# Task Scheduler guide

This guide gives information on the task scheduler application

{@img task_scheduler.png Alt task scheduler}

## Usage 

The task scheduler application allows to launch user's scripts on DSM.

### Information available for each task :

- Enable
- Task name
- Application (or user's script)
- Action (or script content)
- Trigger time
- User (can be root)

## Task scheduler screenshot

{@img task_screen.png Alt task screen}


## Source 

For more details check the class details for the [source code](#!/api/SYNO.SDS.TaskScheduler.TaskSchedulerWidget)
