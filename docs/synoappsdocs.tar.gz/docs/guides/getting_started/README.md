# Applications guides

Welcome to the Application guides section.<br><br>

The below chapters include technical information on modules or 3rd party applications.


## Information available  :

- [Widget module](#!/guide/widget)
- [Task Scheduler application](#!/guide/task_scheduler)







