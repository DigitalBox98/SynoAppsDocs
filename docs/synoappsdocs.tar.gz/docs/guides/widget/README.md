# Widget guide

This guide gives information on the Widget module

## Usage 

The Widget module allows to add widget information on DSM.

### Information available via modules :

- System Health
- Resource monitor
- Storage
- Connected Users
- Schedules Tasks
- File Change Log
- Recent Logs
- Backup

## Widget screenshot

{@img widget.png Alt widget screen}


## Widget modules order  


    @example
	Ext.define("SYNO.SDS._Widget.ViewConfig", {
	    statics: {
	        ModuleOrder: ["SYNO.SDS.SystemInfoApp.SystemHealthWidget", "SYNO.SDS.ResourceMonitor.Widget", "SYNO.SDS.SystemInfoApp.StorageUsageWidget", "SYNO.SDS.SystemInfoApp.ConnectionLogWidget", "SYNO.SDS.BackupApp.ScheduleBackupWidget", "SYNO.SDS.TaskScheduler.TaskSchedulerWidget", "SYNO.SDS.SystemInfoApp.FileChangeLogWidget", "SYNO.SDS.SystemInfoApp.RecentLogWidget"],
	        ModuleList: ["SYNO.SDS.SystemInfoApp.SystemHealthWidget", "SYNO.SDS.ResourceMonitor.Widget"]
	    }
	});

## Source 

For more details check the class details for the [source code](#!/api/SYNO.SDS.Widget.ModuleLoader)
