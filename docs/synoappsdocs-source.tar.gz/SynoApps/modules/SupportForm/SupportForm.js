/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function asyncGeneratorStep(e, t, n, o, i, r, a) {
    try {
        var s = e[r](a),
            l = s.value
    } catch (e) {
        return void n(e)
    }
    s.done ? t(l) : Promise.resolve(l).then(o, i)
}

function _asyncToGenerator(e) {
    return function() {
        var t = this,
            n = arguments;
        return new Promise(function(o, i) {
            function r(e) {
                asyncGeneratorStep(s, o, i, r, a, "next", e)
            }

            function a(e) {
                asyncGeneratorStep(s, o, i, r, a, "throw", e)
            }
            var s = e.apply(t, n);
            r(void 0)
        })
    }
}
Ext.ns("SYNO.SDS.SupportForm"), SYNO.SDS.SupportForm.Module = Ext.extend(Object, {
    constructor: function() {},
    activate: function() {},
    deactivate: function() {
        return !0
    },
    getPanel: function() {
        return null
    },
    getAbsoluteURL: function(e) {
        return String.format("{0}/{1}", this.jsConfig.jsBaseURL, e)
    },
    getHelpParam: Ext.emptyFn
}), Ext.ns("SYNO.SDS.SupportForm"), Ext.define("SYNO.SDS.SupportForm.FormModule", {
    extend: "SYNO.SDS.SupportForm.Module",
    constructor: function(e) {
        this.callParent([e]), this.createPanel(e)
    },
    getPanel: function() {
        return this.panel
    },
    createPanel: function(e) {
        var t = {
            cp: e.cp,
            module: this,
            border: !1,
            frame: !1,
            autoScroll: !1,
            autoFlexcroll: !1,
            header: !1,
            useDefaultBtn: !1,
            layout: "fit",
            items: [{
                xtype: "syno_panel",
                region: "center",
                itemId: "form_iframe",
                padding: 0,
                id: "form_iframe",
                name: "form_iframe",
                hidden: !0,
                autoFlexcroll: !1,
                html: String.format('<iframe id="iframe_form" src="about:blank" frameborder="0" marginheight="0" marginwidth="0" width="100%" height="100%"></iframe>')
            }]
        };
        this.panel = new SYNO.SDS.SupportForm.FormPanel(t)
    },
    stopPolling: function() {
        Ext.isDefined(this.pollingId) && (this.cp.pollUnreg(this.pollingId), delete this.pollingId)
    },
    onPollingDone: function(e, t, n) {
        if (!e) return void this.stopPolling();
        t.finished && this.stopPolling()
    },
    startPolling: function() {
        this.pollingId = this.cp.pollReg({
            webapi: {
                api: "SYNO.Core.SupportForm.Log",
                method: "polling",
                version: 1
            },
            interval: 20,
            scope: this,
            status_callback: this.onPollingDone
        })
    },
    activate: function() {
        this.panel.init(), this.startPolling()
    },
    deactivate: function() {
        this.panel.el.unmask(), Ext.getDom("iframe_form").src = "about:blank", this.stopPolling()
    }
}), Ext.define("SYNO.SDS.SupportForm.FormPanel", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(e) {
        var t = Ext.apply({
            padding: 0
        }, e);
        this.callParent([t])
    },
    init: function() {
        function e() {
            return t.apply(this, arguments)
        }
        var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t = this;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        return e.prev = 0, e.next = 3, this.runAsyncWithMask(_asyncToGenerator(regeneratorRuntime.mark(function e() {
                            var n;
                            return regeneratorRuntime.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, t.queryMyDSCenter();
                                    case 2:
                                        if (n = e.sent, !1 !== n.is_logged_in) {
                                            e.next = 7;
                                            break
                                        }
                                        t.showNotLoggedInMask(), e.next = 13;
                                        break;
                                    case 7:
                                        if (!0 !== n.is_logged_in || !Ext.isDefined(n.account) || !Ext.isDefined(n.auth_key)) {
                                            e.next = 12;
                                            break
                                        }
                                        return e.next = 10, t.loadSupportForm(n.account, n.auth_key);
                                    case 10:
                                        e.next = 13;
                                        break;
                                    case 12:
                                        throw new Error("Invalid format of result from MyDSCenter");
                                    case 13:
                                    case "end":
                                        return e.stop()
                                }
                            }, e, this)
                        })));
                    case 3:
                        e.next = 9;
                        break;
                    case 5:
                        e.prev = 5, e.t0 = e.catch(0), this.alert(_T("support_center", "error_unknown")), SYNO.Debug.debug(e.t0);
                    case 9:
                    case "end":
                        return e.stop()
                }
            }, e, this, [
                [0, 5]
            ])
        }));
        return e
    }(),
    runAsyncWithMask: function() {
        function e(e) {
            return t.apply(this, arguments)
        }
        var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
            var n, o, i, r;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        return n = void 0, o = void 0, i = 0, this.cp.setStatusBusy(n, o, i), e.prev = 4, e.next = 7, t();
                    case 7:
                        return r = e.sent, e.abrupt("return", r);
                    case 9:
                        return e.prev = 9, this.cp.clearStatusBusy(), e.finish(9);
                    case 12:
                    case "end":
                        return e.stop()
                }
            }, e, this, [
                [4, , 9, 12]
            ])
        }));
        return e
    }(),
    queryMyDSCenter: function() {
        return this.sendWebAPIPromise({
            api: "SYNO.Core.MyDSCenter",
            method: "query",
            version: 2
        })
    },
    loadSupportForm: function() {
        function e(e, n) {
            return t.apply(this, arguments)
        }
        var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t, n) {
            var o;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        return e.next = 2, this.sendWebAPIPromise({
                            api: "SYNO.Core.SupportForm.Form",
                            method: "get",
                            version: 1
                        });
                    case 2:
                        return o = e.sent, o.user_id = t, o.auth_key = n, e.next = 7, this.generateIframe(o);
                    case 7:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return e
    }(),
    generateIframe: function(e) {
        var t = this;
        return new Promise(function(n, o) {
            var i = String.format("{0}//{1}/webapi/entry.cgi?api=SYNO.Core.SupportForm.Form&method=upload&version=1&tid={2}", window.location.protocol, window.location.host, e.tid),
                r = "",
                a = "",
                s = t.cp.getOpenConfig("extra");
            if (s && (r = s.pkg_id, a = s.pkg_version), "about:blank" === Ext.getDom("iframe_form").src) {
                var l = setTimeout(function() {
                    this.el.mask(_T("support_center", "error_unknown"), "syno-ux-mask-info"), Ext.getCmp("form_iframe").setVisible(!1), Ext.getDom("iframe_form").src = "about:blank", n()
                }.createDelegate(t), 6e4);
                Ext.EventManager.on(Ext.getDom("iframe_form"), "load", function() {
                    Ext.EventManager.removeAll(Ext.getDom("iframe_form")), clearTimeout(l), l = null, Ext.getCmp("form_iframe").setVisible(!0), Ext.EventManager.on(Ext.getDom("iframe_form"), "load", function() {
                        if (Ext.EventManager.removeAll(Ext.getDom("iframe_form")), "about:blank" === Ext.getDom("iframe_form").src);
                        else {
                            var e = t.getFrameResponse();
                            t.onFormSubmitted(e)
                        }
                    }), n()
                }, t);
                var u = {
                    user_id: e.user_id,
                    auth_key: e.auth_key,
                    dsm_user: t._S("user"),
                    sn: e.sn,
                    model: e.model,
                    dsm_version: e.version,
                    pseudo_sn: e.pseudo_sn,
                    pseudo_model: e.pseudo_model,
                    pseudo_dsm_version: e.pseudo_dsm_version,
                    timestamp: e.timestamp,
                    theme: _S("theme_cls"),
                    lang: _S("lang"),
                    supportform_version: 2,
                    buildphase: e.buildphase,
                    isdemo: !!t._S("demo_mode"),
                    pkg_id: r,
                    pkg_version: a,
                    user_agnet: navigator.userAgent,
                    url: i
                };
                Ext.getDom("iframe_form").setAttribute("src", String.format(e.server_baseurl + "/iframe/support?{0}{1}", Ext.urlEncode(u), t.getCustomParam(e.custom)))
            } else n()
        })
    },
    alert: function(e) {
        var t = this;
        return new Promise(function(n, o) {
            t.cp.getMsgBox().alert(_T("support_center", "title"), e, n)
        })
    },
    formSubmittedResponseToMessage: function(e) {
        if (e.success) return "" !== e.data.msg ? e.data.msg : e.data.attach ? _T("support_center", "send_attach") : _T("support_center", "success_send_form");
        switch (e.error.code) {
            case 119:
                return _T("support_center", "error_support_ticket_timeout");
            case 4703:
                return e.error.errors.result.msg;
            case 4701:
            default:
                return _T("support_center", "error_unknown")
        }
    },
    onFormSubmitted: function() {
        function e(e) {
            return t.apply(this, arguments)
        }
        var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
            var n;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        return Ext.getCmp("form_iframe").setVisible(!1), Ext.getDom("iframe_form").src = "about:blank", n = this.formSubmittedResponseToMessage(t), e.next = 5, this.alert(n);
                    case 5:
                        return e.next = 7, this.init();
                    case 7:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return e
    }(),
    getCustomParam: function(e) {
        var t = "";
        return Ext.iterate(e, function(e, n) {
            t += "&custom[" + e + "]=" + n
        }, this), t
    },
    getFrameResponse: function() {
        var e = {};
        try {
            var t, n, o = Ext.getDom("iframe_form"),
                i = o.contentWindow.document || o.contentDocument || window.frames.iframe_form.document;
            if (!i || !i.body) throw {
                message: "Failed to get iframe body"
            };
            n = (t = i.body.firstChild) && /pre/i.test(t.tagName) ? t.textContent : (t = i.getElementsByTagName("textarea")[0]) ? t.value : i.body.textContent || i.body.innerText, e = Ext.decode(n)
        } catch (t) {
            e = {
                success: !1,
                error: (t.message || t.description).trim()
            }
        }
        return e
    },
    showNotLoggedInMask: function() {
        var e, t, n;
        e = String.format('<a href="" class="link-font" id="login_btn">{0}</a>', _T("myds", "myds_account")), t = String.format(_T("support_center", "support_login_first"), e), this.el.mask(t, "syno-ux-mask-info"), n = Ext.get("login_btn"), Ext.isObject(n) && n.on("click", this.onClickLoginBtn, this)
    },
    popLoginWeb: function() {
        function e() {
            return t.apply(this, arguments)
        }
        var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t = this;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        if (void 0 !== this.webLogin) {
                            e.next = 4;
                            break
                        }
                        return e.next = 3, SYNO.SDS.SynologyAccount.WebLogin.create();
                    case 3:
                        this.webLogin = e.sent;
                    case 4:
                        return e.abrupt("return", new Promise(function(e, n) {
                            var o = function() {
                                return e(null)
                            };
                            t.webLogin.popLoginWeb(e, n, o)
                        }));
                    case 5:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return e
    }(),
    onClickLoginBtn: function() {
        function e(e) {
            return t.apply(this, arguments)
        }
        var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
            var n = this;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        return t.preventDefault(), e.prev = 1, e.next = 4, this.runAsyncWithMask(_asyncToGenerator(regeneratorRuntime.mark(function e() {
                            var t, o, i;
                            return regeneratorRuntime.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, n.popLoginWeb();
                                    case 2:
                                        if (null === (t = e.sent)) {
                                            e.next = 8;
                                            break
                                        }
                                        return n.el.unmask(), o = t.account, i = t.auth_key, e.next = 8, n.loadSupportForm(o, i);
                                    case 8:
                                    case "end":
                                        return e.stop()
                                }
                            }, e, this)
                        })));
                    case 4:
                        e.next = 10;
                        break;
                    case 6:
                        e.prev = 6, e.t0 = e.catch(1), this.alert(_T("support_center", "error_unknown")), SYNO.Debug.debug(e.t0);
                    case 10:
                    case "end":
                        return e.stop()
                }
            }, e, this, [
                [1, 6]
            ])
        }));
        return e
    }()
}), Ext.ns("SYNO.SDS.SupportForm"), Ext.define("SYNO.SDS.SupportForm.RemoteModule", {
    extend: "SYNO.SDS.SupportForm.Module",
    constructor: function(e) {
        this.callParent([e]), this.createPanel(e), this.panel.mon(this.panel, "afterlayout", this.switchLayout, this), this.panel.mon(Ext.getCmp(this.hibernation_debug_id), "check", this.switchLayout, this)
    },
    getPanel: function() {
        return this.panel
    },
    onCommit: function() {
        if (!this.panel.isFormDirty() && !this.panel.isDebugItemDirty()) return void this.panel.setStatusError({
            text: _T("error", "nochange_subject"),
            clear: !0
        });
        this.cp.getEl().mask(_T("common", "loading"));
        var e = {
            enable_support_channel: Ext.getCmp(this.enable_support_channel_id).getValue(),
            hibernation_debug_en: Ext.getCmp(this.hibernation_debug_id).getValue(),
            hibernation_debug_level: Ext.getCmp(this.hibernation_debug_level).getValue(),
            fan_debug_en: Ext.getCmp(this.fan_debug_id).getValue(),
            sysstat_dump_en: Ext.getCmp(this.sysstat_dump_id).getValue()
        };
        Ext.apply(e, this.panel.getDebugItemParam()), this.cp.sendWebAPI({
            api: "SYNO.Core.SupportForm.Service",
            method: "set",
            version: 1,
            params: e,
            scope: this,
            callback: function(e, t, n) {
                this.cp && !this.cp.isDestroyed && (this.cp.getEl().unmask(), e || this.cp.getMsgBox().alert("", _T("error", "error_error_system")), this.panel.loadForm())
            }
        })
    },
    onReset: function() {
        this.panel.loadForm()
    },
    createPanel: function(e) {
        var t = {
            cp: e.cp,
            module: this,
            border: !1,
            frame: !1,
            autoScroll: !0,
            header: !1,
            useDefaultBtn: !1,
            padding: 0,
            webapi: {
                api: "SYNO.Core.SupportForm.Service",
                methods: {
                    get: "get"
                },
                version: 1
            },
            buttons: [{
                btnStyle: "gray",
                text: _T("common", "reset"),
                xtype: "syno_button",
                scope: this,
                handler: this.onReset
            }, {
                btnStyle: "blue",
                text: _T("common", "commit"),
                xtype: "syno_button",
                scope: this,
                handler: this.onCommit
            }],
            items: [{
                xtype: "syno_fieldset",
                title: _T("support_center", "fieldset_remote"),
                itemId: "remote_fieldset",
                name: "remote_fieldset",
                id: "remote_fieldset",
                items: [{
                    xtype: "syno_displayfield",
                    hideLabel: !0,
                    value: _T("support_center", "remote_desc")
                }, {
                    xtype: "syno_checkbox",
                    boxLabel: _T("support_center", "support_channel_chkbox"),
                    itemId: "enable_support_channel",
                    id: this.enable_support_channel_id = Ext.id(),
                    name: "enable_support_channel"
                }, {
                    xtype: "syno_displayfield",
                    fieldLabel: _T("support_center", "expired_date"),
                    htmlEncode: !1,
                    name: "expiredate",
                    labelWidth: 280,
                    indent: 1,
                    value: "-"
                }, {
                    xtype: "syno_displayfield",
                    fieldLabel: _T("support_center", "sns_identifier_key"),
                    name: "sns_identifier_key",
                    labelWidth: 280,
                    selectable: !0,
                    indent: 1,
                    value: "-"
                }]
            }, {
                xtype: "syno_fieldset",
                title: _T("support_center", "support_log_tool_title"),
                itemId: "log_tools",
                name: "log_tools",
                id: "log_tools",
                items: this.getLogToolSetting()
            }, {
                xtype: "syno_fieldset",
                title: _T("support_center", "fieldset_log"),
                itemId: "log_fieldset",
                name: "log_fieldset",
                id: "log_fieldset",
                items: [{
                    xtype: "syno_displayfield",
                    hideLabel: !0,
                    value: _T("support_center", "log_desc")
                }, {
                    xtype: "syno_button",
                    btnStyle: "default",
                    id: "log_btn",
                    text: _T("support_center", "log_generate_btn"),
                    autoWidth: !0,
                    scope: this,
                    tooltip: e.cp._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                    handler: this.doDownload
                }]
            }]
        };
        this.panel = new SYNO.SDS.SupportForm.ServicePanel(t)
    },
    getLogToolSetting: function() {
        var e = new Ext.data.SimpleStore({
            fields: ["display", "value"],
            data: [
                [_T("support_center", "support_hibernation_cannot_sleep"), 1],
                [_T("support_center", "support_hibernation_awake_frequently"), 2]
            ]
        });
        return [{
            xtype: "syno_checkbox",
            boxLabel: _T("support_center", "support_hibernation_debug_mode"),
            itemId: "hibernation_debug_en",
            name: "hibernation_debug_en",
            id: this.hibernation_debug_id = Ext.id(),
            listeners: {
                scope: this,
                check: function(e, t) {
                    var n = Ext.getCmp(this.hibernation_debug_level);
                    t ? (n.enable(), n.setValue(1)) : (n.disable(), n.clearValue())
                }
            }
        }, {
            xtype: "syno_displayfield",
            indent: 1,
            htmlEncode: !1,
            value: String.format('<span class="syno-ux-note">{0}{1}</span> {2}', _T("common", "note"), _T("common", "colon"), _T("support_center", "support_hibernation_note"))
        }, {
            xtype: "syno_combobox",
            store: e,
            name: "hibernation_debug_level",
            fieldLabel: _T("support_center", "support_hibernation_problem"),
            indent: 1,
            displayField: "display",
            valueField: "value",
            editable: !1,
            id: this.hibernation_debug_level = Ext.id()
        }, {
            xtype: "syno_checkbox",
            boxLabel: _T("support_center", "support_fan_debug_mode"),
            itemId: "fan_debug_en",
            name: "fan_debug_en",
            id: this.fan_debug_id = Ext.id()
        }, {
            xtype: "syno_checkbox",
            boxLabel: _T("support_center", "support_system_stat_dump"),
            itemId: "sysstat_dump_en",
            name: "sysstat_dump_en",
            id: this.sysstat_dump_id = Ext.id()
        }]
    },
    switchLayout: function() {
        var e = Ext.getCmp(this.hibernation_debug_id).getValue();
        this.setCompEnable([Ext.getCmp(this.fan_debug_id), Ext.getCmp(this.sysstat_dump_id)], !e), e ? Ext.getCmp(this.hibernation_debug_level).enable() : (Ext.getCmp(this.hibernation_debug_level).disable(), Ext.getCmp(this.hibernation_debug_level).clearValue())
    },
    setCompEnable: function(e, t) {
        for (var n = 0; n < e.length; n++) t ? e[n].enable() : (e[n].disable(), e[n].setValue(!1))
    },
    activate: function() {
        this.panel.loadForm()
    },
    deactivate: function() {
        return !this.panel.isFormDirty() && !this.panel.isDebugItemDirty()
    },
    onDownloadFail: function() {
        this.wait.hide(), this.cp.getMsgBox().alert(_T("download", "download_failed"), _T("download", "download_msg_action_failed"))
    },
    doDownload: function(e, t, n, o) {
        var i = [];
        if (i = this.panel.getFilterComponent(), 0 === i.length) return void this.cp.getMsgBox().alert("", _T("filetable", "filetable_select_one"));
        this.wait = this.cp.getMsgBox().wait(_T("relayservice", "file_downloading")), this.cp.sendWebAPI({
            scope: this,
            webapi: {
                api: "SYNO.Core.SupportForm.Log",
                version: 1,
                method: "collect",
                params: {
                    app_list: i
                }
            },
            callback: function(e, t) {
                if (!e) return void this.onDownloadFail();
                this.taskId = t.task_id, this.startPolling()
            }
        })
    },
    startPolling: function() {
        this.pollingId = this.cp.pollReg({
            webapi: {
                api: "SYNO.Core.SupportForm.Log",
                method: "status",
                version: 1,
                params: {
                    task_id: this.taskId
                }
            },
            interval: 5,
            status_callback: this.onPollingDone,
            scope: this
        })
    },
    stopPolling: function() {
        Ext.isDefined(this.pollingId) && (this.cp.pollUnreg(this.pollingId), delete this.pollingId)
    },
    onPollingDone: function(e, t, n) {
        if (!e) return this.stopPolling(), void this.onDownloadFail();
        t.finished && (this.stopPolling(), this.wait.hide(), this.onCollectDone(t.path))
    },
    onCollectDone: function(e) {
        this.cp.downloadWebAPI({
            scope: this,
            webapi: {
                api: "SYNO.Core.SupportForm.Log",
                version: 1,
                method: "download",
                params: {
                    path: e
                }
            },
            callback: function(e, t) {
                e || this.onDownloadFail()
            }
        })
    }
}), Ext.define("SYNO.SDS.SupportForm.ServicePanel", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(e) {
        this.filter_prefix = "filter_", this.callParent([e])
    },
    processReturnData: function(e, t, n) {
        for (var o = 0; o < t.result.length; o++) "SYNO.Core.SupportForm.Service" == t.result[o].api && "get" == t.result[o].method && (this.updateRemoteComponent(t.result[o].data), this.updateFilterComponent(t.result[o].data.app_list), 0 >= t.result[o].data.fan_num && this.hideFanDebug());
        SYNO.SDS.SupportForm.ServicePanel.superclass.processReturnData.call(this, e, t, n), this.doLayout()
    },
    updateRemoteComponent: function(e) {
        if (null === e.sns_identifier_key && (e.sns_identifier_key = "-"), null === e.expiredate) e.expiredate = "-";
        else {
            var t = Date.parseDate(e.expiredate, "Y/n/j"),
                n = SYNO.SDS.DateTimeFormatter(t, {
                    type: "date"
                });
            e.expiredate = '<font class="syno-supportform-expire">' + n + "</font>"
        }
    },
    processParams: function(e, t) {
        return "set" !== e ? SYNO.SDS.SupportForm.ServicePanel.superclass.processParams.call(this, e, t) : (Ext.isArray(t) && Ext.isObject(t[0]) && "set" === t[0].method && Ext.isEmpty(t[0].params), t)
    },
    updateFilterComponent: function(e) {
        var t = this.cp.getOpenConfig("extra"),
            n = Ext.isObject(t) ? t.pkg_id : "",
            o = this.getComponent("log_fieldset"),
            i = [];
        Ext.isEmpty(o) || Ext.isEmpty(e) || (Ext.isEmpty(this.filterComponent) || (o.remove(this.filterComponent), delete this.filterComponent), e.forEach(function(e) {
            i.push({
                enable: e.enable || e.id === n,
                id: e.id,
                name: e.name
            })
        }, this), this.enableColumn = new SYNO.ux.EnableColumn({
            header: _T("common", "enabled"),
            dataIndex: "enable",
            menuDisabled: !0,
            sortable: !0,
            width: .2,
            align: "center"
        }), this.filterStore = new Ext.data.JsonStore({
            fields: ["enable", "id", "name"],
            autoLoad: !1
        }), this.filterComponent = new SYNO.ux.GridPanel({
            padding: 0,
            enableHdMenu: !1,
            plugins: [this.enableColumn],
            store: this.filterStore,
            columns: [this.enableColumn, {
                header: _T("status", "header_item"),
                dataIndex: "name",
                width: .8
            }]
        }), this.filterStore.loadData(i), this.filterComponent.setHeight(42 + 29 * i.length), o.insert(1, this.filterComponent), o.doLayout())
    },
    isDebugItemDirty: function() {
        return 0 !== this.filterComponent.getStore().getModifiedRecords().length
    },
    getFilterComponent: function() {
        var e = [];
        return this.filterComponent.getStore().each(function(t) {
            t.data.enable && e.push(t.data.id)
        }, this), e
    },
    getDebugItemParam: function() {
        var e = {};
        return this.filterComponent.getStore().each(function(t) {
            e[this.filter_prefix + t.data.id] = t.data.enable
        }, this), e
    },
    hideFanDebug: function() {
        var e = this.getComponent("log_tools");
        if (e) {
            var t = e.getComponent("fan_debug_en");
            t && t.hide()
        }
    }
}), Ext.ns("SYNO.SDS.SupportForm"), 
 /**
 * @class SYNO.SDS.SupportForm.Application
 * @extends SYNO.SDS.AppInstance
 * SupportForm application instance class
 *
 */  
SYNO.SDS.SupportForm.Application = Ext.extend(SYNO.SDS.AppInstance, {
    appWindowName: "SYNO.SDS.SupportForm.MainWindow"
}), SYNO.SDS.SupportForm.MainWindow = Ext.extend(SYNO.SDS.AppWindow, {
    constructor: function(e) {
        this.appInstance = e.appInstance;
        var t = this.fillConfig(e);
        SYNO.SDS.SupportForm.MainWindow.superclass.constructor.call(this, t)
    },
    fillConfig: function(e) {
        var t = {
            layout: "border",
            cls: "syno-app-support-form",
            dsmStyle: "v5",
            minWidth: 1e3,
            minHeight: 570,
            width: 1e3,
            height: 570,
            border: !1,
            plain: !0,
            items: [this.moduleList = new SYNO.SDS.SupportForm.ModuleList({
                region: "west",
                appWin: this
            }), this.moduleCt = new SYNO.ux.Panel({
                layout: "card",
                padding: "16px 12px 0 16px",
                border: !1,
                frame: !1,
                hideMode: "offsets",
                cls: "syno-app-support-form-module-ct",
                region: "center",
                appWin: this
            })]
        };
        return Ext.apply(t, e), t
    },
    getModule: function(e) {
        var t, n = this.moduleCt,
            o = n.getComponent(e);
        if (o) t = o.module;
        else {
            var i;
            i = Ext.getClassByName(e), i.prototype.jsConfig = this.jsConfig, t = new i({
                cp: this
            }), t.cp = this, o = t.getPanel(), o.module = t, o.itemId = e, n.add(o), t.title = o.title, t.height = o.height
        }
        return t
    },
    activateModule: function(e, t) {
        if (e && e.activate) {
            var n = e.getPanel();
            n instanceof Ext.TabPanel && Ext.isFunction(n.setActiveTab) && n.setActiveTab(0), e.activate(t)
        }
    },
    startModule: function(e, t) {
        var n;
        if (!(n = this.getModule(e))) return !1;
        this.moduleCt.layout.setActiveItem(e), this.activateModule(n, t)
    },
    deactivateModule: function(e, t) {
        var n = this.getModule(e);
        if (n && n.deactivate) return n.deactivate(t)
    },
    onActivate: function() {
        var e = Ext.getDom("iframe_form");
        if (e) {
            var t = Ext.get(e.parentNode).query(".sds-shim-for-iframe");
            Ext.each(t, function(e) {
                Ext.removeNode(e)
            })
        }
        SYNO.SDS.SupportForm.MainWindow.superclass.onActivate.apply(this, arguments)
    },
    onDeactivate: function() {
        if (Ext.getDom("iframe_form")) {
            var e = document.createElement("div");
            e.classList.add("sds-shim-for-iframe"), Ext.get(Ext.getDom("iframe_form").parentNode).appendChild(e)
        }
        SYNO.SDS.SupportForm.MainWindow.superclass.onDeactivate.apply(this, arguments)
    },
    onClose: function() {
        var e = this;
        if (this.isSkipDeactivateCheck()) return this.clearSkipDeactivateCheck(), !0;
        var t, n = !0;
        if ((t = this.moduleList.getSelectionModel().getSelectedNode().attributes.fn) && !1 === (n = this.deactivateModule(t))) {
            var o = this.getModule("SYNO.SDS.SupportForm.RemoteModule");
            this.confirmLostChangePromise({
                save: function() {
                    o.onCommit(), e.setSkipDeactivateCheck(), e.close()
                },
                dontSave: function() {
                    e.setSkipDeactivateCheck(), e.close()
                },
                cancel: Ext.emptyFn
            }, this)
        }
        return n
    },
    isSkipDeactivateCheck: function() {
        return !!this.skipDeactivateCheckFlag
    },
    setSkipDeactivateCheck: function() {
        this.skipDeactivateCheckFlag = !0
    },
    clearSkipDeactivateCheck: function() {
        this.skipDeactivateCheckFlag = !1
    }
}), SYNO.SDS.SupportForm.ModuleList = Ext.extend(SYNO.ux.ModuleList, {
    constructor: function(e) {
        var t = this.fillConfig(e);
        SYNO.SDS.SupportForm.ModuleList.superclass.constructor.call(this, t), this.getSelectionModel().on("selectionchange", this.onModuleListSelect, this), this.getSelectionModel().on("beforeselect", this.onBeforeSelect, this)
    },
    fillConfig: function(e) {
        var t = {
            itemId: "module_list",
            padding: "16px 12px 0 12px",
            listItems: [{
                text: "support_center:support_form",
                iconCls: "cate-icn-contact",
                fn: "SYNO.SDS.SupportForm.FormModule"
            }, {
                text: "support_center:support_services",
                iconCls: "cate-icn-utilities",
                fn: "SYNO.SDS.SupportForm.RemoteModule"
            }],
            listeners: {
                scope: this,
                single: !0,
                load: function() {
                    (function() {
                        this.selectModule("SYNO.SDS.SupportForm.FormModule")
                    }).defer(200, this)
                }
            }
        };
        return Ext.apply(t, e), t
    },
    onBeforeSelect: function(e, t, n) {
        var o = this;
        if (!n) return !0;
        if (this.appWin.isSkipDeactivateCheck()) return this.appWin.clearSkipDeactivateCheck(), !0;
        var i, r = !0;
        if ((i = n.attributes.fn) && !1 === (r = this.appWin.deactivateModule(i))) {
            var a = this.appWin.getModule("SYNO.SDS.SupportForm.RemoteModule");
            this.appWin.confirmLostChangePromise({
                save: function() {
                    a.onCommit(), o.appWin.setSkipDeactivateCheck(), o.appWin.moduleList.selectModule(t.attributes.fn)
                },
                dontSave: function() {
                    a.onReset(), o.appWin.setSkipDeactivateCheck(), o.appWin.moduleList.selectModule(t.attributes.fn)
                },
                cancel: Ext.emptyFn
            }, this)
        }
        return r
    },
    onModuleListSelect: function(e, t) {
        var n;
        t.leaf && (n = t.attributes.fn, n ? this.appWin.startModule(n) : this.appWin.getMsgBox().alert(this.appWin.title, "not implemented yet"))
    }
});
