/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function _typeof(t) {
    return (_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
        return typeof t
    } : function(t) {
        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
    })(t)
}! function(t) {
    var e = {};

    function n(r) {
        if (e[r]) return e[r].exports;
        var o = e[r] = {
            i: r,
            l: !1,
            exports: {}
        };
        return t[r].call(o.exports, o, o.exports, n), o.l = !0, o.exports
    }
    n.m = t, n.c = e, n.d = function(t, e, r) {
        n.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: r
        })
    }, n.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }, n.t = function(t, e) {
        if (1 & e && (t = n(t)), 8 & e) return t;
        if (4 & e && "object" === _typeof(t) && t && t.__esModule) return t;
        var r = Object.create(null);
        if (n.r(r), Object.defineProperty(r, "default", {
                enumerable: !0,
                value: t
            }), 2 & e && "string" != typeof t)
            for (var o in t) n.d(r, o, function(e) {
                return t[e]
            }.bind(null, o));
        return r
    }, n.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t.default
        } : function() {
            return t
        };
        return n.d(e, "a", e), e
    }, n.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, n.p = "", n(n.s = 22)
}([function(t, e) {
    t.exports = Vue
}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {
    t.exports = n(45)
}, function(t, e, n) {
    "use strict";
    var r = n(1);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(2);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(3);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(4);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(5);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(6);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(7);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(8);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(9);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(10);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(11);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(12);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(13);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(14);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(15);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(16);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(17);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(18);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(19);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(20);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(21);
    n.n(r).a
}, function(t, e, n) {}, function(t, e, n) {
    "use strict";
    n.r(e);
    var r = {};
    n.r(r), n.d(r, "generateDsmFqdnRulesByValidator", function() {
        return mt
    }), n.d(r, "generateApplicationFqdnRulesByValidator", function() {
        return ht
    }), n.d(r, "generateDsmPortRulesByValidator", function() {
        return vt
    }), n.d(r, "generateApplicationPortRulesByValidator", function() {
        return _t
    }), n.d(r, "generateAliasRulesByValidator", function() {
        return gt
    }), n.d(r, "generateAccessControlNameRules", function() {
        return yt
    }), n.d(r, "accessControlCidrRules", function() {
        return bt
    });
    var o = n(0),
        i = n.n(o),
        a = {
            created: function() {
                this.SYNO = window.SYNO
            },
            methods: {
                _TT: function(t, e, n) {
                    try {
                        return SYNO.SDS.Strings[t][e][n]
                    } catch (t) {
                        return ""
                    }
                },
                _JSLIBSTR: function(t, e) {
                    try {
                        return SYNOJSLIB_Strings[t][e]
                    } catch (t) {
                        return ""
                    }
                }
            }
        };

    function s(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }

    function c(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise(function(r, o) {
                var i = t.apply(e, n);

                function a(t) {
                    s(i, r, o, a, c, "next", t)
                }

                function c(t) {
                    s(i, r, o, a, c, "throw", t)
                }
                a(void 0)
            })
        }
    }

    function l(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter(function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            }))), r.forEach(function(e) {
                u(t, e, n[e])
            })
        }
        return t
    }

    function u(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }
    var p = {
        props: {
            applicationId: {
                type: String,
                required: !0
            },
            profile: {
                type: Object,
                required: !0
            },
            onlyShowCustom: {
                type: Boolean,
                default: !1
            },
            forceBackgroundImage: {
                type: String
            }
        },
        mounted: function() {
            this.$watch("backgroundImage", this.getBackgroundSize, {
                immediate: !0
            })
        },
        computed: {
            isRetina: function() {
                return SYNO.SDS.UIFeatures.IconSizeManager.isRetinaMode()
            },
            resolution: function() {
                return this.isRetina ? "2x" : "1x"
            },
            appFnMapConfig: function() {
                return SYNO.SDS.Config.FnMap[this.applicationId].config
            },
            needBackgroundSize: function() {
                return ["center", "tile"].includes(this.profile.background_position)
            },
            defaultBackgroundImage: function() {
                if ("dsm" === this.applicationId) return "webman/resources/images/".concat(this.resolution, "/default_login_background/dsm7_01.jpg");
                var t = this.appFnMapConfig.jsBaseURL,
                    e = this.appFnMapConfig.loginStyle.defaultLoginWallpaper.replace("{0}", "1x");
                return "".concat(t, "/").concat(e)
            },
            customBackgroundImage: function() {
                if (this.profile.only_background_color) return "";
                if (this.forceBackgroundImage) return this.forceBackgroundImage;
                if ("dsm" === this.applicationId && this.profile.background_seq || "dsm" !== this.applicationId && this.profile.login_background_seq) {
                    var t = {
                        api: "SYNO.Core.Theme.Image",
                        version: 1,
                        method: "get",
                        params: l({
                            type: "login_background",
                            data: this.profile.background_seq
                        }, "dsm" !== this.applicationId ? {
                            app: this.applicationId
                        } : {})
                    };
                    return "".concat(SYNO.API.GetBaseURL(t), "&_v=").concat(Date.now())
                }
                return this.defaultBackgroundImage
            },
            previewBackgroundImage: function() {
                return this.profile.enable_background_customize || this.profile.only_background_color ? this.customBackgroundImage : this.defaultBackgroundImage
            },
            backgroundImage: function() {
                return this.onlyShowCustom ? this.customBackgroundImage : this.previewBackgroundImage
            }
        },
        data: function() {
            return {
                backgroundSize: [0, 0]
            }
        },
        methods: {
            getBackgroundNativeSize: function() {
                var t = c(regeneratorRuntime.mark(function t() {
                    var e;
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (this.backgroundImage) {
                                    t.next = 2;
                                    break
                                }
                                return t.abrupt("return", [0, 0]);
                            case 2:
                                return (e = new Image).src = this.backgroundImage, t.next = 6, new Promise(function(t) {
                                    return e.addEventListener("load", t)
                                });
                            case 6:
                                return t.abrupt("return", [e.width, e.height]);
                            case 7:
                            case "end":
                                return t.stop()
                        }
                    }, t, this)
                }));
                return function() {
                    return t.apply(this, arguments)
                }
            }(),
            getBackgroundSize: function() {
                var t = c(regeneratorRuntime.mark(function t() {
                    var e;
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.next = 2, this.getBackgroundNativeSize();
                            case 2:
                                e = t.sent, this.backgroundSize = [154 * e[0] / window.outerWidth, 96 * e[1] / window.outerHeight];
                            case 4:
                            case "end":
                                return t.stop()
                        }
                    }, t, this)
                }));
                return function() {
                    return t.apply(this, arguments)
                }
            }()
        }
    };
    n(23);

    function d(t, e, n, r, o, i, a, s) {
        var c, l = "function" == typeof t ? t.options : t;
        if (e && (l.render = e, l.staticRenderFns = n, l._compiled = !0), r && (l.functional = !0), i && (l._scopeId = "data-v-" + i), a ? (c = function(t) {
                (t = t || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) || "undefined" == typeof __VUE_SSR_CONTEXT__ || (t = __VUE_SSR_CONTEXT__), o && o.call(this, t), t && t._registeredComponents && t._registeredComponents.add(a)
            }, l._ssrRegister = c) : o && (c = s ? function() {
                o.call(this, this.$root.$options.shadowRoot)
            } : o), c)
            if (l.functional) {
                l._injectStyles = c;
                var u = l.render;
                l.render = function(t, e) {
                    return c.call(e), u(t, e)
                }
            } else {
                var p = l.beforeCreate;
                l.beforeCreate = p ? [].concat(p, c) : [c]
            } return {
            exports: t,
            options: l
        }
    }
    var f = d(p, function() {
        var t = this.$createElement;
        return (this._self._c || t)("div", {
            class: ["preview-image", "preview-image--" + this.profile.background_position],
            style: {
                "background-image": "url('" + this.backgroundImage + "')",
                "background-color": this.profile.background_color,
                "background-size": this.needBackgroundSize ? this.backgroundSize[0] + "px " + this.backgroundSize[1] + "px" : void 0
            }
        })
    }, [], !1, null, "54a99782", null).exports;

    function m(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter(function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            }))), r.forEach(function(e) {
                h(t, e, n[e])
            })
        }
        return t
    }

    function h(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }

    function v(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }

    function _(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise(function(r, o) {
                var i = t.apply(e, n);

                function a(t) {
                    v(i, r, o, a, s, "next", t)
                }

                function s(t) {
                    v(i, r, o, a, s, "throw", t)
                }
                a(void 0)
            })
        }
    }

    function g() {
        return y.apply(this, arguments)
    }

    function y() {
        return (y = _(regeneratorRuntime.mark(function t() {
            var e, n = arguments;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = n.length > 0 && void 0 !== n[0] ? n[0] : {}, t.next = 3, synowebapi.promises.request({
                            api: "SYNO.Core.AppPortal",
                            version: 2,
                            method: "list",
                            params: e
                        });
                    case 3:
                        return t.abrupt("return", t.sent);
                    case 4:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }))).apply(this, arguments)
    }

    function b() {
        return w.apply(this, arguments)
    }

    function w() {
        return (w = _(regeneratorRuntime.mark(function t() {
            var e, n, r, o = arguments;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = o.length > 0 && void 0 !== o[0] ? o[0] : "dsm", n = "dsm" === e ? {
                            api: "SYNO.Core.Theme.Login",
                            version: 1,
                            method: "get"
                        } : {
                            api: "SYNO.Core.Theme.AppPortalLogin",
                            version: 1,
                            method: "get",
                            params: {
                                app: e
                            }
                        }, t.next = 4, synowebapi.promises.request(n);
                    case 4:
                        return r = t.sent, t.abrupt("return", m({
                            login_title: "",
                            login_welcome_title: "",
                            login_welcome_msg: "",
                            login_footer_msg: ""
                        }, r));
                    case 6:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }))).apply(this, arguments)
    }

    function x() {
        return k.apply(this, arguments)
    }

    function k() {
        return (k = _(regeneratorRuntime.mark(function t() {
            var e, n, r, o, i, a = arguments;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = a.length > 0 && void 0 !== a[0] ? a[0] : "dsm", n = a.length > 1 && void 0 !== a[1] ? a[1] : {}, r = "dsm" === e ? n.logo_path || n.logo_seq > 0 : n.logo_path || n.login_logo_seq > -1, o = m({}, n, {
                            enable_logo_customize: !(!n.enable_logo_customize || !r)
                        }), i = "dsm" === e ? {
                            api: "SYNO.Core.Theme.Login",
                            version: 1,
                            method: "set",
                            params: o
                        } : {
                            api: "SYNO.Core.Theme.AppPortalLogin",
                            version: 1,
                            method: "set",
                            params: m({
                                app: e
                            }, o)
                        }, t.next = 7, synowebapi.promises.request(i);
                    case 7:
                        return t.abrupt("return", t.sent);
                    case 8:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }))).apply(this, arguments)
    }

    function S() {
        return $.apply(this, arguments)
    }

    function $() {
        return ($ = _(regeneratorRuntime.mark(function t() {
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.next = 2, synowebapi.promises.request({
                            api: "SYNO.Core.Web.DSM",
                            version: 2,
                            method: "get"
                        });
                    case 2:
                        return t.abrupt("return", t.sent);
                    case 3:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }))).apply(this, arguments)
    }

    function C() {
        return P.apply(this, arguments)
    }

    function P() {
        return (P = _(regeneratorRuntime.mark(function t() {
            var e, n, r = arguments;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = r.length > 0 && void 0 !== r[0] ? r[0] : {}, (n = JSON.parse(JSON.stringify(e))).http_port = parseInt(n.http_port, 10), n.https_port = parseInt(n.https_port, 10), t.next = 6, synowebapi.promises.request({
                            api: "SYNO.Core.Web.DSM",
                            version: 2,
                            method: "set",
                            params: n
                        });
                    case 6:
                        return t.abrupt("return", t.sent);
                    case 7:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }))).apply(this, arguments)
    }

    function R() {
        return A.apply(this, arguments)
    }

    function A() {
        return (A = _(regeneratorRuntime.mark(function t() {
            var e, n = arguments;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = n.length > 0 && void 0 !== n[0] ? n[0] : "", t.next = 3, synowebapi.promises.request({
                            api: "SYNO.Core.AppPortal",
                            method: "get",
                            version: 2,
                            params: {
                                id: e,
                                additional: ["default_setting"]
                            }
                        });
                    case 3:
                        return t.abrupt("return", t.sent);
                    case 4:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }))).apply(this, arguments)
    }

    function O() {
        return I.apply(this, arguments)
    }

    function I() {
        return (I = _(regeneratorRuntime.mark(function t() {
            var e, n, r = arguments;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = r.length > 0 && void 0 !== r[0] ? r[0] : {}, (n = JSON.parse(JSON.stringify(e))).http_port && (n.http_port = parseInt(n.http_port, 10)), n.https_port && (n.https_port = parseInt(n.https_port, 10)), t.next = 6, synowebapi.promises.request({
                            api: "SYNO.Core.AppPortal",
                            method: "set",
                            version: 2,
                            params: n
                        });
                    case 6:
                        return t.abrupt("return", t.sent);
                    case 7:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }))).apply(this, arguments)
    }

    function D() {
        return q.apply(this, arguments)
    }

    function q() {
        return (q = _(regeneratorRuntime.mark(function t() {
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.next = 2, synowebapi.promises.request({
                            api: "SYNO.Core.AppPortal.ReverseProxy",
                            method: "list",
                            version: 1
                        });
                    case 2:
                        return t.abrupt("return", t.sent);
                    case 3:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }))).apply(this, arguments)
    }

    function E() {
        return T.apply(this, arguments)
    }

    function T() {
        return (T = _(regeneratorRuntime.mark(function t() {
            var e, n = arguments;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = n.length > 0 && void 0 !== n[0] ? n[0] : {}, t.next = 3, synowebapi.promises.request({
                            api: "SYNO.Core.AppPortal.ReverseProxy",
                            method: "create",
                            version: 1,
                            params: {
                                entry: e
                            }
                        });
                    case 3:
                        return t.abrupt("return", t.sent);
                    case 4:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }))).apply(this, arguments)
    }

    function N() {
        return B.apply(this, arguments)
    }

    function B() {
        return (B = _(regeneratorRuntime.mark(function t() {
            var e, n = arguments;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = n.length > 0 && void 0 !== n[0] ? n[0] : {}, t.next = 3, synowebapi.promises.request({
                            api: "SYNO.Core.AppPortal.ReverseProxy",
                            method: "update",
                            version: 1,
                            params: {
                                entry: e
                            }
                        });
                    case 3:
                        return t.abrupt("return", t.sent);
                    case 4:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }))).apply(this, arguments)
    }

    function L() {
        return j.apply(this, arguments)
    }

    function j() {
        return (j = _(regeneratorRuntime.mark(function t() {
            var e, n = arguments;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = n.length > 0 && void 0 !== n[0] ? n[0] : [], t.next = 3, synowebapi.promises.request({
                            api: "SYNO.Core.AppPortal.ReverseProxy",
                            method: "delete",
                            version: 1,
                            params: {
                                uuids: e
                            }
                        });
                    case 3:
                        return t.abrupt("return", t.sent);
                    case 4:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }))).apply(this, arguments)
    }

    function Y() {
        return H.apply(this, arguments)
    }

    function H() {
        return (H = _(regeneratorRuntime.mark(function t() {
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.next = 2, synowebapi.promises.request({
                            api: "SYNO.Core.AppPortal.AccessControl",
                            version: 1,
                            method: "list"
                        });
                    case 2:
                        return t.abrupt("return", t.sent);
                    case 3:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }))).apply(this, arguments)
    }

    function F() {
        return M.apply(this, arguments)
    }

    function M() {
        return (M = _(regeneratorRuntime.mark(function t() {
            var e, n = arguments;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = n.length > 0 && void 0 !== n[0] ? n[0] : {}, t.next = 3, synowebapi.promises.request({
                            api: "SYNO.Core.AppPortal.AccessControl",
                            method: "create",
                            version: 1,
                            params: e
                        });
                    case 3:
                        return t.abrupt("return", t.sent);
                    case 4:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }))).apply(this, arguments)
    }

    function V() {
        return U.apply(this, arguments)
    }

    function U() {
        return (U = _(regeneratorRuntime.mark(function t() {
            var e, n = arguments;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = n.length > 0 && void 0 !== n[0] ? n[0] : {}, t.next = 3, synowebapi.promises.request({
                            api: "SYNO.Core.AppPortal.AccessControl",
                            method: "update",
                            version: 1,
                            params: e
                        });
                    case 3:
                        return t.abrupt("return", t.sent);
                    case 4:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }))).apply(this, arguments)
    }

    function W() {
        return z.apply(this, arguments)
    }

    function z() {
        return (z = _(regeneratorRuntime.mark(function t() {
            var e, n = arguments;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = n.length > 0 && void 0 !== n[0] ? n[0] : [], t.next = 3, synowebapi.promises.request({
                            api: "SYNO.Core.AppPortal.AccessControl",
                            method: "delete",
                            version: 1,
                            params: {
                                uuids: e
                            }
                        });
                    case 3:
                        return t.abrupt("return", t.sent);
                    case 4:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }))).apply(this, arguments)
    }

    function Q() {
        return K.apply(this, arguments)
    }

    function K() {
        return (K = _(regeneratorRuntime.mark(function t() {
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.next = 2, synowebapi.promises.request({
                            api: "SYNO.Core.AppPortal.Config",
                            version: 1,
                            method: "get"
                        });
                    case 2:
                        return t.abrupt("return", t.sent);
                    case 3:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }))).apply(this, arguments)
    }

    function G() {
        return J.apply(this, arguments)
    }

    function J() {
        return (J = _(regeneratorRuntime.mark(function t() {
            var e, n = arguments;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e = n.length > 0 && void 0 !== n[0] ? n[0] : {}, t.next = 3, synowebapi.promises.request({
                            api: "SYNO.Core.AppPortal.Config",
                            version: 1,
                            method: "set",
                            params: e
                        });
                    case 3:
                        return t.abrupt("return", t.sent);
                    case 4:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }))).apply(this, arguments)
    }

    function X() {
        return Z.apply(this, arguments)
    }

    function Z() {
        return (Z = _(regeneratorRuntime.mark(function t() {
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        if (SYNO.API.GetKnownAPI("SYNO.WebStation.HTTP.VHost")) {
                            t.next = 2;
                            break
                        }
                        return t.abrupt("return", {});
                    case 2:
                        return t.next = 4, synowebapi.promises.request({
                            api: "SYNO.WebStation.HTTP.VHost",
                            method: "list",
                            version: 1
                        });
                    case 4:
                        return t.abrupt("return", t.sent);
                    case 5:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }))).apply(this, arguments)
    }
    var tt = {
            components: {
                BackgroundPreview: f
            },
            props: {
                applicationId: {
                    type: String,
                    required: !0
                },
                profile: {
                    type: Object,
                    required: !0
                }
            },
            computed: {
                isRetina: function() {
                    return SYNO.SDS.UIFeatures.IconSizeManager.isRetinaMode()
                },
                resolution: function() {
                    return this.isRetina ? "2x" : "1x"
                },
                appConf: function() {
                    var t = SYNO.SDS.Config.FnMap[this.applicationId];
                    return t && t.config || {}
                },
                maskPath: function() {
                    if ("dsm" === this.applicationId) return SYNO.SDS.UIFeatures.IconSizeManager.getIconPath("webman/modules/AdminCenter/images/{1}/login_portal/login_ui/img_loginui_dsm.png");
                    if (!(this.appConf && this.appConf.jsBaseURL && this.appConf.loginStyle && this.appConf.loginStyle.loginPreviewThumbnailMaskPath)) return null;
                    var t = this.appConf.loginStyle.loginPreviewThumbnailMaskPath.replace("{0}", this.resolution);
                    return "".concat(this.appConf.jsBaseURL, "/").concat(t)
                },
                iconPath: function() {
                    return "dsm" === this.applicationId ? SYNO.SDS.UIFeatures.IconSizeManager.getIconPath("webman/modules/AdminCenter/images/{1}/login_portal/pkg_icn/dsm.png") : this.appConf && this.appConf.jsBaseURL ? this.appConf.loginIcon ? SYNO.SDS.UIFeatures.IconSizeManager.getIconPath("".concat(this.appConf.jsBaseURL, "/").concat(this.appConf.loginIcon), "Header") : this.appConf.icon ? SYNO.SDS.UIFeatures.IconSizeManager.getIconPath("".concat(this.appConf.jsBaseURL, "/").concat(this.appConf.icon), "Header") : null : null
                }
            }
        },
        et = (n(24), d(tt, function() {
            var t = this.$createElement,
                e = this._self._c || t;
            return e("section", {
                staticClass: "login-style-preview"
            }, [e("background-preview", {
                staticClass: "login-style-preview__cover",
                attrs: {
                    "application-id": this.applicationId,
                    profile: this.profile
                }
            }), this._v(" "), e("img", {
                staticClass: "login-style-preview__cover",
                attrs: {
                    src: this.maskPath,
                    draggable: "false"
                }
            }), this._v(" "), e("img", {
                staticClass: "login-style-preview__icon",
                attrs: {
                    src: this.iconPath,
                    draggable: "false"
                }
            })], 1)
        }, [], !1, null, "31669801", null));

    function nt(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }
    var rt = d({
        components: {
            LoginStylePreview: et.exports
        },
        props: {
            applicationId: {
                type: String,
                required: !0
            }
        },
        mounted: function() {
            this.load()
        },
        data: function() {
            return {
                profile: {}
            }
        },
        methods: {
            load: function() {
                var t, e = (t = regeneratorRuntime.mark(function t() {
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.next = 2, b(this.applicationId);
                            case 2:
                                this.profile = t.sent;
                            case 3:
                            case "end":
                                return t.stop()
                        }
                    }, t, this)
                }), function() {
                    var e = this,
                        n = arguments;
                    return new Promise(function(r, o) {
                        var i = t.apply(e, n);

                        function a(t) {
                            nt(i, r, o, a, s, "next", t)
                        }

                        function s(t) {
                            nt(i, r, o, a, s, "throw", t)
                        }
                        a(void 0)
                    })
                });
                return function() {
                    return e.apply(this, arguments)
                }
            }()
        }
    }, function() {
        var t = this.$createElement;
        return (this._self._c || t)("login-style-preview", {
            attrs: {
                "application-id": this.applicationId,
                profile: this.profile
            }
        })
    }, [], !1, null, null, null).exports;

    function ot(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }
    var it = {
            computed: {
                Ext: function(t) {
                    function e() {
                        return t.apply(this, arguments)
                    }
                    return e.toString = function() {
                        return t.toString()
                    }, e
                }(function() {
                    return Ext
                })
            },
            mounted: function() {
                var t, e = (t = regeneratorRuntime.mark(function t() {
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                this.updateAppWindow();
                            case 1:
                            case "end":
                                return t.stop()
                        }
                    }, t, this)
                }), function() {
                    var e = this,
                        n = arguments;
                    return new Promise(function(r, o) {
                        var i = t.apply(e, n);

                        function a(t) {
                            ot(i, r, o, a, s, "next", t)
                        }

                        function s(t) {
                            ot(i, r, o, a, s, "throw", t)
                        }
                        a(void 0)
                    })
                });
                return function() {
                    return e.apply(this, arguments)
                }
            }(),
            methods: {
                updateAppWindow: function() {
                    this.$root._$extPanel && (this.$appWindow = this.$root._$extPanel.findAppWindow(), this.$window = this.$appWindow), this.$root.$children[0] && this.$root.$children[0].$children[0] && "ModalWindow" === this.$root.$children[0].$children[0].$options.name && (this.$window = this.$root.$children[0].$children[0], this.$appWindow = this.getAppWindow())
                },
                getAppWindow: function() {
                    return function t(e) {
                        return e ? e._isVue && "AppWindow" === e.$options.name ? e : e._isVue ? t(e._isVue ? e.$options.owner : e.owner) : e.findAppWindow() : null
                    }(this.$window)
                },
                close: function() {
                    this.$window.close()
                }
            }
        },
        at = (SYNO.SDS.UIFeatures.IconSizeManager.isRetinaMode(), {
            components: {
                ApplicationPreview: rt
            },
            mixins: [it],
            props: {
                applicationId: {
                    type: String,
                    required: !0
                },
                applicationDisplayName: {
                    type: String,
                    required: !0
                }
            },
            methods: {
                openEditLoginStyle: function() {
                    var t = this,
                        e = function() {
                            var e, n;
                            return t.$window._isVue ? (e = t.$window).openWindow.apply(e, arguments) : (n = t.$window).openVueWindow.apply(n, arguments)
                        }(SYNO.SDS.AdminCenter.LoginPortal.Dialogs.LoginStyleEditor_vue),
                        n = e.component,
                        r = e.window;
                    n.$children[0].$data.applicationId = this.applicationId, n.$children[0].$data.applicationDisplayName = this.applicationDisplayName, r.$on("close", function() {
                        t.$refs.preview.load()
                    })
                }
            }
        }),
        st = (n(25), d(at, function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-form-multiple-item", {
                attrs: {
                    "syno-id": "syno-lp-form-item-edit-style",
                    "hide-label": "",
                    prop: "p-lp-login-style"
                }
            }, [n("application-preview", {
                ref: "preview",
                attrs: {
                    "application-id": t.applicationId
                }
            }), t._v(" "), n("v-button", {
                staticClass: "ac-lp-edit-style-btn",
                attrs: {
                    "syno-id": "syno-lp-button-edit-style"
                },
                on: {
                    click: function() {
                        return t.openEditLoginStyle()
                    }
                }
            }, [t._v("\n    " + t._s(t.$i18n("controlpanel", "edit_login_style")) + "\n  ")])], 1)
        }, [], !1, null, null, null).exports),
        ct = {
            filters: {
                colon: function(t) {
                    return "".concat(t).concat(_T("common", "colon"))
                }
            }
        };

    function lt(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }

    function ut(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise(function(r, o) {
                var i = t.apply(e, n);

                function a(t) {
                    lt(i, r, o, a, s, "next", t)
                }

                function s(t) {
                    lt(i, r, o, a, s, "throw", t)
                }
                a(void 0)
            })
        }
    }
    var pt = {
        mixins: [it],
        data: function() {
            return {
                dataProperty: "data",
                spinner: {
                    isLoading: !1,
                    loadingType: null,
                    showStatusBar: !1,
                    statusBarState: null,
                    errorText: ""
                }
            }
        },
        methods: {
            onApply: function() {
                var t = ut(regeneratorRuntime.mark(function t() {
                    var e, n = this;
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.onLoading(), t.next = 3, this._validate();
                            case 3:
                                if (t.sent) {
                                    t.next = 6;
                                    break
                                }
                                return this.onDone(), t.abrupt("return", !1);
                            case 6:
                                return t.next = 8, new Promise(function(t) {
                                    var e = function() {
                                            var e = ut(regeneratorRuntime.mark(function e() {
                                                return regeneratorRuntime.wrap(function(e) {
                                                    for (;;) switch (e.prev = e.next) {
                                                        case 0:
                                                            n._commit(), n.onDone(), t(!0);
                                                        case 3:
                                                        case "end":
                                                            return e.stop()
                                                    }
                                                }, e, this)
                                            }));
                                            return function() {
                                                return e.apply(this, arguments)
                                            }
                                        }(),
                                        r = function() {
                                            var e = ut(regeneratorRuntime.mark(function e() {
                                                var r = arguments;
                                                return regeneratorRuntime.wrap(function(e) {
                                                    for (;;) switch (e.prev = e.next) {
                                                        case 0:
                                                            n.onError.apply(n, r), t(!1);
                                                        case 2:
                                                        case "end":
                                                            return e.stop()
                                                    }
                                                }, e, this)
                                            }));
                                            return function() {
                                                return e.apply(this, arguments)
                                            }
                                        }();
                                    n.$emit("apply", n[n.dataProperty], e, r)
                                });
                            case 8:
                                return e = t.sent, t.abrupt("return", e);
                            case 10:
                            case "end":
                                return t.stop()
                        }
                    }, t, this)
                }));
                return function() {
                    return t.apply(this, arguments)
                }
            }(),
            onCancel: function() {
                var t = ut(regeneratorRuntime.mark(function t() {
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                this.$emit("cancel");
                            case 1:
                            case "end":
                                return t.stop()
                        }
                    }, t, this)
                }));
                return function() {
                    return t.apply(this, arguments)
                }
            }(),
            beforeClose: function() {
                var t = ut(regeneratorRuntime.mark(function t() {
                    var e;
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (this._isDirty()) {
                                    t.next = 2;
                                    break
                                }
                                return t.abrupt("return", !0);
                            case 2:
                                return t.next = 4, this.openConfirmer();
                            case 4:
                                if ("save" !== (e = t.sent)) {
                                    t.next = 9;
                                    break
                                }
                                return t.next = 8, this.onApply();
                            case 8:
                                return t.abrupt("return", t.sent);
                            case 9:
                                if ("dont_save" !== e) {
                                    t.next = 11;
                                    break
                                }
                                return t.abrupt("return", !0);
                            case 11:
                                return t.abrupt("return", !1);
                            case 12:
                            case "end":
                                return t.stop()
                        }
                    }, t, this)
                }));
                return function() {
                    return t.apply(this, arguments)
                }
            }(),
            openConfirmer: function() {
                var t = ut(regeneratorRuntime.mark(function t() {
                    var e, n = this;
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.updateAppWindow(), e = Promise.resolve(), e = this.$window._isVue ? this.$window.getMsgBox().confirmLostChange() : new Promise(function(t) {
                                    n.$window.getMsgBox().confirm("", n.$i18n("common", "confirm_lostchange"), function(e) {
                                        switch (e) {
                                            case "yes":
                                                t("save");
                                                break;
                                            case "no":
                                                t("cancel");
                                                break;
                                            default:
                                                t("dont_save")
                                        }
                                    }, n.$window, {
                                        yes: n.$i18n("common", "save"),
                                        no: n.$i18n("common", "cancel"),
                                        leftCustom: n.$i18n("common", "dont_save")
                                    })
                                }), t.next = 5, e;
                            case 5:
                                return t.abrupt("return", t.sent);
                            case 6:
                            case "end":
                                return t.stop()
                        }
                    }, t, this)
                }));
                return function() {
                    return t.apply(this, arguments)
                }
            }(),
            _commit: function() {
                return (this.commit || this.$refs.form && this.$refs.form.commit || function() {})()
            },
            _validate: function() {
                var t = ut(regeneratorRuntime.mark(function t() {
                    var e;
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return e = this.validate || this.$refs.form && this.$refs.form.validate || function() {
                                    return !0
                                }, t.next = 3, e();
                            case 3:
                                return t.abrupt("return", t.sent);
                            case 4:
                            case "end":
                                return t.stop()
                        }
                    }, t, this)
                }));
                return function() {
                    return t.apply(this, arguments)
                }
            }(),
            _isDirty: function() {
                return (this.isDirty || this.$refs.form && this.$refs.form.isDirty || function() {
                    return !1
                })()
            },
            onReset: function() {
                this.$refs.form.resetFields()
            },
            onLoading: function() {
                this.spinner.isLoading = !0, this.spinner.loadingType = "statusbar", this.spinner.showStatusBar = !0, this.spinner.statusBarState = "loading", this._onLoading && this._onLoading()
            },
            onDone: function() {
                this.spinner.isLoading = !1, this.spinner.loadingType = null, this.spinner.statusBarState = null
            },
            onError: function(t) {
                this.spinner.errorText = "string" == typeof t ? t : SYNO.API.getErrorString(t), this.spinner.isLoading = !1, this.spinner.loadingType = "statusbar", this.spinner.showStatusBar = !0, this.spinner.statusBarState = "error", this._onError && this._onError(t)
            }
        }
    };

    function dt(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }

    function ft(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise(function(r, o) {
                var i = t.apply(e, n);

                function a(t) {
                    dt(i, r, o, a, s, "next", t)
                }

                function s(t) {
                    dt(i, r, o, a, s, "throw", t)
                }
                a(void 0)
            })
        }
    }
    var mt = function(t) {
            return [{
                type: "string",
                required: !0,
                asyncValidator: function() {
                    var e = ft(regeneratorRuntime.mark(function e(n, r) {
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, t.validateDsm(r, 80);
                                case 2:
                                    if (e.sent) {
                                        e.next = 4;
                                        break
                                    }
                                    throw _T("app_port_alias", "err_fqdn_duplicated");
                                case 4:
                                    return e.next = 6, t.validateDsm(r, 443);
                                case 6:
                                    if (e.sent) {
                                        e.next = 8;
                                        break
                                    }
                                    throw _T("app_port_alias", "err_fqdn_duplicated");
                                case 8:
                                    return e.abrupt("return");
                                case 9:
                                case "end":
                                    return e.stop()
                            }
                        }, e, this)
                    }));
                    return function(t, n) {
                        return e.apply(this, arguments)
                    }
                }()
            }]
        },
        ht = function(t) {
            return [{
                type: "string",
                required: !0,
                asyncValidator: function() {
                    var e = ft(regeneratorRuntime.mark(function e(n, r) {
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, t.validateAppPortal(r, 80);
                                case 2:
                                    if (e.sent) {
                                        e.next = 4;
                                        break
                                    }
                                    throw _T("app_port_alias", "err_fqdn_duplicated");
                                case 4:
                                    return e.next = 6, t.validateAppPortal(r, 443);
                                case 6:
                                    if (e.sent) {
                                        e.next = 8;
                                        break
                                    }
                                    throw _T("app_port_alias", "err_fqdn_duplicated");
                                case 8:
                                    return e.abrupt("return");
                                case 9:
                                case "end":
                                    return e.stop()
                            }
                        }, e, this)
                    }));
                    return function(t, n) {
                        return e.apply(this, arguments)
                    }
                }()
            }]
        },
        vt = function(t) {
            return function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                return [{
                    type: "string",
                    required: !0,
                    asyncValidator: function() {
                        var t = ft(regeneratorRuntime.mark(function t(n, r) {
                            return regeneratorRuntime.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        if (Ext.form.VTypes.port(r)) {
                                            t.next = 2;
                                            break
                                        }
                                        throw Ext.form.VTypes.portText;
                                    case 2:
                                        if (r !== e) {
                                            t.next = 4;
                                            break
                                        }
                                        throw _T("error", "error_port_conflict");
                                    case 4:
                                        return t.abrupt("return");
                                    case 5:
                                    case "end":
                                        return t.stop()
                                }
                            }, t, this)
                        }));
                        return function(e, n) {
                            return t.apply(this, arguments)
                        }
                    }()
                }, {
                    asyncValidator: function() {
                        var e = ft(regeneratorRuntime.mark(function e(n, r) {
                            return regeneratorRuntime.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, t.validate(r);
                                    case 2:
                                    case "end":
                                        return e.stop()
                                }
                            }, e, this)
                        }));
                        return function(t, n) {
                            return e.apply(this, arguments)
                        }
                    }()
                }]
            }
        },
        _t = function(t) {
            return function() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                return [{
                    type: "string",
                    asyncValidator: function() {
                        var t = ft(regeneratorRuntime.mark(function t(n, r) {
                            return regeneratorRuntime.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        if (r) {
                                            t.next = 2;
                                            break
                                        }
                                        return t.abrupt("return");
                                    case 2:
                                        if (Ext.form.VTypes.port(r)) {
                                            t.next = 4;
                                            break
                                        }
                                        throw Ext.form.VTypes.portText;
                                    case 4:
                                        if (+r != +e) {
                                            t.next = 6;
                                            break
                                        }
                                        throw _T("app_port_alias", "err_port_dup");
                                    case 6:
                                        return t.abrupt("return");
                                    case 7:
                                    case "end":
                                        return t.stop()
                                }
                            }, t, this)
                        }));
                        return function(e, n) {
                            return t.apply(this, arguments)
                        }
                    }()
                }, {
                    asyncValidator: function() {
                        var e = ft(regeneratorRuntime.mark(function e(n, r) {
                            return regeneratorRuntime.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, t.validate(r);
                                    case 2:
                                    case "end":
                                        return e.stop()
                                }
                            }, e, this)
                        }));
                        return function(t, n) {
                            return e.apply(this, arguments)
                        }
                    }()
                }]
            }
        },
        gt = function(t) {
            return [{
                type: "string",
                asyncValidator: function() {
                    var e = ft(regeneratorRuntime.mark(function e(n, r) {
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (r) {
                                        e.next = 2;
                                        break
                                    }
                                    return e.abrupt("return");
                                case 2:
                                    return e.next = 4, t.validate(r);
                                case 4:
                                case "end":
                                    return e.stop()
                            }
                        }, e, this)
                    }));
                    return function(t, n) {
                        return e.apply(this, arguments)
                    }
                }()
            }]
        },
        yt = function() {
            var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : [];
            return [{
                type: "string",
                required: !0,
                asyncValidator: function() {
                    var e = ft(regeneratorRuntime.mark(function e(n, r) {
                        return regeneratorRuntime.wrap(function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if ("" !== r) {
                                        e.next = 2;
                                        break
                                    }
                                    throw " ";
                                case 2:
                                    if (!t.some(function(t) {
                                            return t === r
                                        })) {
                                        e.next = 4;
                                        break
                                    }
                                    throw _T("app_port_alias", "err_profile_dup");
                                case 4:
                                    return e.abrupt("return");
                                case 5:
                                case "end":
                                    return e.stop()
                            }
                        }, e, this)
                    }));
                    return function(t, n) {
                        return e.apply(this, arguments)
                    }
                }()
            }]
        },
        bt = [{
            type: "string",
            asyncValidator: function() {
                var t = ft(regeneratorRuntime.mark(function t(e, n) {
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (n) {
                                    t.next = 2;
                                    break
                                }
                                return t.abrupt("return");
                            case 2:
                                if (Ext.form.VTypes.cidr(n)) {
                                    t.next = 4;
                                    break
                                }
                                throw _T("app_port_alias", "err_bad_source_ip_or_cidr");
                            case 4:
                                return t.abrupt("return");
                            case 5:
                            case "end":
                                return t.stop()
                        }
                    }, t, this)
                }));
                return function(e, n) {
                    return t.apply(this, arguments)
                }
            }()
        }];

    function wt(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter(function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            }))), r.forEach(function(e) {
                xt(t, e, n[e])
            })
        }
        return t
    }

    function xt(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }

    function kt(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }

    function St(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise(function(r, o) {
                var i = t.apply(e, n);

                function a(t) {
                    kt(i, r, o, a, s, "next", t)
                }

                function s(t) {
                    kt(i, r, o, a, s, "throw", t)
                }
                a(void 0)
            })
        }
    }

    function $t(t, e) {
        if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
    }

    function Ct(t, e) {
        for (var n = 0; n < e.length; n++) {
            var r = e[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
        }
    }

    function Pt(t, e, n) {
        return e && Ct(t.prototype, e), n && Ct(t, n), t
    }
    var Rt = function() {
            function t() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "dsm";
                $t(this, t), this.applicationId = e, this.portals = [], this.preserves = [], this.promise = Promise.resolve(), this.fetchApplications()
            }
            return Pt(t, [{
                key: "validate",
                value: function() {
                    var t = St(regeneratorRuntime.mark(function t() {
                        var e, n, r = arguments;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return e = r.length > 0 && void 0 !== r[0] ? r[0] : "", t.next = 3, this.promise;
                                case 3:
                                    if (n = parseInt(e, 10), "dsm" !== this.applicationId) {
                                        t.next = 8;
                                        break
                                    }
                                    return t.abrupt("return", this.validateDsm(n));
                                case 8:
                                    return t.abrupt("return", this.validateApplication(n));
                                case 9:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }, {
                key: "validateDsm",
                value: function() {
                    var t = St(regeneratorRuntime.mark(function t() {
                        var e, n = arguments;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    if (e = n.length > 0 && void 0 !== n[0] ? n[0] : 0, !SYNO.SDS.Utils.isReservedPort(this.applicationId, e, e)) {
                                        t.next = 3;
                                        break
                                    }
                                    throw _T("ftp", "ftp_port_in_used");
                                case 3:
                                    if (!SYNO.SDS.Utils.isBrowserReservedPort(e, e)) {
                                        t.next = 5;
                                        break
                                    }
                                    throw _T("common", "err_browser_reserved_ports");
                                case 5:
                                    return t.abrupt("return", !0);
                                case 6:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }, {
                key: "validateApplication",
                value: function() {
                    var t = St(regeneratorRuntime.mark(function t() {
                        var e, n, r = this,
                            o = arguments;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return e = o.length > 0 && void 0 !== o[0] ? o[0] : 0, t.next = 3, this.promise;
                                case 3:
                                    if (n = SYNO.SDS.AdminCenter.LoginPortal.Utils.getPortNameByServiceName(this.applicationId), !SYNO.SDS.Utils.isReservedPort(n, e, e)) {
                                        t.next = 6;
                                        break
                                    }
                                    throw _T("app_port_alias", "err_port_reserved");
                                case 6:
                                    if (!SYNO.SDS.Utils.isBrowserReservedPort(e, e)) {
                                        t.next = 8;
                                        break
                                    }
                                    throw _T("common", "err_browser_reserved_ports");
                                case 8:
                                    if (!this.preserves.filter(function(t) {
                                            return t.id !== r.applicationId
                                        }).some(function(t) {
                                            return t.http_port === e || t.https_port === e
                                        })) {
                                        t.next = 11;
                                        break
                                    }
                                    throw _T("app_port_alias", "err_port_reserved");
                                case 11:
                                    if (!this.portals.filter(function(t) {
                                            return t.id !== r.applicationId
                                        }).some(function(t) {
                                            return t.http_port === e || t.https_port === e
                                        })) {
                                        t.next = 14;
                                        break
                                    }
                                    throw _T("app_port_alias", "err_port_used");
                                case 14:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }, {
                key: "fetchApplications",
                value: function() {
                    var t = St(regeneratorRuntime.mark(function t() {
                        var e, n, r;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return this.promise = g({
                                        additional: ["default_setting"]
                                    }), t.next = 3, this.promise;
                                case 3:
                                    e = t.sent, n = e.portal, r = void 0 === n ? [] : n, this.portals = r, this.preserves = this.portals.map(function(t) {
                                        var e = t && t.additional && t.additional.default_setting;
                                        return wt({
                                            id: t.id
                                        }, e)
                                    }).filter(function(t) {
                                        return t.http_port || t.https_port
                                    });
                                case 8:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }]), t
        }(),
        At = function() {
            function t() {
                $t(this, t), this.entries = [], this.promise = Promise.resolve(), this.load()
            }
            return Pt(t, [{
                key: "validateFrontendPort",
                value: function() {
                    var t = St(regeneratorRuntime.mark(function t() {
                        var e, n, r = arguments;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return e = r.length > 0 && void 0 !== r[0] ? r[0] : {}, t.next = 3, this.promise;
                                case 3:
                                    if (n = /^(localhost|127\.0\.0\.1|0\.0\.0\.0|::1|0:0:0:0:0:0:0:1)$/i, e.frontend.fqdn && "*" !== e.frontend.fqdn && !n.exec(e.frontend.fqdn)) {
                                        t.next = 14;
                                        break
                                    }
                                    if (80 != +e.frontend.port && 443 != +e.frontend.port) {
                                        t.next = 7;
                                        break
                                    }
                                    throw _T("app_port_alias", "err_port_reserved");
                                case 7:
                                    if (!this.entries.filter(function(t) {
                                            return t.UUID !== e.UUID
                                        }).some(function(t) {
                                            return +t.frontend.port == +e.frontend.port
                                        })) {
                                        t.next = 10;
                                        break
                                    }
                                    throw _T("app_port_alias", "err_port_used");
                                case 10:
                                    if (!SYNO.SDS.Utils.isReservedPort("www", +e.frontend.port, +e.frontend.port)) {
                                        t.next = 12;
                                        break
                                    }
                                    throw _T("app_port_alias", "err_port_reserved");
                                case 12:
                                    if (!n.exec(e.backend.fqdn) || +e.frontend.port != +e.backend.port) {
                                        t.next = 14;
                                        break
                                    }
                                    throw _T("app_port_alias", "err_port_used");
                                case 14:
                                    if (!SYNO.SDS.Utils.isBrowserReservedPort(+e.frontend.port, +e.frontend.port)) {
                                        t.next = 16;
                                        break
                                    }
                                    throw _T("common", "err_browser_reserved_ports");
                                case 16:
                                    if (!this.entries.filter(function(t) {
                                            return t.UUID !== e.UUID
                                        }).filter(function(t) {
                                            return t.frontend.fqdn
                                        }).some(function(t) {
                                            return t.frontend.fqdn && e.frontend.fqdn && t.frontend.fqdn.toLowerCase() === e.frontend.fqdn.toLowerCase() && +t.frontend.port == +e.frontend.port
                                        })) {
                                        t.next = 19;
                                        break
                                    }
                                    throw _T("app_port_alias", "err_frontend_duplicated");
                                case 19:
                                    return t.abrupt("return", !0);
                                case 20:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }, {
                key: "validateBackendPort",
                value: function() {
                    var t = St(regeneratorRuntime.mark(function t() {
                        var e, n = arguments;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    if ((e = n.length > 0 && void 0 !== n[0] ? n[0] : {}).backend.port) {
                                        t.next = 3;
                                        break
                                    }
                                    return t.abrupt("return", _JSLIBSTR("extlang", "fieldblank"));
                                case 3:
                                    if (!e.frontend.fqdn || !e.backend.fqdn || e.frontend.fqdn.toLowerCase() !== e.backend.fqdn.toLowerCase() || +e.frontend.port != +e.backend.port) {
                                        t.next = 5;
                                        break
                                    }
                                    throw _T("app_port_alias", "err_backend_duplicated");
                                case 5:
                                    return t.abrupt("return", !0);
                                case 6:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }, {
                key: "load",
                value: function() {
                    var t = St(regeneratorRuntime.mark(function t() {
                        var e, n, r;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return this.promise = D(), t.next = 3, this.promise;
                                case 3:
                                    e = t.sent, n = e.entries, r = void 0 === n ? [] : n, this.entries = r;
                                case 7:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }]), t
        }();

    function Ot(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter(function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            }))), r.forEach(function(e) {
                It(t, e, n[e])
            })
        }
        return t
    }

    function It(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }

    function Dt(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }

    function qt(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise(function(r, o) {
                var i = t.apply(e, n);

                function a(t) {
                    Dt(i, r, o, a, s, "next", t)
                }

                function s(t) {
                    Dt(i, r, o, a, s, "throw", t)
                }
                a(void 0)
            })
        }
    }

    function Et(t, e) {
        for (var n = 0; n < e.length; n++) {
            var r = e[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
        }
    }
    var Tt = function() {
        function t() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
            ! function(t, e) {
                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
            }(this, t), this.applicationId = e, this.preserves = [], this.portals = [], this.promise = Promise.resolve(), this.fetchApplications()
        }
        var e, n, r;
        return e = t, (n = [{
            key: "fetchApplications",
            value: function() {
                var t = qt(regeneratorRuntime.mark(function t() {
                    var e, n, r;
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.promise = g({
                                    additional: ["default_setting"]
                                }), t.next = 3, this.promise;
                            case 3:
                                e = t.sent, n = e.portal, r = void 0 === n ? [] : n, this.portals = r, this.preserves = this.portals.map(function(t) {
                                    var e = t && t.additional && t.additional.default_setting;
                                    return Ot({
                                        id: t.id
                                    }, e)
                                }).filter(function(t) {
                                    return t.alias
                                });
                            case 8:
                            case "end":
                                return t.stop()
                        }
                    }, t, this)
                }));
                return function() {
                    return t.apply(this, arguments)
                }
            }()
        }, {
            key: "validate",
            value: function() {
                var t = qt(regeneratorRuntime.mark(function t() {
                    var e, n = this,
                        r = arguments;
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (e = r.length > 0 && void 0 !== r[0] ? r[0] : "", Ext.form.VTypes.aliasname(e)) {
                                    t.next = 3;
                                    break
                                }
                                throw _T("controlpanel", "bad_alias_detail");
                            case 3:
                                return t.next = 5, this.promise;
                            case 5:
                                if (!this.preserves.filter(function(t) {
                                        return t.id !== n.applicationId
                                    }).some(function(t) {
                                        return t.alias === e
                                    })) {
                                    t.next = 8;
                                    break
                                }
                                throw _T("app_port_alias", "err_alias_refused");
                            case 8:
                                if (!this.portals.filter(function(t) {
                                        return t.id !== n.applicationId
                                    }).some(function(t) {
                                        return t.alias === e
                                    })) {
                                    t.next = 11;
                                    break
                                }
                                throw _T("app_port_alias", "err_alias_used");
                            case 11:
                            case "end":
                                return t.stop()
                        }
                    }, t, this)
                }));
                return function() {
                    return t.apply(this, arguments)
                }
            }()
        }]) && Et(e.prototype, n), r && Et(e, r), t
    }();

    function Nt(t) {
        return function(t) {
            if (Array.isArray(t)) return Bt(t)
        }(t) || function(t) {
            if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) return Array.from(t)
        }(t) || function(t, e) {
            if (!t) return;
            if ("string" == typeof t) return Bt(t, e);
            var n = Object.prototype.toString.call(t).slice(8, -1);
            "Object" === n && t.constructor && (n = t.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(n);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Bt(t, e)
        }(t) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function Bt(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
        return r
    }

    function Lt(t, e) {
        for (var n = 0; n < e.length; n++) {
            var r = e[n];
            r.enumerable = r.enumerable || !1, r.configurable = !0, "value" in r && (r.writable = !0), Object.defineProperty(t, r.key, r)
        }
    }

    function jt(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }

    function Yt(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise(function(r, o) {
                var i = t.apply(e, n);

                function a(t) {
                    jt(i, r, o, a, s, "next", t)
                }

                function s(t) {
                    jt(i, r, o, a, s, "throw", t)
                }
                a(void 0)
            })
        }
    }

    function Ht(t) {
        return {
            asyncValidator: function() {
                var e = Yt(regeneratorRuntime.mark(function e() {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (!t) {
                                    e.next = 2;
                                    break
                                }
                                throw t;
                            case 2:
                            case "end":
                                return e.stop()
                        }
                    }, e, this)
                }));
                return function() {
                    return e.apply(this, arguments)
                }
            }()
        }
    }

    function Ft(t) {
        return {
            asyncValidator: function() {
                var e = Yt(regeneratorRuntime.mark(function e(n, r) {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (Ext.form.VTypes[t](r)) {
                                    e.next = 2;
                                    break
                                }
                                throw Ext.form.VTypes["".concat(t, "Text")];
                            case 2:
                            case "end":
                                return e.stop()
                        }
                    }, e, this)
                }));
                return function(t, n) {
                    return e.apply(this, arguments)
                }
            }()
        }
    }
    var Mt = function() {
            function t() {
                var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "dsm";
                ! function(t, e) {
                    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                }(this, t), this.fqdnPairs = [], this.applicationId = e, this.promise = Promise.resolve(), this.load()
            }
            var e, n, r;
            return e = t, (n = [{
                key: "validate",
                value: function() {
                    var t = Yt(regeneratorRuntime.mark(function t() {
                        var e, n, r, o, i, a = arguments;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return e = a.length > 0 && void 0 !== a[0] ? a[0] : "", n = a.length > 1 && void 0 !== a[1] ? a[1] : 0, r = a.length > 2 && void 0 !== a[2] ? a[2] : {}, t.next = 5, this.promise;
                                case 5:
                                    return o = r.skips, i = void 0 === o ? [] : o, t.abrupt("return", this.fqdnPairs.filter(function(t) {
                                        return !i.includes(t.type)
                                    }).every(function(t) {
                                        return t.fqdn !== e || t.port !== n
                                    }));
                                case 7:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }, {
                key: "validateDsm",
                value: function() {
                    var t = Yt(regeneratorRuntime.mark(function t() {
                        var e, n, r = arguments;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return e = r.length > 0 && void 0 !== r[0] ? r[0] : "", n = r.length > 1 && void 0 !== r[1] ? r[1] : 0, t.next = 4, this.validate(e, n, {
                                        skips: ["dsm"]
                                    });
                                case 4:
                                    return t.abrupt("return", t.sent);
                                case 5:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }, {
                key: "validateAppPortal",
                value: function() {
                    var t = Yt(regeneratorRuntime.mark(function t() {
                        var e, n, r, o = this,
                            i = arguments;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return e = i.length > 0 && void 0 !== i[0] ? i[0] : "", n = i.length > 1 && void 0 !== i[1] ? i[1] : 0, t.next = 4, this.validate(e, n, {
                                        skips: ["app-portal"]
                                    });
                                case 4:
                                    return r = t.sent, t.abrupt("return", r && this.fqdnPairs.filter(function(t) {
                                        return "app-portal" === t.type
                                    }).filter(function(t) {
                                        return t.id !== o.applicationId
                                    }).every(function(t) {
                                        return t.fqdn !== e || t.port !== n
                                    }));
                                case 6:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }, {
                key: "validateFrontendReverseProxy",
                value: function() {
                    var t = Yt(regeneratorRuntime.mark(function t() {
                        var e, n = arguments;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return e = n.length > 0 && void 0 !== n[0] ? n[0] : {}, t.next = 3, this.validate(e.frontend.fqdn, +e.frontend.port, {
                                        skips: ["reverse-proxy"]
                                    });
                                case 3:
                                    if (t.sent) {
                                        t.next = 6;
                                        break
                                    }
                                    throw _T("app_port_alias", "err_fqdn_duplicated");
                                case 6:
                                    return t.abrupt("return");
                                case 7:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }, {
                key: "load",
                value: function() {
                    var t = Yt(regeneratorRuntime.mark(function t() {
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return this.promise = Promise.all([this.loadFqdnPairsByDSM(), this.loadFqdnPairsByAppPortals(), this.loadFqdnPairsByReverseProxy(), this.loadFqdnPairsByVHost()]), t.next = 3, this.promise;
                                case 3:
                                    return t.abrupt("return", t.sent);
                                case 4:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }, {
                key: "loadFqdnPairsByDSM",
                value: function() {
                    var t = Yt(regeneratorRuntime.mark(function t() {
                        var e, n;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.next = 2, S();
                                case 2:
                                    if (e = t.sent, n = e.fqdn) {
                                        t.next = 6;
                                        break
                                    }
                                    return t.abrupt("return");
                                case 6:
                                    this.fqdnPairs.push({
                                        type: "dsm",
                                        fqdn: n,
                                        port: 80
                                    }), this.fqdnPairs.push({
                                        type: "dsm",
                                        fqdn: n,
                                        port: 443
                                    });
                                case 8:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }, {
                key: "loadFqdnPairsByAppPortals",
                value: function() {
                    var t = Yt(regeneratorRuntime.mark(function t() {
                        var e, n, r;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.next = 2, g();
                                case 2:
                                    e = t.sent, n = e.portal, r = (void 0 === n ? [] : n).reduce(function(t, e) {
                                        return e.fqdn ? Nt(t).concat([{
                                            type: "app-portal",
                                            id: e.id,
                                            fqdn: e.fqdn.toLowerCase(),
                                            port: 80
                                        }, {
                                            type: "app-portal",
                                            id: e.id,
                                            fqdn: e.fqdn.toLowerCase(),
                                            port: 443
                                        }]) : t
                                    }, []), this.fqdnPairs = this.fqdnPairs.concat(r);
                                case 7:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }, {
                key: "loadFqdnPairsByReverseProxy",
                value: function() {
                    var t = Yt(regeneratorRuntime.mark(function t() {
                        var e, n, r;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.next = 2, D();
                                case 2:
                                    e = t.sent, n = e.entries, r = (void 0 === n ? [] : n).reduce(function(t, e) {
                                        if (!(e.frontend && e.frontend.fqdn && e.frontend.port)) return t;
                                        var n = e.frontend,
                                            r = n.fqdn,
                                            o = n.port;
                                        return Nt(t).concat([{
                                            type: "reverse-proxy",
                                            fqdn: r.toLowerCase(),
                                            port: o
                                        }])
                                    }, []), this.fqdnPairs = this.fqdnPairs.concat(r);
                                case 7:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }, {
                key: "loadFqdnPairsByVHost",
                value: function() {
                    var t = Yt(regeneratorRuntime.mark(function t() {
                        var e, n, r;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.next = 2, X();
                                case 2:
                                    e = t.sent, n = e.hosts, r = (void 0 === n ? [] : n).flatMap(function(t) {
                                        if (!t.fqdn) return [];
                                        var e = t.fqdn.toLowerCase(),
                                            n = t.port,
                                            r = n.http,
                                            o = void 0 === r ? [] : r,
                                            i = n.https,
                                            a = void 0 === i ? [] : i;
                                        return Nt(o).concat(Nt(a)).map(function(t) {
                                            return {
                                                type: "vhost",
                                                fqdn: e,
                                                port: t
                                            }
                                        })
                                    }), this.fqdnPairs = this.fqdnPairs.concat(r);
                                case 7:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }]) && Lt(e.prototype, n), r && Lt(e, r), t
        }(),
        Vt = {
            components: {
                vFormItemLoginStyle: st
            },
            mixins: [it, ct, pt, a],
            props: {
                inModal: {
                    type: Boolean,
                    default: !1
                },
                applicationId: {
                    type: String,
                    required: !0
                },
                settings: {
                    type: Object,
                    required: !0
                }
            },
            mounted: function() {
                var t = this;
                this.onLoading(), this.$watch("settings", function() {
                    for (var e in t.settings) t.$set(t.currentSettings, e, t.settings[e]);
                    t.form.enable_hsts = t.currentSettings.enable_hsts || t.currentSettings.hsts, t.onDone()
                }, {
                    deep: !0
                }), this.$watch("currentSettings.fqdn", function() {
                    t.currentSettings.enable_custom_domain = !!t.currentSettings.fqdn, t.$forceUpdate()
                }), this.$watch("currentSettings.fqdn", function() {
                    "" === t.currentSettings.fqdn && (t.currentSettings.fqdn = null)
                }), this.$watch("currentSettings.alias", function() {
                    "" === t.currentSettings.alias && (t.currentSettings.alias = null)
                }), this.$watch("currentSettings.http_port", function() {
                    t.currentSettings.http_port = t.currentSettings.http_port ? parseInt(t.currentSettings.http_port, 10) : null
                }), this.$watch("currentSettings.https_port", function() {
                    t.currentSettings.https_port = t.currentSettings.https_port ? parseInt(t.currentSettings.https_port, 10) : null
                }), this.$watch("currentSettings.enable_custom_domain", function() {
                    t.currentSettings.enable_custom_domain ? ("hsts" in t.currentSettings && (t.currentSettings.hsts = t.form.enable_hsts), "enable_hsts" in t.currentSettings && (t.currentSettings.enable_hsts = t.form.enable_hsts)) : ("hsts" in t.currentSettings && (t.currentSettings.hsts = !1), "enable_hsts" in t.currentSettings && (t.currentSettings.enable_hsts = !1))
                }), this.$watch("form.enable_hsts", function() {
                    "hsts" in t.currentSettings && (t.currentSettings.hsts = t.form.enable_hsts), "enable_hsts" in t.currentSettings && (t.currentSettings.enable_hsts = t.form.enable_hsts)
                })
            },
            computed: {
                defaultSettings: function() {
                    return this.currentSettings.additional && this.currentSettings.additional.default_setting || {}
                },
                dsmFqdnRules: function() {
                    return mt(this.fqdnValidator)
                },
                httpPortRules: function() {
                    return vt(this.portValidator)(this.currentSettings.https_port)
                },
                httpsPortRules: function() {
                    return vt(this.portValidator)(this.currentSettings.http_port)
                }
            },
            data: function() {
                return {
                    dataProperty: "currentSettings",
                    currentSettings: {
                        additional: {
                            default_setting: {}
                        },
                        enable_custom_domain: !1
                    },
                    form: {
                        enable_hsts: !1
                    },
                    fqdnValidator: new Mt("dsm"),
                    portValidator: new Rt("dsm")
                }
            },
            methods: {
                _onLoading: function() {
                    this.$emit("loading")
                },
                _onError: function(t) {
                    this.$emit("error", t)
                }
            }
        },
        Ut = (n(26), d(Vt, function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-panel", {
                class: {
                    "ac-lp-login-editor__panel": !0, "ac-lp-login-editor__panel--modal": t.inModal
                },
                attrs: {
                    "fluid-footer": "",
                    "syno-id": "syno-lp-panel-application-editor",
                    loading: t.spinner.isLoading,
                    "loading-type": t.spinner.loadingType,
                    "show-status-bar": t.spinner.showStatusBar,
                    "status-bar-state": t.spinner.statusBarState,
                    "error-text": t.spinner.errorText,
                    "confirm-text": t.$i18n("common", "save"),
                    "cancel-text": t.inModal ? void 0 : t.$i18n("common", "reset"),
                    confirm: function() {
                        return t.onApply()
                    },
                    cancel: function() {
                        return t.onCancel()
                    }
                },
                on: {
                    "update:showStatusBar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    },
                    "update:show-status-bar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    }
                },
                scopedSlots: t._u([{
                    key: "body",
                    fn: function() {
                        return [n("v-perfect-scrollbar", [n("div", {
                            class: {
                                "lp-modal-content": t.inModal
                            }
                        }, [n("v-form", {
                            ref: "form",
                            staticClass: "lp-modal-content--bottom-padding",
                            attrs: {
                                "syno-id": "syno-lp-le-form",
                                model: t.currentSettings
                            }
                        }, [n("v-fieldset", {
                            staticClass: "ac-lp-login-editor__login-style-fieldset",
                            attrs: {
                                "syno-id": "syno-lp-le-fieldset-style",
                                title: t.$i18n("controlpanel", "login_style_label")
                            }
                        }, [n("v-form-item-login-style", {
                            attrs: {
                                "application-id": t.applicationId,
                                "application-display-name": t.currentSettings.display_name || ""
                            }
                        })], 1), t._v(" "), n("v-fieldset", {
                            attrs: {
                                "syno-id": "syno-lp-le-fieldset-web-service",
                                title: t.$i18n("controlpanel", "web_service")
                            }
                        }, [t._t("web-service", [n("v-form-item", {
                            staticClass: "ac-lp-login-editor__form-item",
                            attrs: {
                                "syno-id": "syno-lp-le-form-item-http",
                                label: t._f("colon")(t.$i18n("controlpanel", "dsm_port_http")),
                                prop: "p-lp-le-http",
                                rules: t.httpPortRules
                            }
                        }, [n("v-input", {
                            staticClass: "ac-lp-login-editor__input",
                            attrs: {
                                "number-only": "",
                                name: "p-lp-le-http",
                                "syno-id": "syno-lp-le-input-http",
                                mask: function(t) {
                                    return t.substr(0, 5)
                                }
                            },
                            model: {
                                value: t.currentSettings.http_port,
                                callback: function(e) {
                                    t.$set(t.currentSettings, "http_port", e)
                                },
                                expression: "currentSettings.http_port"
                            }
                        })], 1), t._v(" "), n("v-form-item", {
                            staticClass: "ac-lp-login-editor__form-item",
                            attrs: {
                                "syno-id": "syno-lp-le-form-item-https",
                                label: t._f("colon")(t.$i18n("controlpanel", "dsm_port_https")),
                                prop: "p-lp-le-https",
                                rules: t.httpsPortRules
                            }
                        }, [n("v-input", {
                            staticClass: "ac-lp-login-editor__input",
                            attrs: {
                                "number-only": "",
                                name: "p-lp-le-https",
                                "syno-id": "syno-lp-le-input-https",
                                mask: function(t) {
                                    return t.substr(0, 5)
                                }
                            },
                            model: {
                                value: t.currentSettings.https_port,
                                callback: function(e) {
                                    t.$set(t.currentSettings, "https_port", e)
                                },
                                expression: "currentSettings.https_port"
                            }
                        })], 1)], {
                            settings: t.currentSettings,
                            defaultSettings: t.defaultSettings
                        }), t._v(" "), t._t("post-web-service", null, {
                            settings: t.currentSettings,
                            defaultSettings: t.defaultSettings
                        })], 2), t._v(" "), n("v-fieldset", {
                            attrs: {
                                "syno-id": "syno-lp-le-fieldset-domain",
                                title: t.$i18n("app_port_alias", "desc_domain")
                            }
                        }, [t._t("domain", [n("v-form-item", {
                            attrs: {
                                "syno-id": "syno-lp-le-form-item-domain-desc",
                                "hide-label": "",
                                textonly: ""
                            }
                        }, [t._v("\n                " + t._s(t.$i18n("controlpanel", "dsm_domain_desc")) + "\n              ")]), t._v(" "), n("v-form-item", {
                            staticClass: "ac-lp-login-editor__form-item",
                            attrs: {
                                "syno-id": "syno-lp-le-form-item-domain",
                                label: "" + t.$i18n("controlpanel", "customized_domain") + t.$i18n("common", "colon"),
                                prop: "p-lp-domain",
                                rules: t.dsmFqdnRules
                            },
                            scopedSlots: t._u([{
                                key: "after",
                                fn: function() {
                                    return [n("v-whitetip", {
                                        attrs: {
                                            "syno-id": "syno-lp-le-whitetip-hsts",
                                            content: t.$i18n("service", "tip_dsm_fqdn_NetBIOS")
                                        }
                                    })]
                                },
                                proxy: !0
                            }])
                        }, [n("v-input", {
                            staticClass: "ac-lp-login-editor__input",
                            attrs: {
                                "syno-id": "syno-lp-le-input-domain",
                                name: "p-lp-domain"
                            },
                            model: {
                                value: t.currentSettings.fqdn,
                                callback: function(e) {
                                    t.$set(t.currentSettings, "fqdn", e)
                                },
                                expression: "currentSettings.fqdn"
                            }
                        })], 1), t._v(" "), n("v-form-item", {
                            attrs: {
                                "syno-id": "syno-lp-le-form-item-hsts",
                                "hide-label": "",
                                prop: "p-lp-hsts"
                            }
                        }, [n("v-checkbox", {
                            attrs: {
                                "syno-id": "syno-lp-le-checkbox-hsts",
                                name: "p-lp-hsts",
                                disabled: !t.currentSettings.enable_custom_domain
                            },
                            model: {
                                value: t.form.enable_hsts,
                                callback: function(e) {
                                    t.$set(t.form, "enable_hsts", e)
                                },
                                expression: "form.enable_hsts"
                            }
                        }, [t._v("\n                  " + t._s(t.$i18n("service", "enable_hsts_desc")) + "\n                ")])], 1)], {
                            settings: t.currentSettings,
                            defaultSettings: t.defaultSettings,
                            form: t.form
                        })], 2), t._v(" "), t._t("post-fieldsets", null, {
                            settings: t.currentSettings,
                            defaultSettings: t.defaultSettings
                        })], 2)], 1)])]
                    },
                    proxy: !0
                }], null, !0)
            })
        }, [], !1, null, null, null).exports);

    function Wt(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }

    function zt(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise(function(r, o) {
                var i = t.apply(e, n);

                function a(t) {
                    Wt(i, r, o, a, s, "next", t)
                }

                function s(t) {
                    Wt(i, r, o, a, s, "throw", t)
                }
                a(void 0)
            })
        }
    }
    var Qt = {
            components: {
                CommonLoginEditor: Ut
            },
            mixins: [it],
            mounted: function() {
                this.load()
            },
            data: function() {
                return {
                    dsmSettings: {}
                }
            },
            computed: {
                stringGotoCertificate: function() {
                    return this.$i18n("certificate", "goto_certificate")
                },
                stringGotoCertificateFront: function() {
                    return this.stringGotoCertificate.split("{0}").reduce(function(t) {
                        return t
                    })
                },
                stringGotoCertificateEnd: function() {
                    return this.stringGotoCertificate.split("{0}").reduce(function(t, e) {
                        return e
                    })
                }
            },
            methods: {
                load: function() {
                    var t = zt(regeneratorRuntime.mark(function t() {
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return this.$refs.loginEditor.onLoading(), t.next = 3, S();
                                case 3:
                                    return this.dsmSettings = t.sent, t.next = 6, this.$nextTick();
                                case 6:
                                    this.$refs.loginEditor.$refs.form.commit(), this.$refs.loginEditor.onDone();
                                case 8:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                gotoCertificatePage: function() {
                    this.$appWindow.startModule("SYNO.SDS.AdminCenter.Security.Main", {
                        tab: "CertificateTab"
                    })
                },
                onCancel: function() {
                    this.$refs.loginEditor.onReset()
                },
                updateDSMSettings: function() {
                    var t = zt(regeneratorRuntime.mark(function t() {
                        var e, n, r, o, i = arguments;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    if (e = i.length > 0 && void 0 !== i[0] ? i[0] : {}, n = i.length > 1 ? i[1] : void 0, r = i.length > 2 ? i[2] : void 0, this.$refs.loginEditor._isDirty()) {
                                        t.next = 5;
                                        break
                                    }
                                    return t.abrupt("return", r(this.$i18n("error", "nochange_subject")));
                                case 5:
                                    return t.prev = 5, t.next = 8, C(e);
                                case 8:
                                    o = t.sent, n(), this.redirectOrRestart(o && o.redirect_url), this.load(), t.next = 17;
                                    break;
                                case 14:
                                    t.prev = 14, t.t0 = t.catch(5), r(t.t0);
                                case 17:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this, [
                            [5, 14]
                        ])
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                redirectOrRestart: function() {
                    var t = zt(regeneratorRuntime.mark(function t() {
                        var e, n, r, o = this,
                            i = arguments;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    if (e = i.length > 0 && void 0 !== i[0] ? i[0] : "", n = !this.$appWindow.IsAllowRelay() || this.$appWindow.getOpenConfig("cms_self"), e && n) {
                                        t.next = 7;
                                        break
                                    }
                                    return t.next = 5, new Promise(function(t) {
                                        SYNO.SDS.AdminCenter.Utils.WaitHttpdRestart(o.$appWindow, t)()
                                    });
                                case 5:
                                    return this.$appWindow.IsAllowRelay() && this.$appWindow.close(), t.abrupt("return");
                                case 7:
                                    return r = e.replace("://127.0.0.1", "://".concat(this.$appWindow.getDsmHost())), this.maskDSMWithMessageBox(this.$i18n("service", "restart_apache")), t.next = 11, new Promise(function(t) {
                                        return setTimeout(t, 3e4)
                                    });
                                case 11:
                                    return this.maskDSMWithMessageBox(this.$i18n("tcpip", "connect_new_ip")), SYNO.SDS.UserSettings.unregisterUnloadEvent(), window.location.href = r, t.abrupt("return");
                                case 15:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                maskDSMWithMessageBox: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    this.dsmMessageBox && !this.dsmMessageBox.isDestroyed || (this.dsmMessageBox = new SYNO.SDS.MessageBoxV5({
                        modal: !0,
                        draggable: !1,
                        renderTo: document.body
                    })), this.dsmMessageBox.getWrapper().show({
                        msg: t || this.$i18n("common", "msg_waiting")
                    })
                }
            }
        },
        Kt = (n(27), {
            components: {
                DsmLoginEditor: d(Qt, function() {
                    var t = this,
                        e = t.$createElement,
                        n = t._self._c || e;
                    return n("common-login-editor", {
                        ref: "loginEditor",
                        attrs: {
                            "application-id": "dsm",
                            settings: t.dsmSettings
                        },
                        on: {
                            apply: t.updateDSMSettings,
                            cancel: t.onCancel
                        },
                        scopedSlots: t._u([{
                            key: "post-web-service",
                            fn: function(e) {
                                var r = e.settings;
                                return [n("v-form-item", {
                                    attrs: {
                                        "syno-id": "syno-lp-dsm-form-item-redirect",
                                        "hide-label": "",
                                        prop: "p-lp-dsm-redirect"
                                    }
                                }, [n("v-checkbox", {
                                    attrs: {
                                        "syno-id": "syno-lp-dsm-checkbox-redirect"
                                    },
                                    model: {
                                        value: r.enable_https_redirect,
                                        callback: function(e) {
                                            t.$set(r, "enable_https_redirect", e)
                                        },
                                        expression: "currentSettings.enable_https_redirect"
                                    }
                                }, [t._v("\n        " + t._s(t.$i18n("service", "redirect_secureui")) + "\n      ")])], 1), t._v(" "), n("v-form-item", {
                                    attrs: {
                                        "syno-id": "syno-lp-dsm-form-item-certificate",
                                        "hide-label": "",
                                        textonly: ""
                                    }
                                }, [n("span", {
                                    staticClass: "ac-lp-text-note"
                                }, [t._v(t._s(t.$i18n("common", "note")) + t._s(t.$i18n("common", "colon")))]), t._v("\n      " + t._s(t.stringGotoCertificateFront) + "\n      "), n("a", {
                                    staticClass: "ac-lp-link",
                                    on: {
                                        click: t.gotoCertificatePage
                                    }
                                }, [t._v(t._s(t.$i18n("certificate", "certificate")))]), t._v("\n      " + t._s(t.stringGotoCertificateEnd) + "\n    ")])]
                            }
                        }])
                    })
                }, [], !1, null, "59793c74", null).exports
            },
            methods: {
                load: function() {
                    this.$refs.dsmEditor.load()
                },
                isDirty: function() {
                    return this.$refs.dsmEditor.$refs.loginEditor._isDirty()
                },
                onApply: function() {
                    this.$refs.dsmEditor.$refs.loginEditor.onApply()
                },
                onCancel: function() {
                    this.$refs.dsmEditor.$refs.loginEditor.onReset()
                }
            }
        }),
        Gt = (n(28), d(Kt, function() {
            var t = this.$createElement,
                e = this._self._c || t;
            return e("div", {
                staticClass: "lp-tab--dsm"
            }, [e("dsm-login-editor", {
                ref: "dsmEditor"
            })], 1)
        }, [], !1, null, "a894f550", null).exports),
        Jt = {
            mixins: [it],
            mounted: function() {
                var t = this.$appWindow.IsAllowRelay(),
                    e = t ? this.$appWindow.getDsmHost() : window.location.hostname,
                    n = t ? this.$appWindow.getDsmHttpPort() : window.location.port;
                this.linkMaker = SYNO.SDS.AdminCenter.LoginPortal.Utils.LinkMaker(!0, !0, t, e, n)
            },
            data: function() {
                return {
                    linkMaker: function() {}
                }
            },
            methods: {
                generateAliasHref: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    return this.linkMaker(!1, !0, !1, !0, t, !1)
                },
                generateHttpPortHref: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    return this.linkMaker(!1, !1, !0, !0, t, !0)
                },
                generateHttpsPortHref: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    return this.linkMaker(!1, !1, !1, !0, t, !0)
                },
                generateFqdnHref: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "";
                    return SYNO.SDS.AdminCenter.LoginPortal.Utils.FQDNLinkMaker2(t)
                }
            }
        },
        Xt = {
            mixins: [Jt],
            props: {
                application: {
                    type: Object,
                    required: !0
                }
            },
            computed: {
                isQuickConnectTunnel: function() {
                    return SYNO.SDS.QuickConnect.Utils.isInTunnel()
                },
                fqdnLink: function() {
                    return this.generateFqdnHref(this.application.fqdn)
                },
                httpLink: function() {
                    return this.generateHttpPortHref(this.application.http_port)
                },
                httpsLink: function() {
                    return this.generateHttpsPortHref(this.application.https_port)
                },
                aliasLink: function() {
                    return this.generateAliasHref(this.application.alias)
                }
            }
        },
        Zt = (n(29), {
            components: {
                ApplicationPreview: rt,
                ApplicationInformation: d(Xt, function() {
                    var t = this,
                        e = t.$createElement,
                        n = t._self._c || e;
                    return n("div", {
                        staticClass: "lp-applications-information"
                    }, [n("div", {
                        staticClass: "lp-applications-information__row lp-applications-information__row--title"
                    }, [t._v(t._s(t.application.display_name))]), t._v(" "), n("div", {
                        staticClass: "lp-applications-information__row"
                    }, [n("span", {
                        staticClass: "lp-applications-information__row__label"
                    }, [t._v(t._s(t.$i18n("app_port_alias", "desc_domain")) + t._s(t.$i18n("common", "colon")))]), t._v(" "), n("span", {
                        staticClass: "lp-applications-information__row__field"
                    }, [!t.isQuickConnectTunnel && t.application.fqdn ? n("a", {
                        attrs: {
                            href: t.fqdnLink,
                            target: "_blank"
                        }
                    }, [t._v(t._s(t.application.fqdn))]) : t.application.fqdn ? n("span", [t._v(t._s(t.application.fqdn))]) : n("span", [t._v("-")])])]), t._v(" "), n("div", {
                        staticClass: "lp-applications-information__row"
                    }, [n("span", {
                        staticClass: "lp-applications-information__row__label"
                    }, [t._v("Http / Https" + t._s(t.$i18n("common", "colon")))]), t._v(" "), n("span", {
                        staticClass: "lp-applications-information__row__field"
                    }, [!t.isQuickConnectTunnel && t.application.http_port ? n("a", {
                        attrs: {
                            href: t.httpLink,
                            target: "_blank"
                        }
                    }, [t._v(t._s(t.application.http_port))]) : t.application.http_port ? n("span", [t._v(t._s(t.application.http_port))]) : n("span", [t._v("-")]), t._v(" "), n("span", [t._v("/")]), t._v(" "), !t.isQuickConnectTunnel && t.application.https_port ? n("a", {
                        attrs: {
                            href: t.httpsLink,
                            target: "_blank"
                        }
                    }, [t._v(t._s(t.application.https_port))]) : t.application.https_port ? n("span", [t._v(t._s(t.application.https_port))]) : n("span", [t._v("-")])])]), t._v(" "), n("div", {
                        staticClass: "lp-applications-information__row"
                    }, [n("span", {
                        staticClass: "lp-applications-information__row__label"
                    }, [t._v(t._s(t.$i18n("app_port_alias", "desc_alias")) + t._s(t.$i18n("common", "colon")))]), t._v(" "), n("span", {
                        staticClass: "lp-applications-information__row__field"
                    }, [t.application.alias ? n("a", {
                        attrs: {
                            href: t.aliasLink,
                            target: "_blank"
                        }
                    }, [t._v(t._s(t.application.alias))]) : n("span", [t._v("-")])])])])
                }, [], !1, null, null, null).exports
            },
            props: {
                application: {
                    type: Object,
                    required: !0
                }
            },
            methods: {
                load: function() {
                    [this.$refs.preview, this.$refs.information].forEach(function(t) {
                        return t.load && t.load()
                    })
                }
            }
        });
    n(30);

    function te(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }
    var ee = {
            components: {
                ApplicationItem: d(Zt, function() {
                    var t = this.$createElement,
                        e = this._self._c || t;
                    return e("div", {
                        staticClass: "application-item"
                    }, [e("application-preview", {
                        ref: "preview",
                        staticClass: "application-item__preview",
                        attrs: {
                            "application-id": this.application.id
                        }
                    }), this._v(" "), e("application-information", {
                        ref: "information",
                        staticClass: "application-item__information",
                        attrs: {
                            application: this.application
                        }
                    })], 1)
                }, [], !1, null, "760531c0", null).exports
            },
            mixins: [it, pt],
            mounted: function() {
                this.load()
            },
            computed: {
                selectedApplicationId: function() {
                    return this.applications[this.selectedIndex] && this.applications[this.selectedIndex].id || null
                }
            },
            data: function() {
                return {
                    selectedIndex: null,
                    applications: []
                }
            },
            methods: {
                load: function() {
                    var t, e = (t = regeneratorRuntime.mark(function t() {
                        var e, n, r = this;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return this.onLoading(), t.next = 3, g();
                                case 3:
                                    e = t.sent, n = e && e.portal || [], this.applications = n.filter(function(t) {
                                        return SYNO.SDS.StatusNotifier.isAppEnabled(t.id)
                                    }), this.applications.forEach(function(t, e) {
                                        r.$refs["application-item-".concat(e)] && r.$refs["application-item-".concat(e)].load && r.$refs["application-item-".concat(e)].load()
                                    }), this.onDone();
                                case 8:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }), function() {
                        var e = this,
                            n = arguments;
                        return new Promise(function(r, o) {
                            var i = t.apply(e, n);

                            function a(t) {
                                te(i, r, o, a, s, "next", t)
                            }

                            function s(t) {
                                te(i, r, o, a, s, "throw", t)
                            }
                            a(void 0)
                        })
                    });
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                openEditorDialog: function() {
                    var t = this,
                        e = this.applications.find(function(e) {
                            return e.id === t.selectedApplicationId
                        });
                    if (e) {
                        var n = this.$appWindow.openVueWindow(SYNO.SDS.AdminCenter.LoginPortal.Dialogs.ApplicationEditor_vue),
                            r = n.component,
                            o = n.window;
                        r.$children[0].$data.applicationId = e.id, r.$children[0].$data.applicationDisplayName = e.display_name, o.$on("close", function() {
                            return t.load()
                        })
                    }
                },
                openOptionsDialog: function() {
                    this.$appWindow.openVueWindow(SYNO.SDS.AdminCenter.LoginPortal.Dialogs.Options_vue)
                },
                onApply: function() {
                    this.load()
                },
                onCancel: function() {
                    this.load()
                }
            }
        },
        ne = (n(31), d(ee, function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("div", {
                staticClass: "lp-tab lp-applications-page"
            }, [n("v-panel", {
                staticClass: "lp-tab__panel lp-applications-page__panel",
                attrs: {
                    "syno-id": "syno-lp-panel-apps",
                    "fluid-footer": "",
                    "has-tbar": "",
                    "has-fbar": !1,
                    loading: t.spinner.isLoading,
                    "loading-type": t.spinner.loadingType,
                    "show-status-bar": t.spinner.showStatusBar,
                    "status-bar-state": t.spinner.statusBarState,
                    "error-text": t.spinner.errorText,
                    confirm: function() {
                        return t.onApply()
                    },
                    cancel: function() {
                        return t.onCancel()
                    }
                },
                on: {
                    "update:showStatusBar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    },
                    "update:show-status-bar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    }
                },
                scopedSlots: t._u([{
                    key: "tbar",
                    fn: function() {
                        return [n("v-button", {
                            attrs: {
                                "syno-id": "syno-lp-btn-apps-edit",
                                disabled: !t.selectedApplicationId
                            },
                            on: {
                                click: function(e) {
                                    return t.openEditorDialog()
                                }
                            }
                        }, [t._v("\n        " + t._s(t.$i18n("common", "alt_edit")) + "\n      ")]), t._v(" "), n("v-button", {
                            attrs: {
                                "syno-id": "syno-lp-btn-apps-edit"
                            },
                            on: {
                                click: function(e) {
                                    return t.openOptionsDialog()
                                }
                            }
                        }, [t._v("\n        " + t._s(t.$i18n("common", "webman_options")) + "\n      ")])]
                    },
                    proxy: !0
                }, {
                    key: "body",
                    fn: function() {
                        return [n("v-data-view", {
                            staticClass: "lp-applications-page__data-view",
                            attrs: {
                                "syno-id": "syno-dv-lp-apps",
                                items: t.applications
                            },
                            on: {
                                selectionchange: function(e) {
                                    t.selectedIndex = e
                                }
                            },
                            scopedSlots: t._u([{
                                key: "item",
                                fn: function(e) {
                                    var r = e.item,
                                        o = e.index;
                                    return [n("div", {
                                        on: {
                                            dblclick: function(e) {
                                                return t.openEditorDialog()
                                            }
                                        }
                                    }, [n("application-item", {
                                        ref: "application-item-" + o,
                                        attrs: {
                                            application: r
                                        }
                                    })], 1)]
                                }
                            }])
                        })]
                    },
                    proxy: !0
                }])
            })], 1)
        }, [], !1, null, null, null).exports),
        re = {
            mixins: [it, pt],
            methods: {
                openReverseProxyDialog: function() {
                    var t = this.$appWindow.openVueWindow(SYNO.SDS.AdminCenter.LoginPortal.Dialogs.ReverseProxy_vue);
                    t.component, t.window
                },
                openAclDialog: function() {
                    var t = this.$appWindow.openVueWindow(SYNO.SDS.AdminCenter.LoginPortal.Dialogs.AccessControl_vue);
                    t.component, t.window
                }
            }
        },
        oe = (n(32), d(re, function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-panel", {
                staticClass: "lp-tab__panel lp-advanced-page__panel",
                attrs: {
                    "syno-id": "syno-panel-lp-advanced",
                    "fluid-footer": "",
                    "has-fbar": !1,
                    loading: t.spinner.isLoading,
                    "loading-type": t.spinner.loadingType,
                    "show-status-bar": t.spinner.showStatusBar,
                    "status-bar-state": t.spinner.statusBarState,
                    "error-text": t.spinner.errorText
                },
                on: {
                    "update:showStatusBar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    },
                    "update:show-status-bar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    }
                },
                scopedSlots: t._u([{
                    key: "body",
                    fn: function() {
                        return [n("v-form", {
                            attrs: {
                                "syno-id": "syno-form-lp-adv"
                            }
                        }, [n("v-fieldset", {
                            staticClass: "lp-advanced-page__first-fieldset",
                            attrs: {
                                "syno-id": "syno-fieldset-lp-adv-reverse-proxy",
                                title: t.$i18n("app_port_alias", "title_reverse_proxy"),
                                collapsible: !1
                            }
                        }, [n("v-form-item", {
                            attrs: {
                                "syno-id": "syno-form-item-lp-adv-reverse-proxy-desc",
                                "hide-label": "",
                                textonly: ""
                            }
                        }, [t._v("\n          " + t._s(t.$i18n("controlpanel", "reverse_proxy_desc")) + "\n        ")]), t._v(" "), n("v-button", {
                            attrs: {
                                "syno-id": "syno-btn-lp-adv-rp"
                            },
                            on: {
                                click: function(e) {
                                    return t.openReverseProxyDialog()
                                }
                            }
                        }, [t._v("\n        " + t._s(t.$i18n("app_port_alias", "title_reverse_proxy")) + "\n        ")])], 1), t._v(" "), n("v-fieldset", {
                            attrs: {
                                "syno-id": "syno-fieldset-lp-adv-acl",
                                title: t.$i18n("app_port_alias", "title_access_control"),
                                collapsible: !1
                            }
                        }, [n("v-form-item", {
                            attrs: {
                                "syno-id": "syno-form-item-lp-adv-acl-desc",
                                "hide-label": "",
                                textonly: ""
                            },
                            scopedSlots: t._u([{
                                key: "after",
                                fn: function() {
                                    return [n("v-whitetip", {
                                        attrs: {
                                            "syno-id": "syno-lp-le-whitetip-http",
                                            content: t.$i18n("controlpanel", "desc_acl_profile")
                                        }
                                    })]
                                },
                                proxy: !0
                            }])
                        }, [t._v("\n          " + t._s(t.$i18n("controlpanel", "acl_desc")) + "\n          ")]), t._v(" "), n("v-button", {
                            attrs: {
                                "syno-id": "syno-btn-lp-adv-rp"
                            },
                            on: {
                                click: function(e) {
                                    return t.openAclDialog()
                                }
                            }
                        }, [t._v("\n        " + t._s(t.$i18n("app_port_alias", "title_access_control")) + "\n        ")])], 1)], 1)]
                    },
                    proxy: !0
                }])
            })
        }, [], !1, null, null, null)),
        ie = d({
            components: {
                TabDsm: Gt,
                TabApplications: ne,
                TabAdvanced: oe.exports
            },
            computed: {
                hasFbar: function() {
                    return "dsm" === this.tabKey
                }
            },
            data: function() {
                return {
                    tabKey: "dsm"
                }
            },
            methods: {
                load: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                    [this.$refs.dsm, this.$refs.applications, this.$refs.advanced].forEach(function(t) {
                        return t.load && t.load()
                    }), this.setTab(t.tab)
                },
                setTab: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : "",
                        e = ["dsm", "applications", "advanced"].includes(t) ? t : "dsm";
                    this.tabKey = e
                },
                isDirty: function() {
                    var t = this;
                    return ["dsm", "applications", "advanced"].some(function(e) {
                        var n = t.$refs[e],
                            r = n.isDirty && n.isDirty() || !1;
                        return r && (t.tabKey = e), r
                    })
                },
                onApply: function() {
                    [this.$refs.dsm, this.$refs.applications, this.$refs.advanced].forEach(function(t) {
                        return t.onApply && t.onApply()
                    })
                },
                onCancel: function() {
                    this.$refs.dsm.onCancel()
                }
            }
        }, function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-tabs", {
                staticClass: "admin-center__login-portal",
                attrs: {
                    "syno-id": "ac-lp-tabs",
                    "active-tab-key": t.tabKey,
                    "has-fbar": !1,
                    "cancel-text": t.$i18n("common", "reset")
                },
                on: {
                    change: function(e) {
                        t.tabKey = e
                    }
                }
            }, [n("v-tab-pane", {
                attrs: {
                    "syno-id": "ac-lp-tab-dsm",
                    "tab-key": "dsm",
                    tab: "DSM"
                }
            }, [n("tab-dsm", {
                ref: "dsm"
            })], 1), t._v(" "), n("v-tab-pane", {
                attrs: {
                    "syno-id": "ac-lp-tab-dsm",
                    "tab-key": "applications",
                    tab: t.$i18n("controlpanel", "applications")
                }
            }, [n("tab-applications", {
                ref: "applications"
            })], 1), t._v(" "), n("v-tab-pane", {
                attrs: {
                    "syno-id": "ac-lp-tab-dsm",
                    "tab-key": "advanced",
                    tab: t.$i18n("controlpanel", "advanced")
                }
            }, [n("tab-advanced", {
                ref: "advanced"
            })], 1)], 1)
        }, [], !1, null, null, null).exports;

    function ae(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter(function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            }))), r.forEach(function(e) {
                se(t, e, n[e])
            })
        }
        return t
    }

    function se(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }

    function ce(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }

    function le(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise(function(r, o) {
                var i = t.apply(e, n);

                function a(t) {
                    ce(i, r, o, a, s, "next", t)
                }

                function s(t) {
                    ce(i, r, o, a, s, "throw", t)
                }
                a(void 0)
            })
        }
    }

    function ue(t) {
        return function(t) {
            if (Array.isArray(t)) return pe(t)
        }(t) || function(t) {
            if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) return Array.from(t)
        }(t) || function(t, e) {
            if (!t) return;
            if ("string" == typeof t) return pe(t, e);
            var n = Object.prototype.toString.call(t).slice(8, -1);
            "Object" === n && t.constructor && (n = t.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(n);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return pe(t, e)
        }(t) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function pe(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
        return r
    }
    var de = {
            components: {
                CommonLoginEditor: Ut
            },
            mixins: [Jt, it, ct],
            props: {
                inModal: {
                    type: Boolean,
                    default: !1
                },
                applicationId: {
                    type: String,
                    required: !0
                }
            },
            mounted: function() {
                this.fetchAppPortal(), this.fetchAccessControl()
            },
            computed: {
                isQuickConnectTunnel: function() {
                    return SYNO.SDS.QuickConnect.Utils.isInTunnel()
                },
                tipPrefix: function() {
                    return "".concat(this.$i18n("service", "service_file_customized_tip"), " ").concat(this.$i18n("common", "colon"), " ")
                },
                rules: function() {
                    return r
                },
                aliasRules: function() {
                    return gt(this.aliasValidator)
                },
                httpPortRules: function() {
                    var t = this;
                    return function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        return [{
                            asyncValidator: function() {
                                var e = le(regeneratorRuntime.mark(function e() {
                                    return regeneratorRuntime.wrap(function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                            case 0:
                                                if (!t.errors.httpPort) {
                                                    e.next = 2;
                                                    break
                                                }
                                                throw t.errors.httpPort;
                                            case 2:
                                            case "end":
                                                return e.stop()
                                        }
                                    }, e, this)
                                }));
                                return function() {
                                    return e.apply(this, arguments)
                                }
                            }()
                        }].concat(ue(_t(t.portValidator)(e.https_port)))
                    }
                },
                httpsPortRules: function() {
                    var t = this;
                    return function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
                        return [{
                            asyncValidator: function() {
                                var e = le(regeneratorRuntime.mark(function e() {
                                    return regeneratorRuntime.wrap(function(e) {
                                        for (;;) switch (e.prev = e.next) {
                                            case 0:
                                                if (!t.errors.httpsPort) {
                                                    e.next = 2;
                                                    break
                                                }
                                                throw t.errors.httpsPort;
                                            case 2:
                                            case "end":
                                                return e.stop()
                                        }
                                    }, e, this)
                                }));
                                return function() {
                                    return e.apply(this, arguments)
                                }
                            }()
                        }].concat(ue(_t(t.portValidator)(e.http_port)))
                    }
                },
                applicationFqdnRules: function() {
                    var t = this;
                    return [{
                        asyncValidator: function() {
                            var e = le(regeneratorRuntime.mark(function e() {
                                return regeneratorRuntime.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            if (!t.errors.fqdn) {
                                                e.next = 2;
                                                break
                                            }
                                            throw t.errors.fqdn;
                                        case 2:
                                        case "end":
                                            return e.stop()
                                    }
                                }, e, this)
                            }));
                            return function() {
                                return e.apply(this, arguments)
                            }
                        }()
                    }, {
                        asyncValidator: function() {
                            var t = le(regeneratorRuntime.mark(function t(e, n) {
                                return regeneratorRuntime.wrap(function(t) {
                                    for (;;) switch (t.prev = t.next) {
                                        case 0:
                                            if (Ext.form.VTypes.FQDN(n)) {
                                                t.next = 2;
                                                break
                                            }
                                            throw Ext.form.VTypes.FQDNText;
                                        case 2:
                                        case "end":
                                            return t.stop()
                                    }
                                }, t, this)
                            }));
                            return function(e, n) {
                                return t.apply(this, arguments)
                            }
                        }()
                    }].concat(ue(ht(this.fqdnValidator)))
                },
                accessControlRules: function() {
                    var t = this;
                    return [{
                        asyncValidator: function() {
                            var e = le(regeneratorRuntime.mark(function e(n, r) {
                                return regeneratorRuntime.wrap(function(e) {
                                    for (;;) switch (e.prev = e.next) {
                                        case 0:
                                            if (t.accessControlOptions.some(function(t) {
                                                    return t.value === r
                                                })) {
                                                e.next = 3;
                                                break
                                            }
                                            throw t.$i18n("extlang", "invalidText");
                                        case 3:
                                        case "end":
                                            return e.stop()
                                    }
                                }, e, this)
                            }));
                            return function(t, n) {
                                return e.apply(this, arguments)
                            }
                        }()
                    }]
                },
                accessControlOptions: function() {
                    return [{
                        label: this.$i18n("app_port_alias", "not_configured"),
                        value: null
                    }].concat(ue(this.accessControls.map(function(t) {
                        return {
                            label: t.name,
                            value: t.UUID
                        }
                    })))
                }
            },
            data: function() {
                return {
                    dataProperty: "settings",
                    settings: {},
                    accessControls: [],
                    fqdnValidator: new Mt(this.applicationId),
                    portValidator: new Rt(this.applicationId),
                    aliasValidator: new Tt(this.applicationId),
                    errors: {
                        httpPort: "",
                        httpsPort: "",
                        fqdn: ""
                    },
                    isCreateAccessControlActive: !1
                }
            },
            methods: {
                fetchAppPortal: function() {
                    var t = le(regeneratorRuntime.mark(function t() {
                        var e;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.next = 2, R(this.applicationId);
                                case 2:
                                    return e = t.sent, this.settings = ae({
                                        acl: null,
                                        fqdn: null
                                    }, e), t.next = 6, this.$nextTick();
                                case 6:
                                    this.$refs.loginEditor.$refs.form.commit();
                                case 7:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                fetchAccessControl: function() {
                    var t = le(regeneratorRuntime.mark(function t() {
                        var e;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.next = 2, Y();
                                case 2:
                                    e = t.sent, this.accessControls = e && e.entries || [];
                                case 4:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                openCreateDialog: function() {
                    var t = le(regeneratorRuntime.mark(function t() {
                        var e, n = this;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    this.isCreateAccessControlActive = !1, this.$refs.select.closeDropdown(), this.updateAppWindow(), e = this.$window.openWindow(SYNO.SDS.AdminCenter.LoginPortal.Dialogs.CreateAccessControl_vue), e.component, e.window.$on("success", function() {
                                        var t = le(regeneratorRuntime.mark(function t(e) {
                                            var r;
                                            return regeneratorRuntime.wrap(function(t) {
                                                for (;;) switch (t.prev = t.next) {
                                                    case 0:
                                                        return t.next = 2, n.fetchAccessControl();
                                                    case 2:
                                                        r = n.accessControls.find(function(t) {
                                                            return t.name === e.name
                                                        }), n.settings.acl = r.UUID || null;
                                                    case 4:
                                                    case "end":
                                                        return t.stop()
                                                }
                                            }, t, this)
                                        }));
                                        return function(e) {
                                            return t.apply(this, arguments)
                                        }
                                    }());
                                case 5:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                emitApply: function() {
                    for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                    this.$emit.apply(this, ["apply"].concat(e))
                },
                emitCancel: function() {
                    for (var t = arguments.length, e = new Array(t), n = 0; n < t; n++) e[n] = arguments[n];
                    this.$emit.apply(this, ["cancel"].concat(e))
                },
                _onLoading: function() {
                    this.errors.httpPort = "", this.errors.httpsPort = "", this.errors.fqdn = ""
                },
                _onError: function(t) {
                    if (t && t.code) {
                        switch (t.code) {
                            case 4105:
                                this.errors.httpPort = SYNO.API.getErrorString(t);
                                break;
                            case 4106:
                                this.errors.httpsPort = SYNO.API.getErrorString(t);
                                break;
                            case 4107:
                                this.errors.fqdn = SYNO.API.getErrorString(t)
                        }
                        this.$refs.loginEditor.$refs.form.validate()
                    }
                }
            }
        },
        fe = (n(33), d(de, function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("common-login-editor", {
                ref: "loginEditor",
                staticClass: "ac-application-login-editor",
                attrs: {
                    "in-modal": t.inModal,
                    "application-id": t.applicationId,
                    settings: t.settings
                },
                on: {
                    apply: t.emitApply,
                    cancel: t.emitCancel,
                    loading: t._onLoading,
                    error: t._onError
                },
                scopedSlots: t._u([{
                    key: "web-service",
                    fn: function(e) {
                        var r = e.settings,
                            o = e.defaultSettings;
                        return [n("v-form-item", {
                            attrs: {
                                "syno-id": "syno-form-item-lp-ale-webservice-desc",
                                "hide-label": "",
                                textonly: ""
                            }
                        }, [t._v("\n      " + t._s(t.$i18n("controlpanel", "applications_web_service_desc")) + "\n    ")]), t._v(" "), n("v-form-item", {
                            staticClass: "ac-lp-login-editor__form-item",
                            attrs: {
                                "syno-id": "syno-form-item-lp-ale-alias",
                                prop: "p-lp-ale-alias",
                                label: t._f("colon")(t.$i18n("app_port_alias", "desc_alias")),
                                rules: t.aliasRules
                            }
                        }, [n("v-input", {
                            staticClass: "ac-lp-login-editor__input",
                            attrs: {
                                "syno-id": "syno-input-lp-ale-alias",
                                name: "p-lp-ale-alias",
                                placeholder: o.alias
                            },
                            model: {
                                value: r.alias,
                                callback: function(e) {
                                    t.$set(r, "alias", e)
                                },
                                expression: "currentSettings.alias"
                            }
                        })], 1), t._v(" "), n("v-form-item", {
                            directives: [{
                                name: "show",
                                rawName: "v-show",
                                value: r.alias,
                                expression: "currentSettings.alias"
                            }],
                            staticClass: "ac-lp-login-editor__form-item link-tip-wrapper",
                            attrs: {
                                "text-only": "",
                                "syno-id": "syno-form-item-lp-ale-alias-link"
                            }
                        }, [n("span", {
                            directives: [{
                                name: "tooltip",
                                rawName: "v-tooltip",
                                value: "" + t.generateAliasHref(r.alias),
                                expression: "`${generateAliasHref(currentSettings.alias)}`"
                            }],
                            staticClass: "link-tip"
                        }, [t._v("\n        " + t._s(t.tipPrefix) + "\n        "), t.settings.alias === r.alias ? n("a", {
                            attrs: {
                                href: t.generateAliasHref(r.alias),
                                target: "_blank"
                            }
                        }, [t._v("\n          " + t._s(t.generateAliasHref(r.alias)) + "\n        ")]) : n("span", [t._v("\n          " + t._s(t.generateAliasHref(r.alias)) + "\n        ")])])]), t._v(" "), n("v-form-item", {
                            staticClass: "ac-lp-login-editor__form-item",
                            attrs: {
                                "syno-id": "syno-lp-ale-form-item-http",
                                label: t._f("colon")(t.$i18n("controlpanel", "customized_port_http")),
                                prop: "p-lp-ale-http",
                                rules: t.httpPortRules(r)
                            }
                        }, [n("v-input", {
                            staticClass: "ac-lp-login-editor__input",
                            attrs: {
                                "number-only": "",
                                name: "p-lp-ale-http",
                                "syno-id": "syno-lp-ale-input-http",
                                placeholder: o.http_port,
                                mask: function(t) {
                                    return t.substr(0, 5)
                                }
                            },
                            model: {
                                value: r.http_port,
                                callback: function(e) {
                                    t.$set(r, "http_port", e)
                                },
                                expression: "currentSettings.http_port"
                            }
                        })], 1), t._v(" "), t.isQuickConnectTunnel ? t._e() : n("v-form-item", {
                            directives: [{
                                name: "show",
                                rawName: "v-show",
                                value: r.http_port,
                                expression: "currentSettings.http_port"
                            }],
                            staticClass: "ac-lp-login-editor__form-item link-tip-wrapper",
                            attrs: {
                                "text-only": "",
                                "syno-id": "syno-form-item-lp-ale-http-link"
                            }
                        }, [n("span", {
                            directives: [{
                                name: "tooltip",
                                rawName: "v-tooltip",
                                value: "" + t.generateHttpPortHref(r.http_port),
                                expression: "`${generateHttpPortHref(currentSettings.http_port)}`"
                            }],
                            staticClass: "link-tip"
                        }, [t._v("\n        " + t._s(t.tipPrefix) + "\n        "), "" + t.settings.http_port == "" + r.http_port ? n("a", {
                            attrs: {
                                href: t.generateHttpPortHref(r.http_port),
                                target: "_blank"
                            }
                        }, [t._v("\n          " + t._s(t.generateHttpPortHref(r.http_port)) + "\n        ")]) : n("span", [t._v("\n          " + t._s(t.generateHttpPortHref(r.http_port)) + "\n        ")])])]), t._v(" "), n("v-form-item", {
                            staticClass: "ac-lp-login-editor__form-item",
                            attrs: {
                                "syno-id": "syno-lp-ale-form-item-https",
                                label: t._f("colon")(t.$i18n("controlpanel", "customized_port_https")),
                                prop: "p-lp-ale-https",
                                rules: t.httpsPortRules(r)
                            }
                        }, [n("v-input", {
                            staticClass: "ac-lp-login-editor__input",
                            attrs: {
                                "number-only": "",
                                name: "p-lp-ale-https",
                                "syno-id": "syno-lp-ale-input-https",
                                placeholder: o.https_port,
                                mask: function(t) {
                                    return t.substr(0, 5)
                                }
                            },
                            model: {
                                value: r.https_port,
                                callback: function(e) {
                                    t.$set(r, "https_port", e)
                                },
                                expression: "currentSettings.https_port"
                            }
                        })], 1), t._v(" "), t.isQuickConnectTunnel ? t._e() : n("v-form-item", {
                            directives: [{
                                name: "show",
                                rawName: "v-show",
                                value: r.https_port,
                                expression: "currentSettings.https_port"
                            }],
                            staticClass: "ac-lp-login-editor__form-item lp-login-style-editor__form-item--last link-tip-wrapper",
                            attrs: {
                                "text-only": "",
                                "syno-id": "syno-form-item-lp-ale-https-link"
                            }
                        }, [n("span", {
                            directives: [{
                                name: "tooltip",
                                rawName: "v-tooltip",
                                value: "" + t.generateHttpsPortHref(r.https_port),
                                expression: "`${generateHttpsPortHref(currentSettings.https_port)}`"
                            }],
                            staticClass: "link-tip"
                        }, [t._v("\n        " + t._s(t.tipPrefix) + "\n        "), "" + t.settings.https_port == "" + r.https_port ? n("a", {
                            attrs: {
                                href: t.generateHttpsPortHref(r.https_port),
                                target: "_blank"
                            }
                        }, [t._v("\n          " + t._s(t.generateHttpsPortHref(r.https_port)) + "\n        ")]) : n("span", [t._v("\n          " + t._s(t.generateHttpsPortHref(r.https_port)) + "\n        ")])])])]
                    }
                }, {
                    key: "domain",
                    fn: function(e) {
                        var r = e.settings,
                            o = e.defaultSettings,
                            i = e.form;
                        return [n("v-form-item", {
                            attrs: {
                                "syno-id": "syno-form-item-lp-ale-domain-desc",
                                "hide-label": "",
                                textonly: ""
                            }
                        }, [t._v("\n      " + t._s(t.$i18n("controlpanel", "applications_domain_desc")) + "\n    ")]), t._v(" "), n("v-form-item", {
                            staticClass: "ac-lp-login-editor__form-item",
                            attrs: {
                                "syno-id": "syno-lp-ale-form-item-domain",
                                label: t._f("colon")(t.$i18n("controlpanel", "customized_domain")),
                                prop: "p-lp-ale-domain",
                                rules: t.applicationFqdnRules
                            },
                            scopedSlots: t._u([{
                                key: "after",
                                fn: function() {
                                    return [n("v-whitetip", {
                                        attrs: {
                                            "syno-id": "syno-lp-le-whitetip-hsts",
                                            content: t.$i18n("service", "tip_dsm_fqdn_NetBIOS")
                                        }
                                    })]
                                },
                                proxy: !0
                            }], null, !0)
                        }, [n("v-input", {
                            staticClass: "ac-lp-login-editor__input",
                            attrs: {
                                "syno-id": "syno-lp-ale-input-domain",
                                name: "p-lp-ale-domain",
                                placeholder: o.fqdn
                            },
                            model: {
                                value: r.fqdn,
                                callback: function(e) {
                                    t.$set(r, "fqdn", e)
                                },
                                expression: "currentSettings.fqdn"
                            }
                        })], 1), t._v(" "), t.isQuickConnectTunnel ? t._e() : n("v-form-item", {
                            directives: [{
                                name: "show",
                                rawName: "v-show",
                                value: r.fqdn,
                                expression: "currentSettings.fqdn"
                            }],
                            staticClass: "ac-lp-login-editor__form-item link-tip-wrapper",
                            attrs: {
                                "text-only": "",
                                "syno-id": "syno-form-item-lp-ale-fqdn-link"
                            }
                        }, [n("span", {
                            directives: [{
                                name: "tooltip",
                                rawName: "v-tooltip",
                                value: "" + t.generateFqdnHref(r.fqdn),
                                expression: "`${generateFqdnHref(currentSettings.fqdn)}`"
                            }],
                            staticClass: "link-tip"
                        }, [t._v("\n        " + t._s(t.tipPrefix) + "\n        "), "" + t.settings.fqdn == "" + r.fqdn ? n("a", {
                            attrs: {
                                href: t.generateFqdnHref(r.fqdn),
                                target: "_blank"
                            }
                        }, [t._v("\n          " + t._s(t.generateFqdnHref(r.fqdn)) + "\n        ")]) : n("span", [t._v("\n          " + t._s(t.generateFqdnHref(r.fqdn)) + "\n        ")])])]), t._v(" "), n("v-form-item", {
                            staticClass: "lp-login-style-editor__form-item--last",
                            attrs: {
                                "syno-id": "syno-lp-ale-form-item-hsts",
                                "hide-label": "",
                                prop: "p-lp-ale-hsts"
                            }
                        }, [n("v-checkbox", {
                            attrs: {
                                "syno-id": "syno-lp-ale-checkbox-hsts",
                                name: "p-lp-ale-hsts",
                                disabled: !r.enable_custom_domain
                            },
                            model: {
                                value: i.enable_hsts,
                                callback: function(e) {
                                    t.$set(i, "enable_hsts", e)
                                },
                                expression: "form.enable_hsts"
                            }
                        }, [t._v("\n        " + t._s(t.$i18n("service", "enable_hsts_desc")) + "\n      ")])], 1)]
                    }
                }, {
                    key: "post-fieldsets",
                    fn: function(e) {
                        var r = e.settings;
                        return [n("v-fieldset", {
                            attrs: {
                                "syno-id": "syno-lp-ale-acl",
                                title: t.$i18n("app_port_alias", "title_access_control")
                            }
                        }, [n("v-form-item", {
                            attrs: {
                                "syno-id": "syno-form-item-lp-ale-acl-desc",
                                "hide-label": "",
                                textonly: ""
                            }
                        }, [t._v("\n        " + t._s(t.$i18n("controlpanel", "applications_acl_desc")) + "\n      ")]), t._v(" "), n("v-form-item", {
                            staticClass: "ac-lp-login-editor__form-item",
                            attrs: {
                                "syno-id": "syno-form-item-lp-ale-acl",
                                label: t._f("colon")(t.$i18n("app_port_alias", "desc_acl")),
                                prop: "syno-form-item-lp-ale-acl",
                                rules: t.accessControlRules
                            },
                            scopedSlots: t._u([{
                                key: "after",
                                fn: function() {
                                    return [n("v-whitetip", {
                                        attrs: {
                                            "syno-id": "syno-lp-le-whitetip-hsts"
                                        }
                                    }, [n("span", {
                                        domProps: {
                                            innerHTML: t._s(t.$i18n("app_port_alias", "tip_access_control"))
                                        }
                                    })])]
                                },
                                proxy: !0
                            }], null, !0)
                        }, [n("v-select", {
                            ref: "select",
                            attrs: {
                                readonly: "",
                                "syno-id": "syno-select-lp-ale-acl",
                                name: "syno-form-item-lp-ale-acl",
                                width: "200px",
                                options: t.accessControlOptions
                            },
                            scopedSlots: t._u([{
                                key: "bottom-actions",
                                fn: function(e) {
                                    var r, o = e.actionClass,
                                        i = e.activatedActionClass;
                                    return [n("div", {
                                        class: (r = {}, r[o] = !0, r[i] = t.isCreateAccessControlActive, r),
                                        on: {
                                            click: function(e) {
                                                return t.openCreateDialog()
                                            },
                                            mouseenter: function(e) {
                                                t.isCreateAccessControlActive = !0
                                            },
                                            mouseleave: function(e) {
                                                t.isCreateAccessControlActive = !1
                                            }
                                        }
                                    }, [t._v("\n              " + t._s(t.$i18n("vpnc", "create_profile")) + "\n            ")])]
                                }
                            }], null, !0),
                            model: {
                                value: r.acl,
                                callback: function(e) {
                                    t.$set(r, "acl", e)
                                },
                                expression: "currentSettings.acl"
                            }
                        })], 1)], 1)]
                    }
                }])
            })
        }, [], !1, null, null, null));

    function me(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }
    var he = d({
        components: {
            ApplicationLoginEditor: fe.exports
        },
        mixins: [it],
        computed: {
            title: function() {
                return this.$i18n("controlpanel", "edit_application_login_settings").replace("{0}", this.applicationDisplayName)
            }
        },
        data: function() {
            return {
                applicationId: null,
                applicationDisplayName: ""
            }
        },
        methods: {
            onApply: function() {
                var t, e = (t = regeneratorRuntime.mark(function t(e, n, r) {
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.prev = 0, t.next = 3, O(e);
                            case 3:
                                n(), this.close(), t.next = 10;
                                break;
                            case 7:
                                t.prev = 7, t.t0 = t.catch(0), r(t.t0);
                            case 10:
                            case "end":
                                return t.stop()
                        }
                    }, t, this, [
                        [0, 7]
                    ])
                }), function() {
                    var e = this,
                        n = arguments;
                    return new Promise(function(r, o) {
                        var i = t.apply(e, n);

                        function a(t) {
                            me(i, r, o, a, s, "next", t)
                        }

                        function s(t) {
                            me(i, r, o, a, s, "throw", t)
                        }
                        a(void 0)
                    })
                });
                return function(t, n, r) {
                    return e.apply(this, arguments)
                }
            }()
        }
    }, function() {
        var t = this,
            e = t.$createElement,
            n = t._self._c || e;
        return n("v-modal-window", {
            staticClass: "admin-center__login-portal",
            attrs: {
                "syno-id": "syno-lp-modal-app-editor",
                height: 580,
                width: 620,
                title: t.title,
                "before-close": function() {
                    return t.$refs.editor.$refs.loginEditor.beforeClose()
                }
            }
        }, [t.applicationId ? n("application-login-editor", {
            ref: "editor",
            attrs: {
                "in-modal": "",
                "application-id": t.applicationId
            },
            on: {
                apply: t.onApply,
                cancel: function(e) {
                    return t.close()
                }
            }
        }) : t._e()], 1)
    }, [], !1, null, null, null).exports;

    function ve(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }
    var _e = {
            components: {
                BackgroundPreview: f
            },
            mixins: [it],
            props: {
                applicationId: {
                    type: String,
                    required: !0
                },
                profile: {
                    type: Object,
                    required: !0
                }
            },
            mounted: function() {
                var t = this;
                this.$watch("form.enableBackground", function() {
                    t.form.enableBackground ? (t.form.backgroundImgOrColor = "image", t.profile.enable_background_customize = !0, t.profile.only_background_color = !1) : (t.profile.enable_background_customize = !1, t.profile.only_background_color = !1)
                }), this.$watch("form.backgroundImgOrColor", function() {
                    "image" === t.form.backgroundImgOrColor && (t.profile.enable_background_customize = !0, t.profile.only_background_color = !1), "color" === t.form.backgroundImgOrColor && (t.profile.enable_background_customize = !1, t.profile.only_background_color = !0)
                })
            },
            data: function() {
                return {
                    isCustomColorPanelShown: !1,
                    tmpBackgroundSrc: null,
                    form: {
                        enableBackground: this.profile.enable_background_customize || this.profile.only_background_color,
                        backgroundImgOrColor: this.profile.enable_background_customize ? "image" : "color"
                    }
                }
            },
            computed: {
                isRetina: function() {
                    return SYNO.SDS.UIFeatures.IconSizeManager.isRetinaMode()
                },
                resolution: function() {
                    return this.isRetina ? "2x" : "1x"
                },
                jsBaseUrl: function() {
                    return SYNO.SDS.Config.FnMap[this.applicationId] ? SYNO.SDS.Config.FnMap[this.applicationId].config.jsBaseURL : ""
                },
                loginStyleConfig: function() {
                    return SYNO.SDS.Config.FnMap[this.applicationId] ? SYNO.SDS.Config.FnMap[this.applicationId].config.loginStyle : {}
                },
                colorWindowConfig: function() {
                    return {
                        title: this.$i18n("personal_settings", "customize_color"),
                        showClose: !1,
                        showMaximize: !1,
                        resizable: !1,
                        showMinimize: !1,
                        height: "auto",
                        width: 436
                    }
                },
                shouldAppendedColorPickerShown: function() {
                    return ["center", "fit"].includes(this.profile.background_position)
                },
                backgroundPositionOptions: function() {
                    return [{
                        label: this.$i18n("dsmoption", "login_background_position_fill"),
                        value: "fill"
                    }, {
                        label: this.$i18n("dsmoption", "login_background_position_center"),
                        value: "center"
                    }, {
                        label: this.$i18n("dsmoption", "login_background_position_fit"),
                        value: "fit"
                    }, {
                        label: this.$i18n("dsmoption", "login_background_position_stretch"),
                        value: "stretch"
                    }, {
                        label: this.$i18n("dsmoption", "login_background_position_tile"),
                        value: "tile"
                    }]
                },
                backgroundImgOrColorOptions: function() {
                    return [{
                        label: this.$i18n("personal_settings", "image"),
                        value: "image"
                    }, {
                        label: this.$i18n("personal_settings", "color"),
                        value: "color"
                    }]
                }
            },
            methods: {
                openImageSelector: function() {
                    var t = this,
                        e = new SYNO.SDS.Utils.ImageSelector({
                            owner: this.$appWindow,
                            appName: this.applicationId
                        }, "login", "background");
                    e.mon(e, "choose", function(n) {
                        if (n) {
                            var r = n.get("apply_type");
                            switch (t.profile.background_type = r, t.profile.background_path = "fromDS" === r || "pkgDefault" === r ? n.get("path") : n.get("path").split("/").pop(), r) {
                                case "pkgDefault":
                                    t.tmpBackgroundSrc = "".concat(t.jsBaseUrl, "/").concat(t.loginStyleConfig.defaultLoginWallpaper).replace("{0}", t.resolution);
                                    break;
                                case "fromDS":
                                    t.tmpBackgroundSrc = n.get("url").replace(/size=%22medium%22/, "size=%22big%22");
                                    break;
                                default:
                                    t.tmpBackgroundSrc = n.get("url").replace(/is_thumbnail=(true)/, "is_thumbnail=false").replace(/thumbnail_(\d*)\./, "dsm7_$1.")
                            }
                            e.close()
                        }
                    }), this.$window.openExtWindow(e)
                },
                onColorChange: function(t) {
                    this.profile.background_color = t, this.closeCustomColorPanel()
                },
                showCustomColorPanel: function() {
                    var t, e = (t = regeneratorRuntime.mark(function t() {
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return this.isCustomColorPanelShown = !0, t.next = 3, this.$nextTick();
                                case 3:
                                    this.$window.openModalWindow(this.$refs.customColorWindow);
                                case 4:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }), function() {
                        var e = this,
                            n = arguments;
                        return new Promise(function(r, o) {
                            var i = t.apply(e, n);

                            function a(t) {
                                ve(i, r, o, a, s, "next", t)
                            }

                            function s(t) {
                                ve(i, r, o, a, s, "throw", t)
                            }
                            a(void 0)
                        })
                    });
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                closeCustomColorPanel: function() {
                    this.$refs.customColorWindow.close(), this.isCustomColorPanelShown = !1
                }
            }
        },
        ge = (n(34), d(_e, function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("div", {
                staticClass: "custom-background"
            }, [n("v-form-item", {
                staticClass: "custom-background__checkbox",
                attrs: {
                    "syno-id": "syno-form-item-lp-lse-bg",
                    "hide-label": "",
                    prop: "p-lp-lse-bg"
                }
            }, [n("v-checkbox", {
                attrs: {
                    "syno-id": "syno-checkbox-lp-lse-bg",
                    name: "p-lp-lse-bg"
                },
                model: {
                    value: t.form.enableBackground,
                    callback: function(e) {
                        t.$set(t.form, "enableBackground", e)
                    },
                    expression: "form.enableBackground"
                }
            }, [t._v("\n      " + t._s(t.$i18n("dsmoption", "login_background")) + "\n    ")])], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    "syno-id": "syno-lp-lse-background-preview",
                    "hide-label": "",
                    indent: "1"
                }
            }, [n("div", {
                staticClass: "custom-background__preview-and-select"
            }, [n("background-preview", {
                class: {
                    "custom-background__preview-background": !0, "custom-background__preview-background--disabled": !t.form.enableBackground
                },
                attrs: {
                    "only-show-custom": "",
                    "application-id": t.applicationId,
                    profile: t.profile,
                    "force-background-image": t.tmpBackgroundSrc
                }
            }), t._v(" "), n("div", [n("v-form-item", {
                attrs: {
                    "syno-id": "syno-form-item-lp-lse-enable-bg",
                    "hide-label": "",
                    prop: "p-lp-lse-enable-bg"
                }
            }, [n("v-select", {
                attrs: {
                    "syno-id": "syno-select-lp-lse-enable-bg",
                    width: "200px",
                    name: "p-lp-lse-enable-bg",
                    disabled: !t.form.enableBackground,
                    options: t.backgroundImgOrColorOptions
                },
                model: {
                    value: t.form.backgroundImgOrColor,
                    callback: function(e) {
                        t.$set(t.form, "backgroundImgOrColor", e)
                    },
                    expression: "form.backgroundImgOrColor"
                }
            })], 1), t._v(" "), "color" === t.form.backgroundImgOrColor ? [n("v-form-item", {
                attrs: {
                    "syno-id": "syno-form-item-lp-lse-color",
                    "hide-label": ""
                }
            }, [n("v-color-picker", {
                attrs: {
                    disabled: !t.profile.only_background_color,
                    "syno-id": "syno-cp-lp-lse-bg-color"
                },
                on: {
                    showcustom: function(e) {
                        return t.showCustomColorPanel()
                    }
                },
                model: {
                    value: t.profile.background_color,
                    callback: function(e) {
                        t.$set(t.profile, "background_color", e)
                    },
                    expression: "profile.background_color"
                }
            })], 1)] : [n("v-form-item", {
                attrs: {
                    "syno-id": "syno-form-item-lp-lse-select-btn",
                    "hide-label": ""
                }
            }, [n("v-button", {
                attrs: {
                    "syno-id": "syno-select-lp-lse-img",
                    disabled: !t.profile.enable_background_customize
                },
                on: {
                    click: function(e) {
                        return t.openImageSelector()
                    }
                }
            }, [t._v("\n              " + t._s(t.$i18n("personal_settings", "select_image")) + "\n            ")])], 1), t._v(" "), n("v-form-multiple-item", {
                attrs: {
                    "hide-label": "",
                    "syno-id": "syno-multiple-form-item-lp-lse-bg-pos"
                }
            }, [n("v-form-item", {
                staticClass: "lp-login-style-editor__form-item--last",
                attrs: {
                    "syno-id": "syno-form-item-lp-lse-bg-pos",
                    "hide-label": ""
                }
            }, [n("v-select", {
                attrs: {
                    "syno-id": "syno-select-lp-lse-bg-pos",
                    width: "200px",
                    disabled: !t.profile.enable_background_customize,
                    options: t.backgroundPositionOptions
                },
                model: {
                    value: t.profile.background_position,
                    callback: function(e) {
                        t.$set(t.profile, "background_position", e)
                    },
                    expression: "profile.background_position"
                }
            })], 1), t._v(" "), n("v-form-item", {
                staticClass: "lp-login-style-editor__form-item--last",
                attrs: {
                    "syno-id": "syno-form-item-lp-lse-appended-color",
                    "hide-label": ""
                }
            }, [n("v-color-picker", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: t.shouldAppendedColorPickerShown,
                    expression: "shouldAppendedColorPickerShown"
                }],
                attrs: {
                    "syno-id": "syno-cp-lp-lse-bg-appended-color",
                    disabled: !t.profile.enable_background_customize
                },
                on: {
                    showcustom: function(e) {
                        return t.showCustomColorPanel()
                    }
                },
                model: {
                    value: t.profile.background_color,
                    callback: function(e) {
                        t.$set(t.profile, "background_color", e)
                    },
                    expression: "profile.background_color"
                }
            })], 1)], 1), t._v(" "), n("v-form-item", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: !1,
                    expression: "false"
                }],
                attrs: {
                    "syno-id": "syno-form-item-lp-lse-bg-type",
                    prop: "p-item-lp-lse-bg-type"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "syno-input-lp-lse-bg-type",
                    name: "p-item-lp-lse-bg-type"
                },
                model: {
                    value: t.profile.background_type,
                    callback: function(e) {
                        t.$set(t.profile, "background_type", e)
                    },
                    expression: "profile.background_type"
                }
            })], 1), t._v(" "), n("v-form-item", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: !1,
                    expression: "false"
                }],
                attrs: {
                    "syno-id": "syno-form-item-lp-lse-bg-path",
                    prop: "p-item-lp-lse-bg-path"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "syno-input-lp-lse-bg-type",
                    name: "p-item-lp-lse-bg-path"
                },
                model: {
                    value: t.profile.background_path,
                    callback: function(e) {
                        t.$set(t.profile, "background_path", e)
                    },
                    expression: "profile.background_path"
                }
            })], 1)]], 2)], 1)]), t._v(" "), t.isCustomColorPanelShown ? n("v-modal-window", t._b({
                ref: "customColorWindow",
                attrs: {
                    "syno-id": "login-style-editor-v-form-custom-backgroud-modal-window-0",
                    inline: ""
                }
            }, "v-modal-window", t.colorWindowConfig, !1), [n("v-color-custom-panel", {
                attrs: {
                    "syno-id": "login-style-editor-v-form-custom-backgroud-color-custom-panel-0",
                    initial: t.profile.background_color
                },
                on: {
                    colorselected: t.onColorChange,
                    colorselectcanceled: function(e) {
                        return t.closeCustomColorPanel()
                    }
                }
            })], 1) : t._e()], 1)
        }, [], !1, null, "69bbb4c7", null).exports),
        ye = {
            mixins: [it],
            props: {
                applicationId: {
                    type: String,
                    required: !0
                },
                profile: {
                    type: Object,
                    required: !0
                }
            },
            computed: {
                logoSrc: function() {
                    if (this.tmpLogoSrc) return this.tmpLogoSrc;
                    var t = {
                        api: "SYNO.Core.Theme.Image",
                        version: 1,
                        method: "get",
                        params: {
                            type: "login_logo"
                        }
                    };
                    return "dsm" === this.applicationId && this.profile.logo_seq && (t.params.seq = this.profile.logo_seq), "dsm" !== this.applicationId && this.profile.login_logo_seq && (t.params.seq = this.profile.login_logo_seq, t.params.app = this.applicationId), t.params.seq ? "".concat(SYNO.API.GetBaseURL(t), "&_v=").concat(Date.now()) : null
                }
            },
            data: function() {
                return {
                    tmpLogoSrc: null
                }
            },
            methods: {
                openImageSelector: function() {
                    var t = this,
                        e = new SYNO.SDS.Utils.ImageSelector({
                            owner: this.$appWindow
                        }, "login", "logo");
                    e.mon(e, "choose", function(n) {
                        if (n) {
                            t.tmpLogoSrc = n.get("url");
                            var r = n.get("apply_type");
                            t.profile.logo_type = r, t.profile.logo_path = "fromDS" === r ? n.get("path") : n.get("path").split("/").pop(), e.close()
                        }
                    }), this.$window.openExtWindow(e)
                }
            }
        };
    n(35);

    function be(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }
    var we = {
            components: {
                VFormCustomBackgroud: ge,
                VFormCustomLogo: d(ye, function() {
                    var t = this,
                        e = t.$createElement,
                        n = t._self._c || e;
                    return n("div", [n("v-form-item", {
                        staticClass: "custom-logo__checkbox",
                        attrs: {
                            "syno-id": "syno-form-item-lp-lse-enable-logo",
                            "hide-label": "",
                            prop: "p-lp-lse-enable-logo"
                        }
                    }, [n("v-checkbox", {
                        attrs: {
                            "syno-id": "syno-checkbox-lp-lse-enable-logo",
                            name: "p-lp-lse-enable-logo"
                        },
                        model: {
                            value: t.profile.enable_logo_customize,
                            callback: function(e) {
                                t.$set(t.profile, "enable_logo_customize", e)
                            },
                            expression: "profile.enable_logo_customize"
                        }
                    }, [t._v("\n      " + t._s(t.$i18n("dsmoption", "login_logo")) + "\n    ")])], 1), t._v(" "), n("v-form-item", {
                        staticClass: "lp-login-style-editor__form-item--last",
                        attrs: {
                            "syno-id": "syno-form-item-lp-lse-logo",
                            "hide-label": "",
                            indent: "1"
                        }
                    }, [n("div", {
                        staticClass: "custom-logo__preview-and-select"
                    }, [n("div", {
                        class: {
                            "custom-logo__preview-logo": !0, "custom-logo__preview-logo--disabled": !t.profile.enable_logo_customize
                        },
                        style: {
                            backgroundImage: t.logoSrc ? "url('" + t.logoSrc + "')" : null
                        }
                    }), t._v(" "), n("v-form-item", {
                        attrs: {
                            "syno-id": "syno-form-item-lp-lse-selector",
                            "hide-label": ""
                        }
                    }, [n("v-button", {
                        attrs: {
                            "syno-id": "syno-btn-lp-lse-selector",
                            disabled: !t.profile.enable_logo_customize
                        },
                        on: {
                            click: function(e) {
                                return t.openImageSelector()
                            }
                        }
                    }, [t._v("\n          " + t._s(t.$i18n("personal_settings", "select_image")) + "\n        ")])], 1)], 1)]), t._v(" "), n("v-form-item", {
                        directives: [{
                            name: "show",
                            rawName: "v-show",
                            value: !1,
                            expression: "false"
                        }],
                        attrs: {
                            "syno-id": "syno-form-item-lp-lse-logo-src",
                            prop: "_"
                        }
                    }, [n("v-input", {
                        attrs: {
                            "syno-id": "syno-input-item-lp-lse-logo-src",
                            name: "_"
                        },
                        model: {
                            value: t.logoSrc,
                            callback: function(e) {
                                t.logoSrc = e
                            },
                            expression: "logoSrc"
                        }
                    })], 1)], 1)
                }, [], !1, null, "7405e2cf", null).exports
            },
            mixins: [it, pt, ct],
            props: {
                applicationId: {
                    type: String,
                    required: !0
                }
            },
            mounted: function() {
                this.fetchData()
            },
            computed: {
                isProfileEmpty: function() {
                    return 0 === Object.keys(this.profile).length
                },
                isRetina: function() {
                    return SYNO.SDS.UIFeatures.IconSizeManager.isRetinaMode()
                },
                resolution: function() {
                    return this.isRetina ? "2x" : "1x"
                },
                origin: function() {
                    var t = window.location.origin;
                    return t || (t = "".concat(window.location.protocol, "//").concat(window.location.hostname).concat(window.location.port ? ":" + window.location.port : "")), t
                }
            },
            data: function() {
                return {
                    dataProperty: "profile",
                    profile: {}
                }
            },
            methods: {
                fetchData: function() {
                    var t, e = (t = regeneratorRuntime.mark(function t() {
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.next = 2, b(this.applicationId);
                                case 2:
                                    return this.profile = t.sent, t.next = 5, this.$nextTick();
                                case 5:
                                    this.$refs.form.commit();
                                case 6:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }), function() {
                        var e = this,
                            n = arguments;
                        return new Promise(function(r, o) {
                            var i = t.apply(e, n);

                            function a(t) {
                                be(i, r, o, a, s, "next", t)
                            }

                            function s(t) {
                                be(i, r, o, a, s, "throw", t)
                            }
                            a(void 0)
                        })
                    });
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                openPreviewTab: function() {
                    var t = this,
                        e = this.getPreviewUrl(),
                        n = this.getPreviewParam(),
                        r = this.registerMessageEvent(function(e) {
                            e && e.data && e.data.origin === t.origin && ("save" === e.data.action && t.onApply(), delete window.previewParam, r())
                        });
                    window.previewParam = n;
                    window.open(e, "preview_login_style")
                },
                getPreviewUrl: function() {
                    this.updateAppWindow();
                    var t = this.$appWindow.getDsmHost(),
                        e = this.$appWindow.getDsmHttpPort(),
                        n = t && e ? "http://".concat(t, ":").concat(e, "/webman") : "",
                        r = Ext.urlEncode({
                            preview: !0,
                            app_name: this.applicationId || ""
                        });
                    return Ext.urlAppend("".concat(n, "/index.cgi"), r)
                },
                getPreviewParam: function() {
                    if (!this.$refs.form.isDirty()) return null;
                    var t = "dsm" === this.applicationId ? !!(this.profile.logo_path || this.profile.logo_seq > 0) : !!(this.profile.logo_path || this.profile.login_logo_seq > -1),
                        e = "dsm" === this.applicationId ? !!(this.profile.background_path || this.profile.background_seq > 0) : !!(this.profile.background_path || this.profile.login_background_seq > -1);
                    return {
                        preview_modified: !Ext.isIE9m,
                        new_logo: !!this.profile.logo_path,
                        login_logo_enable: this.profile.enable_logo_customize && t,
                        login_logo_path: this.getImageFullPath(this.profile.logo_type, this.profile.logo_path),
                        login_logo_ext: (this.profile.logo_path || "").split(".").pop(),
                        logo_type: this.profile.logo_type,
                        new_background: !!this.profile.background_path,
                        login_background_enable: this.profile.enable_background_customize && e,
                        login_background_path: this.getImageFullPath(this.profile.background_type, this.profile.background_path),
                        login_background_ext: (this.profile.background_path || "").split(".").pop(),
                        login_background_type: this.profile.background_type,
                        login_background_pos: this.profile.background_position,
                        login_background_color: this.profile.background_color,
                        login_only_bgcolor: this.profile.only_background_color,
                        custom_login_title: this.profile.login_title,
                        login_welcome_title: this.profile.login_welcome_title,
                        login_welcome_msg: this.profile.login_welcome_msg,
                        login_footer_msg: this.profile.login_footer_msg,
                        login_footer_enable_html: this.profile.login_footer_enable_html
                    }
                },
                getImageFullPath: function(t) {
                    var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "",
                        n = e;
                    return "history" === t && (n = "/usr/syno/etc/login_image/".concat(e)), "default" === t && (n = "/usr/syno/synoman/webman/resources/images/".concat(this.resolution, "/default_login_background/").concat(e)), "pkgDefault" === t && (n = String.format(e, this.resolution, e)), n
                },
                registerMessageEvent: function(t) {
                    return !Ext.isIE9m && window.addEventListener && window.removeEventListener ? (window.addEventListener("message", t), function() {
                        return window.removeEventListener("message", t)
                    }) : function() {}
                }
            }
        },
        xe = (n(36), d(we, function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-panel", {
                staticClass: "lp-login-style-editor__panel",
                attrs: {
                    "syno-id": "syno-panel-lp-lse",
                    "fluid-footer": "",
                    loading: t.spinner.isLoading,
                    "loading-type": t.spinner.loadingType,
                    "show-status-bar": t.spinner.showStatusBar,
                    "status-bar-state": t.spinner.statusBarState,
                    "error-text": t.spinner.errorText
                },
                on: {
                    "update:showStatusBar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    },
                    "update:show-status-bar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    }
                },
                scopedSlots: t._u([{
                    key: "body",
                    fn: function() {
                        return [n("v-perfect-scrollbar", [n("div", {
                            staticClass: "lp-modal-content"
                        }, [n("v-form", {
                            ref: "form",
                            attrs: {
                                "syno-id": "syno-form-lp-lse"
                            }
                        }, [n("v-fieldset", {
                            staticClass: "lp-login-style-editor__fieldset--first",
                            attrs: {
                                "syno-id": "syno-fieldset-lp-lse-title",
                                title: t.$i18n("dsmoption", "login_title_background")
                            }
                        }, [n("v-form-item", {
                            staticClass: "lp-login-style-editor__login-title lp-login-style-editor__form-item",
                            attrs: {
                                "syno-id": "syno-form-item-lp-lse-title",
                                prop: "p-lp-lse-title",
                                label: t._f("colon")(t.$i18n("dsmsetting", "login_title"))
                            }
                        }, [n("v-input", {
                            attrs: {
                                "syno-id": "syno-input-lp-lse-title",
                                name: "p-lp-lse-title"
                            },
                            model: {
                                value: t.profile.login_title,
                                callback: function(e) {
                                    t.$set(t.profile, "login_title", e)
                                },
                                expression: "profile.login_title"
                            }
                        })], 1), t._v(" "), t.isProfileEmpty ? t._e() : n("v-form-custom-backgroud", {
                            attrs: {
                                "application-id": t.applicationId,
                                profile: t.profile
                            }
                        }), t._v(" "), t.isProfileEmpty ? t._e() : n("v-form-custom-logo", {
                            attrs: {
                                "application-id": t.applicationId,
                                profile: t.profile
                            }
                        })], 1), t._v(" "), n("v-fieldset", {
                            attrs: {
                                "syno-id": "syno-fieldset-lp-lse-msg",
                                title: t.$i18n("dsmoption", "login_style_messages")
                            }
                        }, [n("v-form-item", {
                            attrs: {
                                "syno-id": "syno-form-item-lp-lse-msg-desc",
                                "hide-label": "",
                                textonly: ""
                            }
                        }, [t._v("\n              " + t._s(t.$i18n("dsmoption", "login_style_messages_desc")) + "\n            ")]), t._v(" "), n("v-form-item", {
                            staticClass: "lp-login-style-editor__form-item",
                            attrs: {
                                "syno-id": "syno-form-item-lp-lse-msg-title",
                                label: t._f("colon")(t.$i18n("dsmsetting", "welcome_title")),
                                prop: "p-lp-lse-msg-title"
                            }
                        }, [n("v-input", {
                            attrs: {
                                "syno-id": "syno-input-lp-lse-msg-title",
                                name: "p-lp-lse-msg-title",
                                maxlength: 127
                            },
                            model: {
                                value: t.profile.login_welcome_title,
                                callback: function(e) {
                                    t.$set(t.profile, "login_welcome_title", e)
                                },
                                expression: "profile.login_welcome_title"
                            }
                        })], 1), t._v(" "), n("v-form-item", {
                            staticClass: "lp-login-style-editor__form-item lp-login-style-editor__form-item--textarea",
                            attrs: {
                                "syno-id": "syno-form-item-lp-lse-msg-msg",
                                label: t._f("colon")(t.$i18n("dsmsetting", "welcome_msg")),
                                prop: "p-lp-lse-msg-msg"
                            }
                        }, [n("v-input", {
                            attrs: {
                                "syno-id": "syno-input-lp-lse-msg-msg",
                                type: "textarea",
                                name: "p-lp-lse-msg-msg",
                                maxlength: 255
                            },
                            model: {
                                value: t.profile.login_welcome_msg,
                                callback: function(e) {
                                    t.$set(t.profile, "login_welcome_msg", e)
                                },
                                expression: "profile.login_welcome_msg"
                            }
                        })], 1), t._v(" "), n("v-form-item", {
                            staticClass: "lp-login-style-editor__form-item lp-login-style-editor__form-item--textarea",
                            attrs: {
                                "syno-id": "syno-form-item-lp-lse-msg-footer",
                                label: t._f("colon")(t.$i18n("dsmsetting", "footer_msg")),
                                prop: "p-lp-lse-msg-footer"
                            }
                        }, [n("v-input", {
                            attrs: {
                                "syno-id": "syno-input-lp-lse-msg-msg-footer",
                                type: "textarea",
                                name: "p-lp-lse-msg-footer",
                                maxlength: 512
                            },
                            model: {
                                value: t.profile.login_footer_msg,
                                callback: function(e) {
                                    t.$set(t.profile, "login_footer_msg", e)
                                },
                                expression: "profile.login_footer_msg"
                            }
                        })], 1), t._v(" "), n("v-form-item", {
                            staticClass: "lp-login-style-editor__form-item lp-login-style-editor__form-item--last-in-fieldset",
                            attrs: {
                                "syno-id": "syno-form-item-lp-lse-msg-footer-html",
                                prop: "p-lp-lse-msg-footer-html"
                            }
                        }, [n("v-checkbox", {
                            attrs: {
                                "syno-id": "syno-checkbox-lp-lse-msg-footer-html",
                                name: "p-lp-lse-msg-footer-html"
                            },
                            model: {
                                value: t.profile.login_footer_enable_html,
                                callback: function(e) {
                                    t.$set(t.profile, "login_footer_enable_html", e)
                                },
                                expression: "profile.login_footer_enable_html"
                            }
                        }, [t._v("\n                " + t._s(t.$i18n("dsmsetting", "footer_enable_html")) + "\n              ")])], 1)], 1)], 1)], 1)])]
                    },
                    proxy: !0
                }, {
                    key: "fbar",
                    fn: function() {
                        return [n("div", {
                            staticClass: "default pull-right"
                        }, [n("v-button", {
                            attrs: {
                                "syno-id": "syno-btn-fbar-preview",
                                type: "footbar"
                            },
                            on: {
                                click: function(e) {
                                    return t.openPreviewTab()
                                }
                            }
                        }, [t._v("\n          " + t._s(t.$i18n("dsmoption", "login_preview")) + "\n        ")]), t._v(" "), n("v-button", {
                            attrs: {
                                "syno-id": "syno-btn-fbar-cancel",
                                type: "footbar"
                            },
                            on: {
                                click: function(e) {
                                    return t.onCancel()
                                }
                            }
                        }, [t._v("\n          " + t._s(t.$i18n("common", "cancel")) + "\n        ")]), t._v(" "), n("v-button", {
                            attrs: {
                                "syno-id": "syno-btn-fbar-commit",
                                type: "footbar",
                                suffix: "blue"
                            },
                            on: {
                                click: function(e) {
                                    return t.onApply()
                                }
                            }
                        }, [t._v("\n          " + t._s(t.$i18n("common", "save")) + "\n        ")])], 1)]
                    },
                    proxy: !0
                }])
            })
        }, [], !1, null, null, null));

    function ke(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }
    var Se = d({
        components: {
            LoginStyleEditor: xe.exports
        },
        mixins: [it],
        data: function() {
            return {
                applicationId: null,
                applicationDisplayName: ""
            }
        },
        computed: {
            title: function() {
                return "dsm" === this.applicationId ? this.$i18n("dsmoption", "loginstyle_editor_header") : this.$i18n("controlpanel", "edit_application_login_style").replace("{0}", this.applicationDisplayName)
            }
        },
        methods: {
            onApply: function() {
                var t, e = (t = regeneratorRuntime.mark(function t(e, n, r) {
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.prev = 0, t.next = 3, x(this.applicationId, e);
                            case 3:
                                n(), this.close(), t.next = 10;
                                break;
                            case 7:
                                t.prev = 7, t.t0 = t.catch(0), r(t.t0);
                            case 10:
                            case "end":
                                return t.stop()
                        }
                    }, t, this, [
                        [0, 7]
                    ])
                }), function() {
                    var e = this,
                        n = arguments;
                    return new Promise(function(r, o) {
                        var i = t.apply(e, n);

                        function a(t) {
                            ke(i, r, o, a, s, "next", t)
                        }

                        function s(t) {
                            ke(i, r, o, a, s, "throw", t)
                        }
                        a(void 0)
                    })
                });
                return function(t, n, r) {
                    return e.apply(this, arguments)
                }
            }()
        }
    }, function() {
        var t = this,
            e = t.$createElement,
            n = t._self._c || e;
        return n("v-modal-window", {
            staticClass: "admin-center__login-portal",
            attrs: {
                "syno-id": "syno-lp-modal-login-style-editor",
                height: 520,
                width: 620,
                title: t.title,
                "before-close": function() {
                    return t.$refs.editor.beforeClose()
                }
            }
        }, [n("div", {
            staticClass: "lp-modal-content-wrapper"
        }, [t.applicationId ? n("login-style-editor", {
            ref: "editor",
            attrs: {
                applicationId: t.applicationId
            },
            on: {
                apply: t.onApply,
                cancel: function(e) {
                    return t.close()
                }
            }
        }) : t._e()], 1)])
    }, [], !1, null, null, null).exports;

    function $e(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }

    function Ce(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise(function(r, o) {
                var i = t.apply(e, n);

                function a(t) {
                    $e(i, r, o, a, s, "next", t)
                }

                function s(t) {
                    $e(i, r, o, a, s, "throw", t)
                }
                a(void 0)
            })
        }
    }

    function Pe(t, e) {
        return function(t) {
            if (Array.isArray(t)) return t
        }(t) || function(t, e) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(t))) return;
            var n = [],
                r = !0,
                o = !1,
                i = void 0;
            try {
                for (var a, s = t[Symbol.iterator](); !(r = (a = s.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
            } catch (t) {
                o = !0, i = t
            } finally {
                try {
                    r || null == s.return || s.return()
                } finally {
                    if (o) throw i
                }
            }
            return n
        }(t, e) || function(t, e) {
            if (!t) return;
            if ("string" == typeof t) return Re(t, e);
            var n = Object.prototype.toString.call(t).slice(8, -1);
            "Object" === n && t.constructor && (n = t.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(n);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Re(t, e)
        }(t, e) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function Re(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
        return r
    }
    var Ae = {
            filters: {
                renderFontendOrBackend: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                        e = "UNKNOWN";
                    switch (t.protocol) {
                        case 0:
                            e = "http";
                            break;
                        case 1:
                            e = "https";
                            break;
                        default:
                            e = "UNKOWN"
                    }
                    var n = t.fqdn || "*",
                        r = [
                            [0, 80],
                            [1, 443]
                        ].some(function(e) {
                            var n = Pe(e, 2),
                                r = n[0],
                                o = n[1];
                            return !(t.protocol === r && t.port === o)
                        }) ? ":".concat(t.port) : "";
                    return "".concat(e, "://").concat(n).concat(r)
                }
            },
            mixins: [it, pt],
            data: function() {
                return {
                    data: [],
                    selectedRows: []
                }
            },
            computed: {
                singleSelectedRow: function() {
                    return 1 === this.selectedRows.length && this.selectedRows[0]
                },
                isEditActionActive: function() {
                    return !!this.singleSelectedRow
                },
                isDeleteActionActive: function() {
                    return this.selectedRows.length > 0
                },
                columns: function() {
                    return [{
                        title: this.$i18n("app_port_alias", "description"),
                        field: "description"
                    }, {
                        title: this.$i18n("app_port_alias", "source"),
                        field: "frontend"
                    }, {
                        title: this.$i18n("app_port_alias", "destination"),
                        field: "backend"
                    }]
                }
            },
            mounted: function() {
                this.load()
            },
            methods: {
                load: function() {
                    var t = Ce(regeneratorRuntime.mark(function t() {
                        var e;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return this.onLoading(), t.next = 3, D();
                                case 3:
                                    e = t.sent, this.data = e && e.entries || [], this.onDone();
                                case 6:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                openCreateDialog: function() {
                    var t = this;
                    this.updateAppWindow(), this.$window.openWindow(SYNO.SDS.AdminCenter.LoginPortal.Dialogs.CreateReverseProxy_vue).window.$on("close", function() {
                        return t.load()
                    })
                },
                openEditDialog: function() {
                    var t = this;
                    this.isEditActionActive && (this.updateAppWindow(), this.$window.openWindow(SYNO.SDS.AdminCenter.LoginPortal.Dialogs.UpdateReverseProxy_vue, {
                        profile: this.singleSelectedRow
                    }).window.$on("close", function() {
                        return t.load()
                    }))
                },
                deleteReverseProxies: function() {
                    var t = Ce(regeneratorRuntime.mark(function t() {
                        var e;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    if (this.isDeleteActionActive) {
                                        t.next = 2;
                                        break
                                    }
                                    return t.abrupt("return");
                                case 2:
                                    return t.next = 4, this.$window.getMsgBox().confirmDelete("", this.$i18n("app_port_alias", "confirm_delete_proxy"));
                                case 4:
                                    if ("confirm" === t.sent) {
                                        t.next = 7;
                                        break
                                    }
                                    return t.abrupt("return");
                                case 7:
                                    return t.prev = 7, this.onLoading(), e = this.selectedRows.map(function(t) {
                                        return t.UUID
                                    }), t.next = 12, L(e);
                                case 12:
                                    this.load(), this.onDone(), t.next = 19;
                                    break;
                                case 16:
                                    t.prev = 16, t.t0 = t.catch(7), this.onError(t.t0);
                                case 19:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this, [
                            [7, 16]
                        ])
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }
        },
        Oe = (n(37), {
            components: {
                ReverseProxy: d(Ae, function() {
                    var t = this,
                        e = t.$createElement,
                        n = t._self._c || e;
                    return n("v-panel", {
                        staticClass: "lp-reverse-proxy-component__panel",
                        attrs: {
                            "fluid-footer": "",
                            "syno-id": "syno-panel-reverse-proxy",
                            "has-tbar": 0 !== t.data.length,
                            loading: t.spinner.isLoading,
                            "loading-type": t.spinner.loadingType,
                            "show-status-bar": t.spinner.showStatusBar,
                            "status-bar-state": t.spinner.statusBarState
                        },
                        on: {
                            "update:showStatusBar": function(e) {
                                return t.$set(t.spinner, "showStatusBar", e)
                            },
                            "update:show-status-bar": function(e) {
                                return t.$set(t.spinner, "showStatusBar", e)
                            }
                        },
                        scopedSlots: t._u([{
                            key: "tbar",
                            fn: function() {
                                return [n("div", {
                                    staticClass: "lp-modal-content"
                                }, [n("v-button", {
                                    attrs: {
                                        "syno-id": "syno-btn-reverse-proxy-create"
                                    },
                                    on: {
                                        click: function(e) {
                                            return t.openCreateDialog()
                                        }
                                    }
                                }, [t._v("\n        " + t._s(t.$i18n("common", "create")) + "\n      ")]), t._v(" "), n("v-button", {
                                    attrs: {
                                        "syno-id": "syno-btn-reverse-proxy-edit",
                                        disabled: !t.isEditActionActive
                                    },
                                    on: {
                                        click: function(e) {
                                            return t.openEditDialog()
                                        }
                                    }
                                }, [t._v("\n        " + t._s(t.$i18n("common", "alt_edit")) + "\n      ")]), t._v(" "), n("v-button", {
                                    attrs: {
                                        "syno-id": "syno-btn-reverse-proxy-delete",
                                        disabled: !t.isDeleteActionActive
                                    },
                                    on: {
                                        click: function(e) {
                                            return t.deleteReverseProxies()
                                        }
                                    }
                                }, [t._v("\n        " + t._s(t.$i18n("common", "delete")) + "\n      ")])], 1)]
                            },
                            proxy: !0
                        }, {
                            key: "body",
                            fn: function() {
                                return [0 !== t.data.length ? n("div", {
                                    staticClass: "lp-modal-content lp-modal-content--no-top-padding"
                                }, [n("v-data-table", {
                                    staticClass: "lp-reverse-proxy-component__data-table",
                                    attrs: {
                                        "multiple-selected": "",
                                        "syno-id": "syno-table-reverse-proxy",
                                        columns: t.columns,
                                        "current-data": t.data
                                    },
                                    on: {
                                        refresh: function(e) {
                                            return t.load()
                                        },
                                        rowclick: function(e) {
                                            t.selectedRows = e.rows
                                        },
                                        rowdblclick: function(e) {
                                            return t.openEditDialog()
                                        }
                                    },
                                    scopedSlots: t._u([{
                                        key: "frontend",
                                        fn: function(e) {
                                            var n = e.data;
                                            return [t._v("\n          " + t._s(t._f("renderFontendOrBackend")(n)) + "\n        ")]
                                        }
                                    }, {
                                        key: "backend",
                                        fn: function(e) {
                                            var n = e.data;
                                            return [t._v("\n          " + t._s(t._f("renderFontendOrBackend")(n)) + "\n        ")]
                                        }
                                    }], null, !1, 2723677059)
                                })], 1) : n("v-empty-view", {
                                    attrs: {
                                        "syno-id": "syno-empty-view-reverse-proxy"
                                    },
                                    on: {
                                        "action-click": function(e) {
                                            return t.openCreateDialog()
                                        }
                                    }
                                })]
                            },
                            proxy: !0
                        }, {
                            key: "fbar",
                            fn: function() {
                                return [n("div", {
                                    staticClass: "default pull-right"
                                }, [n("v-button", {
                                    attrs: {
                                        "syno-id": "reverse-proxy-index-button-0",
                                        type: "footbar"
                                    },
                                    on: {
                                        click: function(e) {
                                            return t.onCancel()
                                        }
                                    }
                                }, [t._v("\n        " + t._s(t.$i18n("common", "close")) + "\n      ")])], 1)]
                            },
                            proxy: !0
                        }])
                    })
                }, [], !1, null, null, null).exports
            },
            mixins: [it]
        }),
        Ie = (n(38), d(Oe, function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-modal-window", {
                attrs: {
                    "syno-id": "syno-modal-reverse-proxy",
                    height: 450,
                    width: 680,
                    title: t.$i18n("app_port_alias", "title_reverse_proxy")
                }
            }, [n("div", {
                staticClass: "lp-modal-content-wrapper"
            }, [n("reverse-proxy", {
                on: {
                    apply: function(e) {
                        return t.close()
                    },
                    cancel: function(e) {
                        return t.close()
                    }
                }
            })], 1)])
        }, [], !1, null, null, null).exports);

    function De(t) {
        return function(t) {
            if (Array.isArray(t)) return qe(t)
        }(t) || function(t) {
            if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) return Array.from(t)
        }(t) || function(t, e) {
            if (!t) return;
            if ("string" == typeof t) return qe(t, e);
            var n = Object.prototype.toString.call(t).slice(8, -1);
            "Object" === n && t.constructor && (n = t.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(n);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return qe(t, e)
        }(t) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function qe(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
        return r
    }

    function Ee(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }

    function Te(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise(function(r, o) {
                var i = t.apply(e, n);

                function a(t) {
                    Ee(i, r, o, a, s, "next", t)
                }

                function s(t) {
                    Ee(i, r, o, a, s, "throw", t)
                }
                a(void 0)
            })
        }
    }
    var Ne = {
        props: {
            profile: {
                type: String,
                required: !0
            },
            errors: {
                type: Object,
                required: !0
            },
            isDirty: {
                type: Function,
                default: function() {
                    return !1
                }
            },
            validate: {
                type: Function,
                default: function() {
                    return !0
                }
            }
        },
        created: function() {
            this.fqdnValidator = new Mt, this.portValidator = new At
        },
        computed: {
            reverseProxyFrontendFqdnRules: function() {
                var t = this;
                return [Ht(this.errors.frontendFqdn), Ft("FQDN2"), {
                    asyncValidator: function() {
                        var e = Te(regeneratorRuntime.mark(function e() {
                            return regeneratorRuntime.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, t.fqdnValidator.validateFrontendReverseProxy(t.profile);
                                    case 2:
                                    case "end":
                                        return e.stop()
                                }
                            }, e, this)
                        }));
                        return function() {
                            return e.apply(this, arguments)
                        }
                    }()
                }]
            },
            reverseProxyFrontendPortRules: function() {
                var t = this;
                return [Ht(this.errors.frontendPort), Ft("port"), {
                    asyncValidator: function() {
                        var e = Te(regeneratorRuntime.mark(function e() {
                            return regeneratorRuntime.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, t.portValidator.validateFrontendPort(t.profile);
                                    case 2:
                                    case "end":
                                        return e.stop()
                                }
                            }, e, this)
                        }));
                        return function() {
                            return e.apply(this, arguments)
                        }
                    }()
                }]
            },
            reverseProxyBackendFqdnRules: function() {
                return [Ht(this.errors.backendFqdn), Ft("FQDN3")]
            },
            reverseProxyBackendPortRules: function() {
                var t = this;
                return [Ft("port"), {
                    asyncValidator: function() {
                        var e = Te(regeneratorRuntime.mark(function e() {
                            return regeneratorRuntime.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        return e.next = 2, t.portValidator.validateBackendPort(t.profile);
                                    case 2:
                                    case "end":
                                        return e.stop()
                                }
                            }, e, this)
                        }));
                        return function() {
                            return e.apply(this, arguments)
                        }
                    }()
                }]
            },
            reverseProxyTimeoutRules: function() {
                var t = this;
                return [{
                    asyncValidator: function() {
                        var e = Te(regeneratorRuntime.mark(function e(n, r) {
                            return regeneratorRuntime.wrap(function(e) {
                                for (;;) switch (e.prev = e.next) {
                                    case 0:
                                        if (1 <= r && r <= 86400) {
                                            e.next = 2;
                                            break
                                        }
                                        throw t.$i18n("app_port_alias", "err_proxy_timeout");
                                    case 2:
                                        return e.abrupt("return");
                                    case 3:
                                    case "end":
                                        return e.stop()
                                }
                            }, e, this)
                        }));
                        return function(t, n) {
                            return e.apply(this, arguments)
                        }
                    }()
                }]
            },
            reverseProxyConnectTimeoutRules: function() {
                return [Ht(this.errors.proxyConnectTimeout)].concat(De(this.reverseProxyTimeoutRules))
            },
            reverseProxySendTimeoutRules: function() {
                return [Ht(this.errors.proxySendTimeout)].concat(De(this.reverseProxyTimeoutRules))
            },
            reverseProxyReadTimeoutRules: function() {
                return [Ht(this.errors.proxyReadTimeout)].concat(De(this.reverseProxyTimeoutRules))
            }
        },
        methods: {
            _onLoading: function() {
                this.errors.frontendFqdn = "", this.errors.frontendPort = "", this.errors.backendFqdn = "", this.errors.customHeaderNameIndex = -1, this.errors.customHeaderName = "", this.errors.customHeaderValueIndex = -1, this.errors.customHeaderValue = "", this.errors.proxyConnectTimeout = "", this.errors.proxyReadTimeout = "", this.errors.proxySendTimeout = "", this.$nextTick()
            },
            _onError: function(t) {
                if (t && t.code) {
                    switch (t.code) {
                        case 4154:
                            this.errors.frontendFqdn = SYNO.API.getErrorString(t);
                            break;
                        case 4155:
                            this.errors.frontendPort = SYNO.API.getErrorString(t);
                            break;
                        case 4156:
                            this.errors.backendFqdn = SYNO.API.getErrorString(t);
                            break;
                        case 4164:
                        case 4166:
                            this.errors.customHeaderNameIndex = t.errors.index[0], this.errors.customHeaderName = SYNO.API.getErrorString(t);
                            break;
                        case 4165:
                            this.errors.customHeaderValueIndex = t.errors.index[0], this.errors.customHeaderValue = SYNO.API.getErrorString(t);
                            break;
                        case 4168:
                            this.errors.proxyConnectTimeout = SYNO.API.getErrorString(t);
                            break;
                        case 4169:
                            this.errors.proxyReadTimeout = SYNO.API.getErrorString(t);
                            break;
                        case 4170:
                            this.errors.proxySendTimeout = SYNO.API.getErrorString(t)
                    }
                    this.validate()
                }
            },
            generateReverseProxyCustomizedHeaderNameRules: function(t) {
                var e = this;
                return [{
                    asyncValidator: function() {
                        var n = Te(regeneratorRuntime.mark(function n() {
                            return regeneratorRuntime.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                    case 0:
                                        if (t !== e.errors.customHeaderNameIndex) {
                                            n.next = 2;
                                            break
                                        }
                                        throw e.errors.customHeaderName;
                                    case 2:
                                        return n.abrupt("return");
                                    case 3:
                                    case "end":
                                        return n.stop()
                                }
                            }, n, this)
                        }));
                        return function() {
                            return n.apply(this, arguments)
                        }
                    }()
                }, {
                    asyncValidator: function() {
                        var t = Te(regeneratorRuntime.mark(function t(n, r) {
                            return regeneratorRuntime.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        if (/^([a-zA-Z1-9]|-){1,}$/i.exec(r)) {
                                            t.next = 3;
                                            break
                                        }
                                        throw e.$i18n("app_port_alias", "err_invalid_header_name");
                                    case 3:
                                        return t.abrupt("return");
                                    case 4:
                                    case "end":
                                        return t.stop()
                                }
                            }, t, this)
                        }));
                        return function(e, n) {
                            return t.apply(this, arguments)
                        }
                    }()
                }, {
                    asyncValidator: function() {
                        var t = Te(regeneratorRuntime.mark(function t(n, r) {
                            return regeneratorRuntime.wrap(function(t) {
                                for (;;) switch (t.prev = t.next) {
                                    case 0:
                                        if (!(e.profile.customize_headers.filter(function(t) {
                                                return t.name.toUpperCase() === r.toUpperCase()
                                            }).length > 1)) {
                                            t.next = 3;
                                            break
                                        }
                                        throw e.$i18n("app_port_alias", "err_header_name_duplicated");
                                    case 3:
                                        return t.abrupt("return");
                                    case 4:
                                    case "end":
                                        return t.stop()
                                }
                            }, t, this)
                        }));
                        return function(e, n) {
                            return t.apply(this, arguments)
                        }
                    }()
                }]
            },
            generateReverseProxyCustomizedHeaderValueRules: function(t) {
                var e = this;
                return [{
                    asyncValidator: function() {
                        var n = Te(regeneratorRuntime.mark(function n(r, o) {
                            return regeneratorRuntime.wrap(function(n) {
                                for (;;) switch (n.prev = n.next) {
                                    case 0:
                                        if (o) {
                                            n.next = 2;
                                            break
                                        }
                                        throw e.$i18n("app_port_alias", "err_invalid_header_value");
                                    case 2:
                                        if (t !== e.errors.customHeaderValueIndex) {
                                            n.next = 4;
                                            break
                                        }
                                        throw e.errors.customHeaderValue;
                                    case 4:
                                        return n.abrupt("return");
                                    case 5:
                                    case "end":
                                        return n.stop()
                                }
                            }, n, this)
                        }));
                        return function(t, e) {
                            return n.apply(this, arguments)
                        }
                    }()
                }]
            }
        }
    };

    function Be(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }

    function Le(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise(function(r, o) {
                var i = t.apply(e, n);

                function a(t) {
                    Be(i, r, o, a, s, "next", t)
                }

                function s(t) {
                    Be(i, r, o, a, s, "throw", t)
                }
                a(void 0)
            })
        }
    }

    function je(t) {
        return function(t) {
            if (Array.isArray(t)) return Ye(t)
        }(t) || function(t) {
            if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) return Array.from(t)
        }(t) || function(t, e) {
            if (!t) return;
            if ("string" == typeof t) return Ye(t, e);
            var n = Object.prototype.toString.call(t).slice(8, -1);
            "Object" === n && t.constructor && (n = t.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(n);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Ye(t, e)
        }(t) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function Ye(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
        return r
    }
    var He = {
            mixins: [pt, Ne],
            props: {
                profile: {
                    type: Object,
                    required: !0
                },
                isDirty: {
                    type: Function,
                    required: !0
                },
                commit: {
                    type: Function,
                    required: !0
                },
                validate: {
                    type: Function,
                    required: !0
                }
            },
            data: function() {
                return {
                    dataProperty: "profile",
                    aclProfiles: []
                }
            },
            computed: {
                aclOptions: function() {
                    return [{
                        label: this.$i18n("app_port_alias", "not_configured"),
                        value: null
                    }].concat(je(this.aclProfiles.map(function(t) {
                        return {
                            label: t.name,
                            value: t.UUID
                        }
                    })))
                },
                protocolOptions: function() {
                    return [{
                        label: this.$i18n("common", "http"),
                        value: 0
                    }, {
                        label: this.$i18n("common", "https"),
                        value: 1
                    }]
                }
            },
            mounted: function() {
                var t = Le(regeneratorRuntime.mark(function t() {
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                this.load();
                            case 1:
                            case "end":
                                return t.stop()
                        }
                    }, t, this)
                }));
                return function() {
                    return t.apply(this, arguments)
                }
            }(),
            methods: {
                load: function() {
                    var t = Le(regeneratorRuntime.mark(function t() {
                        var e;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.next = 2, Y();
                                case 2:
                                    e = t.sent, this.aclProfiles = e.entries || [];
                                case 4:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }
        },
        Fe = (n(39), d(He, function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-form", {
                ref: "form",
                staticClass: "reverse-proxy-editor-general",
                attrs: {
                    "syno-id": "reverse-proxy-editor-general-form-0"
                }
            }, [n("v-panel", {
                attrs: {
                    "syno-id": "reverse-proxy-editor-general-panel-0",
                    "fluid-footer": "",
                    loading: t.spinner.isLoading,
                    "loading-type": t.spinner.loadingType,
                    "show-status-bar": t.spinner.showStatusBar,
                    "status-bar-state": t.spinner.statusBarState,
                    "error-text": t.spinner.errorText,
                    "confirm-text": t.$i18n("common", "save"),
                    confirm: function() {
                        return t.onApply()
                    },
                    cancel: function() {
                        return t.onCancel()
                    }
                },
                on: {
                    "update:showStatusBar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    },
                    "update:show-status-bar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    }
                },
                scopedSlots: t._u([{
                    key: "body",
                    fn: function() {
                        return [n("v-form-item", {
                            attrs: {
                                prop: "reverse-proxy-editor-general-input-0",
                                label: t.$i18n("app_port_alias", "reverse_proxy_name") + t.$i18n("common", "colon"),
                                rules: [{
                                    type: "string",
                                    required: !0
                                }]
                            }
                        }, [n("v-input", {
                            attrs: {
                                "syno-id": "reverse-proxy-editor-general-input-0",
                                name: "reverse-proxy-editor-general-input-0"
                            },
                            model: {
                                value: t.profile.description,
                                callback: function(e) {
                                    t.$set(t.profile, "description", e)
                                },
                                expression: "profile.description"
                            }
                        })], 1), t._v(" "), n("v-fieldset", {
                            attrs: {
                                title: t.$i18n("app_port_alias", "source"),
                                collapsible: !1
                            }
                        }, [n("v-form-item", {
                            attrs: {
                                label: t.$i18n("app_port_alias", "protocol") + t.$i18n("common", "colon")
                            }
                        }, [n("v-single-select", {
                            attrs: {
                                "syno-id": "reverse-proxy-editor-general-single-select-0",
                                width: null,
                                options: t.protocolOptions
                            },
                            model: {
                                value: t.profile.frontend.protocol,
                                callback: function(e) {
                                    t.$set(t.profile.frontend, "protocol", e)
                                },
                                expression: "profile.frontend.protocol"
                            }
                        })], 1), t._v(" "), n("v-form-item", {
                            attrs: {
                                prop: "reverse-proxy-editor-general-input-1",
                                label: t.$i18n("app_port_alias", "hostname") + t.$i18n("common", "colon"),
                                rules: t.reverseProxyFrontendFqdnRules
                            }
                        }, [n("v-input", {
                            attrs: {
                                "syno-id": "reverse-proxy-editor-general-input-1",
                                name: "reverse-proxy-editor-general-input-1",
                                placeholder: "*",
                                maxlength: 255
                            },
                            model: {
                                value: t.profile.frontend.fqdn,
                                callback: function(e) {
                                    t.$set(t.profile.frontend, "fqdn", e)
                                },
                                expression: "profile.frontend.fqdn"
                            }
                        })], 1), t._v(" "), n("v-form-item", {
                            attrs: {
                                prop: "reverse-proxy-editor-general-input-2",
                                label: t.$i18n("common", "port") + t.$i18n("common", "colon"),
                                rules: t.reverseProxyFrontendPortRules
                            }
                        }, [n("v-input", {
                            attrs: {
                                "syno-id": "reverse-proxy-editor-general-input-2",
                                name: "reverse-proxy-editor-general-input-2",
                                placeholder: 0 === t.profile.frontend.protocol ? "80" : "443",
                                "number-only": "",
                                maxlength: 5
                            },
                            model: {
                                value: t.profile.frontend.port,
                                callback: function(e) {
                                    t.$set(t.profile.frontend, "port", e)
                                },
                                expression: "profile.frontend.port"
                            }
                        })], 1), t._v(" "), n("v-form-item", {
                            attrs: {
                                "hide-label": ""
                            }
                        }, [n("v-checkbox", {
                            attrs: {
                                "syno-id": "reverse-proxy-editor-general-checkbox-0",
                                disabled: 0 === t.profile.frontend.protocol
                            },
                            model: {
                                value: t.profile.frontend.https.hsts,
                                callback: function(e) {
                                    t.$set(t.profile.frontend.https, "hsts", e)
                                },
                                expression: "profile.frontend.https.hsts"
                            }
                        }, [t._v("\n            " + t._s(t.$i18n("service", "enable_hsts")) + "\n          ")])], 1), t._v(" "), n("v-form-item", {
                            attrs: {
                                label: t.$i18n("app_port_alias", "desc_acl") + t.$i18n("common", "colon")
                            },
                            scopedSlots: t._u([{
                                key: "after",
                                fn: function() {
                                    return [n("v-whitetip", [n("span", {
                                        domProps: {
                                            innerHTML: t._s(t.$i18n("app_port_alias", "tip_access_control"))
                                        }
                                    })])]
                                },
                                proxy: !0
                            }])
                        }, [n("v-single-select", {
                            staticClass: "frontend-acl-select",
                            attrs: {
                                "syno-id": "reverse-proxy-editor-general-single-select-1",
                                tooltip: "",
                                width: null,
                                options: t.aclOptions
                            },
                            model: {
                                value: t.profile.frontend.acl,
                                callback: function(e) {
                                    t.$set(t.profile.frontend, "acl", e)
                                },
                                expression: "profile.frontend.acl"
                            }
                        })], 1)], 1), t._v(" "), n("v-fieldset", {
                            attrs: {
                                title: t.$i18n("app_port_alias", "destination"),
                                collapsible: !1
                            }
                        }, [n("v-form-item", {
                            attrs: {
                                label: t.$i18n("app_port_alias", "protocol") + t.$i18n("common", "colon")
                            }
                        }, [n("v-single-select", {
                            attrs: {
                                "syno-id": "reverse-proxy-editor-general-single-select-2",
                                width: null,
                                options: t.protocolOptions
                            },
                            model: {
                                value: t.profile.backend.protocol,
                                callback: function(e) {
                                    t.$set(t.profile.backend, "protocol", e)
                                },
                                expression: "profile.backend.protocol"
                            }
                        })], 1), t._v(" "), n("v-form-item", {
                            attrs: {
                                prop: "reverse-proxy-editor-general-input-3",
                                label: t.$i18n("app_port_alias", "hostname") + t.$i18n("common", "colon"),
                                rules: t.reverseProxyBackendFqdnRules
                            }
                        }, [n("v-input", {
                            attrs: {
                                "syno-id": "reverse-proxy-editor-general-input-3",
                                name: "reverse-proxy-editor-general-input-3",
                                placeholder: "localhost",
                                maxlength: 255
                            },
                            model: {
                                value: t.profile.backend.fqdn,
                                callback: function(e) {
                                    t.$set(t.profile.backend, "fqdn", e)
                                },
                                expression: "profile.backend.fqdn"
                            }
                        })], 1), t._v(" "), n("v-form-item", {
                            attrs: {
                                prop: "reverse-proxy-editor-general-input-4",
                                label: t.$i18n("common", "port") + t.$i18n("common", "colon"),
                                rules: t.reverseProxyBackendPortRules
                            }
                        }, [n("v-input", {
                            attrs: {
                                "syno-id": "reverse-proxy-editor-general-input-4",
                                name: "reverse-proxy-editor-general-input-4",
                                placeholder: 0 === t.profile.backend.protocol ? "80" : "443",
                                "number-only": "",
                                maxlength: 5
                            },
                            model: {
                                value: t.profile.backend.port,
                                callback: function(e) {
                                    t.$set(t.profile.backend, "port", e)
                                },
                                expression: "profile.backend.port"
                            }
                        })], 1)], 1)]
                    },
                    proxy: !0
                }])
            })], 1)
        }, [], !1, null, null, null).exports);

    function Me(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }
    var Ve = d({
            mixins: [it, pt, Ne],
            props: {
                profile: {
                    type: Object,
                    required: !0
                },
                isDirty: {
                    type: Function,
                    required: !0
                },
                commit: {
                    type: Function,
                    required: !0
                },
                validate: {
                    type: Function,
                    required: !0
                }
            },
            data: function() {
                return {
                    dataProperty: "profile",
                    selectedIndexes: []
                }
            },
            computed: {
                isDeleteActionActive: function() {
                    return this.selectedIndexes.length > 0
                },
                columns: function() {
                    return [{
                        title: this.$i18n("app_port_alias", "proxy_header_name"),
                        field: "name",
                        disableSort: !0
                    }, {
                        title: this.$i18n("app_port_alias", "proxy_header_value"),
                        field: "value",
                        disableSort: !0
                    }]
                }
            },
            methods: {
                addHeader: function() {
                    var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {
                            name: "",
                            value: ""
                        },
                        e = !!t.name,
                        n = this.profile.customize_headers.map(function(t) {
                            return t.name
                        }).some(function(e) {
                            return e === t.name
                        });
                    e && n || this.profile.customize_headers.push(t)
                },
                addWebsocketHeaders: function() {
                    this.addHeader({
                        name: "Upgrade",
                        value: "$http_upgrade"
                    }), this.addHeader({
                        name: "Connection",
                        value: "$connection_upgrade"
                    })
                },
                deleteHeaders: function() {
                    var t, e = (t = regeneratorRuntime.mark(function t() {
                        var e = this;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    if (this.isDeleteActionActive) {
                                        t.next = 2;
                                        break
                                    }
                                    return t.abrupt("return");
                                case 2:
                                    return t.next = 4, this.$window.getMsgBox().confirmDelete("", this.$i18n("app_port_alias", "confirm_delete_profile"));
                                case 4:
                                    if ("confirm" === t.sent) {
                                        t.next = 7;
                                        break
                                    }
                                    return t.abrupt("return");
                                case 7:
                                    this.profile.customize_headers = this.profile.customize_headers.filter(function(t, n) {
                                        return !e.selectedIndexes.includes(n)
                                    }), this.selectedIndexes = [];
                                case 9:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }), function() {
                        var e = this,
                            n = arguments;
                        return new Promise(function(r, o) {
                            var i = t.apply(e, n);

                            function a(t) {
                                Me(i, r, o, a, s, "next", t)
                            }

                            function s(t) {
                                Me(i, r, o, a, s, "throw", t)
                            }
                            a(void 0)
                        })
                    });
                    return function() {
                        return e.apply(this, arguments)
                    }
                }()
            }
        }, function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-form", {
                ref: "form",
                attrs: {
                    "syno-id": "reverse-proxy-editor-custom-header-form-0"
                }
            }, [n("v-panel", {
                attrs: {
                    "syno-id": "reverse-proxy-editor-custom-header-panel-0",
                    "has-tbar": "",
                    "fluid-footer": "",
                    loading: t.spinner.isLoading,
                    "loading-type": t.spinner.loadingType,
                    "show-status-bar": t.spinner.showStatusBar,
                    "status-bar-state": t.spinner.statusBarState,
                    "error-text": t.spinner.errorText,
                    "confirm-text": t.$i18n("common", "save"),
                    confirm: function() {
                        return t.onApply()
                    },
                    cancel: function() {
                        return t.onCancel()
                    }
                },
                on: {
                    "update:showStatusBar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    },
                    "update:show-status-bar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    }
                },
                scopedSlots: t._u([{
                    key: "tbar",
                    fn: function() {
                        return [n("v-button", {
                            attrs: {
                                "syno-id": "reverse-proxy-editor-custom-header-button-0"
                            },
                            scopedSlots: t._u([{
                                key: "dropdown",
                                fn: function() {
                                    return [n("v-menu", {
                                        attrs: {
                                            "syno-id": "reverse-proxy-editor-custom-header-menu-0"
                                        }
                                    }, [n("v-menu-item", {
                                        attrs: {
                                            "syno-id": "reverse-proxy-editor-custom-header-menu-item-0",
                                            title: t.$i18n("common", "create")
                                        },
                                        on: {
                                            click: function(e) {
                                                return t.addHeader()
                                            }
                                        }
                                    }), t._v(" "), n("v-menu-item", {
                                        attrs: {
                                            "syno-id": "reverse-proxy-editor-custom-header-menu-item-1",
                                            title: t.$i18n("app_port_alias", "desc_policy_web_socket")
                                        },
                                        on: {
                                            click: function(e) {
                                                return t.addWebsocketHeaders()
                                            }
                                        }
                                    })], 1)]
                                },
                                proxy: !0
                            }])
                        }, [t._v("\n        " + t._s(t.$i18n("common", "create")) + "\n        ")]), t._v(" "), n("v-button", {
                            attrs: {
                                "syno-id": "reverse-proxy-editor-custom-header-button-1",
                                disabled: !t.isDeleteActionActive
                            },
                            on: {
                                click: t.deleteHeaders
                            }
                        }, [t._v("\n        " + t._s(t.$i18n("common", "delete")) + "\n      ")])]
                    },
                    proxy: !0
                }, {
                    key: "body",
                    fn: function() {
                        return [n("v-data-table", {
                            ref: "dataTable",
                            attrs: {
                                "syno-id": "reverse-proxy-editor-custom-header-data-table-0",
                                "multiple-selected": "",
                                columns: t.columns,
                                "current-data": t.profile.customize_headers
                            },
                            on: {
                                rowclick: function(e) {
                                    t.selectedIndexes = e.indexes
                                }
                            },
                            scopedSlots: t._u([{
                                key: "name",
                                fn: function(e) {
                                    var r = e.row,
                                        o = e.index;
                                    return [n("v-form-item", {
                                        attrs: {
                                            prop: "reverse-proxy-editor-custom-header-input-0",
                                            rules: t.generateReverseProxyCustomizedHeaderNameRules(o)
                                        }
                                    }, [n("v-input", {
                                        attrs: {
                                            "syno-id": "reverse-proxy-editor-custom-header-input-0",
                                            name: "reverse-proxy-editor-custom-header-input-0"
                                        },
                                        model: {
                                            value: r.name,
                                            callback: function(e) {
                                                t.$set(r, "name", e)
                                            },
                                            expression: "row.name"
                                        }
                                    })], 1)]
                                }
                            }, {
                                key: "value",
                                fn: function(e) {
                                    var r = e.row,
                                        o = e.index;
                                    return [n("v-form-item", {
                                        attrs: {
                                            prop: "reverse-proxy-editor-custom-header-input-1",
                                            rules: t.generateReverseProxyCustomizedHeaderValueRules(o)
                                        }
                                    }, [n("v-input", {
                                        attrs: {
                                            "syno-id": "reverse-proxy-editor-custom-header-input-1",
                                            name: "reverse-proxy-editor-custom-header-input-1"
                                        },
                                        model: {
                                            value: r.value,
                                            callback: function(e) {
                                                t.$set(r, "value", e)
                                            },
                                            expression: "row.value"
                                        }
                                    })], 1)]
                                }
                            }])
                        })]
                    },
                    proxy: !0
                }])
            })], 1)
        }, [], !1, null, null, null).exports,
        Ue = {
            mixins: [pt, Ne],
            props: {
                profile: {
                    type: Object,
                    required: !0
                },
                isDirty: {
                    type: Function,
                    required: !0
                },
                commit: {
                    type: Function,
                    required: !0
                },
                validate: {
                    type: Function,
                    required: !0
                }
            },
            data: function() {
                return {
                    dataProperty: "profile",
                    form: {
                        useErrorPage: !this.profile.proxy_intercept_errors
                    }
                }
            },
            computed: {
                httpVersionOptions: function() {
                    return [{
                        label: "HTTP 1.0",
                        value: 0
                    }, {
                        label: "HTTP 1.1",
                        value: 1
                    }]
                }
            },
            mounted: function() {
                var t = this;
                this.$watch("form.useErrorPage", function(e) {
                    t.profile.proxy_intercept_errors = !e
                })
            }
        },
        We = (n(40), d(Ue, function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-form", {
                ref: "form",
                staticClass: "reverse-proxy-editor-advanced",
                attrs: {
                    "syno-id": "reverse-proxy-editor-advanced-form-0"
                }
            }, [n("v-panel", {
                attrs: {
                    "syno-id": "reverse-proxy-editor-advanced-panel-0",
                    "fluid-footer": "",
                    loading: t.spinner.isLoading,
                    "loading-type": t.spinner.loadingType,
                    "show-status-bar": t.spinner.showStatusBar,
                    "status-bar-state": t.spinner.statusBarState,
                    "error-text": t.spinner.errorText,
                    "confirm-text": t.$i18n("common", "save"),
                    confirm: function() {
                        return t.onApply()
                    },
                    cancel: function() {
                        return t.onCancel()
                    }
                },
                on: {
                    "update:showStatusBar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    },
                    "update:show-status-bar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    }
                },
                scopedSlots: t._u([{
                    key: "body",
                    fn: function() {
                        return [n("v-form-item", {
                            attrs: {
                                "hide-label": "",
                                textonly: ""
                            }
                        }, [t._v("\n        " + t._s(t.$i18n("app_port_alias", "desc_proxy_timeout")) + "\n      ")]), t._v(" "), n("v-form-item", {
                            attrs: {
                                prop: "reverse-proxy-editor-advanced-input-0",
                                indent: "1",
                                label: t.$i18n("app_port_alias", "desc_proxy_connect_timeout") + t.$i18n("common", "colon"),
                                rules: t.reverseProxyConnectTimeoutRules
                            }
                        }, [n("v-input", {
                            attrs: {
                                "syno-id": "reverse-proxy-editor-advanced-input-0",
                                name: "reverse-proxy-editor-advanced-input-0",
                                "number-only": "",
                                maxlength: 5
                            },
                            model: {
                                value: t.profile.proxy_connect_timeout,
                                callback: function(e) {
                                    t.$set(t.profile, "proxy_connect_timeout", e)
                                },
                                expression: "profile.proxy_connect_timeout"
                            }
                        })], 1), t._v(" "), n("v-form-item", {
                            attrs: {
                                prop: "reverse-proxy-editor-advanced-input-1",
                                indent: "1",
                                label: t.$i18n("app_port_alias", "desc_proxy_send_timeout") + t.$i18n("common", "colon"),
                                rules: t.reverseProxySendTimeoutRules
                            }
                        }, [n("v-input", {
                            attrs: {
                                "syno-id": "reverse-proxy-editor-advanced-input-1",
                                name: "reverse-proxy-editor-advanced-input-1",
                                "number-only": "",
                                maxlength: 5
                            },
                            model: {
                                value: t.profile.proxy_send_timeout,
                                callback: function(e) {
                                    t.$set(t.profile, "proxy_send_timeout", e)
                                },
                                expression: "profile.proxy_send_timeout"
                            }
                        })], 1), t._v(" "), n("v-form-item", {
                            attrs: {
                                prop: "reverse-proxy-editor-advanced-input-2",
                                indent: "1",
                                label: t.$i18n("app_port_alias", "desc_proxy_read_timeout") + t.$i18n("common", "colon"),
                                rules: t.reverseProxyReadTimeoutRules
                            }
                        }, [n("v-input", {
                            attrs: {
                                "syno-id": "reverse-proxy-editor-advanced-input-2",
                                name: "reverse-proxy-editor-advanced-input-2",
                                "number-only": "",
                                maxlength: 5
                            },
                            model: {
                                value: t.profile.proxy_read_timeout,
                                callback: function(e) {
                                    t.$set(t.profile, "proxy_read_timeout", e)
                                },
                                expression: "profile.proxy_read_timeout"
                            }
                        })], 1), t._v(" "), n("v-form-item", {
                            staticClass: "proxy_http_version",
                            attrs: {
                                prop: "reverse-proxy-editor-advanced-single-select-0",
                                label: t.$i18n("app_port_alias", "desc_proxy_http_version") + t.$i18n("common", "colon")
                            }
                        }, [n("v-single-select", {
                            attrs: {
                                "syno-id": "reverse-proxy-editor-advanced-single-select-0",
                                name: "reverse-proxy-editor-advanced-single-select-0",
                                width: null,
                                options: t.httpVersionOptions
                            },
                            model: {
                                value: t.profile.proxy_http_version,
                                callback: function(e) {
                                    t.$set(t.profile, "proxy_http_version", e)
                                },
                                expression: "profile.proxy_http_version"
                            }
                        })], 1), t._v(" "), n("v-form-item", {
                            attrs: {
                                "hide-label": "",
                                prop: "reverse-proxy-editor-advanced-checkbox-0"
                            }
                        }, [n("v-checkbox", {
                            attrs: {
                                "syno-id": "reverse-proxy-editor-advanced-checkbox-0",
                                name: "reverse-proxy-editor-advanced-checkbox-0"
                            },
                            model: {
                                value: t.form.useErrorPage,
                                callback: function(e) {
                                    t.$set(t.form, "useErrorPage", e)
                                },
                                expression: "form.useErrorPage"
                            }
                        }, [t._v("\n          " + t._s(t.$i18n("app_port_alias", "desc_proxy_intercept_errors")) + "\n        ")])], 1)]
                    },
                    proxy: !0
                }])
            })], 1)
        }, [], !1, null, null, null).exports);

    function ze(t, e) {
        return function(t) {
            if (Array.isArray(t)) return t
        }(t) || function(t, e) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(t))) return;
            var n = [],
                r = !0,
                o = !1,
                i = void 0;
            try {
                for (var a, s = t[Symbol.iterator](); !(r = (a = s.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
            } catch (t) {
                o = !0, i = t
            } finally {
                try {
                    r || null == s.return || s.return()
                } finally {
                    if (o) throw i
                }
            }
            return n
        }(t, e) || Je(t, e) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function Qe(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }

    function Ke(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise(function(r, o) {
                var i = t.apply(e, n);

                function a(t) {
                    Qe(i, r, o, a, s, "next", t)
                }

                function s(t) {
                    Qe(i, r, o, a, s, "throw", t)
                }
                a(void 0)
            })
        }
    }

    function Ge(t) {
        return function(t) {
            if (Array.isArray(t)) return Xe(t)
        }(t) || function(t) {
            if ("undefined" != typeof Symbol && Symbol.iterator in Object(t)) return Array.from(t)
        }(t) || Je(t) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function Je(t, e) {
        if (t) {
            if ("string" == typeof t) return Xe(t, e);
            var n = Object.prototype.toString.call(t).slice(8, -1);
            return "Object" === n && t.constructor && (n = t.constructor.name), "Map" === n || "Set" === n ? Array.from(n) : "Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n) ? Xe(t, e) : void 0
        }
    }

    function Xe(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
        return r
    }

    function Ze(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter(function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            }))), r.forEach(function(e) {
                tn(t, e, n[e])
            })
        }
        return t
    }

    function tn(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }

    function en() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        return Ze({
            description: "",
            proxy_connect_timeout: 60,
            proxy_read_timeout: 60,
            proxy_send_timeout: 60,
            proxy_http_version: 1,
            proxy_intercept_errors: !1
        }, t, {
            frontend: Ze({
                acl: null,
                fqdn: null,
                port: null,
                protocol: 0
            }, t.frontend, {
                https: Ze({
                    hsts: !1
                }, t.frontend && t.frontend.https)
            }),
            backend: Ze({
                fqdn: null,
                port: null,
                protocol: 0
            }, t.backend),
            customize_headers: Ge(t.customize_headers || [])
        })
    }
    var nn = d({
        components: {
            General: Fe,
            CustomHeader: Ve,
            Advanced: We
        },
        props: {
            profile: {
                type: Object,
                required: !0
            }
        },
        data: function() {
            return {
                aProfile: en(this.profile),
                activeTabKey: "general",
                errors: {
                    frontendFqdn: "",
                    frontendPort: "",
                    backendFqdn: "",
                    customHeaderNameIndex: -1,
                    customHeaderName: "",
                    customHeaderValueIndex: -1,
                    customHeaderValue: "",
                    proxyConnectTimeout: "",
                    proxyReadTimeout: "",
                    proxySendTimeout: ""
                }
            }
        },
        computed: {
            tabs: function() {
                return [{
                    key: "general",
                    title: this.$i18n("app_port_alias", "title_proxy_general"),
                    synoId: "reverse-proxy-editor-tab-pane-general",
                    component: Fe
                }, {
                    key: "custom-header",
                    title: this.$i18n("app_port_alias", "title_proxy_customized_headers"),
                    synoId: "reverse-proxy-editor-tab-pane-header",
                    component: Ve
                }, {
                    key: "advanced",
                    title: this.$i18n("app_port_alias", "title_proxy_advance"),
                    synoId: "reverse-proxy-editor-tab-pane-advanced",
                    component: We
                }]
            }
        },
        mounted: function() {
            this.watchConvertStringToNumber()
        },
        methods: {
            beforeClose: function() {
                return this.$refs[this.activeTabKey][0].beforeClose()
            },
            isDirty: function() {
                var t = this;
                return this.tabs.map(function(t) {
                    return t.key
                }).map(function(e) {
                    return t.$refs[e][0]
                }).some(function(t) {
                    return t.$refs.form.isDirty()
                })
            },
            commit: function() {
                var t = this;
                this.tabs.map(function(t) {
                    return t.key
                }).map(function(e) {
                    return t.$refs[e][0]
                }).forEach(function(t) {
                    return t.$refs.form.commit()
                })
            },
            validate: function() {
                var t = Ke(regeneratorRuntime.mark(function t() {
                    var e, n = this;
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.next = 2, this.$nextTick();
                            case 2:
                                return t.next = 4, Promise.all(this.tabs.map(function(t) {
                                    return t.key
                                }).map(function(t) {
                                    return [t, n.$refs[t][0]]
                                }).reverse().map(function() {
                                    var t = Ke(regeneratorRuntime.mark(function t(e) {
                                        var r, o, i;
                                        return regeneratorRuntime.wrap(function(t) {
                                            for (;;) switch (t.prev = t.next) {
                                                case 0:
                                                    return r = ze(e, 2), o = r[0], i = r[1], t.next = 3, i.$refs.form.validate();
                                                case 3:
                                                    if (t.sent) {
                                                        t.next = 6;
                                                        break
                                                    }
                                                    return n.activeTabKey = o, t.abrupt("return", !1);
                                                case 6:
                                                    return t.abrupt("return", !0);
                                                case 7:
                                                case "end":
                                                    return t.stop()
                                            }
                                        }, t, this)
                                    }));
                                    return function(e) {
                                        return t.apply(this, arguments)
                                    }
                                }()));
                            case 4:
                                return e = t.sent, t.abrupt("return", e.every(function(t) {
                                    return t
                                }));
                            case 6:
                            case "end":
                                return t.stop()
                        }
                    }, t, this)
                }));
                return function() {
                    return t.apply(this, arguments)
                }
            }(),
            watchConvertStringToNumber: function() {
                var t = this;
                this.$watch("aProfile.frontend.port", function() {
                    t.aProfile.frontend.port = t.aProfile.frontend.port ? parseInt(t.aProfile.frontend.port, 10) : null
                }), this.$watch("aProfile.backend.port", function() {
                    t.aProfile.backend.port = t.aProfile.backend.port ? parseInt(t.aProfile.backend.port, 10) : null
                }), this.$watch("aProfile.proxy_connect_timeout", function() {
                    t.aProfile.proxy_connect_timeout = t.aProfile.proxy_connect_timeout ? parseInt(t.aProfile.proxy_connect_timeout, 10) : null
                }), this.$watch("aProfile.proxy_read_timeout", function() {
                    t.aProfile.proxy_read_timeout = t.aProfile.proxy_read_timeout ? parseInt(t.aProfile.proxy_read_timeout, 10) : null
                }), this.$watch("aProfile.proxy_send_timeout", function() {
                    t.aProfile.proxy_send_timeout = t.aProfile.proxy_send_timeout ? parseInt(t.aProfile.proxy_send_timeout, 10) : null
                })
            },
            emitApply: function() {
                var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                    e = arguments.length > 1 ? arguments[1] : void 0,
                    n = arguments.length > 2 ? arguments[2] : void 0,
                    r = JSON.parse(JSON.stringify(t));
                "*" === r.frontend.fqdn && (r.frontend.fqdn = null), r.customize_headers = r.customize_headers.map(function(t) {
                    return {
                        name: t.name,
                        value: t.value
                    }
                }), this.$emit("apply", r, e, n)
            }
        }
    }, function() {
        var t = this,
            e = t.$createElement,
            n = t._self._c || e;
        return n("v-tabs", {
            attrs: {
                "syno-id": "reverse-proxy-editor-tabs-0",
                "has-fbar": !1,
                "active-tab-key": t.activeTabKey
            },
            on: {
                change: function(e) {
                    t.activeTabKey = e
                }
            }
        }, t._l(t.tabs, function(e) {
            return n("v-tab-pane", {
                key: e.key,
                attrs: {
                    "syno-id": e.synoId,
                    "tab-key": e.key,
                    tab: e.title
                }
            }, [n(e.component, {
                ref: e.key,
                refInFor: !0,
                tag: "component",
                attrs: {
                    profile: t.aProfile,
                    errors: t.errors,
                    "is-dirty": t.isDirty,
                    commit: t.commit,
                    validate: t.validate
                },
                on: {
                    apply: t.emitApply,
                    cancel: function(e) {
                        return t.$emit("cancel")
                    }
                }
            })], 1)
        }), 1)
    }, [], !1, null, null, null).exports;

    function rn(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }
    var on = d({
        components: {
            ReverseProxyEditor: nn
        },
        mixins: [it],
        data: function() {
            return {
                profile: {}
            }
        },
        methods: {
            onApply: function() {
                var t, e = (t = regeneratorRuntime.mark(function t() {
                    var e, n, r, o = arguments;
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return e = o.length > 0 && void 0 !== o[0] ? o[0] : {}, n = o.length > 1 ? o[1] : void 0, r = o.length > 2 ? o[2] : void 0, t.prev = 3, t.next = 6, E(e);
                            case 6:
                                n(), this.close(), t.next = 13;
                                break;
                            case 10:
                                t.prev = 10, t.t0 = t.catch(3), r(t.t0);
                            case 13:
                            case "end":
                                return t.stop()
                        }
                    }, t, this, [
                        [3, 10]
                    ])
                }), function() {
                    var e = this,
                        n = arguments;
                    return new Promise(function(r, o) {
                        var i = t.apply(e, n);

                        function a(t) {
                            rn(i, r, o, a, s, "next", t)
                        }

                        function s(t) {
                            rn(i, r, o, a, s, "throw", t)
                        }
                        a(void 0)
                    })
                });
                return function() {
                    return e.apply(this, arguments)
                }
            }()
        }
    }, function() {
        var t = this,
            e = t.$createElement,
            n = t._self._c || e;
        return n("v-modal-window", {
            staticClass: "admin-center-login-portal admin-center-login-portal--reverse_proxy",
            attrs: {
                "syno-id": "reverse-proxy-create-modal-window-0",
                height: 560,
                width: 600,
                title: t.$i18n("app_port_alias", "desc_edit_reverse_proxy"),
                "before-close": function() {
                    return t.$refs.editor.beforeClose()
                }
            }
        }, [n("reverse-proxy-editor", {
            ref: "editor",
            attrs: {
                profile: t.profile
            },
            on: {
                apply: t.onApply,
                cancel: function(e) {
                    return t.close()
                }
            }
        })], 1)
    }, [], !1, null, null, null).exports;

    function an(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }
    var sn = d({
        components: {
            ReverseProxyEditor: nn
        },
        mixins: [it],
        props: {
            profile: {
                type: Object,
                required: !0
            }
        },
        methods: {
            onApply: function() {
                var t, e = (t = regeneratorRuntime.mark(function t() {
                    var e, n, r, o = arguments;
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return e = o.length > 0 && void 0 !== o[0] ? o[0] : {}, n = o.length > 1 ? o[1] : void 0, r = o.length > 2 ? o[2] : void 0, t.prev = 3, t.next = 6, N(e);
                            case 6:
                                n(), this.close(), t.next = 13;
                                break;
                            case 10:
                                t.prev = 10, t.t0 = t.catch(3), r(t.t0);
                            case 13:
                            case "end":
                                return t.stop()
                        }
                    }, t, this, [
                        [3, 10]
                    ])
                }), function() {
                    var e = this,
                        n = arguments;
                    return new Promise(function(r, o) {
                        var i = t.apply(e, n);

                        function a(t) {
                            an(i, r, o, a, s, "next", t)
                        }

                        function s(t) {
                            an(i, r, o, a, s, "throw", t)
                        }
                        a(void 0)
                    })
                });
                return function() {
                    return e.apply(this, arguments)
                }
            }()
        }
    }, function() {
        var t = this,
            e = t.$createElement,
            n = t._self._c || e;
        return n("v-modal-window", {
            staticClass: "admin-center-login-portal admin-center-login-portal--reverse_proxy",
            attrs: {
                "syno-id": "reverse-proxy-update-modal-window-0",
                height: 560,
                width: 600,
                title: t.$i18n("app_port_alias", "desc_edit_reverse_proxy"),
                "before-close": function() {
                    return t.$refs.editor.beforeClose()
                }
            }
        }, [n("reverse-proxy-editor", {
            ref: "editor",
            attrs: {
                profile: t.profile
            },
            on: {
                apply: t.onApply,
                cancel: function(e) {
                    return t.close()
                }
            }
        })], 1)
    }, [], !1, null, null, null).exports;

    function cn(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }

    function ln(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise(function(r, o) {
                var i = t.apply(e, n);

                function a(t) {
                    cn(i, r, o, a, s, "next", t)
                }

                function s(t) {
                    cn(i, r, o, a, s, "throw", t)
                }
                a(void 0)
            })
        }
    }
    var un = {
            mixins: [it, pt],
            mounted: function() {
                var t = ln(regeneratorRuntime.mark(function t() {
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.next = 2, this.$nextTick();
                            case 2:
                                this.load();
                            case 3:
                            case "end":
                                return t.stop()
                        }
                    }, t, this)
                }));
                return function() {
                    return t.apply(this, arguments)
                }
            }(),
            computed: {
                singleSelectedRow: function() {
                    return 1 === this.selectedRows.length && this.selectedRows[0]
                },
                isEditActionActive: function() {
                    return !!this.singleSelectedRow
                },
                isDeleteActionActive: function() {
                    return this.selectedRows.length > 0
                },
                columns: function() {
                    return [{
                        title: this.$i18n("common", "name"),
                        field: "name"
                    }]
                }
            },
            data: function() {
                return {
                    data: [],
                    selectedRows: []
                }
            },
            methods: {
                load: function() {
                    var t = ln(regeneratorRuntime.mark(function t() {
                        var e;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return this.onLoading(), this.$refs.dataTable && this.$refs.dataTable.clearSelection(), t.next = 4, Y();
                                case 4:
                                    e = t.sent, this.data = e && e.entries || [], this.onDone();
                                case 7:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                openCreateDialog: function() {
                    var t = ln(regeneratorRuntime.mark(function t() {
                        var e, n = this;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    this.updateAppWindow(), e = this.$window.openWindow(SYNO.SDS.AdminCenter.LoginPortal.Dialogs.CreateAccessControl_vue), e.component, e.window.$on("close", function() {
                                        return n.load()
                                    });
                                case 3:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                openEditDialog: function() {
                    var t = ln(regeneratorRuntime.mark(function t() {
                        var e, n = this;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    if (this.isEditActionActive) {
                                        t.next = 2;
                                        break
                                    }
                                    return t.abrupt("return");
                                case 2:
                                    this.updateAppWindow(), e = this.$window.openWindow(SYNO.SDS.AdminCenter.LoginPortal.Dialogs.UpdateAccessControl_vue, {
                                        profile: this.singleSelectedRow
                                    }), e.component, e.window.$on("close", function() {
                                        return n.load()
                                    });
                                case 5:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                deleteAccessControls: function() {
                    var t = ln(regeneratorRuntime.mark(function t() {
                        var e;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    if (this.isDeleteActionActive) {
                                        t.next = 2;
                                        break
                                    }
                                    return t.abrupt("return");
                                case 2:
                                    return t.next = 4, this.$window.getMsgBox().confirmDelete("", this.$i18n("app_port_alias", "confirm_delete_profile"));
                                case 4:
                                    if ("confirm" === t.sent) {
                                        t.next = 7;
                                        break
                                    }
                                    return t.abrupt("return");
                                case 7:
                                    return t.prev = 7, this.onLoading(), e = this.selectedRows.map(function(t) {
                                        return t.UUID
                                    }), t.next = 12, W(e);
                                case 12:
                                    t.sent, this.load(), this.onDone(), t.next = 20;
                                    break;
                                case 17:
                                    t.prev = 17, t.t0 = t.catch(7), this.onError(t.t0);
                                case 20:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this, [
                            [7, 17]
                        ])
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }
        },
        pn = (n(41), d(un, function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-panel", {
                staticClass: "lp-acl-component__panel",
                attrs: {
                    "fluid-footer": "",
                    "syno-id": "syno-panel-acl",
                    "has-tbar": 0 !== t.data.length,
                    loading: t.spinner.isLoading,
                    "loading-type": t.spinner.loadingType,
                    "show-status-bar": t.spinner.showStatusBar,
                    "status-bar-state": t.spinner.statusBarState
                },
                on: {
                    "update:showStatusBar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    },
                    "update:show-status-bar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    }
                },
                scopedSlots: t._u([{
                    key: "tbar",
                    fn: function() {
                        return [n("div", {
                            staticClass: "lp-modal-content"
                        }, [n("v-button", {
                            attrs: {
                                "syno-id": "syno-btn-acl-create"
                            },
                            on: {
                                click: function(e) {
                                    return t.openCreateDialog()
                                }
                            }
                        }, [t._v("\n        " + t._s(t.$i18n("common", "create")) + "\n      ")]), t._v(" "), n("v-button", {
                            attrs: {
                                "syno-id": "syno-btn-acl-edit",
                                disabled: !t.isEditActionActive
                            },
                            on: {
                                click: function(e) {
                                    return t.openEditDialog()
                                }
                            }
                        }, [t._v("\n        " + t._s(t.$i18n("common", "alt_edit")) + "\n      ")]), t._v(" "), n("v-button", {
                            attrs: {
                                "syno-id": "syno-btn-acl-delete",
                                disabled: !t.isDeleteActionActive
                            },
                            on: {
                                click: function(e) {
                                    return t.deleteAccessControls()
                                }
                            }
                        }, [t._v("\n        " + t._s(t.$i18n("common", "delete")) + "\n      ")])], 1)]
                    },
                    proxy: !0
                }, {
                    key: "body",
                    fn: function() {
                        return [0 !== t.data.length ? n("div", {
                            staticClass: "lp-modal-content lp-modal-content--no-top-padding"
                        }, [n("v-data-table", {
                            ref: "dataTable",
                            staticClass: "lp-acl-component__data-table",
                            attrs: {
                                "multiple-selected": "",
                                "syno-id": "syno-table-acl",
                                columns: t.columns,
                                "current-data": t.data
                            },
                            on: {
                                refresh: function(e) {
                                    return t.load()
                                },
                                rowclick: function(e) {
                                    t.selectedRows = e.rows
                                },
                                rowdblclick: function(e) {
                                    return t.openEditDialog()
                                }
                            }
                        })], 1) : n("v-empty-view", {
                            attrs: {
                                "syno-id": "syno-empty-view-acl"
                            },
                            on: {
                                "action-click": function(e) {
                                    return t.openCreateDialog()
                                }
                            }
                        })]
                    },
                    proxy: !0
                }, {
                    key: "fbar",
                    fn: function() {
                        return [n("div", {
                            staticClass: "default pull-right"
                        }, [n("v-button", {
                            attrs: {
                                "syno-id": "access-control-index-button-0",
                                type: "footbar"
                            },
                            on: {
                                click: function(e) {
                                    return t.onCancel()
                                }
                            }
                        }, [t._v("\n        " + t._s(t.$i18n("common", "close")) + "\n      ")])], 1)]
                    },
                    proxy: !0
                }])
            })
        }, [], !1, null, null, null)),
        dn = d({
            components: {
                AccessControl: pn.exports
            },
            mixins: [it]
        }, function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-modal-window", {
                attrs: {
                    "syno-id": "syno-modal-acl",
                    height: 450,
                    width: 680,
                    title: t.$i18n("app_port_alias", "title_access_control")
                }
            }, [n("div", {
                staticClass: "lp-modal-content-wrapper"
            }, [n("access-control", {
                on: {
                    apply: function(e) {
                        return t.close()
                    },
                    cancel: function(e) {
                        return t.close()
                    }
                }
            })], 1)])
        }, [], !1, null, null, null).exports;

    function fn(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }

    function mn(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise(function(r, o) {
                var i = t.apply(e, n);

                function a(t) {
                    fn(i, r, o, a, s, "next", t)
                }

                function s(t) {
                    fn(i, r, o, a, s, "throw", t)
                }
                a(void 0)
            })
        }
    }
    var hn = {
            mixins: [pt],
            props: {
                profile: {
                    type: Object,
                    default: function() {},
                    required: !0
                }
            },
            computed: {
                columns: function() {
                    return [{
                        title: this.$i18n("app_port_alias", "desc_source_ip_or_cidr"),
                        field: "address",
                        disableSort: !0
                    }, {
                        title: this.$i18n("app_port_alias", "desc_allow_or_deny"),
                        field: "access",
                        disableSort: !0
                    }]
                },
                accessOptions: function() {
                    return [{
                        label: this.$i18n("app_port_alias", "desc_allow"),
                        value: !0
                    }, {
                        label: this.$i18n("app_port_alias", "desc_deny"),
                        value: !1
                    }]
                },
                rules: function() {
                    return r
                },
                nameRules: function() {
                    var t = this,
                        e = this.allProfiles.filter(function(e) {
                            return e.UUID !== t.profile.UUID
                        }).map(function(t) {
                            return t.name
                        });
                    return yt(e)
                }
            },
            mounted: function() {
                var t = mn(regeneratorRuntime.mark(function t() {
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.next = 2, this.fetchPropfiles();
                            case 2:
                                this.fillDefaultProfileNameWhenMounted();
                            case 3:
                            case "end":
                                return t.stop()
                        }
                    }, t, this)
                }));
                return function() {
                    return t.apply(this, arguments)
                }
            }(),
            data: function() {
                return {
                    dataProperty: "profile",
                    selected: null,
                    allProfiles: []
                }
            },
            methods: {
                fetchPropfiles: function() {
                    var t = mn(regeneratorRuntime.mark(function t() {
                        var e;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return this.onLoading(), t.next = 3, Y();
                                case 3:
                                    e = t.sent, this.allProfiles = e && e.entries || [], this.onDone();
                                case 6:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                fillDefaultProfileNameWhenMounted: function() {
                    var t = mn(regeneratorRuntime.mark(function t() {
                        var e, n, r, o, i, a = this;
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    if ("" === this.profile.name) {
                                        t.next = 2;
                                        break
                                    }
                                    return t.abrupt("return");
                                case 2:
                                    e = this.allProfiles.map(function(t) {
                                        return t.name
                                    }), n = this.$i18n("app_port_alias", "desc_new_profile"), r = function(t, n) {
                                        if (e.every(function(e) {
                                                return e !== t
                                            })) return a.profile.name = t, "break"
                                    }, o = n, i = 2;
                                case 6:
                                    if (!(i < 1e3)) {
                                        t.next = 13;
                                        break
                                    }
                                    if ("break" !== r(o, i)) {
                                        t.next = 10;
                                        break
                                    }
                                    return t.abrupt("break", 13);
                                case 10:
                                    o = "".concat(n, " (").concat(i++, ")"), t.next = 6;
                                    break;
                                case 13:
                                    return t.next = 15, this.$nextTick();
                                case 15:
                                    return this._commit(), t.abrupt("return");
                                case 17:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                appendRule: function() {
                    this.profile.rules.push({
                        address: "",
                        access: !0
                    })
                },
                deleteRule: function() {
                    var t = mn(regeneratorRuntime.mark(function t() {
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    if (this.selected) {
                                        t.next = 2;
                                        break
                                    }
                                    return t.abrupt("return");
                                case 2:
                                    return t.next = 4, this.$window.getMsgBox().confirmDelete("", this.$i18n("app_port_alias", "confirm_delete_proxy"));
                                case 4:
                                    if ("confirm" === t.sent) {
                                        t.next = 7;
                                        break
                                    }
                                    return t.abrupt("return");
                                case 7:
                                    this.profile.rules.splice(this.selected.index, 1), this.$refs.dataTable.clearSelection();
                                case 9:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }
        },
        vn = (n(42), d(hn, function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-panel", {
                staticClass: "lp-acl-editor__panel",
                attrs: {
                    "syno-id": "syno-panel-lp-acl-editor",
                    loading: t.spinner.isLoading,
                    "loading-type": t.spinner.loadingType,
                    "show-status-bar": t.spinner.showStatusBar,
                    "status-bar-state": t.spinner.statusBarState,
                    "error-text": t.spinner.errorText,
                    "confirm-text": t.$i18n("common", "save"),
                    confirm: function() {
                        return t.onApply()
                    },
                    cancel: function() {
                        return t.onCancel()
                    }
                },
                on: {
                    "update:showStatusBar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    },
                    "update:show-status-bar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    }
                },
                scopedSlots: t._u([{
                    key: "body",
                    fn: function() {
                        return [n("div", {
                            staticClass: "lp-modal-content"
                        }, [n("v-form", {
                            ref: "form",
                            staticClass: "lp-acl-editor__content-container",
                            attrs: {
                                "syno-id": "syno-form-lp-acl-editor"
                            }
                        }, [n("v-form-item", {
                            attrs: {
                                "syno-id": "syno-form-item-lp-acl-editor-name",
                                prop: "p-lp-acl-editor-name",
                                rules: t.nameRules,
                                label: t.$i18n("app_port_alias", "profile_name")
                            }
                        }, [n("v-input", {
                            attrs: {
                                "syno-id": "syno-input-lp-acl-editor-name",
                                name: "p-lp-acl-editor-name"
                            },
                            model: {
                                value: t.profile.name,
                                callback: function(e) {
                                    t.$set(t.profile, "name", e)
                                },
                                expression: "profile.name"
                            }
                        })], 1), t._v(" "), n("v-fieldset", {
                            staticClass: "lp-acl-editor__fieldset",
                            attrs: {
                                "syno-id": "syno-fieldset-lp-acl-cidr",
                                title: t.$i18n("app_port_alias", "access_control_rules"),
                                collapsible: !1
                            }
                        }, [n("div", {
                            staticClass: "lp-acl-editor__rules-toolbar"
                        }, [n("v-button", {
                            attrs: {
                                "syno-id": "syno-btn-lp-acl-cidr-add"
                            },
                            on: {
                                click: function(e) {
                                    return t.appendRule()
                                }
                            }
                        }, [t._v("\n              " + t._s(t.$i18n("common", "create")) + "\n            ")]), t._v(" "), n("v-button", {
                            attrs: {
                                "syno-id": "syno-btn-lp-acl-cidr-del",
                                disabled: !t.selected
                            },
                            on: {
                                click: function(e) {
                                    return t.deleteRule()
                                }
                            }
                        }, [t._v("\n              " + t._s(t.$i18n("common", "delete")) + "\n            ")])], 1), t._v(" "), n("v-data-table", {
                            ref: "dataTable",
                            staticClass: "lp-acl-editor__data-table",
                            attrs: {
                                "syno-id": "syno-table-lp-acl-cidr-rules",
                                "is-draggable": "",
                                columns: t.columns,
                                "current-data": t.profile.rules
                            },
                            on: {
                                reorder: function(e) {
                                    t.profile.rules = e.data
                                },
                                rowclick: function(e) {
                                    t.selected = e
                                },
                                rowclear: function(e) {
                                    t.selected = null
                                }
                            },
                            scopedSlots: t._u([{
                                key: "th",
                                fn: function(e) {
                                    var r = e.title;
                                    return ["address" === e.column.field ? [t._v("\n                " + t._s(r) + "\n                  "), n("v-whitetip", {
                                        attrs: {
                                            "syno-id": "syno-lp-acl-whitetip-cidr",
                                            content: t.$i18n("controlpanel", "tip_source_ip_or_cidr")
                                        }
                                    })] : t._e()]
                                }
                            }, {
                                key: "address",
                                fn: function(e) {
                                    var r = e.row;
                                    return [n("v-form-item", {
                                        attrs: {
                                            "syno-id": "syno-form-item-lp-acl-cidr-rule-address",
                                            prop: "p-lp-acl-cidr-rule-address",
                                            rules: t.rules.accessControlCidrRules
                                        }
                                    }, [n("v-input", {
                                        attrs: {
                                            "syno-id": "syno-input-lp-acl-cidr-rule-address",
                                            name: "p-lp-acl-cidr-rule-address",
                                            placeholder: t.$i18n("app_port_alias", "desc_all")
                                        },
                                        model: {
                                            value: r.address,
                                            callback: function(e) {
                                                t.$set(r, "address", e)
                                            },
                                            expression: "rule.address"
                                        }
                                    })], 1)]
                                }
                            }, {
                                key: "access",
                                fn: function(e) {
                                    var r = e.row;
                                    return [n("v-form-item", {
                                        attrs: {
                                            "syno-id": "syno-form-item-lp-acl-cidr-rule-access",
                                            prop: "p-lp-acl-cidr-rule-access"
                                        }
                                    }, [n("v-select", {
                                        attrs: {
                                            "syno-id": "syno-select-lp-acl-cidr-rule-access",
                                            name: "p-lp-acl-cidr-rule-access",
                                            width: "",
                                            options: t.accessOptions
                                        },
                                        model: {
                                            value: r.access,
                                            callback: function(e) {
                                                t.$set(r, "access", e)
                                            },
                                            expression: "rule.access"
                                        }
                                    })], 1)]
                                }
                            }])
                        }), t._v(" "), n("v-form-item", {
                            staticClass: "lp-login-style-editor__form-item--last",
                            attrs: {
                                textonly: "",
                                "hide-label": "",
                                "syno-id": "syno-form-item-acl-foot-note"
                            }
                        }, [n("span", {
                            staticClass: "ac-lp-text-note"
                        }, [t._v(t._s(t.$i18n("common", "note")) + t._s(t.$i18n("common", "colon")))]), t._v("\n            " + t._s(t.$i18n("controlpanel", "note_source_ip_or_cidr")) + "\n          ")])], 1)], 1)], 1)]
                    },
                    proxy: !0
                }])
            })
        }, [], !1, null, null, null).exports);

    function _n(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }
    var gn = d({
        components: {
            AccessControlEditor: vn
        },
        mixins: [it],
        data: function() {
            return {
                profile: {
                    name: "",
                    rules: []
                }
            }
        },
        methods: {
            onApply: function() {
                var t, e = (t = regeneratorRuntime.mark(function t(e, n, r) {
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return e.rules = e.rules.map(function(t) {
                                    return {
                                        address: t.address,
                                        access: t.access
                                    }
                                }), t.prev = 1, t.next = 4, F({
                                    entry: e
                                });
                            case 4:
                                t.sent, this.$window.$emit("success", e), n(), this.close(), t.next = 13;
                                break;
                            case 10:
                                t.prev = 10, t.t0 = t.catch(1), r(t.t0);
                            case 13:
                            case "end":
                                return t.stop()
                        }
                    }, t, this, [
                        [1, 10]
                    ])
                }), function() {
                    var e = this,
                        n = arguments;
                    return new Promise(function(r, o) {
                        var i = t.apply(e, n);

                        function a(t) {
                            _n(i, r, o, a, s, "next", t)
                        }

                        function s(t) {
                            _n(i, r, o, a, s, "throw", t)
                        }
                        a(void 0)
                    })
                });
                return function(t, n, r) {
                    return e.apply(this, arguments)
                }
            }()
        }
    }, function() {
        var t = this,
            e = t.$createElement,
            n = t._self._c || e;
        return n("v-modal-window", {
            attrs: {
                "syno-id": "syno-modal-acl-create",
                height: 420,
                width: 720,
                title: t.$i18n("app_port_alias", "title_edit_access_control"),
                "before-close": function() {
                    return t.$refs.editor.beforeClose()
                }
            }
        }, [n("div", {
            staticClass: "lp-modal-content-wrapper"
        }, [n("access-control-editor", {
            ref: "editor",
            attrs: {
                profile: t.profile
            },
            on: {
                apply: t.onApply,
                cancel: function(e) {
                    return t.close()
                }
            }
        })], 1)])
    }, [], !1, null, null, null).exports;

    function yn(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }
    var bn = d({
        components: {
            AccessControlEditor: vn
        },
        mixins: [it],
        props: {
            profile: {
                type: Object,
                required: !0
            }
        },
        data: function() {
            return {
                currentProfile: JSON.parse(JSON.stringify(this.profile))
            }
        },
        methods: {
            onApply: function() {
                var t, e = (t = regeneratorRuntime.mark(function t(e, n, r) {
                    return regeneratorRuntime.wrap(function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return e.rules = e.rules.map(function(t) {
                                    return {
                                        address: t.address,
                                        access: t.access
                                    }
                                }), t.prev = 1, t.next = 4, V({
                                    entry: e
                                });
                            case 4:
                                t.sent, n(), this.close(), t.next = 12;
                                break;
                            case 9:
                                t.prev = 9, t.t0 = t.catch(1), r(t.t0);
                            case 12:
                            case "end":
                                return t.stop()
                        }
                    }, t, this, [
                        [1, 9]
                    ])
                }), function() {
                    var e = this,
                        n = arguments;
                    return new Promise(function(r, o) {
                        var i = t.apply(e, n);

                        function a(t) {
                            yn(i, r, o, a, s, "next", t)
                        }

                        function s(t) {
                            yn(i, r, o, a, s, "throw", t)
                        }
                        a(void 0)
                    })
                });
                return function(t, n, r) {
                    return e.apply(this, arguments)
                }
            }()
        }
    }, function() {
        var t = this,
            e = t.$createElement,
            n = t._self._c || e;
        return n("v-modal-window", {
            attrs: {
                "syno-id": "syno-modal-acl-update",
                height: 420,
                width: 720,
                title: t.$i18n("app_port_alias", "title_edit_access_control"),
                "before-close": function() {
                    return t.$refs.editor.beforeClose()
                }
            }
        }, [n("div", {
            staticClass: "lp-modal-content-wrapper"
        }, [t.profile ? n("access-control-editor", {
            ref: "editor",
            attrs: {
                profile: t.currentProfile
            },
            on: {
                apply: t.onApply,
                cancel: function(e) {
                    return t.close()
                }
            }
        }) : t._e()], 1)])
    }, [], !1, null, null, null).exports;

    function wn(t, e, n, r, o, i, a) {
        try {
            var s = t[i](a),
                c = s.value
        } catch (t) {
            return void n(t)
        }
        s.done ? e(c) : Promise.resolve(c).then(r, o)
    }

    function xn(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise(function(r, o) {
                var i = t.apply(e, n);

                function a(t) {
                    wn(i, r, o, a, s, "next", t)
                }

                function s(t) {
                    wn(i, r, o, a, s, "throw", t)
                }
                a(void 0)
            })
        }
    }
    var kn = {
            mixins: [it, pt],
            mounted: function() {
                this.load(), this.$on("apply", this._onApply), this.$on("cancel", this._onCancel)
            },
            data: function() {
                return {
                    dataProperty: "appPortalConfig",
                    appPortalConfig: {}
                }
            },
            methods: {
                load: function() {
                    var t = xn(regeneratorRuntime.mark(function t() {
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return this.onLoading(), t.next = 3, Q();
                                case 3:
                                    return this.appPortalConfig = t.sent, t.next = 6, this.$nextTick();
                                case 6:
                                    this.$refs.form.commit(), this.onDone();
                                case 8:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this)
                    }));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                _onApply: function() {
                    var t = xn(regeneratorRuntime.mark(function t(e, n, r) {
                        return regeneratorRuntime.wrap(function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.prev = 0, t.next = 3, G(e);
                                case 3:
                                    t.sent, n(), this.close(), t.next = 11;
                                    break;
                                case 8:
                                    t.prev = 8, t.t0 = t.catch(0), r(t.t0);
                                case 11:
                                case "end":
                                    return t.stop()
                            }
                        }, t, this, [
                            [0, 8]
                        ])
                    }));
                    return function(e, n, r) {
                        return t.apply(this, arguments)
                    }
                }(),
                _onCancel: function() {
                    this.close()
                }
            }
        },
        Sn = (n(43), d(kn, function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-modal-window", {
                attrs: {
                    "syno-id": "syno-lp-modal-options",
                    height: "auto",
                    width: 480,
                    title: t.$i18n("login_portal", "network_option_header"),
                    "before-close": function() {
                        return t.beforeClose()
                    }
                }
            }, [n("div", {
                staticClass: "lp-modal-content-wrapper"
            }, [n("v-panel", {
                staticClass: "lp-options-dialog__panel",
                attrs: {
                    "syno-id": "syno-lp-panel-options",
                    "fluid-footer": "",
                    loading: t.spinner.isLoading,
                    "loading-type": t.spinner.loadingType,
                    "show-status-bar": t.spinner.showStatusBar,
                    "status-bar-state": t.spinner.statusBarState,
                    "error-text": t.spinner.errorText,
                    confirm: function() {
                        return t.onApply()
                    },
                    cancel: function() {
                        return t.onCancel()
                    }
                },
                on: {
                    "update:showStatusBar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    },
                    "update:show-status-bar": function(e) {
                        return t.$set(t.spinner, "showStatusBar", e)
                    }
                },
                scopedSlots: t._u([{
                    key: "body",
                    fn: function() {
                        return [n("div", {
                            staticClass: "lp-modal-content lp-modal-content--bottom-padding"
                        }, [n("v-form", {
                            ref: "form",
                            attrs: {
                                "syno-id": "syno-lp-form-options"
                            }
                        }, [n("v-form-item", {
                            attrs: {
                                "syno-id": "syno-lp-form-item-options-show-titlebar",
                                "hide-label": "",
                                prop: "p-lp-options-show-titlebar"
                            }
                        }, [n("v-checkbox", {
                            attrs: {
                                "syno-id": "syno-lp-checkbox-options-show-titlebar",
                                name: "p-lp-options-show-titlebar",
                                value: !t.appPortalConfig.show_titlebar
                            },
                            on: {
                                input: function(e) {
                                    t.appPortalConfig.show_titlebar = !e
                                }
                            }
                        }, [t._v("\n                " + t._s(t.$i18n("common", "remove_banner")) + "\n              ")])], 1), t._v(" "), n("v-form-item", {
                            attrs: {
                                "syno-id": "syno-lp-form-item-options-show-titlebar-desc",
                                "hide-label": "",
                                indent: "1"
                            }
                        }, [t._v("\n              " + t._s(t.$i18n("common", "remove_banner_desc")) + "\n            ")])], 1)], 1)]
                    },
                    proxy: !0
                }])
            })], 1)])
        }, [], !1, null, null, null).exports);
    n(44);
    Ext.namespace("SYNO.SDS.AdminCenter.LoginPortal"), 
/**
 * @class SYNO.SDS.AdminCenter.LoginPortal
 * AdminCenter login portal
 *
 */   
    SYNO.SDS.AdminCenter.LoginPortal.Main_vue = i.a.extend({
        template: "<LpMain />",
        components: {
            LpMain: ie
        }
    }), Ext.namespace("SYNO.SDS.AdminCenter.LoginPortal.Dialogs"), SYNO.SDS.AdminCenter.LoginPortal.Dialogs.ApplicationEditor_vue = i.a.extend({
        template: "<LpApplicationEditor />",
        components: {
            LpApplicationEditor: he
        }
    }), SYNO.SDS.AdminCenter.LoginPortal.Dialogs.LoginStyleEditor_vue = i.a.extend({
        template: "<LpLoginStyleEditor />",
        components: {
            LpLoginStyleEditor: Se
        }
    }), SYNO.SDS.AdminCenter.LoginPortal.Dialogs.ReverseProxy_vue = i.a.extend({
        template: "<LpReverseProxy />",
        components: {
            LpReverseProxy: Ie
        }
    }), SYNO.SDS.AdminCenter.LoginPortal.Dialogs.CreateReverseProxy_vue = i.a.extend({
        template: "<LpCreateReverseProxy />",
        components: {
            LpCreateReverseProxy: on
        }
    }), SYNO.SDS.AdminCenter.LoginPortal.Dialogs.UpdateReverseProxy_vue = i.a.extend({
        template: '<LpUpdateReverseProxy :profile="profile" />',
        components: {
            LpUpdateReverseProxy: sn
        },
        props: {
            profile: {
                type: Object,
                required: !0
            }
        }
    }), SYNO.SDS.AdminCenter.LoginPortal.Dialogs.AccessControl_vue = i.a.extend({
        template: "<LpAccessControl />",
        components: {
            LpAccessControl: dn
        }
    }), SYNO.SDS.AdminCenter.LoginPortal.Dialogs.CreateAccessControl_vue = i.a.extend({
        template: "<LpCreateAccessControl />",
        components: {
            LpCreateAccessControl: gn
        }
    }), SYNO.SDS.AdminCenter.LoginPortal.Dialogs.UpdateAccessControl_vue = i.a.extend({
        template: '<LpUpdateAccessControl :profile="profile" />',
        components: {
            LpUpdateAccessControl: bn
        },
        props: {
            profile: {
                type: Object,
                required: !0
            }
        }
    }), SYNO.SDS.AdminCenter.LoginPortal.Dialogs.Options_vue = i.a.extend({
        template: "<LpOptions />",
        components: {
            LpOptions: Sn
        }
    })
}]);
