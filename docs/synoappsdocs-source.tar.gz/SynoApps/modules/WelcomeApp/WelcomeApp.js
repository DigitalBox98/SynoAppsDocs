! function(e) {
    var t = {};

    function o(n) {
        if (t[n]) return t[n].exports;
        var i = t[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return e[n].call(i.exports, i, i.exports, o), i.l = !0, i.exports
    }
    o.m = e, o.c = t, o.d = function(e, t, n) {
        o.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: n
        })
    }, o.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, o.t = function(e, t) {
        if (1 & t && (e = o(e)), 8 & t) return e;
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var n = Object.create(null);
        if (o.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var i in e) o.d(n, i, function(t) {
                return e[t]
            }.bind(null, i));
        return n
    }, o.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return o.d(t, "a", t), t
    }, o.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, o.p = "", o(o.s = 73)
}([function(e, t, o) {
    "use strict";

    function n(e, t, o, n, i, s, r, a) {
        var c, p = "function" == typeof e ? e.options : e;
        if (t && (p.render = t, p.staticRenderFns = o, p._compiled = !0), n && (p.functional = !0), s && (p._scopeId = "data-v-" + s), r ? (c = function(e) {
                (e = e || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) || "undefined" == typeof __VUE_SSR_CONTEXT__ || (e = __VUE_SSR_CONTEXT__), i && i.call(this, e), e && e._registeredComponents && e._registeredComponents.add(r)
            }, p._ssrRegister = c) : i && (c = a ? function() {
                i.call(this, this.$root.$options.shadowRoot)
            } : i), c)
            if (p.functional) {
                p._injectStyles = c;
                var l = p.render;
                p.render = function(e, t) {
                    return c.call(t), l(e, t)
                }
            } else {
                var d = p.beforeCreate;
                p.beforeCreate = d ? [].concat(d, c) : [c]
            } return {
            exports: e,
            options: p
        }
    }
    o.d(t, "a", (function() {
        return n
    }))
}, function(e, t, o) {
    "use strict";
    t.a = {
        methods: {
            T: function(e, t) {
                var o = _T(e, t);
                return o && "" !== o ? o : "".concat(e, ":").concat(t)
            },
            D: function(e) {
                var t = _D(e);
                return t && "" !== t ? t : "".concat(e)
            },
            htmlEncode: function(e) {
                return e ? String(e).replace(/&/g, "&amp;").replace(/>/g, "&gt;").replace(/</g, "&lt;").replace(/'/g, "&quot;").replace(/'/g, "&apos;") : e
            },
            urlEncode: function(e) {
                var t = [];
                for (var o in e) t.push(encodeURIComponent(o) + "=" + encodeURIComponent(e[o]));
                return t.join("&")
            },
            formatUrl: function(e, t, o) {
                var n = '<a href="{0}" target="_blank">';
                return String.format(e, String.format(n, t), "</a>", String.format(n, o), "</a>")
            }
        }
    }
}, function(e, t, o) {
    "use strict";

    function n(e, t, o, n, i, s, r) {
        try {
            var a = e[s](r),
                c = a.value
        } catch (e) {
            return void o(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(n, i)
    }

    function i(e) {
        return function() {
            var t = this,
                o = arguments;
            return new Promise((function(i, s) {
                var r = e.apply(t, o);

                function a(e) {
                    n(r, i, s, a, c, "next", e)
                }

                function c(e) {
                    n(r, i, s, a, c, "throw", e)
                }
                a(void 0)
            }))
        }
    }
    var s, r;
    t.a = {
        methods: {
            strengthChecker: function(e) {
                var t = ["weak", "medium", "strong"],
                    o = [this.T("welcome", "passwd_weak"), this.T("welcome", "passwd_medium"), this.T("welcome", "passwd_strong")];
                return synowebapi.promises.request({
                    api: "SYNO.Core.User.PasswordMeter",
                    method: "evaluate",
                    version: "1",
                    encryption: ["password"],
                    params: {
                        password: e,
                        required_rules: this.rules
                    }
                }).then((function(e) {
                    var n = function(e) {
                        return Math.floor(e / 2)
                    }(e.score);
                    return {
                        strength: t[n],
                        strengthText: o[n]
                    }
                }))
            },
            setUdc: (r = i(regeneratorRuntime.mark((function e(t) {
                var o, n, i, s, r = arguments;
                return regeneratorRuntime.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return o = r.length > 1 && void 0 !== r[1] && r[1], n = [{
                                api: "SYNO.Core.DataCollect",
                                method: "set",
                                version: 1,
                                params: {
                                    enable: t
                                }
                            }, {
                                api: "SYNO.Core.QuickStart.Info",
                                method: "set_udc",
                                version: 1,
                                params: {
                                    udc_value: _S("productversion")
                                }
                            }], o && (n = n.concat([{
                                api: "SYNO.Core.QuickStart.Info",
                                method: "set_confautobkp",
                                version: 1,
                                params: {
                                    confautobkp_value: "done"
                                }
                            }, {
                                api: "SYNO.Core.QuickStart.Info",
                                method: "set_mib",
                                version: 2,
                                params: {
                                    mib_value: _S("productversion") + _S("buildphase")
                                }
                            }])), e.prev = 3, e.next = 6, synowebapi.promises.request({
                                api: "SYNO.Entry.Request",
                                method: "request",
                                version: 1,
                                compound: {
                                    mode: "sequential",
                                    stopwhenerror: !0,
                                    params: n
                                }
                            });
                        case 6:
                            !0 === (i = e.sent).has_fail ? (s = SYNO.API.Response.GetFirstError(i), this.$emit("display-error", s), this.$emit("set-loader", !1), this.updateFooter()) : (SYNO.SDS.Session.udc_check_state = _S("productversion"), SYNO.SDS.Session.udc_enabled = t, this.$emit("close")), e.next = 15;
                            break;
                        case 10:
                            e.prev = 10, e.t0 = e.catch(3), this.$emit("display-error", e.t0), this.$emit("set-loader", !1), this.updateFooter();
                        case 15:
                            return e.prev = 15, e.finish(15);
                        case 17:
                        case "end":
                            return e.stop()
                    }
                }), e, this, [
                    [3, 10, 15, 17]
                ])
            }))), function(e) {
                return r.apply(this, arguments)
            }),
            setStepWebapi: (s = i(regeneratorRuntime.mark((function e(t) {
                return regeneratorRuntime.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return e.prev = 0, e.next = 3, synowebapi.promises.request({
                                api: "SYNO.Core.QuickStart.Info",
                                method: "set_wizard_step",
                                version: 3,
                                params: {
                                    quickstart_wizard_step: t
                                }
                            });
                        case 3:
                            e.next = 8;
                            break;
                        case 5:
                            e.prev = 5, e.t0 = e.catch(0), SYNO.Debug.error(e.t0);
                        case 8:
                        case "end":
                            return e.stop()
                    }
                }), e, this, [
                    [0, 5]
                ])
            }))), function(e) {
                return s.apply(this, arguments)
            }),
            uuid: function() {
                return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (function(e) {
                    var t = 16 * Math.random() | 0;
                    return ("x" == e ? t : 3 & t | 8).toString(16)
                }))
            }
        }
    }
}, function(e, t) {
    e.exports = Vuex
}, function(e, t, o) {
    "use strict";
    e.exports = function(e) {
        var t = [];
        return t.toString = function() {
            return this.map((function(t) {
                var o = function(e, t) {
                    var o = e[1] || "",
                        n = e[3];
                    if (!n) return o;
                    if (t && "function" == typeof btoa) {
                        var i = (r = n, "/*# sourceMappingURL=data:application/json;charset=utf-8;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(r)))) + " */"),
                            s = n.sources.map((function(e) {
                                return "/*# sourceURL=" + n.sourceRoot + e + " */"
                            }));
                        return [o].concat(s).concat([i]).join("\n")
                    }
                    var r;
                    return [o].join("\n")
                }(t, e);
                return t[2] ? "@media " + t[2] + "{" + o + "}" : o
            })).join("")
        }, t.i = function(e, o) {
            "string" == typeof e && (e = [
                [null, e, ""]
            ]);
            for (var n = {}, i = 0; i < this.length; i++) {
                var s = this[i][0];
                null != s && (n[s] = !0)
            }
            for (i = 0; i < e.length; i++) {
                var r = e[i];
                null != r[0] && n[r[0]] || (o && !r[2] ? r[2] = o : o && (r[2] = "(" + r[2] + ") and (" + o + ")"), t.push(r))
            }
        }, t
    }
}, function(e, t, o) {
    "use strict";

    function n(e, t) {
        for (var o = [], n = {}, i = 0; i < t.length; i++) {
            var s = t[i],
                r = s[0],
                a = {
                    id: e + ":" + i,
                    css: s[1],
                    media: s[2],
                    sourceMap: s[3]
                };
            n[r] ? n[r].parts.push(a) : o.push(n[r] = {
                id: r,
                parts: [a]
            })
        }
        return o
    }
    o.r(t), o.d(t, "default", (function() {
        return m
    }));
    var i = "undefined" != typeof document;
    if ("undefined" != typeof DEBUG && DEBUG && !i) throw new Error("vue-style-loader cannot be used in a non-browser environment. Use { target: 'node' } in your Webpack config to indicate a server-rendering environment.");
    var s = {},
        r = i && (document.head || document.getElementsByTagName("head")[0]),
        a = null,
        c = 0,
        p = !1,
        l = function() {},
        d = null,
        u = "undefined" != typeof navigator && /msie [6-9]\b/.test(navigator.userAgent.toLowerCase());

    function m(e, t, o, i) {
        p = o, d = i || {};
        var r = n(e, t);
        return h(r),
            function(t) {
                for (var o = [], i = 0; i < r.length; i++) {
                    var a = r[i];
                    (c = s[a.id]).refs--, o.push(c)
                }
                t ? h(r = n(e, t)) : r = [];
                for (i = 0; i < o.length; i++) {
                    var c;
                    if (0 === (c = o[i]).refs) {
                        for (var p = 0; p < c.parts.length; p++) c.parts[p]();
                        delete s[c.id]
                    }
                }
            }
    }

    function h(e) {
        for (var t = 0; t < e.length; t++) {
            var o = e[t],
                n = s[o.id];
            if (n) {
                n.refs++;
                for (var i = 0; i < n.parts.length; i++) n.parts[i](o.parts[i]);
                for (; i < o.parts.length; i++) n.parts.push(g(o.parts[i]));
                n.parts.length > o.parts.length && (n.parts.length = o.parts.length)
            } else {
                var r = [];
                for (i = 0; i < o.parts.length; i++) r.push(g(o.parts[i]));
                s[o.id] = {
                    id: o.id,
                    refs: 1,
                    parts: r
                }
            }
        }
    }

    function f() {
        var e = document.createElement("style");
        return e.type = "text/css", r.appendChild(e), e
    }

    function g(e) {
        var t, o, n = document.querySelector('style[data-vue-ssr-id~="' + e.id + '"]');
        if (n) {
            if (p) return l;
            n.parentNode.removeChild(n)
        }
        if (u) {
            var i = c++;
            n = a || (a = f()), t = b.bind(null, n, i, !1), o = b.bind(null, n, i, !0)
        } else n = f(), t = x.bind(null, n), o = function() {
            n.parentNode.removeChild(n)
        };
        return t(e),
            function(n) {
                if (n) {
                    if (n.css === e.css && n.media === e.media && n.sourceMap === e.sourceMap) return;
                    t(e = n)
                } else o()
            }
    }
    var w, v = (w = [], function(e, t) {
        return w[e] = t, w.filter(Boolean).join("\n")
    });

    function b(e, t, o, n) {
        var i = o ? "" : n.css;
        if (e.styleSheet) e.styleSheet.cssText = v(t, i);
        else {
            var s = document.createTextNode(i),
                r = e.childNodes;
            r[t] && e.removeChild(r[t]), r.length ? e.insertBefore(s, r[t]) : e.appendChild(s)
        }
    }

    function x(e, t) {
        var o = t.css,
            n = t.media,
            i = t.sourceMap;
        if (n && e.setAttribute("media", n), d.ssrId && e.setAttribute("data-vue-ssr-id", t.id), i && (o += "\n/*# sourceURL=" + i.sources[0] + " */", o += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(i)))) + " */"), e.styleSheet) e.styleSheet.cssText = o;
        else {
            for (; e.firstChild;) e.removeChild(e.firstChild);
            e.appendChild(document.createTextNode(o))
        }
    }
}, function(e, t, o) {
    "use strict";
    e.exports = function(e, t) {
        return "string" != typeof e ? e : (/^['"].*['"]$/.test(e) && (e = e.slice(1, -1)), /["'() \t\n]/.test(e) || t ? '"' + e.replace(/"/g, '\\"').replace(/\n/g, "\\n") + '"' : e)
    }
}, function(e, t, o) {
    var n = o(22);
    "string" == typeof n && (n = [
        [e.i, n, ""]
    ]), n.locals && (e.exports = n.locals);
    (0, o(5).default)("4d08af5c", n, !1, {})
}, function(e, t, o) {
    var n = o(24);
    "string" == typeof n && (n = [
        [e.i, n, ""]
    ]), n.locals && (e.exports = n.locals);
    (0, o(5).default)("07da45c0", n, !1, {})
}, function(e, t, o) {
    var n = o(26);
    "string" == typeof n && (n = [
        [e.i, n, ""]
    ]), n.locals && (e.exports = n.locals);
    (0, o(5).default)("d0181a64", n, !1, {})
}, function(e, t, o) {
    var n = o(28);
    "string" == typeof n && (n = [
        [e.i, n, ""]
    ]), n.locals && (e.exports = n.locals);
    (0, o(5).default)("059ba282", n, !1, {})
}, function(e, t, o) {
    var n = o(30);
    "string" == typeof n && (n = [
        [e.i, n, ""]
    ]), n.locals && (e.exports = n.locals);
    (0, o(5).default)("743bd304", n, !1, {})
}, function(e, t, o) {
    var n = o(34);
    "string" == typeof n && (n = [
        [e.i, n, ""]
    ]), n.locals && (e.exports = n.locals);
    (0, o(5).default)("27a17f6c", n, !1, {})
}, function(e, t, o) {
    var n = o(38);
    "string" == typeof n && (n = [
        [e.i, n, ""]
    ]), n.locals && (e.exports = n.locals);
    (0, o(5).default)("2c8ce428", n, !1, {})
}, function(e, t, o) {
    var n = o(42);
    "string" == typeof n && (n = [
        [e.i, n, ""]
    ]), n.locals && (e.exports = n.locals);
    (0, o(5).default)("65247548", n, !1, {})
}, function(e, t, o) {
    var n = o(44);
    "string" == typeof n && (n = [
        [e.i, n, ""]
    ]), n.locals && (e.exports = n.locals);
    (0, o(5).default)("72efb500", n, !1, {})
}, function(e, t, o) {
    var n = o(46);
    "string" == typeof n && (n = [
        [e.i, n, ""]
    ]), n.locals && (e.exports = n.locals);
    (0, o(5).default)("1015dbb8", n, !1, {})
}, function(e, t, o) {
    var n = o(48);
    "string" == typeof n && (n = [
        [e.i, n, ""]
    ]), n.locals && (e.exports = n.locals);
    (0, o(5).default)("574229a1", n, !1, {})
}, function(e, t, o) {
    var n = o(52);
    "string" == typeof n && (n = [
        [e.i, n, ""]
    ]), n.locals && (e.exports = n.locals);
    (0, o(5).default)("70732106", n, !1, {})
}, function(e, t) {
    e.exports = "webman/modules/WelcomeApp/images/assets/4fa235b68da3c32bfc03ba5a51a06ad4.png"
}, function(e, t) {
    e.exports = "webman/modules/WelcomeApp/images/assets/0c8c2b2ee6ed75fe1133323ef98e516a.png"
}, function(e, t, o) {
    "use strict";
    var n = o(7);
    o.n(n).a
}, function(e, t, o) {
    (e.exports = o(4)(!1)).push([e.i, ".quick-start-loader .quick-start-loader-title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.quick-start-loader{text-align:center}.quick-start-loader .quick-start-loader-title{color:#414b55;font-size:22px;line-height:36px;margin-top:40px}.quick-start-loader .quick-start-loader-body{font-size:13px;line-height:20px;margin-top:10px;width:600px;margin-left:172px}.quick-start-loader .v-btn-footbar.v-btn-cancel.quick-start-loader-btn{margin-top:66px}.quick-start-loader .quick-start-loader-animation{width:320px;height:60px;margin-top:192px;margin-left:auto;margin-right:auto;position:relative}.quick-start-loader .quick-start-spinner1{width:60px;height:60px;margin-left:240px;margin-right:auto;border-radius:2px;-webkit-animation:quick-start-rotate1 2.4s infinite ease-in-out, loader-background 2.4s infinite alternate;animation:quick-start-rotate1 2.4s infinite ease-in-out, loader-background 2.4s infinite alternate;position:relative;-webkit-transform-origin:-100px center;transform-origin:-100px center}@-webkit-keyframes quick-start-rotate1{0%{-webkit-transform:perspective(300px) rotateX(0deg) rotateY(0deg) scale(0.6, 0.6);transform:perspective(300px) rotateX(0deg) rotateY(0deg) scale(0.6, 0.6)}50%{-webkit-transform:perspective(300px) rotateX(0deg) rotateY(-200deg) scale(0.4, 0.4);transform:perspective(300px) rotateX(0deg) rotateY(-200deg) scale(0.4, 0.4)}100%{-webkit-transform:perspective(300px) rotateX(0deg) rotateY(-360deg) scale(0.6, 0.6);transform:perspective(300px) rotateX(0deg) rotateY(-360deg) scale(0.6, 0.6)}}@keyframes quick-start-rotate1{0%{-webkit-transform:perspective(300px) rotateX(0deg) rotateY(0deg) scale(0.6, 0.6);transform:perspective(300px) rotateX(0deg) rotateY(0deg) scale(0.6, 0.6)}50%{-webkit-transform:perspective(300px) rotateX(0deg) rotateY(-200deg) scale(0.4, 0.4);transform:perspective(300px) rotateX(0deg) rotateY(-200deg) scale(0.4, 0.4)}100%{-webkit-transform:perspective(300px) rotateX(0deg) rotateY(-360deg) scale(0.6, 0.6);transform:perspective(300px) rotateX(0deg) rotateY(-360deg) scale(0.6, 0.6)}}.quick-start-loader .quick-start-spinner2{width:60px;height:60px;margin-left:240px;margin-right:auto;border-radius:2px;-webkit-animation:quick-start-rotate2 2.4s infinite linear, loader-background 2.4s infinite alternate;animation:quick-start-rotate2 2.4s infinite linear, loader-background 2.4s infinite alternate;-webkit-animation-delay:0.1s;animation-delay:0.1s;position:relative;-webkit-transform-origin:-100px center;transform-origin:-100px center;top:-60px;z-index:-1px;opacity:0.5}@-webkit-keyframes quick-start-rotate2{0%{-webkit-transform:perspective(300px) rotateX(0deg) rotateY(0deg) scale(0.6, 0.6);transform:perspective(300px) rotateX(0deg) rotateY(0deg) scale(0.6, 0.6)}50%{-webkit-transform:perspective(300px) rotateX(0deg) rotateY(-190deg) scale(0.4, 0.4);transform:perspective(300px) rotateX(0deg) rotateY(-190deg) scale(0.4, 0.4)}100%{-webkit-transform:perspective(300px) rotateX(0deg) rotateY(-360deg) scale(0.6, 0.6);transform:perspective(300px) rotateX(0deg) rotateY(-360deg) scale(0.6, 0.6)}}@keyframes quick-start-rotate2{0%{-webkit-transform:perspective(300px) rotateX(0deg) rotateY(0deg) scale(0.6, 0.6);transform:perspective(300px) rotateX(0deg) rotateY(0deg) scale(0.6, 0.6)}50%{-webkit-transform:perspective(300px) rotateX(0deg) rotateY(-190deg) scale(0.4, 0.4);transform:perspective(300px) rotateX(0deg) rotateY(-190deg) scale(0.4, 0.4)}100%{-webkit-transform:perspective(300px) rotateX(0deg) rotateY(-360deg) scale(0.6, 0.6);transform:perspective(300px) rotateX(0deg) rotateY(-360deg) scale(0.6, 0.6)}}.quick-start-loader .quick-start-spinner3{width:60px;height:60px;margin-left:240px;margin-right:auto;border-radius:2px;-webkit-animation:quick-start-rotate3 2.4s infinite linear, loader-background 2.4s infinite alternate;animation:quick-start-rotate3 2.4s infinite linear, loader-background 2.4s infinite alternate;-webkit-animation-delay:0.2s;animation-delay:0.2s;position:relative;-webkit-transform-origin:-100px center;transform-origin:-100px center;top:-120px;z-index:-2px;opacity:0.3}@-webkit-keyframes quick-start-rotate3{0%{-webkit-transform:perspective(300px) rotateX(0deg) rotateY(0deg) scale(0.6, 0.6);transform:perspective(300px) rotateX(0deg) rotateY(0deg) scale(0.6, 0.6)}50%{-webkit-transform:perspective(300px) rotateX(0deg) rotateY(-180deg) scale(0.4, 0.4);transform:perspective(300px) rotateX(0deg) rotateY(-180deg) scale(0.4, 0.4)}100%{-webkit-transform:perspective(300px) rotateX(0deg) rotateY(-360deg) scale(0.6, 0.6);transform:perspective(300px) rotateX(0deg) rotateY(-360deg) scale(0.6, 0.6)}}@keyframes quick-start-rotate3{0%{-webkit-transform:perspective(300px) rotateX(0deg) rotateY(0deg) scale(0.6, 0.6);transform:perspective(300px) rotateX(0deg) rotateY(0deg) scale(0.6, 0.6)}50%{-webkit-transform:perspective(300px) rotateX(0deg) rotateY(-180deg) scale(0.4, 0.4);transform:perspective(300px) rotateX(0deg) rotateY(-180deg) scale(0.4, 0.4)}100%{-webkit-transform:perspective(300px) rotateX(0deg) rotateY(-360deg) scale(0.6, 0.6);transform:perspective(300px) rotateX(0deg) rotateY(-360deg) scale(0.6, 0.6)}}@-webkit-keyframes loader-background{0%{background-color:#057FEB}50%{background-color:#00d7b4}100%{background-color:#ffaa00}}@keyframes loader-background{0%{background-color:#057FEB}50%{background-color:#00d7b4}100%{background-color:#ffaa00}}\n", ""])
}, function(e, t, o) {
    "use strict";
    var n = o(8);
    o.n(n).a
}, function(e, t, o) {
    t = e.exports = o(4)(!1);
    var n = o(6),
        i = n(o(19)),
        s = n(o(20));
    t.push([e.i, ".welcome-step-title[data-v-0726dce0],.welcome-app-welcome-page .welcome-page .welcome-page-content .welcome-page-title[data-v-0726dce0]{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.welcome-step-header[data-v-0726dce0]{padding-top:24px;height:128px}.welcome-step-title[data-v-0726dce0]{color:#414b55;font-size:22px;line-height:36px;margin-bottom:6px}.welcome-step-desc[data-v-0726dce0]{color:#414b55;line-height:20px;padding:4px 0 4px 0}.welcome-step-body[data-v-0726dce0]{margin-left:12px;margin-right:12px;height:318px}.welcome-step-body .welcome-step-body-img[data-v-0726dce0]{width:376px;height:260px;margin-right:44px;background-position:0 0;background-repeat:no-repeat;float:left}.welcome-step-body .welcome-step-body-content[data-v-0726dce0]{width:500px;margin-top:28px;float:left;color:#414b55;line-height:20px;font-size:13px}.welcome-step-body .welcome-step-body-content .welcome-step-body-content-desc[data-v-0726dce0]{padding-top:4px;padding-bottom:4px;line-height:20px}.welcome-step-body .welcome-step-body-content .welcome-step-link[data-v-0726dce0]{margin-top:6px}.welcome-step-body .v-ps[data-v-0726dce0]{padding-right:12px}.welcome-app-welcome-page .welcome-page[data-v-0726dce0]{height:580px;display:flex;justify-content:center;flex-direction:column}.welcome-app-welcome-page .welcome-page .welcome-page-content[data-v-0726dce0]{margin-left:72px;width:800px;height:auto;text-align:center}.welcome-app-welcome-page .welcome-page .welcome-page-content .welcome-page-title[data-v-0726dce0]{color:#414B55;font-size:32px;line-height:44px;height:44px;margin-bottom:10px}.welcome-app-welcome-page .welcome-page .welcome-page-content .welcome-page-desc[data-v-0726dce0]{color:#414B55;font-size:18px;line-height:28px;height:28px}.welcome-app-welcome-page .welcome-page .welcome-page-content .welcome-page-btn[data-v-0726dce0]{margin-top:34px;margin-bottom:10px}.welcome-app-welcome-page .welcome-page .welcome-page-content .whats-new-link[data-v-0726dce0]{font-size:13px;color:#057FEB;line-height:28px}.welcome-app-welcome-page .welcome-page .welcome-page-logo[data-v-0726dce0]{position:absolute;bottom:24px;left:50%;transform:translate(-50%, 0%);height:24px;width:78px;background-size:78px 24px;background-image:url(" + i + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .welcome-app-welcome-page .welcome-page .welcome-page-logo[data-v-0726dce0]{background-image:url(" + s + ');background-size:image-width("../../images/default/1x/synology_logo.png") image-height("../../images/default/1x/synology_logo.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .welcome-app-welcome-page .welcome-page .welcome-page-logo[data-v-0726dce0]{background-image:url(' + s + ');background-size:image-width("../../images/default/1x/synology_logo.png") image-height("../../images/default/1x/synology_logo.png");outline:1px green dashed}}\n', ""])
}, function(e, t, o) {
    "use strict";
    var n = o(9);
    o.n(n).a
}, function(e, t, o) {
    (e.exports = o(4)(!1)).push([e.i, ".welcome-step-title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.welcome-step-header{padding-top:24px;height:128px}.welcome-step-title{color:#414b55;font-size:22px;line-height:36px;margin-bottom:6px}.welcome-step-desc{color:#414b55;line-height:20px;padding:4px 0 4px 0}.welcome-step-body{margin-left:12px;margin-right:12px;height:318px}.welcome-step-body .welcome-step-body-img{width:376px;height:260px;margin-right:44px;background-position:0 0;background-repeat:no-repeat;float:left}.welcome-step-body .welcome-step-body-content{width:500px;margin-top:28px;float:left;color:#414b55;line-height:20px;font-size:13px}.welcome-step-body .welcome-step-body-content .welcome-step-body-content-desc{padding-top:4px;padding-bottom:4px;line-height:20px}.welcome-step-body .welcome-step-body-content .welcome-step-link{margin-top:6px}.welcome-step-body .v-ps{padding-right:12px}.welcome-admin-form{padding-bottom:6px}.welcome-admin-form .v-form-item-label{width:240px;margin-right:8px}.welcome-admin-form .v-form-item-input{width:260px}.welcome-admin-form .v-textfield-strength{padding-bottom:6px}\n", ""])
}, function(e, t, o) {
    "use strict";
    var n = o(10);
    o.n(n).a
}, function(e, t, o) {
    (e.exports = o(4)(!1)).push([e.i, ".welcome-step-title,.welcome-step-body .content-body .content-text .content-title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.welcome-step-header{padding-top:24px;height:128px}.welcome-step-title{color:#414b55;font-size:22px;line-height:36px;margin-bottom:6px}.welcome-step-desc{color:#414b55;line-height:20px;padding:4px 0 4px 0}.welcome-step-body{margin-left:12px;margin-right:12px;height:318px}.welcome-step-body .welcome-step-body-img{width:376px;height:260px;margin-right:44px;background-position:0 0;background-repeat:no-repeat;float:left}.welcome-step-body .welcome-step-body-content{width:500px;margin-top:28px;float:left;color:#414b55;line-height:20px;font-size:13px}.welcome-step-body .welcome-step-body-content .welcome-step-body-content-desc{padding-top:4px;padding-bottom:4px;line-height:20px}.welcome-step-body .welcome-step-body-content .welcome-step-link{margin-top:6px}.welcome-step-body .v-ps{padding-right:12px}.welcome-step-body .content-body{margin-bottom:18px;min-height:44px}.welcome-step-body .content-body .content-icon{float:left;width:44px;height:44px;border-radius:6px;margin-right:16px;background:var(--background)}.welcome-step-body .content-body .content-icon.active-insight{background-color:#199BED}.welcome-step-body .content-body .content-icon.business-user{background-color:#00A7E6}.welcome-step-body .content-body .content-icon.normal-user{background-color:#1E7DF1}.welcome-step-body .content-body .content-icon.secure-signin{background-color:#4582FD}.welcome-step-body .content-body .content-img{width:30px;height:30px;padding:7px 7px}.welcome-step-body .content-body .content-text{float:left;margin-bottom:18px}.welcome-step-body .content-body .content-text .content-title{width:440px;font-size:13px}.welcome-step-body .content-body .content-text .content-desc{width:440px}\n", ""])
}, function(e, t, o) {
    "use strict";
    var n = o(11);
    o.n(n).a
}, function(e, t, o) {
    t = e.exports = o(4)(!1);
    var n = o(6),
        i = n(o(31)),
        s = n(o(32));
    t.push([e.i, ".welcome-step-title[data-v-96576d9c]{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.welcome-step-header[data-v-96576d9c]{padding-top:24px;height:128px}.welcome-step-title[data-v-96576d9c]{color:#414b55;font-size:22px;line-height:36px;margin-bottom:6px}.welcome-step-desc[data-v-96576d9c]{color:#414b55;line-height:20px;padding:4px 0 4px 0}.welcome-step-body[data-v-96576d9c]{margin-left:12px;margin-right:12px;height:318px}.welcome-step-body .welcome-step-body-img[data-v-96576d9c]{width:376px;height:260px;margin-right:44px;background-position:0 0;background-repeat:no-repeat;float:left}.welcome-step-body .welcome-step-body-content[data-v-96576d9c]{width:500px;margin-top:28px;float:left;color:#414b55;line-height:20px;font-size:13px}.welcome-step-body .welcome-step-body-content .welcome-step-body-content-desc[data-v-96576d9c]{padding-top:4px;padding-bottom:4px;line-height:20px}.welcome-step-body .welcome-step-body-content .welcome-step-link[data-v-96576d9c]{margin-top:6px}.welcome-step-body .v-ps[data-v-96576d9c]{padding-right:12px}.welcome-step-body[data-v-96576d9c]{margin-right:0px}.welcome-step-body .welcome-step-body-content[data-v-96576d9c]{margin-top:0px;width:512px}.welcome-step-body .welcome-step-body-content .v-ps[data-v-96576d9c]{max-height:290px}.welcome-step-body .welcome-step-body-content .welcome-step-link[data-v-96576d9c]{line-height:28px;margin-top:24px}.welcome-step-body .welcome-step-body-content .blank[data-v-96576d9c]{height:28px}.welcome-step-body .welcome-step-body-img[data-v-96576d9c]{background-size:376px 260px;background-image:url(" + i + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .welcome-step-body .welcome-step-body-img[data-v-96576d9c]{background-image:url(" + s + ');background-size:image-width("../../images/default/1x/img_register.png") image-height("../../images/default/1x/img_register.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .welcome-step-body .welcome-step-body-img[data-v-96576d9c]{background-image:url(' + s + ');background-size:image-width("../../images/default/1x/img_register.png") image-height("../../images/default/1x/img_register.png");outline:1px green dashed}}\n', ""])
}, function(e, t) {
    e.exports = "webman/modules/WelcomeApp/images/assets/6cc1e64cb4ad2ceece5857521ea76c54.png"
}, function(e, t) {
    e.exports = "webman/modules/WelcomeApp/images/assets/0c5a3e5e54bb4c170be2984f0f277da2.png"
}, function(e, t, o) {
    "use strict";
    var n = o(12);
    o.n(n).a
}, function(e, t, o) {
    t = e.exports = o(4)(!1);
    var n = o(6),
        i = n(o(35)),
        s = n(o(36));
    t.push([e.i, ".welcome-step-title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.welcome-step-header{padding-top:24px;height:128px}.welcome-step-title{color:#414b55;font-size:22px;line-height:36px;margin-bottom:6px}.welcome-step-desc{color:#414b55;line-height:20px;padding:4px 0 4px 0}.welcome-step-body{margin-left:12px;margin-right:12px;height:318px}.welcome-step-body .welcome-step-body-img{width:376px;height:260px;margin-right:44px;background-position:0 0;background-repeat:no-repeat;float:left}.welcome-step-body .welcome-step-body-content{width:500px;margin-top:28px;float:left;color:#414b55;line-height:20px;font-size:13px}.welcome-step-body .welcome-step-body-content .welcome-step-body-content-desc{padding-top:4px;padding-bottom:4px;line-height:20px}.welcome-step-body .welcome-step-body-content .welcome-step-link{margin-top:6px}.welcome-step-body .v-ps{padding-right:12px}.welcome-step-udc .welcome-step-body .welcome-step-body-img{background-size:376px 260px;background-image:url(" + i + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .welcome-step-udc .welcome-step-body .welcome-step-body-img{background-image:url(" + s + ');background-size:image-width("../../images/default/1x/img_udc.png") image-height("../../images/default/1x/img_udc.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .welcome-step-udc .welcome-step-body .welcome-step-body-img{background-image:url(' + s + ');background-size:image-width("../../images/default/1x/img_udc.png") image-height("../../images/default/1x/img_udc.png");outline:1px green dashed}}.welcome-step-udc .welcome-step-body .welcome-step-udc-check{margin-top:6px}\n', ""])
}, function(e, t) {
    e.exports = "webman/modules/WelcomeApp/images/assets/fc5ed47d114bf32622a53ad48a7568df.png"
}, function(e, t) {
    e.exports = "webman/modules/WelcomeApp/images/assets/7268d07bba2a8fbefc9a13c2e93fb5b6.png"
}, function(e, t, o) {
    "use strict";
    var n = o(13);
    o.n(n).a
}, function(e, t, o) {
    t = e.exports = o(4)(!1);
    var n = o(6),
        i = n(o(39)),
        s = n(o(40));
    t.push([e.i, ".welcome-step-title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.welcome-step-header{padding-top:24px;height:128px}.welcome-step-title{color:#414b55;font-size:22px;line-height:36px;margin-bottom:6px}.welcome-step-desc{color:#414b55;line-height:20px;padding:4px 0 4px 0}.welcome-step-body{margin-left:12px;margin-right:12px;height:318px}.welcome-step-body .welcome-step-body-img{width:376px;height:260px;margin-right:44px;background-position:0 0;background-repeat:no-repeat;float:left}.welcome-step-body .welcome-step-body-content{width:500px;margin-top:28px;float:left;color:#414b55;line-height:20px;font-size:13px}.welcome-step-body .welcome-step-body-content .welcome-step-body-content-desc{padding-top:4px;padding-bottom:4px;line-height:20px}.welcome-step-body .welcome-step-body-content .welcome-step-link{margin-top:6px}.welcome-step-body .v-ps{padding-right:12px}.welcome-step-quickconnect .welcome-step-body .welcome-step-body-img{background-size:376px 260px;background-image:url(" + i + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .welcome-step-quickconnect .welcome-step-body .welcome-step-body-img{background-image:url(" + s + ');background-size:image-width("../../images/default/1x/img_quickconnect.png") image-height("../../images/default/1x/img_quickconnect.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .welcome-step-quickconnect .welcome-step-body .welcome-step-body-img{background-image:url(' + s + ');background-size:image-width("../../images/default/1x/img_quickconnect.png") image-height("../../images/default/1x/img_quickconnect.png");outline:1px green dashed}}.welcome-step-quickconnect .welcome-step-body .welcome-step-quickconnect-form{margin-top:24px}.welcome-step-quickconnect .welcome-step-body .welcome-step-quickconnect-form .v-textfield-input{width:136px}\n', ""])
}, function(e, t) {
    e.exports = "webman/modules/WelcomeApp/images/assets/d9da297f516969d26949b604b2f572b0.png"
}, function(e, t) {
    e.exports = "webman/modules/WelcomeApp/images/assets/db55578f3fea60b68a714c975a1784d3.png"
}, function(e, t, o) {
    "use strict";
    var n = o(14);
    o.n(n).a
}, function(e, t, o) {
    (e.exports = o(4)(!1)).push([e.i, ".welcome-step-title,.welcome-step-useful .welcome-step-useful-title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.welcome-step-header{padding-top:24px;height:128px}.welcome-step-title{color:#414b55;font-size:22px;line-height:36px;margin-bottom:6px}.welcome-step-desc{color:#414b55;line-height:20px;padding:4px 0 4px 0}.welcome-step-body{margin-left:12px;margin-right:12px;height:318px}.welcome-step-body .welcome-step-body-img{width:376px;height:260px;margin-right:44px;background-position:0 0;background-repeat:no-repeat;float:left}.welcome-step-body .welcome-step-body-content{width:500px;margin-top:28px;float:left;color:#414b55;line-height:20px;font-size:13px}.welcome-step-body .welcome-step-body-content .welcome-step-body-content-desc{padding-top:4px;padding-bottom:4px;line-height:20px}.welcome-step-body .welcome-step-body-content .welcome-step-link{margin-top:6px}.welcome-step-body .v-ps{padding-right:12px}.welcome-step-useful .welcome-step-header{height:fit-content;margin-bottom:12px}.welcome-step-useful .welcome-step-body-useful{float:left;width:920px;padding:12px}.welcome-step-useful .welcome-step-body-useful.text{line-height:20px;padding:10px 0 4px 0}.welcome-step-useful .welcome-step-body-useful.border-tier2{border-top:1px solid rgba(198,212,224,0.7)}.welcome-step-useful .welcome-step-body-useful.border-tier3{border-top:1px solid rgba(198,212,224,0.4)}.welcome-step-useful .welcome-step-useful-title{margin-right:28px;width:260px;float:left;font-size:16px;color:#414b55;line-height:28px}.welcome-step-useful .welcome-step-useful-desc{width:632px;float:left}.welcome-step-useful .welcome-step-useful-desc .welcome-step-body-content-desc{padding-top:4px;padding-bottom:4px;line-height:20px}.welcome-step-useful .welcome-step-useful-desc .v-btn{font-size:13px;margin-top:6px;margin-left:32px}\n", ""])
}, function(e, t, o) {
    "use strict";
    var n = o(15);
    o.n(n).a
}, function(e, t, o) {
    (e.exports = o(4)(!1)).push([e.i, ".welcome-step-title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.welcome-step-header{padding-top:24px;height:128px}.welcome-step-title{color:#414b55;font-size:22px;line-height:36px;margin-bottom:6px}.welcome-step-desc{color:#414b55;line-height:20px;padding:4px 0 4px 0}.welcome-step-body{margin-left:12px;margin-right:12px;height:318px}.welcome-step-body .welcome-step-body-img{width:376px;height:260px;margin-right:44px;background-position:0 0;background-repeat:no-repeat;float:left}.welcome-step-body .welcome-step-body-content{width:500px;margin-top:28px;float:left;color:#414b55;line-height:20px;font-size:13px}.welcome-step-body .welcome-step-body-content .welcome-step-body-content-desc{padding-top:4px;padding-bottom:4px;line-height:20px}.welcome-step-body .welcome-step-body-content .welcome-step-link{margin-top:6px}.welcome-step-body .v-ps{padding-right:12px}.welcome-network-form{padding-bottom:6px}.welcome-network-form .v-form-item-label{width:240px;margin-right:8px}.welcome-network-form .v-textfield-input{width:236px}.welcome-network-form .v-textfield-strength{padding-bottom:6px}.welcome-network-form .v-form-multi-wrapper .v-form-multi-item.small>div{margin-right:4px}\n", ""])
}, function(e, t, o) {
    "use strict";
    var n = o(16);
    o.n(n).a
}, function(e, t, o) {
    (e.exports = o(4)(!1)).push([e.i, ".welcome-step-title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.welcome-step-header{padding-top:24px;height:128px}.welcome-step-title{color:#414b55;font-size:22px;line-height:36px;margin-bottom:6px}.welcome-step-desc{color:#414b55;line-height:20px;padding:4px 0 4px 0}.welcome-step-body{margin-left:12px;margin-right:12px;height:318px}.welcome-step-body .welcome-step-body-img{width:376px;height:260px;margin-right:44px;background-position:0 0;background-repeat:no-repeat;float:left}.welcome-step-body .welcome-step-body-content{width:500px;margin-top:28px;float:left;color:#414b55;line-height:20px;font-size:13px}.welcome-step-body .welcome-step-body-content .welcome-step-body-content-desc{padding-top:4px;padding-bottom:4px;line-height:20px}.welcome-step-body .welcome-step-body-content .welcome-step-link{margin-top:6px}.welcome-step-body .v-ps{padding-right:12px}.syno-welcome-app .v-window-header-wrapper{display:none}.syno-welcome-app .v-window-body{background-color:#2b67d6;position:absolute;width:100%;height:100%;min-width:1024px;min-height:580px;box-sizing:border-box;display:flex;flex-direction:column;align-items:center;justify-content:center}.syno-welcome-app .v-window-body .v-spin-wrapper{display:flex;width:100%;height:100%;align-items:center;justify-content:center}.syno-welcome-app-wizard{height:580px;width:1024px;background-color:#fff;border-radius:4px;box-shadow:0 4px 20px 0 rgba(0,0,0,0.5)}.syno-welcome-app-wizard .headline-wrap{display:none}.syno-welcome-app-wizard .v-wizard-footer{border-top:none;height:86px;padding-right:32px}.syno-welcome-app-wizard .v-btn{font-size:14px}.syno-welcome-app-wizard .v-btn.v-btn-footbar{height:42px;margin:11px 0 22px 0}.syno-welcome-app-wizard .v-btn.v-btn-footbar.v-btn-blue{min-width:180px}.syno-welcome-app-wizard .v-btn.v-btn-footbar.v-btn-grey{margin-right:16px;min-width:120px}.syno-welcome-app-wizard .v-btn.v-btn-footbar span{padding:1px 24px 0 24px}.syno-welcome-app-wizard .fade-enter-active,.syno-welcome-app-wizard .fade-leave-active{transition:opacity 0.15s}.syno-welcome-app-wizard .fade-enter-active.v-wizard-step,.syno-welcome-app-wizard .fade-leave-active.v-wizard-step{position:absolute}.syno-welcome-app-wizard .fade-enter,.syno-welcome-app-wizard .fade-leave-to{opacity:0}\n", ""])
}, function(e, t, o) {
    "use strict";
    var n = o(17);
    o.n(n).a
}, function(e, t, o) {
    t = e.exports = o(4)(!1);
    var n = o(6),
        i = n(o(49)),
        s = n(o(50));
    t.push([e.i, ".welcome-step-title,.welcome-dialog-quickconnect .dialog .body .title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.welcome-step-header{padding-top:24px;height:128px}.welcome-step-title{color:#414b55;font-size:22px;line-height:36px;margin-bottom:6px}.welcome-step-desc{color:#414b55;line-height:20px;padding:4px 0 4px 0}.welcome-step-body{margin-left:12px;margin-right:12px;height:318px}.welcome-step-body .welcome-step-body-img{width:376px;height:260px;margin-right:44px;background-position:0 0;background-repeat:no-repeat;float:left}.welcome-step-body .welcome-step-body-content{width:500px;margin-top:28px;float:left;color:#414b55;line-height:20px;font-size:13px}.welcome-step-body .welcome-step-body-content .welcome-step-body-content-desc{padding-top:4px;padding-bottom:4px;line-height:20px}.welcome-step-body .welcome-step-body-content .welcome-step-link{margin-top:6px}.welcome-step-body .v-ps{padding-right:12px}.welcome-dialog-quickconnect.v-window{box-shadow:0 4px 15px 0 rgba(0,0,0,0.3);border-radius:8px}.welcome-dialog-quickconnect .v-window-header-wrapper{display:none}.welcome-dialog-quickconnect .dialog.v-panel{padding-top:0px}.welcome-dialog-quickconnect .dialog .body{width:500px;height:176px;margin-left:30px;margin-top:24px;margin-right:30px}.welcome-dialog-quickconnect .dialog .body .title{font-size:18px;line-height:24px;padding-bottom:12px}.welcome-dialog-quickconnect .dialog .body .desc{line-height:20px}.welcome-dialog-quickconnect .dialog .body .v-form{margin-top:10px}.welcome-dialog-quickconnect .dialog .body .v-form .v-form-item-label{width:210px;margin-right:8px}.welcome-dialog-quickconnect .dialog .body .v-form .v-textfield-input{width:222px}.welcome-dialog-quickconnect .dialog .body .v-form .btn{background-size:24px 48px;background-image:url(" + i + ");width:30px;height:28px;background-repeat:no-repeat;background-size:24px;background-position:2px 1px;border-radius:3px}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .welcome-dialog-quickconnect .dialog .body .v-form .btn{background-image:url(" + s + ');background-size:image-width("../../images/default/1x/menu_copy.png") image-height("../../images/default/1x/menu_copy.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .welcome-dialog-quickconnect .dialog .body .v-form .btn{background-image:url(' + s + ');background-size:image-width("../../images/default/1x/menu_copy.png") image-height("../../images/default/1x/menu_copy.png");outline:1px green dashed}}.welcome-dialog-quickconnect .dialog .fbar-wrapper{padding:20px 0px 20px 0px;margin:0 6px 0 30px;border-top:none}.welcome-dialog-quickconnect .dialog .fbar-wrapper .v-status-bar{padding-left:0px}\n', ""])
}, function(e, t) {
    e.exports = "webman/modules/WelcomeApp/images/assets/f079396a233851cd4cedca788edc0fd2.png"
}, function(e, t) {
    e.exports = "webman/modules/WelcomeApp/images/assets/171d77a8424d1bc7e6d159030642e4a6.png"
}, function(e, t, o) {
    "use strict";
    var n = o(18);
    o.n(n).a
}, function(e, t, o) {
    (e.exports = o(4)(!1)).push([e.i, ".syno-welcome-app-dialog .body-wrapper{height:245px}.syno-welcome-app-dialog .body-wrapper .advance-settings{margin-left:20px;margin-top:12px}.syno-welcome-app-dialog .body-wrapper .advance-settings .desc{padding-bottom:4px}.syno-welcome-app-dialog .body-wrapper .advance-settings .v-radio-wrapper{margin-top:12px}.syno-welcome-app-dialog .body-wrapper .advance-settings .v-form-item{margin-top:6px;margin-bottom:12px}.syno-welcome-app-dialog .body-wrapper .advance-settings .v-form-item-label{width:224px;margin-right:8px}.syno-welcome-app-dialog .body-wrapper .advance-settings .v-form-item-input{width:220px}.syno-welcome-app-dialog .fbar-wrapper{margin:0}\n", ""])
}, , , , , , , , , , , , , , , , , , , , , function(e, t, o) {
    "use strict";
    o.r(t);
    var n = function() {
        var e = this,
            t = e.$createElement,
            o = e._self._c || t;
        return o("v-app-instance", {
            attrs: {
                "syno-id": "welcome-app-instance",
                "class-name": "SYNO.SDS.App.WelcomeApp.Instance",
                fullsize: !0,
                "should-launch": e.shouldLaunch
            }
        }, [o("v-app-window", {
            ref: "appWindow",
            staticClass: "syno-welcome-app",
            attrs: {
                "syno-id": "welcome-app-window",
                closable: !1,
                "default-maximized": !0,
                resizable: !1
            }
        }, [o("v-spin", {
            attrs: {
                tip: e.T("common", "loading"),
                spinning: e.loading
            }
        }, [e.shouldShowWizard ? o("v-wizard", {
            ref: "quickStartWizard",
            staticClass: "syno-welcome-app-wizard",
            attrs: {
                "syno-id": "welcome-app-wizard",
                "active-step-key": e.activeStepKey,
                "custom-buttons-group": e.customButtonsGroup,
                "next-step-disabled": e.nextStepDisabled,
                "previous-step-disabled": e.previousStepDisabled
            }
        }, [e.isShowLoader ? o("loader", {
            attrs: {
                "is-show-cancel-btn": e.isShowCancelBtn,
                title: e.loaderTitle,
                body: e.loaderBody
            },
            on: {
                "on-cancel-btn": e.onLoaderCancel
            }
        }) : e._e(), e._v(" "), !e.isShowLoader && e.isAccountShow ? o("div", [o("welcome-page", {
            on: {
                "set-active-step-key": e.setActiveStepKey
            }
        }), e._v(" "), o("create-admin-account", {
            on: {
                "alert-message-box": e.onMessageBoxAlert,
                "custom-footer-buttons": e.customFooterButtons,
                "display-error": e.displayError,
                "is-doing-auth": e.setIsDoingAuth,
                "set-status": e.onSetStatus
            }
        })], 1) : e._e(), e._v(" "), o("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: !e.isShowLoader && !e.isAccountShow,
                expression: "!isShowLoader && !isAccountShow"
            }]
        }, [e.isSupportXa ? o("xa-set-static-ip", {
            on: {
                "custom-footer-buttons": e.customFooterButtons,
                "confirm-message-box": e.onMessageBoxConfirm,
                "display-error": e.displayError,
                "set-active-step-key": e.setActiveStepKey,
                "set-status": e.onSetStatus
            }
        }) : e._e(), e._v(" "), o("create-syno-account", {
            attrs: {
                "is-business-user": e.isBusinessUser
            },
            on: {
                "close-msg-box": e.closeMsgBox,
                "confirm-message-box": e.onMessageBoxConfirm,
                "custom-footer-buttons": e.customFooterButtons,
                "display-error": e.displayError,
                "set-active-step-key": e.setActiveStepKey,
                "set-status": e.onSetStatus,
                "set-loader": e.onSetLoader
            }
        }), e._v(" "), o("udc-settings", {
            on: {
                close: e.onClose,
                "custom-footer-buttons": e.customFooterButtons,
                "display-error": e.displayError,
                "set-loader": e.onSetLoader
            }
        }), e._v(" "), o("quickconnect-setup", {
            on: {
                "confirm-message-box": e.onMessageBoxConfirm,
                "custom-footer-buttons": e.customFooterButtons,
                "display-error": e.displayError,
                "set-active-step-key": e.setActiveStepKey,
                "set-status": e.onSetStatus,
                "show-quickconnect-created": e.onQuickconnectCreated
            }
        }), e._v(" "), o("useful-tools-settings", {
            on: {
                close: e.onClose,
                "custom-footer-buttons": e.customFooterButtons,
                "display-error": e.displayError,
                "set-loader": e.onSetLoader,
                "show-advance-settings": e.onAdvanceSettings
            }
        })], 1)], 1) : e._e()], 1)], 1)], 1)
    };
    n._withStripped = !0;
    var i = o(1),
        s = o(3),
        r = new(o.n(s).a.Store)({
            state: {
                encryption: {
                    encryptionCheck: "auto",
                    password: void 0
                },
                quickconnect: {
                    id: "",
                    account: "",
                    domain: "",
                    ddns_domain: "direct.quickconnect.to"
                },
                url: {
                    tos: "https://www.synology.com/company/legal/terms_conditions_account",
                    privacy: "https://www.synology.com/company/legal/privacy",
                    login: "",
                    register: "",
                    account: "https://account.synology.com/register"
                },
                networkInterface: {
                    ip: void 0,
                    mask: void 0,
                    gateway: void 0,
                    dns: void 0,
                    ifname: void 0,
                    enable_ha_ip: void 0,
                    is_default_gateway: void 0,
                    mtu: void 0,
                    enable_vlan: void 0,
                    use_dhcp: !1
                }
            },
            mutations: {
                setEncryption: function(e, t) {
                    t && t.password && (e.encryption.password = t.password), t && t.encryptionCheck && (e.encryption.encryptionCheck = t.encryptionCheck)
                },
                setQuickconnect: function(e, t) {
                    t.server_alias && (e.quickconnect.id = t.server_alias), t.domain && (e.quickconnect.domain = t.domain), t.ddns_domain && (e.quickconnect.ddns_domain = t.ddns_domain)
                },
                setQuickconnectAccount: function(e, t) {
                    e.quickconnect.account = t
                },
                setUrlRegister: function(e, t) {
                    e.url.register = t
                },
                setUrlLogin: function(e, t) {
                    e.url.login = t
                },
                setNetworkInterface: function(e, t) {
                    Object.keys(t).forEach((function(o) {
                        o in e.networkInterface && (e.networkInterface[o] = t[o])
                    })), e.networkInterface.use_dhcp = !1
                },
                clearPassword: function(e, t) {
                    e.encryption.password = ""
                }
            },
            getters: {
                getNetworkInterface: function(e) {
                    return e.networkInterface
                },
                getQuickconnect: function(e) {
                    return e.quickconnect
                }
            },
            strict: !0
        }),
        a = {
            methods: {
                endWelcome: function(e, t) {
                    this.appWin = e, this.setLoader = t, this.listTimeZone().then(this.setNTPTimeZone.bind(this)).then(this.setOtherDefaultSetting.bind(this)).then(this.getAuthKey.bind(this)).then(this.setNetworkSetting.bind(this)).then(function(t) {
                        !1 === t || this.waiting_for_reload ? this.setLoader(!0) : this.auth_key ? this.redirectQuickconnect() : this.need_redirect ? window.location.reload(!0) : !1 !== t && e.close()
                    }.bind(this))
                },
                setOtherDefaultSetting: function() {
                    return this.requestPromise({
                        compound: {
                            params: this.getWebAPIs(),
                            stopwhenerror: !1
                        }
                    }).then(function(e) {
                        SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PromotionApp", "show_upgrade_welcome", !1);
                        var t = "business" === _S("theme_cls");
                        SYNO.SDS.isBusinessModel === t ? (e && e.result && Ext.each(e.result, (function(e, t) {
                            "SYNO.Core.Region.NTP.DateTimeFormat" === e.api && e.success && (SYNO.SDS.Session.date_format = SYNO.SDS.DateTimeUtils.GetDateFormatByLang(_S("lang")), SYNO.SDS.Session.time_format = SYNO.SDS.DateTimeUtils.GetTimeFormatByLang(_S("lang")))
                        })), SYNO.SDS.Session.promotion_hide = !0) : this.need_redirect = !0
                    }.bind(this)).catch((function(e) {
                        SYNO.Debug(e)
                    }))
                },
                getWebAPIs: function() {
                    var e = new Date,
                        t = this.defaultLanguageSettingRequest(),
                        o = [{
                            api: "SYNO.Core.QuickStart.Info",
                            method: "check_permission",
                            version: 1,
                            callback: Ext.emptyFn
                        }, {
                            api: "SYNO.Core.QuickStart.Info",
                            method: "hide_welcome",
                            version: 1,
                            callback: Ext.emptyFn
                        }, {
                            api: "SYNO.Storage.CGI.Smart.Scheduler",
                            method: "set",
                            version: 1,
                            params: {
                                app: {
                                    task_name: "Auto S.M.A.R.T. Test",
                                    id: "-1",
                                    enabled: "true",
                                    test_style: "quick",
                                    test_range: "all",
                                    selected_disks: "",
                                    test_type: "smart"
                                },
                                basic: {
                                    task_name: "Auto S.M.A.R.T. Test",
                                    id: "-1",
                                    enabled: "true",
                                    test_style: "quick",
                                    test_range: "all",
                                    selected_disks: "",
                                    test_type: "smart"
                                },
                                schedule: {
                                    date: String.format("{0}/{1}/{2}", e.getFullYear(), e.getMonth() + 1, e.getDate()),
                                    repeat: 1,
                                    date_type: 1,
                                    hour: 0,
                                    min: 0,
                                    repeat_hour: 0,
                                    repeat_min: 0,
                                    last_work_hour: 0,
                                    repeat_min_store_config: [],
                                    repeat_hour_store_config: [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23]
                                }
                            },
                            callback: Ext.emptyFn
                        }, {
                            api: "SYNO.Core.Region.NTP.DateTimeFormat",
                            version: 1,
                            method: "set",
                            params: {
                                date_format: SYNO.SDS.DateTimeUtils.GetDateFormatByLang(_S("lang")),
                                time_format: SYNO.SDS.DateTimeUtils.GetTimeFormatByLang(_S("lang"))
                            }
                        }];
                    return null !== t && o.push(t), o
                },
                onSetNetworkFailed: function(e) {
                    var t = this;
                    return "no need to redirect" === e || (this.$emit("set-loader", !1), this.appWin.getMsgBox().alert("error", _T("welcome", "apply_network_failed")).then((function() {
                        t.appWin.close()
                    })), !1)
                },
                setNetworkSetting: function() {
                    if (!r.getters.getNetworkInterface || !r.getters.getNetworkInterface.ip) return this.$emit("set-loader", !1), !0;
                    var e = {
                        api: "SYNO.Core.Network.Ethernet",
                        method: "set",
                        version: 1,
                        params: {
                            configs: [r.getters.getNetworkInterface]
                        }
                    };
                    return this.$emit("set-loader", !0), this.requestPromise(e).then(this.redirect.bind(this)).catch(this.onSetNetworkFailed.bind(this))
                },
                getBrowserTimeZone: function(e) {
                    var t, o, n, i, s = "Dublin";
                    return t = (new Date).getFullYear(), Ext.isNumber(t) && (o = new Date(t, 0, 1).getTimezoneOffset(), n = new Date(t, 6, 1).getTimezoneOffset()), Ext.isNumber(o) && Ext.isNumber(n) && (i = -1 * Math.max(o, n) * 60), 28800 === i && "chs" === _S("lang") ? "Beijing" : (Ext.each(e, (function(e, t, o) {
                        if (e.offset === i) return s = e.value, !1
                    }), this), s)
                },
                requestPromise: function(e) {
                    return new Promise((function(t, o) {
                        SYNO.API.Request(Ext.apply(e, {
                            callback: function(e, n) {
                                e ? t(n) : o(n)
                            },
                            scope: this
                        }))
                    }))
                },
                listTimeZone: function() {
                    return this.requestPromise({
                        api: "SYNO.Core.Region.NTP",
                        version: 1,
                        method: "listzone"
                    }).then(function(e) {
                        var t = e.zonedata;
                        return this.getBrowserTimeZone(t)
                    }.bind(this)).catch(function() {
                        return "Dublin"
                    }.bind(this))
                },
                setNTPTimeZone: function(e) {
                    var t, o;
                    return "Beijing" === e ? (t = "set", o = {
                        timezone: e,
                        enable_ntp: "ntp",
                        server: "pool.ntp.org"
                    }) : (t = "setzone", o = {
                        timezone: e
                    }), this.requestPromise({
                        api: "SYNO.Core.Region.NTP",
                        version: 1,
                        method: t,
                        params: o
                    }).catch((function(t) {
                        SYNO.Debug("Unable to set NTP time zone to: " + e), SYNO.Debug(t)
                    }))
                },
                defaultLanguageSettingRequest: function() {
                    if (SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.WelcomeApp.Instance", "welcome_dsm50_hide")) return null;
                    var e = _S("lang"),
                        t = "enu",
                        o = "enu",
                        n = SYNO.SDS.Utils.getSupportedLanguage(0),
                        i = SYNO.SDS.Utils.getSupportedLanguageCodepage(0);
                    return Ext.each(n, (function(o) {
                        if (o[0] === e) return t = o[0], !1
                    }), this), Ext.each(i, (function(t) {
                        if (t[0] === e) return o = t[0], !1
                    }), this), {
                        api: "SYNO.Core.Region.Language",
                        version: 1,
                        method: "set",
                        params: {
                            language: "def",
                            maillang: t,
                            codepage: o
                        }
                    }
                },
                redirect: function(e) {
                    if (!e) throw "no need to redirect";
                    var t = e.redirect,
                        o = e.secure,
                        n = e.ip_list,
                        i = e.port,
                        s = e.auth_key,
                        r = 15e3,
                        a = 0;
                    if (!(Ext.isBoolean(o) && Ext.isArray(n) && Ext.isString(i) && Ext.isString(s))) throw "bad parameters";
                    if (!t) throw o = "https:" === location.protocol, n = [location.hostname], i = location.port, "no need to redirect";
                    if (this.auth_key) this.redirectQuickconnect();
                    else {
                        SYNO.SDS.StatusNotifier.fireEvent("redirect"), window.onbeforeunload = null;
                        var c = function(e) {
                            var t = "http" + (!0 === o ? "s" : ""),
                                r = String.format("{0}://{1}:{2}/index.cgi?auth_key={3}", t, n[e % n.length], i, s);
                            window.location = r
                        };
                        for (c.defer(r, this, [0]), a = 0; a < 3; a++) c.defer(r += 1e4, this, [0]);
                        for (a = 1; a <= n.length; a++) c.defer(r += 1e4, this, [a])
                    }
                    this.waiting_for_reload = !0
                },
                getAuthKey: function() {
                    if (this.auth_key = "", Ext.form.VTypes.v4ip(location.hostname) && r.getters.getQuickconnect) {
                        var e = r.getters.getQuickconnect,
                            t = e.id,
                            o = e.domain;
                        if (t && o) return this.requestPromise({
                            api: "SYNO.API.Auth.Key",
                            version: 7,
                            method: "get"
                        }).then(function(e) {
                            this.auth_key = e.auth_key || this.auth_key
                        }.bind(this)).catch((function(e) {
                            SYNO.Debug(e)
                        }))
                    }
                    return !0
                },
                redirectQuickconnect: function() {
                    var e = this;
                    return synowebapi.promises.request({
                        api: "SYNO.Core.QuickConnect",
                        method: "get",
                        version: 2
                    }).then((function(t) {
                        r.commit("setQuickconnect", t);
                        var o = r.getters.getQuickconnect,
                            n = o.id,
                            i = o.domain,
                            s = o.ddns_domain,
                            a = location.hostname.replaceAll(".", "-"),
                            c = "https://".concat(a, ".").concat(n, ".").concat(s, ":5001/webman/pingpong.cgi?action=cors&quickconnect=true");
                        return e.requestPromise({
                            api: "SYNO.Core.Web.DSM",
                            version: 2,
                            method: "set",
                            params: {
                                enable_https_redirect: !0
                            }
                        }).then((function() {
                            e.pingpong((function() {
                                SYNO.SDS.StatusNotifier.fireEvent("redirect"), window.onbeforeunload = null, window.location = "https://".concat(i, "/").concat(n, "?auth_key=").concat(e.auth_key)
                            }), 0, c)
                        })).catch(function(e) {
                            this.appWin.close(), SYNO.Debug(e)
                        }.bind(e))
                    })).catch((function(e) {
                        SYNO.Debug.error(e)
                    }))
                },
                pingpong: function(e, t, o) {
                    var n = this;
                    if (t >= 12) return e();
                    synowebapi.create().request({
                        requestFormat: "raw",
                        url: o,
                        timeout: 1e4,
                        callback: function(i, s) {
                            if (i) return e();
                            window.setTimeout((function() {
                                n.pingpong(e, t + 1, o)
                            }), 5e3)
                        }
                    })
                }
            }
        },
        c = o(2),
        p = function() {
            var e = this,
                t = e.$createElement,
                o = e._self._c || t;
            return o("v-wizard-step", {
                staticClass: "welcome-app-welcome-page",
                attrs: {
                    "syno-id": "welcome-app-welcome-page-wizard-step",
                    "next-step-key": "create_admin_account",
                    "show-footer": !1,
                    "show-transition": !0,
                    "step-key": "welcome_page"
                }
            }, [e.isShowLoader ? o("loader", {
                attrs: {
                    body: e.loaderBody,
                    "is-show-cancel-btn": !1,
                    title: e.loaderTitle
                }
            }) : o("div", {
                staticClass: "welcome-page"
            }, [o("div", {
                staticClass: "welcome-page-content"
            }, [o("div", {
                staticClass: "welcome-page-title"
            }, [e._v(e._s(e.T("welcome", "promotion_welcome_title_normal")))]), e._v(" "), o("div", {
                staticClass: "welcome-page-desc"
            }, [e._v(e._s(e.T("welcome", "promotion_welcome_subtitle_normal")))]), e._v(" "), o("br"), e._v(" "), o("v-button", {
                staticClass: "welcome-page-btn",
                attrs: {
                    "syno-id": "quick-start-wizard-steps-welcome-page-button-0",
                    suffix: "blue",
                    type: "footbar",
                    disabled: e.isShowLoader
                },
                on: {
                    click: e.onStart
                }
            }, [e._v("\n                " + e._s(e.T("common", "start")) + "\n            ")]), e._v(" "), o("br"), e._v(" "), o("span", {
                staticClass: "whats-new-link",
                domProps: {
                    innerHTML: e._s(e.whatsNewLink)
                }
            })], 1), e._v(" "), o("div", {
                staticClass: "welcome-page-logo"
            })])], 1)
        };
    p._withStripped = !0;
    var l = function() {
        var e = this,
            t = e.$createElement,
            o = e._self._c || t;
        return o("div", {
            staticClass: "quick-start-loader"
        }, [e._m(0), e._v(" "), o("div", {
            staticClass: "quick-start-loader-title"
        }, [e._v(e._s(e.loadTitle))]), e._v(" "), e.isShowCancelBtn ? o("v-button", {
            staticClass: "v-btn-footbar v-btn-cancel quick-start-loader-btn",
            attrs: {
                "syno-id": "welcome-app-loading-cancel-btn"
            },
            on: {
                click: e.onCancel
            }
        }, [e._v("\n        " + e._s(e.T("common", "cancel")) + "\n    ")]) : e._e(), e._v(" "), e.body ? o("div", {
            staticClass: "quick-start-loader-body"
        }, [e._v("\n        " + e._s(e.body) + "\n    ")]) : e._e()], 1)
    };
    l._withStripped = !0;
    var d = {
            mixins: [i.a],
            props: {
                isShowCancelBtn: {
                    type: Boolean,
                    default: !0
                },
                title: {
                    type: String,
                    default: void 0
                },
                body: {
                    type: String,
                    default: void 0
                }
            },
            computed: {
                loadTitle: function() {
                    return this.title || this.T("welcome", "loading")
                }
            },
            methods: {
                onCancel: function() {
                    this.isShowCancelBtn && this.$emit("on-cancel-btn")
                }
            }
        },
        u = (o(21), o(0)),
        m = Object(u.a)(d, l, [function() {
            var e = this.$createElement,
                t = this._self._c || e;
            return t("div", {
                staticClass: "quick-start-loader-animation"
            }, [t("div", {
                staticClass: "quick-start-spinner1"
            }), this._v(" "), t("div", {
                staticClass: "quick-start-spinner2"
            }), this._v(" "), t("div", {
                staticClass: "quick-start-spinner3"
            })])
        }], !1, null, null, null);
    m.options.__file = "src/components/loader.vue";
    var h = m.exports;

    function f(e, t, o, n, i, s, r) {
        try {
            var a = e[s](r),
                c = a.value
        } catch (e) {
            return void o(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(n, i)
    }
    var g, w, v = {
            components: {
                loader: h
            },
            mixins: [i.a],
            data: function() {
                return {
                    isShowLoader: !0,
                    loaderTitle: void 0,
                    loaderBody: void 0,
                    current: 0,
                    total: 1,
                    disabledBtn: !1,
                    whatsNewLink: String.format(this.T("welcome", "see_what_new"), '<a href="https://sy.to/dsm7new" target="_blank" rel="noopener noreferrer">', "</a>")
                }
            },
            mounted: function() {
                this.$options.onPkgChanged = this.onPkgChanged.bind(this), SYNO.SDS.SocketInst.registerSDKEvent("package_progress_changed", this.$options.onPkgChanged), setTimeout(function() {
                    this.unregisterPkgchanged()
                }.bind(this), 6e5), this.getPkgStatus()
            },
            methods: {
                getPkgStatus: (g = regeneratorRuntime.mark((function e() {
                    var t, o, n;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.prev = 0, e.next = 3, synowebapi.promises.request({
                                    api: "SYNO.Entry.Request",
                                    method: "request",
                                    version: 1,
                                    compound: {
                                        mode: "sequential",
                                        stopwhenerror: !0,
                                        params: [{
                                            api: "SYNO.Core.Package.Progress",
                                            method: "get",
                                            version: 1,
                                            params: {
                                                jobname: "install_low_builtin_pkgs"
                                            }
                                        }, {
                                            api: "SYNO.Core.Package.Progress",
                                            method: "get",
                                            version: 1,
                                            params: {
                                                jobname: "start_all_pkgs"
                                            }
                                        }]
                                    }
                                });
                            case 3:
                                (t = e.sent) && !1 === t.has_fail ? (o = t.result[0], n = t.result[1], this.onPkgChanged(n.data), this.onPkgChanged(o.data)) : this.unregisterPkgchanged(), e.next = 10;
                                break;
                            case 7:
                                e.prev = 7, e.t0 = e.catch(0), this.unregisterPkgchanged();
                            case 10:
                            case "end":
                                return e.stop()
                        }
                    }), e, this, [
                        [0, 7]
                    ])
                })), w = function() {
                    var e = this,
                        t = arguments;
                    return new Promise((function(o, n) {
                        var i = g.apply(e, t);

                        function s(e) {
                            f(i, o, n, s, r, "next", e)
                        }

                        function r(e) {
                            f(i, o, n, s, r, "throw", e)
                        }
                        s(void 0)
                    }))
                }, function() {
                    return w.apply(this, arguments)
                }),
                onPkgChanged: function(e) {
                    if (!e) return this.unregisterPkgchanged();
                    var t = e.job,
                        o = e.status,
                        n = e.current,
                        i = e.total;
                    "install_low_builtin_pkgs" === t && "running" === o ? (this.current = Math.max(n || 0, this.current), this.total = Math.max(i || 0, this.total, this.current), this.loaderTitle = String.format(this.T("welcome", "installing_pkgs_title"), this.current, this.total), this.loaderBody = this.T("welcome", "installing_pkgs_body")) : "install_low_builtin_pkgs" === t && "finished" === o || "start_all_pkgs" === t && "not_started" === o ? (this.loaderTitle = this.T("welcome", "starting_pkgs"), this.loaderBody = "") : "install_low_builtin_pkgs" === t && "not_started" === o ? (this.loaderTitle = this.T("welcome", "waiting_install_pkgs"), this.loaderBody = "") : this.unregisterPkgchanged()
                },
                unregisterPkgchanged: function() {
                    this.isShowLoader = !1, SYNO.SDS.SocketInst.unregister("package_progress_changed", this.$options.onPkgChanged)
                },
                onStart: function() {
                    this.$emit("set-active-step-key", "create_admin_account")
                }
            }
        },
        b = (o(23), Object(u.a)(v, p, [], !1, null, "0726dce0", null));
    b.options.__file = "src/quick-start-wizard-steps/welcome-page.vue";
    var x = b.exports,
        y = function() {
            var e = this,
                t = e.$createElement,
                o = e._self._c || t;
            return o("v-wizard-step", {
                attrs: {
                    "syno-id": "welcome-app-create-admin-wizard-step",
                    finished: e.finished,
                    "show-transition": !0,
                    "step-key": "create_admin_account"
                },
                on: {
                    activate: e.showFooter
                }
            }, [o("div", {
                staticClass: "welcome-step-header"
            }, [o("div", {
                staticClass: "welcome-step-title"
            }, [e._v("\n            " + e._s(String.format(e.T("welcome", "welcome_admin_account_title"), e.D("product"))) + "\n        ")]), e._v(" "), o("div", {
                staticClass: "welcome-step-desc"
            }, [e._v(e._s(e.T("welcome", "create_admin_desc")))])]), e._v(" "), o("v-form", {
                ref: "form",
                staticClass: "welcome-step-body welcome-admin-form",
                attrs: {
                    "syno-id": "welcome-app-create-admin-form",
                    rules: e.rules
                }
            }, [e.isDocker ? e._e() : o("v-form-item", {
                attrs: {
                    "syno-id": "welcome-app-create-device-name-item",
                    prop: "deviceName",
                    label: e.T("user", "device_name") + ":"
                }
            }, [o("v-input", {
                attrs: {
                    name: "device_name",
                    "syno-id": "welcome-app-create-device-name-input",
                    "fit-container": "",
                    maxlength: e.deviceNameMaxLength
                },
                model: {
                    value: e.fields.deviceName,
                    callback: function(t) {
                        e.$set(e.fields, "deviceName", t)
                    },
                    expression: "fields.deviceName"
                }
            })], 1), e._v(" "), o("v-form-item", {
                attrs: {
                    "syno-id": "welcome-app-create-nas-account-item",
                    prop: "nasAccount",
                    label: e.T("user", "nas_account") + ":"
                }
            }, [o("v-input", {
                attrs: {
                    name: "nas_account",
                    "syno-id": "welcome-app-create-nas-account-input",
                    "fit-container": "",
                    maxlength: e.nasNameMaxLength
                },
                model: {
                    value: e.fields.nasAccount,
                    callback: function(t) {
                        e.$set(e.fields, "nasAccount", t)
                    },
                    expression: "fields.nasAccount"
                }
            })], 1), e._v(" "), o("v-form-item", {
                attrs: {
                    "syno-id": "welcome-app-create-password-item",
                    prop: "password",
                    label: e.T("user", "user_passwd") + ":"
                }
            }, [o("v-input", {
                attrs: {
                    name: "password",
                    "syno-id": "welcome-app-create-password-input",
                    type: "password",
                    "fit-container": "",
                    maxlength: e.passwordMaxLength,
                    "strength-checker": e.strengthChecker
                },
                model: {
                    value: e.fields.password,
                    callback: function(t) {
                        e.$set(e.fields, "password", t)
                    },
                    expression: "fields.password"
                }
            })], 1), e._v(" "), o("v-form-item", {
                attrs: {
                    "syno-id": "welcome-app-create-confirm-password-item",
                    prop: "confirmPassword",
                    label: e.T("user", "user_repswd") + ":"
                }
            }, [o("v-input", {
                attrs: {
                    name: "password",
                    "syno-id": "welcome-app-create-confirm-password-input",
                    type: "password",
                    "fit-container": "",
                    maxlength: e.passwordMaxLength
                },
                model: {
                    value: e.fields.confirmPassword,
                    callback: function(t) {
                        e.$set(e.fields, "confirmPassword", t)
                    },
                    expression: "fields.confirmPassword"
                }
            })], 1)], 1)], 1)
        };

    function k(e) {
        for (var t = 1; t < arguments.length; t++) {
            var o = null != arguments[t] ? Object(arguments[t]) : {},
                n = Object.keys(o);
            "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(o).filter((function(e) {
                return Object.getOwnPropertyDescriptor(o, e).enumerable
            })))), n.forEach((function(t) {
                _(e, t, o[t])
            }))
        }
        return e
    }

    function _(e, t, o) {
        return t in e ? Object.defineProperty(e, t, {
            value: o,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = o, e
    }

    function S(e, t, o, n, i, s, r) {
        try {
            var a = e[s](r),
                c = a.value
        } catch (e) {
            return void o(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(n, i)
    }

    function C(e) {
        return function() {
            var t = this,
                o = arguments;
            return new Promise((function(n, i) {
                var s = e.apply(t, o);

                function r(e) {
                    S(s, n, i, r, a, "next", e)
                }

                function a(e) {
                    S(s, n, i, r, a, "throw", e)
                }
                r(void 0)
            }))
        }
    }
    y._withStripped = !0;
    var q, O, T = {
            mixins: [i.a, c.a],
            data: function() {
                return {
                    deviceNameMaxLength: 15,
                    nasNameMaxLength: 64,
                    passwordMaxLength: 127,
                    isDocker: "yes" === _D("dockerdsm"),
                    fields: {
                        deviceName: null,
                        nasAccount: null,
                        password: void 0,
                        confirmPassword: void 0
                    },
                    rules: {
                        deviceName: {
                            required: !0,
                            validator: this.validateDeviceName
                        },
                        nasAccount: {
                            required: !0,
                            validator: this.validateNasAccount,
                            usedname: []
                        },
                        password: {
                            required: !0,
                            validator: this.validatePassword
                        },
                        confirmPassword: {
                            required: !0,
                            validator: this.validateConfirmPassword
                        },
                        exclude_username: !0,
                        min_length: 6,
                        min_length_enable: !0
                    }
                }
            },
            mounted: (O = C(regeneratorRuntime.mark((function e() {
                return regeneratorRuntime.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return e.next = 2, this.getPasswordPolicy();
                        case 2:
                            this.validator = new SYNO.SDS.Utils.CheckStrongPassword, this.validator.passwordPolicy = k({}, this.rules);
                        case 4:
                        case "end":
                            return e.stop()
                    }
                }), e, this)
            }))), function() {
                return O.apply(this, arguments)
            }),
            methods: {
                showFooter: function() {
                    this.$emit("custom-footer-buttons", {
                        next: {
                            text: _T("common", "next"),
                            show: !0
                        }
                    })
                },
                validateDeviceName: function(e, t, o) {
                    try {
                        return this.fields.deviceName ? !!Ext.form.VTypes.netbiosName(this.fields.deviceName) || new Error(this.T("user", "error_invalid_device_name")) : new Error(this.T("user", "error_no_device_name"))
                    } catch (e) {
                        SYNO.Debug.error(e)
                    }
                },
                validateNasAccount: function(e, t, o) {
                    try {
                        if (!this.fields.nasAccount) return new Error(this.T("user", "error_no_nas_account"));
                        var n = this.fields.nasAccount.toLowerCase();
                        return "admin" === n || "root" === n ? new Error(String.format(this.T("user", "error_dont_use_admin"), n)) : this.rules.nasAccount.usedname.indexOf(this.fields.nasAccount) >= 0 ? new Error(this.T("user", "error_nameused")) : !!Ext.form.VTypes.username(this.fields.nasAccount) || new Error(this.T("user", "error_bad_nas_account"))
                    } catch (e) {
                        SYNO.Debug.error(e)
                    }
                },
                validatePassword: function(e, t, o) {
                    try {
                        if (!this.fields.password || this.fields.password.length < this.rules.min_length) return !0 !== this.rules.min_length_enable || new Error(this.T("passwd", "min_length_enable") + " " + this.rules.min_length);
                        var n = this.validator.isPasswordValid(this.fields.password, this.fields.nasAccount, this.fields.nasAccount);
                        return !0 === n || new Error(n)
                    } catch (e) {
                        SYNO.Debug.error(e)
                    }
                },
                validateConfirmPassword: function(e, t, o) {
                    try {
                        return !this.fields.password || (this.fields.password === this.fields.confirmPassword || new Error(_JSLIBSTR("vtype", "password_confirm_failed")))
                    } catch (e) {
                        SYNO.Debug.error(e)
                    }
                },
                finished: (q = C(regeneratorRuntime.mark((function e() {
                    var t, o = this;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return t = function(e) {
                                    e.onGotoNextPage()
                                }, e.next = 3, this.$refs.form.validate();
                            case 3:
                                if (e.sent) {
                                    e.next = 6;
                                    break
                                }
                                return e.abrupt("return", !1);
                            case 6:
                                return this.$emit("set-status", "busy"), synowebapi.promises.request({
                                    api: "SYNO.Core.User",
                                    method: "get",
                                    version: "1",
                                    params: {
                                        name: this.fields.nasAccount
                                    }
                                }).then((function(e) {
                                    o.$emit("set-status", "clear");
                                    for (var t = 0; t < e.users.length; ++t) - 1 === o.rules.nasAccount.usedname.indexOf(e.users[t].name) && o.rules.nasAccount.usedname.push(e.users[t].name);
                                    o.$refs.form.validate()
                                })).catch((function(e) {
                                    t(o)
                                })), e.abrupt("return", !1);
                            case 9:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return q.apply(this, arguments)
                }),
                getPasswordPolicy: function() {
                    var e = this;
                    return synowebapi.promises.request({
                        api: "SYNO.Core.User.PasswordPolicy",
                        method: "get",
                        version: 1
                    }).then((function(t) {
                        var o = t.strong_password || {};
                        o.strong_password_enable = Object.keys(o).length > 0, Object.assign(e.rules, o)
                    })).catch((function(e) {
                        SYNO.Debug.error(e.stack)
                    }))
                },
                getCreateAdminRequests: function() {
                    var e = [{
                        api: "SYNO.Core.Security.AutoBlock",
                        method: "set",
                        version: 1,
                        params: {
                            attempts: 10,
                            enable: !0,
                            enable_expire: !1,
                            within_mins: 5
                        }
                    }];
                    return "yes" !== _D("dockerdsm") && e.push({
                        api: "SYNO.Core.Network",
                        method: "set",
                        version: 1,
                        params: {
                            server_name: this.fields.deviceName
                        }
                    }), e = e.concat([{
                        api: "SYNO.Core.User",
                        method: "set",
                        version: 1,
                        params: {
                            name: "admin",
                            password: function() {
                                var e = function(e) {
                                        return Math.floor(Math.random() * e)
                                    },
                                    t = "abcdefghijklmnopqrstuvwxyz",
                                    o = "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
                                    n = "~`!@#$%^&*()-_+={[}]|\\:;\"'<,>.?/",
                                    i = "1234567890" + t + o + n,
                                    s = 16 + e(32),
                                    r = [],
                                    a = 0;
                                for (Ext.each(["1234567890", t, o, n], (function(t) {
                                        r[a++] = t[e(t.length)]
                                    })); a < s;) r[a++] = i[e(i.length)];
                                for (; 0 !== a;) {
                                    var c = e(a--),
                                        p = r[a];
                                    r[a] = r[c], r[c] = p
                                }
                                return r.join("")
                            }()
                        }
                    }, {
                        api: "SYNO.Core.User",
                        method: "create",
                        version: 1,
                        params: {
                            name: this.fields.nasAccount,
                            password: this.fields.password
                        }
                    }, {
                        api: "SYNO.Core.Group.Member",
                        method: "add",
                        version: 1,
                        params: {
                            group: "administrators",
                            name: [this.fields.nasAccount]
                        }
                    }, {
                        api: "SYNO.Core.User",
                        method: "set",
                        version: 1,
                        params: {
                            expired: "now",
                            name: "admin"
                        }
                    }])
                },
                onGotoNextPage: function() {
                    var e = this,
                        t = function() {
                            "yes" !== _D("dockerdsm") && (SYNO.SDS.Session.hostname = this.fields.deviceName);
                            var e = _S("custom_login_title") || _D("manager") + " - " + _S("hostname");
                            document.title = this.htmlEncode(e)
                        }.bind(this),
                        o = function(e) {
                            var t = this;
                            this.$emit("alert-message-box", this.T("error", "error_error"), SYNO.API.getErrorString(SYNO.API.Response.GetFirstError(e)), (function() {
                                t.$emit("set-status", "clear"), window.location.reload()
                            }))
                        }.bind(this);
                    SYNO.SDS.StatusNotifier.fireEvent("halt"), synowebapi.promises.request({
                        api: "SYNO.Entry.Request",
                        version: 1,
                        method: "request",
                        encryption: ["password"],
                        compound: {
                            stopwhenerror: !1,
                            params: this.getCreateAdminRequests()
                        }
                    }).then((function(n) {
                        t(), n.has_fail ? o(n) : e.doAuth()
                    })).catch((function(e) {
                        t(), o(e)
                    }))
                },
                doAuth: function() {
                    this.$emit("is-doing-auth", !0), window.location.origin || (window.location.origin = window.location.protocol + "//" + window.location.hostname + (window.location.port ? ":" + window.location.port : ""));
                    var e = (new Date).getTime(),
                        t = {
                            account: this.fields.nasAccount,
                            passwd: this.fields.password
                        };
                    synowebapi.request({
                        url: "webapi/entry.cgi?api=SYNO.API.Auth",
                        requestFormat: "raw",
                        responseFormat: "raw",
                        method: "POST",
                        params: SYNO.SDS.HandShake.GetLoginParams(t),
                        encryption: Object.keys(t),
                        callback: function() {
                            window.location.href = "/?dc=" + e
                        }
                    })
                }
            }
        },
        N = (o(25), Object(u.a)(T, y, [], !1, null, null, null));
    N.options.__file = "src/quick-start-wizard-steps/create-admin-account.vue";
    var P = N.exports,
        A = function() {
            var e = this,
                t = e.$createElement,
                o = e._self._c || t;
            return o("v-wizard-step", {
                attrs: {
                    "syno-id": "welcome-app-create-syno-step",
                    "next-step-key": e.nextStepKey,
                    "pre-enter-next-step": e.prepareToNext,
                    "pre-enter-previous-step": e.prepareToPre,
                    "show-transition": !0,
                    "step-key": "create_syno_account"
                },
                on: {
                    activate: e.getNetworkStatus
                }
            }, [e.isShowSynoAccountStep ? o("div", [o("div", {
                staticClass: "welcome-step-header"
            }, [o("div", {
                staticClass: "welcome-step-title"
            }, [e._v("\n                " + e._s(e.T("welcome", "create_syno_account_title")) + "\n            ")]), e._v(" "), o("div", {
                staticClass: "welcome-step-desc",
                domProps: {
                    innerHTML: e._s(e.descText)
                }
            })]), e._v(" "), o("div", {
                staticClass: "welcome-step-body"
            }, [o("div", {
                staticClass: "welcome-step-body-img"
            }), e._v(" "), o("div", {
                staticClass: "welcome-step-body-content"
            }, [o("v-perfect-scrollbar", [o("div", {
                staticClass: "blank"
            }), e._v(" "), o("icon-title-desc", {
                attrs: {
                    title: e.T("welcome", "secure_signin"),
                    desc: e.T("welcome", "secure_signin_desc"),
                    icon: "secure_signin"
                }
            }), e._v(" "), o("icon-title-desc", {
                attrs: {
                    title: e.T("welcome", e.isBusinessUser || !e.supportMib ? "take_advantage_services" : "access_anywhere"),
                    desc: e.T("welcome", e.isBusinessUser || !e.supportMib ? "take_advantage_services_desc" : "access_anywhere_desc"),
                    icon: e.isBusinessUser || !e.supportMib ? "services" : "access"
                }
            }), e._v(" "), o("icon-title-desc", {
                attrs: {
                    title: e.T("welcome", e.supportMib ? "active_insight" : "access_anywhere"),
                    desc: e.T("welcome", e.supportMib ? "active_insight_desc" : "access_anywhere_desc"),
                    icon: e.supportMib ? "protection" : "access"
                }
            })], 1), e._v(" "), o("div", {
                ref: "linkText",
                staticClass: "welcome-step-link",
                domProps: {
                    innerHTML: e._s(e.linkText)
                }
            })], 1)])]) : e._e()])
        };
    A._withStripped = !0;
    var Y = function() {
        var e = this,
            t = e.$createElement,
            o = e._self._c || t;
        return o("div", {
            staticClass: "content-body"
        }, [o("div", {
            staticClass: "content-icon",
            class: {
                "active-insight": "protection" === e.icon, "business-user": "access" === e.icon, "normal-user": "services" === e.icon, "secure-signin": "secure_signin" === e.icon
            }
        }, [o("img", {
            staticClass: "content-img",
            attrs: {
                src: e.iconPath
            }
        })]), e._v(" "), o("div", {
            staticClass: "content-text"
        }, [o("div", {
            staticClass: "content-title"
        }, [e._v(e._s(e.title))]), e._v(" "), o("div", {
            staticClass: "content-desc"
        }, [e._v(e._s(e.desc))])])])
    };
    Y._withStripped = !0;
    var $ = {
            props: {
                icon: {
                    type: String,
                    default: ""
                },
                title: {
                    type: String,
                    default: ""
                },
                desc: {
                    type: String,
                    default: ""
                }
            },
            computed: {
                iconPath: function() {
                    return "../../../webman/modules/WelcomeApp/images/" + (SYNO.SDS.UIFeatures.test("isRetina") ? "2x/" : "1x/") + ("icn_" + this._props.icon + ".png")
                }
            }
        },
        D = (o(27), Object(u.a)($, Y, [], !1, null, null, null));

    function B(e, t, o, n, i, s, r) {
        try {
            var a = e[s](r),
                c = a.value
        } catch (e) {
            return void o(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(n, i)
    }

    function E(e) {
        return function() {
            var t = this,
                o = arguments;
            return new Promise((function(n, i) {
                var s = e.apply(t, o);

                function r(e) {
                    B(s, n, i, r, a, "next", e)
                }

                function a(e) {
                    B(s, n, i, r, a, "throw", e)
                }
                r(void 0)
            }))
        }
    }

    function I(e, t, o) {
        return t in e ? Object.defineProperty(e, t, {
            value: o,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = o, e
    }
    D.options.__file = "src/components/icon-title-desc.vue";
    var z, R, L, j, M, U, W, F, Q = {
            components: {
                "icon-title-desc": D.exports
            },
            mixins: [i.a, c.a],
            props: {
                isBusinessUser: Boolean
            },
            data: function() {
                return {
                    isConnectingInternet: !1,
                    isGettingNetwork: !0,
                    isLoading: !1,
                    connectingFooterBtnGroup: {
                        back: {
                            text: this.T("common", "skip"),
                            show: !0
                        },
                        next: {
                            text: this.T("common", "create")
                        }
                    },
                    notConnectingFooterBtnGroup: {
                        next: {
                            text: this.T("welcome", "got_it")
                        }
                    },
                    supportMib: "no" !== _D("support_mib")
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var o = null != arguments[t] ? Object(arguments[t]) : {},
                        n = Object.keys(o);
                    "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(o).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(o, e).enumerable
                    })))), n.forEach((function(t) {
                        I(e, t, o[t])
                    }))
                }
                return e
            }({}, Object(s.mapState)(["url", "quickconnect"]), {
                nextStepKey: function() {
                    return this.isConnectingInternet ? "quickconnect_setup" : "udc_settings"
                },
                descText: function() {
                    return this.formatUrl(this.T("welcome", "useful_terms_privacy"), this.url.tos, this.url.privacy)
                },
                linkText: function() {
                    return this.isConnectingInternet ? String.format(this.T("welcome", "syno_login_link"), '<a href="#">', "</a>") : this.formatUrl(this.T("welcome", "syno_create_link"), this.url.account)
                },
                isShowSynoAccountStep: function() {
                    return !this.isGettingNetwork
                }
            }),
            watch: {
                isShowSynoAccountStep: (F = E(regeneratorRuntime.mark((function e() {
                    var t, o = this;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (!0 !== this.isConnectingInternet) {
                                    e.next = 4;
                                    break
                                }
                                return e.next = 3, this.$nextTick();
                            case 3:
                                this.$refs && this.$refs.linkText && (t = this.$refs.linkText.querySelectorAll("a")).length > 0 && t[0].addEventListener("click", (function() {
                                    o.showLoader(!0), o.isDoingCreate = !1, o.webLogin.popLoginWeb(o.webLoginResolve, o.webLoginReject, o.webLoginClose)
                                }));
                            case 4:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return F.apply(this, arguments)
                })
            },
            methods: {
                getNetworkStatus: (W = E(regeneratorRuntime.mark((function e() {
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return this.$emit("set-status", "busy"), e.next = 3, this.apiGetQuickConnect();
                            case 3:
                                this.isGettingNetwork = !1, this.$emit("set-status", "clear");
                            case 5:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return W.apply(this, arguments)
                }),
                prepareToNext: (U = E(regeneratorRuntime.mark((function e() {
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (!0 !== this.isLoading) {
                                    e.next = 2;
                                    break
                                }
                                return e.abrupt("return", !1);
                            case 2:
                                if (!this.isConnectingInternet) {
                                    e.next = 7;
                                    break
                                }
                                return this.showLoader(!0), this.isDoingCreate = !0, this.webLogin.popCreateWeb(this.webLoginResolve, this.webLoginReject, this.webLoginClose), e.abrupt("return", !1);
                            case 7:
                                return this.setStepWebapi(this.nextStepKey), e.abrupt("return", !0);
                            case 9:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return U.apply(this, arguments)
                }),
                prepareToPre: function() {
                    var e = this;
                    if (!1 === this.isConnectingInternet || !0 === this.isLoading) return !1;
                    var t = function() {
                        e.setStepWebapi("udc_settings"), e.$emit("set-active-step-key", "udc_settings")
                    };
                    return this.isBusinessUser ? t() : this.$emit("confirm-message-box", this.T("welcome", "want_change_mind"), this.T("welcome", "want_change_mind_desc"), (function(e) {
                        "confirm" === e && t()
                    }), {
                        cancel: {
                            type: "footbar",
                            text: this.T("common", "return")
                        },
                        confirm: {
                            type: "footbar",
                            text: this.T("common", "skip_anyway"),
                            suffix: "cancel"
                        }
                    }), !1
                },
                onLoaderCancel: function() {
                    var e = this;
                    this.$emit("confirm-message-box", this.T("welcome", this.isDoingCreate ? "confirm_registration_discard_title" : "confirm_login_discard_title"), this.T("welcome", "confirm_registration_discard_desc"), (function(t) {
                        "confirm" === t && e.showLoader(!1)
                    }))
                },
                showLoader: function(e) {
                    this.isLoading = e, this.$emit("set-loader", e, !0, this.onLoaderCancel), e ? e && !this.popupChecker && (this.popupChecker = setInterval(function() {
                        var e = this.webLogin;
                        e && e.popup && e.popup.closed && !e.isProcessing && this.showLoader(!1)
                    }.bind(this), 1e3)) : (this.$emit("custom-footer-buttons", this.connectingFooterBtnGroup), this.popupChecker && (clearInterval(this.popupChecker), this.popupChecker = null), this.webLogin && this.webLogin.cancel())
                },
                apiGetQuickConnect: (M = E(regeneratorRuntime.mark((function e() {
                    var t;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.prev = 0, e.next = 3, synowebapi.promises.request({
                                    api: "SYNO.Core.QuickConnect",
                                    method: "get",
                                    version: 2,
                                    timeout: 3e4
                                });
                            case 3:
                                if (t = e.sent, this.$store.commit("setQuickconnect", t), !t || !t.enabled) {
                                    e.next = 10;
                                    break
                                }
                                this.setStepWebapi("tools_settings"), this.$emit("set-active-step-key", "tools_settings"), e.next = 12;
                                break;
                            case 10:
                                return e.next = 12, this.apiQueryMyDSCenter();
                            case 12:
                                e.next = 18;
                                break;
                            case 14:
                                return e.prev = 14, e.t0 = e.catch(0), e.next = 18, this.apiQueryMyDSCenter();
                            case 18:
                            case "end":
                                return e.stop()
                        }
                    }), e, this, [
                        [0, 14]
                    ])
                }))), function() {
                    return M.apply(this, arguments)
                }),
                apiQueryMyDSCenter: (j = E(regeneratorRuntime.mark((function e() {
                    var t;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.prev = 0, e.next = 3, synowebapi.promises.request({
                                    api: "SYNO.Core.MyDSCenter",
                                    method: "query",
                                    version: 2,
                                    timeout: 3e4
                                });
                            case 3:
                                if (!(t = e.sent) || !t.is_logged_in) {
                                    e.next = 9;
                                    break
                                }
                                this.$store.commit("setQuickconnectAccount", t.account), this.$emit("set-active-step-key", "quickconnect_setup"), e.next = 11;
                                break;
                            case 9:
                                return e.next = 11, this.getRegisterUrl();
                            case 11:
                                e.next = 17;
                                break;
                            case 13:
                                return e.prev = 13, e.t0 = e.catch(0), e.next = 17, this.getRegisterUrl();
                            case 17:
                            case "end":
                                return e.stop()
                        }
                    }), e, this, [
                        [0, 13]
                    ])
                }))), function() {
                    return j.apply(this, arguments)
                }),
                getRegisterUrl: (L = E(regeneratorRuntime.mark((function e() {
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, SYNO.SDS.SynologyAccount.WebLogin.create();
                            case 2:
                                this.webLogin = e.sent, this.webLogin && (this.webLogin.registerUrl && this.$store.commit("setUrlRegister", this.webLogin.registerUrl), this.webLogin.loginUrl && this.$store.commit("setUrlLogin", this.webLogin.loginUrl), this.webLogin.registerUrl && this.webLogin.loginUrl && (this.isConnectingInternet = !0)), this.$emit("custom-footer-buttons", !1 === this.isConnectingInternet ? this.notConnectingFooterBtnGroup : this.connectingFooterBtnGroup);
                            case 5:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return L.apply(this, arguments)
                }),
                enableSecureSignin: (R = E(regeneratorRuntime.mark((function e() {
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.prev = 0, e.next = 3, synowebapi.promises.request({
                                    api: "SYNO.SecureSignIn.Package",
                                    method: "set",
                                    version: 1,
                                    params: {
                                        enabled: !0
                                    }
                                });
                            case 3:
                                e.next = 8;
                                break;
                            case 5:
                                e.prev = 5, e.t0 = e.catch(0), SYNO.Debug.error(e.t0);
                            case 8:
                            case "end":
                                return e.stop()
                        }
                    }), e, this, [
                        [0, 5]
                    ])
                }))), function() {
                    return R.apply(this, arguments)
                }),
                webLoginResolve: (z = E(regeneratorRuntime.mark((function e(t) {
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (!t || !t.account) {
                                    e.next = 6;
                                    break
                                }
                                return this.$store.commit("setQuickconnectAccount", t.account), e.next = 4, this.enableSecureSignin();
                            case 4:
                                this.showLoader(!1), this.$emit("set-active-step-key", "quickconnect_setup");
                            case 6:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function(e) {
                    return z.apply(this, arguments)
                }),
                webLoginReject: function(e) {
                    var t = this;
                    this.$emit("display-error", e, (function() {
                        t.showLoader(!1)
                    }))
                },
                webLoginClose: function() {
                    this.$emit("close-msg-box"), this.showLoader(!1)
                }
            }
        },
        X = (o(29), Object(u.a)(Q, A, [], !1, null, "96576d9c", null));
    X.options.__file = "src/quick-start-wizard-steps/create-syno-account.vue";
    var G = X.exports,
        V = function() {
            var e = this,
                t = e.$createElement,
                o = e._self._c || t;
            return o("v-wizard-step", {
                staticClass: "welcome-step-udc",
                attrs: {
                    "syno-id": "welcome-app-udc-settings-step",
                    finished: e.finished,
                    "show-transition": !0,
                    "step-key": "udc_settings"
                },
                on: {
                    activate: e.updateFooter
                }
            }, [o("div", {
                staticClass: "welcome-step-header"
            }, [o("div", {
                staticClass: "welcome-step-title"
            }, [e._v(e._s(e.T("welcome", "udc_title")))]), e._v(" "), o("div", {
                staticClass: "welcome-step-desc"
            }, [e._v(e._s(e.T("welcome", "udc_subtitle")))])]), e._v(" "), o("div", {
                staticClass: "welcome-step-body"
            }, [o("div", {
                staticClass: "welcome-step-body-img"
            }), e._v(" "), o("v-perfect-scrollbar", [o("div", {
                staticClass: "welcome-step-body-content"
            }, [o("div", {
                staticClass: "welcome-step-body-content-desc",
                domProps: {
                    innerHTML: e._s(e.linkText)
                }
            }), e._v(" "), o("div", {
                staticClass: "welcome-step-udc-check"
            }, [o("v-checkbox", {
                attrs: {
                    "syno-id": "welcome-app-udc-checkbox"
                },
                model: {
                    value: e.fields.enableUdc,
                    callback: function(t) {
                        e.$set(e.fields, "enableUdc", t)
                    },
                    expression: "fields.enableUdc"
                }
            }, [e._v("\n                        " + e._s(e.T("welcome", "agree_udc")) + "\n                    ")])], 1)])])], 1)])
        };

    function H(e, t, o, n, i, s, r) {
        try {
            var a = e[s](r),
                c = a.value
        } catch (e) {
            return void o(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(n, i)
    }

    function K(e, t, o) {
        return t in e ? Object.defineProperty(e, t, {
            value: o,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = o, e
    }
    V._withStripped = !0;
    var J = {
            mixins: [i.a, c.a],
            data: function() {
                return {
                    fields: {
                        enableUdc: !1
                    }
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var o = null != arguments[t] ? Object(arguments[t]) : {},
                        n = Object.keys(o);
                    "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(o).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(o, e).enumerable
                    })))), n.forEach((function(t) {
                        K(e, t, o[t])
                    }))
                }
                return e
            }({}, Object(s.mapState)(["url"]), {
                linkText: function() {
                    return this.formatUrl(this.T("welcome", "udc_desc"), this.url.privacy)
                }
            }),
            methods: {
                updateFooter: function() {
                    this.$emit("custom-footer-buttons", {
                        next: {
                            text: this.T("common", "proceed"),
                            show: !0
                        },
                        back: {
                            show: !1
                        }
                    })
                },
                finished: function() {
                    var e = function(e) {
                        return function() {
                            var t = this,
                                o = arguments;
                            return new Promise((function(n, i) {
                                var s = e.apply(t, o);

                                function r(e) {
                                    H(s, n, i, r, a, "next", e)
                                }

                                function a(e) {
                                    H(s, n, i, r, a, "throw", e)
                                }
                                r(void 0)
                            }))
                        }
                    }(regeneratorRuntime.mark((function e() {
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return this.$emit("set-loader", !0), this.setUdc.call(this, this.fields.enableUdc, !0), e.abrupt("return", !1);
                                case 3:
                                case "end":
                                    return e.stop()
                            }
                        }), e, this)
                    })));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }()
            }
        },
        Z = (o(33), Object(u.a)(J, V, [], !1, null, null, null));
    Z.options.__file = "src/quick-start-wizard-steps/udc-settings.vue";
    var ee = Z.exports,
        te = function() {
            var e = this,
                t = e.$createElement,
                o = e._self._c || t;
            return o("v-wizard-step", {
                staticClass: "welcome-step-quickconnect",
                attrs: {
                    "syno-id": "welcome-app-quickconnect-create-step",
                    "next-step-key": "tools_settings",
                    "pre-enter-next-step": e.prepareToNext,
                    "pre-enter-previous-step": e.prepareToPre,
                    "show-transition": !0,
                    "step-key": "quickconnect_setup"
                },
                on: {
                    activate: e.onActivate
                }
            }, [o("div", {
                staticClass: "welcome-step-header"
            }, [o("div", {
                staticClass: "welcome-step-title"
            }, [e._v(e._s(e.T("welcome", "access_anywhere")))]), e._v(" "), o("div", {
                staticClass: "welcome-step-desc"
            }, [e._v(e._s(e.T("welcome", "quickconnect_setup_desc")))])]), e._v(" "), o("div", {
                staticClass: "welcome-step-body"
            }, [o("div", {
                staticClass: "welcome-step-body-img"
            }), e._v(" "), o("v-perfect-scrollbar", [o("div", {
                staticClass: "welcome-step-body-content"
            }, [o("div", {
                staticClass: "welcome-step-body-content-desc"
            }, [e._v("\n                    " + e._s(e.T("welcome", "quickconnect_setup_desc1")) + "\n                ")]), e._v(" "), o("div", {
                staticClass: "welcome-step-body-content-desc",
                domProps: {
                    innerHTML: e._s(e.linkText)
                }
            }), e._v(" "), o("v-form", {
                staticClass: "welcome-step-quickconnect-form",
                attrs: {
                    "syno-id": "welcome-app-quickconnect-form",
                    rules: e.rules
                }
            }, [o("v-form-multiple-item", {
                attrs: {
                    "hide-label": !0
                }
            }, [o("v-form-item", {
                ref: "quickconnectIdFrom",
                attrs: {
                    "syno-id": "welcome-app-quickconnect-item",
                    prop: "quickconnectId"
                }
            }, [o("v-input", {
                attrs: {
                    name: "quickconnectId",
                    "syno-id": "welcome-app-quickconnect-input",
                    maxlength: 63,
                    placeholder: e.placeholderText
                },
                model: {
                    value: e.fields.quickconnectId,
                    callback: function(t) {
                        e.$set(e.fields, "quickconnectId", t)
                    },
                    expression: "fields.quickconnectId"
                }
            })], 1), e._v(" "), o("div", {
                staticClass: "welcome-step-body-content-desc"
            }, [e._v(e._s(e.urlPostfix))])], 1)], 1)], 1)])], 1)])
        };

    function oe(e, t, o, n, i, s, r) {
        try {
            var a = e[s](r),
                c = a.value
        } catch (e) {
            return void o(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(n, i)
    }

    function ne(e) {
        return function() {
            var t = this,
                o = arguments;
            return new Promise((function(n, i) {
                var s = e.apply(t, o);

                function r(e) {
                    oe(s, n, i, r, a, "next", e)
                }

                function a(e) {
                    oe(s, n, i, r, a, "throw", e)
                }
                r(void 0)
            }))
        }
    }

    function ie(e, t, o) {
        return t in e ? Object.defineProperty(e, t, {
            value: o,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = o, e
    }
    te._withStripped = !0;
    var se, re, ae = {
            mixins: [i.a, c.a],
            data: function() {
                return {
                    fields: {
                        quickconnectId: null
                    },
                    rules: {
                        quickconnectId: {
                            required: !0,
                            validator: this.validateQuickconnectId,
                            usedId: []
                        }
                    },
                    setAliasAgain: !1,
                    urlPostfix: ".quickconnect.to"
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var o = null != arguments[t] ? Object(arguments[t]) : {},
                        n = Object.keys(o);
                    "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(o).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(o, e).enumerable
                    })))), n.forEach((function(t) {
                        ie(e, t, o[t])
                    }))
                }
                return e
            }({}, Object(s.mapState)(["quickconnect", "url"]), {
                linkText: function() {
                    return this.formatUrl(this.T("welcome", "quickconnect_setup_desc2"), this.url.tos, this.url.privacy)
                },
                placeholderText: function() {
                    var e = "";
                    if (this.quickconnect.account) {
                        var t = this.quickconnect.account.match(/(.+@[^\.]+)/);
                        e = t && t[0] ? t[0].replace(/[^\w^\d^\-]/g, "") : ""
                    }
                    return e
                }
            }),
            methods: {
                updateFooter: function() {
                    this.$emit("custom-footer-buttons", {
                        next: {
                            text: this.T("common", "submit"),
                            show: !0
                        },
                        back: {
                            text: this.T("common", "skip"),
                            show: !0
                        }
                    })
                },
                onActivate: (re = ne(regeneratorRuntime.mark((function e() {
                    var t;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return this.updateFooter(), e.prev = 1, e.next = 4, synowebapi.promises.request({
                                    api: "SYNO.Core.QuickConnect.RegisterSite",
                                    method: "get",
                                    version: 1,
                                    timeout: 1e4
                                });
                            case 4:
                                (t = e.sent) && "cnc.quickconnect.cn" === t.host && (this.urlPostfix = ".quickconnect.cn"), e.next = 10;
                                break;
                            case 8:
                                e.prev = 8, e.t0 = e.catch(1);
                            case 10:
                            case "end":
                                return e.stop()
                        }
                    }), e, this, [
                        [1, 8]
                    ])
                }))), function() {
                    return re.apply(this, arguments)
                }),
                getApiCompound: function() {
                    return [{
                        api: "SYNO.Core.QuickConnect",
                        method: "set_server_alias",
                        version: 2,
                        params: {
                            enabled: !0,
                            force: this.setAliasAgain,
                            myds_account: this.quickconnect.account,
                            server_alias: this.fields.quickconnectId
                        }
                    }, {
                        api: "SYNO.Core.QuickConnect",
                        method: "set",
                        version: 2,
                        params: {
                            enabled: !0
                        }
                    }, {
                        api: "SYNO.Core.QuickConnect",
                        method: "get",
                        version: 2
                    }]
                },
                setQuickconnectId: (se = ne(regeneratorRuntime.mark((function e() {
                    var t, o, n, i, s, r;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return t = this, o = this.getApiCompound(), this.$emit("set-status", "busy"), e.prev = 3, e.next = 6, synowebapi.promises.request({
                                    api: "SYNO.Entry.Request",
                                    version: 1,
                                    method: "request",
                                    compound: {
                                        mode: "sequential",
                                        stopwhenerror: !0,
                                        params: o
                                    }
                                });
                            case 6:
                                !0 === (n = e.sent).has_fail ? (i = SYNO.API.Response.GetValByAPI(n, "SYNO.Core.QuickConnect", "set_server_alias"), 2906 === (s = i ? i.code : null) ? this.$emit("confirm-message-box", "", this.T("relayservice", "alias_change_machine_message"), (function(e) {
                                    "confirm" === e && (t.setAliasAgain = !0, t.setQuickconnectId())
                                })) : 2904 === s ? (-1 === this.rules.quickconnectId.usedId.indexOf(this.fields.quickconnectId) && this.rules.quickconnectId.usedId.push(this.fields.quickconnectId), this.$refs.quickconnectIdFrom.validate()) : this.$emit("display-error", SYNO.API.Response.GetFirstError(n))) : (r = SYNO.API.Response.GetValByAPI(n, "SYNO.Core.QuickConnect", "get"), this.$store.commit("setQuickconnect", r), this.$emit("show-quickconnect-created")), e.next = 13;
                                break;
                            case 10:
                                e.prev = 10, e.t0 = e.catch(3), this.$emit("display-error", e.t0);
                            case 13:
                                return e.prev = 13, this.$emit("set-status", "clear"), e.finish(13);
                            case 16:
                            case "end":
                                return e.stop()
                        }
                    }), e, this, [
                        [3, 10, 13, 16]
                    ])
                }))), function() {
                    return se.apply(this, arguments)
                }),
                prepareToNext: function() {
                    var e = ne(regeneratorRuntime.mark((function e() {
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, this.$refs.quickconnectIdFrom.validate();
                                case 2:
                                    return e.sent || this.setQuickconnectId(), e.abrupt("return", !1);
                                case 5:
                                case "end":
                                    return e.stop()
                            }
                        }), e, this)
                    })));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                prepareToPre: function() {
                    return this.setStepWebapi("tools_settings"), this.$emit("set-active-step-key", "tools_settings"), !1
                },
                validateQuickconnectId: function(e, t, o) {
                    try {
                        if (!t) return new Error(this.T("welcome", "error_no_quickconnect_id"));
                        if (this.rules.quickconnectId.usedId.indexOf(this.fields.quickconnectId) >= 0) return new Error(this.T("welcome", "error_quickconnect_exist"));
                        return !(!t || !/^[a-zA-Z][a-zA-Z\-0-9]*$/.test(t)) || new Error(this.T("welcome", "error_quickconnect_invalid"))
                    } catch (e) {
                        SYNO.Debug.error(e)
                    }
                }
            }
        },
        ce = (o(37), Object(u.a)(ae, te, [], !1, null, null, null));
    ce.options.__file = "src/quick-start-wizard-steps/quickconnect-setup.vue";
    var pe = ce.exports,
        le = function() {
            var e = this,
                t = e.$createElement,
                o = e._self._c || t;
            return o("v-wizard-step", {
                staticClass: "welcome-step-useful",
                attrs: {
                    "syno-id": "welcome-app-useful-tool-step",
                    finished: e.finished,
                    "show-transition": !0,
                    "step-key": "tools_settings"
                },
                on: {
                    activate: e.onActivate
                }
            }, [o("div", {
                staticClass: "welcome-step-header"
            }, [o("div", {
                staticClass: "welcome-step-title"
            }, [e._v(e._s(e.T("welcome", "useful_tools_title")))]), e._v(" "), o("div", {
                staticClass: "welcome-step-desc"
            }, [e._v(e._s(e.T("welcome", "useful_tools_subtitle")))])]), e._v(" "), e.supportMib ? o("div", {
                staticClass: "welcome-step-body-useful border-tier2"
            }, [o("div", {
                staticClass: "welcome-step-useful-title"
            }, [e._v(e._s(e.T("welcome", "active_insight")))]), e._v(" "), o("div", {
                staticClass: "welcome-step-useful-desc"
            }, [o("div", {
                staticClass: "welcome-step-body-content-desc"
            }, [e._v("\n                " + e._s(e.T("welcome", "active_insight_desc")) + "\n            ")]), e._v(" "), o("v-checkbox", {
                attrs: {
                    "syno-id": "welcome-app-oncloud-checkbox"
                },
                model: {
                    value: e.fields.enableOnCloudProtection,
                    callback: function(t) {
                        e.$set(e.fields, "enableOnCloudProtection", t)
                    },
                    expression: "fields.enableOnCloudProtection"
                }
            }, [e._v("\n                " + e._s(e.T("welcome", "agree_active_insight")) + "\n            ")])], 1)]) : e._e(), e._v(" "), o("div", {
                class: e.getConfBkgUpClass()
            }, [o("div", {
                staticClass: "welcome-step-useful-title"
            }, [e._v(e._s(e.T("welcome", "conf_backup_title")))]), e._v(" "), o("div", {
                staticClass: "welcome-step-useful-desc"
            }, [o("div", {
                staticClass: "welcome-step-body-content-desc"
            }, [e._v("\n                " + e._s(e.T("welcome", "conf_backup_desc")) + "\n            ")]), e._v(" "), o("v-checkbox", {
                attrs: {
                    "syno-id": "welcome-app-autobackup-checkbox"
                },
                model: {
                    value: e.fields.enableAutoBackup,
                    callback: function(t) {
                        e.$set(e.fields, "enableAutoBackup", t)
                    },
                    expression: "fields.enableAutoBackup"
                }
            }, [e._v("\n                " + e._s(e.T("welcome", "enable_conf_backup")) + "\n            ")]), e._v(" "), o("v-button", {
                attrs: {
                    "syno-id": "welcome-app-autobackup-button",
                    disabled: !e.fields.enableAutoBackup
                },
                on: {
                    click: e.onAdvanceSettings
                }
            }, [e._v("\n                " + e._s(e.T("common", "adv_setting")) + "\n            ")])], 1)]), e._v(" "), e.supportMib ? e._e() : o("div", {
                staticClass: "welcome-step-body-useful border-tier3"
            }, [o("div", {
                staticClass: "welcome-step-useful-title"
            }, [e._v(e._s(e.T("welcome", "udc_title")))]), e._v(" "), o("div", {
                staticClass: "welcome-step-useful-desc"
            }, [o("div", {
                staticClass: "welcome-step-body-content-desc",
                domProps: {
                    innerHTML: e._s(e.udcLinkText)
                }
            }), e._v(" "), o("v-checkbox", {
                attrs: {
                    "syno-id": "welcome-app-udc-setting-checkbox"
                },
                model: {
                    value: e.fields.enableUdc,
                    callback: function(t) {
                        e.$set(e.fields, "enableUdc", t)
                    },
                    expression: "fields.enableUdc"
                }
            }, [e._v("\n                " + e._s(e.T("welcome", "agree_udc")) + "\n            ")])], 1)]), e._v(" "), o("div", {
                staticClass: "welcome-step-body-useful border-tier2 text",
                domProps: {
                    innerHTML: e._s(e.linkText)
                }
            })])
        };

    function de(e, t, o, n, i, s, r) {
        try {
            var a = e[s](r),
                c = a.value
        } catch (e) {
            return void o(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(n, i)
    }

    function ue(e) {
        return function() {
            var t = this,
                o = arguments;
            return new Promise((function(n, i) {
                var s = e.apply(t, o);

                function r(e) {
                    de(s, n, i, r, a, "next", e)
                }

                function a(e) {
                    de(s, n, i, r, a, "throw", e)
                }
                r(void 0)
            }))
        }
    }

    function me(e, t, o) {
        return t in e ? Object.defineProperty(e, t, {
            value: o,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = o, e
    }
    le._withStripped = !0;
    var he, fe, ge = {
            mixins: [i.a, c.a],
            data: function() {
                var e = "agree" === SYNO.SDS.Session.privacy_agreement;
                return {
                    fields: {
                        enableOnCloudProtection: e,
                        enableAutoBackup: e,
                        enableUdc: !1
                    },
                    isSetAutoBackup: !1,
                    supportMib: "no" !== _D("support_mib")
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var o = null != arguments[t] ? Object(arguments[t]) : {},
                        n = Object.keys(o);
                    "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(o).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(o, e).enumerable
                    })))), n.forEach((function(t) {
                        me(e, t, o[t])
                    }))
                }
                return e
            }({}, Object(s.mapState)(["encryption", "url", "quickconnect"]), {
                linkText: function() {
                    return this.formatUrl(this.T("welcome", "useful_terms_privacy"), this.url.tos, this.url.privacy)
                },
                udcLinkText: function() {
                    return this.formatUrl(this.T("welcome", "udc_desc"), this.url.privacy)
                }
            }),
            methods: {
                onActivate: function() {
                    var e = ue(regeneratorRuntime.mark((function e() {
                        var t;
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    if (e.prev = 0, this.quickconnect.id && this.quickconnect.domain) {
                                        e.next = 6;
                                        break
                                    }
                                    return e.next = 4, synowebapi.promises.request({
                                        api: "SYNO.Core.QuickConnect",
                                        method: "get",
                                        version: 2,
                                        timeout: 3e4
                                    });
                                case 4:
                                    t = e.sent, this.$store.commit("setQuickconnect", t);
                                case 6:
                                    e.next = 11;
                                    break;
                                case 8:
                                    e.prev = 8, e.t0 = e.catch(0), SYNO.Debug(e.t0);
                                case 11:
                                    this.updateFooter();
                                case 12:
                                case "end":
                                    return e.stop()
                            }
                        }), e, this, [
                            [0, 8]
                        ])
                    })));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                updateFooter: function() {
                    this.$emit("custom-footer-buttons", {
                        next: {
                            text: this.T("common", "proceed"),
                            show: !0
                        },
                        back: {
                            show: !1
                        }
                    })
                },
                finished: function() {
                    var e = ue(regeneratorRuntime.mark((function e() {
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return this.$emit("set-loader", !0), e.next = 3, this.setAutoBackup();
                                case 3:
                                    if (!1 !== this.isSetAutoBackup) {
                                        e.next = 5;
                                        break
                                    }
                                    return e.abrupt("return", !1);
                                case 5:
                                    if (this.supportMib) {
                                        e.next = 10;
                                        break
                                    }
                                    return e.next = 8, this.setUdc.call(this, this.fields.enableUdc);
                                case 8:
                                    e.next = 13;
                                    break;
                                case 10:
                                    return e.next = 12, this.setActiveInsight();
                                case 12:
                                    this.$emit("close");
                                case 13:
                                    return e.abrupt("return", !1);
                                case 14:
                                case "end":
                                    return e.stop()
                            }
                        }), e, this)
                    })));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                setAutoBackup: (fe = ue(regeneratorRuntime.mark((function e() {
                    var t, o, n, i, s;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (!this.isSetAutoBackup) {
                                    e.next = 2;
                                    break
                                }
                                return e.abrupt("return");
                            case 2:
                                return t = {
                                    api: "SYNO.Backup.Config.AutoBackup",
                                    method: "set",
                                    version: 1,
                                    encryption: ["pwd"],
                                    params: {
                                        enable: this.fields.enableAutoBackup,
                                        enc_method: this.encryption.encryptionCheck,
                                        overwrite: !0
                                    }
                                }, "manual" === this.encryption.encryptionCheck && this.encryption.password && (t.params.pwd = this.encryption.password), (o = []).push(t), o.push({
                                    api: "SYNO.Core.QuickStart.Info",
                                    method: "set_confautobkp",
                                    version: 1,
                                    params: {
                                        confautobkp_value: "done"
                                    }
                                }), e.prev = 7, e.next = 10, synowebapi.promises.request({
                                    api: "SYNO.Entry.Request",
                                    method: "request",
                                    version: 1,
                                    compound: {
                                        mode: "sequential",
                                        stopwhenerror: !0,
                                        params: o
                                    }
                                });
                            case 10:
                                !0 === (n = e.sent).has_fail ? (i = SYNO.API.Response.GetFirstError(n), this.$emit("display-error", i), this.$emit("set-loader", !1), this.updateFooter()) : (this.isSetAutoBackup = !0, (s = n && n.result && n.result[0]).success && s.data.prikey_session_id && synowebapi.download({
                                    api: "SYNO.Backup.Config.AutoBackup",
                                    method: "download_private_key",
                                    version: 1,
                                    params: {
                                        prikey_session_id: s.data.prikey_session_id
                                    }
                                }), this.$store.commit("clearPassword")), e.next = 19;
                                break;
                            case 14:
                                e.prev = 14, e.t0 = e.catch(7), this.$emit("display-error", e.t0), this.$emit("set-loader", !1), this.updateFooter();
                            case 19:
                                return e.prev = 19, e.finish(19);
                            case 21:
                            case "end":
                                return e.stop()
                        }
                    }), e, this, [
                        [7, 14, 19, 21]
                    ])
                }))), function() {
                    return fe.apply(this, arguments)
                }),
                setActiveInsight: (he = ue(regeneratorRuntime.mark((function e() {
                    var t;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return t = [], this.fields.enableOnCloudProtection && t.push({
                                    api: "SYNO.ActiveInsight.Package",
                                    method: "start_mib",
                                    version: 1,
                                    params: {
                                        is_advance_mode: "yes" == _D("support_mib_adv_mode")
                                    }
                                }), t.push({
                                    api: "SYNO.Core.QuickStart.Info",
                                    method: "set_mib",
                                    version: 2,
                                    params: {
                                        mib_value: _S("productversion") + _S("buildphase")
                                    }
                                }), t.push({
                                    api: "SYNO.Core.QuickStart.Info",
                                    method: "set_udc",
                                    version: 1,
                                    params: {
                                        udc_value: _S("productversion")
                                    }
                                }), e.next = 6, synowebapi.promises.request({
                                    api: "SYNO.Entry.Request",
                                    method: "request",
                                    version: 1,
                                    compound: {
                                        mode: "sequential",
                                        stopwhenerror: !1,
                                        params: t
                                    }
                                });
                            case 6:
                                SYNO.SDS.Session.udc_check_state = _S("productversion");
                            case 7:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return he.apply(this, arguments)
                }),
                onAdvanceSettings: function() {
                    this.$emit("show-advance-settings")
                },
                getConfBkgUpClass: function() {
                    return "welcome-step-body-useful " + (this.supportMib ? "border-tier3" : "border-tier2")
                }
            }
        },
        we = (o(41), Object(u.a)(ge, le, [], !1, null, null, null));
    we.options.__file = "src/quick-start-wizard-steps/useful-tools-settings.vue";
    var ve = we.exports,
        be = function() {
            var e = this,
                t = e.$createElement,
                o = e._self._c || t;
            return o("v-wizard-step", {
                attrs: {
                    "syno-id": "quick-start-wizard-steps-xa-set-static-ip-wizard-step-0",
                    "next-step-key": "create_syno_account",
                    "pre-enter-next-step": e.prepareToNext,
                    "pre-enter-previous-step": e.prepareToPre,
                    "show-transition": !0,
                    "step-key": "xa_set_static_ip"
                },
                on: {
                    activate: e.getNetworkStatus
                }
            }, [o("div", {
                staticClass: "welcome-step-header"
            }, [o("div", {
                staticClass: "welcome-step-title"
            }, [e._v(e._s(e.T("welcome", "network_setup_title")))]), e._v(" "), o("div", {
                staticClass: "welcome-step-desc"
            }, [e._v(e._s(e.T("welcome", "network_setup_desc")))])]), e._v(" "), o("v-form", {
                ref: "form",
                staticClass: "welcome-step-body welcome-network-form",
                attrs: {
                    "syno-id": "quick-start-wizard-steps-xa-set-static-ip-form-0",
                    rules: e.rules
                }
            }, [o("v-form-multiple-item", {
                attrs: {
                    label: e.T("tcpip", "tcpip_ipaddr") + ":"
                }
            }, [o("v-form-item", {
                attrs: {
                    prop: "ip"
                }
            }, [o("v-input", {
                attrs: {
                    "syno-id": "quick-start-wizard-steps-xa-set-static-ip-input-0",
                    name: "ip",
                    maxlength: 15
                },
                model: {
                    value: e.fields.ip,
                    callback: function(t) {
                        e.$set(e.fields, "ip", t)
                    },
                    expression: "fields.ip"
                }
            })], 1), e._v(" "), o("v-whitetip", {
                attrs: {
                    "syno-id": "quick-start-wizard-steps-xa-set-static-ip-whitetip-0",
                    content: e.T("welcome", "network_setup_desc_tip")
                }
            })], 1), e._v(" "), o("v-form-item", {
                attrs: {
                    prop: "mask",
                    label: e.T("tcpip", "tcpip_mask") + ":"
                }
            }, [o("v-input", {
                attrs: {
                    "syno-id": "quick-start-wizard-steps-xa-set-static-ip-input-1",
                    name: "mask",
                    maxlength: 15
                },
                model: {
                    value: e.fields.mask,
                    callback: function(t) {
                        e.$set(e.fields, "mask", t)
                    },
                    expression: "fields.mask"
                }
            })], 1), e._v(" "), o("v-form-item", {
                attrs: {
                    prop: "gateway",
                    label: e.T("network", "route_gateway") + ":"
                }
            }, [o("v-input", {
                attrs: {
                    "syno-id": "quick-start-wizard-steps-xa-set-static-ip-input-2",
                    name: "gateway",
                    maxlength: 15
                },
                model: {
                    value: e.fields.gateway,
                    callback: function(t) {
                        e.$set(e.fields, "gateway", t)
                    },
                    expression: "fields.gateway"
                }
            })], 1), e._v(" "), o("v-form-item", {
                attrs: {
                    prop: "dns",
                    label: e.T("network", "route_dns") + ":"
                }
            }, [o("v-input", {
                attrs: {
                    "syno-id": "quick-start-wizard-steps-xa-set-static-ip-input-3",
                    name: "dns",
                    maxlength: 15
                },
                model: {
                    value: e.fields.dns,
                    callback: function(t) {
                        e.$set(e.fields, "dns", t)
                    },
                    expression: "fields.dns"
                }
            })], 1)], 1)], 1)
        };

    function xe(e, t, o, n, i, s, r) {
        try {
            var a = e[s](r),
                c = a.value
        } catch (e) {
            return void o(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(n, i)
    }

    function ye(e) {
        return function() {
            var t = this,
                o = arguments;
            return new Promise((function(n, i) {
                var s = e.apply(t, o);

                function r(e) {
                    xe(s, n, i, r, a, "next", e)
                }

                function a(e) {
                    xe(s, n, i, r, a, "throw", e)
                }
                r(void 0)
            }))
        }
    }

    function ke(e, t, o) {
        return t in e ? Object.defineProperty(e, t, {
            value: o,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = o, e
    }
    be._withStripped = !0;
    var _e = {
            mixins: [i.a],
            props: {},
            data: function() {
                return {
                    currentIP: void 0,
                    fields: {
                        ip: void 0,
                        mask: void 0,
                        gateway: void 0,
                        dns: void 0
                    },
                    rules: {
                        ip: {
                            required: !0,
                            validator: this.validateIp
                        },
                        mask: {
                            required: !0,
                            validator: this.validateMask
                        },
                        gateway: {
                            required: !1,
                            validator: this.validateGateway
                        },
                        dns: {
                            required: !1,
                            validator: this.validateDns
                        }
                    }
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var o = null != arguments[t] ? Object(arguments[t]) : {},
                        n = Object.keys(o);
                    "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(o).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(o, e).enumerable
                    })))), n.forEach((function(t) {
                        ke(e, t, o[t])
                    }))
                }
                return e
            }({}, Object(s.mapState)(["networkInterface"])),
            methods: {
                getNetworkStatus: function() {
                    var e = ye(regeneratorRuntime.mark((function e() {
                        var t;
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.prev = 0, this.$emit("set-status", "busy"), e.next = 4, synowebapi.promises.request({
                                        api: "SYNO.Core.Network.Ethernet",
                                        method: "list",
                                        version: 2
                                    });
                                case 4:
                                    t = e.sent, this.currentInterface = t.find((function(e) {
                                        return "connected" === e.status && e.ip === window.location.hostname
                                    })), this.currentInterface && this.currentInterface.ifname ? (this.fields.mask = this.currentInterface.mask, this.fields.dns = this.currentInterface.dns, this.fields.gateway = this.currentInterface.gateway, this.currentIP = this.currentInterface.ip, this.$emit("custom-footer-buttons", {
                                        back: {
                                            text: this.T("common", "skip"),
                                            show: !0
                                        },
                                        next: {
                                            text: this.T("common", "next")
                                        }
                                    })) : this.$emit("set-active-step-key", "create_syno_account"), e.next = 12;
                                    break;
                                case 9:
                                    e.prev = 9, e.t0 = e.catch(0), this.$emit("set-active-step-key", "create_syno_account");
                                case 12:
                                    return e.prev = 12, this.$emit("set-status", "clear"), e.finish(12);
                                case 15:
                                case "end":
                                    return e.stop()
                            }
                        }), e, this, [
                            [0, 9, 12, 15]
                        ])
                    })));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                prepareToNext: function() {
                    var e = ye(regeneratorRuntime.mark((function e() {
                        var t;
                        return regeneratorRuntime.wrap((function(e) {
                            for (;;) switch (e.prev = e.next) {
                                case 0:
                                    return e.next = 2, this.$refs.form.validate();
                                case 2:
                                    if (e.sent) {
                                        e.next = 5;
                                        break
                                    }
                                    return e.abrupt("return", !1);
                                case 5:
                                    return t = !1, e.prev = 6, this.$emit("set-status", "busy"), e.next = 10, synowebapi.promises.request({
                                        api: "SYNO.Core.Network.Ethernet",
                                        method: "DAD",
                                        version: 1,
                                        params: {
                                            ifname: this.currentInterface.ifname,
                                            ip: this.fields.ip
                                        }
                                    });
                                case 10:
                                    t = !0, this.$store.commit("setNetworkInterface", Object.assign({}, this.currentInterface, this.fields)), e.next = 17;
                                    break;
                                case 14:
                                    e.prev = 14, e.t0 = e.catch(6), this.$emit("display-error", e.t0);
                                case 17:
                                    return e.prev = 17, this.$emit("set-status", "clear"), e.finish(17);
                                case 20:
                                    return e.abrupt("return", t);
                                case 21:
                                case "end":
                                    return e.stop()
                            }
                        }), e, this, [
                            [6, 14, 17, 20]
                        ])
                    })));
                    return function() {
                        return e.apply(this, arguments)
                    }
                }(),
                prepareToPre: function() {
                    var e = this;
                    return this.$emit("confirm-message-box", null, this.T("welcome", "network_setup_skip_msg"), (function(t) {
                        "confirm" === t && e.$emit("set-active-step-key", "create_syno_account")
                    })), !1
                },
                validateIp: function(e, t, o) {
                    try {
                        if (!Ext.form.VTypes.v4ip(this.fields.ip)) return new Error(Ext.form.VTypes.v4ipText);
                        var n = this.fields.ip.split(".");
                        if (!this.fields.mask) return !0;
                        var i = this.fields.mask.split(".");
                        if (4 !== n.length || 4 !== i.length) return !0;
                        var s = parseInt(n[0], 10) << 24 | parseInt(n[1], 10) << 16 | parseInt(n[2], 10) << 8 | parseInt(n[3], 10);
                        return s == (s | ~(parseInt(i[0], 10) << 24 | parseInt(i[1], 10) << 16 | parseInt(i[2], 10) << 8 | parseInt(i[3], 10))) ? new Error(this.T("network", "error_bad_broadcast_ip")) : !["169.254.3.1", "169.254.3.2", "169.254.2.1", "169.254.2.2", "127.0.0.1", "127.0.0.0", this.currentIP].includes(this.fields.ip) || new Error(this.T("tcpip", "tcpip_ip_used"))
                    } catch (e) {
                        SYNO.Debug.error(e)
                    }
                },
                validateMask: function(e, t, o) {
                    try {
                        return !!Ext.form.VTypes.netmask(this.fields.mask) || new Error(Ext.form.VTypes.netmaskText)
                    } catch (e) {
                        SYNO.Debug.error(e)
                    }
                },
                validateGateway: function(e, t, o) {
                    try {
                        if (!1 === e.required && "" === this.fields.gateway) return !0;
                        if (!Ext.form.VTypes.v4ip(this.fields.gateway)) return new Error(Ext.form.VTypes.v4ipText);
                        if (this.fields.gateway && this.fields.ip && this.fields.mask)
                            if (!SYNO.SDS.Utils.Network.GatewayMatchIP(this.fields.gateway, this.fields.ip, this.fields.mask)) return new Error(this.T("common", "error_notmatch"));
                        return !0
                    } catch (e) {
                        SYNO.Debug.error(e)
                    }
                },
                validateDns: function(e, t, o) {
                    try {
                        return !1 === e.required && "" === this.fields.dns || (!!Ext.form.VTypes.v4ip(this.fields.dns) || new Error(Ext.form.VTypes.v4ipText))
                    } catch (e) {
                        SYNO.Debug.error(e)
                    }
                }
            }
        },
        Se = (o(43), Object(u.a)(_e, be, [], !1, null, null, null));
    Se.options.__file = "src/quick-start-wizard-steps/xa-set-static-ip.vue";
    var Ce = {
            components: {
                WelcomePage: x,
                CreateAdminAccount: P,
                CreateSynoAccount: G,
                QuickconnectSetup: pe,
                UdcSettings: ee,
                UsefulToolsSettings: ve,
                XaSetStaticIp: Se.exports,
                Loader: h
            },
            mixins: [i.a, a, c.a],
            props: {},
            data: function() {
                var e = !1 === SYNO.SDS.Session.admin_configured,
                    t = "yes" === _D("support_xa", "no");
                return {
                    nextStepDisabled: !1,
                    previousStepDisabled: !1,
                    customButtonsGroup: {
                        next: {
                            show: !1
                        }
                    },
                    isAccountShow: e,
                    isWelcomeHidden: _S("welcome_hide"),
                    shouldShowWizard: e || !_S("welcome_hide"),
                    activeStepKey: e ? "welcome_page" : t ? "xa_set_static_ip" : _S("quickstart_wizard_step") ? _S("quickstart_wizard_step") : "create_syno_account",
                    isBusinessUser: _D("maxdisks") >= 5 || /^(FS|RS|RC|eds14)/i.test(_D("upnpmodelname")),
                    isSupportXa: t,
                    loading: !1,
                    isShowLoader: !1,
                    isShowCancelBtn: !1,
                    onLoaderCancel: function() {},
                    isDoingClose: !1,
                    loaderTitle: void 0,
                    loaderBody: void 0
                }
            },
            methods: {
                shouldLaunch: function() {
                    return this.isAccountShow || !this.isWelcomeHidden
                },
                customFooterButtons: function(e) {
                    this.customButtonsGroup = e
                },
                onMessageBoxConfirm: function(e, t, o, n, i) {
                    this.messageBox = this.$refs.appWindow.getMsgBox(), this.messageBox.confirm(e, t, n, i).then(o)
                },
                onMessageBoxAlert: function(e, t, o) {
                    this.messageBox = this.$refs.appWindow.getMsgBox(), this.messageBox.alert(e, t).then(o)
                },
                onAdvanceSettings: function() {
                    this.$refs.appWindow.openModalWindow(SYNO.SDS.App.WelcomeApp.UsefulToolsAdvSettings)
                },
                onQuickconnectCreated: function() {
                    var e = this;
                    this.$refs.appWindow.openModalWindow(SYNO.SDS.App.WelcomeApp.QuickconnectCreated).window.$on("close", (function() {
                        e.setStepWebapi("tools_settings"), e.setActiveStepKey("tools_settings")
                    }))
                },
                onClose: function() {
                    this.isDoingClose || (this.isDoingClose = !0, this.endWelcome(this.$refs.appWindow, this.onSetLoader))
                },
                onSetStatus: function(e) {
                    "busy" === e ? (this.loading = !0, this.$refs.appWindow.mask(.4)) : (this.loading = !1, this.$refs.appWindow.unmask())
                },
                setIsDoingAuth: function(e) {
                    this.$refs.appWindow.isDoingAuth = e
                },
                canReload: function() {
                    return this.$refs.appWindow.isDoingAuth || _S("admin_configured")
                },
                displayError: function(e, t) {
                    var o = this.T("error", "error_error_system");
                    e && e.code && (o = SYNO.API.Errors.core[e.code] || this.T("error", "error_error_system")), this.onMessageBoxAlert("", o, t)
                },
                setActiveStepKey: function(e) {
                    this.activeStepKey = e
                },
                onSetLoader: function() {
                    var e = arguments.length > 0 && void 0 !== arguments[0] && arguments[0],
                        t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
                        o = arguments.length > 2 ? arguments[2] : void 0,
                        n = arguments.length > 3 ? arguments[3] : void 0;
                    this.isShowLoader = e, this.isShowCancelBtn = t, this.onLoaderCancel = o || function() {}, this.isShowLoader ? (null == this.preBtnGroup && (this.preBtnGroup = this.customButtonsGroup), this.customFooterButtons({
                        next: {
                            show: !1
                        },
                        back: {
                            show: !1
                        }
                    })) : (this.customFooterButtons(this.preBtnGroup), this.preBtnGroup = null), n && (this.loaderTitle = n.title || "", this.loaderBody = n.body || "")
                },
                closeMsgBox: function() {
                    this.messageBox && this.messageBox.close()
                }
            }
        },
        qe = (o(45), Object(u.a)(Ce, n, [], !1, null, null, null));
    qe.options.__file = "src/quick-start-wizard.vue";
    var Oe = qe.exports,
        Te = function() {
            var e = this,
                t = e.$createElement,
                o = e._self._c || t;
            return o("v-modal-window", {
                ref: "window",
                staticClass: "welcome-dialog-quickconnect",
                attrs: {
                    width: "560",
                    height: "auto",
                    "syno-id": "welcome-app-quickconnect-create-modal",
                    "show-close": !1
                }
            }, [o("v-panel", {
                staticClass: "dialog",
                attrs: {
                    "loading-type": "statusbar",
                    "syno-id": "welcome-app-quickconnect-create-panel",
                    "error-text": e.errorText,
                    "show-status-bar": e.showStatusBar,
                    "status-bar-state": e.statusBarState,
                    "success-text": e.successText
                },
                on: {
                    "update:showStatusBar": function(t) {
                        e.showStatusBar = t
                    },
                    "update:show-status-bar": function(t) {
                        e.showStatusBar = t
                    }
                },
                scopedSlots: e._u([{
                    key: "body",
                    fn: function() {
                        return [o("div", {
                            staticClass: "body"
                        }, [o("div", {
                            staticClass: "title"
                        }, [e._v("\n                    " + e._s(e.T("welcome", "quickconnect_created_title")) + "\n                ")]), e._v(" "), o("div", {
                            staticClass: "desc"
                        }, [e._v("\n                    " + e._s(e.T("welcome", "quickconnect_created_desc")) + "\n                ")]), e._v(" "), o("v-form", {
                            staticClass: "welcome-step-quickconnect-form",
                            attrs: {
                                "syno-id": "welcome-app-quickconnect-create-form"
                            }
                        }, [o("v-form-multiple-item", {
                            attrs: {
                                label: e.T("welcome", "with_web_browsers") + ":"
                            }
                        }, [o("v-form-item", [o("v-input", {
                            attrs: {
                                id: "quickstart-quickconnect-id-url",
                                name: "quickconnectId",
                                "syno-id": "welcome-app-quickconnect-id-url-input",
                                "disable-hover-style": !0,
                                "focus-class": !1,
                                readonly: !0,
                                value: e.quickconnectUrl
                            }
                        })], 1), e._v(" "), o("v-button", {
                            staticClass: "btn",
                            attrs: {
                                "syno-id": "welcome-app-quickconnect-id-url-btn"
                            },
                            on: {
                                click: function(t) {
                                    return e.onCopy("quickstart-quickconnect-id-url")
                                }
                            }
                        })], 1), e._v(" "), o("v-form-multiple-item", {
                            attrs: {
                                label: e.T("welcome", "with_mobile_apps") + ":"
                            }
                        }, [o("v-form-item", [o("v-input", {
                            attrs: {
                                id: "quickstart-quickconnect-id",
                                name: "quickconnectId",
                                "syno-id": "welcome-app-quickconnect-id-input",
                                "disable-hover-style": !0,
                                "focus-class": !1,
                                readonly: !0,
                                value: e.quickconnect.id
                            }
                        })], 1), e._v(" "), o("v-button", {
                            staticClass: "btn",
                            attrs: {
                                "syno-id": "welcome-app-quickconnect-id-btn"
                            },
                            on: {
                                click: function(t) {
                                    return e.onCopy("quickstart-quickconnect-id")
                                }
                            }
                        })], 1)], 1)], 1)]
                    },
                    proxy: !0
                }, {
                    key: "fbar",
                    fn: function() {
                        return [o("div", {
                            staticClass: "default pull-right"
                        }, [o("v-button", {
                            attrs: {
                                "syno-id": "welcome-app-quickconnect-create-ok-btn",
                                type: "footbar",
                                color: "blue"
                            },
                            on: {
                                click: e.onClose
                            }
                        }, [e._v("\n                    " + e._s(e.T("common", "ok")) + "\n                ")])], 1)]
                    },
                    proxy: !0
                }])
            })], 1)
        };

    function Ne(e, t, o) {
        return t in e ? Object.defineProperty(e, t, {
            value: o,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = o, e
    }
    Te._withStripped = !0;
    var Pe = {
            mixins: [i.a],
            data: function() {
                return {
                    loading: !1,
                    showStatusBar: !1,
                    statusBarState: "loading",
                    successText: this.T("common", "setting_applied"),
                    errorText: this.T("common", "error_system")
                }
            },
            computed: function(e) {
                for (var t = 1; t < arguments.length; t++) {
                    var o = null != arguments[t] ? Object(arguments[t]) : {},
                        n = Object.keys(o);
                    "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(o).filter((function(e) {
                        return Object.getOwnPropertyDescriptor(o, e).enumerable
                    })))), n.forEach((function(t) {
                        Ne(e, t, o[t])
                    }))
                }
                return e
            }({}, Object(s.mapState)(["quickconnect"]), {
                quickconnectUrl: function() {
                    return String.format("https://{0}/{1}", this.quickconnect.domain ? this.quickconnect.domain : "quickconnect.to", this.quickconnect.id)
                }
            }),
            methods: {
                onCopy: function(e) {
                    this.showStatusBar = !0, this.statusBarState = "loading";
                    try {
                        document.getElementById(e).select(), document.execCommand("copy"), this.successText = this.T("welcome", "url_copied"), this.statusBarState = "success"
                    } catch (e) {
                        this.errorText = this.T("error", "clip_failed"), this.statusBarState = "error"
                    }
                },
                onClose: function() {
                    this.$refs.window.close()
                }
            }
        },
        Ae = (o(47), Object(u.a)(Pe, Te, [], !1, null, null, null));
    Ae.options.__file = "src/dialogs/quickconnect-created.vue";
    var Ye = Ae.exports,
        $e = function() {
            var e = this,
                t = e.$createElement,
                o = e._self._c || t;
            return o("v-modal-window", {
                ref: "window",
                staticClass: "syno-welcome-app-dialog",
                attrs: {
                    width: "520",
                    height: "341",
                    "syno-id": "welcome-app-autobackup-adv-modal",
                    "show-close": !1,
                    title: e.T("common", "adv_setting")
                }
            }, [o("v-panel", {
                attrs: {
                    "syno-id": "welcome-app-autobackup-adv-panel",
                    cancel: e.closeWindow,
                    confirm: e.onApply,
                    "has-fbar": !0
                }
            }, [o("template", {
                slot: "body"
            }, [o("div", {
                staticClass: "advance-settings"
            }, [o("div", {
                staticClass: "desc"
            }, [e._v("\n                    " + e._s(e.T("welcome", "choose_encryption_type")) + "\n                ")]), e._v(" "), o("v-form", {
                ref: "form",
                attrs: {
                    "syno-id": "welcome-app-autobackup-adv-form",
                    rules: e.rules
                }
            }, [o("v-radio-group", {
                attrs: {
                    name: "encryptionCheck",
                    "syno-id": "welcome-app-autobackup-adv-radio-group"
                },
                model: {
                    value: e.fields.encryptionCheck,
                    callback: function(t) {
                        e.$set(e.fields, "encryptionCheck", t)
                    },
                    expression: "fields.encryptionCheck"
                }
            }, [o("v-radio", {
                attrs: {
                    name: "encryptionCheck",
                    "syno-id": "welcome-app-autobackup-adv-auto-encryption-radio",
                    value: "auto"
                }
            }, [e._v("\n                            " + e._s(e.T("confbackup", "auto_enc")) + "\n                        ")]), e._v(" "), o("v-radio", {
                attrs: {
                    name: "encryptionCheck",
                    "syno-id": "welcome-app-autobackup-adv-self-encryption-radio",
                    value: "manual"
                }
            }, [e._v("\n                            " + e._s(e.T("confbackup", "self_enc")) + "\n                            "), o("v-form-item", {
                attrs: {
                    "syno-id": "welcome-app-autobackup-adv-password-form-item",
                    prop: "password",
                    label: e.T("user", "user_passwd") + ":"
                }
            }, [o("v-input", {
                attrs: {
                    name: "password",
                    "syno-id": "welcome-app-autobackup-adv-password-item",
                    type: "password",
                    "fit-container": "",
                    disabled: "auto" === e.fields.encryptionCheck,
                    "strength-checker": e.strengthChecker
                },
                model: {
                    value: e.fields.password,
                    callback: function(t) {
                        e.$set(e.fields, "password", t)
                    },
                    expression: "fields.password"
                }
            })], 1), e._v(" "), o("v-form-item", {
                attrs: {
                    "syno-id": "welcome-app-autobackup-adv-confirm-password-form-item",
                    prop: "confirmPassword",
                    label: e.T("user", "user_repswd") + ":"
                }
            }, [o("v-input", {
                attrs: {
                    name: "password",
                    "syno-id": "welcome-app-autobackup-adv-confirm-password-item",
                    type: "password",
                    "fit-container": "",
                    disabled: "auto" === e.fields.encryptionCheck
                },
                model: {
                    value: e.fields.confirmPassword,
                    callback: function(t) {
                        e.$set(e.fields, "confirmPassword", t)
                    },
                    expression: "fields.confirmPassword"
                }
            })], 1)], 1)], 1)], 1)], 1)])], 2)], 1)
        };

    function De(e, t, o, n, i, s, r) {
        try {
            var a = e[s](r),
                c = a.value
        } catch (e) {
            return void o(e)
        }
        a.done ? t(c) : Promise.resolve(c).then(n, i)
    }

    function Be(e) {
        for (var t = 1; t < arguments.length; t++) {
            var o = null != arguments[t] ? Object(arguments[t]) : {},
                n = Object.keys(o);
            "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(o).filter((function(e) {
                return Object.getOwnPropertyDescriptor(o, e).enumerable
            })))), n.forEach((function(t) {
                Ee(e, t, o[t])
            }))
        }
        return e
    }

    function Ee(e, t, o) {
        return t in e ? Object.defineProperty(e, t, {
            value: o,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = o, e
    }
    $e._withStripped = !0;
    var Ie, ze = {
            mixins: [i.a, c.a],
            props: {
                resolver: {
                    type: Function,
                    default: void 0
                }
            },
            data: function() {
                return {
                    fields: {
                        encryptionCheck: "auto",
                        password: void 0,
                        confirmPassword: void 0
                    },
                    rules: {
                        password: {
                            required: !0,
                            validator: this.validatePassword
                        },
                        confirmPassword: {
                            validator: this.validateConfirmPassword
                        },
                        min_length: 8
                    }
                }
            },
            computed: Be({}, Object(s.mapState)(["encryption"])),
            mounted: function() {
                this.fields.encryptionCheck = this.encryption.encryptionCheck, this.fields.password = this.fields.confirmPassword = this.encryption.password
            },
            methods: {
                onApply: (Ie = function(e) {
                    return function() {
                        var t = this,
                            o = arguments;
                        return new Promise((function(n, i) {
                            var s = e.apply(t, o);

                            function r(e) {
                                De(s, n, i, r, a, "next", e)
                            }

                            function a(e) {
                                De(s, n, i, r, a, "throw", e)
                            }
                            r(void 0)
                        }))
                    }
                }(regeneratorRuntime.mark((function e() {
                    var t;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if ("auto" !== this.fields.encryptionCheck) {
                                    e.next = 6;
                                    break
                                }
                                this.$store.commit("setEncryption", this.fields), this.resolver && this.resolver(Be({}, this.fields)), this.closeWindow(!0), e.next = 22;
                                break;
                            case 6:
                                return e.prev = 6, e.next = 9, this.$refs.form.validate();
                            case 9:
                                if (e.sent) {
                                    e.next = 12;
                                    break
                                }
                                throw {
                                    text: this.T("common", "forminvalid")
                                };
                            case 12:
                                this.$store.commit("setEncryption", this.fields), this.resolver && this.resolver(Be({}, this.fields)), this.closeWindow(!0), e.next = 22;
                                break;
                            case 17:
                                e.prev = 17, e.t0 = e.catch(6), t = this.T("common", "error_system"), t = e.t0.code ? SYNO.API.Errors.core[e.t0.code] : e.t0.text, this.$refs.window.getMsgBox().alert("", t);
                            case 22:
                            case "end":
                                return e.stop()
                        }
                    }), e, this, [
                        [6, 17]
                    ])
                }))), function() {
                    return Ie.apply(this, arguments)
                }),
                closeWindow: function() {
                    this.$refs.window.close()
                },
                validatePassword: function(e, t, o) {
                    return !(!this.fields.password || this.fields.password.length < this.rules.min_length) || new Error(this.T("passwd", "min_length_enable") + " " + this.rules.min_length)
                },
                validateConfirmPassword: function(e, t, o) {
                    return this.fields.password === this.fields.confirmPassword || new Error(_JSLIBSTR("vtype", "password_confirm_failed"))
                }
            }
        },
        Re = (o(51), Object(u.a)(ze, $e, [], !1, null, null, null));
    Re.options.__file = "src/dialogs/useful-tools-adv-settings.vue";
    var Le = Re.exports;
    Ext.namespace("SYNO.SDS.App.WelcomeApp"), // @require: SYNO.SDS.SynologyAccount.WebLogin
    
 /**
 * @class SYNO.SDS.App.WelcomeApp.Instance
 * WelcomeApp application instance class
 *
 */      
        SYNO.SDS.App.WelcomeApp.Instance = Vue.extend({
            components: {
                QuickStart: Oe
            },
            template: "<QuickStart/>",
            store: r
        }), SYNO.SDS.App.WelcomeApp.QuickconnectCreated = Vue.extend({
            components: {
                QuickconnectCreated: Ye
            },
            template: "<QuickconnectCreated/>",
            store: r
        }), SYNO.SDS.App.WelcomeApp.UsefulToolsAdvSettings = Vue.extend({
            components: {
                UsefulToolsAdvSettings: Le
            },
            template: '<UsefulToolsAdvSettings :resolver="resolver" />',
            props: ["resolver"],
            store: r
        })
}]);
