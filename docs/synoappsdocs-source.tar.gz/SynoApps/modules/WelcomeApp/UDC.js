/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.define("SYNO.SDS.UDC.Utils", {
    singleton: !0,
    sendWebAPIPrmoise: function(e) {
        return new Promise(function(t, n) {
            var i = this.findAppWindow();
            e.callback = function(e, i, s, o) {
                e && !i || !1 === i.has_fail ? t({
                    succ: e,
                    data: i,
                    request: s,
                    opts: o
                }) : n({
                    succ: e,
                    data: i,
                    request: s,
                    opts: o
                })
            }, i.sendWebAPI(e)
        }.bind(this))
    },
    setUDCState: function(e) {
        return this.sendWebAPIPrmoise({
            api: "SYNO.Core.QuickStart.Info",
            version: 1,
            method: "set_udc",
            params: {
                udc_value: e
            }
        })
    }
}), 
 /**
 * @class SYNO.SDS.UDC.WelcomePanel
 * @extends Ext.Container
 * Welcome panel class
 *
 */  
Ext.define("SYNO.SDS.UDC.WelcomePanel", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = {
            cls: "udc-welcome-panel inner-panel",
            items: [{
                xtype: "box",
                cls: "content title",
                html: _T("welcome", "udc_welcome_title")
            }, {
                xtype: "box",
                cls: "content desc",
                html: _T("welcome", "udc_welcome_desc")
            }, {
                xtype: "container",
                cls: "bbar",
                items: [{
                    xtype: "syno_button",
                    btnStyle: "blue",
                    width: "100%",
                    text: _T("welcome", "udc_sure"),
                    handler: this.onSureBtnClick.bind(this)
                }, {
                    xtype: "syno_button",
                    text: _T("welcome", "udc_later"),
                    handler: this.onRemindBtnClick.bind(this)
                }, {
                    xtype: "box",
                    cls: "skip-btn",
                    html: _T("common", "no_thanks"),
                    listeners: {
                        afterrender: this.onSkipBtnRender.bind(this)
                    }
                }]
            }]
        };
        this.callParent([Ext.apply(t, e)])
    },
    onSkipBtnRender: function(e) {
        e.el.on("click", this.onDisagree.bind(this))
    },
    sendWebAPIPrmoise: SYNO.SDS.UDC.Utils.sendWebAPIPrmoise,
    setUDCState: SYNO.SDS.UDC.Utils.setUDCState,
    onSureBtnClick: function() {
        this.hide()
    },
    onRemindBtnClick: function() {
        this.setUDCState("later").then(function() {
            this.findAppWindow().close()
        }.bind(this)).catch(function() {
            this.findAppWindow().close()
        }.bind(this))
    },
    onDisagree: function() {
        this.sendWebAPIPrmoise({
            api: "SYNO.Core.DataCollect",
            version: 1,
            method: "set",
            params: {
                enable: !1
            }
        }).then(this.setUDCState.bind(this, _S("productversion"))).then(function() {
            this.findAppWindow().close()
        }.bind(this)).catch(function() {
            this.findAppWindow().close()
        }.bind(this))
    }
}), Ext.define("SYNO.SDS.UDC.StatementPanel", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = {
            cls: "udc-statement-panel inner-panel",
            items: [{
                xtype: "container",
                cls: "statement-title-wrap",
                items: [{
                    xtype: "box",
                    cls: "statement-title",
                    html: _T("welcome", "udc_statement_title")
                }]
            }, {
                xtype: "container",
                cls: "statement-content-wrap",
                items: {
                    ref: "../statementBox",
                    xtype: "box",
                    cls: "statement-content",
                    autoFlexcroll: !0,
                    updateScrollBarEventNames: ["afterrender"],
                    html: _T("welcome", "udc_statement_content")
                }
            }, {
                xtype: "container",
                cls: "statement-checkbox-wrap",
                items: [{
                    xtype: "syno_checkbox",
                    htmlEncode: !1,
                    checked: !1,
                    boxLabel: _T("welcome", "udc_statement_checkbox"),
                    listeners: {
                        check: this.onUDCStatementCheck.bind(this)
                    }
                }]
            }, {
                xtype: "container",
                cls: "bbar",
                items: [{
                    xtype: "syno_button",
                    btnStyle: "blue",
                    ref: "../confirmBtn",
                    disabled: !0,
                    text: _T("common", "ok"),
                    handler: this.onAgree.bind(this)
                }]
            }, {
                xtype: "box",
                cls: "close-btn",
                listeners: {
                    afterrender: this.onCloseBtnRender.bind(this)
                }
            }]
        };
        this.callParent([Ext.apply(t, e)]), this.mon(this, "show", this.onAfterShow, this)
    },
    onUDCStatementCheck: function(e, t) {
        this.confirmBtn.setDisabled(!t)
    },
    onAfterShow: function() {
        this.statementBox.updateFleXcroll(), this.addClass.defer(10, this, ["activate"])
    },
    onCloseBtnRender: function(e) {
        e.el.on("click", function() {
            this.el.dom.classList.remove("activate"), this.hide.defer(250, this)
        }, this)
    },
    sendWebAPIPrmoise: SYNO.SDS.UDC.Utils.sendWebAPIPrmoise,
    setUDCState: SYNO.SDS.UDC.Utils.setUDCState,
    onAgree: function() {
        this.sendWebAPIPrmoise({
            api: "SYNO.Core.DataCollect",
            version: 1,
            method: "set",
            params: {
                enable: !0
            }
        }).then(this.setUDCState.bind(this, _S("productversion"))).then(function() {
            this.findAppWindow().close()
        }.bind(this)).catch(function() {
            this.findAppWindow().close()
        }.bind(this))
    }
}), Ext.define("SYNO.SDS.UDC.MainPanel", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = [];
        SYNO.SDS.UDC.Constraint.isUDCVisible() && (t = t.concat([new SYNO.SDS.UDC.WelcomePanel({
            owner: this,
            itemId: "welcome"
        }), new SYNO.SDS.UDC.StatementPanel({
            owner: this,
            itemId: "statement",
            hidden: !0
        })]));
        var n = {
            cls: "udc-main-panel",
            activeItem: "welcome",
            width: 600,
            height: 494,
            hideMode: "offsets",
            items: t
        };
        this.callParent([Ext.apply(n, e)]), this.bindEvents()
    },
    bindEvents: function() {
        var e = this.getComponent("welcome"),
            t = this.getComponent("statement");
        e && e.mon(t, "hide", function() {
            e.show()
        }), t && t.mon(e, "hide", function() {
            t.show()
        })
    },
    sendWebAPIPrmoise: SYNO.SDS.UDC.Utils.sendWebAPIPrmoise,
    setUDCState: SYNO.SDS.UDC.Utils.setUDCState
}), Ext.define("SYNO.SDS.UDC.Constraint", {
    singleton: !0,
    isUDCVisible: function() {
        var e = _S("udc_enabled"),
            t = _S("udc_check_state");
        return "yes" !== e && (Ext.isEmpty(t) || "later" === t || t !== _S("productversion"))
    }
}), Ext.define("SYNO.SDS.UDC.Instance", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.UDC.AppWindow",
    fullsize: !0,
    shouldLaunch: function() {
        var e = SYNO.SDS.UDC.Constraint.isUDCVisible();
        return e || SYNO.SDS.App.PromotionApp.QuickTourTrayLauncher(), e
    }
}), Ext.define("SYNO.SDS.UDC.AppWindow", {
    extend: "SYNO.SDS.AppWindow",
    constructor: function(e) {
        var t = {
            border: !1,
            toggleGrayOverlay: !1,
            toggleMinimizable: !1,
            defaultMaximized: !0,
            maximized: !0,
            resizable: !1,
            header: !1,
            showHelp: !1,
            cls: "syno-udc-win",
            renderTo: document.body,
            items: new SYNO.SDS.UDC.MainPanel
        };
        this.callParent([Ext.apply(t, e)]), this.mon(this, "beforedestroy", SYNO.SDS.App.PromotionApp.QuickTourTrayLauncher)
    },
    onOpen: function() {
        SYNO.SDS.ShowDesktop(), this.callParent(arguments)
    }
});
