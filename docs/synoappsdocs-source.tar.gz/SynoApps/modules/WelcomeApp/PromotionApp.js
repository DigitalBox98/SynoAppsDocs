! function(e) {
    var i = {};

    function o(t) {
        if (i[t]) return i[t].exports;
        var n = i[t] = {
            i: t,
            l: !1,
            exports: {}
        };
        return e[t].call(n.exports, n, n.exports, o), n.l = !0, n.exports
    }
    o.m = e, o.c = i, o.d = function(e, i, t) {
        o.o(e, i) || Object.defineProperty(e, i, {
            enumerable: !0,
            get: t
        })
    }, o.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, o.t = function(e, i) {
        if (1 & i && (e = o(e)), 8 & i) return e;
        if (4 & i && "object" == typeof e && e && e.__esModule) return e;
        var t = Object.create(null);
        if (o.r(t), Object.defineProperty(t, "default", {
                enumerable: !0,
                value: e
            }), 2 & i && "string" != typeof e)
            for (var n in e) o.d(t, n, function(i) {
                return e[i]
            }.bind(null, n));
        return t
    }, o.n = function(e) {
        var i = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return o.d(i, "a", i), i
    }, o.o = function(e, i) {
        return Object.prototype.hasOwnProperty.call(e, i)
    }, o.p = "", o(o.s = 74)
}([function(e, i, o) {
    "use strict";

    function t(e, i, o, t, n, a, s, r) {
        var p, c = "function" == typeof e ? e.options : e;
        if (i && (c.render = i, c.staticRenderFns = o, c._compiled = !0), t && (c.functional = !0), a && (c._scopeId = "data-v-" + a), s ? (p = function(e) {
                (e = e || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) || "undefined" == typeof __VUE_SSR_CONTEXT__ || (e = __VUE_SSR_CONTEXT__), n && n.call(this, e), e && e._registeredComponents && e._registeredComponents.add(s)
            }, c._ssrRegister = p) : n && (p = r ? function() {
                n.call(this, this.$root.$options.shadowRoot)
            } : n), p)
            if (c.functional) {
                c._injectStyles = p;
                var m = c.render;
                c.render = function(e, i) {
                    return p.call(i), m(e, i)
                }
            } else {
                var l = c.beforeCreate;
                c.beforeCreate = l ? [].concat(l, p) : [p]
            } return {
            exports: e,
            options: c
        }
    }
    o.d(i, "a", (function() {
        return t
    }))
}, function(e, i, o) {
    "use strict";
    i.a = {
        methods: {
            T: function(e, i) {
                var o = _T(e, i);
                return o && "" !== o ? o : "".concat(e, ":").concat(i)
            },
            D: function(e) {
                var i = _D(e);
                return i && "" !== i ? i : "".concat(e)
            },
            htmlEncode: function(e) {
                return e ? String(e).replace(/&/g, "&amp;").replace(/>/g, "&gt;").replace(/</g, "&lt;").replace(/'/g, "&quot;").replace(/'/g, "&apos;") : e
            },
            urlEncode: function(e) {
                var i = [];
                for (var o in e) i.push(encodeURIComponent(o) + "=" + encodeURIComponent(e[o]));
                return i.join("&")
            },
            formatUrl: function(e, i, o) {
                var t = '<a href="{0}" target="_blank">';
                return String.format(e, String.format(t, i), "</a>", String.format(t, o), "</a>")
            }
        }
    }
}, function(e, i, o) {
    "use strict";

    function t(e, i, o, t, n, a, s) {
        try {
            var r = e[a](s),
                p = r.value
        } catch (e) {
            return void o(e)
        }
        r.done ? i(p) : Promise.resolve(p).then(t, n)
    }

    function n(e) {
        return function() {
            var i = this,
                o = arguments;
            return new Promise((function(n, a) {
                var s = e.apply(i, o);

                function r(e) {
                    t(s, n, a, r, p, "next", e)
                }

                function p(e) {
                    t(s, n, a, r, p, "throw", e)
                }
                r(void 0)
            }))
        }
    }
    var a, s;
    i.a = {
        methods: {
            strengthChecker: function(e) {
                var i = ["weak", "medium", "strong"],
                    o = [this.T("welcome", "passwd_weak"), this.T("welcome", "passwd_medium"), this.T("welcome", "passwd_strong")];
                return synowebapi.promises.request({
                    api: "SYNO.Core.User.PasswordMeter",
                    method: "evaluate",
                    version: "1",
                    encryption: ["password"],
                    params: {
                        password: e,
                        required_rules: this.rules
                    }
                }).then((function(e) {
                    var t = function(e) {
                        return Math.floor(e / 2)
                    }(e.score);
                    return {
                        strength: i[t],
                        strengthText: o[t]
                    }
                }))
            },
            setUdc: (s = n(regeneratorRuntime.mark((function e(i) {
                var o, t, n, a, s = arguments;
                return regeneratorRuntime.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return o = s.length > 1 && void 0 !== s[1] && s[1], t = [{
                                api: "SYNO.Core.DataCollect",
                                method: "set",
                                version: 1,
                                params: {
                                    enable: i
                                }
                            }, {
                                api: "SYNO.Core.QuickStart.Info",
                                method: "set_udc",
                                version: 1,
                                params: {
                                    udc_value: _S("productversion")
                                }
                            }], o && (t = t.concat([{
                                api: "SYNO.Core.QuickStart.Info",
                                method: "set_confautobkp",
                                version: 1,
                                params: {
                                    confautobkp_value: "done"
                                }
                            }, {
                                api: "SYNO.Core.QuickStart.Info",
                                method: "set_mib",
                                version: 2,
                                params: {
                                    mib_value: _S("productversion") + _S("buildphase")
                                }
                            }])), e.prev = 3, e.next = 6, synowebapi.promises.request({
                                api: "SYNO.Entry.Request",
                                method: "request",
                                version: 1,
                                compound: {
                                    mode: "sequential",
                                    stopwhenerror: !0,
                                    params: t
                                }
                            });
                        case 6:
                            !0 === (n = e.sent).has_fail ? (a = SYNO.API.Response.GetFirstError(n), this.$emit("display-error", a), this.$emit("set-loader", !1), this.updateFooter()) : (SYNO.SDS.Session.udc_check_state = _S("productversion"), SYNO.SDS.Session.udc_enabled = i, this.$emit("close")), e.next = 15;
                            break;
                        case 10:
                            e.prev = 10, e.t0 = e.catch(3), this.$emit("display-error", e.t0), this.$emit("set-loader", !1), this.updateFooter();
                        case 15:
                            return e.prev = 15, e.finish(15);
                        case 17:
                        case "end":
                            return e.stop()
                    }
                }), e, this, [
                    [3, 10, 15, 17]
                ])
            }))), function(e) {
                return s.apply(this, arguments)
            }),
            setStepWebapi: (a = n(regeneratorRuntime.mark((function e(i) {
                return regeneratorRuntime.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return e.prev = 0, e.next = 3, synowebapi.promises.request({
                                api: "SYNO.Core.QuickStart.Info",
                                method: "set_wizard_step",
                                version: 3,
                                params: {
                                    quickstart_wizard_step: i
                                }
                            });
                        case 3:
                            e.next = 8;
                            break;
                        case 5:
                            e.prev = 5, e.t0 = e.catch(0), SYNO.Debug.error(e.t0);
                        case 8:
                        case "end":
                            return e.stop()
                    }
                }), e, this, [
                    [0, 5]
                ])
            }))), function(e) {
                return a.apply(this, arguments)
            }),
            uuid: function() {
                return "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, (function(e) {
                    var i = 16 * Math.random() | 0;
                    return ("x" == e ? i : 3 & i | 8).toString(16)
                }))
            }
        }
    }
}, , function(e, i, o) {
    "use strict";
    e.exports = function(e) {
        var i = [];
        return i.toString = function() {
            return this.map((function(i) {
                var o = function(e, i) {
                    var o = e[1] || "",
                        t = e[3];
                    if (!t) return o;
                    if (i && "function" == typeof btoa) {
                        var n = (s = t, "/*# sourceMappingURL=data:application/json;charset=utf-8;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(s)))) + " */"),
                            a = t.sources.map((function(e) {
                                return "/*# sourceURL=" + t.sourceRoot + e + " */"
                            }));
                        return [o].concat(a).concat([n]).join("\n")
                    }
                    var s;
                    return [o].join("\n")
                }(i, e);
                return i[2] ? "@media " + i[2] + "{" + o + "}" : o
            })).join("")
        }, i.i = function(e, o) {
            "string" == typeof e && (e = [
                [null, e, ""]
            ]);
            for (var t = {}, n = 0; n < this.length; n++) {
                var a = this[n][0];
                null != a && (t[a] = !0)
            }
            for (n = 0; n < e.length; n++) {
                var s = e[n];
                null != s[0] && t[s[0]] || (o && !s[2] ? s[2] = o : o && (s[2] = "(" + s[2] + ") and (" + o + ")"), i.push(s))
            }
        }, i
    }
}, function(e, i, o) {
    "use strict";

    function t(e, i) {
        for (var o = [], t = {}, n = 0; n < i.length; n++) {
            var a = i[n],
                s = a[0],
                r = {
                    id: e + ":" + n,
                    css: a[1],
                    media: a[2],
                    sourceMap: a[3]
                };
            t[s] ? t[s].parts.push(r) : o.push(t[s] = {
                id: s,
                parts: [r]
            })
        }
        return o
    }
    o.r(i), o.d(i, "default", (function() {
        return g
    }));
    var n = "undefined" != typeof document;
    if ("undefined" != typeof DEBUG && DEBUG && !n) throw new Error("vue-style-loader cannot be used in a non-browser environment. Use { target: 'node' } in your Webpack config to indicate a server-rendering environment.");
    var a = {},
        s = n && (document.head || document.getElementsByTagName("head")[0]),
        r = null,
        p = 0,
        c = !1,
        m = function() {},
        l = null,
        u = "undefined" != typeof navigator && /msie [6-9]\b/.test(navigator.userAgent.toLowerCase());

    function g(e, i, o, n) {
        c = o, l = n || {};
        var s = t(e, i);
        return d(s),
            function(i) {
                for (var o = [], n = 0; n < s.length; n++) {
                    var r = s[n];
                    (p = a[r.id]).refs--, o.push(p)
                }
                i ? d(s = t(e, i)) : s = [];
                for (n = 0; n < o.length; n++) {
                    var p;
                    if (0 === (p = o[n]).refs) {
                        for (var c = 0; c < p.parts.length; c++) p.parts[c]();
                        delete a[p.id]
                    }
                }
            }
    }

    function d(e) {
        for (var i = 0; i < e.length; i++) {
            var o = e[i],
                t = a[o.id];
            if (t) {
                t.refs++;
                for (var n = 0; n < t.parts.length; n++) t.parts[n](o.parts[n]);
                for (; n < o.parts.length; n++) t.parts.push(h(o.parts[n]));
                t.parts.length > o.parts.length && (t.parts.length = o.parts.length)
            } else {
                var s = [];
                for (n = 0; n < o.parts.length; n++) s.push(h(o.parts[n]));
                a[o.id] = {
                    id: o.id,
                    refs: 1,
                    parts: s
                }
            }
        }
    }

    function f() {
        var e = document.createElement("style");
        return e.type = "text/css", s.appendChild(e), e
    }

    function h(e) {
        var i, o, t = document.querySelector('style[data-vue-ssr-id~="' + e.id + '"]');
        if (t) {
            if (c) return m;
            t.parentNode.removeChild(t)
        }
        if (u) {
            var n = p++;
            t = r || (r = f()), i = y.bind(null, t, n, !1), o = y.bind(null, t, n, !0)
        } else t = f(), i = x.bind(null, t), o = function() {
            t.parentNode.removeChild(t)
        };
        return i(e),
            function(t) {
                if (t) {
                    if (t.css === e.css && t.media === e.media && t.sourceMap === e.sourceMap) return;
                    i(e = t)
                } else o()
            }
    }
    var b, v = (b = [], function(e, i) {
        return b[e] = i, b.filter(Boolean).join("\n")
    });

    function y(e, i, o, t) {
        var n = o ? "" : t.css;
        if (e.styleSheet) e.styleSheet.cssText = v(i, n);
        else {
            var a = document.createTextNode(n),
                s = e.childNodes;
            s[i] && e.removeChild(s[i]), s.length ? e.insertBefore(a, s[i]) : e.appendChild(a)
        }
    }

    function x(e, i) {
        var o = i.css,
            t = i.media,
            n = i.sourceMap;
        if (t && e.setAttribute("media", t), l.ssrId && e.setAttribute("data-vue-ssr-id", i.id), n && (o += "\n/*# sourceURL=" + n.sources[0] + " */", o += "\n/*# sourceMappingURL=data:application/json;base64," + btoa(unescape(encodeURIComponent(JSON.stringify(n)))) + " */"), e.styleSheet) e.styleSheet.cssText = o;
        else {
            for (; e.firstChild;) e.removeChild(e.firstChild);
            e.appendChild(document.createTextNode(o))
        }
    }
}, function(e, i, o) {
    "use strict";
    e.exports = function(e, i) {
        return "string" != typeof e ? e : (/^['"].*['"]$/.test(e) && (e = e.slice(1, -1)), /["'() \t\n]/.test(e) || i ? '"' + e.replace(/"/g, '\\"').replace(/\n/g, "\\n") + '"' : e)
    }
}, , , , , , , , , , , , , function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/4fa235b68da3c32bfc03ba5a51a06ad4.png"
}, function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/0c8c2b2ee6ed75fe1133323ef98e516a.png"
}, , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , , function(e, i, o) {
    var t = o(54);
    "string" == typeof t && (t = [
        [e.i, t, ""]
    ]), t.locals && (e.exports = t.locals);
    (0, o(5).default)("5e8d4054", t, !1, {})
}, function(e, i, o) {
    i = e.exports = o(4)(!1);
    var t = o(6),
        n = t(o(55)),
        a = t(o(56)),
        s = t(o(57)),
        r = t(o(58)),
        p = t(o(59)),
        c = t(o(60)),
        m = t(o(19)),
        l = t(o(20)),
        u = t(o(61)),
        g = t(o(62)),
        d = t(o(63)),
        f = t(o(64)),
        h = t(o(65)),
        b = t(o(66)),
        v = t(o(67)),
        y = t(o(68)),
        x = t(o(69)),
        _ = t(o(70)),
        w = t(o(71)),
        k = t(o(72));
    i.push([e.i, ".syno-promotion-app .syno-promotion-app-intro .services .item .name,.syno-promotion-app .syno-promotion-app-config .title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.syno-promotion-app .btn-group .btn-create,.syno-promotion-app .btn-group .btn-skip,.syno-promotion-app .syno-promotion-app-welcome .main .admin-user .subtitle,.syno-promotion-app .syno-promotion-app-welcome .main .normal-user .subtitle,.syno-promotion-app .syno-promotion-app-intro .subtitle,.syno-promotion-app .syno-promotion-app-intro .services .item .desc,.syno-promotion-app .syno-promotion-app-config .subtitle,.syno-promotion-app .syno-promotion-app-config .content{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:400}.syno-promotion-app .syno-promotion-app-welcome .main .admin-user .title,.syno-promotion-app .syno-promotion-app-welcome .main .admin-user .features .feature .text,.syno-promotion-app .syno-promotion-app-welcome .main .normal-user .title,.syno-promotion-app .syno-promotion-app-intro .title{font-family:Verdana,Arial,Microsoft JhengHei,sans-serif;font-weight:700}.syno-cjk .syno-promotion-app .syno-promotion-app-welcome .main .admin-user .title,.syno-promotion-app .syno-promotion-app-welcome .main .admin-user .syno-cjk .title,.syno-cjk .syno-promotion-app .syno-promotion-app-welcome .main .admin-user .features .feature .text,.syno-promotion-app .syno-promotion-app-welcome .main .admin-user .features .feature .syno-cjk .text,.syno-cjk .syno-promotion-app .syno-promotion-app-welcome .main .normal-user .title,.syno-promotion-app .syno-promotion-app-welcome .main .normal-user .syno-cjk .title,.syno-cjk .syno-promotion-app .syno-promotion-app-intro .title,.syno-promotion-app .syno-promotion-app-intro .syno-cjk .title{font-weight:600}.syno-promotion-app-msg-box.v-window.v-message-box-window span.syno-ux-note{color:#00A6A6}@keyframes mask-bg{from{background-color:transparent}to{background-color:rgba(0,0,0,0.2)}}.syno-promotion-app-mask{animation:0.1s mask-bg forwards;position:absolute;top:0;right:0;bottom:0;left:0;z-index:10;width:100%;height:100%}.syno-promotion-app{transition-property:top, right, bottom, left, height, width;transition-duration:.4s;transition-timing-function:ease}.syno-promotion-app .content-fade-enter-active,.syno-promotion-app .content-fade-leave-active{transition:opacity .4s ease}.syno-promotion-app .content-fade-enter,.syno-promotion-app .content-fade-leave-to{opacity:0}.syno-promotion-app .v-ps{padding-right:0}.syno-promotion-app .v-ps .ps__rail-y{opacity:0.6}.syno-promotion-app .v-window-header-wrapper{display:none}.syno-promotion-app .btn-group{flex:1;display:flex;flex-direction:column;justify-content:flex-end}.syno-promotion-app .btn-group .btn-continue{width:200px;align-self:center}.syno-promotion-app .btn-group .btn-continue.apply{margin-top:30px;margin-bottom:2px}.syno-promotion-app .btn-group .btn-create{align-self:center;text-align:center;font-size:12px;line-height:20px;color:#057FEB;text-decoration:underline;margin-top:16px}.syno-promotion-app .btn-group .btn-create:hover{cursor:pointer;color:#006DCC}.syno-promotion-app .btn-group .btn-skip{align-self:center;text-align:center;font-size:12px;line-height:20px;margin-top:4px;color:#414b55;text-decoration:underline}.syno-promotion-app .btn-group .btn-skip:hover{cursor:pointer;color:#057FEB}.syno-promotion-app .syno-promotion-app-welcome{width:100%;height:100%;padding:32px 40px;display:flex;flex-direction:column;align-items:center;box-sizing:border-box}.syno-promotion-app .syno-promotion-app-welcome .main{width:100%}.syno-promotion-app .syno-promotion-app-welcome .main .admin-user{height:368px;width:100%;display:flex;flex-direction:column;align-items:center}.syno-promotion-app .syno-promotion-app-welcome .main .admin-user .title{width:560px;color:#414b55;font-size:22px;line-height:32px;text-align:center;margin-bottom:12px}.syno-promotion-app .syno-promotion-app-welcome .main .admin-user .subtitle{width:560px;height:40px;color:#414b55;font-size:13px;line-height:20px;text-align:center;margin-bottom:52px}.syno-promotion-app .syno-promotion-app-welcome .main .admin-user .features{height:100%;width:100%;display:flex;flex-direction:row}.syno-promotion-app .syno-promotion-app-welcome .main .admin-user .features .feature{flex:1;height:100%;display:flex;flex-direction:column;align-items:center}.syno-promotion-app .syno-promotion-app-welcome .main .admin-user .features .feature .img{height:90px;width:100%;background-position:center}.syno-promotion-app .syno-promotion-app-welcome .main .admin-user .features .feature .img.left{background-size:220px 90px;background-image:url(" + n + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-promotion-app .syno-promotion-app-welcome .main .admin-user .features .feature .img.left{background-image:url(" + a + ');background-size:image-width("../../images/default/1x/img_welcome_intuitive.png") image-height("../../images/default/1x/img_welcome_intuitive.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-promotion-app .syno-promotion-app-welcome .main .admin-user .features .feature .img.left{background-image:url(' + a + ');background-size:image-width("../../images/default/1x/img_welcome_intuitive.png") image-height("../../images/default/1x/img_welcome_intuitive.png");outline:1px green dashed}}.syno-promotion-app .syno-promotion-app-welcome .main .admin-user .features .feature .img.center{background-size:220px 90px;background-image:url(' + s + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-promotion-app .syno-promotion-app-welcome .main .admin-user .features .feature .img.center{background-image:url(" + r + ');background-size:image-width("../../images/default/1x/img_welcome_management.png") image-height("../../images/default/1x/img_welcome_management.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-promotion-app .syno-promotion-app-welcome .main .admin-user .features .feature .img.center{background-image:url(' + r + ');background-size:image-width("../../images/default/1x/img_welcome_management.png") image-height("../../images/default/1x/img_welcome_management.png");outline:1px green dashed}}.syno-promotion-app .syno-promotion-app-welcome .main .admin-user .features .feature .img.right{background-size:220px 90px;background-image:url(' + p + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-promotion-app .syno-promotion-app-welcome .main .admin-user .features .feature .img.right{background-image:url(" + c + ');background-size:image-width("../../images/default/1x/img_welcome_secure.png") image-height("../../images/default/1x/img_welcome_secure.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-promotion-app .syno-promotion-app-welcome .main .admin-user .features .feature .img.right{background-image:url(' + c + ');background-size:image-width("../../images/default/1x/img_welcome_secure.png") image-height("../../images/default/1x/img_welcome_secure.png");outline:1px green dashed}}.syno-promotion-app .syno-promotion-app-welcome .main .admin-user .features .feature .text{color:#414b55;font-size:13px;line-height:20px;text-align:center}.syno-promotion-app .syno-promotion-app-welcome .main .normal-user{min-height:253px;box-sizing:border-box;padding-top:123px;display:flex;flex-direction:column;justify-content:flex-end;align-items:center}.syno-promotion-app .syno-promotion-app-welcome .main .normal-user .title{width:100%;color:#414b55;font-size:30px;line-height:44px;text-align:center;margin-bottom:10px}.syno-promotion-app .syno-promotion-app-welcome .main .normal-user .subtitle{width:100%;color:#414b55;font-size:18px;line-height:28px;text-align:center;margin-bottom:48px}.syno-promotion-app .syno-promotion-app-welcome .footer{flex:1;width:100%;display:flex;flex-direction:column;justify-content:space-between;align-items:center}.syno-promotion-app .syno-promotion-app-welcome .footer .btn{width:200px}.syno-promotion-app .syno-promotion-app-welcome .footer .syno-logo{background-size:78px 24px;background-image:url(' + m + ");height:24px;width:78px;opacity:.6}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-promotion-app .syno-promotion-app-welcome .footer .syno-logo{background-image:url(" + l + ');background-size:image-width("../../images/default/1x/synology_logo.png") image-height("../../images/default/1x/synology_logo.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-promotion-app .syno-promotion-app-welcome .footer .syno-logo{background-image:url(' + l + ');background-size:image-width("../../images/default/1x/synology_logo.png") image-height("../../images/default/1x/synology_logo.png");outline:1px green dashed}}.syno-promotion-app .syno-promotion-app-intro{width:100%;height:100%;padding:32px 40px;display:flex;flex-direction:column;align-items:center;box-sizing:border-box}.syno-promotion-app .syno-promotion-app-intro .title{color:#414b55;width:100%;font-size:22px;line-height:32px;text-align:center;margin-bottom:12px}.syno-promotion-app .syno-promotion-app-intro .subtitle{color:#414b55;width:560px;height:60px;font-size:13px;line-height:20px;text-align:center;margin-bottom:32px}.syno-promotion-app .syno-promotion-app-intro .services{width:100%;display:flex;flex-direction:row;justify-content:center;margin-bottom:22px}.syno-promotion-app .syno-promotion-app-intro .services .item{width:220px;height:190px;display:flex;flex-direction:column;align-items:center}.syno-promotion-app .syno-promotion-app-intro .services .item .img{width:100%;height:90px}.syno-promotion-app .syno-promotion-app-intro .services .item .img.secure-signin{background-size:220px 90px;background-image:url(' + u + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-promotion-app .syno-promotion-app-intro .services .item .img.secure-signin{background-image:url(" + g + ');background-size:image-width("../../images/default/1x/img_secure_sign_in.png") image-height("../../images/default/1x/img_secure_sign_in.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-promotion-app .syno-promotion-app-intro .services .item .img.secure-signin{background-image:url(' + g + ');background-size:image-width("../../images/default/1x/img_secure_sign_in.png") image-height("../../images/default/1x/img_secure_sign_in.png");outline:1px green dashed}}.syno-promotion-app .syno-promotion-app-intro .services .item .img.active-insight{background-size:220px 90px;background-image:url(' + d + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-promotion-app .syno-promotion-app-intro .services .item .img.active-insight{background-image:url(" + f + ');background-size:image-width("../../images/default/1x/img_active_insight.png") image-height("../../images/default/1x/img_active_insight.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-promotion-app .syno-promotion-app-intro .services .item .img.active-insight{background-image:url(' + f + ');background-size:image-width("../../images/default/1x/img_active_insight.png") image-height("../../images/default/1x/img_active_insight.png");outline:1px green dashed}}.syno-promotion-app .syno-promotion-app-intro .services .item .img.configuration-backup{background-size:220px 90px;background-image:url(' + h + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-promotion-app .syno-promotion-app-intro .services .item .img.configuration-backup{background-image:url(" + b + ');background-size:image-width("../../images/default/1x/img_configuration_backup.png") image-height("../../images/default/1x/img_configuration_backup.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-promotion-app .syno-promotion-app-intro .services .item .img.configuration-backup{background-image:url(' + b + ');background-size:image-width("../../images/default/1x/img_configuration_backup.png") image-height("../../images/default/1x/img_configuration_backup.png");outline:1px green dashed}}.syno-promotion-app .syno-promotion-app-intro .services .item .name{color:#414b55;height:40px;font-size:13px;line-height:20px;display:flex;flex-direction:column;justify-content:center;text-align:center}.syno-promotion-app .syno-promotion-app-intro .services .item .desc{color:#414b55;height:60px;font-size:13px;line-height:20px;text-align:center}.syno-promotion-app .syno-promotion-app-intro .services .service-spacer{width:30px}.syno-promotion-app .syno-promotion-app-config{min-height:100%;box-sizing:border-box;padding:24px 40px;display:flex;flex-direction:column}.syno-promotion-app .syno-promotion-app-config .title{width:100%;font-size:20px;line-height:32px}.syno-promotion-app .syno-promotion-app-config .title.small{font-size:14px;line-height:28px}.syno-promotion-app .syno-promotion-app-config .title.page-title{margin-bottom:8px}.syno-promotion-app .syno-promotion-app-config .subtitle,.syno-promotion-app .syno-promotion-app-config .content{color:#414b55;width:100%;font-size:13px;line-height:20px;margin:4px 0px}.syno-promotion-app .syno-promotion-app-config .subtitle.subtitle,.syno-promotion-app .syno-promotion-app-config .content.subtitle{margin-bottom:12px}.syno-promotion-app .syno-promotion-app-config .subtitle.content.ai-note,.syno-promotion-app .syno-promotion-app-config .content.content.ai-note{margin-top:24px}.syno-promotion-app .syno-promotion-app-config .subtitle.content.privacy-tos,.syno-promotion-app .syno-promotion-app-config .content.content.privacy-tos{line-height:40px}.syno-promotion-app .syno-promotion-app-config .subtitle span.note,.syno-promotion-app .syno-promotion-app-config .content span.note{color:#00A6A6}.syno-promotion-app .syno-promotion-app-config .subtitle a:hover,.syno-promotion-app .syno-promotion-app-config .content a:hover{cursor:pointer}.syno-promotion-app .syno-promotion-app-config .checkbox.v-checkbox-wrapper{padding:4px 0px}.syno-promotion-app .syno-promotion-app-config .checkbox.v-checkbox-wrapper .v-checkbox-icon{top:6px}.syno-promotion-app .syno-promotion-app-config .section-wrapper{display:flex;flex-direction:row}.syno-promotion-app .syno-promotion-app-config .section-wrapper .section-main{flex:1}.syno-promotion-app .syno-promotion-app-config .section-wrapper .section-main .active-insight-enable-wrapper{display:flex;flex-direction:row;align-items:center}.syno-promotion-app .syno-promotion-app-config .section-wrapper .section-icon{width:64px;height:64px;margin:0 20px 0 8px}.syno-promotion-app .syno-promotion-app-config .section-wrapper .section-icon.secure-signin{background-size:64px 64px;background-image:url(' + v + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-promotion-app .syno-promotion-app-config .section-wrapper .section-icon.secure-signin{background-image:url(" + y + ');background-size:image-width("../../images/default/1x/img_secure_sign_in_s.png") image-height("../../images/default/1x/img_secure_sign_in_s.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-promotion-app .syno-promotion-app-config .section-wrapper .section-icon.secure-signin{background-image:url(' + y + ');background-size:image-width("../../images/default/1x/img_secure_sign_in_s.png") image-height("../../images/default/1x/img_secure_sign_in_s.png");outline:1px green dashed}}.syno-promotion-app .syno-promotion-app-config .section-wrapper .section-icon.active-insight{background-size:64px 64px;background-image:url(' + x + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-promotion-app .syno-promotion-app-config .section-wrapper .section-icon.active-insight{background-image:url(" + _ + ');background-size:image-width("../../images/default/1x/img_active_insight_s.png") image-height("../../images/default/1x/img_active_insight_s.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-promotion-app .syno-promotion-app-config .section-wrapper .section-icon.active-insight{background-image:url(' + _ + ');background-size:image-width("../../images/default/1x/img_active_insight_s.png") image-height("../../images/default/1x/img_active_insight_s.png");outline:1px green dashed}}.syno-promotion-app .syno-promotion-app-config .section-wrapper .section-icon.configuration-backup{background-size:64px 64px;background-image:url(' + w + ")}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpack .syno-promotion-app .syno-promotion-app-config .section-wrapper .section-icon.configuration-backup{background-image:url(" + k + ');background-size:image-width("../../images/default/1x/img_configuration_backup_s.png") image-height("../../images/default/1x/img_configuration_backup_s.png")}}@media (-webkit-min-device-pixel-ratio: 1.5), (-o-min-device-pixel-ratio: 3 / 2), (min-resolution: 144dpi){.synohdpackdebug .syno-promotion-app .syno-promotion-app-config .section-wrapper .section-icon.configuration-backup{background-image:url(' + k + ');background-size:image-width("../../images/default/1x/img_configuration_backup_s.png") image-height("../../images/default/1x/img_configuration_backup_s.png");outline:1px green dashed}}.syno-promotion-app .syno-promotion-app-config .divider{width:100%;height:1px;background-color:rgba(198,212,224,0.7);margin:12px 0px}.syno-promotion-app .syno-promotion-app-config .divider.small-top{margin-top:4px}.syno-promotion-app-msg-box.v-window.v-message-box-window br{display:block;content:"";margin-top:6px}.syno-promotion-app-msg-box.v-window.v-message-box-window .message-box .body-wrapper .dialog-title{font-size:18px}\n', ""])
}, function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/3300aa3f688cd958187438b1b88fc323.png"
}, function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/0d84a13df8c72720fc1bca52be4d6b08.png"
}, function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/d2100ec6ed6164a959f4759259598611.png"
}, function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/50eca058ee3a24d240a1f779e5ec65fa.png"
}, function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/c8c9049d8f9da887d6ccadbe3e4a690e.png"
}, function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/952d068c7733729d0679a963edb12b73.png"
}, function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/69a219c8aa0a1e8ad3a64e6dd82a376c.png"
}, function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/5666f077f3ada94ce2e85ce3a4d0e732.png"
}, function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/df98a279543354ac077bf2e25ca147f3.png"
}, function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/ed582157b98841819594af887cc1512f.png"
}, function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/509114d048636ae8628b3368b71686eb.png"
}, function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/ea93ee3d01b9b706aae9f7da6600fb3d.png"
}, function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/364208e2b9f17dcdef0ee5a4ad2cffbf.png"
}, function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/989594c6bd9ccb593266550ed6b67c3d.png"
}, function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/b4f5752e82a3950fbf092766cc4f14de.png"
}, function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/b68a6a4a42bbdf38030a123e4d72db9d.png"
}, function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/045d038a12e3c76aab47e95965fb95d7.png"
}, function(e, i) {
    e.exports = "webman/modules/WelcomeApp/images/assets/49ef9576c771c77f87e766a22ca3d527.png"
}, , function(e, i, o) {
    "use strict";
    o.r(i);
    var t = function() {
        var e = this,
            i = e.$createElement,
            o = e._self._c || i;
        return o("v-app-instance", {
            attrs: {
                "syno-id": "promotion-app-instance",
                "class-name": "SYNO.SDS.App.PromotionApp.Instance",
                "can-open": e.shouldLaunch
            }
        }, [o("div", {
            ref: "appRoot",
            staticClass: "syno-promotion-app-mask"
        }, [o("v-app-window", {
            ref: "appWindow",
            staticClass: "syno-promotion-app",
            attrs: {
                "syno-id": "promotion-app-window",
                "always-on-top": !0,
                "default-maximized": !1,
                "toggle-minimizable": !1,
                height: e.height,
                width: 800,
                "before-close": e.beforeAppWindowClose
            },
            on: {
                "zindex-changed": e.onAppWindowZindexChanged
            }
        }, [o("transition", {
            attrs: {
                name: "content-fade",
                mode: "out-in"
            }
        }, ["welcome" === e.step ? o("welcome-page", {
            key: "welcome",
            staticClass: "syno-promotion-app-welcome",
            attrs: {
                aria: e.aria,
                "is-admin": e.isAdmin
            },
            on: {
                start: e.goToPromotionInfoStep
            }
        }) : e._e(), e._v(" "), "intro" === e.step ? o("intro-page", {
            key: "intro",
            staticClass: "syno-promotion-app-intro",
            attrs: {
                aria: e.aria,
                "is-logged-in": e.isLoggedIn,
                "support-mib": e.supportMib
            },
            on: {
                signin: e.signin,
                "create-account": e.createAccount,
                "go-next-step": e.goToPromotionConfigStep,
                skip: e.skip
            }
        }) : e._e(), e._v(" "), "config" === e.step ? o("v-perfect-scrollbar", {
            key: "config"
        }, [o("config-page", {
            staticClass: "syno-promotion-app-config",
            attrs: {
                aria: e.aria,
                "support-mib": e.supportMib,
                "is-ntp-enabled": e.isNtpEnabled,
                "enable-active-insight": e.enableActiveInsight,
                "enable-configuration-backup": e.enableConfigurationBackup
            },
            on: {
                "update:enableActiveInsight": function(i) {
                    e.enableActiveInsight = i
                },
                "update:enable-active-insight": function(i) {
                    e.enableActiveInsight = i
                },
                "update:enableConfigurationBackup": function(i) {
                    e.enableConfigurationBackup = i
                },
                "update:enable-configuration-backup": function(i) {
                    e.enableConfigurationBackup = i
                },
                submit: e.submit,
                skip: e.skip
            }
        })], 1) : e._e()], 1)], 1)], 1)])
    };
    t._withStripped = !0;
    var n = function() {
        var e = this,
            i = e.$createElement,
            o = e._self._c || i;
        return o("div", [o("div", {
            staticClass: "main"
        }, [e.isAdmin ? o("div", {
            staticClass: "admin-user"
        }, [o("div", {
            staticClass: "title",
            attrs: {
                tabindex: "0",
                "aria-label": e.aria.welcome.titleAdmin
            }
        }, [e._v(e._s(e.aria.welcome.titleAdmin))]), e._v(" "), o("div", {
            staticClass: "subtitle",
            attrs: {
                "aria-label": e.aria.welcome.subtitleAdmin
            },
            domProps: {
                innerHTML: e._s(e.aria.welcome.subtitleAdmin)
            }
        }), e._v(" "), o("div", {
            staticClass: "features"
        }, [o("div", {
            staticClass: "feature"
        }, [o("div", {
            staticClass: "img left",
            attrs: {
                tabindex: "0",
                "aria-label": e.aria.welcome.feature1
            }
        }), e._v(" "), o("div", {
            staticClass: "text"
        }, [e._v(e._s(e.aria.welcome.feature1))])]), e._v(" "), o("div", {
            staticClass: "feature"
        }, [o("div", {
            staticClass: "img center",
            attrs: {
                tabindex: "0",
                "aria-label": e.aria.welcome.feature2
            }
        }), e._v(" "), o("div", {
            staticClass: "text"
        }, [e._v(e._s(e.aria.welcome.feature2))])]), e._v(" "), o("div", {
            staticClass: "feature"
        }, [o("div", {
            staticClass: "img right",
            attrs: {
                tabindex: "0",
                "aria-label": e.aria.welcome.feature3
            }
        }), e._v(" "), o("div", {
            staticClass: "text"
        }, [e._v(e._s(e.aria.welcome.feature3))])])])]) : o("div", {
            staticClass: "normal-user"
        }, [o("div", {
            staticClass: "title",
            attrs: {
                tabindex: "0",
                "aria-label": e.aria.welcome.titleNormal
            }
        }, [e._v(e._s(e.aria.welcome.titleNormal))]), e._v(" "), o("div", {
            staticClass: "subtitle",
            attrs: {
                tabindex: "0",
                "aria-label": e.aria.welcome.subtitleNormal
            }
        }, [e._v(e._s(e.aria.welcome.subtitleNormal))])])]), e._v(" "), o("div", {
            staticClass: "footer"
        }, [o("v-button", {
            staticClass: "btn",
            attrs: {
                "syno-id": "syno-promition-app-welcome-start",
                type: "footbar",
                suffix: "main",
                tabindex: "0"
            },
            on: {
                click: function(i) {
                    return e.$emit("start")
                }
            }
        }, [e._v("\n            " + e._s(e.T("common", "start")) + "\n        ")]), e._v(" "), o("div", {
            staticClass: "syno-logo"
        })], 1)])
    };
    n._withStripped = !0;
    var a = o(1),
        s = {
            mixins: [a.a],
            props: {
                aria: {
                    type: Object,
                    required: !0
                },
                isAdmin: {
                    type: Boolean,
                    required: !0
                }
            }
        },
        r = o(0),
        p = Object(r.a)(s, n, [], !1, null, null, null);
    p.options.__file = "src/promotion-app/welcome.vue";
    var c = p.exports,
        m = function() {
            var e = this,
                i = e.$createElement,
                o = e._self._c || i;
            return o("div", [o("div", {
                staticClass: "title",
                attrs: {
                    tabindex: "0",
                    "aria-label": e.aria.title,
                    "aria-labelledby": e.aria.subtitleId
                }
            }, [e._v(e._s(e.aria.title))]), e._v(" "), o("div", {
                staticClass: "subtitle",
                attrs: {
                    id: e.aria.subtitleId,
                    "aria-label": e.aria.subtitle
                }
            }, [e._v(e._s(e.aria.subtitle))]), e._v(" "), o("div", {
                staticClass: "services"
            }, [o("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: e.supportMib,
                    expression: "supportMib"
                }],
                staticClass: "item"
            }, [o("div", {
                staticClass: "img active-insight"
            }), e._v(" "), o("div", {
                staticClass: "name",
                attrs: {
                    tabindex: "0",
                    "aria-label": e.aria.activeInsight.title,
                    "aria-labelledby": e.aria.activeInsight.subtitleId
                }
            }, [e._v("\n                " + e._s(e.aria.activeInsight.title) + "\n            ")]), e._v(" "), o("div", {
                staticClass: "desc",
                attrs: {
                    id: e.aria.activeInsight.subtitleId,
                    "aria-label": e.aria.activeInsight.subtitle
                }
            }, [e._v("\n                " + e._s(e.aria.activeInsight.subtitle) + "\n            ")])]), e._v(" "), o("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: e.supportMib,
                    expression: "supportMib"
                }],
                staticClass: "service-spacer"
            }), e._v(" "), o("div", {
                staticClass: "item"
            }, [o("div", {
                staticClass: "img configuration-backup"
            }), e._v(" "), o("div", {
                staticClass: "name",
                attrs: {
                    tabindex: "0",
                    "aria-label": e.aria.configurationBackup.title,
                    "aria-labelledby": e.aria.configurationBackup.subtitleId
                }
            }, [e._v("\n                " + e._s(e.aria.configurationBackup.title) + "\n            ")]), e._v(" "), o("div", {
                staticClass: "desc",
                attrs: {
                    id: e.aria.configurationBackup.subtitleId,
                    "aria-label": e.aria.configurationBackup.subtitle
                }
            }, [e._v("\n                " + e._s(e.aria.configurationBackup.subtitle) + "\n            ")])]), e._v(" "), o("div", {
                staticClass: "service-spacer"
            }), e._v(" "), o("div", {
                staticClass: "item"
            }, [o("div", {
                staticClass: "img secure-signin"
            }), e._v(" "), o("div", {
                staticClass: "name",
                attrs: {
                    tabindex: "0",
                    "aria-label": e.aria.secureSignin.title,
                    "aria-labelledby": e.aria.secureSignin.subtitleId
                }
            }, [e._v("\n                " + e._s(e.aria.secureSignin.title) + "\n            ")]), e._v(" "), o("div", {
                staticClass: "desc",
                attrs: {
                    id: e.aria.secureSignin.subtitleId,
                    "aria-label": e.aria.secureSignin.subtitle
                }
            }, [e._v("\n                " + e._s(e.aria.secureSignin.subtitle) + "\n            ")])])]), e._v(" "), o("div", {
                staticClass: "btn-group"
            }, [o("v-button", {
                staticClass: "btn-continue",
                attrs: {
                    "syno-id": "syno-promition-app-intro-continue",
                    type: "footbar",
                    suffix: "main"
                },
                on: {
                    click: function(i) {
                        return e.$emit(e.isLoggedIn ? "go-next-step" : "signin")
                    }
                }
            }, [e._v("\n            " + e._s(e.isLoggedIn ? e.T("common", "next") : e.T("common", "login")) + "\n        ")]), e._v(" "), e.isLoggedIn ? e._e() : o("div", {
                staticClass: "btn-create",
                attrs: {
                    tabindex: "0",
                    "aria-label": e.aria.createBtn
                },
                on: {
                    click: function(i) {
                        return e.$emit("create-account")
                    }
                }
            }, [e._v("\n            " + e._s(e.aria.createBtn) + "\n        ")]), e._v(" "), e.isLoggedIn ? e._e() : o("div", {
                staticClass: "btn-skip",
                attrs: {
                    tabindex: "0",
                    "aria-label": e.aria.skipBtn
                },
                on: {
                    click: function(i) {
                        return e.$emit("skip")
                    }
                }
            }, [e._v(e._s(e.aria.skipBtn))])], 1)])
        };
    m._withStripped = !0;
    var l = {
            name: "intro",
            mixins: [a.a],
            props: {
                aria: {
                    type: Object,
                    required: !0
                },
                isLoggedIn: {
                    type: Boolean,
                    required: !0
                },
                supportMib: {
                    type: Boolean,
                    required: !0
                }
            }
        },
        u = Object(r.a)(l, m, [], !1, null, null, null);
    u.options.__file = "src/promotion-app/intro.vue";
    var g = u.exports,
        d = function() {
            var e = this,
                i = e.$createElement,
                o = e._self._c || i;
            return o("div", [o("div", {
                staticClass: "title page-title",
                attrs: {
                    tabindex: "0",
                    "aria-label": e.aria.configTitle,
                    "aria-labelledby": e.aria.configSubtitleId
                }
            }, [e._v("\n        " + e._s(e.aria.configTitle) + "\n    ")]), e._v(" "), o("div", {
                staticClass: "divider"
            }), e._v(" "), e.supportMib ? o("div", {
                staticClass: "section-wrapper"
            }, [o("div", {
                staticClass: "section-icon active-insight"
            }), e._v(" "), o("div", {
                staticClass: "section-main"
            }, [o("div", {
                staticClass: "title small",
                attrs: {
                    tabindex: "0",
                    "aria-label": e.aria.activeInsight.configTitle,
                    "aria-labelledby": e.aria.activeInsight.configDescId + " " + e.aria.activeInsight.configNoteId
                }
            }, [e._v("\n                " + e._s(e.aria.activeInsight.configTitle) + "\n            ")]), e._v(" "), o("div", {
                staticClass: "content",
                attrs: {
                    id: e.aria.activeInsight.configDescId,
                    "aria-label": e.aria.activeInsight.configDesc
                },
                domProps: {
                    innerHTML: e._s(e.aria.activeInsight.configDesc)
                }
            }), e._v(" "), o("div", {
                staticClass: "active-insight-enable-wrapper"
            }, [o("v-checkbox", {
                staticClass: "checkbox",
                attrs: {
                    "syno-id": "syno-promition-app-config-insight-enable",
                    value: e.enableActiveInsight
                },
                on: {
                    input: e.onActiveInsightChange
                }
            }, [e._v("\n                    " + e._s(e.T("welcome", "promotion_active_insight_enable")) + "\n                ")]), e._v(" "), o("v-whitetip", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: !e.isNtpEnabled,
                    expression: "!isNtpEnabled"
                }],
                attrs: {
                    "force-simple": "",
                    content: e.aria.activeInsight.configNote
                }
            })], 1)])]) : e._e(), e._v(" "), e.supportMib ? o("div", {
                staticClass: "divider"
            }) : e._e(), e._v(" "), o("div", {
                staticClass: "section-wrapper"
            }, [o("div", {
                staticClass: "section-icon configuration-backup"
            }), e._v(" "), o("div", {
                staticClass: "section-main"
            }, [o("div", {
                staticClass: "title small",
                attrs: {
                    tabindex: "0",
                    "aria-label": e.aria.configurationBackup.configTitle,
                    "aria-labelledby": e.aria.configurationBackup.configDescId
                }
            }, [e._v("\n                " + e._s(e.aria.configurationBackup.configTitle) + "\n            ")]), e._v(" "), o("div", {
                staticClass: "content",
                attrs: {
                    id: e.aria.configurationBackup.configDescId,
                    "aria-label": e.aria.configurationBackup.configDesc
                },
                domProps: {
                    innerHTML: e._s(e.aria.configurationBackup.configDesc)
                }
            }), e._v(" "), o("v-checkbox", {
                staticClass: "checkbox",
                attrs: {
                    "syno-id": "syno-promition-app-config-backup-enable",
                    value: e.enableConfigurationBackup
                },
                on: {
                    input: e.onConfigurationBackupChange
                }
            }, [e._v("\n                " + e._s(e.T("welcome", "promotion_conf_backup_enable")) + "\n            ")])], 1)]), e._v(" "), o("div", {
                staticClass: "divider"
            }), e._v(" "), o("div", {
                staticClass: "section-wrapper"
            }, [o("div", {
                staticClass: "section-icon secure-signin"
            }), e._v(" "), o("div", {
                staticClass: "section-main"
            }, [o("div", {
                staticClass: "title small",
                attrs: {
                    tabindex: "0",
                    "aria-label": e.aria.secureSignin.configTitle,
                    "aria-labelledby": e.aria.secureSignin.configDescId
                }
            }, [e._v("\n                " + e._s(e.aria.secureSignin.configTitle) + "\n            ")]), e._v(" "), o("div", {
                staticClass: "content",
                attrs: {
                    id: e.aria.secureSignin.configDescId,
                    "aria-label": e.aria.secureSignin.configDesc
                }
            }, [e._v("\n                " + e._s(e.aria.secureSignin.configDesc) + "\n            ")])])]), e._v(" "), o("div", {
                staticClass: "divider"
            }), e._v(" "), o("div", {
                staticClass: "content privacy-tos",
                domProps: {
                    innerHTML: e._s(e.privacyTosText)
                }
            }), e._v(" "), o("div", {
                staticClass: "btn-group"
            }, [o("v-button", {
                staticClass: "btn-continue apply",
                attrs: {
                    "syno-id": "syno-promition-app-config-continue",
                    type: "footbar",
                    suffix: "main"
                },
                on: {
                    click: function(i) {
                        return e.$emit("submit")
                    }
                }
            }, [e._v("\n            " + e._s(e.T("common", "commit")) + "\n        ")]), e._v(" "), o("div", {
                staticClass: "btn-skip",
                attrs: {
                    tabindex: "0",
                    "aria-label": e.aria.skipBtn
                },
                on: {
                    click: function(i) {
                        return e.$emit("skip", {
                            shouldSkipUDC: !0
                        })
                    }
                }
            }, [e._v(e._s(e.aria.skipBtn))])], 1)])
        };
    d._withStripped = !0;
    var f = o(2),
        h = {
            name: "config",
            mixins: [a.a, f.a],
            props: {
                aria: {
                    type: Object,
                    required: !0
                },
                supportMib: {
                    type: Boolean,
                    required: !0
                },
                isNtpEnabled: {
                    type: Boolean,
                    required: !0
                },
                enableActiveInsight: {
                    type: Boolean,
                    required: !0
                },
                enableConfigurationBackup: {
                    type: Boolean,
                    required: !0
                }
            },
            data: function() {
                return {
                    privacyTosText: this.formatUrl(this.T("welcome", "useful_terms_privacy"), "https://www.synology.com/company/legal", "https://www.synology.com/company/legal/privacy")
                }
            },
            methods: {
                onActiveInsightChange: function(e) {
                    this.$emit("update:enableActiveInsight", e)
                },
                onConfigurationBackupChange: function(e) {
                    this.$emit("update:enableConfigurationBackup", e)
                }
            }
        },
        b = Object(r.a)(h, d, [], !1, null, null, null);
    b.options.__file = "src/promotion-app/config.vue";
    var v = b.exports;
    o(53);

    function y(e, i, o, t, n, a, s) {
        try {
            var r = e[a](s),
                p = r.value
        } catch (e) {
            return void o(e)
        }
        r.done ? i(p) : Promise.resolve(p).then(t, n)
    }

    function x(e) {
        return function() {
            var i = this,
                o = arguments;
            return new Promise((function(t, n) {
                var a = e.apply(i, o);

                function s(e) {
                    y(a, t, n, s, r, "next", e)
                }

                function r(e) {
                    y(a, t, n, s, r, "throw", e)
                }
                s(void 0)
            }))
        }
    }

    function _(e) {
        return function(e) {
            if (Array.isArray(e)) {
                for (var i = 0, o = new Array(e.length); i < e.length; i++) o[i] = e[i];
                return o
            }
        }(e) || function(e) {
            if (Symbol.iterator in Object(e) || "[object Arguments]" === Object.prototype.toString.call(e)) return Array.from(e)
        }(e) || function() {
            throw new TypeError("Invalid attempt to spread non-iterable instance")
        }()
    }
    var w, k, S, C, T, A = {
            mixins: [a.a, f.a],
            components: {
                WelcomePage: c,
                IntroPage: g,
                ConfigPage: v
            },
            data: function() {
                var e = _S("is_admin");
                return {
                    windowHeight: window.innerHeight,
                    supportMib: "no" !== _D("support_mib"),
                    isAdmin: e,
                    isLoggedIn: void 0,
                    showPromotion: e && !_S("promotion_hide"),
                    step: "welcome",
                    isNtpEnabled: !1,
                    isLoading: !1,
                    shouldSkipUDC: !1,
                    enableActiveInsight: !1,
                    enableConfigurationBackup: !1
                }
            },
            computed: {
                height: function() {
                    return "config" !== this.step || !this.supportMib || this.windowHeight < 900 ? 520 : 632
                },
                aria: function() {
                    var e = this.uuid();
                    return {
                        title: this.T("welcome", "promotion_title"),
                        subtitle: "".concat(this.T("welcome", "promotion_subtitle"), " ").concat(this.T("welcome", this.isLoggedIn ? "promotion_subtitle_next" : "promotion_subtitle_signin")),
                        subtitleId: "".concat(e, "-subtitle-aria"),
                        configTitle: this.T("welcome", "promotion_useful_tools_title"),
                        configSubtitle: this.T("welcome", "useful_tools_subtitle"),
                        configSubtitleId: "".concat(e, "-config-subtitle-aria"),
                        createBtn: this.T("welcome", "promotion_create_syno_account"),
                        skipBtn: this.T("welcome", "promotion_skip"),
                        secureSignin: {
                            title: this.T("welcome", "promotion_secure_signin_title"),
                            subtitle: this.T("welcome", "promotion_secure_signin_desc"),
                            subtitleId: "".concat(e, "-ss-subtitle-aria"),
                            configTitle: this.T("welcome", "promotion_secure_signin_title"),
                            configDesc: "".concat(String.format(this.T("welcome", "promotion_secure_signin_config_desc"), "", "")),
                            configDescId: "".concat(e, "-ss-config-desc-aria")
                        },
                        activeInsight: {
                            title: this.T("welcome", "promotion_active_insight_title"),
                            subtitle: this.T("welcome", "promotion_active_insight_desc"),
                            subtitleId: "".concat(e, "-ai-subtitle-aria"),
                            configTitle: this.T("welcome", "promotion_active_insight_title"),
                            configDesc: "".concat(String.format(this.T("welcome", "promotion_active_insight_config_desc"), "<a href='https://insight.synology.com' target='_blank'>", "</a>")),
                            configDescId: "".concat(e, "-ai-config-desc-aria"),
                            configNote: "".concat(String.format.apply(String, [this.T("welcome", "promotion_active_insight_note")].concat(_(Array(6).fill(""))))),
                            configNoteId: "".concat(e, "-ai-config-note-aria")
                        },
                        configurationBackup: {
                            title: this.T("welcome", "promotion_conf_backup_title"),
                            subtitle: this.T("welcome", "promotion_conf_backup_desc"),
                            subtitleId: "".concat(e, "-cb-subtitle-aria"),
                            configTitle: this.T("welcome", "promotion_conf_backup_title"),
                            configDesc: this.T("welcome", "promotion_conf_backup_config_desc"),
                            configDescId: "".concat(e, "-cb-config-desc-aria")
                        },
                        welcome: {
                            titleAdmin: this.T("welcome", "promotion_welcome_title_admin"),
                            titleNormal: this.T("welcome", "promotion_welcome_title_normal"),
                            subtitleAdmin: "".concat(String.format(this.T("welcome", "promotion_welcome_subtitle_admin"), "<a href='https://sy.to/dsm7new' target='_blank'>", "</a>")),
                            subtitleNormal: this.T("welcome", "promotion_welcome_subtitle_normal"),
                            feature1: this.T("welcome", "promotion_welcome_feature1"),
                            feature2: this.T("welcome", "promotion_welcome_feature2"),
                            feature3: this.T("welcome", "promotion_welcome_feature3")
                        }
                    }
                }
            },
            mounted: function() {
                var e = this;
                this.isAdmin && (SYNO.SDS.SynologyAccount.WebLogin.create().then((function(i) {
                    return e.webLogin = i
                })), this.MyDSCenterPromise = synowebapi.promises.request({
                    api: "SYNO.Core.MyDSCenter",
                    version: 2,
                    method: "query"
                }).then((function(i) {
                    var o = i.is_logged_in;
                    return e.isLoggedIn = o
                })).catch((function(i) {
                    i && 3002 === i.code ? e.isLoggedIn = !0 : e.isLoggedIn = !1
                })), synowebapi.promises.request({
                    api: "SYNO.Core.Region.NTP",
                    version: 2,
                    method: "get"
                }).then((function(i) {
                    var o = i.enable_ntp;
                    return e.isNtpEnabled = "ntp" === o
                })))
            },
            methods: {
                shouldLaunch: function() {
                    return !!(!1 !== SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PromotionApp", "show_upgrade_welcome")) || (this.$refs.appRoot.parentElement.removeChild(this.$refs.appRoot), SYNO.SDS.AppLaunch("SYNO.SDS.UDC.Instance", {
                        skip: !this.isAdmin
                    }), !1)
                },
                onAppWindowZindexChanged: function(e) {
                    this.$refs.appRoot.style.zIndex = e
                },
                beforeAppWindowClose: function() {
                    return this.$refs.appRoot.parentElement.removeChild(this.$refs.appRoot), this.isAdmin ? (synowebapi.promises.request({
                        api: "SYNO.Core.Promotion.Info",
                        version: 1,
                        method: "hide_promotion"
                    }), SYNO.SDS.AppLaunch("SYNO.SDS.UDC.Instance")) : SYNO.SDS.App.PromotionApp.QuickTourTrayLauncher(), !0
                },
                signin: function() {
                    var e = this.webLogin;
                    e && e.loginUrl && (this.showLoader(!0), e.popLoginWeb(this.onWebLoginResolved, this.onWebLoginRejected, this.onWebLoginCanceled))
                },
                createAccount: function() {
                    var e = this.webLogin;
                    e && e.registerUrl && (this.showLoader(!0), e.popCreateWeb(this.onWebLoginResolved, this.onWebLoginRejected, this.onWebLoginCanceled))
                },
                onWebLoginResolved: function() {
                    this.isLoggedIn = !0, this.showLoader(!1), this.goToPromotionConfigStep()
                },
                onWebLoginRejected: function() {
                    this.showLoader(!1)
                },
                onWebLoginCanceled: function() {
                    this.showLoader(!1)
                },
                skip: (T = x(regeneratorRuntime.mark((function e() {
                    var i, o, t, n;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return i = this.T("welcome", this.isLoggedIn ? "promotion_dialog_reconsider_content_main_2" : "promotion_dialog_reconsider_content_main_1"), o = String.format(this.T("welcome", "promotion_dialog_reconsider_content_note"), "<span class='syno-ux-note'>", "</span>"), t = i + "<br/>" + o, e.next = 5, this.$refs.appWindow.getMsgBox({
                                    customCls: "syno-promotion-app-msg-box"
                                }).confirm(this.T("welcome", "want_change_mind"), t, {
                                    confirm: {
                                        text: this.T("common", "yes")
                                    },
                                    cancel: {
                                        text: this.T("common", "no_thanks")
                                    }
                                }, {
                                    useHtml: !0
                                });
                            case 5:
                                if ("confirm" !== (n = e.sent) || this.isLoggedIn) {
                                    e.next = 10;
                                    break
                                }
                                return e.next = 9, this.$nextTick();
                            case 9:
                                this.signin();
                            case 10:
                                "cancel" === n && this.$refs.appWindow.close();
                            case 11:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return T.apply(this, arguments)
                }),
                submit: (C = x(regeneratorRuntime.mark((function e() {
                    var i, o, t, n, a, s, r;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return this.$refs.appWindow.close(), i = [{
                                    api: "SYNO.Backup.Config.AutoBackup",
                                    method: "set",
                                    version: 1,
                                    encryption: ["pwd"],
                                    params: {
                                        enable: this.enableConfigurationBackup,
                                        enc_method: "auto",
                                        overwrite: !0
                                    }
                                }, {
                                    api: "SYNO.SecureSignIn.Package",
                                    method: "set",
                                    version: 1,
                                    params: {
                                        enabled: !0
                                    }
                                }], this.supportMib && this.enableActiveInsight && i.push({
                                    api: "SYNO.ActiveInsight.Package",
                                    version: 1,
                                    method: "start_mib"
                                }), e.next = 5, synowebapi.promises.request({
                                    api: "SYNO.Entry.Request",
                                    method: "request",
                                    version: 1,
                                    compound: {
                                        mode: "parallel",
                                        stopwhenerror: !1,
                                        params: i
                                    }
                                });
                            case 5:
                                o = e.sent, t = o.has_fail, n = o.result, t && (a = {
                                    "SYNO.ActiveInsight.Package": this.T("welcome", "promotion_active_insight_title"),
                                    "SYNO.Backup.Config.AutoBackup": this.T("welcome", "promotion_conf_backup_title")
                                }, s = n.reduce((function(e, i) {
                                    return i.success || e.push(a[i.api]), e
                                }), []), r = String.format(this.T("welcome", "promotion_notification_setting_failed"), s.join(", "), "<a data-syno-app='SYNO.SDS.AdminCenter.Application'>", "</a>"), SYNO.SDS.SystemTray.notifyVueMsg(null, this.T("myds", "myds_service"), r, 0, !1));
                            case 9:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return C.apply(this, arguments)
                }),
                waitForLoginStatusReady: (S = x(regeneratorRuntime.mark((function e(i) {
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, Promise.race([this.MyDSCenterPromise, new Promise((function(e) {
                                    return setTimeout(e, 1e3 * i)
                                }))]);
                            case 2:
                                void 0 === this.isLoggedIn && (this.isLoggedIn = !0);
                            case 3:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function(e) {
                    return S.apply(this, arguments)
                }),
                goToPromotionInfoStep: (k = x(regeneratorRuntime.mark((function e() {
                    var i, o, t;
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PromotionApp", "show_upgrade_welcome", !1), !this.showPromotion) {
                                    e.next = 17;
                                    break
                                }
                                return i = _D("unique"), o = i.split("_").pop(), t = o.includes("j") || o.includes("slim") || o.includes("se"), this.showLoader(!0), e.next = 10, this.waitForLoginStatusReady(t ? 8 : 2);
                            case 10:
                                return this.showLoader(!1), this.step = "intro", e.next = 14, this.$nextTick();
                            case 14:
                                this.$refs.appWindow.$options.manager.centerWindow(this.$refs.appWindow), e.next = 18;
                                break;
                            case 17:
                                this.$refs.appWindow.close();
                            case 18:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return k.apply(this, arguments)
                }),
                goToPromotionConfigStep: (w = x(regeneratorRuntime.mark((function e() {
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return this.step = "config", e.next = 3, this.$nextTick();
                            case 3:
                                this.$refs.appWindow.$options.manager.centerWindow(this.$refs.appWindow);
                            case 4:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                }))), function() {
                    return w.apply(this, arguments)
                }),
                showLoader: function(e) {
                    e ? this.$refs.appWindow.setStatus(.5, _T("common", "msg_waiting")) : this.$refs.appWindow.clearStatus()
                }
            }
        },
        I = Object(r.a)(A, t, [], !1, null, null, null);
    I.options.__file = "src/promotion-app/promotion-app.vue";
    var N = I.exports;
    Ext.namespace("SYNO.SDS.App.PromotionApp"), 
 /**
 * @class SYNO.SDS.App.PromotionApp.QuickTourTrayLauncher
 * PromotionApp quick tour tray launcher
 *
 */       
    SYNO.SDS.App.PromotionApp.QuickTourTrayLauncher = function() {
        !1 !== SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PromotionApp", "show_quick_tour_tray") && (SYNO.SDS.JSLoad("SYNO.SDS.HelpBrowser.QuickTourTray", (function() {
            SYNO.SDS.SystemTray.notifyVueCustomizeMsg("", new SYNO.SDS.HelpBrowser.QuickTourTray)
        })), SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PromotionApp", "show_quick_tour_tray", !1))
    }, SYNO.SDS.App.PromotionApp.Instance = Vue.extend({
        components: {
            Promotion: N
        },
        template: "<Promotion/>"
    })
}]);
