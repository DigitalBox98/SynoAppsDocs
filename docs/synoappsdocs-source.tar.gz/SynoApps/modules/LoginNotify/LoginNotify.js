/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.LoginNotifyChecker
 * @extends SYNO.SDS.AppInstance
 * LoginNotify application instance class
 *
 */
Ext.define("SYNO.SDS.LoginNotifyChecker", {
    extend: "SYNO.SDS.AppInstance",
    initInstance: function(a) {
        if (!this.win) {
            this.win = new SYNO.SDS.Window({
                appInstance: this
            });
            this.addInstance(this.win);
            this.queryIsNeedNotify()
        }
    },
    queryIsNeedNotify: function() {
        var a = null;
        var b = Ext.emptyFn;
        if (_S("authType") === "local") {
            a = {
                api: "SYNO.Core.NormalUser.LoginNotify",
                method: "check",
                version: 1
            };
            b = this.localLoginNotifyHandler
        } else {
            if (_S("authType") === "ldap") {
                a = {
                    api: "SYNO.Core.Directory.LDAP.Login.Notify",
                    method: "check",
                    version: 1,
                    params: {
                        username: _S("user")
                    }
                };
                b = this.ldapLoginNotifyHandler
            }
        }
        if (a !== null) {
            this.sendWebAPI(Ext.apply({
                scope: this,
                callback: function(d, c) {
                    if (d) {
                        Ext.createDelegate(b, this)(c)
                    } else {
                        SYNO.Debug.error("[Error]: ", c)
                    }
                }
            }, a))
        }
    },
    promptNotification: function(b, a) {
        SYNO.SDS.SystemTray.notifyMsg("", b, a, 10000, false)
    },
    localLoginNotifyHandler: function(a) {
        if (a.need_notify) {
            this.promptNotification("DSM", String.format(_T("ldap", "login_check_password_desc"), a.valid_days))
        }
    },
    ldapLoginNotifyHandler: function(a) {
        if (a.isNeed) {
            var d = String.format(_T("ldap", "login_check_password_desc"), a.day);
            var b = Ext.urlAppend(a.url, Ext.urlEncode({
                action: "chpass",
                uid: _S("user")
            }));
            var c = String.format("<a href='{0}' target='blank' tabIndex='-1'>{1}</a>", b, d);
            this.promptNotification("Directory Server", c)
        }
    }
});
