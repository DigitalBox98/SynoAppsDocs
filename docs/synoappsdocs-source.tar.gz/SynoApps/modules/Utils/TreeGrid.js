/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/*
 * Ext JS Library 3.2.1
 * Copyright(c) 2006-2010 Ext JS, Inc.
 * licensing@extjs.com
 * http://www.extjs.com/license
 */
Ext.ns("Ext.ux.tree");
Ext.ux.tree.TreeGridNodeUI = Ext.extend(Ext.tree.TreeNodeUI, {
    isTreeGridNodeUI: true,
    renderElements: function(d, l, h, o) {
        var m;
        var q = d.getOwnerTree(),
            k = q.columns,
            j = k[0],
            e, b, g;
        this.indentMarkup = d.parentNode ? d.parentNode.ui.getChildIndent() : "";
        if (j.tpl) {
            m = j.tpl.apply(l)
        } else {
            m = l[j.dataIndex] || j.text
        }
        if (j.renderer) {
            if (j.scope) {
                m = j.renderer(m, j.scope)
            } else {
                m = j.renderer(m)
            }
        }
        b = ['<tbody class="x-tree-node">', '<tr ext:tree-node-id="', d.id, '" class="x-tree-node-el x-tree-node-leaf ', l.cls, '">', '<td class="x-treegrid-col">', '<span class="x-tree-node-indent">', this.indentMarkup, "</span>", '<img src="', this.emptyIcon, '" class="x-tree-ec-icon x-tree-elbow">', '<img src="', l.icon || this.emptyIcon, '" class="x-tree-node-icon', (l.icon ? " x-tree-node-inline-icon" : ""), (l.iconCls ? " " + l.iconCls : ""), '" unselectable="on">', '<a hidefocus="on" class="x-tree-node-anchor" href="', l.href ? l.href : "#", '" tabIndex="1" ', l.hrefTarget ? ' target="' + l.hrefTarget + '"' : "", ">", '<span unselectable="on"' + (l.cls ? " class=" + l.cls : "") + ">", m, "</span></a>", "</td>"];
        for (e = 1, g = k.length; e < g; e++) {
            var p;
            j = k[e];
            if (j.tpl) {
                p = j.tpl.apply(l)
            } else {
                p = l[j.dataIndex]
            }
            if (j.renderer) {
                if (j.scope) {
                    p = j.renderer(p, j.scope)
                } else {
                    p = j.renderer(p)
                }
            }
            b.push('<td class="x-treegrid-col ', (j.cls ? j.cls : ""), '">', '<div unselectable="on" class="x-treegrid-text"', (j.align ? ' style="text-align: ' + j.align + ';"' : ""), ">", (p), "</div>", "</td>")
        }
        b.push('</tr><tr class="x-tree-node-ct"><td colspan="', k.length, '">', '<table class="x-treegrid-node-ct-table" cellpadding="0" cellspacing="0" style="table-layout: fixed; display: none; width: ', q.innerCt.getWidth(), 'px;"><colgroup>');
        for (e = 0, g = k.length; e < g; e++) {
            if (typeof(k[e].minWidth) != "undefined") {
                b.push('<col style="width: ', (k[e].hidden ? 0 : k[e].width), "px; minWidth: ", k[e].minWidth, 'px;" />')
            } else {
                b.push('<col style="width: ', (k[e].hidden ? 0 : k[e].width), 'px;" />')
            }
        }
        b.push("</colgroup></table></td></tr></tbody>");
        if (o !== true && d.nextSibling && d.nextSibling.ui.getEl()) {
            this.wrap = Ext.DomHelper.insertHtml("beforeBegin", d.nextSibling.ui.getEl(), b.join(""))
        } else {
            this.wrap = Ext.DomHelper.insertHtml("beforeEnd", h, b.join(""))
        }
        this.elNode = this.wrap.childNodes[0];
        this.ctNode = this.wrap.childNodes[1].firstChild.firstChild;
        var f = this.elNode.firstChild.childNodes;
        this.indentNode = f[0];
        this.ecNode = f[1];
        this.iconNode = f[2];
        this.anchor = f[3];
        this.textNode = f[3].firstChild
    },
    animExpand: function(a) {
        this.ctNode.style.display = "";
        Ext.ux.tree.TreeGridNodeUI.superclass.animExpand.call(this, a)
    },
    appendDDGhost: function(c) {
        var b = this.elNode.cloneNode(true);
        c.appendChild(b.firstChild)
    }
});
Ext.ux.tree.TreeGridRootNodeUI = Ext.extend(Ext.tree.TreeNodeUI, {
    isTreeGridNodeUI: true,
    render: function() {
        if (!this.rendered) {
            this.wrap = this.ctNode = this.node.ownerTree.innerCt.dom;
            this.node.expanded = true
        }
        if (Ext.isWebKit) {
            var a = this.ctNode;
            a.style.tableLayout = null;
            (function() {
                a.style.tableLayout = "fixed"
            }).defer(1)
        }
    },
    destroy: function() {
        if (this.elNode) {
            Ext.dd.Registry.unregister(this.elNode.id)
        }
        delete this.node
    },
    collapse: Ext.emptyFn,
    expand: Ext.emptyFn
});
/*
 * Ext JS Library 3.2.1
 * Copyright(c) 2006-2010 Ext JS, Inc.
 * licensing@extjs.com
 * http://www.extjs.com/license
 */
Ext.ns("Ext.ux.tree");
Ext.ux.tree.TreeGridLoader = Ext.extend(SYNO.API.TreeLoader, {
    createNode: function(a) {
        if (!a.uiProvider) {
            a.uiProvider = Ext.ux.tree.TreeGridNodeUI
        }
        return SYNO.API.TreeLoader.prototype.createNode.call(this, a)
    }
});
/*
 * Ext JS Library 3.2.1
 * Copyright(c) 2006-2010 Ext JS, Inc.
 * licensing@extjs.com
 * http://www.extjs.com/license
 */
Ext.ns("Ext.ux.tree");
Ext.ux.tree.TreeGridSorter = Ext.extend(Ext.tree.TreeSorter, {
    sortClasses: ["sort-asc", "sort-desc"],
    sortAscText: "Sort Ascending",
    sortDescText: "Sort Descending",
    constructor: function(a, b) {
        if (!Ext.isObject(b)) {
            b = {
                property: a.columns[0].dataIndex || "text",
                folderSort: true
            }
        }
        Ext.ux.tree.TreeGridSorter.superclass.constructor.apply(this, arguments);
        this.tree = a;
        a.on("headerclick", this.onHeaderClick, this);
        a.ddAppendOnly = true;
        var c = this;
        this.defaultSortFn = function(k, j) {
            var g = c.dir && c.dir.toLowerCase() == "desc";
            var d = c.property || "text";
            var f = c.sortType;
            var h = c.folderSort;
            var i = c.caseSensitive === true;
            var e = c.leafAttr || "leaf";
            if (h) {
                if (k.attributes[e] && !j.attributes[e]) {
                    return 1
                }
                if (!k.attributes[e] && j.attributes[e]) {
                    return -1
                }
            }
            var m = f ? f(k) : (i ? k.attributes[d] : k.attributes[d].toUpperCase());
            var l = f ? f(j) : (i ? j.attributes[d] : j.attributes[d].toUpperCase());
            if (m < l) {
                return g ? +1 : -1
            } else {
                if (m > l) {
                    return g ? -1 : +1
                } else {
                    return 0
                }
            }
        };
        a.on("afterrender", this.onAfterTreeRender, this, {
            single: true
        });
        a.on("headermenuclick", this.onHeaderMenuClick, this)
    },
    onAfterTreeRender: function() {
        if (this.tree.hmenu) {
            this.tree.hmenu.insert(0, {
                itemId: "asc",
                text: this.sortAscText,
                cls: "xg-hmenu-sort-asc"
            }, {
                itemId: "desc",
                text: this.sortDescText,
                cls: "xg-hmenu-sort-desc"
            })
        }
        this.updateSortIcon(this.getPropertyIdx(this.property), this.dir)
    },
    onHeaderMenuClick: function(d, b, a) {
        if (b === "asc" || b === "desc") {
            this.onHeaderClick(d, null, a);
            return false
        }
    },
    onHeaderClick: function(e, b, a) {
        if (e && !this.tree.headersDisabled) {
            var d = this;
            d.property = e.dataIndex;
            d.dir = e.dir = (e.dir === "desc" ? "asc" : "desc");
            d.sortType = e.sortType;
            d.caseSensitive = (true === Ext.isBoolean(e.caseSensitive) ? e.caseSensitive : this.caseSensitive);
            d.sortFn = e.sortFn || this.defaultSortFn;
            this.tree.root.cascade(function(c) {
                if (!c.isLeaf()) {
                    d.updateSort(d.tree, c)
                }
            });
            this.updateSortIcon(a, e.dir)
        }
    },
    updateSortIcon: function(b, a) {
        var d = this.sortClasses;
        var c = this.tree.innerHd.select("td").removeClass(d);
        c.item(b).addClass(d[a == "desc" ? 1 : 0])
    },
    getPropertyIdx: function(b) {
        var a = 0;
        Ext.each(this.tree.columns, function(c) {
            if (c.dataIndex === b) {
                return false
            }++a
        });
        return a
    }
});
/*
 * Ext JS Library 3.2.1
 * Copyright(c) 2006-2010 Ext JS, Inc.
 * licensing@extjs.com
 * http://www.extjs.com/license
 */
Ext.ns("Ext.ux.tree");
Ext.tree.ColumnResizer = Ext.extend(Ext.util.Observable, {
    minWidth: 14,
    constructor: function(a) {
        Ext.apply(this, a);
        Ext.tree.ColumnResizer.superclass.constructor.call(this)
    },
    init: function(a) {
        this.tree = a;
        a.on("render", this.initEvents, this)
    },
    initEvents: function(a) {
        a.mon(a.innerHd, "mousemove", this.handleHdMove, this);
        this.tracker = new Ext.dd.DragTracker({
            onBeforeStart: this.onBeforeStart.createDelegate(this),
            onStart: this.onStart.createDelegate(this),
            onDrag: this.onDrag.createDelegate(this),
            onEnd: this.onEnd.createDelegate(this),
            tolerance: 3,
            autoStart: 300
        });
        this.tracker.initEl(a.innerHd);
        a.on("beforedestroy", this.tracker.destroy, this.tracker)
    },
    handleHdMove: function(f, j) {
        var g = 5,
            i = f.getPageX(),
            d = f.getTarget(".x-treegrid-hd", 3, true);
        if (d) {
            var b = d.getRegion(),
                k = d.dom.style,
                c = d.dom.parentNode;
            if (i - b.left <= g && d.dom !== c.firstChild) {
                var a = d.dom.previousSibling;
                while (a && Ext.fly(a).hasClass("x-treegrid-hd-hidden")) {
                    a = a.previousSibling
                }
                if (a) {
                    this.activeHd = Ext.get(a);
                    k.cursor = Ext.isWebKit ? "e-resize" : "col-resize"
                }
            } else {
                if (b.right - i <= g) {
                    var h = d.dom;
                    while (h && Ext.fly(h).hasClass("x-treegrid-hd-hidden")) {
                        h = h.previousSibling
                    }
                    if (h) {
                        this.activeHd = Ext.get(h);
                        k.cursor = Ext.isWebKit ? "w-resize" : "col-resize"
                    }
                } else {
                    delete this.activeHd;
                    k.cursor = ""
                }
            }
        }
    },
    onBeforeStart: function(a) {
        this.dragHd = this.activeHd;
        return !!this.dragHd
    },
    onStart: function(b) {
        this.tree.headersDisabled = true;
        this.proxy = this.tree.body.createChild({
            cls: "x-treegrid-resizer"
        });
        this.proxy.setHeight(this.tree.body.getHeight());
        var a = this.tracker.getXY()[0];
        this.hdX = this.dragHd.getX();
        this.hdIndex = this.tree.findHeaderIndex(this.dragHd);
        this.proxy.setX(this.hdX);
        this.proxy.setWidth(a - this.hdX);
        this.maxWidth = this.tree.outerCt.getWidth() - this.tree.innerBody.translatePoints(this.hdX).left
    },
    onDrag: function(b) {
        var a = this.tracker.getXY()[0];
        this.proxy.setWidth((a - this.hdX).constrain(this.minWidth, this.maxWidth))
    },
    onEnd: function(c) {
        var b = this.proxy.getWidth(),
            a = this.tree;
        this.proxy.remove();
        delete this.dragHd;
        a.columns[this.hdIndex].width = b;
        a.updateColumnWidths();
        setTimeout(function() {
            a.headersDisabled = false
        }, 100)
    }
});
/*
 * Ext JS Library 3.2.1
 * Copyright(c) 2006-2010 Ext JS, Inc.
 * licensing@extjs.com
 * http://www.extjs.com/license
 */
(function() {
    Ext.override(Ext.grid.Column, {
        init: function() {
            var b = Ext.data.Types,
                a = this.sortType;
            if (this.type) {
                if (Ext.isString(this.type)) {
                    this.type = Ext.data.Types[this.type.toUpperCase()] || b.AUTO
                }
            } else {
                this.type = b.AUTO
            }
            if (Ext.isString(a)) {
                this.sortType = Ext.data.SortTypes[a]
            } else {
                if (Ext.isEmpty(a)) {
                    this.sortType = this.type.sortType
                }
            }
        }
    });
    Ext.tree.Column = Ext.extend(Ext.grid.Column, {});
    Ext.tree.NumberColumn = Ext.extend(Ext.grid.NumberColumn, {});
    Ext.tree.DateColumn = Ext.extend(Ext.grid.DateColumn, {});
    Ext.tree.BooleanColumn = Ext.extend(Ext.grid.BooleanColumn, {});
    Ext.reg("tgcolumn", Ext.tree.Column);
    Ext.reg("tgnumbercolumn", Ext.tree.NumberColumn);
    Ext.reg("tgdatecolumn", Ext.tree.DateColumn);
    Ext.reg("tgbooleancolumn", Ext.tree.BooleanColumn)
})();
/*
 * Ext JS Library 3.2.1
 * Copyright(c) 2006-2010 Ext JS, Inc.
 * licensing@extjs.com
 * http://www.extjs.com/license
 */
Ext.ns("Ext.ux.tree");
Ext.ux.tree.TreeGrid = Ext.extend(Ext.tree.TreePanel, {
    rootVisible: false,
    useArrows: true,
    lines: false,
    borderWidth: Ext.isBorderBox ? 0 : 2,
    cls: "x-treegrid",
    columnResize: true,
    enableSort: true,
    reserveScrollOffset: true,
    enableHdMenu: true,
    columnsText: "Columns",
    initComponent: function() {
        if (!this.root) {
            this.root = new Ext.tree.AsyncTreeNode({
                text: "Root"
            })
        }
        var a = this.loader;
        if (!a) {
            a = new Ext.ux.tree.TreeGridLoader({
                dataUrl: this.dataUrl,
                requestMethod: this.requestMethod,
                store: this.store
            })
        } else {
            if (Ext.isObject(a) && !a.load) {
                a = new Ext.ux.tree.TreeGridLoader(a)
            } else {
                if (a) {
                    if (!a.createNode) {
                        a.createNode = function(b) {
                            if (!b.uiProvider) {
                                b.uiProvider = Ext.ux.tree.TreeGridNodeUI
                            }
                            return Ext.tree.TreeLoader.prototype.createNode.call(this, b)
                        }
                    }
                }
            }
        }
        this.loader = a;
        Ext.ux.tree.TreeGrid.superclass.initComponent.call(this);
        this.initColumns();
        if (this.enableSort) {
            this.treeGridSorter = new Ext.ux.tree.TreeGridSorter(this, this.enableSort)
        }
        if (this.columnResize) {
            this.colResizer = new Ext.tree.ColumnResizer(this.columnResize);
            this.colResizer.init(this)
        }
        if (!this.internalTpl) {
            this.internalTpl = new Ext.XTemplate('<div class="x-grid3-header">', '<div class="x-treegrid-header-inner">', '<div class="x-grid3-header-offset">', '<table cellspacing="0" cellpadding="0" border="0"><colgroup><tpl for="columns"><col /></tpl></colgroup>', '<thead><tr class="x-grid3-hd-row">', '<tpl for="columns">', '<td class="x-grid3-hd x-grid3-cell x-treegrid-hd" style="text-align: {align};" id="', this.id, '-xlhd-{#}">', '<div class="x-grid3-hd-inner x-treegrid-hd-inner" unselectable="on">', this.enableHdMenu ? '<a class="x-grid3-hd-btn" href="#"></a>' : "", '{header}<img class="x-grid3-sort-icon" src="', Ext.BLANK_IMAGE_URL, '" />', "</div>", "</td></tpl>", "</tr></thead>", "</div></table>", "</div></div>", "</div>", '<div class="x-treegrid-root-node">', '<table class="x-treegrid-root-table" cellpadding="0" cellspacing="0" style="table-layout: fixed;"></table>', "</div>")
        }
        if (!this.colgroupTpl) {
            this.colgroupTpl = new Ext.XTemplate('<colgroup><tpl for="columns"><col style="width: {width}px"/></tpl></colgroup>')
        }
    },
    initColumns: function() {
        var e = this.columns,
            a = e.length,
            d = [],
            b, f;
        for (b = 0; b < a; b++) {
            f = e[b];
            if (!f.isColumn) {
                f.xtype = f.xtype ? (/^tg/.test(f.xtype) ? f.xtype : "tg" + f.xtype) : "tgcolumn";
                f = Ext.create(f)
            }
            f.init(this);
            d.push(f);
            if (this.enableSort !== false && f.sortable !== false) {
                f.sortable = true;
                this.enableSort = true
            }
        }
        this.columns = d
    },
    onRender: function() {
        Ext.tree.TreePanel.superclass.onRender.apply(this, arguments);
        this.el.addClass("x-treegrid");
        this.outerCt = this.body.createChild({
            cls: "x-tree-root-ct x-treegrid-ct " + (this.useArrows ? "x-tree-arrows" : this.lines ? "x-tree-lines" : "x-tree-no-lines")
        });
        this.internalTpl.overwrite(this.outerCt, {
            columns: this.columns
        });
        this.mainHd = Ext.get(this.outerCt.dom.firstChild);
        this.innerHd = Ext.get(this.mainHd.dom.firstChild);
        this.innerBody = Ext.get(this.outerCt.dom.lastChild);
        this.innerCt = Ext.get(this.innerBody.dom.firstChild);
        this.colgroupTpl.insertFirst(this.innerCt, {
            columns: this.columns
        });
        if (this.hideHeaders) {
            this.header.dom.style.display = "none"
        } else {
            if (this.enableHdMenu !== false) {
                this.hmenu = new SYNO.ux.Menu({
                    id: this.id + "-hctx"
                });
                if (this.enableColumnHide !== false) {
                    this.colMenu = new SYNO.ux.Menu({
                        id: this.id + "-hcols-menu"
                    });
                    this.colMenu.on({
                        scope: this,
                        beforeshow: this.beforeColMenuShow,
                        itemclick: this.handleHdMenuClick
                    });
                    this.hmenu.add({
                        itemId: "columns",
                        hideOnClick: false,
                        text: this.columnsText,
                        menu: this.colMenu,
                        iconCls: "x-cols-icon"
                    })
                }
                this.hmenu.on("itemclick", this.handleHdMenuClick, this)
            }
        }
    },
    setRootNode: function(a) {
        a.attributes.uiProvider = Ext.ux.tree.TreeGridRootNodeUI;
        a = Ext.ux.tree.TreeGrid.superclass.setRootNode.call(this, a);
        if (this.innerCt) {
            this.colgroupTpl.insertFirst(this.innerCt, {
                columns: this.columns
            })
        }
        return a
    },
    clearInnerCt: function() {
        if (Ext.isIE) {
            var a = this.innerCt.dom;
            while (a.firstChild) {
                a.removeChild(a.firstChild)
            }
        } else {
            Ext.ux.tree.TreeGrid.superclass.clearInnerCt.call(this)
        }
    },
    initEvents: function() {
        Ext.ux.tree.TreeGrid.superclass.initEvents.apply(this, arguments);
        this.mon(this.innerHd, "click", this.handleHdDown, this);
        this.mon(this.mainHd, {
            scope: this,
            mouseover: this.handleHdOver,
            mouseout: this.handleHdOut
        })
    },
    onResize: function(b, c) {
        Ext.ux.tree.TreeGrid.superclass.onResize.apply(this, arguments);
        var e = this.innerBody.dom;
        var f = this.innerHd.dom;
        if (!e) {
            return
        }
        if (Ext.isNumber(c)) {
            e.style.height = this.body.getHeight(true) - f.offsetHeight + "px"
        }
        if (Ext.isNumber(b)) {
            var a = Ext.num(this.scrollOffset, Ext.getScrollBarWidth());
            if (this.reserveScrollOffset || ((e.offsetWidth - e.clientWidth) > 10)) {
                this.setScrollOffset(a)
            } else {
                var d = this;
                setTimeout(function() {
                    d.setScrollOffset(e.offsetWidth - e.clientWidth > 10 ? a : 0)
                }, 10)
            }
        }
    },
    updateColumnWidths: function() {
        var l = this.columns,
            n = l.length,
            a = this.outerCt.query("colgroup"),
            m = a.length,
            k, e, d, b, f;
        for (d = 0; d < n; d++) {
            k = l[d];
            for (b = 0; b < m; b++) {
                e = a[b];
                e.childNodes[d].style.width = (k.hidden ? 0 : k.width) + "px";
                if (typeof(k.minWidth) != "undefined") {
                    e.childNodes[d].style.minWidth = k.minWidth + "px"
                }
            }
        }
        for (d = 0, a = this.innerHd.query("td"), f = a.length; d < f; d++) {
            k = Ext.fly(a[d]);
            if (l[d] && l[d].hidden) {
                k.addClass("x-treegrid-hd-hidden")
            } else {
                k.removeClass("x-treegrid-hd-hidden")
            }
        }
        var h = this.getTotalColumnWidth();
        Ext.fly(this.innerHd.dom.firstChild).setWidth(h + (this.scrollOffset || 0));
        this.outerCt.select("table").setWidth(h);
        this.syncHeaderScroll()
    },
    getVisibleColumns: function() {
        var c = [],
            d = this.columns,
            a = d.length,
            b;
        for (b = 0; b < a; b++) {
            if (!d[b].hidden) {
                c.push(d[b])
            }
        }
        return c
    },
    getTotalColumnWidth: function() {
        var d = 0;
        for (var b = 0, c = this.getVisibleColumns(), a = c.length; b < a; b++) {
            d += c[b].width
        }
        return d
    },
    setScrollOffset: function(a) {
        this.scrollOffset = a;
        this.updateColumnWidths()
    },
    handleHdDown: function(h, d) {
        var g = h.getTarget(".x-treegrid-hd");
        var b;
        if (g && Ext.fly(d).hasClass("x-grid3-hd-btn")) {
            b = this.findHeaderIndex(g);
            var a = this.hmenu.items,
                f = this.columns,
                i = f[b];
            h.stopEvent();
            Ext.fly(g).addClass("x-grid3-hd-menu-open");
            this.hdCtxIndex = b;
            this.fireEvent("headerbuttonclick", a, i, g, b);
            this.hmenu.on("hide", function() {
                Ext.fly(g).removeClass("x-grid3-hd-menu-open")
            }, this, {
                single: true
            });
            this.hmenu.show(d, "tl-bl?")
        } else {
            if (g) {
                b = this.findHeaderIndex(g);
                this.fireEvent("headerclick", this.columns[b], g, this.findHeaderIndex(g))
            }
        }
    },
    handleHdOver: function(f, b) {
        var d = f.getTarget(".x-treegrid-hd");
        if (d && !this.headersDisabled) {
            var a = this.findHeaderIndex(d);
            this.activeHdRef = b;
            this.activeHdIndex = a;
            var c = Ext.get(d);
            this.activeHdRegion = c.getRegion();
            c.addClass("x-grid3-hd-over");
            this.activeHdBtn = c.child(".x-grid3-hd-btn");
            if (this.activeHdBtn) {
                this.activeHdBtn.dom.style.height = (d.firstChild.offsetHeight - 1) + "px"
            }
        }
    },
    handleHdOut: function(c, a) {
        var b = c.getTarget(".x-treegrid-hd");
        if (b && (!Ext.isIE || !c.within(b, true))) {
            this.activeHdRef = null;
            Ext.fly(b).removeClass("x-grid3-hd-over");
            b.style.cursor = ""
        }
    },
    findHeaderIndex: function(c) {
        c = c.dom || c;
        var b = c.parentNode.childNodes;
        for (var a = 0; b[a]; a++) {
            if (b[a] == c) {
                return a
            }
        }
        return -1
    },
    beforeColMenuShow: function() {
        var d = this.columns,
            b = d.length,
            a, e;
        this.colMenu.removeAll();
        for (a = 1; a < b; a++) {
            e = d[a];
            if (e.hideable !== false) {
                this.colMenu.add(new Ext.menu.CheckItem({
                    itemId: "col-" + a,
                    text: e.header,
                    checked: !e.hidden,
                    hideOnClick: false,
                    disabled: e.hideable === false
                }))
            }
        }
    },
    handleHdMenuClick: function(b) {
        var a = this.hdCtxIndex,
            c = b.getItemId();
        if (this.fireEvent("headermenuclick", this.columns[a], c, a) !== false) {
            a = c.substr(4);
            if (a > 0 && this.columns[a]) {
                this.setColumnVisible(a, !b.checked)
            }
        }
        return true
    },
    setColumnVisible: function(a, b) {
        this.columns[a].hidden = !b;
        this.updateColumnWidths()
    },
    syncHeaderScroll: function() {
        var a = this.innerBody.dom;
        this.innerHd.dom.scrollLeft = a.scrollLeft;
        this.innerHd.dom.scrollLeft = a.scrollLeft
    },
    registerNode: function(a) {
        Ext.ux.tree.TreeGrid.superclass.registerNode.call(this, a);
        if (!a.uiProvider && !a.isRoot && !a.ui.isTreeGridNodeUI) {
            a.ui = new Ext.ux.tree.TreeGridNodeUI(a)
        }
    }
});
Ext.reg("treegrid", Ext.ux.tree.TreeGrid);
Ext.define("Ext.ux.tree.FleXcrollTreeGrid", {
    extend: "Ext.ux.tree.TreeGrid",
    updateScrollBarEventNames: ["afterlayout", "expandnode", "collapsenode", "resize"],
    updateScrollBarImmediate: {
        resize: true,
        afterlayout: true
    },
    constructor: function(a) {
        var b = Ext.apply(a, {
            autoFlexcroll: false
        });
        var c = this;
        c.callParent([b]);
        c.updateScrollBarEventNames.forEach(function(d) {
            this.mon(this, d, this.updateScrollBarImmediate[d] ? this.updateScrollbar : this.updateScroller, this);
            if (!this.updateScrollBarImmediate[d]) {
                this.mon(this, d, this.updateColumnWidths, this)
            }
        }, c)
    },
    afterRender: function() {
        var a = this;
        a.callParent(arguments);
        a.scroller = a.innerBody;
        a.addClass("syno-ux-gridpanel x-grid-panel");
        a.scroller.addClass("x-grid3-scroller")
    },
    updateScrollbar: function() {
        var a = this;
        var b = a.scroller.dom;
        a.updateColumnWidths();
        if (b && b.fleXcroll) {
            b.fleXcroll.updateScrollBars();
            b.fleXcroll.setScrollPos(0, 0, true)
        } else {
            if (b) {
                fleXenv.fleXcrollMain(b)
            }
        }
    },
    updateColumnWidths: function() {
        var d = this,
            e = d.columns,
            c = e.length,
            a = this.innerCt.parent().getWidth(),
            f = this.getTotalColumnWidth(),
            b;
        for (b = 0; b < c; b++) {
            e[b].width = (e[b].width * a) / f
        }
        d.callParent(arguments)
    }
});