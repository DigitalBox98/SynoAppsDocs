/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.namespace("SYNO.SDS.Utils.ExternalDevices");
 /**
 * @class SYNO.SDS.Utils.ExternalDevices.getFilesystem
 * Utils external devices get filesystem 
 *
 */  
SYNO.SDS.Utils.ExternalDevices.getFilesystem = function(a) {
    switch (a) {
        case "vfat":
            return _T("usb", "usb_fs_fat");
        case "ntfs":
            return _T("usb", "usb_fs_ntfs");
        case "ext3":
            return _T("volume", "volume_ext3");
        case "ext4":
            return _T("volume", "volume_ext4");
        case "hfsplus":
            return _T("volume", "volume_hfsplus");
        default:
            return _T("usb", "usb_fs_other")
    }
};
SYNO.SDS.Utils.ExternalDevices.getStatus = function(a) {
    switch (a) {
        case "normal":
            return '<font class="green-status">' + _T("usb", "usb_st_normal") + "</font>";
        case "format_fail":
            return '<font class="red-status">' + _T("usb", "usb_st_formatfail") + "</font>";
        case "hddfail":
            return '<font class="red-status">' + _T("usb", "usb_st_fail") + "</font>";
        case "corrupt":
            return '<font class="red-status">' + _T("usb", "usb_st_needfsck") + "</font>";
        case "fsck":
            return '<font class="red-status">' + _T("usb", "usb_st_fsck") + "</font>";
        case "formating":
            return '<font class="red-status">' + _T("usb", "usb_st_format") + "</font>";
        case "init":
            return '<font class="red-status">' + _T("usb", "usb_st_init") + "</font>";
        case "usbcopy":
            return '<font class="red-status">' + _T("usb", "usb_st_usbcopy") + "</font>";
        case "usbbackup":
            return '<font class="red-status">' + _T("usb", "usb_st_backingup") + "</font>"
    }
    return a
};
SYNO.SDS.Utils.ExternalDevices.getStatusForESata = function(a, b) {
    switch (a) {
        case "hddfail":
            return '<font class="red-status">' + _T("sata", "sata_handlefail") + "</font>";
        case "format_fail":
            return '<font class="red-status">' + _T("sata", "sata_format_err") + "</font>";
        case "corrupt":
            return '<font class="red-status">' + _T("sata", "sata_needfsck") + "</font>";
        case "fsck":
            return '<font class="red-status">' + _T("sata", "sata_fsck") + "</font>";
        case "formating":
            return '<font class="red-status">' + _T("usb", "usb_st_format") + "</font>";
        case "init":
            return '<font class="red-status">' + _T("sata", "sata_init") + "</font>";
        case "usbbackup":
            return '<font class="red-status">' + _T("sata", "sata_backingup") + "</font>";
        default:
            if (b == _T("usb", "usb_inactive_disk")) {
                return '<font class="red-status">' + _T("usbbackup", "usbbkp_cfrm_inactive") + "</font>"
            }
            return '<font class="green-status">' + _T("usb", "usb_st_normal") + "</font>"
    }
};
