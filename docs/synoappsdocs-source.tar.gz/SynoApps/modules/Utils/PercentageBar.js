/* Copyright (c) 2020 Synology Inc. All rights reserved. */

 /**
 * @class SYNO.SDS.Utils.PercentageBar
 * @extends Ext.XTemplate
 * Percentage bar class
 *
 */  
Ext.define("SYNO.SDS.Utils.PercentageBar", {
    extend: "Ext.XTemplate",
    defaultConf: {
        barWidth: 150,
        barHeight: 16,
        lineHeight: 16,
        marginTop: 0,
        value: 0,
        showValueText: true,
        fixed: true,
        isTray: false,
        fixedBarTpl: ['<div class="{cls} syno-percentage-cmp">', '<div class="percentage-cmp-hbar-background" style="width:{barWidth}px; height:{barHeight}px;">', '<div class="percentage-cmp-hbar-fill" style="width:{fillW}px; height:{barHeight}px; min-width: {fillMinWidth}px;" ></div>', "</div>", '<tpl if="(this.showValueText)">', '<div class="percentage-cmp-value" style="line-height:{lineHeight}px;"> {value} %</div>', "</tpl>", "</div>"],
        flexBarTpl: ['<div class="{cls} syno-percentage-cmp">', '<tpl if="(this.showExtraText)">', '<div class="percentage-cmp-value extra-info" style="line-height:{lineHeight}px;"> {extraInfo}</div>', "</tpl>", '<tpl if="(this.showValueText)">', '<div class="percentage-cmp-value" style="line-height:{lineHeight}px;"> {value} %</div>', "</tpl>", '<div class="percentage-cmp-hbar-background" style="height:{barHeight}px; margin-top:{marginTop}px;">', '<div class="percentage-cmp-hbar-fill" style="width:{fillW}%; height:{barHeight}px; min-width: {fillMinWidth}px;" ></div>', "</div>", "</div>"],
        fixedTrayBarTpl: ['<div class="{cls} syno-percentage-cmp" style="height: {barHeight}px;">', '<div class="percentage-cmp-hbar-background" style="width:{barWidth}px; height:{barHeight}px;">', '<div class="percentage-cmp-hbar-fill" style="width:{fillW}px; height:{barHeight}px; min-width: {fillMinWidth}px;" ></div>', "</div>", "</div>", '<div class="syno-percentage-text" style="display: block; height: 20px;">', '<tpl if="(this.showValueText)">', '<div class="percentage-cmp-size" style="display:inline-block; float:left;"> {info} </div>', '<div class="percentage-cmp-value" style="display:inline-block; float:right;"> {value} %</div>', '<div class="x-clear"></div>', "</tpl>", "</div>"],
        flexTrayBarTpl: ['<div class="{cls} syno-percentage-cmp" style="height: {barHeight}px;">', '<tpl if="(this.showExtraText)">', '<div class="percentage-cmp-value extra-info" style="line-height: {barHeight}px;"> {extraInfo}</div>', "</tpl>", '<div class="percentage-cmp-hbar-background" style="height:{barHeight}px;">', '<div class="percentage-cmp-hbar-fill" style="width:{fillW}%; height:{barHeight}px; min-width: {fillMinWidth}px;" ></div>', "</div>", "</div>", '<div class="syno-percentage-text" style="display: block; height: 20px;">', '<tpl if="(this.showValueText)">', '<div class="pescentage-cmp-size" style="display:inline-block; float:left;"> {info} </div>', '<div class="percentage-cmp-value" style="display:inline-block; float:right;"> {value} %</div>', '<div class="x-clear"></div>', "</tpl>", "</div>"]
    },
    constructor: function(a) {
        Ext.apply(this, this.defaultConf);
        Ext.apply(this, a);
        if (this.fixed) {
            if (this.isTray) {
                SYNO.SDS.Utils.PercentageBar.superclass.constructor.apply(this, this.fixedTrayBarTpl)
            } else {
                SYNO.SDS.Utils.PercentageBar.superclass.constructor.apply(this, this.fixedBarTpl)
            }
        } else {
            if (this.isTray) {
                SYNO.SDS.Utils.PercentageBar.superclass.constructor.apply(this, this.flexTrayBarTpl)
            } else {
                SYNO.SDS.Utils.PercentageBar.superclass.constructor.apply(this, this.flexBarTpl)
            }
        }
    },
    fill: function(d, e, c, f) {
        var b = (this.fixed) ? d * (this.barWidth / 100) : d,
            a;
        c = c || (d === 100);
        a = {
            barHeight: this.barHeight,
            barWidth: this.barWidth,
            lineHeight: this.lineHeight,
            marginTop: this.marginTop,
            fillW: b,
            extraInfo: e,
            value: d,
            info: f,
            fillMinWidth: b > 0 ? 6 : 0,
            cls: this.cls + (c ? " no-animation" : "")
        };
        return this.applyTemplate(a)
    }
});
Ext.define("SYNO.SDS.Utils.ProgressBar", {
    extend: "SYNO.SDS.Utils.PercentageBar",
    constructor: function(a) {
        this.callParent(arguments);
        this.cls = this.cls ? this.cls : "sds-ux-progressbar"
    }
});
