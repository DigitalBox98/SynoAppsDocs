/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.namespace("SYNO.SDS");
var DSM_LOGIN_BACKGROUND_NUM = 8;
var DSM_DESKTOP_BACKGROUND_NUM = 10;
 /**
 * @class SYNO.SDS.Utils.ImageSelector
 * @extends SYNO.SDS.ModalWindow
 * Image selector class
 *
 */  
SYNO.SDS.Utils.ImageSelector = Ext.extend(SYNO.SDS.ModalWindow, {
    rootId: "fm_root",
    nodeMyImage: "nodeMyImage",
    nodeDefault: "nodeDefault",
    pageSize: (!Ext.isIE || Ext.isModernIE) ? 1000 : 250,
    upload: false,
    maxImageSizeKB: Number.MAX_SAFE_INTEGER,
    constructor: function(c, f, d) {
        this.owner = c.owner;
        this.source = f;
        this.type = d;
        this.typeParam = ("desktop" == f) ? d : f + "_" + d;
        this.state = "logo" === this.type ? "myimage" : "default";
        this.config = c;
        this.d = (new Date()).getTime();
        this.imageWebapi = {
            api: "SYNO.Core.Theme.Image",
            method: "get",
            version: 1
        };
        this.superuser = false;
        this.gotoPath = "";
        this.enumGluster = false;
        this.enumCluster = false;
        this.enumSnapshot = false;
        this.needrw = Ext.isDefined(c.needrw) ? c.needrw : false;
        this.appName = c.appName;
        var b = new Ext.data.Store({
            proxy: new SYNO.API.Proxy({
                api: "SYNO.Core.File",
                appWindow: this.owner || false,
                method: "list",
                version: 1,
                listeners: {
                    scope: this,
                    beforeload: function(g, h) {
                        var i = g.activeRequest.read;
                        if (i) {
                            Ext.Ajax.abort(i)
                        }
                    }
                }
            }),
            reader: new Ext.data.JsonReader({
                root: "files",
                id: "path"
            }, [{
                name: "file_id",
                mapping: "path"
            }, {
                name: "path"
            }, {
                name: "real_path",
                mapping: "additional.real_path"
            }, {
                name: "filename",
                mapping: "name"
            }, {
                name: "type",
                mapping: "additional.type"
            }]),
            remoteSort: true,
            autoDestroy: true,
            paramNames: {
                start: "offset",
                limit: "limit",
                sort: "sort_by",
                dir: "sort_direction"
            },
            sortInfo: {
                field: "name",
                direction: "ASC"
            },
            baseParams: {
                sort_by: "name",
                additional: ["real_path", "type", "size"],
                pattern: "jpg,jpeg,jpe,gif,bmp,png"
            },
            listeners: {
                scope: this,
                beforeload: function(g, h) {
                    this.dataView_DS.getEl().mask(_T("common", "loading"), "x-mask-loading");
                    var k = h.params;
                    var j = g.fields.get(g.sortInfo.field);
                    var i = j ? (j.mapping || j.name) : "name";
                    i = i.split(".", 3);
                    k.sort_by = i[2] || i[1] || i[0];
                    k.status_filter = "valid";
                    k.needrw = !!this.needrw;
                    return k
                },
                load: function() {
                    this.dataView_DS.getEl().unmask()
                },
                exception: function(i, j, k, h, l, g) {
                    this.dataView_DS.getEl().mask(SYNO.API.Erros.core[l.code])
                }
            }
        });
        if ("" !== this.appName) {
            SYNO.SDS.Utils.FileChooser.Utils.UpdateConfigByCapability(c, this.appName)
        }
        var a = {
            itemId: "mainWindow",
            title: _T("personal_settings", "select_image"),
            width: 860,
            height: 545,
            minWidth: 860,
            minHeight: 545,
            layout: "fit",
            hideBorders: true,
            padding: "0 20px 0px 8px",
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: this.cancelHandler
            }, {
                text: _T("common", "choose"),
                btnStyle: "blue",
                scope: this,
                handler: this.selectHandler
            }],
            items: []
        };
        this.store_fromDS = b;
        var e = {
            itemId: "mainPanel",
            layout: "border",
            cls: "syno-sds-image-selector",
            hideBorders: true,
            items: [{
                itemId: "westpanel",
                xtype: "syno_panel",
                region: "west",
                width: 200,
                split: true,
                minWidth: 150,
                autoScroll: true,
                layout: "border",
                items: [{
                    itemId: "tree_myimage",
                    xtype: "syno_treepanel",
                    region: "north",
                    useArrows: true,
                    border: false,
                    cls: "tree_myimage",
                    rootVisible: false,
                    padding: "8px 4px 0 4px",
                    root: new Ext.tree.AsyncTreeNode({
                        cls: "root_node",
                        expanded: true,
                        children: [{
                            id: this.nodeMyImage,
                            text: _T("image_selector", "my_image"),
                            allowDrop: false,
                            iconCls: "icon_my_image",
                            expanded: true,
                            children: []
                        }, {
                            id: this.nodeDefault,
                            text: _T("image_selector", "default_wallpaper"),
                            allowDrop: false,
                            iconCls: "icon_default_image",
                            expanded: true,
                            hidden: "logo" === this.type,
                            children: []
                        }]
                    }),
                    selModel: new Ext.tree.DefaultSelectionModel({
                        listeners: {
                            selectionchange: {
                                fn: this.onTreeMyImageSelectionChange,
                                scope: this,
                                buffer: 100
                            },
                            beforeselect: {
                                fn: this.onTreeMyImageBeforeSelect,
                                scope: this
                            }
                        }
                    })
                }, {
                    itemId: "tree",
                    xtype: "syno_treepanel",
                    cls: "tree_filestation",
                    region: "center",
                    autoScroll: true,
                    useArrows: true,
                    border: false,
                    rootVisible: false,
                    padding: "0 4px 0 4px",
                    loader: new SYNO.API.TreeLoader({
                        api: "SYNO.Core.File",
                        method: "list",
                        version: 1,
                        baseParams: {
                            status_filter: "valid",
                            needrw: !!this.needrw
                        },
                        clearOnLoad: false,
                        appWindow: this.owner || false,
                        createNode: function(g, h) {
                            if (!h) {
                                return SYNO.API.TreeLoader.prototype.createNode.call(this, g)
                            }
                            g = SYNO.SDS.Utils.FileChooser.Utils.ParseTreeNode(g, h);
                            if (!g.spath) {
                                g.spath = g.path
                            }
                            if ((!c.enumGluster && g.is_gluster) || (!c.enumCluster && g.is_cluster) || (!c.enumSnapshot && g.is_snapshot) || (!c.enumColdStorage && g.is_cold_storage) || (!c.enumC2Share && g.is_c2share) || (Ext.isFunction(c.treeFilter) && false === c.treeFilter(this, g))) {
                                g.cls = (g.cls || "") + (" node_display_none");
                                g.hideNode = true
                            }
                            if (Ext.isDefined(g.children) && Ext.isArray(g.children.files) && g.children.files.length > 0) {
                                g.expanded = true
                            }
                            return SYNO.API.TreeLoader.prototype.createNode.call(this, g)
                        },
                        processResponse: function(k, j, r, s) {
                            var t = k.responseText;
                            try {
                                var g = k.responseData || Ext.decode(t);
                                g = ("fm_root" !== j.id) ? g.data.files : g.data;
                                j.beginUpdate();
                                for (var l = 0, m = g.length; l < m; l++) {
                                    var h = this.createNode(g[l], j);
                                    if (h) {
                                        var q = j.appendChild(h);
                                        this.doNodeload(q)
                                    }
                                }
                                j.endUpdate();
                                this.runCallback(r, s || j, [j])
                            } catch (p) {
                                this.handleFailure(k)
                            }
                        },
                        doNodeload: function(j) {
                            if (!j.attributes.children) {
                                return
                            }
                            var h = j.attributes.children.files;
                            j.beginUpdate();
                            for (var g = 0; g < h.length; g++) {
                                var k = j.appendChild(this.createNode(h[g], j));
                                this.doNodeload(k)
                            }
                            j.endUpdate()
                        },
                        listeners: {
                            scope: this,
                            beforeload: function(h, g) {
                                if ("fm_root" === g.id) {
                                    Ext.apply(h.baseParams, {
                                        superuser: this.superuser,
                                        folder_path: "/"
                                    })
                                } else {
                                    Ext.apply(h.baseParams, {
                                        superuser: this.superuser,
                                        filetype: "dir",
                                        folder_path: g.id.substr(g.id.indexOf("/")),
                                        additional: ["real_path", "size", "owner", "time", "perm", "type", "mount_point_type"],
                                        goto_path: !this.gotoComplete ? this.gotoPath : ""
                                    })
                                }
                            },
                            load: function(l, j) {
                                if (j.id !== "fm_root" || "fromDS" !== this.state) {
                                    return
                                }
                                var h;
                                for (var g = 0; g < j.childNodes.length; g++) {
                                    h = j.childNodes[g];
                                    if (!h.attributes.hideNode) {
                                        this.tree.getNodeById(h.id).select();
                                        break
                                    }
                                }
                                if (!this.gotoComplete && !Ext.isEmpty(this.gotoPath)) {
                                    if (this.gotoPath.indexOf("/", 1) !== -1) {
                                        SYNO.SDS.Utils.FileChooser.Utils.getShareNodeByPath(this.tree, this.gotoPath).reload(function() {
                                            this.gotoComplete = true;
                                            var i = this.tree.getNodeById(SYNO.SDS.Utils.FileChooser.Utils.source.remote + this.gotoPath);
                                            if (Ext.isDefined(i)) {
                                                i.select()
                                            } else {
                                                if (Ext.isDefined(h)) {
                                                    h.select()
                                                }
                                            }
                                        }, this)
                                    } else {
                                        this.gotoComplete = true;
                                        var k = this.tree.getNodeById(SYNO.SDS.Utils.FileChooser.Utils.source.remote + this.gotoPath);
                                        if (Ext.isDefined(k)) {
                                            k.select()
                                        } else {
                                            if (Ext.isDefined(h)) {
                                                h.select()
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }),
                    root: (new Ext.tree.AsyncTreeNode({
                        id: "fm_top_root",
                        allowDrag: false,
                        allowDrop: false,
                        children: [{
                            cls: "root_node",
                            text: _S("hostname"),
                            draggable: false,
                            allowDrop: false,
                            expanded: true,
                            id: this.rootId
                        }]
                    })),
                    selModel: new Ext.tree.DefaultSelectionModel({
                        listeners: {
                            selectionchange: {
                                fn: this.onTreeSelectionChange,
                                scope: this,
                                buffer: 100
                            },
                            beforeselect: {
                                fn: this.onTreeBeforeSelect,
                                scope: this
                            }
                        }
                    })
                }]
            }, {
                layout: "card",
                itemId: "centerpanel",
                region: "center",
                xtype: "syno_panel",
                padding: "16px 0 0 16px",
                minWidth: 300,
                border: false,
                bbar: new Ext.PagingToolbar({
                    store: this.store_fromDS,
                    pageSize: this.pageSize,
                    hidden: true,
                    listeners: {
                        scope: this,
                        change: function(h, i) {
                            var g = (i.total > h.pageSize) && this.state === "fromDS";
                            h.setVisible(g);
                            if (i.total !== 0 && (i.total % h.pageSize) === 0 && h.store.getCount() === 0) {
                                h.movePrevious()
                            }
                            h.ownerCt.doLayout();
                            return true
                        }
                    }
                }),
                items: [{
                    itemId: "panel_myimage",
                    xtype: "syno_panel",
                    border: false,
                    items: [this.getUploadPanel(c), {
                        xtype: "syno_fieldset",
                        title: _T("image_selector", "history"),
                        itemId: "myimage_fieldset",
                        items: [{
                            xtype: "syno_button",
                            itemId: "clean_button",
                            text: _T("dsmnotify", "clearall"),
                            scope: this,
                            handler: this.onCleanHistoryImages
                        }, {
                            itemId: "view_history",
                            xtype: "dataview",
                            cls: "view-thumbnails myimage-view-thumbnails",
                            singleSelect: true,
                            itemSelector: "div.thumb-wrap",
                            store: this.createWebapiStore(c),
                            prepareData: (function(g) {
                                var h = {
                                    type: this.typeParam,
                                    is_thumbnail: true,
                                    index: g.index,
                                    d: this.d
                                };
                                g.url = this.getBaseURL(Ext.apply(this.imageWebapi, {
                                    params: h
                                }));
                                g.apply_type = "history";
                                g.path = g.path;
                                g.filename = this.type + (g.index + 1) + "." + g.path.split(".").pop();
                                return g
                            }).createDelegate(this),
                            tpl: this.getDataViewTpl(),
                            listeners: {
                                scope: this,
                                dblclick: {
                                    fn: this.onViewItemDoubleClick
                                },
                                beforeselect: {
                                    fn: this.onViewHistoryBeforeSelect,
                                    scope: this
                                }
                            }
                        }]
                    }],
                    listeners: {
                        scope: this,
                        activate: function() {
                            this.uploadBtn.updateFileInputStyle()
                        }
                    }
                }],
                listeners: {
                    scope: this,
                    afterlayout: function() {
                        if (!this.centerPanel) {
                            return
                        }
                        var g = this.centerPanel.getLayout().activeItem;
                        if (g) {
                            g.updateFleXcroll()
                        }
                    }
                }
            }]
        };
        e.items[1].items.push(this.initViewConfig());
        if (this.type === "background") {
            e.items[1].items.push(this.initDefaultPanel())
        }
        a.items.push(e);
        Ext.apply(a, c);
        SYNO.SDS.Utils.ImageSelector.superclass.constructor.call(this, a);
        this.addEvents("choose");
        this.mainPanel = this.getComponent("mainPanel");
        this.westPanel = this.mainPanel.getComponent("westpanel");
        this.centerPanel = this.mainPanel.getComponent("centerpanel");
        this.tree = this.westPanel.getComponent("tree");
        this.view = this.centerPanel.getComponent("view");
        this.tree_myimage = this.westPanel.getComponent("tree_myimage");
        this.panel_myimage = this.centerPanel.getComponent("panel_myimage");
        this.view_history = this.panel_myimage.getComponent("myimage_fieldset").getComponent("view_history");
        this.cleanBtn = this.panel_myimage.getComponent("myimage_fieldset").getComponent("clean_button");
        this.uploadForm = this.panel_myimage.getComponent("upload_fieldset").getComponent("upload_form");
        this.uploadBtn = Ext.getCmp(this.uploadBtnID);
        if ("background" === this.type) {
            this.panel_default = this.centerPanel.getComponent("panel_default");
            this.view_default = this.panel_default.getComponent("view_default");
            if ("login" === this.source || "fbsharing_login" === this.source) {
                this.addDefaultPackageRecord();
                this.addDefaultRecord(DSM_LOGIN_BACKGROUND_NUM, "login")
            } else {
                if ("desktop" === this.source) {
                    this.addDefaultRecord(DSM_DESKTOP_BACKGROUND_NUM, "desktop")
                }
            }
        }
        this.uploadForm.on("actioncomplete", this.onUploadDone, this);
        this.uploadForm.on("actionfailed", this.onUploadDone, this);
        if (this.isFirefox3()) {
            this.uploadForm.addClass("ext-firefox3")
        }
    },
    createWebapiStore: function(a) {
        var b = new SYNO.API.JsonStore({
            api: "SYNO.Core.Theme.Image",
            method: "list",
            version: 1,
            baseParams: {
                type: this.typeParam
            },
            root: "list",
            id: "index",
            fields: ["index", "filename", "path"],
            remoteSort: true,
            autoDestroy: true,
            appWindow: a.owner,
            listeners: {
                scope: this,
                load: this.onWebapiStoreLoad,
                exception: function(e, f, g, d, h, c) {
                    if (h && h.code === 4004) {
                        this.getMsgBox().alert("", _T("wallpaper", "error_unknown"))
                    }
                }
            }
        });
        return b
    },
    getImageLoader: function() {
        return this.imageload || (this.imageload = new SYNO.SDS.Utils.ImageLoad())
    },
    onBeforeDestroy: function() {
        this.getImageLoader().stop();
        SYNO.SDS.Utils.ImageSelector.superclass.onBeforeDestroy.apply(this, arguments)
    },
    isRetina: function() {
        return SYNO.SDS.UIFeatures.IconSizeManager.isRetinaMode()
    },
    addDefaultRecord: function(e, h) {
        var c = "webman/resources/images/{0}/default_login_background";
        var b = "webman/resources/images/{0}/default_wallpaper";
        var f = (h === "login") ? c : b;
        var j = this.view_default.getStore();
        var l, a;
        var k = this.isRetina() ? "2x" : "1x";
        var g = "dsm7_0";
        for (var d = 1; d <= e; d++) {
            if (h === "login") {
                l = g + d + ".jpg"
            } else {
                l = "/usr/syno/synoman/" + f + "/" + g + d + ".jpg";
                l = String.format(l, k)
            }
            a = String.format(f, k) + "/thumbnail_0" + d + ".jpg?v=" + _S("version");
            j.add(new Ext.data.Record(Ext.applyIf({
                path: l,
                apply_type: "default",
                type: ".jpg",
                filename: "Wallpaper" + d,
                url: a
            })))
        }
    },
    addDefaultPackageRecord: function() {
        if (this.appName && SYNO.SDS.Config.FnMap[this.appName] && SYNO.SDS.Config.FnMap[this.appName].config) {
            var a = SYNO.SDS.Config.FnMap[this.appName].config;
            if (a.loginStyle && a.loginStyle.defaultLoginWallpaper && a.loginStyle.defaultLoginWallpaperThumbnail) {
                var b = this.view_default.getStore();
                var d = "/usr/syno/synoman/" + a.jsBaseURL + "/" + a.loginStyle.defaultLoginWallpaper;
                var c = a.jsBaseURL + "/" + a.loginStyle.defaultLoginWallpaperThumbnail;
                b.add(new Ext.data.Record(Ext.applyIf({
                    path: d,
                    apply_type: "pkgDefault",
                    type: ".jpg",
                    filename: _T("image_selector", "default_package_wallpaper_filename"),
                    url: c.replace("{0}", this.isRetina() ? "2x" : "1x")
                })))
            }
        }
    },
    initViewConfig: function() {
        var a = this.getImageLoader();
        return (this.dataView_DS = new SYNO.SDS.Utils.DataView.LazyDataView({
            itemId: "view",
            cls: "view-thumbnails",
            store: this.store_fromDS,
            hidden: true,
            tpl: new Ext.XTemplate('<tpl for=".">', '<div class="thumb-wrap">', '<div ext:qtip="{filename:qtipHtmlEncode}" class="thumb">', '<div class="thumb-hover thumb-loading">', '<img src="../scripts/ext-3/resources/images/default/s.gif" url="{url}">', "</div>", "<span>{filename:htmlEncode}</span>", "</div>", "</div>", "</tpl>", '<div class="x-clear"></div>'),
            overClass: "x-view-over",
            singleSelect: true,
            itemSelector: "div.thumb-wrap",
            loadingText: _T("common", "loading"),
            itemCls: ".syno-sds-image-selector div.thumb",
            onLoadItem: function(d) {
                var c = d.select("img"),
                    b;
                if (c.elements.length) {
                    b = c.elements[0];
                    if (b) {
                        b.src = b.getAttribute("url");
                        a.loadImg(b, {
                            load: (function(e) {
                                var f = Ext.fly(e).parent();
                                if (f) {
                                    f.removeClass("thumb-loading")
                                }
                            }),
                            error: (function(e) {
                                var f = Ext.fly(e).parent();
                                if (f) {
                                    f.removeClass("thumb-loading")
                                }
                                e.src = "/webman/modules/PhotoViewer/images/no_thumbnail.gif"
                            })
                        })
                    }
                }
            },
            prepareData: (function(b) {
                if (b.type) {
                    if ("." !== b.type[0]) {
                        b.type = "." + b.type
                    }
                }
                var c = {
                    path: b.path,
                    d: this.d,
                    size: "medium"
                };
                if (4944 <= parseInt(this._S("version"), 10) || 4 <= parseInt(this._S("fullversion").substr(this._S("fullversion").indexOf("-s") + 2), 10)) {
                    b.url = this.getBaseURL(Ext.apply({
                        api: "SYNO.Core.File.Thumbnail",
                        method: "get",
                        version: 1
                    }, {
                        params: c
                    }))
                } else {
                    b.url = this.getBaseURL(Ext.apply({
                        api: "SYNO.FileStation.Thumb",
                        method: "get",
                        version: 1
                    }, {
                        params: c
                    }))
                }
                if (b.filename) {
                    b.ellipsis_filename = Ext.util.Format.ellipsis(b.filename, 15, true)
                } else {
                    b.ellipsis_filename = ""
                }
                b.apply_type = "fromDS";
                return b
            }).createDelegate(this),
            listeners: {
                scope: this,
                dblclick: {
                    fn: this.onViewItemDoubleClick
                }
            }
        }))
    },
    initDefaultPanel: function() {
        var a = new SYNO.ux.Panel({
            itemId: "panel_default",
            hidden: true,
            border: false,
            items: [{
                itemId: "view_default",
                xtype: "dataview",
                cls: "view-thumbnails",
                singleSelect: true,
                overClass: "x-view-over",
                itemSelector: "div.thumb-wrap",
                store: new Ext.data.ArrayStore({
                    autoDestroy: true,
                    fields: ["filename", "path", "url", "type", "apply_type"],
                    data: []
                }),
                tpl: this.getDataViewTpl(),
                listeners: {
                    scope: this,
                    dblclick: {
                        fn: this.onViewItemDoubleClick
                    },
                    beforeselect: {
                        fn: this.onViewDefaultBeforeSelect,
                        scope: this
                    }
                }
            }]
        });
        return a
    },
    onViewItemDoubleClick: function() {
        this.selectHandler()
    },
    onTreeBeforeSelect: function(c, a, b) {
        if (this.rootId === a.id) {
            return false
        }
        if (!this.gotoComplete && !Ext.isEmpty(this.gotoPath)) {
            return false
        }
        if ("fromDS" === this.state) {
            return true
        }
        this.state = "fromDS";
        if (this.tree_myimage.getSelectionModel().getSelectedNode()) {
            this.tree_myimage.getSelectionModel().clearSelections()
        }
        this.centerPanel.layout.setActiveItem(this.view);
        return true
    },
    onTreeSelectionChange: function(b, a) {
        if (a) {
            this.view.emptyText = "";
            this.store_fromDS.removeAll();
            this.store_fromDS.baseParams.folder_path = a.attributes.spath;
            this.store_fromDS.baseParams.filetype = "file";
            this.store_fromDS.load({
                params: {
                    offset: 0,
                    limit: this.pageSize
                }
            });
            this.view.emptyText = '<div style="margin:10px 0px 5px 10px;">' + _T("image_selector", "folder_empty") + "</div>"
        }
    },
    onTreeMyImageBeforeSelect: function(c, a, b) {
        if (this.tree.getSelectionModel().getSelectedNode()) {
            this.tree.getSelectionModel().clearSelections()
        }
        if (this.nodeMyImage === a.id) {
            this.state = "myimage";
            this.centerPanel.layout.setActiveItem(this.panel_myimage)
        } else {
            if (this.panel_default && this.nodeDefault === a.id) {
                this.state = "default";
                this.centerPanel.layout.setActiveItem(this.panel_default)
            }
        }
    },
    onTreeMyImageSelectionChange: function(c, b) {
        if (b && this.nodeMyImage === b.id) {
            var a = this.view_history.getStore();
            this.view_history.emptyText = "";
            a.removeAll();
            a.load();
            this.view_history.emptyText = '<div style="margin:10px 0px 5px 10px;">' + _T("image_selector", "folder_empty") + "</div>"
        }
    },
    onCleanHistoryImages: function() {
        var a = this;
        this.getMsgBox().confirm("confirm", _T("image_selector", "clean_history_confirm"), function(b) {
            if (b === "yes") {
                a.doCleanHistoryImages()
            }
        })
    },
    doCleanHistoryImages: function() {
        var a = this.view_history.getStore();
        a.removeAll();
        this.panel_myimage.updateFleXcroll();
        this.cleanBtn.disable();
        this.panel_myimage.getEl().mask(_T("common", "loading"), "x-mask-loading");
        this.sendWebAPI({
            api: "SYNO.Core.Theme.Image",
            method: "clean_history",
            version: 1,
            params: {
                type: this.typeParam
            },
            scope: this,
            callback: function() {
                this.panel_myimage.getEl().unmask()
            }
        })
    },
    onWebapiStoreLoad: function() {
        this.panel_myimage.updateFleXcroll();
        var a = this.view_history.getStore();
        if (a.data.length !== 0) {
            this.cleanBtn.enable()
        } else {
            this.cleanBtn.disable()
        }
    },
    onViewDefaultBeforeSelect: function(c, a, b) {
        if (this.view_history) {
            this.view_history.clearSelections()
        }
    },
    onViewHistoryBeforeSelect: function(c, a, b) {
        if (this.view_default) {
            this.view_default.clearSelections()
        }
    },
    selectHandler: function() {
        var a;
        if (this.upload) {
            var b = new Ext.data.Record.create([{
                name: "path"
            }, {
                name: "apply_type"
            }, {
                name: "type"
            }, {
                name: "filename"
            }, {
                name: "url"
            }]);
            var d = {
                index: 0,
                type: this.typeParam,
                d: (new Date()).getTime()
            };
            var c = this.getBaseURL(Ext.apply(this.imageWebapi, {
                params: d
            }));
            a = new b({
                path: this.upload_data.path,
                hd_path: this.upload_data.hd_path,
                filename: this.upload_data.filename,
                apply_type: "history",
                url: c
            });
            this.upload = false
        } else {
            if ("fromDS" === this.state) {
                a = this.view.getSelectedRecords()[0];
                if (a && a.json && a.json.additional.size / 1000 > this.maxImageSizeKB) {
                    this.alertOverSize();
                    return
                }
            } else {
                if ("myimage" === this.state) {
                    a = this.view_history.getSelectedRecords()[0]
                } else {
                    if ("default" === this.state) {
                        a = this.view_default.getSelectedRecords()[0]
                    }
                }
            }
        }
        if (a) {
            this.fireEvent("choose", a)
        } else {
            this.setStatusError({
                text: _T("image_selector", "error_not_an_image")
            })
        }
    },
    cancelHandler: function() {
        this.hide()
    },
    onUploadDone: function(b, c) {
        this.clearStatusBusy();
        if (!c.result || !c.result.success) {
            var d = _T("user", "user_file_upload_fail");
            var a;
            if (c.result && c.result.error) {
                a = c.result.error;
                if (SYNO.API.Erros.core[a.code]) {
                    d = SYNO.API.Erros.core[a.code]
                }
            }
            if (a && a.code === 4004) {
                this.getMsgBox().alert("", _T("wallpaper", "error_unknown"))
            } else {
                this.getMsgBox().alert(this.title, d)
            }
            return
        } else {
            this.upload = c.result.success;
            this.upload_data = c.result.data;
            this.selectHandler()
        }
    },
    isFirefox3: function() {
        if (Ext.isGecko && 0 < navigator.userAgent.search("Firefox/3")) {
            return true
        }
        return false
    },
    afterShow: function() {
        SYNO.SDS.Utils.ImageSelector.superclass.afterShow.apply(this, arguments);
        this.d = (new Date()).getTime();
        this.gotoComplete = false;
        this.tree.getNodeById("fm_root").reload();
        this.tree_myimage.getSelectionModel().clearSelections();
        if ("myimage" === this.state) {
            this.tree_myimage.getRootNode().firstChild.select()
        } else {
            if ("default" === this.state) {
                this.tree_myimage.getRootNode().lastChild.select()
            }
        }
    },
    afterHide: function() {
        SYNO.SDS.Utils.ImageSelector.superclass.afterHide.apply(this, arguments);
        var a = this.tree.getSelectionModel().getSelectedNode();
        if ("fromDS" === this.state && a) {
            this.gotoPath = a.attributes.spath
        }
    },
    getDataViewTpl: function() {
        var a = new Ext.XTemplate('<tpl for=".">', '<div class="thumb-wrap">', '<div ext:qtip="{filename:qtipHtmlEncode}" class="thumb">', '<div class="thumb-hover">', '<img src="{url}">', "</div>", "<span>{filename:htmlEncode}</span>", "</div>", "</div>", "</tpl>", '<div class="x-clear"></div>');
        return a
    },
    getUploadPanel: function(b) {
        var a = SYNO.API.GetBaseURL({
            api: "SYNO.Core.Theme.Image",
            method: "upload",
            version: 1
        });
        if (b.owner && b.owner.getBaseURL) {
            a = b.owner.getBaseURL({
                api: "SYNO.Core.Theme.Image",
                method: "upload",
                version: 1
            })
        }
        return {
            xtype: "syno_fieldset",
            title: _T("image_selector", "title_upload_local"),
            itemId: "upload_fieldset",
            items: [{
                xtype: "form",
                itemId: "upload_form",
                id: this.uploadFormID = Ext.id(),
                cls: "image-selector-upload-form",
                border: false,
                fileUpload: true,
                trackRestOnLoad: true,
                autoFlexcroll: false,
                url: a,
                items: [{
                    itemId: "type",
                    name: "type",
                    xtype: "hidden",
                    value: this.typeParam
                }, {
                    xtype: "syno_filebutton",
                    id: this.uploadBtnID = Ext.id(),
                    itemId: "upload_btn",
                    name: "upload_image",
                    fieldLabel: _T("image_selector", "source_upload"),
                    hideLabel: true,
                    buttonOnly: true,
                    disabled: _S("demo_mode"),
                    buttonText: _T("image_selector", "source_upload"),
                    listeners: {
                        scope: this,
                        render: function(c) {
                            if ("logo" == this.type) {
                                SYNO.ux.AddTip(c.getEl(), _T("dsmoption", "prompt_size"))
                            }
                            c.el.on("change", function() {
                                var d = Ext.getCmp(this.uploadFormID);
                                this.uploadBtn = c;
                                if (c.el.dom.value) {
                                    this.setStatusBusy({
                                        text: _T("common", "saving")
                                    });
                                    d.getForm().submit()
                                }
                            }, this)
                        }
                    }
                }],
                listeners: {
                    beforeaction: function(f, g) {
                        var e = g.form.items.get("upload_btn"),
                            c, d;
                        if (e && e.getEl() && e.getEl().dom) {
                            c = e.getEl().dom
                        }
                        if (c && c.files) {
                            d = c.files[0].size;
                            if ((d / 1000) > this.maxImageSizeKB) {
                                this.alertOverSize();
                                this.clearStatusBusy();
                                return false
                            }
                        }
                    },
                    scope: this
                }
            }]
        }
    },
    alertOverSize: function() {
        this.findAppWindow().getMsgBox().alert("no title", String.format(_T("personal_settings", "image_is_too_big"), Ext.util.Format.fileSize(this.maxImageSizeKB * 1024)))
    }
});
