/* Copyright (c) 2020 Synology Inc. All rights reserved. */

 /**
 * @class SYNO.SDS.Utils.AccountPasswordDialog
 * @extends SYNO.SDS.ModalWindow
 * AccountPassword dialog class
 *
 */  
Ext.define("SYNO.SDS.Utils.AccountPasswordDialog", {
    extend: "SYNO.SDS.ModalWindow",
    dailog: undefined,
    statics: {
        openDialog: function(a, b) {
            if ("SynologyCMS" === a._S("user")) {
                b();
                return
            }
            if (!this.dialog) {
                this.dialog = new SYNO.SDS.Utils.AccountPasswordDialog({
                    owner: a,
                    callback: b,
                    listeners: {
                        scope: this,
                        beforeclose: function() {
                            this.dialog = undefined
                        }
                    }
                })
            }
            this.dialog.open()
        }
    },
    constructor: function(a) {
        a.callback = a.callback || function() {};
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        var b = {
            title: _T("common", "enter_password_to_continue"),
            width: 550,
            height: 240,
            resizable: false,
            layout: "fit",
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "alt_cancel"),
                scope: this,
                handler: this.cancel
            }, {
                xtype: "syno_button",
                text: _T("common", "submit"),
                btnStyle: "red",
                scope: this,
                handler: this.submit
            }],
            items: [{
                xtype: "syno_formpanel",
                itemId: "account_password_form_panel",
                bodyStyle: "padding: 0",
                items: [{
                    xtype: "syno_displayfield",
                    value: String.format(_T("common", "enter_user_password"))
                }, {
                    xtype: "syno_textfield",
                    fieldLabel: _T("common", "username"),
                    allowBlank: false,
                    itemId: "account"
                }, {
                    xtype: "syno_textfield",
                    fieldLabel: _T("common", "password"),
                    textType: "password",
                    allowBlank: false,
                    itemId: "password"
                }]
            }]
        };
        Ext.apply(b, a);
        return b
    },
    getForm: function() {
        var a = this.getComponent("account_password_form_panel");
        return a.getForm()
    },
    submit: function() {
        var a = this.getForm();
        this.setStatusBusy();
        this.callback({
            account: a.findField("account").getValue(),
            passwd: a.findField("password").getValue()
        }, this.onSubmit.bind(this))
    },
    onSubmit: function(d, a) {
        this.clearStatusBusy();
        if (d) {
            this.close()
        } else {
            var c = {};
            var b = this.getForm();
            Ext.applyIf(c, a);
            this.setStatusError(c);
            b.findField("password").focusInput()
        }
    },
    cancel: function() {
        this.callback();
        this.close()
    }
});
