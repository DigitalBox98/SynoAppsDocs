/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.Utils.ImageLoad");
 /**
 * @class SYNO.SDS.Utils.ImageLoad
 * @extends Object
 * Image load class
 *
 */  
SYNO.SDS.Utils.ImageLoad = Ext.extend(Object, {
    list: [],
    intervalId: null,
    tick: function() {
        for (var a = 0; a < this.list.length; a++) {
            if (this.list[a].end) {
                this.list.splice(a--, 1)
            } else {
                this.list[a]()
            }
        }
        if (!this.list.length) {
            this.stop()
        }
    },
    stop: function() {
        clearInterval(this.intervalId);
        this.intervalId = null;
        this.clean()
    },
    clean: function() {
        for (var a = 0; a < this.list.length; a++) {
            if (this.list[a].img) {
                this.list[a].img.onload = this.list[a].img.onerror = null
            }
        }
        this.list = []
    },
    load: function(c, a) {
        var b = new Image();
        b.src = c;
        this.loadImg(b, a, true)
    },
    loadImg: function(b, a) {
        this.loadfn(b, a, false)
    },
    loadfn: function(d, l, i) {
        l = l || {};
        var g, b, j, c, a, k = l.beforeload,
            f = l.ready,
            h = l.load,
            e = l.error;
        if (d.complete) {
            if (Ext.isFunction(f)) {
                f(d)
            }
            if (Ext.isFunction(h)) {
                h(d)
            }
            return
        }
        b = d.width;
        j = d.height;
        d.onerror = function() {
            if (Ext.isFunction(e)) {
                e(d)
            }
            g.end = true;
            d.onload = d.onerror = null;
            if (false !== i) {
                d = null
            }
        };
        g = function() {
            c = d.width;
            a = d.height;
            if (c !== b || a !== j || c * a > 1024) {
                if (Ext.isFunction(f)) {
                    f(d)
                }
                g.end = true
            }
        };
        g();
        d.onload = function() {
            if (!g.end) {
                g()
            }
            if (Ext.isFunction(h)) {
                h(d)
            }
            d.onload = d.onerror = null;
            if (false !== i) {
                d = null
            }
        };
        g.img = d;
        if (!g.end) {
            this.list.push(g);
            if (this.intervalId === null) {
                this.intervalId = setInterval(this.tick.createDelegate(this), 100)
            }
        }
        if (Ext.isFunction(k)) {
            k(d)
        }
    }
});
