/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.namespace("SYNO.SDS.PollingTask");
/**
 * @class SYNO.SDS.PollingTask.Application
 * @extends SYNO.SDS.AppInstance
 * PollingTask application instance class
 *
 */
Ext.define("SYNO.SDS.PollingTask.Application", {
    extend: "SYNO.SDS.AppInstance",
    initInstance: function(a) {
        this.trayItem = this.trayItem || [];
        if (!this.trayItem[0]) {
            this.trayItem[0] = new SYNO.SDS.PollingTask.Tray({
                appInstance: this
            });
            this.addInstance(this.trayItem[0]);
            this.trayItem[0].open(a)
        }
    }
});
Ext.define("SYNO.SDS.PollingTask.Tray", {
    extend: "SYNO.SDS.Tray.ArrowTray",
    initPanel: function() {
        return new SYNO.SDS.PollingTask.Panel({
            module: this,
            baseURL: this.jsConfig.jsBaseURL
        })
    }
});
Ext.define("SYNO.SDS.PollingTask.Panel", {
    extend: "SYNO.SDS.Tray.Panel",
    id: Ext.id(),
    blEnableClick: false,
    storeId: "DiskPortDisabledTray",
    lastSeen: 0,
    lastRead: 0,
    pollTask: null,
    pollTaskConfig: null,
    pollingInterval: 30 * 1000,
    externalDeviceJson: null,
    constructor: function(a) {
        this.gcList = [];
        this.callParent([Ext.apply({
            hidden: true,
            floating: true,
            shadow: false,
            title: _T("disk_info", "disk_disable_title"),
            width: 320,
            height: 314,
            cls: "sds-port-disabled-panel",
            renderTo: document.body,
            layout: "fit",
            padding: "0px 8px 8px 8px",
            bodyStyle: "border-radius:3px",
            items: this.dataView = new SYNO.ux.FleXcroll.DataView({
                itemSelector: "div.item",
                emptyText: "No Disabled Disk Ports.",
                itemId: "dataview",
                singleSelect: true,
                autoScroll: true,
                store: new Ext.data.JsonStore({
                    autoDestroy: true,
                    storeId: this.storeId,
                    root: "diskList",
                    fields: ["num_id", "port_type", "port_type_str"]
                }),
                listeners: {
                    click: {
                        fn: this.nodeClick,
                        scope: this,
                        buffer: 80
                    }
                },
                tpl: new Ext.XTemplate('<tpl for=".">', '<div class="item">', '<span class = "sds-eject-device-button"></span>', '<div class="sds-port-disabled-icon sm-list-icon sm-list-icon-disk" style="float: left;"></div><div class="title">{[this.localize(this.getDisplayName(values))]}</div>', "{[this.getDisplayContent(values)]}", "</div>", "</div>", "</tpl>", "</div>", {
                    compiled: true,
                    disableFormats: true,
                    localize: this.localizeMsg.createDelegate(this, [false], true),
                    localizeNoTags: this.encodedMsg.createDelegate(this, [true], true),
                    getDisplayName: this.getDisplayName.createDelegate(this),
                    getDisplayContent: this.getDisplayContent.createDelegate(this)
                })
            })
        }, a)]);
        Ext.StoreMgr.get(this.storeId).removeAll();
        this.pollTaskConfig = {
            interval: this.pollingInterval,
            api: "SYNO.Core.Polling.Data",
            method: "get",
            version: 1,
            params: {
                action: "load",
                load_disabled_port: true
            },
            scope: this,
            callback: this.loadData
        };
        this.initialPolling = true;
        this.pollTask = this.addWebAPITask(this.pollTaskConfig).start(true);
        this.mon(SYNO.SDS.StatusNotifier, "redirect", this.pollTask.stop, this.pollTask);
        this.mon(SYNO.SDS.StatusNotifier, "halt", this.pollTask.stop, this.pollTask)
    },
    getDisplayName: function(b) {
        var a = "";
        switch (b.port_type_str) {
            case "internal":
                a = _T("disk_info", "disk_disable_info_num_int").replace("{0}", b.num_id);
                break;
            case "eSATA":
                a = _T("disk_info", "disk_disable_info_num_esata").replace("{0}", b.num_id);
                break;
            default:
                return ""
        }
        return this.encodedMsg(a)
    },
    getDisplayContent: function(b) {
        var a = String.format('<a href="#" style="text-decoration:underline;" class="sds-port-disabled-link link-font">{0}</a>', _T("disk_info", "disk_en"));
        var c = b.port_type_str === "eSATA" ? String.format(_T("disk_info", "disk_en_info_esata"), a) : String.format(_T("disk_info", "disk_en_info"), a);
        return String.format('<div class="msg"> {0}</div>', c)
    },
    nodeClick: function(f, b, c, d) {
        var a = this.dataView.getRecord(c);
        if (this.blEnableClick) {
            this.enablePort(a);
            this.blEnableClick = false
        }
        a = null
    },
    enableClick: function() {
        this.blEnableClick = true
    },
    enablePort: function(b) {
        var a = this;
        if (!b) {
            return
        }
        a.hide();
        a.getMsgBox().confirm(_T("disk_info", "disk_disable_title"), _T("disk_info", "disk_en_warn"), function(c, d) {
            if (c == "yes") {
                this.doEnableAction(b)
            }
        }, this)
    },
    getMsgBox: function(b) {
        var a = this;
        if (!a.msgBox || a.msgBox.isDestroyed) {
            a.msgBox = new SYNO.SDS.MessageBoxV5({
                modal: true,
                draggable: false,
                renderTo: document.body
            })
        }
        return a.msgBox.getWrapper()
    },
    doEnableAction: function(a) {
        var b = {
            action: "apply",
            type: a.get("port_type"),
            port: a.get("num_id")
        };
        this.sendWebAPI({
            api: "SYNO.Core.Polling.Data",
            version: 1,
            method: "set",
            params: b,
            scope: this,
            callback: function(f, e, c, d) {
                if (!f) {
                    this.module.getMsgBox().alert(_T("disk_info", "disk_disable_title"), _T("common", "error_system"));
                    return
                }
            }
        })
    },
    localizeMsg: function(e, b) {
        var c = [];
        if (!Ext.isArray(e)) {
            e = [e]
        }
        for (var a = 0; a < e.length; a++) {
            c.push(SYNO.SDS.UIString.GetLocalizedString(e[a]))
        }
        var d = String.format.apply(String, c);
        if (b) {
            return Ext.util.Format.stripTags(d)
        } else {
            return d
        }
    },
    encodedMsg: function(b, a) {
        return Ext.util.Format.htmlEncode(this.localizeMsg(b, a))
    },
    onShow: function() {
        var b = this;
        SYNO.SDS.PollingTask.Panel.superclass.onShow.apply(this, arguments);
        var a = this.externalDeviceJson;
        this.loadJsonData(a);
        b.dataView.getEl().on("click", function(d, c) {
            b.enableClick()
        }, null, {
            delegate: "a.sds-port-disabled-link"
        })
    },
    loadData: function(d, c) {
        var b = this,
            a = {};
        if (!d) {
            return
        }
        a.data = c || {};
        b.externalDeviceJson = a;
        this.initialPolling = false;
        if (!Ext.isArray(a.data.diskList) || !a.data.diskList.length) {
            b.hideTray();
            return
        }
        b.loadJsonDataByPolling(a)
    },
    hideTray: function() {
        var a = this;
        Ext.StoreMgr.get(a.storeId).removeAll();
        a.module.setTaskButtonVisible(false);
        a.hide()
    },
    haveRecord: function(a) {
        var b, e = a.length,
            c, d;
        for (b = 0; b < e; b++) {
            d = a[b];
            c = d.port_type_str;
            if (!c) {
                continue
            }
            return true
        }
        return false
    },
    loadJsonDataByPolling: function(a) {
        var b = this;
        if (!b.haveRecord(a.data.diskList)) {
            b.hideTray()
        } else {
            b.module.setTaskButtonVisible(true)
        }
        b.loadJsonData(a)
    },
    loadJsonData: function(b) {
        var c = this;
        if (c.isVisible()) {
            var a = Ext.StoreMgr.get(c.storeId);
            a.loadData(b.data)
        }
    },
    beforeDestroy: function() {
        var a = this;
        SYNO.SDS.PollingTask.Panel.superclass.beforeDestroy.call(a);
        if (a.msgBox && !a.msgBox.isDestroyed) {
            a.msgBox.destroy();
            delete a.msgBox
        }
        delete a.externalDeviceJson
    }
});
