/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.define("SYNO.SDS.OTPWizard.WelcomeStep", {
    extend: "SYNO.SDS.Wizard.WelcomeStep",
    constructor: function(b) {
        var a = Ext.apply({
            headline: _T("personal_settings", "otp_wizard_welcome_title"),
            items: [{
                xtype: "syno_displayfield",
                htmlEncode: false,
                value: String.format(_T("personal_settings", "otp_wizard_welcome_desc"), '<span class="syno-ux-note">' + _T("common", "note") + "</span>", '<a href="http://www.synology.com/knowledgebase/DSM/tutorial/Management/OTP_packages_supportability" target="_blank">', "</a>")
            }, {
                xtype: "syno_displayfield",
                cls: "syno-otp-welcome-desc-icon",
                style: "text-align: center; margin-left: auto; "
            }],
            htmlEncode: false,
            disableNextInDemoMode: true
        }, b);
        this.callParent([a])
    },
    getNext: function() {
        this.owner.setStatusBusy({
            text: _T("common", "saving")
        });
        this.sendWebAPI({
            api: "SYNO.Core.OTP",
            method: "get_qrcode",
            version: 3,
            params: {
                enable_margin: false,
                account: this._S("user") + "@" + this._S("hostname")
            },
            callback: function(c, a, b) {
                this.owner.clearStatusBusy();
                if (!c) {
                    this.owner.displayError();
                    return
                }
                this.owner.mailStep.load();
                this.owner.secretKey = a.key;
                this.owner.QRcodeImg = a.img;
                this.owner.appAccount = a.appAccount;
                this.owner.qrcodeStep.load();
                if (-1 != this._S("user").search("\\\\")) {
                    this.owner.goNext("qrcode")
                } else {
                    this.owner.goNext(this.nextId)
                }
            },
            scope: this
        });
        return false
    }
});
Ext.define("SYNO.SDS.OTPWizard.MailStep", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(b) {
        this.ldap_server_addr = "";
        var a = Ext.apply({
            headline: _T("personal_settings", "otp_wizard_mail_title"),
            items: [{
                xtype: "syno_displayfield",
                htmlEncode: false,
                name: "OTP_mail_desc",
                value: _T("personal_settings", "otp_wizard_mail_desc")
            }, {
                xtype: "syno_textfield",
                fieldLabel: _T("personal_settings", "otp_wizard_rescue_mail"),
                name: "OTP_mail",
                maxlength: 512,
                vtype: "email",
                allowBlank: false
            }],
            keys: [{
                key: [10, 13],
                scope: this,
                handler: this.getNext
            }]
        }, b);
        SYNO.SDS.OTPWizard.MailStep.superclass.constructor.call(this, a)
    },
    load: function() {
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Core.NormalUser",
            method: "get",
            version: 1,
            scope: this,
            callback: function(c, b, a) {
                this.owner.clearStatusBusy();
                if (c) {
                    this.form.findField("OTP_mail").setValue(b.email);
                    this.form.findField("OTP_mail").originalValue = b.email;
                    this.form.findField("OTP_mail").clearInvalid();
                    if (_S("authType") === "ldap") {
                        this.userDN = b.userDN;
                        this.ldap_server_addr = b.ldapServerAddr
                    } else {
                        this.userDN = "";
                        this.ldap_server_addr = ""
                    }
                    this.doLayout()
                }
            }
        })
    },
    getNext: function() {
        if (!this.form.findField("OTP_mail").isValid()) {
            return false
        }
        if (!this.form.findField("OTP_mail").isDirty()) {
            return this.nextId
        }
        var a = this.form.findField("OTP_mail").getValue();
        this.owner.setStatusBusy({
            text: _T("common", "saving")
        });
        this.sendWebAPI({
            api: "SYNO.Core.OTP",
            method: "save_mail",
            version: 2,
            params: {
                bind_dn: this.userDN,
                bind_pwd: this.owner.password,
                server_addr: this.ldap_server_addr,
                mail: a
            },
            encryption: ["bind_dn", "bind_pwd", "server_addr", "mail"],
            callback: function(d, b, c) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.owner.displayError(b.code);
                    if (b.code !== 4207) {
                        return false
                    }
                }
                if (this.owner.accountMailField) {
                    this.owner.accountMailField.setValue(a)
                }
                this.owner.goNext(this.nextId)
            },
            scope: this
        });
        return false
    }
});
Ext.define("SYNO.SDS.OTPWizard.QRcodeStep", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(b) {
        this.manualId = Ext.id();
        var a = Ext.apply({
            headline: _T("personal_settings", "otp_wizard_install_app"),
            items: [{
                xtype: "syno_displayfield",
                value: _T("personal_settings", "otp_wizard_install_app_desc")
            }, {
                xtype: "syno_displayfield",
                value: _T("personal_settings", "otp_wizard_install_app_path")
            }, {
                xtype: "syno_displayfield",
                cls: "syno-otp-authenticator-div",
                html: '<div class="syno-otp-authenticator"><div class="syno-otp-authenticator-icon syno-otp-authenticator-download-icon-ios"></div><div class="syno-otp-authenticator-text"><span><a href="https://apps.apple.com/app/id1513105891">iOS</a></span></div></div><div class="syno-otp-authenticator"><div class="syno-otp-authenticator-icon syno-otp-authenticator-download-icon-android"></div><div class="syno-otp-authenticator-text"><span><a href="http://play.google.com/store/apps/details?id=com.synology.securesignin">Android</a></span></div></div>',
                htmlEncode: false
            }]
        }, b);
        SYNO.SDS.OTPWizard.QRcodeStep.superclass.constructor.call(this, a)
    },
    load: function() {
        var a = Ext.get("qrcode_img");
        a.dom.src = "data:image/png;base64," + this.owner.QRcodeImg
    },
    getNext: function() {
        this.owner.authStep.load();
        return this.nextId
    },
    setHeight: function() {
        return this.callParent(arguments)
    }
});
Ext.define("SYNO.SDS.OTPWizard.AuthStep", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(b) {
        this.manualId = Ext.id();
        var c = "&nbsp;&nbsp;&nbsp;&nbsp;";
        var a = Ext.apply({
            headline: _T("personal_settings", "otp_wizard_setup_authenticator"),
            items: [{
                xtype: "syno_displayfield",
                htmlEncode: false,
                value: _T("personal_settings", "otp_wizard_scan_qrcode") + "<br>" + c + _T("personal_settings", "otp_wizard_scan_qrcode_with_app")
            }, {
                xtype: "syno_displayfield",
                cls: "syno-otp-qrcode-display",
                html: '<img id = "qrcode_img" src="" width="120" height="120" />'
            }, {
                xtype: "syno_displayfield",
                cls: "syno-otp-link-text",
                htmlEncode: false,
                value: '<a class="pathlink" tabindex="0", id=' + this.manualId + ">" + _T("personal_settings", "otp_wizard_scan_qrcode_failed") + "</a>",
                listeners: {
                    render: function(e) {
                        var d = e.el.first("a.pathlink");
                        if (d) {
                            this.mon(d, "click", this.launchEditDialog, this);
                            d.addKeyListener(Ext.EventObject.SPACE, this.launchEditDialog, this);
                            d.addKeyListener(Ext.EventObject.ENTER, this.launchEditDialog, this)
                        }
                    },
                    scope: this,
                    single: true,
                    buffer: 80
                }
            }, {
                xtype: "syno_displayfield",
                htmlEncode: false,
                value: _T("personal_settings", "otp_wizard_confirm_code_title") + "<br>" + c + _T("personal_settings", "otp_wizard_confirm_code_desc")
            }, {
                xtype: "syno_textfield",
                itemCls: "syno-otp-authcode-text",
                name: "OTP_auth",
                labelWidth: 200,
                width: 200,
                fieldLabel: _T("personal_settings", "otp_verification_code"),
                maxLength: 6,
                regex: new RegExp("[0-9]{6}"),
                regexText: _T("personal_settings", "otp_err_auth_code"),
                allowBlank: false
            }],
            keys: [{
                key: [10, 13],
                scope: this,
                handler: this.getNext
            }]
        }, b);
        SYNO.SDS.OTPWizard.AuthStep.superclass.constructor.call(this, a)
    },
    load: function() {
        var a = Ext.get("qrcode_img");
        a.dom.src = "data:image/png;base64," + this.owner.QRcodeImg;
        this.getForm().findField("OTP_auth").reset()
    },
    launchEditDialog: function() {
        var a = new SYNO.SDS.OTPWizard.QRcodeStep.EditDialog({
            owner: this.owner
        });
        a.show()
    },
    getNext: function() {
        if (!this.getForm().findField("OTP_auth").isValid()) {
            return false
        }
        var a = this.form.findField("OTP_auth").getValue();
        var b = {
            code: a
        };
        this.owner.setStatusBusy({
            text: _T("common", "saving")
        });
        this.sendWebAPI({
            api: "SYNO.Core.OTP",
            method: "auth_tmp_code",
            version: 3,
            params: b,
            callback: function(e, c, d) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.displayError(c.code);
                    return false
                }
                if (this.owner.module) {
                    this.owner.module.OTPenabled = true
                }
                this.owner.goNext(this.nextId);
                this.owner.getButton("back").hide();
                this.owner.getButton("next").setText(_T("common", "close"))
            },
            scope: this
        });
        return false
    }
});
Ext.define("SYNO.SDS.OTPWizard.QRcodeStep.EditDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        Ext.apply(this, a || {});
        var b = {
            owner: this.owner,
            width: 580,
            height: 246,
            resizable: false,
            shadow: true,
            collapsible: false,
            title: _T("personal_settings", "otp_wizard_title"),
            layout: "fit",
            trackResetOnLoad: true,
            forceSelection: true,
            waitMsgTarget: true,
            border: false,
            items: this.panel = this.initPanel(),
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: this.close
            }, {
                text: _T("common", "apply"),
                scope: this,
                btnStyle: "blue",
                handler: this.onApply
            }]
        };
        SYNO.SDS.OTPWizard.QRcodeStep.EditDialog.superclass.constructor.call(this, b)
    },
    initPanel: function() {
        var b = {
            itemId: "otp_edit_panel",
            border: false,
            items: [{
                xtype: "syno_displayfield",
                value: _T("personal_settings", "otp_edit_desc")
            }, {
                xtype: "syno_textfield",
                fieldLabel: _T("personal_settings", "otp_account_name"),
                name: "account_name",
                labelWidth: 150,
                value: this.owner.appAccount,
                allowBlank: false
            }, {
                xtype: "syno_displayfield",
                labelWidth: 150,
                hideLabel: false,
                fieldLabel: _T("personal_settings", "otp_secret_key"),
                name: "edit_secret_key",
                value: this.owner.secretKey
            }]
        };
        var a = new Ext.form.FormPanel(b);
        return a
    },
    getForm: function() {
        return this.panel.form
    },
    onApply: function() {
        if (!this.getForm().findField("account_name").isValid()) {
            return false
        }
        var a = this.getForm().findField("account_name").getValue();
        a = a.replace(/\\/g, "/");
        var b = {
            secretKey: this.getForm().findField("edit_secret_key").getValue(),
            enable_margin: false,
            account: a
        };
        this.sendWebAPI({
            api: "SYNO.Core.OTP",
            method: "edit_secret_key",
            version: 2,
            params: b,
            callback: function(e, c, d) {
                if (!e) {
                    this.owner.displayError();
                    return false
                }
                this.owner.QRcodeImg = c.img;
                this.owner.secretKey = c.key;
                this.owner.appAccount = c.appAccount;
                this.owner.qrcodeStep.load();
                this.close()
            },
            scope: this
        })
    }
});
Ext.define("SYNO.SDS.OTPWizard.FinishStep", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(b) {
        var a = Ext.apply({
            headline: _T("personal_settings", "otp_wizard_finish_title"),
            items: [{
                xtype: "syno_displayfield",
                value: _T("personal_settings", "otp_wizard_finish_desc")
            }, {
                xtype: "syno_displayfield",
                htmlEncode: false,
                value: '<span class="syno-ux-note">' + _T("common", "note") + "</span>" + _T("common", "colon") + " " + _T("personal_settings", "otp_wizard_finish_tips")
            }]
        }, b);
        this.callParent([a])
    },
    getNext: function() {
        return this.nextId
    }
});

/**
 * @class SYNO.SDS.OTPWizard.Instance
 * @extends SYNO.SDS.AppInstance
 * OTPWizard application instance class
 *
 */
Ext.define("SYNO.SDS.OTPWizard.Instance", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.OTPWizard.MainWindow"
});
Ext.define("SYNO.SDS.OTPWizard.MainWindow", {
    extend: "SYNO.SDS.Wizard.AppWindow",
    next_step: null,
    WIZRAD_HEIGHT: 540,
    constructor: function(b) {
        this.welcomeStep = new SYNO.SDS.OTPWizard.WelcomeStep({
            itemId: "welcome",
            nextId: "mail"
        });
        this.mailStep = new SYNO.SDS.OTPWizard.MailStep({
            itemId: "mail",
            nextId: "qrcode"
        });
        this.qrcodeStep = new SYNO.SDS.OTPWizard.QRcodeStep({
            itemId: "qrcode",
            nextId: "authenticate"
        });
        this.authStep = new SYNO.SDS.OTPWizard.AuthStep({
            itemId: "authenticate",
            nextId: "finish"
        });
        this.finishStep = new SYNO.SDS.OTPWizard.FinishStep({
            itemId: "finish",
            nextId: null
        });
        var a = [this.welcomeStep, this.mailStep, this.qrcodeStep, this.authStep, this.finishStep];
        this.callParent([Ext.apply({
            title: _T("personal_settings", "otp_wizard_title"),
            showHelp: false,
            cls: "syno-otp-wizard-header",
            width: 820,
            height: this.WIZRAD_HEIGHT,
            steps: a,
            toggleMinimizable: false
        }, b)])
    },
    onRequest: function(a) {
        Ext.apply(this, a);
        this.callParent(arguments)
    },
    onOpen: function(a) {
        Ext.apply(this, a);
        this.setActiveStep("welcome");
        this.callParent(arguments);
        this.userPwd = a.password
    },
    displayError: function(a) {
        var b = _T("error", "error_error_system");
        if (a === 4207) {
            b = _T("personal_settings", "failed_to_set_ldap_otp_mail")
        } else {
            if (a === 4208) {
                b = _T("personal_settings", "otp_auth_failed")
            } else {
                if (a === 4209) {
                    b = _T("personal_settings", "otp_save_config_failed")
                } else {
                    if (a === 4230) {
                        b = _T("personal_settings", "otp_auth_failed") + _T("network", "domain_options_sync_time_enable")
                    }
                }
            }
        }
        this.getMsgBox().alert(this.title, b)
    },
    setNextStep: function(a, b) {
        if (0 > this.stepStack.indexOf(a)) {
            this.stepStack.push(a)
        }
        if (Ext.isString(b)) {
            this.stepStack.push(b)
        }
    },
    onClose: function() {
        if (!this.module) {
            return
        }
        if (this.triggerCheckbox) {
            this.triggerCheckbox.setValue(this.module.OTPenabled)
        }
        if (this.module.otp_settings_btn) {
            this.module.otp_settings_btn.setDisabled(!this.module.OTPenabled)
        }
    }
});
