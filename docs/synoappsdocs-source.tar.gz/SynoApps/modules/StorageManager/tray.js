/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.namespace("SYNO.SDS.StorageManager.CacheAdvisor");
 /**
 * @class SYNO.SDS.StorageManager.CacheAdvisor.Application
 * @extends SYNO.SDS.AppInstance
 * StorageManager CacheAdvisor application instance class
 *
 */  
SYNO.SDS.StorageManager.CacheAdvisor.Application = Ext.extend(SYNO.SDS.AppInstance, {
    initInstance: function(a) {
        this.trayItem = this.trayItem || [];
        if (("yes" === _D("support_ssd_cache", "no")) && !this.trayItem[0]) {
            this.trayItem[0] = new SYNO.SDS.StorageManager.CacheAdvisor.Tray({
                appInstance: this
            });
            this.addInstance(this.trayItem[0]);
            this.trayItem[0].open(a)
        }
    }
});
Ext.define("SYNO.SDS.StorageManager.CacheAdvisor.Tray", {
    extend: "SYNO.SDS.Tray.ArrowTray",
    initPanel: function() {
        var b = this;
        var a = new SYNO.SDS.StorageManager.CacheAdvisor.Panel({
            module: b
        });
        return a
    }
});
Ext.define("SYNO.SDS.StorageManager.CacheAdvisor.Panel", {
    extend: "SYNO.SDS.Tray.Panel",
    constructor: function(a) {
        var b = Ext.apply({
            module: a.module,
            hidden: true,
            title: _T("volume", "advisor_tray_title"),
            width: 360,
            cls: "sds-tray-cache-advisor-panel",
            bodyCssClass: "sds-tray-cache-advisor-panel-body",
            renderTo: document.body,
            items: this.createObjs()
        }, a);
        this.callParent([b]);
        this.getCmpsAsMembers();
        this.initContext();
        this.polling_interval = 6;
        this.startPolling()
    },
    createObjs: function() {
        var a = [{
            xtype: "container",
            cls: "header-panel",
            width: "auto",
            items: [{
                xtype: "container",
                cls: "sds-cache-advisor-analyzing icon-volume",
                items: [{
                    xtype: "box",
                    cls: "analyzing-icon"
                }]
            }, {
                xtype: "container",
                cls: "header-context",
                width: "auto",
                items: [{
                    xtype: "box",
                    cls: "title",
                    html: _T("volume", "advisor_state_analyze")
                }, {
                    xtype: "box",
                    html: _T("volume", "advisor_history_analysis_result"),
                    id: this.field_recommended_size_id = Ext.id()
                }, {
                    xtype: "container",
                    cls: "size-row",
                    id: this.field_size_id = Ext.id(),
                    items: [{
                        xtype: "box",
                        cls: "size-with-pin",
                        id: this.field_size_with_pin_id = Ext.id()
                    }]
                }, {
                    xtype: "box",
                    cls: "link",
                    id: this.field_link_id = Ext.id()
                }]
            }]
        }, {
            xtype: "container",
            cls: "context-panel",
            width: "auto",
            items: [{
                xtype: "box",
                id: this.field_target_id = Ext.id()
            }, {
                xtype: "box",
                id: this.field_hot_data_size_id = Ext.id()
            }, {
                xtype: "box",
                id: this.field_io_size_byte_id = Ext.id()
            }, {
                xtype: "box",
                id: this.field_time_spent_id = Ext.id()
            }]
        }];
        return a
    },
    getCmpsAsMembers: function() {
        var b = ["field_size", "field_recommended_size", "field_size_with_pin", "field_link", "field_target", "field_hot_data_size", "field_io_size_byte", "field_time_spent"];
        for (var a = 0; a < b.length; ++a) {
            this[b[a]] = Ext.getCmp(this[b[a] + "_id"])
        }
    },
    initContext: function() {
        var b = this;
        var a;
        var c;
        a = Ext.id();
        c = '<a class="link-font" id="' + a + '" href="#">' + _T("volume", "advisor_tray_link") + " </a>";
        this.field_link.el.update(c);
        b.mon(Ext.fly(a), "click", function() {
            SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance", {
                fn: "SYNO.SDS.StorageManager.Pool.Main",
                dlg: "SYNO.SDS.StorageManager.Vue.CacheAdvisorWindow",
                windowParam: {
                    openVueWin: true
                }
            });
            this.module.taskButton.toggle(false);
            b.hide()
        }, b, {
            single: false
        });
        b.learnMoreId = Ext.id();
        b.tipIcon = SYNO.ux.AddWhiteTipWithMsg(this.field_size_with_pin, "");
        b.tipIcon.el.on("mouseenter", function() {
            setTimeout(function() {
                var d = setInterval(function() {
                    var e;
                    if (!!(e = Ext.fly(b.learnMoreId))) {
                        b.mon(e, "click", function() {
                            SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                                topic: "SYNO.SDS.StorageManager.Instance:StorageManager/ssd_cache_advisor.html"
                            })
                        }, b);
                        clearInterval(d)
                    }
                }, 100)
            }, 500)
        })
    },
    startPolling: function() {
        this.polling_id = this.pollReg({
            interval: this.polling_interval,
            immediate: true,
            scope: this,
            webapi: {
                api: "SYNO.Storage.CGI.Flashcache",
                method: "advisor_poll",
                version: 1
            },
            status_callback: this.polling_callback
        })
    },
    polling_callback: function(g, c, d, a) {
        var e;
        var b = SYNO.SDS.Utils.StorageUtils.UiRenderHelper;
        var f = false;
        var h = false;
        var i = "";
        if (g) {
            this.module.setTaskButtonVisible(c.is_analyzing);
            if (c.is_analyzing) {
                e = SYNO.SDS.StorageUtils.SpaceIDParser(c.volume);
                this.field_target.el.update(_T("volume", "advisor_info_target") + _T("common", "colon") + "&nbsp" + (e ? e.str : "-"));
                this.field_size_with_pin.el.update(b.SizeRender(c.recommended_size_pin_meta));
                this.field_hot_data_size.el.update(_T("volume", "advisor_info_hot_data") + _T("common", "colon") + "&nbsp" + b.SizeRender(c.hot_data_size));
                this.field_io_size_byte.el.update(String.format(_T("volume", "advisor_info_analyzed_io"), b.SizeRender(c.io_speed_byte)));
                this.field_time_spent.el.update(_T("volume", "advisor_info_time_spent") + _T("common", "colon") + "&nbsp" + this.timeDeltaFormat(c.execution_time));
                f = c.meet_criteria;
                this.field_recommended_size.setVisible(f);
                this.field_size.setVisible(f);
                this.field_hot_data_size.setVisible(!f);
                if (f) {
                    h = c.recommended_size !== c.recommended_size_pin_meta;
                    i = _T("volume", "advisor_pin_metadata_desc");
                    i += h ? String.format(_T("volume", "advisor_no_pin_metadata_desc"), b.SizeRender(c.recommended_size)) : "";
                    i += ' <a class="link-font" href="#" id="' + this.learnMoreId + '">' + _T("volume", "advisor_learn_more") + "</a>";
                    this.tipIcon.el.set({
                        "ext:wtip": i
                    })
                }
            } else {
                this.module.taskButton.toggle(false);
                this.hide()
            }
        } else {
            this.module.setTaskButtonVisible(false)
        }
    },
    timeDeltaFormat: function(f) {
        var d = Math.floor(f % 60);
        var c = Math.floor((f % (60 * 60)) / 60);
        var a = Math.floor((f % (24 * 60 * 60)) / (60 * 60));
        var b = Math.floor(f / (24 * 60 * 60));
        var e = [];
        if (0 < b) {
            e.push(b + _T("volume", "advisor_info_time_spent_day"))
        }
        if (0 < a) {
            e.push(a + _T("volume", "advisor_info_time_spent_hour"))
        }
        if (0 < c) {
            e.push(c + _T("volume", "advisor_info_time_spent_min"))
        }
        if (0 === e.length) {
            return d + _T("volume", "advisor_info_time_spent_sec")
        }
        return e.join(" ")
    }
});
