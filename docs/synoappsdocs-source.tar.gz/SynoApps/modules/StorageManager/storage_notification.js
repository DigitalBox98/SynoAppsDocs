/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.namespace("SYNO.SDS.StorageManager.Notify");
/**
 * @class SYNO.SDS.StorageManager.Notify.Instance
 * @extends SYNO.SDS.AppInstance
 * StorageManager Notify application instance class
 *
 */
Ext.define("SYNO.SDS.StorageManager.Notify.Instance", {
    extend: "SYNO.SDS.AppInstance",
    shouldNotifyMsg: function(a, b) {
        return false
    },
    onOpen: function(a) {
        SYNO.API.Request({
            webapi: {
                api: "SYNO.Storage.CGI.Storage",
                method: "login_check",
                version: 1
            },
            callback: this.updaterHandler,
            scope: this
        })
    },
    updaterHandler: function(e, a, d, b) {
        if (!e) {
            return
        }

        function c(g) {
            var h = "";
            h = _T("volume", "volume_warn_ebox_missing");
            h = String.format(h, g);
            var f = new SYNO.SDS.MessageBoxV5({
                modal: true,
                draggable: false,
                renderTo: document.body,
                isAlwaysOnTop: function() {
                    return true
                }
            });
            f.alert("", h)
        }
        if (a.isDisplay && a.disk_contains_crashed_space) {
            c(a.disk_contains_crashed_space)
        }
        this.destroy()
    }
});
Ext.define("SYNO.SDS.StorageManager.Notify.FirmwareUpgrade.AutoLaunchSummary.Instance", {
    extend: "SYNO.SDS.AppInstance",
    onOpen: function() {
        this.initInstance()
    },
    initInstance: function() {
        var b = this;
        var a = [{
            api: "SYNO.Core.Storage.Disk.FWUpgrade",
            method: "poll",
            version: 1
        }, {
            api: "SYNO.Core.Storage.Disk.FWUpgrade",
            method: "get_summary",
            params: {
                source: "launch_summary"
            },
            version: 1
        }];
        var c = function(h, g, f, d) {
            if (!h) {
                return
            }
            if (g.result.some(function(j) {
                    return !j.success
                })) {
                return
            }
            var i = g.result[0];
            if ("upgrading" === i.data.status) {
                return
            }
            var e = g.result[1];
            if (!e.data.success || 0 === e.data.drives.length) {
                return
            }
            SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance", {
                fn: "SYNO.SDS.StorageManager.Disk.Main",
                dlg: "SYNO.SDS.StorageManager.Wizard.FirmwareUpgrade",
                modalParam: {
                    param: {
                        summaryList: [e.data],
                        ui_state: "single_summary",
                        cancelAutoLaunch: true
                    }
                }
            })
        };
        if (_S("ha_running") && ("yes" !== _D("support_xa"))) {
            a = [{
                api: "SYNO.SHA.Firmware.Upgrade",
                method: "get",
                version: 1
            }, {
                api: "SYNO.SHA.Panel.Overview",
                method: "load",
                version: 1
            }];
            c = function(i, h, g, f) {
                var d = h.result.every(function(k) {
                    return k.success
                });
                if (!d) {
                    return
                }
                var j = h.result[0].data;
                var e = h.result[1].data;
                if (j.is_show_summary || !j.summary_data) {
                    return
                }
                if (j[e.lnode.hostname] || j[e.rnode.hostname]) {
                    if (j.summary_data) {
                        SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance", {
                            fn: "SYNO.SDS.StorageManager.Disk.Main",
                            dlg: "SYNO.SDS.StorageManager.Wizard.FirmwareUpgrade",
                            modalParam: {
                                param: {
                                    summaryList: j.summary_data.ui_json.summaryList,
                                    ui_state: "sha_summary",
                                    cancelAutoLaunch: true
                                }
                            }
                        });
                        return
                    }
                }
            }
        }
        SYNO.API.Request({
            api: "SYNO.Entry.Request",
            version: 1,
            method: "request",
            compound: {
                mode: "parallel",
                params: a
            },
            callback: c,
            scope: b
        })
    }
});
Ext.define("SYNO.SDS.StorageManager.Notify.FirmwareUpgrade.NotificationSummary.Instance", {
    extend: "SYNO.SDS.AppInstance",
    onOpen: function(a) {
        this.initInstance(a)
    },
    initInstance: function(b) {
        var a = this;
        a.appItem = new SYNO.SDS.StorageManager.Wizard.FirmwareUpgrade({
            appInstance: a
        });
        a.addInstance(a.appItem);
        a.appItem.open(b);
        a.appItem.maskEl.hide()
    }
});
SYNO.SDS.StorageManager.Notify.FirmwareUpgrade.Renderer = function(a, b) {
    return b.replace("%SUMMARY_DATA%", a)
};
