/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function asyncGeneratorStep(e, t, i, s, a, n, o) {
    try {
        var r = e[n](o),
            d = r.value
    } catch (e) {
        return void i(e)
    }
    r.done ? t(d) : Promise.resolve(d).then(s, a)
}

function _asyncToGenerator(e) {
    return function() {
        var t = this,
            i = arguments;
        return new Promise(function(s, a) {
            var n = e.apply(t, i);

            function o(e) {
                asyncGeneratorStep(n, s, a, o, r, "next", e)
            }

            function r(e) {
                asyncGeneratorStep(n, s, a, o, r, "throw", e)
            }
            o(void 0)
        })
    }
}

function _typeof(e) {
    return (_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
        return typeof e
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    })(e)
}

function _toConsumableArray(e) {
    return _arrayWithoutHoles(e) || _iterableToArray(e) || _nonIterableSpread()
}

function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function _iterableToArray(e) {
    if (Symbol.iterator in Object(e) || "[object Arguments]" === Object.prototype.toString.call(e)) return Array.from(e)
}

function _arrayWithoutHoles(e) {
    if (Array.isArray(e)) {
        for (var t = 0, i = new Array(e.length); t < e.length; t++) i[t] = e[t];
        return i
    }
}
Ext.define("SYNO.SDS.StorageManager.Wizard.CacheSetting", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t, i = this,
            s = [],
            a = function(e, t) {
                return "<div>" + e + '</div><div class="sm-cache-config-opt-desc">' + t + "</div>"
            };
        if (i.appWin = e.appWin, i.owner = e.owner, i.skipSeqIO = e.skipSeqIO, i.maxDegradeFlush = e.maxDegradeFlush, i.metadataCache = e.metadataCache, i.ssdPath = e.ssdPath, i.mountSpaceId = e.mountSpaceId, i.configureOpts = e.configureOpts, i.metadataCacheAndAdvisorShowMsg = e.metadataCacheAndAdvisorShowMsg, i.configureOpts.includes("skipSeqIo") && s.push({
                xtype: "syno_checkbox",
                name: "skip_seq_io",
                htmlEncode: !1,
                boxLabel: a(_T("volume", "cache_skip_seq_io"), _T("volume", "cache_skip_seq_io_desc")),
                value: 0
            }), i.configureOpts.includes("maxDegradeFlush") && s.push({
                xtype: "syno_checkbox",
                name: "max_degrade_flush",
                htmlEncode: !1,
                boxLabel: a(_T("volume", "cache_max_degrade_flush"), _T("volume", "cache_max_degrade_flush_desc")),
                value: 0
            }), i.configureOpts.includes("metadataCache")) {
            var n = SYNO.SDS.StorageUtils.GetSizeUnit(e.volume.metadata_cache_hard_lower_bound_byte);
            s.push({
                xtype: "syno_checkbox",
                name: "metadata_cache",
                htmlEncode: !1,
                disabled: !e.metadataCache && e.totalSize < e.volume.metadata_cache_hard_lower_bound_byte,
                boxLabel: a(_T("volume", "metadata_cache_enable") + " " + String.format(_T("volume", "cache_metadata_required"), n.size + n.unit), _T("volume", "metadata_cache_enable_desc")),
                value: 0
            })
        }
        t = {
            title: _T("common", "configure"),
            width: 700,
            minWidth: 700,
            height: 480,
            padding: "16px 20px 24px 20px",
            layout: "fit",
            items: [{
                xtype: "syno_formpanel",
                itemId: "main",
                border: !1,
                autoHeight: !0,
                trackResetOnLoad: !0,
                items: s
            }],
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "alt_cancel"),
                scope: this,
                handler: this.onCancel
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                text: _T("common", "save"),
                scope: this,
                handler: this.onSave
            }]
        }, i.callParent([Ext.apply(t, e)])
    },
    getForm: function() {
        return this.getComponent("main").getForm()
    },
    onOpen: function() {
        var e = this;
        e.callParent(arguments), e.getForm().setValues({
            skip_seq_io: e.skipSeqIO
        }), e.getForm().setValues({
            max_degrade_flush: e.maxDegradeFlush
        }), e.getForm().setValues({
            metadata_cache: e.metadataCache
        })
    },
    __onSave: function() {
        var e, t = !(arguments.length > 0 && void 0 !== arguments[0]) || arguments[0],
            i = this,
            s = i.skipSeqIO,
            a = i.maxDegradeFlush,
            n = i.metadataCache;
        this.getForm().isDirty() ? this.getForm().isValid() && ((e = i.getForm().findField("skip_seq_io")) && (s = Boolean(e.getValue())), (e = i.getForm().findField("max_degrade_flush")) && (a = Boolean(e.getValue())), (e = i.getForm().findField("metadata_cache")) && (n = Boolean(e.getValue())), this.setStatusBusy(), SYNO.API.Request({
            api: "SYNO.Storage.CGI.Flashcache",
            method: "configure",
            version: 1,
            params: {
                ssdPath: i.ssdPath,
                mountSpaceId: i.mountSpaceId,
                skipSeqIO: s,
                maxDegradeFlush: a,
                metadataCache: n,
                validate: t
            },
            callback: function(e, s, a, n) {
                this.clearStatusBusy(), e ? t && s.failure_reasons.length > 0 ? i.metadataCacheAndAdvisorShowMsg(i, s, "setting").then(function(e) {
                    e && i.__onSave(!1)
                }) : (this.isDataChanged = !0, this.close()) : SYNO.SDS.StorageUtils.ReportWebapiFailure(this, s)
            },
            scope: this
        })) : this.close()
    },
    onSave: function() {
        this.__onSave()
    },
    onCancel: function() {
        this.getForm().isDirty() ? this.getMsgBox().confirm(this.title, _T("common", "confirm_lostchange"), function(e) {
            "yes" === e && this.close()
        }, this) : this.close()
    }
}), Ext.namespace("SYNO.SDS.TaskScheduler.SMART"), Ext.namespace("SYNO.SDS.StorageManager.Disk"), SYNO.SDS.StorageManager.Disk.UTILIZATION_THRESHOLD = 5, SYNO.SDS.StorageManager.Disk.COMPARE_WARN_THRESHOLD = 5, SYNO.SDS.StorageManager.Disk.DISK_PERF_NUM_THRESHOLD = 3, SYNO.SDS.StorageManager.Disk.ERR_DISK_IN_USE = 403, SYNO.SDS.StorageManager.Disk.ERR_PERFORMANCE_TEST = 404, SYNO.SDS.StorageManager.Disk.ERR_TESTING = 406, SYNO.SDS.StorageManager.Disk.ERR_PERF_TESTING = 407, SYNO.SDS.StorageManager.Disk.ERR_SECURITY_ERASING = 408, SYNO.SDS.StorageManager.Disk.ERR_FW_UPGRADING = 409, SYNO.SDS.StorageManager.Disk.HISTORY_DAY_INTERVAL = 1, SYNO.SDS.StorageManager.Disk.HISTORY_MONTH_INTERVAL = 31, SYNO.SDS.StorageManager.Disk.HISTORY_SEASON_INTERVAL = 92, SYNO.SDS.StorageManager.Disk.HISTORY_DAY_SKIP = 0, SYNO.SDS.StorageManager.Disk.HISTORY_MONTH_SKIP = 0, SYNO.SDS.StorageManager.Disk.HISTORY_YEAR_SKIP = 0, SYNO.SDS.StorageManager.Disk.HISTORY_SEASON_SKIP = 0, SYNO.SDS.TaskScheduler.SMART.LastTriggerTimeGet = function(e) {
    var t = null;
    return e ? (e.forEach(function(e) {
        var i;
        e.next_trigger_time && (i = Date.parseDate(e.next_trigger_time, "Y-m-d H:i")) && (!t || t.getTime() > i.getTime()) && (t = i)
    }), null === t ? null : SYNO.SDS.DateTimeFormatter(t)) : null
}, Ext.define("SYNO.SDS.StorageManager.Wizard.SmartTest", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.panel = new SYNO.SDS.StorageManager.SmartTestView(Ext.apply({
            appWin: this,
            parentWin: this,
            style: "padding: 16px 20px 0px;"
        }, e));
        var t = Ext.apply({
            title: _T("smart", "smart_toolbar_smart_test"),
            width: 650,
            height: 475,
            minHeight: 380,
            minWidth: 560,
            layout: "fit",
            dsmStyle: "v5",
            items: [{
                xtype: "syno_panel",
                autoFlexcroll: !0,
                items: this.panel
            }],
            buttons: [{
                text: _T("common", "alt_close"),
                handler: this.close,
                scope: this
            }]
        }, e);
        this.callParent([t])
    },
    onActivate: function() {
        this.panel.onActivate()
    }
}), Ext.define("SYNO.SDS.StorageManager.SmartTestView", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t, i = this;
        if (i.is_target_ha_passive = e.is_target_ha_passive, i.owner = e.owner, i.appWin = e.appWin, i.device = e.device, i.parent = e.parent, i.parentWin = e.parentWin, i.isHaPanel = e.isHaPanel, i.needRefresh = !1, i.needSchedule = !0 !== e.isHaPanel && e.needSchedule, i.adv_support = !1, !1 === i.isHaPanel && e.disks)
            for (var s = 0; s < e.disks.length; s++)
                if ("not_support" !== e.disks[s].adv_status) {
                    i.adv_support = !0;
                    break
                } t = Ext.apply({
            title: !0 === e.noTitle ? null : _T("smart", "smart_toolbar_smart_test"),
            items: [i.configForm({
                itemId: "form",
                noTitle: e.noTitle
            })],
            listeners: {
                scope: i,
                beforedestroy: i.pollingTaskStop
            }
        }, e), i.TestLogPollingConf = i.getPollingConf(i.device), i.callParent([t]), i.mon(i, "afterlayout", i.onAfterlayout, i, {
            single: !0
        })
    },
    onActivate: function(e) {
        this.onRenderScheduleStatus(), this.pollingTaskStart()
    },
    configForm: function(e) {
        var t = this;
        return Ext.apply({
            xtype: "syno_formpanel",
            trackResetOnLoad: !0,
            autoFlexcroll: !1,
            padding: 0,
            border: !1,
            items: [{
                xtype: "syno_displayfield",
                value: _T("disk_info", "disk_smart_test_desc")
            }, {
                itemId: "quick_radio",
                xtype: "syno_radio",
                boxLabel: _T("smart", "smart_quick_test"),
                name: "testStyle",
                inputValue: "quick",
                checked: !0
            }, {
                xtype: "syno_displayfield",
                value: _T("disk_info", "disk_smart_quick_desc"),
                itemId: "quick_desc",
                indent: 1
            }, {
                itemId: "extend_radio",
                xtype: "syno_radio",
                boxLabel: _T("smart", "smart_extend_test"),
                name: "testStyle",
                inputValue: "extend"
            }, {
                xtype: "syno_displayfield",
                value: _T("disk_info", "disk_smart_extend_desc"),
                itemId: "extend_desc",
                indent: 1
            }, {
                xtype: "syno_displayfield",
                name: "testingStatus",
                hidden: !0,
                htmlEncode: !1
            }, {
                xtype: "syno_button",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                itemId: "apply",
                id: this.testBtnId = Ext.id(),
                text: _T("smart", "smart_test_button_start"),
                handler: this.onApply,
                scope: this
            }, {
                xtype: "syno_displayfield",
                cls: "sm-disk-smart-secondary-title",
                value: _T("smart", "smart_test_result")
            }, {
                xtype: "syno_displayfield",
                name: "quickTestLog",
                htmlEncode: !1,
                fieldLabel: _T("smart", "smart_quick_test_log")
            }, {
                xtype: "syno_displayfield",
                name: "extendTestLog",
                htmlEncode: !1,
                fieldLabel: _T("smart", "smart_extend_test_log")
            }, {
                xtype: "syno_displayfield",
                cls: "sm-disk-smart-secondary-title",
                value: _T("common", "schedule"),
                hidden: !t.needSchedule
            }, {
                xtype: "syno_displayfield",
                name: "scheduleTimeField",
                hidden: !t.needSchedule,
                itemId: "scheduleStatus",
                htmlEncode: !1,
                fieldLabel: _T("schedule", "next_trigger_time")
            }, {
                xtype: "syno_button",
                itemId: "scheduleBtn",
                text: _T("disk_info", "disk_schedule_smart_test_btn"),
                hidden: !0,
                style: {
                    marginBottom: "4px"
                },
                handler: function() {
                    t.onHandleSchedule()
                },
                scope: t
            }]
        }, e)
    },
    getPollingConf: function(e) {
        var t = this;
        if (!e) throw Error("param error: device is not set");
        return {
            interval: 5,
            immediate: !0,
            webapi: SYNO.SDS.StorageUtils.ReplaceWebapiSHA(t.is_target_ha_passive, {
                api: "SYNO.Core.Storage.Disk",
                version: 1,
                method: "get_smart_test_log",
                params: {
                    device: t.device
                }
            }),
            status_callback: function(e, i, s, a) {
                if (t.cleanMask && (t.appWin.clearStatusBusy(), t.cleanMask = !1), !e) return t.appWin.getMsgBox().alert("", _T("smart", "smart_status_unknow")), void t.pollingTaskStop();
                t.fillData(i)
            },
            scope: t
        }
    },
    onAfterlayout: function(e) {
        this.form = this.getComponent("form").getForm(), this.btn = this.getComponent("form").getComponent("apply"), this.radio_quick = this.getComponent("form").getComponent("quick_radio"), this.desc_quick = this.getComponent("form").getComponent("quick_desc"), this.radio_extend = this.getComponent("form").getComponent("extend_radio"), this.desc_extend = this.getComponent("form").getComponent("extend_desc")
    },
    pollingTaskStart: function() {
        void 0 === this.TestLogPollingID && (this.TestLogPollingID = this.pollReg(this.TestLogPollingConf))
    },
    pollingTaskStop: function() {
        void 0 !== this.TestLogPollingID && (this.pollUnreg(this.TestLogPollingID), this.TestLogPollingID = void 0)
    },
    testing: void 0,
    quickTime: void 0,
    extendTime: void 0,
    cleanMask: !1,
    fillData: function(e) {
        var t, i, s, a = this,
            n = SYNO.SDS.StorageUtils;
        t = e.testInfo[0], i = n.smartTestStatusRender(t.quick), s = n.smartTestStatusRender(t.extend), "completed" !== t.quick && "damage" !== t.quick && "aborted" !== t.quick && "interrupted" !== t.quick || 0 < e.quick_last.length && (i = String.format("{0} ({1})", i, SYNO.SDS.DateTimeFormatter(Date.parseDate(e.quick_last, "Y/m/d H:i:s"), {
            type: "datetimesec"
        }))), "completed" !== t.extend && "damage" !== t.extend && "aborted" !== t.extend && "interrupted" !== t.extend || 0 < e.extend_last.length && (s = String.format("{0} ({1})", s, SYNO.SDS.DateTimeFormatter(Date.parseDate(e.extend_last, "Y/m/d H:i:s"), {
            type: "datetimesec"
        }))), this.form.findField("quickTestLog").setRawValue(i), this.form.findField("extendTestLog").setRawValue(s), this.quickTime = t.quickTime, this.extendTime = t.extendTime, this.testing = t.testing, this.testing ? (this.form.findField("testingStatus").setVisible(!0), "-1" !== t.remain ? this.form.findField("testingStatus").setRawValue(SYNO.SDS.StorageUtils.smartStatusRender("", t.remain)) : SYNO.SDS.StorageUtils.setUpdateTimeAnimate(!0, this.form.findField("testingStatus"), _T("background_task", "task_processing")), this.radio_quick.getEl().findParentNode("").parentNode.style.display = "none", this.desc_quick.getEl().findParentNode("").parentNode.style.display = "none", this.radio_extend.getEl().findParentNode("").parentNode.style.display = "none", this.desc_extend.getEl().findParentNode("").parentNode.style.display = "none", this.btn.setText(_T("smart", "smart_test_button_stop")), a.needRefresh = !0) : (this.form.findField("testingStatus").setVisible(!1), this.form.findField("testingStatus").setRawValue(""), this.radio_quick.getEl().findParentNode("").parentNode.style.display = "", this.desc_quick.getEl().findParentNode("").parentNode.style.display = "", this.radio_extend.getEl().findParentNode("").parentNode.style.display = "", this.desc_extend.getEl().findParentNode("").parentNode.style.display = "", this.btn.setText(_T("smart", "smart_test_button_start")), a.needRefresh && (a.appWin.healthOverviewPanel && a.appWin.healthOverviewPanel.onHealthInfoRefresh({
            device: a.device,
            ignoreBusyMask: !0
        }), a.needRefresh = !1)), _S("demo_mode") ? (Ext.getCmp(this.testBtnId).setDisabled(!0), Ext.getCmp(this.testBtnId).setTooltip(_JSLIBSTR("uicommon", "error_demo"))) : this.testing || !t.perf_testing && !t.ihm_testing ? (Ext.getCmp(this.testBtnId).setDisabled(!1), Ext.getCmp(this.testBtnId).setTooltip("")) : (Ext.getCmp(this.testBtnId).setDisabled(!0), Ext.getCmp(this.testBtnId).setTooltip(_T("disk_info", "other_is_testing"))), a.doLayout(), a.parentWin && a.parentWin.doLayout()
    },
    onApply: function() {
        var e, t, i, s = this;
        this.testing ? this.sendStopRequest() : ("quick" === (e = this.form.findField("testStyle").getGroupValue()) ? (t = _T("smart", "smart_quick_test"), i = String.format(_T("smart", "smart_test_time"), _T("smart", "smart_quick_test"), this.quickTime, 1 === parseInt(this.quickTime, 10) ? _T("common", "time_minute") : _T("common", "time_minutes"))) : "extend" === e && (t = _T("smart", "smart_extend_test"), i = String.format(_T("smart", "smart_test_time"), _T("smart", "smart_extend_test"), this.extendTime, 1 === parseInt(this.extendTime, 10) ? _T("common", "time_minute") : _T("common", "time_minutes"))), s.appWin.healthInfo && s.appWin.healthInfo.overview && s.appWin.healthInfo.overview.smart_test_limit ? s.appWin.getMsgBox().confirm("", _T("disk_info", "disk_smart_test_warn"), function(a) {
            "yes" === a && s.sendTestRequest(t, i, e)
        }, s) : s.sendTestRequest(t, i, e))
    },
    sendStopRequest: function() {
        this.appWin.setStatusBusy({
            text: _T("common", "saving")
        }), this.appWin.sendWebAPI(SYNO.SDS.StorageUtils.ReplaceWebapiSHA(this.is_target_ha_passive, {
            api: "SYNO.Core.Storage.Disk",
            version: 1,
            method: "do_smart_test",
            params: {
                device: this.device,
                type: "stop"
            },
            callback: function(e, t, i, s) {
                if (!e) return this.appWin.clearStatusBusy(), this.appWin.getMsgBox().alert("", _T("common", "error_system")), void this.pollingTaskStop();
                this.cleanMask = !0, this.appWin.sendWebAPI(SYNO.SDS.StorageUtils.ReplaceWebapiSHA(this.is_target_ha_passive, {
                    api: "SYNO.Core.Storage.Disk",
                    version: 1,
                    method: "get_smart_test_log",
                    params: {
                        device: this.device
                    },
                    callback: function(e, t, i, s) {
                        if (this.cleanMask && (this.appWin.clearStatusBusy(), this.cleanMask = !1), !e) return this.appWin.getMsgBox().alert("", _T("common", "error_system")), void this.pollingTaskStop();
                        this.fillData(t)
                    },
                    scope: this
                }))
            },
            scope: this
        }))
    },
    sendTestRequest: function(e, t, i) {
        this.appWin.getMsgBox().confirm(e, t, function(e) {
            "yes" === e && (this.appWin.setStatusBusy({
                text: _T("common", "saving")
            }), this.appWin.sendWebAPI(SYNO.SDS.StorageUtils.ReplaceWebapiSHA(this.is_target_ha_passive, {
                api: "SYNO.Core.Storage.Disk",
                version: 1,
                method: "do_smart_test",
                params: {
                    device: this.device,
                    type: i
                },
                callback: function(e, t, i, s) {
                    if (!e) return this.appWin.clearStatusBusy(), this.appWin.getMsgBox().alert("", _T("smart", "smart_selftest_cmd_exec_failed")), void this.pollingTaskStop();
                    this.cleanMask = !0, this.appWin.sendWebAPI(SYNO.SDS.StorageUtils.ReplaceWebapiSHA(this.is_target_ha_passive, {
                        api: "SYNO.Core.Storage.Disk",
                        version: 1,
                        method: "get_smart_test_log",
                        params: {
                            device: this.device
                        },
                        callback: function(e, t, i, s) {
                            if (this.cleanMask && (this.appWin.clearStatusBusy(), this.cleanMask = !1), !e) return this.appWin.getMsgBox().alert("", _T("common", "error_system")), void this.pollingTaskStop();
                            this.fillData(t)
                        },
                        scope: this
                    }))
                },
                scope: this
            })))
        }, this)
    },
    onRenderScheduleStatus: function() {
        var e, t = this;
        !0 === t.needSchedule && t.appWin.healthInfo && t.appWin.healthInfo.overview && !0 === t.appWin.healthInfo.overview.scheduled ? (e = SYNO.SDS.TaskScheduler.SMART.LastTriggerTimeGet(t.appWin.healthInfo.overview.smart_schedule_list), t.getComponent("form").getComponent("scheduleBtn").setVisible(!1)) : !0 === t.needSchedule ? t.getComponent("form").getComponent("scheduleBtn").setVisible(!0) : t.getComponent("form").getComponent("scheduleBtn").setVisible(!1), t.form.findField("scheduleStatus").setRawValue(Ext.isEmpty(e) ? "-" : e), t.doLayout(), t.parentWin && t.parentWin.doLayout()
    },
    onHandleSchedule: function() {
        var e, t = this;
        t.appWin && t.smartSchedulerTable && t.owner ? (e = {
            owner: t.appWin,
            owner_grid: t.smartSchedulerTable,
            disks: t.disks,
            diskMap: t.appWin.diskMap,
            schedule_id: -1,
            basic_limitation: !1,
            caller: t,
            adv_support: t.adv_support,
            test_type: "smart"
        }, new SYNO.SDS.StorageManager.Wizard.EditDialog(e).open(e)) : SYNO.Debug.error("Invalid arguments", t)
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.AdvTest", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.panel = new SYNO.SDS.StorageManager.AdvTestView(Ext.apply({
            appWin: this
        }, e));
        var t = [];
        t.push({
            xtype: "syno_fieldset",
            title: _T("disk_info", "disk_ironwolf_health"),
            items: this.panel
        });
        var i = Ext.apply({
            title: _T("disk_info", "disk_ironwolf_health"),
            width: 650,
            height: 450,
            minHeight: 380,
            minWidth: 560,
            layout: "fit",
            dsmStyle: "v5",
            padding: "0px 20px",
            items: t,
            buttons: [{
                text: _T("common", "alt_close"),
                handler: this.close,
                scope: this
            }]
        }, e);
        this.callParent([i])
    },
    onActivate: function() {
        this.panel.onActivate()
    }
}), Ext.define("SYNO.SDS.StorageManager.AdvTestView", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t, i = this;
        i.owner = e.owner, i.appWin = e.appWin, i.device = e.device, i.parent = e.parent, i.cleanMask = !1, i.needRefresh = !1, i.needSchedule = !0 !== e.isHaPanel && e.needSchedule, t = Ext.apply({
            title: _T("disk_info", "disk_ironwolf_health"),
            layout: "fit",
            items: [i.configForm({
                itemId: "form"
            })],
            listeners: {
                scope: i,
                beforedestroy: i.pollingTaskStop
            }
        }, e), i.TestLogPollingConf = i.getPollingConf(i.device), i.callParent([t])
    },
    onActivate: function(e) {
        this.onRenderScheduleStatus(), this.pollingTaskStart()
    },
    configForm: function(e) {
        var t = this;
        return Ext.apply({
            xtype: "syno_formpanel",
            trackResetOnLoad: !0,
            border: !1,
            padding: 0,
            items: [{
                xtype: "syno_fieldset",
                collapsible: !1,
                title: _T("disk_info", "disk_ironwolf_health_manage"),
                htmlEncode: !1,
                itemId: "test_field",
                synodefaults: {
                    width: 200
                },
                items: [{
                    xtype: "syno_displayfield",
                    value: _T("disk_info", "disk_adv_test_desc")
                }, {
                    xtype: "syno_displayfield",
                    id: t.testingStatusId = Ext.id()
                }, {
                    xtype: "syno_button",
                    disabled: _S("demo_mode"),
                    tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                    id: t.testBtnId = Ext.id(),
                    text: _T("smart", "smart_test_button_start"),
                    style: {
                        marginBottom: "8px"
                    },
                    handler: t.onApply,
                    scope: t
                }, {
                    xtype: "syno_displayfield",
                    id: t.noteId = Ext.id(),
                    htmlEncode: !1,
                    value: _T("disk_info", "disk_ironwolf_link_note")
                }, {
                    xtype: "syno_displayfield",
                    cls: "sm-disk-smart-secondary-title",
                    value: _T("smart", "smart_test_result")
                }, {
                    xtype: "syno_displayfield",
                    id: t.testResultId = Ext.id(),
                    htmlEncode: !1,
                    fieldLabel: _T("disk_info", "disk_ironwolf_test_pre_result")
                }, {
                    xtype: "syno_displayfield",
                    id: t.testOutputId = Ext.id(),
                    htmlEncode: !1,
                    fieldLabel: _T("disk_info", "disk_adv_test_code")
                }, {
                    xtype: "syno_displayfield",
                    cls: "sm-disk-smart-secondary-title",
                    value: _T("common", "schedule"),
                    hidden: !t.needSchedule
                }, {
                    xtype: "syno_displayfield",
                    name: "scheduleTimeField",
                    itemId: "scheduleStatus",
                    htmlEncode: !1,
                    hidden: !t.needSchedule,
                    fieldLabel: _T("schedule", "next_trigger_time")
                }, {
                    xtype: "syno_button",
                    itemId: "scheduleBtn",
                    text: _T("disk_info", "disk_schedule_ironwolf_test_btn"),
                    hidden: !0,
                    handler: function() {
                        t.onHandleSchedule()
                    },
                    scope: t
                }]
            }]
        }, e)
    },
    getPollingConf: function(e) {
        var t = this;
        if (!e) throw Error("param error: device is not set");
        return {
            interval: 5,
            immediate: !0,
            webapi: SYNO.SDS.StorageUtils.ReplaceWebapiSHA(this.is_target_ha_passive, {
                api: "SYNO.Core.Storage.Disk",
                version: 1,
                method: "get_adv_test_log",
                params: {
                    device: t.device
                }
            }),
            status_callback: function(e, i, s, a) {
                if (t.cleanMask && (t.appWin.clearStatusBusy(), t.cleanMask = !1), !e) return t.appWin.getMsgBox().alert("", _T("status", "status_not_available")), void t.pollingTaskStop();
                t.fillData(i)
            },
            scope: t
        }
    },
    pollingTaskStart: function() {
        void 0 === this.TestLogPollingID && (this.TestLogPollingID = this.pollReg(this.TestLogPollingConf))
    },
    pollingTaskStop: function() {
        void 0 !== this.TestLogPollingID && (this.pollUnreg(this.TestLogPollingID), this.TestLogPollingID = void 0)
    },
    fillData: function(e) {
        var t = this,
            i = "",
            s = "",
            a = SYNO.SDS.StorageUtils.DiskTestLogRender(e.test_result);
        switch (s = String.format('<span class="{0}">{1}</span>', a.color, a.text), "" !== e.test_time && (s += String.format(" ({0})", SYNO.SDS.DateTimeFormatter(Date.parseDate(e.test_time, "Y/m/d H:i:s"), {
                type: "datetimesec"
            }))), Ext.getCmp(t.testResultId).setRawValue(s), i = "" === a.code ? a.tooltip : "unknown" === a.code ? e.test_code + ". " + a.tooltip : a.code + ". " + a.tooltip, Ext.getCmp(t.testOutputId).setRawValue(i), e.disk_code) {
            case "ironwolf":
                Ext.getCmp(t.noteId).setValue(_T("disk_info", "disk_ironwolf_link_note"));
                break;
            case "ironwolf_pro":
                Ext.getCmp(t.noteId).setValue(_T("disk_info", "disk_ironwolf_pro_link_note"));
                break;
            default:
                Ext.getCmp(t.noteId).setValue(""), Ext.getCmp(t.noteId).setVisible(!1)
        }
        t.testing = e.testing, t.testing ? (SYNO.SDS.StorageUtils.setUpdateTimeAnimate(!0, Ext.getCmp(t.testingStatusId), _T("background_task", "task_processing")), Ext.getCmp(t.testingStatusId).setVisible(!0), Ext.getCmp(t.testBtnId).setText(_T("smart", "smart_test_button_stop")), t.needRefresh = !0) : (Ext.getCmp(t.testingStatusId).setRawValue(""), Ext.getCmp(t.testingStatusId).setVisible(!1), Ext.getCmp(t.testBtnId).setText(_T("smart", "smart_test_button_start")), t.needRefresh && (t.appWin.healthOverviewPanel && t.appWin.healthOverviewPanel.onHealthInfoRefresh({
            device: t.device,
            ignoreBusyMask: !0
        }), t.needRefresh = !1)), _S("demo_mode") ? (Ext.getCmp(this.testBtnId).setDisabled(!0), Ext.getCmp(this.testBtnId).setTooltip(_JSLIBSTR("uicommon", "error_demo"))) : t.testing || !e.perf_testing && !e.smart_testing ? (Ext.getCmp(this.testBtnId).setDisabled(!1), Ext.getCmp(this.testBtnId).setTooltip("")) : (Ext.getCmp(this.testBtnId).setDisabled(!0), Ext.getCmp(this.testBtnId).setTooltip(_T("disk_info", "other_is_testing"))), t.doLayout()
    },
    onApply: function() {
        var e = "";
        this.testing ? (e = "stop", this.sendTestRequest(e)) : (e = "start", this.confirmTestRequest(e))
    },
    confirmTestRequest: function(e) {
        var t = this;
        t.appWin.getMsgBox().confirm("", _T("disk_info", "disk_ironwolf_test_processing"), function(i) {
            "yes" === i && t.sendTestRequest(e)
        }, t)
    },
    sendTestRequest: function(e) {
        var t = this;
        t.appWin.setStatusBusy({
            text: _T("common", "saving")
        }), t.appWin.sendWebAPI(SYNO.SDS.StorageUtils.ReplaceWebapiSHA(this.is_target_ha_passive, {
            api: "SYNO.Core.Storage.Disk",
            version: 1,
            method: "do_adv_test",
            params: {
                device: t.device,
                type: e
            },
            callback: function(e, i, s, a) {
                if (!e) return t.appWin.clearStatusBusy(), t.appWin.getMsgBox().alert("", _T("error", "error_error_system")), void t.pollingTaskStop();
                t.cleanMask = !0, t.appWin.sendWebAPI(SYNO.SDS.StorageUtils.ReplaceWebapiSHA(this.is_target_ha_passive, {
                    api: "SYNO.Core.Storage.Disk",
                    version: 1,
                    method: "get_adv_test_log",
                    params: {
                        device: t.device
                    },
                    callback: function(e, i, s, a) {
                        if (t.cleanMask && (t.appWin.clearStatusBusy(), t.cleanMask = !1), !e) return t.appWin.getMsgBox().alert("", _T("common", "error_system")), void t.pollingTaskStop();
                        t.needRefresh = !0, t.fillData(i)
                    },
                    scope: t
                }))
            },
            scope: t
        }))
    },
    onRenderScheduleStatus: function() {
        var e, t = this,
            i = t.getComponent("form").getComponent("test_field");
        !0 === t.needSchedule && t.appWin.healthInfo && t.appWin.healthInfo.overview && !0 === t.appWin.healthInfo.overview.adv_scheduled ? (e = SYNO.SDS.TaskScheduler.SMART.LastTriggerTimeGet(t.appWin.healthInfo.overview.ihm_schedule_list), i.getComponent("scheduleBtn").setVisible(!1)) : !0 === t.needSchedule ? i.getComponent("scheduleBtn").setVisible(!0) : i.getComponent("scheduleBtn").setVisible(!1), i.getComponent("scheduleStatus").setRawValue(Ext.isEmpty(e) ? "-" : e)
    },
    onHandleSchedule: function() {
        var e, t = this;
        t.appWin && t.smartSchedulerTable && t.owner ? (e = {
            owner: t.appWin,
            owner_grid: t.smartSchedulerTable,
            disks: t.owner.disks,
            diskMap: t.appWin.diskMap,
            schedule_id: -1,
            basic_limitation: !1,
            caller: t,
            adv_support: !0,
            test_type: "adv"
        }, new SYNO.SDS.StorageManager.Wizard.EditDialog(e).open(e)) : SYNO.Debug.error("Invalid arguments", t)
    }
}), Ext.define("SYNO.SDS.StorageManager.WddaView", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t, i = this;
        i.owner = e.owner, i.appWin = e.appWin, i.device = e.device, i.parent = e.parent, i.cleanMask = !1, t = Ext.apply({
            title: _T("disk_info", "disk_wdda_title"),
            layout: "fit",
            items: [i.configForm({
                itemId: "form"
            })],
            listeners: {
                scope: i,
                beforedestroy: i.pollingTaskStop
            }
        }, e), i.TestLogPollingConf = i.getPollingConf(i.device), i.callParent([t])
    },
    onActivate: function() {
        this.pollingTaskStart()
    },
    configForm: function(e) {
        return Ext.apply({
            xtype: "syno_formpanel",
            border: !1,
            padding: 0,
            items: [{
                xtype: "syno_fieldset",
                collapsible: !1,
                title: _T("disk_info", "disk_wdda_full_title"),
                htmlEncode: !1,
                itemId: "testField",
                synodefaults: {
                    width: 200
                },
                items: [{
                    xtype: "syno_displayfield",
                    value: _T("disk_info", "disk_wdda_description")
                }, {
                    xtype: "syno_displayfield",
                    itemId: "status",
                    fieldLabel: _T("common", "status")
                }, {
                    xtype: "syno_displayfield",
                    itemId: "result",
                    htmlEncode: !1,
                    fieldLabel: _T("smart", "smart_test_result_sentence")
                }, {
                    xtype: "syno_displayfield",
                    itemId: "recommend",
                    htmlEncode: !1,
                    fieldLabel: _T("smart", "smart_test_recommend")
                }]
            }]
        }, e)
    },
    getPollingConf: function(e) {
        var t = this;
        if (!e) throw Error("param error: device is not set");
        return {
            interval: 5,
            immediate: !0,
            webapi: SYNO.SDS.StorageUtils.ReplaceWebapiSHA(this.is_target_ha_passive, {
                api: "SYNO.Core.Storage.Disk",
                version: 1,
                method: "get_wdda_test_result",
                params: {
                    device: t.device
                }
            }),
            status_callback: function(e, i, s, a) {
                if (t.cleanMask && (t.appWin.clearStatusBusy(), t.cleanMask = !1), !e) return t.appWin.getMsgBox().alert("", _T("status", "status_not_available")), void t.pollingTaskStop();
                t.fillData(i)
            },
            scope: t
        }
    },
    pollingTaskStart: function() {
        void 0 === this.TestLogPollingID && (this.TestLogPollingID = this.pollReg(this.TestLogPollingConf))
    },
    pollingTaskStop: function() {
        void 0 !== this.TestLogPollingID && (this.pollUnreg(this.TestLogPollingID), this.TestLogPollingID = void 0)
    },
    fillData: function(e) {
        var t, i = "",
            s = SYNO.SDS.StorageUtils.DiskWddaRender(e.test_result),
            a = this.getComponent("form").getComponent("testField");
        a && s && (a.getComponent("status").setValue(e.is_wdda_enabled ? _T("common", "enabled") : _T("common", "disabled")), i = String.format('<span class="{0}">{1}</span>', s.color, s.result), "" !== e.test_time && (i += String.format(" ({0})", SYNO.SDS.DateTimeFormatter(Date.parseDate(e.test_time, "Y/m/d H:i:s"), {
            type: "datetimesec"
        }))), a.getComponent("result").setValue(e.is_wdda_enabled ? i : "-"), t = s.recommend, a.getComponent("recommend").setValue(e.is_wdda_enabled && !Ext.isEmpty(t) ? t : "-"), this.doLayout())
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.HealthInfo", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t = [];
        this.cfg = e, this.cfg.appWin = this, this.healthOverviewPanel = new SYNO.SDS.StorageManager.HealthOverview(Ext.apply({
            id: this.healthOverviewId = Ext.id()
        }, this.cfg)), this.smartPanel = new SYNO.SDS.StorageManager.SmartPanel(Ext.apply({
            id: this.smartPanelId = Ext.id()
        }, this.cfg)), this.smartInfoPanel = new SYNO.SDS.StorageManager.SmartInfo(Ext.apply({
            id: this.smartInfoId = Ext.id(),
            isNvme: !1
        }, this.cfg)), this.smartInfoNVMePanel = new SYNO.SDS.StorageManager.SmartInfo(Ext.apply({
            id: this.smartInfoNVMeId = Ext.id(),
            isNvme: !0
        }, this.cfg)), this.advPanel = new SYNO.SDS.StorageManager.AdvTestView(Ext.apply({
            id: this.advTestViewId = Ext.id(),
            needSchedule: !0
        }, this.cfg)), this.wddaPanel = new SYNO.SDS.StorageManager.WddaView(Ext.apply({
            id: this.wddaViewId = Ext.id()
        }, this.cfg)), t.push(this.healthOverviewPanel), t.push(this.smartInfoPanel), t.push(this.smartInfoNVMePanel), t.push(this.advPanel), t.push(this.wddaPanel), t.push(this.smartPanel), t.push(new SYNO.SDS.StorageManager.HealthHistory(Ext.apply({
            id: this.healthHistoryId = Ext.id()
        }, this.cfg)));
        var i = new SYNO.SDS.Utils.TabPanel({
                id: this.tabPanelId = Ext.id(),
                activeTab: 0,
                items: t
            }),
            s = Ext.apply({
                title: _T("disk_info", "disk_health_info") + " - " + e.name,
                modal: !1,
                width: 820,
                height: 580,
                minWidth: 820,
                minHeight: 580,
                layout: "fit",
                items: i,
                buttons: [{
                    text: _T("common", "alt_close"),
                    handler: this.close,
                    scope: this
                }]
            }, e);
        this.callParent([s]), Ext.getCmp(this.tabPanelId).hideTabStripItem(this.advTestViewId), Ext.getCmp(this.tabPanelId).hideTabStripItem(this.wddaViewId), Ext.getCmp(this.tabPanelId).hideTabStripItem(this.smartInfoId), Ext.getCmp(this.tabPanelId).hideTabStripItem(this.smartInfoNVMeId), Ext.getCmp(this.tabPanelId).hideTabStripItem(this.smartPanelId), Ext.getCmp(this.tabPanelId).hideTabStripItem(this.healthHistoryId)
    },
    removeTab: function(e) {
        var t = 0;
        void 0 !== e && (t += 40, t += 7 * Ext.getCmp(this.healthOverviewId).title.length + 40, "not_support" !== e.adv_status ? (Ext.getCmp(this.tabPanelId).unhideTabStripItem(this.advTestViewId), t += 7 * Ext.getCmp(this.advTestViewId).title.length + 40) : "not_support" !== e.wdda_status && (Ext.getCmp(this.tabPanelId).unhideTabStripItem(this.wddaViewId), t += 7 * Ext.getCmp(this.wddaViewId).title.length + 40), e.smartTest_support ? (Ext.getCmp(this.tabPanelId).unhideTabStripItem(this.smartPanelId), t += 7 * Ext.getCmp(this.smartPanelId).title.length + 40, this.smartPanel.removePanel(e.smartInfo_support)) : e.smartInfo_support && (e.isNVMeDisk ? (Ext.getCmp(this.tabPanelId).unhideTabStripItem(this.smartInfoNVMeId), t += 7 * Ext.getCmp(this.smartInfoNVMeId).title.length + 40) : (Ext.getCmp(this.tabPanelId).unhideTabStripItem(this.smartInfoId), t += 7 * Ext.getCmp(this.smartInfoId).title.length + 40)), e.healthHistory_support && (Ext.getCmp(this.tabPanelId).unhideTabStripItem(this.healthHistoryId), t += 7 * Ext.getCmp(this.healthHistoryId).title.length + 40), this.getWidth() < t && this.setWidth(t))
    },
    onGotoTabPanel: function(e) {
        var t, i = {
            overview: this.healthOverviewId,
            nvme_info: this.smartInfoNVMeId,
            adv_test: this.advTestViewId,
            wdda: this.wddaViewId,
            smart_test: this.smartPanelId,
            history: this.healthHistoryId
        };
        if ("smart_info" === e) {
            var s = new SYNO.SDS.StorageManager.SmartInfo(Ext.apply({
                    style: "padding: 0px 20px;",
                    isNvme: !1,
                    height: 450
                }, this.cfg)),
                a = new SYNO.SDS.ModalWindow({
                    owner: this.appWin,
                    dsmStyle: "v5",
                    resizable: !1,
                    width: 700,
                    height: 510,
                    hideLabel: !1,
                    title: _T("smart", "smart_toolbar_smart_info"),
                    buttons: [{
                        text: _T("common", "alt_close"),
                        scope: this,
                        handler: function() {
                            a.close()
                        }
                    }],
                    items: s
                });
            return a.open(), void s.onActivate()
        }
        e in i ? (t = i[e], Ext.getCmp(this.tabPanelId).setActiveTab(t)) : SYNO.Debug.error("no such panel", e)
    }
}), Ext.define("SYNO.SDS.StorageManager.HealthOverview", {
    extend: "SYNO.ux.Panel",
    loaded: !1,
    constructor: function(e) {
        if (this.owner = e.owner, this.appWin = e.appWin, this.device = e.device, this.temp = e.temp, this.parent = e.parent, this.is_target_ha_passive = e.is_target_ha_passive, this.isHaPanel = e.isHaPanel, this.warningBtnRenderId = Ext.id(), this.scheduleBtnRenderId = Ext.id(), this.gotoSmartInfoPanelLinkId = Ext.id(), this.gotoSmartTestPanelLinkId = Ext.id(), this.gotoIronWolfPanelLinkId = Ext.id(), this.gotoHistoryPanelLinkId = Ext.id(), this.gotoWddaPanelLinkId = Ext.id(), this.predictLinkId = Ext.id(), this.diskHealth = new Ext.DataView({
                tpl: new Ext.XTemplate('<tpl for=".">', '<div class="sm-overview-health-mini-status">', '<div class="sm-overview-health-mini-icon-align ">', '<div class="{iconCls} {iconCls}-{status}"></div>', '<div class="{statusIconCls} {statusIconCls}-{status}"></div>', "</div>", '<div class="sm-overview-health-mini-textarea">', '<div class="sm-overview-health-mini-text">{text}</div>', '<div class="sm-overview-health-mini-desc">{desc}</div>', "<div id=" + this.warningBtnRenderId + ' class="sm-overview-health-button"></div>', "</div>", "</div>", "</tpl>"),
                store: this.healthStore = new Ext.data.JsonStore({
                    autoDestroy: !0,
                    fields: ["status", "text", "desc", "iconCls", "statusIconCls"]
                })
            }), this.adv_support = !1, !1 === this.isHaPanel)
            for (var t = 0; t < e.disks.length; t++)
                if ("not_support" !== e.disks[t].adv_status) {
                    this.adv_support = !0;
                    break
                } var i = [];
        i.push({
            xtype: "syno_displayfield",
            htmlEncode: !1,
            itemId: "remainLifeDisplayField",
            fieldLabel: _T("disk_info", "disk_remain_life")
        }, {
            xtype: "syno_displayfield",
            htmlEncode: !1,
            itemId: "SBMonthLeftDisplayField",
            fieldLabel: _T("disk_info", "ssd_bundle_useful_time")
        }, {
            xtype: "syno_displayfield",
            itemId: "tempDisplayField",
            fieldLabel: _T("status", "temperature")
        }), i.push({
            xtype: "syno_displayfield",
            itemId: "poweronDisplayField",
            fieldLabel: _T("disk_info", "disk_poweron_hours")
        }, {
            xtype: "syno_displayfield",
            itemId: "retryDisplayField",
            fieldLabel: _T("disk_info", "disk_retry_ct")
        }, {
            xtype: "syno_displayfield",
            htmlEncode: !1,
            itemId: "badSectorDisplayField",
            fieldLabel: _T("disk_info", "disk_bad_sector_ct")
        }, {
            xtype: "syno_displayfield",
            itemId: "idnfDisplayField",
            fieldLabel: _T("disk_info", "disk_identify_failed_ct")
        });
        var s = Ext.apply({
            title: _T("helptoc", "logcenter_overview"),
            border: !1,
            autoFlexcroll: !0,
            items: [this.diskHealth, {
                xtype: "syno_fieldset",
                cls: "sm-health-statistics-fieldset",
                hidden: !0,
                itemId: "statisticsFieldSet",
                title: _T("disk_info", "disk_health_statistics"),
                border: !1,
                labelWidth: 300,
                items: i
            }, {
                border: !1,
                xtype: "syno_fieldset",
                hidden: !0,
                id: this.description_field_id = Ext.id(),
                title: _T("disk_info", "disk_health_description_and_other_warning"),
                items: [{
                    xtype: "syno_displayfield",
                    htmlEncode: !1,
                    fieldLabel: "",
                    id: this.system_long_desc_id = Ext.id(),
                    hideLabel: !0
                }]
            }],
            listeners: {
                activate: this.onActivate,
                scope: this
            }
        }, e);
        this.callParent([s])
    },
    onActivate: function(e) {
        this.loaded || this.onHealthInfoRefresh(e)
    },
    onHealthInfoRefresh: function(e) {
        !0 !== e.ignoreBusyMask && this.appWin.setStatusBusy(), this.appWin.sendWebAPI(SYNO.SDS.StorageUtils.ReplaceWebapiSHA(this.is_target_ha_passive, {
            api: "SYNO.Storage.CGI.Smart",
            method: "get_health_info",
            version: 1,
            params: {
                device: e.device
            },
            scope: this,
            callback: function(t, i) {
                !0 !== e.ignoreBusyMask && this.appWin.clearStatusBusy();
                var s;
                t ? (this.loaded = !0, this.appWin.healthInfo = i.healthInfo, (s = this.appWin.healthInfo.overview) ? (this.onLoadSuccess(s), this.onRenderGotoLink(s), this.appWin.smartInfoPanel.onActivate(), this.appWin.smartInfoNVMePanel.onActivate(), "not_support" !== s.adv_status && this.appWin.advPanel.onActivate(), s.smartTest_support && this.appWin.smartPanel.onActivate(), "not_support" !== s.wdda_status && this.appWin.wddaPanel.onActivate()) : this.onLoadFail()) : this.onLoadFail()
            }
        }))
    },
    onRenderGotoLink: function(e) {
        var t = Ext.fly(this.gotoSmartInfoPanelLinkId);
        Ext.isObject(t) && e.smartInfo_support && (e.isNVMeDisk ? this.mon(t, "click", function() {
            this.appWin.onGotoTabPanel("nvme_info")
        }, this) : this.mon(t, "click", function() {
            this.appWin.onGotoTabPanel("smart_info")
        }, this)), t = Ext.fly(this.gotoSmartTestPanelLinkId), Ext.isObject(t) && e.smartTest_support && this.mon(t, "click", function() {
            this.appWin.onGotoTabPanel("smart_test")
        }, this), t = Ext.fly(this.gotoIronWolfPanelLinkId), Ext.isObject(t) && "not_support" !== e.adv_status && this.mon(t, "click", function() {
            this.appWin.onGotoTabPanel("adv_test")
        }, this), t = Ext.fly(this.gotoHistoryPanelLinkId), Ext.isObject(t) && e.healthHistory_support && this.mon(t, "click", function() {
            this.appWin.onGotoTabPanel("history")
        }, this), t = Ext.fly(this.gotoWddaPanelLinkId), Ext.isObject(t) && "not_support" !== e.wdda_status && this.mon(t, "click", function() {
            this.appWin.onGotoTabPanel("wdda")
        }, this), t = Ext.fly(this.predictLinkId), Ext.isObject(t) && this.mon(t, "click", function() {
            this.openHelper()
        }, this)
    },
    onRenderButton: function(e) {
        var t, i = this,
            s = !1,
            a = 0,
            n = [];
        for (t = 0 < e.smart_suppress || 0 < e.smart_disable || !0 === e.adv_modified || (0 < e.smart_test_suppress || 0 < e.smart_test_disable) && "normal" === e.smart_test || (0 < e.wdda_suppress || 0 < e.wdda_disable) && "warning" !== e.wdda_status || (0 < e.nvme_perc_used_suppress || 0 < e.nvme_perc_used_disable) && !1 === e.nvme_perc_used_full, a = 0; a < e.smart_fail.length; a++)
            if ("critical" !== e.smart_fail[a].type) {
                s = !0;
                break
            }! 0 !== e.adv_modifiable && !0 !== e.wdda_modifiable && !0 !== e.nvme_perc_used_full && "normal_past" !== e.smart_test || (s = !0), s || t ? (i.modifyWarningBtn = new Ext.menu.Item({
            text: _T("disk_info", "disk_remove_warning_title"),
            id: i.modifyWarningId = Ext.id(),
            handler: i.onHandleWarning,
            disabled: !s,
            scope: i
        }), n.push(i.modifyWarningBtn), i.recoverWarningBtn = new Ext.menu.Item({
            text: _T("disk_info", "disk_recover_warning_title"),
            id: i.recoverWarningId = Ext.id(),
            handler: i.onEnableWarning,
            disabled: !t,
            scope: i
        }), n.push(i.recoverWarningBtn), i.warningMenu = new SYNO.ux.Menu({
            items: n
        }), i.warningBtn = new SYNO.ux.Button({
            id: i.warningBtnId = Ext.id(),
            text: _T("disk_info", "disk_modify_warning_title"),
            menu: i.warningMenu,
            renderTo: i.warningBtnRenderId,
            scope: i
        }), i.diskHealth.getNode(i.warningBtnRenderId).classList.remove("sm-overview-display-none")) : i.diskHealth.getNode(i.warningBtnRenderId).classList.add("sm-overview-display-none")
    },
    onHandleWarning: function() {
        var e = {
            owner: this.appWin,
            appWin: this.appWin,
            device: this.device,
            is_target_ha_passive: this.is_target_ha_passive
        };
        new SYNO.SDS.StorageManager.Wizard.SmartWarning(e).open(e)
    },
    onEnableWarning: function() {
        var e = {
            owner: this.appWin,
            appWin: this.appWin,
            device: this.device,
            is_target_ha_passive: this.is_target_ha_passive
        };
        new SYNO.SDS.StorageManager.Wizard.EnableWarning(e).open(e)
    },
    smartOtherNormalJudge: function(e) {
        return "fail" !== e.smart_test && "warning" !== e.adv_status && "critical" !== e.adv_status && "failing" !== e.adv_status
    },
    renderOverviewStatus: function(e) {
        var t = function(e, t, i) {
                var s;
                return s = String.format('<a class="link-font" href="#" id="{0}">{1}</a>', e, t), String.format(i, s)
            },
            i = "",
            s = "",
            a = "",
            n = "",
            o = "";
        switch (e.overview_status) {
            case "normal":
                i = "normal", s = _T("disk_info", "disk_status_healthy"), a = _T("disk_info", "disk_smart_ok_desc"), o = "normal", "life_below_thr" === e.smart_info ? (a = _T("disk_info", "disk_status_remain_life_desc"), o = "life_below_thr") : !0 === e.sb_days_left_warning && (a = _T("disk_info", "ssd_bundle_useful_time_desc"), o = "sb_days_left_warning");
                break;
            case "warning":
                i = "warning", s = _T("disk_info", "disk_status_warning"), n = _T("disk_info", "disk_status_warning_action"), !0 === e.smart_fail_repeat ? (a = t(this.gotoSmartInfoPanelLinkId, _T("smart", "smart_toolbar_smart_info"), _T("disk_info", "disk_status_smart_repeat_fail_main_desc")), o = "smart_info_repeat") : !0 === e.smart_fail_past ? (a = t(this.gotoSmartInfoPanelLinkId, _T("smart", "smart_toolbar_smart_info"), _T("disk_info", "disk_status_smart_info_normal_past_main_desc")), o = "smart_info_past") : "normal_past" === e.smart_test ? (a = t(this.gotoSmartTestPanelLinkId, _T("smart", "smart_toolbar_smart_test"), _T("disk_info", "disk_status_smart_test_normal_past_main_desc")), o = "smart_test_past") : "warning" === e.adv_status ? (a = t(this.gotoIronWolfPanelLinkId, _T("disk_info", "disk_ironwolf_test") + ": ", "{0}" + _T(e.adv_section, e.adv_key)), o = "ihm_test_warning", n = "") : "warning" === e.wdda_status ? (a = t(this.gotoWddaPanelLinkId, _T("disk_info", "disk_wdda_title"), _T("disk_info", "disk_status_wdda_warning_main_desc")), o = "wdda_warning", n = _T("disk_info", "disk_status_wdda_warning_action")) : e.isNVMeDisk && e.nvme_perc_used_full ? (a = _T("disk_info", "nvme_percentage_used_full"), o = "nvme_warning_perctage_used_full") : e.isNVMeDisk && e.critial_warning.temp_over_thr && (a = _T("notification_event", "DiskTemperatureAbnormal"), o = "nvme_warning_temp", n = _T("disk_info", "disk_status_temperature_warning_action"));
                break;
            case "critical":
                i = "critical", s = _T("disk_info", "disk_status_critical"), n = _T("disk_info", "disk_status_critical_action"), "life_danger" === e.smart_info ? (a = _T("disk_info", "disk_status_remain_life_severe_main_desc"), o = "life_danger") : !0 === e.sb_days_left_critical ? (a = _T("disk_info", "ssd_bundle_useful_time_severe_desc"), o = "sb_days_left_critical") : !0 === e.smart_fail_critical ? (a = t(this.gotoSmartInfoPanelLinkId, _T("smart", "smart_toolbar_smart_info"), _T("disk_info", "disk_status_smart_critical_fail_main_desc")), o = "smart_info_critical") : "critical" === e.health_prediction ? (a = this.preparePredictDesc(e.health_prediction_factor), n = "", o = "health_prediction_critical") : "critical" === e.adv_status ? (a = t(this.gotoIronWolfPanelLinkId, _T("disk_info", "disk_ironwolf_test") + ": ", "{0}" + _T(e.adv_section, e.adv_key)), o = "ihm_test_critical", n = "") : !0 === e.isNVMeDisk ? e.critial_warning.spare_below_thr ? (a = String.format(_T("disk_info", "nvme_critical_warning_reach_vendor_threshold"), e.remain_life, e.remain_life_thr), o = "nvme_critical_below_vender_thr") : e.critial_warning.degraded ? (a = _T("disk_info", "nvme_critical_warning_media_error"), o = "nvme_critical_degraded") : e.critial_warning.vm_backup_fail && (a = _T("disk_info", "nvme_critical_warning_volatile_memory_backup_device_fail"), o = "nvme_critical_vm_backup_fail") : "critical" === e.disk_error_unc_status ? (a = _T("disk_info", "disk_status_unc_critical_main_desc"), o = "disk_error_critical_unc") : "critical" === e.disk_error_timeout_status ? (a = _T("disk_info", "disk_status_timeout_critical_main_desc"), o = "disk_error_critical_timeout") : "critical" === e.disk_error_reset_fail_status && (a = _T("disk_info", "disk_status_reset_fail_critical_main_desc"), o = "disk_error_critical_reset_fail");
                break;
            case "failing":
                i = "failing", s = _T("disk_info", "disk_status_failing"), n = _T("disk_info", "disk_status_failing_action"), "fail" === e.smart_test ? (a = t(this.gotoSmartTestPanelLinkId, _T("smart", "smart_toolbar_smart_test"), _T("disk_info", "disk_status_critical_smart_fail_main_desc")), o = "smart_test_fail") : "failing" === e.adv_status ? (a = t(this.gotoIronWolfPanelLinkId, _T("disk_info", "disk_ironwolf_test") + ": ", "{0}" + _T(e.adv_section, e.adv_key)), o = "ihm_test_fail", n = "") : e.isNVMeDisk && e.critial_warning.read_only && (a = _T("disk_info", "nvme_critical_warning_read_only_mode"), o = "nvme_fail");
                break;
            default:
                SYNO.Debug.error("no such status", e.overview_status), i = ""
        }
        return Ext.isEmpty(n) || (a += "<br>" + n), {
            diskStatus: i,
            text: s,
            desc: a,
            mainStatus: o
        }
    },
    onLoadSuccess: function(e) {
        var t, i = {},
            s = [],
            a = SYNO.SDS.StorageUtils,
            n = "",
            o = this.getComponent("statisticsFieldSet"),
            r = o.getComponent("tempDisplayField"),
            d = o.getComponent("poweronDisplayField"),
            l = o.getComponent("retryDisplayField"),
            p = o.getComponent("badSectorDisplayField"),
            u = o.getComponent("idnfDisplayField"),
            c = o.getComponent("remainLifeDisplayField"),
            _ = o.getComponent("SBMonthLeftDisplayField");
        r.setValue(a.DiskTemperatureRender(this.temp)), (e.isSataDisk || e.isNVMeDisk) && d.setValue(String.format("{0} {1}", e.poweron, 1 === parseInt(e.poweron, 10) ? _T("common", "time_hour") : _T("common", "time_hours"))), e.isSataDisk && (l.setValue(e.retry), u.setValue(e.idnf)), d.setVisible(e.isSataDisk || e.isNVMeDisk), l.setVisible(e.isSataDisk), u.setVisible(e.isSataDisk), this.appWin.removeTab(e), -1 === e.remain_life ? c.setVisible(!1) : (c.setVisible(!0), c.setValue(a.RemainLifeRenderOld(e.remain_life, e.below_remain_life_show_thr, e.remain_life_danger)), SYNO.ux.AddWhiteTipWithMsg(c, String.format(_T("disk_info", "disk_remain_life_info"), e.remain_life_attr))), e.isSataDisk && !e.isSsd ? (p.setVisible(!0), p.setValue(a.BadSecCtRender(e.unc, e.exceed_bad_sector_thr))) : p.setVisible(!1), e.sb_days_left_warning ? (_.setVisible(!0), _.setValue(a.SBTimeStringFormatRender(e.sb_days_left, e.sb_days_left_critical)), SYNO.ux.AddWhiteTipWithMsg(_, _T("disk_info", "ssd_bundle_option_info"))) : _.setVisible(!1), o.show(), i.iconCls = "sm-overview-health-mini-icon", i.statusIconCls = "sm-overview-health-mini-status-icon";
        var h = this.renderOverviewStatus(e);
        i.status = h.diskStatus, i.text = h.text, i.desc = h.desc, t = h.mainStatus, "" !== i.status && (s.push(i), this.healthStore.loadData(s), this.onRenderButton(e), 0 !== e.retry && SYNO.ux.AddWhiteTipWithMsg(l, String.format(_T("disk_info", "disk_retry_desc"))), 0 === e.unc || e.isSsd || SYNO.ux.AddWhiteTipWithMsg(p, String.format(_T("disk_info", "disk_bad_sector_desc"))), 0 !== e.idnf && SYNO.ux.AddWhiteTipWithMsg(u, String.format(_T("disk_info", "disk_identify_failed_desc"))), n += this.addBottomDescFailing(e, t), n += this.addBottomDescCritical(e, t), n += this.addBottomDescWarning(e, t), "" === (n += this.addBottomDescInfo(e, t)) ? (Ext.getCmp(this.system_long_desc_id).hide(), Ext.getCmp(this.description_field_id).hide()) : (Ext.getCmp(this.system_long_desc_id).setValue(n), Ext.getCmp(this.system_long_desc_id).show(), Ext.getCmp(this.description_field_id).show()), this.doLayout())
    },
    onLoadFail: function() {
        var e = {},
            t = [];
        this.appWin.removeTab(), e.status = "access_error", e.text = _T("disk_info", "disk_status_access_err"), e.desc = _T("disk_info", "disk_status_access_err_desc"), e.iconCls = "sm-overview-health-mini-icon", e.statusIconCls = "sm-overview-health-mini-status-icon", t.push(e), this.healthStore.loadData(t), Ext.getCmp(this.system_long_desc_id).hide(), Ext.getCmp(this.description_field_id).hide(), this.doLayout()
    },
    addBottomDescFailing: function(e, t) {
        var i = "";
        return "smart_test_fail" !== t && (i += "fail" === e.smart_test ? _T("disk_info", "disk_status_critical_smart_fail_desc") + "<br><br>" : ""), "ihm_test_fail" !== t && (i += "failing" === e.adv_status ? _T(e.adv_section, e.adv_key) + "<br><br>" : ""), "nvme_fail" !== t && (i += e.isNVMeDisk && e.critial_warning.read_only ? _T("disk_info", "nvme_critical_warning_read_only_mode") + "<br><br>" : ""), i
    },
    addBottomDescCritical: function(e, t) {
        var i = "",
            s = 0;
        for ("life_danger" !== t && "nvme_fail" != t && (i += "life_danger" === e.smart_info ? _T("disk_info", "disk_status_remain_life_severe_main_desc") + "<br><br>" : ""), "sb_days_left_critical" === t || "life_danger" === e.smart_info || e.isNVMeDisk && e.critial_warning.read_only || (i += !0 === e.sb_days_left_critical ? _T("disk_info", "ssd_bundle_useful_time_severe_desc") + "<br><br>" : ""), s = 0; s < e.smart_fail.length; s++) "critical" == e.smart_fail[s].type && (i += "smart_info_critical" !== t ? String.format(_T("disk_info", "disk_status_smart_critical_fail_mask_desc"), e.smart_fail[s].id, e.smart_fail[s].name) + "<br><br>" : String.format(_T("disk_info", "disk_status_smart_critical_fail_bottom_desc"), e.smart_fail[s].id, e.smart_fail[s].name) + "<br><br>");
        return "health_prediction_critical" !== t && (i += "critical" === e.health_prediction ? this.preparePredictDesc(e.health_prediction_factor) + "<br><br>" : ""), "ihm_test_critical" !== t && (i += "critical" === e.adv_status ? _T(e.adv_section, e.adv_key) + "<br>" : ""), !0 === e.isNVMeDisk && ("nvme_critical_below_vender_thr" !== t && (i += e.critial_warning.spare_below_thr ? String.format(_T("disk_info", "nvme_critical_warning_reach_vendor_threshold"), e.remain_life, e.remain_life_thr) + "<br><br>" : ""), "nvme_critical_degraded" !== t && (i += e.critial_warning.degraded ? _T("disk_info", "nvme_critical_warning_media_error") + "<br><br>" : ""), "nvme_critical_vm_backup_fail" !== t && (i += e.critial_warning.vm_backup_fail ? _T("disk_info", "nvme_critical_warning_volatile_memory_backup_device_fail") + "<br><br>" : "")), "disk_error_critical_unc" !== t && (i += "critical" === e.disk_error_unc_status ? _T("disk_info", "disk_status_unc_critical_main_desc") + "<br><br>" : ""), "disk_error_critical_timeout" !== t && (i += "critical" === e.disk_error_timeout_status ? _T("disk_info", "disk_status_timeout_critical_main_desc") + "<br><br>" : ""), "disk_error_critical_reset_fail" !== t && (i += "critical" === e.disk_error_reset_fail_status ? _T("disk_info", "disk_status_reset_fail_critical_main_desc") + "<br><br>" : ""), i
    },
    addBottomDescWarning: function(e, t) {
        var i = "",
            s = 0;
        for (s = 0; s < e.smart_fail.length; s++) "repeat" == e.smart_fail[s].type ? i += "smart_info_repeat" !== t ? String.format(_T("disk_info", "disk_status_smart_repeat_fail_mask_desc"), e.smart_fail[s].id, e.smart_fail[s].name) + "<br><br>" : String.format(_T("disk_info", "disk_status_smart_repeat_fail_bottom_desc"), e.smart_fail[s].id, e.smart_fail[s].name) + "<br><br>" : "past" === e.smart_fail[s].type && (i += String.format(_T("disk_info", "disk_status_smart_info_normal_past_bottom_desc"), e.smart_fail[s].id, e.smart_fail[s].name) + "<br><br>");
        return "smart_test_past" !== t && "normal_past" === e.smart_test && (i += String.format(_T("disk_info", "disk_status_smart_test_normal_past_main_desc"), _T("smart", "smart_toolbar_smart_test")) + "<br><br>"), "ihm_test_warning" !== t && (i += "warning" === e.adv_status ? _T(e.adv_section, e.adv_key) + "<br><br>" : ""), "wdda_warning" !== t && "warning" === e.wdda_status && (i += String.format(_T("disk_info", "disk_status_wdda_warning_main_desc"), _T("disk_info", "disk_wdda_title")) + "<br><br>"), "nvme_warning_perctage_used_full" !== t && (i += e.isNVMeDisk && e.nvme_perc_used_full ? _T("disk_info", "nvme_percentage_used_full") + "<br><br>" : ""), "nvme_warning_temp" !== t && (i += e.isNVMeDisk && e.critial_warning.temp_over_thr ? _T("notification_event", "DiskTemperatureAbnormal") + "<br><br>" : ""), i
    },
    addBottomDescInfo: function(e, t) {
        var i, s = "",
            a = [],
            n = [];
        Ext.isEmpty(e.low_performance_in_raid_disk_list) || (n = e.low_performance_in_raid_disk_list.split(",")), "life_below_thr" !== t && "nvme_fail" != t && "life_danger" !== t && "nvme_critical_below_vender_thr" !== t && !0 === e.below_remain_life_thr && (s += _T("disk_info", "disk_status_remain_life_desc") + "<br><br>"), "sb_days_left_warning" === t || "life_danger" === e.smart_info || e.isNVMeDisk && e.critial_warning.read_only || !0 === e.sb_days_left_warning && !1 === e.sb_days_left_critical && (s += _T("disk_info", "ssd_bundle_status_useful_time_desc") + "<br><br>"), "low" === e.seq_status ? s += _T("disk_info", "disk_low_seq_perf_desc") + "<br><br>" : "past" === e.seq_status && (s += _T("disk_info", "disk_past_seq_perf_desc") + "<br><br>");
        for (var o = 0; o < n.length; ++o)(i = this.appWin.diskMap[n[o]]) && a.push(SYNO.SDS.StorageUtils.DiskDisplayNameGet(i));
        return "now" === e.low_performance_in_raid ? s += String.format(_T("disk_info", "disk_low_perf_in_raid_now_desc"), a.join(", ")) + "<br><br>" : "past" === e.low_performance_in_raid && (s += _T("disk_info", "disk_low_perf_in_raid_past_desc") + "<br><br>"), ("normal_suppress" === e.smart_info || "normal_repeat_suppress" === e.smart_info || !0 === e.adv_modified || "normal" === e.smart_test && 1 <= e.smart_test_suppress && 0 === e.smart_test_disable || 1 <= e.wdda_suppress && 0 === e.wdda_disable && "warning" !== e.wdda_status || 1 <= e.nvme_perc_used_suppress && 0 === e.nvme_perc_used_disable && !1 === e.nvme_perc_used_full) && (s += _T("disk_info", "disk_status_suppress_detail") + "<br><br>"), ("normal_disable" === e.smart_info || "normal" === e.smart_test && 0 < e.smart_test_disable || 0 < e.wdda_disable && "warning" !== e.wdda_status || 0 < e.nvme_perc_used_disable && !1 === e.nvme_perc_used_full) && (s += _T("disk_info", "disk_status_disable_detail") + "<br><br>"), e.smartTest_support && !e.scheduled && (s += _T("disk_info", "disk_no_sched_smart_test_desc") + "<br><br>"), s
    },
    preparePredictDesc: function(e) {
        var t = String.format('<a class="link-font" href="#" id="{0}">', this.predictLinkId),
            i = "",
            s = "";
        return Ext.isEmpty(e) ? s = String.format(_T("disk_info", "disk_status_health_prediction_critical_main_desc"), t, "</a>") : (i = SYNO.SDS.StorageUtils.DiskPredictionMainFactorRender(e, this.appWin.healthInfo.smartInfo), s = String.format(_T("disk_info", "disk_status_health_prediction_critical_main_desc_with_cause"), t, "</a>", i)), s
    },
    openHelper: function() {
        SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
            topic: "SYNO.SDS.StorageManager.Instance:StorageManager/disk.html"
        })
    }
}), Ext.define("SYNO.SDS.StorageManager.SmartPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t, i = this,
            s = [];
        i.owner = e.owner, i.appWin = e.appWin, i.device = e.device, i.parent = e.parent, i.disks = e.disks, i.isHaPanel = e.isHaPanel, i.is_target_ha_passive = e.is_target_ha_passive, i.smartTestPanel = new SYNO.SDS.StorageManager.SmartTestView({
            needSchedule: !0,
            noTitle: !0,
            parentWin: i,
            owner: i.owner,
            appWin: i.appWin,
            parent: i.parent,
            device: i.device,
            disks: i.disks,
            smartSchedulerTable: e.smartSchedulerTable,
            isHaPanel: i.isHaPanel,
            is_target_ha_passive: i.is_target_ha_passive
        }), s.push({
            xtype: "syno_fieldset",
            title: _T("smart", "smart_toolbar_smart_test"),
            id: i.smartTestId = Ext.id(),
            items: i.smartTestPanel
        }), i.smartInfoPanel = new SYNO.SDS.StorageManager.SmartInfoPanel({
            owner: i.owner,
            appWin: i.appWin,
            device: i.device,
            isHaPanel: i.isHaPanel,
            height: 100,
            is_target_ha_passive: i.is_target_ha_passive
        }), s.push({
            xtype: "syno_fieldset",
            style: {
                marginTop: "16px"
            },
            title: _T("smart", "smart_toolbar_smart_info"),
            id: i.smartInfoId = Ext.id(),
            items: i.smartInfoPanel
        }), t = Ext.apply({
            autoFlexcroll: !0,
            title: _T("smart", "smart_name"),
            dsmStyle: "v5",
            items: s,
            listeners: {
                activate: i.onActivate,
                scope: i
            }
        }, e), i.callParent([t]), i.mon(i, "resize", function(e, t) {
            e.smartTestPanel.setWidth(t - 16), e.smartInfoPanel.setWidth(t - 16), e.doLayout()
        }, i)
    },
    removePanel: function(e) {
        e ? Ext.getCmp(this.smartInfoId).setVisible(!0) : Ext.getCmp(this.smartInfoId).setVisible(!1)
    },
    onActivate: function() {
        var e, t = this;
        t.appWin.healthInfo && t.appWin.healthInfo.overview ? (e = t.appWin.healthInfo.overview.smartInfo_support, t.removePanel(e), t.smartTestPanel.onActivate()) : SYNO.Debug.error("Failed to read disk overview status", t.appWin)
    }
}), SYNO.SDS.StorageManager.monthOffset = 0, SYNO.SDS.StorageManager.convertToMonth = function(e) {
    return [_JSLIBSTR("extlang", "jan").substr(0, 3), _JSLIBSTR("extlang", "feb").substr(0, 3), _JSLIBSTR("extlang", "mar").substr(0, 3), _JSLIBSTR("extlang", "apr").substr(0, 3), _JSLIBSTR("extlang", "may").substr(0, 3), _JSLIBSTR("extlang", "jun").substr(0, 3), _JSLIBSTR("extlang", "jul").substr(0, 3), _JSLIBSTR("extlang", "aug").substr(0, 3), _JSLIBSTR("extlang", "sep").substr(0, 3), _JSLIBSTR("extlang", "oct").substr(0, 3), _JSLIBSTR("extlang", "nov").substr(0, 3), _JSLIBSTR("extlang", "dec").substr(0, 3)][(e + SYNO.SDS.StorageManager.monthOffset) % 12]
}, SYNO.SDS.StorageManager.getMonth = function(e) {
    return ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"][e % 12]
}, Ext.define("SYNO.SDS.StorageManager.HealthHistory", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t, i = this,
            s = [];
        i.owner = e.owner, i.appWin = e.appWin, i.device = e.device, i.isHaPanel = e.isHaPanel, i.is_target_ha_passive = e.is_target_ha_passive, i.healthTestHistoryPanel = new SYNO.SDS.StorageManager.HealthTestHistory({
            appWin: i.appWin,
            device: i.device,
            isHaPanel: i.isHaPanel,
            is_target_ha_passive: i.is_target_ha_passive
        }), s.push({
            xtype: "syno_fieldset",
            title: _T("disk_info", "disk_health_test_history_title"),
            bwrapCfg: {
                cls: "sm-health-history-field-wrap"
            },
            cls: "sm-health-history-fieldset",
            collapsible: !0,
            collapsed: !1,
            id: i.healthTestHistoryId = Ext.id(),
            items: i.healthTestHistoryPanel
        }), i.smartInfoHistoryPanel = new SYNO.SDS.StorageManager.SmartInfoHistory({
            appWin: i.appWin
        }), s.push({
            xtype: "syno_fieldset",
            title: _T("disk_info", "disk_smart_info_history_title"),
            cls: "sm-health-history-fieldset",
            collapsible: !0,
            collapsed: !0,
            id: i.smartInfoHistoryId = Ext.id(),
            items: i.smartInfoHistoryPanel
        }), t = Ext.apply({
            title: _T("disk_info", "disk_history_title"),
            dsmStyle: "v5",
            autoFlexcroll: !0,
            items: s,
            listeners: {
                activate: i.onActivate,
                scope: i
            }
        }, e), i.callParent([t]), i.mon(i, "resize", function(e, t) {
            var i = t - 20;
            e.healthTestHistoryPanel.setWidth(i), e.smartInfoHistoryPanel.setWidth(i), e.smartInfoHistoryPanel.chartResize(t - 16)
        }, i), i.mon(Ext.getCmp(i.healthTestHistoryId), "expand", function() {
            i.smartInfoHistoryPanel.setVisible(!1), Ext.getCmp(i.smartInfoHistoryId).collapse()
        }), i.mon(Ext.getCmp(i.smartInfoHistoryId), "expand", function() {
            i.smartInfoHistoryPanel.setVisible(!0), i.smartInfoHistoryPanel.drawChart(), Ext.getCmp(i.healthTestHistoryId).collapse()
        }, i), i.mon(Ext.getCmp(i.smartInfoHistoryId), "collapse", function() {
            i.smartInfoHistoryPanel.setVisible(!1)
        }, i)
    },
    onActivate: function() {
        var e = this;
        e.healthTestHistoryPanel.onActivate(), e.smartInfoSupport = !SYNO.SDS.StorageUtils.IsOnlySupportSas() && e.appWin.healthInfo.overview.isSataDisk, e.smartInfoSupport ? (Ext.getCmp(e.smartInfoHistoryId).setVisible(!0), e.smartInfoHistoryPanel.onActivate()) : Ext.getCmp(e.smartInfoHistoryId).setVisible(!1)
    }
}), Ext.define("SYNO.SDS.StorageManager.HealthPredictionHistory", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        this.chartData = null, this.historyData = null, this.appWin = e.appWin, this.device = e.device, this.needRefresh = !0, this.threshold = 0, this.HistoryChartInstance = null, this.validDataIndex = 0, this.chartLeft = 28;
        var t = SYNO.SDS.StorageManager.Disk.HISTORY_DAY_INTERVAL,
            i = SYNO.SDS.StorageManager.Disk.HISTORY_MONTH_INTERVAL,
            s = SYNO.SDS.StorageManager.Disk.HISTORY_SEASON_INTERVAL,
            a = SYNO.SDS.StorageManager.Disk.HISTORY_DAY_SKIP,
            n = SYNO.SDS.StorageManager.Disk.HISTORY_MONTH_SKIP,
            o = SYNO.SDS.StorageManager.Disk.HISTORY_YEAR_SKIP,
            r = SYNO.SDS.StorageManager.Disk.HISTORY_SEASON_SKIP,
            d = 15 * (t + 1) + a + 1,
            l = 6 * (i + 1) + n + 1,
            p = 12 * (i + 1) + o + 1,
            u = 12 * (s + 1) + r + 1;
        this.modeConfig = {
            one_month: {
                limit: d,
                interval: t,
                skip: a,
                type: "date"
            },
            six_month: {
                limit: l,
                interval: i,
                skip: n,
                type: "month"
            },
            one_year: {
                limit: p,
                interval: i,
                skip: o,
                type: "month"
            },
            three_year: {
                limit: u,
                interval: s,
                skip: r,
                type: "season"
            }
        };
        this.historyPanel = new Ext.Panel({
            width: 644,
            height: 197,
            border: !1,
            resizable: !0
        }), this.ModeLabel = new SYNO.ux.DisplayField({
            margins: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 20
            },
            cls: "sm-disk-health-combo-label",
            value: _T("rsrcmonitor", "time_range") + _T("common", "colon")
        }), this.ModeCombo = new SYNO.ux.ComboBox({
            displayField: "display",
            valueField: "value",
            value: this.modeConfig.one_month,
            width: 150,
            listWidth: 150,
            store: new Ext.data.ArrayStore({
                fields: ["value", "display"],
                data: [
                    [this.modeConfig.one_month, _T("time", "past_time_one_month")],
                    [this.modeConfig.six_month, _T("time", "past_time_six_month")],
                    [this.modeConfig.one_year, _T("time", "past_time_one_year")],
                    [this.modeConfig.three_year, _T("time", "past_time_three_year")]
                ]
            }),
            listeners: {
                select: {
                    scope: this,
                    fn: this.modeChange
                }
            }
        });
        var c = Ext.apply({
            tbar: {
                style: {
                    padding: "0px",
                    "margin-bottom": "6px"
                },
                items: ["->", this.ModeLabel, this.ModeCombo]
            },
            items: [this.historyPanel, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                height: 59,
                value: '<span class="syno-ux-note">' + _T("common", "note") + _T("common", "colon") + " </span>" + _T("disk_info", "disk_health_prediction_history_note")
            }]
        }, e);
        this.callParent([c])
    },
    genHistoryData: function(e, t, i) {
        function s(e, t, s) {
            var a = "";
            switch (t) {
                case "year":
                    a = e.getFullYear();
                    break;
                case "month":
                    a = SYNO.SDS.StorageManager.getMonth(e.getMonth());
                    break;
                case "day":
                    a = e.getDate();
                    break;
                default:
                    SYNO.Debug.error("Invalid mode type at xais data", i.type), a = ""
            }
            return {
                value: a,
                textStyle: {
                    fontSize: 12,
                    fontWeight: s ? "bold" : "normal"
                }
            }
        }
        var a, n, o, r, d, l = i.limit,
            p = [],
            u = 0,
            c = new Date,
            _ = i.interval + 1;
        c.setDate(c.getDate() - l), a = "date" === i.type ? c.getMonth() : c.getFullYear();
        for (var h = 0; h < l; h++) {
            var m, g = {};
            if (c.setDate(c.getDate() + 1), o = void 0, r = void 0, d = void 0, o = new Date(c), r = o.getMonth() + 1, d = o.getDate(), m = [o.getFullYear(), (r > 9 ? "" : "0") + r, (d > 9 ? "" : "0") + d].join("-"), g.ui_score = -100, g.observe = 0, m in e) {
                var S = e[m];
                g.ui_score = S.ui_score, g.observe = S.observe, g.factor = Ext.isEmpty(S.factor) ? null : SYNO.SDS.StorageUtils.DiskPredictionMainFactorRender(S.factor, this.appWin.healthInfo.smartInfo), g.fail = g.ui_score >= t ? 1 : 0, u = h
            }
            if (i.skip <= h && 0 == (h - i.skip) % _) {
                var f;
                switch (i.type) {
                    case "date":
                        f = (n = c.getMonth()) !== a ? s(c, "month", !0) : s(c, "day", !1), a = n;
                        break;
                    case "month":
                    case "season":
                        f = (n = c.getFullYear()) !== a ? s(c, "year", !0) : s(c, "month", !1), a = n;
                        break;
                    default:
                        SYNO.Debug.error("Invalid mode type at gen history data", i.type)
                }
                g.xData = f
            } else g.xData = "";
            g.time = m, p.push(g)
        }
        return {
            data: p,
            index: u
        }
    },
    loadHistoryData: function(e) {
        this.appWin.setStatusBusy(), this.appWin.sendWebAPI({
            api: "SYNO.Core.Storage.Disk",
            method: "disk_health_prediction_log_get",
            version: 1,
            params: {
                device: e.device,
                limit: e.mode.limit
            },
            scope: this,
            callback: function(t, i) {
                if (this.appWin.clearStatusBusy(), t) {
                    this.needRefresh = !1;
                    var s = this.genHistoryData(i.prediction_log, i.threshold, e.mode);
                    this.historyData = s.data, this.validDataIndex = s.index, this.threshold = i.threshold, this.drawChart()
                } else SYNO.Debug.error("Failed to get history data", i)
            }
        })
    },
    onActivate: function(e) {
        var t = this.ModeCombo.value;
        this.needRefresh && this.loadHistoryData({
            device: this.device,
            mode: t
        }), this.setDefaultTip()
    },
    modeChange: function() {
        this.loadHistoryData({
            device: this.device,
            mode: this.ModeCombo.value
        })
    },
    setDefaultTip: function() {
        null !== this.HistoryChartInstance && this.HistoryChartInstance.dispatchAction({
            type: "showTip",
            seriesIndex: 0,
            dataIndex: this.validDataIndex
        })
    },
    drawChart: function() {
        var e;
        this.HistoryChartInstance = echarts.init(this.historyPanel.body.dom), null !== this.historyData && !1 !== this.isVisible() && null !== this.HistoryChartInstance && (e = this.getChartOpt({
            title: _T("disk_info", "disk_health_prediction_history_yaxis"),
            chartData: this.historyData,
            threshold: this.threshold,
            mode: this.ModeCombo.value
        }), this.HistoryChartInstance.setOption(e), this.HistoryChartInstance.setOption(this.adjustChartConfig(this.threshold)), this.doLayout(), this.appWin.doLayout(), this.setDefaultTip())
    },
    chartResize: function(e) {
        var t = this;
        null !== t.HistoryChartInstance && (t.isDestroyed || (t.setWidth(e), t.historyPanel.setWidth(e), t.HistoryChartInstance.setOption(t.adjustChartConfig(t.threshold)), t.doLayout(), t.HistoryChartInstance.resize()))
    },
    adjustChartConfig: function(e) {
        var t = this,
            i = t.historyPanel.getWidth() - 1;
        return {
            series: [{
                markLine: {
                    data: [{
                        name: "danger_threshold",
                        yAxis: e,
                        x: t.chartLeft
                    }, {
                        yAxis: e,
                        x: i
                    }]
                },
                markArea: {
                    data: [
                        [{
                            x: t.chartLeft + 1
                        }, {
                            x: i - 1
                        }]
                    ]
                }
            }, {
                markLine: {
                    data: [{
                        yAxis: 100,
                        x: t.chartLeft
                    }, {
                        yAxis: 100,
                        x: i
                    }, {
                        yAxis: 0,
                        x: t.chartLeft
                    }, {
                        yAxis: 0,
                        x: i
                    }]
                }
            }]
        }
    },
    getChartOpt: function(e) {
        var t = e.chartData,
            i = this.chartLeft + 15,
            s = this.chartLeft,
            a = this.chartLeft + 9;
        return {
            grid: {
                top: 20,
                right: 17,
                left: i,
                bottom: 22
            },
            xAxis: {
                type: "category",
                data: t.map(function(e) {
                    return e.xData
                }),
                boundaryGap: !1,
                splitLine: {
                    show: !1
                },
                axisLabel: {
                    interval: 0,
                    color: "#323C46",
                    showMinLabel: !0,
                    showMaxLabel: !0,
                    margin: 6
                },
                axisLine: {
                    show: !1
                },
                axisTick: {
                    show: !1
                }
            },
            yAxis: [{
                type: "value",
                offset: 15,
                min: 0,
                max: 100,
                splitLine: {
                    show: !0,
                    lineStyle: {
                        color: "#C6D4E0",
                        width: 1
                    }
                },
                axisLabel: {
                    color: "#323C46",
                    margin: 6
                },
                axisLine: {
                    lineStyle: {
                        color: "#C6D4E0",
                        opacity: .7,
                        width: 1
                    }
                },
                axisTick: {
                    inside: !0,
                    length: 15,
                    lineStyle: {
                        color: "#C6D4E0",
                        width: 1
                    }
                }
            }, {
                type: "value",
                offset: 15,
                position: "right",
                min: 0,
                max: 100,
                axisLine: {
                    lineStyle: {
                        color: "#C6D4E0",
                        opacity: .7,
                        width: 1
                    }
                },
                axisLabel: {
                    show: !1
                },
                splitLine: {
                    show: !1
                },
                axisTick: {
                    inside: !0,
                    length: 15,
                    lineStyle: {
                        color: "#C6D4E0",
                        width: 1
                    }
                }
            }],
            tooltip: {
                trigger: "axis",
                position: [a, 28],
                transitionDuration: 0,
                backgroundColor: "rgba(255,255,255,0.85)",
                borderColor: "rgba(198,212,224,0.70)",
                borderWidth: 1,
                triggerOn: "mousemove|click",
                axisPointer: {
                    type: "line",
                    snap: !0,
                    lineStyle: {
                        color: "#315FCC"
                    }
                },
                padding: 0,
                formatter: function(e, i, s) {
                    if (null !== e) {
                        var a = t[e[0].dataIndex],
                            n = a.time.replace(new RegExp("-", "g"), "/"),
                            o = '<div class="sm-disk-health-tooltip-panel">',
                            r = '<p class="{0}">{1}</p>';
                        return o += String.format(r, "sm-disk-health-tooltip-date sm-font-bold", _T("time", "time_date") + _T("common", "colon") + " " + n), 0 > a.ui_score ? 0 === a.observe ? o += String.format(r, "sm-disk-health-tooltip-desc", _T("disk_info", "disk_prediction_main_factor_no_record")) : o += String.format(r, "sm-disk-health-tooltip-desc", _T("disk_info", "disk_prediction_main_factor_observe")) : (o += String.format(r, (1 === a.fail ? "sm-disk-health-tooltip-score-critical" : "sm-disk-health-tooltip-score-normal") + " sm-font-medium", _T("status", "header_value") + _T("common", "colon") + " " + Math.round(a.ui_score)), Ext.isEmpty(a.factor) || 1 !== a.fail || (o += '<div class="sm-disk-health-tooltip-top-hr"></div><div class="sm-disk-health-tooltip-bottom-hr"></div>', o += String.format(r, "sm-disk-health-tooltip-desc", a.factor))), o += "</div>"
                    }
                    SYNO.Debug.error("Invalid argument")
                }
            },
            series: [{
                data: t.map(function(e) {
                    return 0 <= e.ui_score ? e.ui_score : "-"
                }),
                type: "line",
                symbol: "none",
                lineStyle: {
                    width: 1
                },
                animation: !1,
                markLine: {
                    silent: !0,
                    animation: !1,
                    symbol: "none",
                    label: {
                        show: !1
                    },
                    lineStyle: {
                        type: "solid",
                        color: "#FC9B98",
                        width: 1
                    }
                },
                markArea: {
                    silent: !0,
                    animation: !1,
                    itemStyle: {
                        color: "#FAFCFF",
                        opacity: .6
                    }
                }
            }, {
                type: "line",
                markLine: {
                    silent: !0,
                    animation: !1,
                    symbol: "none",
                    label: {
                        show: !1
                    },
                    lineStyle: {
                        type: "solid",
                        color: "#C6D4E0",
                        width: 1
                    }
                }
            }],
            visualMap: {
                show: !1,
                pieces: [{
                    gt: 0,
                    lte: e.threshold,
                    color: "#009FD5"
                }],
                outOfRange: {
                    color: "#F94B4B"
                }
            },
            title: {
                text: e.title,
                top: 0,
                left: s,
                padding: 0,
                textStyle: {
                    color: "#323C46",
                    fontSize: 12,
                    verticalAlign: "middle",
                    align: "left",
                    lineHeight: 20
                }
            }
        }
    }
}), Ext.define("SYNO.SDS.StorageManager.SmartInfoHistory", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        this.chartData = null, this.appWin = e.appWin;
        var t = {
            width: 644,
            height: 158,
            border: !1,
            resizable: !0,
            style: {
                marginBottom: "18px"
            }
        };
        this.RemainLifePanel = new Ext.Panel(Ext.apply({
            id: this.remain_life_panel_id = Ext.id(),
            hidden: !0
        }, t)), this.UncPanel = new Ext.Panel(Ext.apply({
            id: this.unc_panel_id = Ext.id(),
            hidden: !0
        }, t)), this.RetryPanel = new Ext.Panel(t), this.IdnfPanel = new Ext.Panel(t), this.RemainLifeChartInstance = null, this.UncChartInstance = null, this.RetryChartInstance = null, this.IdnfChartInstance = null, this.ModeCombo = new SYNO.ux.ComboBox({
            displayField: "display",
            valueField: "value",
            value: "single",
            width: 150,
            listWidth: 150,
            store: new Ext.data.ArrayStore({
                fields: ["value", "display"],
                data: [
                    ["single", _T("disk_info", "disk_history_mode_sigle")],
                    ["incremental", _T("disk_info", "disk_history_mode_incremental")]
                ]
            }),
            listeners: {
                select: {
                    scope: this,
                    fn: this.modeChange
                }
            }
        });
        var i = Ext.apply({
            tbar: {
                style: {
                    padding: "0px",
                    "margin-bottom": "6px",
                    "border-style": "none"
                },
                items: ["->", this.ModeCombo]
            },
            items: [this.RemainLifePanel, this.UncPanel, this.RetryPanel, this.IdnfPanel]
        }, e);
        this.callParent([i])
    },
    onActivate: function(e) {
        var t = this.ModeCombo.value;
        this.appWin.healthInfo && this.appWin.healthInfo.history ? (this.chartData = this.appWin.healthInfo.history, this.displayData = "incremental" === t ? this.chartData.incremental : this.chartData.single, SYNO.SDS.StorageManager.monthOffset = this.displayData.offset, this.drawChart()) : this.appWin.getMsgBox().alert("", _T("status", "status_not_available"))
    },
    modeChange: function() {
        var e = this.ModeCombo.value;
        this.displayData = "incremental" === e ? this.chartData.incremental : this.chartData.single, this.drawChart()
    },
    showRemainLifePanel: function() {
        -1 !== this.appWin.healthInfo.overview.remain_life && "incremental" == this.ModeCombo.value ? Ext.getCmp(this.remain_life_panel_id).show() : Ext.getCmp(this.remain_life_panel_id).hide()
    },
    showUncPanel: function() {
        var e = !this.appWin.healthInfo.overview.isSsd;
        Ext.getCmp(this.unc_panel_id).setVisible(e)
    },
    genTicks: function() {
        var e = [],
            t = 0;
        for (t = 0; t < 12; t++) e.push(SYNO.SDS.StorageManager.convertToMonth(t));
        return e
    },
    genMouseTrack: function(e) {
        var t = SYNO.SDS.StorageManager.convertToMonth(e.x - 1) + ": " + e.y;
        return e.y < 0 && (t += "<br>" + _T("disk_info", "disk_history_unc_tooltip")), t
    },
    chartResize: function(e) {
        var t = this;
        t.isDestroyed || (t.setWidth(e), t.RemainLifePanel.setWidth(e), t.UncPanel.setWidth(e), t.RetryPanel.setWidth(e), t.IdnfPanel.setWidth(e), t.doLayout(), null !== t.RemainLifeChartInstance && t.RemainLifeChartInstance.resize(), null !== t.UncChartInstance && t.UncChartInstance.resize(), null !== t.RetryChartInstance && t.RetryChartInstance.resize(), null !== t.IdnfChartInstance && t.IdnfChartInstance.resize())
    },
    getChartOpt: function(e, t, i) {
        for (var s = 28 + 8 * (i.toString().length - 3), a = s, n = s + 9, o = 0, r = [], d = 0; d < t.length; d++) {
            var l = new Date;
            l.setMonth(SYNO.SDS.StorageManager.monthOffset - (t.length - d));
            var p = l.getMonth() + 1,
                u = [l.getFullYear(), (p > 9 ? "" : "0") + p].join("/");
            r.push([t[d][1], u]), o += void 0 !== t[d][1] ? 1 : 0
        }
        return {
            grid: {
                top: 20,
                left: s,
                bottom: 20,
                right: 2,
                backgroundColor: "#FAFCFF",
                show: !0
            },
            xAxis: {
                type: "category",
                data: this.genTicks(),
                splitNumber: 12,
                axisLine: {
                    show: !1
                },
                axisLabel: {
                    margin: 6
                },
                axisTick: {
                    show: !1
                }
            },
            yAxis: {
                type: "value",
                splitNumber: 5,
                max: function(e) {
                    return Math.max(e.max, 100)
                },
                min: 0
            },
            tooltip: {
                trigger: "axis",
                position: [n, 28],
                transitionDuration: 0,
                backgroundColor: "rgba(255,255,255,0.85)",
                borderColor: "rgba(198,212,224,0.70)",
                borderWidth: 1,
                triggerOn: "mousemove|click",
                axisPointer: {
                    type: "line",
                    lineStyle: {
                        color: "#E64040",
                        width: 1
                    }
                },
                padding: 0,
                formatter: function(e, t, i) {
                    if (null !== e) {
                        var s = r[e[0].dataIndex],
                            a = s[1],
                            n = s[0],
                            o = '<div class="sm-disk-health-tooltip-panel" style="width:110px">',
                            d = '<p class="{0}">{1}</p>';
                        if (s[0] || 0 == s[0]) return o += String.format(d, "sm-disk-health-tooltip-date sm-font-bold", _T("time", "time_date") + _T("common", "colon") + " " + a), o += String.format(d, "sm-disk-health-tooltip-score-normal sm-font-medium", _T("status", "header_value") + _T("common", "colon") + " " + Math.round(n)), o += "</div>"
                    } else SYNO.Debug.error("Invalid argument")
                }
            },
            series: {
                data: r.map(function(e) {
                    return e[0]
                }),
                type: "line",
                animation: !1,
                symbol: 1 < o ? "none" : "circle",
                symbolSize: 4,
                lineStyle: {
                    width: 1,
                    color: "#009FD5"
                },
                name: e.title,
                itemStyle: {
                    color: "#0086e5"
                }
            },
            title: {
                text: e.title,
                top: 0,
                left: a,
                padding: 0,
                textStyle: {
                    color: "#414B55",
                    fontSize: 12,
                    verticalAlign: "middle",
                    align: "left",
                    lineHeight: 20
                }
            }
        }
    },
    drawChart: function() {
        var e, t, i, s;
        if (this.showRemainLifePanel(), this.showUncPanel(), this.RetryChartInstance = echarts.init(this.RetryPanel.body.dom), this.IdnfChartInstance = echarts.init(this.IdnfPanel.body.dom), e = Math.max.apply(Math, [100].concat(_toConsumableArray(this.displayData.remainLife.map(function(e) {
                return e[1] || 0
            })), _toConsumableArray(this.displayData.unc.map(function(e) {
                return e[1] || 0
            })), _toConsumableArray(this.displayData.retry.map(function(e) {
                return e[1] || 0
            })), _toConsumableArray(this.displayData.idnf.map(function(e) {
                return e[1] || 0
            })))), null !== this.chartData && !1 !== this.isVisible() && null !== this.RetryChartInstance && null !== this.IdnfChartInstance) {
            for (var a = 0; a < this.displayData.remainLife.length; a++) - 1 == this.displayData.remainLife[a][1] && (this.displayData.remainLife[a][1] = null);
            if (Ext.getCmp(this.remain_life_panel_id).isVisible()) {
                if (this.RemainLifeChartInstance = echarts.init(this.RemainLifePanel.body.dom), null === this.RemainLifeChartInstance) return;
                var n = this.getChartOpt({
                    title: _T("disk_info", "disk_remain_life")
                }, this.displayData.remainLife, e);
                this.RemainLifeChartInstance.setOption(echarts.syno.getDefaultOptions()), this.RemainLifeChartInstance.setOption(n)
            }
            if (Ext.getCmp(this.unc_panel_id).isVisible()) {
                if (this.UncChartInstance = echarts.init(this.UncPanel.body.dom), null === this.UncChartInstance) return;
                t = this.getChartOpt({
                    title: _T("disk_info", "disk_bad_sector_ct")
                }, this.displayData.unc, e), this.UncChartInstance.setOption(echarts.syno.getDefaultOptions()), this.UncChartInstance.setOption(t)
            }
            i = this.getChartOpt({
                title: _T("disk_info", "disk_retry_ct")
            }, this.displayData.retry, e), this.RetryChartInstance.setOption(echarts.syno.getDefaultOptions()), this.RetryChartInstance.setOption(i), s = this.getChartOpt({
                title: _T("disk_info", "disk_identify_failed_ct")
            }, this.displayData.idnf, e), this.IdnfChartInstance.setOption(echarts.syno.getDefaultOptions()), this.IdnfChartInstance.setOption(s), this.doLayout(), this.appWin.doLayout()
        }
    }
}), Ext.define("SYNO.SDS.StorageManager.HealthTestHistory", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t = this,
            i = [
                ["all", _T("common", "show_all")],
                ["smart", _T("smart", "smart_toolbar_smart_test")]
            ];
        t.appWin = e.appWin, t.device = e.device, t.isHaPanel = e.isHaPanel, t.is_target_ha_passive = e.is_target_ha_passive, t.pageSize = 8, t.exportBtn = new SYNO.ux.SplitButton({
            text: _T("autoblock", "autoblock_export_ip_list"),
            handler: t.onExportHtml,
            disabled: !0,
            scope: t,
            menu: {
                items: [{
                    text: _T("log", "html_type"),
                    handler: t.onExportHtml,
                    scope: t
                }, {
                    text: _T("log", "csv_type"),
                    handler: t.onExportCSV,
                    scope: t
                }]
            }
        }), t.importBtn = new SYNO.ux.Button({
            text: _T("disk_info", "import_previous_data"),
            handler: t.onImportLog,
            scope: t,
            hidden: !0
        }), t.ModeCombo = new SYNO.ux.ComboBox({
            displayField: "display",
            valueField: "value",
            value: "all",
            width: 150,
            listWidth: 150,
            store: new Ext.data.ArrayStore({
                fields: ["value", "display"],
                data: i
            }),
            listeners: {
                select: {
                    scope: t,
                    fn: t.modeChange
                }
            }
        }), t.colModel = new Ext.grid.ColumnModel({
            defaults: {
                sortable: !1
            },
            columns: [{
                header: _T("time", "time_time"),
                dataIndex: "time",
                renderer: function(e) {
                    return SYNO.SDS.DateTimeFormatter(Date.parseDate(e, "Y/m/d H:i:s"), {
                        type: "datetimesec"
                    })
                }
            }, {
                header: _T("report", "report_type"),
                dataIndex: "displayType"
            }, {
                header: _T("smart", "smart_test_result"),
                dataIndex: "displayResult",
                renderer: function(e, t, i) {
                    return "ihm" === i.data.type && "ihm_000" !== i.data.result ? t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(i.data.tooltip) + '"' : t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(e) + '"', e
                }
            }]
        }), t.healthTestHistoryStore = t.createStore(e), t.gridPanel = new SYNO.ux.GridPanel({
            layout: "fit",
            colModel: t.colModel,
            store: t.healthTestHistoryStore,
            style: {
                paddingTop: "0px"
            },
            enableHdMenu: !1,
            disableSelection: !0,
            height: 274
        }), t.paging = new SYNO.ux.PagingToolbar({
            store: t.healthTestHistoryStore,
            pageSize: t.pageSize,
            displayInfo: !0,
            showRefreshBtn: !0
        });
        var s = Ext.apply({
            layout: "fit",
            tbar: {
                style: {
                    "border-style": "none"
                },
                items: [t.exportBtn, t.importBtn, "->", t.ModeCombo]
            },
            items: [t.gridPanel],
            bbar: t.paging
        }, e);
        t.callParent([s])
    },
    onRefreshConfig: function() {
        var e = this;
        e.appWin.setStatusBusy(), e.appWin.sendWebAPI(SYNO.SDS.StorageUtils.ReplaceWebapiSHA(this.is_target_ha_passive, {
            api: "SYNO.Core.Storage.Disk",
            method: "get_disk_log",
            version: 1,
            params: {
                type: "test"
            },
            scope: e,
            callback: function(t, i, s, a) {
                e.appWin.clearStatusBusy(), t ? e.importBtn.setVisible(i.exist_previous_log) : e.appWin.getMsgBox().alert("", _T("common", "error_system"))
            }
        }))
    },
    createStore: function(e) {
        var t, i = this,
            s = i.is_target_ha_passive ? "SYNO.SHA.Util" : "SYNO.Core.Storage.Disk",
            a = i.is_target_ha_passive ? "send_remote_webapi" : "disk_test_log_get";
        return t = i.is_target_ha_passive ? {
            remote_api: "SYNO.Core.Storage.Disk",
            remote_method: "disk_test_log_get",
            remote_version: "1",
            remote_params: {
                device: i.device,
                offset: 0,
                limit: i.pageSize,
                sort_by: "time",
                sort_direction: "DESC"
            }
        } : {
            device: i.device,
            offset: 0,
            limit: i.pageSize,
            sort_by: "time",
            sort_direction: "DESC"
        }, new SYNO.API.JsonStore({
            api: s,
            method: a,
            version: "1",
            autoDestroy: !0,
            remoteSort: !0,
            appWindow: e.appWin,
            baseParams: t,
            totalProperty: "total",
            root: "testLog",
            fields: ["id", "time", "type", "test_type", "result", {
                name: "displayType",
                convert: function(e, t) {
                    return i.onRenderTestType(t.type, t.test_type)
                }
            }, {
                name: "displayResult",
                convert: function(e, t) {
                    var i = SYNO.SDS.StorageUtils.DiskTestLogRender(t.result);
                    return i ? "" === i.code ? String.format('<span class="{0}">{1}</span>', i.color, i.text) : "unknown" === i.code ? String.format('<span class="{0}">{1}. {2}</span>', i.color, t.test_code, i.text) : String.format('<span class="{0}">{1}. {2}</span>', i.color, i.code, i.text) : ""
                }
            }, {
                name: "tooltip",
                convert: function(e, t) {
                    var i = SYNO.SDS.StorageUtils.DiskTestLogRender(t.result);
                    return i ? i.tooltip : ""
                }
            }],
            listeners: {
                scope: i,
                exception: i.onException
            }
        })
    },
    onException: function(e, t, i, s, a) {
        this.appWin.clearStatusBusy(), "LogFailed" === a.errors.reason ? this.appWin.setStatusError({
            text: _T("metadata", "metadata_err_enable"),
            clear: !0
        }) : "SerialFailed" === a.errors.reason ? this.appWin.setStatusError({
            text: _T("disk_info", "disk_log_event_retrieve_fail"),
            clear: !0
        }) : this.appWin.setStatusError({
            text: _T("error", "error_error_system"),
            clear: !0
        })
    },
    onActivate: function() {
        var e = this,
            t = [];
        t.push(["all", _T("common", "show_all")], ["smart", _T("smart", "smart_toolbar_smart_test")]), "not_support" !== e.appWin.healthInfo.overview.adv_status && t.push(["ihm", _T("disk_info", "disk_ironwolf_test")]), e.ModeCombo.store.loadData(t), e.mon(e.healthTestHistoryStore, "load", e.onAfterStoreLoad, e), e.mon(e.healthTestHistoryStore, "beforeload", e.onBeforeStoreLoad, e), e.is_target_ha_passive ? Ext.apply(e.healthTestHistoryStore.baseParams.remote_params, {
            type: e.ModeCombo.value
        }) : Ext.apply(e.healthTestHistoryStore.baseParams, {
            type: e.ModeCombo.value
        }), e.onRefreshConfig(), e.healthTestHistoryStore.load()
    },
    modeChange: function() {
        var e = this;
        e.is_target_ha_passive ? Ext.apply(e.healthTestHistoryStore.baseParams.remote_params, {
            type: e.ModeCombo.value
        }) : Ext.apply(e.healthTestHistoryStore.baseParams, {
            type: e.ModeCombo.value
        }), e.healthTestHistoryStore.load()
    },
    onAfterStoreLoad: function(e, t, i) {
        this.appWin.clearStatusBusy(), 0 < e.getCount() ? this.exportBtn.setDisabled(!1) : this.exportBtn.setDisabled(!0)
    },
    onBeforeStoreLoad: function(e, t) {
        this.appWin.setStatusBusy()
    },
    onRenderTestType: function(e, t) {
        return "smart" === e ? "quick" === t ? _T("smart", "smart_smart_quick_test") : "extend" === t ? _T("smart", "smart_smart_extend_test") : _T("disk_info", "disk_status_unknown") : "ihm" === e ? _T("disk_info", "disk_ironwolf_test") : _T("disk_info", "disk_status_unknown")
    },
    onExportHtml: function() {
        this.onExport("html")
    },
    onExportCSV: function() {
        this.onExport("csv")
    },
    onExport: function(e) {
        this.downloadWebAPI({
            webapi: SYNO.SDS.StorageUtils.ReplaceWebapiSHADownload(this.is_target_ha_passive, {
                api: "SYNO.Core.Storage.Disk",
                method: "export_test_log",
                version: 1,
                params: {
                    device: this.device,
                    type: e,
                    testType: this.ModeCombo.value
                }
            }),
            scope: this
        })
    },
    onImportLog: function() {
        var e = this,
            t = new SYNO.SDS.StorageManager.Wizard.ImportLog(Ext.apply({
                appWin: e.appWin,
                owner: e.owner,
                parentNode: e,
                type: "test"
            }));
        e.mon(t, "close", function() {
            Ext.isFunction(t.hideFromOwner) && t.hideFromOwner(), t.isDataChanged && (e.appWin.stopPollTask(), e.appWin.setStatusBusy(), e.appWin.cleanMask = !0, e.appWin.startPollTask())
        }, e, {
            single: !0
        }), t.open()
    }
}), Ext.define("SYNO.SDS.StorageManager.SmartInfoPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t = this;
        t.smartInfoBtn = new SYNO.ux.Button({
            text: _T("securityscan", "detail"),
            handler: function() {
                t.openSmartInfo()
            },
            scope: t
        });
        var i = Ext.apply({
            items: [{
                xtype: "syno_displayfield",
                style: {
                    marginBottom: "6px"
                },
                value: _T("disk_info", "disk_smart_info_desc")
            }, t.smartInfoBtn]
        }, e);
        t.callParent([i])
    },
    openSmartInfo: function() {
        var e = this;
        e.appWin && e.owner && e.appWin.healthInfo && e.appWin.healthInfo.overview ? (e.infoFormPanel = new SYNO.SDS.StorageManager.SmartInfo({
            owner: e.appWin,
            appWin: e.appWin,
            style: "padding: 0px 20px;",
            isNvme: e.appWin.healthInfo.overview.isNVMeDisk,
            height: 450
        }), e.infoDialog = new SYNO.SDS.ModalWindow({
            owner: e.appWin,
            dsmStyle: "v5",
            resizable: !1,
            width: 700,
            height: 510,
            hideLabel: !1,
            title: _T("smart", "smart_toolbar_smart_info"),
            buttons: [{
                text: _T("common", "alt_close"),
                scope: e,
                handler: function() {
                    e.infoDialog.close()
                }
            }],
            items: e.infoFormPanel
        }), e.infoDialog.open(), e.infoFormPanel.onActivate()) : SYNO.Debug.error("Invalid arguments", e)
    }
}), Ext.define("SYNO.SDS.StorageManager.SmartInfo", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t;
        this.owner = e.owner, this.appWin = e.appWin, t = e.isNvme ? this.configGridNvme({
            itemId: "grid"
        }) : this.configGrid({
            itemId: "grid"
        });
        var i = Ext.apply({
            title: _T("smart", "smart_toolbar_smart_info"),
            autoFlexcroll: !0,
            items: [{
                xtype: "syno_displayfield",
                itemId: "smartInfodesc",
                style: {
                    marginBottom: "12px"
                },
                value: !0 === e.isNvme ? _T("disk_info", "disk_smart_info_desc") : _T("disk_info", "disk_smart_info_detail_desc")
            }, t],
            listeners: {
                activate: this.onActivate,
                scope: this
            }
        }, e);
        this.callParent([i]), this.mon(this, "resize", function(e, t, i) {
            Ext.getCmp(e.smartInfoGridId).setWidth(t), e.onAdjustGridHeight()
        }, this)
    },
    configGrid: function(e) {
        return Ext.apply({
            layout: "fit",
            border: !1,
            xtype: "syno_gridpanel",
            columns: [{
                header: _T("smart", "smart_id"),
                dataIndex: "id",
                width: 50,
                sortable: !1
            }, {
                id: "name",
                header: _T("smart", "smart_attribute"),
                dataIndex: "name",
                width: 150,
                sortable: !1
            }, {
                header: _T("smart", "smart_current"),
                dataIndex: "current",
                width: 75,
                sortable: !1
            }, {
                header: _T("smart", "smart_worst"),
                dataIndex: "worst",
                width: 75,
                sortable: !1
            }, {
                header: _T("smart", "smart_threshold"),
                dataIndex: "threshold",
                width: 75,
                sortable: !1
            }, {
                header: _T("smart", "smart_raw"),
                dataIndex: "raw",
                width: 150,
                sortable: !1
            }],
            viewConfig: {
                forceFit: !0
            },
            enableHdMenu: !1,
            autoExpandColumn: "name",
            sm: new Ext.grid.RowSelectionModel,
            store: new Ext.data.JsonStore({
                root: "smartInfo",
                fields: ["id", "name", "current", "worst", "threshold", "raw"]
            }),
            id: this.smartInfoGridId = Ext.id()
        }, e)
    },
    configGridNvme: function(e) {
        return Ext.apply({
            layout: "fit",
            border: !1,
            xtype: "syno_gridpanel",
            style: {
                marginTop: "8px"
            },
            columns: [{
                id: "name",
                header: _T("smart", "smart_attribute"),
                dataIndex: "name",
                width: 150,
                sortable: !1
            }, {
                header: _T("smart", "smart_current"),
                dataIndex: "current",
                width: 75,
                sortable: !1
            }, {
                header: _T("volume", "volume_diskstatus"),
                dataIndex: "status",
                width: 75,
                sortable: !1,
                renderer: function(e, t, i) {
                    return "Airflow_Temperature_Cel" === i.get("name") && "In_the_past" === i.get("status") ? e : "OK" === i.get("status") ? e : '<font class="red-status"> ' + e + " </font>"
                }
            }],
            viewConfig: {
                forceFit: !0
            },
            enableHdMenu: !1,
            autoExpandColumn: "name",
            sm: new Ext.grid.RowSelectionModel,
            store: new Ext.data.JsonStore({
                root: "smartInfo",
                fields: ["name", "current", "status"]
            }),
            id: this.smartInfoGridId = Ext.id()
        }, e)
    },
    onActivate: function() {
        var e = this.getComponent("grid");
        this.appWin.healthInfo && this.appWin.healthInfo.smartInfo && this.appWin.healthInfo.overview ? (e.getStore().loadData(this.appWin.healthInfo), e.view.updateScroller(), this.onAdjustGridHeight()) : this.appWin.getMsgBox().alert("", _T("status", "status_not_available"))
    },
    onAdjustGridHeight: function() {
        var e;
        e = this.getHeight() - this.getComponent("smartInfodesc").getHeight() - 30, Ext.getCmp(this.smartInfoGridId).setHeight(e)
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.TaskPanel", {
    extend: "SYNO.ux.EditorGridPanel",
    btnEdit: null,
    btnDel: null,
    btnRun: null,
    constructor: function(e) {
        var t = this.fillConfig(e);
        this.callParent([Ext.apply(t, e)]), this.mon(this.getSelectionModel(), "selectionchange", this.onSelectionChange, this), this.btnEdit = this.getTopToolbar().getComponent("edit"), this.btnDel = this.getTopToolbar().getComponent("delete"), this.btnRun = this.getTopToolbar().getComponent("run"), this.loadData()
    },
    fillConfig: function(e) {
        this.appWin = e.appWin, this.adv_support = !1;
        for (var t = 0; t < this.appWin.disks.count; t++)
            if ("not_support" !== this.appWin.disks.dataArray[t].json.adv_status) {
                this.adv_support = !0;
                break
            } this.enableColumn = new SYNO.ux.EnableColumn({
            header: _T("common", "enabled"),
            dataIndex: "enabled",
            width: 50,
            align: "center",
            enableFastSelectAll: !0
        }), this.columnModel = new Ext.grid.ColumnModel([this.enableColumn, {
            header: _T("localbkp", "localbkp_bkpset_name"),
            dataIndex: "task_name",
            renderer: function(e) {
                var t = Ext.util.Format.htmlEncode(e);
                return '<div ext:qtip="' + Ext.util.Format.htmlEncode(t) + '">' + t + "</div>"
            },
            sortable: !0
        }, {
            header: _T("common", "action"),
            dataIndex: "action",
            renderer: function(e) {
                return e.replace(/#(.*?):(.*?)#/g, function(e, t, i) {
                    return _T(t, i)
                })
            }
        }, {
            header: _T("schedule", "next_trigger_time"),
            dataIndex: "next_trigger_time",
            renderer: function(e) {
                return SYNO.SDS.DateTimeFormatter(Date.parseDate(e, "Y-m-d H:i"))
            },
            align: "center",
            sortable: !0
        }]), this.taskStore = new SYNO.API.Store({
            api: "SYNO.Storage.CGI.Smart.Scheduler",
            method: "list",
            version: 1,
            appWindow: this.appWin,
            reader: new Ext.data.JsonReader({
                root: "items",
                totalProperty: "total"
            }, ["enabled", "id", "can_run", "task_name", "app_name", "simple_edit_form", "edit_form", "edit_app", "action", "next_trigger_time"]),
            sortInfo: {
                field: "id",
                direction: "ASC"
            },
            remoteSort: !1,
            pruneModifiedRecords: !0
        }), this.toolbar = new Ext.Toolbar({
            defaultType: "syno_button"
        }), this.toolbar.add({
            text: _T("common", "create"),
            itemId: "create",
            btnStyle: "blue",
            handler: this.onCreate,
            scope: this
        }, {
            text: _T("common", "alt_edit"),
            itemId: "edit",
            disabled: !0,
            handler: this.onEdit,
            scope: this
        }, {
            text: _T("common", "delete"),
            itemId: "delete",
            disabled: !0,
            handler: this.onDelete,
            scope: this
        }, {
            text: _T("common", "run"),
            itemId: "run",
            disabled: !0,
            handler: this.onRun,
            scope: this
        });
        var i = {
            title: _T("schedule", "task_scheduler"),
            header: !1,
            cm: this.columnModel,
            ds: this.taskStore,
            height: 225,
            tbar: this.toolbar,
            cls: "sm-test-schedule-tctab",
            style: {
                paddingTop: "0px"
            },
            bwrapCssClass: "sm-grid-no-border",
            autoScroll: !0,
            selModel: new Ext.grid.RowSelectionModel,
            plugins: [this.enableColumn]
        };
        return Ext.apply(i, e), i
    },
    isDirty: function() {
        return this.getStore().getModifiedRecords().length > 0
    },
    onSelectionChange: function() {
        var e = this.getSelectionModel().getCount();
        0 < e ? (this.btnDel.enable(), this.btnRun.enable()) : (this.btnDel.disable(), this.btnRun.disable()), 1 == e ? this.btnEdit.enable() : this.btnEdit.disable()
    },
    loadData: function() {
        this.taskStore.removeAll(), this.taskStore.load()
    },
    onOpenEditDialog: function(e) {
        new SYNO.SDS.StorageManager.Wizard.EditDialog({
            owner: this.owner,
            owner_grid: this,
            disks: this.owner.disks,
            schedule_id: e,
            basic_limitation: !1,
            adv_support: this.adv_support,
            test_type: "all"
        }).open()
    },
    onCreate: function() {
        this.onOpenEditDialog(-1)
    },
    onEdit: function() {
        var e = this.getSelectionModel().getSelections();
        this.onOpenEditDialog(e[0].id)
    },
    getApplyApiCfg: function() {
        var e = [],
            t = this.getStore().getModifiedRecords();
        if (0 !== t.length) {
            for (var i = 0; i < t.length; ++i) e.push({
                id: t[i].data.id,
                enabled: t[i].data.enabled
            });
            return {
                api: "SYNO.Storage.CGI.Smart.Scheduler",
                method: "change_state",
                version: 1,
                params: {
                    tasks: e
                }
            }
        }
    },
    applyCallback: function(e, t) {
        this.getStore().commitChanges(), this.loadData()
    },
    onDelete: function() {
        for (var e = this, t = e.getSelectionModel().getSelections(), i = [], s = [], a = null, n = 0; n < t.length; n++) {
            var o = t[n].data;
            i.push(o.task_name), s.push(o.id)
        }(a && !a.isDestroyed || (a = new SYNO.SDS.MessageBoxV5({
            renderTo: e.owner.body
        })), a.getWrapper()).confirmDelete("", _T("schedule", "confirm_delete_task") + "<br>" + i.join(", "), function(t) {
            if ("yes" === t) {
                var i = {
                    tasks: s
                };
                e.owner.setStatusBusy(), e.sendWebAPI({
                    api: "SYNO.Storage.CGI.Smart.Scheduler",
                    method: "delete",
                    version: 1,
                    params: i,
                    scope: e,
                    callback: function() {
                        e.loadData(), e.owner.clearStatusBusy()
                    }
                })
            }
        })
    },
    onRun: function() {
        for (var e = this.getSelectionModel().getSelections(), t = ":", i = 0; i < e.length; ++i) 0 !== i && (t += ","), t += " " + e[i].data.task_name;
        this.owner.getMsgBox().confirm(_T("schedule", "run_task"), _T("schedule", "confirm_run_task") + t, this.runTasks, this)
    },
    runTasks: function(e) {
        if ("no" !== e) {
            var t = this.getSelectionModel().getSelections(),
                i = [],
                s = 0;
            for (s = 0; s < t.length; ++s) i.push(t[s].id);
            var a = {
                tasks: i
            };
            this.owner.setStatusBusy(), this.appWin.sendWebAPI({
                api: "SYNO.Storage.CGI.Smart.Scheduler",
                method: "run",
                version: 1,
                params: a,
                scope: this,
                callback: function() {
                    this.loadData(), this.owner.clearStatusBusy()
                }
            })
        }
    },
    validate: function() {
        return !0
    },
    reset: function() {
        Ext.isDefined(this.taskStore.reader.jsonData) && this.taskStore.loadData(this.taskStore.reader.jsonData)
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.EditDialog", {
    extend: "SYNO.SDS.ModalWindow",
    EditPanelBasic: null,
    EditPanelSchedule: null,
    tabpanel: null,
    constructor: function(e) {
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        this.EditPanelBasic = new SYNO.SDS.StorageManager.Disk.Dialog.EditBasicPanel({
            owner: this,
            diskMap: e.diskMap,
            adv_support: e.adv_support,
            test_type: e.test_type
        }), this.EditPanelSchedule = new SYNO.SDS.TaskScheduler2.EditSchedulePanel({
            needTitle: !0
        }), this.tabpanel = new SYNO.ux.TabPanel({
            activeTab: 0,
            height: 450,
            items: [this.EditPanelBasic, this.EditPanelSchedule]
        });
        var t = {
            title: -1 == e.schedule_id ? _T("schedule", "create_task") : _T("schedule", "edit_task"),
            width: 550,
            minWidth: 550,
            autoHeight: !0,
            items: this.tabpanel,
            dsmStyle: "v5",
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                btnStyle: "gray",
                handler: this.onClickCancel
            }, {
                text: _T("common", "apply"),
                scope: this,
                btnStyle: "blue",
                handler: this.onClickOK
            }],
            listeners: {
                beforeclose: this.onBeforeClose.bind(this)
            },
            forceClose: !1
        };
        return Ext.apply(t, e), t
    },
    onClickOK: function() {
        if (this.EditPanelBasic.isValid() && this.EditPanelSchedule.isValid()) {
            var e = {
                basic: this.EditPanelBasic.getData(),
                schedule: this.EditPanelSchedule.getData(),
                app: this.EditPanelBasic.getData()
            };
            e.schedule = this.scheduleToOld(e.schedule), this.setStatusBusy(), this.sendWebAPI({
                api: "SYNO.Storage.CGI.Smart.Scheduler",
                method: "set",
                version: 1,
                params: e,
                scope: this,
                callback: this.applyDone
            })
        } else this.tabpanel.setActiveTab(this.EditPanelBasic.isValid() ? this.EditPanelSchedule : this.EditPanelBasic)
    },
    applyDone: function(e, t) {
        this.clearStatusBusy(), this.owner_grid.loadData(), e ? (null !== this.caller && void 0 !== this.caller && this.caller.appWin && this.caller.appWin.healthOverviewPanel && this.caller.appWin.healthOverviewPanel.onHealthInfoRefresh({
            device: this.caller.device
        }), this.forceClose = !0, this.close()) : ("name repeat" === t.errors.reason && (this.tabpanel.setActiveTab(this.EditPanelBasic), this.EditPanelBasic.getForm().findField("task_name").markInvalid(_T("schedule", "msg_duplicate_name"))), this.setStatusError({
            text: _T("common", "forminvalid"),
            clear: !0
        }))
    },
    onClickCancel: function() {
        this.close()
    },
    onBeforeClose: function() {
        var e = this;
        return !(!e.forceClose && (e.EditPanelBasic.isDirty() || e.EditPanelSchedule.getForm().isDirty())) || (e.confirmLostChangePromise({
            save: function() {
                e.onClickOK()
            },
            dontSave: function() {
                e.forceClose = !0, e.close()
            },
            cancel: Ext.emptyFn
        }, e), !1)
    },
    onOpen: function() {
        this.loadTask(this.schedule_id), this.callParent(arguments)
    },
    loadTask: function(e) {
        this.setStatusBusy(), this.sendWebAPI({
            api: "SYNO.Storage.CGI.Smart.Scheduler",
            method: "get",
            version: 1,
            params: {
                id: e
            },
            scope: this,
            callback: function(e, t) {
                this.clearStatusBusy(), e ? (this.respTask = t.task[0], this.EditPanelBasic.setDataBasic(this.respTask.basic), this.EditPanelBasic.setDataApp(this.respTask.app), this.EditPanelBasic.initialDataSetting(), this.EditPanelSchedule.setData(this.scheduleToNew(this.respTask.schedule))) : this.getMsgBox().alert("", _T("schedule", "load_task_error"), function() {
                    this.close()
                }, this)
            }
        })
    },
    scheduleToNew: function(e) {
        return e.hasOwnProperty("week_name") && (e.week_day = e.week_name, delete e.week_name), e.hasOwnProperty("repeat") && (e.repeat_data = e.repeat, e.repeat_date = e.repeat, delete e.repeat), e.hasOwnProperty("min") && (e.minute = e.min, delete e.min), e
    },
    scheduleToOld: function(e) {
        return e.hasOwnProperty("week_day") && (e.week_name = e.week_day, delete e.week_day), e.hasOwnProperty("repeat_data") && (e.repeat = e.repeat_data, delete e.repeat_data), e.hasOwnProperty("minute") && (e.min = e.minute, delete e.minute), e.hasOwnProperty("repeat_date") && (e.repeat = e.repeat_date, delete e.repeat_date), e
    }
}), Ext.define("SYNO.SDS.StorageManager.Disk.Dialog.EditBasicPanel", {
    extend: "SYNO.ux.FormPanel",
    DataSetting: null,
    constructor: function(e) {
        this.owner = e.owner, this.diskMap = e.diskMap, this.adv_support = e.adv_support, this.test_type = e.test_type;
        var t = this.fillConfig(e);
        this.callParent([t]), this.mon(Ext.getCmp(this.selected_disks_id), "additem", this.diskStoreSort, this), this.mon(Ext.getCmp(this.selected_disks_id), "removeitem", this.diskStoreSort, this), this.mon(Ext.getCmp(this.selected_adv_disks_id), "additem", this.advDiskStoreSort, this), this.mon(Ext.getCmp(this.selected_adv_disks_id), "removeitem", this.advDiskStoreSort, this), this.displayGeneralSettings()
    },
    fillConfig: function(e) {
        var t = this.displayNameGet.createDelegate(this);
        this.owner_store = new Ext.data.Store({
            reader: new Ext.data.JsonReader({
                root: "owner_store"
            }, ["display"])
        }), this.disk_store = new Ext.data.Store({
            reader: new Ext.data.JsonReader({
                root: "disk_store"
            }, [{
                name: "device",
                mapping: "device"
            }, {
                name: "id",
                mapping: "id"
            }, {
                name: "i18nNamingInfo",
                convert: t
            }, {
                name: "ctnOrder",
                mapping: "container.order"
            }, {
                name: "numId",
                mapping: "num_id"
            }, {
                name: "portType",
                mapping: "portType"
            }, {
                name: "smart_test_limit",
                mapping: "smart_test_limit"
            }, {
                name: "serial",
                mapping: "serial"
            }]),
            listeners: {
                load: this.onStoreLoad,
                scope: this
            }
        }), this.adv_disk_store = new Ext.data.Store({
            reader: new Ext.data.JsonReader({
                root: "disk_store"
            }, [{
                name: "device",
                mapping: "device"
            }, {
                name: "id",
                mapping: "id"
            }, {
                name: "i18nNamingInfo",
                convert: t
            }, {
                name: "ctnOrder",
                mapping: "container.order"
            }, {
                name: "numId",
                mapping: "num_id"
            }, {
                name: "portType",
                mapping: "portType"
            }, {
                name: "serial",
                mapping: "serial"
            }])
        });
        var i = {
            title: _T("schedule", "basic_info"),
            items: [{
                xtype: "syno_fieldset",
                title: _T("vpnc", "basic_setting"),
                items: [{
                    xtype: "syno_displayfield",
                    hidden: !0,
                    id: this.test_type_smart_desc_id = Ext.id(),
                    fieldLabel: _T("disk_info", "disk_test_task_type"),
                    value: _T("smart", "smart_name")
                }, {
                    xtype: "syno_displayfield",
                    hidden: !0,
                    id: this.test_type_adv_desc_id = Ext.id(),
                    fieldLabel: _T("disk_info", "disk_test_task_type"),
                    value: _T("disk_info", "disk_ironwolf_health")
                }, {
                    xtype: "syno_radio",
                    boxLabel: _T("smart", "smart_name"),
                    name: "test_type",
                    id: this.test_type_smart_id = Ext.id(),
                    inputValue: "smart",
                    fieldLabel: _T("disk_info", "disk_test_task_type"),
                    hideLabel: !1,
                    listeners: {
                        check: function(e, t) {
                            t && this.refreshPage("smart")
                        },
                        scope: this
                    }
                }, {
                    xtype: "syno_radio",
                    boxLabel: _T("disk_info", "disk_ironwolf_health"),
                    name: "test_type",
                    id: this.test_type_adv_id = Ext.id(),
                    inputValue: "adv",
                    hidden: !0,
                    fieldLabel: "adv" === this.test_type ? _T("disk_info", "disk_test_task_type") : "",
                    hideLabel: !1,
                    listeners: {
                        check: function(e, t) {
                            t && this.refreshPage("adv")
                        },
                        scope: this
                    }
                }, {
                    xtype: "syno_radio",
                    boxLabel: _T("schedule", "event_all"),
                    name: "test_type",
                    id: this.test_type_all_id = Ext.id(),
                    inputValue: "all",
                    checked: !0,
                    hidden: !0,
                    hideLabel: !1,
                    listeners: {
                        check: function(e, t) {
                            t && this.refreshPage("all")
                        },
                        scope: this
                    }
                }, {
                    xtype: "syno_textfield",
                    allowBlank: !1,
                    emptyText: "Task name",
                    id: this.task_name_id = Ext.id(),
                    fieldLabel: _T("s2s", "s2s_lbl_task_name"),
                    name: "task_name",
                    width: 200,
                    itemId: "task_name",
                    validator: function(e) {
                        return e == Ext.util.Format.stripTags(e)
                    }
                }, {
                    xtype: "hidden",
                    name: "id"
                }, {
                    xtype: "syno_combobox",
                    hidden: !0,
                    triggerAction: "all",
                    width: 200,
                    id: this.task_owner_id = Ext.id(),
                    listWidth: 200,
                    fieldLabel: _T("common", "owner"),
                    name: "owner",
                    hiddenName: "owner",
                    itemId: "owner",
                    editable: !1,
                    valueField: "display",
                    displayField: "display",
                    disabled: !0,
                    mode: "local",
                    store: this.owner_store
                }, {
                    xtype: "syno_checkbox",
                    hidden: !0,
                    boxLabel: _T("common", "enabled"),
                    name: "enabled",
                    itemId: "enabled"
                }]
            }, {
                xtype: "syno_fieldset",
                title: _T("schedule", "smart_schedule_type"),
                id: this.smart_test_type_id = Ext.id(),
                items: [{
                    xtype: "syno_radio",
                    boxLabel: _T("smart", "smart_quick_test"),
                    id: this.test_style_quick = Ext.id(),
                    checked: !0,
                    name: "test_style",
                    inputValue: "quick"
                }, {
                    xtype: "syno_radio",
                    boxLabel: _T("smart", "smart_extend_test"),
                    id: this.test_style_extend = Ext.id(),
                    name: "test_style",
                    inputValue: "extend"
                }]
            }, {
                xtype: "syno_fieldset",
                title: _T("schedule", "smart_schedule_range"),
                id: this.test_range_id = Ext.id(),
                items: [{
                    xtype: "syno_radio",
                    boxLabel: _T("disk_info", "disk_test_all_support_disk"),
                    id: this.test_range_all = Ext.id(),
                    name: "test_range",
                    inputValue: "all",
                    listeners: {
                        check: function(e, t) {
                            t ? Ext.getCmp(this.selected_disks_id).setDisabled(!0) : Ext.getCmp(this.selected_disks_id).setDisabled(!1)
                        },
                        scope: this
                    }
                }, {
                    xtype: "syno_radio",
                    boxLabel: _T("schedule", "smart_schedule_apply_sel"),
                    id: this.test_range_sel = Ext.id(),
                    name: "test_range",
                    inputValue: "sel",
                    scope: this
                }, {
                    xtype: "syno_superboxselect",
                    hideLabel: !0,
                    fieldLabel: "",
                    displayField: "i18nNamingInfo",
                    id: this.selected_disks_id = Ext.id(),
                    resizable: !0,
                    valueField: "serial",
                    name: "selected_disks",
                    triggerAction: "all",
                    mode: "local",
                    store: this.disk_store
                }]
            }, {
                xtype: "syno_fieldset",
                title: _T("disk_info", "disk_ironwolf_test"),
                id: this.test_adv_range_id = Ext.id(),
                items: [{
                    xtype: "syno_radio",
                    boxLabel: _T("disk_info", "disk_adv_test_all_support_disk"),
                    id: this.adv_test_range_all = Ext.id(),
                    name: "adv_test_range",
                    inputValue: "all",
                    listeners: {
                        check: function(e, t) {
                            t ? Ext.getCmp(this.selected_adv_disks_id).setDisabled(!0) : Ext.getCmp(this.selected_adv_disks_id).setDisabled(!1)
                        },
                        scope: this
                    }
                }, {
                    xtype: "syno_radio",
                    boxLabel: _T("schedule", "smart_schedule_apply_sel"),
                    id: this.adv_test_range_sel = Ext.id(),
                    name: "adv_test_range",
                    inputValue: "sel",
                    scope: this
                }, {
                    xtype: "syno_superboxselect",
                    hideLabel: !0,
                    fieldLabel: "",
                    displayField: "i18nNamingInfo",
                    id: this.selected_adv_disks_id = Ext.id(),
                    resizable: !0,
                    valueField: "serial",
                    name: "selected_adv_disks",
                    triggerAction: "all",
                    mode: "local",
                    store: this.adv_disk_store
                }]
            }]
        };
        return Ext.apply(i, e), i
    },
    displayNameGet: function(e, t) {
        var i = this.diskMap[t.id];
        return SYNO.SDS.StorageUtils.DiskDisplayNameGet(i)
    },
    isDirty: function() {
        var e = this.getForm().getValues(),
            t = Object.getOwnPropertyNames(Object.assign({}, e)),
            i = !1,
            s = !0,
            a = !1,
            n = void 0;
        try {
            for (var o, r = t[Symbol.iterator](); !(s = (o = r.next()).done); s = !0) {
                var d = o.value;
                if ("object" !== _typeof(e[d]) && e[d] != this.DataSetting[d]) {
                    i = !0;
                    break
                }
                if ("object" === _typeof(e[d]) && e[d].valueOf() != this.DataSetting[d].valueOf()) {
                    i = !0;
                    break
                }
            }
        } catch (e) {
            a = !0, n = e
        } finally {
            try {
                s || null == r.return || r.return()
            } finally {
                if (a) throw n
            }
        }
        return i
    },
    getData: function() {
        return this.getForm().getValues()
    },
    setDataBasic: function(e) {
        this.owner_store.loadData(e), this.getForm().setValues(e)
    },
    initialDataSetting: function(e) {
        this.DataSetting || (this.DataSetting = this.getForm().getValues())
    },
    displayGeneralSettings: function() {
        "smart" !== this.test_type && this.adv_support ? "adv" === this.test_type ? (Ext.getCmp(this.test_type_smart_desc_id).setVisible(!1), Ext.getCmp(this.test_type_adv_desc_id).setVisible(!0), Ext.getCmp(this.test_type_smart_id).setVisible(!1), Ext.getCmp(this.test_type_adv_id).setVisible(!1), Ext.getCmp(this.test_type_all_id).setVisible(!1)) : (Ext.getCmp(this.test_type_smart_desc_id).setVisible(!1), Ext.getCmp(this.test_type_adv_desc_id).setVisible(!1), Ext.getCmp(this.test_type_smart_id).setVisible(!0), Ext.getCmp(this.test_type_adv_id).setVisible(!0), Ext.getCmp(this.test_type_all_id).setVisible(!0)) : (Ext.getCmp(this.test_type_smart_desc_id).setVisible(!0), Ext.getCmp(this.test_type_adv_desc_id).setVisible(!1), Ext.getCmp(this.test_type_smart_id).setVisible(!1), Ext.getCmp(this.test_type_adv_id).setVisible(!1), Ext.getCmp(this.test_type_all_id).setVisible(!1))
    },
    setDataApp: function(e) {
        var t = [],
            i = e;
        this.displayGeneralSettings(), "extend" === e.test_style ? Ext.getCmp(this.test_style_extend).setValue(!0) : Ext.getCmp(this.test_style_quick).setValue(!0), (Ext.getCmp(this.test_type_smart_id).isVisible() || Ext.getCmp(this.test_type_smart_desc_id).isVisible()) && (this.disk_store.loadData(e), this.diskStoreSort()), (Ext.getCmp(this.test_type_adv_id).isVisible() || Ext.getCmp(this.test_type_adv_desc_id).isVisible()) && (Ext.each(e.disk_store, function(e) {
            "not_support" !== e.adv_status && t.push(e)
        }), i.disk_store = t, this.adv_disk_store.loadData(i), this.advDiskStoreSort()), this.refreshPage(e.test_type), e.selected_disks && Ext.getCmp(this.selected_disks_id).setValue(e.selected_disks), "all" === e.test_range ? (Ext.getCmp(this.test_range_all).setValue(!0), Ext.getCmp(this.selected_disks_id).setDisabled(!0)) : (Ext.getCmp(this.test_range_sel).setValue(!0), Ext.getCmp(this.selected_disks_id).setDisabled(!1)), e.selected_adv_disks && Ext.getCmp(this.selected_adv_disks_id).setValue(e.selected_adv_disks), "all" === e.adv_test_range ? (Ext.getCmp(this.adv_test_range_all).setValue(!0), Ext.getCmp(this.selected_adv_disks_id).setDisabled(!0)) : (Ext.getCmp(this.adv_test_range_sel).setValue(!0), Ext.getCmp(this.selected_adv_disks_id).setDisabled(!1))
    },
    refreshPage: function(e) {
        void 0 === e && (e = "smart" !== this.test_type && this.adv_support ? "adv" === this.test_type ? "adv" : "all" : "smart"), "smart" === e ? (Ext.getCmp(this.test_type_smart_id).setValue(!0), Ext.getCmp(this.smart_test_type_id).setVisible(!0), Ext.getCmp(this.test_range_id).setVisible(!0), Ext.getCmp(this.test_range_all).setVisible(!0), Ext.getCmp(this.test_range_sel).setVisible(!0), Ext.getCmp(this.selected_disks_id).setVisible(!0), Ext.getCmp(this.test_adv_range_id).setVisible(!1), Ext.getCmp(this.adv_test_range_all).setVisible(!1), Ext.getCmp(this.adv_test_range_sel).setVisible(!1), Ext.getCmp(this.selected_adv_disks_id).setVisible(!1)) : "adv" === e ? (Ext.getCmp(this.test_type_adv_id).setValue(!0), Ext.getCmp(this.smart_test_type_id).setVisible(!1), Ext.getCmp(this.test_range_id).setVisible(!1), Ext.getCmp(this.test_range_all).setVisible(!1), Ext.getCmp(this.test_range_sel).setVisible(!1), Ext.getCmp(this.selected_disks_id).setVisible(!1), Ext.getCmp(this.test_adv_range_id).setVisible(!0), Ext.getCmp(this.adv_test_range_all).setVisible(!0), Ext.getCmp(this.adv_test_range_sel).setVisible(!0), Ext.getCmp(this.selected_adv_disks_id).setVisible(!0)) : "all" === e && (Ext.getCmp(this.test_type_all_id).setValue(!0), Ext.getCmp(this.smart_test_type_id).setVisible(!0), Ext.getCmp(this.test_range_id).setVisible(!0), Ext.getCmp(this.test_range_all).setVisible(!0), Ext.getCmp(this.test_range_sel).setVisible(!0), Ext.getCmp(this.selected_disks_id).setVisible(!0), Ext.getCmp(this.test_adv_range_id).setVisible(!0), Ext.getCmp(this.adv_test_range_all).setVisible(!0), Ext.getCmp(this.adv_test_range_sel).setVisible(!0), Ext.getCmp(this.selected_adv_disks_id).setVisible(!0)), this.doLayout()
    },
    isValid: function() {
        var e = this,
            t = !1;
        return Ext.getCmp(e.task_name_id).isValid() || (t = !0), Ext.getCmp(e.test_range_sel).getValue() && Ext.getCmp(e.selected_disks_id).isVisible() && "" === Ext.getCmp(e.selected_disks_id).getValue() && (Ext.getCmp(e.selected_disks_id).markInvalid(_T("volume", "volume_add_warningnodisk")), t = !0), Ext.getCmp(e.adv_test_range_sel).getValue() && Ext.getCmp(e.selected_adv_disks_id).isVisible() && "" === Ext.getCmp(e.selected_adv_disks_id).getValue() && (Ext.getCmp(e.selected_adv_disks_id).markInvalid(_T("volume", "volume_add_warningnodisk")), t = !0), !t || (e.owner.setStatusError({
            text: _T("error", "error_bad_field"),
            clear: !0
        }), !1)
    },
    diskStoreSort: function() {
        this.disk_store.sort([{
            field: "ctnOrder",
            direction: "ASC"
        }, {
            field: "portType",
            direction: "DESC"
        }, {
            field: "numId",
            direction: "ASC"
        }], "ASC")
    },
    advDiskStoreSort: function() {
        this.adv_disk_store.sort([{
            field: "ctnOrder",
            direction: "ASC"
        }, {
            field: "portType",
            direction: "DESC"
        }, {
            field: "numId",
            direction: "ASC"
        }], "ASC")
    },
    onStoreLoad: function(e, t) {
        e.filterBy(function(e) {
            return !e.get("smart_test_limit")
        }), delete e.snapshot
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.Benchmark", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t, i = this;
        i.owner = e.owner, i.appWin = e.appWin, i.disks = e.disks, i.selectIdx = e.selectIdx, i.pollingId = void 0, i.processing = !1, i.diskPerf = new Ext.DataView({
            tpl: new Ext.XTemplate('<tpl for=".">', '<div class="sm-disk-perf-status">', '<div id="prev-btn-id"></div>', '<div class="sm-disk-perf-disk-icon"></div>', '<div class="sm-disk-perf-textarea">', '<div class="sm-disk-perf-title">{text}</div>', '<div class="sm-disk-perf-desc">', "{diskVendor} {diskModel}</br>", '<div class="sm-disk-perf-desc-label">{latestLabel}:</div>{latestValue}</br>', '<div class="sm-disk-perf-desc-label">{compareLabel}:</div>{compareValue}</br>', '<div class="sm-disk-perf-desc-label">{typeLabel}:</div>{typeValue}</br>', "</div>", '<div id="run-test-btn-id"></div>', "</div>", '<div id="next-btn-id"></div>', "</div>", "</tpl>"),
            store: i.perfStore = new Ext.data.JsonStore({
                autoDestroy: !0,
                fields: ["text", "latestLabel", "latestValue", "compareLabel", "compareValue", "typeLabel", "typeValue", "diskVendor", "diskModel"]
            })
        });
        var s = '<div class="sm-disk-perf-result-box-{position}"><div class="sm-disk-perf-result-box-title sm-font-bold">{title}</div><div class="sm-disk-perf-result-box-content"><div class="sm-disk-perf-result-box-content-value sm-disk-perf-result-box-content-value-{contentStatus}" data-unit="{unit}">{value}</div></div><div class="sm-disk-perf-result-box-status"><div class="sm-disk-perf-result-box-status-icon sm-disk-perf-result-box-status-icon-{direction}-{status}"></div><div class="sm-disk-perf-result-box-status-value sm-disk-perf-result-box-status-value-{status}">{comparison}</div></div></div>';
        i.diskPerfResult = new Ext.DataView({
            tpl: new Ext.XTemplate('<tpl for=".">', '<div class="sm-disk-perf-fieldset">{readTitle}</div>', '<div class="sm-disk-perf-result-box" style="margin-bottom: 16px;">', '<tpl for="diskReadPerf">', s, "</tpl>", "</div>", '<div class="sm-disk-perf-fieldset">{writeTitle}', '<span class="sm-tip-placeholder" tip="{writeInfo}"></span>', "</div>", '<div class="sm-disk-perf-result-box" style="margin-bottom: 20px;">', '<tpl for="diskWritePerf">', s, "</tpl>", "</div>", "</tpl>"),
            store: i.perfResultStore = new Ext.data.JsonStore({
                autoDestroy: !0,
                fields: ["readTitle", "writeTitle", "writeInfo", "diskReadPerf", "diskWritePerf"]
            })
        }), t = Ext.apply({
            title: _T("disk_info", "disk_perf_benchmark"),
            width: 660,
            height: 610,
            minWidth: 660,
            minHeight: 610,
            dsmStyle: "v5",
            layout: "fit",
            resizable: !1,
            items: [{
                xtype: "syno_formpanel",
                trackResetOnLoad: !0,
                border: !1,
                items: [i.diskPerf, i.diskPerfResult]
            }],
            buttons: [{
                text: _T("common", "alt_close"),
                handler: i.close,
                scope: i
            }],
            listeners: {
                beforedestroy: i.pollingTaskStop,
                scope: i
            }
        }, e), i.callParent([t])
    },
    onOpen: function() {
        for (var e = this, t = 0; t < e.disks.length; t++) e.disks[t].selectCompareLog = !1, e.disks[t].selectIdx = -1, e.disks[t].compareLog = {
            time: "-",
            testType: "-",
            readIopsValue: 0,
            readBwValue: 0,
            readBwUnit: "",
            readLatencyValue: 0,
            readLatencyUnit: "",
            writeIopsValue: 0,
            writeBwValue: 0,
            writeBwUnit: "",
            writeLatencyValue: 0,
            writeLatencyUnit: ""
        };
        e.pollingTaskStart(), e.onUpdateStore(), e.callParent(arguments)
    },
    onUpdatePerfStore: function() {
        var e = this,
            t = {},
            i = [],
            s = {},
            a = e.perfHistoryStore.getCount(),
            n = 0;
        if (e.latestLog = {
                time: "-",
                testType: "-",
                readIopsValue: 0,
                readBwValue: 0,
                readBwUnit: "",
                readLatencyValue: 0,
                readLatencyUnit: "",
                writeIopsValue: 0,
                writeBwValue: 0,
                writeBwUnit: "",
                writeLatencyValue: 0,
                writeLatencyUnit: ""
            }, 0 < a && (s = e.perfHistoryStore.getAt(a - 1), e.latestLog = s.data), e.disks[e.selectIdx].selectCompareLog && e.disks[e.selectIdx].compareLog.testType != e.latestLog.testType && (e.disks[e.selectIdx].selectCompareLog = !1, e.disks[e.selectIdx].selectIdx = -1, e.disks[e.selectIdx].compareLog = {
                time: "-",
                testType: "-",
                readIopsValue: 0,
                readBwValue: 0,
                readBwUnit: "",
                readLatencyValue: 0,
                readLatencyUnit: "",
                writeIopsValue: 0,
                writeBwValue: 0,
                writeBwUnit: "",
                writeLatencyValue: 0,
                writeLatencyUnit: ""
            }), !e.disks[e.selectIdx].selectCompareLog)
            for (n = a - 2; n >= 0; n--)
                if ((s = e.perfHistoryStore.getAt(n)).data.testType === e.latestLog.testType) {
                    e.disks[e.selectIdx].compareLog = s.data, e.disks[e.selectIdx].selectCompareLog = !0, e.disks[e.selectIdx].selectIdx = n;
                    break
                } e.testType = a ? e.latestLog.testType : "-", "internal" === e.disks[e.selectIdx].diskContainer.type ? t.text = e.disks[e.selectIdx].diskName + " (" + e.disks[e.selectIdx].diskContainer.str + ")" : t.text = e.disks[e.selectIdx].diskName, t.latestLabel = _T("disk_info", "disk_perf_latest_test"), t.latestValue = a ? SYNO.SDS.DateTimeFormatter(Date.parseDate(e.latestLog.time, "Y/m/d H:i:s"), {
            type: "datetimesec"
        }) : "-", t.compareLabel = _T("disk_info", "disk_perf_compare_with"), e.compareValueId = Ext.id(), t.compareValue = e.disks[e.selectIdx].selectCompareLog ? SYNO.SDS.DateTimeFormatter(Date.parseDate(e.disks[e.selectIdx].compareLog.time, "Y/m/d H:i:s"), {
            type: "datetimesec"
        }) + ' (<a id="' + e.compareValueId + '" class="link-font" href="#">' + _T("common", "choose") + "</a>)" : "-", t.typeLabel = _T("disk_info", "disk_perf_test_type"), t.typeValue = e.testType, t.diskVendor = e.disks[e.selectIdx].vendor, t.diskModel = e.disks[e.selectIdx].model, i.push(t), e.perfStore.loadData(i)
    },
    onUpdatePerfResultStore: function() {
        var e = this,
            t = {},
            i = [];
        t.readTitle = _T("disk_info", "disk_perf_read_performance"), t.writeTitle = _T("disk_info", "disk_perf_write_performance"), t.writeInfo = _T("disk_info", "disk_perf_write_performance_info"), t.diskReadPerf = [], e.processing ? (t.diskReadPerf.push(e.onRenderResultBoxWithoutValue("left", _T("rsrcmonitor", "iops"), "processing")), t.diskReadPerf.push(e.onRenderResultBoxWithoutValue("center", _T("rsrcmonitor", "throughput"), "processing")), t.diskReadPerf.push(e.onRenderResultBoxWithoutValue("right", _T("rsrcmonitor", "latency"), "processing"))) : (t.diskReadPerf.push(e.onRenderResultBox("left", _T("rsrcmonitor", "iops"), e.latestLog.readIopsValue, "", e.disks[e.selectIdx].compareLog.readIopsValue, "")), t.diskReadPerf.push(e.onRenderResultBox("center", _T("rsrcmonitor", "throughput"), e.latestLog.readBwValue, e.latestLog.readBwUnit, e.disks[e.selectIdx].compareLog.readBwValue, e.disks[e.selectIdx].compareLog.readBwUnit)), t.diskReadPerf.push(e.onRenderResultBox("right", _T("rsrcmonitor", "latency"), e.latestLog.readLatencyValue, e.latestLog.readLatencyUnit, e.disks[e.selectIdx].compareLog.readLatencyValue, e.disks[e.selectIdx].compareLog.readLatencyUnit))), t.diskWritePerf = [], e.processing ? (t.diskWritePerf.push(e.onRenderResultBoxWithoutValue("left", _T("rsrcmonitor", "iops"), "processing")), t.diskWritePerf.push(e.onRenderResultBoxWithoutValue("center", _T("rsrcmonitor", "throughput"), "processing")), t.diskWritePerf.push(e.onRenderResultBoxWithoutValue("right", _T("rsrcmonitor", "latency"), "processing"))) : (t.diskWritePerf.push(e.onRenderResultBox("left", _T("rsrcmonitor", "iops"), e.latestLog.writeIopsValue, "", e.disks[e.selectIdx].compareLog.writeIopsValue, "")), t.diskWritePerf.push(e.onRenderResultBox("center", _T("rsrcmonitor", "throughput"), e.latestLog.writeBwValue, e.latestLog.writeBwUnit, e.disks[e.selectIdx].compareLog.writeBwValue, e.disks[e.selectIdx].compareLog.writeBwUnit)), t.diskWritePerf.push(e.onRenderResultBox("right", _T("rsrcmonitor", "latency"), e.latestLog.writeLatencyValue, e.latestLog.writeLatencyUnit, e.disks[e.selectIdx].compareLog.writeLatencyValue, e.disks[e.selectIdx].compareLog.writeLatencyUnit))), i.push(t), e.perfResultStore.loadData(i)
    },
    onRenderResultBoxWithoutValue: function(e, t, i) {
        var s = {};
        switch (i) {
            case "processing":
                s = {
                    position: e,
                    title: t,
                    contentStatus: i,
                    unit: "",
                    value: "",
                    status: "",
                    direction: "",
                    comparison: ""
                };
                break;
            case "na":
                s = {
                    position: e,
                    title: t,
                    contentStatus: i,
                    unit: "",
                    value: "N/A",
                    status: "",
                    direction: "",
                    comparison: ""
                };
                break;
            case "no":
                s = {
                    position: e,
                    title: t,
                    contentStatus: i,
                    unit: "",
                    value: "--",
                    status: "",
                    direction: "",
                    comparison: ""
                };
                break;
            case "notsup":
                s = {
                    position: e,
                    title: t,
                    contentStatus: i,
                    unit: "",
                    value: "Not Supported",
                    status: "",
                    direction: "",
                    comparison: ""
                }
        }
        return s
    },
    onRenderResultBox: function(e, t, i, s, a, n) {
        var o, r = "",
            d = "",
            l = "",
            p = "";
        return 0 > Number(i) ? this.onRenderResultBoxWithoutValue(e, t, "notsup") : Number(i) ? (s != n && ("MB/s" === s ? (i *= 1024, s = "KB/s") : "MB/s" === n ? (a *= 1024, n = "KB/s") : "ms" === s ? (i *= 1e3, s = "us") : "ms" === n && (a *= 1e3, n = "us")), p = "normal", Number(a) ? (0 > (r = this.onRenderValueToOneDecimal((i - a) / a * 100)) ? (d = "down", l = _T("rsrcmonitor", "latency") == t ? "good" : "bad") : 0 < r ? (d = "up", l = _T("rsrcmonitor", "latency") == t ? "bad" : "good") : (d = "normal", l = "normal"), r = Math.abs(r), SYNO.SDS.StorageManager.Disk.COMPARE_WARN_THRESHOLD <= r && (p = l), r += "%") : l = "normal", {
            position: e,
            title: t,
            contentStatus: p,
            unit: (o = this.onRenderValueAndUnit(i, s)).unit,
            value: o.value,
            status: l,
            direction: d,
            comparison: r
        }) : this.onRenderResultBoxWithoutValue(e, t, "na")
    },
    onRenderValueAndUnit: function(e, t) {
        switch (1024 < e && "KB/s" === t ? (e /= 1024, t = "MB/s") : 1e3 < e && "us" === t && (e /= 1e3, t = "ms"), t) {
            case "MB/s":
            case "KB/s":
                e = this.onRenderValueToInt(e);
                break;
            case "ms":
            case "us":
                e = this.onRenderValueToOneDecimal(e)
        }
        return {
            value: e = this.onRenderMilliFormat(e),
            unit: t
        }
    },
    onRenderValueToOneDecimal: function(e) {
        return (Math.round(e * Math.pow(10, 1)) / Math.pow(10, 1)).toFixed(1)
    },
    onRenderValueToInt: function(e) {
        return Math.round(e)
    },
    onRenderMilliFormat: function(e) {
        return e && e.toString().replace(/^\d+/g, function(e) {
            return e.replace(/(?=(?!^)(\d{3})+$)/g, ",")
        })
    },
    onRenderButton: function() {
        var e = this;
        0 < e.selectIdx && (e.prevBtn = new Ext.Container({
            cls: "sm-disk-perf-prev-btn",
            id: e.prevBtnId = Ext.id(),
            renderTo: "prev-btn-id"
        }), Ext.get(e.prevBtnId).addListener("click", function(t, i) {
            e.onChangeDisk(!1)
        }, e)), e.disks.length - 1 > e.selectIdx && (e.nextBtn = new Ext.Container({
            cls: "sm-disk-perf-next-btn",
            id: e.nextBtnId = Ext.id(),
            renderTo: "next-btn-id"
        }), Ext.get(e.nextBtnId).addListener("click", function(t, i) {
            e.onChangeDisk(!0)
        }, e)), e.disks[e.selectIdx].selectCompareLog && Ext.get(e.compareValueId).addListener("click", function(t, i) {
            e.onOpenHistoryWizard()
        }, e), e.runTestBtn = new SYNO.ux.Button({
            id: e.runTestBtnId = Ext.id(),
            text: _T("disk_info", "disk_perf_run_test_now"),
            handler: function() {
                e.onHandleTest()
            },
            renderTo: "run-test-btn-id",
            scope: e
        }), e.processing ? Ext.getCmp(e.runTestBtnId).setText(_T("disk_info", "disk_perf_stop_test")) : Ext.getCmp(e.runTestBtnId).setText(_T("disk_info", "disk_perf_run_test_now"))
    },
    onChangeDisk: function(e) {
        var t = this;
        e && t.disks.length - 1 <= t.selectIdx || !e && 0 >= t.selectIdx || (e ? t.selectIdx++ : t.selectIdx--, t.pollingTaskStop(), t.onUpdateStore(), t.pollingTaskStart())
    },
    onHandleTest: function() {
        var e = this;
        _T("disk_info", "disk_perf_run_test_now") === Ext.getCmp(e.runTestBtnId).getText() ? (e.setStatusBusy(), e.sendWebAPI({
            api: "SYNO.Core.Storage.Disk",
            method: "get_performance_test_status",
            version: 1,
            params: {
                device: e.disks[e.selectIdx].device
            },
            scope: e,
            callback: e.checkStatus
        })) : e.stopPerfTest()
    },
    checkStatus: function(e, t) {
        var i = this;
        i.clearStatusBusy(), e ? t.is_erasing ? i.getMsgBox().alert("", String.format(_T("volume", "disk_secure_erasing"))) : t.smart_testing || t.ihm_testing ? i.getMsgBox().alert("", String.format(_T("disk_info", "other_is_testing"))) : t.fw_upgrading ? i.getMsgBox().alert("", String.format(_T("disk_info", "fwupgrade_result_upgrading_title"))) : i.checkUtilization() : SYNO.Debug.error("Failed to get disk current status", t)
    },
    checkUtilization: function() {
        var e = this;
        e.sendWebAPI({
            api: "SYNO.Core.Storage.Disk",
            method: "get_performance_test_info",
            version: 1,
            params: {
                device: e.disks[e.selectIdx].device,
                spare: e.disks[e.selectIdx].spare
            },
            scope: e,
            callback: function(t, i) {
                e.clearStatusBusy(), t ? SYNO.SDS.StorageManager.Disk.DISK_PERF_NUM_THRESHOLD <= i.num ? e.getMsgBox().alert("", String.format(_T("disk_info", "disk_perf_system_busy_warn"), SYNO.SDS.StorageManager.Disk.DISK_PERF_NUM_THRESHOLD)) : e.startPerfTest(i.type) : SYNO.Debug.error("Failed to get performance num", i)
            }
        })
    },
    pollingTaskStart: function() {
        var e = this;
        e.pollingId || (e.pollingId = e.pollReg({
            webapi: {
                api: "SYNO.Core.Storage.Disk",
                method: "get_performance_test_status",
                version: 1,
                params: {
                    device: e.disks[e.selectIdx].device
                }
            },
            interval: 60,
            immediate: !0,
            scope: e,
            status_callback: function(t, i) {
                t ? ("processing" !== i.status ? (e.processing = !1, e.pollingTaskStop()) : e.processing = !0, e.onUpdateStore()) : SYNO.Debug.error("Get performance status error", i)
            }
        }))
    },
    pollingTaskStop: function() {
        var e = this;
        e.pollingId && (e.pollUnreg(e.pollingId), e.pollingId = void 0, e.processing = !1)
    },
    startPerfTest: function(e) {
        var t = this;
        t.setStatusBusy(), t.sendWebAPI({
            api: "SYNO.Core.System.Utilization",
            method: "get",
            version: 1,
            params: {
                type: "current",
                resource: ["disk"]
            },
            scope: t,
            callback: function(i, s) {
                if (t.clearStatusBusy(), i) {
                    var a = t.disks[t.selectIdx].device.replace("/dev/", ""),
                        n = {
                            no: {
                                text: _T("disk_info", "disk_perf_do_test_continue"),
                                btnStyle: "grey"
                            },
                            yes: {
                                text: Ext.MessageBox.buttonText.no,
                                btnStyle: "blue"
                            }
                        },
                        o = 0,
                        r = -1;
                    for (o = 0; o < s.disk.disk.length; o++)
                        if (a == s.disk.disk[o].device) {
                            r = s.disk.disk[o].utilization;
                            break
                        } 0 > r ? SYNO.Debug.error("Failed to get utilization of " + t.disks[t.selectIdx].device) : SYNO.SDS.StorageManager.Disk.UTILIZATION_THRESHOLD < r ? t.getMsgBox({
                        btnStyle: "blue"
                    }).confirm(_T("disk_info", "disk_perf_do_test_warn_title"), String.format(_T("disk_info", "disk_perf_do_test_warn_info"), r, SYNO.SDS.StorageManager.Disk.UTILIZATION_THRESHOLD), function(i) {
                        "no" === i && t.confirmPerfTest(r, e)
                    }, t, n) : t.confirmPerfTest(r, e)
                } else SYNO.Debug.error("Failed to get utilization", s)
            }
        })
    },
    confirmPerfTest: function(e, t) {
        if ("quick" === t) this.doPerfTest(e, t);
        else {
            var i = {
                yes: {
                    text: _T("disk_info", "disk_perf_do_test_continue"),
                    btnStyle: "red"
                },
                no: {
                    text: Ext.MessageBox.buttonText.no
                }
            };
            this.getMsgBox().confirm("", _T("disk_info", "disk_perf_confirm_full_test_text"), function(i) {
                "yes" === i && SYNO.SDS.Utils.PasswordConfirmDialog.openDialog(this, this.doPerfTest, [e, t])
            }, this, i)
        }
    },
    doPerfTest: function(e, t) {
        var i = this;
        i.setStatusBusy(), i.sendWebAPI({
            api: "SYNO.Core.Storage.Disk",
            method: "do_performance_test",
            version: 1,
            params: {
                device: i.disks[i.selectIdx].device,
                type: t,
                isSsdCache: i.disks[i.selectIdx].isSsdCache,
                utilization: e
            },
            scope: i,
            callback: function(e, t) {
                if (i.clearStatusBusy(), !e) {
                    var s = SYNO.SDS.StorageManager.Disk;
                    if (s.ERR_PERF_TESTING !== t.code) return s.ERR_TESTING === t.code ? void i.getMsgBox().alert("", String.format(_T("disk_info", "other_is_testing"))) : s.ERR_SECURITY_ERASING === t.code ? void i.getMsgBox().alert("", _T("volume", "disk_secure_erasing")) : s.ERR_FW_UPGRADING === t.code ? void i.getMsgBox().alert("", String.format(_T("disk_info", "fwupgrade_result_upgrading_title"))) : void i.getMsgBox().alert("", _T("disk_info", "disk_perf_do_test_warn_title"));
                    i.getMsgBox().alert("", String.format(_T("disk_info", "disk_perf_already_testing")))
                }
                Ext.getCmp(i.runTestBtnId).setText(_T("disk_info", "disk_perf_stop_test")), i.pollingTaskStart(), i.onUpdateStore()
            }
        })
    },
    stopPerfTest: function() {
        var e = this;
        e.setStatusBusy(), e.sendWebAPI({
            api: "SYNO.Core.Storage.Disk",
            method: "stop_performance_test",
            version: 1,
            params: {
                device: e.disks[e.selectIdx].device
            },
            scope: e,
            callback: function(t, i) {
                e.clearStatusBusy(), t ? (Ext.getCmp(e.runTestBtnId).setText(_T("disk_info", "disk_perf_run_test_now")), e.pollingTaskStop(), e.onUpdateStore()) : SYNO.Debug.error("Failed to stop performance test", i)
            }
        })
    },
    onOpenHistoryWizard: function() {
        var e = this,
            t = new SYNO.SDS.StorageManager.Wizard.PerfHistory({
                owner: e,
                appWin: e,
                testType: e.testType,
                perfHistoryStore: e.perfHistoryStore,
                latestLog: e.latestLog,
                selectIdx: e.disks[e.selectIdx].selectIdx
            });
        e.mon(t, "close", function() {
            t.isSelected && (e.disks[e.selectIdx].compareLog = t.compareLog, e.disks[e.selectIdx].selectCompareLog = !0, e.disks[e.selectIdx].selectIdx = t.selectIdx, e.onUpdateStore())
        }, e, {
            single: !0
        }), t.open()
    },
    onUpdateStore: function() {
        var e = this,
            t = {
                model: e.disks[e.selectIdx].model,
                serial: e.disks[e.selectIdx].serial
            };
        e.setStatusBusy(), e.sendWebAPI({
            api: "SYNO.Core.Storage.Disk",
            method: "get_performance_test_log",
            version: 1,
            params: t,
            scope: e,
            callback: function(t, i) {
                e.clearStatusBusy(), t ? (e.onUpdatePerfHistoryStore(i.diskPerfLog), e.onUpdatePerfStore(), e.onUpdatePerfResultStore(), e.onRenderButton(), SYNO.SDS.StorageUtils.DataViewToolTipsAdd(e.diskPerfResult)) : SYNO.Debug.error("Failed to get performance test log", i)
            }
        })
    },
    onUpdatePerfHistoryStore: function(e) {
        var t = this;
        t.perfHistoryStore && t.perfHistoryStore.destroy(), t.perfHistoryStore = new SYNO.SDS.StorageManager.Disk.PerfHistoryStore, delete t.perfLogs, t.perfLogs = [], Ext.each(e, function(e) {
            var i = {};
            i.time = e.time, i.testType = "quick" === e.type ? _T("disk_info", "disk_perf_test_type_basic") : _T("disk_info", "disk_perf_test_type_full"), i.readIopsValue = e.read.iops, i.readIops = t.onRenderMilliFormat(e.read.iops), i.readBwValue = t.onRenderValueToInt(e.read.bw), i.readBwUnit = e.read.bw_unit, -1 === i.readBwValue ? i.readBw = "-" : i.readBw = t.onRenderMilliFormat(i.readBwValue) + i.readBwUnit, i.readLatencyValue = t.onRenderValueToOneDecimal(e.read.latency), i.readLatencyUnit = e.read.latency_unit, i.readLatency = t.onRenderMilliFormat(i.readLatencyValue) + i.readLatencyUnit, i.writeIopsValue = e.write.iops, i.writeIops = i.writeIopsValue ? t.onRenderMilliFormat(i.writeIopsValue) : "-", i.writeBwValue = t.onRenderValueToInt(e.write.bw), i.writeBwUnit = e.write.bw_unit, -1 === i.writeBwValue ? i.writeBw = "-" : i.writeBw = i.writeBwUnit ? t.onRenderMilliFormat(i.writeBwValue) + i.writeBwUnit : "-", i.writeLatencyValue = t.onRenderValueToOneDecimal(e.write.latency), i.writeLatencyUnit = e.write.latency_unit, i.writeLatency = i.writeLatencyUnit ? t.onRenderMilliFormat(i.writeLatencyValue) + i.writeLatencyUnit : "-", t.perfLogs.push(i)
        }), t.perfHistoryStore.loadData(t.perfLogs)
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.PerfHistory", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t, i = this;
        i.owner = e.owner, i.appWin = e.appWin, i.testType = e.testType, i.perfHistoryStore = e.perfHistoryStore, i.latestLog = e.latestLog, i.selectIdx = e.selectIdx, i.isSelected = !1, i.colModel = new Ext.grid.ColumnModel({
            defaults: {
                sortable: !0
            },
            columns: [{
                header: _T("time", "time_time"),
                dataIndex: "time",
                renderer: function(e) {
                    return SYNO.SDS.DateTimeFormatter(Date.parseDate(e, "Y/m/d H:i:s"), {
                        type: "datetimesec"
                    })
                },
                width: 140
            }, {
                header: _T("rsrcmonitor", "read"),
                dataIndex: "readIops",
                width: 70
            }, {
                header: _T("rsrcmonitor", "write"),
                dataIndex: "writeIops",
                width: 70
            }, {
                header: _T("rsrcmonitor", "read"),
                dataIndex: "readBw",
                width: 70
            }, {
                header: _T("rsrcmonitor", "write"),
                dataIndex: "writeBw",
                width: 70
            }, {
                header: _T("rsrcmonitor", "read"),
                dataIndex: "readLatency",
                width: 70
            }, {
                header: _T("rsrcmonitor", "write"),
                dataIndex: "writeLatency",
                width: 70
            }, {
                header: _T("disk_info", "disk_perf_test_type"),
                dataIndex: "testType",
                width: 70
            }]
        }), i.selModel = new Ext.grid.RowSelectionModel({
            singleSelect: !0,
            listeners: {
                selectionchange: i.onSelectionChange,
                scope: i
            }
        }), i.gridPanel = new SYNO.ux.GridPanel({
            layout: "fit",
            colModel: i.colModel,
            selModel: i.selModel,
            enableHdMenu: !1,
            store: i.perfHistoryStore,
            plugins: [new SYNO.ux.plugin.GroupHeaderGrid({
                groups: [{
                    header: _T("rsrcmonitor", "iops"),
                    dataIndex: ["readIops", "writeIops"]
                }, {
                    header: _T("rsrcmonitor", "throughput"),
                    dataIndex: ["readBw", "writeBw"]
                }, {
                    header: _T("rsrcmonitor", "latency"),
                    dataIndex: ["readLatency", "writeLatency"]
                }]
            })]
        }), t = Ext.apply({
            title: _T("disk_info", "disk_perf_choose_title"),
            width: 800,
            height: 400,
            minWidth: 800,
            minHeight: 400,
            dsmStyle: "v5",
            layout: "fit",
            items: [i.gridPanel],
            buttons: [{
                text: _T("common", "close"),
                scope: i,
                handler: i.close
            }, {
                text: _T("common", "apply"),
                scope: i,
                disabled: !0,
                id: i.applySelectId = Ext.id(),
                handler: i.onApply,
                btnStyle: "blue"
            }],
            listeners: {
                scope: i,
                afterlayout: i.onAfterlayout
            }
        }, e), i.callParent([t])
    },
    onAfterlayout: function() {
        this.gridPanel.view.updateScroller(), this.gridPanel.getSelectionModel().selectRow(this.selectIdx)
    },
    onApply: function() {
        var e = this;
        e.compareLog.testType == e.testType ? e.latestLog.time != e.compareLog.time ? (e.isSelected = !0, e.close()) : e.getMsgBox().alert("", _T("disk_info", "disk_perf_same_log_warn")) : e.getMsgBox().alert("", _T("disk_info", "disk_perf_diff_type_warn"))
    },
    onSelectionChange: function() {
        var e = this,
            t = e.selModel.getSelected();
        void 0 !== t ? (e.selectIdx = e.gridPanel.store.indexOf(t), e.compareLog = t.data, Ext.getCmp(e.applySelectId).setDisabled(!1)) : Ext.getCmp(e.applySelectId).setDisabled(!0)
    }
}), Ext.define("SYNO.SDS.StorageManager.Disk.PerfHistoryStore", {
    extend: "Ext.data.JsonStore",
    constructor: function(e) {
        this.callParent([Ext.apply({
            idProperty: "time",
            fields: ["time", "testType", "readIops", "readIopsValue", "writeIops", "writeIopsValue", "readBw", "readBwValue", "readBwUnit", "writeBw", "writeBwValue", "writeBwUnit", "readLatency", "readLatencyValue", "readLatencyUnit", "writeLatency", "writeLatencyValue", "writeLatencyUnit"]
        }, e)])
    }
}), Ext.define("SYNO.SDS.StorageManager.Disk.AdvHistoryStore", {
    extend: "Ext.data.JsonStore",
    constructor: function(e) {
        this.callParent([Ext.apply({
            autoDestroy: !0,
            idProperty: "id",
            fields: ["id", "time", "result"]
        }, e)])
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.SmartWarning", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t, i = this,
            s = [];
        i.device = e.device, i.owner = e.owner, i.appWin = e.appWin, s.push({
            xtype: "syno_combobox",
            id: i.typeId = Ext.id(),
            displayField: "display",
            valueField: "warning",
            fieldLabel: "",
            hideLabel: !0,
            width: 494,
            listWidth: 494,
            store: new Ext.data.ArrayStore({
                autoDestroy: !0,
                fields: ["warning", "display", "smartId"],
                data: []
            }),
            listeners: {
                select: {
                    scope: i,
                    fn: i.onTypeChange
                }
            }
        }, {
            xtype: "syno_radio",
            boxLabel: _T("disk_info", "disk_suppress_warning_btn"),
            name: "warning_action",
            inputValue: "suppress",
            checked: !0
        }, {
            xtype: "syno_displayfield",
            indent: 1,
            tabIndex: -1,
            value: _T("disk_info", "disk_suppress_warning_short_desc")
        }, {
            xtype: "syno_radio",
            boxLabel: _T("disk_info", "disk_disable_warning_btn"),
            name: "warning_action",
            inputValue: "disable"
        }, {
            xtype: "syno_displayfield",
            htmlEncode: !1,
            value: String.format('<span class="red-status">{0}</span>', _T("disk_info", "disk_suppress_disable_warning_desc"))
        }, {
            xtype: "syno_checkbox",
            boxLabel: _T("disk_info", "disk_suppress_warning_confirm"),
            listeners: {
                check: {
                    scope: i,
                    fn: i.onCheckboxCheck
                }
            }
        }), t = Ext.apply({
            title: _T("disk_info", "disk_remove_warning_title"),
            width: 550,
            height: 370,
            dsmStyle: "v5",
            layout: "fit",
            items: [{
                xtype: "syno_formpanel",
                id: i.formId = Ext.id(),
                border: !1,
                items: s
            }],
            buttons: [{
                text: _T("common", "cancel"),
                scope: i,
                btnStyle: "gray",
                handler: i.onClickCancel
            }, {
                text: _T("common", "apply"),
                id: i.confirmId = Ext.id(),
                scope: i,
                disabled: !0,
                btnStyle: "red",
                cls: "syno-ux-button-blue",
                handler: i.onClickConfirm
            }],
            listeners: {
                activate: i.onActivate,
                scope: i
            }
        }, e), i.callParent([t])
    },
    onActivate: function() {
        var e, t = this,
            i = [],
            s = 0;
        if (t.appWin.healthInfo && t.appWin.healthInfo.overview) {
            for (e = t.appWin.healthInfo.overview, s = 0; s < e.smart_fail.length; s++) "critical" !== e.smart_fail[s].type && i.push(["smart", SYNO.SDS.StorageUtils.WarningTitleStringGet("smart", e.smart_fail[s].id), e.smart_fail[s].id]);
            "normal_past" === e.smart_test && i.push(["smart_test", SYNO.SDS.StorageUtils.WarningTitleStringGet("smart_test", -1), -1]), !0 === e.adv_modifiable && i.push(["adv", SYNO.SDS.StorageUtils.WarningTitleStringGet("adv", -1), -1]), !0 === e.wdda_modifiable && i.push(["wdda", SYNO.SDS.StorageUtils.WarningTitleStringGet("wdda", -1), -1]), !0 === e.nvme_perc_used_full && i.push(["nvme_perc_used_full", SYNO.SDS.StorageUtils.WarningTitleStringGet("nvme_perc_used_full", -1), -1]), Ext.getCmp(t.typeId).store.loadData(i), Ext.getCmp(t.typeId).setValue(Ext.getCmp(t.typeId).getStore().getAt(0).get("warning")), t.onTypeChange(Ext.getCmp(t.typeId), Ext.getCmp(t.typeId).getStore().getAt(0))
        } else t.appWin.getMsgBox().alert("", _T("status", "status_not_available"))
    },
    onClickConfirm: function() {
        var e, t, i = this;
        t = Ext.getCmp(i.formId).getForm().findField("warning_action").getGroupValue(), e = {
            device: i.device,
            action: t,
            type: i.type,
            smartId: -1 === i.smartId ? "" : i.smartId.toString()
        }, i.appWin.setStatusBusy(), i.appWin.sendWebAPI(SYNO.SDS.StorageUtils.ReplaceWebapiSHA(this.is_target_ha_passive, {
            api: "SYNO.Storage.CGI.Smart",
            method: "smart_warning_set",
            version: 1,
            params: e,
            scope: i,
            callback: function(e, t) {
                i.appWin.clearStatusBusy(), e ? (i.appWin.healthOverviewPanel.onHealthInfoRefresh({
                    device: i.device
                }), i.close()) : SYNO.Debug.error("send webapi smart_warning_set error")
            }
        }))
    },
    onClickCancel: function() {
        this.close()
    },
    onCheckboxCheck: function(e, t) {
        Ext.getCmp(this.confirmId).setDisabled(!t)
    },
    onTypeChange: function(e, t) {
        Ext.getCmp(this.typeId).setValue(t.get("display")), this.type = t.get("warning"), this.smartId = t.get("smartId")
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.EnableWarning", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t, i = this;
        i.device = e.device, i.owner = e.owner, i.appWin = e.appWin, i.is_target_ha_passive = e.is_target_ha_passive, t = Ext.apply({
            title: _T("disk_info", "disk_recover_warning_title"),
            width: 500,
            height: 200,
            dsmStyle: "v5",
            layout: "fit",
            items: [{
                xtype: "syno_formpanel",
                border: !1,
                id: i.formId = Ext.id(),
                items: [{
                    xtype: "syno_combobox",
                    id: i.typeId = Ext.id(),
                    displayField: "display",
                    valueField: "warning",
                    fieldLabel: "",
                    hideLabel: !0,
                    width: 444,
                    listWidth: 444,
                    store: new Ext.data.ArrayStore({
                        autoDestroy: !0,
                        fields: ["warning", "display", "action", "smartId", "descDisplay"],
                        data: [],
                        listeners: {
                            load: i.onStoreLoad,
                            scope: i
                        }
                    }),
                    listeners: {
                        select: {
                            scope: i,
                            fn: i.onTypeChange
                        }
                    }
                }, {
                    xtype: "syno_displayfield",
                    id: i.descId = Ext.id()
                }]
            }],
            buttons: [{
                text: _T("common", "cancel"),
                id: i.confirmId = Ext.id(),
                scope: i,
                handler: i.onClickCancel
            }, {
                text: _T("disk_info", "disk_enable_warning_title"),
                cls: "syno-ux-button-blue",
                scope: i,
                handler: i.onClickConfirm
            }],
            listeners: {
                activate: i.onActivate,
                scope: i
            }
        }, e), i.callParent([t])
    },
    onActivate: function() {
        var e, t = this,
            i = [],
            s = 0;
        e = {
            device: t.device
        }, t.setStatusBusy(), t.sendWebAPI(SYNO.SDS.StorageUtils.ReplaceWebapiSHA(t.is_target_ha_passive, {
            api: "SYNO.Storage.CGI.Smart",
            method: "smart_warning_get",
            version: 1,
            params: e,
            scope: t,
            callback: function(e, a) {
                if (t.clearStatusBusy(), e) {
                    for (t.actionInfo = a, s = 0; s < t.actionInfo.length; s++) i.push([t.actionInfo[s].warning, SYNO.SDS.StorageUtils.WarningTitleStringGet(t.actionInfo[s].warning, t.actionInfo[s].id), t.actionInfo[s].action, t.actionInfo[s].id, t.descStringGet(t.actionInfo[s].warning, t.actionInfo[s].action, t.actionInfo[s].id)]);
                    Ext.getCmp(t.typeId).store.loadData(i), Ext.getCmp(t.typeId).setValue(Ext.getCmp(t.typeId).getStore().getAt(0).get("warning")), t.onTypeChange(Ext.getCmp(t.typeId), Ext.getCmp(t.typeId).getStore().getAt(0))
                } else SYNO.Debug.error("send webapi smart_warning_get error")
            }
        }))
    },
    descStringGet: function(e, t, i) {
        var s = "";
        switch (e) {
            case "smart":
                s = "suppress" === t ? String.format(_T("disk_info", "disk_warning_smart_info_past_suppress"), i) : String.format(_T("disk_info", "disk_warning_smart_info_past_disable"), i);
                break;
            case "life":
                s = "suppress" === t ? _T("disk_info", "disk_warning_life_suppress") : _T("disk_info", "disk_warning_life_disable");
                break;
            case "adv":
                s = "suppress" === t ? _T("disk_info", "disk_warning_ironwolf_suppress") : _T("disk_info", "disk_warning_ironwolf_disable");
                break;
            case "smart_test":
                s = "suppress" === t ? _T("disk_info", "disk_warning_smart_test_past_suppress") : _T("disk_info", "disk_warning_smart_test_past_disable");
                break;
            case "wdda":
                s = "suppress" === t ? _T("disk_info", "disk_warning_wdda_suppress") : _T("disk_info", "disk_warning_wdda_disable");
                break;
            case "nvme_perc_used_full":
                s = "suppress" === t ? _T("disk_info", "disk_warning_nvme_perc_used_suppress") : _T("disk_info", "disk_warning_nvme_perc_used_disable");
                break;
            default:
                return void SYNO.Debug.error("no such value", e)
        }
        return s
    },
    onClickConfirm: function() {
        var e, t = this;
        e = {
            device: t.device,
            action: t.action,
            type: t.type,
            smartId: t.smartId
        }, t.appWin.setStatusBusy(), t.appWin.sendWebAPI(SYNO.SDS.StorageUtils.ReplaceWebapiSHA(t.is_target_ha_passive, {
            api: "SYNO.Storage.CGI.Smart",
            method: "smart_warning_set",
            version: 1,
            params: e,
            scope: t,
            callback: function(e, i) {
                t.appWin.clearStatusBusy(), e ? (t.appWin.healthOverviewPanel.onHealthInfoRefresh({
                    device: t.device
                }), t.close()) : SYNO.Debug.error("send webapi smart_warning_set error")
            }
        }))
    },
    onClickCancel: function() {
        this.close()
    },
    onTypeChange: function(e, t) {
        var i = this;
        Ext.getCmp(i.typeId).setValue(t.get("display")), Ext.getCmp(i.descId).setValue(t.get("descDisplay")), i.type = t.get("warning"), i.action = "suppress" === t.get("action") ? "remove" : "enable", i.smartId = t.get("smartId")
    },
    onStoreLoad: function(e, t) {
        var i = {},
            s = "";
        e.filterBy(function(e) {
            return s = e.get("warning") + e.get("smartId"), !i[s] && (i[s] = !0, !0)
        }), delete e.snapshot
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.SwitchDiskLed", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t, i = this;
        i.device = e.device, i.owner = e.owner, i.appWin = e.appWin, i.is_target_ha_passive = e.is_target_ha_passive, t = Ext.apply({
            title: _T("disk_info", "switch_led_light_title"),
            width: 550,
            height: 320,
            minWidth: 550,
            minHeight: 250,
            autoFlexcroll: !0,
            dsmStyle: "v5",
            layout: "fit",
            items: [{
                xtype: "syno_formpanel",
                padding: 0,
                border: !1,
                items: [{
                    xtype: "syno_displayfield",
                    value: _T("disk_info", "switch_led_light_desc")
                }, {
                    xtype: "syno_displayfield",
                    value: _T("disk_info", "switch_led_light_time")
                }, {
                    xtype: "syno_combobox",
                    id: i.ledRemainTime = Ext.id(),
                    fieldLabel: _T("time", "time_time"),
                    store: i.getRemainTimeStore(),
                    displayField: "display",
                    valueField: "value",
                    labelWidth: 50,
                    width: 200
                }, {
                    xtype: "syno_displayfield",
                    id: i.remainText = Ext.id(),
                    hidden: !0
                }]
            }],
            buttons: [{
                text: _T("common", "alt_close"),
                handler: i.onClickClose,
                scope: i
            }, {
                text: _T("disk_info", "switch_led_light_btn"),
                id: i.confirmId = Ext.id(),
                handler: i.onClickConfirm,
                cls: "syno-ux-button-blue",
                scope: i
            }],
            listeners: {
                scope: i,
                beforedestroy: i.pollingTaskStop
            }
        }, e), i.callParent([t]), i.mon(i, "afterlayout", i.onAfterlayout, i, {
            single: !0
        })
    },
    onActivate: function() {
        this.callParent(arguments), Ext.getCmp(this.ledRemainTime).setValue(60)
    },
    onAfterlayout: function(e) {
        var t = this;
        if (!(t.device = e.device)) throw Error("param error: device is not set");
        t.GetStatusPollingConf = {
            interval: 5,
            immediate: !0,
            webapi: SYNO.SDS.StorageUtils.ReplaceWebapiSHA(t.is_target_ha_passive, {
                api: "SYNO.Core.Storage.Disk",
                version: 1,
                method: "get_disk_led_status",
                params: {
                    device: t.device
                }
            }),
            status_callback: function(e, i, s, a) {
                if (t.cleanMask && (t.clearStatusBusy(), t.cleanMask = !1), !e) return t.appWin.getMsgBox().alert("", _T("status", "status_not_available")), void t.pollingTaskStop();
                t.fillData(i)
            },
            scope: t
        }, t.setStatusBusy(), t.cleanMask = !0, t.pollingTaskStart()
    },
    getRemainTimeStore: function() {
        return new Ext.data.SimpleStore({
            fields: ["value", "display"],
            data: [
                [60, "1 " + _T("common", "time_minute")],
                [300, "5 " + _T("hddsleep", "hddsleep_min")],
                [900, "15 " + _T("hddsleep", "hddsleep_min")],
                [1800, "30 " + _T("hddsleep", "hddsleep_min")],
                [3600, "60 " + _T("hddsleep", "hddsleep_min")]
            ]
        })
    },
    pollingTaskStart: function() {
        void 0 === this.GetStatusPollingId && (this.GetStatusPollingId = this.pollReg(this.GetStatusPollingConf))
    },
    pollingTaskStop: function() {
        void 0 !== this.GetStatusPollingId && (this.pollUnreg(this.GetStatusPollingId), this.GetStatusPollingId = void 0)
    },
    fillData: function(e) {
        var t = this,
            i = "",
            s = Ext.getCmp(t.ledRemainTime);
        0 < e.time ? (i = 1 < e.time ? String.format(_T("disk_info", "switch_led_light_remain"), e.time) : String.format(_T("disk_info", "switch_led_light_remain_singular"), e.time), Ext.getCmp(t.remainText).setValue(i), Ext.getCmp(t.remainText).setVisible(!0), s.setValue(e.duration), s.disable(), t.action = "restore", Ext.getCmp(t.confirmId).setText(_T("disk_info", "restore_led_light_btn"))) : (Ext.getCmp(t.remainText).setVisible(!1), t.action = "switch", !0 === s.disabled && s.setValue(60), s.enable(), Ext.getCmp(t.confirmId).setText(_T("disk_info", "switch_led_light_btn")))
    },
    onClickConfirm: function() {
        var e = Ext.getCmp(this.ledRemainTime).getValue();
        this.onSwitchDiskLed(e)
    },
    onClickClose: function() {
        this.close()
    },
    onSwitchDiskLed: function(e) {
        var t = this,
            i = {
                device: t.device,
                action: t.action,
                time: e
            };
        t.setStatusBusy(), t.sendWebAPI(SYNO.SDS.StorageUtils.ReplaceWebapiSHA(t.is_target_ha_passive, {
            api: "SYNO.Core.Storage.Disk",
            method: "set_disk_led_status",
            version: 1,
            params: i,
            scope: t,
            callback: function(e, i) {
                var s = function() {
                    t.clearStatusBusy(), t.pollingTaskStop(), t.pollingTaskStart()
                }.createDelegate(t);
                t.isDataChanged = !0, setTimeout(s, 1e3), e || t.appWin.getMsgBox().alert("", _T("status", "status_not_available"))
            }
        }))
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.DiskConfig", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t, i = this,
            s = [];
        i.device = e.device, i.owner = e.owner, i.appWin = e.appWin, i.is_target_ha_passive = e.is_target_ha_passive, s.push({
            xtype: "syno_checkbox",
            scope: i,
            id: i.CacheCheckboxId = Ext.id(),
            boxLabel: _T("hddsleep", "dcache_config"),
            name: "wcache_en",
            value: !0
        }, {
            xtype: "syno_displayfield",
            scope: i,
            id: i.CacheDescdiskId = Ext.id(),
            value: _T("hddsleep", "dcache_desc"),
            hidden: !0
        }, {
            xtype: "syno_displayfield",
            scope: i,
            id: i.CacheDescnoteId = Ext.id(),
            value: _T("hddsleep", "dwcache_suggest"),
            htmlEncode: !1,
            hidden: !0
        }), t = Ext.apply({
            title: _T("volume", "configuration"),
            width: 600,
            height: 280,
            minWidth: 600,
            minHeight: 280,
            dsmStyle: "v5",
            layout: "fit",
            items: [{
                xtype: "syno_formpanel",
                border: !1,
                padding: 0,
                items: s
            }],
            buttons: [{
                text: _T("common", "cancel"),
                handler: i.onClickClose,
                scope: i
            }, {
                text: _T("common", "commit"),
                id: i.confirmId = Ext.id(),
                handler: i.onClickConfirm,
                cls: "syno-ux-button-blue",
                scope: i
            }]
        }, e), i.callParent([t])
    },
    fillData: function(e) {
        Ext.getCmp(this.CacheCheckboxId).setValue(e.wcache_en), Ext.getCmp(this.CacheDescdiskId).setVisible(!(e.blacklist || e.disable_wcache_off_list)), Ext.getCmp(this.CacheDescnoteId).setVisible(e.blacklist || e.disable_wcache_off_list), Ext.getCmp(this.CacheCheckboxId).setDisabled(e.blacklist || e.disable_wcache_off_list)
    },
    onClickConfirm: function() {
        var e = this,
            t = {
                device: e.device,
                wcache_en: Ext.getCmp(e.CacheCheckboxId).getValue()
            };
        e.setStatusBusy(), e.sendWebAPI(SYNO.SDS.StorageUtils.ReplaceWebapiSHA(e.is_target_ha_passive, {
            api: "SYNO.Core.Storage.Disk",
            method: "disk_config_set",
            version: 1,
            params: t,
            scope: e,
            callback: function(t, i) {
                e.clearStatusBusy(), t ? e.close() : i.errors && i.errors.errinfo.sec && i.errors.errinfo.key ? e.setStatusError({
                    text: _T(i.errors.errinfo.sec, i.errors.errinfo.key)
                }) : e.setStatusError({
                    text: _T("disk_info", "disk_err_set_wcache")
                })
            }
        }))
    },
    onClickClose: function() {
        this.close()
    },
    onActivate: function() {
        this.callParent(arguments);
        var e = this,
            t = {
                device: e.device
            };
        e.setStatusBusy(), e.sendWebAPI(SYNO.SDS.StorageUtils.ReplaceWebapiSHA(e.is_target_ha_passive, {
            api: "SYNO.Core.Storage.Disk",
            method: "disk_config_get",
            version: 1,
            params: t,
            scope: e,
            callback: function(t, i) {
                e.clearStatusBusy(), t ? e.fillData(i) : e.appWin.getMsgBox().alert("", _T("status", "status_not_available"))
            }
        }))
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.ImportLog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t, i = this;
        i.parentNode = e.parentNode, i.owner = e.owner, i.appWin = e.appWin, i.is_target_ha_passive = e.is_target_ha_passive, i.type = e.type, t = Ext.apply({
            title: _T("disk_info", "import_previous_data"),
            width: 550,
            height: 200,
            minWidth: 550,
            minHeight: 200,
            dsmStyle: "v5",
            layout: "fit",
            items: [{
                xtype: "syno_formpanel",
                border: !1,
                items: [{
                    xtype: "syno_displayfield",
                    value: _T("disk_info", "log_update_desc")
                }, {
                    xtype: "syno_displayfield",
                    htmlEncode: !1,
                    value: '<span class="syno-ux-note">' + _T("common", "note") + _T("common", "colon") + " </span>" + _T("disk_info", "log_update_note")
                }]
            }],
            buttons: [{
                text: _T("nfs", "nfs_kerberos_import_keys"),
                scope: this,
                handler: this.onClickImport
            }, {
                text: _T("common", "cancel"),
                scope: this,
                handler: this.onClickCancel
            }]
        }, e), i.callParent([t])
    },
    onClickImport: function() {
        var e = this;
        e.setStatusBusy(), e.sendWebAPI(SYNO.SDS.StorageUtils.ReplaceWebapiSHA(this.is_target_ha_passive, {
            api: "SYNO.Core.Storage.Disk",
            method: "import_previous_log",
            version: 1,
            params: {
                type: e.type
            },
            scope: e,
            callback: function(t, i, s, a) {
                e.clearStatusBusy(), t ? (e.parentNode.onRefreshConfig(), e.parentNode.isImporting = !0, e.parentNode.onRefreshImportingMask(), e.close()) : e.appWin.getMsgBox().alert("", _T("common", "error_system"))
            }
        }))
    },
    onClickCancel: function() {
        this.close()
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.FirmwareUpgradeGridPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t, i = this;
        i.owner = e.owner, i.grid = i.createGrid({
            owner: i,
            appWin: i.appWin
        }), t = Ext.apply({
            cls: "sm-fwupgrade-grid",
            padding: 0,
            items: [{
                xtype: "syno_displayfield",
                cls: "sm-fwupgrade-grid-title",
                hidden: !0,
                htmlEncode: !1,
                ref: "titleCmp"
            }, {
                xtype: "container",
                cls: "sm-fwupgrade-grid-loading-desc",
                hidden: !0,
                htmlEncode: !1,
                ref: "loadingDescCmp"
            }, {
                xtype: "syno_displayfield",
                cls: "sm-fwupgrade-grid-desc",
                hidden: !0,
                htmlEncode: !1,
                ref: "descCmp"
            }, i.grid]
        }, e), i.callParent([t])
    },
    createGrid: function(e) {
        var t, i = SYNO.SDS.Utils.StorageUtils.UiRenderHelper;
        this.colModel = new Ext.grid.ColumnModel({
            columns: [{
                header: _T("disk_info", "fwupgrade_drive_location"),
                dataIndex: "location",
                renderer: function(e) {
                    return i.DiskDisplayNameGet(e)
                }
            }, {
                header: _T("disk_info", "fwupgrade_drive_model"),
                dataIndex: "model"
            }, {
                header: _T("disk_info", "fwupgrade_drive_used_by"),
                dataIndex: "used_by",
                useHtmlEncodeRender: !1,
                renderer: function(e) {
                    var t = SYNO.SDS.StorageUtils.SpaceIDParser(e).str || "-";
                    return "-" === t ? String.format('<span class="disable-font">{0}</span>', _T("disk_info", "fwupgrade_no_in_use")) : t
                }
            }, {
                header: _T("disk_info", "fwupgrade_current_version"),
                dataIndex: "current_version",
                useHtmlEncodeRender: !1
            }, {
                header: _T("disk_info", "fwupgrade_latest_version"),
                dataIndex: "available_version"
            }, {
                header: _T("disk_info", "fwupgrade_firmware_status"),
                dataIndex: "status",
                useHtmlEncodeRender: !1,
                renderer: function(e) {
                    return "required" === e ? String.format('<span class="red-status">{0}</span>', _T("disk_info", "fwupgrade_firmware_status_required")) : String.format('<span class="green-status">{0}</span>', _T("disk_info", "fwupgrade_firmware_status_optional"))
                }
            }, {
                header: _T("disk_info", "fwupgrade_firmware_status"),
                dataIndex: "summary_result",
                useHtmlEncodeRender: !1,
                renderer: function(e, t, i) {
                    var s, a;
                    return e ? (s = String.format(_T("disk_info", "fwupgrade_result_firmware_status_successful"), i.data.available_version), a = String.format('<div class="sm-fwupgrade-grid-result-image sm-fwupgrade-grid-result-success"></div><div class="sm-fwupgrade-grid-result-content green-status">{0}</div>', s)) : (s = String.format(_T("disk_info", "fwupgrade_result_firmware_status_failed"), i.data.current_version, i.data.available_version), a = String.format('<div class="sm-fwupgrade-grid-result-image sm-fwupgrade-grid-result-fail"></div><div class="sm-fwupgrade-grid-result-content red-status">{0}</div>', s)), t.attr = String.format('ext:qtip="{0}"', s), t.css = "sm-fwupgrade-grid-result", a
                }
            }]
        });
        var s = Ext.apply({
            enableHdMenu: !0,
            padding: 0,
            colModel: this.colModel,
            store: new Ext.data.JsonStore({
                autoDestroy: !0,
                fields: ["id", "serial", "location", "model", "used_by", "order", "current_version", "available_version", "status", "summary_result"]
            })
        }, e);
        return t = new SYNO.ux.GridPanel(s), this.originColCfg = this.colModel.config.map(function(e) {
            return e
        }), t
    },
    setType: function(e) {
        var t = this,
            i = ["location", "model", "used_by", "current_version", "available_version", "status"],
            s = [120, 120, 120, 120, 120, 184];
        "successful_summary" === e ? (i = ["location", "model", "summary_result"], s = [150, 150, 494]) : "failed_summary" === e && (i = ["location", "model", "used_by", "summary_result"], s = [150, 150, 150, 344]), t.colModel.config = t.originColCfg.filter(function(e) {
            return i.some(function(t) {
                return t === e.dataIndex
            })
        }), s.forEach(function(e, i) {
            t.grid.colModel.setColumnWidth(i, e)
        })
    },
    setTableTitle: function(e) {
        this.titleCmp.setValue(e)
    },
    setTitleVisible: function(e) {
        this.titleCmp.setVisible(e)
    },
    setLoadingDesc: function(e) {
        this.loadingDescCmp.el && this.loadingDescCmp.el.update(e)
    },
    setLoadingDescVisible: function(e) {
        this.loadingDescCmp.setVisible(e)
    },
    setDesc: function(e) {
        this.descCmp.setValue(e)
    },
    setDescVisible: function(e) {
        this.descCmp.setVisible(e)
    },
    setGridVisible: function(e) {
        this.grid.setVisible(e)
    },
    loadDrivesInfo: function(e) {
        var t = e.map(function(e) {
            var t = Ext.decode(e.ui_json);
            return {
                id: e.id,
                used_by: t.used_by,
                location: t.location,
                model: t.model,
                order: t.order,
                current_version: e.firmware,
                available_version: e.available_firmware,
                summary_result: e.success
            }
        });
        this.updateDrives(t, !0)
    },
    updateDrives: function(e, t) {
        if (t = t || !1) e.sort(function(e, t) {
            var i = e.order,
                s = t.order;
            return i > s ? 1 : i < s ? -1 : 0
        });
        else {
            var i = 0;
            e.sort(SYNO.SDS.StorageUtils.DiskSort), e = e.map(function(e) {
                return delete e.numId, delete e.ctnOrder, delete e.portType, delete e.pciSlot, e.order = i, i++, e
            })
        }
        this.grid.setHeight(45 + 29 * e.length), this.grid.getStore().loadData(e, !1)
    },
    dumpDrivesInfo: function() {
        return this.getDriveInfoByKey(["id", "serial", "location", "model", "used_by", "order"]).map(function(e) {
            return {
                id: e.id,
                serial: e.serial,
                ui_json: {
                    location: e.location,
                    model: e.model,
                    used_by: e.used_by,
                    order: e.order
                }
            }
        })
    },
    getDriveInfoByKey: function(e) {
        var t = this.grid.getStore(),
            i = [];
        return t.each(function(t) {
            var s = {};
            e.forEach(function(e) {
                s[e] = t.get(e)
            }), i.push(s)
        }), i
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.FirmwareUpgrade", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t, i = this;
        i.param = e.param || {}, i.utils = i.createUtils(), i.defaultCmp = i.createBeforListDriveResponseCmp(), i.upToDateCmp = i.createUpToDateCmp(), i.noNetworkCmp = i.createNoNetworkCmp(), i.singleCmp = new SYNO.SDS.StorageManager.Wizard.FWUpgradePanel({
            itemId: "single",
            owner: i,
            appWin: e.appWin
        }), i.singleSummaryCmp = new SYNO.SDS.StorageManager.Wizard.FWUpgradePanelSummary({
            itemId: "single_summary",
            owner: i
        }), i.shaCmp = new SYNO.SDS.StorageManager.Wizard.SHAFWUpgradePanel({
            itemId: "sha",
            owner: i,
            appWin: e.appWin
        }), i.shaSummaryCmp = new SYNO.SDS.StorageManager.Wizard.SHAFWUpgradePanelSummary({
            itemId: "sha_summary",
            owner: i
        }), t = Ext.apply({
            layout: "card",
            title: _T("disk_info", "fwupgrade_title"),
            width: 860,
            height: 540,
            resizable: !1,
            padding: "0px 20px",
            dsmStyle: "v5",
            items: [i.defaultCmp, i.upToDateCmp, i.noNetworkCmp, i.singleCmp, i.singleSummaryCmp, i.shaCmp, i.shaSummaryCmp],
            buttons: [i.createButtons("../")]
        }, e), i.callParent([t])
    },
    createBeforListDriveResponseCmp: function() {
        return new Ext.Container({
            itemId: "default"
        })
    },
    createUpToDateCmp: function() {
        return new Ext.Container({
            xtype: "container",
            itemId: "up_to_date",
            cls: "sm-fwupgrade-headline-body",
            items: [{
                height: "auto",
                cls: "sm-fwupgrade-headline-panel",
                border: !1,
                items: [{
                    xtype: "container",
                    cls: "sm-fwupgrade-image sm-fwupgrade-up-to-date"
                }, {
                    xtype: "syno_displayfield",
                    cls: "sm-fwupgrade-center-context sm-fwupgrade-title",
                    value: _T("disk_info", "fwupgrade_up_to_date_title")
                }, {
                    xtype: "syno_displayfield",
                    cls: "sm-fwupgrade-center-context sm-fwupgrade-opacity",
                    value: _T("disk_info", "fwupgrade_up_to_date_desc")
                }]
            }]
        })
    },
    createNoNetworkCmp: function() {
        var e = this,
            t = Ext.id();
        return new Ext.Container({
            xtype: "container",
            itemId: "no_network",
            cls: "sm-fwupgrade-headline-body",
            items: [{
                height: "auto",
                cls: "sm-fwupgrade-headline-panel",
                border: !1,
                items: [{
                    xtype: "container",
                    cls: "sm-fwupgrade-image sm-fwupgrade-unable-to-check"
                }, {
                    xtype: "syno_displayfield",
                    cls: "sm-fwupgrade-center-context sm-fwupgrade-title",
                    value: _T("disk_info", "fwupgrade_no_availiable_title")
                }, {
                    xtype: "syno_displayfield",
                    cls: "sm-fwupgrade-center-context",
                    htmlEncode: !1,
                    value: e.utils.formatLinkToSetting(t, _T("disk_info", "fwupgrade_no_available_desc"), "sm-fwupgrade-opacity"),
                    listeners: {
                        afterrender: function() {
                            e.utils.addLinktoSettingEvent(t)
                        }
                    }
                }]
            }]
        })
    },
    createUtils: function() {
        var e = this;
        return {
            formatLinkToSetting: function(e, t, i) {
                var s, a = "";
                return i && (a = String.format(' class="{0}"', i)), s = String.format('</span><a class="link-font sm-fwupgrade-font-bold" id="{0}" href="#">', e), "<span" + a + ">" + String.format(t, s, "</a><span" + a + ">") + "</span>"
            },
            addLinktoSettingEvent: function(t) {
                var i = Ext.fly(t);
                e.mon(i, "click", function() {
                    SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance", {
                        fn: "SYNO.SDS.StorageManager.Disk.Main",
                        tab: "settings-tab"
                    }), e.onClickClose()
                }, e)
            }
        }
    },
    createButtons: function(e) {
        return [{
            ref: e + "closeBtnCmp",
            handler: this.onClickClose,
            scope: this
        }, {
            text: _T("disk_info", "fwupgrade_upgrade_btn"),
            btnStyle: "blue",
            ref: e + "upgradeBtnCmp",
            hidden: !0,
            handler: this.onClickUpgrade,
            scope: this
        }]
    },
    handleParam: function(e) {
        var t = this;
        e = e || t.param, ["single_summary", "sha_summary"].includes(e.ui_state) ? (t.changeCard(e.ui_state), t.current.showSummary(e.summaryList), !0 === e.cancelAutoLaunch && t.current.sendCancelAutoLaunch()) : SYNO.SDS.StorageUtils.isSHA ? t.shaCmp.loadDrive() : t.singleCmp.loadDrive()
    },
    onOpen: function(e) {
        this.changeCard("default"), this.callParent(arguments), this.handleParam(e)
    },
    onRequest: function(e) {
        this.callParent(arguments), this.handleParam(e), this.blinkShadow(3)
    },
    onClickUpgrade: function() {
        var e = this,
            t = {
                yes: _T("disk_info", "fwupgrade_upgrade_btn"),
                no: _T("common", "cancel")
            },
            i = e.getMsgBox();
        i.show({
            title: "",
            msg: _T("disk_info", "fwupgrade_confirm_upgrade"),
            buttons: t,
            fn: function(t) {
                "yes" === t && e.current.upgrade()
            },
            scope: e,
            minWidth: i.minWidth
        })
    },
    onClickClose: function() {
        this.current.stopPollTask && this.current.stopPollTask(), this.close()
    },
    changeCard: function(e, t) {
        var i = this,
            s = i.layout;
        switch (e) {
            case "default":
                s.setActiveItem("default"), i.current = i.defaultCmp, t = t || !1;
                break;
            case "up_to_date":
                s.setActiveItem("up_to_date"), i.current = i.upToDateCmp, t = t || !1;
                break;
            case "no_network":
                s.setActiveItem("no_network"), i.current = i.noNetworkCmp, t = t || !1;
                break;
            case "single":
                s.setActiveItem("single"), i.current = i.singleCmp, t = t || !0;
                break;
            case "sha":
                s.setActiveItem("sha"), i.current = i.shaCmp, t = t || !0;
                break;
            case "single_summary":
                s.setActiveItem("single_summary"), i.current = i.singleSummaryCmp, t = t || !1;
                break;
            case "sha_summary":
                s.setActiveItem("sha_summary"), i.current = i.shaSummaryCmp, t = t || !1;
                break;
            default:
                return void SYNO.Debug.error("Unknown case: ", e)
        }
        i.changeBtnState(t), this.doLayout()
    },
    changeBtnState: function(e) {
        this.upgradeBtnCmp.setVisible(e), this.closeBtnCmp.setText(e ? _T("common", "cancel") : _T("common", "close"))
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.FWUpgradePanelTemplate", {
    extend: "SYNO.ux.FormPanel",
    interval: 1e3,
    timeout: 300,
    constructor: function(e) {
        var t, i = this;
        i.owner = e.owner, i.headlineCmp = i.createHeadlineCmp(), i.gridsCnt = new Ext.Container({
            cls: "sm-fwupgrade-grids-panel",
            items: []
        }), t = Ext.apply({
            height: 456,
            padding: "0px 0px",
            items: [i.headlineCmp, i.gridsCnt]
        }, e), i.callParent([t])
    },
    createHeadlineCmp: function() {
        var e = this,
            t = Ext.id();
        return new Ext.Container({
            cls: "sm-fwupgrade-desc-panel",
            items: [{
                xtype: "syno_displayfield",
                value: _T("disk_info", "fwupgrade_has_new_firmware_title"),
                cls: "sm-fwupgrade-title",
                ref: "./titleCmp"
            }, {
                xtype: "syno_displayfield",
                value: _T("disk_info", "fwupgrade_has_new_firmware_desc"),
                hidden: !0,
                htmlEncode: !1,
                ref: "./descCommonCmp"
            }, {
                xtype: "syno_displayfield",
                value: _T("disk_info", "fwupgrade_has_new_firmware_desc") + '</br><span class="syno-ux-note">' + _T("common", "note") + _T("common", "colon") + "</span>" + e.owner.utils.formatLinkToSetting(t, _T("disk_info", "fwupgrade_no_available_desc")),
                hidden: !0,
                htmlEncode: !1,
                ref: "./descNoNetworkCmp",
                listeners: {
                    afterrender: function() {
                        e.owner.utils.addLinktoSettingEvent(t)
                    }
                }
            }]
        })
    },
    createNewGridPanel: function(e) {
        var t = new SYNO.SDS.StorageManager.Wizard.FirmwareUpgradeGridPanel({
            owner: this,
            appWin: this.appWin
        });
        return t.setType(e), this.gridsCnt.add(t), this.doLayout(), t
    },
    resetGrids: function() {
        this.gridsCnt.removeAll()
    },
    changeTitleAndDescState: function(e, t, i) {
        e ? this.owner.changeCard(t ? "up_to_date" : "no_network") : (this.descCommonCmp.setVisible(t), this.descNoNetworkCmp.setVisible(!t), this.owner.changeCard(i))
    },
    getCompoundCfg: function(e, t) {
        return {
            api: "SYNO.Entry.Request",
            version: 1,
            method: "request",
            compound: {
                mode: "parallel",
                params: e
            },
            callback: t,
            scope: this
        }
    },
    sendCompound: function(e, t) {
        SYNO.API.Request(this.getCompoundCfg(e, t))
    },
    getBasicWebapiCfg: function(e) {
        return {
            api: "SYNO.Core.Storage.Disk.FWUpgrade",
            method: e,
            version: 1
        }
    },
    alertError: function(e, t) {
        this.owner.clearStatusBusy(), this.stopPollTask(), this.owner.getEl().unmask(), SYNO.SDS.StorageUtils.ReportWebapiFailure(e, t)
    },
    startPollTask: function() {
        var e = this;
        e.pollTask = e.pollTask || e.owner.addWebAPITask(Ext.apply(e.getCompoundCfg(e.getPollCfg(), e.stepPoll), {
            interval: e.interval
        })), e.timeSpent = 0, e.pollTask.start(), e.owner.getEl().mask(_T("disk_info", "fwupgrade_upgrading"), "x-mask-loading")
    },
    stopPollTask: function() {
        this.pollTask && this.pollTask.stop()
    },
    genDefDiskInfo: function(e) {
        if (e) return {
            numId: e.get("num_id"),
            ctnOrder: parseInt(e.get("container").order, 10),
            portType: e.get("portType"),
            pciSlot: e.get("pciSlot"),
            location: e.get("i18nNamingInfo"),
            model: e.get("model"),
            used_by: e.get("used_by")
        }
    },
    loadDrive: function() {
        this.owner.setStatusBusy(), this.sendCompound(this.getListDriveCfg(), this.stepListDrive)
    },
    getBasicListDriveCfg: function() {
        return this.getBasicWebapiCfg("list_drive")
    },
    stepListDrive: function(e, t, i, s) {
        var a = this;
        a.handleListDrive(e, t, i, s, function(e) {
            "start_polling" === e ? (a.owner.clearStatusBusy(), a.startPollTask()) : "finish_list_drive" === e ? a.owner.clearStatusBusy() : "alert_error" === e && a.alertError(a.owner, t)
        })
    },
    upgrade: function() {
        this.owner.setStatusBusy(), this.sendCompound(this.getPrepareCfg(), this.stepPrepare)
    },
    getBasicPrepareCfg: function(e) {
        return Ext.apply(this.getBasicWebapiCfg("prepare"), {
            params: {
                drives: e
            }
        })
    },
    stepPrepare: function(e, t, i, s) {
        var a = this;
        a.handlePrepare(e, t, i, s, function(e) {
            var i = a.owner.getMsgBox(),
                s = {
                    alert_drive_busy: "fwupgrade_drive_acting_alert",
                    alert_not_enough_space: "fwupgrade_not_enough_space_alert",
                    alert_lock_failed: "fwupgrade_lock_failed_alert"
                },
                n = {
                    alert_no_network: "fwupgrade_no_available_alert",
                    alert_cant_get_from_server: "fwupgrade_firmware_not_match_alert"
                };
            if ("reload_list_drive" === e) a.owner.clearStatusBusy(), i.show({
                title: "",
                msg: _T("disk_info", "fwupgrade_drive_no_match_alert"),
                buttons: {
                    yes: _T("common", "refresh")
                },
                fn: function() {
                    a.loadDrive()
                },
                scope: a,
                minWidth: i.minWidth
            });
            else if (s[e]) a.owner.clearStatusBusy(), i.alert("", _T("disk_info", s[e]));
            else if (n[e]) {
                var o = Ext.id(),
                    r = a.owner.utils.formatLinkToSetting(o, _T("disk_info", n[e]));
                a.owner.clearStatusBusy(), i.alert("", r), a.owner.utils.addLinktoSettingEvent(o)
            } else if ("start_upgrade" === e) a.sendCompound(a.getStartUpgradeCfg(), a.stepStartUpgrade);
            else if ("defer_upgrade" === e) {
                var d = {
                    yes: _T("system", "reboot_opt"),
                    no: _T("common", "cancel")
                };
                a.owner.clearStatusBusy(), i.confirm("", a.getRebootConfirmMsg(), function(e) {
                    "yes" === e && a.handleReboot()
                }, a, d)
            } else "alert_error" === e && a.alertError(a.owner, t)
        })
    },
    getBasicStartUpgradeCfg: function() {
        return this.getBasicWebapiCfg("start_upgrade")
    },
    stepStartUpgrade: function(e, t, i, s) {
        var a = this;
        a.handleStartUpgrade(e, t, i, s, function(e) {
            "start_polling" === e ? (a.owner.clearStatusBusy(), a.startPollTask()) : "alert_error" === e && a.alertError(a.owner, t)
        })
    },
    getBasicPollCfg: function() {
        return this.getBasicWebapiCfg("poll")
    },
    stepPoll: function(e, t, i, s) {
        var a, n = this;
        if (n.timeSpent += n.interval / 1e3, n.timeSpent > n.timeout) return n.stopPollTask(), n.owner.getEl().unmask(), void n.alertError(n.owner, t);
        a = function(e) {
            "show_summary" === e ? (n.stopPollTask(), n.sendCompound(n.getWarmUpgradeSummaryCfg(), n.stepWarmUpgradeSummary)) : "alert_error" === e && n.alertError(n.owner, t)
        }, n.handlePoll(e, t, i, s, a)
    },
    getBasicSummaryCfg: function(e) {
        return Ext.apply(this.getBasicWebapiCfg("get_summary"), {
            params: {
                source: e
            }
        })
    },
    getBasicWarmUpgradeSummaryCfg: function() {
        return this.getBasicSummaryCfg("current")
    },
    stepWarmUpgradeSummary: function(e, t, i, s) {
        var a = this;
        a.handleWarmUpgradeSummary(e, t, i, s, function(e) {
            "cancel_auto_launch" === e ? (a.sendCancelAutoLaunch(), a.owner.getEl().unmask(), a.owner.clearStatusBusy()) : "alert_error" === e && a.alertError(a.owner, t)
        })
    },
    getBasicCancelAutoLaunchCfg: function() {
        return this.getBasicWebapiCfg("cancel_auto_launch")
    },
    sendCancelAutoLaunch: function() {
        this.sendCompound(this.owner.current.getCancelAutoLaunchCfg())
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.FWUpgradePanel", {
    extend: "SYNO.SDS.StorageManager.Wizard.FWUpgradePanelTemplate",
    getListDriveCfg: function() {
        return [Ext.apply(this.getBasicListDriveCfg(), {}), Ext.apply(this.getBasicPollCfg(), {})]
    },
    handleListDrive: function(e, t, i, s, a) {
        var n, o, r = this,
            d = "alert_error";
        if (e && t.result[0].success) {
            if (o = t.result[0].data, "upgrading" === t.result[1].data.status) return r.owner.changeCard("default", !0), void a(d = "start_polling");
            r.resetGrids(), r.gridPanel = r.createNewGridPanel(), r.changeTitleAndDescState(0 === o.drives.length, o.access_network, "single"), n = o.drives.reduce(function(e, t) {
                var i = r.owner.diskMap[t.id];
                return void 0 !== i && e.push(Ext.apply({
                    id: t.id,
                    serial: t.serial,
                    current_version: t.current_fw,
                    available_version: t.available_fw,
                    status: t.status
                }, r.genDefDiskInfo(i))), e
            }, []), r.gridPanel.updateDrives(n), a(d = "finish_list_drive")
        } else a(d)
    },
    getPrepareCfg: function() {
        var e = this.gridPanel.dumpDrivesInfo();
        return [Ext.apply(this.getBasicPrepareCfg(e), {})]
    },
    handlePrepare: function(e, t, i, s, a) {
        var n, o = "alert_error";
        e && t.result[0].success ? ("need_reload" === (n = t.result[0].data.status) ? o = "reload_list_drive" : "drive_busy" === n ? o = "alert_drive_busy" : "not_enough_space_download_firmware" === n ? o = "alert_not_enough_space" : "no_available_firmware" === n ? o = "alert_no_network" : "lock_failed" === n ? o = "alert_lock_failed" : "cant_get_from_server" === n ? o = "alert_cant_get_from_server" : "need_reboot" === n ? o = "defer_upgrade" : "normal" === n && (o = "start_upgrade"), a(o)) : a(o)
    },
    getStartUpgradeCfg: function() {
        return [Ext.apply(this.getBasicStartUpgradeCfg(), {})]
    },
    getRebootConfirmMsg: function() {
        var e = SYNO.SDS.StorageUtils.isXA ? "fwupgrade_confirm_reboot_cluster" : "fwupgrade_confirm_reboot";
        return _T("disk_info", e)
    },
    handleStartUpgrade: function(e, t, i, s, a) {
        var n = "alert_error";
        e && t.result[0].success && (n = "start_polling"), a(n)
    },
    handleReboot: function() {
        SYNO.SDS.System.FirmwareUpgradeReboot()
    },
    getPollCfg: function() {
        return [Ext.apply(this.getBasicPollCfg(), {})]
    },
    handlePoll: function(e, t, i, s, a) {
        var n, o = "alert_error";
        e && t.result[0].success ? "upgrading" !== (n = t.result[0].data.status) && ("finished" === n && (o = "show_summary"), a(o)) : a(o)
    },
    getWarmUpgradeSummaryCfg: function() {
        return [Ext.apply(this.getBasicWarmUpgradeSummaryCfg(), {})]
    },
    handleWarmUpgradeSummary: function(e, t, i, s, a) {
        var n = "alert_error";
        e && t.result[0].success ? (this.owner.singleSummaryCmp.showSummary([t.result[0].data]), this.owner.changeCard("single_summary"), a(n = "cancel_auto_launch")) : a(n)
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.FWUpgradePanelSummaryTemplate", {
    extend: "SYNO.SDS.StorageManager.Wizard.FWUpgradePanelTemplate",
    createHeadlineCmp: function() {
        return new Ext.Container({
            cls: "sm-fwupgrade-desc-panel",
            items: [{
                xtype: "syno_displayfield",
                cls: "sm-fwupgrade-title",
                htmlEncode: !1,
                ref: "../titleCmp"
            }, {
                xtype: "syno_displayfield",
                value: _T("disk_info", "fwupgrade_has_new_firmware_desc"),
                ref: "../descCmp"
            }]
        })
    },
    changeType: function(e) {
        var t, i, s;
        switch (e) {
            case "success":
                t = "fwupgrade_result_successful_title", i = "green-status", s = "fwupgrade_result_successful_desc";
                break;
            case "fail":
                t = "fwupgrade_result_failed_title", i = "red-status", s = "fwupgrade_result_failed_desc";
                break;
            case "upgrading":
                t = "fwupgrade_result_upgrading_title", i = "blue-status", s = "fwupgrade_result_upgrading_desc";
                break;
            default:
                return void SYNO.Debug.error("Unknown type: ", e)
        }
        this.titleCmp.setValue(String.format('<span class="{0}">{1}</span>', i, _T("disk_info", t))), this.descCmp.setValue(_T("disk_info", s))
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.FWUpgradePanelSummary", {
    extend: "SYNO.SDS.StorageManager.Wizard.FWUpgradePanelSummaryTemplate",
    showSummary: function(e) {
        var t, i = e[0];
        t = i.drives.every(function(e) {
            return !0 === e.success
        }), this.changeType(t ? "success" : "fail"), this.resetGrids(), this.createNewGridPanel(t ? "successful_summary" : "failed_summary").loadDrivesInfo(i.drives)
    },
    getCancelAutoLaunchCfg: function() {
        return [Ext.apply(this.getBasicCancelAutoLaunchCfg(), {})]
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.SHAFWUpgradePanel", {
    extend: "SYNO.SDS.StorageManager.Wizard.FWUpgradePanelTemplate",
    NODES: 2,
    constructor: function(e) {
        var t = this,
            i = Array.apply(null, {
                length: t.NODES
            });
        t.involve_list = i.map(Function.call, function() {
            return !1
        }), t.hostname_list = i.map(Function.call, function() {
            return ""
        }), t.drive_grid_list = [], t.callParent([e])
    },
    getListDiskCfg: function() {
        return {
            api: "SYNO.Core.Storage.Disk",
            method: "list",
            version: "1",
            params: {
                offset: 0,
                limit: -1
            }
        }
    },
    getRebootConfirmMsg: function() {
        return _T("disk_info", "fwupgrade_confirm_reboot_cluster")
    },
    genRemoteWebapi: function(e) {
        return {
            api: "SYNO.SHA.Util",
            method: "send_remote_webapi",
            version: 1,
            params: {
                remote_api: e.api,
                remote_method: e.method,
                remote_version: e.version,
                remote_params: e.params ? e.params : {}
            }
        }
    },
    updateGridList: function(e, t, i, s) {
        var a = this,
            n = t.reduce(function(e, t) {
                if (void 0 !== i[t.id]) {
                    var s = Ext.apply({
                        id: t.id,
                        serial: t.serial,
                        current_version: t.current_fw,
                        available_version: t.available_fw,
                        status: t.status
                    }, a.genDefDiskInfo(i[t.id]));
                    e.push(s)
                }
                return e
            }, []);
        e.updateDrives(n), e.setTitleVisible(!0), e.setTableTitle(s)
    },
    groupByNodeNum: function(e) {
        var t = this;
        return e.reduce(function(e, i, s) {
            return e[s % t.NODES].push(i), e
        }, Array.apply(null, {
            length: t.NODES
        }).map(Function.call, function() {
            return []
        }))
    },
    genWebapiGroup: function(e) {
        var t = this,
            i = function(e, i) {
                switch (i) {
                    case 0:
                        return e;
                    case 1:
                        return t.genRemoteWebapi(e);
                    default:
                        return {}
                }
            };
        return Array.isArray(e) ? e.map(i) : Array.apply(null, {
            length: t.NODES
        }).map(Function.call, function() {
            return e
        }).map(i)
    },
    getListDriveCfg: function() {
        var e = [];
        return (e = e.concat(this.genWebapiGroup(this.getBasicListDriveCfg()))).push({
            api: "SYNO.SHA.Firmware.Upgrade",
            method: "get",
            version: 1
        }), e.push({
            api: "SYNO.SHA.Panel.Overview",
            method: "load",
            version: 1
        }), e
    },
    handleListDrive: function(e, t, i, s, a) {
        var n = this,
            o = t.result[t.result.length - 1],
            r = t.result[t.result.length - 2];
        if (e && o.success && o.data.success && r.success) {
            if (n.hostname_list = ["active" === o.data.lnode.role ? o.data.lnode.hostname : o.data.rnode.hostname, "active" === o.data.lnode.role ? o.data.rnode.hostname : o.data.lnode.hostname], r.data.summary_data && r.data.summary_data.ui_json.summaryList.reduce(function(e, t, i) {
                    var s = n.involve_list[i] = "upgrading" === t.status;
                    return e || s
                }, !1)) return n.owner.shaSummaryCmp.showSummary(r.data.summary_data.ui_json.summaryList), n.owner.changeCard("sha_summary"), void n.owner.clearStatusBusy();
            n.resetGrids(), n.drive_grid_list = Array.apply(null, {
                length: n.NODES
            }).map(Function.call, function() {
                return n.createNewGridPanel()
            });
            var d = [n.owner.diskMap, n.owner.passiveDiskMap],
                l = n.groupByNodeNum(t.result.slice(0, t.result.length - 2)).reduce(function(e, t, i) {
                    var s = t[0];
                    if (!s.success) return n.drive_grid_list[i].setGridVisible(!1), n.involve_list[i] = !1, e;
                    var a = s.data,
                        o = d[i],
                        r = 0 === a.drives.length;
                    if (n.drive_grid_list[i].setGridVisible(!r), n.involve_list[i] = !r, !r) {
                        var l = String.format('{0} <span class="sm-fwupgrade-grid-subtitle">({1})</span>', n.hostname_list[i], 0 === i ? _TT("SYNO.SDS.HA.Instance", "ui", "active") : _TT("SYNO.SDS.HA.Instance", "ui", "passive"));
                        n.updateGridList(n.drive_grid_list[i], a.drives, o, l)
                    }
                    return e.up_to_date = e.up_to_date && r, e.access_network = e.access_network && a.access_network, e
                }, {
                    up_to_date: !0,
                    access_network: !0
                });
            n.changeTitleAndDescState(l.up_to_date, l.access_network, "sha"), a("finish_list_drive")
        } else a("alert_error")
    },
    getPrepareCfg: function() {
        var e = this,
            t = e.drive_grid_list.map(function(t) {
                var i = t.dumpDrivesInfo();
                return e.getBasicPrepareCfg(i)
            });
        return e.genWebapiGroup(t)
    },
    handlePrepare: function(e, t, i, s, a) {
        var n = this;
        if (e) {
            a({
                error: "alert_error",
                need_reload: "reload_list_drive",
                drive_busy: "alert_drive_busy",
                not_enough_space_download_firmware: "alert_not_enough_space",
                lock_failed: "alert_lock_failed",
                cant_get_from_server: "alert_cant_get_from_server",
                no_available_firmware: "alert_no_network",
                need_reboot: "defer_upgrade",
                normal: "start_upgrade"
            } [t.result.reduce(function(e, t, i) {
                if (n.involve_list[i] && !t.success) return "error";
                if ("error" === e) return e;
                var s = n.involve_list[i] ? t.data.status : "normal";
                return "need_reload" === e || "need_reload" === s ? "need_reload" : "drive_busy" === e || "drive_busy" === s ? "drive_busy" : "not_enough_space_download_firmware" === e || "not_enough_space_download_firmware" === s ? "not_enough_space_download_firmware" : "no_available_firmware" === e || "no_available_firmware" === s ? "no_available_firmware" : "lock_failed" === e || "lock_failed" === s ? "lock_failed" : "cant_get_from_server" === e || "cant_get_from_server" === s ? "cant_get_from_server" : "need_reboot" === e || "need_reboot" === s ? "need_reboot" : "normal" === e && "normal" === s ? "normal" : (n.involve_list[i] = function(e) {
                    return "defer_upgrade" === e || "start_upgrade" === e
                }(s), "normal")
            }, "normal")])
        } else a("alert_error")
    },
    getStartUpgradeCfg: function() {
        return [{
            api: "SYNO.SHA.Firmware.Upgrade",
            method: "set",
            version: 1,
            params: {
                firmware_upgrade_list: this.involve_list,
                upgrade_type: "start_upgrade"
            }
        }]
    },
    handleStartUpgrade: function(e, t, i, s, a) {
        var n = "alert_error";
        e && (n = "start_polling"), a(n)
    },
    handleReboot: function() {
        var e = {
            firmware_upgrade_list: this.involve_list,
            upgrade_type: "defer_upgrade"
        };
        SYNO.SDS.HA.RebootHA(this, e)
    },
    getPollCfg: function() {
        return this.genWebapiGroup(this.getBasicPollCfg())
    },
    handlePoll: function(e, t, i, s, a) {
        var n = this;
        e ? t.result.every(function(e, t) {
            return !n.involve_list[t] || (!e.success || "finished" === e.data.status)
        }) && a("show_summary") : a("alert_error")
    },
    getWarmUpgradeSummaryCfg: function() {
        return this.genWebapiGroup(this.getBasicWarmUpgradeSummaryCfg())
    },
    handleWarmUpgradeSummary: function(e, t, i, s, a) {
        var n = this,
            o = "alert_error";
        if (e) {
            var r = t.result.map(function(e, t) {
                return {
                    involve: n.involve_list[t],
                    drives: e.success ? e.data.drives : [],
                    hostname: n.hostname_list[t],
                    status: "finished"
                }
            });
            n.owner.shaSummaryCmp.showSummary(r), n.owner.changeCard("sha_summary"), a(o = "cancel_auto_launch")
        } else a(o)
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.SHAFWUpgradePanelSummary", {
    extend: "SYNO.SDS.StorageManager.Wizard.FWUpgradePanelSummaryTemplate",
    NODES: 2,
    showSummary: function(e) {
        var t = this;
        t.resetGrids();
        var i = e.map(function(e, i) {
                var s = t.createNewGridPanel(),
                    a = e.involve,
                    n = "upgrading" === e.status,
                    o = function() {
                        if (a) return n ? "upgrading" : 0 === e.drives.length ? "error" : e.drives.every(function(e) {
                            return !0 === e.success
                        }) ? "success" : "fail"
                    }(),
                    r = String.format('{0} <span class="sm-fwupgrade-grid-subtitle">({1})</span>', e.hostname, 0 === i ? _TT("SYNO.SDS.HA.Instance", "ui", "active") : _TT("SYNO.SDS.HA.Instance", "ui", "passive"));
                return s.setTitleVisible(a), s.setDescVisible(a && "error" === o), s.setLoadingDescVisible(a && "upgrading" === o), s.setGridVisible(a && ("success" === o || "fail" === o)), s.setTableTitle(r), s.setDesc(_T("disk_info", "fwupgrade_result_failed_desc")), s.setLoadingDesc(_T("disk_info", "fwupgrade_result_upgrading_desc")), a && ("success" !== o && "fail" !== o || (s.loadDrivesInfo(e.drives), s.setType("success" === o ? "successful_summary" : "failed_summary"))), o
            }),
            s = i.some(function(e) {
                return "upgrading" === e
            });
        t.changeType(s ? "upgrading" : i.every(function(e) {
            return void 0 === e || "success" === e
        }) ? "success" : "fail"), s ? t.startPolling() : t.stopPolling()
    },
    genPollingTask: function() {
        return {
            interval: 3,
            immediate: !0,
            webapi: {
                api: "SYNO.SHA.Firmware.Upgrade",
                method: "get",
                version: 1
            },
            status_callback: function(e, t, i) {
                e && this.showSummary(t.summary_data.ui_json.summaryList)
            },
            scope: this
        }
    },
    startPolling: function() {
        this.poll || (this.poll = this.pollReg(this.genPollingTask()))
    },
    stopPolling: function() {
        this.poll && (this.pollUnreg(this.poll), this.poll = null)
    },
    getCancelAutoLaunchCfg: function() {
        return [{
            api: "SYNO.SHA.Firmware.Upgrade",
            method: "cancel_auto_launch",
            version: 1
        }]
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.UploadDBDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.owner = e.owner, this.updateLastUpdateTime = e.updateLastUpdateTime;
        var t = Ext.apply({
            dsmStyle: "v5",
            title: _T("disk_info", "disk_upload_db_title"),
            resizable: !1,
            closable: !0,
            width: 600,
            height: 350,
            useStatusBar: !0,
            padding: "16px 20px 0px 20px",
            items: this.getItems(),
            layout: {
                type: "vbox",
                align: "stretch"
            },
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: function() {
                    this.close()
                }
            }, {
                text: _T("disk_info", "disk_upload_db_apply_btn"),
                scope: this,
                btnStyle: "blue",
                handler: this.onSubmit
            }]
        }, e);
        this.callParent([t])
    },
    getItems: function() {
        var e = [];
        return e.push(this.createMainUploadForm()), e.push({
            xtype: "box",
            flex: 1
        }), e.push({
            xtype: "syno_displayfield",
            htmlEncode: !1,
            margins: {
                top: 0,
                right: 0,
                bottom: 12,
                left: 0
            },
            value: _T("disk_info", "disk_upload_db_note")
        }), e
    },
    createMainUploadForm: function() {
        return new SYNO.SDS.Utils.FormPanel({
            itemId: "upload_main",
            padding: "0px 0px",
            fileUpload: !0,
            trackResetOnLoad: !0,
            frame: !1,
            border: !1,
            webapi: {
                api: "SYNO.Core.Storage.Disk",
                method: "upload_offlinekit",
                version: 1
            },
            items: [{
                xtype: "syno_displayfield",
                htmlEncode: !1,
                value: _T("disk_info", "disk_upload_db_desc")
            }, {
                xtype: "syno_filebutton",
                fieldLabel: _T("itunes", "itunes_path"),
                name: "offline_kit_file"
            }],
            onApiSuccess: Ext.createDelegate(this.onMainUploadSuccess, this),
            onApiFailure: Ext.createDelegate(this.onUploadFailed, this)
        })
    },
    onSubmit: function() {
        var e = this.get("upload_main");
        this.validFileName(e.getForm().findField("offline_kit_file")) && (this.setStatusBusy({
            text: _T("update", "update_uploading")
        }), e.upload())
    },
    validFileName: function(e) {
        if (!e) return !1;
        if (!e.isDirty()) return this.getMsgBox().alert("", _T("error", "error_nochoosefile")), !1;
        var t = e.getValue();
        return ".sa" == t.substr(t.length - 3, 3) || (this.getMsgBox().alert("", _T("disk_info", "disk_upload_db_error_verify")), !1)
    },
    onMainUploadSuccess: function(e, t, i) {
        this.clearStatusBusy(), this.updateLastUpdateTime(t.db_last_update_time), this.appWin.getToastBox(_T("disk_info", "disk_update_db_finish"), !1, null, {
            delay: 3e3
        }), this.close()
    },
    onUploadFailed: function(e, t, i) {
        this.clearStatusBusy(), this.getMsgBox().alert("", SYNO.API.getErrorString(t.code))
    }
}), SYNO.SDS.StorageManager.Wizard.DiskStep = function(e) {
    var t = {
            needNewDisk: !0,
            isAddMirror: !1
        },
        i = {
            repair: "repair",
            expand_by_disk: "add",
            convert_shr_to_pool: "convert",
            expand_unfinished_shr: "unfinish_shr"
        } [e.add_type],
        s = e.space.disks.length,
        a = SYNO.SDS.StorageManager.StoragePool.RaidLevelDesc,
        n = {
            shr_without_disk_protect: "shr",
            shr_with_1_disk_protect: "shr",
            shr_with_2_disk_protect: "shr_2"
        } [e.space.device_type] || e.space.device_type,
        o = {
            currentPoolNumID: e.space.num_id
        },
        r = {
            minNewDiskCount: "wizard-disk-num-cls"
        },
        d = SYNO.SDS.StorageUtils,
        l = e.space.can_do[e.add_type],
        p = a[n].max - s,
        u = {
            repair: {
                min: 1,
                max: l
            },
            expand_by_disk: {
                min: l,
                max: p
            },
            convert_shr_to_pool: {
                min: l,
                max: p
            },
            expand_unfinished_shr: {
                min: l.migrate_to_shr2 || 1,
                max: p
            }
        };
    return !SYNO.SDS.StorageUtils.supportRaidGroup || e.isSHR ? (e.diskStepDesc = d.getDiskStepDesc(t, i, "select", u[e.add_type].max, u[e.add_type].min, o, r), new SYNO.SDS.StorageManager.Wizard.ClassicDiskStep(e)) : (e.diskStepDesc = d.getDiskStepDesc(t, i, "drag", u[e.add_type].max, u[e.add_type].min, o, r), new SYNO.SDS.StorageManager.Wizard.AdvDiskStep(e))
}, Ext.define("SYNO.SDS.StorageManager.Wizard.ClassicDiskStep", {
    extend: "SYNO.SDS.StorageManager.Wizard.Step",
    space: null,
    allowBlank: !1,
    filter: void 0,
    free_disks: null,
    free_disks_for_expand: null,
    disks: null,
    defaultChecked: !0,
    constructor: function(e) {
        var t, i = this;
        i.space = e.space || null, i.free_disks = e.advDisks, i.validator = i.diskChooserValidater, i.gridView = i.createGrid({
            ref: "disksField"
        }), Object.assign(i, e.funcs), delete e.funcs, i.unavailableDisks = [], i.actionTitleDesc = e.diskStepDesc, t = {
            cls: "sm-classic-disk-step",
            headline: _T("storage_pool", "select_drives_title"),
            labelWidth: 200,
            height: 405,
            layout: "fit",
            items: [{
                xtype: "syno_panel",
                ref: "borderPanel",
                layout: "border",
                items: [{
                    xtype: "syno_displayfield",
                    cls: "classic-disk-step-desc",
                    ref: "actionField",
                    region: "north",
                    value: e.diskStepDesc,
                    htmlEncode: !1
                }, {
                    xtype: "syno_panel",
                    ref: "center",
                    region: "center",
                    cls: "wizard-common-disk-sel-section",
                    items: [i.gridView, {
                        xtype: "syno_displayfield",
                        ref: "sizeField",
                        value: "",
                        htmlEncode: !1,
                        style: {
                            "white-space": "nowrap",
                            overflow: "hidden",
                            "text-overflow": "ellipsis"
                        }
                    }]
                }, {
                    xtype: "syno_displayfield",
                    region: "south",
                    value: String.format("<span class='teal-status'>{0}</span><span>{1}</span>", _T("volume", "cache_notice"), " " + _T("storage_pool", "new_drive_note")),
                    htmlEncode: !1
                }]
            }]
        }, i.callParent([Ext.apply(t, e)]), this.mon(i.gridView, "rowclick", this.onEnableClick.bind(this))
    },
    openDriveRequirementWindow: function() {
        var e = this.getDiskReasonWindowConfig(this.unavailableDisks, this.diskConfition);
        this.openDiskReasonWindow(this.owner, e)
    },
    addListenerOnClickLink: function() {
        Ext.select(".open-drive-requirement-info").on("click", this.openDriveRequirementWindow.bind(this))
    },
    updateEstimateSize: function() {
        var e = this,
            t = this.getIds(),
            i = {
                estimate_for: this.add_type,
                space_id: this.space.id,
                disk_id: t,
                device_type: this.space.device_type
            },
            s = "",
            a = e.borderPanel.center.sizeField,
            n = "expand_unfinished_shr" === this.add_type;
        0 !== t.length || n ? (this.estimateReqId && Ext.Ajax.abort(this.estimateReqId), this.estimateReqId = SYNO.API.Request({
            api: "SYNO.Storage.CGI.Pool",
            method: "estimate_size",
            version: 1,
            params: i,
            callback: function(t, i) {
                this.estimatReqId = null, t ? (s = e.getEstimateSizeHtml(i.size), a.setValue(s)) : SYNO.SDS.StorageUtils.ReportWebapiFailure(this, i)
            },
            scope: e
        }).tId) : (s = e.getEstimateSizeHtml(this.space.size.total), a.setValue(s))
    },
    getEstimateSizeHtml: function(e) {
        var t, i = SYNO.SDS.StorageUtils.GetSizeUnit(e),
            s = "<span>" + _T("storage_pool", "estimate_capacity") + _T("common", "colon") + "</span>",
            a = this.getIds(),
            n = 0,
            o = 0,
            r = {
                curDiskCnt: this.space.disks.length,
                newSelectCnt: a.length,
                isAddDisk: "expand_by_disk" === this.add_type,
                styleClass: "wizard-disk-num-cls"
            },
            d = {
                shr_without_disk_protect: "shr",
                shr_with_1_disk_protect: "shr",
                shr_with_2_disk_protect: "shr_2"
            } [this.space.device_type] || this.space.device_type;
        switch (o = SYNO.SDS.StorageManager.StoragePool.RaidLevelDesc[d].max - this.space.disks.length, this.add_type) {
            case "repair":
                n = 1, o = this.space.can_do.repair;
                break;
            case "expand_by_disk":
                n = this.space.can_do.expand_by_disk;
                break;
            case "convert_shr_to_pool":
                n = this.space.can_do.convert_shr_to_pool;
                break;
            case "expand_unfinished_shr":
                var l = this.space.can_do.expand_unfinished_shr.migrate_to_shr2;
                n = "migrate_to_shr2" === this.getData("shr_operation", "not_shr_op") && l ? l : 0
        }
        return t = n - a.length, s + SYNO.SDS.StorageUtils.getEstimateSizeHtml("select", o < a.length, i, o, t, d, r)
    },
    onEnableClick: function() {
        this.updateEstimateSize()
    },
    createGrid: function(e) {
        this.enableColumn = new SYNO.ux.EnableColumn({
            owner: this,
            dataIndex: "enabled",
            id: "enable",
            bindRowClick: !0,
            align: "center",
            width: 32,
            listeners: {
                scope: this,
                click: this.onEnableClick,
                selectall: this.onEnableClick
            }
        });
        var t = Ext.apply({
            boxMaxHeight: 290,
            enableHdMenu: !1,
            layout: "fit",
            cls: "without-dirty-red-grid",
            plugins: this.enableColumn,
            columns: [this.enableColumn, {
                header: _T("volume", "volume_disknumber"),
                dataIndex: "nameHashValue",
                sortable: !0,
                renderer: function(e, t, i, s, a, n, o) {
                    return i.data.name
                }
            }, {
                header: _T("volume", "volume_diskmodel"),
                dataIndex: "model",
                sortable: !0
            }, {
                header: _T("volume", "volume_disk_type"),
                dataIndex: "diskType",
                sortable: !0,
                width: 67
            }, {
                header: _T("volume", "4k_hdd_title"),
                dataIndex: "is4Kn",
                sortable: !0,
                width: 67,
                renderer: function(e) {
                    return e ? _T("common", "yes") : _T("common", "no")
                }
            }, {
                header: _T("volume", "volume_diskcapacity"),
                dataIndex: "size_total",
                sortable: !0,
                renderer: function(e, t, i, s, a, n, o) {
                    return SYNO.SDS.StorageUtils.SizeRender(e)
                }
            }],
            store: this.disks = new Ext.data.JsonStore({
                autoDestroy: !0,
                fields: ["id", "enabled", "name", "model", "size_total", "container", "numId", "diskType", "is4Kn", "nameHashValue", "compatibility", "unc", "remote_info"],
                listeners: {
                    update: function(e, t, i) {
                        Ext.data.Record.EDIT === i && (this.allowBlank || this.onRecordUpdate())
                    },
                    scope: this
                }
            })
        }, e);
        return new SYNO.ux.GridPanel(t)
    },
    loadDisks: function() {
        var e = this,
            t = SYNO.SDS.StorageUtils,
            i = e.defaultChecked,
            s = this.getSource(),
            a = [],
            n = e.borderPanel.center.disksField;
        e.free_disks = e.free_disks.filter(function(e) {
            return !("internal" === s && !e.isInternal()) && !("ebox" === s && !e.isInEbox())
        }), e.diskCondition.checkLocation = {
            location: s
        }, Ext.each(e.free_disks, function(s) {
            var n = e.hasAbnormalDisk(s);
            a.push({
                enabled: i && !n,
                id: s.id,
                num_id: s.num_id,
                name: s.name,
                nameHashValue: t.DiskNameHashValueGet(s.container.order, s.num_id, s.portType),
                model: s.model,
                size_total: parseInt(s.size_total, 10),
                container: s.container,
                diskType: s.isSsd ? "SSD" : "HDD",
                is4Kn: s.is4Kn,
                compatibility: s.compatibility,
                unc: s.get("unc"),
                remote_info: s.get("remote_info")
            })
        }), a.sort(function(e, t) {
            return e.container.order > t.container.order ? 1 : e.container.order < t.container.order ? -1 : e.num_id > t.num_id ? 1 : e.num_id < t.num_id ? -1 : 0
        }), e.disks.loadData(a, !1), n.setHeight(28 + 29 * (a.length + 1) + 1)
    },
    loadUnavailableDisks: function() {
        var e = this,
            t = e.getDiskDifference(e.allDisks, e.free_disks);
        e.unavailableDisks = t.filter(function(t) {
            var i = e.isDiskQualified(t, e.diskCondition).unqualifiedReasons;
            return e.isDiskToBeShowed(i)
        })
    },
    getAvailableDisksForAdd: function(e) {
        var t = this.owner.getPoolObject(),
            i = t.get("minimal_disk_size"),
            s = t.get("container"),
            a = [],
            n = [],
            o = !1,
            r = this.diskMap,
            d = function(s) {
                return -1 === t.get("device_type").indexOf("shr") || "expand_by_disk" !== e ? s.isBiggerThan(i) : s.isBiggerThan(i) || s.isEqualToAny(n)
            };
        return s && t.get("can_do") ? (t.get("disks").forEach(function(e) {
            var t = r[e];
            if (!t) return !0;
            t.is4Kn && (o = !0), n.push(parseInt(t.get("size_total"), 10))
        }, this), t.get("can_do").raid_cross ? a = this.getMatchedDisk(function() {
            return this.isNormalTray() && this.isFree() && d(this) && (this.is4Kn && o || !this.is4Kn && !o)
        }) : "internal" === s ? a = this.getMatchedDisk(function() {
            return this.isNormalTray() && this.isFree() && this.isInternal() && d(this) && (this.is4Kn && o || !this.is4Kn && !o)
        }) : "ebox" === s && (a = this.getMatchedDisk(function() {
            return this.isFree() && this.isInEbox() && d(this) && (this.is4Kn && o || !this.is4Kn && !o)
        })), a) : a
    },
    isInternal: function(e) {
        return "internal" === e.get("container").type
    },
    isNeedCrossWarning: function() {
        var e, t, i = !1,
            s = !1;
        if (this.space) {
            if ("cross" === (t = this.space.get("container"))) return !1;
            "internal" === t ? i = !0 : s = !0
        }
        for (e = 0; e < this.disks.getCount(); e++)
            if (this.disks.getAt(e).get("enabled") && (this.isInternal(this.disks.getAt(e)) ? i = !0 : s = !0, i && s)) return !0;
        return !1
    },
    isNeedPowerButtonDisableWarning: function() {
        for (var e = 0; e < this.disks.getCount(); e++)
            if (this.disks.getAt(e).get("enabled") && this.disks.getAt(e).get("container").supportPwrBtnDisable) return !0;
        return !1
    },
    isSelectAny: function() {
        for (var e = 0; e < this.disks.getCount(); e++)
            if (this.disks.getAt(e).get("enabled")) return !0;
        return !1
    },
    getIds: function() {
        var e = [];
        return this.disks.each(function(t) {
            t.get("enabled") && e.push(t.id)
        }), e
    },
    getNames: function() {
        var e = [];
        return this.disks.each(function(t) {
            t.get("enabled") && e.push(t.get("name"))
        }), e
    },
    getDisks: function() {
        var e = [];
        return this.disks.each(function(t) {
            t.get("enabled") && e.push(t)
        }), e
    },
    getStore: function() {
        return this.disks
    },
    getSource: function() {
        return this.space && !SYNO.SDS.StorageUtils.isSupportRaidCross ? this.space.get("container") : this.getData("disk_source", "all")
    },
    diskChooserValidater: function() {
        var e, t, i = this,
            s = this.getData("manage_action", "create"),
            a = this.getData("raid_level"),
            n = this.getDisks(),
            o = n.length,
            r = !1,
            d = !1,
            l = !1;
        if ("create" !== s && (e = this.owner.getPoolObject()), 0 < (t = this.getDiskCountLimit(e, s)).max && o > t.max) return this.owner.getMsgBox().alert("", String.format(_T("volume", "volume_max_disks_count"), t.max)), !1;
        if (o < t.min) return this.owner.getMsgBox().alert("", String.format(_T("volume", "volume_min_disk_count"), t.min)), !1;
        if ("create" === s && "raid_10" === a && 0 != o % 2) return this.owner.getMsgBox().alert("", _T("volume", "raid10_constrain")), !1;
        if (e) {
            if (this.isDiskExceedMax(n, e)) return this.owner.getMsgBox().alert("", _T("volume", "volume_disk_3tb_limitation")), !1;
            if (Ext.each(e.get("disks"), function(e) {
                    return r = i.diskMap[e].is4Kn, !1
                }), Ext.each(n, function(e) {
                    e.get("is4Kn") ? d = !0 : l = !0
                }), r && l || !r && d) return this.owner.getMsgBox().alert("", _T("volume", "not_allow_hybrid_hdd")), !1
        }
        return !0
    },
    getDiskCountLimit: function(e, t) {
        var i = e ? e.get("can_do") : {},
            s = this.getData("migrate_type"),
            a = this.getData("raid_level"),
            n = 0,
            o = 0;
        switch (t) {
            case "create":
                o = SYNO.SDS.StorageUtils.RAIDDiskMinMaxCountGet(a).min, n = SYNO.SDS.StorageUtils.RAIDDiskMinMaxCountGet(a).max;
                break;
            case "repair":
                n = i.repair;
                break;
            case "expand":
                o = i.expand;
                break;
            case "convert_shr_to_pool":
                o = i.convert_shr_to_pool;
                break;
            case "expand_unfinished_shr":
                switch (this.getData("shr_operation")) {
                    case "add_disk":
                    case "hotspare_repair":
                        o = 0;
                        break;
                    case "migrate_to_shr2":
                        o = i.expand_unfinished_shr.migrate_to_shr2
                }
        }
        if (Ext.isDefined(s)) switch (s) {
            case "add_mirror":
                n = i.migrate.add_mirror;
                break;
            case "to_raid1":
                n = i.migrate.to_raid1;
                break;
            case "to_raid5+spare":
                var r = i.migrate["to_raid5+spare"].split("-");
                o = parseInt(r[0], 10), n = parseInt(r[1], 10);
                break;
            case "to_raid5":
                o = i.migrate.to_raid5;
                break;
            case "to_raid6":
                o = i.migrate.to_raid6;
                break;
            case "to_shr2":
                o = i.migrate.to_shr2
        }
        return {
            max: n,
            min: o
        }
    },
    isDiskExceedMax: function(e, t) {
        var i = parseInt(t.get("maximal_disk_size"), 10);
        if (void 0 === i || 0 === i) return !1;
        for (var s = 0; s < e.length; s++)
            if (i < parseInt(e[s].get("size_total"), 10)) return !0;
        return !1
    },
    refreshDesc: function() {
        var e = this,
            t = this.getData("shr_operation", "not_shr_op"),
            i = e.borderPanel.actionField,
            s = e.actionTitleDesc,
            a = e.unavailableDisks.length;
        if ("add_disk" === t || "migrate_to_shr2" === t) {
            var n = {
                    shr_without_disk_protect: "shr",
                    shr_with_1_disk_protect: "shr",
                    shr_with_2_disk_protect: "shr_2"
                } [e.space.device_type],
                o = SYNO.SDS.StorageManager.StoragePool.RaidLevelDesc,
                r = {
                    add_disk: {
                        mode: "add",
                        minDisk: 0,
                        maxDisk: o[n].max - e.space.disks.length,
                        RAIDTypeAfter: {
                            shr: "SHR",
                            shr_2: "SHR-2"
                        } [n]
                    },
                    migrate_to_shr2: {
                        mode: "migrate",
                        minDisk: e.space.can_do.expand_unfinished_shr.migrate_to_shr2,
                        maxDisk: o.shr_2.max - e.space.disks.length,
                        RAIDTypeAfter: "SHR-2"
                    }
                },
                d = {
                    needNewDisk: 0 < r[t].minDisk,
                    isAddMirror: !1
                },
                l = {
                    currentPoolNumID: e.space.num_id,
                    RAIDTypeLabel: r[t].RAIDTypeAfter
                };
            s = SYNO.SDS.StorageUtils.getDiskStepDesc(d, r[t].mode, "select", r[t].maxDisk, r[t].minDisk, l)
        }
        if (0 < a) {
            var p = 1 === a ? "disk_reason_add_drive_single_desc_link" : "disk_reason_add_drive_multi_desc_link";
            s = s + " " + String.format(_T("disk_info", p), "open-drive-requirement-info", a)
        }
        i.setValue(s), e.borderPanel.doLayout()
    },
    refreshDescAndEstimateSize: function() {
        this.allowBlank = this.getData("allow_disk_blank", !1), this.onRecordUpdate(), this.refreshDesc(), this.updateEstimateSize()
    },
    activate: function() {
        var e, t = this,
            i = this.getData("wizard_mode"),
            s = this.getData("manage_action");
        if ("pool_manage" === i && (t.addType = s), e = this.getSource(), t.diskSource != e) {
            t.diskSource = e, t.defaultChecked = this.getData("disk_default_checked", !0), "pool_manage" !== i && (t.free_disks = t.allDisks.filter(function(e) {
                return e.isNormalTray() && e.isFree()
            }), t.diskCondition = {}, t.diskCondition.checkDiskNormalTray = {
                isDiskNormalTray: !0
            }, t.diskCondition.checkDiskFree = {
                freeType: "available"
            });
            var a = this.getData("shr_operation", "not_shr_op");
            "add_disk" !== a && "migrate_to_shr2" !== a || (t.mon(t.ownerCt, "activate", t.refreshDescAndEstimateSize.bind(t)), t.refreshDescAndEstimateSize()), "pool_manage" === i && this.defaultChecked && (this.defaultChecked = !1), t.loadDisks(), t.loadUnavailableDisks(), this.refreshDesc(), t.addListenerOnClickLink(), t.updateEstimateSize(), t.owner.doLayout()
        }
    },
    onRecordUpdate: function() {
        this.allowBlank || this.isSelectAny() ? this.owner.getButton("next").enable() : this.owner.getButton("next").disable()
    },
    updateData: function(e) {
        e.disk_ids = this.getIds(), e.disk_groups = []
    },
    checkEboxWarning: function() {
        var e, t, i = this,
            s = [];
        return !this.raidGroup && this.isNeedPowerButtonDisableWarning() && s.push(_T("storage_pool", "ebox_power_button_disabled")), !this.raidGroup && this.isNeedCrossWarning() && s.push(_T("storage_pool", "ebox_internal_mix_warning")), 0 === s.length || (t = '<div class="sm-storage-warning-dlg-title">' + _T("storage_pool", "wizard_disk_step_ebox_dlg_title") + '</div><div class="sm-msg-box-list-section-under-title">{0}</div>', e = String.format(t, s.map(function(e) {
            return '<div class="sm-suggestion-list-item">' + e + "</div>"
        }).join("")), new SYNO.SDS.StorageManager.Dialog.Confirm({
            owner: this.owner,
            warningMsg: e,
            callback: function(e) {
                e && i.owner.goNextWithoutCheck()
            }
        }).open(), !1)
    },
    beforeNext: function() {
        var e, t = this,
            i = this,
            s = this.getDisks(),
            a = !1,
            n = !1;
        if (e = this.getIds().length, Ext.isFunction(this.validator) && !this.validator()) return !1;
        if (Ext.each(s, function(e) {
                e.get("is4Kn") ? n = !0 : a = !0
            }), a && n) return this.owner.getMsgBox().alert("", _T("volume", "not_allow_hybrid_hdd")), !1;
        if (0 === e && this.allowBlank) return !0;
        if (!0 !== i.hasAbnormalDisk(s)) return i.checkEboxWarning();
        var o = i.getDiskAlertMsg(s),
            r = {
                yes: {
                    text: _T("common", "continue"),
                    btnStyle: "red"
                },
                no: {
                    text: _T("common", "cancel")
                }
            };
        return this.openWarningBox(i.owner, o, r).then(function(e) {
            if ("yes" !== e) return !1;
            i.checkEboxWarning() && t.owner.goNextWithoutCheck()
        }).catch(function() {
            return !1
        }), !1
    },
    deactivate: function() {
        this.owner.getButton("next").enable()
    },
    summary: function(e) {
        this.getNames().length > 0 && e.append(_T("volume", "volume_apply_disk"), this.getNames().join(", "))
    },
    checkState: function() {
        var e = this;
        SYNO.SDS.Wizard.Step.prototype.checkState.apply(e, arguments), 0 < e.getDisks().length || e.allowBlank ? e.owner.getButton("next").enable() : e.owner.getButton("next").disable()
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.PoolFromStep", {
    extend: "SYNO.SDS.StorageManager.Wizard.Step",
    constructor: function(e) {
        var t;
        this.appWin = e.appWin, this.loaded = !1, t = {
            headline: _T("volume", "volume_choose_raid_title"),
            items: [{
                xtype: "syno_displayfield",
                htmlEncode: !1,
                value: _T("volume", "choose_pool_from_step_description")
            }, {
                xtype: "syno_displayfield",
                cls: "sm-empty-line"
            }, {
                xtype: "syno_radio",
                boxLabel: _T("volume", "volume_choose_existing_raid"),
                name: "poolstep",
                itemId: "existing",
                inputValue: "existing",
                checked: !0
            }, {
                xtype: "syno_radio",
                boxLabel: _T("volume", "volume_create_raid"),
                name: "poolstep",
                itemId: "create",
                inputValue: "create"
            }]
        }, this.callParent([Ext.apply(t, e)])
    },
    activate: function() {
        var e, t = this;
        t.loaded || (e = t.appWin.storagePools.getMatched("isFreeSizeBiggerThan1GB", "isWritable"), 0 === t.appWin.disks.getMatched("isNormalTray", "isFree").length ? t.getComponent("create").disable() : (t.getComponent("create").enable(), t.getComponent("create").setValue(!0)), 0 === e.length ? t.getComponent("existing").disable() : (t.getComponent("existing").enable(), t.getComponent("existing").setValue(!0)), t.loaded = !0)
    },
    updateData: function(e) {
        e.pool_from = this.getValues()
    },
    getNext: function() {
        return this.nextId[this.getForm().getValues().poolstep]
    },
    getValues: function() {
        return this.getForm().getValues().poolstep
    },
    summary: function(e) {}
}), Ext.define("SYNO.SDS.StorageManager.Wizard.VolumePropertyStep", {
    extend: "SYNO.SDS.StorageManager.Wizard.Step",
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.deviceType = void 0, i.maxFreeSizeGB = void 0, i.minSizeGB = 10, i.maxVolumeByte = parseInt(SYNO.SDS.StorageUtils.getMaxVolumeSize(), 10), i.maxFreeSizeByte = void 0, i.maxFreeSizeGB = void 0, i.sizeValueInput = void 0, i.deviceType = e.deviceType, i.setDefaultDesc = !0;
        var s = _T("volume", "volume_allocate_size_field_name");
        "lun" == i.deviceType && (s = _T("iscsilun", "iscsilun_allocate_size_field_name")), t = {
            headline: _T("volume", "volume_allocate_size_title"),
            items: [{
                xtype: "syno_displayfield",
                fieldLabel: _T("common", "name"),
                itemId: "pool_name"
            }, {
                xtype: "syno_textfield",
                itemId: "desc",
                name: "desc",
                fieldLabel: _T("share", "share_comment"),
                width: 300,
                maxLength: 64,
                enableKeyEvents: !0,
                value: "",
                listeners: {
                    keypress: function() {
                        this.setDefaultDesc = !1
                    },
                    scope: this
                }
            }, {
                xtype: "syno_displayfield",
                fieldLabel: _T("volume", "volume_totalsize"),
                itemId: "pool_total"
            }, {
                xtype: "syno_displayfield",
                fieldLabel: _T("volume", "volume_freesize"),
                itemId: "pool_free"
            }, {
                indent: 0,
                xtype: "panel",
                layout: "hbox",
                itemId: "size",
                border: !1,
                fieldLabel: String.format("{0} ({1})", s, _T("common", "size_gb")),
                labelStyle: "line-height: 28px;padding:0px;",
                bodyStyle: {
                    padding: "0px 0px 0px 0px"
                },
                items: [{
                    xtype: "syno_numberfield",
                    allowDecimals: !1,
                    width: 100,
                    value: "10",
                    itemId: "size_value"
                }, {
                    xtype: "syno_button",
                    itemId: "size_max",
                    text: _T("common", "max"),
                    handler: function(e, t) {
                        this.SizeValueInput.setValue(this.maxFreeSizeGB)
                    },
                    style: {
                        "margin-left": "6px"
                    },
                    scope: this
                }]
            }]
        }, this.callParent([Ext.apply(t, e)])
    },
    getEstimatedSize: function() {
        var e = this,
            t = "multiple" === this.getData("raid_type");
        e.owner.setStatusBusy(), e.owner.getButton("next").disable(), SYNO.API.Request({
            api: "SYNO.Storage.CGI.Pool",
            method: "estimate_size",
            version: 1,
            params: {
                estimate_for: "create",
                disk_id: e.owner.getDiskIds(),
                device_type: e.owner.getRaidLevel()
            },
            callback: function(i, s, a, n) {
                var o, r;
                if (e.owner.clearStatusBusy(), !i) return SYNO.SDS.StorageUtils.ReportWebapiFailure(this, s), void e.owner.getButton("next").disable();
                o = r = s.size, t && (o = Math.min(e.maxVolumeByte, o)), e.updatePoolInfo({
                    freeByte: o,
                    totalByte: r,
                    poolId: s.new_pool_path
                })
            },
            scope: e
        })
    },
    getPoolSize: function(e) {
        var t = this.appWin.storagePools.data[e],
            i = t.get("size"),
            s = parseInt(i.used, 10),
            a = parseInt(i.total, 10),
            n = a - s;
        t.supportMultiple() && (n = Math.min(this.maxVolumeByte, n)), this.updatePoolInfo({
            freeByte: n,
            totalByte: a,
            poolId: e
        })
    },
    updatePoolInfo: function(e) {
        var t = SYNO.SDS.StorageUtils;
        this.maxFreeSizeGB = t.GetSizeGB(e.freeByte, 0), this.maxFreeSizeByte = e.freeByte, this.getComponent("pool_name").setValue(t.SpaceIDParser(e.poolId).str), this.getComponent("pool_total").setValue(t.SizeRender(e.totalByte, 2)), this.getComponent("pool_free").setValue(String.format("{0} {1}", this.maxFreeSizeGB, _T("common", "size_gb"))), this.SizeValueInput.setValue(this.maxFreeSizeGB), "single" === this.getData("raid_type") ? (this.SizeValueInput.disable(), this.SizeValueBtn.disable()) : (this.SizeValueInput.enable(), this.SizeValueBtn.enable()), this.updateDesc()
    },
    updateDesc: function() {
        var e, t = "";
        this.setDefaultDesc && (t += String.format(_T("volume", "volume_default_desc"), this.getComponent("pool_name").getValue()), t += ", ", e = this.getData("raid_level"), t += SYNO.SDS.StorageUtils.RaidLevelRender(e), this.getComponent("desc").setValue(t))
    },
    getAllocateByte: function() {
        var e = this.SizeValueInput.getValue();
        return e === this.maxFreeSizeGB ? this.maxFreeSizeByte : 1024 * e * 1024 * 1024
    },
    getDescription: function() {
        return this.getComponent("desc").getValue()
    },
    activate: function() {
        var e = this.getData("quick_mode"),
            t = this.getData("pool_from"),
            i = this.getData("selected_pool_id");
        this.SizeValueInput = this.getComponent("size").getComponent("size_value"), this.SizeValueBtn = this.getComponent("size").getComponent("size_max"), this.getComponent("size").doLayout(), e || "create" === t ? this.getEstimatedSize() : i && this.getPoolSize(i)
    },
    updateData: function(e) {
        e.volume_description = this.getDescription(), e.allocate_byte = this.getAllocateByte()
    },
    getNext: function() {
        var e, t, i, s = this,
            a = !1,
            n = this.getData("raid_type"),
            o = s.SizeValueInput.getValue();
        return !!this.getForm().isValid() && (s.maxFreeSizeGB < o ? (e = String.format("{0}", s.minSizeGB), t = String.format("{0}", s.maxFreeSizeGB), i = String.format(_T("volume", "volume_valid_range_warning"), e, t), a = !0) : s.minSizeGB > o && "single" !== n && (e = String.format("{0}", s.minSizeGB), i = String.format(_JSLIBSTR("extlang", "minnumber"), e), a = !0), a ? (s.SizeValueInput.markInvalid(i), !1) : s.nextId)
    },
    summary: function(e) {
        var t = String.format("{0} {1}", this.SizeValueInput.getValue(), _T("common", "size_gb"));
        e.append(_T("volume", "volume_pool"), this.getComponent("pool_name").getValue()), e.append(_T("volume", "volume_size_allocated"), t), e.append(_T("volume", "volume_desc"), this.getDescription())
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.DiskCheckStep", {
    extend: "SYNO.SDS.StorageManager.Wizard.Step",
    constructor: function(e) {
        var t = {
            headline: _T("volume", "volume_diskcheck"),
            items: [{
                xtype: "syno_radio",
                boxLabel: String.format("{0} ({1})", _T("common", "yes"), _T("volume", "volume_recommand")),
                name: "check",
                inputValue: "yes",
                itemId: "check"
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                value: _T("volume", "volume_diskcheck_enable_help")
            }, {
                xtype: "syno_displayfield",
                cls: "sm-empty-line"
            }, {
                xtype: "syno_radio",
                boxLabel: String.format("{0}", _T("common", "no")),
                name: "check",
                inputValue: "no",
                itemId: "nocheck"
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                value: _T("volume", "volume_diskcheck_disable_help")
            }]
        };
        t = Ext.apply(t, e), this.callParent([t])
    },
    isChecked: function() {
        return "yes" === this.getForm().getValues().check
    },
    getNext: function() {
        return this.nextId
    },
    isSkip: function() {
        if (this.getData("quick_mode")) return !0;
        switch (this.getData("raid_level")) {
            case "raid_5":
            case "raid_6":
            case "raid_f1":
            case "shr_2":
                return !0;
            case "shr":
                if (this.getData("disk_ids", []).length > 2) return !0
        }
        return !1
    },
    updateData: function(e) {
        e.disk_check = this.isChecked()
    },
    summary: function(e) {
        this.isSkip() || e.append(_T("volume", "volume_diskcheck_title"), this.isChecked() ? _T("common", "yes") : _T("common", "no"))
    },
    activate: function() {
        var e = !1,
            t = this.owner.getRaidLevel(),
            i = this.getData("disk_ids", []);
        switch (t) {
            case "shr_with_1_disk_protect":
                e = i.length < 3;
                break;
            case "shr_without_disk_protect":
            case "basic":
            case "raid_0":
            case "raid_linear":
                e = !0
        }
        this.getComponent(e ? "check" : "nocheck").setValue(!0)
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.SHROperationStep", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        this.appWin = e.appWin, this.spaceType = e.spaceType || "volume";
        var t = {
            headline: _T("volume", "choose_unfinished_shr_operation_title"),
            items: [{
                xtype: "syno_radio",
                boxLabel: _T("volume", "volume_expand_raidgroup_by_add_disk"),
                name: "shr_operation",
                itemId: "add_disk",
                inputValue: "add_disk"
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                itemId: "add_disk_desc",
                value: _T("volume", "volume_expand_unfinished_shr_add_disk_desc")
            }, {
                xtype: "syno_radio",
                boxLabel: _T("volume", "volume_expand_unfinished_shr_to_shr2"),
                name: "shr_operation",
                itemId: "migrate_to_shr2",
                inputValue: "migrate_to_shr2"
            }, {
                xtype: "syno_radio",
                boxLabel: _T("volume", "spare_repair"),
                name: "shr_operation",
                itemId: "hotspare_repair",
                inputValue: "hotspare_repair"
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                itemId: "hotspare_repair_desc",
                value: _T("volume", "spare_expand_unalloc_desc")
            }, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                value: "</br>"
            }, {
                xtype: "syno_displayfield",
                itemId: "note",
                htmlEncode: !1,
                value: _T("volume", "volume_expand_unfinished_shr_note")
            }]
        };
        this.callParent([Ext.apply(t, e)])
    },
    activate: function() {
        var e = this.getComponent("add_disk"),
            t = this.getComponent("add_disk_desc"),
            i = this.getComponent("migrate_to_shr2"),
            s = this.getComponent("hotspare_repair"),
            a = this.getComponent("hotspare_repair_desc");
        this.pool = this.owner.pool, this.SHROperation = this.pool.get("can_do").expand_unfinished_shr || {}, this.SHROperation.add_disk ? e.setValue(!0) : (e.disable(), t.disable(), s.disable(), a.disable(), i.setValue(!0))
    },
    getOperation: function() {
        return this.getForm().getValues().shr_operation
    },
    updateData: function(e) {
        var t = this.getOperation();
        e.shr_operation = t, e.disk_default_checked = !1, "migrate_to_shr2" === t && 0 < this.SHROperation.migrate_to_shr2 ? e.allow_disk_blank = !1 : e.allow_disk_blank = !0
    },
    getNext: function() {
        return "hotspare_repair" === this.getOperation() ? this.nextId.summary : this.nextId.disk
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.ManageSummaryStep", {
    extend: "SYNO.SDS.StorageManager.Wizard.SummaryStep",
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.pool = void 0, i.stopServicesType = void 0, i.convertSHRToPool = !1, i.estimateSizeCallBack = void 0, i.apis = [], i.checkFastRepairApi = void 0, i.estimateSizeApi = void 0, t = {
            headline: _T("volume", "volume_wizard_summary_title"),
            columns: [{
                width: 370,
                header: _T("status", "header_item"),
                dataIndex: "key",
                renderer: function(e, t, i) {
                    return '<div class="sm-font-medium">' + e + "</div>"
                }
            }, {
                id: "value",
                autoExpand: !0,
                header: _T("status", "header_value"),
                dataIndex: "value",
                renderer: function(e, t, i) {
                    return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(e) + '"', '<div style="white-space:normal;" class="sm-font-normal">' + e + "</div>"
                },
                scope: this
            }]
        }, i.callParent([Ext.apply(t, e)])
    },
    activate: function() {
        var e, t, i, s, a = this,
            n = a.getStore(),
            o = a.getData("disk_groups", []),
            r = a.getData("disk_ids", []);
        a.callParent(arguments), a.pool = a.owner.getPoolObject(), e = a.pool, n.append(_T("common", "name"), e.postName), e.isSingleLun() ? (t = "SYNO.Core.Storage.iSCSILUN", a.estimateSizeCallBack = a.lunEstimateCallBack, i = "lun", s = e.get("deploy_path")) : e.isSingleVolume() ? (t = "SYNO.Storage.CGI.Volume", a.estimateSizeCallBack = a.volumeEstimateCallBack, i = "volume", s = e.get("deploy_path")) : (t = "SYNO.Storage.CGI.Pool", a.estimateSizeCallBack = a.poolEstimateCallBack, i = "pool", s = e.id), this.type = i, a.owner.setStatusBusy(), a.owner.getButton("next").disable(), a.estimateSizeApi = {
            api: t,
            method: "estimate_size",
            version: 1,
            params: {
                estimate_for: a.owner.getActionType(),
                disk_id: r,
                space_id: s,
                diskGroups: o
            }
        }, a.apis.push(a.estimateSizeApi), "repair" === a.getData("manage_action") && "yes" === _D("support_fast_repair") && (a.checkFastRepairApi = {
            api: "SYNO.Storage.CGI.Pool",
            version: 1,
            method: "check_fast_repair",
            params: {
                pool_path: e.get("space_path")
            }
        }, a.apis.push(a.checkFastRepairApi)), SYNO.API.Request({
            compound: {
                params: a.apis,
                stopwhenerror: !0
            },
            callback: a.summaryInfoCallBack,
            scope: a
        })
    },
    ownerApplySettings: function(e, t) {
        e && this.owner.applySettings(t.stopServicesType, t.doFastRepair)
    },
    getNext: function() {
        0 === this.getData("disk_ids", []).length ? this.ownerApplySettings(!0, {}) : new SYNO.SDS.StorageManager.Dialog.Confirm({
            owner: this.owner,
            warningMsg: _T("volume", "volume_adddisk_type_two_warning"),
            params: {
                stopServicesType: this.stopServicesType,
                doFastRepair: this.doFastRepair
            },
            callback: this.ownerApplySettings
        }).open();
        return !1
    },
    checkAutoSHRConvert: function(e, t) {
        var i = this.getData("manage_action");
        if (this.pool.isSHR() || this.pool.supportMultiple()) {
            switch (i) {
                case "repair":
                case "replace":
                case "expand_with_unalloc_size":
                case "expand_unfinished_shr":
                case "expand_by_disk":
                    break;
                default:
                    return
            }
            this.owner.getMsgBox().confirm(this.owner.title, _T("volume", "volume_auto_convert_shr_to_pool_tip"), function(s) {
                var a = this.getStore();
                if ("yes" === s) {
                    var n = "replace" === i ? _T("storage_pool", "pool_shr_replace_and_convert") : "repair" === i ? _T("volume", "volume_shr_repair_and_convert") : _T("volume", "volume_shr_expand_and_convert");
                    this.convertSHRToPool = !0, a.append(_T("volume", "volume_pool_freesize"), String.format("{0} {1}", _T("volume", "volume_add_warningabout"), SYNO.SDS.StorageUtils.SizeRender(e - t))), a.each(function(e) {
                        if (e.json.key === _T("volume", "volume_add_purpose")) return e.set("value", n), e.commit(), !1
                    })
                }
                a.each(function(e) {
                    if (e.json.key === _T("volume", "volume_totalsize")) return e.set("value", SYNO.SDS.StorageUtils.SizeRender(t)), e.commit(), !1
                }), this.owner.getButton("next").enable()
            }, this, null, {
                maxWidth: 420
            })
        }
    },
    getVolumeMaxFsSize: function() {
        var e, t = 0;
        return (e = this.volumeMap[this.pool.get("deploy_path")]) && (t = parseInt(e.get("max_fs_size"), 10)), t
    },
    volumeEstimateCallBack: function(e) {
        var t, i, s = this,
            a = SYNO.SDS.StorageUtils,
            n = {},
            o = parseInt(a.getMaxVolumeSize(), 10),
            r = parseInt(s.pool.get("size").total, 10),
            d = parseInt(e.size, 10),
            l = s.getData("manage_action"),
            p = d;
        this.reachSpaceSizeLimit(d, r) || "convert_shr_to_pool" === l || (i = this.getVolumeMaxFsSize(), d > (t = Math.min(i, o)) && (n.text = _T("volume", "volume_over_fs_limit_warning"), n.text = String.format(n.text, a.SizeRender(t)), SYNO.SDS.StorageUtils.ReportWebapiFailure(this, n, this.checkAutoSHRConvert, d, t), -1 === ["repair", "expand_with_unalloc_size"].indexOf(l) ? s.owner.getButton("next").disable() : p = t)), s.getStore().append(_T("volume", "volume_totalsize"), String.format("{0} {1}", _T("volume", "volume_add_warningabout"), SYNO.SDS.StorageUtils.SizeRender(p))), "data_scrubbing" !== l && e.stop_service_type && (s.stopServicesType = e.stop_service_type)
    },
    poolEstimateCallBack: function(e) {
        this.getStore().append(_T("volume", "volume_totalsize"), String.format("{0} {1}", _T("volume", "volume_add_warningabout"), SYNO.SDS.StorageUtils.SizeRender(e.size))), e.stop_service_type && (this.stopServicesType = e.stop_service_type)
    },
    lunEstimateCallBack: function(e) {
        var t = parseInt(this.pool.get("size").total, 10),
            i = parseInt(e.size, 10);
        this.reachSpaceSizeLimit(i, t), this.getStore().append(_T("volume", "volume_totalsize"), String.format("{0} {1}", _T("volume", "volume_add_warningabout"), SYNO.SDS.StorageUtils.SizeRender(e.size))), e.stop_service_type && (this.stopServicesType = e.stop_service_type)
    },
    addBlueDescriptionRow: function(e) {
        e = '<span class="blue-status" style="line-height:20px;padding-top:4px;padding-bottom:4px;display:inline-block;">' + e + "</span>", this.getStore().append(_T("common", "note"), e)
    },
    addActionRow: function(e) {
        var t = SYNO.SDS.StorageUtils;
        this.getStore().append(_T("volume", "volume_add_purpose"), t.AddDiskTypeRender(e))
    },
    addFastRepairDescriptionRow: function(e) {
        var t = _T("storage_pool", "fast_repair_check_internal_error");
        switch (e.status) {
            case "no_supported_space":
                t = _T("storage_pool", "fast_repair_check_no_supported_space");
                break;
            case "volume_crashed":
                t = _T("storage_pool", "fast_repair_check_volume_error"), t = String.format(t, e.volume_id);
                break;
            case "empty_raid":
                t = _T("storage_pool", "fast_repair_check_empty_raid");
                break;
            case "high_usage":
                t = _T("storage_pool", "fast_repair_check_high_usage"), t = String.format(t, e.high_usage_ratio);
                break;
            case "normal":
            case "disable":
            case "unsupported":
                return;
            default:
                t = _T("storage_pool", "fast_repair_check_internal_error")
        }
        this.addBlueDescriptionRow(t)
    },
    addRepairTypeAndDescription: function(e) {
        var t = this.getStore();
        null !== e && e.success ? e.data.can_do ? (t.append(_T("storage_pool", "repair_type"), _T("storage_pool", "fast_repair")), this.owner.setDoFastRepair(!0)) : (t.append(_T("storage_pool", "repair_type"), _T("storage_pool", "normal_repair")), this.addFastRepairDescriptionRow(e.data)) : (t.append(_T("storage_pool", "repair_type"), _T("storage_pool", "normal_repair")), this.addBlueDescriptionRow(_T("storage_pool", "fast_repair_check_internal_error")))
    },
    summaryInfoCallBack: function(e, t, i, s) {
        var a, n = this,
            o = n.getStore(),
            r = n.getData("manage_action"),
            d = n.getData("migrate_type"),
            l = n.getData("disk_ids", []),
            p = SYNO.SDS.StorageUtils,
            u = null,
            c = null;
        for (n.owner.clearStatusBusy(), Ext.isFunction(n.owner.setDoFastRepair) && n.owner.setDoFastRepair(!1), a = 0; a < t.result.length; a++) {
            var _ = t.result[a];
            SYNO.ux.Utils.checkApiConsistency(_, n.estimateSizeApi) ? u = _ : SYNO.ux.Utils.checkApiConsistency(_, n.checkFastRepairApi) && (c = _)
        }
        if (null === u || !u.success) return SYNO.SDS.StorageUtils.ReportWebapiFailure(n, t), n.owner.getButton("next").disable(), n.addActionRow(r), void n.doLayout();
        switch (r) {
            case "migrate":
                n.addActionRow(r), o.append(_T("volume", "volume_migrate_type"), p.MigrateTypeRender(d)), n.estimateSizeCallBack(u.data);
                break;
            case "data_scrubbing":
                n.addActionRow(r), n.estimateSizeCallBack(u.data), o.append(_T("volume", "notice"), _T("volume", "data_scrubbing_notice"));
                break;
            case "expand_by_disk":
                n.addActionRow(r), n.estimateSizeCallBack(u.data), "shr_without_disk_protect" === n.pool.device_type && 1 === l.length && o.append(_T("common", "note"), _T("volume", "volume_add_disk_into_shr_raidgroup_help"));
                break;
            case "repair":
                n.addActionRow(r), "yes" !== _D("support_fast_repair") ? n.estimateSizeCallBack(u.data) : (n.addRepairTypeAndDescription(c), n.estimateSizeCallBack(u.data));
                break;
            default:
                n.addActionRow(r), n.estimateSizeCallBack(u.data)
        }
        n.doLayout()
    },
    reachSpaceSizeLimit: function(e, t) {
        var i = this.getData("manage_action");
        if (e > t) {
            var s, a = e - t;
            if (SYNO.SDS.StorageUtils.isUpToHASpaceSizeLimit(a)) return "repair" === i ? s = String.format(_T("volume", "space_size_limit_repair_cannot_expand"), SYNO.SDS.StorageUtils.getHASpaceSizeLimitStr()) : (s = String.format(_T("volume", "space_size_limit_cannot_proceed"), SYNO.SDS.StorageUtils.getHASpaceSizeLimitStr()), this.owner.getButton("next").disable()), this.owner.getMsgBox().alert("", s), !0
        }
        return !1
    },
    disableNextInDemoMode: !0
}), Ext.define("SYNO.SDS.StorageManager.Wizard.AdvDiskStep", {
    extend: "SYNO.SDS.StorageManager.Wizard.Step",
    constructor: function(e) {
        this.subgroupName = void 0, this.freeDisksPanel = void 0, this.raidDisksPanel = void 0, this.ctrlHold = !1, this.shiftHold = !1, this.proxy = void 0, this.moving = !1, this.lastClickedA = void 0, this.lastClickedS = void 0, this.minSize = 0, this.minSizeRequiredDisks = 0, this.adjustHeight = 270, this.mode = e.mode || "create", this.disks = e.advDisks, Object.assign(this, e.funcs), delete e.funcs, this.unavailableDisks = [], this.actionTitleDesc = e.diskStepDesc, this.raidType = null, this.raidLevel = null, this.raidLimitNum = null, this.requiredDiskForSHR = e.repair || 0, this.initFreeDiskPanel(), this.initRaidDiskPanel();
        var t = {
            cls: "sm-adv-disk-step",
            headline: _T("storage_pool", "configure_raid_group_title"),
            height: 405,
            layout: "fit",
            items: [{
                xtype: "syno_panel",
                ref: "borderPanel",
                layout: "border",
                items: [{
                    xtype: "syno_displayfield",
                    cls: "adv-disk-step-desc",
                    ref: "actionField",
                    value: e.diskStepDesc,
                    region: "north",
                    htmlEncode: !1,
                    style: {
                        padding: "4px 0 16px 0"
                    }
                }, {
                    xtype: "syno_panel",
                    cls: "adv-disk-step-disk",
                    region: "center",
                    hideLabel: !0,
                    layout: "hbox",
                    border: !1,
                    height: this.adjustHeight,
                    width: 620,
                    padding: 0,
                    items: [this.freeDisksPanel, this.raidDisksPanel]
                }, {
                    xtype: "syno_panel",
                    ref: "south",
                    region: "south",
                    autoHeight: !0,
                    bodyStyle: {
                        padding: "0"
                    },
                    items: [{
                        xtype: "syno_displayfield",
                        ref: "sizeField",
                        value: "",
                        style: {
                            margin: "0 0 6px 0"
                        },
                        htmlEncode: !1
                    }, {
                        xtype: "syno_displayfield",
                        value: String.format("<span class='teal-status'>{0}</span><span>{1}</span>", _T("volume", "cache_notice"), " " + _T("storage_pool", "new_drive_note")),
                        htmlEncode: !1
                    }]
                }]
            }]
        };
        Ext.apply(t, e), this.callParent([t])
    },
    initEvents: function() {
        this.callParent(arguments), this.bindKeyboardEvents(), this.mon(this.freeDisksPanel.view.getStore(), "load", this.setMask, this)
    },
    setMask: function() {
        0 === this.freeDisksPanel.view.getStore().getCount() ? this.freeDisksPanel.body.mask(_T("volume", "volume_no_available_disks"), "syno-ux-mask-info") : this.freeDisksPanel.body.unmask()
    },
    bindKeyboardEvents: function() {
        var e = Ext.getDoc();
        this.mon(e, "keydown", function(e, t) {
            switch (e.getKey()) {
                case e.CONTROL:
                    this.ctrlHold = !0;
                    break;
                case e.SHIFT:
                    this.shiftHold = !0;
                    break;
                default:
                    return
            }
        }, this), this.mon(e, "keyup", function(e, t) {
            switch (e.getKey()) {
                case e.CONTROL:
                    this.ctrlHold = !1;
                    break;
                case e.SHIFT:
                    this.shiftHold = !1;
                    break;
                default:
                    return
            }
        }, this)
    },
    initFreeDiskPanel: function() {
        var e = {
                tpl: this.getFreeDiskTpl(),
                layout: "fit",
                store: new Ext.data.JsonStore({
                    autoDestroy: !0,
                    root: "containers",
                    fields: ["id", "name", "disks"],
                    listeners: {
                        load: function() {
                            if (Ext.get("freeDisksPanel")) {
                                var e = Ext.get("freeDisksPanel").query(".selectable");
                                Ext.each(e, function(e, t, i) {
                                    var s = new Ext.Element(e);
                                    if (s.hasClass("toggle") || s.hasClass("sds-space-host-name")) return !0;
                                    this.mon(s, "mousedown", this.onMouseDown, this)
                                }, this);
                                var t = Ext.get("freeDisksPanel").query(".toggle");
                                Ext.each(t, function(e, t, i) {
                                    var s = new Ext.Element(e);
                                    this.mon(s, "mousedown", function(e, t) {
                                        e.stopEvent();
                                        var i = new Ext.Element(t);
                                        i.parent("div", !1).next("ul", !1).setVisibilityMode(Ext.Element.DISPLAY), i.parent("div", !1).next("ul", !1).toggle(), i.toggleClass("sds-space-toggle-collapse")
                                    }, this)
                                }, this)
                            }
                            this.doLayout()
                        },
                        scope: this
                    }
                })
            },
            t = new Ext.DataView(e);
        this.freeDisksPanel = new Ext.Panel({
            id: "freeDisksPanel",
            cls: "adv-disk-step-free-disk-panel",
            bodyStyle: {
                padding: "0",
                border: "none"
            },
            width: 320,
            height: this.adjustHeight,
            margins: {
                top: 0,
                right: 16,
                bottom: 0,
                left: 0
            },
            view: t,
            flex: 48,
            autoFlexcroll: !0,
            items: t
        })
    },
    getFreeDiskTpl: function() {
        var e = new Ext.XTemplate("<ul>", '<tpl for=".">', '<li class="enclosure sds-space-disk-li">', '<div class="sds-space-disk-container owner selectable" side="available" type="enclosure" devId="{id}">', '<div class="toggle sds-space-toggle nonselectable"></div>', '<span class="sds-space-host-name">{name}</span>', "</div>", "<ul>", '<tpl for="disks">', '<li class="sds-space-disk-li">', '<div class="sds-space-disk disk selectable" side="available" diskType="{diskType}" owner="{owner}" container="{owner}" size_total="{size_total}" devId="{id}"><div class="sds-space-disk-icon nonselectable"></div><span class="sds-space-disk-name">{shortName} - {diskType} / {driveType} {size} {display4Kn}</span></div>', "</li>", "</tpl>", "</ul>", "</li>", "</tpl>", "</ul>");
        return e.compile(), e
    },
    initRaidDiskPanel: function() {
        var e = {
                tpl: this.getRaidDiskTpl(),
                layout: "fit",
                store: new Ext.data.JsonStore({
                    autoDestroy: !0,
                    root: "raids",
                    fields: ["id", "disks"],
                    listeners: {
                        load: function() {
                            if (Ext.get("raidDisksPanel")) {
                                var e = Ext.get("raidDisksPanel").query(".sds-space-disk-remove-icon");
                                Ext.each(e, function(e, t, i) {
                                    var s = new Ext.Element(e);
                                    e.getAttribute("used_by") || this.mon(s, "click", function(e, t, i) {
                                        var s = [];
                                        s.push({
                                            dom: t.parentNode
                                        }), this.dropToAvailable(s)
                                    }, this)
                                }, this), this.updateEstimateSize()
                            }
                            this.doLayout()
                        },
                        scope: this
                    }
                })
            },
            t = new Ext.DataView(e);
        this.raidDisksPanel = new Ext.Panel({
            id: "raidDisksPanel",
            border: !1,
            bodyStyle: {
                "border-left": "1px solid",
                "border-color": "rgba(198,212,224,0.4)",
                padding: "0 0 0 15px"
            },
            width: 408,
            height: this.adjustHeight,
            view: t,
            flex: 52,
            autoFlexcroll: !0,
            items: t
        })
    },
    getRaidDiskTpl: function() {
        var e = new Ext.XTemplate("<ul>", '<tpl for=".">', '<li class="sds-space-disk-li">', '<div devId="id" class="sds-space-raid owner nonselectable" used_by="{id}">{id}</div>', "<ul>", '<tpl for="disks">', '<tpl if="dummy == true">', '<li class="sds-space-disk-li"><div class="sds-space-dummy dummy {cls}" used_by="dummy" minSize="{minSize}" raidNum="{raidNum}">', '<tpl if="required == true">', _T("volume", "volume_required_disk"), "</tpl>", '<tpl if="required == false">', _T("volume", "volume_additional_disk"), "</tpl>", "</div></li>", "</tpl>", '<tpl if="dummy == false">', '<li class="sds-space-disk-li">', '<div class="sds-space-disk-choosed disk {cls}" diskType="{diskType}" side="pool" owner="{parent.id}" container="{owner}" devId="{id}" size_total="{size_total}" used_by="{used_by}" raidNum="{raidNum}"><div class="sds-space-disk-icon nonselectable"></div><span class="sds-space-disk-name">{shortName} - {diskType} / {driveType} {size} {display4Kn}</span>', "<tpl if=\"cls == 'selectable'\">", '<div class="sds-space-disk-remove-icon"></div>', "</tpl>", "</div>", "</li>", "</tpl>", "</tpl>", "</ul>", "</li>", "</tpl>", "</ul>");
        return e.compile(), e
    },
    onMouseDown: function(e, t) {
        var i = new Ext.Element(t);
        (i.hasClass("sds-space-host-name") || i.hasClass("sds-space-disk-icon") || i.hasClass("sds-space-disk-name")) && (t = (i = i.parent()).dom), new Ext.Element(t).getXY()[0] < Ext.get("raidDisksPanel").getXY()[0] ? this.lastClickA = i : this.lastClickS = i, this.lastClick = i, e.stopEvent(), this.checkSelection(t);
        var s = this;
        s.lastPos = e.getXY();
        var a = setTimeout(function() {
            var e = Ext.getDoc();
            s.mon(e, "mousemove", s.onMouseMove, s), s.mon(e, "mouseup", s.onMouseUp, s)
        }, 50);
        this.mon(i, "mouseup", function() {
            clearTimeout(a)
        }, this, {
            single: !0
        })
    },
    checkSelection: function(e) {
        var t, i, s = new Ext.Element(e);
        if (new Ext.Element(e).getXY()[0] < Ext.get("raidDisksPanel").getXY()[0] ? (t = Ext.get("freeDisksPanel"), i = "lastClickedA") : (t = Ext.get("raidDisksPanel"), i = "lastClickedS"), this.ctrlHold || this.shiftHold || s.hasClass("sds-pool-create-device-selected") || (Ext.each(t.query(".sds-pool-create-device-selected"), function() {
                new Ext.Element(this).removeClass("sds-pool-create-device-selected")
            }), s.addClass("sds-pool-create-device-selected")), this.shiftHold)
            if (null === this[i]) s.addClass("sds-pool-create-device-selected");
            else {
                Ext.each(t.query(".sds-pool-create-device-selected"), function() {
                    new Ext.Element(this).removeClass("sds-pool-create-device-selected")
                });
                var a = this[i].getXY()[1] < s.getXY()[1] ? this[i].getXY()[1] : s.getXY()[1],
                    n = this[i].getXY()[1] > s.getXY()[1] ? this[i].getXY()[1] : s.getXY()[1];
                Ext.each(t.query(".selectable"), function() {
                    var e = new Ext.Element(this);
                    e.getXY()[1] >= a && e.getXY()[1] <= n && !e.hasClass("nonselectable") && e.addClass("sds-pool-create-device-selected")
                })
            }
        else this.ctrlHold && s.toggleClass("sds-pool-create-device-selected");
        this[i] = s
    },
    onMouseMove: function(e, t) {
        var i, s, a, n = new Ext.Element(t),
            o = e.getXY();
        (n.hasClass("sds-space-host-name") || n.hasClass("sds-space-disk-icon") || n.hasClass("sds-space-disk-name")) && (t = (n = n.parent()).dom), this.lastPos && (i = Math.pow(this.lastPos[0] - o[0], 2), s = Math.pow(this.lastPos[1] - o[1], 2), a = Math.sqrt(i + s)), a > 15 && !this.proxy && (this.moved = !0, this.createDragProxy(t)), this.proxy && (o[0] += 5, o[1] += 5, this.proxy.setXY(o), this.proxy.setStyle({
            position: "absolute",
            "z-index": "100000",
            width: "200px"
        })), this.dropHint && this.dropHint.hasClass("sds-space-dummy-disk-hover") && this.dropHint.removeClass("sds-space-dummy-disk-hover"), this.isInDropZone(e, "raidDisks") ? Ext.each(Ext.get("raidDisksPanel").query("div"), function(t) {
            var i = new Ext.Element(t);
            return i.hasClass("dummy") && e.getXY()[1] >= i.getXY()[1] && e.getXY()[1] <= i.getXY()[1] + i.getHeight() ? (this.dropHint = i, i.hasClass("sds-space-dummy-disk-hover") || i.addClass("sds-space-dummy-disk-hover"), this.dropPos = "", !1) : e.getXY()[1] >= i.getXY()[1] && e.getXY()[1] < i.getXY()[1] + i.getHeight() / 2 && !i.hasClass("dummy") && i.hasClass("selectable") ? (this.dropHint = i, i.hasClass("sds-space-dummy-disk-hover") || i.addClass("sds-space-dummy-disk-hover"), this.dropPos = "top", !1) : e.getXY()[1] >= i.getXY()[1] + i.getHeight() / 2 && e.getXY()[1] < i.getXY()[1] + i.getHeight() && !i.hasClass("dummy") && i.hasClass("selectable") ? (this.dropHint = i, i.hasClass("sds-space-dummy-disk-hover") || i.addClass("sds-space-dummy-disk-hover"), this.dropPos = "bottom", !1) : (delete this.dropHint, delete this.dropPos, void i.removeClass("sds-space-dummy-disk-hover"))
        }, this) : (delete this.dropHint, delete this.dropPos)
    },
    createDropHint: function(e) {
        this.dropHintProxy || (this.dropHintProxy = new Ext.Element(Ext.DomHelper.createDom({
            tag: "div",
            html: ">"
        })), Ext.getBody().appendChild(this.dropHintProxy)), this.dropHintProxy.setStyle({
            position: "absolute",
            "z-index": "100000",
            width: "20px",
            height: "20px"
        }), this.dropHintProxy.setXY(e)
    },
    createDragProxy: function(e) {
        var t;
        t = new Ext.Element(e).getXY()[0] < Ext.get("raidDisksPanel").getXY()[0] ? Ext.get("freeDisksPanel") : Ext.get("raidDisksPanel");
        var i = [],
            s = [],
            a = {};
        Ext.each(t.query(".sds-pool-create-device-selected"), function() {
            var e = new Ext.Element(this);
            e.hasClass("owner") ? (a[this.getAttribute("devId")] = !0, i.push(e)) : a[this.getAttribute("owner")] || s.push(e)
        }), (i = i.concat(s)).sort(function(e, t) {
            return e.getXY()[1] > t.getXY()[1] ? 1 : e.getXY()[1] < t.getXY()[1] ? -1 : 0
        }), this.proxy = new Ext.Element(Ext.DomHelper.createDom({
            tag: "div"
        })), this.proxy.nodes = [], Ext.each(i, function(e) {
            var t = this,
                i = e.parent().dom,
                s = i.cloneNode(!0);
            if (s.childNodes[0].removeAttribute("id"), i.childNodes[0].classList.add("sds-space-disk-drag"), this.proxy.nodes.push(i), s.childNodes[0].classList.add("sds-space-disk-drag-ghost"), e.hasClass("owner")) {
                var a = s.firstChild,
                    n = s.childNodes[1].childNodes.length,
                    o = '<span class="drag-host-hint-ext">' + s.childNodes[1].childNodes.length + " " + _JSLIBSTR("uicommon", n > 1 ? "items" : "item") + "</span>";
                i.childNodes[1].childNodes.forEach(function(e) {
                    e.childNodes[0].classList.add("sds-space-disk-drag"), t.proxy.nodes.push(e)
                }), Ext.DomHelper.insertHtml("beforeEnd", a, o), a.removeAttribute("id"), this.proxy.appendChild(a)
            } else s.removeAttribute("id"), s.style.height = "28px", this.proxy.appendChild(s)
        }, this), this.proxy.setStyle({
            position: "absolute",
            "z-index": "100000",
            width: "200px"
        }), Ext.getBody().appendChild(this.proxy)
    },
    onMouseUp: function(e, t) {
        var i, s = new Ext.Element(t);
        (s.hasClass("sds-space-host-name") || s.hasClass("sds-space-disk-icon") || s.hasClass("sds-space-disk-name")) && (t = (s = s.parent()).dom), i = new Ext.Element(t).getXY()[0] < Ext.get("raidDisksPanel").getXY()[0] ? Ext.get("freeDisksPanel") : Ext.get("raidDisksPanel"), this.ctrlHold || this.shiftHold || this.moved || (Ext.each(i.query(".sds-pool-create-device-selected"), function() {
            new Ext.Element(this).removeClass("sds-pool-create-device-selected")
        }), s.addClass("sds-pool-create-device-selected")), this.proxy && (this.proxy.nodes.forEach(function(e) {
            e.childNodes[0].classList.remove("sds-space-disk-drag")
        }), this.proxy.remove(), this.proxy = null), this.dropHintProxy && (this.dropHintProxy.remove(), delete this.dropHintProxy);
        var a = Ext.getDoc();
        this.mun(a, "mousemove", this.onMouseMove, this), this.mun(a, "mouseup", this.onMouseUp, this), this.dropSelections(e, t), delete this.lastPos
    },
    dropSelections: function(e, t) {
        var i, s, a = this.lastClick;
        if (new Ext.Element(a.dom).getXY()[0] < Ext.get("raidDisksPanel").getXY()[0]) {
            if (i = Ext.get("freeDisksPanel"), this.isInDropZone(e, "raidDisks"))
                if (s = this.getSelectedDisks(i), this.dropHint) switch (this.dropPos) {
                    case "":
                        this.dropOnDummyAToS(s);
                        break;
                    case "top":
                        this.dropOnTopAToS(s);
                        break;
                    case "bottom":
                        this.dropOnBottomAToS(s)
                } else this.isMultiRAIDMode() ? this.dropToTheEndAToSMulti(s) : this.dropToTheEndAToS(s)
        } else if (i = Ext.get("raidDisksPanel"), s = this.getSelectedDisks(i), this.isInDropZone(e, "freeDisks")) this.dropToAvailable(s);
        else if (this.moved) switch (this.dropPos) {
            case "":
                this.dropOnDummySToS(s);
                break;
            case "top":
                this.dropOnTopSToS(s);
                break;
            case "bottom":
                this.dropOnBottomSToS(s)
        }
        this.moved = !1
    },
    dropToTheEndAToSMulti: function(e) {
        if ("repair" !== this.owner.add_type) {
            var t, i, s, a, n = !1,
                o = 0;
            Ext.each(this.RaidDisksData.raids, function(r) {
                var d, l, p, u = 0;
                for (this.pool && o <= this.pool.raids.length - 1 && (p = this.pool.raids[o], u = parseInt(this.pool.raids[o].minDevSize, 10)), t = this.maxDisks, i = [], Ext.each(r.disks, function(e) {
                        e.dummy || (i.push(e), --t)
                    }, this), a = [], s = 0; s < e.length; ++s) d = e[s].dom.getAttribute("devId"), (l = this.diskMap[d]).totalSizeNumber >= u && 0 < t ? (e[s] = null, this.freeDisks[d].available = !1, i.push(this.createDisk(l, o, !1, !1, !0)), --t) : a.push(e[s]);
                e = a, n = this.fillDummyDisks(i, o, p), delete r.disks, r.disks = i, ++o
            }, this), !n && 0 < e.length && this.fillOthers(e), this.checkLastRAID(), this.prepareFreeDisksData(), this.freeDisksPanel.view.store.loadData(this.FreeDisksData, !1), this.raidDisksPanel.view.store.loadData(this.RaidDisksData, !1)
        }
    },
    getRepairRequiredCount: function(e, t, i) {
        return e && t && t.devices ? 0 < e.length - t.normalDevCount ? 0 : 1 : i
    },
    fillDummyDisks: function(e, t, i) {
        var s, a, n = this.maxDisks - e.length;
        for (i && "repair" === this.owner.add_type ? (n = a = parseInt(i.designedDiskCount, 10) - e.length, "raid_6" !== this.raidLevel && "raid_10" !== this.raidLevel || (a = this.getRepairRequiredCount(e, i, a))) : i && "expand_by_disk" === this.owner.add_type ? a = parseInt(i.designedDiskCount, 10) - e.length + 1 : i && "migrate" === this.owner.add_type ? a = "raid_1" === this.raidLevel && 1 === parseInt(i.designedDiskCount, 10) ? parseInt(i.designedDiskCount, 10) - e.length + 1 : this.minDisks > parseInt(i.designedDiskCount, 10) ? this.minDisks - e.length : "raid_1" === this.pool.device_type && "raid_1" !== this.raidLevel ? this.minDisks - e.length : parseInt(i.designedDiskCount, 10) + 1 - e.length : (a = this.minDisks - e.length, "raid_10" === this.raidLevel && e.length > this.minDisks && 1 == e.length % 2 && (a = 1)), s = 0 < n; 0 < n;) e.push({
            raidNum: t,
            dummy: !0,
            required: 0 < a,
            cls: 0 < a ? "sds-space-required-disk nonselectable" : "sds-space-dummy nonselectable"
        }), --n, --a;
        return s
    },
    fillOthers: function(e) {
        if ("migrate" !== this.owner.add_type) {
            var t, i = 0,
                s = 0;
            Ext.each(this.RaidDisksData.raids, function(a) {
                var n = [],
                    o = !1;
                if (Ext.each(a.disks, function(e) {
                        if (e.dummy) return o = !0, !1;
                        n.push(e)
                    }, this), !o) return ++s, !0;
                if (t = this.maxDisks - n.length, this.pool && (i = this.pool.raids && this.pool.raids[s] ? parseInt(this.pool.raids[s].minDevSize, 10) : parseInt(this.pool.get("minimal_disk_size"), 10)), "repair" === this.owner.add_type) {
                    var r = this.pool.raids[s];
                    t = parseInt(r.designedDiskCount, 10) - n.length
                }
                var d = [];
                if (Ext.each(e, function(e) {
                        var a = e.dom.getAttribute("devId"),
                            o = this.diskMap[a];
                        o.totalSizeNumber >= i && 0 < t ? (this.freeDisks[a].available = !1, n.push(this.createDisk(o, s, !1, !1, !0)), --t) : d.push(e)
                    }, this), e = d, "repair" !== this.owner.add_type && this.fillDummyDisks(n, s, null), delete a.disks, a.disks = n, 0 === e.length) return !1;
                ++s
            }, this), 0 < e.length && "repair" !== this.owner.add_type && this.fillNewRaid(e)
        }
    },
    fillNewRaid: function(e) {
        var t, i, s, a, n, o = 0;
        for (t = 0; t < e.length; ++t) 0 === o && (i = this.RaidDisksData.raids.length, a = [], this.RaidDisksData.raids.push({
            disks: a,
            id: String.format(this.subgroupName, i + 1),
            raidNum: i
        }), o = this.maxDisks), s = e[t].dom.getAttribute("devId"), n = this.diskMap[s], 0 < o && (this.freeDisks[s].available = !1, a.push(this.createDisk(n, i, !1, !1, !0)), --o);
        a = this.RaidDisksData.raids[this.RaidDisksData.raids.length - 1].disks, i = this.RaidDisksData.raids.length - 1, this.fillDummyDisks(a, i, null)
    },
    dropToTheEndAToS: function(e) {
        if ("repair" !== this.owner.add_type) {
            var t = 0 === this.RaidDisksData.raids.length ? 0 : this.RaidDisksData.raids.length - 1;
            if (this.RaidDisksData.raids[t]) {
                var i = 0,
                    s = t;
                this.pool && (i = this.pool.raids && this.pool.raids[s] ? parseInt(this.pool.raids[s].minDevSize, 10) : parseInt(this.pool.get("minimal_disk_size"), 10));
                var a, n, o = [];
                Ext.each(this.RaidDisksData.raids[t].disks, function(e) {
                    e.dummy || o.push(e)
                }, this), this.pool && (n = this.pool.raids[s]), a = -1 < this.raidLevel.indexOf("shr") ? this.requiredDiskForSHR : n && "repair" === this.owner.add_type ? parseInt(n.designedDiskCount, 10) - o.length : this.maxDisks - o.length, Ext.each(e, function(e) {
                    var t = e.dom.getAttribute("devId"),
                        n = this.diskMap[t];
                    n.totalSizeNumber >= i && 0 < a && (this.freeDisks[t].available = !1, o.push(this.createDisk(n, s, !1, !1, !0)), --a, --this.requiredDiskForSHR)
                }, this);
                var r, d = this.maxDisks - o.length;
                for (-1 < this.raidLevel.indexOf("shr") ? d = r = this.requiredDiskForSHR : n && "repair" === this.owner.add_type ? d = r = parseInt(n.designedDiskCount, 10) - o.length : n && "expand_by_disk" === this.owner.add_type ? r = parseInt(n.designedDiskCount, 10) - o.length + 1 : n && "migrate" === this.owner.add_type ? r = "raid_1" === this.raidLevel && 2 === parseInt(n.designedDiskCount, 10) ? parseInt(n.designedDiskCount, 10) - o.length + 1 : this.minDisks > parseInt(n.designedDiskCount, 10) ? this.minDisks - o.length : "raid_1" === this.pool.device_type && "raid_1" !== this.raidLevel ? this.minDisks - o.length : parseInt(n.designedDiskCount, 10) + 1 - o.length : (r = this.minDisks - o.length, "raid_10" === this.raidLevel && o.length > this.minDisks && 1 == o.length % 2 && (r = 1)); 0 < d;) o.push({
                    raidNum: s,
                    dummy: !0,
                    required: 0 < r,
                    cls: 0 < r ? "sds-space-required-disk nonselectable" : "sds-space-dummy nonselectable"
                }), --d, --r;
                delete this.RaidDisksData.raids[t].disks, this.RaidDisksData.raids[t].disks = o, this.checkLastRAID(), this.prepareFreeDisksData(), this.freeDisksPanel.view.store.loadData(this.FreeDisksData, !1), this.raidDisksPanel.view.store.loadData(this.RaidDisksData, !1)
            }
        }
    },
    dropOnDummyAToS: function(e) {
        var t, i, s, a = parseInt(this.dropHint.dom.getAttribute("raidNum"), 10),
            n = this.RaidDisksData.raids[a],
            o = 0;
        this.pool && (o = this.pool.raids && this.pool.raids[a] ? parseInt(this.pool.raids[a].minDevSize, 10) : parseInt(this.pool.get("minimal_disk_size"), 10));
        var r, d, l = [];
        Ext.each(n.disks, function(e) {
            e.dummy || l.push(e)
        }, this), this.pool && this.pool.raids && (d = this.pool.raids[a]), r = -1 < this.raidLevel.indexOf("shr") ? this.requiredDiskForSHR : d && "repair" === this.owner.add_type ? parseInt(d.designedDiskCount, 10) - l.length : this.maxDisks - l.length;
        var p = [];
        Ext.each(e, function(e) {
            var i = e.dom.getAttribute("devId");
            (t = this.diskMap[i]).totalSizeNumber >= o && 0 < r ? (this.freeDisks[i].available = !1, l.push(this.createDisk(t, a, !1, !1, !0)), --r, --this.requiredDiskForSHR) : p.push(e)
        }, this), e = p, s = this.maxDisks - l.length, -1 < this.raidLevel.indexOf("shr") ? s = i = this.requiredDiskForSHR : d && "repair" === this.owner.add_type ? (s = i = parseInt(d.designedDiskCount, 10) - l.length, "raid_6" !== this.raidLevel && "raid_10" !== this.raidLevel || (i = this.getRepairRequiredCount(l, d, i))) : d && "expand_by_disk" === this.owner.add_type ? i = parseInt(d.designedDiskCount, 10) - l.length + 1 : d && "migrate" === this.owner.add_type ? i = "raid_1" === this.raidLevel && 2 === parseInt(d.designedDiskCount, 10) ? parseInt(d.designedDiskCount, 10) - l.length + 1 : this.minDisks > parseInt(d.designedDiskCount, 10) ? this.minDisks - l.length : "raid_1" === this.pool.device_type && "raid_1" !== this.raidLevel ? this.minDisks - l.length : parseInt(d.designedDiskCount, 10) + 1 - l.length : (i = this.minDisks - l.length, "raid_10" === this.raidLevel && l.length > this.minDisks && 1 == l.length % 2 && (i = 1));
        for (var u = 0 < s; 0 < s;) l.push({
            raidNum: a,
            dummy: !0,
            required: 0 < i,
            cls: 0 < i ? "sds-space-required-disk nonselectable" : "sds-space-dummy nonselectable"
        }), --s, --i;
        delete n.disks, n.disks = l, this.isMultiRAIDMode() && !u && 0 < e.length && this.fillOthers(e), this.checkLastRAID(), this.prepareFreeDisksData(), this.freeDisksPanel.view.store.loadData(this.FreeDisksData, !1), this.raidDisksPanel.view.store.loadData(this.RaidDisksData, !1)
    },
    dropOnTopAToS: function(e) {
        var t, i, s, a = parseInt(this.dropHint.dom.getAttribute("raidNum"), 10),
            n = this.RaidDisksData.raids[a],
            o = 0;
        this.pool && (o = this.pool.raids && this.pool.raids[a] ? parseInt(this.pool.raids[a].minDevSize, 10) : parseInt(this.pool.get("minimal_disk_size"), 10));
        var r, d, l = [];
        Ext.each(n.disks, function(e) {
            e && !e.dummy && l.push(e)
        }, this), this.pool && this.pool.raids && (d = this.pool.raids[a]), r = -1 < this.raidLevel.indexOf("shr") ? this.requiredDiskForSHR : d && "repair" === this.owner.add_type ? parseInt(d.designedDiskCount, 10) - l.length : this.maxDisks - l.length;
        var p = [],
            u = [];
        Ext.each(e, function(e) {
            var i = e.dom.getAttribute("devId");
            (t = this.diskMap[i]).totalSizeNumber >= o && 0 < r ? (this.freeDisks[i].available = !1, p.push(this.createDisk(t, a, !1, !1, !0)), --r, --this.requiredDiskForSHR) : u.push(e)
        }, this), e = u;
        var c = l;
        l = [];
        for (var _ = 0; _ < c.length; ++_) c[_].id === this.dropHint.dom.getAttribute("devId") && (l = l.concat(p)), l.push(c[_]);
        s = this.maxDisks - l.length, -1 < this.raidLevel.indexOf("shr") ? s = i = this.requiredDiskForSHR : d && "repair" === this.owner.add_type ? (s = i = parseInt(d.designedDiskCount, 10) - l.length, "raid_6" !== this.raidLevel && "raid_10" !== this.raidLevel || (i = this.getRepairRequiredCount(l, d, i))) : d && "expand_by_disk" === this.owner.add_type ? i = parseInt(d.designedDiskCount, 10) - l.length + 1 : d && "migrate" === this.owner.add_type ? i = "raid_1" === this.raidLevel && 2 === parseInt(d.designedDiskCount, 10) ? parseInt(d.designedDiskCount, 10) - l.length + 1 : this.minDisks > parseInt(d.designedDiskCount, 10) ? this.minDisks - l.length : "raid_1" === this.pool.device_type && "raid_1" !== this.raidLevel ? this.minDisks - l.length : parseInt(d.designedDiskCount, 10) + 1 - l.length : (i = this.minDisks - l.length, "raid_10" === this.raidLevel && l.length > this.minDisks && 1 == l.length % 2 && (i = 1));
        for (var h = 0 < s; 0 < s;) l.push({
            raidNum: a,
            dummy: !0,
            required: 0 < i,
            cls: 0 < i ? "sds-space-required-disk nonselectable" : "sds-space-dummy nonselectable"
        }), --s, --i;
        delete n.disks, n.disks = l, this.isMultiRAIDMode() && !h && 0 < e.length && this.fillOthers(e), this.checkLastRAID(), this.prepareFreeDisksData(), this.freeDisksPanel.view.store.loadData(this.FreeDisksData, !1), this.raidDisksPanel.view.store.loadData(this.RaidDisksData, !1)
    },
    dropOnBottomAToS: function(e) {
        var t, i, s, a = parseInt(this.dropHint.dom.getAttribute("raidNum"), 10),
            n = this.RaidDisksData.raids[a],
            o = 0;
        this.pool && (o = this.pool.raids && this.pool.raids[a] ? parseInt(this.pool.raids[a].minDevSize, 10) : parseInt(this.pool.get("minimal_disk_size"), 10));
        var r, d, l = [];
        Ext.each(n.disks, function(e) {
            e && !e.dummy && l.push(e)
        }, this), this.pool && this.pool.raids && (d = this.pool.raids[a]), r = -1 < this.raidLevel.indexOf("shr") ? this.requiredDiskForSHR : d && "repair" === this.owner.add_type ? parseInt(d.designedDiskCount, 10) - l.length : this.maxDisks - l.length;
        var p = [],
            u = [];
        Ext.each(e, function(e) {
            var i = e.dom.getAttribute("devId");
            (t = this.diskMap[i]).totalSizeNumber >= o && 0 < r ? (this.freeDisks[i].available = !1, p.push(this.createDisk(t, a, !1, !1, !0)), --r, --this.requiredDiskForSHR) : u.push(e)
        }, this), e = u;
        var c = l;
        l = [];
        for (var _ = 0; _ < c.length; ++_) l.push(c[_]), c[_].id === this.dropHint.dom.getAttribute("devId") && (l = l.concat(p));
        s = this.maxDisks - l.length, -1 < this.raidLevel.indexOf("shr") ? s = i = this.requiredDiskForSHR : d && "repair" === this.owner.add_type ? (s = i = parseInt(d.designedDiskCount, 10) - l.length, "raid_6" !== this.raidLevel && "raid_10" !== this.raidLevel || (i = this.getRepairRequiredCount(l, d, i))) : d && "expand_by_disk" === this.owner.add_type ? i = parseInt(d.designedDiskCount, 10) - l.length + 1 : d && "migrate" === this.owner.add_type ? i = "raid_1" === this.raidLevel && 2 === parseInt(d.designedDiskCount, 10) ? parseInt(d.designedDiskCount, 10) - l.length + 1 : this.minDisks > parseInt(d.designedDiskCount, 10) ? this.minDisks - l.length : "raid_1" === this.pool.device_type && "raid_1" !== this.raidLevel ? this.minDisks - l.length : parseInt(d.designedDiskCount, 10) + 1 - l.length : (i = this.minDisks - l.length, "raid_10" === this.raidLevel && l.length > this.minDisks && 1 == l.length % 2 && (i = 1));
        for (var h = 0 < s; 0 < s;) l.push({
            raidNum: a,
            dummy: !0,
            required: 0 < i,
            cls: 0 < i ? "sds-space-required-disk nonselectable" : "sds-space-dummy nonselectable"
        }), --s, --i;
        delete n.disks, n.disks = l, this.isMultiRAIDMode() && !h && 0 < e.length && this.fillOthers(e), this.checkLastRAID(), this.prepareFreeDisksData(), this.freeDisksPanel.view.store.loadData(this.FreeDisksData, !1), this.raidDisksPanel.view.store.loadData(this.RaidDisksData, !1)
    },
    dropToAvailable: function(e) {
        var t;
        Ext.each(e, function(e) {
            var i = e.dom.getAttribute("devId");
            t = parseInt(e.dom.getAttribute("raidNum"), 10);
            for (var s = 0; s < this.RaidDisksData.raids[t].disks.length; ++s)
                if (this.RaidDisksData.raids[t].disks[s] && this.RaidDisksData.raids[t].disks[s].id === i) {
                    this.RaidDisksData.raids[t].disks[s] = null;
                    break
                } this.freeDisks[i].available = !0
        }, this), this.requiredDiskForSHR += e.length, t = 0, Ext.each(this.RaidDisksData.raids, function(e) {
            var i, s, a, n = [];
            for (Ext.each(e.disks, function(e) {
                    e && !e.dummy && n.push(e)
                }, this), this.pool && this.pool.raids && (a = this.pool.raids[t]), s = this.maxDisks - n.length, -1 < this.raidLevel.indexOf("shr") ? s = i = this.requiredDiskForSHR : a && "repair" === this.owner.add_type ? (s = i = parseInt(a.designedDiskCount, 10) - n.length, "raid_6" !== this.raidLevel && "raid_10" !== this.raidLevel || (i = this.getRepairRequiredCount(n, a, i))) : a && "expand_by_disk" === this.owner.add_type ? i = parseInt(a.designedDiskCount, 10) - n.length + 1 : a && "migrate" === this.owner.add_type ? i = "raid_1" === this.raidLevel && 2 === parseInt(a.designedDiskCount, 10) ? parseInt(a.designedDiskCount, 10) - n.length + 1 : this.minDisks > parseInt(a.designedDiskCount, 10) ? this.minDisks - n.length : "raid_1" === this.pool.device_type && "raid_1" !== this.raidLevel ? this.minDisks - n.length : parseInt(a.designedDiskCount, 10) + 1 - n.length : (i = this.minDisks - n.length, "raid_10" === this.raidLevel && n.length > this.minDisks && 1 == n.length % 2 && (i = 1)); 0 < s;) n.push({
                raidNum: t,
                dummy: !0,
                required: 0 < i,
                cls: 0 < i ? "sds-space-required-disk nonselectable" : "sds-space-dummy nonselectable"
            }), --s, --i;
            delete e.disks, e.disks = n, ++t
        }, this), this.checkLastRAID(), this.prepareFreeDisksData(), this.freeDisksPanel.view.store.loadData(this.FreeDisksData, !1), this.raidDisksPanel.view.store.loadData(this.RaidDisksData, !1)
    },
    dropOnDummySToS: function(e) {
        var t, i, s, a, n, o = parseInt(this.dropHint.dom.getAttribute("raidNum"), 10),
            r = this.RaidDisksData.raids[o],
            d = 0;
        this.pool && (d = this.pool.raids && this.pool.raids[o] ? parseInt(this.pool.raids[o].minDevSize, 10) : parseInt(this.pool.get("minimal_disk_size"), 10)), this.pool && this.pool.raids && (n = this.pool.raids[o]), -1 < this.raidLevel.indexOf("shr") ? a = this.SHRDiskNum : n && "repair" === this.owner.add_type ? a = parseInt(n.designedDiskCount, 10) : (a = this.maxDisks, Ext.each(r.disks, function(e) {
            e.dummy || --a
        }, this));
        var l, p = [],
            u = [];
        Ext.each(e, function(e) {
            var i = e.dom.getAttribute("devId");
            if ((t = this.diskMap[i]).totalSizeNumber >= d && 0 < a) {
                var s = parseInt(e.dom.getAttribute("raidNum"), 10);
                p.push({
                    id: t.id,
                    raidNum: s
                }), u.push(this.createDisk(t, o, !1, !1, !0)), --a
            }
        }, this), Ext.each(p, function(e) {
            for (var t = 0; t < this.RaidDisksData.raids[e.raidNum].disks.length; ++t) this.RaidDisksData.raids[e.raidNum].disks[t] && e.id === this.RaidDisksData.raids[e.raidNum].disks[t].id && (this.RaidDisksData.raids[e.raidNum].disks[t] = null)
        }, this), Ext.each(this.RaidDisksData.raids, function(e) {
            l = [], Ext.each(e.disks, function(e) {
                e && !e.dummy && l.push(e)
            }, this), delete e.disks, e.disks = l
        }, this), r.disks = r.disks.concat(u), o = 0, Ext.each(this.RaidDisksData.raids, function(e) {
            for (this.pool && this.pool.raids && (n = this.pool.raids[o]), s = this.maxDisks - e.disks.length, -1 < this.raidLevel.indexOf("shr") ? (i = this.requiredDiskForSHR, s = i) : n && "repair" === this.owner.add_type ? (i = parseInt(n.designedDiskCount, 10) - e.disks.length, s = i, "raid_6" !== this.raidLevel && "raid_10" !== this.raidLevel || (i = this.getRepairRequiredCount(l, n, i))) : n && "expand_by_disk" === this.owner.add_type ? i = parseInt(n.designedDiskCount, 10) - e.disks.length + 1 : n && "migrate" === this.owner.add_type ? i = "raid_1" === this.raidLevel && 2 === parseInt(n.designedDiskCount, 10) ? parseInt(n.designedDiskCount, 10) - e.disks.length + 1 : this.minDisks > parseInt(n.designedDiskCount, 10) ? this.minDisks - e.disks.length : "raid_1" === this.pool.device_type && "raid_1" !== this.raidLevel ? this.minDisks - e.disks.length : parseInt(n.designedDiskCount, 10) + 1 - e.disks.length : (i = this.minDisks - e.disks.length, "raid_10" === this.raidLevel && e.disks.length > this.minDisks && 1 == e.disks.length % 2 && (i = 1)); 0 < s;) e.disks.push({
                raidNum: o,
                dummy: !0,
                required: 0 < i,
                cls: 0 < i ? "sds-space-required-disk nonselectable" : "sds-space-dummy nonselectable"
            }), --s, --i;
            ++o
        }, this), this.checkLastRAID(), this.prepareFreeDisksData(), this.freeDisksPanel.view.store.loadData(this.FreeDisksData, !1), this.raidDisksPanel.view.store.loadData(this.RaidDisksData, !1)
    },
    dropOnTopSToS: function(e) {
        var t, i, s, a = parseInt(this.dropHint.dom.getAttribute("raidNum"), 10),
            n = 0;
        this.pool && (n = this.pool.raids && this.pool.raids[a] ? parseInt(this.pool.raids[a].minDevSize, 10) : parseInt(this.pool.get("minimal_disk_size"), 10));
        var o = [];
        Ext.each(e, function(e) {
            o.push(e.dom.getAttribute("devId"))
        }, this);
        var r, d = [],
            l = this.maxDisks;
        for (this.pool && this.pool.raids && (r = this.pool.raids[a]), l = -1 < this.raidLevel.indexOf("shr") ? this.SHRDiskNum : r && "repair" === this.owner.add_type ? parseInt(r.designedDiskCount, 10) : this.maxDisks, i = 0; i < this.RaidDisksData.raids[a].disks.length; ++i)
            if (this.RaidDisksData.raids[a].disks[i]) {
                if (this.RaidDisksData.raids[a].disks[i].dummy) break;
                this.RaidDisksData.raids[a].disks[i].id === this.dropHint.dom.getAttribute("devId") && Ext.each(e, function(e) {
                    var t = e.dom.getAttribute("devId"),
                        i = this.diskMap[t];
                    if (i.totalSizeNumber >= n && 0 < l) {
                        for (var s = parseInt(e.dom.getAttribute("raidNum"), 10), o = 0; o < this.RaidDisksData.raids[s].disks.length; ++o)
                            if (this.RaidDisksData.raids[s].disks[o] && this.RaidDisksData.raids[s].disks[o].id === i.id) {
                                this.RaidDisksData.raids[s].disks[o] = null;
                                break
                            } d.push(this.createDisk(i, a, !1, !1, !0)), --l
                    }
                }, this), 0 < l && this.RaidDisksData.raids[a].disks[i] && -1 === o.indexOf(this.RaidDisksData.raids[a].disks[i].id) ? (d.push(this.RaidDisksData.raids[a].disks[i]), --l) : 0 >= l && this.RaidDisksData.raids[a].disks[i] && this.freeDisks[this.RaidDisksData.raids[a].disks[i].id] && (this.freeDisks[this.RaidDisksData.raids[a].disks[i].id].available = !0)
            } delete this.RaidDisksData.raids[a].disks, this.RaidDisksData.raids[a].disks = d, Ext.each(this.RaidDisksData.raids, function(e) {
            d = [], Ext.each(e.disks, function(e) {
                e && !e.dummy && d.push(e)
            }, this), delete e.disks, e.disks = d
        }, this), a = 0, Ext.each(this.RaidDisksData.raids, function(e) {
            for (this.pool && this.pool.raids && (r = this.pool.raids[a]), s = this.maxDisks - e.disks.length, -1 < this.raidLevel.indexOf("shr") ? (t = this.requiredDiskForSHR, s = t) : r && "repair" === this.owner.add_type ? (t = parseInt(r.designedDiskCount, 10) - e.disks.length, s = t, "raid_6" !== this.raidLevel && "raid_10" !== this.raidLevel || (t = this.getRepairRequiredCount(d, r, t))) : r && "expand_by_disk" === this.owner.add_type ? t = parseInt(r.designedDiskCount, 10) - e.disks.length + 1 : r && "migrate" === this.owner.add_type ? t = "raid_1" === this.raidLevel && 2 === parseInt(r.designedDiskCount, 10) ? parseInt(r.designedDiskCount, 10) - e.disks.length + 1 : this.minDisks > parseInt(r.designedDiskCount, 10) ? this.minDisks - e.disks.length : "raid_1" === this.pool.device_type && "raid_1" !== this.raidLevel ? this.minDisks - e.disks.length : parseInt(r.designedDiskCount, 10) + 1 - e.disks.length : (t = this.minDisks - e.disks.length, "raid_10" === this.raidLevel && e.disks.length > this.minDisks && 1 == e.disks.length % 2 && (t = 1)); 0 < s;) e.disks.push({
                raidNum: a,
                dummy: !0,
                required: 0 < t,
                cls: 0 < t ? "sds-space-required-disk nonselectable" : "sds-space-dummy nonselectable"
            }), --s, --t;
            ++a
        }, this), this.checkLastRAID(), this.prepareFreeDisksData(), this.freeDisksPanel.view.store.loadData(this.FreeDisksData, !1), this.raidDisksPanel.view.store.loadData(this.RaidDisksData, !1)
    },
    dropOnBottomSToS: function(e) {
        var t, i, s, a, n = parseInt(this.dropHint.dom.getAttribute("raidNum"), 10),
            o = 0;
        this.pool && (o = this.pool.raids && this.pool.raids[n] ? parseInt(this.pool.raids[n].minDevSize, 10) : parseInt(this.pool.get("minimal_disk_size"), 10));
        var r = [];
        Ext.each(e, function(e) {
            r.push(e.dom.getAttribute("devId"))
        }, this);
        var d, l = [],
            p = this.maxDisks;
        for (this.pool && this.pool.raids && (d = this.pool.raids[n]), p = -1 < this.raidLevel.indexOf("shr") ? this.SHRDiskNum : d && "repair" === this.owner.add_type ? parseInt(d.designedDiskCount, 10) : this.maxDisks, s = 0; s < this.RaidDisksData.raids[n].disks.length; ++s)
            if (this.RaidDisksData.raids[n].disks[s]) {
                if (this.RaidDisksData.raids[n].disks[s].dummy) break;
                0 < p && this.RaidDisksData.raids[n].disks[s] && -1 === r.indexOf(this.RaidDisksData.raids[n].disks[s].id) ? (l.push(this.RaidDisksData.raids[n].disks[s]), --p) : 0 >= p && this.RaidDisksData.raids[n].disks[s] && (this.freeDisks[this.RaidDisksData.raids[n].disks[s].id].available = !0), this.RaidDisksData.raids[n].disks[s] && this.RaidDisksData.raids[n].disks[s].id === this.dropHint.dom.getAttribute("devId") && Ext.each(e, function(e) {
                    var i = e.dom.getAttribute("devId");
                    if ((t = this.diskMap[i]).totalSizeNumber >= o && 0 < p) {
                        for (var s = parseInt(e.dom.getAttribute("raidNum"), 10), a = 0; a < this.RaidDisksData.raids[s].disks.length; ++a)
                            if (this.RaidDisksData.raids[s].disks[a] && this.RaidDisksData.raids[s].disks[a].id === t.id) {
                                this.RaidDisksData.raids[s].disks[a] = null;
                                break
                            } l.push(this.createDisk(t, n, !1, !1, !0)), --p
                    }
                }, this)
            } delete this.RaidDisksData.raids[n].disks, this.RaidDisksData.raids[n].disks = l, Ext.each(this.RaidDisksData.raids, function(e) {
            l = [], Ext.each(e.disks, function(e) {
                e && !e.dummy && l.push(e)
            }, this), delete e.disks, e.disks = l
        }, this), n = 0, Ext.each(this.RaidDisksData.raids, function(e) {
            for (this.pool && this.pool.raids && (d = this.pool.raids[n]), a = this.maxDisks - e.disks.length, -1 < this.raidLevel.indexOf("shr") ? (i = this.requiredDiskForSHR, a = i) : d && "repair" === this.owner.add_type ? (i = parseInt(d.designedDiskCount, 10) - e.disks.length, a = i, "raid_6" !== this.raidLevel && "raid_10" !== this.raidLevel || (i = this.getRepairRequiredCount(l, d, i))) : d && "expand_by_disk" === this.owner.add_type ? i = parseInt(d.designedDiskCount, 10) - e.disks.length + 1 : d && "migrate" === this.owner.add_type ? i = "raid_1" === this.raidLevel && 2 === parseInt(d.designedDiskCount, 10) ? parseInt(d.designedDiskCount, 10) - e.disks.length + 1 : this.minDisks > parseInt(d.designedDiskCount, 10) ? this.minDisks - e.disks.length : "raid_1" === this.pool.device_type && "raid_1" !== this.raidLevel ? this.minDisks - e.disks.length : parseInt(d.designedDiskCount, 10) + 1 - e.disks.length : (i = this.minDisks - e.disks.length, "raid_10" === this.raidLevel && e.disks.length > this.minDisks && 1 == e.disks.length % 2 && (i = 1)); 0 < a;) e.disks.push({
                raidNum: n,
                dummy: !0,
                required: 0 < i,
                cls: 0 < i ? "sds-space-required-disk nonselectable" : "sds-space-dummy nonselectable"
            }), --a, --i;
            ++n
        }, this), this.checkLastRAID(), this.prepareFreeDisksData(), this.freeDisksPanel.view.store.loadData(this.FreeDisksData, !1), this.raidDisksPanel.view.store.loadData(this.RaidDisksData, !1)
    },
    checkAddNewRAID: function(e) {
        if ("repair" !== this.owner.add_type) {
            var t = this.RaidDisksData.raids[this.RaidDisksData.raids.length - 1].disks,
                i = !1,
                s = {};
            if (Ext.each(t, function(e) {
                    if (e.dummy) return i = !0, !1
                }, this), !i) {
                var a = this.RaidDisksData.raids.length;
                s.id = String.format(this.subgroupName, a + 1), s.raidNum = a, s.disks = [], this.RaidDisksData.raids.push(s);
                var n = this.maxDisks;
                Ext.each(e, function(e) {
                    if (0 === n) return !1;
                    var t = e.dom.getAttribute("devId"),
                        i = this.diskMap[t];
                    this.freeDisks[t].available = !1, s.disks.push(this.createDisk(i, a, !1, !1, !0)), --n
                }, this);
                var o = this.minDisks - s.disks.length;
                "raid_10" === this.raidLevel && s.disks.length > this.minDisks && 1 == s.disks.length % 2 && (o = 1);
                for (var r = this.maxDisks - s.disks.length; 0 < r;) s.disks.push({
                    raidNum: a,
                    dummy: !0,
                    required: 0 < o,
                    cls: 0 < o ? "sds-space-required-disk nonselectable" : "sds-space-dummy nonselectable"
                }), --r, --o;
                this.prepareFreeDisksData(), this.freeDisksPanel.view.store.loadData(this.FreeDisksData, !1), this.raidDisksPanel.view.store.loadData(this.RaidDisksData, !1)
            }
        }
    },
    checkAddNewDummyRaid: function() {
        if ("repair" !== this.owner.add_type) {
            var e = !0;
            if (Ext.each(this.RaidDisksData.raids, function(t) {
                    return Ext.each(t.disks, function(t) {
                        if (t.dummy) return e = !1
                    }, this), e
                }, this), e) {
                var t = this.minDisks,
                    i = this.maxDisks,
                    s = [],
                    a = this.RaidDisksData.raids.length,
                    n = {};
                for (a !== this.firstEditableRaid && (t = 0); 0 < i;) s.push({
                    raidNum: a,
                    dummy: !0,
                    required: 0 < t,
                    cls: 0 < t ? "sds-space-required-disk nonselectable" : "sds-space-dummy nonselectable"
                }), --i, --t;
                n.disks = s, n.id = String.format(this.subgroupName, a + 1), n.raidNum = a, this.RaidDisksData.raids.push(n), this.raidDisksPanel.view.store.loadData(this.RaidDisksData, !1)
            }
        }
    },
    checkLastRAID: function() {
        for (var e, t, i = !0; i && !(1 >= this.RaidDisksData.raids.length);) {
            for (t = this.RaidDisksData.raids[this.RaidDisksData.raids.length - 1], e = 0; e < t.disks.length; e++)
                if (!t.disks[e].dummy) {
                    i = !1;
                    break
                } i && this.RaidDisksData.raids.pop()
        }
        this.isMultiRAIDMode() && "migrate" !== this.owner.add_type && this.checkAddNewDummyRaid()
    },
    isInDropZone: function(e, t) {
        var i, s = {
            begin: [0, 0],
            end: [0, 0]
        };
        if ("freeDisks" === t) {
            var a = Ext.get("freeDisksPanel");
            i = a.getXY(), s.begin[0] = i[0], s.begin[1] = i[1], s.end[0] = i[0] + a.getWidth(), s.end[1] = i[1] + a.getHeight()
        } else {
            var n = Ext.get("raidDisksPanel");
            i = n.getXY(), s.begin[0] = i[0], s.begin[1] = i[1], s.end[0] = i[0] + n.getWidth(), s.end[1] = i[1] + n.getHeight()
        }
        return (i = e.getXY())[0] >= s.begin[0] && i[1] >= s.begin[1] && i[0] <= s.end[0] && i[1] <= s.end[1]
    },
    getSelectedDisks: function(e) {
        var t = [],
            i = {};
        return Ext.each(e.query(".sds-pool-create-device-selected"), function() {
            var e = new Ext.Element(this);
            e.hasClass("owner") ? (i[this.getAttribute("devId")] = !0, Ext.each(e.next().query("div"), function() {
                var e = new Ext.Element(this);
                e.hasClass("sds-space-disk-icon") || t.push(e)
            })) : i[this.getAttribute("owner")] || t.push(e)
        }), t
    },
    activate: function() {
        var e = this.getData("raid_type", ""),
            t = this.getData("raid_level", ""),
            i = this.getData("hdd_type", ""),
            s = this.getData("raid_limit_number", 6),
            a = this.getData("manage_action", "create"),
            n = {};
        this.pool = this.getData("pool"), "migrate" === a && (t = this.owner.getRaidLevel()), this.setUnavailableDisks(), this.refreshDesc(), this.addListenerOnClickLink(), this.raidType === e && this.raidLevel === t && this.hddType === i && this.raidLimitNum === s || (this.raidType = e, this.raidLevel = t, this.raidLimitNum = s, n.diskType = i, this.getFreeDisks(n), this.initialized = !1), this.isMultiRAIDMode() ? this.subgroupName = String.format("{0} ({1} {2})", _T("volume", "volume_storage_pool"), _T("volume", "volume_raid_subgroup"), "{0}") : this.subgroupName = _T("volume", "volume_storage_pool"), this.decideMinMaxDiskNumber(), this.initialized || (this.initialized = !0, this.initializeRAIDData()), this.updateEstimateSize(), this.prepareFreeDisksData(), this.freeDisksPanel.view.store.loadData(this.FreeDisksData, !1), this.raidDisksPanel.view.store.loadData(this.RaidDisksData, !1)
    },
    decideMinMaxDiskNumber: function() {
        var e = SYNO.SDS.StorageUtils.RAIDDiskMinMaxCountGet(this.raidLevel, this.raidLimitNum);
        this.minDisks = e.min, this.maxDisks = e.max
    },
    initializeRAIDData: function() {
        var e, t, i, s, a;
        if (this.RaidDisksData = {}, this.RaidDisksData.raids = [], this.pool && this.pool.raids) return this.pool.raids.sort(this.sortRaid), t = 0, Ext.each(this.pool.raids, function(n) {
            for ((e = {}).id = String.format(this.subgroupName, t + 1), e.raidNum = t, e.disks = [], this.RaidDisksData.raids.push(e), Ext.each(n.devices, function(s) {
                    if ("crashed" === (i = this.diskMap[s.id]).get("status") || "deactivated" === i.get("status")) return !0;
                    e.disks.push(this.createDisk(i, t, !1, !1, !1))
                }, this), e.disks.sort(SYNO.SDS.StorageUtils.DiskSort), "repair" === this.owner.add_type ? (s = n.designedDiskCount - n.normalDevCount, a = s, "raid_6" !== this.raidLevel && "raid_10" !== this.raidLevel || (s = this.getRepairRequiredCount(e.disks, n, s))) : "expand_by_disk" === this.owner.add_type ? (s = 1, a = this.maxDisks - e.disks.length) : "migrate" === this.owner.add_type ? (s = "raid_1" === this.raidLevel ? 1 : this.minDisks > parseInt(n.designedDiskCount, 10) ? this.minDisks - e.disks.length : "raid_1" === this.pool.device_type && "raid_1" !== this.raidLevel ? this.minDisks - e.disks.length : parseInt(n.designedDiskCount, 10) + 1 - e.disks.length, a = this.maxDisks - e.disks.length) : ("raid_10" === this.raidLevel && e.disks.length > this.minDisks && 1 == e.disks.length % 2 && (s = 1), a = s, this.isMultiRAIDMode() && (a = this.maxDisks - e.disks.length)), this.firstEditableRaid = 0 < a ? t : t + 1; 0 < a;) e.disks.push({
                raidNum: t,
                dummy: !0,
                required: 0 < s,
                cls: 0 < s ? "sds-space-required-disk nonselectable" : "sds-space-dummy nonselectable"
            }), --a, --s;
            ++t
        }, this), void(this.isMultiRAIDMode() && this.checkAddNewDummyRaid());
        "repair" === this.owner.add_type && -1 < this.raidLevel.indexOf("shr") ? this.initSHRRAID() : (this.firstEditableRaid = 0, this.initialFirstRAID())
    },
    initSHRRAID: function() {
        var e = this.requiredDiskForSHR,
            t = {};
        for (t.id = String.format(this.subgroupName, 1), t.raidNum = 0, t.disks = [], this.RaidDisksData.raids.push(t), Ext.each(this.pool.get("disks"), function(e) {
                var i = this.diskMap[e];
                if ("crashed" === i.get("status") || "deactivated" === i.get("status")) return !0;
                t.disks.push(this.createDisk(i, 0, !1, !1, !1))
            }, this); 0 < e;) t.disks.push({
            raidNum: 0,
            dummy: !0,
            required: !0,
            cls: "sds-space-required-disk nonselectable"
        }), --e;
        this.SHRDiskNum = t.disks.length
    },
    initialFirstRAID: function() {
        var e = {},
            t = "";
        t = this.isMultiRAIDMode() ? String.format(this.subgroupName, 1) : this.subgroupName, e.id = t, e.raidNum = 0, e.disks = [], this.RaidDisksData.raids.push(e);
        var i = this.minDisks - e.disks.length;
        "raid_10" === this.raidLevel && e.disks.length > this.minDisks && 1 == e.disks.length % 2 && (i = 1);
        for (var s = this.maxDisks; 0 < s;) e.disks.push({
            raidNum: 0,
            dummy: !0,
            required: 0 < i,
            cls: 0 < i ? "sds-space-required-disk nonselectable" : "sds-space-dummy nonselectable"
        }), --s, --i
    },
    prepareFreeDisksData: function() {
        var e = {};
        if (0 < this.minSizeRequiredDisks && 0 < this.minSize) {
            var t = 0;
            Ext.each(this.selectedDisk, function(e) {
                e.totalSizeNumber >= this.minSize && ++t
            }, this);
            var i = [];
            t < this.minSizeRequiredDisks && Ext.each(this.selectedDisk, function(e) {
                e.totalSizeNumber >= this.minSize ? i.push(e) : e.available = !0
            }, this)
        }
        for (var s in this.freeDisks)
            if (this.freeDisks.hasOwnProperty(s)) {
                var a = this.freeDisks[s];
                if (!a.available) continue;
                var n = a.owner;
                e[n] || (e[n] = {}, e[n].id = n, e[n].name = 0 === a.container.order ? _S("hostname") : a.container.str, e[n].order = a.container.order, e[n].disks = []);
                var o = e[n];
                o.disks.push(a), o.disks.sort(SYNO.SDS.StorageUtils.DiskSort)
            } for (s in delete this.FreeDisksData, this.FreeDisksData = {}, this.FreeDisksData.containers = [], e) e.hasOwnProperty(s) && this.FreeDisksData.containers.push(e[s]);
        var r = function(e, t) {
            return e.order > t.order ? 1 : e.order < t.order ? -1 : 0
        };
        this.FreeDisksData.containers.sort(r), Ext.each(this.FreeDisksData.containers, function(e) {
            e.disks.sort(r)
        }, this)
    },
    isValid: function() {
        return this.isMultiRAIDMode() ? this.isValidMutiRaid() : this.isValidSingleRaid()
    },
    isValidMutiRaid: function() {
        var e, t, i = !0,
            s = !1,
            a = !1,
            n = !1,
            o = function(e) {
                return !e.dummy && e.is4Kn ? a = !0 : e.dummy || (n = !0), !s && e.dummy && (s = !0), i = !e.required
            };
        for (e = 0; e < this.RaidDisksData.raids.length && (0 === e || e !== this.RaidDisksData.raids.length - 1); ++e) t = this.RaidDisksData.raids[e], Ext.each(t.disks, o, this);
        return a && n ? (this.owner.getMsgBox().alert("", _T("volume", "not_allow_hybrid_hdd")), !1) : 1 === this.RaidDisksData.raids.length ? (i ? this.owner.clearStatus() : this.markupRequiredDisks(), i) : (i && 1 < this.RaidDisksData.raids.length && (t = this.RaidDisksData.raids[this.RaidDisksData.raids.length - 1], Ext.each(t.disks, function(e) {
            return i = !e.required
        }, this)), i && s && "repair" !== this.owner.add_type ? (this.markupAdditionalDisks(), !1) : (this.owner.clearStatus(), i ? this.owner.clearStatus() : this.markupRequiredDisks(), i))
    },
    markupRequiredDisks: function() {
        this.owner.setStatusError({
            text: _T("volume", "volume_fill_all_required_disks"),
            clear: 3e3
        });
        var e = Ext.get("raidDisksPanel").query(".sds-space-required-disk");
        Ext.each(e, function(e, t, i) {
            new Ext.Element(e).addClass("sds-space-red-status")
        })
    },
    markupAdditionalDisks: function() {
        this.owner.setStatusError({
            text: _T("volume", "volume_fill_all_additional_disks"),
            clear: 3e3
        });
        var e = Ext.get("raidDisksPanel").query(".sds-space-dummy"),
            t = this.RaidDisksData.raids.length - 1;
        Ext.each(e, function(e, i, s) {
            if (t === parseInt(e.getAttribute("raidNum"), 10)) return !0;
            new Ext.Element(e).addClass("sds-space-red-status")
        })
    },
    isValidSingleRaid: function() {
        var e = !0,
            t = !1,
            i = !1;
        if (!this.RaidDisksData.raids[0]) return !1;
        if (Ext.each(this.RaidDisksData.raids[0].disks, function(s) {
                return !s.dummy && s.is4Kn ? t = !0 : s.dummy || (i = !0), e = !s.required
            }, this), t && i) return this.owner.getMsgBox().alert("", _T("volume", "not_allow_hybrid_hdd")), !1;
        if (e) this.owner.clearStatus();
        else {
            this.owner.setStatusError({
                text: _T("volume", "volume_fill_all_required_disks"),
                clear: 3e3
            });
            var s = Ext.get("raidDisksPanel").query(".sds-space-required-disk");
            Ext.each(s, function(e, t, i) {
                new Ext.Element(e).addClass("red-status")
            })
        }
        return e
    },
    checkEboxWarning: function() {
        var e, t, i = this,
            s = [];
        return i.isNeedPowerButtonDisableWarning() && s.push(_T("storage_pool", "ebox_power_button_disabled")), i.isNeedCrossWarning() && s.push(_T("storage_pool", "ebox_internal_mix_warning")), 0 === s.length || (t = '<div class="sm-storage-warning-dlg-title">' + _T("storage_pool", "wizard_disk_step_ebox_dlg_title") + '</div><div class="sm-msg-box-list-section-under-title">{0}</div>', e = String.format(t, s.map(function(e) {
            return '<div class="sm-suggestion-list-item">' + e + "</div>"
        }).join("")), new SYNO.SDS.StorageManager.Dialog.Confirm({
            owner: i.owner,
            warningMsg: e,
            callback: function(e) {
                e && i.owner.goNextWithoutCheck()
            }
        }).open(), !1)
    },
    isNeedCrossWarning: function() {
        var e = this;
        return this.RaidDisksData.raids.some(function(t) {
            return e.isToBeCrossRaid(t)
        })
    },
    isToBeCrossRaid: function(e) {
        var t = e.disks.filter(function(e) {
                return !1 === e.isSelectable
            }),
            i = e.disks.filter(function(e) {
                return !0 === e.isSelectable
            }),
            s = !1,
            a = !1,
            n = function(e) {
                "internal" === e.container.type ? s = !0 : a = !0
            };
        return !(0 >= i.length) && (t.forEach(function(e) {
            return n(e)
        }), (!s || !a) && (i.forEach(function(e) {
            return n(e)
        }), s && a))
    },
    isNeedPowerButtonDisableWarning: function() {
        return this.RaidDisksData.raids.some(function(e) {
            return e.disks.filter(function(e) {
                return !0 === e.isSelectable
            }).some(function(e) {
                return e.container.supportPwrBtnDisable
            })
        })
    },
    beforeNext: function() {
        var e = this,
            t = this;
        if (!this.isValid()) return !1;
        var i = this.getDiskIds().map(function(t) {
            return e.diskMap[t]
        });
        if (!0 !== t.hasAbnormalDisk(i)) return t.checkEboxWarning();
        var s = t.getDiskAlertMsg(i),
            a = {
                yes: {
                    text: _T("common", "continue"),
                    btnStyle: "red"
                },
                no: {
                    text: _T("common", "cancel")
                }
            };
        return this.openWarningBox(t.owner, s, a).then(function(i) {
            if ("yes" !== i) return !1;
            t.checkEboxWarning() && e.owner.goNextWithoutCheck()
        }).catch(function() {
            return !1
        }), !1
    },
    getDiskIds: function() {
        var e = [];
        return this.RaidDisksData ? (Ext.each(this.RaidDisksData.raids, function(t) {
            Ext.each(t.disks, function(t) {
                "" !== t.used_by || t.dummy || e.push(t.id)
            })
        }), e) : e
    },
    getDiskShortName: function(e, t, i) {
        return 0 < e ? String.format("{0}-{1}", e, t) : String.format("{0} {1}", i, t)
    },
    getDiskGroups: function() {
        var e, t = [];
        return this.isMultiRAIDMode() ? "migrate" === this.owner.add_type ? t : this.RaidDisksData ? (Ext.each(this.RaidDisksData.raids, function(i) {
            var s = [],
                a = "new_raid",
                n = !0;
            this.pool && this.pool.raids && this.pool.raids[i.raidNum] && (a = this.pool.raids[i.raidNum].raidPath, n = !1), Ext.each(i.disks, function(e) {
                "" !== e.used_by || e.dummy || s.push(e.id)
            }, this), e = {
                isNew: n,
                disks: s,
                raidPath: a
            }, 0 < s.length && t.push(e)
        }, this), t) : t : t
    },
    setUnavailableDisks: function() {
        var e = this,
            t = e.getDiskDifference(e.allDisks, e.disks);
        e.unavailableDisks = t.filter(function(t) {
            var i = e.isDiskQualified(t, e.diskCondition).unqualifiedReasons;
            return e.isDiskToBeShowed(i)
        })
    },
    refreshDesc: function() {
        var e = this.borderPanel.actionField,
            t = this.actionTitleDesc,
            i = this.unavailableDisks.length;
        if (0 < i) {
            var s = 1 === i ? "disk_reason_add_drive_single_desc_link" : "disk_reason_add_drive_multi_desc_link";
            t = t + " " + String.format(_T("disk_info", s), "open-drive-requirement-info", i)
        }
        e.setValue(t), this.borderPanel.doLayout()
    },
    openDriveRequirementWindow: function() {
        var e = this.getDiskReasonWindowConfig(this.unavailableDisks, this.diskConfition);
        this.openDiskReasonWindow(this.owner, e)
    },
    addListenerOnClickLink: function() {
        Ext.select(".open-drive-requirement-info").on("click", this.openDriveRequirementWindow.bind(this))
    },
    getFreeDisks: function(e) {
        delete this.freeDisks, this.freeDisks = {}, Ext.each(this.disks, function(e) {
            var t;
            t = "internal" === e.get("container").type ? "host" : "expander_" + e.get("container").order;
            var i = e.get("container").order ? e.get("container").order + " -" : "",
                s = e.get("order"),
                a = e.get("pciSlot"),
                n = this.getDiskShortName(a, s, i);
            this.freeDisks[e.id] = {
                container: {
                    str: e.get("container").str,
                    type: e.get("container").type,
                    order: e.get("container").order || 0,
                    supportPwrBtnDisable: e.get("container").supportPwrBtnDisable
                },
                owner: t,
                device: e.get("device"),
                diskType: e.get("diskType"),
                driveType: e.isSSD() ? "SSD" : "HDD",
                id: e.id,
                order: e.get("order"),
                model: e.get("model"),
                name: SYNO.SDS.StorageUtils.DiskDisplayNameGet(e),
                longName: e.get("longName"),
                shortName: n,
                rpm: e.get("rpm"),
                serial: e.get("serial"),
                size_total: e.get("size_total"),
                size: SYNO.SDS.StorageUtils.SizeRender(e.get("size_total")),
                status: e.get("status"),
                temp: e.get("temp"),
                used_by: e.get("used_by"),
                available: !0,
                dummy: !1,
                is4Kn: e.get("is4Kn"),
                display4Kn: e.get("is4Kn") ? String.format("({0})", _T("volume", "4kn")) : "",
                pciSlot: a,
                portType: e.get("portType"),
                ctnOrder: parseInt(e.get("container").order, 10)
            }
        }, this)
    },
    getNames: function() {
        var e = [];
        return Ext.each(this.RaidDisksData.raids, function(t) {
            Ext.each(t.disks, function(t) {
                t.dummy || "" !== t.used_by || e.push(t.longName)
            }, this)
        }, this), e
    },
    isMultiRAIDMode: function() {
        if ("multiple" !== this.raidType) return !1;
        switch (this.raidLevel) {
            case "raid_5":
            case "raid_6":
            case "raid_f1":
                break;
            default:
                return !1
        }
        return !0
    },
    updateData: function(e) {
        e.disk_ids = this.getDiskIds(), e.disk_groups = this.getDiskGroups()
    },
    summary: function(e) {
        var t = this.getNames();
        t.length > 0 && e.append(_T("volume", "volume_apply_disk"), t.join(", "))
    },
    createDisk: function(e, t, i, s, a) {
        var n = e.get("container").order ? e.get("container").order + " -" : "",
            o = e.get("order"),
            r = e.get("pciSlot"),
            d = this.getDiskShortName(r, o, n);
        return {
            container: {
                str: e.get("container").str,
                type: e.get("container").type,
                order: e.get("container").order || 0,
                supportPwrBtnDisable: e.get("container").supportPwrBtnDisable
            },
            device: e.get("device"),
            diskType: e.get("diskType"),
            driveType: e.isSSD() ? "SSD" : "HDD",
            id: e.id,
            numId: e.get("num_id"),
            ctnOrder: e.get("container").order,
            order: e.get("order"),
            model: e.get("model"),
            name: SYNO.SDS.StorageUtils.DiskDisplayNameGet(e),
            longName: SYNO.SDS.StorageUtils.DiskDisplayNameGet(e),
            shortName: d,
            rpm: e.get("rpm"),
            serial: e.get("serial"),
            size_total: e.get("size_total"),
            size: SYNO.SDS.StorageUtils.SizeRender(e.get("size_total")),
            status: e.get("status"),
            temp: e.get("temp"),
            used_by: e.get("used_by"),
            raidNum: t,
            available: i,
            dummy: s,
            cls: a ? "selectable" : "nonselectable",
            isSelectable: a,
            is4Kn: e.get("is4Kn"),
            display4Kn: e.get("is4Kn") ? String.format("({0})", _T("volume", "4kn")) : "",
            portType: e.get("portType"),
            pciSlot: r
        }
    },
    sortRaid: function(e, t) {
        var i = e.raidPath.split("/")[2].split("d")[1],
            s = t.raidPath.split("/")[2].split("d")[1],
            a = e.designedDiskCount,
            n = t.designedDiskCount;
        return a > n ? -1 : a < n ? 1 : (i = parseInt(i, 10)) > (s = parseInt(s, 10)) ? 1 : i < s ? -1 : 0
    },
    updateEstimateSize: function() {
        var e = this,
            t = this.getDiskIds(),
            i = this.owner.getPoolObject(),
            s = {
                estimate_for: this.owner.add_type,
                space_id: i.id,
                disk_id: t,
                device_type: i.device_type,
                diskGroups: this.getDiskGroups()
            },
            a = "",
            n = e.borderPanel.south.sizeField,
            o = "expand_unfinished_shr" === this.add_type;
        0 !== t.length || o ? SYNO.API.Request({
            api: "SYNO.Storage.CGI.Pool",
            method: "estimate_size",
            version: 1,
            params: s,
            callback: function(t, i) {
                t ? (a = e.getEstimateSizeHtml(i.size), n.setValue(a)) : SYNO.SDS.StorageUtils.ReportWebapiFailure(this, i)
            },
            scope: e
        }) : (a = e.getEstimateSizeHtml(i.size.total), n.setValue(a))
    },
    getEstimateSizeHtml: function(e) {
        var t, i = this.owner.getPoolObject(),
            s = SYNO.SDS.StorageUtils.GetSizeUnit(e),
            a = "<span>" + _T("storage_pool", "estimate_capacity") + _T("common", "colon") + "</span>",
            n = this.getDiskIds(),
            o = {
                curDiskCnt: i.disks.length,
                newSelectCnt: n.length,
                isAddDisk: "expand_by_disk" === this.add_type,
                styleClass: "wizard-disk-num-cls"
            },
            r = {
                shr_without_disk_protect: "shr",
                shr_with_1_disk_protect: "shr",
                shr_with_2_disk_protect: "shr_2"
            } [i.device_type] || i.device_type;
        return t = this.getLackDiskCnt(), a + SYNO.SDS.StorageUtils.getEstimateSizeHtml("drag", !1, s, 0, t, r, o)
    },
    getLackDiskCnt: function() {
        var e = 0,
            t = !0,
            i = !1,
            s = void 0;
        try {
            for (var a, n = this.RaidDisksData.raids[Symbol.iterator](); !(t = (a = n.next()).done); t = !0) {
                var o = a.value,
                    r = !0,
                    d = !1,
                    l = void 0;
                try {
                    for (var p, u = o.disks[Symbol.iterator](); !(r = (p = u.next()).done); r = !0) {
                        p.value.required && e++
                    }
                } catch (e) {
                    d = !0, l = e
                } finally {
                    try {
                        r || null == u.return || u.return()
                    } finally {
                        if (d) throw l
                    }
                }
            }
        } catch (e) {
            i = !0, s = e
        } finally {
            try {
                t || null == n.return || n.return()
            } finally {
                if (i) throw s
            }
        }
        return e
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.DeletePool", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t, i = this;
        i.titleMap = {
            delete: _T("volume", "volume_remove_raid_group"),
            eject: _T("storage_pool", "pool_deactivate_summary_title")
        }, i.descMap = {
            delete: _T("storage_pool", "pool_delete_summary_desc"),
            eject: _T("storage_pool", "pool_deactivate_summary_desc")
        }, i.btnMap = {
            delete: {
                btnStyle: "red",
                text: _T("common", "remove")
            },
            eject: {
                btnStyle: "blue",
                text: _T("common", "run")
            }
        }, i.isDataChanged = !1, i.appWin = e.appWin, i.owner = e.owner, i.services = void 0, i.allSsdcaches = e.allSsdcaches, i.rmOpt = e.rmOpt, t = {
            title: i.titleMap[i.rmOpt],
            width: 640,
            height: 350,
            resizable: !1,
            layout: "fit",
            items: [{
                itemId: "main",
                border: !1,
                style: {
                    padding: "16px 20px 0px 20px"
                },
                items: [{
                    xtype: "syno_displayfield",
                    value: i.descMap[i.rmOpt],
                    id: i.descID = Ext.id(),
                    itemId: "desc"
                }, i.grid = new SYNO.SDS.Wizard.SummaryStep({
                    layout: "fit",
                    height: 200,
                    style: {
                        paddingTop: "8px"
                    }
                })]
            }],
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "alt_cancel"),
                scope: i,
                handler: i.onCancel
            }, {
                xtype: "syno_button",
                btnStyle: i.btnMap[i.rmOpt].btnStyle,
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                text: i.btnMap[i.rmOpt].text,
                id: i.applyButtonID = Ext.id(),
                scope: i,
                handler: i.onSave
            }]
        }, i.callParent([Ext.apply(t, e)])
    },
    onOpen: function() {
        var e, t, i = this,
            s = i.grid.getStore();
        if (i.callParent(arguments), i.pool.isSingleLun()) {
            if (0 === i.pool.luns.length) return;
            var a = i.pool.luns[0].name;
            return s.append(_T("tree", "leaf_raid"), i.pool.name), s.append(_T("volume", "volume_iscsitrg_lun"), a), void(SYNO.SDS.StorageUtils.supportSsdCache && 0 < i.allSsdcaches.length && Ext.each(i.allSsdcaches, function(e) {
                if (-1 < e.get("path").indexOf(a)) return s.append(_T("volume", "ssd_cache_string2"), String.format("{0}({1})", _T("volume", "ssd_cache"), a)), !1
            }, i))
        }
        i.pool.isSingleVolume() ? (t = "SYNO.Storage.CGI.Volume", e = {
            space_id: [i.pool.get("deploy_path")]
        }) : (t = "SYNO.Storage.CGI.Pool", e = {
            space_id: i.pool.get("id")
        }), i.setStatusBusy(), SYNO.API.Request({
            api: t,
            method: "enum_resource",
            version: 1,
            params: e,
            callback: function(e, t, s, a) {
                i.clearStatusBusy(), e ? i.loadData(t, s) : SYNO.SDS.StorageUtils.ReportWebapiFailure(this, t)
            },
            scope: i
        })
    },
    loadData: function(e, t) {
        var i, s, a, n = this,
            o = SYNO.SDS.StorageUtils,
            r = {},
            d = {},
            l = [],
            p = o.CheckFailedMsg(e.check),
            u = !1;
        "hard_failed" === p ? (u = !0, Ext.getCmp(n.applyButtonID).disable(), Ext.getCmp(n.descID).setValue(_T("volume", "del_hard_check_fail")), function(e) {
            var t = !0;
            "single" === n.pool.get("raidType") && n.pool.get("deploy_path") ? (e.space_id.forEach(function(e) {
                if ("crashed" !== n.volumeMap[e].status) return t = !1, !1
            }), t && (Ext.getCmp(n.applyButtonID).enable(), Ext.getCmp(n.descID).setValue(_T("volume", "del_soft_check_fail")))) : "crashed" === n.poolMap[e.space_id].status && (Ext.getCmp(n.applyButtonID).enable(), Ext.getCmp(n.descID).setValue(_T("volume", "del_soft_check_fail")))
        }(t)) : "soft_failed" === p ? Ext.getCmp(n.descID).setValue(_T("volume", "del_soft_check_fail")) : Ext.getCmp(n.descID).setValue(n.descMap[n.rmOpt]), (s = n.grid.getStore()).append(_T("volume", "volume_storage_pool"), n.pool.name), e.check && e.check.pools && o.CheckMsg(e.check, u, "pools", s), "single" === n.pool.get("raidType") && n.pool.get("deploy_path") && (a = o.SpaceIDParser(n.pool.get("deploy_path")).str, s.append(_T("volume", "volume"), a), o.CheckMsg(e.check, u, "volumes", s), SYNO.SDS.StorageUtils.supportSsdCache && 0 < n.allSsdcaches.length && Ext.each(n.allSsdcaches, function(e) {
            if (n.pool.get("deploy_path") === e.get("mountSpaceId")) return s.append(_T("volume", "ssd_cache_string2"), o.SpaceIDParser(e.get("id")).str), !1
        }, n)), e.services && e.services.length > 0 && s.append(_T("volume", "volume_warninglistservice"), o.getServiceNames(e.services)), e.iscsiluns && e.iscsiluns.length > 0 && (s.append(_T("volume", "volume_iscsitrg_lun"), o.getNamesString(e.iscsiluns)), o.CheckMsg(e.check, u, "iscsiluns", s)), e.volumes && e.volumes.length > 0 && (s.append(_T("volume", "volume"), o.getVolumeNames(e.volumes)), o.CheckMsg(e.check, u, "volumes", s)), e.shares && e.shares.length > 0 && (s.append(_T("volume", "volume_status_warningdelinfo"), o.getNamesString(e.shares)), o.CheckMsg(e.check, u, "shares", s)), e.pkgs && e.pkgs.length > 0 && s.append(_T("pkgmgr", "title_packages"), o.getNamesString(e.pkgs)), n.services = e.services, SYNO.SDS.StorageUtils.supportSsdCache && (Ext.each(e.volumes, function(e) {
            r[e.name] = !0
        }), Ext.each(e.iscsiluns, function(e) {
            d[e.name] = !0
        }), Ext.each(n.allSsdcaches, function(e) {
            i = e.get("mountSpaceId"), r[i] && l.push(String.format("{0} ({1})", o.SpaceIDParser(e.get("id")).str, o.SpaceIDParser(i).str)), d[o.SpaceIDParser(i).num] && l.push(String.format("{0} ({1})", o.SpaceIDParser(e.get("id")).str, o.SpaceIDParser(i).num))
        }, n), 0 < l.length && s.append(_T("volume", "ssd_cache_string2"), l.join(", ")))
    },
    onSave: function() {
        var e, t, i, s, a = this;
        "eject" === a.rmOpt ? (t = "SYNO.Storage.CGI.Pool", i = "deactivate", e = {
            space_id: a.pool.id
        }, SYNO.SDS.Utils.PasswordConfirmDialog.openDialog(a, a.applySettings, [t, i, e])) : (a.pool.isSingleVolume() ? (t = "SYNO.Storage.CGI.Volume", i = "delete", e = {
            delete_space: !0,
            space_id: [a.pool.get("deploy_path")]
        }) : (t = "SYNO.Storage.CGI.Pool", i = "delete", e = {
            space_id: a.pool.get("id")
        }), e.force = !0, s = String.format('1. <font class="red-status">{0}</font><br/>', _T("volume", "volume_delete_warning")), s += String.format("2. {0}", _T("volume", "volume_all_service_stop")), a.getMsgBox().confirmDelete("", s, function(s) {
            "yes" === s && SYNO.SDS.Utils.PasswordConfirmDialog.openDialog(a, a.applySettings, [t, i, e])
        }, a, void 0))
    },
    onCancel: function() {
        this.close()
    },
    applySettings: function(e, t, i) {
        var s = {};
        this.setStatusBusy({
            text: _T("common", "saving")
        }), SYNO.API.Request({
            api: e,
            method: t,
            version: 1,
            params: i,
            callback: function(i, a, n, o) {
                if (!i) return this.clearStatusBusy(), void(SYNO.SDS.StorageUtils.IsFeasibilityFail(a, s) ? SYNO.SDS.StorageUtils.ConfirmFeasibilityFail(this, s, this.applySettings, e, t, n) : (SYNO.SDS.StorageUtils.HARemoteCheckErrParsing(a), SYNO.SDS.StorageUtils.ReportWebapiFailure(this, a)));
                "eject" === this.rmOpt && SYNO.SDS.StorageUtils.updateItemContent({
                    itemType: "pools",
                    props: [{
                        id: n.space_id,
                        values: {
                            status: "deactivating",
                            is_actioning: !0
                        }
                    }]
                }), this.clearStatusBusy(), this.disableServices(this.services), this.isDataChanged = !0, this.close()
            },
            scope: this
        })
    },
    disableServices: function(e) {
        var t = {
            media: void 0,
            audio: "SYNO.SDS.AudioStation.Application",
            itunes: void 0,
            photo: "SYNO.SDS.PhotoStation",
            web: "SYNO.SDS.WebStation",
            netbkp: void 0,
            download: "SYNO.SDS.DownloadStation",
            mysql: void 0,
            surveillance: "SYNO.SDS.SurveillanceStation",
            userhome: void 0,
            weblocal: void 0
        };
        Ext.each(e, function(e) {
            Ext.isString(t[e]) && SYNO.SDS.StatusNotifier.setServiceDisabled(t[e], !0)
        })
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.CreatePoolMain", {
    extend: "SYNO.SDS.StorageManager.Wizard.ModalWindow",
    constructor: function(e) {
        var t, i = this;
        i.isDataChanged = !1, i.appWin = e.appWin, i.owner = e.owner, t = {
            title: _T("volume", "volume_raid_creation_title"),
            mode: "pool_create",
            width: 700,
            height: 520,
            minHeight: 475,
            minWidth: 700,
            resizable: !1,
            border: !1,
            steps: []
        }, SYNO.SDS.StorageUtils.isSingleBay() || t.steps.push(new SYNO.SDS.StorageManager.Wizard.PoolTypeStep({
            appWin: i.appWin,
            itemId: "raid_type",
            nextId: "property"
        })), t.steps.push(new SYNO.SDS.StorageManager.Wizard.PoolPropertyStep({
            appWin: i.appWin,
            itemId: "property",
            nextId: "disk",
            allDisks: e.llDisks,
            getMatchedDisk: e.getMatchedDisk
        })), t.steps.push(new SYNO.SDS.StorageManager.Wizard.DiskStep({
            appWin: i.appWin,
            itemId: "disk",
            nextId: "disk_check",
            diskMap: e.diskMap,
            getMatchedDisk: e.getMatchedDisk
        })), t.steps.push(new SYNO.SDS.StorageManager.Wizard.DiskCheckStep({
            appWin: i.appWin,
            itemId: "disk_check",
            nextId: "summary"
        })), t.steps.push(new SYNO.SDS.StorageManager.Wizard.CreatePoolSummaryStep({
            appWin: i.appWin,
            itemId: "summary",
            nextId: null
        })), i.callParent([Ext.apply(t, e)])
    },
    onOpen: function() {
        SYNO.SDS.StorageUtils.isSingleBay() && this.setData("raid_type", "single"), this.setData("create_for", "storage_pool"), this.callParent(arguments)
    },
    getRaidType: function() {
        return this.getData("raid_type", "")
    },
    getDesc: function() {
        return this.getData("pool_description", "")
    },
    getRaidLevel: function() {
        var e = this.getData("raid_level", ""),
            t = this.getData("disk_ids", []);
        return "shr_2" === e ? e = "shr_with_2_disk_protect" : "shr" === e && (e = 1 === t.length ? "shr_without_disk_protect" : "shr_with_1_disk_protect"), e
    },
    getRaidLimitNum: function() {
        return this.getData("raid_limit_number")
    },
    getHddType: function() {
        return this.getData("hdd_type")
    },
    getDiskIds: function() {
        return this.getData("disk_ids")
    },
    getDiskGroups: function() {
        return this.getData("disk_groups")
    },
    getDiskCheck: function() {
        return this.getData("disk_check")
    },
    applySettings: function(e) {
        var t = {},
            i = {};
        t.disk_id = this.getDiskIds(), t.device_type = this.getRaidLevel(), t.is_disk_check = this.getDiskCheck(), t.is_pool_child = !1, t.allocate_size = "0", t.spare_disk_count = "0", t.desc = this.getDesc(), t.is_unused = "single" === this.getRaidType(), t.diskGroups = this.getDiskGroups(), t.limitNum = this.getRaidLimitNum().toString(), t.force = e || !1, 1 >= t.diskGroups.length && delete t.diskGroups, this.getButton("next").disable(), this.setStatusBusy({
            text: _T("common", "saving")
        }), SYNO.API.Request({
            api: "SYNO.Storage.CGI.Pool",
            method: "create",
            version: 1,
            params: t,
            callback: function(e, t, s, a) {
                var n;
                this.clearStatusBusy(), e ? (this.getButton("next").enable(), this.getButton("next").setText(_T("common", "alt_finish")), this.isDataChanged = !0, n = String.format(_T("volume", "volume_create_vol_lun_hint"), _T("volume", "volume_storage_pool")), this.owner.getMsgBox().alert("", n), this.close()) : SYNO.SDS.StorageUtils.IsFeasibilityFail(t, i) ? SYNO.SDS.StorageUtils.ConfirmFeasibilityFail(this, i, this.applySettings, !0) : (SYNO.SDS.StorageUtils.HARemoteCheckErrParsing(t), SYNO.SDS.StorageUtils.ReportWebapiFailure(this, t))
            },
            scope: this
        })
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.PoolTypeStep", {
    extend: "SYNO.SDS.StorageManager.Wizard.Step",
    constructor: function(e) {
        var t, i = SYNO.SDS.StorageUtils.getMaxVolumeSize() <= 16 * Math.pow(1024, 4),
            s = String.format('<span class="syno-ux-note">{0}{1} </span>{2}', _T("common", "note"), _T("common", "colon"), "{0}");
        this.setDefault = !0, this.appWin = e.appWin, t = {
            headline: _T("volume", "volume_raid_purpose_title"),
            cls: "sm-custom-form",
            listeners: {
                afterlayout: this.addTip,
                scope: this,
                single: !0
            },
            items: [{
                xtype: "syno_displayfield",
                value: _T("volume", "pool_type_step_description")
            }, {
                xtype: "syno_displayfield",
                cls: "sm-empty-line"
            }, {
                xtype: "syno_radio",
                boxLabel: _T("volume", "pool_type_for_performance"),
                name: "RaidType",
                itemId: "singleVolume",
                inputValue: "single"
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                value: _T("volume", "pool_support_single_volume")
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                htmlEncode: !1,
                value: String.format(s, _T("volume", "pool_single_volume_disk_number_limit_note")),
                hidden: !SYNO.SDS.StorageUtils.supportRaidGroup
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                htmlEncode: !1,
                value: String.format(s, _T("volume", "pool_single_volume_size_limit_note")),
                hidden: !i
            }, {
                xtype: "syno_displayfield",
                cls: "sm-empty-line"
            }, {
                xtype: "syno_radio",
                boxLabel: _T("volume", "pool_type_for_flexibility"),
                name: "RaidType",
                itemId: "multiple",
                inputValue: "multiple"
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                value: _T("volume", "pool_support_multiple_volume")
            }, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                indent: 1,
                value: String.format(s, _T("volume", "pool_support_shr")),
                hidden: !SYNO.SDS.StorageUtils.isSupportSHR() || SYNO.SDS.StorageUtils.supportRaidGroup || _S("ha_running")
            }, {
                xtype: "syno_displayfield",
                itemId: "supportRaidGroupField",
                htmlEncode: !1,
                indent: 1,
                value: String.format(s, _T("volume", "pool_support_raid_group")),
                hidden: !SYNO.SDS.StorageUtils.supportRaidGroup
            }]
        }, this.callParent([Ext.apply(t, e)])
    },
    getRaidType: function() {
        return this.getForm().getValues().RaidType
    },
    getNext: function() {
        return this.nextId
    },
    isSkip: function() {
        return SYNO.SDS.StorageUtils.isSingleBay()
    },
    updateData: function(e) {
        e.raid_type = this.getRaidType()
    },
    addTip: function() {
        var e = this.getComponent("supportRaidGroupField"),
            t = _T("volume", "raid_group_feature_info");
        e && void 0 !== e.getEl() && SYNO.ux.AddTip(e.getEl(), Ext.util.Format.htmlEncode(t))
    },
    activate: function() {
        this.setDefault && (this.getComponent("singleVolume").setValue(!0), this.setDefault = !1)
    },
    summary: function(e) {
        var t = "single" === this.getRaidType() ? _T("common", "no") : _T("common", "yes");
        e.append(_T("volume", "volume_multiple_vol_lun_support"), t)
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.PoolPropertyStep", {
    extend: "SYNO.SDS.StorageManager.Wizard.Step",
    constructor: function(e) {
        var t, i = this,
            s = [],
            a = SYNO.SDS.StorageUtils;
        i.setDefault = !0, i.setDefaultDesc = !0, i.appWin = e.appWin, i.currentRaidType = null, i.currentRaidLimit = 12, i.isNeedSelectSource = !a.isSupportRaidCross() && a.isSupportEbox() && a.isEboxPluged(), i.isOneBayBasicVolume = a.isSingleBay(), i.tabList = [], i.tabList.push(["SAS", "SAS"]), "no" === _D("support_dual_head", "no") && i.tabList.push(["SATA", "SATA"]), "yes" === _D("support_internal_volume_by_nvme") && i.tabList.push(["NVMe", "NVMe"]), i.isNeedSelectSource && s.push({
            xtype: "syno_storage_disableable_combobox",
            name: "hddSource",
            itemId: "hddSource",
            lazyRender: !0,
            store: new Ext.data.ArrayStore({
                id: "value",
                fields: ["text", "value", "disabled"]
            }),
            fieldLabel: _T("volume", "pool_disk_source"),
            displayField: "text",
            valueField: "value",
            forceSelection: !0,
            mode: "local",
            allowBlank: !1,
            listeners: {
                select: this.onDiskSourceSelect,
                scope: this
            }
        }), s = s.concat([{
            xtype: "syno_textfield",
            itemId: "desc",
            name: "desc",
            fieldLabel: _T("volume", "pool_desc"),
            maxLength: 64,
            enableKeyEvents: !0,
            listeners: {
                keypress: function() {
                    this.setDefaultDesc = !1
                },
                scope: this
            }
        }, {
            xtype: "syno_combobox",
            name: "level",
            itemId: "level",
            hiddenName: "level",
            store: this.levelStore = new Ext.data.ArrayStore({
                id: "value",
                fields: ["text", "value"]
            }),
            fieldLabel: _T("volume", "volume_raid_title"),
            displayField: "text",
            valueField: "value",
            forceSelection: !0,
            mode: "local",
            allowBlank: !1,
            validator: function() {
                var e = i.getForm().getValues().level || "basic",
                    t = SYNO.SDS.StorageUtils.RAIDDiskMinMaxCountGet(e),
                    s = i.getFreeDisksBySettings(),
                    a = s.length,
                    n = i.filterDisksBySSD(s).length;
                return "raid_f1" === e && t.min > n || t.min > a ? (i.owner.getButton("next").disable(), _T("volume", "volume_create_pool_without_enough_disk_warning")) : (i.owner.getButton("next").enable(), !0)
            },
            listeners: {
                select: this.onRaidLevelChanged,
                scope: this
            }
        }, {
            xtype: "syno_displayfield",
            itemId: "minDiskNum",
            anchor: "95%",
            fieldLabel: _T("volume", "min_raid_disk_number"),
            value: "0"
        }, {
            xtype: "syno_combobox",
            name: "limitNum",
            itemId: "limitNum",
            hiddenName: "limitNum",
            hiddenValue: 0,
            hidden: !SYNO.SDS.StorageUtils.supportRaidGroup,
            store: new Ext.data.ArrayStore({
                data: [
                    ["6", 6],
                    ["12", 12],
                    ["24", 24]
                ],
                id: "value",
                fields: ["text", "value"]
            }),
            fieldLabel: _T("volume", "limit_raid_disk_number"),
            displayField: "text",
            valueField: "value",
            mode: "local",
            allowBlank: !1,
            listeners: {
                select: this.onLimitedChanged,
                scope: this
            }
        }, {
            xtype: "syno_combobox",
            name: "hddType",
            itemId: "hddType",
            hiddenName: "hddType",
            store: new Ext.data.ArrayStore({
                data: i.tabList,
                id: "value",
                fields: ["text", "value"]
            }),
            fieldLabel: _T("volume", "volume_hdd_type"),
            displayField: "text",
            valueField: "value",
            forceSelection: !0,
            mode: "local",
            allowBlank: !1,
            listeners: {
                select: this.onHddTypeSelect,
                scope: this
            },
            hidden: !SYNO.SDS.StorageUtils.supportSas || "yes" === _D("support_dual_head", "no")
        }, {
            xtype: "syno_displayfield",
            itemId: "raidGroupFeature",
            fieldLabel: _T("volume", "raid_group_feature"),
            value: _T("common", "not_support"),
            hidden: !SYNO.SDS.StorageUtils.supportRaidGroup
        }, {
            xtype: "syno_displayfield",
            itemId: "raidDescription",
            hidden: !0,
            hideLabel: !0,
            htmlEncode: !1,
            anchor: "95%"
        }]), t = {
            headline: _T("volume", "volume_raid_property"),
            labelWidth: 300,
            listeners: {
                afterlayout: function() {
                    this.addTip("limitNum", _T("volume", "limit_raid_disk_number_info"))
                },
                scope: this,
                single: !0
            },
            items: s
        }, i.callParent([Ext.apply(t, e)])
    },
    addTip: function(e, t) {
        var i = this.getComponent(e);
        i && void 0 !== i.getEl() && SYNO.ux.AddTip(i.getEl(), Ext.util.Format.htmlEncode(t))
    },
    onRaidLevelChanged: function(e, t, i) {
        this.updateForm()
    },
    onLimitedChanged: function(e, t, i) {
        this.currentRaidLimit = this.getRaidLimit()
    },
    onHddTypeSelect: function() {
        this.setDefaultLevel(), this.updateForm()
    },
    onDiskSourceSelect: function(e, t, i, s) {
        t && (SYNO.SDS.StorageUtils.isSingleBayWithEbox() && (this.isOneBayBasicVolume = "internal" === t.data.value, this.levelStore.loadData(this.generateLevelStore(), !1)), this.setDefaultLevel(), this.updateForm())
    },
    matchFirstRule: function(e, t, i) {
        return "" !== i ? i : e ? t : i
    },
    setDefaultLevel: function() {
        var e = this.getComponent("level"),
            t = e.getStore(),
            i = this.getData("quick_mode", !1),
            s = this.getData("raid_type", "single"),
            a = "",
            n = this.getFreeDisksBySettings(),
            o = n.length,
            r = this.filterDisksBySSD(n).length;
        switch (SYNO.SDS.StorageUtils.supportDiffRaid && this.isAllFlashModel() ? "FS_model" : SYNO.SDS.StorageUtils.supportRaidGroup ? "raidgroup_model" : this.isOneBayBasicVolume ? "basic" : i ? "quick_mode" : "multiple" === s ? "multiple_mode" : "single_volume") {
            case "FS_model":
                a = this.matchFirstRule(3 <= r, "raid_f1", a), a = this.matchFirstRule(3 <= o, "raid_5", a), a = this.matchFirstRule(2 === o, "raid_1", a), a = this.matchFirstRule(1 === o, "basic", a);
                break;
            case "raidgroup_model":
            case "single_volume":
                a = this.matchFirstRule(3 <= o, "raid_5", a), a = this.matchFirstRule(2 === o, "raid_1", a), a = this.matchFirstRule(1 === o, "basic", a);
                break;
            case "basic":
                a = "basic";
                break;
            case "quick_mode":
                a = this.matchFirstRule(!0, "shr", a);
                break;
            case "multiple_mode":
                _S("ha_running") || (a = this.matchFirstRule(!0, "shr", a)), a = this.matchFirstRule(3 <= o, "raid_5", a), a = this.matchFirstRule(2 === o, "raid_1", a), a = this.matchFirstRule(1 === o, "basic", a)
        }
        "" === a && (a = t.getAt(0).data.value), e.setValue(a), e.setDisabled(this.levelStore.data.items.length < 2)
    },
    updateRAID: function() {
        var e = this,
            t = e.getData("raid_type", "single"),
            i = e.getComponent("level").getValue() || "basic",
            s = SYNO.SDS.StorageUtils.RAIDDiskMinMaxCountGet(i),
            a = s.min;
        SYNO.SDS.StorageUtils.supportRaidGroup && "multiple" === t && s.raidGroup ? (e.getComponent("limitNum").setValue(e.currentRaidLimit), e.getComponent("limitNum").enable(), e.getComponent("raidGroupFeature").setValue(_T("pkgmgr", "support"))) : (e.getComponent("limitNum").setValue(24), e.getComponent("limitNum").disable(), e.getComponent("raidGroupFeature").setValue(_T("common", "not_support"))), e.addTip("raidGroupFeature", _T("volume", "raid_group_feature_info")), "shr" === i && (a += String.format(" ({0})", _T("volume", "shr_one_drive_no_data_protection_info"))), this.getComponent("minDiskNum").setValue(a)
    },
    updateDesc: function() {
        var e = this.getRaidLevel();
        this.setDefaultDesc && this.getComponent("desc").setValue(SYNO.SDS.StorageUtils.RaidLevelRender(e))
    },
    updateRaidDesc: function() {
        var e, t = this.getRaidLevel(),
            i = this.getComponent("raidDescription"),
            s = String.format(_T("volume", "pool_raid_desc"), SYNO.SDS.StorageUtils.RaidLevelRender(t));
        switch (t) {
            case "shr":
            case "shr_2":
                e = _T("volume", "volume_type_description_shr");
                break;
            case "basic":
                e = _T("volume", "volume_type_description_basic");
                break;
            case "raid_linear":
                e = _T("volume", "volume_type_description_linear");
                break;
            case "raid_0":
                e = _T("volume", "volume_type_description_raid_0");
                break;
            case "raid_1":
                e = _T("volume", "volume_type_description_raid_1");
                break;
            case "raid_10":
                e = _T("volume", "volume_type_description_raid_10");
                break;
            case "raid_5":
                e = _T("volume", "volume_type_description_raid_5");
                break;
            case "raid_6":
                e = _T("volume", "volume_type_description_raid_6");
                break;
            case "raid_f1":
                e = _T("volume", "volume_type_description_raid_f1");
                break;
            default:
                return void i.hide()
        }
        i.setValue('<div class="sds-pool-raid-desc"><div><a>' + s + "</a></div><div>" + e + "</div></div>"), i.show(), this.doLayout()
    },
    updateForm: function() {
        this.updateRAID(), this.updateDesc(), this.updateRaidDesc()
    },
    pushWhenMatch: function(e, t, i) {
        e && t.push(i)
    },
    generateLevelStore: function() {
        var e = this.getData("raid_type", "single"),
            t = this.getData("quick_mode", !1),
            i = [],
            s = 0,
            a = {};
        return Ext.each(this.allDisks, function(e) {
            if ("disabled" === e.get("portType") || e.isCacheTray()) return !0;
            var t, i = e.get("container");
            if (Ext.isNumber(a[i.order])) return !0;
            if ("ebox" === i.type) {
                if (SYNO.SDS.StorageUtils.supportSas && this.appWin.AHAInfo) t = this.appWin.AHAInfo.enclosures[i.order - 1].max_disk;
                else if (0 === (t = SYNO.SDS.StorageUtils.GetEboxBayNumber(i.str))) return !0
            } else t = parseInt(_D("maxdisks", "1"), 10);
            a[i.order] = t
        }, this), Ext.iterate(a, function(e, t) {
            SYNO.SDS.StorageUtils.isSupportRaidCross() ? s += t : s = Math.max(s, t)
        }, this), t ? (this.pushWhenMatch(1 <= s, i, ["SHR", "shr"]), this.pushWhenMatch(4 <= s, i, ["SHR-2", "shr_2"]), i) : (SYNO.SDS.StorageUtils.supportRaidGroup || !SYNO.SDS.StorageUtils.isSupportSHR() || "multiple" !== e || _S("ha_running") || (this.pushWhenMatch(1 <= s, i, ["SHR", "shr"]), this.pushWhenMatch(4 <= s, i, ["SHR-2", "shr_2"])), this.pushWhenMatch(2 <= s, i, [_T("volume", "volume_type_raid_1"), "raid_1"]), this.pushWhenMatch(3 <= s, i, [_T("volume", "volume_type_raid_5"), "raid_5"]), this.pushWhenMatch(4 <= s, i, [_T("volume", "volume_type_raid_6"), "raid_6"]), this.pushWhenMatch(4 <= s, i, [_T("volume", "volume_type_raid_10"), "raid_10"]), this.pushWhenMatch(1 <= s, i, [_T("volume", "volume_type_basic"), "basic"]), this.pushWhenMatch(1 <= s, i, [_T("volume", "volume_type_linear"), "raid_linear"]), this.pushWhenMatch(2 <= s, i, [_T("volume", "volume_type_raid_0"), "raid_0"]), SYNO.SDS.StorageUtils.supportDiffRaid && this.pushWhenMatch(3 <= s, i, [_T("volume", "volume_type_raid_f1"), "raid_f1"]), SYNO.SDS.StorageUtils.isSingleBay() && (!this.isNeedSelectSource || this.isNeedSelectSource && "internal" === this.getDiskSource()) && (i = [
            [_T("volume", "volume_type_basic"), "basic"]
        ]), i)
    },
    filterDisksBySource: function(e, t) {
        return e && Ext.isArray(e) ? "internal" === (t = t || this.getDiskSource()) ? e.filter(function(e) {
            return e.isInternal()
        }) : "ebox" === t ? e.filter(function(e) {
            return e.isInEbox()
        }) : e.filter(function() {
            return !0
        }) : []
    },
    filterDisksByHddType: function(e) {
        if (!e || !Ext.isArray(e)) return [];
        var t = this.getHddType();
        return e.filter(function(e) {
            return e.get("diskType") === t
        })
    },
    filterDisksBySSD: function(e) {
        return e && Ext.isArray(e) ? e.filter(function(e) {
            return e.isSSD()
        }) : []
    },
    getAllFreeDisks: function() {
        return this.allFreeDisks || (this.allFreeDisks = this.getMatchedDisk("isNormalTray", "isFree")), this.allFreeDisks
    },
    getFreeDisksBySettings: function() {
        var e = this.getAllFreeDisks();
        return e = this.filterDisksBySource(e), e = this.filterDisksByHddType(e)
    },
    getNext: function() {
        return !!this.getForm().isValid() && this.nextId
    },
    getDiskSource: function() {
        var e = this.getComponent("hddSource");
        return !!e && e.getValue()
    },
    getRaidLevel: function() {
        return this.getComponent("level").getValue()
    },
    getRaidLimit: function() {
        return this.getComponent("limitNum").getValue()
    },
    getDescription: function() {
        return this.getComponent("desc").getValue()
    },
    getHddType: function() {
        return this.getComponent("hddType").getValue()
    },
    getDefaultHddType: function() {
        var e = !1,
            t = !1,
            i = this.getAllFreeDisks();
        return Ext.each(i, function(i) {
            var s = i.get("diskType");
            "SATA" === s ? e = !0 : "SAS" === s && (t = !0)
        }), t ? "SAS" : e ? "SATA" : SYNO.SDS.StorageUtils.supportSas ? "SAS" : "SATA"
    },
    isAllFlashModel: function() {
        return /^fs[0-9]*/i.test(_D("upnpmodelname"))
    },
    activate: function() {
        var e = this,
            t = "storage_pool" === e.getData("create_for"),
            i = e.getData("raid_type", ""),
            s = e.currentRaidType !== i,
            a = this.getAllFreeDisks(),
            n = this.filterDisksBySource(a, "internal"),
            o = this.filterDisksBySource(a, "ebox");
        if (e.currentRaidType = i, e.isNeedSelectSource) {
            var r = e.getComponent("hddSource"),
                d = n.length <= 0 || SYNO.SDS.StorageUtils.isSingleBay() && t,
                l = o.length <= 0;
            r.getStore().loadData([
                [_T("volume", "volume_disk_source_internal"), "internal", d],
                [_T("volume", "volume_disk_source_ebox"), "ebox", l]
            ], !1), d ? l || (r.setValue("ebox"), this.isOneBayBasicVolume = !1) : (r.setValue("internal"), this.isOneBayBasicVolume = SYNO.SDS.StorageUtils.isSingleBay()), s = !0
        }
        e.levelStore.loadData(this.generateLevelStore(), !1), s && (e.getComponent("hddType").setValue(this.getDefaultHddType()), e.setDefaultLevel()), e.updateForm()
    },
    updateData: function(e) {
        e.raid_level = this.getRaidLevel(), e.raid_limit_number = this.getRaidLimit(), e.hdd_type = this.getHddType(), e.pool_description = this.getDescription(), this.isNeedSelectSource && (e.disk_source = this.getDiskSource())
    },
    summary: function(e) {
        var t = this.owner.getRaidLevel(),
            i = this.getRaidLimit();
        e.append(_T("volume", "pool_desc"), this.getDescription()), "shr" !== t.substr(0, 3) ? e.append(_T("volume", "volume_raid_title"), SYNO.SDS.StorageUtils.DeviceTypeRender(t), !0) : e.append(_T("volume", "volume_raid_title"), SYNO.SDS.StorageUtils.SpaceTypeRender(t), !0), SYNO.SDS.StorageUtils.supportSas && e.append(_T("volume", "volume_hdd_type"), this.getHddType()), SYNO.SDS.StorageUtils.supportRaidGroup && "basic" !== t && "raid_1" !== t && e.append(_T("volume", "limit_raid_disk_number"), i)
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.CreatePoolSummaryStep", {
    extend: "SYNO.SDS.StorageManager.Wizard.SummaryStep",
    constructor: function(e) {
        var t = {
            headline: _T("volume", "volume_wizard_summary_title")
        };
        this.callParent([Ext.apply(t, e)])
    },
    activate: function() {
        this.callParent(arguments), this.owner.setStatusBusy(), this.owner.getButton("next").disable();
        var e = {
            estimate_for: "create"
        };
        e.disk_id = this.owner.getDiskIds(), e.device_type = this.owner.getRaidLevel(), e.diskGroups = this.owner.getDiskGroups(), 1 >= e.diskGroups.length && delete e.diskGroups, SYNO.API.Request({
            api: "SYNO.Storage.CGI.Pool",
            method: "estimate_size",
            version: 1,
            params: e,
            callback: function(e, t, i, s) {
                if (this.owner.clearStatusBusy(), !e) return SYNO.SDS.StorageUtils.ReportWebapiFailure(this, t), void this.owner.getButton("next").disable();
                _S("demo_mode") || this.owner.getButton("next").enable(), this.getStore().append(_T("volume", "volume_totalsize"), _T("volume", "volume_add_warningabout") + " " + SYNO.SDS.StorageUtils.SizeRender(t.size)), this.doLayout()
            },
            scope: this
        })
    },
    getNext: function() {
        return this.owner.applySettings(), !1
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.EditPool", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t, i = this;
        i.isDataChanged = !1, i.appWin = e.appWin, i.owner = e.owner, i.pool = e.pool, i.allSsdcaches = e.allSsdcaches, i.isVirtualPool = e.isVirtualPool, this.forceClose = !1;
        var s = {
                xtype: "syno_fieldset",
                collapsible: !1,
                title: _T("common", "general"),
                itemId: "general",
                name: "general",
                hidden: i.isVirtualPool,
                items: [{
                    xtype: "syno_textfield",
                    validateOnBlur: !0,
                    validationEvent: "blur",
                    name: "desc",
                    itemId: "desc",
                    fieldLabel: _T("share", "share_comment"),
                    disabled: !0,
                    width: 250,
                    maxLength: 64
                }]
            },
            a = {
                xtype: "syno_fieldset",
                collapsible: !1,
                ref: "../stripeCacheFieldset",
                title: _T("volume", "stripe_cache_size"),
                itemId: "fieldset_stripe_cache_size",
                name: "fieldset_stripe_cache_size",
                hidden: !0,
                items: [{
                    xtype: "syno_displayfield",
                    value: _T("storage_pool", "pool_setting_stripe_cache_size_desc")
                }, {
                    xtype: "syno_displayfield",
                    itemId: "not_support_displayfield",
                    value: _T("volume", "stripe_cache_size_not_support"),
                    hidden: !0
                }, {
                    xtype: "syno_radio",
                    itemId: "default_radio",
                    name: "stripe_cache_size",
                    ref: "../../radio_default",
                    boxLabel: _T("volume", "stripe_cache_size_default"),
                    inputValue: "default",
                    indent: 1
                }, {
                    xtype: "syno_radio",
                    itemId: "small_radio",
                    name: "stripe_cache_size",
                    ref: "../../radio_small",
                    boxLabel: _T("volume", "stripe_cache_size_small"),
                    inputValue: "small",
                    indent: 1
                }, {
                    xtype: "syno_displayfield",
                    htmlEncode: !1,
                    value: String.format('<span class="syno-ux-note">{0}{1} </span>{2}', _T("common", "note"), _T("common", "colon"), _T("volume", "stripe_cache_size_notice"))
                }]
            },
            n = {
                xtype: "syno_fieldset",
                collapsible: !1,
                title: _T("volume", "ssd_trim_title"),
                ref: "../ssdTrimFieldset",
                hidden: !0,
                items: [{
                    xtype: "syno_displayfield",
                    value: _T("storage_pool", "pool_setting_ssd_trim_desc")
                }, {
                    xtype: "syno_checkbox",
                    boxLabel: _T("volume", "ssd_trim_en"),
                    handler: i.onEnableSSDTrim,
                    name: "ssd_trim_enable",
                    hideLabel: !0,
                    scope: i
                }, {
                    xtype: "syno_displayfield",
                    fieldLabel: _T("schedule", "next_trigger_time"),
                    value: i.nextTriggerTime,
                    ref: "../../triggerTimeDisplayField"
                }, {
                    xtype: "syno_button",
                    ref: "../../setScheduleBtn",
                    text: _T("wireless_ap", "ap_set_schedule"),
                    handler: i.onSetSchedule,
                    disabled: !0,
                    scope: i
                }]
            };
        t = {
            title: _T("common", "common_settings"),
            items: [new SYNO.ux.FormPanel({
                itemId: "settingPanel",
                border: !1,
                trackResetOnLoad: !0,
                labelWidth: 130,
                items: [s, a, n]
            })],
            width: 700,
            height: 480,
            resizable: !1,
            layout: "fit",
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "alt_cancel"),
                scope: i,
                handler: i.onCancel
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                text: _T("common", "save"),
                scope: i,
                handler: i.onSave
            }],
            listeners: {
                beforeclose: this.onBeforeClose.bind(this)
            }
        }, i.callParent([Ext.apply(t, e)]), i.fieldDesc = i.getComponent("settingPanel").getComponent("general").getComponent("desc")
    },
    onEnableSSDTrim: function(e, t) {
        t ? (this.setScheduleBtn.enable(), this.setNextTriggerTime(this.nextTriggerTime)) : (this.setScheduleBtn.disable(), this.setNextTriggerTime("-"), this.ssdTrim.schedule.next_trigger_time = null)
    },
    setNextTriggerTime: function(e) {
        var t;
        t = "-" === e || "N/A" === e ? e : SYNO.SDS.DateTimeFormatter(Date.parseDate(e, "Y-n-j h:i")), this.triggerTimeDisplayField.setValue(t), this.triggerTimeDisplayField.initValue()
    },
    updateNextTriggerTime: function(e) {
        var t = this,
            i = {},
            s = this.ssdTrim.schedule,
            a = this.schedule;
        "-" === this.nextTriggerTime || this.isScheduleEdited ? (i.schedule = this.isScheduleEdited ? this.scheduleToOld(a) : s, t.setStatusBusy(), SYNO.API.Request({
            api: "SYNO.Storage.CGI.Volume",
            method: "next_trim_time_get",
            version: 1,
            params: i,
            callback: function(i, s, a, n) {
                t.clearStatusBusy(), i ? (this.nextTriggerTime = s.next_trigger_time, e && t.setNextTriggerTime(this.nextTriggerTime)) : SYNO.SDS.StorageUtils.ReportWebapiFailure(this, s)
            },
            scope: this
        })) : e && t.setNextTriggerTime(this.nextTriggerTime)
    },
    onSetSchedule: function() {
        var e = this,
            t = e;
        if (this.supportSSDTrim) {
            var i = new SYNO.SDS.TaskScheduler2.ScheduleDialog({
                title: _T("schedule", "schedule_advance"),
                height: 500,
                listeners: {
                    close: {
                        scope: e,
                        fn: function() {
                            e.schedule = t.schedule, e.isScheduleEdited = !!e.schedule, e.updateNextTriggerTime(!0)
                        }
                    }
                },
                owner: t
            });
            e.schedule = t.schedule;
            var s = this.ssdTrim.schedule,
                a = this.schedule,
                n = this.isScheduleEdited ? a : s;
            i.open(this.scheduleToNew(n))
        }
    },
    getFirstVolume: function() {
        return this.pool.volumes.find(function(e) {
            return !e.isUnstableSpace()
        })
    },
    isSupportSSDTrim: function(e) {
        if ("yes" !== _D("support_trim", "no")) return !1;
        if ("not support" === e) return !1;
        if (SYNO.SDS.StorageUtils.supportSsdCache && this.pool.volumes.every(function(e) {
                return !!e.ssdcache
            }.bind(this))) return !1;
        return "disabled by time backup" !== e && "partial support" !== e
    },
    scheduleToNew: function(e) {
        if (e.hasOwnProperty("week_name") && (e.week_day = e.week_name, delete e.week_name), e.hasOwnProperty("repeat") && (e.repeat_data = e.repeat, e.repeat_date = e.repeat, delete e.repeat), e.hasOwnProperty("min") && (e.minute = e.min, delete e.min), !e.hasOwnProperty("date")) {
            var t = new Date;
            e.date = t.getYear() + 1900 + "/" + (t.getMonth() + 1) + "/" + t.getDate(), e.repeat_date = 0
        }
        return e
    },
    scheduleToOld: function(e) {
        return e.hasOwnProperty("week_day") && (e.week_name = e.week_day, delete e.week_day), e.hasOwnProperty("repeat_data") && (e.repeat = e.repeat_data, delete e.repeat_data), e.hasOwnProperty("minute") && (e.min = e.minute, delete e.minute), e.hasOwnProperty("repeat_date") && (e.repeat = e.repeat_date, delete e.repeat_date), e
    },
    updateValues: function(e) {
        e.desc = this.pool.desc, this.fieldDesc.setDisabled(!1), this.getComponent("settingPanel").getForm().setValues(e), this.stripeCacheFieldset.setVisible(this.supportStripeCacheSize), this.ssdTrimFieldset.setVisible(this.supportSSDTrim), this.supportSSDTrim && (this.setNextTriggerTime(this.nextTriggerTime), "-" === this.nextTriggerTime && this.updateNextTriggerTime(!1)), this.getComponent("settingPanel").updateFleXcroll()
    },
    onOpen: function() {
        var e = this,
            t = [];
        e.isVirtualPool || (t = t.concat({
            api: "SYNO.Storage.CGI.Pool",
            method: "get_setting",
            version: 1,
            params: {
                pool_path: this.pool.get("space_path")
            }
        }));
        var i = e.getFirstVolume();
        i && (t = t.concat({
            api: "SYNO.Storage.CGI.Volume",
            method: "ssd_trim_get",
            version: 1,
            params: {
                space_path: i.vol_path
            }
        })), e.callParent(arguments), e.setStatusBusy({
            text: _T("common", "loading")
        }), synowebapi.promises.request({
            api: "SYNO.Entry.Request",
            version: 1,
            method: "request",
            compound: {
                params: t
            }
        }).then(function(t) {
            if (t.has_fail) throw new Error("unknown");
            var i = {},
                s = e.isVirtualPool ? 0 : 1;
            t.result.map(function(e) {
                if (!e.success) throw new Error(e)
            });
            var a = e.isVirtualPool ? {
                    stripe_cache_size: "not_support"
                } : t.result[0].data,
                n = {
                    ssd_trim: {
                        support: "not support"
                    }
                };
            (1 < t.result.length || e.isVirtualPool) && (n = t.result[s].data), Ext.apply(i, a), e.ssdTrim = n.ssd_trim, e.supportStripeCacheSize = "not_support" !== a.stripe_cache_size, e.supportSSDTrim = e.isSupportSSDTrim(n.ssd_trim.support), e.supportSSDTrim && (i.ssd_trim_enable = 1 === n.ssd_trim.enable, e.nextTriggerTime = n.ssd_trim.schedule.next_trigger_time || "-"), e.clearStatusBusy(), e.updateValues(i)
        }).catch(function(t) {
            e.clearStatusBusy(), SYNO.SDS.StorageUtils.ReportWebapiFailure(e.findWindow(), t)
        })
    },
    isDirty: function() {
        return this.getComponent("settingPanel").getForm().isDirty() || this.isScheduleEdited
    },
    onSave: function() {
        if (this.getComponent("settingPanel").getForm().isValid())
            if (this.isDirty()) {
                var e = [],
                    t = {},
                    i = this.getComponent("settingPanel").getForm().getValues();
                !this.isVirtualPool && this.getComponent("settingPanel").getForm().isDirty() && (t = {
                    pool_path: this.pool.space_path,
                    desc: i.desc
                }, this.supportStripeCacheSize && (this.radio_default.isDirty() || this.radio_small.isDirty()) && (t.stripe_cache_size = i.stripe_cache_size), e.push({
                    api: "SYNO.Storage.CGI.Pool",
                    method: "set_setting",
                    version: 1,
                    params: t
                })), this.supportSSDTrim && e.push({
                    api: "SYNO.Storage.CGI.Volume",
                    method: "ssd_trim_save",
                    version: 1,
                    params: {
                        enable: "true" === i.ssd_trim_enable ? 1 : 0,
                        space_path: this.pool.space_path,
                        uuid: this.pool.uuid,
                        num_id: this.pool.num_id,
                        is_pool_child: !this.isVirtualPool,
                        schedule: this.scheduleToOld(this.isScheduleEdited ? this.schedule : this.ssdTrim.schedule)
                    }
                }), this.setStatusBusy({
                    text: _T("common", "saving")
                }), synowebapi.promises.request({
                    api: "SYNO.Entry.Request",
                    version: 1,
                    method: "request",
                    compound: {
                        params: e
                    }
                }).then(function(e) {
                    this.clearStatusBusy(), this.isDataChanged = !0, this.forceClose = !0, this.close()
                }.bind(this)).catch(function(e) {
                    this.clearStatusBusy(), SYNO.SDS.StorageUtils.ReportWebapiFailure(this.findWindow(), e)
                }.bind(this))
            } else this.setStatusError({
                text: _T("error", "nochange_subject"),
                clear: !0
            })
    },
    onCancel: function() {
        this.close()
    },
    onBeforeClose: function() {
        return !(this.isDirty() && !this.forceClose) || (this.confirmLostChangePromise({
            save: function() {
                this.onSave()
            },
            dontSave: function() {
                this.forceClose = !0, this.close()
            },
            cancel: function() {}
        }, this), !1)
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.ManagePool", {
    extend: "SYNO.SDS.StorageManager.Wizard.ModalWindow",
    constructor: function(e) {
        var t, i = this,
            s = 0;
        i.appWin = e.appWin, i.owner = e.owner, i.pool = e.pool || null, i.allDisks = e.allDisks, i.disks = e.disks || [], i.manageType = e.manageType || {}, i.migrateType = e.migrateType || {}, i.add_type = e.add_type, i.title = e.title, i.diskCondition = e.diskCondition || {}, i.funcs = e.funcs || {}, i.raidLimitNum = i.pool.get("limited_disk_number"), i.isDataChanged = !1, e.repair && (s = e.repair), t = Ext.apply({
            title: _T("volume", "volume_raid_management_title"),
            mode: "pool_manage",
            width: 820,
            height: 560,
            minHeight: 475,
            minWidth: 700,
            resizable: !0,
            border: !1,
            steps: []
        }, e), "migrate" === i.add_type ? i.activeStep = "migrate" : "expand_unfinished_shr" === i.add_type ? i.activeStep = "shr_operation" : "expand_with_unalloc_size" === i.add_type ? i.activeStep = "summary" : "data_scrubbing" === i.add_type ? i.activeStep = "summary" : i.activeStep = "advDisk", "migrate" === i.add_type && t.steps.push(new SYNO.SDS.StorageManager.Wizard.MigrateTypeStep({
            appWin: i.appWin,
            migrateType: i.migrateType,
            migrateConstrain: i.pool.get("can_do").migrate,
            itemId: "migrate",
            nextId: "advDisk"
        })), "expand_unfinished_shr" === i.add_type && t.steps.push(new SYNO.SDS.StorageManager.Wizard.SHROperationStep({
            appWin: i.appWin,
            spaceType: i.spaceType,
            itemId: "shr_operation",
            nextId: {
                disk: "advDisk",
                summary: "summary"
            }
        })), -1 === ["expand_with_unalloc_size", "data_scrubbing"].indexOf(i.add_type) && t.steps.push(new SYNO.SDS.StorageManager.Wizard.DiskStep({
            appWin: i.appWin,
            isSHR: i.getPoolObject().isSHR(),
            allDisks: i.allDisks,
            advDisks: i.disks,
            diskCondition: i.diskCondition,
            funcs: i.funcs,
            raidLimitNum: i.raidLimitNum,
            repair: s,
            diskMap: e.diskMap,
            getMatchedDisk: e.getMatchedDisk,
            itemId: "advDisk",
            nextId: "summary",
            hasAbnormalDisk: e.hasAbnormalDisk,
            getDiskAlertMsg: e.getDiskAlertMsg,
            openWarningBox: e.openWarningBox,
            space: i.pool,
            add_type: i.add_type
        })), t.steps.push(new SYNO.SDS.StorageManager.Wizard.ManageSummaryStep({
            appWin: i.appWin,
            itemId: "summary",
            nextId: null,
            volumeMap: e.volumeMap
        })), i.callParent([t])
    },
    activate: function() {
        this.callParent(arguments)
    },
    onOpen: function() {
        var e = this;
        this.setData("pool", e.pool), this.setData("space", e.pool), this.setData("manage_action", e.add_type), this.setData("raid_type", e.pool.get("raidType")), this.setData("raid_level", e.pool.get("device_type")), this.setData("raid_limit_number", e.pool.get("limited_disk_number")), e.setActiveStep(e.activeStep), e.callParent(arguments)
    },
    getPoolObject: function() {
        return this.pool
    },
    getManageType: function() {
        return this.add_type
    },
    getMigrateType: function() {
        return this.getData("migrate_type")
    },
    getHddType: function() {
        return this.diskMap[this.pool.get("disks")[0]].get("diskType")
    },
    getRaidType: function() {
        return this.pool.get("raidType")
    },
    getRaidLevel: function() {
        var e = this.getData("migrate_type");
        if (!e) return this.pool.getDeviceType();
        switch (e) {
            case "add_mirror":
            case "to_raid1":
                return "raid_1";
            case "to_raid5":
                return "raid_5";
            case "to_raid6":
                return "raid_6";
            default:
                return ""
        }
    },
    getRaidLimitNum: function() {
        return this.getData("raid_limit_number") || this.pool.get("limited_disk_number")
    },
    getDiskIds: function() {
        return this.getData("disk_ids", [])
    },
    getDiskGroups: function() {
        return this.getData("disk_groups", [])
    },
    getActionType: function() {
        var e = this.getManageType();
        return "migrate" === e ? "migrate_" + this.getMigrateType() : e
    },
    getSHROperation: function() {
        return this.getData("shr_operation")
    },
    getDoFastRepair: function() {
        return this.getData("doFastRepair", [])
    },
    setDoFastRepair: function(e) {
        this.setData("doFastRepair", e)
    },
    applySettings: function(e) {
        this.pool.isSingleLun() ? this.applySettingsLun(e) : this.pool.isSingleVolume() ? this.applySettingsVolume(e) : this.applySettingsPool(e)
    },
    applySettingsPool: function(e) {
        var t = "";
        switch (e) {
            case "stop_in_minutes":
                t = String.format(_T("volume", "volume_change_service_stop_in_minutes"), _T("common", "ask_cont"))
        }
        if ("" !== t) return "yes" === _D("support_share_encryption", "no") && (t = String.format("1. {0}<p>2. {1}", _T("volume", "volume_share_encryption_unmount_warning"), t)), void this.getMsgBox().confirm(this.title, t, function(e) {
            "yes" === e && this.sendRequestPool()
        }, this);
        this.sendRequestPool()
    },
    sendRequestPool: function(e) {
        var t, i = {},
            s = this.getDiskIds(),
            a = this.getDiskGroups(),
            n = this.getManageType(),
            o = this.getActionType(),
            r = this.getSHROperation(),
            d = {};
        switch (i.space_id = this.pool.id, i.force = e || !1, n) {
            case "repair":
                t = "repair", i.disk_id = s, i.diskGroups = a, i.do_fast_repair = this.getDoFastRepair();
                break;
            case "data_scrubbing":
                t = "data_scrubbing", i.diskGroups = a;
                break;
            case "expand_by_disk":
                t = "expand_by_add_disk", i.disk_id = s, i.diskGroups = a;
                break;
            case "expand_with_unalloc_size":
                t = "expand_unallocated";
                break;
            case "migrate":
                t = "migrate", i.migrate_type = o, i.disk_id = s, "raid_5" === this.getRaidLevel() && (i.limit_num = this.getRaidLimitNum());
                break;
            case "expand_unfinished_shr":
                t = "expand_unfinished_shr", i.shr_action = r, i.disk_id = s;
                break;
            case "convert_shr_to_pool":
                t = "convert_shr_to_pool", i.disk_id = s;
                break;
            default:
                return void SYNO.Debug("unknown add type")
        }
        this.getButton("next").disable(), this.setStatusBusy({
            text: _T("common", "saving")
        }), SYNO.API.Request({
            api: "SYNO.Storage.CGI.Pool",
            method: t,
            version: 1,
            params: i,
            callback: function(e, t, i, s) {
                this.clearStatusBusy(), e ? (this.getButton("next").enable(), this.getButton("next").setText(_T("common", "alt_finish")), this.isDataChanged = !0, this.fireEvent("apply-success"), this.close()) : SYNO.SDS.StorageUtils.IsFeasibilityFail(t, d) ? SYNO.SDS.StorageUtils.ConfirmFeasibilityFail(this, d, this.sendRequestPool, !0) : (SYNO.SDS.StorageUtils.HARemoteCheckErrParsing(t), SYNO.SDS.StorageUtils.ReportWebapiFailure(this, t))
            },
            scope: this
        })
    },
    applySettingsVolume: function(e) {
        var t = "";
        switch (e) {
            case "stop_in_minutes":
                t = String.format(_T("volume", "volume_change_service_stop_in_minutes"), _T("common", "ask_cont"))
        }
        if ("" !== t) return "yes" === _D("support_share_encryption", "no") && (t = String.format("1. {0}<p>2. {1}", _T("volume", "volume_share_encryption_unmount_warning"), t)), void this.getMsgBox().confirm(this.title, t, function(e) {
            "yes" === e && this.sendRequestVolume()
        }, this);
        this.sendRequestVolume()
    },
    sendRequestVolume: function(e) {
        var t, i = {},
            s = this.getDiskIds(),
            a = this.getDiskGroups(),
            n = this.getManageType(),
            o = this.getActionType(),
            r = this.getSHROperation(),
            d = {};
        switch (i.pool_path = this.pool.id, i.space_id = this.pool.get("deploy_path"), i.force = e || !1, n) {
            case "repair":
                t = "repair", i.disk_id = s, i.diskGroups = a, i.do_fast_repair = this.getDoFastRepair();
                break;
            case "data_scrubbing":
                t = "data_scrubbing", i.diskGroups = a;
                break;
            case "expand_by_disk":
                t = "expand_by_add_disk", i.disk_id = s, i.diskGroups = a;
                break;
            case "expand_with_unalloc_size":
                t = "expand_unallocated";
                break;
            case "migrate":
                t = "migrate", i.migrate_type = o, i.disk_id = s, i.diskGroups = a, "raid_5" === this.getRaidLevel() && (i.limit_num = this.getRaidLimitNum());
                break;
            case "expand_unfinished_shr":
                t = "expand_unfinished_shr", i.shr_action = r, i.disk_id = s;
                break;
            case "convert_shr_to_pool":
                t = "convert_shr_to_pool", i.disk_id = s;
                break;
            default:
                return void SYNO.Debug("unknown add type")
        }
        this.getStep("summary") && this.getStep("summary").convertSHRToPool && (i.convert_shr_to_pool = !0), this.getButton("next").disable(), this.setStatusBusy({
            text: _T("common", "saving")
        }), SYNO.API.Request({
            api: "SYNO.Storage.CGI.Volume",
            method: t,
            version: 1,
            params: i,
            callback: function(e, t, i, s) {
                this.clearStatusBusy(), e ? (this.getButton("next").enable(), this.getButton("next").setText(_T("common", "alt_finish")), this.isDataChanged = !0, this.fireEvent("apply-success"), this.close()) : SYNO.SDS.StorageUtils.IsFeasibilityFail(t, d) ? SYNO.SDS.StorageUtils.ConfirmFeasibilityFail(this, d, this.sendRequestVolume, !0) : (SYNO.SDS.StorageUtils.HARemoteCheckErrParsing(t), SYNO.SDS.StorageUtils.ReportWebapiFailure(this, t))
            },
            scope: this
        })
    },
    applySettingsLun: function(e) {
        var t = "";
        switch (e) {
            case "stop_in_minutes":
                t = String.format(_T("volume", "volume_change_service_stop_in_minutes"), _T("common", "ask_cont"))
        }
        "" === t ? this.sendRequestLun() : this.getMsgBox().confirm(this.title, t, function(e) {
            "yes" === e && this.sendRequestLun()
        }, this)
    },
    sendRequestLun: function(e) {
        var t = {},
            i = this.getDiskIds(),
            s = this.getDiskGroups(),
            a = this.getManageType(),
            n = this.getActionType();
        switch (t.pool_path = this.pool.id, t.space_id = this.pool.get("deploy_path"), t.force = e || !1, a) {
            case "repair":
                t.method = "repair", t.disk_id = i, t.diskGroups = s;
                break;
            case "data_scrubbing":
                t.method = "data_scrubbing", t.diskGroups = s;
                break;
            case "expand_by_disk":
                t.method = "expand_by_add_disk", t.disk_id = i, t.diskGroups = s;
                break;
            case "expand_with_unalloc_size":
                t.method = "expand_unallocated";
                break;
            case "migrate":
                t.method = "migrate", t.migrate_type = n, t.disk_id = i, t.diskGroups = s, "raid_5" === this.getRaidLevel() && (t.limit_num = this.getRaidLimitNum());
                break;
            default:
                return void SYNO.Debug("unknown add type")
        }
        this.getButton("next").disable(), this.setStatusBusy({
            text: _T("common", "saving")
        }), this.sendWebAPI({
            api: "SYNO.Core.Storage.iSCSILUN",
            method: t.method,
            version: 1,
            params: t,
            callback: function(e, t) {
                var i = {};
                this.clearStatusBusy(), e ? (this.getButton("next").enable(), this.getButton("next").setText(_T("common", "alt_finish")), t.str ? this.getMsgBox().alert("", t.str, this.close, this) : (this.isDataChanged = !0, this.close())) : SYNO.SDS.StorageUtils.IsFeasibilityFail(t, i) ? SYNO.SDS.StorageUtils.ConfirmFeasibilityFail(this, i, this.sendRequestLun, !0) : (SYNO.SDS.StorageUtils.HARemoteCheckErrParsing(t), SYNO.SDS.StorageUtils.ReportWebapiFailure(this, t))
            },
            scope: this
        })
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.MigrateTypeStep", {
    extend: "SYNO.SDS.StorageManager.Wizard.Step",
    constructor: function(e) {
        var t, i = this;
        i.migrateType = void 0, i.migrateConstrain = void 0, i.loaded = !1, i.appWin = e.appWin, t = {
            headline: _T("volume", "volume_migrate_type_title"),
            items: [{
                xtype: "syno_radio",
                boxLabel: _T("volume", "volume_migrate_add_mirror"),
                name: "migrateType",
                itemId: "add_mirror",
                inputValue: "add_mirror",
                listeners: {
                    check: this.onMigrateTypeChanged,
                    scope: this
                }
            }, {
                xtype: "syno_radio",
                boxLabel: _T("volume", "volume_migrate_to_raid1"),
                name: "migrateType",
                itemId: "to_raid1",
                inputValue: "to_raid1",
                listeners: {
                    check: this.onMigrateTypeChanged,
                    scope: this
                }
            }, {
                xtype: "syno_radio",
                boxLabel: _T("volume", "volume_migrate_to_raid5"),
                name: "migrateType",
                itemId: "to_raid5",
                inputValue: "to_raid5",
                listeners: {
                    check: this.onMigrateTypeChanged,
                    scope: this
                }
            }, {
                xtype: "syno_radio",
                boxLabel: _T("volume", "volume_migrate_to_raid5_spare"),
                name: "migrateType",
                itemId: "to_raid5+spare",
                inputValue: "to_raid5+spare",
                listeners: {
                    check: this.onMigrateTypeChanged,
                    scope: this
                }
            }, {
                xtype: "syno_radio",
                boxLabel: _T("volume", "volume_migrate_to_raid6"),
                name: "migrateType",
                itemId: "to_raid6",
                inputValue: "to_raid6",
                listeners: {
                    check: this.onMigrateTypeChanged,
                    scope: this
                }
            }, {
                xtype: "syno_radio",
                boxLabel: _T("volume", "volume_migrate_to_shr2"),
                name: "migrateType",
                itemId: "to_shr2",
                inputValue: "to_shr2",
                listeners: {
                    check: this.onMigrateTypeChanged,
                    scope: this
                }
            }, {
                xtype: "syno_combobox",
                fieldLabel: _T("volume", "limit_raid_disk_number"),
                name: "limitNum",
                itemId: "limitNum",
                hidden: !0,
                hiddenName: "limitNum",
                hiddenValue: 0,
                store: new Ext.data.ArrayStore({
                    data: [
                        ["6", 6],
                        ["12", 12],
                        ["24", 24]
                    ],
                    id: "value",
                    fields: ["text", "value"]
                }),
                displayField: "text",
                valueField: "value",
                mode: "local",
                allowBlank: !1
            }]
        }, i.callParent([Ext.apply(t, e)])
    },
    onMigrateTypeChanged: function(e, t) {
        var i = this.owner.getPoolObject(),
            s = this.getComponent("limitNum");
        "to_raid5" === e.itemId && (!0 === t && SYNO.SDS.StorageUtils.supportRaidGroup ? s.show() : s.hide(), i.supportMultiple() ? s.enable() : (s.disable(), s.setValue(24)))
    },
    getType: function() {
        return this.getForm().getValues().migrateType
    },
    activate: function() {
        var e, t = this.owner.getPoolObject(),
            i = "";
        this.loaded || (Ext.each(this.find("name", "migrateType"), function(e) {
            e.hide()
        }), t.isSHR() ? e = ["to_shr2"] : (e = ["to_raid5", "to_raid6"], SYNO.SDS.StorageUtils.supportHotSpare || e.splice(1, 0, "to_raid5+spare"), "add_mirror" in this.migrateType && this.migrateType.add_mirror ? e.unshift("add_mirror") : e.unshift("to_raid1")), Ext.each(e, function(e) {
            var t = this.getComponent(e);
            e in this.migrateType && this.migrateType[e] ? (t.enable(), i = e) : t.disable(), t.show()
        }, this), this.getComponent("limitNum").setValue(24), this.getComponent(i).setValue(!0), this.loaded = !0)
    },
    updateData: function(e) {
        var t = this.getType(),
            i = !1;
        ("to_raid5" === t && 0 === this.migrateConstrain.to_raid5 || "to_raid6" === t && 0 === this.migrateConstrain.to_raid6) && (i = !0), e.allow_disk_blank = i, "to_raid5" === t && (e.raid_limit_number = this.getComponent("limitNum").getValue()), e.migrate_type = this.getType()
    },
    summary: function(e) {
        "to_raid5" === this.getType() && SYNO.SDS.StorageUtils.supportRaidGroup && e.append(_T("volume", "limit_raid_disk_number"), this.getComponent("limitNum").getValue())
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.RemoveDetected", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.owner = e.owner, i.parent = e.parent, i.pool = e.pool, t = {
            title: _T("storage_pool", "pool_remove_detected_title"),
            width: 640,
            height: 350,
            resizable: !1,
            layout: "fit",
            items: [{
                itemId: "main",
                border: !1,
                style: {
                    padding: "16px 20px 0px 20px"
                },
                items: [{
                    xtype: "syno_displayfield",
                    value: _T("storage_pool", "pool_delete_summary_desc"),
                    itemId: "desc"
                }, i.gridPanel = i.gridPanelConfig()]
            }],
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "alt_cancel"),
                scope: i,
                handler: i.onCancel
            }, {
                xtype: "syno_button",
                btnStyle: "red",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                text: _T("common", "remove"),
                id: i.applyButtonID = Ext.id(),
                scope: i,
                handler: i.onSave
            }]
        }, i.callParent([Ext.apply(t, e)])
    },
    gridPanelConfig: function(e) {
        var t = Ext.apply({
            border: !1,
            xtype: "syno_gridpanel",
            height: 220,
            style: {
                marginTop: "8px"
            },
            columns: [{
                header: _T("status", "header_item"),
                dataIndex: "item",
                sortable: !1
            }, {
                header: _T("status", "header_value"),
                dataIndex: "value",
                sortable: !1,
                renderer: function(e, t, i) {
                    return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(e) + '"', String.format('<font class="sm-font-normal">{0}</font>', e)
                }
            }],
            enableHdMenu: !1,
            sm: new Ext.grid.RowSelectionModel,
            store: new Ext.data.JsonStore({
                autoDestroy: !0,
                idProperty: "item",
                fields: ["item", "value"]
            })
        }, e);
        return new SYNO.ux.GridPanel(t)
    },
    onOpen: function() {
        this.callParent(arguments), this.loadData()
    },
    loadData: function() {
        var e = this,
            t = SYNO.SDS.StorageUtils,
            i = [],
            s = [],
            a = [],
            n = e.diskMap;
        i.push({
            item: _T("storage_pool", "pool_previous_location"),
            value: e.pool.get("hostname")
        }), Ext.isEmpty(e.pool.get("desc")) || i.push({
            item: _T("volume", "pool_desc"),
            value: Ext.util.Format.htmlEncode(e.pool.get("desc"))
        }), i.push({
            item: _T("volume", "volume_raid_type"),
            value: t.SpaceTypeRender(e.pool.get("device_type"), !1)
        }), Ext.each(e.pool.get("disks"), function(e) {
            var i = n[e];
            s.push(t.DiskDisplayNameGet(i))
        }), i.push({
            item: _T("volume", "volume_disk"),
            value: s.join(", ")
        }), Ext.each(e.pool.SSDCacheDisks, function(e) {
            a.push(e.name)
        }), 0 < a.length && i.push({
            item: _T("storage_pool", "pool_cache_drives"),
            value: a.join(", ")
        }), e.gridPanel.getStore().loadData(i)
    },
    onSave: function() {
        var e, t, i = this;
        e = {
            pool_id: i.pool.get("num_id")
        }, t = String.format('<span class="red-status">{0}</span><br/>', _T("storage_pool", "pool_remove_detected_warn")), i.getMsgBox().confirmDelete("", t, function(t) {
            "yes" === t && SYNO.SDS.Utils.PasswordConfirmDialog.openDialog(i, i.applySettings, ["SYNO.Storage.CGI.DetectedPool", "remove", e])
        }, i)
    },
    onCancel: function() {
        this.close()
    },
    applySettings: function(e, t, i) {
        var s = this;
        s.setStatusBusy({
            text: _T("common", "saving")
        }), s.sendWebAPI({
            api: e,
            method: t,
            version: 1,
            params: i,
            callback: function(e, t, i, a) {
                var n = function() {
                    s.clearStatusBusy(), s.close()
                }.createDelegate(s);
                setTimeout(n, 6e3)
            },
            scope: s
        })
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.RemoveMissing", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.owner = e.owner, i.parent = e.parent, i.pool = e.pool, t = {
            title: _T("storage_pool", "pool_remove_missing_title"),
            width: 640,
            height: 350,
            resizable: !1,
            layout: "fit",
            items: [{
                itemId: "main",
                border: !1,
                style: {
                    padding: "16px 20px 0px 20px"
                },
                items: [{
                    xtype: "syno_displayfield",
                    value: _T("storage_pool", "pool_delete_summary_desc"),
                    itemId: "desc"
                }, i.gridPanel = i.gridPanelConfig()]
            }],
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "alt_cancel"),
                scope: i,
                handler: i.onCancel
            }, {
                xtype: "syno_button",
                btnStyle: "red",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                text: _T("common", "remove"),
                id: i.applyButtonID = Ext.id(),
                scope: i,
                handler: i.onSave
            }]
        }, i.callParent([Ext.apply(t, e)])
    },
    gridPanelConfig: function(e) {
        var t = Ext.apply({
            border: !1,
            xtype: "syno_gridpanel",
            height: 220,
            style: {
                marginTop: "8px"
            },
            columns: [{
                header: _T("status", "header_item"),
                dataIndex: "item",
                sortable: !1
            }, {
                header: _T("status", "header_value"),
                dataIndex: "value",
                sortable: !1,
                renderer: function(e, t, i) {
                    return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(e) + '"', String.format('<font class="sm-font-normal">{0}</font>', e)
                }
            }],
            enableHdMenu: !1,
            sm: new Ext.grid.RowSelectionModel,
            store: new Ext.data.JsonStore({
                autoDestroy: !0,
                idProperty: "item",
                fields: ["item", "value"]
            })
        }, e);
        return new SYNO.ux.GridPanel(t)
    },
    onOpen: function() {
        this.callParent(arguments), this.loadData()
    },
    loadData: function() {
        var e = this,
            t = SYNO.SDS.StorageUtils,
            i = [],
            s = [],
            a = [],
            n = e.diskMap;
        Ext.isEmpty(e.pool.get("desc")) || i.push({
            item: _T("volume", "pool_desc"),
            value: Ext.util.Format.htmlEncode(e.pool.get("desc"))
        }), i.push({
            item: _T("volume", "volume_raid_title"),
            value: t.SpaceTypeRender(e.pool.get("device_type"), !1)
        }), Ext.each(e.pool.get("disks"), function(e) {
            var i = n[e];
            s.push(t.DiskDisplayNameGet(i))
        }), 0 < s.length && i.push({
            item: _T("volume", "volume_disk"),
            value: s.join(", ")
        }), Ext.each(e.pool.SSDCacheDisks, function(e) {
            a.push(e.name)
        }), 0 < a.length && i.push({
            item: _T("volume", "volume_cache_disk"),
            value: a.join(", ")
        }), e.gridPanel.getStore().loadData(i)
    },
    onSave: function() {
        var e, t, i = this;
        e = {
            space_uuid: i.pool.get("uuid")
        }, t = _T("storage_pool", 1 === i.pool.disks.length ? "warning_remove_missing_pool" : "warning_remove_missing_pool_mulit_insert_drives"), i.getMsgBox().confirmDelete("", t, function(t) {
            "yes" === t && SYNO.SDS.Utils.PasswordConfirmDialog.openDialog(i, i.applySettings, ["SYNO.Storage.CGI.Pool", "remove_missing_pool", e])
        }, i)
    },
    onCancel: function() {
        this.close()
    },
    applySettings: function(e, t, i) {
        var s = this;
        s.setStatusBusy({
            text: _T("common", "saving")
        }), s.sendWebAPI({
            api: e,
            method: t,
            version: 1,
            params: i,
            callback: function(e, t, i, a) {
                var n = function() {
                    s.clearStatusBusy(), s.close()
                }.createDelegate(s);
                setTimeout(n, 6e3)
            },
            scope: s
        })
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.ChooseReplacedDiskStep", {
    extend: "SYNO.SDS.StorageManager.Wizard.Step",
    constructor: function(e) {
        var t, i = this,
            s = [];
        i.appWin = e.appWin, i.owner = e.owner, i.pool = e.pool, i.freeDisks = e.freeDisks, i.loaded = !1, i.showDiskHealthOnSelReplaced = e.showInPoolDiskHealth, i.newDiskCondition = e.poolDiskCondition, i.getUnavailableDisks = e.getUnavailableDisks, i.openDriveRequirementWindow = e.openDriveRequirementWindow, s.push({
            xtype: "syno_displayfield",
            value: _T("storage_pool", "replace_choose_replaced_desc"),
            style: {
                "margin-bottom": "6px"
            }
        }), s.push(i.createGrid()), t = {
            headline: _T("storage_pool", "replace_choose_replaced_title"),
            items: s
        }, i.callParent([Ext.apply(t, e)])
    },
    activate: function() {
        this.loaded || (this.getReplacedDiskData(), this.loaded = !0), this.owner.getButton("next").disable()
    },
    deactivate: function() {
        this.owner.getButton("next").enable()
    },
    checkState: function() {
        SYNO.SDS.Wizard.Step.prototype.checkState.apply(this, arguments), this.getReplacedDisk() ? this.owner.getButton("next").enable() : this.owner.getButton("next").disable()
    },
    isRaidGroupPool: function() {
        var e = this;
        return !(!SYNO.SDS.StorageUtils.supportRaidGroup || e.pool.isSHR() || "multiple" !== e.pool.get("raidType") || "raid_5" !== e.pool.get("device_type") && "raid_6" !== e.pool.get("device_type") && "raid_f1" !== e.pool.get("device_type"))
    },
    createGrid: function(e) {
        var t = this,
            i = [],
            s = new SYNO.SDS.StorageManager.RadioEnableColumn({
                dataIndex: "enabled",
                id: "enable"
            });
        s.width = 22, i.push(s), t.isRaidGroupPool() && i.push({
            header: SYNO.SDS.StorageUtils.SpaceIDParser(t.pool.get("id")).str,
            dataIndex: "raidArray",
            sortable: !0
        }), i.push({
            header: _T("volume", "volume_disk"),
            dataIndex: "nameHashValue",
            sortable: !0,
            hideable: !1,
            renderer: function(e, t, i, s, a, n, o) {
                return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(i.data.name) + '"', i.data.name
            },
            tooltip: _T("volume", "volume_disk")
        }), t.showDiskHealthOnSelReplaced && i.push({
            header: _T("disk_info", "disk_health_status"),
            dataIndex: "healthStatus",
            sortable: !0,
            hideable: !1,
            renderer: function(e, t, i, s, a, n, o) {
                return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(i.data.healthStatus) + '"', i.data.healthStatus
            },
            tooltip: _T("disk_info", "disk_health_status")
        }), i.push({
            header: _T("volume", "volume_disk_type"),
            dataIndex: "diskType",
            sortable: !0,
            tooltip: _T("volume", "volume_disk_type"),
            renderer: function(e, t, i) {
                return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(e) + '"', '<div style="white-space:normal;">' + e + "</div>"
            }
        }), i.push({
            header: _T("volume", "volume_diskcapacity"),
            dataIndex: "totalSize",
            sortable: !0,
            tooltip: _T("volume", "volume_diskcapacity"),
            renderer: function(e, t, i) {
                return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(e) + '"', '<div style="white-space:normal;">' + e + "</div>"
            }
        });
        var a = Ext.apply({
            enableHdMenu: !1,
            layout: "fit",
            height: 300,
            cls: "without-dirty-red-grid sm-replace-step",
            plugins: s,
            columns: i,
            sm: t.rowSelModel = new Ext.grid.RowSelectionModel({
                singleSelect: !0
            }),
            store: t.diskStore = new Ext.data.JsonStore({
                autoDestroy: !0,
                fields: ["id", "enabled", "raidArray", "name", "diskType", "totalSize", "nameHashValue", "healthStatus"],
                listeners: {
                    update: function(e, i, s) {
                        Ext.data.Record.EDIT === s && t.checkState()
                    },
                    scope: t
                }
            })
        }, e);
        return new SYNO.ux.GridPanel(a)
    },
    getReplacedDiskData: function() {
        var e = this,
            t = [],
            i = e.diskMap;
        if (delete e.uiData, e.uiData = [], e.isRaidGroupPool()) {
            var s = "",
                a = 1;
            e.pool.get("raids").forEach(function(n) {
                s = String.format("{0} {1}", _T("volume", "volume_raid_subgroup"), a++), t.length = 0, n.devices.forEach(function(e) {
                    i[e.id].raidArray = s, t.push(i[e.id])
                }, e), e.getReplacedDiskItems(t)
            }, e)
        } else t.length = 0, e.pool.get("disks").forEach(function(e) {
            t.push(i[e])
        }, e), e.getReplacedDiskItems(t);
        e.diskStore.loadData(e.uiData)
    },
    getReplacedDiskItems: function(e) {
        var t = this,
            i = SYNO.SDS.StorageUtils;
        e.sort(SYNO.SDS.StorageUtils.DiskSort), e.forEach(function(e) {
            var s = {};
            t.isRaidGroupPool() && (s.raidArray = e.get("raidArray")), s.id = e.get("id"), s.name = e.get("longName"), s.model = e.get("model"), s.diskType = i.DiskTypeRender(e, SYNO.SDS.StorageUtils.supportSas), s.totalSize = SYNO.SDS.StorageUtils.SizeRender(e.get("size_total")), s.expansion = "internal" === e.get("type") ? _S("hostname") : e.get("container").str, s.healthStatus = i.DiskOverviewStatusRender(e.get("overview_status")), s.remainLife = i.RemainLifeRenderOld(e.get("remain_life"), e.get("below_remain_life_show_thr"), e.get("remain_life_danger")), s.serial = e.get("serial"), s.nameHashValue = i.DiskNameHashValueGet(e.get("container").order, e.get("num_id"), e.get("portType")), t.uiData.push(s)
        }, t)
    },
    getReplacedDisk: function() {
        for (var e = 0; e < this.diskStore.getCount(); e++)
            if (!0 === this.diskStore.getAt(e).get("enabled")) return this.diskStore.getAt(e).get("id");
        return null
    },
    beforeNext: function() {
        var e = this,
            t = this,
            i = this.getReplacedDisk(),
            s = t.pool.raids.find(function(e) {
                return e.devices.some(function(e) {
                    return e.id === i
                })
            }),
            a = t.freeDisks.some(function(e) {
                return +e.totalSizeNumber >= +s.minDevSize
            });
        if (!a) {
            t.newDiskCondition.checkCapacity.requestSize = +s.minDevSize;
            var n = t.getUnavailableDisks(t.newDiskCondition),
                o = 1 < n.length ? "disk_reason_crt_pool_multi_desc_link" : "disk_reason_crt_pool_single_desc_link",
                r = "open-drive-requirement-info",
                d = {},
                l = null,
                p = String.format(_T("disk_info", o), r, n.length);
            (l = t.owner).getMsgBox().alert("", p), (d = l.msgBox).el.dom.getElementsByClassName(r).forEach(function(i) {
                return i.addEventListener("click", e.openDriveRequirementWindow.bind(e, d, t.newDiskCondition, n))
            })
        }
        return a
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.ChooseNewDiskStep", {
    extend: "SYNO.SDS.StorageManager.Wizard.Step",
    constructor: function(e) {
        var t, i = this,
            s = [],
            a = !0,
            n = !1,
            o = e.diskMap;
        i.appWin = e.appWin, i.owner = e.owner, i.pool = e.pool, i.disks = e.disks, i.allDisks = e.allDisks, i.hasAbnormalDisk = e.hasAbnormalDisk, i.getDiskAlertMsg = e.getDiskAlertMsg, i.openWarningBox = e.openWarningBox, i.loaded = !1, s.push({
            xtype: "syno_displayfield",
            value: _T("storage_pool", "replace_choose_new_desc")
        }), a = !0, i.pool.get("disks").forEach(function(e) {
            if (!o[e].isSSD()) return a = !1, !1
        }, i), n = !1, i.disks.forEach(function(e) {
            if (!e.isSSD()) return n = !0, !1
        }, i), a && n && s.push({
            xtype: "syno_displayfield",
            value: String.format('<span class="syno-ux-note">{0}{1} </span>{2}', _T("common", "note"), _T("common", "colon"), _T("storage_pool", "add_hdd_to_ssd_pool_warn")),
            htmlEncode: !1
        }), s.push({
            xtype: "syno_combobox",
            ref: "locationBox",
            width: 150,
            listWidth: 150,
            hideLabel: !0,
            store: new Ext.data.ArrayStore({
                id: "value",
                fields: ["value", "text"],
                data: []
            }),
            displayField: "text",
            valueField: "value",
            forceSelection: !0,
            allowBlank: !1,
            listeners: {
                select: i.locationChange,
                scope: i
            }
        }, i.createGrid()), t = {
            headline: _T("storage_pool", "replace_choose_new_title"),
            items: s
        }, i.callParent([Ext.apply(t, e)])
    },
    activate: function() {
        var e = this;
        e.loaded ? e.locationChange() : (e.getReplacingDiskData(), e.setLocationVisibility(), e.loaded = !0), e.owner.getButton("next").disable()
    },
    deactivate: function() {
        this.owner.getButton("next").enable()
    },
    checkState: function() {
        SYNO.SDS.Wizard.Step.prototype.checkState.apply(this, arguments), this.getReplacingDisk() ? this.owner.getButton("next").enable() : this.owner.getButton("next").disable()
    },
    createGrid: function(e) {
        var t = this,
            i = [],
            s = new SYNO.SDS.StorageManager.RadioEnableColumn({
                dataIndex: "enabled",
                id: "enable"
            });
        s.width = 22, i.push(s), i.push({
            header: _T("volume", "volume_disk"),
            dataIndex: "nameHashValue",
            sortable: !0,
            hideable: !1,
            renderer: function(e, t, i, s, a, n, o) {
                return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(i.data.name) + '"', i.data.name
            },
            tooltip: _T("volume", "volume_disk")
        }), i.push({
            header: _T("volume", "volume_disk_type"),
            dataIndex: "diskType",
            sortable: !0,
            tooltip: _T("volume", "volume_disk_type"),
            renderer: function(e, t, i) {
                return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(e) + '"', '<div style="white-space:normal;">' + e + "</div>"
            }
        }), i.push({
            header: _T("volume", "volume_diskcapacity"),
            dataIndex: "totalSize",
            sortable: !0,
            tooltip: _T("volume", "volume_diskcapacity"),
            renderer: function(e, t, i) {
                return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(e) + '"', '<div style="white-space:normal;">' + e + "</div>"
            }
        });
        var a = Ext.apply({
            enableHdMenu: !1,
            layout: "fit",
            height: 278,
            cls: "without-dirty-red-grid sm-replace-step",
            plugins: s,
            columns: i,
            sm: t.rowSelModel = new Ext.grid.RowSelectionModel({
                singleSelect: !0
            }),
            store: t.diskStore = new Ext.data.JsonStore({
                autoDestroy: !0,
                fields: ["id", "enabled", "name", "model", "diskType", "totalSize", "hotspare", "serial", "compatibility", "container", "nameHashValue", "unc", "remote_info"],
                listeners: {
                    update: function(e, i, s) {
                        Ext.data.Record.EDIT === s && t.checkState()
                    },
                    scope: t
                }
            })
        }, e);
        return new SYNO.ux.GridPanel(a)
    },
    isToBeCrossRAID: function() {
        var e = this.diskMap[this.getReplacingDisk()],
            t = "internal" === this.pool.container || "internal" === e.container.type,
            i = "ebox" === this.pool.container || "ebox" === e.container.type;
        return t && i
    },
    isNeedPowerButtonDisableWarning: function() {
        return this.diskMap[this.getReplacingDisk()].container.supportPwrBtnDisable
    },
    checkEboxWarning: function() {
        var e, t, i = this,
            s = [];
        return i.isNeedPowerButtonDisableWarning() && s.push(_T("storage_pool", "ebox_power_button_disabled")), i.isToBeCrossRAID() && s.push(_T("storage_pool", "ebox_internal_mix_warning")), 0 === s.length || (t = '<div class="sm-storage-warning-dlg-title">' + _T("storage_pool", "wizard_disk_step_ebox_dlg_title") + '</div><div class="sm-msg-box-list-section-under-title">{0}</div>', e = String.format(t, s.map(function(e) {
            return '<div class="sm-suggestion-list-item">' + e + "</div>"
        }).join("")), new SYNO.SDS.StorageManager.Dialog.Confirm({
            owner: i.owner,
            warningMsg: e,
            callback: function(e) {
                e && i.owner.goNextWithoutCheck()
            }
        }).open(), !1)
    },
    beforeNext: function() {
        var e = this,
            t = e.diskMap[e.getReplacingDisk()];
        if (!0 !== e.hasAbnormalDisk(t)) return e.checkEboxWarning();
        var i = e.getDiskAlertMsg(t),
            s = {
                yes: {
                    text: _T("common", "continue"),
                    btnStyle: "red"
                },
                no: {
                    text: _T("common", "cancel")
                }
            };
        return this.openWarningBox(e.owner, i, s).then(function(t) {
            if ("yes" !== t) return !1;
            e.checkEboxWarning() && e.owner.goNextWithoutCheck()
        }).catch(function() {
            return !1
        }), !1
    },
    getReplacingDiskData: function() {
        var e = this,
            t = [];
        delete e.containers, e.containers = [], e.disks.forEach(function(t) {
            e.containers[t.get("container").order] || (e.containers[t.get("container").order] = {}, e.containers[t.get("container").order].name = 0 === t.get("container").order ? _S("hostname") : t.get("container").str, e.containers[t.get("container").order].disks = []), e.containers[t.get("container").order].disks.push(t)
        }, e);
        for (var i = 0; i < e.containers.length; i++) e.containers[i] && t.push([i, e.containers[i].name]);
        e.locationBox.store.loadData(t), e.locationBox.setValue(e.locationBox.getStore().getAt(0).get("value")), e.locationChange()
    },
    getReplacingDiskItems: function(e) {
        var t = [],
            i = SYNO.SDS.StorageUtils,
            s = this.owner.getStep("choose_replaced").getReplacedDisk(),
            a = this.pool.raids.find(function(e) {
                return e.devices.some(function(e) {
                    return e.id === s
                })
            });
        (e = e.filter(function(e) {
            return e.totalSizeNumber >= +a.minDevSize
        })).sort(SYNO.SDS.StorageUtils.DiskSort), e.forEach(function(e) {
            var s = {};
            s.id = e.get("id"), s.name = e.get("longName"), s.model = e.get("model"), s.diskType = i.DiskTypeRender(e, SYNO.SDS.StorageUtils.supportSas), s.totalSize = SYNO.SDS.StorageUtils.SizeRender(e.get("size_total")), s.hotspare = "hotspare" === e.get("used_by") ? _T("common", "yes") : "-", s.serial = e.get("serial"), s.compatibility = e.get("compatibility"), s.container = e.get("container"), s.unc = e.get("unc"), s.remote_info = e.get("remote_info"), s.nameHashValue = i.DiskNameHashValueGet(e.get("container").order, e.get("num_id"), e.get("portType")), t.push(s)
        }, this), this.diskStore.loadData(t)
    },
    locationChange: function() {
        this.getReplacingDiskItems(this.containers[this.locationBox.getValue()].disks), this.checkState()
    },
    setLocationVisibility: function() {
        var e = 1 < this.containers.length;
        this.locationBox.setVisible(e)
    },
    getReplacingDisk: function() {
        for (var e = 0; e < this.diskStore.getCount(); e++)
            if (!0 === this.diskStore.getAt(e).get("enabled")) return this.diskStore.getAt(e).get("id");
        return null
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.ReplaceSummaryStep", {
    extend: "SYNO.SDS.StorageManager.Wizard.ManageSummaryStep",
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.owner = e.owner, i.pool = e.pool, i.diskMap = e.diskMap, t = {
            headline: _T("volume", "volume_wizard_summary_title")
        }, i.callParent([Ext.apply(t, e)])
    },
    activate: function() {
        var e = this,
            t = [],
            i = e.owner.getStep("choose_replaced").getReplacedDisk(),
            s = e.owner.getStep("choose_new").getReplacingDisk();
        e.getStore().removeAll(), e.getStore().append(_T("storage_pool", "replaced_disk"), e.diskMap[i].longName), e.getStore().append(_T("storage_pool", "replacing_disk"), e.diskMap[s].longName), e.getStore().append(_T("common", "name"), SYNO.SDS.StorageUtils.SpaceIDParser(e.pool.get("id")).str), e.getStore().append(_T("volume", "volume_add_purpose"), _T("storage_pool", "replace_action")), t.push(s), e.owner.setStatusBusy(), e.owner.sendWebAPI({
            api: "SYNO.Storage.CGI.Pool",
            method: "estimate_size",
            version: 1,
            params: {
                estimate_for: "replace",
                space_id: e.pool.get("id"),
                replaced_disk_id: i,
                disk_id: t
            },
            scope: e,
            callback: function(t, i) {
                e.owner.clearStatusBusy(), t && (this.pool.isSHR() && !this.pool.supportMultiple() ? e.volumeEstimateCallBack(i) : e.getStore().append(_T("volume", "volume_totalsize"), SYNO.SDS.StorageUtils.SizeRender(i.size)))
            }
        })
    },
    applyOwnerSettings: function(e) {
        e && this.owner.applySettings()
    },
    getNext: function() {
        return new SYNO.SDS.StorageManager.Dialog.Confirm({
            owner: this.owner,
            warningMsg: _T("volume", "volume_adddisk_type_two_warning"),
            callback: this.applyOwnerSettings
        }).open(), !1
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.ReplacePool", {
    extend: "SYNO.SDS.StorageManager.Wizard.ModalWindow",
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.owner = e.owner, i.parent = e.parent, i.pool = e.pool, i.disks = e.disks, i.allDisks = e.allDisks, i.volumeMap = e.volumeMap, (t = {
            title: _T("storage_pool", "replace_title"),
            width: 820,
            height: 560,
            resizable: !1,
            layout: "fit",
            cls: "sm-manage-replace",
            steps: []
        }).steps.push(new SYNO.SDS.StorageManager.Wizard.ChooseReplacedDiskStep({
            appWin: i.appWin,
            owner: i,
            pool: i.pool,
            diskMap: e.diskMap,
            freeDisks: e.disks,
            showInPoolDiskHealth: e.showInPoolDiskHealth,
            getUnavailableDisks: e.getUnavailableDisks,
            newDiskCondition: e.newDiskCondition,
            openDriveRequirementWindow: e.openDriveRequirementWindow,
            itemId: "choose_replaced",
            nextId: "choose_new"
        })), t.steps.push(new SYNO.SDS.StorageManager.Wizard.ChooseNewDiskStep({
            appWin: i.appWin,
            owner: i,
            pool: i.pool,
            disks: i.disks,
            allDisks: i.allDisks,
            diskMap: e.diskMap,
            itemId: "choose_new",
            nextId: "summary",
            hasAbnormalDisk: e.hasAbnormalDisk,
            getDiskAlertMsg: e.getDiskAlertMsg,
            openWarningBox: e.openWarningBox
        })), t.steps.push(new SYNO.SDS.StorageManager.Wizard.ReplaceSummaryStep({
            appWin: i.appWin,
            owner: i,
            pool: i.pool,
            diskMap: e.diskMap,
            disks: i.disks,
            volumeMap: i.volumeMap,
            itemId: "summary",
            nextId: null
        })), i.callParent([Ext.apply(t, e)])
    },
    onOpen: function() {
        this.setData("manage_action", "replace"), this.callParent(arguments)
    },
    applySettings: function(e) {
        var t = this,
            i = [],
            s = {},
            a = {};
        i.push({
            src: t.getStep("choose_replaced").getReplacedDisk(),
            dst: t.getStep("choose_new").getReplacingDisk()
        }), s.space_id = t.pool.get("id"), s.replace_info = i, s.force = e || !1, this.getStep("summary") && this.getStep("summary").convertSHRToPool && (s.convert_shr_to_pool = !0), t.setStatusBusy(), t.sendWebAPI({
            api: "SYNO.Storage.CGI.Pool",
            method: "replace",
            version: 1,
            params: s,
            callback: function(e, i, s, n) {
                t.clearStatusBusy(), e ? (t.isDataChanged = !0, this.fireEvent("apply-success"), t.close()) : SYNO.SDS.StorageUtils.IsFeasibilityFail(i, a) ? SYNO.SDS.StorageUtils.ConfirmFeasibilityFail(t, a, t.applySettings, !0) : (t.appWin.getMsgBox().alert("", _T("common", "commfail")), SYNO.Debug("failed to send webapi for replacement", s, i))
            },
            scope: t
        })
    },
    getActionType: function() {
        return this.getData("manage_action")
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.EnclosureInfo", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t;
        this.appWin = e.appWin, this.owner = e.owner, t = {
            title: _T("home", "home_subject"),
            width: 420,
            height: 126 + 28 * (e.data.length + 1),
            layout: "fit",
            dsmStyle: "v5",
            border: !1,
            items: [{
                layout: "fit",
                xtype: "syno_gridpanel",
                border: !1,
                columns: [{
                    header: _T("smart", "smart_attribute"),
                    dataIndex: "item",
                    width: 200,
                    sortable: !1
                }, {
                    header: _T("relayservice", "status"),
                    dataIndex: "status",
                    width: 180,
                    useHtmlEncodeRender: !1,
                    sortable: !1
                }],
                enableHdMenu: !1,
                store: new Ext.data.JsonStore({
                    autoDestroy: !0,
                    fields: ["item", "status"],
                    data: e.data
                })
            }],
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "alt_close"),
                handler: this.close,
                scope: this
            }]
        }, this.callParent([Ext.apply(t, e)])
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.DualEnclosureInfo", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t;
        this.appWin = e.appWin, this.owner = e.owner, t = {
            title: _T("home", "home_subject"),
            width: 420,
            height: 126 + 28 * (e.data.length + 1),
            resizable: !1,
            layout: "fit",
            dsmStyle: "v5",
            border: !1,
            items: [{
                layout: "fit",
                xtype: "syno_gridpanel",
                border: !1,
                columns: [{
                    header: _T("smart", "smart_attribute"),
                    dataIndex: "item",
                    width: 200,
                    sortable: !1
                }, {
                    header: _T("relayservice", "status"),
                    dataIndex: "status",
                    width: 180,
                    useHtmlEncodeRender: !1,
                    sortable: !1
                }],
                enableHdMenu: !1,
                store: new Ext.data.JsonStore({
                    autoDestroy: !0,
                    fields: ["item", "status"],
                    data: e.data
                })
            }],
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "alt_close"),
                handler: this.close,
                scope: this
            }]
        }, this.callParent([Ext.apply(t, e)])
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.CreateVolumeMain", {
    extend: "SYNO.SDS.StorageManager.Wizard.ModalWindow",
    constructor: function(e) {
        var t, i, s = this,
            a = SYNO.SDS.StorageUtils;
        s.appWin = e.appWin, s.owner = e.owner, s.supportBtrfs = "yes" === _D("support_btrfs", "no"), s.isDataChanged = !1, t = e.option, i = {
            title: _T("volume", "volume_add_volmgr_title"),
            cls: "sm-wizard-main",
            mode: "volume_create",
            width: 640,
            height: 560,
            minHeight: 560,
            minWidth: 640,
            resizable: !0,
            border: !1,
            steps: []
        }, a.supportRaidGroup || (a.isSingleBay() || i.steps.push(new SYNO.SDS.StorageManager.Wizard.CreateVolumeModeStep({
            appWin: s.appWin,
            option: t,
            itemId: "create_mode",
            nextId: {
                quick: "property",
                custom: "pool_from"
            }
        })), a.isSingleBay() && !a.isSingleBayWithEbox() || i.steps.push(new SYNO.SDS.StorageManager.Wizard.PoolFromStep({
            appWin: s.appWin,
            itemId: "pool_from",
            nextId: {
                create: "raid_type",
                existing: "pool_choosing"
            }
        }))), a.isSingleBay() && !a.isSingleBayWithEbox() || (i.steps.push(new SYNO.SDS.StorageManager.Wizard.PoolChoosingStep({
            appWin: s.appWin,
            itemId: "pool_choosing",
            nextId: "allocate_size_step"
        })), i.steps.push(new SYNO.SDS.StorageManager.Wizard.PoolTypeStep({
            appWin: s.appWin,
            itemId: "raid_type",
            nextId: "property"
        }))), i.steps.push(new SYNO.SDS.StorageManager.Wizard.PoolPropertyStep({
            appWin: s.appWin,
            itemId: "property",
            nextId: "disk"
        })), i.steps.push(new SYNO.SDS.StorageManager.Wizard.DiskStep({
            appWin: s.appWin,
            itemId: "disk",
            nextId: "check"
        })), i.steps.push(new SYNO.SDS.StorageManager.Wizard.DiskCheckStep({
            appWin: s.appWin,
            itemId: "check",
            getNext: function() {
                return this.getData("quick_mode", !1) || a.isSingleBay() ? "fsstep" : "allocate_size_step"
            }
        })), i.steps.push(new SYNO.SDS.StorageManager.Wizard.VolumePropertyStep({
            appWin: s.appWin,
            itemId: "allocate_size_step",
            deviceType: "volume",
            nextId: "fsstep"
        })), i.steps.push(new SYNO.SDS.StorageManager.Wizard.VolumeFsTypeStep({
            appWin: s.appWin,
            itemId: "fsstep",
            nextId: "summary"
        })), i.steps.push(new SYNO.SDS.StorageManager.Wizard.CreateVolumeSummaryStep({
            appWin: s.appWin,
            isOneBay: a.isSingleBay(),
            headline: _T("volume", "volume_wizard_summary_title"),
            itemId: "summary",
            nextId: null
        })), s.callParent([Ext.apply(i, e)])
    },
    onOpen: function() {
        this.callParent(arguments), SYNO.SDS.StorageUtils.supportRaidGroup && (this.setData("quick_mode", !1), this.setData("pool_from", "existing")), SYNO.SDS.StorageUtils.isSingleBay() && (this.setData("quick_mode", !1), this.setData("pool_from", "create"), this.setData("raid_type", "single")), this.setData("create_for", "volume")
    },
    isQuickMode: function() {
        return this.getData("quick_mode", !1)
    },
    getSpaceType: function() {
        return "volume"
    },
    getDiskIds: function() {
        return this.getData("disk_ids", [])
    },
    getRaidLevel: function() {
        var e = this.getData("raid_level", ""),
            t = this.getData("disk_ids", []);
        return "shr_2" === e ? e = "shr_with_2_disk_protect" : "shr" === e && (e = 1 === t.length ? "shr_without_disk_protect" : "shr_with_1_disk_protect"), e
    },
    getPoolPath: function() {
        return this.getData("selected_pool_id", "")
    },
    getDescription: function() {
        return this.getData("volume_description") || this.getData("pool_description") || ""
    },
    isChooseExistingPool: function() {
        return "existing" === this.getData("pool_from")
    },
    getFsType: function() {
        return this.getData("fs_type", _D("defaultfs", "ext4"))
    },
    getAllocateSizeMB: function() {
        var e = this.getData("allocate_byte", 0);
        return Math.floor(e / 1024 / 1024).toString()
    },
    getDiskCheck: function() {
        return this.getData("disk_check", !1)
    },
    isPoolChild: function() {
        return "multiple" === this.getData("raid_type")
    },
    applySettings: function(e) {
        var t, i, s = this.getData("raid_type"),
            a = this.getData("deploy_space_path"),
            n = {},
            o = {};
        n.force = e || !1, this.isChooseExistingPool() ? ("single" === s ? (i = "deploy_unused", n.space_path = a) : (i = "create_on_existing_pool", n.pool_path = this.getPoolPath(), n.allocate_size = this.getAllocateSizeMB()), n.fs_type = this.getFsType(), n.vol_desc = this.getDescription(), n.atime_opt = "relatime") : (t = this.getRaidLevel(), i = "create", n.pool_path = this.getPoolPath(), n.fs_type = this.getFsType(), n.allocate_size = this.getAllocateSizeMB(), n.disk_id = this.getDiskIds(), n.is_disk_check = this.getDiskCheck(), n.device_type = t, n.is_pool_child = this.isPoolChild(), n.spare_disk_count = "0", n.vol_desc = this.getDescription(), n.desc = SYNO.SDS.StorageUtils.RaidLevelRender(t), n.atime_opt = "relatime"), this.getButton("next").disable(), this.setStatusBusy({
            text: _T("common", "saving")
        }), SYNO.API.Request({
            api: "SYNO.Storage.CGI.Volume",
            method: i,
            version: 1,
            params: n,
            callback: function(e, t, i, s) {
                this.clearStatusBusy(), e ? (this.getButton("next").enable(), this.getButton("next").setText(_T("common", "alt_finish")), this.isDataChanged = !0, this.close()) : SYNO.SDS.StorageUtils.IsFeasibilityFail(t, o) ? SYNO.SDS.StorageUtils.ConfirmFeasibilityFail(this, o, this.applySettings, !0) : (SYNO.SDS.StorageUtils.HARemoteCheckErrParsing(t), SYNO.SDS.StorageUtils.ReportWebapiFailure(this, t))
            },
            scope: this
        })
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.ManageVolume", {
    extend: "SYNO.SDS.StorageManager.Wizard.ModalWindow",
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.owner = e.owner, i.volume = e.volume || null, i.manageAction = e.manageAction, (t = Ext.apply({
            title: _T("volume", "volume_raid_management_title"),
            mode: "pool_manage",
            width: 700,
            height: 520,
            minHeight: 475,
            minWidth: 700,
            resizable: !0,
            border: !1,
            steps: []
        }, e)).steps.push(new SYNO.SDS.StorageManager.Wizard.ManageSummaryStep({
            appWin: i.appWin,
            itemId: "summary",
            nextId: null
        })), i.callParent([t])
    },
    activate: function() {
        this.callParent(arguments)
    },
    onOpen: function() {
        this.setData("manage_action", this.manageAction), this.callParent(arguments)
    },
    getPoolObject: function() {
        return this.volume
    },
    getActionType: function() {
        return this.manageAction
    },
    applySettings: function(e) {
        var t = "";
        switch (e) {
            case "stop_in_minutes":
                t = String.format(_T("volume", "volume_change_service_stop_in_minutes"), _T("common", "ask_cont"))
        }
        if ("" !== t) return "yes" === _D("support_share_encryption", "no") && (t = String.format("1. {0}<p>2. {1}", _T("volume", "volume_share_encryption_unmount_warning"), t)), void this.getMsgBox().confirm(this.title, t, function(e) {
            "yes" === e && this.sendRequestVolume()
        }, this);
        this.sendRequestVolume()
    },
    sendRequestVolume: function() {
        var e, t = {};
        switch (t.pool_path = this.volume.get("pool_path"), t.space_id = this.volume.id, this.manageAction) {
            case "expand_with_unalloc_size":
                e = "expand_unallocated";
                break;
            default:
                return void SYNO.Debug("unknown add type")
        }
        this.getButton("next").disable(), this.setStatusBusy({
            text: _T("common", "saving")
        }), SYNO.API.Request({
            api: "SYNO.Storage.CGI.Volume",
            method: e,
            version: 1,
            params: t,
            callback: function(e, t, i, s) {
                if (this.clearStatusBusy(), !e) return SYNO.SDS.StorageUtils.HARemoteCheckErrParsing(t), void SYNO.SDS.StorageUtils.ReportWebapiFailure(this, t);
                this.getButton("next").enable(), this.getButton("next").setText(_T("common", "alt_finish")), this.close()
            },
            scope: this
        })
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.CreateVolumeModeStep", {
    extend: "SYNO.SDS.StorageManager.Wizard.Step",
    constructor: function(e) {
        var t, i = String.format('<span class="syno-ux-note">{0}{1} </span>{2}', _T("common", "note"), _T("common", "colon"), "{0}");
        this.loaded = !1, this.option = e.option || {}, this.appWin = e.appWin, this.owner = e.owner, t = {
            headline: _T("volume", "volume_add_mode_title"),
            items: [{
                xtype: "syno_radio",
                boxLabel: _T("volume", "volume_add_mode_systemdefault"),
                name: "choose_mode",
                itemId: "quick",
                inputValue: "quick",
                disabled: !0
            }, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                indent: 1,
                value: _T("volume", "volume_add_mode_systemdefault_help")
            }, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                indent: 1,
                value: String.format(i, _T("volume", "volume_type_shr_support_note")),
                hidden: !SYNO.SDS.StorageUtils.supportHA
            }, {
                xtype: "syno_displayfield",
                cls: "sm-empty-line"
            }, {
                xtype: "syno_radio",
                boxLabel: _T("volume", "volume_add_mode_customized"),
                name: "choose_mode",
                itemId: "custom",
                inputValue: "custom",
                disabled: !0
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                value: _T("volume", "volume_add_mode_customized_help")
            }, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                indent: 1,
                value: String.format(i, _T("volume", "volume_add_mode_customized_note"))
            }]
        }, this.callParent([Ext.apply(t, e)])
    },
    isQuickMode: function() {
        return "quick" === this.getForm().getValues().choose_mode
    },
    activate: function() {
        this.loaded || (this.option.can_create_volume ? (_S("ha_running") ? (this.getComponent("quick").disable(), this.getComponent("custom").setValue(!0)) : (this.getComponent("quick").enable(), this.getComponent("quick").setValue(!0)), this.getComponent("custom").enable()) : this.option.can_create_volume_on_existing_pool ? (this.getComponent("quick").disable(), this.getComponent("custom").enable(), this.getComponent("custom").setValue(!0)) : (this.getComponent("quick").disable(), this.getComponent("custom").disable()), this.loaded = !0)
    },
    getNext: function() {
        return this.nextId[this.getForm().getValues().choose_mode]
    },
    updateData: function(e) {
        e.quick_mode = this.isQuickMode()
    },
    summary: function(e) {
        e.append(_T("volume", "volume_space"), _T("volume", "volume"))
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.VolumeFsTypeStep", {
    extend: "SYNO.SDS.StorageManager.Wizard.Step",
    constructor: function(e) {
        var t;
        this.loaded = !1, this.option = e.option || {}, this.appWin = e.appWin, this.owner = e.owner, t = {
            headline: _T("volume", "volume_add_fs_title"),
            cls: "sm-custom-form",
            items: [{
                xtype: "syno_radio",
                boxLabel: _T("volume", "volume_add_fs_btrfs"),
                name: "choose_fs",
                itemId: "btrfs",
                inputValue: "btrfs"
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                value: _T("volume", "volume_add_fs_btrfs_help")
            }, {
                xtype: "syno_displayfield",
                cls: "sm-empty-line"
            }, {
                xtype: "syno_radio",
                boxLabel: _T("volume", "volume_add_fs_ext4"),
                name: "choose_fs",
                itemId: "ext4",
                inputValue: "ext4"
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                value: _T("volume", "volume_add_fs_ext4_help")
            }, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                style: {
                    "text-decoration": "underline",
                    marginTop: "18px"
                },
                value: _T("volume", "volume_choose_fs_info")
            }]
        }, this.callParent([Ext.apply(t, e)])
    },
    isSkip: function() {
        return !SYNO.SDS.StorageUtils.supportBtrfs
    },
    getFsType: function() {
        return this.getForm().getValues().choose_fs
    },
    activate: function() {
        this.loaded || (SYNO.SDS.StorageUtils.supportBtrfs && "btrfs" === _D("defaultfs") ? this.getComponent("btrfs").setValue(!0) : this.getComponent("ext4").setValue(!0), this.loaded = !0)
    },
    updateData: function(e) {
        e.fs_type = this.getFsType()
    },
    getNext: function() {
        return this.nextId
    },
    summary: function(e) {
        var t;
        this.isSkip() || (t = "btrfs" === this.getFsType() ? _T("volume", "volume_add_fs_btrfs_type") : _T("volume", "volume_add_fs_ext4_type"), e.append(_T("volume", "volume_add_fs_type"), t))
    }
}), 
 /**
 * @class SYNO.SDS.StorageManager.Wizard.CreateVolumeSummaryStep
 * @extends SYNO.SDS.StorageManager.Wizard.SummaryStep
 * StorageManager wizard create volume summary class
 *
 */  
Ext.define("SYNO.SDS.StorageManager.Wizard.CreateVolumeSummaryStep", {
    extend: "SYNO.SDS.StorageManager.Wizard.SummaryStep",
    constructor: function(e) {
        this.isOneBay = !1;
        var t = {
            headline: _T("volume", "volume_wizard_summary_title")
        };
        t = Ext.apply(t, e), this.callParent([t])
    },
    estimateSize: function() {
        var e = "multiple" === this.getData("raid_type", "single");
        this.owner.setStatusBusy(), this.owner.getButton("next").disable(), SYNO.API.Request({
            api: "SYNO.Storage.CGI.Volume",
            method: "estimate_size",
            version: 1,
            params: {
                estimate_for: "create",
                disk_id: this.owner.getDiskIds(),
                device_type: this.owner.getRaidLevel()
            },
            callback: function(t, i, s, a) {
                if (this.owner.clearStatusBusy(), !t) return SYNO.SDS.StorageUtils.ReportWebapiFailure(this, i), void this.owner.getButton("next").disable();
                this.getStore().append(_T("volume", "volume_totalsize"), _T("volume", "volume_add_warningabout") + " " + SYNO.SDS.StorageUtils.SizeRender(i.size)), this.checkSize(e ? this.getData("allocate_byte", 0) : parseInt(i.size, 10))
            },
            scope: this
        })
    },
    checkSize: function(e) {
        var t = this,
            i = parseInt(SYNO.SDS.StorageUtils.getMaxVolumeSize(), 10),
            s = {};
        e > i && (s.text = _T("error", "error_volume_oversize"), s.text = String.format(s.text, SYNO.SDS.StorageUtils.SizeRender(i)), SYNO.SDS.StorageUtils.ReportWebapiFailure(this, s, function() {
            t.owner.getButton("next").disable()
        }))
    },
    activate: function() {
        var e = this.getData("pool_from", "create"),
            t = this.getData("quick_mode", !1),
            i = this.getData("allocate_byte", 0);
        this.callParent(arguments), "create" === e || t ? this.estimateSize() : this.checkSize(i)
    },
    getNext: function() {
        return this.owner.applySettings(), !1
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.VolumeGeneralProperty", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        var t, i = this,
            s = [];
        i.maxFreeSizeGB = 0, i.maxFreeSizeByte = 0, i.maxExpandSizeGB = 0, i.maxExpandSizeByte = 0, i.minExpandSizeGB = 0, i.supportBtrfs = "yes" === _D("support_btrfs", "no"), i.appWin = e.appWin, i.owner = e.owner, i.mode = e.mode, i.volume = e.volume, i.expandVolumeFlag = !1, s.push(new SYNO.ux.FieldSet({
            itemId: "volume_configure",
            title: _T("volume", "volume_edit_description"),
            items: {
                xtype: "syno_textfield",
                validateOnBlur: !0,
                validationEvent: "blur",
                name: "desc",
                itemId: "desc",
                ref: "desc",
                enableKeyEvents: !0,
                fieldLabel: _T("share", "share_comment"),
                width: 250,
                maxLength: 64
            }
        })), s.push(new SYNO.ux.FieldSet({
            itemId: "volume_record_file_access_time",
            title: _T("volume", "volume_setting_rec_file_access_time_title"),
            items: [{
                xtype: "syno_displayfield",
                itemId: "volume_record_file_access_time_desc",
                hideLabel: !0,
                value: _T("volume", "volume_atime_desc")
            }, {
                xtype: "syno_combobox",
                itemId: "atime_opt",
                name: "atime_opt",
                fieldLabel: _T("schedule", "schedule_every"),
                lazyRender: !0,
                width: 250,
                editable: !1,
                mode: "local",
                forceSelection: !0,
                allowBlank: !1,
                value: "relatime",
                store: [
                    ["relatime", _T("volume", "daily")],
                    ["monthly", _T("volume", "monthly")],
                    ["noatime", _T("volume", "never")]
                ]
            }]
        })), s.push(new SYNO.ux.FieldSet({
            itemId: "modify_size",
            title: _T("volume", "modify_size"),
            items: [{
                xtype: "syno_displayfield",
                itemId: "modify_size_desc",
                hideLabel: !0,
                value: _T("volume", "modify_size_desc")
            }, {
                xtype: "syno_displayfield",
                itemId: "allocated_size_desc",
                hideLabel: !1,
                disabled: !0,
                disabledClass: "",
                fieldLabel: _T("volume", "volume_pool_usedsize"),
                width: 250,
                value: "100000"
            }, {
                xtype: "syno_displayfield",
                itemId: "size_max_desc",
                hideLabel: !1,
                disabled: !0,
                disabledClass: "",
                fieldLabel: _T("volume", "volume_max_allocatable_size"),
                width: 250,
                value: "200000"
            }, {
                layout: "hbox",
                itemId: "size_panel",
                border: !1,
                fieldLabel: String.format("{0} ({1})", _T("volume", "volume_allocate_size_field_name"), _T("common", "size_gb")),
                labelStyle: "line-height: 28px;padding:0px;",
                bodyStyle: {
                    padding: "0px 0px 0px 0px"
                },
                items: [{
                    xtype: "syno_numberfield",
                    allowDecimals: !1,
                    validateOnBlur: !0,
                    width: 250,
                    value: "1",
                    itemId: "size_value",
                    validator: function(e) {
                        var t = SYNO.SDS.StorageUtils,
                            s = i.minExpandSizeGB,
                            a = t.getAllocatableSpaceSize() / 1024 / 1024 / 1024 + s;
                        return a < i.maxExpandSizeGB && t.isUpToHASpaceSizeLimit(1024 * (e - s) * 1024 * 1024) ? String.format(_T("volume", "space_size_limit_exceed_expand_limit"), t.getHASpaceSizeLimitStr(), a) : !(i.maxExpandSizeGB < e || i.minExpandSizeGB > e) || String.format(_T("volume", "volume_valid_range_warning"), i.minExpandSizeGB, i.maxExpandSizeGB)
                    }
                }, {
                    xtype: "syno_button",
                    itemId: "size_max",
                    text: _T("common", "max"),
                    handler: function(e, t) {
                        i.sizeCmp.setValue(i.sizeCmp.maxValue)
                    },
                    style: {
                        "margin-left": "6px"
                    },
                    scope: i
                }]
            }]
        })), s.push(new SYNO.ux.FieldSet({
            itemId: "expand_size",
            title: _T("volume", "expand_size"),
            items: [{
                xtype: "syno_displayfield",
                htmlEncode: !1,
                itemId: "expand_size_desc",
                hideLabel: !0,
                value: _T("volume", "expand_size_desc")
            }, {
                xtype: "syno_compositefield",
                itemId: "expand_size_comp",
                ref: "expand_size_comp",
                border: !1,
                labelStyle: "line-height: 28px;padding:0px;",
                bodyStyle: {
                    padding: "0px 0px 0px 0px"
                },
                items: [{
                    xtype: "syno_displayfield",
                    itemId: "allocated_size_desc",
                    ref: "allocated_size_desc",
                    hideLabel: !1,
                    disabled: !0,
                    disabledClass: "",
                    fieldLabel: _T("volume", "volume_pool_usedsize"),
                    width: 80,
                    value: "100000"
                }, {
                    xtype: "syno_button",
                    itemId: "expand_size_button",
                    text: _T("volume", "volume_setting_expand_size_btn"),
                    handler: i.expandToFullSize,
                    style: {
                        "margin-left": "6px"
                    },
                    scope: i
                }]
            }, {
                xtype: "syno_displayfield",
                itemId: "size_max_desc",
                hideLabel: !1,
                disabled: !0,
                disabledClass: "",
                fieldLabel: _T("volume", "volume_max_allocatable_size"),
                width: 250,
                value: "200000"
            }]
        })), s.push(new SYNO.ux.FieldSet({
            itemId: "volume_settings_usage_detail",
            title: _T("volume", "usage_detail"),
            items: [{
                xtype: "syno_displayfield",
                hideLabel: !0,
                value: _T("volume", "usage_detail_desc")
            }, {
                xtype: "syno_checkbox",
                id: i.usageCheckBox = Ext.id(),
                name: "usageCheckBox",
                itemId: "usageCheckBoxId",
                handler: i.onClickUsageCheckBox,
                boxLabel: _T("volume", "usage_detail_option"),
                value: !1,
                ref: "enableUsage",
                scope: this
            }]
        })), t = {
            itemId: "volumeConfigPanel",
            border: !1,
            trackResetOnLoad: !0,
            layoutConfig: {
                trackLabels: !0
            },
            labelWidth: 250,
            items: s
        }, i.callParent([Ext.apply(t, e)]);
        var a = i.getComponent("volume_configure");
        i.descCmp = a.getComponent("desc");
        var n = i.getComponent("volume_record_file_access_time");
        i.atimeOptCmp = n.getComponent("atime_opt");
        var o = i.getComponent("modify_size");
        i.sizeCmp = o.getComponent("size_panel").getComponent("size_value"), i.maxSizeBtn = o.getComponent("size_panel").getComponent("size_max"), i.maxSizeDesc = o.getComponent("size_max_desc"), i.alloSizeDesc = o.getComponent("allocated_size_desc");
        var r = i.getComponent("expand_size");
        i.expandMaxSizeDesc = r.getComponent("size_max_desc"), i.expandAlloSizeDesc = r.expand_size_comp.allocated_size_desc, i.usageDetailCmp = i.getComponent("volume_settings_usage_detail"), i.usageCheckBoxCmp = i.usageDetailCmp.getComponent("usageCheckBoxId"), i.isUsageCheckBoxInit = !1, i.UsageCheckBoxInitValue = !1
    },
    onActivate: function() {
        var e, t, i, s, a, n, o, r, d, l = this,
            p = SYNO.SDS.StorageUtils;
        if (l.volume) {
            !(e = l.pool) || l.volume.isSingleBayBasicVolume() ? (n = p.getMaxVolumeSize(), i = parseInt(l.volume.get("size").used, 10), s = parseInt(l.volume.get("size").used, 10), a = "") : (n = p.getMaxVolumeSize(), i = parseInt(e.get("size").total, 10), s = parseInt(e.get("size").used, 10), a = p.SpaceIDParser(e.get("id")).str), t = parseInt(l.volume.get("size").total_device, 10), o = parseInt(i - s + t, 10), (r = parseInt(l.volume.get("max_fs_size"), 10)) < o ? (l.maxExpandSizeGB = p.GetSizeGB(r, 0), l.maxExpandSizeByte = r) : (l.maxExpandSizeGB = p.GetSizeGB(o, 0), l.maxExpandSizeByte = o), l.minExpandSizeGB = p.GetSizeGB(t, 0), l.minExpandSizeGB > l.maxExpandSizeGB && (l.maxExpandSizeGB = l.minExpandSizeGB, l.maxExpandSizeByte = t), l.maxExpandSizeByte > n && (l.maxExpandSizeByte = n, l.maxExpandSizeGB = n / 1024 / 1024 / 1024), d = Ext.util.Format.htmlDecode(l.volume.get("vol_desc")), l.getForm().setValues({
                pool: a,
                desc: d,
                atime_opt: l.volume.get("atime_opt"),
                size_value: l.minExpandSizeGB
            }), l.sizeCmp.maxValue = l.maxExpandSizeGB, l.sizeCmp.minValue = l.minExpandSizeGB, l.maxSizeDesc.setValue(String.format("{0} {1}", l.maxExpandSizeGB, _T("common", "size_gb"))), l.alloSizeDesc.setValue(String.format("{0} {1}", l.minExpandSizeGB, _T("common", "size_gb")));
            var u = p.GetSizeUnit(l.volume.size.total);
            if (l.expandMaxSizeDesc.setValue(String.format("{0} {1}", l.maxExpandSizeGB, _T("common", "size_gb"))), l.expandAlloSizeDesc.setValue(String.format("{0} {1}", u.size, u.unit)), "btrfs" === l.volume.fs_type ? this.updateUsageDetailEn() : l.usageDetailCmp.hide(), "single" === l.volume.raidType && l.getComponent("modify_size").hide(), l.volume.can_do && l.volume.can_do.expand_with_unalloc_size || l.getComponent("expand_size").hide(), !e || !e.isFreeSizeBiggerThan1GB() || !e.isWritable) return l.sizeCmp.disable(), void l.maxSizeBtn.disable();
            e && "single" !== e.get("raidType") ? (l.sizeCmp.enable(), l.maxSizeBtn.enable()) : (l.sizeCmp.disable(), l.maxSizeBtn.disable())
        }
    },
    onClickUsageCheckBox: function() {
        var e = this;
        !0 === e.isUsageCheckBoxInit && !1 === e.UsageCheckBoxInitValue && !0 === e.usageCheckBoxCmp.getValue() && this.findWindow().getMsgBox().confirm(this.title, _T("volume", "usage_enable_notice"), function(t) {
            "cancel" === t && e.usageCheckBoxCmp.setValue(!1)
        }, this, {
            cancel: {
                text: _T("common", "cancel")
            },
            ok: {
                text: _T("common", "ok"),
                btnStyle: "blue"
            }
        })
    },
    updateUsageDetailEn: function() {
        this.owner.setStatusBusy(), this.sendWebAPI({
            api: "SYNO.Storage.CGI.Volume",
            method: "get_space_usage",
            version: 1,
            params: {
                volume_path: this.volume.vol_path
            },
            callback: function(e, t) {
                if (this.owner.clearStatusBusy(), !e) return SYNO.SDS.StorageUtils.HARemoteCheckErrParsing(t), void SYNO.SDS.StorageUtils.ReportWebapiFailure(this, t);
                switch (t.status) {
                    case "enabled":
                    case "enabling":
                        this.form.setValues({
                            usageCheckBox: !0
                        }), this.UsageCheckBoxInitValue = !0;
                        break;
                    case "disabled":
                    case "disabling":
                        this.form.setValues({
                            usageCheckBox: !1
                        }), this.UsageCheckBoxInitValue = !1
                }
                this.isUsageCheckBoxInit = !0
            },
            scope: this
        })
    },
    getAllocateSizeMB: function() {
        var e = this.sizeCmp;
        return (e.getValue() === e.maxValue ? Math.floor(parseInt(this.maxFreeSizeByte, 10) / 1024 / 1024) : 1024 * parseInt(e.getValue(), 10)).toString()
    },
    isValid: function() {
        return this.getForm().isValid()
    },
    isDirty: function() {
        return this.getForm().isDirty() || this.expandVolumeFlag
    },
    getSettingAPI: function() {
        var e, t, i, s, a = this,
            n = [];
        if (a.isValid() && a.isDirty()) return (a.descCmp.isDirty() || a.atimeOptCmp.isDirty()) && (i = a.descCmp.getValue(), s = a.atimeOptCmp.getValue(), e = {
            space_id: a.volume.get("id"),
            desc: i,
            atime_opt: s
        }, n.push({
            api: "SYNO.Storage.CGI.Volume",
            method: "set_setting",
            version: 1,
            params: e
        })), a.sizeCmp.isDirty() && (t = 1024 * parseInt(a.sizeCmp.getValue(), 10) * 1024 * 1024, e = {
            space_id: a.volume.get("id"),
            new_size: t.toString()
        }, n.push({
            api: "SYNO.Storage.CGI.Volume",
            method: "expand_pool_child",
            version: 1,
            params: e
        })), a.usageCheckBoxCmp.isDirty() && n.push({
            api: "SYNO.Storage.CGI.Volume",
            method: a.usageCheckBoxCmp.getValue() ? "enable_space_usage" : "disable_space_usage",
            version: 1,
            params: {
                volume_path: a.volume.vol_path
            }
        }), a.expandVolumeFlag && ((e = {}).space_id = this.volume.id, n.push({
            api: "SYNO.Storage.CGI.Volume",
            method: "expand_unallocated",
            version: 1,
            params: e
        })), n
    },
    expandToFullSize: function() {
        this.expandAlloSizeDesc.setValue(String.format("{0} {1}", this.maxExpandSizeGB, _T("common", "size_gb"))), this.expandVolumeFlag = !0
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.DeleteVolume", {
    extend: "SYNO.SDS.ModalWindow",
    serviceNameMap: {
        media: _T("tree", "leaf_mediaservice"),
        itunes: _T("tree", "leaf_itunes"),
        audio: _T("tree", "leaf_audio"),
        photo: _T("tree", "leaf_photo"),
        netbkp: _T("tree", "leaf_netbkp"),
        web: _T("tree", "leaf_web"),
        download: _T("tree", "node_download"),
        mysql: _T("tree", "leaf_mysql"),
        surveillance: _T("tree", "leaf_surveillance"),
        userhome: _T("user", "user_home")
    },
    constructor: function(e) {
        var t, i = this;
        i.isDataChanged = !1, i.appWin = e.appWin, i.owner = e.owner, i.volumeIds = e.volumeIds || [], i.services = void 0, i.deleteFrom = e.deleteFrom, i.isInternalVolume = e.isInternalVolume, t = {
            title: "virtualPool" === i.deleteFrom ? _T("volume", "volume_remove_raid_group") : _T("volume", "volume_delete_volmgr_title"),
            width: 640,
            height: 350,
            resizable: !1,
            layout: "fit",
            items: [{
                itemId: "main",
                border: !1,
                style: {
                    padding: "16px 20px 0px 20px"
                },
                items: [{
                    xtype: "syno_displayfield",
                    value: "",
                    id: i.descID = Ext.id(),
                    itemId: "desc"
                }, i.grid = new SYNO.SDS.Wizard.SummaryStep({
                    layout: "fit",
                    height: 200,
                    style: {
                        paddingTop: "8px"
                    }
                })]
            }],
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "alt_cancel"),
                scope: i,
                handler: i.onCancel
            }, {
                xtype: "syno_button",
                btnStyle: "red",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                text: _T("common", "remove"),
                id: i.applyButtonID = Ext.id(),
                scope: i,
                handler: i.onSave
            }]
        }, i.callParent([Ext.apply(t, e)])
    },
    onOpen: function() {
        var e, t = this,
            i = SYNO.SDS.StorageUtils;
        t.callParent(arguments), 0 !== t.volumeIds.length && (e = t.grid.getStore(), t.isInternalVolume && i.isSingleBay() && e.append(_T("volume", "volume_storage_pool"), i.SpaceIDParser("reuse_").str), e.append(_T("volume", "volume"), i.getVolumeNames(t.volumeIds)), t.setStatusBusy(), SYNO.API.Request({
            api: "SYNO.Storage.CGI.Volume",
            method: "enum_resource",
            version: 1,
            params: {
                space_id: t.volumeIds
            },
            callback: function(e, i, s, a) {
                t.clearStatusBusy(), e ? t.loadData(i, s) : SYNO.SDS.StorageUtils.ReportWebapiFailure(this, i)
            },
            scope: t
        }))
    },
    onSave: function() {
        var e, t, i = this;
        e = {
            space_id: i.volumeIds,
            force: !0
        }, t = '1. <font class="red-status">' + _T("volume", "volume_delete_warning") + "</font><br/>2. ", t += _T("volume", "volume_all_service_stop"), i.getMsgBox().confirmDelete("", t, function(t) {
            "yes" === t && SYNO.SDS.Utils.PasswordConfirmDialog.openDialog(i, i.apply, ["delete", e])
        }, i)
    },
    onCancel: function() {
        this.close()
    },
    loadData: function(e, t) {
        var i = this,
            s = i.grid.getStore(),
            a = SYNO.SDS.StorageUtils,
            n = {},
            o = [],
            r = a.CheckFailedMsg(e.check),
            d = !1;
        "hard_failed" === r ? (d = !0, Ext.getCmp(i.applyButtonID).disable(), Ext.getCmp(i.descID).setValue(_T("volume", "del_hard_check_fail")), function(e) {
            var t = !0;
            e.space_id.forEach(function(e) {
                if ("crashed" !== i.volumeMap[e].get("status")) return t = !1, !1
            }), t && (Ext.getCmp(i.applyButtonID).enable(), Ext.getCmp(i.descID).setValue(_T("volume", "del_soft_check_fail")))
        }(t)) : "soft_failed" === r ? Ext.getCmp(i.descID).setValue(_T("volume", "del_soft_check_fail")) : "virtualPool" === i.deleteFrom ? Ext.getCmp(i.descID).setValue(_T("storage_pool", "pool_delete_summary_desc")) : i.isInternalVolume && a.isSingleBay() ? Ext.getCmp(i.descID).setValue(_T("volume", "volume_delete_summary_single_bay_internal_desc")) : Ext.getCmp(i.descID).setValue(_T("volume", "volume_delete_summary_desc")), a.CheckMsg(e.check, d, "volumes", s), e.services && e.services.length > 0 && s.append(_T("volume", "volume_warninglistservice"), a.getServiceNames(e.services)), e.iscsiluns && e.iscsiluns.length > 0 && (s.append(_T("volume", "volume_iscsitrg_lun"), a.getNamesString(e.iscsiluns)), a.CheckMsg(e.check, d, "iscsiluns", s)), e.shares && e.shares.length > 0 && (s.append(_T("volume", "volume_status_warningdelinfo"), a.getNamesString(e.shares)), a.CheckMsg(e.check, d, "shares", s)), e.pkgs && e.pkgs.length > 0 && s.append(_T("pkgmgr", "title_packages"), a.getNamesString(e.pkgs)), i.services = e.services, "yes" === _D("support_ssd_cache", "no") && (Ext.each(i.volumeIds, function(e) {
            n[e] = !0
        }), Ext.each(i.allSsdcaches, function(e) {
            n[e.get("mountSpaceId")] && o.push(SYNO.SDS.Utils.StorageUtils.SpaceIDParser(e.get("id")).str)
        }, i), 0 < o.length && s.append(_T("volume", "ssd_cache_string2"), o.join(", ")))
    },
    apply: function(e, t) {
        var i = this,
            s = {};
        i.setStatusBusy({
            text: _T("common", "saving")
        }), SYNO.API.Request({
            api: "SYNO.Storage.CGI.Volume",
            method: e,
            version: 1,
            params: t,
            callback: function(t, a, n, o) {
                i.clearStatusBusy(), t ? (SYNO.SDS.StorageUtils.disableServices(i.services), i.isDataChanged = !0, i.close()) : SYNO.SDS.StorageUtils.IsFeasibilityFail(a, s) ? SYNO.SDS.StorageUtils.ConfirmFeasibilityFail(this, s, this.apply, e, n) : (SYNO.SDS.StorageUtils.HARemoteCheckErrParsing(a), SYNO.SDS.StorageUtils.ReportWebapiFailure(this, a))
            },
            scope: i
        })
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.ConfigureVolume", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t, i = this,
            s = this;
        s.appWin = e.appWin, s.owner = e.owner, s.volume = e.volume, s.pool = e.pool, this.forceClose = !1, this.volumeConfigPanel = new SYNO.SDS.StorageManager.Wizard.VolumeGeneralProperty({
            appWin: s.appWin,
            owner: s,
            volume: s.volume,
            pool: s.pool
        }), t = {
            title: _T("common", "common_settings"),
            width: 700,
            height: 480,
            resizable: !1,
            layout: "fit",
            plain: !0,
            border: !1,
            items: this.volumeConfigPanel,
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "alt_cancel"),
                scope: this,
                handler: this.onCancel
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                text: _T("common", "save"),
                scope: this,
                handler: this.onSave
            }],
            listeners: {
                activate: {
                    fn: function() {
                        i.volumeConfigPanel.onActivate()
                    },
                    single: !0,
                    scope: this
                },
                beforeclose: this.onBeforeClose.bind(this)
            }
        }, s.callParent([Ext.apply(t, e)])
    },
    onSave: function() {
        var e = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t, i, s, a;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        if (t = this, i = [], this.isValid()) {
                            e.next = 4;
                            break
                        }
                        return e.abrupt("return");
                    case 4:
                        if (this.isDirty()) {
                            e.next = 7;
                            break
                        }
                        return this.setStatusError({
                            text: _T("error", "nochange_subject"),
                            clear: !0
                        }), e.abrupt("return");
                    case 7:
                        if (s = this.volumeConfigPanel.getSettingAPI()) {
                            e.next = 11;
                            break
                        }
                        return this.close(), e.abrupt("return");
                    case 11:
                        if (s.forEach(function(e) {
                                Ext.isObject(e) && i.push(e)
                            }), 0 === i.length && this.close(), "btrfs" !== this.volume.fs_type) {
                            e.next = 22;
                            break
                        }
                        return e.next = 16, this.getUsageDetailStatus();
                    case 16:
                        if ("disabling" !== e.sent) {
                            e.next = 22;
                            break
                        }
                        return a = {
                            ok: {
                                text: _T("common", "ok"),
                                btnStyle: "blue"
                            }
                        }, e.next = 21, this.alert(this, _T("volume", "volume_is_busy"), _T("volume", "usage_enable_volume_busy"), a);
                    case 21:
                        return e.abrupt("return");
                    case 22:
                        this.setStatusBusy(), this.sendWebAPI({
                            scope: this,
                            compound: {
                                stopwhenerror: !1,
                                mode: "parallel",
                                params: i
                            },
                            callback: function(e, i, s, a) {
                                this.clearStatusBusy(), this.isDataChanged = !0, e ? i.has_fail ? Ext.each(i.result, function(e) {
                                    var i = {};
                                    e.success || (SYNO.SDS.StorageUtils.IsFeasibilityFail(e.error, i) ? SYNO.SDS.StorageUtils.ConfirmFeasibilityFail(t, i, t.sendWebapiSkipFeasibilityCheck, SYNO.API.Util.GetReqByAPI(a, e.api, e.method)) : (SYNO.SDS.StorageUtils.HARemoteCheckErrParsing(e.error), SYNO.SDS.StorageUtils.ReportWebapiFailure(t, e.error)))
                                }) : (this.forceClose = !0, this.close()) : this.getMsgBox().alert("", _T("error", "error_subject"))
                            }
                        });
                    case 24:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return function() {
            return e.apply(this, arguments)
        }
    }(),
    onCancel: function() {
        this.close()
    },
    onBeforeClose: function() {
        return !(this.isDirty() && !this.forceClose) || (this.confirmLostChangePromise({
            save: function() {
                if (!this.isValid()) return !1;
                this.onSave()
            },
            dontSave: function() {
                this.forceClose = !0, this.close()
            },
            cancel: function() {}
        }, this), !1)
    },
    isDirty: function() {
        return Ext.isFunction(this.volumeConfigPanel.isDirty) && this.volumeConfigPanel.isDirty()
    },
    isValid: function() {
        return Ext.isFunction(this.volumeConfigPanel.isValid) && this.volumeConfigPanel.isValid()
    },
    getActiveTab: function() {
        var e = this.getComponent("main");
        return e && Ext.isFunction(e.getActiveTab) ? e.getActiveTab() : null
    },
    sendWebapiSkipFeasibilityCheck: function(e) {
        e.params.force = !0, this.setStatusBusy({
            text: _T("common", "saving")
        }), this.sendWebAPI({
            api: e.api,
            method: e.method,
            version: e.version,
            params: e.params,
            callback: function(e, t) {
                if (this.clearStatusBusy(), !e) return SYNO.SDS.StorageUtils.HARemoteCheckErrParsing(t), void SYNO.SDS.StorageUtils.ReportWebapiFailure(this, t);
                this.isDataChanged = !0, this.forceClose = !0, this.close()
            },
            scope: this
        })
    },
    getUsageDetailStatus: function() {
        return this.sendWebAPIPromise({
            api: "SYNO.Storage.CGI.Volume",
            method: "get_space_usage",
            version: 1,
            params: {
                volume_path: this.volume.vol_path
            }
        }).then(function(e) {
            return e.status
        })
    },
    alert: function(e, t, i, s) {
        return new Promise(function(t, a) {
            e.getMsgBox().alert("", i, function(e) {
                t()
            }, this, s)
        }.bind(this))
    },
    confirm: function(e, t, i) {
        return new Promise(function(s, a) {
            e.getMsgBox().confirm("comfirm", t, s, this, i)
        }.bind(this))
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.PoolChoosingStep", {
    extend: "SYNO.SDS.StorageManager.Wizard.Step",
    constructor: function(e) {
        var t;
        this.appWin = e.appWin, this.loaded = !1, t = {
            headline: _T("volume", "volume_choose_raid_title"),
            items: [{
                xtype: "syno_message_combobox",
                fieldLabel: _T("volume", "volume_pool"),
                width: 250,
                name: "pools",
                itemId: "pools",
                valueField: "id",
                displayField: "display",
                descriptionField: "desc",
                store: this.poolStore = new Ext.data.JsonStore({
                    autoDestroy: !0,
                    idProperty: "id",
                    fields: ["id", "display", "avail", "total", "desc", "raidLevel", "multipleSupport", "spacePath"]
                }),
                listeners: {
                    select: this.onSelect,
                    scope: this
                }
            }, {
                xtype: "syno_displayfield",
                itemId: "raid_level",
                fieldLabel: _T("volume", "volume_raid_type"),
                htmlEncode: !1
            }, {
                xtype: "syno_displayfield",
                itemId: "multiple_volume_support",
                fieldLabel: _T("volume", "volume_multiple_vol_lun_support")
            }, {
                xtype: "syno_displayfield",
                itemId: "total_size",
                fieldLabel: _T("volume", "volume_totalsize")
            }, {
                xtype: "syno_displayfield",
                itemId: "free_size",
                fieldLabel: _T("volume", "volume_freesize")
            }]
        }, this.callParent([Ext.apply(t, e)])
    },
    activate: function() {
        var e, t, i = this,
            s = SYNO.SDS.StorageUtils,
            a = [];
        i.loaded || (e = i.appWin.storagePools.getMatched("isFreeSizeBiggerThan1GB", "isWritable"), Ext.each(e, function(e) {
            var t, i, n, o, r;
            r = e.get("id"), t = e.get("size"), n = parseInt(t.used, 10), o = (i = parseInt(t.total, 10)) - n, a.push({
                id: r,
                display: String.format("{0} ({1}: {2})", s.SpaceIDParser(r).str, _T("volume", "volume_freesize"), s.SizeRenderWithFloor(o)),
                desc: e.get("desc"),
                avail: o,
                total: i,
                numId: e.get("num_id"),
                raidLevel: e.get("device_type"),
                multipleSupport: e.supportMultiple(),
                spacePath: e.get("space_path")
            })
        }), a.sort(function(e, t) {
            return e.numId > t.numId ? 1 : e.numId === t.numId ? 0 : -1
        }), i.poolStore.loadData(a), (t = i.poolStore.getAt(0)) && (i.getComponent("pools").setValue(t.get("id")), i.onSelect(i, t, 0)), i.loaded = !0)
    },
    onSelect: function(e, t, i) {
        var s = SYNO.SDS.StorageUtils,
            a = this.getComponent("raid_level"),
            n = this.getComponent("multiple_volume_support"),
            o = this.getComponent("total_size"),
            r = this.getComponent("free_size");
        a.setValue(s.SpaceTypeRender(t.data.raidLevel)), n.setValue(t.data.multipleSupport ? _T("common", "yes") : _T("common", "no")), o.setValue(s.SizeRender(t.data.total)), r.setValue(s.SizeRender(t.data.avail))
    },
    updateData: function(e) {
        var t = this.getComponent("pools"),
            i = t.getValue(),
            s = t.getStore().getById(i);
        e.selected_pool_id = i, e.raid_level = s.data.raidLevel, e.raid_type = s.data.multipleSupport ? "multiple" : "single", e.deploy_space_path = s.data.spacePath
    },
    getNext: function() {
        return this.nextId
    },
    summary: function(e) {}
}), Ext.namespace("SYNO.SDS.StorageManager.Pool"), Ext.define("SYNO.SDS.StorageManager.Pool.Settings.Dialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t = this,
            i = e.owner,
            s = e.appWin;
        this.settingPanel = new SYNO.SDS.StorageManager.Pool.ConfigPanel({
            appWin: s,
            owner: i
        });
        var a = Ext.apply({
            width: 700,
            height: 580,
            minWidth: 700,
            minHeight: 580,
            layout: "fit",
            items: this.settingPanel,
            buttons: [{
                xtype: "syno_button",
                btnStyle: "grey",
                text: _T("common", "cancel"),
                scope: this,
                handler: this.cancelHandler
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                text: _T("common", "save"),
                scope: this,
                handler: this.applyHandler
            }],
            listeners: {
                activate: function() {
                    t.settingPanel.fireEvent("initData", t)
                },
                beforeclose: this.onBeforeClose
            }
        }, e);
        this.callParent([a]), this.addManagedComponent(this.settingPanel)
    },
    onBeforeClose: function() {
        if (!this.skipCheckDirty && this.settingPanel.getForm().isDirty()) return this.confirmLostChangePromise({
            save: function() {
                this.applyHandler()
            },
            dontSave: function() {
                this.settingPanel.getForm().reset(), this.close()
            },
            cancel: function() {}
        }, this), !1
    },
    cancelHandler: function() {
        this.close()
    },
    applyHandler: function() {
        this.settingPanel.applyForm()
    },
    forceClose: function() {
        this.skipCheckDirty = !0, this.close()
    }
}), Ext.define("SYNO.SDS.StorageManager.Pool.ConfigPanel", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(e) {
        var t, i = this,
            s = this;
        this.appWin = e.appWin, this.owner = e.owner, this.getFastRepairConfigApi = {
            api: "SYNO.Storage.CGI.Storage",
            method: "get_fast_repair_config",
            version: 1,
            params: {}
        }, this.getAutoRepairConfigApi = {
            api: "SYNO.Storage.CGI.Storage",
            method: "get_auto_repair_config",
            version: 1,
            params: {}
        }, this.getResyncSpeedApi = {
            api: "SYNO.Storage.CGI.Storage",
            method: "get_resync_speed",
            version: 1,
            params: {}
        };
        var a = {
                xtype: "syno_fieldset",
                itemId: "adv_repair",
                title: _T("storage_pool", "repair_adv_setting_title"),
                listeners: {},
                items: []
            },
            n = {
                xtype: "syno_fieldset",
                itemId: "speed_limit",
                title: _T("data_scrubbing", "speed_limit"),
                items: [{
                    xtype: "syno_radio",
                    name: "speed_option",
                    itemId: "speed_limit_slow",
                    boxLabel: _T("data_scrubbing", "speed_limit_slow"),
                    value: !1,
                    inputValue: "resync_slower"
                }, {
                    xtype: "syno_radio",
                    name: "speed_option",
                    itemId: "speed_limit_fast",
                    boxLabel: _T("data_scrubbing", "speed_limit_fast"),
                    value: !1,
                    inputValue: "resync_faster"
                }, {
                    xtype: "syno_radio",
                    name: "speed_option",
                    itemId: "speed_limit_manual",
                    boxLabel: _T("data_scrubbing", "manual"),
                    value: !1,
                    inputValue: "resync_manual",
                    listeners: {
                        scope: this,
                        check: function(e, t) {
                            t ? (this.getField("speed_max_comp").setDisabled(!1), this.getField("speed_min_comp").setDisabled(!1), this.getField("speed_max_comp").show(), this.getField("speed_min_comp").show()) : (this.getField("speed_max_comp").hide(), this.getField("speed_min_comp").hide(), this.getField("speed_max_comp").setDisabled(!0), this.getField("speed_min_comp").setDisabled(!0)), s.updateFleXcroll()
                        }
                    }
                }, {
                    xtype: "syno_compositefield",
                    itemId: "speed_max_comp",
                    hidden: !0,
                    hideLabel: !0,
                    items: [{
                        xtype: "syno_displayfield",
                        width: 70,
                        indent: 1,
                        value: _T("data_scrubbing", "speed_limit_max")
                    }, {
                        xtype: "syno_numberfield",
                        name: "speed_max",
                        itemId: "speed_max",
                        indent: 1,
                        validator: function() {
                            return s.speedChecker()
                        },
                        minValue: 0
                    }, {
                        xtype: "syno_displayfield",
                        width: 10,
                        indent: 1,
                        value: ""
                    }, {
                        xtype: "syno_displayfield",
                        indent: 1,
                        value: "MB/s"
                    }]
                }, {
                    xtype: "syno_compositefield",
                    itemId: "speed_min_comp",
                    hidden: !0,
                    hideLabel: !0,
                    items: [{
                        xtype: "syno_displayfield",
                        width: 70,
                        indent: 1,
                        value: _T("data_scrubbing", "speed_limit_min")
                    }, {
                        xtype: "syno_numberfield",
                        name: "speed_min",
                        itemId: "speed_min",
                        indent: 1,
                        validator: function() {
                            return s.speedChecker()
                        },
                        minValue: 0
                    }, {
                        xtype: "syno_displayfield",
                        width: 10,
                        indent: 1,
                        value: ""
                    }, {
                        xtype: "syno_displayfield",
                        indent: 1,
                        value: "MB/s"
                    }]
                }, {
                    xtype: "syno_displayfield",
                    htmlEncode: !1,
                    value: '<span class="syno-ux-note">' + _T("common", "note") + _T("common", "colon") + " </span>" + _T("data_scrubbing", "resync_speed_note")
                }]
            };
        this.getConfigApis = [];
        var o = [];
        s.getConfigApis.push(s.getResyncSpeedApi), o.push(n), "yes" === _D("support_fast_repair", "no") && (a.items.push({
            xtype: "syno_displayfield",
            htmlEncode: !1,
            value: '<span class="sm-storage-setting-subtitle">' + _T("storage_pool", "fast_repair") + "</span>"
        }, {
            xtype: "syno_displayfield",
            htmlEncode: !1,
            value: _T("storage_pool", "fast_repair_tip")
        }, {
            xtype: "syno_checkbox",
            name: "fast_repair_enable",
            itemId: "fast_repair_enable",
            boxLabel: _T("storage_pool", "fast_repair_enable")
        }), s.getConfigApis.push(s.getFastRepairConfigApi)), "yes" === _D("support_auto_repair", "no") && (a.items.push({
            xtype: "syno_displayfield",
            htmlEncode: !1,
            value: '<span class="sm-storage-setting-subtitle">' + _T("storage_pool", "auto_repair_title") + "</span>"
        }, {
            xtype: "syno_displayfield",
            htmlEncode: !1,
            value: _T("storage_pool", "auto_repair_desc")
        }, {
            xtype: "syno_checkbox",
            name: "auto_repair_enable",
            itemId: "auto_repair_enable",
            boxLabel: _T("storage_pool", "auto_repair_enable")
        }), s.getConfigApis.push(s.getAutoRepairConfigApi)), a.items.length > 0 && o.push(a), t = {
            title: _T("volume", "configuration"),
            items: o,
            useDefaultBtn: !1,
            itemId: "config_panel"
        }, this.callParent([Ext.apply(t, e)]), this.on("initData", function() {
            i.onActivate()
        }, this, {
            single: !0
        })
    },
    getField: function(e) {
        return this.getForm().findField(e)
    },
    speedChecker: function() {
        return this.getField("speed_min").getValue() >= this.getField("speed_max").getValue() ? _T("data_scrubbing", "resync_speed_setting_warning") : !(1e4 < this.getField("speed_min").getValue() || 1e4 < this.getField("speed_max").getValue()) || _T("data_scrubbing", "resync_speed_range_warning")
    },
    getConfigCallBack: function(e, t, i) {
        var s, a = this;
        if (a.ownerCt.clearStatusBusy(), e && !t.has_fail) {
            for (s = 0; s < t.result.length; s++) {
                var n = t.result[s];
                SYNO.ux.Utils.checkApiConsistency(n, a.getFastRepairConfigApi) && "yes" === _D("support_fast_repair", "no") ? a.getForm().setValues({
                    fast_repair_enable: n.data.is_fast_repair_enable
                }) : "yes" === _D("support_auto_repair", "no") && SYNO.ux.Utils.checkApiConsistency(n, a.getAutoRepairConfigApi) ? a.getForm().setValues({
                    auto_repair_enable: n.data.enable
                }) : SYNO.ux.Utils.checkApiConsistency(n, a.getResyncSpeedApi) && a.getForm().setValues({
                    speed_option: n.data.speed_option,
                    speed_max: n.data.speed_max,
                    speed_min: n.data.speed_min
                })
            }
            a.updateFleXcroll()
        } else a.ownerCt.getMsgBox().alert("", _T("common", "commfail"))
    },
    onActivate: function() {
        this.ownerCt.setStatusBusy(), SYNO.API.Request({
            compound: {
                params: this.getConfigApis
            },
            callback: this.getConfigCallBack,
            scope: this
        })
    },
    getResyncSpeedParams: function() {
        var e = this.getForm().getValues().speed_option,
            t = {
                speed_option: e
            };
        return "resync_manual" === e && (t.speed_max = this.getField("speed_max").getValue(), t.speed_min = this.getField("speed_min").getValue()), t
    },
    getAutoRepairParams: function() {
        return {
            enable: this.getField("auto_repair_enable").getValue()
        }
    },
    applyForm: function() {
        var e = "yes" === _D("support_auto_repair", "no");
        if (this.getForm().isValid())
            if (this.getForm().isDirty()) {
                var t = [{
                    api: "SYNO.Storage.CGI.Storage",
                    method: "set_resync_speed",
                    version: 1,
                    params: this.getResyncSpeedParams()
                }];
                if ("yes" === _D("support_fast_repair", "no")) {
                    var i = this.getField("fast_repair_enable").getValue();
                    t.push({
                        api: "SYNO.Storage.CGI.Storage",
                        version: 1,
                        method: "set_fast_repair_config",
                        params: {
                            is_fast_repair_enable: i,
                            is_auto_scrubbing_enable: i
                        }
                    })
                }
                e && t.push({
                    api: "SYNO.Storage.CGI.Storage",
                    version: 1,
                    method: "set_auto_repair_config",
                    params: this.getAutoRepairParams()
                });
                var s = function() {
                        this.ownerCt.setStatusBusy(), SYNO.API.Request({
                            compound: {
                                params: t
                            },
                            callback: function(e, t, i, s) {
                                this.ownerCt.clearStatusBusy(), e && !t.has_fail ? this.ownerCt.forceClose() : this.ownerCt.getMsgBox().alert("", _T("common", "commfail"))
                            },
                            scope: this
                        })
                    },
                    a = this.getField("auto_repair_enable");
                e && a.isDirty() && a.getValue() ? this.ownerCt.getMsgBox().confirm(this.title, _T("storage_pool", "auto_repair_confirm_desc"), function(e) {
                    "yes" === e ? s.call(this) : a.setValue(!1)
                }, this, {
                    yes: {
                        text: _T("common", "save")
                    },
                    no: {
                        text: _T("common", "cancel")
                    }
                }) : s.call(this)
            } else this.ownerCt.forceClose();
        else this.ownerCt.setStatusError({
            text: _T("common", "forminvalid"),
            clear: !0
        })
    }
});
