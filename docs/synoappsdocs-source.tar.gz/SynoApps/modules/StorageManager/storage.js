/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.StorageManager.Instance
 * @extends SYNO.SDS.AppInstance
 * Storage application instance class
 *
 */
Ext.define("SYNO.SDS.StorageManager.Instance", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.StorageManager.MainWindow",
    shouldNotifyMsg: function(e, t) {
        return !this.window || this.window.isDestroyed || !this.window.isVisible() || this.window.shouldNotifyMsg(e, t)
    }
}), Ext.define("SYNO.SDS.StorageManager.MainWindow", {
    extend: "SYNO.SDS.AppWindow",
    constructor: function(e) {
        var t = {
            update_err_count: 0,
            cls: SYNO.SDS.StorageUtils.isVDSM ? "syno-app-storage-manager is-vdsm" : "syno-app-storage-manager",
            width: 1200,
            height: 580,
            minWidth: 1200,
            minHeight: 580,
            defaultMaximized: !0,
            firstTime: !0,
            items: this.createVuePanel(e)
        };
        this.callParent([Ext.apply(t, e)]), this.addManagedComponent(this.vuePanel), this.mon(this, "beforeclose", this.onBeforeWindowClose.bind(this))
    },
    createVuePanel: function(e) {
        return this.vuePanel = new SYNO.SDS.VuePanel({
            vueClass: SYNO.SDS.StorageManager.Vue.StoragePanel,
            mountId: "storage-manager",
            layout: "fit",
            cls: "v-storage-manager",
            owner: this
        }), this.vuePanel
    },
    onOpen: function(e) {
        this.openParam = e, this.callParent(arguments), this.setStatusBusy(), this.cleanMask = !0, this.createPollTask(), this.startPollTask(), this.vuePanel._$vueInst.$refs.storagemgr.$emit("winopen")
    },
    onRequest: function(e) {
        this.callParent(arguments), this.checkModalOrMask() || (this.openParam = e, this.stopPollTask(), this.startPollTask())
    },
    onBeforeWindowClose: function() {
        return this.getVueInstance().close()
    },
    getVueInstance: function() {
        return this.vuePanel._$vueInst.$refs.storagemgr
    },
    createPollTask: function() {
        var e = this,
            t = {
                api: "SYNO.Storage.CGI.Storage",
                method: "load_info",
                version: 1,
                timeout: 6e5
            },
            a = [t, {
                api: "SYNO.Core.ISCSI.LUN",
                version: 1,
                method: "list",
                additional: ["is_action_locked", "is_mapped", "extent_size", "allocated_size", "status", "allow_bkpobj", "flashcache_status", "family_config", "sync_progress"]
            }];
        if (SYNO.SDS.SocketInst.register({
                api: "SYNO.Storage.CGI.Spare",
                version: 1,
                method: "list"
            }, function(t) {
                t && t.success && (e.hotSpares = t.data.hotSpares)
            }, !0), SYNO.SDS.StorageUtils.isSupportCableOverviewUI()) {
            var o = "";
            switch (SYNO.SDS.StorageUtils.getCableOverviewId()) {
                case "SYNO.SDS.StorageManager.DualHeadCableOverview.Main":
                    o = "DualEnclosure";
                    break;
                case "SYNO.SDS.StorageManager.DualChainCableOverview.Main":
                case "SYNO.SDS.StorageManager.CableOverview.Main":
                    o = "Enclosure";
                    break;
                default:
                    return void SYNO.Debug("no matching cable overview class")
            }
            a.push({
                api: "SYNO.Storage.CGI." + o,
                method: "load",
                version: 1
            })
        } else SYNO.SDS.StorageUtils.isSupportTaipeiOverviewUI() && a.push({
            api: "SYNO.Storage.CGI.TaipeiEnclosure",
            method: "load",
            version: 1
        });
        return SYNO.SDS.StorageUtils.isSHA && (a.push(SYNO.SDS.StorageUtils.ReplaceWebapiSHA(!0, Object.assign({}, t))), a.push({
            api: "SYNO.SHA.Util",
            method: "load_cluster_info",
            version: 1
        })), this.pollTask = this.pollTask || this.addWebAPITask({
            api: "SYNO.Entry.Request",
            version: 1,
            method: "request",
            compound: {
                mode: "parallel",
                params: a
            },
            interval: 6e3,
            callback: this.pollResultHandler,
            scope: this
        }), this.pollTask
    },
    stopPollTask: function() {
        this.pollTask && this.pollTask.stop()
    },
    startPollTask: function(e) {
        this.pollOnce = e, this.pollTask && this.pollTask.start()
    },
    pollResultHandler: function(e, t, a, o) {
        var i = this,
            s = this,
            n = this.getVueInstance();
        if (!e || s.pollShouldReportError(t)) {
            if (s.update_err_count += 1, s.update_err_count < 3) return void SYNO.Debug("tolerant connection fail, retry")
        } else s.update_err_count = 0;
        return s.cleanMask && (s.clearStatusBusy(), s.cleanMask = !1), s.pollOnce && (s.pollOnce = !1, s.pollTask.stop()), e ? s.pollShouldReportError(t) ? (Ext.each(t.result, function(e) {
            e.success || (SYNO.SDS.StorageUtils.HARemoteCheckErrParsing(e.error), SYNO.SDS.StorageUtils.ReportWebapiFailure(s, e.error))
        }), void s.stopPollTask()) : void(n && n.loadInfo(t, this.hotSpares).then(function() {
            i.openParam && i.handleOpenPage(), s.highlightNodeId && (s.getVueInstance().highlightNode(s.highlightNodeId), s.highlightNodeId = null), i.fireEvent("storageinfoloaded")
        })) : (s.getMsgBox().alert("", _T("error", "error_subject")), void s.pollTask.stop())
    },
    pollShouldReportError: function(e) {
        return !!e.has_fail && e.result.some(function(t) {
            return "SYNO.Core.ISCSI.LUN" !== t.api && !1 === e.success
        })
    },
    handleOpenPage: function() {
        if (!this.checkModalOrMask() && this.openParam) {
            var e = this.openParam,
                t = e.fn,
                a = e.tab,
                o = e.dlg,
                i = e.vueWizard,
                s = e.wizard,
                n = e.modalParam,
                r = e.windowParam,
                l = e.skipFirstTime;
            if (n = n || {}, t) {
                var u = {
                    diskPanel: "disk-tab",
                    general: "settings-tab"
                } [a];
                u && (a = u), this.getVueInstance().openPage(t, a)
            }
            if (o) "FirmwareUpgrade" === o && (o = "SYNO.SDS.StorageManager.Wizard.FirmwareUpgrade", n = Object.assign(n, {
                requireDiskMap: !0,
                requirePassiveDiskMapIfSHA: !0
            })), this.getVueInstance().openWindow(o, n, r);
            else if (i) {
                var S = this.getVueInstance();
                Object.keys(SYNO.SDS.StorageManager.Vue).some(function(e) {
                    return i === e
                }) || (i = "CreateWizardWindow");
                var d = "SYNO.SDS.StorageManager.Vue.".concat(i),
                    h = null,
                    p = null;
                if ("CreateWizardWindow" === i) {
                    p = S.openWindow(d, null, {
                        openVueWin: !0,
                        fromVueWin: !1
                    }).component;
                    if (!n || !["pool", "volume", "both"].some(function(e) {
                            return n.mode === e
                        }) || "string" != typeof n.title) {
                        var c = 0 < S.pools.length;
                        (n = {}).mode = c ? "volume" : "both", n.title = c ? _T("volume", "create_volume") : _T("storage_pool", "wizard_title_create_both")
                    }
                    p.setMode(n.mode), p.title = n.title
                } else if ("ManageIdleDriveWindow" === i) {
                    if (S.disks.some(function(e) {
                            return e.isIdle().result
                        })) {
                        var g = S.openWindow(d, null, {
                            openVueWin: !0,
                            fromVueWin: !1
                        });
                        h = g.window, (p = g.component).$root.$options.window = h
                    } else S.getRootWindow().getMsgBox().alert("", _T("disk_info", "no_free_disk_to_manage"))
                }
            } else s ? this.getVueInstance().openWizard(s, n) : !l && this.firstTime && (this.getVueInstance().checkIfOpenFirstTimeWizard(), this.firstTime = !1);
            this.openParam = null
        }
    }
});
