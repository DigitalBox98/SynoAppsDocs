/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.namespace("SYNO.SDS.StorageUtils"), Ext.namespace("SYNO.SDS.StorageManager.StoragePool"), Ext.namespace("SYNO.SDS.StorageManager.StorageTaipeiOverview"), 
 /**
 * @class SYNO.SDS.StorageManager.StoragePool.RaidLevelDesc
 * StorageManager storage pool raid level desc class
 *
 */  
SYNO.SDS.StorageManager.StoragePool.RaidLevelDesc = {
    shr: {
        min: 1,
        max: 65536,
        raidGroup: !1
    },
    shr_2: {
        min: 4,
        max: 65536,
        raidGroup: !1
    },
    raid_1: {
        min: 2,
        max: 4,
        raidGroup: !1
    },
    raid_5: {
        min: 3,
        max: 65536,
        raidGroup: !0
    },
    raid_6: {
        min: 4,
        max: 65536,
        raidGroup: !0
    },
    raid_f1: {
        min: 3,
        max: 65536,
        raidGroup: !0
    },
    raid_10: {
        min: 4,
        max: 65536,
        raidGroup: !1
    },
    raid_0: {
        min: 2,
        max: 65536,
        raidGroup: !1
    },
    basic: {
        min: 1,
        max: 1,
        raidGroup: !1
    },
    raid_linear: {
        min: 1,
        max: 65536,
        raidGroup: !1
    }
}, SYNO.SDS.StorageUtils = function() {
    var e = SYNO.SDS.Utils.StorageUtils.UiRenderHelper,
        t = null,
        r = !1;
    return {
        SpaceIDParser: SYNO.SDS.Utils.StorageUtils.SpaceIDParser,
        GetSizeGB: SYNO.SDS.Utils.StorageUtils.GetSizeGB,
        SizeRenderWithFloor: e.SizeRenderWithFloor,
        GetSizeUnitWithFloor: e.GetSizeUnitWithFloor,
        SizeRender: e.SizeRender,
        GetSizeUnit: e.GetSizeUnit,
        StatusRender: e.StatusRender,
        StatusNameRender: e.StatusNameRender,
        PlainStatusNameRender: e.PlainStatusNameRender,
        ProgressRender: e.ProgressRender,
        WarningTextRender: e.WarningTextRender,
        StepNameRender: e.StepNameRender,
        PercentRender: e.PercentRender,
        RaidLevelRender: e.RaidLevelRender,
        SpaceTypeRender: e.SpaceTypeRender,
        DeviceTypeRender: e.DeviceTypeRender,
        ParseID: e.ParseID,
        DiskIDRender: e.DiskIDRender,
        DiskStatusRender: e.DiskStatusRender,
        DiskStatusTooltipRender: e.DiskStatusTooltipRender,
        DiskSwapStatusRender: e.DiskSwapStatusRender,
        smartStatusRender: e.smartStatusRender,
        DiskTypeRender: e.DiskTypeRender,
        AddDiskTypeRender: e.AddDiskTypeRender,
        MigrateTypeRender: e.MigrateTypeRender,
        TargetStatusRender: e.TargetStatusRender,
        SpareStatusRender: e.SpareStatusRender,
        SnapShotStatusRender: e.SnapShotStatusRender,
        getErrorMsg: e.getErrorMsg,
        decodeResponse: e.decodeResponse,
        htmlEncoder: e.htmlEncoder,
        htmlDecoder: e.htmlDecoder,
        getServiceNames: e.getServiceNames,
        getVolumeNames: e.getVolumeNames,
        getNamesString: e.getNamesString,
        disableServices: e.disableServices,
        DiskTemperatureRender: e.DiskTemperatureRender,
        DiskSummaryStatusRender: e.DiskSummaryStatusRender,
        SBTimeStringFormatRender: e.SBTimeStringFormatRender,
        SBTimeStringRender: e.SBTimeStringRender,
        RemainLifeRender: e.RemainLifeRender,
        RemainLifeRenderOld: e.RemainLifeRenderOld,
        BadSecCtRender: e.BadSecCtRender,
        advStatusRender: e.advStatusRender,
        smartTestStatusRender: e.smartTestStatusRender,
        textAnimate: e.textAnimate,
        setUpdateTimeAnimate: e.setUpdateTimeAnimate,
        WarningTitleStringGet: e.WarningTitleStringGet,
        DiskOverviewStatusRender: e.DiskOverviewStatusRender,
        DiskTestLogRender: e.DiskTestLogRender,
        DiskPredictionMainFactorRender: e.DiskPredictionMainFactorRender,
        DiskWddaRender: e.DiskWddaRender,
        DiskCompatibilityGet: e.DiskCompatibilityGet,
        DiskOverviewStatusRenderMap: e.DiskOverviewStatusRenderMap,
        DiskStatusRenderMap: e.DiskStatusRenderMap,
        DriveFirmwareRender: e.DriveFirmwareRender,
        supportRaid: "yes" === _D("supportraid", "no"),
        supportDiffRaid: "yes" === _D("support_diffraid", "no"),
        supportSas: "yes" === _D("supportsas", "no"),
        supportRaidGroup: "yes" === _D("supportraidgroup", "no"),
        supportHotSpare: "yes" === _D("support_hotspare", "no"),
        supportSsdCache: "yes" === _D("support_ssd_cache", "no"),
        supportFastRepair: "yes" === _D("support_fast_repair", "no"),
        supportHA: "yes" === _D("support_ha", "no"),
        supportBtrfs: "yes" === _D("support_btrfs", "no"),
        supportExt4: "yes" === _D("supportext4", "no"),
        supportDualHead: "yes" === _D("support_dual_head", "no"),
        expansionHostPort: _D("host_wide_port_count", 0),
        disableSnapUI: "yes" === _D("support_dr_snap", "no"),
        isXA: "yes" === _D("support_xa", "no"),
        isSHA: _S("ha_running") && "yes" !== _D("support_xa", "no"),
        isVDSM: "kvmx64" === _D("synobios") || "nextkvmx64" === _D("synobios") || "kvmcloud" === _D("synobios"),
        supportISCSI: "yes" === _D("support_iscsi_target", "no"),
        maxDiskCntNoGroup: function() {
            return this.supportRaidGroup ? 24 : 65536
        },
        isSingleBay: function() {
            return 1 === parseInt(_D("maxdisks", 1), 10)
        },
        setHasAnyEboxPool: function(e) {
            r = e
        },
        hasEbox: function() {
            return !(!this.isSingleBay() || !r) || this.isSupportEbox() && this.isEboxPluged()
        },
        isSingleBayWithEbox: function() {
            return this.isSingleBay() && this.hasEbox()
        },
        isSingleBayWithoutEbox: function() {
            return this.isSingleBay() && !this.hasEbox()
        },
        isAllFlashModel: function() {
            return /^fs[0-9]*/i.test(_D("upnpmodelname"))
        },
        setEnv: function(e) {
            t = e
        },
        getEnv: function() {
            return t
        },
        isSupportSHR: function() {
            return t && t.support.sysdef
        },
        isSupportRaidCross: function() {
            return t && t.support.raid_cross
        },
        isSupportEbox: function() {
            return t && t.support.ebox
        },
        isSupportSysRaidCustomization: function() {
            return "yes" === _D("support_dual_head", "no") || 5 <= SYNO.SDS.StorageUtils.getBayNumber()
        },
        isEboxPluged: function() {
            return t && t.eunits && t.eunits.length
        },
        isSupportCableOverviewUI: function() {
            var e = SYNO.SDS.StorageUtils;
            return e.supportSas && 2 <= Number(e.expansionHostPort) || e.supportDualHead
        },
        isSupportTaipeiOverviewUI: function() {
            return "yes" === _D("support_cable_overview", "no") && "yes" === _D("supportsas", "no")
        },
        getCableOverviewId: function() {
            var e = SYNO.SDS.StorageUtils,
                t = null;
            return e.isSupportCableOverviewUI() ? t = e.supportDualHead ? "SYNO.SDS.StorageManager.DualHeadCableOverview.Main" : _S("is_dual_chain") ? "SYNO.SDS.StorageManager.DualChainCableOverview.Main" : "SYNO.SDS.StorageManager.CableOverview.Main" : e.isSupportTaipeiOverviewUI() && (t = "SYNO.SDS.StorageManager.TaipeiCableOverview.Main"), t
        },
        getBayNumber: function() {
            return t ? parseInt(t.bay_number, 10) : 1
        },
        getMaxVolumeSize: function() {
            return t ? "yes" === _D("unlimited_volume_size") ? 72057594037927940 : SYNO.SDS.StorageUtils.supportRaidGroup && t.ram_enough_for_fs_high_end ? parseInt(t.max_fs_bytes_high_end, 10) : parseInt(t.max_fs_bytes, 10) : 0
        },
        isUpToHASpaceSizeLimit: function(e) {
            if (!t || !t.space_size_limit.is_limited) return !1;
            var r = function(e) {
                    return SYNO.SDS.StorageUtils.GetSizeGB(parseInt(e, 10), 0)
                },
                i = this.getAllocatableSpaceSize();
            return void 0 !== e ? r(i) < r(e) : 0 === i
        },
        getHASpaceSizeLimitStr: function() {
            return t ? SYNO.SDS.StorageUtils.SizeRender(t.space_size_limit.size_limit) : SYNO.SDS.StorageUtils.SizeRender(439804651110400)
        },
        getAllocatableSpaceSize: function() {
            return t ? parseInt(t.space_size_limit.allocatable_size, 10) : 0
        },
        isUpToBatchTaskCount: function() {
            return !(!t || !t.batchtask || void 0 === t.batchtask.remain_task || 0 !== t.batchtask.remain_task)
        },
        getMaxBatchTaskCount: function() {
            if (t && t.batchtask && void 0 !== t.batchtask.max_task) return t.batchtask.max_task
        },
        updateItemContent: function(e) {
            var t = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.StorageManager.Instance")[0];
            t && e && e.itemType && e.props && t.window.getVueInstance().$store.dispatch("PoolModule/updateItemByKey", e)
        },
        getDiskStepDesc: function(e, t, r, i, a, n, s) {
            var o = Object.assign({
                RAIDTypeLabel: "",
                minNewDiskCount: ""
            }, s);
            return e.needNewDisk ? this.getDiskStepDescStr(e.isAddMirror, t, r, i, a, n, o) : String.format(_T("storage_pool", "wizard_diskstep_" + t + "_without_new_disk"), '<span class="' + o.RAIDTypeLabel + '">' + n.RAIDTypeLabel + "</span>")
        },
        getDiskStepDescStr: function(e, t, r, i, a, n, s) {
            var o, S = ["cache_create", "cache_repair"].some(function(e) {
                    return e === t
                }) ? "volume" : "storage_pool",
                d = 1 < (a = Math.max(1, a)) ? "multiple" : "single",
                p = i > a ? "_atleast" : "",
                u = e ? "_mirror" : "",
                l = [];
            switch (l.push('<span class="' + s.minNewDiskCount + '">' + a + "</span>"), t) {
                case "create":
                case "cache_create":
                    l.push('<span class="' + s.RAIDTypeLabel + '">' + n.RAIDTypeLabel + "</span>");
                    break;
                case "add":
                case "repair":
                case "convert":
                case "unfinish_shr":
                    l.push(n.currentPoolNumID);
                    break;
                case "cache_repair":
                    l.push(n.currentCacheNumID);
                    break;
                case "migrate":
                    l.push(n.currentPoolNumID), l.push('<span class="' + s.RAIDTypeLabel + '">' + n.RAIDTypeLabel + "</span>")
            }
            return o = "wizard_diskstep_" + t + "_" + r + "_" + d + p + u, String.format(_T(S, o), l[0], l[1], l[2])
        },
        getEstimateSizeHtml: function(e, t, r, i, a, n, s) {
            var o = "",
                S = "",
                d = "",
                p = "",
                u = "bold-text",
                l = Ext.isNumber(s.curDiskCnt) && Ext.isNumber(s.newSelectCnt),
                _ = l && "shr" === n && 1 === s.curDiskCnt && 1 === s.newSelectCnt && s.isAddDisk,
                c = l && "shr" === n && 0 === s.curDiskCnt && 2 === s.newSelectCnt && s.isCreateNewPool,
                m = l && 1 == (s.curDiskCnt + s.newSelectCnt) % 2,
                g = "raid_10" === n && m;
            return t ? (S = 1 < i ? "wizard_disk_step_reach_disk_limit_multiple" : "wizard_disk_step_reach_disk_limit_single", d = "red-status", o = String.format(_T("storage_pool", S), i)) : 1 < a ? o = String.format(_T("storage_pool", "wizard_disk_step_" + e + "_more_disks"), a) : 1 === a ? o = s.isReplace ? _T("storage_pool", "wizard_replace_choose_replacing_disk_to_continue") : _T("storage_pool", "wizard_disk_step_" + e + "_one_more_disk") : g ? o = _T("storage_pool", "wizard_disk_step_" + e + "_one_more_disk") : (o = r.size + " " + r.unit, u = s.styleClass || "bold-text", _ ? p = String.format(' <span ext:qtip="{0}">{0}</span>', _T("storage_pool", "wizard_disk_step_capacity_not_increase")) : c && (p = String.format(' <span ext:qtip="{0}">{0}</span>', _T("storage_pool", "wizard_disk_step_create_shr_capacity_hint")))), String.format('<span class="{0} {1}">{2}</span>{3}', u, d, o, p)
        }
    }
}(), SYNO.SDS.StorageUtils.TipRenderer = function(e, t) {
    return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(e)) + '"', Ext.util.Format.htmlEncode(e)
}, SYNO.SDS.StorageUtils.check = function() {
    var e, t;
    for (e = 0; e < arguments.length; e++) {
        if (t = arguments[e], Ext.isFunction(t) && !t.call(this)) return !1;
        if (Ext.isString(t) && !this[t]()) return !1
    }
    return !0
}, SYNO.SDS.StorageUtils.isAnyMatched = function() {
    var e = arguments;
    return -1 !== this.findBy(function(t) {
        return t.check.apply(t, e)
    })
}, SYNO.SDS.StorageUtils.getMatched = function() {
    var e, t, r = arguments,
        i = [];
    for (e = 0; e < this.getCount(); e++)(t = this.getAt(e)).check.apply(t, r) && i.push(t);
    return i
}, SYNO.SDS.StorageUtils.FormatSuggestion = function(e) {
    var t = void 0 !== e.section ? e.section : "volume",
        r = _T(t, e.str),
        i = e.arg;
    return null == i ? r : r.replace(/\{(\d+)\}/g, function(e, t) {
        return i[t]
    })
}, SYNO.SDS.StorageUtils.FormatSizeSuggestion = function(e) {
    var t = void 0 !== e.section ? e.section : "volume",
        r = _T(t, e.str),
        i = e.arg;
    return null == i ? r : r.replace(/\{(\d+)\}/g, function(e, t) {
        return "number" == typeof i[t] ? SYNO.SDS.StorageUtils.SizeRender(i[t]) : i[t]
    })
}, SYNO.SDS.StorageUtils.HARemoteCheckErrParsing = function(e) {
    var t = [],
        r = e.errors;
    _S("ha_running") && void 0 !== r && (void 0 !== r.ha_remote_empty_err_disks && 0 < r.ha_remote_empty_err_disks.length && t.push(String.format(_TT("SYNO.SDS.HA.Instance", "wizard", "error_disk_empty"), r.ha_remote_empty_err_disks.map(SYNO.SDS.HA.HADiskIndexRenderer).join(", "))), void 0 !== r.ha_remote_forbidden_err_disks && 0 < r.ha_remote_forbidden_err_disks.length && t.push(String.format(_TT("SYNO.SDS.HA.Instance", "wizard", "error_disk_forbidden"), r.ha_remote_forbidden_err_disks.map(SYNO.SDS.HA.HADiskIndexRenderer).join(", "), r.ha_remote_hostname)), void 0 !== r.ha_remote_deactivate_err_disks && 0 < r.ha_remote_deactivate_err_disks.length && t.push(String.format(_TT("SYNO.SDS.HA.Instance", "wizard", "error_disk_deactivate"), r.ha_remote_deactivate_err_disks.map(SYNO.SDS.HA.HADiskIndexRenderer).join(", "), r.ha_remote_hostname)), void 0 !== r.ha_remote_smart_err_disks && 0 < r.ha_remote_smart_err_disks.length && t.push(String.format(_TT("SYNO.SDS.HA.Instance", "wizard", "error_disk_smart"), r.ha_remote_smart_err_disks.map(SYNO.SDS.HA.HADiskIndexRenderer).join(", "), r.ha_remote_hostname)), void 0 !== r.ha_remote_size_err_disks && 0 < r.ha_remote_size_err_disks.length && t.push(String.format(_TT("SYNO.SDS.HA.Instance", "wizard", "error_disk_size"), r.ha_remote_size_err_disks.map(SYNO.SDS.HA.HADiskIndexRenderer).join(", "))), void 0 !== r.ha_remote_type_err_disks && 0 < r.ha_remote_type_err_disks.length && t.push(String.format(_TT("SYNO.SDS.HA.Instance", "wizard", "error_disk_type"), r.ha_remote_type_err_disks.map(SYNO.SDS.HA.HADiskIndexRenderer).join(", "))), void 0 !== r.ha_remote_log_sect_size_err_disks && 0 < r.ha_remote_log_sect_size_err_disks.length && t.push(String.format(_TT("SYNO.SDS.HA.Instance", "wizard", "error_disk_log_sect_size"), r.ha_remote_log_sect_size_err_disks.map(SYNO.SDS.HA.HADiskIndexRenderer).join(", "))), !0 === r.ha_remote_offline && t.push(_TT("SYNO.SDS.HA.Instance", "ui", "error_passive_not_online")), !0 === r.ha_remote_space_failed && t.push(_TT("SYNO.SDS.HA.Instance", "wizard", "error_passive_space_unmatched")), !0 === r.ha_remote_memory_size_mismatch && t.push(_TT("SYNO.SDS.HA.Instance", "ui", "error_fcache_memsize")), e.text = t.join("<br><br>"), "" === e.text && (e.text = _TT("SYNO.SDS.HA.Instance", "common", "error_system")))
}, SYNO.SDS.StorageUtils.CheckFailedMsg = function(e) {
    var t, r, i = "pass";
    if (!e) return i;
    for (t in e)
        if (e.hasOwnProperty(t)) {
            if ("hard_failed" === i) break;
            for (r in e[t])
                if (e[t].hasOwnProperty(r)) {
                    if (e[t][r].hard) {
                        i = "hard_failed";
                        break
                    }
                    e[t][r].soft && (i = "soft_failed")
                }
        } return i
}, SYNO.SDS.StorageUtils.UpdateGridCheckMsg = function(e, t, r) {
    var i, a;
    for (i = 0; i < t.length; ++i) a = SYNO.SDS.Utils.GetFeasibilityCheckMsg(t[i]), 0 === i ? r.append(e, a) : r.append("", a)
}, SYNO.SDS.StorageUtils.CheckMsg = function(e, t, r, i) {
    var a, n, s = SYNO.SDS.StorageUtils;
    if (e && e[r])
        for (a in e[r]) e[r].hasOwnProperty(a) && (n = "volumes" === r ? SYNO.SDS.Utils.StorageUtils.VolumeNameRenderer(a) : "pools" === r ? SYNO.SDS.Utils.StorageUtils.SpaceIDParser(a).str : a, t ? e[r][a].hard && s.UpdateGridCheckMsg(n, e[r][a].hard, i) : e[r][a].soft && s.UpdateGridCheckMsg(n, e[r][a].soft, i))
}, SYNO.SDS.StorageUtils.ReportWebapiFailure = function(e, t, r) {
    var i, a;
    void 0 !== t && void 0 !== e && (i = "string" == typeof t.text ? t.text : t.errors ? this.getErrorMsg(t.errors) : _T("error", "error_subject"), a = [].slice.call(arguments, SYNO.SDS.StorageUtils.ReportWebapiFailure.length), SYNO.SDS.StorageUtils.getMsgBox(e, "alert", e.title, i, function(t) {
        r && r.apply(e, a)
    }, e))
}, SYNO.SDS.StorageUtils.SortFnByTypeAndID = function(e, t, r, i) {
    if (!(r instanceof Function && Array.isArray(i))) return 0;
    var a = r(e),
        n = r(t);
    return a.type === n.type ? a.id - n.id : i.indexOf(a.type) - i.indexOf(n.type)
}, SYNO.SDS.StorageUtils.PoolSort = function(e, t) {
    return SYNO.SDS.StorageUtils.SortFnByTypeAndID(e, t, function(e) {
        return e ? e.isMissingPool ? {
            type: "missingPool",
            id: +e.num_id
        } : e.isDetectedPool ? {
            type: "detectedPool",
            id: +e.num_id
        } : e.isPool() ? {
            type: "normalPool",
            id: +e.num_id
        } : {
            type: "invalidInput",
            id: 0
        } : {
            type: "invalidInput",
            id: 0
        }
    }, ["normalPool", "detectedPool", "missingPool", "invalidInput"])
}, SYNO.SDS.StorageUtils.VolumeSort = function(e, t) {
    return SYNO.SDS.StorageUtils.SortFnByTypeAndID(e, t, function(e) {
        return e && e.isVolume() ? {
            type: "normalVolume",
            id: +e.num_id
        } : {
            type: "invalidInput",
            id: 0
        }
    }, ["normalVolume", "invalidInput"])
}, SYNO.SDS.StorageUtils.DiskSort = function(e, t) {
    var r, i, a, n, s, o, S, d, p, u;
    if (!e || !t) return e ? -1 : t ? 1 : 0;
    if (Ext.isFunction(e.get) && Ext.isFunction(t.get) ? (r = e.get("num_id"), i = t.get("num_id"), a = e.get("container").type, n = t.get("container").type, s = e.get("container").order, o = t.get("container").order, S = "cache" === e.get("portType") ? 2 : 1, d = "cache" === t.get("portType") ? 2 : 1, p = e.get("pciSlot"), u = t.get("pciSlot")) : (r = e.numId, i = t.numId, a = "internal", n = "internal", s = e.ctnOrder, o = t.ctnOrder, S = "cache" === e.portType ? 2 : 1, d = "cache" === t.portType ? 2 : 1, p = e.pciSlot, u = t.pciSlot), a !== n) {
        if ("ebox" === a) return 1;
        if ("ebox" === n) return -1;
        if ("internal" === a) return 1;
        if ("internal" === n) return -1
    }
    return s > o ? 1 : s < o ? -1 : S > d ? 1 : S < d ? -1 : p > u ? 1 : p < u ? -1 : r > i ? 1 : r < i ? -1 : 0
}, SYNO.SDS.StorageUtils.getDefaultCompareFunc = function(e) {
    return function(t, r) {
        var i, a;
        return e.fn ? (i = e.fn(t), a = e.fn(r)) : e.getHtml ? (i = e.getHtml(t), a = e.getHtml(r)) : (i = t[e.field], a = r[e.field]), "DESC" === e.sort ? i < a ? 1 : -1 : "ASC" === e.sort ? i < a ? -1 : 1 : 0
    }
}, SYNO.SDS.StorageUtils.IsFeasibilityFail = function(e, t) {
    return !!(e.errors && e.errors.feasibility && (t.soft = e.errors.feasibility.soft || [], t.hard = e.errors.feasibility.hard || [], t.soft.length > 0 || t.hard.length > 0))
}, SYNO.SDS.StorageUtils.getMsgBox = function(e, t, r, i, a, n) {
    var s, o, S = this;
    if (a = a || function() {}, e.getMsgBox) s = e, o = e.getMsgBox;
    else if (e.owner && e.owner.getMsgBox) s = e.owner, o = e.owner.getMsgBox;
    else {
        if (!e.$options.owner || !e.$optoins.owner.getMsgBox) throw Error("Does not found 'getMsgBox'");
        s = e.$options.owner, o = e.$options.owner.getMsgBox
    }
    s._isVue ? o.call(s)[t]("", i, null, {
        isHtmlContent: !0
    }).then(function(e) {
        "confirm" === e && (e = "yes"), a.apply(n || S, [e])
    }) : o.call(s)[t]("", i, a.bind(n || this), n || this, null, {
        maxWidth: 420
    })
}, SYNO.SDS.StorageUtils.ConfirmFeasibilityFail = function(e, t, r) {
    var i, a, n, s = [];
    if (!e) throw Error("No window");
    0 < t.hard.length ? (t.hard.forEach(function(e) {
        n = SYNO.SDS.Utils.GetFeasibilityCheckMsg(e), s.push(n)
    }), i = String.format("{0}</br></br>{1}", _T("volume", "hard_check_fail"), s.join("</br>")), SYNO.SDS.StorageUtils.getMsgBox(e, "alert", e.title, i)) : 0 < t.soft.length && (t.soft.forEach(function(e) {
        n = SYNO.SDS.Utils.GetFeasibilityCheckMsg(e), s.push(n)
    }), i = String.format("{0}</br></br>{1}", _T("volume", "soft_check_fail"), s.join("</br>")), a = [].slice.call(arguments, SYNO.SDS.StorageUtils.ConfirmFeasibilityFail.length), SYNO.SDS.StorageUtils.getMsgBox(e, "confirm", e.title, i, function(t) {
        "yes" === t && r.apply(e, a)
    }, e))
}, SYNO.SDS.StorageUtils.DiskDisplayNameGet = function(e, t) {
    var r = SYNO.SDS.Utils.StorageUtils.UiRenderHelper;
    return e.hasOwnProperty("i18nNamingInfo") ? r.DiskDisplayNameGet(e.i18nNamingInfo, t) : r.DeprecatedDiskDisplayNameGet(e.name, t, e.pciSlot, e.num_id, e.isCacheTray())
}, SYNO.SDS.StorageUtils.DiskNameHashValueGet = function(e, t, r) {
    return 1e3 * e + 100 * ("cache" === r ? 2 : 1) + t
}, SYNO.SDS.StorageUtils.ReplaceWebapiSHA = function(e, t) {
    if (e) {
        var r = {
            remote_api: t.api,
            remote_method: t.method,
            remote_version: t.version,
            remote_params: t.params,
            remote_download: !1
        };
        t.api = "SYNO.SHA.Util", t.method = "send_remote_webapi", t.version = 1, t.params = r
    }
    return t
}, SYNO.SDS.StorageUtils.ReplaceWebapiSHADownload = function(e, t) {
    if (e) {
        var r = {
            remote_api: t.api,
            remote_method: t.method,
            remote_version: t.version,
            remote_params: t.params,
            remote_download: !0
        };
        t.api = "SYNO.SHA.Util", t.method = "send_remote_webapi", t.version = 1, t.params = r
    }
    return t
}, SYNO.SDS.StorageUtils.RAIDDiskMinMaxCountGet = function(e, t) {
    var r, i, a = SYNO.SDS.StorageManager.StoragePool.RaidLevelDesc[e];
    return r = a.max, i = a.min, t === parseInt(t, 10) && (r = Math.min(r, t)), "yes" === _D("supportraidgroup", "no") && "raid_linear" === e && (i = 2), {
        max: r,
        min: i,
        raidGroup: a.raidGroup
    }
}, SYNO.SDS.StorageUtils.GetEboxBayNumber = function(e) {
    var t, r, i;
    return 2 != (t = e.split("-")).length || 3 > t[0].length ? 0 : (r = t[0].match(/\d+/)) && 0 !== r.length ? (i = parseInt(r[0].substr(0, r[0].length - 2), 10), isNaN(i) ? 0 : i) : 0
}, SYNO.SDS.StorageUtils.StatusPriorityGet = function(e, t) {
    return "volume" === e && "crashed" === t ? 1 : "volume" === e && "read_only" === t ? 2 : "pool" === e && "crashed" === t ? 3 : "cache" === e && "write_crash" === t ? 4 : "pool" === e && "error" === t ? 5 : "volume" === e && "degrade" === t ? 6 : "pool" === e && "degrade" === t ? 7 : "cache" !== e || "read_crash" !== t && "write_bypass" !== t ? "cache" === e && "degrade" === t ? 9 : Number.MAX_VALUE : 8
}, SYNO.SDS.StorageUtils.ResizePanel = function(e, t) {
    var r = 240,
        i = 47;
    t ? e.container.setStyle("padding", "0px") : (e.container.setStyle("padding", "16px 16px 0 16px"), r += 32, i += 16), e.container.setSize(e.appWin.getWidth() - 240, e.appWin.getHeight() - 47), e.setSize(e.appWin.getWidth() - r, e.appWin.getHeight() - i), e.doLayout()
}, SYNO.SDS.StorageUtils.DataViewToolTipsAdd = function(e) {
    var t = e ? e.getEl() : null,
        r = t ? t.query(".sm-tip-placeholder") : [];
    Ext.each(r, function(e) {
        SYNO.ux.AddTip(e, e.getAttribute("tip")).childNodes.forEach(function(e) {
            e.style = "vertical-align: middle; position: relative;"
        })
    })
}, SYNO.SDS.StorageManager.StorageTaipeiOverview.LinkType = {
    UNCHECK: -1,
    IN: 1,
    OUT: 2,
    NO: 3,
    ILLEGAL: 4,
    NEED_CONNECT: 5
}, SYNO.SDS.StorageUtils.ControllerToString = function(e) {
    return !Ext.isNumber(e) || e < 0 ? "" : String.fromCharCode("A".charCodeAt(0) + e)
}, SYNO.SDS.StorageUtils.ControllerRenderer = function(e, t) {
    var r = SYNO.SDS.StorageUtils.ControllerToString(e);
    return r ? (t = t || _T("volume", "controller_i"), String.format(t, r)) : "-"
}, SYNO.SDS.StorageUtils.IsOnlySupportSas = function() {
    return "yes" === _D("support_dual_head", "no") || "yes" === _D("support_xa", "no")
}, SYNO.SDS.StorageUtils.GenDiskObj = function(e) {
    var t = new SYNO.SDS.StorageManager.Disk.Object;
    return t.json = e, t.id = e.id, t
};
