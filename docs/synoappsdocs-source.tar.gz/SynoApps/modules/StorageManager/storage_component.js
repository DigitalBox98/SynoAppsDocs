/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.namespace("SYNO.SDS.StorageManager"), 
/**
 * @class SYNO.SDS.StorageManager.Dialog.Confirm
 * @extends SYNO.SDS.ModalWindow
 * StorageManager dialog confirm class
 *
 */
Ext.define("SYNO.SDS.StorageManager.Dialog.Confirm", {
    extend: "SYNO.SDS.ModalWindow",
    owner: null,
    checkboxID: null,
    okButtonID: null,
    next_id: null,
    callbackAutoClose: !0,
    noDeleteIcon: !1,
    constructor: function(t) {
        var e = this;
        e.appWin = t.appWin, e.owner = t.owner, e.next_id = t.next_id, e.callback = t.callback, e.params = t.params, e.needPassword = t.needPassword, e.winWidth = void 0 !== t.winWidth ? t.winWidth : 480, e.callbackAutoClose = void 0 !== t.callbackAutoClose ? t.callbackAutoClose : e.callbackAutoClose, e.noDeleteIcon = void 0 !== t.noDeleteIcon ? t.noDeleteIcon : e.noDeleteIcon, e.callParent([e.getConfig(t)]), Ext.getCmp(this.okButtonID).setDisabled(void 0 !== t.checkBoxText), e.noDeleteIcon || this.addClass("confirm-delete-icon")
    },
    getConfig: function(t) {
        var e = [];
        return e.push("->"), e.push({
            text: t.buttons && t.buttons.no ? t.buttons.no : _T("common", "close"),
            xtype: "syno_button",
            scope: this,
            handler: function() {
                Ext.isFunction(this.callback) && this.callback(!1), this.close()
            }
        }), e.push({
            xtype: "syno_button",
            btnStyle: t.noDeleteIcon ? "blue" : "red",
            text: t.buttons && t.buttons.yes ? t.buttons.yes : _T("common", "ok"),
            cls: "syno-ux-button-blue",
            id: this.okButtonID = Ext.id(),
            scope: this,
            handler: this.onClickOKButton
        }), Ext.apply({
            width: this.winWidth,
            autoHeight: !0,
            layout: "fit",
            cls: "x-window-dlg sm-storage-warning-dlg",
            fbar: e,
            header: !1,
            draggable: !1,
            elements: "body",
            padding: t.noDeleteIcon ? "24px 30px 0 30px" : "44px 30px 0 30px",
            resizable: !1,
            items: [{
                xtype: "syno_panel",
                autoHeight: !0,
                items: [{
                    xtype: "syno_displayfield",
                    value: t.title,
                    cls: "sm-storage-warning-dlg-title no-margin-title",
                    hidden: void 0 === t.title
                }, {
                    xtype: "syno_displayfield",
                    htmlEncode: !1,
                    hideLabel: !0,
                    value: t.warningMsg
                }, {
                    xtype: "syno_checkbox",
                    id: this.checkboxID = Ext.id(),
                    htmlEncode: !1,
                    boxLabel: t.checkBoxText,
                    hideLabel: !0,
                    handler: this.onClickConfirmReadingCheckbox,
                    hidden: void 0 === t.checkBoxText,
                    scope: this
                }]
            }]
        }, t)
    },
    onClickConfirmReadingCheckbox: function() {
        !0 === Ext.getCmp(this.checkboxID).getValue() ? Ext.getCmp(this.okButtonID).setDisabled(!1) : Ext.getCmp(this.okButtonID).setDisabled(!0)
    },
    onClickOKButton: function() {
        var t = this;
        Ext.isFunction(t.callback) && (!0 === t.needPassword ? SYNO.SDS.Utils.PasswordConfirmDialog.openDialog(t, t.callback, [!0, t.params]) : t.callback(!0, t.params)), t.next_id && t.owner.goNext(t.next_id), !0 === t.callbackAutoClose && t.close()
    }
}), Ext.define("SYNO.SDS.StorageManager.Dialog.Warning", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(t) {
        var e = this;
        e.callback = t.callback, e.noDeleteIcon = !!t.noDeleteIcon, e.callParent([e.getConfig(t)]), e.noDeleteIcon || this.addClass("confirm-delete-icon")
    },
    getConfig: function(t) {
        var e = this,
            i = [],
            s = [];
        return i.push({
            xtype: "syno_button",
            text: t.btns && t.btns.no && t.btns.no.text ? t.btns.no.text : _T("common", "no"),
            scope: this,
            handler: this.onClickNoButton
        }), i.push({
            xtype: "syno_button",
            btnStyle: t.btns && t.btns.yes && t.btns.yes.btnStyle ? t.btns.yes.btnStyle : "red",
            text: t.btns && t.btns.yes && t.btns.yes.text ? t.btns.yes.text : _T("common", "yes"),
            scope: this,
            handler: this.onClickYesButton
        }), e.msgWidth = t.msgWidth ? t.msgWidth : 600, s.push({
            xtype: "syno_displayfield",
            itemId: "msg1",
            cls: "sm-disk-alert-field",
            width: e.msgWidth,
            value: t && t.msgs[0] && t.msgs[0].html ? t.msgs[0].html : "",
            htmlEncode: !1
        }), s.push({
            xtype: "syno_panel",
            itemId: "msg2",
            cls: "sm-disk-alert-field",
            width: e.msgWidth,
            autoFlexcroll: !0,
            items: [{
                xtype: "syno_displayfield",
                itemId: "msg21",
                width: e.msgWidth,
                value: t && t.msgs[1] && t.msgs[1].html ? t.msgs[1].html : "",
                htmlEncode: !1
            }]
        }), s.push({
            xtype: "syno_displayfield",
            itemId: "msg3",
            cls: "sm-disk-alert-field",
            width: e.msgWidth,
            value: t && t.msgs[2] && t.msgs[2].html ? t.msgs[2].html : "",
            htmlEncode: !1
        }), Ext.apply({
            width: t.width ? t.width : 660,
            cls: "x-window-dlg",
            fbar: i,
            header: !1,
            draggable: !1,
            elements: "body",
            padding: t.noDeleteIcon ? "14px 30px 0 30px" : "44px 30px 0 30px",
            resizable: !1,
            items: s,
            listeners: {
                afterrender: function() {
                    var t, i, s = 166 - e.getComponent("msg1").getHeight() - e.getComponent("msg3").getHeight(),
                        a = e.getComponent("msg2").getComponent("msg21").getHeight();
                    200 < a ? i = 200 : (i = a, e.getComponent("msg2").setAutoFleXcroll(!1)), t = i - s, e.getComponent("msg2").setHeight(i), e.setHeight(e.getHeight() + t)
                }
            }
        }, t)
    },
    onClickNoButton: function() {
        Ext.isFunction(this.callback) && this.callback("no", this), this.close()
    },
    onClickYesButton: function() {
        Ext.isFunction(this.callback) && this.callback("yes", this), this.close()
    }
}), Ext.define("SYNO.SDS.StorageManager.Disk.ReasonGridPanel", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(t) {
        var e, i = this;
        i.isSHA = SYNO.SDS.StorageUtils.isSHA, i.desc = t.desc, i.disks = t.disks, i.reasons = t.reasons, i.clsPrefix = "sm-disk-reason", i.isSHA && (i.passiveDisks = t.passiveDisks, i.passiveReasons = t.passiveReasons, i.localHostname = t.hostname.active ? String.format("{0} ({1})", t.hostname.active, _TT("SYNO.SDS.HA.Instance", "ui", "active")) : _TT("SYNO.SDS.HA.Instance", "ui", "active"), i.remoteHostname = t.hostname.passive ? String.format("{0} ({1})", t.hostname.passive, _TT("SYNO.SDS.HA.Instance", "ui", "passive")) : _TT("SYNO.SDS.HA.Instance", "ui", "passive")), i.disksStore = {}, i.gridView = i.createGrid({
            ref: "disksGrid"
        }), e = {
            cls: "".concat(i.clsPrefix, "-main-window"),
            title: _T("disk_info", "disk_reason_panel_title"),
            width: i.isSHA ? 860 : 780,
            height: 480,
            boxMinWidth: i.isSHA ? 860 : 780,
            boxMinHeight: 480,
            layout: "fit",
            items: [{
                xtype: "syno_formpanel",
                bodyStyle: {
                    padding: "0px"
                },
                ref: "mainPanel",
                autoFlexcroll: !1,
                items: [{
                    xtype: "syno_displayfield",
                    ref: "textField",
                    style: {
                        padding: "0px"
                    },
                    value: i.desc,
                    htmlEncode: !1
                }, i.gridView]
            }],
            listeners: {
                afterlayout: function() {
                    i.setDisksGridHt()
                },
                afterrender: function() {
                    i.loadDisks(), SYNO.SDS.StorageUtils.DataViewToolTipsAdd(i.mainPanel.textField)
                }
            },
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "close"),
                scope: this,
                handler: this.onClickClose
            }]
        }, i.callParent([Ext.apply(e, t)])
    },
    createGrid: function(t) {
        var e = this,
            i = Ext.apply({
                enableHdMenu: !1,
                layout: "fit",
                style: {
                    padding: "6px 0 12px 0"
                },
                bwrapStyle: {
                    padding: "0"
                },
                bodyStyle: {
                    padding: "0"
                },
                columns: [{
                    header: _T("volume", "volume_disk"),
                    dataIndex: "nameHashValue",
                    sortable: !0,
                    width: 100,
                    renderer: function(t, e, i, s, a, n, o) {
                        var l = i.data.name;
                        return '<div ext:qtip="'.concat(l, '">').concat(l, "</div>")
                    }
                }, {
                    header: _T("status", "status_name"),
                    dataIndex: "hostname",
                    sortable: !0,
                    width: 100,
                    hidden: !e.isSHA,
                    renderer: function(t, e, i, s, a, n, o) {
                        return '<div ext:qtip="'.concat(t, '">').concat(t, "</div>")
                    }
                }, {
                    header: _T("volume", "volume_disk_type"),
                    dataIndex: "diskType",
                    sortable: !0,
                    width: 120
                }, {
                    header: _T("volume", "volume_diskcapacity"),
                    dataIndex: "size_total",
                    sortable: !0,
                    width: 120,
                    renderer: function(t, e, i, s, a, n, o) {
                        return SYNO.SDS.StorageUtils.SizeRender(t)
                    }
                }, {
                    header: _T("disk_info", "disk_health_status"),
                    dataIndex: "healthStatus",
                    sortable: !0,
                    width: 120,
                    renderer: function(t, e, i, s, a, n, o) {
                        return t
                    }
                }, {
                    header: _T("disk_info", "disk_reason_panel_column_header_reason"),
                    dataIndex: "reason",
                    sortable: !0,
                    width: 244,
                    renderer: function(t, i, s, a, n, o) {
                        return t = '<div ext:qtip="'.concat(Ext.util.Format.htmlEncode(t), '" class="').concat(e.clsPrefix, '-reason-col-cell">').concat(t, "</div>")
                    }
                }],
                store: e.disksStore = new Ext.data.JsonStore({
                    autoDestroy: !0,
                    fields: ["nameHashValue", "name", "hostname", "healthStatus", "diskType", "size_total", "reason"]
                })
            }, t);
        return new SYNO.ux.GridPanel(i)
    },
    setDisksGridHt: function() {
        var t, e = this.mainPanel,
            i = this.mainPanel.textField,
            s = this.mainPanel.disksGrid;
        t = e.getHeight() - i.getHeight() - 6, s.setHeight(t)
    },
    loadDisks: function() {
        var t = this,
            e = [];
        Ext.each(t.disks, function(i) {
            e.push({
                nameHashValue: SYNO.SDS.StorageUtils.DiskNameHashValueGet(i.container.order, i.num_id, i.portType),
                hostname: t.isSHA ? t.localHostname : "",
                name: SYNO.SDS.StorageUtils.DiskDisplayNameGet(i),
                diskType: i.diskTypeParsed,
                size_total: +i.size_total,
                reason: t.reasons[i.id],
                healthStatus: i.healthStatusTip
            })
        }), t.isSHA && Ext.each(t.passiveDisks, function(i) {
            t.passiveReasons[i.id] && e.push({
                nameHashValue: SYNO.SDS.StorageUtils.DiskNameHashValueGet(i.container.order, i.num_id, i.portType),
                hostname: t.remoteHostname,
                name: SYNO.SDS.StorageUtils.DiskDisplayNameGet(i),
                diskType: i.diskTypeParsed,
                size_total: +i.size_total,
                reason: t.passiveReasons[i.id],
                healthStatus: i.healthStatusTip
            })
        }), t.disksStore.loadData(e, !1)
    },
    onClickClose: function() {
        this.close()
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.SummaryStore", {
    extend: "SYNO.SDS.Wizard.SummaryStore",
    constructor: function() {
        SYNO.SDS.Wizard.SummaryStore.superclass.constructor.call(this, {
            autoDestroy: !0,
            root: "data",
            fields: ["key", "value", "skipValueEncode"]
        })
    },
    append: function(t, e, i) {
        var s = {
            key: t,
            value: e,
            skipValueEncode: !!i
        };
        this.loadData({
            data: [s]
        }, !0)
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.ModalWindow", {
    extend: "SYNO.SDS.Wizard.ModalWindow",
    constructor: function(t) {
        this.callParent(arguments), this.skipBeforeNext = !1, this.dataStack = [{
            wizard_mode: t.mode || ""
        }]
    },
    onOpen: function() {
        this.callParent(arguments);
        var t = this.getActiveStep();
        Ext.isFunction(t.isSkip) && t.isSkip() && (Ext.isFunction(t.getNext) ? this.goNext(t.getNext()) : this.goNext())
    },
    setData: function(t, e) {
        this.dataStack[this.dataStack.length - 1][t] = e
    },
    goNextWithoutCheck: function() {
        var t = this.getActiveStep();
        this.skipBeforeNext = !0, Ext.isFunction(t.getNext) ? this.goNext(t.getNext()) : this.goNext()
    },
    goNext: function(t) {
        var e, i;
        e = this.getActiveStep(), !this.skipBeforeNext && Ext.isFunction(e.beforeNext) && !1 === e.beforeNext() || (i = SYNO.SDS.Utils.clone(this.dataStack.slice(-1).pop()) || {}, Ext.isFunction(e.updateData) && e.updateData(i), this.dataStack.push(i), this.callParent(arguments), this.skipBeforeNext = !1, e = this.getActiveStep(), Ext.isFunction(e.isSkip) && e.isSkip() && (Ext.isFunction(e.getNext) ? this.goNext(e.getNext()) : this.goNext()))
    },
    goBack: function() {
        var t;
        this.dataStack.pop(), this.callParent(arguments), this.stepStack.length < 1 || (t = this.getActiveStep(), Ext.isFunction(t.isSkip) && t.isSkip() && (Ext.isFunction(t.getBack) ? this.goBack(t.getBack()) : this.goBack()))
    },
    getData: function(t, e) {
        var i = this.dataStack.slice(-1).pop()[t];
        return void 0 !== i ? i : e
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.Step", {
    extend: "SYNO.ux.FormPanel",
    activate: function() {},
    deactivate: function() {},
    isSkip: function() {
        return !1
    },
    getNext: function() {
        return this.nextId || null
    },
    getBack: function() {},
    beforeNext: function() {
        return !0
    },
    updateData: function(t) {},
    summary: function(t) {},
    getData: function(t, e) {
        var i;
        return this.owner && this.owner.dataStack && (i = this.owner.dataStack.slice(-1).pop()[t]), void 0 !== i ? i : e
    }
}), Ext.define("SYNO.SDS.StorageManager.Wizard.SummaryStep", {
    extend: "SYNO.SDS.Wizard.SummaryStep",
    constructor: function() {
        var t = arguments[0] || {};
        t.store = new SYNO.SDS.StorageManager.Wizard.SummaryStore, this.callParent([t])
    },
    activate: function() {
        var t = this.owner.stepStack,
            e = null;
        this.callParent(arguments), this.getStore().removeAll(!0);
        for (var i = 0; i < t.length; i++) e = this.owner.getStep(t[i]), Ext.isFunction(e.isSkip) && e.isSkip() || Ext.isFunction(e.summary) && e.summary(this.getStore());
        this.getView().refresh()
    },
    descRenderer: function(t, e, i, s, a, n) {
        var o, l, r;
        return i.data.skipValueEncode ? (o = t.toString().replace(/<.*?>/g, ""), r = Ext.util.Format.htmlEncode(o), l = t) : (r = Ext.util.Format.htmlEncode(t), r = Ext.util.Format.htmlEncode(r), l = Ext.util.Format.htmlEncode(t)), e.attr = String.format('ext:qtip="{0}"', r), String.format('<font class="sm-font-bold">{0}</font>', l)
    },
    getData: function(t, e) {
        var i;
        return this.owner && this.owner.dataStack && (i = this.owner.dataStack.slice(-1).pop()[t]), void 0 !== i ? i : e
    }
}), Ext.define("SYNO.SDS.StorageManager.DisableableComboBox", {
    extend: "SYNO.ux.ComboBox",
    constructor: function(t) {
        var e, i;
        this.disabledField = t.disabledField || "disabled", this.displayField = t.displayField || "text", i = String.format("sm-disableable-combo-disabled-{{0}}", this.disabledField), e = {
            tpl: new Ext.XTemplate('<tpl for=".">', '<div class="x-combo-list-item ' + i + '">{' + this.displayField + "}</div>", "</tpl>")
        }, this.callParent([Ext.apply(e, t)])
    },
    afterRender: function() {
        this.mon(this, "beforeselect", function(t, e, i) {
            return !e.get(this.disabledField)
        }, this), this.callParent(arguments)
    }
}), Ext.reg("syno_storage_disableable_combobox", SYNO.SDS.StorageManager.DisableableComboBox), Ext.define("SYNO.SDS.StorageManager.RadioEnableColumn", {
    extend: "SYNO.ux.EnableColumn",
    constructor: function(t) {
        this.callParent([Ext.apply({
            bindRowClick: !0,
            sortable: !1,
            disableSelectAll: !0,
            align: "center",
            resizable: !1,
            width: 50,
            hideable: !1
        }, t)])
    },
    onCellClick: function(t, e, i) {
        var s = t.getStore(),
            a = t.view.focusEl.dom;
        if (!this.isIgnore("cell", s.getAt(e))) {
            s = t.getStore();
            for (var n = 0; n < s.getCount(); n++) s.getAt(n).set(this.dataIndex, n === e);
            this.commitChanges && s.commitChanges(), this.checkSelectAll(s), a.focus()
        }
    }
});
