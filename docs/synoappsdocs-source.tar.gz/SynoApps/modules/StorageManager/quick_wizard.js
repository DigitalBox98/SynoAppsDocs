/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function asyncGeneratorStep(e, t, i, n, r, a, s) {
    try {
        var o = e[a](s),
            c = o.value
    } catch (e) {
        return void i(e)
    }
    o.done ? t(c) : Promise.resolve(c).then(n, r)
}

function _asyncToGenerator(e) {
    return function() {
        var t = this,
            i = arguments;
        return new Promise(function(n, r) {
            var a = e.apply(t, i);

            function s(e) {
                asyncGeneratorStep(a, n, r, s, o, "next", e)
            }

            function o(e) {
                asyncGeneratorStep(a, n, r, s, o, "throw", e)
            }
            s(void 0)
        })
    }
}
/**
 * @class SYNO.SDS.StorageManager.QuickWizard.Instance
 * @extends SYNO.SDS.AppInstance
 * StorageManager application instance class
 *
 */
Ext.define("SYNO.SDS.StorageManager.QuickWizard.Instance", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.StorageManager.QuickWizard.AppWindow"
}), Ext.define("SYNO.SDS.StorageManager.QuickWizard.AppWindow", {
    extend: "SYNO.SDS.AppWindow",
    constructor: function() {
        this.volumeExist = !0, this.panelRef = new SYNO.SDS.StorageManager.QuickWizard.Panel;
        var e = {
            border: !1,
            loaded: !1,
            hasPool: !1,
            toggleMinimizable: !1,
            resizable: !1,
            header: !1,
            showHelp: !1,
            width: 602,
            height: 450,
            minWidth: 602,
            minHeight: 450,
            draggable: !1,
            cls: "syno-sm-quickstrart-win",
            items: this.panelRef
        };
        this.callParent([e]), this.mon(this, "beforeshow", this.checkVisible.bind(this)), this.mon(this, "show", this.center.bind(this)), this.requestVolumeInfo()
    },
    checkVisible: function() {
        return !this.volumeExist
    },
    requestVolumeInfo: function() {
        this.sendWebAPI({
            api: "SYNO.Core.Storage.Volume",
            method: "list",
            version: 1,
            params: {
                offset: 0,
                limit: -1,
                location: "internal"
            },
            callback: this.setQuickWizardVisability.bind(this)
        })
    },
    setQuickWizardVisability: function(e, t) {
        e ? 0 < t.volumes.length ? (this.firstAdminPromiseFunc && this.firstAdminPromiseFunc.quickStartResolve(), this.close()) : (this.volumeExist = !1, this.show()) : (this.firstAdminPromiseFunc && this.firstAdminPromiseFunc.quickStartReject(), this.close())
    }
}), Ext.define("SYNO.SDS.StorageManager.QuickWizard.Panel", {
    extend: "Ext.Container",
    constructor: function() {
        var e = {
            cls: "syno-sm-quickstrart-panel",
            items: [{
                xtype: "box",
                cls: "video-rect",
                html: '<video id="stg-video" width="602" height="230" autoplay loop muted="muted"><source id="stg-video-src" src="webman/modules/StorageManager/images/1x/video_storage_city.mp4" type="video/mp4"></video>'
            }, {
                xtype: "container",
                cls: "text-btn-sec",
                items: [{
                    xtype: "box",
                    cls: "title-wrap",
                    html: '<div class="title">' + _T("storage_manager", "quick_start_panel_title") + "</div>"
                }, {
                    xtype: "box",
                    cls: "desc",
                    html: _T("storage_manager", "quick_start_panel_desc")
                }, {
                    xtype: "container",
                    cls: "bbar",
                    items: [{
                        xtype: "syno_button",
                        btnStyle: "blue",
                        text: _T("storage_manager", "quick_start_panel_btn_text"),
                        handler: this.openSM.bind(this)
                    }]
                }]
            }]
        };
        this.callParent([e])
    },
    openSM: function() {
        this.findAppWindow().close(), SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance", {
            fn: "SYNO.SDS.StorageManager.Pool.Main",
            vueWizard: "CreateWizardWindow"
        }, !1, function() {
            var e = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.StorageManager.Instance")[0];
            this.firstAdminPromiseFunc && e.window.getVueInstance().$store.dispatch("FirstTimeInstallModule/assignCreatePostHookFunc", {
                hasFunc: !0,
                func: function(e, t) {
                    !e || t ? this.firstAdminPromiseFunc.quickStartResolve() : this.firstAdminPromiseFunc.quickStartReject()
                }.bind(this)
            })
        }.bind(this))
    }
}), SYNO.SDS.StorageManager.SMQuickStart = _asyncToGenerator(regeneratorRuntime.mark(function e() {
    var t, i, n, r, a, s, o, c;
    return regeneratorRuntime.wrap(function(e) {
        for (;;) switch (e.prev = e.next) {
            case 0:
                if (n = SYNO.SDS.UIFeatures.test("isRetina"), e.t0 = n, !e.t0) {
                    e.next = 6;
                    break
                }
                return e.next = 5, SYNO.SDS.HelpBrowser.Utils.checkOnline();
            case 5:
                e.t0 = e.sent;
            case 6:
                return r = e.t0, a = function() {
                    var e = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.StorageManager.Instance")[0];
                    e && e.window.getVueInstance().$store.dispatch("FirstTimeInstallModule/assignCreatePostHookFunc", {
                        hasFunc: !1,
                        func: function() {}
                    })
                }, s = function() {
                    a(), t()
                }, o = function() {
                    a(), i()
                }, c = function() {
                    var e = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.StorageManager.QuickWizard.Instance")[0];
                    if (e.window.firstAdminPromiseFunc = {
                            quickStartResolve: s,
                            quickStartReject: o
                        }, e.window.panelRef.firstAdminPromiseFunc = {
                            quickStartResolve: s,
                            quickStartReject: o
                        }, r) {
                        var t = SYNO.SDS.HelpBrowser.Utils.onlineURL + "getTipsMedia/DSM/video_storage_city.mp4",
                            i = Ext.get("stg-video-src"),
                            n = Ext.get("stg-video");
                        i.dom.setAttribute("src", t), n.dom.load(), n.dom.play()
                    }
                }, SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.QuickWizard.Instance", {}, !1, c), e.abrupt("return", new Promise(function(e, n) {
                    t = e, i = n
                }));
            case 13:
            case "end":
                return e.stop()
        }
    }, e, this)
})), SYNO.SDS.StorageManager.SMQuickStart.register = function() {
    SYNO.SDS.ExecuteAfterFirstTime && SYNO.SDS.ExecuteAfterFirstTime.register("SYNO.SDS.StorageManager.SMQuickStart", SYNO.SDS.StorageManager.SMQuickStart)
}, SYNO.SDS.StorageManager.SMQuickStart.register();
