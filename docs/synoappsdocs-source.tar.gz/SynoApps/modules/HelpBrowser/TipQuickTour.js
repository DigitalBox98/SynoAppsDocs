! function(e) {
    var r = {};

    function t(o) {
        if (r[o]) return r[o].exports;
        var n = r[o] = {
            i: o,
            l: !1,
            exports: {}
        };
        return e[o].call(n.exports, n, n.exports, t), n.l = !0, n.exports
    }
    t.m = e, t.c = r, t.d = function(e, r, o) {
        t.o(e, r) || Object.defineProperty(e, r, {
            enumerable: !0,
            get: o
        })
    }, t.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, t.t = function(e, r) {
        if (1 & r && (e = t(e)), 8 & r) return e;
        if (4 & r && "object" == typeof e && e && e.__esModule) return e;
        var o = Object.create(null);
        if (t.r(o), Object.defineProperty(o, "default", {
                enumerable: !0,
                value: e
            }), 2 & r && "string" != typeof e)
            for (var n in e) t.d(o, n, function(r) {
                return e[r]
            }.bind(null, n));
        return o
    }, t.n = function(e) {
        var r = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return t.d(r, "a", r), r
    }, t.o = function(e, r) {
        return Object.prototype.hasOwnProperty.call(e, r)
    }, t.p = "", t(t.s = 28)
}({
    28: function(e, r) {
        Ext.namespace("SYNO.SDS.HelpBrowser"), 
/**
 * @class SYNO.SDS.HelpBrowser.QuickTourChecker
 * QuickTourChecker 
 *
 */            
        SYNO.SDS.HelpBrowser.QuickTourChecker = function(e) {
            var r = function() {
                    SYNO.SDS.JSLoad("SYNO.SDS.HelpBrowser.QuickTourTray", (function() {
                        SYNO.SDS.SystemTray.notifyVueCustomizeMsg("", new SYNO.SDS.HelpBrowser.QuickTourTray)
                    }))
                },
                t = e["SYNO.SDS.SystemConfigChecker"];
            if (!(t && t[0] && t[0].value)) return synowebapi.promises.request({
                api: "SYNO.Core.Storage.Volume",
                method: "list",
                version: 1,
                params: {
                    offset: 0,
                    limit: 1,
                    location: "internal"
                }
            }).then((function(e) {
                e && e.total && r()
            })).catch((function(e) {
                SYNO.Debug(e)
            }));
            var o = t[0].value,
                n = o.volume_count,
                u = o.has_config_data;
            n > 0 && !u && r()
        }, SYNO.SDS.HelpBrowser.QuickTourChecker.register = function() {
            SYNO.SDS.ExecuteAfterFirstTime && SYNO.SDS.ExecuteAfterFirstTime.register("SYNO.SDS.HelpBrowser.QuickTourChecker", SYNO.SDS.HelpBrowser.QuickTourChecker)
        }, SYNO.SDS.HelpBrowser.QuickTourChecker.register()
    }
});
