! function(t) {
    var e = {};

    function n(s) {
        if (e[s]) return e[s].exports;
        var a = e[s] = {
            i: s,
            l: !1,
            exports: {}
        };
        return t[s].call(a.exports, a, a.exports, n), a.l = !0, a.exports
    }
    n.m = t, n.c = e, n.d = function(t, e, s) {
        n.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: s
        })
    }, n.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }, n.t = function(t, e) {
        if (1 & e && (t = n(t)), 8 & e) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var s = Object.create(null);
        if (n.r(s), Object.defineProperty(s, "default", {
                enumerable: !0,
                value: t
            }), 2 & e && "string" != typeof t)
            for (var a in t) n.d(s, a, function(e) {
                return t[e]
            }.bind(null, a));
        return s
    }, n.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t.default
        } : function() {
            return t
        };
        return n.d(e, "a", e), e
    }, n.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, n.p = "", n(n.s = 7)
}([function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e) {
    t.exports = Vue
}, function(t, e, n) {
    "use strict";
    var s = n(0);
    n.n(s).a
}, function(t, e, n) {
    "use strict";
    var s = n(1);
    n.n(s).a
}, function(t, e, n) {
    "use strict";
    var s = n(2);
    n.n(s).a
}, function(t, e, n) {
    "use strict";
    n.r(e);
    var s = n(3),
        a = n.n(s),
        i = function() {
            var t = this.$createElement,
                e = this._self._c || t;
            return e("v-app-instance", {
                attrs: {
                    "syno-id": "update-mask-app-instance",
                    "class-name": "SYNO.SDS.App.UpdateMaskApp.Instance",
                    fullsize: !0,
                    "should-launch": this.shouldLaunch
                }
            }, [e("v-app-window", {
                staticClass: "update-mask-app-window",
                attrs: {
                    "syno-id": "update-mask-app-window",
                    closable: !1,
                    "default-maximized": !0,
                    resizable: !1
                }
            }, [e("div", {
                staticClass: "copyright-layer"
            }, [e("div", {
                staticClass: "copyright"
            }, [this._v("Copyright © 2020 Synology Inc. All rights reserved")])]), this._v(" "), e("div", {
                staticClass: "upgrading-display-layer"
            }, [e("UpdateMask")], 1)])], 1)
        };
    i._withStripped = !0;
    var r = function() {
        var t = this,
            e = t.$createElement,
            n = t._self._c || e;
        return n("div", {
            staticClass: "upgrading-display"
        }, [n("Loading", {
            staticClass: "loading-icon"
        }), t._v(" "), n("div", {
            staticClass: "upgrading-title"
        }, [t._v(t._s(t.T("update", "updatemask_title")))]), t._v(" "), n("div", {
            staticClass: "upgrading-desc"
        }, [t._v(t._s(t.T("update", "updatemask_desc")))])], 1)
    };
    r._withStripped = !0;
    var o = function() {
        var t = this.$createElement;
        this._self._c;
        return this._m(0)
    };
    o._withStripped = !0;
    n(4);

    function p(t, e, n, s, a, i, r, o) {
        var p, c = "function" == typeof t ? t.options : t;
        if (e && (c.render = e, c.staticRenderFns = n, c._compiled = !0), s && (c.functional = !0), i && (c._scopeId = "data-v-" + i), r ? (p = function(t) {
                (t = t || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) || "undefined" == typeof __VUE_SSR_CONTEXT__ || (t = __VUE_SSR_CONTEXT__), a && a.call(this, t), t && t._registeredComponents && t._registeredComponents.add(r)
            }, c._ssrRegister = p) : a && (p = o ? function() {
                a.call(this, this.$root.$options.shadowRoot)
            } : a), p)
            if (c.functional) {
                c._injectStyles = p;
                var u = c.render;
                c.render = function(t, e) {
                    return p.call(e), u(t, e)
                }
            } else {
                var d = c.beforeCreate;
                c.beforeCreate = d ? [].concat(d, p) : [p]
            } return {
            exports: t,
            options: c
        }
    }
    var c = p({}, o, [function() {
        var t = this.$createElement,
            e = this._self._c || t;
        return e("div", {
            staticClass: "loader"
        }, [e("div", {
            staticClass: "spinner1"
        }), this._v(" "), e("div", {
            staticClass: "spinner2"
        }), this._v(" "), e("div", {
            staticClass: "spinner3"
        })])
    }], !1, null, "efe9d588", null);
    c.options.__file = "src/components/Loading.vue";
    var u = {
            components: {
                Loading: c.exports
            },
            methods: {
                T: function(t, e) {
                    return _T(t, e) || "".concat(t, ":").concat(e)
                }
            }
        },
        d = (n(5), p(u, r, [], !1, null, "0d22e1f6", null));
    d.options.__file = "src/components/UpdateMask.vue";
    var l = {
            components: {
                UpdateMask: d.exports
            },
            methods: {
                shouldLaunch: function() {
                    return _S("is_upgrading")
                }
            }
        },
        f = (n(6), p(l, i, [], !1, null, "e95e06e8", null));
    f.options.__file = "src/components/UpdateMaskApp.vue";
    var _ = f.exports;
    Ext.namespace("SYNO.SDS.App.UpdateMaskApp"), 
/**
 * @class SYNO.SDS.App.UpdateMaskApp.Instance
 * UpdateMaskApp application instance class
 *
 */  
    SYNO.SDS.App.UpdateMaskApp.Instance = a.a.extend({
        components: {
            UpdateMaskApp: _
        },
        template: "<UpdateMaskApp/>"
    })
}]);
