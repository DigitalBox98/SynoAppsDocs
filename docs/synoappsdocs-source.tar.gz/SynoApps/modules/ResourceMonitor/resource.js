/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function asyncGeneratorStep(e, t, i, r, a, o, n) {
    try {
        var s = e[o](n),
            c = s.value
    } catch (e) {
        return void i(e)
    }
    s.done ? t(c) : Promise.resolve(c).then(r, a)
}

function _asyncToGenerator(e) {
    return function() {
        var t = this,
            i = arguments;
        return new Promise(function(r, a) {
            function o(e) {
                asyncGeneratorStep(s, r, a, o, n, "next", e)
            }

            function n(e) {
                asyncGeneratorStep(s, r, a, o, n, "throw", e)
            }
            var s = e.apply(t, i);
            o(void 0)
        })
    }
}
var _this3 = this;
Ext.ns("SYNO.SDS.ResourceMonitor.Performance.Chart"), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Detail.Header", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = this,
            i = Ext.apply({
                layout: {
                    type: "hbox",
                    pack: "end"
                },
                height: 32,
                topLayer: e.topLayer,
                items: [],
                listeners: {
                    activate: this.onActivate,
                    scope: this
                }
            }, e.config);
        Ext.isEmpty(e.lun_field_button) || i.items.push(e.lun_field_button.button), Ext.isEmpty(e.device_view_all) || i.items.push(e.device_view_all), Ext.isEmpty(e.type_combo) || (t.type_label = t.createCustomLabel(_T("rsrcmonitor", "chart"), !1), t.type_combo = t.createTypeCombo(e.type_combo.data), i.items.push(t.type_label), i.items.push(t.type_combo)), Ext.isEmpty(e.lun_combo) || (i.items.push(e.lun_combo.label), i.items.push(e.lun_combo.combo)), t.history_label = t.createCustomLabel(_T("rsrcmonitor", "time_range"), !0), t.history_combo = t.createHistoryCombo(), i.items.push(t.history_label), i.items.push(t.history_combo), this.callParent([i])
    },
    createHistoryCombo: function() {
        return new SYNO.ux.ComboBox({
            xtype: "syno_combobox",
            itemId: "history_combo",
            width: 170,
            margins: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 8
            },
            triggerAction: "all",
            editable: !1,
            valueField: "history",
            displayField: "displayText",
            value: "current",
            mode: "local",
            autoScroll: !1,
            hidden: !0,
            store: new Ext.data.ArrayStore({
                fields: ["history", "displayText"],
                data: [
                    ["current", _T("rsrcmonitor", "realtime")],
                    ["week", _T("rsrcmonitor", "last_7_days")],
                    ["month", _T("rsrcmonitor", "last_30_days")],
                    ["half_year", _T("rsrcmonitor", "last_6_months")],
                    ["year", _T("rsrcmonitor", "last_12_months")]
                ]
            }),
            listeners: {
                select: {
                    scope: this,
                    fn: this.headerChange
                }
            }
        })
    },
    createTypeCombo: function(e) {
        return new SYNO.ux.ComboBox({
            itemId: "type_combo",
            width: 200,
            margins: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 8
            },
            triggerAction: "all",
            editable: !1,
            mode: "local",
            autoScroll: !1,
            valueField: "type",
            displayField: "displayText",
            value: e[0][0],
            store: new Ext.data.ArrayStore({
                fields: ["type", "displayText"],
                data: e
            }),
            listeners: {
                select: {
                    scope: this,
                    fn: this.headerChange
                }
            }
        })
    },
    createCustomLabel: function(e, t) {
        return new SYNO.ux.DisplayField({
            margins: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 20
            },
            style: "text-align: right;",
            width: "auto",
            value: e + ":",
            hidden: t
        })
    },
    headerChange: function() {
        var e = this.getContentConfig();
        this.topLayer.setTimeRange(e.history), this.fireEvent("contentSelect", e)
    },
    reloadContent: function(e) {
        this.history_combo && this.history_combo.setValue(e.history), this.type_combo && this.type_combo.setValue(e.type), this.fireEvent("contentSelect", e)
    },
    getContentConfig: function() {
        var e = {};
        return this.history_combo ? e.history = this.history_combo.value : e.history = "current", this.type_combo && (e.type = this.type_combo.value), this.lun_combo && (e.lun = this.lun_combo.value), e
    },
    setToRealTime: function() {
        var e = this;
        e.history_combo && (e.history_combo.setValue("current"), e.headerChange())
    },
    onActivate: function() {
        var e = this.getContentConfig();
        this.history_combo.hidden || e.history !== this.topLayer.time_range && (e.history = this.topLayer.time_range, this.reloadContent(e))
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Chart.Current", {
    extend: "Ext.Panel",
    totalTime: 180,
    constructor: function(e) {
        var t = this,
            i = {
                store: e.lines ? e.lines.map(function(i, r) {
                    return new SYNO.SDS.ResourceMonitor.Performance.DataSet({
                        totalTime: e.totalTime ? e.totalTime : t.totalTime,
                        itemId: i.itemId || "store" + r,
                        color: i.color,
                        lineStyle: i.lineStyle,
                        areaStyle: i.areaStyle,
                        lineName: i.lineName
                    })
                }, this) : [],
                border: !1,
                topLayer: e.topLayer,
                dataType: "normal"
            };
        Ext.apply(i, e), this.callParent([i])
    },
    initEvents: function() {
        var e = this;
        SYNO.SDS.ResourceMonitor.Performance.Chart.Current.superclass.initEvents.call(this, arguments), e.mon(e, "resize", function() {
            e.echarts && e.echarts.resize()
        }, e), e.mon(e.topLayer.appWin, "server_change", e.clearStoreData, e)
    },
    drawChart: function() {
        var e, t = this,
            i = [],
            r = 0;
        if (!(t.isDestroyed || !t.body || t.body.getSize(!0).width <= 1 || t.body.getSize(!0).height <= 1)) {
            for (r = 0; r < t.store.length; ++r) i.push(t.store[r].genSeries());
            e = t.getChartType(), e.series = i, t.primitiveLegend && (e.legend = SYNO.SDS.ResourceMonitor.Performance.Chart.Util.legendConfig, e.legend.data = [_T("rsrcmonitor", "rsrcmonitor_trans"), _T("rsrcmonitor", "rsrcmonitor_recv")]), t.canvasHeight && (e.height = t.canvasHeight), t.echarts || (t.echarts = echarts.init(t.body.dom)), t.echarts.setOption(e)
        }
    },
    updateStores: function(e) {
        var t = this,
            i = !1;
        Ext.each(t.store, function(t) {
            if (i = e.every(function(e, i, r) {
                    return t.itemId !== e.itemId
                })) return !1
        }), (i || e.length !== t.store.length) && (t.store = e.map(function(e) {
            return new SYNO.SDS.ResourceMonitor.Performance.DataSet({
                totalTime: t.totalTime,
                lineStyle: e.lineStyle,
                areaStyle: e.areaStyle,
                color: e.color,
                itemId: e.itemId,
                lineName: e.lineName
            })
        }))
    },
    pushValueById: function(e, t) {
        var i = this,
            r = 0;
        Ext.each(e, function(e, a, o) {
            for (r = 0; r < i.store.length; ++r)
                if (i.store[r].itemId === e.itemId) return void i.store[r].pushData(e.value, t)
        })
    },
    pushValue: function(e, t) {
        var i = this,
            r = 0,
            a = 0;
        for (r = i.store.length - 1; r >= 0; --r) i.store[r].pushData(e[r] + a, t), i.aggregate && (a += e[r])
    },
    clearStoreData: function() {
        var e = this,
            t = 0;
        for (t = e.store.length - 1; t >= 0; --t) e.store[t].clear()
    },
    getChartType: function() {
        var e = this,
            t = echarts.syno.getDefaultOptions(),
            i = 0,
            r = SYNO.SDS.ResourceMonitor.Performance.Chart.Util,
            a = r.chartConfig,
            o = r.tooltipConfig;
        switch (a.apply(t), o.apply(t.tooltip), t.tooltip.formatter = e.trackFormatter.createDelegate(e), t.xAxis.max = e.store[0] ? e.store[0].getLastTime() : 0, t.xAxis.min = Ext.max([t.xAxis.max - e.totalTime, 0]), t.xAxis.axisLabel.show = !1, t.grid.top = 20, t.grid.right = 5, t.grid.left = 42, t.grid.bottom = 20, e.dataType) {
            case "percent":
                i = 100;
                break;
            case "byte":
            case "bytes":
                i = e.getMaxDataValue(), i = !Ext.isNumber(i) || i < 102400 ? 102400 : Math.ceil(1.1 * i);
                break;
            case "timeus":
                i = e.getMaxDataValue(), i = !Ext.isNumber(i) || i < 10 ? 10 : Math.ceil(1.1 * i);
                break;
            case "normal":
            case "iops":
                i = e.getMaxDataValue(), i = !Ext.isNumber(i) || i < 10 ? 10 : Math.ceil(1.1 * i);
                break;
            default:
                return
        }
        return t.yAxis.min = 0, t.yAxis.max = i, t.yAxis.splitNumber = 5, t.yAxis.axisLabel.color = r.labelConfig.color, e.chartTitle && (t.yAxis.name = e.chartTitle, t.yAxis.nameTextStyle.color = r.labelConfig.color, t.yAxis.nameTextStyle.fontFamily = a.textStyle.fontFamily, t.yAxis.nameTextStyle.fontSize = a.textStyle.fontSize, t.yAxis.nameTextStyle.fontWeight = a.textStyle.fontWeight), echarts.syno.customizeAxis(t.yAxis, e.dataType), t
    },
    getMaxDataValue: function() {
        var e = this,
            t = 0,
            i = 0;
        for (i = 0; i < e.store.length; ++i) t < e.store[i].getMaxDataValue() && (t = e.store[i].getMaxDataValue());
        return t
    },
    trackFormatter: function(e) {
        var t, i, r, a = this,
            o = [],
            n = 0,
            s = 0,
            c = [],
            l = function(t) {
                return t.itemId === e[s].seriesId
            };
        for (t = new Date(1e3 * e[0].data[0]), t = SYNO.SDS.DateTimeFormatter(t, {
                type: "datetimesec"
            }), s = e.length - 1; s >= 0; --s) o[s] = e[s].data[1] - n, a.aggregate && (n += o[s]);
        for (s = 0; s < e.length; ++s) {
            var d = a.topLayer.numberUnit(o[s], a.dataType);
            i = d.num + " " + d.unit, a.lines && (r = a.lines.find(l)), c.push({
                name: e[s].seriesName,
                value: i,
                color: e[s].color,
                fontColor: a.lines && a.lines[s] && a.lines[s].fontColor ? a.lines[s].fontColor : e[s].color,
                order: a.lines ? r.trackOrder : 0
            })
        }
        return c = c.sort(function(e, t) {
            return e.order > t.order ? 1 : -1
        }), SYNO.SDS.ResourceMonitor.Performance.Chart.Util.getStyledInfoList(t, c)
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Chart.History", {
    extend: "Ext.Panel",
    aggregate: !1,
    lines: [],
    timeAxis: "week",
    dataType: "percent",
    dataBase: 1,
    data: {},
    dataSize: 0,
    constructor: function(e) {
        var t = {
            topLayer: e.topLayer,
            border: !1
        };
        Ext.apply(t, e), this.callParent([t])
    },
    initEvents: function() {
        this.callParent(arguments), this.mon(this, "resize", function() {
            this.echarts && this.echarts.resize()
        }, this)
    },
    setChartConfig: function(e) {
        this.maxValue = 0, Ext.isDefined(e.aggregate) && (this.aggregate = e.aggregate), Ext.isDefined(e.lines) && (this.lines = e.lines), Ext.isDefined(e.timeAxis) && (this.timeAxis = e.timeAxis), Ext.isDefined(e.dataType) && (this.dataType = e.dataType), Ext.isDefined(e.dataBase) && (this.dataBase = e.dataBase), Ext.isDefined(e.data) && (this.data = e.data), Ext.isDefined(e.dataSize) && (this.dataSize = e.dataSize), Ext.isDefined(e.endTime) && (this.endTime = e.endTime), Ext.isDefined(e.timeInterval) && (this.timeInterval = e.timeInterval), Ext.isDefined(e.chartTitle) ? this.chartTitle = e.chartTitle : this.chartTitle = null
    },
    drawChart: function() {
        if (!(this.isDestroyed || !this.body || this.body.getSize(!0).width <= 1 || this.body.getSize(!0).height <= 1)) {
            this.echarts || (this.echarts = echarts.init(this.body.dom));
            var e = this.genSeries(),
                t = this.getChartType(e);
            this.primitiveLegend && (t.legend = SYNO.SDS.ResourceMonitor.Performance.Chart.Util.legendConfig, t.legend.data = [_T("rsrcmonitor", "rsrcmonitor_trans"), _T("rsrcmonitor", "rsrcmonitor_recv")]), this.canvasHeight && (t.height = this.canvasHeight), this.setHeight && (t.height = this.setHeight), this.setInterval && this.maxValue >= this.setInterval && ("Utilization" === this.chartName && (this.maxValue = Math.max(this.maxValue, 100)), "TransferRate" === this.chartName && (this.maxValue = Math.max(this.maxValue, 102400)), t.yAxis.interval = Math.ceil(this.maxValue / this.setInterval)), t.dataZoom = this.getDataZoom(), this.echarts.setOption(t, !0)
        }
    },
    genSeries: function() {
        var e = this,
            t = [],
            i = "bytes" === this.dataType ? this.dataBase : 1,
            r = this.aggregate ? this.aggregateData() : this.data;
        return this.lines.forEach(function(a) {
            var o = a.itemId,
                n = [],
                s = e.endTime;
            Ext.isDefined(r[o]) && (r[o].reverse().forEach(function(t) {
                n.push([1e3 * s, t * i]), s -= e.timeInterval, t * i > e.maxValue && (e.maxValue = t * i)
            }), t.push({
                type: "line",
                data: n.reverse(),
                lines: a.lineType,
                color: a.color,
                name: a.lineName,
                showSymbol: !1,
                symbol: "circle",
                symbolSize: 0,
                lineStyle: a.lineStyle,
                areaStyle: a.areaStyle,
                id: a.itemId
            }))
        }), t
    },
    aggregateData: function() {
        for (var e = 0, t = this.lines.length, i = SYNO.Util.copy(this.data), r = 0; r < this.dataSize; ++r) {
            e = 0;
            for (var a = t - 1; a >= 0; --a) e += i[this.lines[a].itemId][r], i[this.lines[a].itemId][r] = e
        }
        return i
    },
    getChartType: function(e) {
        var t = echarts.syno.getDefaultOptions(),
            i = SYNO.SDS.ResourceMonitor.Performance.Chart.Util.chartConfig;
        return t.grid.top = 20, t.grid.right = 5, t.grid.left = 42, t.grid.bottom = 74, t.textStyle = i.textStyle, t.yAxis.nameTextStyle.fontFamily = i.textStyle.fontFamily, t.yAxis.nameTextStyle.fontSize = i.textStyle.fontSize, t.series = e, this.setTooltipConfig(t), this.setYaxisConfig(t), this.setXaxisConfig(t), t
    },
    setYaxisConfig: function(e) {
        var t = SYNO.SDS.ResourceMonitor.Performance.Chart.Util.labelConfig,
            i = SYNO.SDS.ResourceMonitor.Performance.Chart.Util.chartConfig,
            r = this.maxValue;
        switch (this.dataType) {
            case "percent":
                e.yAxis.min = 0, e.yAxis.max = 100;
                break;
            case "byte":
            case "bytes":
                r = !Ext.isNumber(r) || r < 102400 ? 102400 : Math.ceil(1.1 * r), e.yAxis.min = 0, e.yAxis.max = r;
                break;
            case "timeus":
                r = !Ext.isNumber(r) || r < 10 ? 10 : Math.ceil(1.1 * r), e.yAxis.min = 0, e.yAxis.max = r;
                break;
            case "normal":
            case "iops":
                r = !Ext.isNumber(r) || r < 10 ? 10 : Math.ceil(1.1 * r), e.yAxis.min = 0, e.yAxis.max = r;
                break;
            default:
                return
        }
        this.chartTitle && (e.yAxis.name = this.chartTitle, e.yAxis.nameTextStyle.color = t.color, e.yAxis.nameTextStyle.fontFamily = i.textStyle.fontFamily, e.yAxis.nameTextStyle.fontSize = i.textStyle.fontSize, e.yAxis.nameTextStyle.fontWeight = i.textStyle.fontWeight), e.yAxis.axisLabel.color = t.color, echarts.syno.customizeAxis(e.yAxis, this.dataType)
    },
    setXaxisConfig: function(e) {
        var t = SYNO.SDS.ResourceMonitor.Performance.Chart.Util.labelConfig,
            i = e.xAxis;
        switch (i.type = "time", i.splitLine = {
                show: !1
            }, i.axisLabel.padding = [6, 0, 0, 0], i.axisLabel.color = t.color, i.axisLabel.showMaxLabel = !1, i.axisLabel.showMinLabel = !0, i.axisLabel.formatter = this.getFormatter(), this.timeAxis) {
            default:
            case "week":
            case "month":
                i.splitNumber = 7;
                break;
            case "half_year":
            case "year":
                i.splitNumber = 12
        }
    },
    setTooltipConfig: function(e) {
        SYNO.SDS.ResourceMonitor.Performance.Chart.Util.tooltipConfig.apply(e.tooltip, !0), e.tooltip.formatter = this.trackFormatter.createDelegate(this)
    },
    trackFormatter: function(e) {
        var t, i, r, a = this,
            o = [],
            n = [],
            s = 0,
            c = 0,
            l = function(t) {
                return t.itemId === e[c].seriesId
            };
        for (c = e.length - 1; c >= 0; --c) o[c] = e[c].data[1] - s, a.aggregate && (s += o[c]);
        for (c = 0; c < e.length; ++c) {
            var d = a.topLayer.numberUnit(o[c], a.dataType);
            t = d.num + " " + d.unit, a.lines && (i = a.lines.find(l)), n.push({
                name: e[c].seriesName,
                value: t,
                color: e[c].color,
                fontColor: a.lines && a.lines[c] && a.lines[c].fontColor ? a.lines[c].fontColor : e[c].color,
                order: a.lines ? i.trackOrder : 0
            })
        }
        return n = n.sort(function(e, t) {
            return e.order > t.order ? 1 : -1
        }), r = new Date(e[0].data[0]), r = SYNO.SDS.DateTimeFormatter(r, {
            type: "datetimesec"
        }), SYNO.SDS.ResourceMonitor.Performance.Chart.Util.getStyledInfoList(r, n)
    },
    getDataZoom: function() {
        return [{
            type: "inside",
            start: 66,
            end: 100,
            minSpan: 3
        }, {
            left: 36,
            right: 7,
            type: "syno_slider",
            height: 20,
            start: 66,
            end: 100,
            minSpan: 3,
            padding: 6,
            handleIcon: "M6,19c0,1.7-1.3,3-3,3s-3-1.3-3-3c0-1.3,0.8-2.4,2-2.8V0h2v16.2C5.2,16.6,6,17.7,6,19z",
            handleStyle: {
                color: "rgba(5, 127, 235, 1)"
            },
            textStyle: {
                fontSize: 12
            },
            handleSize: "110%",
            fillerColor: "rgba(21, 116, 232, 0.1)",
            borderColor: "rgba(198, 212, 224, 0.7)",
            backgroundColor: "rgba(250, 252, 255, 1)",
            yAxisMax: "percent" === this.dataType ? 100 : void 0,
            yAxisMin: "percent" === this.dataType ? -10 : void 0,
            dataBackground: {
                areaStyle: {
                    color: "rgba(21, 116, 232, 0.2)"
                },
                lineStyle: {
                    color: "rgba(117,148,191, 0.4)",
                    width: 1,
                    opacity: 1
                }
            },
            labelFormatter: this.getFormatter()
        }]
    },
    getFormatter: function() {
        switch (this.timeAxis) {
            case "week":
            case "month":
                return function(e) {
                    var t = new Date(e);
                    return ("0" + (t.getMonth() + 1)).slice(-2) + "/" + ("0" + t.getDate()).slice(-2) + " " + ("0" + t.getHours()).slice(-2) + ":" + ("0" + t.getMinutes()).slice(-2)
                };
            case "half_year":
            case "year":
                return function(e) {
                    var t = new Date(e);
                    return ("0" + (t.getMonth() + 1)).slice(-2) + "/" + ("0" + t.getDate()).slice(-2)
                }
        }
    }
}), SYNO.SDS.ResourceMonitor.Performance.Chart.Style = {
    fontColor: "rgba(65, 75, 85, 1)",
    fontFamily: "Verdana, Microsoft JhengHei, sans-serif"
}, SYNO.SDS.ResourceMonitor.Performance.Chart.Util = {
    minSizeOfChart: 120,
    chartConfig: {
        textStyle: {
            fontSize: 13,
            fontWeight: "normal",
            fontFamily: SYNO.SDS.ResourceMonitor.Performance.Chart.Style.fontFamily
        },
        apply: function(e) {
            var t = SYNO.SDS.ResourceMonitor.Performance.Chart.Util.chartConfig;
            e.textStyle = t.textStyle
        }
    },
    legendConfig: {
        x: "right",
        y: "top",
        itemGap: 40,
        itemWidth: 7.5,
        itemHeight: 9.5,
        top: -6,
        textStyle: {
            padding: [3, 0, 0, 3],
            color: SYNO.SDS.ResourceMonitor.Performance.Chart.Style.fontColor
        }
    },
    labelConfig: {
        color: SYNO.SDS.ResourceMonitor.Performance.Chart.Style.fontColor
    },
    tooltipConfig: {
        left: 46,
        top: 28,
        bottom: 28,
        border: 1,
        verticalPadding: 6,
        horizontalPadding: 8,
        infoHeight: 20,
        dateSectionHeight: 26,
        sliderbarHeight: 50,
        tableClass: "info-list-table",
        moreItemLabelClass: "info-list-more-item-label",
        textStyle: {
            fontFamily: SYNO.SDS.ResourceMonitor.Performance.Chart.Style.fontFamily,
            color: SYNO.SDS.ResourceMonitor.Performance.Chart.Style.fontColor
        },
        axisPointer: {
            lineStyle: {
                color: "#E64040",
                width: 2
            }
        },
        apply: function(e, t) {
            var i = SYNO.SDS.ResourceMonitor.Performance.Chart.Util.tooltipConfig;
            e.axisPointer = i.axisPointer, e.padding = [i.verticalPadding, i.horizontalPadding], e.position = i.positionFunc.createDelegate(_this3, t, !0)
        },
        positionFunc: function(e, t, i, r, a, o) {
            var n = SYNO.SDS.ResourceMonitor.Performance.Chart.Util;
            n.displayMoreItemLabelIfRequired(i, o);
            var s = n.tooltipConfig;
            return [s.left, s.top]
        }
    },
    getStyledInfoList: function(e, t) {
        var i, r;
        for (i = '<table class="info-list-table">', i += '<tr><td colspan="2" class="info-list-time-text">' + e + "</td></tr>", r = 0; r < t.length; ++r) i += '<tr style="color:' + t[r].fontColor + '"><td class="info-list-content-name">' + t[r].name + '</td><td align="right" class="info-list-content-value">' + t[r].value + "</td></tr>";
        return i += "</table>"
    },
    calculateTableHeight: function(e, t) {
        var i = getComputedStyle(e);
        return parseInt(i.height) - t
    },
    calculateMaximumTableHeight: function(e, t, i) {
        var r = SYNO.SDS.ResourceMonitor.Performance.Chart.Util,
            a = r.tooltipConfig,
            o = a.top,
            n = a.bottom,
            s = a.border,
            c = a.verticalPadding,
            l = getComputedStyle(e);
        return parseInt(l.height) - (o + n) - 2 * (c + s) - t - (i ? r.tooltipConfig.sliderbarHeight : 0)
    },
    getInfoNodeList: function(e) {
        var t = SYNO.SDS.ResourceMonitor.Performance.Chart.Util,
            i = t.tooltipConfig.tableClass;
        return e.querySelector(".".concat(i)).querySelectorAll("tr:not(:first-child)")
    },
    calculateMaximumInfoNum: function(e) {
        var t = SYNO.SDS.ResourceMonitor.Performance.Chart.Util,
            i = t.tooltipConfig.infoHeight,
            r = Math.floor(e / i) - 1;
        return Math.max(r, 0)
    },
    removeHiddenInfoNode: function(e, t) {
        for (var i = e.length, r = t; r < i; ++r) e[r].remove()
    },
    createMoreItemLabelTr: function(e) {
        var t = SYNO.SDS.ResourceMonitor.Performance.Chart.Util,
            i = t.tooltipConfig.moreItemLabelClass,
            r = document.createElement("td");
        r.classList.add(i), r.innerHTML = "".concat(e, " more items...");
        var a = document.createElement("tr");
        return a.appendChild(r), a
    },
    getTableBodyDom: function(e) {
        return e.querySelector("tbody")
    },
    displayMoreItemLabelIfRequired: function(e, t) {
        var i = SYNO.SDS.ResourceMonitor.Performance.Chart.Util,
            r = i.tooltipConfig.dateSectionHeight,
            a = i.calculateTableHeight(e, r),
            o = e.offsetParent,
            n = o ? i.calculateMaximumTableHeight(o, r, t) : _this3.minSizeOfChart;
        if (a > n) {
            var s = i.getInfoNodeList(e),
                c = i.calculateMaximumInfoNum(n);
            i.removeHiddenInfoNode(s, c);
            var l = s.length - c,
                d = i.createMoreItemLabelTr(l);
            i.getTableBodyDom(e).appendChild(d)
        }
    }
}, Ext.define("SYNO.SDS.ResourceMonitor.Performance.DataSet", {
    extend: "Ext.util.Observable",
    constructor: function(e) {
        this.data = [];
        var t = Ext.apply({
            totalTime: 360
        }, e);
        Ext.apply(this, t), this.callParent([t])
    },
    pushData: function(e, t) {
        var i = t - this.totalTime,
            r = 0;
        for (0 == this.data.length && this.data.push([t - SYNO.SDS.ResourceMonitor.Performance.CurrentInterval, 0]), this.data.push([t, e]), r = 0; this.data[r][0] < i; ++r);
        2 <= r && (this.data = this.data.slice(r - 2))
    },
    genSeries: function() {
        return {
            type: "line",
            data: this.data,
            lineStyle: this.lineStyle,
            areaStyle: this.areaStyle,
            symbol: "circle",
            symbolSize: 0,
            name: this.lineName,
            color: this.color,
            id: this.itemId,
            z: this.z
        }
    },
    getLastTime: function() {
        var e = this.data[this.data.length - 1];
        return e ? e[0] : 0
    },
    getMaxDataValue: function() {
        return this.data.reduce(function(e, t) {
            return Math.max(e, t[1])
        }, 0)
    },
    clear: function() {
        this.data.length = 0
    },
    getLastDataValue: function() {
        var e = this.data[this.data.length - 1];
        return e ? e[1] : 0
    }
}), Ext.ns("SYNO.SDS.ResourceMonitor.Performance"), SYNO.SDS.ResourceMonitor.Performance.TotalTime = 360, SYNO.SDS.ResourceMonitor.Performance.FlexDiv = function(e) {
    return ['<div style="display: flex; align-items: center;">', e, "</div>"].join("")
}, SYNO.SDS.ResourceMonitor.Performance.ModuleTable = {
    cpu: function(e) {
        return new SYNO.SDS.ResourceMonitor.Performance.Overview.CPU({
            topLayer: e
        })
    },
    gpu: function(e) {
        return new SYNO.SDS.ResourceMonitor.Performance.Overview.GPU({
            topLayer: e
        })
    },
    memory: function(e) {
        return new SYNO.SDS.ResourceMonitor.Performance.Overview.Memory({
            topLayer: e
        })
    },
    gpu_memory: function(e) {
        return new SYNO.SDS.ResourceMonitor.Performance.Overview.GPUMemory({
            topLayer: e
        })
    },
    network: function(e) {
        return new SYNO.SDS.ResourceMonitor.Performance.Overview.Network({
            topLayer: e
        })
    },
    space: function(e) {
        return new SYNO.SDS.ResourceMonitor.Performance.Overview.Space({
            topLayer: e
        })
    },
    iscsi: function(e) {
        return new SYNO.SDS.ResourceMonitor.Performance.Overview.Lun({
            topLayer: e
        })
    },
    nfs: function(e) {
        return new SYNO.SDS.ResourceMonitor.Performance.Overview.NFS({
            topLayer: e
        })
    },
    middle: function(e) {
        return new SYNO.SDS.ResourceMonitor.Performance.Overview.Middle({})
    }
}, Ext.define("SYNO.SDS.ResourceMonitor.Performance.Overview.Middle", {
    extend: "Ext.BoxComponent",
    width: 18,
    border: !1
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Overview.Main", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = this.GetSupportedChartList(e.show_nfs),
            i = new SYNO.SDS.ResourceMonitor.Performance.Overview.Row({
                topLayer: e.topLayer,
                appWin: e.appWin,
                chartList: t.splice(0, Math.ceil(t.length / 2)),
                flex: 1
            }),
            r = {
                xtype: "box",
                height: 16,
                border: !1
            },
            a = new SYNO.SDS.ResourceMonitor.Performance.Overview.Row({
                topLayer: e.topLayer,
                appWin: e.appWin,
                chartList: t,
                flex: 1
            }),
            o = Ext.apply({
                layout: "vbox",
                layoutConfig: {
                    align: "stretch"
                },
                items: [i, r, a],
                listeners: {
                    activate: this.onActivate,
                    scope: this
                }
            }, e);
        this.callParent([o])
    },
    onActivate: function() {
        this.items.each(function(e) {
            Ext.isFunction(e.onActivate) && e.onActivate()
        }, this)
    },
    GetSupportedChartList: function(e) {
        var t = [];
        return t = _D("support_nvidia_gpu") ? t.concat(["cpu", "gpu", "memory", "gpu_memory", "network"]) : t.concat(["cpu", "memory", "network"]), "yes" !== _D("usbstation") && t.push("space"), "yes" === _D("support_iscsi_target", "no") && t.push("iscsi"), e && t.push("nfs"), t
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Overview.Row", {
    extend: "Ext.Container",
    constructor: function(e) {
        this.topLayer = e.topLayer, this.chartList = e.chartList;
        var t = Ext.apply({
            layout: "hbox",
            layoutConfig: {
                align: "stretch"
            },
            items: this.getComponentItems()
        }, e);
        this.callParent([t])
    },
    onActivate: function() {
        this.items.each(function(e) {
            Ext.isFunction(e.onActivate) && e.onActivate()
        }, this)
    },
    addMiddleBuffer: function() {
        var e = this.chartList.reduce(function(e, t) {
            return e.concat(t, "middle")
        }, []);
        return e.pop(), e
    },
    getComponentItems: function() {
        var e = this,
            t = SYNO.SDS.ResourceMonitor.Performance.ModuleTable;
        return this.addMiddleBuffer().filter(function(e) {
            return t.hasOwnProperty(e)
        }).map(function(i) {
            return t[i](e.topLayer)
        })
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Overview.Base", {
    extend: "SYNO.ux.Panel",
    summary_title: "Base",
    colors: ["#00A8F0"],
    totalTime: SYNO.SDS.ResourceMonitor.Performance.TotalTime,
    lastChartData: null,
    flex: 1,
    constructor: function(e) {
        var t = this,
            i = Ext.apply({
                cls: "overview-chart-box",
                border: !1,
                layout: "vbox",
                items: [{
                    itemId: "header",
                    xtype: "box",
                    height: 18
                }, {
                    itemId: "chart",
                    cls: "chart-box",
                    xtype: "box",
                    flex: 1,
                    ref: "chart"
                }, {
                    itemId: "footer",
                    height: 20,
                    xtype: "box"
                }],
                listeners: {
                    scope: this,
                    afterRender: function() {
                        return t.body.removeClass("x-panel-body")
                    }
                }
            }, e);
        this.callParent([i])
    },
    initEvents: function() {
        var e = this;
        this.callParent(arguments), this.mon(this.topLayer, "data_comming", function(t) {
            e.updateData(t)
        }, this), this.mon(this.topLayer, "resize", this.drawResize, this), this.mon(this, "resize", this.drawResize, this), this.doLayout(), this.drawEmptyChart()
    },
    drawResize: function() {
        null !== this.lastChartData && this.topLayer.isVisible() && this.isVisible() && "overview_main" === this.topLayer.activeTab.itemId && (this.updateChartWidth(), this.doLayout(), this.echarts.resize())
    },
    drawChart: function(e, t, i) {
        var r = this.get("header"),
            a = this.get("footer");
        this.lastChartData = {
            options: e,
            header: t,
            footer: i
        }, this.topLayer.isVisible() && this.isVisible() && "overview_main" === this.topLayer.activeTab.itemId && (r.update(t), a.update(i), this.updateChartWidth(), this.echarts || (this.echarts = echarts.init(this.chart.getEl().dom)), this.echarts.setOption(e))
    },
    updateChartWidth: function() {
        var e = this.get("header"),
            t = this.get("footer");
        this.chart.setWidth(this.getWidth()), e.setWidth(this.getWidth()), t.setWidth(this.getWidth())
    },
    getChartType: function() {
        var e = echarts.syno.getDefaultOptions();
        return e.color = this.colors, e.grid.top = 0, e.grid.left = 0, e.grid.right = 0, e.grid.bottom = 0, e.xAxis.axisLabel.show = !1, e.yAxis.axisLabel.show = !1, e.tooltip.show = !1, e
    },
    onActivate: function() {
        null === this.lastChartData || this.hidden || (this.drawChart(this.lastChartData.options, this.lastChartData.header, this.lastChartData.footer), this.drawResize())
    },
    getHeader: function() {
        return "<div class=".concat(this.marginals.header_class, "> ").concat(this.marginals.header_title, " </div>")
    },
    getFooter: function(e) {
        return SYNO.SDS.ResourceMonitor.Performance.FlexDiv("<span class=".concat(this.marginals.footer_class, "> ").concat(this.marginals.footer_value_title, " &nbsp(%)</span>") + "<span class=".concat(this.marginals.footer_value_class, "> ").concat(e, "% </span>"))
    },
    drawEmptyChart: function() {
        var e = this.getChartType(),
            t = this.getHeader(),
            i = this.getFooter(0);
        e.series = [this.getDataSet().genSeries()], this.drawChart(e, t, i)
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Overview.CPU", {
    extend: "SYNO.SDS.ResourceMonitor.Performance.Overview.Base",
    colors: ["#1A8CBF"],
    marginals: {
        header_title: _T("rsrcmonitor", "cpu"),
        header_class: "cpu-title",
        footer_class: "cpu-content",
        footer_value_class: "cpu-content-value",
        footer_value_title: _T("rsrcmonitor", "utilization")
    },
    constructor: function(e) {
        this.callParent([e]), this.usageSet = new SYNO.SDS.ResourceMonitor.Performance.DataSet({
            lineStyle: {
                width: 2
            },
            areaStyle: {
                color: "#18ADE7",
                opacity: .6
            }
        })
    },
    updateData: function(e) {
        if (e.time && e.cpu) {
            var t = this.getChartType(),
                i = e.time,
                r = e.cpu.user_load + e.cpu.system_load;
            this.usageSet.pushData(r, i), t.xAxis.max = this.usageSet.getLastTime(), t.xAxis.min = t.xAxis.max - this.totalTime, t.yAxis.min = 0, t.yAxis.max = 100, t.series = [this.usageSet.genSeries()];
            var a = this.getHeader(),
                o = this.getFooter(r);
            this.drawChart(t, a, o)
        }
    },
    getDataSet: function() {
        return this.usageSet
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Overview.Memory", {
    extend: "SYNO.SDS.ResourceMonitor.Performance.Overview.Base",
    colors: ["#DA8F25"],
    marginals: {
        header_title: _T("rsrcmonitor", "memory"),
        header_class: "mem-title",
        footer_class: "mem-content",
        footer_value_class: "mem-content-value",
        footer_value_title: _T("rsrcmonitor", "utilization")
    },
    constructor: function(e) {
        this.callParent([e]), this.usageSet = new SYNO.SDS.ResourceMonitor.Performance.DataSet({
            lineStyle: {
                width: 2
            },
            areaStyle: {
                color: "#FFAC69",
                opacity: .6
            }
        })
    },
    updateData: function(e) {
        if (e.time && e.memory) {
            var t = this.getChartType(),
                i = e.time,
                r = e.memory.real_usage;
            this.usageSet.pushData(r, i), t.xAxis.max = this.usageSet.getLastTime(), t.xAxis.min = t.xAxis.max - this.totalTime, t.yAxis.min = 0, t.yAxis.max = 100, t.series = [this.usageSet.genSeries()];
            var a = this.getHeader(),
                o = this.getFooter(r);
            this.drawChart(t, a, o)
        }
    },
    getDataSet: function() {
        return this.usageSet
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Overview.GPU", {
    extend: "SYNO.SDS.ResourceMonitor.Performance.Overview.Base",
    colors: ["#5E5EEB"],
    marginals: {
        header_title: _T("rsrcmonitor", "gpu"),
        header_class: "cpu-title",
        footer_class: "cpu-content",
        footer_value_class: "cpu-content-value",
        footer_value_title: _T("rsrcmonitor", "utilization")
    },
    constructor: function(e) {
        this.callParent([e]), this.usageSet = new SYNO.SDS.ResourceMonitor.Performance.DataSet({
            lineStyle: {
                width: 2
            },
            areaStyle: {
                color: "#8181EB",
                opacity: .6
            }
        })
    },
    updateData: function(e) {
        if (e.time && e.gpu) {
            var t = this.getChartType(),
                i = e.time,
                r = e.gpu.gpu_utilization;
            this.usageSet.pushData(r, i), t.xAxis.max = this.usageSet.getLastTime(), t.xAxis.min = t.xAxis.max - this.totalTime, t.yAxis.min = 0, t.yAxis.max = 100, t.series = [this.usageSet.genSeries()];
            var a = this.getHeader(),
                o = this.getFooter(r);
            this.drawChart(t, a, o)
        }
    },
    getDataSet: function() {
        return this.usageSet
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Overview.GPUMemory", {
    extend: "SYNO.SDS.ResourceMonitor.Performance.Overview.Base",
    colors: ["#E0907C"],
    marginals: {
        header_title: _T("rsrcmonitor", "gpu_memory"),
        header_class: "mem-title",
        footer_class: "mem-content",
        footer_value_class: "mem-content-value",
        footer_value_title: _T("rsrcmonitor", "utilization")
    },
    constructor: function(e) {
        this.callParent([e]), this.usageSet = new SYNO.SDS.ResourceMonitor.Performance.DataSet({
            lineStyle: {
                width: 2
            },
            areaStyle: {
                color: "#F2A996",
                opacity: .7
            }
        })
    },
    updateData: function(e) {
        if (e.time && e.gpu) {
            var t = this.getChartType(),
                i = e.time,
                r = e.gpu.gpu_memory_utilization;
            this.usageSet.pushData(r, i), t.xAxis.max = this.usageSet.getLastTime(), t.xAxis.min = t.xAxis.max - this.totalTime, t.yAxis.min = 0, t.yAxis.max = 100, t.series = [this.usageSet.genSeries()];
            var a = this.getHeader(),
                o = this.getFooter(r);
            this.drawChart(t, a, o)
        }
    },
    getDataSet: function() {
        return this.usageSet
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Overview.Space", {
    extend: "SYNO.SDS.ResourceMonitor.Performance.Overview.Base",
    marginals: {
        header_title: _T("tree", "leaf_volume"),
        header_class: "disk-title",
        footer_class: "disk-content",
        footer_value_class: "disk-content-value",
        footer_value_title: _T("rsrcmonitor", "utilization")
    },
    constructor: function(e) {
        this.callParent([e]), this.throughput_read = new SYNO.SDS.ResourceMonitor.Performance.DataSet({
            lineStyle: {
                color: "#D97490",
                width: 2
            },
            areaStyle: {
                color: "#F5A1A1",
                opacity: .6
            },
            z: 2
        }), this.throughput_write = new SYNO.SDS.ResourceMonitor.Performance.DataSet({
            lineStyle: {
                color: "#E4A040",
                width: 2
            },
            areaStyle: {
                color: "#F4CB66",
                opacity: .6
            },
            z: 1
        })
    },
    updateData: function(e) {
        if (e.time && e) {
            var t = this.getChartType(),
                i = e.time,
                r = e.space;
            if (r && r.total) {
                this.throughput_read.pushData(r.total.read_byte, i), this.throughput_write.pushData(r.total.write_byte, i);
                var a = 1.1 * Math.max(this.throughput_read.getMaxDataValue(), this.throughput_write.getMaxDataValue());
                t.yAxis.max = Math.max(a, 102400), t.yAxis.min = 0, t.xAxis.max = Math.max(this.throughput_read.getLastTime(), this.throughput_write.getLastTime()), t.xAxis.min = t.xAxis.max - this.totalTime, t.series = [this.throughput_read.genSeries(), this.throughput_write.genSeries()];
                var o = this.getHeader(),
                    n = this.getFooter({
                        read_byte: r.total.read_byte,
                        write_byte: r.total.write_byte
                    });
                this.drawChart(t, o, n)
            }
        }
    },
    getFooter: function(e) {
        return SYNO.SDS.ResourceMonitor.Performance.FlexDiv('<span class="throughput-content-icon space-read"></span><span class="throughput-content-value space-read">' + Ext.util.Format.fileSize(e.read_byte) + '/s</span><span class="throughput-content-icon space-write"></span><span class="throughput-content-value space-write">' + Ext.util.Format.fileSize(e.write_byte) + "/s</span>")
    },
    drawEmptyChart: function() {
        var e = this.getChartType(),
            t = this.getHeader(),
            i = this.getFooter({
                read_byte: 0,
                write_byte: 0
            });
        e.series = [this.throughput_read.genSeries(), this.throughput_write.genSeries()], this.drawChart(e, t, i)
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Overview.Network", {
    extend: "SYNO.SDS.ResourceMonitor.Performance.Overview.Base",
    marginals: {
        header_title: _T("rsrcmonitor", "network"),
        header_class: "network-title"
    },
    constructor: function(e) {
        this.callParent([e]), this.uploadSet = new SYNO.SDS.ResourceMonitor.Performance.DataSet({
            lineStyle: {
                color: "#1574E8",
                width: 2
            },
            areaStyle: {
                color: "#6794FF",
                opacity: .6
            },
            z: 2
        }), this.downloadSet = new SYNO.SDS.ResourceMonitor.Performance.DataSet({
            lineStyle: {
                color: "#09B3B3",
                width: 2
            },
            areaStyle: {
                color: "#20D6CF",
                opacity: .6
            },
            z: 1
        })
    },
    updateData: function(e) {
        if (e.time && e.network) {
            var t = this.getChartType(),
                i = e.time,
                r = e.network.find(function(e) {
                    return "total" === e.device
                });
            if (r) {
                this.uploadSet.pushData(r.tx, i), this.downloadSet.pushData(r.rx, i);
                var a = 1.1 * Math.max(this.uploadSet.getMaxDataValue(), this.downloadSet.getMaxDataValue());
                t.yAxis.max = Math.max(a, 102400), t.xAxis.max = Math.max(this.uploadSet.getLastTime(), this.downloadSet.getLastTime()), t.xAxis.min = t.xAxis.max - this.totalTime, t.series = [this.uploadSet.genSeries(), this.downloadSet.genSeries()];
                var o = this.getHeader(),
                    n = this.getFooter({
                        tx: r.tx,
                        rx: r.rx
                    });
                this.drawChart(t, o, n)
            }
        }
    },
    getFooter: function(e) {
        return SYNO.SDS.ResourceMonitor.Performance.FlexDiv('<span class="network-content-icon network-out"></span><span class="network-content-value network-out">' + Ext.util.Format.fileSize(e.tx) + '/s</span><span class="network-content-icon network-in"></span><span class="network-content-value network-in">' + Ext.util.Format.fileSize(e.rx) + "/s</span>")
    },
    drawEmptyChart: function() {
        var e = this.getChartType(),
            t = this.getHeader(),
            i = this.getFooter({
                tx: 0,
                rx: 0
            });
        e.series = [this.uploadSet.genSeries(), this.downloadSet.genSeries()], this.drawChart(e, t, i)
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Overview.Lun", {
    extend: "SYNO.SDS.ResourceMonitor.Performance.Overview.Base",
    marginals: {
        header_title: _T("tree", "leaf_iscsilun"),
        header_class: "lun-title"
    },
    constructor: function(e) {
        this.callParent([e]), this.throughput_read = new SYNO.SDS.ResourceMonitor.Performance.DataSet({
            lineStyle: {
                color: "#3BB5B5",
                width: 2
            },
            areaStyle: {
                color: "#64D5CC",
                opacity: .6
            },
            z: 2
        }), this.throughput_write = new SYNO.SDS.ResourceMonitor.Performance.DataSet({
            lineStyle: {
                color: "#73BB4D",
                width: 2
            },
            areaStyle: {
                color: "#90DA81",
                opacity: .6
            },
            z: 1
        })
    },
    updateData: function(e) {
        if (e.time && e.lun) {
            var t = this.getChartType(),
                i = e.time,
                r = e.lun.reduce(function(e, t) {
                    return e + t.read_throughput
                }, 0),
                a = e.lun.reduce(function(e, t) {
                    return e + t.write_throughput
                }, 0);
            this.throughput_read.pushData(r, i), this.throughput_write.pushData(a, i);
            var o = 1.1 * Math.max(this.throughput_read.getMaxDataValue(), this.throughput_write.getMaxDataValue());
            t.yAxis.max = Math.max(o, 102400), t.xAxis.max = Math.max(this.throughput_read.getLastTime(), this.throughput_write.getLastTime()), t.xAxis.min = t.xAxis.max - this.totalTime, t.series = [this.throughput_read.genSeries(), this.throughput_write.genSeries()];
            var n = this.getHeader(),
                s = this.getFooter({
                    read_byte: r,
                    write_byte: a
                });
            this.drawChart(t, n, s)
        }
    },
    getFooter: function(e) {
        return SYNO.SDS.ResourceMonitor.Performance.FlexDiv('<span class="throughput-content-icon lun-read"></span><span class="throughput-content-value lun-read">' + Ext.util.Format.fileSize(e.read_byte) + '/s</span><span class="throughput-content-icon lun-write"></span><span class="throughput-content-value lun-write">' + Ext.util.Format.fileSize(e.write_byte) + "/s</span>")
    },
    drawEmptyChart: function() {
        var e = this.getChartType(),
            t = this.getHeader(),
            i = this.getFooter({
                read_byte: 0,
                write_byte: 0
            });
        e.series = [this.throughput_read.genSeries(), this.throughput_write.genSeries()], this.drawChart(e, t, i)
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Overview.NFS", {
    extend: "SYNO.SDS.ResourceMonitor.Performance.Overview.Base",
    marginals: {
        header_title: _T("tree", "leaf_nfs"),
        header_class: "nfs-title"
    },
    constructor: function(e) {
        this.callParent([e]), this.iops_read = new SYNO.SDS.ResourceMonitor.Performance.DataSet({
            lineStyle: {
                color: "#A27ED5",
                width: 2
            },
            areaStyle: {
                color: "#B491E6",
                opacity: .6
            },
            z: 2
        }), this.iops_write = new SYNO.SDS.ResourceMonitor.Performance.DataSet({
            lineStyle: {
                color: "#CE90CE",
                width: 2
            },
            areaStyle: {
                color: "#DD96D5",
                opacity: .6
            },
            z: 1
        })
    },
    updateData: function(e) {
        if (e.time && e.nfs) {
            var t = e.time,
                i = e.nfs[0] && e.nfs[0].read_OPS || 0,
                r = e.nfs[0] && e.nfs[0].write_OPS || 0;
            this.iops_read.pushData(i, t), this.iops_write.pushData(r, t);
            var a = this.getChartType();
            a.yAxis.max = 1.1 * Math.max(this.iops_read.getMaxDataValue(), this.iops_write.getMaxDataValue()), a.xAxis.max = Math.max(this.iops_read.getLastTime(), this.iops_write.getLastTime()), a.xAxis.min = a.xAxis.max - this.totalTime, a.series = [this.iops_read.genSeries(), this.iops_write.genSeries()];
            var o = this.getHeader(),
                n = this.getFooter({
                    iops_read: i,
                    iops_write: r
                });
            this.drawChart(a, o, n)
        }
    },
    getFooter: function(e) {
        return SYNO.SDS.ResourceMonitor.Performance.FlexDiv('<span class="throughput-content-icon nfs-read"></span><span class="throughput-content-value nfs-read">' + e.iops_read + '/s</span><span class="throughput-content-icon nfs-write"></span><span class="throughput-content-value nfs-write">' + e.iops_write + "/s</span>")
    },
    drawEmptyChart: function() {
        var e = this.getChartType(),
            t = this.getHeader(),
            i = this.getFooter({
                iops_read: 0,
                iops_write: 0
            });
        e.series = [this.iops_read.genSeries(), this.iops_write.genSeries()], this.drawChart(e, t, i)
    }
}), Ext.ns("SYNO.SDS.ResourceMonitor.Performance.CPU"), SYNO.SDS.ResourceMonitor.Performance.CPU.Line = function(e, t, i) {
    return [{
        itemId: e,
        lineName: _T("rsrcmonitor", "iowait"),
        color: "#4D74DF",
        trackOrder: 3,
        lineStyle: {
            width: 0
        },
        areaStyle: {
            opacity: 1
        }
    }, {
        itemId: t,
        lineName: _T("rsrcmonitor", "cpu_system"),
        color: "#2AB5F1",
        trackOrder: 2,
        lineStyle: {
            width: 1
        },
        areaStyle: {
            opacity: 1
        }
    }, {
        itemId: i,
        lineName: _T("rsrcmonitor", "cpu_user"),
        color: "#18E19D",
        fontColor: "#16CC8F",
        trackOrder: 1,
        lineStyle: {
            width: 1
        },
        areaStyle: {
            opacity: 1
        }
    }]
}, Ext.define("SYNO.SDS.ResourceMonitor.Performance.CPU.Main", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = Ext.apply({
            layout: "anchor",
            items: [],
            listeners: {
                activate: this.onActivate,
                scope: this
            }
        }, e);
        this.callParent([t])
    },
    createComponent: function(e) {
        var t = this,
            i = e.showHistory,
            r = !1;
        t.chartHeader ? t.chartHeader.setToRealTime() : (t.chartHeader = new SYNO.SDS.ResourceMonitor.Performance.Detail.Header({
            header_title: _T("rsrcmonitor", "cpu"),
            topLayer: e.topLayer
        }), t.add(t.chartHeader), t.content || (t.content = new SYNO.SDS.ResourceMonitor.Performance.CPU.Content({
            topLayer: e.topLayer,
            anchor: "100% -37",
            header: t.chartHeader
        }), t.add(t.content)), r = !0), i === t.chartHeader.history_combo.hidden && (i ? (t.chartHeader.history_combo.show(), t.chartHeader.history_label.show()) : (t.chartHeader.history_combo.hide(), t.chartHeader.history_label.hide()), r = !0), r && t.doLayout(!1, !0)
    },
    onActivate: function() {
        this.items.each(function(e) {
            Ext.isFunction(e.onActivate) && e.onActivate()
        }, this)
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.CPU.Content", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = {
            cls: "chart-content",
            layout: "card",
            activeItem: 0,
            items: [new SYNO.SDS.ResourceMonitor.Performance.CPU.Current({
                itemId: "current",
                topLayer: e.topLayer,
                controlLayer: this
            }), new SYNO.SDS.ResourceMonitor.Performance.CPU.History({
                itemId: "history",
                topLayer: e.topLayer,
                controlLayer: this
            })]
        };
        Ext.apply(t, e), this.callParent([t]), this.mon(e.header, "contentSelect", this.changeContent, this)
    },
    changeContent: function(e) {
        "current" === e.history ? this.layout.setActiveItem("current") : (this.layout.setActiveItem("history"), this.get("history").setType(e.history))
    },
    setToRealTime: function() {
        this.header.setToRealTime()
    },
    onActivate: function() {
        var e = this.layout.activeItem;
        Ext.isDefined(e) && Ext.isFunction(e.onActivate) && e.onActivate()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.CPU.Current", {
    extend: "Ext.Panel",
    constructor: function(e) {
        this.chart = new SYNO.SDS.ResourceMonitor.Performance.Chart.Current({
            cls: "current-chart",
            chartTitle: _T("rsrcmonitor", "utilization") + " (%)",
            flex: 1,
            topLayer: e.topLayer,
            aggregate: !0,
            totalTime: SYNO.SDS.ResourceMonitor.Performance.CurrentTotalTime,
            lines: SYNO.SDS.ResourceMonitor.Performance.CPU.Line("iowait", "cpu_system", "cpu_user"),
            dataType: "percent"
        });
        var t = {
            layout: "vbox",
            layoutConfig: {
                align: "stretch"
            },
            border: !1,
            items: [this.chart, new SYNO.SDS.ResourceMonitor.Performance.CPU.Current.Footer({
                itemId: "footer",
                topLayer: e.topLayer
            })]
        };
        Ext.apply(t, e), this.callParent([t])
    },
    initEvents: function() {
        var e = this;
        SYNO.SDS.ResourceMonitor.Performance.CPU.Current.superclass.initEvents.apply(e, arguments), e.mon(e.topLayer, "data_comming", function(t) {
            e.updateData(t)
        }), e.mon(e, "activate", e.onActivate, e)
    },
    updateData: function(e) {
        if (e.time && e.cpu) {
            var t = this,
                i = e.cpu,
                r = e.time;
            t.chart.pushValue([i.other_load, i.system_load, i.user_load], r), t.chart.drawChart()
        }
    },
    onActivate: function() {
        this.chart.drawChart()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.CPU.Current.Footer", {
    extend: "Ext.Panel",
    constructor: function(e) {
        var t = this;
        this.legendId = {};
        var i = {
            layout: "hbox",
            cls: "legend",
            border: !1,
            items: [{
                xtype: "box",
                border: !1,
                html: t.createUtilTbl()
            }, {
                xtype: "box",
                border: !1,
                flex: 1
            }, {
                xtype: "box",
                border: !1,
                html: t.createLoadAvarageTbl()
            }]
        };
        Ext.apply(i, e), this.callParent([i])
    },
    initEvents: function() {
        SYNO.SDS.ResourceMonitor.Performance.CPU.Current.Footer.superclass.initEvents.apply(this, arguments);
        var e = this;
        e.mon(e.topLayer, "data_comming", function(t) {
            e.updateData(t)
        })
    },
    updateData: function(e) {
        if (e.cpu) {
            var t = this,
                i = e.cpu,
                r = {},
                a = {};
            r = {
                utilization: i.user_load + i.system_load,
                user: i.user_load,
                system: i.system_load,
                others: i.other_load
            }, a = {
                "1min": Math.round(i["1min_load"]) / 100,
                "5min": Math.round(i["5min_load"]) / 100,
                "15min": Math.round(i["15min_load"]) / 100
            }, t.updateUtilTbl(r), t.updateLoadAvarageTbl(a), t.doLayout()
        }
    },
    createLegendCard: function(e, t, i) {
        return '<div class="legend-card">' + '  <div class="'.concat(e, ' legend-color-item"></div>') + "  <div>" + '    <div class="legend-value-header">'.concat(t, "</div>") + "    <div>".concat(i, "</div>") + "  </div></div>"
    },
    createUtilTbl: function() {
        var e = this,
            t = e.legendId;
        t.util = Ext.id(), t.user = Ext.id(), t.system = Ext.id(), t.others = Ext.id();
        var i = function(t, i, r) {
                return e.createLegendCard(t, i, '<span class="legend-value" id=\''.concat(r, "'>0</span>") + '<span class="legend-value-unit">%</span>')
            },
            r = i("legend-color-user", _T("rsrcmonitor", "cpu_user"), t.user) + i("legend-color-system", _T("rsrcmonitor", "cpu_system"), t.system) + i("legend-color-others", _T("rsrcmonitor", "iowait"), t.others);
        return '<div class="legend-header">' + '  <span class="legend-header-title">'.concat(_T("rsrcmonitor", "utilization"), "</span>") + '  <span class="legend-header-value" id='.concat(t.util, " >0</span>") + '  <span class="legend-value-unit-large">%</span></div><div class="legend-header-bar"></div><div class="legend-util-content">' + r + "</div>"
    },
    updateUtilTbl: function(e) {
        var t = this;
        Ext.fly(t.legendId.util).update("" + e.utilization), Ext.fly(t.legendId.user).update("" + e.user), Ext.fly(t.legendId.system).update("" + e.system), Ext.fly(t.legendId.others).update("" + e.others)
    },
    createLoadAvarageTbl: function() {
        var e = this,
            t = e.legendId;
        t._1min = Ext.id(), t._5min = Ext.id(), t._15min = Ext.id();
        var i = function(t, i) {
                return e.createLegendCard("legend-color-average", t, '<span class="legend-value" id=\''.concat(i, "'>0</span>"))
            },
            r = i("1 ".concat(_T("rsrcmonitor", "minute")), t._1min) + i("5 ".concat(_T("rsrcmonitor", "minutes")), t._5min) + i("15 ".concat(_T("rsrcmonitor", "minutes")), t._15min);
        return '<div class="legend-header">' + '  <span class="legend-header-title">'.concat(_T("rsrcmonitor", "load_average"), "</span>") + '</div><div class="legend-header-bar"></div><div class="legend-load-content">' + r + "</div>"
    },
    updateLoadAvarageTbl: function(e) {
        var t = this;
        Ext.fly(t.legendId._1min).update(e["1min"] + ""), Ext.fly(t.legendId._5min).update(e["5min"] + ""), Ext.fly(t.legendId._15min).update(e["15min"] + "")
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.CPU.History", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = {},
            i = '<table width="100%" style="table-layout:fixed;"><tbody><tr><td class="legend-text" style="min-width: 80px"><div class = "legend-color-dot legend-color-user"></div>' + _T("rsrcmonitor", "cpu_user") + '</td><td class="legend-text" style="min-width: 80px"><div class = "legend-color-dot legend-color-system"></div>' + _T("rsrcmonitor", "cpu_system") + '</td><td class="legend-text" style="min-width: 80px"><div class = "legend-color-dot legend-color-others"></div>' + _T("rsrcmonitor", "iowait") + '</td><td class="legend-text" style="min-width: 80px"></td></tr></tbody></table>';
        this.chart = new SYNO.SDS.ResourceMonitor.Performance.Chart.History({
            chartTitle: _T("rsrcmonitor", "utilization") + " (%)",
            flex: 1,
            topLayer: e.topLayer
        }), t = {
            layout: "vbox",
            layoutConfig: {
                align: "stretch"
            },
            items: [this.chart, {
                xtype: "box",
                margins: {
                    top: 8,
                    right: 0,
                    bottom: 0,
                    left: 38
                },
                height: 24,
                border: !1,
                html: i
            }]
        }, Ext.apply(t, e), this.callParent([t])
    },
    setType: function(e) {
        this.topLayer.setStatusLoading(), SYNO.API.Request({
            api: "SYNO.Core.System.Utilization",
            appWindow: this.topLayer.appWin,
            method: "get",
            version: 1,
            params: {
                type: "history",
                resource: ["cpu"],
                time_range: e
            },
            scope: this,
            callback: this.LoadHistoryData
        })
    },
    LoadHistoryData: function(e, t, i, r) {
        if (this.topLayer.clearStatusLoading(), !e || !t) {
            var a = this.topLayer.webapiErrorMapper(t ? t.code : 0);
            return void this.getEl().mask(a)
        }
        if (!t.data_size) return void this.getEl().mask(_T("rsrcmonitor", "no_history"));
        this.getEl().unmask(), this.drawCharts(t, i)
    },
    drawCharts: function(e, t) {
        var i = {};
        i = {
            chartTitle: _T("rsrcmonitor", "utilization") + " (%)",
            aggregate: !0,
            lines: SYNO.SDS.ResourceMonitor.Performance.CPU.Line("other_load", "system_load", "user_load"),
            timeAxis: t.time_range,
            dataType: "percent",
            data: e.cpu,
            dataSize: e.data_size,
            endTime: e.time,
            timeInterval: e.interval
        }, this.chart.setChartConfig(i), this.chart.drawChart()
    }
}), Ext.ns("SYNO.SDS.ResourceMonitor.Performance.Memory"), SYNO.SDS.ResourceMonitor.Performance.Memory.MemoryLine = function(e) {
    return [{
        itemId: e,
        lineName: _T("rsrcmonitor", "utilization"),
        color: "#1574E8",
        lineStyle: {
            color: "#1574E8",
            width: 2
        },
        areaStyle: {
            color: "#4C9DFF",
            opacity: .6
        }
    }]
}, SYNO.SDS.ResourceMonitor.Performance.Memory.SwapLine = function(e, t) {
    return [{
        itemId: t,
        lineName: _T("rsrcmonitor", "so_descr"),
        color: "#09B3B3",
        lineStyle: {
            color: "#09B3B3",
            width: 2
        },
        areaStyle: {
            color: "#20D6CF",
            opacity: .6
        }
    }, {
        itemId: e,
        lineName: _T("rsrcmonitor", "si_descr"),
        color: "#1574E8",
        lineStyle: {
            color: "#1574E8",
            width: 2
        },
        areaStyle: {
            color: "#4C9DFF",
            opacity: .6
        }
    }]
}, Ext.define("SYNO.SDS.ResourceMonitor.Performance.Memory.Main", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = Ext.apply({
            layout: "anchor",
            items: [],
            listeners: {
                activate: {
                    fn: this.onActivate,
                    scope: this
                }
            }
        }, e);
        this.callParent([t])
    },
    createComponent: function(e) {
        var t = this,
            i = !1,
            r = e.showHistory;
        t.chartHeader ? t.chartHeader.setToRealTime() : (t.chartHeader = new SYNO.SDS.ResourceMonitor.Performance.Detail.Header({
            header_title: _T("rsrcmonitor", "memory"),
            topLayer: e.topLayer,
            type_combo: {
                data: [
                    ["usage", _T("rsrcmonitor", "physical_memory")],
                    ["swap", _T("rsrcmonitor", "swap")]
                ]
            }
        }), t.add(t.chartHeader), t.content || (t.content = new SYNO.SDS.ResourceMonitor.Performance.Memory.Content({
            topLayer: e.topLayer,
            anchor: "100% -37",
            header: t.chartHeader
        }), t.add(t.content)), i = !0), r === t.chartHeader.history_combo.hidden && (r ? (t.chartHeader.history_combo.show(), t.chartHeader.history_label.show()) : (t.chartHeader.history_combo.hide(), t.chartHeader.history_label.hide()), i = !0), i && t.doLayout(!1, !0)
    },
    onActivate: function() {
        this.items.each(function(e) {
            Ext.isFunction(e.onActivate) && e.onActivate()
        }, this)
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Memory.Content", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = {
            itemId: "content",
            cls: "chart-content",
            layout: "card",
            activeItem: 0,
            items: [new SYNO.SDS.ResourceMonitor.Performance.Memory.CurrentPhysical({
                itemId: "current_usage",
                topLayer: e.topLayer,
                controlLayer: this
            }), new SYNO.SDS.ResourceMonitor.Performance.Memory.CurrentSwap({
                itemId: "current_swap",
                topLayer: e.topLayer,
                controlLayer: this
            }), new SYNO.SDS.ResourceMonitor.Performance.Memory.History({
                itemId: "history",
                topLayer: e.topLayer,
                controlLayer: this
            })]
        };
        Ext.apply(t, e), this.callParent([t]), this.mon(e.header, "contentSelect", this.changeContent, this)
    },
    changeContent: function(e) {
        Ext.isDefined(e.type) || (e.type = "usage"), "current" === e.history ? this.layout.setActiveItem("current_" + e.type) : (this.layout.setActiveItem("history"), this.get("history").setType(e.history, e.type))
    },
    setToRealTime: function() {
        this.header.setToRealTime()
    },
    onActivate: function() {
        var e = this.layout.activeItem;
        Ext.isDefined(e) && Ext.isFunction(e.onActivate) && e.onActivate()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Memory.CurrentPhysical", {
    extend: "Ext.Panel",
    lastPollingData: null,
    constructor: function(e) {
        var t = this;
        t.pieId = {
            used: Ext.id(),
            buff: Ext.id(),
            cached: Ext.id(),
            free: Ext.id(),
            reserved: Ext.id()
        }, t.sumarryId = {
            total: Ext.id(),
            totalUnit: Ext.id(),
            util: Ext.id()
        };
        var i = '<div class="pie-title-bar"><span class="pie-title">' + _T("rsrcmonitor", "memory_composition") + '</span><span style="float:right"><span class="legend-value-header-large"  style="display:inline-block; padding-right: 12px;">' + _T("rsrcmonitor", "total") + "</span><span id=" + t.sumarryId.total + ' class="legend-value" style="display:inline-block; padding-right: 8px; padding-left: 0px;">0</span><span id=' + t.sumarryId.totalUnit + ' class="legend-value-unit-large" style="padding-right: 28px;">MB</span><span class="legend-value-header-large" style="display:inline-block; padding-right:12px;">' + _T("rsrcmonitor", "utilization") + "</span><span id=" + t.sumarryId.util + ' class="legend-value" style="display:inline-block; padding-right: 8px; padding-left: 0px;">0</span><span class="legend-value-unit-large">%</span></span></div>',
            r = '<div class="pie-chart"><div id=' + t.pieId.reserved + ' class="legend-color-reserved pie-item"></div> <div id=' + t.pieId.used + ' class="legend-color-used pie-item"></div><div id=' + t.pieId.buff + ' class="legend-color-buff pie-item"></div> <div id=' + t.pieId.cached + ' class="legend-color-cached pie-item"></div><div id=' + t.pieId.free + ' class="legend-color-free pie-item"></div> </div>';
        t.legendId = {
            used: Ext.id(),
            usedUnit: Ext.id(),
            buff: Ext.id(),
            buffUnit: Ext.id(),
            cached: Ext.id(),
            cachedUnit: Ext.id(),
            free: Ext.id(),
            freeUnit: Ext.id(),
            reserved: Ext.id(),
            reservedUnit: Ext.id()
        };
        var a = "<div class=legend-memory-current-physical>" + this.createLegendCard("legend-color-reserved", _T("rsrcmonitor", "reserved"), t.legendId.reserved, t.legendId.reservedUnit) + this.createLegendCard("legend-color-used", _T("rsrcmonitor", "memroy_used"), t.legendId.used, t.legendId.usedUnit) + this.createLegendCard("legend-color-buff", _T("rsrcmonitor", "memroy_buff"), t.legendId.buff, t.legendId.buffUnit) + this.createLegendCard("legend-color-cached", _T("rsrcmonitor", "memory_cached"), t.legendId.cached, t.legendId.cachedUnit) + this.createLegendCard("legend-color-free", _T("rsrcmonitor", "memory_free"), t.legendId.free, t.legendId.freeUnit) + "</div>";
        this.chart = new SYNO.SDS.ResourceMonitor.Performance.Chart.Current({
            cls: "chart-current-physical",
            chartTitle: _T("rsrcmonitor", "utilization") + " (%)",
            flex: 1,
            topLayer: e.topLayer,
            totalTime: SYNO.SDS.ResourceMonitor.Performance.CurrentTotalTime,
            lines: SYNO.SDS.ResourceMonitor.Performance.Memory.MemoryLine("memory_util"),
            dataType: "percent"
        });
        var o = {
                xtype: "panel",
                itemId: "legend",
                cls: "legend",
                border: !1,
                items: [{
                    xtype: "box",
                    html: i
                }, {
                    xtype: "box",
                    itemId: "pie",
                    html: r
                }, {
                    xtype: "box",
                    html: a
                }]
            },
            n = Ext.apply({
                layout: "vbox",
                layoutConfig: {
                    align: "stretch"
                },
                border: !1,
                items: [this.chart, o]
            }, e);
        this.callParent([n])
    },
    createLegendCard: function(e, t, i, r) {
        return '<div class="legend-card">' + '<div class="'.concat(e, ' legend-color-item"></div>') + "<div>" + '<div class="legend-value-header">'.concat(t, "</div>") + "<div>" + "<span id=".concat(i, ' class="legend-value">0</span>') + "<span id=".concat(r, ' class="legend-value-unit">MB</span>') + "</div></div></div>"
    },
    initEvents: function() {
        var e = this;
        SYNO.SDS.ResourceMonitor.Performance.Memory.CurrentPhysical.superclass.initEvents.apply(this, arguments), e.mon(e.topLayer, "data_comming", function(t) {
            e.updateData(t.memory, t.time)
        }), e.mon(e, "resize", e.onResizeThis, e), e.mon(e, "activate", e.onActivate, e)
    },
    onResizeThis: function() {
        var e = this,
            t = e.lastPollingData;
        t && (e.updateRetanglePieChart(t), e.updateLegend(t))
    },
    onActivate: function() {
        var e = this,
            t = e.lastPollingData;
        t && (e.doLayout(), e.updateRetanglePieChart(t), e.updateLegend(t), e.updateSumarry(t), e.chart.drawChart())
    },
    updateData: function(e, t) {
        var i = this,
            r = e,
            a = {};
        a = {
            total: 1024 * r.total_real,
            used: 1024 * (r.total_real - r.avail_real - r.cached - r.buffer),
            buffer: 1024 * r.buffer,
            cached: 1024 * r.cached,
            free: 1024 * r.avail_real,
            util: r.real_usage,
            reserved: 1024 * (r.memory_size - r.total_real),
            ramsize: 1024 * r.memory_size
        }, i.lastPollingData = a, i.updateRetanglePieChart(a), i.updateLegend(a), i.updateSumarry(a), i.updateChart(a, t)
    },
    updateRetanglePieChart: function(e) {
        var t = this,
            i = t.get("legend").get("pie").getWidth() - 8,
            r = Math.ceil(e.reserved * i / e.ramsize),
            a = Math.ceil(e.used * i / e.ramsize),
            o = Math.ceil(e.buffer * i / e.ramsize),
            n = Math.ceil(e.cached * i / e.ramsize),
            s = i + 4 - r - a - o - n;
        Ext.fly(t.pieId.reserved).setWidth(r), Ext.fly(t.pieId.used).setWidth(a), Ext.fly(t.pieId.buff).setWidth(o), Ext.fly(t.pieId.cached).setWidth(n), Ext.fly(t.pieId.free).setWidth(s)
    },
    updateLegend: function(e) {
        var t = this,
            i = t.topLayer.fileSizeUnit(e.used),
            r = t.topLayer.fileSizeUnit(e.buffer),
            a = t.topLayer.fileSizeUnit(e.cached),
            o = t.topLayer.fileSizeUnit(e.free),
            n = t.topLayer.fileSizeUnit(e.reserved);
        Ext.fly(t.legendId.used).update(i.size), Ext.fly(t.legendId.usedUnit).update(i.unit), Ext.fly(t.legendId.buff).update(r.size), Ext.fly(t.legendId.buffUnit).update(r.unit), Ext.fly(t.legendId.cached).update(a.size), Ext.fly(t.legendId.cachedUnit).update(a.unit), Ext.fly(t.legendId.free).update(o.size), Ext.fly(t.legendId.freeUnit).update(o.unit), Ext.fly(t.legendId.reserved).update(n.size), Ext.fly(t.legendId.reservedUnit).update(n.unit)
    },
    updateSumarry: function(e) {
        var t = this,
            i = t.topLayer.fileSizeUnit(e.ramsize);
        Ext.fly(t.sumarryId.total).update(i.size), Ext.fly(t.sumarryId.totalUnit).update(i.unit), Ext.fly(t.sumarryId.util).update(e.util)
    },
    updateChart: function(e, t) {
        var i = this;
        i.chart.pushValue([e.util], t), i.chart.drawChart()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Memory.CurrentSwap", {
    extend: "Ext.Panel",
    lastPollingData: null,
    constructor: function(e) {
        var t, i, r = this,
            a = {};
        r.chart = new SYNO.SDS.ResourceMonitor.Performance.Chart.Current({
            cls: "chart-current-swap",
            flex: 1,
            topLayer: e.topLayer,
            chartTitle: _T("rsrcmonitor", "si_descr") + " / " + _T("rsrcmonitor", "so_descr"),
            totalTime: SYNO.SDS.ResourceMonitor.Performance.CurrentTotalTime,
            lines: SYNO.SDS.ResourceMonitor.Performance.Memory.SwapLine("swap_si", "swap_so"),
            dataType: "bytes"
        }), r.flow = {
            swapin: Ext.id(),
            swapinUnit: Ext.id(),
            swapout: Ext.id(),
            swapoutUnit: Ext.id()
        }, t = '<div class="legend-flow-cards">' + this.createLegendCard("legend-color-swapin", _T("rsrcmonitor", "si_descr"), r.flow.swapin, r.flow.swapinUnit, "Kb/s") + this.createLegendCard("legend-color-swapout", _T("rsrcmonitor", "so_descr"), r.flow.swapout, r.flow.swapoutUnit, "Kb/s") + "</div>", r.swap = {
            total: Ext.id(),
            totalUnit: Ext.id(),
            used: Ext.id(),
            usedUnit: Ext.id(),
            utilization: Ext.id()
        }, i = '<div class="legend-swap-cards">' + this.createLegendCard("legend-color-summary", _T("rsrcmonitor", "total"), r.swap.total, r.swap.totalUnit, "MB") + this.createLegendCard("legend-color-summary", _T("rsrcmonitor", "memroy_used"), r.swap.used, r.swap.usedUnit, "MB") + this.createLegendCard("legend-color-summary", _T("rsrcmonitor", "utilization"), r.swap.utilization, "", "%") + "</div>";
        var o = {
            xtype: "panel",
            cls: "legend-current-swap",
            layout: "hbox",
            border: !1,
            items: [{
                xtype: "box",
                html: t
            }, {
                xtype: "box",
                flex: 1
            }, {
                xtype: "box",
                html: i
            }]
        };
        a = Ext.apply({
            layout: "vbox",
            layoutConfig: {
                align: "stretch"
            },
            border: !1,
            cls: "resource-monitor-swap",
            style: {
                position: "relative"
            },
            items: [r.chart, o]
        }, e), this.callParent([a])
    },
    createLegendCard: function(e, t, i, r, a) {
        return '<div class="legend-card">' + '<div class="'.concat(e, ' legend-color-item"></div>') + "<div>" + '<div class="legend-value-header">'.concat(t, "</div>") + "<div>" + "<span id=".concat(i, ' class="legend-value">0</span>') + "<span id=".concat(r, ' class="legend-value-unit">').concat(a, "</span>") + "</div></div></div>"
    },
    initEvents: function() {
        var e = this;
        SYNO.SDS.ResourceMonitor.Performance.Memory.CurrentSwap.superclass.initEvents.apply(this, arguments), e.mon(e.topLayer, "data_comming", function(t) {
            e.updateData(t.memory, t.time)
        }), e.mon(e, "activate", e.onActivate, e)
    },
    onActivate: function() {
        this.chart.drawChart()
    },
    updateData: function(e, t) {
        var i = this;
        i.chart.pushValue([1024 * e.si_disk, 1024 * e.so_disk], t), i.chart.drawChart(), i.updateFlow(e), i.updateSwap(e)
    },
    updateFlow: function(e) {
        var t = this,
            i = t.getkbSizeUnit(e.si_disk),
            r = t.getkbSizeUnit(e.so_disk);
        Ext.fly(t.flow.swapin).update(i.size), Ext.fly(t.flow.swapinUnit).update(i.unit), Ext.fly(t.flow.swapout).update(r.size), Ext.fly(t.flow.swapoutUnit).update(r.unit)
    },
    getkbSizeUnit: function(e) {
        var t = 0,
            i = "KB/s";
        return e < 1024 ? (t = e, i = "KB/s") : (t = Math.round(e / 1024), i = "MB/s"), {
            size: "" + t,
            unit: i
        }
    },
    updateSwap: function(e) {
        var t = this,
            i = t.topLayer.fileSizeUnit(1024 * e.total_swap),
            r = t.topLayer.fileSizeUnit(1024 * (e.total_swap - e.avail_swap));
        Ext.fly(t.swap.total).update(i.size), Ext.fly(t.swap.totalUnit).update(i.unit), Ext.fly(t.swap.used).update(r.size), Ext.fly(t.swap.usedUnit).update(r.unit), 0 >= e.total_swap ? Ext.fly(t.swap.utilization).update("0") : Ext.fly(t.swap.utilization).update("" + Math.round(100 * (e.total_swap - e.avail_swap) / e.total_swap)), this.doLayout()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Memory.History", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = {};
        this.chart = new SYNO.SDS.ResourceMonitor.Performance.Chart.History({
            topLayer: e.topLayer,
            chartTitle: _T("rsrcmonitor", "utilization") + " (%)",
            flex: 1
        }), t = {
            layout: "vbox",
            layoutConfig: {
                align: "stretch"
            },
            items: [this.chart, {
                xtype: "box",
                height: 24,
                margins: {
                    top: 8,
                    right: 0,
                    bottom: 0,
                    left: 38
                },
                itemId: "footer"
            }]
        }, Ext.apply(t, e), this.callParent([t])
    },
    setType: function(e, t) {
        this.topLayer.setStatusLoading(), SYNO.API.Request({
            api: "SYNO.Core.System.Utilization",
            appWindow: this.topLayer.appWin,
            method: "get",
            version: 1,
            params: {
                type: "history",
                resource: ["memory"],
                time_range: e,
                graph: t
            },
            scope: this,
            callback: this.LoadHistoryData
        })
    },
    LoadHistoryData: function(e, t, i, r) {
        if (this.topLayer.clearStatusLoading(), !e || !t) {
            var a = this.topLayer.webapiErrorMapper(t ? t.code : 0);
            return void this.getEl().mask(a)
        }
        if (!t.data_size) return void this.getEl().mask(_T("rsrcmonitor", "no_history"));
        this.getEl().unmask(), this.drawCharts(t, i), this.setFooter(t, i)
    },
    drawCharts: function(e, t) {
        var i = {};
        i = "usage" === t.graph ? this.setUsageConfig(e, t) : this.setSwapConfig(e, t), this.chart.setChartConfig(i), this.chart.drawChart()
    },
    setUsageConfig: function(e, t) {
        return {
            chartTitle: _T("rsrcmonitor", "utilization") + " (%)",
            lines: SYNO.SDS.ResourceMonitor.Performance.Memory.MemoryLine("real_usage"),
            timeAxis: t.time_range,
            dataType: "percent",
            data: e.memory,
            dataSize: e.data_size,
            endTime: e.time,
            timeInterval: e.interval
        }
    },
    setSwapConfig: function(e, t) {
        return {
            chartTitle: _T("rsrcmonitor", "si_descr") + " / " + _T("rsrcmonitor", "so_descr"),
            lines: SYNO.SDS.ResourceMonitor.Performance.Memory.SwapLine("si_disk", "so_disk"),
            timeAxis: t.time_range,
            dataType: "bytes",
            dataBase: 1024,
            data: e.memory,
            dataSize: e.data_size,
            endTime: e.time,
            timeInterval: e.interval
        }
    },
    setFooter: function(e, t) {
        var i;
        i = "usage" === t.graph ? '<div><table class="dot-legend"><tbody><tr> <td class="legend-text"><div class = "legend-color-usage  legend-color-dot"></div>' + _T("rsrcmonitor", "utilization") + "</td></tr></tbody></table></div>" : '<div class="resource-monitor-swap"><table class="dot-legend" width="100%" style="table-layout:fixed;><tbody><tr class="legend-value-header"><td style="line-height: 20px;"><div class = "legend-color-swapin  legend-color-dot"></div>' + _T("rsrcmonitor", "si_descr") + '</td><td style="line-height: 20px;"><div class = "legend-color-swapout  legend-color-dot"></div>' + _T("rsrcmonitor", "so_descr") + "</td><td/><td/></tr></tbody></table></div>", this.get("footer").update(i)
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Network.Main", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = Ext.apply({
            layout: "anchor",
            items: [],
            ctCls: "performance-dropdown",
            listeners: {
                activate: this.onActivate,
                scope: this
            }
        }, e);
        this.callParent([t])
    },
    createComponent: function(e) {
        var t = this,
            i = e.showHistory,
            r = !1;
        t.chartHeader ? (t.content.get("current").clearInterfaces(), t.chartHeader.setToRealTime()) : (t.chartHeader = new SYNO.SDS.ResourceMonitor.Performance.Detail.Header({
            header_title: _T("rsrcmonitor", "network"),
            topLayer: e.topLayer
        }), t.add(t.chartHeader), t.content || (t.content = new SYNO.SDS.ResourceMonitor.Performance.Network.Content({
            topLayer: e.topLayer,
            anchor: "100% -37",
            header: t.chartHeader
        }), t.add(t.content)), r = !0), i === t.chartHeader.history_combo.hidden && (i ? (t.chartHeader.history_combo.show(), t.chartHeader.history_label.show()) : (t.chartHeader.history_combo.hide(), t.chartHeader.history_label.hide()), r = !0), r && t.doLayout(!1, !0)
    },
    onActivate: function() {
        this.items.each(function(e) {
            Ext.isFunction(e.onActivate) && e.onActivate()
        }, this)
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Network.Content", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = {
            itemId: "content",
            layout: "card",
            activeItem: 0,
            items: [new SYNO.SDS.ResourceMonitor.Performance.Network.Current({
                itemId: "current",
                topLayer: e.topLayer,
                controlLayer: this
            }), new SYNO.SDS.ResourceMonitor.Performance.Network.History({
                itemId: "history",
                topLayer: e.topLayer,
                controlLayer: this
            })]
        };
        Ext.apply(t, e), this.callParent([t]), this.mon(e.header, "contentSelect", this.changeContent, this)
    },
    changeContent: function(e) {
        "current" === e.history ? this.layout.setActiveItem("current") : (this.layout.setActiveItem("history"), this.get("history").setType(e.history, e.type))
    },
    setToRealTime: function() {
        this.header.setToRealTime()
    },
    onActivate: function() {
        var e = this.layout.activeItem;
        Ext.isDefined(e) && Ext.isFunction(e.onActivate) && e.onActivate()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Network.Current", {
    extend: "SYNO.ux.FormPanel",
    lastPollingData: null,
    constructor: function(e) {
        var t = {
            border: !1,
            bodyStyle: {
                padding: "0px"
            },
            topLayer: e.topLayer,
            items: [],
            listeners: {
                scope: this,
                activate: this.onActivate
            }
        };
        Ext.apply(t, e), this.callParent([t])
    },
    initEvents: function() {
        this.callParent(arguments), this.add(new SYNO.SDS.ResourceMonitor.Performance.Network.Current.Interface({
            topLayer: this.topLayer,
            itemId: "total"
        })), this.mon(this.topLayer, "data_comming", function(e) {
            this.updateData(e.network, e.time)
        }, this)
    },
    onActivate: function() {
        this.items.each(function(e) {
            Ext.isFunction(e.drawChart) && e.drawChart()
        }), this.connectEcharts()
    },
    updateData: function(e, t) {
        e && t && (_S("ha_hide_ntb") && this.removeNTBInterfaces(e), this.updateInterfaces(e), this.updateInterfacesData(e, t))
    },
    removeNTBInterfaces: function(e) {
        var t, i;
        t = e.find(function(e) {
            return "total" === e.device
        }), i = e.find(function(e) {
            return "ntb_eth0" === e.device
        }), t && i && (t.rx = t.rx - i.rx, t.tx = t.tx - i.tx, e.remove(i))
    },
    updateInterfaces: function(e) {
        var t = !1;
        e.length > 2 ? this.get("total").show() : this.get("total").hide(), t |= this.removed_network_interfaces(e), (t |= this.append_network_interfaces(e)) && this.doLayout()
    },
    removed_network_interfaces: function(e) {
        var t = this,
            i = [],
            r = !1;
        return this.items.each(function(t) {
            e.find(function(e) {
                return e.device === t.itemId
            }) || i.push(t)
        }), i.forEach(function(e) {
            r = !0, t.remove(e)
        }), r
    },
    append_network_interfaces: function(e) {
        var t = this,
            i = !1;
        return e.forEach(function(e) {
            if (!t.get(e.device)) {
                var r = new SYNO.SDS.ResourceMonitor.Performance.Network.Current.Interface({
                    topLayer: t.topLayer,
                    itemId: e.device
                });
                t.add(r), i = !0
            }
        }), i
    },
    updateInterfacesData: function(e, t) {
        var i = this;
        e.forEach(function(e) {
            var r = i.get(e.device);
            r && r.updateData(e, t)
        })
    },
    clearInterfaces: function() {
        var e = this;
        e.items.each(function(t) {
            "total" !== t.itemId ? e.remove(t) : t.hide()
        })
    },
    connectEcharts: function() {
        echarts.connect(this.items.getRange().filter(function(e) {
            return e.chart.echarts
        }).map(function(e) {
            return e.chart.echarts
        }))
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Network.Current.Interface", {
    extend: "Ext.Container",
    deviceName: "",
    constructor: function(e) {
        var t, i;
        "total" === e.itemId ? this.deviceName = _T("rsrcmonitor", "total") : (i = e.itemId.replace(/\.\d+$/, "").replace(/\d+$/, ""), "bridge" === e.topLayer.appWin._S("net_topology") && "wlan" === i && (t = "wifiap"), this.deviceName = SYNO.SDS.Utils.Network.idToString.apply(e.topLayer.appWin, [e.itemId, t])), this.chart = new SYNO.SDS.ResourceMonitor.Performance.Chart.Current({
            topLayer: e.topLayer,
            chartTitle: this.deviceName,
            totalTime: SYNO.SDS.ResourceMonitor.Performance.CurrentTotalTime,
            primitiveLegend: !0,
            canvasHeight: 120,
            lines: [{
                itemId: "network_trans",
                lineName: _T("rsrcmonitor", "rsrcmonitor_trans"),
                color: "#1574E8",
                lineStyle: {
                    width: 2
                }
            }, {
                itemId: "network_recv",
                lineName: _T("rsrcmonitor", "rsrcmonitor_recv"),
                color: "#09B3B3",
                lineStyle: {
                    width: 2
                }
            }],
            height: 176,
            margins: {
                top: 0,
                right: 0,
                bottom: 20,
                left: 0
            },
            dataType: "bytes"
        });
        var r = {
            border: !1,
            layout: "vbox",
            layoutConfig: {
                align: "stretch"
            },
            items: [this.chart]
        };
        Ext.apply(r, e), this.callParent([r])
    },
    updateData: function(e, t) {
        this.chart.pushValue([e.tx, e.rx], t), this.chart.drawChart()
    },
    drawChart: function() {
        this.chart.drawChart()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Network.History", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        var t = {
            itemId: "charts",
            border: !1,
            bodyStyle: {
                padding: "0px"
            },
            autoFlexcroll: !0,
            topLayer: e.topLayer,
            items: []
        };
        Ext.apply(t, e), this.callParent([t])
    },
    setType: function(e) {
        var t = this,
            i = [];
        t.controlLayer.get("current").items.items.forEach(function(e) {
            Ext.isDefined(e.deviceName) && "total" !== e.itemId && i.push(e.itemId)
        }), t.history = e, t.topLayer.setStatusLoading(), SYNO.API.Request({
            api: "SYNO.Core.System.Utilization",
            appWindow: t.topLayer.appWin,
            method: "get",
            version: 1,
            params: {
                type: "history",
                resource: ["network"],
                time_range: e,
                interfaces: {
                    network: i
                }
            },
            scope: t,
            callback: t.LoadHistoryData
        })
    },
    LoadHistoryData: function(e, t, i, r) {
        if (this.topLayer.clearStatusLoading(), !e || !t) {
            var a = this.topLayer.webapiErrorMapper(t ? t.code : 0);
            return void this.getEl().mask(a)
        }
        if (!t.data_size) return void this.getEl().mask(_T("rsrcmonitor", "no_history"));
        this.getEl().unmask(), this.drawCharts(t, i), echarts.connect(this.getEchartsComponent())
    },
    drawCharts: function(e, t) {
        this.updateInterfaces(e, t), this.items.eachKey(function(e, t) {
            t.drawChart()
        }, this)
    },
    updateInterfaces: function(e, t) {
        var i, r = this,
            a = "",
            o = 0,
            n = [];
        for (r.items.each(function(t) {
                var i = Ext.each(e.network, function(e) {
                    return e.device !== t.itemId
                });
                Ext.isDefined(i) || n.push(t.itemId)
            }, r), Ext.each(n, function(e) {
                r.remove(e)
            }), o = 0; o < e.network.length; ++o) a = r.get(e.network[o].device), a || (a = new SYNO.SDS.ResourceMonitor.Performance.Network.History.Interface({
            topLayer: this.topLayer,
            itemId: e.network[o].device
        }), r.add(a), i = !0), a.setChartConfig({
            topLayer: r.topLayer,
            timeAxis: t.time_range,
            data: e.network[o],
            dataSize: e.data_size,
            endTime: e.time,
            timeInterval: e.interval
        });
        i && r.doLayout()
    },
    getEchartsComponent: function() {
        return this.items.getRange().filter(function(e) {
            return e.chart.echarts
        }).map(function(e) {
            return e.chart.echarts
        })
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Network.History.Interface", {
    extend: "Ext.Container",
    deviceName: "",
    constructor: function(e) {
        this.chart = new SYNO.SDS.ResourceMonitor.Performance.Chart.History({
            topLayer: e.topLayer,
            primitiveLegend: !0,
            lines: [{
                itemId: "tx",
                lineName: _T("rsrcmonitor", "rsrcmonitor_trans"),
                color: "#1574E8",
                lineStyle: {
                    width: 2
                }
            }, {
                itemId: "rx",
                lineName: _T("rsrcmonitor", "rsrcmonitor_recv"),
                color: "#09B3B3",
                lineStyle: {
                    width: 2
                }
            }],
            canvasHeight: 120,
            height: 226,
            margins: {
                top: 0,
                right: 0,
                bottom: 20,
                left: 0
            },
            dataType: "bytes",
            dataBase: 1
        });
        var t = {
            border: !1,
            layout: "vbox",
            layoutConfig: {
                align: "stretch"
            },
            items: [this.chart]
        };
        Ext.apply(t, e), this.callParent([t])
    },
    setChartConfig: function(e) {
        var t, i = this,
            r = i.itemId.replace(/\.\d+$/, "").replace(/\d+$/, "");
        "bridge" === e.topLayer.appWin._S("net_topology") && "wlan" === r && (t = "wifiap"), e.chartTitle = SYNO.SDS.Utils.Network.idToString.apply(e.topLayer.appWin, [i.itemId, t]), i.chart.setChartConfig(e)
    },
    drawChart: function() {
        this.chart.drawChart()
    }
}), Ext.ns("SYNO.SDS.ResourceMonitor.Performance"), SYNO.SDS.ResourceMonitor.Performance.MaxDisplaySize = 7, Ext.define("SYNO.SDS.ResourceMonitor.Performance.Disk.Main", {
    extend: "Ext.Panel",
    header_title: _T("rsrcmonitor", "disk"),
    dataRoot: "disk",
    historyType: "disk",
    constructor: function(e) {
        var t = Ext.apply({
            layout: "anchor",
            items: [],
            listeners: {
                activate: this.onActivate,
                scope: this
            }
        }, e);
        this.callParent([t])
    },
    createComponent: function(e) {
        var t = this,
            i = SYNO.SDS.ResourceMonitor.Performance.Disk.SelectorDialog,
            r = e.showHistory,
            a = !1;
        "space" === this.dataRoot && (i = SYNO.SDS.ResourceMonitor.Performance.Space.SelectorDialog), t.chartHeader ? (t.chartHeader.setToRealTime(), t.content.updateStorages([]), t.content.selectorDialog.clearSelections()) : (t.chartHeader = new SYNO.SDS.ResourceMonitor.Performance.Detail.Header({
            header_title: t.header_title,
            topLayer: e.topLayer,
            type_combo: {
                data: [
                    ["transfer_rate", _T("rsrcmonitor", "transfer_rate")],
                    ["iops", _T("rsrcmonitor", "iops")],
                    ["utilization", _T("rsrcmonitor", "utilization")]
                ]
            },
            device_view_all: {
                cls: "absolute-left",
                xtype: "syno_button",
                btnStyle: "gray",
                text: _T("rsrcmonitor", "view_all"),
                handler: this.showDialog,
                scope: this
            }
        }), t.add(t.chartHeader), t.content || (t.content = new SYNO.SDS.ResourceMonitor.Performance.Disk.Content({
            topLayer: e.topLayer,
            mainLayer: this,
            dataRoot: this.dataRoot,
            historyType: this.historyType,
            anchor: "100% -37",
            selectorDialogClass: i,
            detailHeader: t.chartHeader
        }), t.add(t.content)), a = !0), r === t.chartHeader.history_combo.hidden && (r ? (t.chartHeader.history_combo.show(), t.chartHeader.history_label.show()) : (t.chartHeader.history_combo.hide(), t.chartHeader.history_label.hide()), a = !0), a && t.doLayout(!1, !0)
    },
    onActivate: function() {
        this.items.each(function(e) {
            Ext.isFunction(e.onActivate) && e.onActivate()
        }, this)
    },
    showDialog: function() {
        Ext.isDefined(this.content.selectorDialog) && this.content.selectorDialog.show()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Disk.Content", {
    extend: "Ext.Panel",
    selectorDialog: null,
    defaultColors: ["#FF8484", "#FFBB11", "#30B826", "#A278E5", "#3EDACD", "#FF5AB2", "#61C0FF"],
    defaultStorages: [{
        itemId: "total",
        storageType: "total",
        height: "20px",
        display_name: _T("rsrcmonitor", "total"),
        qtipName: _T("rsrcmonitor", "total"),
        color: "#1574E8"
    }],
    storages: null,
    lastPollingData: null,
    constructor: function(e) {
        var t = {};
        this.storages = SYNO.SDS.Utils.clone(this.defaultStorages), t = Ext.apply({
            layout: "vbox",
            layoutConfig: {
                align: "stretch"
            },
            border: !1,
            autoFlexcroll: !0,
            items: [{
                flex: 1,
                itemId: "content",
                xtype: "container",
                border: !1,
                layout: "card",
                activeItem: 1,
                items: [new SYNO.SDS.ResourceMonitor.Performance.Disk.CurrentUtilization({
                    itemId: "utilization",
                    topLayer: e.topLayer,
                    controlLayer: this
                }), new SYNO.SDS.ResourceMonitor.Performance.Disk.CurrentTransferRate({
                    itemId: "transfer_rate",
                    topLayer: e.topLayer,
                    controlLayer: this
                }), new SYNO.SDS.ResourceMonitor.Performance.Disk.CurrentIOPS({
                    itemId: "iops",
                    topLayer: e.topLayer,
                    controlLayer: this
                }), new SYNO.SDS.ResourceMonitor.Performance.Disk.History({
                    itemId: "history",
                    topLayer: e.topLayer,
                    controlLayer: this
                })]
            }, {
                xtype: "box",
                height: 36,
                itemId: "chart_ctl",
                style: {
                    padding: "0px 0px 0px 36px"
                },
                html: this.getChartCtlHtml()
            }, {
                xtype: "container",
                itemId: "footer",
                border: !1,
                height: 60,
                style: {
                    padding: "20px 0px 0px 36px"
                },
                items: [{
                    xtype: "box",
                    border: !1,
                    itemId: "footer_text"
                }]
            }]
        }, e), this.callParent([t])
    },
    initEvents: function() {
        var e = this;
        SYNO.SDS.ResourceMonitor.Performance.Disk.Main.superclass.initEvents.apply(this, arguments), e.mon(e.topLayer, "data_comming", function(t) {
            t && t[e.dataRoot] && (e.lastPollingData = t[e.dataRoot], e.removeInvalidStorages(t[e.dataRoot]), e.updateFooter(t[e.dataRoot]))
        }), e.mon(e.detailHeader, "contentSelect", e.changeContent, e), e.selectorDialog = new e.selectorDialogClass({
            owner: e.topLayer.appWin,
            topLayer: e.topLayer,
            dataRoot: e.dataRoot
        }), e.mon(e.selectorDialog, "select_finish", e.updateStorages, e), e.mon(e, "activate", e.onActivate, e), e.mon(e, "beforedestroy", e.destroyed, e)
    },
    onActivate: function() {
        var e = this,
            t = e.get("content"),
            i = t.layout.activeItem;
        i && Ext.isFunction(i.onActivate) && i.onActivate()
    },
    setToRealTime: function() {
        this.detailHeader.setToRealTime()
    },
    changeContent: function(e) {
        var t = this.get("content");
        t.boxMinHeight = null, t.anchorSpec = null, "current" === e.history ? (t.layout.setActiveItem(e.type), this.updateFooter(this.lastPollingData)) : (t.layout.setActiveItem("history"), t.get("history").setType(e.history, e.type), this.updateFooter()), this.doLayout()
    },
    showSelectorDialog: function() {
        this.selectorDialog.show()
    },
    getChartCtlHtml: function() {
        var e = '<table width="100%" style="table-layout:fixed" class="ctl-table"><tbody><tr>',
            t = this.storages.map(function(e) {
                return {
                    qtipName: e.qtipName,
                    color: e.color,
                    display_name: e.display_name
                }
            });
        if (4 !== this.storages.length)
            for (var i = Math.abs(4 - this.storages.length), r = 0; r < i; r++) t.push(null);
        for (var a = 0; a < t.length; ++a) 0 == a % 4 && 0 !== a && (e += "</tr><tr>"), null === t[a] ? e += "<td/>" : e += '<td><div class = "legend-color-dot" style="background-color:' + t[a].color + '"></div>' + t[a].display_name + "</td>";
        return e += "</tr></tbody></table>"
    },
    removeInvalidStorages: function(e) {
        var t = this,
            i = !1,
            r = !1,
            a = [];
        Ext.each(t.storages, function(t) {
            "total" !== t.itemId && (r = e[t.storageType].every(function(e) {
                return e.device !== t.itemId
            }), r ? i = !0 : a.push(t))
        }), i && t.updateStorages(a)
    },
    updateStorages: function(e) {
        var t, i = this,
            r = !1,
            a = [];
        Ext.each(i.storages, function(t) {
            !0 !== (r = e.every(function(e, i, r) {
                return t.itemId !== e.id
            })) && a.push(t)
        }), Ext.each(e, function(e, o) {
            !0 === (r = a.every(function(t, i, r) {
                return e.id !== t.itemId
            })) && (t = e, t.color = i.getAColor(a), a.splice(o, 0, t))
        }), i.storages = i.defaultStorages.concat(a), i.get("chart_ctl").update(i.getChartCtlHtml()), i.get("chart_ctl").height = i.storages.length > 4 ? 56 : 36, i.doLayout(), i.fireEvent("storagesUpdate")
    },
    getAColor: function(e) {
        var t = this,
            i = !1,
            r = t.defaultColors[0];
        return Ext.each(t.defaultColors, function(t) {
            if (i = e.every(function(e, i, r) {
                    return t !== e.color
                })) return r = t, !1
        }), r
    },
    updateFooter: function(e) {
        var t, i, r = this,
            a = r.get("footer").get("footer_text"),
            o = r.get("footer"),
            n = r.get("content").layout.activeItem.itemId;
        if ("history" === n) return void o.hide();
        if (i = e.total, !Ext.isDefined(i)) return !1;
        if ("utilization" === n) t = '<div><table style="border-spacing: 0;"><tbody><tr><td rowspan="2" class="legend-color-gray legend-color-item"></td><td class="legend-value-header">' + _T("rsrcmonitor", "utilization") + '</td></tr><tr><td><span class="legend-value">' + i.utilization + '</span><span class="legend-value-unit">%</span></td></tr></tbody></table></div>';
        else if ("transfer_rate" === n) {
            var s = r.topLayer.fileSizeUnit(i.read_byte),
                c = r.topLayer.fileSizeUnit(i.write_byte);
            t = '<div><table style="border-spacing: 0;"><tbody><tr><td rowspan="3" class="legend-color-gray legend-color-item"></td><td class="legend-value-header">' + _T("rsrcmonitor", "read_speed") + '</td><td class="legend-padding-right"></td><td rowspan="3" class="legend-color-gray legend-color-item"></td><td class="legend-value-header">' + _T("rsrcmonitor", "write_speed") + '</td><td class="legend-padding-right"></td></tr><tr><td><span class="legend-value">' + s.size + '</span><span class="legend-value-unit">' + s.unit + '/s</span></td><td class="legend-padding-right"></td><td><span class="legend-value">' + c.size + '</span><span class="legend-value-unit">' + c.unit + '/s</span></td><td class="legend-padding-right"></td></tr></tbody></table></div>'
        } else if ("iops" === n) {
            var l = r.topLayer.numberUnit(i.read_access, "iops"),
                d = r.topLayer.numberUnit(i.write_access, "iops");
            t = '<div><table style="border-spacing: 0;"><tbody><tr><td rowspan="3" class="legend-color-gray legend-color-item"></td><td class="legend-value-header">' + _T("rsrcmonitor", "read") + '</td><td class="legend-padding-right"></td><td rowspan="3" class="legend-color-gray legend-color-item"></td><td class="legend-value-header">' + _T("rsrcmonitor", "write") + '</td><td class="legend-padding-right"></td></tr><tr><td><span class="legend-value">' + l.num + '</span><span class="legend-value-unit">' + l.unit + '</span></td><td class="legend-padding-right"></td><td><span class="legend-value">' + d.num + '</span><span class="legend-value-unit">' + d.unit + '</span></td><td class="legend-padding-right"></td></tr></tbody></table></div>'
        } else t = "<div></div>";
        a.update(t), o.show()
    },
    getStoragesToDraw: function() {
        var e = this,
            t = [],
            i = 0;
        for (i = 0; i < e.storages.length; ++i) t.push(Ext.apply(e.storages[i], {
            lineStyle: {
                width: 2
            },
            lineName: e.storages[i].display_name || e.storages[i].itemId
        }));
        return t
    },
    destroyed: function() {
        this.selectorDialog.destroy(), delete this.selectorDialog
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Disk.SelectorDialog", {
    extend: "SYNO.SDS.ModalWindow",
    lastCommingData: null,
    grids: null,
    dataRoot: "disk",
    constructor: function(e) {
        var t = this;
        t.selectionCheck = {}, t.grids = e.grids || [t.createHddGrid(e)];
        var i = {
            title: _T("rsrcmonitor", "view_all"),
            topLayer: e.topLayer,
            height: 300,
            width: 650,
            layout: "fit",
            items: t.grids,
            closeAction: "hide",
            buttons: [{
                text: _T("common", "cancel"),
                itemId: "close_btn",
                handler: t.closeHandler,
                scope: t
            }, {
                text: _T("common", "ok"),
                btnStyle: "blue",
                itemId: "ok_btn",
                handler: t.okHandler,
                scope: t
            }],
            listeners: {
                show: {
                    fn: function() {
                        t.lastCommingData && t.updateGrids(t.lastCommingData)
                    }
                }
            }
        };
        Ext.apply(i, e), this.callParent([i])
    },
    initEvents: function() {
        var e = this;
        SYNO.SDS.ResourceMonitor.Performance.Disk.SelectorDialog.superclass.initEvents.apply(this, arguments), e.mon(e.topLayer, "data_comming", function(t) {
            e.lastCommingData = t[e.dataRoot], e.isVisible() && e.updateGrids(t[e.dataRoot])
        }), Ext.each(e.grids, function(t) {
            e.mon(t.getSelectionModel(), "afterselect", e.checkExceedMaxSelection, e)
        })
    },
    updateGrids: function(e) {
        var t = this;
        Ext.each(this.grids, function(i) {
            i.getStore().loadData(e[i.itemId]), t.removeInvalidSelections()
        })
    },
    createHddGrid: function(e) {
        var t = SYNO.SDS.ResourceMonitor.Performance.Disk.Utility,
            i = "device",
            r = t.defaultSorter;
        return "yes" === e.owner._D("supportsas") && (i = "display_name", r = t.sasSorter), "yes" === e.owner._D("supportportmappingv2") && (i = "display_name", r = t.sataSorter), this.createStorageGrid({
            itemId: "disk",
            title: _T("rsrcmonitor", "disk"),
            nameIndex: i,
            displayNameSorter: r,
            deviceNameRenderer: t.shortExpansionDiskName,
            topLayer: e.topLayer
        })
    },
    createStorageGrid: function(e) {
        var t = new Ext.data.JsonReader({
                idProperty: "device",
                fields: [{
                    name: "device"
                }, {
                    name: "display_name",
                    sortType: e.displayNameSorter
                }, {
                    name: "utilization"
                }, {
                    name: "read_byte",
                    type: "integer"
                }, {
                    name: "write_byte",
                    type: "integer"
                }, {
                    name: "read_access",
                    type: "integer"
                }, {
                    name: "write_access",
                    type: "integer"
                }]
            }),
            i = new SYNO.SDS.ResourceMonitor.Performance.Disk.SelectorDialog.SelectModel({
                width: 30
            }),
            r = function(t, i, r) {
                var a = r.get("display_name"),
                    o = Ext.util.Format.htmlEncode(a);
                return i.attr = 'ext:qtip="' + o + '"', e.deviceNameRenderer ? Ext.util.Format.htmlEncode(e.deviceNameRenderer(a, e.topLayer)) : o
            },
            a = {
                padding: "0",
                tbar: new SYNO.ux.Toolbar({
                    cls: "resource_monitor_performance_selector_toolbar",
                    items: {
                        xtype: "syno_displayfield",
                        cls: "resource_monitor_performance_selector_view_select_display_field",
                        value: _T("rsrcmonitor", "view_select")
                    }
                }),
                store: new Ext.data.Store({
                    autoDestroy: !0,
                    reader: t,
                    sortInfo: {
                        field: e.nameIndex,
                        direction: "ASC"
                    }
                }),
                colModel: new Ext.grid.ColumnModel({
                    defaults: {
                        sortable: !0,
                        menuDisabled: !0,
                        width: 100,
                        height: 20
                    },
                    columns: [i, {
                        header: _T("common", "name"),
                        width: 160,
                        dataIndex: e.nameIndex,
                        renderer: r
                    }, {
                        header: _T("rsrcmonitor", "utilization") + "(%)",
                        dataIndex: "utilization"
                    }, {
                        header: _T("rsrcmonitor", "read_speed") + "(/s)",
                        renderer: Ext.util.Format.fileSize,
                        dataIndex: "read_byte"
                    }, {
                        header: _T("rsrcmonitor", "write_speed") + "(/s)",
                        renderer: Ext.util.Format.fileSize,
                        dataIndex: "write_byte"
                    }, {
                        header: _T("rsrcmonitor", "read") + "(/s)",
                        dataIndex: "read_access"
                    }, {
                        header: _T("rsrcmonitor", "write") + "(/s)",
                        dataIndex: "write_access"
                    }]
                }),
                sm: i,
                viewConfig: {
                    forceFit: !0,
                    onLoad: Ext.emptyFn,
                    listeners: {
                        beforerefresh: function(e) {
                            e.scrollTop = e.scroller.dom.scrollTop
                        },
                        refresh: function(e) {
                            e.scroller.dom.scrollTop = e.scrollTop
                        }
                    }
                },
                enableHdMenu: !1,
                frame: !1,
                cls: "resource-monitor-performance"
            };
        return Ext.apply(a, e), new SYNO.ux.GridPanel(a)
    },
    getSelections: function() {
        var e = this,
            t = [];
        return Ext.each(e.grids, function(i) {
            t = t.concat(e.getGridSelections(i))
        }), t
    },
    getGridSelections: function(e) {
        var t = this,
            i = [];
        i = e.getSelectionModel().getSelections().map(function(i) {
            var r = {
                itemId: i.get("device"),
                device: i.get("device"),
                storageType: e.itemId
            };
            return e.deviceNameRenderer ? r.display_name = e.deviceNameRenderer(i.get("display_name"), t.topLayer) : r.display_name = i.get("display_name"), r.qtipName = i.get("display_name"), r
        });
        var r = function(t, i) {
            var r = e.nameIndex;
            return "display_name" === r && e.deviceNameRenderer && (r = "qtipName"), e.displayNameSorter(t[r]) > e.displayNameSorter(i[r])
        };
        return i.sort(r), i
    },
    saveSelections: function() {
        Ext.each(this.grids, function(e) {
            e.getSelectionModel().saveSelections()
        })
    },
    resetSelections: function() {
        Ext.each(this.grids, function(e) {
            e.getSelectionModel().resetSelections()
        })
    },
    removeInvalidSelections: function() {
        Ext.each(this.grids, function(e) {
            e.getSelectionModel().removeInvalidSelections()
        })
    },
    clearSelections: function() {
        Ext.each(this.grids, function(e) {
            e.getSelectionModel().clearSelections(!0), e.getSelectionModel().clearCheckSelections()
        })
    },
    isDirty: function() {
        var e = this;
        return !this.grids.every(function(t) {
            return !(!Ext.isEmpty(t.getSelectionModel().checkSelections) || !Ext.isEmpty(e.getSelections())) || t.getSelectionModel().checkSelections.length === e.getSelections().length && t.getSelectionModel().checkSelections.every(function(t) {
                return e.getSelections().some(function(e) {
                    return e.itemId === t.id
                })
            })
        })
    },
    okHandler: function() {
        var e = this,
            t = [];
        if (!e.isDirty()) return void this.closeHandler();
        t = e.getSelections(), t.length > SYNO.SDS.ResourceMonitor.Performance.MaxDisplaySize || (e.clearStatus(), e.saveSelections(), e.fireEvent("select_finish", t), e.hide())
    },
    closeHandler: function() {
        var e = this;
        e.hide(), e.clearStatus(), e.resetSelections()
    },
    checkExceedMaxSelection: function() {
        var e = this,
            t = String.format(_T("rsrcmonitor", "exceeded_max_disk_selection"), SYNO.SDS.ResourceMonitor.Performance.MaxDisplaySize),
            i = [];
        i = e.getSelections(), i.length > SYNO.SDS.ResourceMonitor.Performance.MaxDisplaySize ? e.setStatusError({
            text: t
        }) : e.clearStatus()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Disk.SelectorDialog.SelectModel", {
    extend: "Ext.grid.CheckboxSelectionModel",
    checkSelections: [],
    constructor: function(e) {
        var t = this;
        t.headerCheckId = Ext.id(), t.header = "<div id=" + t.headerCheckId + ' class="x-grid3-row-checker">&#160;</div>', this.callParent([e])
    },
    initEvents: function() {
        SYNO.SDS.ResourceMonitor.Performance.Disk.SelectorDialog.SelectModel.superclass.initEvents.apply(this, arguments), this.grid.mon(this.grid.getStore(), "load", this.checkSelectAll, this), this.grid.mon(this.grid.getStore(), "load", this.fireAfterSelectEvent, this)
    },
    handleMouseDown: function() {},
    checkSelectAll: function() {
        var e = this;
        e.getCount() === e.grid.getStore().getCount() && 0 !== e.getCount() ? Ext.get(e.headerCheckId).addClass("x-grid3-hd-checker-on") : Ext.get(e.headerCheckId).removeClass("x-grid3-hd-checker-on")
    },
    fireAfterSelectEvent: function() {
        this.fireEvent("afterselect")
    },
    onMouseDown: function(e, t) {
        SYNO.SDS.ResourceMonitor.Performance.Disk.SelectorDialog.SelectModel.superclass.onMouseDown.apply(this, arguments), this.checkSelectAll(), this.fireAfterSelectEvent()
    },
    onHdMouseDown: function(e, t) {
        var i = this;
        t.classList.contains("x-grid3-row-checker") && (t.classList.contains("x-grid3-hd-checker-on") ? (Ext.get(i.headerCheckId).removeClass("x-grid3-hd-checker-on"), i.clearSelections()) : (Ext.get(i.headerCheckId).addClass("x-grid3-hd-checker-on"), i.selectAll()), i.fireAfterSelectEvent())
    },
    saveSelections: function() {
        var e = this;
        e.checkSelections = e.getSelections()
    },
    resetSelections: function() {
        var e = this,
            t = e.grid.getStore();
        e.clearSelections(!0), t.each(function(i) {
            Ext.each(e.checkSelections, function(r) {
                if (i.id === r.id) return e.selectRow(t.indexOf(i), !0, !0), !1
            })
        }), e.checkSelectAll()
    },
    removeInvalidSelections: function() {
        var e = this,
            t = e.grid.getStore();
        e.checkSelections = e.checkSelections.filter(function(e) {
            return t.getRange().some(function(t) {
                return t.id === e.id
            })
        })
    },
    clearCheckSelections: function() {
        this.checkSelections.clear()
    }
}), SYNO.SDS.ResourceMonitor.Performance.Disk.Utility = {
    getValueFromComingDataById: function(e, t, i, r) {
        var a = 0;
        return "total" === i ? e.total[r] : (Ext.each(e[t], function(e, t, o) {
            return e.device !== i || (a = e[r], !1)
        }), a)
    },
    shortExpansionDiskName: function(e, t) {
        if ("yes" !== t.appWin._D("supportsas")) return e;
        var i, r, a = _T("volume", "volume_expansion"),
            o = _T("volume", "volume_disk");
        return "(" + a !== e.substr(0, a.length + 1) ? e : null === (i = e.match(/\d+/g)) || 2 !== i.length ? e : (r = "{0} - " + o + " {1}", String.format(r, i[0], i[1]))
    },
    volumeSorter: function(e) {
        return "volume" === e.substr(0, 6) ? parseInt(e.substr(6), 10) : e
    },
    defaultSorter: function(e) {
        return e
    },
    sasSorter: function(e) {
        var t, i = 0,
            r = 0;
        return null === (t = e.match(/\d+/g)) ? e : (1 === t.length ? (i = 0, r = parseInt(t[0], 10)) : (i = parseInt(t[0], 10), r = parseInt(t[1], 10)), 1e3 * i + r)
    },
    sataSorter: function(e) {
        var t = e.match(/^Drive (\d+)(?: \(.+-(\d+)\))?$/);
        return null === t || 3 !== t.length ? e : parseInt(t[1], 10) + 1e3 * parseInt(t[2] ? t[2] : 0, 10)
    }
}, Ext.define("SYNO.SDS.ResourceMonitor.Performance.Disk.CurrentTransferRate", {
    extend: "Ext.Panel",
    constructor: function(e) {
        this.readChart = new SYNO.SDS.ResourceMonitor.Performance.Chart.Current({
            chartTitle: _T("rsrcmonitor", "read_speed"),
            anchor: "100% 50%",
            totalTime: SYNO.SDS.ResourceMonitor.Performance.CurrentTotalTime,
            dataType: "bytes",
            topLayer: e.topLayer
        }), this.writeChart = new SYNO.SDS.ResourceMonitor.Performance.Chart.Current({
            chartTitle: _T("rsrcmonitor", "write_speed"),
            anchor: "100% 50%",
            totalTime: SYNO.SDS.ResourceMonitor.Performance.CurrentTotalTime,
            dataType: "bytes",
            topLayer: e.topLayer
        });
        var t = {
                xtype: "displayfield",
                height: 8,
                border: !1
            },
            i = {
                ctCls: "performance-disk-box",
                layout: "anchor",
                border: !1,
                style: {
                    paddingTop: "12px"
                },
                items: [this.readChart, t, this.writeChart],
                listeners: {
                    scope: this,
                    activate: this.onActivate
                }
            };
        Ext.apply(i, e), this.callParent([i])
    },
    initEvents: function() {
        this.callParent(arguments), this.mon(this.topLayer, "data_comming", function(e) {
            this.updateData(e[this.controlLayer.dataRoot], e.time)
        }, this), this.mon(this.controlLayer, "storagesUpdate", this.onStoragesUpdate, this)
    },
    onStoragesUpdate: function() {
        this.readChart.clearStoreData(), this.writeChart.clearStoreData(), this.readChart.drawChart(), this.writeChart.drawChart()
    },
    updateData: function(e, t) {
        var i = SYNO.SDS.ResourceMonitor.Performance.Disk.Utility,
            r = this.controlLayer.getStoragesToDraw(),
            a = [],
            o = [];
        this.readChart.updateStores(r), this.writeChart.updateStores(r), Ext.each(r, function(t, r, n) {
            a.push({
                itemId: t.itemId,
                value: i.getValueFromComingDataById(e, t.storageType, t.itemId, "read_byte")
            }), o.push({
                itemId: t.itemId,
                value: i.getValueFromComingDataById(e, t.storageType, t.itemId, "write_byte")
            })
        }), this.readChart.pushValueById(a, t), this.writeChart.pushValueById(o, t), this.readChart.drawChart(), this.writeChart.drawChart()
    },
    onActivate: function() {
        this.readChart.drawChart(), this.writeChart.drawChart(), echarts.connect(this.getEchartsComponent())
    },
    getEchartsComponent: function() {
        return this.items.getRange().filter(function(e) {
            return e.echarts
        }).map(function(e) {
            return e.echarts
        })
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Disk.CurrentUtilization", {
    extend: "Ext.Panel",
    constructor: function(e) {
        var t = this,
            i = {};
        t.utilChart = new SYNO.SDS.ResourceMonitor.Performance.Chart.Current({
            chartTitle: _T("rsrcmonitor", "utilization") + " (%)",
            totalTime: SYNO.SDS.ResourceMonitor.Performance.CurrentTotalTime,
            dataType: "percent",
            topLayer: e.topLayer
        }), i = {
            layout: "fit",
            border: !1,
            style: {
                paddingTop: "12px"
            },
            items: [t.utilChart]
        }, Ext.apply(i, e), this.callParent([i])
    },
    initEvents: function() {
        var e = this;
        SYNO.SDS.ResourceMonitor.Performance.Disk.CurrentUtilization.superclass.initEvents.apply(this, arguments), e.mon(e.topLayer, "data_comming", function(t) {
            e.updateData(t[e.controlLayer.dataRoot], t.time)
        }), e.mon(e, "activate", e.onActivate, e), this.mon(this.controlLayer, "storagesUpdate", this.onStoragesUpdate, this)
    },
    onStoragesUpdate: function() {
        this.utilChart.clearStoreData(), this.utilChart.drawChart()
    },
    updateData: function(e, t) {
        var i = this,
            r = SYNO.SDS.ResourceMonitor.Performance.Disk.Utility,
            a = [],
            o = i.controlLayer.getStoragesToDraw();
        i.utilChart.updateStores(o), Ext.each(o, function(t, i, o) {
            a.push({
                itemId: t.itemId,
                value: r.getValueFromComingDataById(e, t.storageType, t.itemId, "utilization")
            })
        }), i.utilChart.pushValueById(a, t), i.utilChart.drawChart()
    },
    onActivate: function() {
        this.utilChart.drawChart()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Disk.CurrentIOPS", {
    extend: "Ext.Panel",
    constructor: function(e) {
        this.readChart = new SYNO.SDS.ResourceMonitor.Performance.Chart.Current({
            chartTitle: _T("rsrcmonitor", "read"),
            anchor: "100% 50%",
            totalTime: SYNO.SDS.ResourceMonitor.Performance.CurrentTotalTime,
            dataType: "iops",
            topLayer: e.topLayer
        }), this.writeChart = new SYNO.SDS.ResourceMonitor.Performance.Chart.Current({
            chartTitle: _T("rsrcmonitor", "write"),
            anchor: "100% 50%",
            totalTime: SYNO.SDS.ResourceMonitor.Performance.CurrentTotalTime,
            dataType: "iops",
            topLayer: e.topLayer
        });
        var t = {
                xtype: "displayfield",
                height: 8,
                border: !1
            },
            i = {
                layout: "anchor",
                border: !1,
                style: {
                    paddingTop: "12px"
                },
                items: [this.readChart, t, this.writeChart],
                listeners: {
                    scope: this,
                    activate: this.onActivate
                }
            };
        Ext.apply(i, e), this.callParent([i])
    },
    initEvents: function() {
        this.callParent(arguments), this.mon(this.topLayer, "data_comming", function(e) {
            this.updateData(e[this.controlLayer.dataRoot], e.time)
        }, this), this.mon(this.controlLayer, "storagesUpdate", this.onStoragesUpdate, this)
    },
    onStoragesUpdate: function() {
        this.readChart.clearStoreData(), this.writeChart.clearStoreData(), this.readChart.drawChart(), this.writeChart.drawChart()
    },
    updateData: function(e, t) {
        var i = SYNO.SDS.ResourceMonitor.Performance.Disk.Utility,
            r = this.controlLayer.getStoragesToDraw(),
            a = [],
            o = [];
        this.readChart.updateStores(r), this.writeChart.updateStores(r), Ext.each(r, function(t) {
            a.push({
                itemId: t.itemId,
                value: i.getValueFromComingDataById(e, t.storageType, t.itemId, "read_access")
            }), o.push({
                itemId: t.itemId,
                value: i.getValueFromComingDataById(e, t.storageType, t.itemId, "write_access")
            })
        }), this.readChart.pushValueById(a, t), this.writeChart.pushValueById(o, t), this.readChart.drawChart(), this.writeChart.drawChart()
    },
    onActivate: function() {
        this.readChart.drawChart(), this.writeChart.drawChart(), echarts.connect(this.getEchartsComponent())
    },
    getEchartsComponent: function() {
        return this.items.getRange().filter(function(e) {
            return e.echarts
        }).map(function(e) {
            return e.echarts
        })
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Disk.History", {
    extend: "Ext.Panel",
    constructor: function(e) {
        this.chart1 = new SYNO.SDS.ResourceMonitor.Performance.Chart.History({
            topLayer: e.topLayer,
            flex: 1,
            setInterval: 4
        }), this.chart2 = new SYNO.SDS.ResourceMonitor.Performance.Chart.History({
            topLayer: e.topLayer,
            flex: 1,
            setInterval: 4
        });
        var t = {
                xtype: "displayfield",
                height: 8,
                border: !1
            },
            i = {
                ctCls: "performance-disk-box",
                layout: "vbox",
                border: !1,
                layoutConfig: {
                    align: "stretch",
                    pack: "start"
                },
                padding: "12px 0px 0px 0px",
                items: [this.chart1, t, this.chart2]
            };
        Ext.apply(i, e), this.callParent([i])
    },
    initEvents: function() {
        var e = this;
        SYNO.SDS.ResourceMonitor.Performance.Disk.History.superclass.initEvents.apply(this, arguments), e.mon(e.controlLayer, "storagesUpdate", e.onStoragesUpdate, e)
    },
    onStoragesUpdate: function() {
        var e = this;
        if (!e.isVisible() || !e.history || !e.type) return !1;
        e.setType(e.history, e.type)
    },
    setType: function(e, t) {
        var i = this,
            r = [],
            a = i.controlLayer.historyType,
            o = {};
        i.history = e, i.type = t, i.topLayer.setStatusLoading(), Ext.each(i.controlLayer.getStoragesToDraw(), function(e) {
            r.push(e.itemId)
        }), "disk" === a ? o = {
            disk: r
        } : "space" === a && (o = {
            space: r
        }), SYNO.API.Request({
            api: "SYNO.Core.System.Utilization",
            appWindow: i.topLayer.appWin,
            method: "get",
            version: 1,
            params: {
                type: "history",
                resource: [a],
                time_range: e,
                interfaces: o,
                graph: t
            },
            scope: i,
            callback: i.LoadHistoryData
        })
    },
    LoadHistoryData: function(e, t, i, r) {
        if (this.topLayer.clearStatusLoading(), !e || !t) {
            var a = this.topLayer.webapiErrorMapper(t ? t.code : 0);
            return void this.getEl().mask(a)
        }
        if (!t.data_size) return void this.getEl().mask(_T("rsrcmonitor", "no_history"));
        this.getEl().unmask(), this.drawCharts(t, i)
    },
    drawCharts: function(e, t) {
        "utilization" === t.graph && this.drawUtilizationChart(e, t), "transfer_rate" === t.graph && this.drawTransferRateChart(e, t), "iops" === t.graph && this.drawIopsChart(e, t), this.doLayout(), echarts.connect(this.getEchartsComponent())
    },
    drawUtilizationChart: function(e, t) {
        var i = this,
            r = [],
            a = {},
            o = {};
        r = i.controlLayer.getStoragesToDraw(), Ext.each(e[i.controlLayer.historyType], function(e) {
            a[e.device] = e.utilization
        }), i.chart1.chartName = "Utilization", o = {
            flex: 1,
            chartTitle: _T("rsrcmonitor", "utilization") + " (%)",
            lines: r,
            timeAxis: t.time_range,
            dataType: "percent",
            data: a,
            dataSize: e.data_size,
            endTime: e.time,
            timeInterval: e.interval
        }, i.chart1.show(), i.chart2.hide(), i.chart1.setChartConfig(o), i.chart1.drawChart()
    },
    drawTransferRateChart: function(e, t) {
        var i = this,
            r = [],
            a = {},
            o = {};
        r = i.controlLayer.getStoragesToDraw(), Ext.each(e[i.controlLayer.historyType], function(e) {
            a[e.device] = e.read_byte
        }), i.chart1.chartName = "TransferRate", i.chart2.chartName = "TransferRate", i.chart1.show(), i.chart2.show(), o = {
            flex: 1,
            chartTitle: _T("rsrcmonitor", "read_speed"),
            lines: r,
            timeAxis: t.time_range,
            dataType: "bytes",
            dataBase: 1,
            data: a,
            dataSize: e.data_size,
            endTime: e.time,
            timeInterval: e.interval
        }, i.chart1.setChartConfig(o), a = {}, Ext.each(e[i.controlLayer.historyType], function(e) {
            a[e.device] = e.write_byte
        }), o.chartTitle = _T("rsrcmonitor", "write_speed"), o.data = a, i.chart2.setChartConfig(o), i.chart1.drawChart(), i.chart2.drawChart()
    },
    drawIopsChart: function(e, t) {
        var i = this,
            r = [],
            a = {},
            o = {};
        r = i.controlLayer.getStoragesToDraw(), Ext.each(e[i.controlLayer.historyType], function(e) {
            a[e.device] = e.read_access
        }), i.chart1.chartName = "Iops", i.chart2.chartName = "Iops", i.chart1.show(), i.chart2.show(), o = {
            flex: 1,
            chartTitle: _T("rsrcmonitor", "read"),
            lines: r,
            timeAxis: t.time_range,
            dataType: "iops",
            data: a,
            dataSize: e.data_size,
            endTime: e.time,
            timeInterval: e.interval
        }, i.chart1.setChartConfig(o), a = {}, Ext.each(e[i.controlLayer.historyType], function(e) {
            a[e.device] = e.write_access
        }), o.chartTitle = _T("rsrcmonitor", "write"), o.data = a, i.chart2.setChartConfig(o), i.chart1.drawChart(), i.chart2.drawChart()
    },
    getEchartsComponent: function() {
        return this.items.getRange().filter(function(e) {
            return e.echarts
        }).map(function(e) {
            return e.echarts
        })
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Space.SelectorDialog", {
    extend: "SYNO.SDS.ResourceMonitor.Performance.Disk.SelectorDialog",
    constructor: function(e) {
        var t = this,
            i = [t.createVolumeGrid()];
        e.owner.hasOpenConfig("is_cms_open") && i.push(t.createLunGrid());
        var r = Ext.apply({
            grids: i
        }, e);
        this.callParent([r])
    },
    createVolumeGrid: function() {
        var e = SYNO.SDS.ResourceMonitor.Performance.Disk.Utility;
        return this.createStorageGrid({
            itemId: "volume",
            title: _T("volume", "volume"),
            nameIndex: "display_name",
            displayNameSorter: e.volumeSorter
        })
    },
    createLunGrid: function() {
        var e = SYNO.SDS.ResourceMonitor.Performance.Disk.Utility;
        return this.createStorageGrid({
            itemId: "lun",
            title: _T("volume", "volume_iscsitrg_lun"),
            nameIndex: "display_name",
            displayNameSorter: e.defaultSorter
        })
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Space.Main", {
    extend: "SYNO.SDS.ResourceMonitor.Performance.Disk.Main",
    header_title: _T("tree", "leaf_volume"),
    dataRoot: "space",
    historyType: "space",
    constructor: function(e) {
        var t = Ext.apply({
            selectorDialogClass: SYNO.SDS.ResourceMonitor.Performance.Space.SelectorDialog
        }, e);
        this.callParent([t])
    }
}), Ext.ns("SYNO.SDS.ResourceMonitor.Performance.Lun"), SYNO.SDS.ResourceMonitor.Performance.Lun.Charts = function() {
    var e = _T("rsrcmonitor", "read"),
        t = _T("rsrcmonitor", "write"),
        i = _T("rsrcmonitor", "total"),
        r = _T("snapmgr", "info_average"),
        a = _T("rsrcmonitor", "rsrcmonitor_trans"),
        o = _T("rsrcmonitor", "rsrcmonitor_recv"),
        n = {
            t: e,
            c: "#1574E8"
        },
        s = {
            t: t,
            c: "#09B3B3"
        },
        c = {
            t: i,
            c: "#A278E5"
        },
        l = {
            t: r,
            c: "#A278E5"
        };
    return [{
        field: "throughput",
        fieldName: _T("rsrcmonitor", "throughput"),
        line: [n, s, c],
        dataType: "bytes",
        show: !0
    }, {
        field: "iops",
        fieldName: _T("rsrcmonitor", "iops"),
        line: [n, s, c],
        dataType: "iops",
        show: !0
    }, {
        field: "total_latency",
        fieldName: _T("rsrcmonitor", "total_latency"),
        line: [l],
        dataType: "timeus",
        show: !0
    }, {
        field: "io_size",
        fieldName: _T("rsrcmonitor", "io_size"),
        line: [n, s],
        dataType: "byte",
        show: !1
    }, {
        field: "io_latency",
        fieldName: _T("rsrcmonitor", "io_latency"),
        line: [n, s, l],
        dataType: "timeus",
        show: !1
    }, {
        field: "network_latency",
        fieldName: _T("rsrcmonitor", "network_latency"),
        line: [{
            t: a,
            c: "#1574E8"
        }, {
            t: o,
            c: "#09B3B3"
        }, l],
        dataType: "timeus",
        show: !1
    }, {
        field: "queue",
        fieldName: _T("rsrcmonitor", "queue_depth"),
        line: [{
            t: _T("rsrcmonitor", "depth"),
            c: "#A278E5"
        }],
        dataType: "normal",
        show: !1
    }]
}(), SYNO.SDS.ResourceMonitor.Performance.Lun.Util = {
    weightAvg: function(e, t, i, r, a) {
        return 0 < a ? (e * t + i * r) / a : 0
    }
}, Ext.define("SYNO.SDS.ResourceMonitor.Performance.Lun.Main", {
    extend: "Ext.Container",
    constructor: function(e) {
        this.alreadySelectedLun = !1, this.callParent([Ext.apply({
            layout: "anchor",
            listeners: {
                activate: this.onActivate,
                scope: this
            }
        }, e)])
    },
    createComponent: function(e) {
        var t = this,
            i = ["#e44c41", "#fb6d96", "#6b6dca", "#80d24c", "#ff8400", "#fcbd00", "#2fc9c2"],
            r = new SYNO.SDS.ResourceMonitor.Performance.Lun.IOStatStore;
        t.fieldSelector = new SYNO.SDS.ResourceMonitor.Performance.Lun.FieldSelector({
            owner: e.topLayer.appWin,
            topLayer: e.topLayer,
            handler: {
                accept: t.udpateGraphType,
                scope: t
            }
        }), t.lunCombo = t.createLunSelector(), t.chartHeader = new SYNO.SDS.ResourceMonitor.Performance.Detail.Header({
            header_title: t.header_title,
            topLayer: e.topLayer,
            lun_combo: {
                label: {
                    xtype: "syno_displayfield",
                    margins: {
                        top: 0,
                        right: 0,
                        bottom: 0,
                        left: 0
                    },
                    style: "text-align: right;",
                    value: "LUN:"
                },
                combo: t.lunCombo
            },
            lun_field_button: {
                button: t.createFieldButton()
            }
        }), t.currentCard = new SYNO.SDS.ResourceMonitor.Performance.Lun.Current({
            itemId: "current",
            topLayer: e.topLayer,
            tabLayer: t,
            iostatStore: r,
            defaultColors: i
        }), t.historyCard = new SYNO.SDS.ResourceMonitor.Performance.Lun.History({
            itemId: "history",
            topLayer: e.topLayer,
            tabLayer: t,
            iostatStore: r,
            defaultColors: i
        }), t.chartContent = new Ext.Container({
            layout: "card",
            anchor: "100% -37",
            topLayer: e.topLayer,
            activeItem: 0,
            style: {
                padding: "12px 0 0 8px"
            },
            items: [t.currentCard, t.historyCard]
        }), t.mon(e.topLayer, "data_comming", function(e) {
            var i = e.lun;
            if (e.is_failed) return void t.mask(t, i);
            r.save(i, e.time), t.updateLuns(i), t.currentCard.updateData()
        }), t.mon(t.chartHeader, "contentSelect", t.changeContent, t), t.add(t.chartHeader), t.add(t.chartContent), t.chartHeader.history_combo.setVisible(e.showHistory), t.chartHeader.history_label.setVisible(e.showHistory), t.doLayout(!1, !0)
    },
    createFieldButton: function() {
        return new SYNO.ux.Button({
            cls: "absolute-left",
            margins: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 10
            },
            text: _T("rsrcmonitor", "choose_charts"),
            scope: this,
            handler: function() {
                this.fieldSelector.show()
            }
        })
    },
    createLunSelector: function() {
        return new SYNO.ux.ComboBox({
            width: 200,
            margins: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 10
            },
            valueField: "uuid",
            displayField: "lun_name",
            listeners: {
                select: function(e, t) {
                    "current" === this.chartContent.layout.activeItem.itemId ? this.currentCard.setSelectedLun(t.get("uuid")) : this.historyCard.setSelectedLun(t.get("uuid"))
                },
                scope: this
            },
            store: new Ext.data.JsonStore({
                fields: ["uuid", {
                    name: "lun_name",
                    sortType: "asNaturalUCString"
                }]
            })
        })
    },
    changeContent: function(e) {
        this.saveActiveItem = this.chartContent.layout.activeItem.itemId, "current" === e.history ? (this.chartContent.layout.setActiveItem("current"), this.chartContent.get("current").setSelectedLun(this.lunCombo.getValue())) : (this.chartContent.layout.setActiveItem("history"), this.chartContent.get("history").setSelectedLun(this.lunCombo.getValue(), e.history))
    },
    onActivate: function() {
        this.lunCombo && 0 === this.lunCombo.store.getCount() ? (this.mask(this, _T("rsrcmonitor", "no_running_luns")), this.alreadySelectedLun = !1) : this.unmask(this), [this.chartHeader, this.currentCard, this.historyCard].forEach(function(e) {
            e && e.fireEvent("activate")
        })
    },
    udpateGraphType: function(e) {
        this.currentCard.updateFieldVisible(e), this.historyCard.updateFieldVisible(e)
    },
    updateLuns: function(e) {
        var t = this.lunCombo,
            i = t.isExpanded();
        e.sort(function(e, t) {
                var i = e.lun_name.toUpperCase(),
                    r = t.lun_name.toUpperCase();
                return i < r ? -1 : i > r ? 1 : 0
            }),
            t.store.loadData(e.map(function(e) {
                return {
                    uuid: e.uuid,
                    lun_name: e.lun_name
                }
            })), i || t.collapse(), 0 === e.length ? (this.mask(this, _T("rsrcmonitor", "no_running_luns")), this.alreadySelectedLun = !1) : this.unmask(this), 0 === e.length || this.alreadySelectedLun || (t.setValue(e[0].uuid), this.chartHeader.headerChange(), this.alreadySelectedLun = !0)
    },
    mask: function(e, t) {
        void 0 !== t ? e.getEl().mask(t, "syno-ux-mask-info") : e.getEl().mask()
    },
    unmask: function(e) {
        e.getEl().unmask()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Lun.IOStatStore", {
    maxStoreNum: 350,
    constructor: function() {
        this.savedData = {}, this.count = 0, this.dummyIostat = {
            data: {
                throughput: [0, 0, 0],
                iops: [0, 0, 0],
                io_size: [0, 0, 0],
                total_latency: [0, 0, 0],
                io_latency: [0, 0, 0],
                network_latency: [0, 0, 0],
                queue: [0, 0, 0]
            },
            time: void 0
        }
    },
    computeData: function(e) {
        var t = e.tx_avg_latency + e.rx_avg_latency;
        return {
            throughput: [e.read_throughput, e.write_throughput, e.total_throughput],
            iops: [e.read_iops, e.write_iops, e.total_iops],
            io_size: [e.read_avg_cmd_size, e.write_avg_cmd_size],
            total_latency: [t + e.total_io_latency],
            io_latency: [e.read_avg_latency, e.write_avg_latency, e.total_io_latency],
            network_latency: [e.tx_avg_latency, e.rx_avg_latency, t],
            queue: [e.deferred_cmd_cnt],
            lun_name: e.lun_name
        }
    },
    save: function(e, t) {
        var i = this,
            r = !1;
        e.forEach(function(e) {
            var a = e.uuid;
            if (!i.savedData[a])
                for (i.savedData[a] = []; i.savedData[a].length !== i.count;) i.savedData[a].push(i.dummyIostat);
            i.savedData[a].push({
                data: i.computeData(e),
                time: t
            }), 2 * i.maxStoreNum < i.savedData[a].length && (i.savedData[a] = i.savedData[a].slice(-i.maxStoreNum), r = !0)
        }), r ? i.count = i.maxStoreNum : i.count += 1
    },
    last: function(e) {
        return e ? e[e.length - 1] : void 0
    },
    transformIostat: function(e) {
        var t, i = this;
        return e.some(function(e) {
            return void 0 !== (t = e.time)
        }), SYNO.SDS.ResourceMonitor.Performance.Lun.Charts.reduce(function(t, r) {
            return t.data[r.field] = e.map(function(e) {
                return i.last(e.data[r.field])
            }), t
        }, {
            data: {},
            time: t
        })
    },
    peekField: function(e) {
        var t = this,
            i = e.map(function(e) {
                return t.peekLun(e)
            });
        return this.transformIostat(i)
    },
    peekLun: function(e) {
        return this.last(this.savedData[e])
    },
    peek: function(e) {
        return Ext.isArray(e) ? this.peekField(e) : this.peekLun(e)
    },
    loadField: function(e) {
        for (var t = this, i = [], r = e.map(function(e) {
                return t.loadLun(e)
            }), a = 0; a < this.count; a++) ! function(e) {
            i.push(t.transformIostat(r.map(function(t) {
                return t[e]
            })))
        }(a);
        return i
    },
    loadLun: function(e) {
        var t = this.savedData[e];
        return t || []
    },
    load: function(e) {
        return Ext.isArray(e) ? this.loadField(e) : this.loadLun(e)
    },
    getLunName: function(e) {
        var t = this.peekLun(e);
        return t ? t.data.lun_name : void 0
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Lun.Current", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        this.selectedLUNs = void 0, this.multiple = !1;
        var t = {
            border: !1,
            autoFlexcroll: !0,
            topLayer: e.topLayer,
            listeners: {
                activate: this.onActivate,
                scope: this
            },
            bodyStyle: {
                padding: "0"
            },
            items: []
        };
        Ext.apply(t, e), this.callParent([t])
    },
    onActivate: function() {
        this.drawChart()
    },
    initEvents: function() {
        this.callParent(arguments), this.initializeDatafields()
    },
    setSelectedLun: function(e) {
        var t = this;
        t.multiple = Ext.isArray(e) && e.length > 1;
        var i = t.getLunLines(e);
        SYNO.SDS.ResourceMonitor.Performance.Lun.Charts.forEach(function(e) {
            var r = t.get(e.field),
                a = r.get("chart"),
                o = t.multiple ? i : t.getFieldLines(e);
            a.updateStores(o), a.lines = o
        }), (t.multiple || t.selectedLUNs !== e) && (t.selectedLUNs = e, t.tabLayer.alreadySelectedLun && t.refreshField())
    },
    getLunLines: function(e) {
        var t = this;
        if (this.multiple) return e.map(function(e, i) {
            return {
                color: t.defaultColors[i],
                itemId: e,
                lineName: t.iostatStore.getLunName(e),
                lineStyle: {
                    width: 2
                }
            }
        })
    },
    getFieldLines: function(e) {
        return e.line.map(function(e, t) {
            return {
                itemId: "line" + t,
                lineName: e.t,
                color: e.c,
                trackColor: e.c,
                lineStyle: {
                    width: 2
                }
            }
        })
    },
    initializeDatafields: function() {
        var e = this,
            t = {};
        this.add(SYNO.SDS.ResourceMonitor.Performance.Lun.Charts.map(function(i) {
            return t[i.field] = i.show, {
                xtype: "container",
                topLayer: e.topLayer,
                itemId: i.field,
                fieldName: i.fieldName,
                border: !1,
                layout: {
                    type: "vbox",
                    align: "stretch"
                },
                cls: "lun-field-ct",
                items: [new SYNO.SDS.ResourceMonitor.Performance.Chart.Current({
                    chartTitle: i.fieldName,
                    cls: "chart",
                    itemId: "chart",
                    topLayer: e.topLayer,
                    totalTime: SYNO.SDS.ResourceMonitor.Performance.CurrentTotalTime,
                    lines: e.getFieldLines(i),
                    height: 164,
                    dataType: i.dataType
                }), {
                    xtype: "box",
                    itemId: "legend",
                    height: 28,
                    html: ""
                }]
            }
        })), this.updateFieldVisible(t)
    },
    updateFieldVisible: function(e) {
        this.items.each(function(t) {
            t.setVisible(e[t.itemId])
        }), this.drawChart(), this.doLayout()
    },
    refreshField: function() {
        this.clearChartData(), this.loadChart(this.iostatStore.load(this.selectedLUNs)), this.updateLegend(this.iostatStore.peek(this.selectedLUNs)), this.drawChart()
    },
    clearChartData: function() {
        this.items.each(function(e) {
            e.get("chart").clearStoreData()
        })
    },
    updateData: function() {
        var e = this.iostatStore.peek(this.selectedLUNs);
        e && (this.updateChart(e), this.updateLegend(e), this.drawChart())
    },
    loadChart: function(e) {
        var t = this;
        e.forEach(function(e) {
            t.updateChart(e)
        })
    },
    updateChart: function(e) {
        e && this.items.each(function(t) {
            t.get("chart").pushValue(e.data[t.itemId], e.time)
        })
    },
    getLunLegend: function(e) {
        return '<div class="legend-lun">' + e.map(function(e) {
            return String.format('<div class="line-indicator"><div class="legend-color-dot" style="background-color:{0}"></div><div class="line-name line-name-fixed" ext:qtip="{1}">{1}</div></div>', e.color, e.lineName)
        }).join("") + "</div>"
    },
    getFieldLegend: function(e, t, i) {
        return '<div class="legend-lun">' + t.lines.map(function(r, a) {
            var o = i.topLayer.numberUnit(e.data[i.itemId][a] || 0, t.dataType),
                n = o.unit,
                s = o.num;
            return "throughput" === i.itemId && (n += "/s"), String.format('<div class="line-indicator"><div class="legend-color-dot" style="background-color:{0}"></div><div class="line-name">{1}</div><div class="legend-value">{2}</div><div class="legend-value-unit">{3}</div></div>', r.color, r.lineName, s, n)
        }).join("") + "</div>"
    },
    updateLegend: function(e) {
        var t = this;
        e && this.items.each(function(i) {
            var r = i.get("chart");
            i.get("legend").update(t.multiple ? t.getLunLegend(r.lines) : t.getFieldLegend(e, r, i))
        })
    },
    drawChart: function() {
        this.items.each(function(e) {
            e.get("chart").drawChart()
        }), echarts.connect(this.getEchartsComponent())
    },
    getEchartsComponent: function() {
        return this.items.getRange().filter(function(e) {
            return e.get("chart").echarts
        }).map(function(e) {
            return e.get("chart").echarts
        })
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Lun.History", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        this.selectedLUNs = void 0;
        var t = {
            border: !1,
            autoFlexcroll: !0,
            topLayer: e.topLayer,
            bodyStyle: {
                padding: "0"
            },
            items: []
        };
        Ext.apply(t, e), this.callParent([t])
    },
    initEvents: function() {
        this.callParent(arguments), this.initializeDatafields()
    },
    setSelectedLun: function(e, t) {
        var i = this;
        e && (i.history || t) && (t && (i.history = t), i.topLayer.setStatusLoading(), i.multiple = Ext.isArray(e) && e.length > 1, i.selectedLUNs = Ext.isArray(e) ? e : [e], SYNO.API.Request({
            api: "SYNO.Core.System.Utilization",
            method: "get",
            version: 1,
            params: {
                type: "history",
                resource: ["lun"],
                time_range: i.history,
                interfaces: {
                    lun: i.selectedLUNs
                }
            },
            scope: i,
            callback: i.loadHistoryData
        }))
    },
    getLunLines: function(e) {
        var t = this;
        if (this.multiple) return e.map(function(e, i) {
            return {
                color: t.defaultColors[i],
                itemId: e,
                lineName: t.iostatStore.getLunName(e),
                lineStyle: {
                    width: 2
                }
            }
        })
    },
    getFieldLines: function(e) {
        return e.line.map(function(e, t) {
            return {
                itemId: "line" + t,
                lineName: e.t,
                color: e.c,
                trackColor: e.c,
                lineStyle: {
                    width: 2
                }
            }
        })
    },
    loadHistoryData: function(e, t, i) {
        if (this.topLayer.clearStatusLoading(), !e) {
            var r = this.topLayer.webapiErrorMapper(t ? t.code : 0);
            return void this.tabLayer.mask(this, r)
        }
        return t && Ext.isDefined(t.data_size) ? 0 === t.data_size ? void this.tabLayer.mask(this, _T("rsrcmonitor", "no_history")) : (this.unmask(this), this.updateGraphData(t, i), this.drawChart(), void echarts.connect(this.getEchartsComponent())) : void this.tabLayer.mask(this, _T("error", "error_error_system"))
    },
    drawChart: function() {
        this.items.each(function(e) {
            e.get("chart").drawChart()
        })
    },
    initializeDatafields: function() {
        var e = this,
            t = {};
        this.add(SYNO.SDS.ResourceMonitor.Performance.Lun.Charts.map(function(i) {
            return t[i.field] = i.show, {
                xtype: "container",
                topLayer: e.topLayer,
                itemId: i.field,
                border: !1,
                fieldName: i.fieldName,
                layout: {
                    type: "vbox",
                    align: "stretch"
                },
                cls: "lun-field-ct",
                items: [new SYNO.SDS.ResourceMonitor.Performance.Chart.History({
                    itemId: "chart",
                    cls: "chart",
                    topLayer: e.topLayer,
                    lines: e.getFieldLines(i),
                    height: 216,
                    dataType: i.dataType,
                    dataBase: 1
                }), {
                    xtype: "box",
                    itemId: "legend",
                    height: 28,
                    html: ""
                }]
            }
        })), this.updateFieldVisible(t)
    },
    updateFieldVisible: function(e) {
        this.items.each(function(t) {
            t.setVisible(e[t.itemId])
        }), this.drawChart(), this.doLayout()
    },
    updateGraphData: function(e, t) {
        var i = this,
            r = this.computeData(e.iscsi, e.data_size),
            a = this.getLunLines(this.selectedLUNs);
        SYNO.SDS.ResourceMonitor.Performance.Lun.Charts.forEach(function(o) {
            var n = i.get(o.field),
                s = n.get("chart"),
                c = i.multiple ? a : i.getFieldLines(o);
            s.setChartConfig({
                chartTitle: o.fieldName,
                topLayer: i.topLayer,
                timeAxis: t.time_range,
                data: r[o.field],
                size: e.data_size,
                endTime: e.time,
                timeInterval: e.interval,
                lines: c
            }), s.lines = c
        }), this.updateLegend(), this.doLayout()
    },
    computeData: function(e, t) {
        return this.multiple ? this.computeMultipleData(e, t) : this.computeSingleData(e[0], t)
    },
    computeMultipleData: function(e, t) {
        return e.reduce(function(e, i) {
            for (var r = [], a = [], o = [], n = 0; n < t; ++n) r[n] = i.tx_avg_latency[n] + i.rx_avg_latency[n], a[n] = i.total_io_latency[n] + r[n], o[n] = SYNO.SDS.ResourceMonitor.Performance.Lun.Util.weightAvg(i.read_avg_cmd_size[n], i.read_iops[n], i.write_avg_cmd_size[n], i.write_iops[n], i.total_iops[n]);
            return e.throughput[i.device] = i.total_throughput, e.iops[i.device] = i.total_iops, e.io_size[i.device] = o, e.total_latency[i.device] = a, e.io_latency[i.device] = i.total_io_latency, e.network_latency[i.device] = r, e.queue[i.device] = i.deferred_cmd_cnt, e
        }, {
            throughput: {},
            iops: {},
            io_size: {},
            total_latency: {},
            io_latency: {},
            network_latency: {},
            queue: {}
        })
    },
    computeSingleData: function(e, t) {
        for (var i = [], r = [], a = 0; a < t; ++a) i[a] = e.tx_avg_latency[a] + e.rx_avg_latency[a], r[a] = e.total_io_latency[a] + i[a];
        return {
            throughput: {
                line0: e.read_throughput,
                line1: e.write_throughput,
                line2: e.total_throughput
            },
            iops: {
                line0: e.read_iops,
                line1: e.write_iops,
                line2: e.total_iops
            },
            io_size: {
                line0: e.read_avg_cmd_size,
                line1: e.write_avg_cmd_size
            },
            total_latency: {
                line0: r
            },
            io_latency: {
                line0: e.read_avg_latency,
                line1: e.write_avg_latency,
                line2: e.total_io_latency
            },
            network_latency: {
                line0: e.tx_avg_latency,
                line1: e.rx_avg_latency,
                line2: i
            },
            queue: {
                line0: e.deferred_cmd_cnt
            }
        }
    },
    updateLegend: function() {
        var e = this;
        this.items.each(function(t) {
            var i = t.get("chart");
            t.get("legend").update(e.getLegend(i.lines))
        })
    },
    getLegend: function(e) {
        return '<div class="legend-lun">' + e.map(function(e) {
            return String.format('<div class="line-indicator"><div class="legend-color-dot" style="background-color:{0}"></div><div class="line-name line-name-fixed" ext:qtip="{1}">{1}</div></div>', e.color, e.lineName)
        }).join("") + "</div>"
    },
    unmask: function(e) {
        e.getEl().unmask()
    },
    getEchartsComponent: function() {
        return this.items.getRange().filter(function(e) {
            return e.get("chart").echarts
        }).map(function(e) {
            return e.get("chart").echarts
        })
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Lun.LunSelector", {
    extend: "SYNO.ux.ComboBox",
    constructor: function(e) {
        this.selectedLUNs = [], this.callParent([Ext.apply({
            triggerAction: "all",
            editable: !1,
            mode: "local",
            autoScroll: !1,
            multiSelect: !0,
            selectOnFocus: !0,
            valueField: "uuid",
            displayField: "lun_name",
            store: new Ext.data.JsonStore({
                fields: ["uuid", {
                    name: "lun_name",
                    sortType: "asNaturalUCString"
                }, "checked"]
            }),
            tpl: new Ext.XTemplate('<tpl for=".">', '<div class="x-combo-list-item">', '<div class="x-form-check-wrap">', '<tpl if="this.isChecked(checked)">', '<input type="button" class="syno-ux-checkbox-icon syno-ux-cb-checked" style="margin-left:0px;">', "</tpl>", '<tpl if="!this.isChecked(checked)">', '<input type="button" class="syno-ux-checkbox-icon" style="margin-left:0px;">', "</tpl>", '<label ext:qtip="{lun_name}" style="line-height:22px;margin-left:28px;">{lun_name}</label>', "</div>", "</div>", "</tpl>", {
                isChecked: function(e) {
                    return !0 === e
                },
                compiled: !0
            })
        }, e)])
    },
    updateLuns: function(e) {
        var t = this;
        this.store.loadData(e.map(function(e) {
            return {
                uuid: e.uuid,
                lun_name: e.lun_name,
                checked: t.selectedLUNs.indexOf(e.uuid) > -1
            }
        })), this.setValue(this.getDisplayValue())
    },
    onSelect: function(e) {
        var t = !e.get("checked");
        e.set("checked", t);
        var i = this.store.query("checked", !0);
        if (i.getCount() > SYNO.SDS.ResourceMonitor.Performance.MaxDisplaySize) {
            var r = this.findAppWindow().getMsgBox();
            return e.set("checked", !1), this.collapse(), void r.alert("", String.format(_T("rsrcmonitor", "exceeded_max_disk_selection"), SYNO.SDS.ResourceMonitor.Performance.MaxDisplaySize))
        }
        if (0 === i.getCount()) return void e.set("checked", !0);
        this.saveLUNs(i.items.map(function(e) {
            return e.get("uuid")
        })), this.setValue(this.getDisplayValue()), Ext.isFunction(this.handler.select) && this.handler.select.call(this.handler.scope, this.getValue())
    },
    saveLUNs: function(e) {
        this.selectedLUNs = e
    },
    getDisplayValue: function() {
        var e = this.selectedLUNs.length;
        return 1 === e ? this.selectedLUNs[0] : String.format("[{0} LUNs]", e)
    },
    getValue: function() {
        return 1 === this.selectedLUNs.length ? this.selectedLUNs[0] : this.selectedLUNs
    },
    checkOneLun: function(e) {
        this.store.each(function(t) {
            t.set("checked", t.get("uuid") === e)
        }), this.saveLUNs([e]), this.setValue(this.getDisplayValue())
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Lun.FieldSelector", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t = this;
        t.handler = e.handler || {}, t.store = new Ext.data.ArrayStore({
            data: SYNO.SDS.ResourceMonitor.Performance.Lun.Charts.map(function(e) {
                return [e.show, e.field, e.fieldName]
            }),
            fields: [{
                name: "checked"
            }, {
                name: "data_field"
            }, {
                name: "field_name"
            }]
        }), this.callParent([Ext.apply({
            title: _T("rsrcmonitor", "choose_charts"),
            topLayer: e.topLayer,
            minHeight: 400,
            minWidth: 450,
            height: 400,
            width: 450,
            padding: "16px 20px 0 20px",
            layout: "fit",
            closeAction: "hide",
            items: [{
                xtype: "syno_tabpanel",
                activeTab: 0,
                items: t.createLunGrid(e)
            }],
            buttons: [{
                text: _T("common", "cancel"),
                handler: function() {
                    t.hide()
                },
                scope: t
            }, {
                text: _T("common", "ok"),
                btnStyle: "blue",
                handler: t.okHandler,
                scope: t
            }],
            listeners: {
                beforehide: function() {
                    t.clearStatus(), t.store.rejectChanges()
                }
            }
        }, e)])
    },
    initEvents: function() {
        this.callParent(arguments)
    },
    createLunGrid: function(e) {
        return this.createFieldGrid({
            title: _T("rsrcmonitor", "data_fields"),
            topLayer: e.topLayer
        })
    },
    createFieldGrid: function(e) {
        var t = new SYNO.ux.EnableColumn({
            dataIndex: "checked",
            align: "center",
            bindRowClick: !0,
            width: 40
        });
        return new SYNO.ux.GridPanel(Ext.apply({
            store: this.store,
            plugins: [t],
            colModel: new Ext.grid.ColumnModel({
                defaults: {
                    sortable: !1,
                    width: 100
                },
                columns: [t, {
                    header: _T("common", "name"),
                    width: 160,
                    dataIndex: "field_name"
                }]
            }),
            enableHdMenu: !1
        }, e))
    },
    getSelections: function() {
        var e = {};
        return this.store.each(function(t) {
            e[t.get("data_field")] = t.get("checked")
        }), e
    },
    okHandler: function() {
        this.clearStatus(), this.store.commitChanges(), Ext.isFunction(this.handler.accept) && this.handler.accept.call(this.handler.scope, this.getSelections()), this.hide()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.GPU.Main", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = Ext.apply({
            layout: "anchor",
            items: [],
            listeners: {
                activate: this.onActivate,
                scope: this
            }
        }, e);
        this.callParent([t])
    },
    createComponent: function(e) {
        var t = !1;
        t |= this.setChartComponent(e.topLayer), (t |= this.setHistoryComponent(e.showHistory)) && this.doLayout(!1, !0)
    },
    onActivate: function() {
        this.items.each(function(e) {
            Ext.isFunction(e.onActivate) && e.onActivate()
        }, this)
    },
    setChartComponent: function(e) {
        return this.chartHeader ? (this.chartHeader.setToRealTime(), !1) : (this.chartHeader = new SYNO.SDS.ResourceMonitor.Performance.Detail.Header({
            header_title: _T("rsrcmonitor", "gpu"),
            topLayer: e,
            type_combo: {
                data: [
                    ["gpu", _T("rsrcmonitor", "gpu_load")],
                    ["memory", _T("rsrcmonitor", "gpu_memory_load")]
                ]
            }
        }), this.add(this.chartHeader), this.content || (this.content = new SYNO.SDS.ResourceMonitor.Performance.GPU.Content({
            topLayer: e,
            anchor: "100% -37",
            header: this.chartHeader
        }), this.add(this.content)), !0)
    },
    setHistoryComponent: function(e) {
        return e === this.chartHeader.history_combo.hidden && (e ? (this.chartHeader.history_combo.show(), this.chartHeader.history_label.show()) : (this.chartHeader.history_combo.hide(), this.chartHeader.history_label.hide()), !0)
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.GPU.Content", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = {
            layout: "card",
            activeItem: 0,
            items: [new SYNO.SDS.ResourceMonitor.Performance.GPU.Current({
                itemId: "current_gpu",
                topLayer: e.topLayer,
                controlLayer: this
            }), new SYNO.SDS.ResourceMonitor.Performance.GPUMemory.Current({
                itemId: "current_memory",
                topLayer: e.topLayer,
                controlLayer: this
            }), new SYNO.SDS.ResourceMonitor.Performance.GPU.History({
                itemId: "history",
                topLayer: e.topLayer,
                controlLayer: this
            })]
        };
        Ext.apply(t, e), this.callParent([t]), this.mon(e.header, "contentSelect", this.changeContent, this)
    },
    changeContent: function(e) {
        Ext.isDefined(e.type) || (e.type = "gpu"), "current" === e.history ? this.layout.setActiveItem(String.format("current_{0}", e.type)) : (this.layout.setActiveItem("history"), this.get("history").setType(e.history, e.type))
    },
    setToRealTime: function() {
        this.header.setToRealTime()
    },
    onActivate: function() {
        var e = this.layout.activeItem;
        Ext.isDefined(e) && Ext.isFunction(e.onActivate) && e.onActivate()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.GPU.Current", {
    extend: "Ext.Panel",
    constructor: function(e) {
        this.chart = new SYNO.SDS.ResourceMonitor.Performance.Chart.Current({
            itemId: "total_chart",
            chartTitle: _T("rsrcmonitor", "utilization") + " (%)",
            flex: 1,
            topLayer: e.topLayer,
            aggregate: !0,
            totalTime: SYNO.SDS.ResourceMonitor.Performance.CurrentTotalTime,
            lines: [{
                itemId: "gpu_utilization",
                lineName: _T("rsrcmonitor", "utilization"),
                color: "#30a9ff",
                trackColor: "#30a9ff",
                trackOrder: 1,
                lineStyle: {
                    width: 1
                },
                areaStyle: {
                    opacity: .7
                }
            }],
            dataType: "percent"
        }), this.uitilization_footer = new SYNO.SDS.ResourceMonitor.Performance.GPU.Current.Footer;
        var t = {
            layout: "vbox",
            layoutConfig: {
                align: "stretch"
            },
            border: !1,
            items: [this.chart, this.uitilization_footer]
        };
        Ext.apply(t, e), this.callParent([t])
    },
    initEvents: function() {
        var e = this;
        e.callParent([arguments]), e.mon(e.topLayer, "data_comming", function(t) {
            e.updateData(t), e.uitilization_footer.updateData(t)
        }), e.mon(e, "activate", e.onActivate, e)
    },
    updateData: function(e) {
        if (e.time && e.gpu) {
            var t = e.gpu,
                i = e.time;
            this.chart.pushValue([t.gpu_utilization], i), this.chart.drawChart()
        }
    },
    onActivate: function() {
        this.chart.drawChart()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.GPU.Current.Footer", {
    extend: "Ext.BoxComponent",
    constructor: function(e) {
        var t = {
            border: !1,
            margins: {
                top: 0,
                right: 0,
                bottom: 20,
                left: 25
            },
            html: this.getChartCtlHtml(0)
        };
        Ext.apply(t, e), this.callParent([t])
    },
    getChartCtlHtml: function(e) {
        return '<div><table><tbody><tr><td rowspan="2" class="legend-color-gray legend-color-item" ></td><td class="legend-value-header">' + _T("rsrcmonitor", "utilization") + '</td></tr><tr><td><span class="legend-value">' + e + '</span><span class="legend-value-unit">%</span></td></tr></tbody></table></div>'
    },
    updateData: function(e) {
        e.gpu && this.update(this.getChartCtlHtml(e.gpu.gpu_utilization))
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.GPUMemory.Current", {
    extend: "Ext.Panel",
    constructor: function(e) {
        this.chart = new SYNO.SDS.ResourceMonitor.Performance.Chart.Current({
            itemId: "total_chart",
            chartTitle: _T("rsrcmonitor", "utilization") + " (%)",
            flex: 1,
            topLayer: e.topLayer,
            aggregate: !0,
            totalTime: SYNO.SDS.ResourceMonitor.Performance.CurrentTotalTime,
            lines: [{
                itemId: "gpu_memory_utilization",
                lineName: _T("rsrcmonitor", "utilization"),
                color: "#30a9ff",
                trackColor: "#30a9ff",
                trackOrder: 1,
                areaStyle: {
                    opacity: .7
                },
                lineStyle: {
                    width: 1
                }
            }],
            dataType: "percent"
        }), this.uitilization_footer = new SYNO.SDS.ResourceMonitor.Performance.GPUMemory.Current.Footer({
            topLayer: e.topLayer,
            margins: {
                top: 2,
                right: 0,
                bottom: 0,
                left: 23
            },
            height: 133,
            style: {
                position: "relative"
            }
        });
        var t = {
            layout: "vbox",
            layoutConfig: {
                align: "stretch"
            },
            border: !1,
            items: [this.chart, this.uitilization_footer]
        };
        Ext.apply(t, e), this.callParent([t])
    },
    initEvents: function() {
        var e = this;
        e.callParent([arguments]), e.mon(e.topLayer, "data_comming", function(t) {
            e.updateData(t), e.uitilization_footer.updateData(t)
        }), e.mon(e, "activate", e.onActivate, e)
    },
    updateData: function(e) {
        if (e.time && e.gpu) {
            var t = e.gpu,
                i = e.time;
            this.chart.pushValue([t.gpu_memory_utilization], i), this.chart.drawChart()
        }
    },
    onActivate: function() {
        this.chart.drawChart(), this.items.each(function(e) {
            Ext.isFunction(e.onActivate) && e.onActivate()
        })
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.GPUMemory.Current.Footer", {
    extend: "Ext.Container",
    usage: null,
    constructor: function(e) {
        var t = {
            border: !1,
            items: [this.getPieChartHtml(), this.getPieChartLegend()],
            listeners: {
                activate: {
                    fn: this.onActivate,
                    scope: this
                },
                resize: {
                    fn: this.onResize,
                    scope: this
                }
            }
        };
        Ext.apply(t, e), this.callParent([t])
    },
    onActivate: function() {
        this.usage && (this.updateSummary(this.usage), this.updatePieChartHtml(this.usage), this.updateLegend(this.usage))
    },
    onResize: function() {
        this.usage && (this.updatePieChartHtml(this.usage), this.updateLegend(this.usage))
    },
    getPieChartHtml: function() {
        this.summary_id = {
            total: Ext.id(),
            totalUnit: Ext.id(),
            util: Ext.id()
        }, this.pieId = {
            used: Ext.id(),
            free: Ext.id()
        };
        var e = '<div style="width: 100%;"><span class="pie-title">' + _T("rsrcmonitor", "memory_composition") + '</span><span style="float:right"><span class="legend-value-header-large"  style="display:inline-block; padding-right: 12px;">' + _T("rsrcmonitor", "total") + "</span><span id=" + this.summary_id.total + ' class="legend-value" style="display:inline-block; padding-right: 8px; padding-left: 0px;">0</span><span id=' + this.summary_id.totalUnit + ' class="legend-value-unit-large" style="padding-right: 28px;">MB</span><span class="legend-value-unit-large" style="display:inline-block; padding-right:12px;">' + _T("rsrcmonitor", "utilization") + "</span><span id=" + this.summary_id.util + ' class="legend-value" style="display:inline-block; padding-right: 8px; padding-left: 0px;">0</span><span class="legend-value-unit-large">%</span></span></div><div class="pie-chart"><div id=' + this.pieId.used + ' class="legend-color-used pie-item"></div><div id=' + this.pieId.free + ' class="legend-color-free pie-last-item"></div> </div>';
        return new Ext.BoxComponent({
            html: e,
            itemId: "pie"
        })
    },
    getPieChartLegend: function() {
        this.legendId = {
            legend: Ext.id(),
            used: Ext.id(),
            usedUnit: Ext.id(),
            free: Ext.id(),
            freeUnit: Ext.id()
        };
        var e = "<div id=" + this.legendId.legend + ' style="position: absolute; top: 73px;"><table class="info-list-table"><tbody><tr><td rowspan="2" class="legend-color-used legend-color-item"></td><td class="legend-value-header">' + _T("rsrcmonitor", "memroy_used") + '</td><td rowspan="2" class="legend-color-free legend-color-item""></td><td class="legend-value-header">' + _T("rsrcmonitor", "memory_free") + "</td></tr><tr><td><span id=" + this.legendId.used + ' class="legend-value">0</span><span id=' + this.legendId.usedUnit + ' class="legend-value-unit">MB</span></td><td><span id=' + this.legendId.free + ' class="legend-value">0</span><span id=' + this.legendId.freeUnit + ' class="legend-value-unit">MB</span></td></tr></tbody></table></div>';
        return new Ext.BoxComponent({
            html: e
        })
    },
    updateData: function(e) {
        if (e.gpu) {
            var t = e.gpu,
                i = {
                    total: 1024 * t.gpu_memory_total,
                    used: 1024 * t.gpu_memory_used,
                    free: 1024 * t.gpu_memory_free,
                    utilization: t.gpu_memory_utilization
                };
            this.usage = i, this.updateSummary(i), this.updatePieChartHtml(i), this.updateLegend(i)
        }
    },
    updatePieChartHtml: function(e) {
        var t = this.get("pie").getWidth() - 2,
            i = Math.ceil(e.used * t / e.total),
            r = t + 1 - i;
        Ext.fly(this.pieId.used).setWidth(i), Ext.fly(this.pieId.free).setWidth(r)
    },
    updateSummary: function(e) {
        var t = this.topLayer.fileSizeUnit(e.total);
        Ext.fly(this.summary_id.total).update(t.size), Ext.fly(this.summary_id.totalUnit).update(t.unit), Ext.fly(this.summary_id.util).update(e.utilization ? e.utilization : "0")
    },
    updateLegend: function(e) {
        var t = this.topLayer.fileSizeUnit(e.used),
            i = this.topLayer.fileSizeUnit(e.free);
        Ext.fly(this.legendId.used).update(t.size), Ext.fly(this.legendId.usedUnit).update(t.unit), Ext.fly(this.legendId.free).update(i.size), Ext.fly(this.legendId.freeUnit).update(i.unit)
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.GPU.History", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = this,
            i = {};
        t.chart = new SYNO.SDS.ResourceMonitor.Performance.Chart.History({
            chartTitle: _T("rsrcmonitor", "utilization") + " (%)",
            anchor: "100% -115"
        }), i = {
            layout: "anchor",
            items: [t.chart, {
                xtype: "box",
                height: 113,
                style: "position: relative; margin: 2px 0px 0px 23px;",
                itemId: "footer"
            }]
        }, Ext.apply(i, e), this.callParent([i])
    },
    setType: function(e, t) {
        var i = this;
        i.topLayer.setStatusLoading(), SYNO.API.Request({
            api: "SYNO.Core.System.Utilization",
            appWindow: i.topLayer.appWin,
            method: "get",
            version: 1,
            params: {
                type: "history",
                resource: ["gpu"],
                time_range: e,
                graph: t
            },
            scope: i,
            callback: i.LoadHistoryData
        })
    },
    LoadHistoryData: function(e, t, i, r) {
        var a = this;
        if (!a.isDestronyed) {
            if (a.topLayer.clearStatusLoading(), !e || !t) return void a.topLayer.appWin.showAlert(_T(t.err_session, t.err_key), a.controlLayer.setToRealTime, a.controlLayer);
            if (!Ext.isDefined(t.data_size) || 0 === t.data_size) return void a.topLayer.appWin.showAlert(_T("rsrcmonitor", "no_history"), a.controlLayer.setToRealTime, a.controlLayer);
            a.drawCharts(t, i), a.setFooter(t, i)
        }
    },
    drawCharts: function(e, t) {
        var i = this,
            r = {};
        e && (r = "gpu" === t.graph ? {
            chartTitle: _T("rsrcmonitor", "utilization") + " (%)",
            lines: [{
                itemId: "gpu_utilization",
                lineName: _T("rsrcmonitor", "utilization"),
                color: "#30a9ff",
                trackColor: "#30a9ff",
                trackOrder: 1,
                lineStyle: {
                    width: 1
                },
                areaStyle: {
                    opacity: .7
                }
            }],
            timeAxis: t.time_range,
            dataType: "percent",
            data: e.gpu,
            dataSize: e.data_size,
            endTime: e.time,
            timeInterval: e.interval
        } : {
            chartTitle: _T("rsrcmonitor", "utilization") + " (%)",
            lines: [{
                itemId: "gpu_memory_utilization",
                lineName: _T("rsrcmonitor", "utilization"),
                color: "#30a9ff",
                trackColor: "#30a9ff",
                trackOrder: 1,
                lineStyle: {
                    width: 1
                },
                areaStyle: {
                    opacity: .7
                }
            }],
            timeAxis: t.time_range,
            dataType: "percent",
            data: e.gpu,
            dataSize: e.data_size,
            endTime: e.time,
            timeInterval: e.interval
        }, i.chart.setChartConfig(r), i.chart.drawChart())
    },
    setFooter: function(e, t) {
        var i = '<div><table><tbody><tr> <td><div class="legend-color-usage legend-color-dot"></div>' + _T("rsrcmonitor", "utilization") + "</td></tr></tbody></table></div>";
        this.get("footer").update(i)
    }
}), Ext.ns("SYNO.SDS.ResourceMonitor.Performance.NFS"), SYNO.SDS.ResourceMonitor.Performance.NFS.Charts = [{
    field: "iops",
    fieldName: _T("rsrcmonitor", "iops"),
    line: [_T("rsrcmonitor", "read"), _T("rsrcmonitor", "write"), _T("rsrcmonitor", "total")],
    dataType: "iops",
    show: !0
}, {
    field: "total_latency",
    fieldName: _T("rsrcmonitor", "total_latency"),
    line: [_T("rsrcmonitor", "read"), _T("rsrcmonitor", "write"), _T("rsrcmonitor", "total")],
    dataType: "timeus",
    show: !0
}], Ext.define("SYNO.SDS.ResourceMonitor.Performance.NFS.Main", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = Ext.apply({
            layout: "anchor",
            items: [],
            listeners: {
                activate: this.onActivate,
                scope: this
            }
        }, e);
        this.callParent([t])
    },
    createComponent: function(e) {
        var t = this,
            i = e.showHistory,
            r = !1;
        t.chartHeader ? (t.content.get("current").clearDatafields(), t.chartHeader.setToRealTime()) : (t.chartHeader = new SYNO.SDS.ResourceMonitor.Performance.Detail.Header({
            header_title: t.header_title,
            topLayer: e.topLayer
        }), t.add(t.chartHeader), t.content || (t.content = new SYNO.SDS.ResourceMonitor.Performance.NFS.Content({
            topLayer: e.topLayer,
            anchor: "100% -37",
            header: t.chartHeader
        }), t.add(t.content)), r = !0), i === t.chartHeader.history_combo.hidden && (i ? (t.chartHeader.history_combo.show(), t.chartHeader.history_label.show()) : (t.chartHeader.history_combo.hide(), t.chartHeader.history_label.hide()), r = !0), r && t.doLayout(!1, !0)
    },
    onActivate: function() {
        this.setMask(), this.items.each(function(e) {
            Ext.isFunction(e.onActivate) && e.onActivate()
        }, this)
    },
    setMask: function() {
        SYNO.API.Request({
            api: "SYNO.Core.FileServ.NFS",
            method: "get",
            version: 2,
            scope: this,
            callback: function(e, t) {
                if (e)
                    if (!0 === t.enable_nfs) this.getEl().unmask();
                    else {
                        if (!_S("is_admin")) return void this.getEl().mask(_T("rsrcmonitor", "admin_delegate_nfs_mask"), "syno-ux-mask-info");
                        this.gotoNfsSettingId || (this.gotoNfsSettingId = Ext.id());
                        var i = _T("share", "nfs_not_enabled"),
                            r = '<a href="" class="link-font" id="' + this.gotoNfsSettingId + '">' + _T("nfs", "nfs_title") + "</a>";
                        this.getEl().mask(String.format(i, r), "syno-ux-mask-info");
                        var a = Ext.get(this.gotoNfsSettingId);
                        Ext.isObject(a) && a.on("click", this.onClickNfsSetting, this)
                    }
            }
        })
    },
    onClickNfsSetting: function(e) {
        e.preventDefault(), SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
            fn: "SYNO.SDS.AdminCenter.FileService.Main",
            tab: "nfs"
        })
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.NFS.Content", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = {
            itemId: "content",
            layout: "card",
            activeItem: 0,
            items: [new SYNO.SDS.ResourceMonitor.Performance.NFS.Current({
                itemId: "current",
                topLayer: e.topLayer,
                controlLayer: this
            }), new SYNO.SDS.ResourceMonitor.Performance.NFS.History({
                itemId: "history",
                topLayer: e.topLayer,
                controlLayer: this
            })],
            style: {
                padding: "12px 0 0 8px"
            }
        };
        Ext.apply(t, e), this.callParent([t]), this.header = e.header, this.mon(e.header, "contentSelect", this.changeContent, this)
    },
    changeContent: function(e) {
        "current" === e.history ? this.layout.setActiveItem("current") : (this.layout.setActiveItem("history"), this.get("history").setType(e.history))
    },
    updateInfo: function(e) {
        this.choosedGraphs = e, this.get("current").updateDatafields(e), this.get("history").updateDatafields(e)
    },
    setToRealTime: function() {
        this.header.setToRealTime()
    },
    onActivate: function() {
        var e = this.layout.activeItem;
        Ext.isDefined(e) && Ext.isFunction(e.onActivate) && e.onActivate()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.NFS.Current", {
    extend: "SYNO.ux.FormPanel",
    defaultDataFields: {},
    constructor: function(e) {
        var t = {
            border: !1,
            autoFlexcroll: !0,
            topLayer: e.topLayer,
            items: [],
            listeners: {
                scope: this,
                activate: this.onActivate
            }
        };
        Ext.apply(t, e), this.callParent([t])
    },
    initEvents: function() {
        var e = this;
        this.callParent(arguments), SYNO.SDS.ResourceMonitor.Performance.NFS.Charts.forEach(function(t) {
            e.defaultDataFields[t.field] = t.show
        }), this.initializeDatafields(), this.updateDatafields(this.defaultDataFields), this.mon(this.topLayer, "data_comming", function(e) {
            this.updateData(e.nfs, e.time)
        }, this)
    },
    onActivate: function() {
        this.items.each(function(e) {
            Ext.isFunction(e.drawChart) && e.drawChart()
        }, this), echarts.connect(this.getEchartsComponent())
    },
    updateData: function(e, t) {
        var i = this;
        e && t && e.forEach(function(e) {
            SYNO.SDS.ResourceMonitor.Performance.NFS.Charts.forEach(function(r) {
                var a = i.get(r.field);
                a && a.updateData(e, t)
            })
        })
    },
    initializeDatafields: function() {
        var e = this;
        SYNO.SDS.ResourceMonitor.Performance.NFS.Charts.forEach(function(t) {
            e.add(new SYNO.SDS.ResourceMonitor.Performance.NFS.Current.Datafield({
                topLayer: e.topLayer,
                itemId: t.field,
                fieldName: t.fieldName,
                cls: "nfs-field-ct"
            }))
        }), this.doLayout()
    },
    updateDatafields: function(e) {
        var t = this;
        SYNO.SDS.ResourceMonitor.Performance.NFS.Charts.forEach(function(i) {
            t.get(i.field).setVisible(e[i.field])
        }), this.doLayout()
    },
    clearDatafields: function() {
        this.items.each(function(e) {
            e.chart.clearStoreData(), e.chart.drawChart()
        })
    },
    getEchartsComponent: function() {
        return this.items.getRange().filter(function(e) {
            return e.chart.echarts
        }).map(function(e) {
            return e.chart.echarts
        })
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.NFS.Current.Datafield", {
    extend: "Ext.Container",
    maxStoreNum: 350,
    constructor: function(e) {
        this.dataField = e.itemId, this.dataType = "", this.lines = this.initializeLines(), this.toplayer = e.topLayer, this.chart = new SYNO.SDS.ResourceMonitor.Performance.Chart.Current({
            topLayer: e.topLayer,
            chartTitle: e.fieldName,
            totalTime: SYNO.SDS.ResourceMonitor.Performance.CurrentTotalTime,
            lines: this.lines.filter(function(e) {
                return e.lineName
            }),
            height: 164,
            dataType: this.dataType
        });
        var t = {
            border: !1,
            layout: "vbox",
            layoutConfig: {
                align: "stretch"
            },
            items: [this.chart, {
                xtype: "box",
                itemId: "legend",
                height: 28,
                margins: {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 36
                },
                html: ""
            }]
        };
        Ext.apply(t, e), this.callParent([t])
    },
    computeData: function(e, t) {
        var i = e.read_OPS,
            r = e.write_OPS,
            a = e.total_OPS,
            o = e.read_max_latency,
            n = e.write_max_latency,
            s = e.total_max_latency;
        switch (this.dataField) {
            case "iops":
                return [i, r, a];
            case "total_latency":
                return [o, n, s];
            default:
                SYNO.Debug("Not supported dataField ".concat(this.dataField))
        }
    },
    updateData: function(e, t) {
        var i = this.computeData(e);
        this.chart.pushValue(i, t), this.updateLegend(i), this.chart.drawChart()
    },
    initializeLines: function() {
        var e = this,
            t = SYNO.SDS.ResourceMonitor.Performance.NFS.Charts.find(function(t) {
                return t.field === e.dataField
            }),
            i = ["#A278E5", "#09B3B3", "#1574E8"];
        return this.dataType = t.dataType, t.line.map(function(e, t) {
            return {
                itemId: "line" + t,
                lineName: e,
                color: i[t],
                lineStyle: {
                    width: 2
                }
            }
        })
    },
    updateLegend: function(e) {
        var t = this;
        this.get("legend").update('<div class="legend-nfs">' + e.filter(function(e, i) {
            return t.lines[i].lineName
        }, this).map(function(e, i) {
            var r = t.topLayer.numberUnit(e || "0", t.dataType),
                a = r.unit,
                o = r.num;
            return String.format('<div class="line-indicator"><div class="legend-color-dot legend-line{0}">&nbsp</div><div class="line-name">{1}</div><div class="legend-value">{2}</div><div class="legend-value-unit">{3}</div></div>', i, t.lines[i].lineName, o, a)
        }).join("") + "</div>")
    },
    drawChart: function() {
        this.chart.drawChart()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.NFS.History", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        this.defaultDataFields = {};
        var t = {
            itemId: "charts",
            border: !1,
            autoFlexcroll: !0,
            topLayer: e.topLayer,
            items: []
        };
        Ext.apply(t, e), this.callParent([t]), this.initialized || this.initializeDatafields()
    },
    setType: function(e) {
        var t = this;
        t.history = e, t.topLayer.setStatusLoading(), SYNO.API.Request({
            api: "SYNO.Core.System.Utilization",
            appWindow: t.topLayer.appWin,
            method: "get",
            version: 1,
            params: {
                type: "history",
                resource: ["nfs"],
                time_range: e,
                interfaces: {
                    nfs: ["nfs"]
                }
            },
            scope: t,
            callback: t.LoadHistoryData
        })
    },
    LoadHistoryData: function(e, t, i, r) {
        if (this.topLayer.clearStatusLoading(), !e || !t) {
            var a = this.topLayer.webapiErrorMapper(t ? t.code : 0);
            return void this.getEl().mask(a)
        }
        if (!t.data_size) return void this.getEl().mask(_T("rsrcmonitor", "no_history"));
        this.getEl().unmask(), this.updateGraphData(t, i), this.drawCharts(t, i), echarts.connect(this.getEchartsComponent())
    },
    drawCharts: function(e, t) {
        var i = this;
        i.items.eachKey(function(e, t) {
            t.drawChart()
        }, i)
    },
    initializeDatafields: function() {
        var e = this;
        SYNO.SDS.ResourceMonitor.Performance.NFS.Charts.forEach(function(t) {
            e.get(t.field) || e.add(new SYNO.SDS.ResourceMonitor.Performance.NFS.History.Datafield({
                topLayer: e.topLayer,
                itemId: t.field
            }))
        }), SYNO.SDS.ResourceMonitor.Performance.NFS.Charts.forEach(function(t) {
            e.defaultDataFields[t.field] = t.show
        }), this.updateDatafields(this.defaultDataFields), this.initialized = !0, this.doLayout()
    },
    updateDatafields: function(e) {
        var t = this;
        SYNO.SDS.ResourceMonitor.Performance.NFS.Charts.forEach(function(i) {
            t.get(i.field).setVisible(e[i.field])
        }), this.doLayout()
    },
    updateGraphData: function(e, t) {
        var i = this;
        SYNO.SDS.ResourceMonitor.Performance.NFS.Charts.forEach(function(r) {
            var a = i.get(r.field),
                o = i.parseData(e.nfs[0], e.data_size, r.field);
            a.setChartConfig({
                chartTitle: r.fieldName,
                topLayer: i.topLayer,
                timeAxis: t.time_range,
                data: o,
                dataSize: e.data_size,
                endTime: e.time,
                timeInterval: e.interval
            })
        }), this.doLayout()
    },
    parseData: function(e, t, i) {
        switch (i) {
            case "iops":
                return {
                    line0: e.read_OPS, line1: e.write_OPS, line2: e.total_OPS
                };
            case "total_latency":
                return {
                    line0: e.read_max_latency, line1: e.write_max_latency, line2: e.total_max_latency
                };
            default:
                return SYNO.Debug("Not supported dataField ".concat(this.dataField)), {
                    line0: [],
                    line1: [],
                    line2: []
                }
        }
    },
    getEchartsComponent: function() {
        return this.items.getRange().filter(function(e) {
            return e.chart.echarts
        }).map(function(e) {
            return e.chart.echarts
        })
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.NFS.History.Datafield", {
    extend: "Ext.Container",
    constructor: function(e) {
        this.dataField = e.itemId, this.dataType = "", this.lines = this.initializeLines(), this.toplayer = e.topLayer, this.chart = new SYNO.SDS.ResourceMonitor.Performance.Chart.History({
            topLayer: e.topLayer,
            lines: this.lines.filter(function(e) {
                return e.lineName
            }),
            height: 216,
            dataType: this.dataType,
            dataBase: 1
        });
        var t = '<div class="legend-nfs">' + this.lines.filter(function(e) {
                return e.lineName
            }, this).map(function(e, t) {
                return String.format('<div class="line-indicator"><div class="legend-color-dot legend-line{0}">&nbsp</div><div class="line-name">{1}</div></div>', t, e.lineName)
            }).join("") + "</div>",
            i = {
                border: !1,
                layout: "vbox",
                layoutConfig: {
                    align: "stretch"
                },
                items: [this.chart, {
                    xtype: "box",
                    itemId: "legend",
                    height: 28,
                    margins: {
                        top: 0,
                        right: 0,
                        bottom: 32,
                        left: 36
                    },
                    html: t
                }]
            };
        Ext.apply(i, e), this.callParent([i])
    },
    initializeLines: function() {
        var e = this,
            t = SYNO.SDS.ResourceMonitor.Performance.NFS.Charts.find(function(t) {
                return t.field === e.dataField
            }),
            i = ["#A278E5", "#09B3B3", "#1574E8"];
        return this.dataType = t.dataType, t.line.map(function(e, t) {
            return {
                itemId: "line" + t,
                lineName: e,
                color: i[t],
                trackColor: i[t],
                lineStyle: {
                    width: 2
                }
            }
        })
    },
    setChartConfig: function(e) {
        this.chart.setChartConfig(e)
    },
    drawChart: function() {
        this.chart.drawChart()
    }
}), Ext.ns("SYNO.SDS.ResourceMonitor.Performance"), SYNO.SDS.ResourceMonitor.Performance.CurrentTotalTime = 7200, SYNO.SDS.ResourceMonitor.Performance.CurrentInterval = 10, Ext.define("SYNO.SDS.ResourceMonitor.Performance.Main", {
    extend: "SYNO.SDS.Utils.TabPanel",
    time_range: "current",
    constructor: function(e) {
        this.show_space = "yes" !== _D("usbstation"), this.show_lun = "yes" === _D("support_iscsi_target", "no"), this.show_gpu = "yes" === _D("support_nvidia_gpu");
        var t = /^synology_([A-Z|a-z|0-9]+)_([A-Z|a-z|0-9]+)/.exec(_D("unique"))[1],
            i = ["armadaxp", "armada370", "armada375", "evansport", "comcerto2k"];
        this.show_nfs = !i.includes(t);
        var r = Ext.apply({
            activeTab: 0,
            syncTabsActiveEvent: !1,
            cls: "resource-monitor-performance",
            bodyCfg: {
                cls: "resource-monitor-performance-tab-panel-body"
            },
            items: [new SYNO.SDS.ResourceMonitor.Performance.Overview.Main({
                cls: "performance-overview",
                itemId: "overview_main",
                topLayer: this,
                appWin: e.appWin,
                title: _T("rsrcmonitor", "overview"),
                show_nfs: this.show_nfs
            }), new SYNO.SDS.ResourceMonitor.Performance.CPU.Main({
                cls: "performance-cpu",
                itemId: "cpu_main",
                title: _T("rsrcmonitor", "cpu")
            }), new SYNO.SDS.ResourceMonitor.Performance.Memory.Main({
                cls: "performance-memory",
                itemId: "mem_main",
                title: _T("rsrcmonitor", "memory")
            }), new SYNO.SDS.ResourceMonitor.Performance.Network.Main({
                cls: "performance-network",
                itemId: "net_main",
                title: _T("rsrcmonitor", "network")
            }), new SYNO.SDS.ResourceMonitor.Performance.Disk.Main({
                cls: "performance-disk",
                itemId: "disk_main",
                title: _T("rsrcmonitor", "disk")
            })]
        }, e);
        return this.show_space && r.items.push(new SYNO.SDS.ResourceMonitor.Performance.Space.Main({
            cls: "performance-disk",
            itemId: "space_main",
            title: _T("tree", "leaf_volume")
        })), this.show_lun && r.items.push(new SYNO.SDS.ResourceMonitor.Performance.Lun.Main({
            cls: "performance-lun",
            itemId: "lun_main",
            title: _T("tree", "leaf_iscsilun")
        })), this.show_gpu && r.items.push(new SYNO.SDS.ResourceMonitor.Performance.GPU.Main({
            cls: "performance-gpu",
            itemId: "gpu_main",
            title: "GPU"
        })), this.show_nfs && r.items.push(new SYNO.SDS.ResourceMonitor.Performance.NFS.Main({
            cls: "performance-nfs",
            itemId: "nfs_main",
            title: _T("tree", "leaf_nfs")
        })), this.callParent([Ext.apply(r)])
    },
    initEvents: function() {
        this.callParent(arguments), this.initPerformance()
    },
    initPerformance: function() {
        var e = this;
        _asyncToGenerator(regeneratorRuntime.mark(function t() {
            var i;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.prev = 0, t.next = 3, e.loadConfigAsync();
                    case 3:
                        return i = t.sent, e.setConfig(i), t.next = 7, e.loadPerformanceFirstTimeAsync();
                    case 7:
                        e.StartPolling(), t.next = 14;
                        break;
                    case 10:
                        t.prev = 10, t.t0 = t.catch(0), SYNO.Debug(t.t0), e.appWin.showAlert(_T("common", "commfail"), e.appWin.close, e.appWin);
                    case 14:
                    case "end":
                        return t.stop()
                }
            }, t, this, [
                [0, 10]
            ])
        }))()
    },
    loadConfigAsync: function() {
        return this.sendWebAPIPromise({
            api: "SYNO.ResourceMonitor.Setting",
            version: 1,
            method: "get",
            scope: this
        }).then(function(e) {
            return {
                showHistory: !!e.enable_history && e.enable_history
            }
        })
    },
    setConfig: function(e) {
        var t = this;
        this.items.each(function(i) {
            Ext.isFunction(i.createComponent) && i.createComponent({
                topLayer: t,
                showHistory: e.showHistory
            }), Ext.isFunction(i.onActivate) && i.onActivate()
        })
    },
    loadPerformanceFirstTimeAsync: function() {
        var e = this;
        return this.sendWebAPIPromise({
            api: "SYNO.Core.System.Utilization",
            version: 1,
            method: "get",
            scope: this,
            param: {
                type: "current",
                resource: this.getResources()
            }
        }).then(function(t) {
            e.fireEvent("data_comming", t)
        })
    },
    getResources: function() {
        var e = ["cpu", "memory", "network", "disk", "nfs"];
        return this.show_nfs && e.push("nfs"), this.show_lun && e.push("lun"), this.show_space && e.push("space"), this.show_gpu && e.push("gpu"), e
    },
    StartPolling: function() {
        var e = this;
        SYNO.SDS.SocketInst.register({
            api: "SYNO.Core.System.Utilization",
            version: 1,
            method: "get",
            params: {
                type: "current"
            }
        }, function(t) {
            t.success && e.fireEvent("data_comming", t.data)
        }, !1)
    },
    clearStatusLoading: function() {
        this.appWin.clearStatusLoading()
    },
    setStatusLoading: function() {
        this.appWin.setStatusLoading()
    },
    setTimeRange: function(e) {
        -1 !== ["current", "day", "week", "month", "year"].indexOf(e) && (this.time_range = e)
    },
    numberUnit: function(e, t) {
        var i = parseInt(e, 10),
            r = i,
            a = "";
        switch (t) {
            case "percent":
                return {
                    num: "" + r, unit: "%"
                };
            case "byte":
            case "bytes":
                return i < 1048576 ? (r = Math.round(10 * i / 1024) / 10, a = "KB") : i < 1073741824 ? (r = Math.round(10 * i / 1048576) / 10, a = "MB") : (r = Math.round(10 * i / 1073741824) / 10, a = "GB"), {
                    num: "" + r,
                    unit: a
                };
            case "timeus":
                return i < 1e3 ? (r = i, a = "us") : i < 1e6 ? (r = Math.round(10 * i / 1e3) / 10, a = "ms") : (r = Math.round(10 * i / 1e6) / 10, a = "s"), {
                    num: "" + r,
                    unit: a
                };
            case "normal":
                return i < 1e3 ? (r = i, a = "") : i < 1e6 ? (r = Math.round(10 * i / 1e3) / 10, a = "K") : (r = Math.round(10 * i / 1e6) / 10, a = "M"), {
                    num: "" + r,
                    unit: a
                };
            case "iops":
                return {
                    num: "" + r, unit: "/s"
                };
            default:
                return {
                    num: "" + r, unit: a
                }
        }
    },
    fileSizeUnit: function(e) {
        var t = this.numberUnit(e, "bytes");
        return {
            size: t.num,
            unit: t.unit
        }
    },
    webapiErrorMapper: function(e) {
        switch (e) {
            case 1051:
            case 1052:
            case 1054:
            case 1055:
            case 1057:
                return _T("error", "error_error_system");
            case 1001:
                return _T("rsrcmonitor", "error_volume_operating");
            case 1053:
                return _T("rsrcmonitor", "error_no_volume");
            case 1008:
                return _T("rsrcmonitor", "error_not_enable_history");
            case 1009:
                return _T("rsrcmonitor", "error_db_updating");
            default:
                return _T("error", "error_error_system")
        }
    }
}), Ext.ns("SYNO.SDS.ResourceMonitor"), SYNO.SDS.ResourceMonitor.PollingIntervalMs = 5e3, Ext.define("SYNO.SDS.ResourceMonitor.Top.Main", {
    extend: "SYNO.ux.GridPanel",
    border: !1,
    frame: !1,
    constructor: function(e) {
        var t = {
            title: _T("rsrcmonitor", "process"),
            itemId: "top",
            store: this.createStore(e),
            colModel: this.configColumnModel(),
            viewConfig: {
                forceFit: !0,
                onLoad: Ext.emptyFn,
                listeners: {
                    beforerefresh: function(e) {
                        e.scrollTop = e.scroller.dom.scrollTop
                    },
                    refresh: function(e) {
                        e.scroller.dom.scrollTop = e.scrollTop
                    }
                }
            }
        };
        return Ext.apply(t, e), this.callParent([Ext.apply(t)])
    },
    initEvents: function() {
        this.callParent(arguments), this.task = this.appWin.addTask({
            interval: SYNO.SDS.ResourceMonitor.PollingIntervalMs,
            scope: this.store,
            run: this.store.load
        }), this.mon(this, "activate", this.onActivate, this), this.mon(this, "deactivate", function() {
            this.task.stop()
        }), this.mon(this.appWin, "server_change", this.onServerChange, this)
    },
    onServerChange: function() {
        this.task.stop(), this.store.removeAll()
    },
    onActivate: function(e) {
        e && e.targetReady && this.mon(this.store, "load", this.clearStatusLoading, this, {
            single: !0
        }), this.task.start(!0), 0 === this.store.getCount() && (this.setHeight(this.appWin.getInnerHeight()), this.setStatusLoading(!1))
    },
    kbfileSize: function(e) {
        return Ext.util.Format.fileSize(1024 * e)
    },
    processStatus: function(e) {
        switch (e) {
            case "R":
                return _T("rsrcmonitor", "running");
            case "S":
                return _T("rsrcmonitor", "sleeping");
            case "T":
                return _T("rsrcmonitor", "stopped");
            default:
                return _T("rsrcmonitor", "sleeping") + " (" + e + ")"
        }
    },
    createStore: function(e) {
        return new SYNO.API.Store({
            api: "SYNO.Core.System.Process",
            version: "1",
            method: "list",
            appWindow: e.appWin,
            listeners: {
                scope: this,
                load: function(e, t, i) {
                    this.clearStatusLoading()
                },
                exception: function(e, t, i, r, a, o) {
                    var n = a && a.error ? SYNO.API.Errors.core[a.error.code] : _T("common", "error_system");
                    this.clearStatusLoading(), this.appWin.getMsgBox().alert("", n)
                }
            },
            remoteSort: !1,
            autoDestroy: !0,
            sortInfo: {
                field: "cpu",
                direction: "DESC"
            },
            reader: new Ext.data.JsonReader({
                idProperty: "pid",
                root: "process"
            }, [{
                name: "command"
            }, {
                name: "pid"
            }, {
                name: "status"
            }, {
                name: "cpu",
                convert: function(e) {
                    return e / 10
                }
            }, {
                name: "mem",
                convert: function(e, t) {
                    return e - (Ext.isDefined(t.mem_shared) ? t.mem_shared : 0)
                }
            }, {
                name: "mem_shared"
            }])
        })
    },
    configColumnModel: function() {
        return new Ext.grid.ColumnModel({
            columns: [{
                header: _T("rsrcmonitor", "process_name"),
                tooltip: _T("rsrcmonitor", "process_name"),
                dataIndex: "command",
                width: 200,
                align: "left"
            }, {
                header: _T("rsrcmonitor", "process_id"),
                tooltip: _T("rsrcmonitor", "process_id"),
                dataIndex: "pid",
                width: 100,
                align: "left"
            }, {
                header: _T("common", "status"),
                tooltip: _T("common", "status"),
                dataIndex: "status",
                renderer: this.processStatus,
                width: 100,
                align: "left"
            }, {
                header: _T("rsrcmonitor", "cpu") + "(%)",
                tooltip: _T("rsrcmonitor", "cpu") + "(%)",
                dataIndex: "cpu",
                width: 100,
                align: "left"
            }, {
                header: _T("rsrcmonitor", "private_memory"),
                tooltip: _T("rsrcmonitor", "private_memory"),
                dataIndex: "mem",
                renderer: this.kbfileSize,
                width: 100,
                align: "left"
            }, {
                header: _T("rsrcmonitor", "shared_memory"),
                tooltip: _T("rsrcmonitor", "shared_memory"),
                dataIndex: "mem_shared",
                renderer: this.kbfileSize,
                width: 100,
                align: "left"
            }],
            defaults: {
                sortable: !0,
                menuDisabled: !1
            }
        })
    },
    setStatusLoading: function(e) {
        if (e) this.appWin.setStatusLoading();
        else {
            if (this.appWin.isStatusLoading) return;
            this.tabParent ? this.tabParent.getEl().mask(_T("common", "loading"), "x-mask-loading") : this.getEl().mask(_T("common", "loading"), "x-mask-loading")
        }
    },
    clearStatusLoading: function() {
        this.appWin.isStatusLoading && this.appWin.clearStatusLoading(), this.tabParent ? this.tabParent.getEl().unmask() : this.getEl().unmask()
    }
}), Ext.ns("SYNO.SDS.ResourceMonitor.ServiceTree"), SYNO.SDS.ResourceMonitor.ServiceTree.PollingIntervalMs = 1e3, SYNO.SDS.ResourceMonitor.ServiceTree.isLackingMetric = function(e) {
    return "-" === e
}, SYNO.SDS.ResourceMonitor.ServiceTree.round1DP = function(e) {
    return Math.round(10 * e) / 10
}, Ext.define("SYNO.SDS.ResourceMonitor.ServiceTree.TreeLoader", {
    extend: "Ext.ux.tree.TreeGridLoader",
    nodeExpanded: {},
    lastClick: null,
    loadFlag: !1,
    constructor: function(e) {
        var t = {
            api: "SYNO.Core.System.ProcessGroup",
            method: "list",
            version: 1,
            clearOnLoad: !1,
            baseParams: {
                interval: 0
            },
            listeners: {
                scope: this,
                load: this.onLoad
            }
        };
        return Ext.apply(t, e), this.callParent([Ext.apply(t)])
    },
    onLoad: function(e, t, i) {
        var r = Ext.decode(i.responseText),
            a = r.data ? r.data : {},
            o = t.getOwnerTree();
        if (e.loadFlag = !1, o.unmask(), !o.task.running) return !1;
        if (!a || !a.slices) return !1;
        e.data = a, t.beginUpdate(), t.removeAll();
        var n = function e(t) {
                return {
                    on: function() {
                        return e(t)
                    },
                    otherwise: function() {
                        return t
                    }
                }
            },
            s = function e(t, i) {
                return {
                    on: function(r, a) {
                        return r(t) ? n(a(t, i)) : e(t, i)
                    },
                    otherwise: function(e) {
                        return e(t, i)
                    }
                }
            };
        a.slices.forEach(function(i) {
            var r = {};
            if (r.unit_name = i.unit_name, i.name_i18n) {
                var a = i.name_i18n.split(":");
                r.display_name = _T(a[0], a[1])
            } else r.display_name = i.name;
            r.cpuFraction = i.cpu_utilization, r.cpu_time = i.cpu_time, r.memory = i.memory, r.read = i.byte_read_per_sec, r.write = i.byte_write_per_sec, i.app = i.icon.app_id ? SYNO.SDS.Config.FnMap[i.icon.app_id.split(" ")[0]] : null, s(i, r).on(this.isUserDefinedApp, this.createUserDefinedIcon).on(this.isAdminCenterApp, this.createAdminCenterAppIcon).on(this.isPackageApp, this.createPackageAppIcon).otherwise(this.ceateDefaultIcon), r.children = [], this.getProcessGroupOfSlice(i.process, i.unit_name).forEach(function(e) {
                r.children.push(e)
            }), r.expanded = !!e.nodeExpanded[r.unit_name], r.listeners = {
                scope: e,
                expand: function(t) {
                    e.nodeExpanded[t.attributes.unit_name] = !0
                },
                collapse: function(t) {
                    delete e.nodeExpanded[t.attributes.unit_name]
                },
                click: function(t) {
                    e.lastClick = {
                        parent: t.attributes.unit_name,
                        child: null
                    }
                }
            };
            var o = e.createNode(r);
            o && t.appendChild(o)
        }, this), t.endUpdate(), e.restoreClickStatus(t), o.updateScrollbar(), e.appWindow.clearStatusLoading()
    },
    getProcessGroupOfSlice: function(e, t) {
        var i = this,
            r = new Map;
        return e.forEach(function(e) {
            if (!r.has(e.name)) return void r.set(e.name, {
                leaf: !0,
                name: e.name,
                display_name: e.name,
                iconCls: "leaf-no-icon",
                cpuFraction: e.cpu_utilization,
                cpu_time: e.cpu_time,
                memory: e.memory,
                read: e.byte_read_per_sec,
                write: e.byte_write_per_sec,
                listeners: {
                    scope: i,
                    click: function(e) {
                        i.lastClick = {
                            parent: t,
                            child: e.attributes.name
                        }
                    }
                }
            });
            var a = r.get(e.name);
            a.cpuFraction = i.addUpResourceValue(a.cpuFraction, e.cpu_utilization), a.cpu_time = i.addUpResourceValue(a.cpu_time, e.cpu_time), a.memory = i.addUpResourceValue(a.memory, e.memory), a.read = i.addUpResourceValue(a.read, e.byte_read_per_sec), a.write = i.addUpResourceValue(a.write, e.byte_write_per_sec)
        }), r
    },
    addUpResourceValue: function(e, t) {
        var i = !SYNO.SDS.ResourceMonitor.ServiceTree.isLackingMetric(e),
            r = !SYNO.SDS.ResourceMonitor.ServiceTree.isLackingMetric(t);
        return i || r ? i && r ? e + t : i ? e : t : "-"
    },
    restoreClickStatus: function(e) {
        var t = this,
            i = e.getOwnerTree(),
            r = !1;
        Ext.each(e.childNodes, function(e) {
            return null !== t.lastClick && (t.lastClick.parent !== e.attributes.unit_name || (null === t.lastClick.child ? (i.selModel.select(e), !1) : (Ext.each(e.childNodes, function(e) {
                if (t.lastClick.child === e.attributes.name) return i.selModel.select(e), r = !0, !1
            }), !r && void 0)))
        })
    },
    resetStatus: function() {
        delete this.nodeExpanded, delete this.lastClick, this.nodeExpanded = {}, this.lastClick = null
    },
    isUserDefinedApp: function(e) {
        return !!e.icon.cls
    },
    createUserDefinedIcon: function(e, t) {
        t.iconCls = e.icon.cls
    },
    isAdminCenterApp: function(e) {
        return !!e.app && "SYNO.SDS.AdminCenter.Application" === e.icon.app_id
    },
    createAdminCenterAppIcon: function(e, t) {
        var i = SYNO.SDS.UIFeatures.test("isRetina") ? "2x" : "1x",
            r = e.icon.name.replace("icon", "icn").replace(/-/g, "_");
        t.icon = String.format("{0}/images/{1}/home_icons/{2}.png", e.app.config.jsBaseURL, i, r)
    },
    isPackageApp: function(e) {
        return !!e.app && "SYNO.SDS.AdminCenter.Application" !== e.icon.app_id
    },
    createPackageAppIcon: function(e, t) {
        var i = encodeURI(e.app.config.jsBaseURL) + "/" + e.app.config.icon;
        t.icon = SYNO.SDS.UIFeatures.IconSizeManager.getIconPath(i, "AppView")
    },
    ceateDefaultIcon: function(e, t) {
        t.iconCls = "icon-other-app"
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.ServiceTree.Main", {
    extend: "Ext.ux.tree.FleXcrollTreeGrid",
    sampleInterval: 2,
    constructor: function(e) {
        var t = {
            cls: "syno-process-group",
            loadMask: !0,
            enableSort: !1,
            stripeRows: !0,
            animate: !1,
            enableHdMenu: !1,
            loader: new SYNO.SDS.ResourceMonitor.ServiceTree.TreeLoader({
                appWindow: e.appWin
            }),
            columns: this.configColumnModel()
        };
        return Ext.apply(t, e), this.callParent([Ext.apply(t)])
    },
    initEvents: function() {
        var e = this;
        e.task = e.appWin.addTask({
            interval: SYNO.SDS.ResourceMonitor.ServiceTree.PollingIntervalMs,
            scope: e,
            run: function() {
                e.loader.baseParams.interval = e.sampleInterval, !0 !== e.loader.loadFlag && (e.loader.loadFlag = !0, e.loader.load(e.root))
            }
        }), e.mon(e, "activate", e.onActivate, e), e.mon(e, "deactivate", e.onDeactivate, e), this.callParent(arguments)
    },
    initComponent: function() {
        this.callParent(arguments), this.treeGridSorter = new Ext.ux.tree.TreeGridSorter(this, {
            property: "cpuFraction",
            folderSort: !0,
            caseSensitive: !0,
            dir: "desc"
        }), this.treeGridSorter.sortFn = this.sortProcessGroup.createDelegate(this.treeGridSorter), this.treeGridSorter.defaultSortFn = this.sortProcessGroup.createDelegate(this.treeGridSorter)
    },
    sortProcessGroup: function(e, t) {
        var i, r = e.attributes,
            a = t.attributes,
            o = this.property,
            n = r[o],
            s = a[o],
            c = this.dir && "desc" == this.dir.toLowerCase(),
            l = this.leafAttr || "leaf",
            d = r.display_name,
            h = a.display_name,
            u = function(e, t) {
                return e < t ? -1 : e > t ? 1 : 0
            };
        if (this.folderSort) {
            if (r[l] && !a[l]) return 1;
            if (!r[l] && a[l]) return -1
        }
        return i = d.split(":"), d = i.length > 1 ? _T(i[0], i[1]) : d, i = h.split(":"), h = i.length > 1 ? _T(i[0], i[1]) : h, "display_name" === this.property ? d < h ? c ? 1 : -1 : d > h ? c ? -1 : 1 : 0 : "-" === n && "-" === s ? u(d, h) : "-" === n ? c ? 1 : -1 : "-" === s ? c ? -1 : 1 : n < s ? c ? 1 : -1 : n > s ? c ? -1 : 1 : u(d, h)
    },
    onActivate: function(e) {
        this.task.start(!1), this.collapseAll(), this.loader.resetStatus()
    },
    onDeactivate: function(e) {
        this.task.stop()
    },
    renderCpuTime: function(e) {
        if (SYNO.SDS.ResourceMonitor.ServiceTree.isLackingMetric(e)) return e;
        for (var t, i = "", r = [86400, 3600, 60, 1], a = [_T("common", "time_days") + " ", ":", ":", ""], o = 0; o < r.length; ++o) t = e, t = 0 < o ? t % r[o - 1] : t, t = Math.floor(t / r[o]), i = 0 === t && 0 === o ? i : String.format("{0}{1}{2}{3}", i, 0 !== o && 10 > t ? "0" : "", t, a[o]);
        return i
    },
    renderCpuFraction: function(e) {
        return SYNO.SDS.ResourceMonitor.ServiceTree.isLackingMetric(e) ? e : SYNO.SDS.ResourceMonitor.ServiceTree.round1DP(100 * e)
    },
    renderMemory: function(e) {
        return SYNO.SDS.ResourceMonitor.ServiceTree.isLackingMetric(e) ? e : Ext.util.Format.fileSize(e)
    },
    renderIO: function(e) {
        if (SYNO.SDS.ResourceMonitor.ServiceTree.isLackingMetric(e)) return e;
        var t = SYNO.SDS.ResourceMonitor.ServiceTree.round1DP(e);
        return Ext.util.Format.fileSize(t)
    },
    configColumnModel: function() {
        return [{
            header: _T("rsrcmonitor", "service_name"),
            dataIndex: "display_name",
            width: 200,
            align: "left"
        }, {
            header: _T("rsrcmonitor", "cpu") + "(%)",
            dataIndex: "cpuFraction",
            renderer: this.renderCpuFraction,
            width: 80,
            align: "left"
        }, {
            header: _T("rsrcmonitor", "cpu") + " Time",
            dataIndex: "cpu_time",
            renderer: this.renderCpuTime,
            width: 120,
            align: "left"
        }, {
            header: _T("rsrcmonitor", "memory"),
            dataIndex: "memory",
            renderer: this.renderMemory,
            width: 80,
            align: "left"
        }, {
            header: _T("rsrcmonitor", "input_per_sec"),
            dataIndex: "read",
            renderer: this.renderIO,
            width: 80,
            align: "left"
        }, {
            header: _T("rsrcmonitor", "output_per_sec"),
            dataIndex: "write",
            renderer: this.renderIO,
            width: 80,
            align: "left"
        }]
    },
    updateColumnWidths: function() {
        var e, t = this,
            i = t.columns,
            r = i.length,
            a = this.innerCt.parent().getWidth(),
            o = this.getTotalColumnWidth();
        if (this.isVisible()) {
            for (e = 0; e < r; e++) i[e].width = i[e].width * a / o;
            t.callParent(arguments)
        }
    },
    mask: function() {
        this.tabParent ? this.tabParent.getEl().mask(_T("common", "loading"), "x-mask-loading") : this.getEl().mask(_T("common", "loading"), "x-mask-loading")
    },
    unmask: function() {
        this.tabParent ? this.tabParent.getEl().unmask() : this.getEl().unmask()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.TaskTab", {
    extend: "SYNO.SDS.Utils.TabPanel",
    constructor: function(e) {
        var t = Ext.apply({
            activeTab: 0,
            useDefaultBtn: !1,
            items: [new SYNO.SDS.ResourceMonitor.ServiceTree.Main({
                itemId: "service_tree",
                appWin: e.appWin,
                title: _T("schedule", "title_service"),
                tabParent: this
            }), new SYNO.SDS.ResourceMonitor.Top.Main({
                itemId: "top",
                appWin: e.appWin,
                title: _T("rsrcmonitor", "process"),
                tabParent: this
            })]
        }, e);
        this.callParent([Ext.apply(t)]), this.mon(this, "activate", this.onActivate, this)
    },
    onActivate: function(e) {
        this.setStatusLoading(), e && e.targetReady && (this.clearStatusLoading(), this.setActiveTab(0), this.items.map.service_tree.fireEvent("activate", {
            targetReady: !0
        }))
    },
    setStatusLoading: function() {
        this.appWin.setStatusLoading()
    },
    clearStatusLoading: function() {
        this.appWin.clearStatusLoading()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Setting.Main", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(e) {
        var t = this;
        this.callParent([Ext.apply({
            buttons: [{
                xtype: "syno_button",
                btnStyle: "grey",
                text: _T("common", "reset"),
                scope: this,
                handler: function() {
                    return t.getForm().reset()
                }
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                text: _T("common", "commit"),
                scope: this,
                handler: this.applyHandler
            }],
            items: [this.createSettingItems(e)],
            listeners: {
                scope: this,
                activate: function() {
                    try {
                        this.getConfAsync()
                    } catch (e) {
                        this.appWin.showAlert(_T(e.errors.err_session, e.errors.err_key))
                    }
                }
            }
        }, e)])
    },
    onPageConfirmLostChangeSave: function() {
        function e() {
            return t.apply(this, arguments)
        }
        var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t, i = this;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        return this.setStatusLoading({
                            text: _T("common", "saving")
                        }), t = function() {
                            return i.appWin.getMsgBox().alert("", _T("common", "commfail"), null, i), Promise.reject()
                        }, e.next = 4, this.setConfAsync().then(Ext.emptyFn, t).finally(function() {
                            i.clearStatusLoading()
                        });
                    case 4:
                        return e.abrupt("return", e.sent);
                    case 5:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return e
    }(),
    createSettingItems: function(e) {
        return [{
            xtype: "syno_checkbox",
            name: "enable_history",
            htmlEncode: !1,
            boxLabel: _T("rsrcmonitor", "enable_history")
        }, {
            xtype: "syno_displayfield",
            indent: 1,
            value: _T("rsrcmonitor", "enable_history_document")
        }]
    },
    applyHandler: function() {
        this.onBeforeActionApply() && this.confirmApply()
    },
    getWebapiParams: function() {
        return {
            enable_history: this.getForm().findField("enable_history").getValue()
        }
    },
    confirmApply: function() {
        var e = this;
        _asyncToGenerator(regeneratorRuntime.mark(function t() {
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return e.setStatusLoading({
                            text: _T("common", "saving")
                        }), t.prev = 1, t.next = 4, e.setConfAsync();
                    case 4:
                        return t.next = 6, e.getConfAsync();
                    case 6:
                        e.appWin.reloadPerformance(), t.next = 14;
                        break;
                    case 9:
                        t.prev = 9, t.t0 = t.catch(1), SYNO.Debug(t.t0), e.getForm().reset(), e.appWin.showAlert(_T(t.t0.errors.err_session, t.t0.errors.err_key));
                    case 14:
                        e.clearStatusLoading();
                    case 15:
                    case "end":
                        return t.stop()
                }
            }, t, this, [
                [1, 9]
            ])
        }))()
    },
    onBeforeActionApply: function() {
        var e = this.getForm();
        return e.isDirty() ? !!e.isValid() || (this.setStatusError({
            text: _T("common", "forminvalid"),
            clear: !0
        }), !1) : (this.setStatusError({
            text: _T("error", "nochange_subject"),
            clear: !0
        }), !1)
    },
    setConfAsync: function() {
        return this.sendWebAPIPromise({
            api: "SYNO.ResourceMonitor.Setting",
            method: "set",
            version: 1,
            params: this.getWebapiParams()
        })
    },
    getConfAsync: function() {
        var e = this;
        return this.sendWebAPIPromise({
            api: "SYNO.ResourceMonitor.Setting",
            method: "get",
            version: 1
        }).then(function(t) {
            e.getForm().setValues(t)
        })
    },
    setStatusError: function(e) {
        e = e || {}, Ext.applyIf(e, {
            text: _T("common", "error_system"),
            iconCls: "syno-ux-statusbar-error",
            clear: !0
        }), this.getFooterToolbar().setStatus(e)
    },
    setStatusLoading: function(e) {
        this.appWin.setStatusLoading(e)
    },
    clearStatusLoading: function() {
        this.appWin.clearStatusLoading()
    }
}), Ext.ns("SYNO.SDS.ResourceMonitor.Util"), Ext.define("SYNO.SDS.ResourceMonitor.Util.AdvancedSearchField", {
    extend: "SYNO.ux.SearchField",
    initEvents: function() {
        this.callParent(arguments), this.mon(Ext.getDoc(), "mousedown", this.onMouseDown, this), this.mon(this, "keypress", function(e, t) {
            t.getKey() === Ext.EventObject.ENTER && (this.searchPanel.setKeyWord(this.getValue()), this.searchPanel.onSearch())
        }, this)
    },
    isInnerComponent: function(e, t) {
        var i = !1;
        return t.items.each(function(t) {
            if (t instanceof Ext.form.ComboBox) {
                if (t.view && e.within(t.view.getEl())) return i = !0, !1
            } else if (t instanceof SYNO.ux.DateTimeField) {
                if (t.isWithinEl(e)) return i = !0, !1
            } else if (t instanceof Ext.form.CompositeField && this.isInnerComponent(e, t)) return i = !0, !1
        }, this), i
    },
    onMouseDown: function(e) {
        var t = this.searchPanel;
        !t || !t.isVisible() || t.isDestroyed || t.inEl || e.within(t.getEl()) || e.within(this.searchtrigger) || this.isInnerComponent(e, this.searchPanel.getForm()) || t.hide()
    },
    onSearchTriggerClick: function() {
        if (this.searchPanel.isVisible()) return void this.searchPanel.hide();
        var e = [6, 1];
        this.searchPanel.getEl().alignTo(this.wrap, "tr-br?", e), this.searchPanel.show(), this.searchPanel.setKeyWord(this.getValue())
    },
    onTriggerClick: function() {
        this.callParent(), this.searchPanel.onReset()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Util.SearchFormPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        this.dateType = {
            custom: 1,
            today: 2,
            yesterday: 4,
            lastweek: 8,
            lastmonth: 16
        }, this.dataRange = [
            [this.dateType.custom, _T("log", "date_custom")],
            [this.dateType.today, _T("log", "date_today")],
            [this.dateType.yesterday, _T("log", "date_yesterday")],
            [this.dateType.lastweek, _T("log", "date_lastweek")],
            [this.dateType.lastmonth, _T("log", "date_lastmonth")]
        ], this.logLevelType = {
            warn: "Warning",
            crit: "Critical"
        }, this.logLevel = [
            [this.logLevelType.warn, _T("log", "warn_level")],
            [this.logLevelType.crit, _T("log", "crit_level")]
        ], Ext.apply(this, e || {});
        var t = this.fillConfig(e);
        this.callParent([t]), this.mon(this, "afterlayout", function() {
            this.defineBehaviors()
        }, this)
    },
    initComponent: function() {
        this.callParent(arguments), this.addEvents("search")
    },
    fillConfig: function(e) {
        return {
            width: 368,
            heigh: 480,
            floating: !0,
            labelAlign: "left",
            trackResetOnLoad: !0,
            waitMsgTarget: !0,
            border: !1,
            bodyStyle: {
                padding: "16px 24px",
                "font-size": "24px"
            },
            style: {
                "border-width": 0
            },
            autoFlexcroll: !1,
            defaults: {
                hideLabel: !0,
                anchor: "100%"
            },
            items: [this.createKeyword(), this.createFriendlyDate(), this.createCustDate(), this.createLevel(), this.createFooter()],
            listeners: {
                actionfailed: {
                    fn: function() {
                        this.setMsg(""), this.form.reset()
                    },
                    scope: this
                },
                beforeshow: {
                    fn: function() {
                        this.doLayout()
                    },
                    single: !0
                },
                show: {
                    fn: this.doLayout,
                    single: !0
                }
            },
            keys: [{
                key: [10, 13],
                fn: function() {
                    this.isVisible() && (this.btnSearch.hidden || this.btnSearch.disabled ? this.btnStop.hidden || this.btnStop.disabled || this.onStop() : this.onSearch())
                },
                scope: this
            }]
        }
    },
    setComboBoxValue: function(e, t) {
        e.setMultiValue && e.setMultiValue(t.split(","))
    },
    getComboBoxValue: function(e) {
        var t = this.getForm().findField(e);
        return t.getMultiValue ? t.getMultiValue().toString() : t.getValue()
    },
    createTpl: function() {
        return new Ext.XTemplate('<tpl for=".">', '<div class="x-combo-list-item" ext:qtip="{displayText:htmlEncode}">', "{displayText:htmlEncode}", "</div>", "</tpl>")
    },
    logSelect: function(e, t, i) {
        this.setComboBoxValue(e, e.getValue())
    },
    createKeyword: function() {
        return [{
            xtype: "syno_displayfield",
            cls: "field-label",
            value: _T("log", "attr_keyword") + _T("common", "colon"),
            flex: 1
        }, {
            xtype: "syno_textfield",
            cls: "field-input",
            msgTarget: "qtip",
            validateOnBlur: !0,
            validationEvent: "blur",
            name: "keyword",
            flex: 2,
            vaule: ""
        }]
    },
    setDate: function(e, t, i) {
        this.form.findField("searchdatefrom").setMaxValue(t), this.form.findField("searchdateto").setMinValue(e), this.form.findField("searchdatefrom").setValue(e), this.form.findField("searchdateto").setValue(t)
    },
    getFromToDate: function(e) {
        var t, i, r = new Date;
        if (e === this.dateType.today) t = r, i = r;
        else if (e === this.dateType.yesterday) t = r.add(Date.DAY, -1), i = t;
        else if (e === this.dateType.lastweek) {
            var a = r.getDay();
            t = r.add(Date.DAY, -7 - a), i = t.add(Date.DAY, 6)
        } else e === this.dateType.lastmonth && (r = r.add(Date.MONTH, -1), t = r.getFirstDateOfMonth(), i = r.getLastDateOfMonth());
        return {
            from: t,
            to: i
        }
    },
    friendlyDateSelect: function(e, t, i) {
        var r = t.get("id"),
            a = this.getFromToDate(r);
        this.setDate(a.from, a.to, !0)
    },
    getFriendlyDateStore: function() {
        var e = this.dataRange;
        return new Ext.data.ArrayStore({
            autoDestroy: !0,
            fields: ["id", "displayText"],
            data: e
        })
    },
    createFriendlyDate: function() {
        return this.FriendlyDate = new SYNO.ux.ComboBox({
            cls: "field-input",
            mode: "local",
            editable: !1,
            name: "dateRange",
            tpl: this.createTpl(),
            resizable: !1,
            store: this.getFriendlyDateStore(),
            displayField: "displayText",
            valueField: "id",
            triggerAction: "all",
            lazyRender: !0,
            flex: 6,
            value: this.dateType.custom,
            listeners: {
                scope: this,
                beforequery: function(e) {
                    delete e.combo.lastQuery
                },
                beforeselect: this.friendlyDateSelect
            }
        }), [{
            xtype: "syno_displayfield",
            cls: "field-label",
            value: _T("log", "date_range") + _T("common", "colon"),
            flex: 1
        }, this.FriendlyDate]
    },
    createCustDate: function() {
        return this.DateFrom = new SYNO.ux.DateTimeField({
            name: "searchdatefrom",
            isAllDay: !0,
            editable: !1,
            dateFormat: "m/d/Y",
            emptyText: _T("log", "date_from"),
            value: "",
            listeners: {
                scope: this,
                select: function(e, t) {
                    this.form.findField("searchdateto").setMinValue(t)
                }
            }
        }), this.DateTo = new SYNO.ux.DateTimeField({
            name: "searchdateto",
            isAllDay: !0,
            editable: !1,
            dateFormat: "m/d/Y",
            emptyText: _T("log", "date_to"),
            value: "",
            listeners: {
                scope: this,
                select: function(e, t) {
                    this.form.findField("searchdatefrom").setMaxValue(t)
                }
            }
        }), [{
            xtype: "syno_displayfield",
            cls: "field-label",
            value: _T("time", "time_date") + _T("common", "colon")
        }, {
            xtype: "syno_compositefield",
            cls: "field-input",
            hideLabel: !0,
            defaults: {
                flex: 1
            },
            defaultMargins: "0 8 0 0",
            items: [this.DateFrom, this.DateTo]
        }]
    },
    getLogLevelStore: function() {
        var e = this.logLevel.slice(0, this.logLevel.length);
        return e.length > 1 && e.splice(0, 0, ["", _T("log", "log_all")]), new Ext.data.ArrayStore({
            autoDestroy: !0,
            fields: ["value", "displayText"],
            data: e
        })
    },
    createLevel: function() {
        return this.LogLevel = new SYNO.ux.ComboBox({
            xtype: "syno_combobox",
            cls: "field-input-last",
            mode: "local",
            editable: !1,
            name: "logLevel",
            tpl: this.createTpl(),
            resizable: !1,
            store: this.getLogLevelStore(),
            displayField: "displayText",
            valueField: "value",
            triggerAction: "all",
            lazyRender: !0,
            flex: 3,
            value: "",
            listeners: {
                scope: this,
                beforequery: function(e) {
                    delete e.combo.lastQuery
                },
                select: this.logSelect
            }
        }), [{
            xtype: "syno_displayfield",
            cls: "field-label",
            name: "logLevelLabel",
            value: _T("log", "logattr") + _T("common", "colon"),
            flex: 1
        }, this.LogLevel]
    },
    createFooter: function() {
        return [{
            xtype: "toolbar",
            itemId: "btns",
            toolbarCls: "x-panel-footer",
            items: [{
                xtype: "lctbtext",
                itemId: "search-loading",
                text: ""
            }, {
                xtype: "lctbtext",
                itemId: "msg",
                height: 26,
                style: "-webkit-text-size-adjust:none;font-size:11px;height:26px;overflow:hidden;",
                cls: "red-status",
                text: ""
            }, {
                xtype: "tbfill"
            }, {
                xtype: "syno_button",
                btnStyle: "grey",
                text: _T("common", "reset"),
                handler: this.onReset,
                scope: this
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                text: _T("smart", "smart_test_button_stop"),
                itemId: "btn_stop",
                hidden: !0,
                handler: this.onStop,
                scope: this
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                text: _T("log", "search"),
                itemId: "btn_search",
                handler: this.onSearch,
                scope: this
            }]
        }]
    },
    hideItems: function(e) {
        var t;
        Ext.isArray(e) || (e = [e]);
        for (var i = e.length - 1; i >= 0; i--)(t = this.form.findField(e[i])) && t.setVisible(!1)
    },
    defineBehaviors: function() {
        var e = this.get("btns");
        this.btnSearch = e.get("btn_search"), this.btnStop = e.get("btn_stop")
    },
    setMsg: function(e) {
        this.get("btns").get("msg").setText(e)
    },
    setKeyWord: function(e) {
        var t = this.form.findField("keyword");
        t && Ext.isString(e) && t.setValue(e), t.focus("", 1)
    },
    onShowHideBtn: function(e) {
        e ? (this.btnSearch.hide(), this.btnStop.show()) : (this.btnSearch.show(), this.btnStop.hide())
    },
    onEnableDisableBtn: function(e) {
        e ? (this.btnSearch.enable(), this.btnStop.enable()) : (this.btnSearch.disable(), this.btnStop.disable())
    },
    isOwnerDestroyed: function() {
        return this.owner && this.owner.isDestroyed
    },
    showMsg: function(e, t) {
        this.isOwnerDestroyed() || this.owner.getMsgBox().alert(e, t)
    },
    hideMsg: function() {
        this.isOwnerDestroyed() || this.owner.getMsgBox().hide()
    },
    isFieldDirty: function(e) {
        return this.form.findField(e).isDirty()
    },
    onSearch: function(e, t) {
        var i, r, a, o, n, s;
        i = this.getForm(), r = i.findField("keyword").getValue(), a = i.findField("searchdatefrom").getRawValue(), o = i.findField("searchdateto").getRawValue(), n = this.getComboBoxValue("logLevel"), s = {
            filter: {
                keyword: r,
                loglevel: n,
                datefrom: a ? new Date(a + " 00:00:00").getTime() / 1e3 : 0,
                dateto: o ? new Date(o + " 23:59:59").getTime() / 1e3 : 0
            }
        }, this.fireEvent("search", this, s)
    },
    onReset: function() {
        this.setMsg(""), this.form.reset(), this.form.findField("searchdatefrom").setMaxValue(null), this.form.findField("searchdateto").setMinValue(null), this.form.findField("logLevel").multiValue = "", this.onSearch()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Util.TextItem", {
    extend: "Ext.Toolbar.TextItem",
    onRender: function(e, t) {
        this.autoEl = {
            cls: "xtb-text",
            html: this.text || "",
            "ext:qtip": this.text || ""
        }, SYNO.SDS.ResourceMonitor.Util.TextItem.superclass.onRender.call(this, e, t)
    },
    setText: function(e) {
        SYNO.SDS.ResourceMonitor.Util.TextItem.superclass.setText.call(this, e), this.rendered && this.el.set({
            "ext:qtip": e
        })
    }
}), Ext.reg("lctbtext", SYNO.SDS.ResourceMonitor.Util.TextItem), Ext.ns("SYNO.SDS.ResourceMonitor.EventRule"), SYNO.SDS.ResourceMonitor.EventRule.Events = {
    getByType: function(e) {
        var t;
        switch (e) {
            case 1:
                t = this.Service;
                break;
            case 2:
                t = this.iSCSI;
                break;
            case 3:
                t = this.Volume;
                break;
            case 4:
                t = this.InternalUse;
                break;
            case 0:
                t = this.System, t.Resource = t.Resource.filter(function(e) {
                    return t.Enable[e[0]]
                });
                break;
            default:
                t = this.System
        }
        return t
    },
    System: {
        Strings: {
            0: _T("rsrcmonitor", "perf_desc_cpu"),
            1: String.format(_T("rsrcmonitor", "perf_desc_load_avg"), "1 " + _T("rsrcmonitor", "minute"), "{1}", "{2}"),
            2: String.format(_T("rsrcmonitor", "perf_desc_load_avg"), "5 " + _T("rsrcmonitor", "minutes"), "{1}", "{2}"),
            3: String.format(_T("rsrcmonitor", "perf_desc_load_avg"), "15 " + _T("rsrcmonitor", "minutes"), "{1}", "{2}"),
            4: _T("rsrcmonitor", "perf_desc_memory"),
            11: _T("rsrcmonitor", "perf_desc_gpu")
        },
        Units: {
            0: "%",
            1: "",
            2: "",
            3: "",
            4: "%",
            11: "%"
        },
        DefVal: {
            0: 80,
            1: 10,
            2: 10,
            3: 10,
            4: 80,
            11: 80
        },
        MinMax: {
            0: [60, 99],
            1: [1, 1e3],
            2: [1, 1e3],
            3: [1, 1e3],
            4: [1, 99],
            11: [60, 99]
        },
        Resource: [
            [0, _T("router_overview", "cpu_utilization")],
            [1, String.format(_T("rsrcmonitor", "cpu_load_avg"), "1 " + _T("rsrcmonitor", "minute"))],
            [2, String.format(_T("rsrcmonitor", "cpu_load_avg"), "5 " + _T("rsrcmonitor", "minutes"))],
            [3, String.format(_T("rsrcmonitor", "cpu_load_avg"), "15 " + _T("rsrcmonitor", "minutes"))],
            [4, _T("router_overview", "memory_utilization")],
            [11, _T("rsrcmonitor", "gpu_utilization")]
        ],
        Enable: {
            0: !0,
            1: !0,
            2: !0,
            3: !0,
            4: !0,
            11: _D("support_nvidia_gpu")
        }
    },
    Service: {
        Strings: {
            0: _T("rsrcmonitor", "perf_desc_serv_cpu"),
            4: _T("rsrcmonitor", "perf_desc_serv_memory"),
            5: _T("rsrcmonitor", "perf_desc_serv_disk")
        },
        Units: {
            0: "%",
            4: "MB",
            5: "MB/s"
        },
        DefVal: {
            0: 80,
            4: 10,
            5: 10
        },
        MinMax: {
            0: [60, 99],
            4: [1, 524288],
            5: [1, 65536]
        },
        Resource: [
            [0, _T("router_overview", "cpu_utilization")],
            [4, _T("rsrcmonitor", "memory_usage")],
            [5, _T("rsrcmonitor", "disk_io_usage")]
        ]
    },
    iSCSI: {
        Strings: {
            6: _T("rsrcmonitor", "perf_desc_iscsi_network"),
            7: _T("rsrcmonitor", "perf_desc_iscsi_disk")
        },
        Units: {
            6: "ms",
            7: "ms"
        },
        DefVal: {
            6: 100,
            7: 100
        },
        MinMax: {
            6: [10, 6e4],
            7: [10, 6e4]
        },
        Resource: [
            [6, _T("rsrcmonitor", "network_latency")],
            [7, _T("rsrcmonitor", "io_latency")]
        ]
    },
    Volume: {
        Strings: {
            5: _T("rsrcmonitor", "perf_desc_volume")
        },
        Units: {
            5: "%"
        },
        DefVal: {
            5: 80
        },
        MinMax: {
            5: [1, 99]
        },
        Resource: [
            [5, _T("rsrcmonitor", "disk_io_utilization")]
        ]
    },
    InternalUse: {
        Strings: {
            8: "Root partition utilization higher than {1}{2}",
            9: "/tmp directory utilization higher than {1}{2}",
            10: "Number of coredump file(s) more than {1}{2}"
        },
        Units: {
            8: "%",
            9: "%",
            10: ""
        },
        DefVal: {
            8: 80,
            9: 80,
            10: 0
        },
        MinMax: {
            8: [1, 99],
            9: [1, 99],
            10: [0, 99]
        },
        Resource: [
            [8, "Root partition utilization"],
            [9, "/tmp directory utilization"],
            [10, "Number of coredump file(s)"]
        ]
    }
}, Ext.define("SYNO.SDS.ResourceMonitor.Log.Main", {
    extend: "SYNO.ux.GridPanel",
    pageSize: 100,
    constructor: function(e) {
        this.store = this.createStore(e), this.searchPanel = this.initSearchForm(), this.toolBar = this.createTBar(), this.bottomBar = this.createBBar();
        var t = {
            cls: "resource-monitor-log-gridpanel",
            text: _T("rsrcmonitor", "performance_event"),
            store: this.store,
            colModel: this.configColumnModel(),
            tbar: this.toolBar,
            bbar: this.bottomBar,
            viewConfig: {
                forceFit: !0,
                onLoad: Ext.emptyFn,
                listeners: {}
            },
            listeners: {
                resize: function() {
                    this.centerMask()
                },
                scope: this
            }
        };
        return Ext.apply(t, e), this.callParent([Ext.apply(t)])
    },
    centerMask: function() {
        var e = Ext.Element.data(this.body, "maskMsg");
        e && (e.center(this.body), e.center(this.body))
    },
    initSearchForm: function() {
        var e = new SYNO.SDS.ResourceMonitor.Util.SearchFormPanel({
            cls: "syno-sds-fs-search-panel resource-monitor-performance-event-search-panel",
            renderTo: Ext.getBody(),
            shadow: !1,
            hidden: !0,
            owner: this
        });
        return this.addManagedComponent(e), e
    },
    createStore: function(e) {
        return new SYNO.API.JsonStore({
            api: "SYNO.ResourceMonitor.Log",
            version: "1",
            method: "list",
            root: "logs",
            autoDestroy: !0,
            remoteSort: !0,
            appWindow: e.appWin,
            baseParams: {
                limit: this.pageSize,
                offset: 0
            },
            listeners: {
                exception: this.onException,
                scope: this
            },
            sortInfo: {
                field: "time",
                direction: "DESC"
            },
            fields: ["time", "level", "event"]
        })
    },
    createTBar: function() {
        var e = {
            xtype: "syno_menu",
            items: [{
                text: _T("log", "html_type"),
                itemId: "export_html",
                scope: this,
                handler: this.btnExportHTML
            }, {
                text: _T("log", "csv_type"),
                itemId: "export_csv",
                scope: this,
                handler: this.btnExportCSV
            }]
        };
        return new SYNO.ux.Toolbar({
            items: [new Ext.Action({
                itemId: "clear",
                text: _T("common", "clean"),
                scope: this,
                handler: this.btnClear
            }), new SYNO.ux.SplitButton({
                itemId: "export",
                text: _T("autoblock", "autoblock_export_ip_list"),
                scope: this,
                handler: this.btnExportHTML,
                menu: e
            }), "->", new SYNO.SDS.ResourceMonitor.Util.AdvancedSearchField({
                iconStyle: "filter",
                searchPanel: this.searchPanel,
                owner: this
            })]
        })
    },
    createBBar: function() {
        return new SYNO.ux.PagingToolbar({
            store: this.store,
            pageSize: this.pageSize,
            displayInfo: !0
        })
    },
    renderLevel: function(e) {
        switch (e) {
            case "Information":
                return "<span style='color:green;' ext:qtip='" + e + "'>" + e + "</span>";
            case "Warning":
                return "<span class='resource-monitor-level-warning' ext:qtip='" + e + "'>" + e + "</span>";
            case "Critical":
                return "<span class='resource-monitor-level-critical' ext:qtip='" + e + "'>" + e + "</span>";
            default:
                return e
        }
    },
    configColumnModel: function() {
        return new Ext.grid.ColumnModel({
            columns: [{
                header: _T("log", "log_time"),
                dataIndex: "time",
                width: 150,
                align: "left",
                renderer: function(e) {
                    var t = Date.parseDate(e, "Y/n/j G:i:s"),
                        i = SYNO.SDS.DateTimeFormatter(t, {
                            type: "datetimesec"
                        });
                    return '<span ext:qtip="' + i + '">' + i + "</span>"
                }
            }, {
                header: _T("log", "logattr"),
                dataIndex: "level",
                width: 80,
                align: "left",
                renderer: this.renderLevel
            }, {
                header: _T("log", "log_action"),
                dataIndex: "event",
                width: 500,
                align: "left",
                renderer: function(e) {
                    return '<span ext:qtip="' + e + '">' + e + "</span>"
                }
            }],
            defaults: {
                sortable: !1,
                menuDisabled: !1
            }
        })
    },
    initEvents: function() {
        SYNO.SDS.ResourceMonitor.Top.Main.superclass.initEvents.apply(this, arguments), this.mon(this, "activate", this.onActivate, this), this.mon(this.searchPanel, "search", this.onSearch, this), this.mon(this.store, "load", this.onAfterStoreLoad, this), this.mon(this.store, "beforeload", this.onBeforeStoreLoad, this), this.mon(this.appWin, "server_change", this.onServerChange, this)
    },
    onServerChange: function() {},
    onActivate: function(e) {
        e && e.targetReady && this.mon(this.store, "load", this.clearStatusLoading, this, {
            single: !0
        }), this.store.load()
    },
    isTheSame: function(e, t) {
        var i;
        for (i in t)
            if (t[i] !== e[i]) return !1;
        return !0
    },
    onSearch: function(e, t) {
        var i = this.store;
        this.isTheSame(i.baseParams, t) || (Ext.apply(i.baseParams, t), i.load())
    },
    setStatusLoading: function() {
        this.appWin.setStatusLoading()
    },
    clearStatusLoading: function() {
        this.appWin.clearStatusLoading()
    },
    refreshStore: function() {
        this.bottomBar.doRefresh()
    },
    btnExportHTML: function() {
        this.btnExport("html")
    },
    btnExportCSV: function() {
        this.btnExport("csv")
    },
    btnExport: function(e) {
        var t = this.store;
        this.downloadWebAPI({
            webapi: {
                version: 1,
                api: "SYNO.ResourceMonitor.Log",
                method: "export",
                params: {
                    type: e,
                    filter: t.baseParams.filter
                }
            },
            scope: this
        })
    },
    btnClear: function() {
        var e = this;
        this.appWin.getMsgBox().confirm("confirm", _T("log", "log_cfrm_clear"), function(t) {
            "yes" === t && e.sendWebAPI({
                api: "SYNO.ResourceMonitor.Log",
                version: 1,
                scope: e,
                method: "clear",
                callback: function(e, t) {
                    e ? this.refreshStore() : this.appWin.getMsgBox().alert("", this.helper.getError(t.code))
                }
            })
        })
    },
    enableButtonCheck: function() {
        var e = this.store,
            t = this.getTopToolbar(),
            i = t.get("clear"),
            r = t.get("export");
        _S("is_admin") && e.getTotalCount() ? (r.enable(), i.enable()) : (r.disable(), i.disable())
    },
    onBeforeStoreLoad: function(e, t) {
        this.appWin.setStatusBusy(), this.getEl().unmask()
    },
    onAfterStoreLoad: function(e, t, i) {
        t.length < 1 ? this.body.mask(_T("rsrcmonitor", "performance_event_no_event")) : this.body.unmask(), this.enableButtonCheck(), this.appWin.clearStatusBusy()
    },
    onException: function(e, t, i, r, a) {
        var o = a && a.error ? SYNO.API.Errors.core[a.error.code] : _T("common", "error_system");
        this.appWin.getMsgBox().alert("alert", o), this.appWin.clearStatusBusy(), this.getEl().mask(_T("rsrcmonitor", "performance_event_no_event"))
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.EventRule.EventDialog", {
    extend: "SYNO.SDS.ModalWindow",
    SUPPORT_SERVICE_WEBAPI: "SYNO.Core.System.ProcessGroup",
    event_data: null,
    load_record: !1,
    constructor: function(e) {
        this.support_internal = e.support_internal, this.is_edit_mode = e.is_edit_mode, this.panel = this.createPanel(), this.applyBtn = new SYNO.ux.Button({
            btnStyle: "blue",
            text: _T("common", "alt_apply"),
            scope: this,
            handler: this.onApply
        });
        var t = {
                btnStyle: "grey",
                text: _T("common", "alt_cancel"),
                scope: this,
                handler: this.btnClose
            },
            i = {
                dsmStyle: "v5",
                width: 500,
                height: 460,
                resizable: !1,
                title: e.title,
                items: [this.panel],
                buttons: [t, this.applyBtn],
                listeners: {
                    beforeclose: this.onBeforeClose,
                    close: this.onClose,
                    scope: this
                }
            };
        Ext.apply(i, e), this.callParent([i]), this.defineBehaviors()
    },
    defineBehaviors: function() {
        new SYNO.ux.Utils.EnableRadioGroup(this.panel.getForm(), "type", {
            0: ["system"],
            1: ["service_name"],
            2: ["iSCSI_lun"],
            3: ["volume"],
            4: ["internal_use"]
        })
    },
    createPanel: function() {
        var e = {
                xtype: "jsonstore",
                autoDestroy: !0,
                idProperty: "value",
                fields: ["value", {
                    name: "display",
                    sortType: "asNaturalUCString"
                }, "desc"],
                sortInfo: {
                    field: "display",
                    direction: "ASC"
                }
            },
            t = {
                xtype: "jsonstore",
                autoDestroy: !0,
                idProperty: "value",
                fields: ["value", {
                    name: "display",
                    sortType: "asNaturalUCString"
                }],
                sortInfo: {
                    field: "display",
                    direction: "ASC"
                }
            },
            i = {
                xtype: "jsonstore",
                autoDestroy: !0,
                idProperty: "value",
                fields: ["value", {
                    name: "display",
                    sortType: "asNaturalUCString"
                }],
                sortInfo: {
                    field: "display",
                    direction: "ASC"
                }
            },
            r = {
                xtype: "jsonstore",
                autoDestroy: !0,
                idProperty: "value",
                fields: ["value", "display"]
            };
        return new SYNO.SDS.Utils.FormPanel({
            border: !1,
            height: 420,
            cls: "event-rule-dialog",
            checkFormDirty: !1,
            webapi: {
                api: "SYNO.ResourceMonitor.EventRule",
                methods: {
                    set: "set"
                },
                version: 1
            },
            items: [{
                xtype: "syno_textfield",
                name: "id",
                value: "",
                allowBlank: !0,
                hidden: !0
            }, {
                xtype: "syno_fieldset",
                title: _T("rsrcmonitor", "performance_event_type"),
                items: [{
                    xtype: "syno_compositefield",
                    hideLabel: !0,
                    items: [{
                        xtype: "syno_radio",
                        boxLabel: _T("rsrcmonitor", "cpu_system"),
                        name: "type",
                        inputValue: "0",
                        width: 180,
                        checked: !0,
                        listeners: {
                            scope: this,
                            check: this.onEventTypeChange
                        }
                    }, {
                        xtype: "syno_textfield",
                        name: "system",
                        value: "general",
                        hidden: !0
                    }]
                }, {
                    xtype: "syno_compositefield",
                    hideLabel: !0,
                    hidden: !SYNO.API.GetKnownAPI(this.SUPPORT_SERVICE_WEBAPI),
                    items: [{
                        xtype: "syno_radio",
                        boxLabel: _T("connections", "service"),
                        width: 180,
                        name: "type",
                        inputValue: "1",
                        listeners: {
                            scope: this,
                            check: this.onEventTypeChange
                        }
                    }, {
                        xtype: "syno_combobox",
                        width: 200,
                        name: "service_name",
                        store: i,
                        displayField: "display",
                        valueField: "value",
                        tpl: '<tpl for="."><div ext:qtip="{display}" class="x-combo-list-item">{display}</div></tpl>',
                        allowBlank: !1
                    }]
                }, {
                    xtype: "syno_compositefield",
                    hideLabel: !0,
                    items: [this.lunRadio = new SYNO.ux.Radio({
                        boxLabel: _T("tree", "leaf_iscsilun"),
                        width: 180,
                        name: "type",
                        inputValue: "2",
                        disabled: !0,
                        listeners: {
                            scope: this,
                            check: this.onEventTypeChange
                        }
                    }), {
                        xtype: "syno_combobox",
                        width: 200,
                        name: "iSCSI_lun",
                        store: t,
                        displayField: "display",
                        valueField: "value",
                        tpl: '<tpl for="."><div ext:qtip="{display}" class="x-combo-list-item">{display}</div></tpl>',
                        allowBlank: !1
                    }]
                }, {
                    xtype: "syno_compositefield",
                    hideLabel: !0,
                    items: [this.volRadio = new SYNO.ux.Radio({
                        boxLabel: _T("tree", "leaf_volume"),
                        width: 180,
                        name: "type",
                        inputValue: "3",
                        disabled: !0,
                        listeners: {
                            scope: this,
                            check: this.onEventTypeChange
                        }
                    }), {
                        xtype: "syno_message_combobox",
                        width: 200,
                        name: "volume",
                        store: e,
                        displayField: "display",
                        valueField: "value",
                        descriptionField: "desc",
                        triggerAction: "all",
                        editable: !1,
                        grow: !0,
                        allowBlank: !1
                    }]
                }, {
                    xtype: "syno_compositefield",
                    hideLabel: !0,
                    hidden: !this.support_internal,
                    items: [{
                        xtype: "syno_radio",
                        boxLabel: "Internal Use",
                        width: 180,
                        name: "type",
                        inputValue: "4",
                        listeners: {
                            scope: this,
                            check: this.onEventTypeChange
                        }
                    }, {
                        xtype: "syno_textfield",
                        name: "internal_use",
                        value: "internal_use",
                        hidden: !0
                    }]
                }]
            }, {
                xtype: "syno_fieldset",
                items: [{
                    xtype: "syno_combobox",
                    fieldLabel: _T("rsrcmonitor", "performance_event_resource"),
                    name: "resource",
                    store: r,
                    displayField: "display",
                    valueField: "value",
                    tpl: '<tpl for="."><div ext:qtip="{display}" class="x-combo-list-item">{display}</div></tpl>',
                    value: 0,
                    listeners: {
                        scope: this,
                        select: this.onResourceSelect
                    }
                }, {
                    xtype: "syno_compositefield",
                    hideLabel: !1,
                    items: [{
                        xtype: "syno_numberfield",
                        width: 200,
                        fieldLabel: _T("rsrcmonitor", "performance_event_threshold"),
                        name: "threshold",
                        minValue: 60,
                        maxValue: 99,
                        value: 80,
                        allowBlank: !1
                    }, {
                        xtype: "syno_displayfield",
                        name: "unit",
                        value: "%"
                    }]
                }, {
                    xtype: "syno_combobox",
                    fieldLabel: _T("log", "logattr"),
                    store: [
                        [0, _T("log", "warn_level")],
                        [1, _T("log", "crit_level")]
                    ],
                    name: "severity",
                    value: 0
                }, {
                    xtype: "syno_checkbox",
                    name: "enable",
                    boxLabel: _T("backup", "enable"),
                    hidden: this.is_edit_mode,
                    checked: !0
                }]
            }],
            processParams: this.processParams,
            setStatusError: this.setStatusError.createDelegate(this),
            setStatusBusy: this.setStatusBusy.createDelegate(this),
            setStatusOK: this.setStatusOK.createDelegate(this),
            clearStatusBusy: this.clearStatusBusy.createDelegate(this),
            processReturnData: this.processReturnData
        })
    },
    loadData: function() {
        var e = [{
            api: "SYNO.Core.Storage.Volume",
            version: 1,
            method: "list",
            params: {
                offset: 0,
                limit: -1,
                location: "internal"
            }
        }, {
            api: "SYNO.Core.ISCSI.LUN",
            version: 1,
            method: "list",
            params: {
                types: ["BLOCK", "FILE", "THIN", "ADV", "CINDER", "CINDER_BLUN", "CINDER_BLUN_THICK", "BLUN", "BLUN_THICK"]
            }
        }];
        this.IsKnownAPI(this.SUPPORT_SERVICE_WEBAPI) && e.push({
            api: this.SUPPORT_SERVICE_WEBAPI,
            version: 1,
            method: "list",
            params: {
                interval: 0
            }
        }), this.sendWebAPI({
            params: {},
            compound: {
                stopwhenerror: !1,
                params: e
            },
            callback: function(e, t, i) {
                this.clearStatusBusy(), e && !t.has_fail ? this.processData(t) : this.getMsgBox().alert("", _T("common", "commfail"), null, this)
            },
            scope: this
        });
        var t = this.panel.getForm().findField("resource"),
            i = t.getStore(),
            r = SYNO.SDS.ResourceMonitor.EventRule.Events.getByType(0);
        i.loadData(r.Resource.map(function(e) {
            return {
                value: e[0],
                display: e[1]
            }
        })), i.getCount() > 0 && t.setValue(i.getAt(0).get("value"))
    },
    onApply: function() {
        if (!this.panel.getForm().isValid()) return this.setStatusError({
            text: _T("common", "forminvalid"),
            clear: !0
        }), !1;
        this.panel.applyHandler()
    },
    onOpen: function() {
        this.setStatusBusy(), this.loadData(), this.callParent(arguments)
    },
    onBeforeClose: function() {
        return !this.panel.getForm().isDirty() || (this.confirmLostChangePromise({
            save: this.onApply,
            dontSave: function() {
                this.doClose()
            },
            cancel: Ext.emptyFn
        }, this), !1)
    },
    btnClose: function() {
        this.close()
    },
    onClose: function() {
        this.grid.loadData()
    },
    onEventTypeChange: function(e, t) {
        if (t) {
            var i = e.getInputValue();
            this.changeResourceAndUnits(parseInt(i, 10))
        }
    },
    onResourceSelect: function(e, t, i) {
        var r = e.getValue(),
            a = this.panel.getForm().findField("unit"),
            o = this.panel.getForm().getValues().type,
            n = SYNO.SDS.ResourceMonitor.EventRule.Events.getByType(parseInt(o, 10));
        a.setValue(n.Units[r]), this.changeThresholdDefMinMax(o, r)
    },
    fillVolume: function(e) {
        var t = SYNO.API.Response.GetValByAPI(e, "SYNO.Core.Storage.Volume", "list"),
            i = this.panel.getForm().findField("volume"),
            r = i.getStore();
        r.loadData(t.volumes.map(function(e) {
            return {
                value: e.volume_path,
                display: SYNO.SDS.Utils.StorageUtils.VolumeNameRenderer(e),
                desc: Ext.util.Format.htmlEncode(e.description)
            }
        })), r.getCount() > 0 ? (this.volRadio.enable(), i.setValue(r.getAt(0).get("value"))) : this.volRadio.disable()
    },
    fillLun: function(e) {
        var t = SYNO.API.Response.GetValByAPI(e, "SYNO.Core.ISCSI.LUN", "list"),
            i = this.panel.getForm().findField("iSCSI_lun"),
            r = i.getStore();
        r.loadData(t.luns.map(function(e) {
            return {
                value: e.uuid,
                display: e.name
            }
        })), r.getCount() > 0 ? (this.lunRadio.enable(), i.setValue(r.getAt(0).get("value"))) : this.lunRadio.disable()
    },
    fillService: function(e) {
        if (this.IsKnownAPI(this.SUPPORT_SERVICE_WEBAPI)) {
            var t = SYNO.API.Response.GetValByAPI(e, this.SUPPORT_SERVICE_WEBAPI, "list"),
                i = this.panel.getForm().findField("service_name"),
                r = i.getStore();
            r.loadData(t.slices.filter(function(e) {
                return "syno_dsm_internal.slice" !== e.unit_name
            }).map(function(e) {
                var t = e.name_i18n.split(":");
                return {
                    value: e.unit_name,
                    display: t.length > 1 ? _T(t[0], t[1]) : e.name
                }
            })), r.getCount() > 0 && i.setValue(r.getAt(0).get("value"))
        }
    },
    processData: function(e) {
        this.fillVolume(e), this.fillLun(e), this.fillService(e);
        var t = this.panel.getForm();
        if (null !== this.event_data) {
            switch (this.load_record = !0, this.changeResourceAndUnits(this.event_data.type), this.event_data.type) {
                case 0:
                    this.event_data.system = this.event_data.service;
                    break;
                case 1:
                    this.event_data.service_name = this.event_data.service;
                    break;
                case 2:
                    this.event_data.iSCSI_lun = this.event_data.service;
                    break;
                case 3:
                    this.event_data.volume = this.event_data.service;
                    break;
                case 4:
                    this.event_data.internal_use = this.event_data.service
            }
            this.event_data.type = this.event_data.type.toString(), t.setValues(this.event_data), this.changeThresholdDefMinMax(this.event_data.type, this.event_data.resource), this.load_record = !1
        }
    },
    changeResourceAndUnits: function(e) {
        var t, i = this.panel.getForm().findField("resource"),
            r = i.getStore(),
            a = this.panel.getForm().findField("unit"),
            o = SYNO.SDS.ResourceMonitor.EventRule.Events.getByType(parseInt(e, 10));
        r.loadData(o.Resource.map(function(e) {
            return {
                value: e[0],
                display: e[1]
            }
        })), t = this.load_record ? this.event_data.resource : o.Resource[0][0], i.setValue(t), i.originalValue = t, a.setValue(o.Units[t]), a.originalValue = o.Units[t], this.changeThresholdDefMinMax(e, t)
    },
    changeThresholdDefMinMax: function(e, t) {
        var i = this.panel.getForm().findField("threshold"),
            r = SYNO.SDS.ResourceMonitor.EventRule.Events.getByType(parseInt(e, 10));
        i.setMinValue(r.MinMax[t][0]), i.setMaxValue(r.MinMax[t][1]), this.load_record || i.setValue(r.DefVal[t])
    },
    processParams: function(e, t) {
        return "set" === e && (0 === t[0].params.id.length && delete t[0].params.id, t[0].params.type = parseInt(t[0].params.type, 10), t[0].params.threshold = parseInt(t[0].params.threshold, 10), t[0].params.service = t[0].params.volume || t[0].params.iSCSI_lun || t[0].params.service_name || t[0].params.system || t[0].params.internal_use, delete t[0].params.internal_use, delete t[0].params.volume, delete t[0].params.iSCSI_lun, delete t[0].params.service_name, delete t[0].params.system, t.pop()), t
    },
    processReturnData: function(e, t, i) {
        var r = this.getApiArray(e);
        if ("set" === e) {
            if (this.isDestroyed) return;
            if (t.has_fail) {
                6106 === SYNO.API.Response.GetValByAPI(t, r[0].api, r[0].method).code ? this.ownerCt.getMsgBox().alert("", _T("rsrcmonitor", "performance_event_rule_exist"), null, this) : this.ownerCt.getMsgBox().alert("", _T("common", "commfail"), function() {
                    this.ownerCt.doClose()
                }, this)
            } else this.ownerCt.applyBtn.setDisabled(!0), this.ownerCt.doClose.defer(600, this.ownerCt)
        }
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.EventRule.Main", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(e) {
        var t = Ext.apply({
            layout: "fit",
            padding: "0px",
            useDefaultBtn: !0,
            listeners: {
                activate: {
                    fn: function() {
                        this.gridPanel.fireEvent("activate", this)
                    },
                    scope: this
                }
            },
            items: [this.gridPanel = new SYNO.SDS.ResourceMonitor.EventRule.EditPanel(e)]
        }, e);
        this.callParent([t])
    },
    applyHandler: function() {
        this.gridPanel.onSavePromise(this, !0)
    },
    cancelHandler: function() {
        this.gridPanel.onReset()
    },
    hasModifiedRecords: function() {
        return this.gridPanel.hasModifiedRecords()
    },
    loadData: function() {
        return this.gridPanel.loadData(!0)
    },
    setNeedMask: function(e) {
        this.gridPanel.needMask = e
    },
    getOnOffWebapiParams: function() {
        return this.gridPanel.getOnOffWebapiParams()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.EventRule.EditPanel", {
    extend: "SYNO.ux.EditorGridPanel",
    needMask: !1,
    pageSize: 50,
    actions: null,
    constructor: function(e) {
        this.store = this.createStore(e), this.toolBar = this.createTBar(), this.support_internal = !1;
        var t = {
            cls: "resource-monitor-eventrule-editorgridpanel",
            store: this.store,
            padding: "0",
            colModel: this.configColumnModel(),
            tbar: this.toolBar,
            bbar: {
                xtype: "syno_paging",
                store: this.store,
                displayInfo: !0,
                pageSize: this.pageSize,
                doRefresh: function() {
                    this.ownerCt.clearStoreModifedAll(), SYNO.ux.PagingToolbar.prototype.doRefresh.apply(this, arguments)
                }
            },
            selModel: new Ext.grid.RowSelectionModel,
            plugins: [this.enableColumn]
        };
        Ext.apply(t, e), this.callParent([Ext.apply(t)]), this.mon(this.getSelectionModel(), "selectionchange", this.selectionChange, this), this.mon(this, "rowdblclick", this.btnEdit, this)
    },
    createStore: function(e) {
        return new SYNO.API.Store({
            api: "SYNO.ResourceMonitor.EventRule",
            version: "1",
            method: "list",
            appWindow: e.appWin,
            listeners: {
                scope: this,
                beforeload: function() {
                    this.appWin.setStatusBusy({
                        text: _T("common", "loading")
                    })
                },
                load: function(e) {
                    this.remainToggleRec(), this.appWin.clearStatusBusy(), this.support_internal = 0 !== e.reader.jsonData.support_internal
                }
            },
            reader: new Ext.data.JsonReader({
                idProperty: "id",
                root: "rules"
            }, ["enable", "id", "severity", "name", "resource", "service", "threshold", "type"]),
            remoteSort: !1,
            sortInfo: {
                field: "id",
                direction: "DESC"
            },
            autoDestroy: !0
        })
    },
    createTBar: function() {
        return this.actions = {
            add: new Ext.Action({
                itemId: "add",
                text: _T("common", "create"),
                handler: this.btnAdd,
                scope: this
            }),
            edit: new Ext.Action({
                itemId: "edit",
                text: _T("common", "alt_edit"),
                handler: this.btnEdit,
                disabled: !0,
                scope: this
            }),
            del: new Ext.Action({
                itemId: "delete",
                text: _T("common", "delete"),
                handler: this.btnDel,
                disabled: !0,
                scope: this
            })
        }, new SYNO.ux.Toolbar({
            style: "border-bottom: 0px",
            items: [this.actions.add, this.actions.edit, this.actions.del]
        })
    },
    configColumnModel: function() {
        return this.enableColumn = new SYNO.ux.EnableColumn({
            header: _T("common", "enabled"),
            dataIndex: "enable",
            width: 90,
            align: "center",
            sortable: !1,
            enableFastSelectAll: !0
        }), new Ext.grid.ColumnModel({
            columns: [this.enableColumn, {
                header: _T("connections", "service"),
                dataIndex: "name",
                width: 100,
                align: "left",
                renderer: this.renderService.createDelegate(this)
            }, {
                header: _T("log", "logattr"),
                dataIndex: "severity",
                width: 60,
                align: "left",
                renderer: this.renderSeverity
            }, {
                header: _T("log", "log_action"),
                dataIndex: "event",
                width: 200,
                align: "left",
                sortable: !1,
                renderer: this.renderEvent.createDelegate(this)
            }],
            defaults: {
                sortable: !0,
                menuDisabled: !1
            }
        })
    },
    initEvents: function() {
        var e = this;
        SYNO.SDS.ResourceMonitor.Top.Main.superclass.initEvents.apply(this, arguments), e.mon(e, "activate", e.onActivate, e), e.mon(e.appWin, "server_change", e.onServerChange, e)
    },
    onServerChange: function() {
        this.store.removeAll()
    },
    onActivate: function(e) {
        e && e.targetReady && this.mon(this.store, "load", this.clearStatusLoading, this, {
            single: !0
        }), this.needMask ? this.getEl().mask(_T("rsrcmonitor", "performance_event_enable_warning"), "syno-ux-mask-info") : this.getEl().unmask()
    },
    loadData: function() {
        arguments.length > 0 && void 0 !== arguments[0] && arguments[0] && this.clearStoreModifedAll(), this.store.removeAll(), this.store.load()
    },
    setStatusLoading: function() {
        this.appWin.setStatusLoading()
    },
    clearStatusLoading: function() {
        this.appWin.clearStatusLoading()
    },
    getAction: function(e) {
        return e in this.actions ? this.actions[e] : void SYNO.Debug("no this action: " + e)
    },
    parseServiceName: function(e, t) {
        var i, r = t.split(":");
        switch (e) {
            case 1:
                i = r.length > 1 ? _T(r[0], r[1]) : t;
                break;
            case 2:
                i = "iSCSI LUN - " + t;
                break;
            case 3:
                i = SYNO.SDS.Utils.StorageUtils.VolumeNameRenderer(t);
                break;
            case 4:
                i = "Internal Use";
                break;
            case 0:
                i = _T("rsrcmonitor", "cpu_system");
                break;
            default:
                i = t
        }
        return i
    },
    renderService: function(e, t, i) {
        var r = this.parseServiceName(i.get("type"), e);
        return '<div ext:qtip="' + r + '">' + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(r)) + "</div>"
    },
    renderSeverity: function(e) {
        var t = 0 === e ? _T("log", "warn_level") : _T("log", "crit_level");
        switch (e) {
            case 0:
                return '<div class="resource-monitor-level-warning" ext:qtip="' + t + '">' + t + "</div>";
            case 1:
                return '<div class="resource-monitor-level-critical" ext:qtip="' + t + '">' + t + "</div>";
            default:
                return t
        }
    },
    renderEvent: function(e, t, i) {
        var r, a = i.get("type"),
            o = i.get("resource"),
            n = SYNO.SDS.ResourceMonitor.EventRule.Events.getByType(a),
            s = n.Strings[o],
            c = n.Units[o],
            l = "";
        switch (a) {
            case 0:
                break;
            case 1:
                l = this.parseServiceName(a, i.get("name"));
                break;
            case 2:
                l = i.get("name");
                break;
            case 3:
                l = this.parseServiceName(a, i.get("name"))
        }
        return '<div ext:qtip="' + (r = String.format(s, l, i.get("threshold"), c)) + '">' + r + "</div>"
    },
    btnAdd: function() {
        new SYNO.SDS.ResourceMonitor.EventRule.EventDialog({
            owner: this.appWin,
            module: this.appWin,
            title: _T("rsrcmonitor", "add_performance_event_rule"),
            is_edit_mode: !1,
            grid: this,
            support_internal: this.support_internal
        }).open()
    },
    btnEdit: function() {
        var e = this.getSelectionModel(),
            t = e.getSelections();
        if (1 != t.length) return !1;
        new SYNO.SDS.ResourceMonitor.EventRule.EventDialog({
            owner: this.appWin,
            module: this.appWin,
            grid: this,
            title: _T("rsrcmonitor", "edit_performance_event_rule"),
            event_data: t[0].data,
            is_edit_mode: !0,
            support_internal: this.support_internal
        }).open()
    },
    btnDel: function() {
        var e = this.getSelectionModel(),
            t = e.getSelections(),
            i = t.map(function(e) {
                return e.id
            });
        this.appWin.getMsgBox().confirmDelete("", _T("app_port_alias", "confirm_delete_proxy"), function(e) {
            "yes" === e && (this.appWin.setStatusBusy(), this.sendWebAPI({
                api: "SYNO.ResourceMonitor.EventRule",
                method: "delete",
                version: 1,
                params: {
                    id_list: i
                },
                callback: function(e, t, i) {
                    if (this.appWin.clearStatusBusy(), !e) return void this.appWin.getMsgBox().alert("", _T("common", "commfail"), null, this);
                    this.loadData()
                },
                scope: this
            }))
        }, this)
    },
    getOnOffWebapiParams: function() {
        return this.getStore().getModifiedRecords().map(function(e) {
            return {
                id: e.id,
                enable: e.get("enable")
            }
        })
    },
    onSavePromise: function(e) {
        var t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
            i = this.getOnOffWebapiParams();
        if (0 === i.length) return void e.setStatusError({
            text: _T("error", "nochange_subject"),
            clear: !0
        });
        this.appWin.setStatusLoading();
        var r = function() {
                this.appWin.clearStatusLoading(), t && this.getStore() && this.loadData()
            }.bind(this),
            a = function() {
                return this.appWin.clearStatusLoading(), this.appWin.getMsgBox().alert("", _T("common", "commfail"), null, this), Promise.reject()
            }.bind(this);
        return this.sendWebAPIPromise({
            api: "SYNO.ResourceMonitor.EventRule",
            method: "onoff",
            version: 1,
            params: {
                id_list: i
            }
        }).then(r, a)
    },
    onReset: function() {
        this.clearStoreModifedAll(), this.store.reload()
    },
    selectionChange: function() {
        var e = this.getSelectionModel(),
            t = e.getSelections();
        this.getAction("del").setDisabled(0 === t.length), this.getAction("edit").setDisabled(1 !== t.length)
    },
    remainToggleRec: function() {
        var e = this,
            t = this.store.modified;
        this.clearStoreModifedAll(), t.forEach(function(t) {
            var i = e.store.getById(t.id);
            i && i.set("enable", t.get("enable"))
        })
    },
    clearStoreModifedAll: function() {
        this.store.modified = []
    },
    hasModifiedRecords: function() {
        return !Ext.isEmpty(this.store.getModifiedRecords())
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Perfalarm.Tab", {
    extend: "SYNO.SDS.Utils.TabPanel",
    constructor: function(e) {
        var t = {
            activeTab: 0,
            useDefaultBtn: !1,
            items: [new SYNO.SDS.ResourceMonitor.Log.Main({
                appWin: e.appWin,
                title: _T("rsrcmonitor", "logs"),
                tabParent: this
            })]
        };
        _S("is_admin") && t.items.push(new SYNO.SDS.ResourceMonitor.EventRule.Main({
            ref: "event_rule",
            appWin: e.appWin,
            title: _T("rsrcmonitor", "performance_event_rule")
        })), Ext.apply(t, e), this.callParent([t])
    },
    onPageConfirmLostChangeSave: function() {
        if (Ext.isDefined(this.event_rule) && this.event_rule.gridPanel) return this.event_rule.gridPanel.onSavePromise(this.event_rule)
    },
    onPageDeactivate: function() {
        return !this.checkFormDirty || (!Ext.isDefined(this.event_rule) || !this.event_rule.hasModifiedRecords()) && (!this.isAnyFormDirty() && void 0)
    },
    onPageActivate: function() {
        Ext.isDefined(this.event_rule) && this.event_rule.loadData()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.CurConn", {
    extend: "Ext.util.Observable",
    itemsPerPage: 50,
    lstLog: null,
    firstActivated: !0,
    appInst: null,
    grid: null,
    constructor: function(e) {
        this.topwin = e.appWin, this.appInst = e.appWin.appInstance, this.callParent(arguments), this.searchField = new SYNO.ux.TextFilter({
            width: 185,
            itemId: "search",
            queryParam: "filter",
            emptyText: _T("connections", "search_connections"),
            store: this.getCurConnStore(),
            pageSize: this.itemsPerPage,
            disabled: !0
        });
        var t = new Ext.Toolbar({
            defaultType: "syno_button"
        });
        t.add({
            text: _T("autoblock", "autoblock_export_ip_list"),
            itemId: "bt_save",
            handler: this.onLogSave,
            scope: this,
            disabled: !0
        }, {
            text: _T("connections", "kick_connection_br"),
            itemId: "bt_kick",
            disabled: !0,
            handler: this.kickConnection,
            hidden: !_S("is_admin"),
            scope: this
        }, {
            text: _T("connections", "disable_this_account"),
            itemId: "bt_disable_account",
            disabled: !0,
            handler: this.disableUser,
            hidden: !_S("is_admin"),
            scope: this
        }, "->", this.searchField), this.paging = new SYNO.ux.PagingToolbar({
            store: this.getCurConnStore(),
            displayInfo: !0,
            pageSize: this.itemsPerPage,
            refreshText: _T("log", "log_reload")
        });
        var i = new SYNO.ux.GridPanel({
            itemId: e.itemId,
            title: e.title,
            store: this.getCurConnStore(),
            colModel: this.getCurrConCM(),
            tbar: t,
            bbar: this.paging,
            sm: new Ext.grid.RowSelectionModel({
                listeners: {
                    selectionchange: {
                        fn: this.updateToolBarBts,
                        scope: this,
                        buffer: 80
                    }
                }
            }),
            autoExpandColumn: "descr",
            loadMask: !0,
            stripeRows: !0,
            listeners: {
                scope: this,
                activate: function(e) {
                    if (this.topwin.hasOpenConfig("is_cms_open") || e && e.targetReady) {
                        var t = this.topwin.getTargetData();
                        if (0 > t.id) return;
                        0 === t.id ? this.topwin.openConfig.cms_id = void 0 : this.topwin.openConfig.cms_id = t.id
                    }
                    this.grid.getTopToolbar().getComponent("bt_save").enable(), this.searchField.enable(), this.onLoad()
                }
            }
        });
        this.grid = i, this.monRightClickEvent()
    },
    monRightClickEvent: function() {
        _S("is_admin") && this.grid.mon(this.grid, "rowcontextmenu", this.showGridCtxMenu, this)
    },
    onLoad: function() {
        var e = this.grid.getStore();
        e.removeAll(), e.load({
            params: {
                start: 0,
                limit: this.itemsPerPage
            }
        })
    },
    onLogSave: function() {
        var e = this.grid.getStore();
        this.topwin.downloadWebAPI({
            webapi: {
                api: "SYNO.Core.CurrentConnection",
                method: "download",
                version: 1,
                params: {
                    sort_by: e.sortInfo.field,
                    sort_direction: e.sortInfo.direction,
                    filter: e.lastOptions.params.filter
                }
            }
        })
    },
    getPanel: function() {
        return this.grid
    },
    getCurConnStore: function() {
        if (this.dsCurCon) return this.dsCurCon;
        var e = new SYNO.API.Store({
            autoLoad: !1,
            api: "SYNO.Core.CurrentConnection",
            timeout: 18e5,
            method: "get",
            version: "1",
            appWindow: this.topwin,
            reader: new Ext.data.JsonReader({
                root: "items",
                totalProperty: "total"
            }, ["pid", "time", "who", "type", "descr", "from", "user_can_be_disabled", "can_be_kicked"]),
            sortInfo: {
                field: "time",
                direction: "DESC"
            },
            remoteSort: !0,
            listeners: {
                scope: this,
                beforeload: function(e, t) {
                    Ext.isDefined(t.params.offset) || (t.params.offset = t.params.start), Ext.isDefined(t.params.start) || (t.params.start = t.params.offset)
                },
                load: {
                    fn: function(e, t, i) {
                        this.grid.getView().updateScroller()
                    }
                }
            }
        });
        return this.dsCurCon = e, this.topwin.addManagedComponent(e), e
    },
    getCurrConCM: function() {
        if (this.cmCurrCon) return this.cmCurrCon;
        var e = new Ext.grid.ColumnModel({
            columns: [{
                header: _T("log", "log_time"),
                dataIndex: "time",
                width: 150,
                renderer: function(e) {
                    var t = Date.parseDate(e, "Y/n/j G:i:s");
                    return SYNO.SDS.DateTimeFormatter(t, {
                        type: "datetimesec"
                    })
                }
            }, {
                header: _T("log", "log_account"),
                dataIndex: "who",
                width: 100,
                renderer: this.whoRender
            }, {
                header: _T("log", "log_client"),
                dataIndex: "from",
                width: 200
            }, {
                header: _T("common", "connection_method"),
                dataIndex: "type",
                width: 150
            }, {
                id: "descr",
                header: _T("log", "log_resource"),
                dataIndex: "descr",
                width: 300,
                renderer: this.htmlEncodeRender
            }],
            defaults: {
                align: "left",
                sortable: !0,
                menuDisabled: !0
            }
        });
        return this.cmCurrCon = e, e
    },
    htmlEncodeRender: function(e, t) {
        var i = Ext.util.Format.htmlEncode(e);
        return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(i) + '"', i
    },
    whoRender: function(e, t) {
        return Ext.isEmpty(e) ? "-" : e
    },
    showGridCtxMenu: function(e, t, i) {
        i.preventDefault();
        var r = e.getSelectionModel();
        r.isSelected(t) || r.selectRow(t), this.getGridCtxMenu().showAt(i.getXY())
    },
    getGridCtxMenu: function() {
        return this.CurrConRowCtxMenu || (this.CurrConRowCtxMenu = new SYNO.ux.Menu({
            itemId: "adminCtxMenu",
            ignoreParentClicks: "true",
            items: [{
                itemId: "kick_conn",
                text: _T("connections", "kick_connection"),
                handler: this.kickConnection,
                scope: this
            }, {
                itemId: "disable_account",
                text: _T("connections", "disable_this_account"),
                handler: this.disableUser,
                scope: this
            }]
        }), this.topwin.addManagedComponent(this.CurrConRowCtxMenu)), this.CurrConRowCtxMenu
    },
    kickConnection: function() {
        var e = this.grid.getSelectionModel(),
            t = e.getSelections();
        if (0 !== t.length) {
            for (var i = [], r = [], a = !1, o = 0; o < t.length; ++o) "HTTP/HTTPS" === t[o].get("type") ? r.push({
                who: t[o].get("who"),
                from: t[o].get("from")
            }) : i.push({
                pid: t[o].get("pid"),
                type: t[o].get("type"),
                who: t[o].get("who"),
                from: t[o].get("from")
            }), _S("user") === t[o].get("who") && (a = !0);
            a ? this.topwin.getMsgBox().confirm(_T("connections", "connections_title"), _T("connections", "confirm_kick_self"), function(e, t) {
                "yes" === e && this.doKickConnection(i, r)
            }, this) : this.doKickConnection(i, r)
        }
    },
    doKickConnection: function(e, t) {
        this.grid.getEl().mask(_T("common", "msg_waiting"), "x-mask-loading"), this.topwin.sendWebAPI({
            api: "SYNO.Core.CurrentConnection",
            method: "kick_connection",
            timeout: 18e5,
            params: {
                service_conn: e,
                http_conn: t
            },
            version: 1,
            scope: this,
            callback: function(e, t) {
                this.grid.getEl().unmask(), e ? this.paging.doRefresh() : this.topwin.getMsgBox().alert("", SYNO.API.Erros.core[t.code] || _T("common", "commfail"))
            }
        })
    },
    disableUser: function() {
        var e = this.grid.getSelectionModel(),
            t = e.getSelections();
        if (0 !== t.length) {
            for (var i = [], r = 0; r < t.length; ++r) _S("user") !== t[r].get("who") && !1 !== t[r].get("user_can_be_disabled") && i.push(t[r].get("who"));
            0 !== i.length && (this.grid.getEl().mask(_T("common", "msg_waiting"), "x-mask-loading"), this.topwin.sendWebAPI({
                api: "SYNO.Core.CurrentConnection",
                method: "disable_user",
                timeout: 18e5,
                params: {
                    users: i
                },
                version: 1,
                scope: this,
                callback: function(e, t) {
                    this.grid.getEl().unmask(), e ? this.paging.doRefresh() : this.topwin.getMsgBox().alert("", SYNO.API.Erros.core[t.code] || _T("common", "commfail"))
                }
            }))
        }
    },
    updateToolBarBts: function(e) {
        var t = 0,
            i = e.getSelections(),
            r = this.grid.getTopToolbar(),
            a = r.getComponent("bt_kick"),
            o = this.getGridCtxMenu().get("kick_conn"),
            n = r.getComponent("bt_disable_account"),
            s = this.getGridCtxMenu().get("disable_account"),
            c = !0,
            l = !0;
        if (a.disable(), o.disable(), n.disable(), s.disable(), 0 !== i.length && !_S("demo_mode")) {
            for (t = 0; t < i.length; ++t)
                if (_S("user") === i[t].get("who") || !1 === i[t].get("user_can_be_disabled")) {
                    l = !1;
                    break
                } for (t = 0; t < i.length; ++t)
                if (!1 === i[t].get("can_be_kicked")) {
                    c = !1;
                    break
                } l && (n.enable(), s.enable()), c && (a.enable(), o.enable())
        }
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.FileHandle.KillConfirmDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t = Ext.apply({
            layout: "fit",
            height: 420,
            width: 680,
            showHelp: !1,
            items: [e.grid],
            buttons: [{
                btnStyle: "grey",
                text: _T("common", "cancel"),
                scope: this,
                handler: this.onCancel
            }, {
                btnStyle: "red",
                text: _T("connections", "kick_connection"),
                scope: this,
                handler: this.onKill
            }]
        }, e);
        this.callParent([t]), this.mon(this, "kill", this.onKill, this)
    },
    onKill: function() {
        this.caller.fireEvent("kill", this.pids), this.close()
    },
    onCancel: function() {
        this.close()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.FileHandle.KillConfirmGrid", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(e) {
        if (this.caller = e.caller, this.message = e.message, this.pids = e.pids, 0 === this.pids.length) return void SYNO.Debug("empty pids");
        this.store = new SYNO.API.Store({
            api: "SYNO.Core.FileHandle",
            method: "get",
            version: "1",
            timeout: 6e4,
            autoLoad: !0,
            baseParams: {
                pids: this.pids,
                deleteConfirm: !0
            },
            reader: new Ext.data.JsonReader({
                root: "OpenedFiles",
                totalProperty: "total"
            }, ["filename", "service", "pid", "user", "host", "time"]),
            listeners: {
                scope: this,
                load: function(e, t, i) {
                    this.caller.fireEvent("dataready", this.pids)
                },
                exception: function(e, t, i, r, a, o) {
                    this.caller.errorLoadingMsg(), this.caller.getEl().unmask()
                }
            }
        });
        var t = Ext.apply({
            header: !1,
            border: !1,
            loadMask: !0,
            tbar: this.createToolBar(),
            ds: this.store,
            cm: this.createColumnModel(),
            selModel: this.createSelectionModel(),
            enableColumnHide: !1,
            enableColumnMove: !1,
            enableColumnResize: !0
        }, e);
        this.callParent([t]), this.selModel.lock()
    },
    createSelectionModel: function() {
        return new SYNO.SDS.RowSelectionModel({
            singleSelect: !0
        })
    },
    createToolBar: function() {
        return new SYNO.ux.Toolbar({
            items: [{
                xtype: "syno_displayfield",
                htmlEncode: !1,
                style: "white-space: normal;",
                value: this.message
            }]
        })
    },
    createColumnModel: function() {
        var e = {
                id: "time",
                header: _T("connections", "last_access_time"),
                dataIndex: "time",
                width: 150,
                align: "left",
                renderer: function(e) {
                    var t = Date.parseDate(e, "Y/n/j G:i:s");
                    return SYNO.SDS.DateTimeFormatter(t, {
                        type: "datetimesec"
                    })
                }
            },
            t = {
                header: _T("common", "common_filename"),
                dataIndex: "filename",
                width: 110,
                align: "left",
                renderer: this.tipRenderer
            },
            i = {
                header: _T("rsrcmonitor", "service_name"),
                dataIndex: "service",
                width: 120,
                align: "left"
            },
            r = {
                header: _T("log", "log_account"),
                dataIndex: "user",
                width: 100,
                align: "left"
            },
            a = {
                header: _T("common", "ip_addr"),
                dataIndex: "host",
                width: 120,
                align: "left"
            };
        return new Ext.grid.ColumnModel({
            columns: [t, r, a, i, e],
            defaults: {
                sortable: !1,
                menuDisabled: !0
            }
        })
    },
    tipRenderer: function(e, t) {
        var i = Ext.util.Format.htmlEncode(e);
        return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(i) + '"', i
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.FileHandle.CannotKillDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t = Ext.apply({
            cls: "syno-admin-center-confirm-dialog x-window-dlg",
            header: !1,
            elements: "body",
            draggable: !1,
            resizable: !1,
            width: 480,
            height: 180,
            popupStyle: "emphasized",
            items: [{
                xtype: "syno_displayfield",
                cls: "dialog-title",
                value: e.title
            }, {
                xtype: "syno_displayfield",
                cls: "dialog-msg",
                value: e.message
            }],
            fbar: ["->", {
                xtype: "syno_button",
                btnStyle: "blue",
                text: _T("common", "ok"),
                scope: this,
                handler: this.onOk
            }]
        }, e);
        this.callParent([t])
    },
    onOk: function() {
        this.close()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.FileHandle.Main", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(e) {
        this.owner = e.owner, this.itemsPerPage = 50;
        var t = Ext.apply({
            store: this.getStore(),
            colModel: this.createColumnModel(),
            selModel: this.createSelectionModel(),
            tbar: this.createToolBar(),
            bbar: this.createBBar(),
            fbar: this.createFBar(),
            footerCfg: {
                style: "padding: 0px;"
            },
            stripeRows: !0,
            loadMask: !0
        }, e);
        this.callParent([t]), this.addEvents("kill"), this.mon(this, "kill", this.kickProcess, this), this.mon(this, "activate", this.onLoad, this), this.mon(this, "deactivate", this.onDeactivate, this), this.addEvents("dataready"), this.mon(this, "dataready", this.openKickConfirmDialog, this)
    },
    getStore: function() {
        if (this.store) return this.store;
        var e = new SYNO.API.Store({
            api: "SYNO.Core.FileHandle",
            method: "get",
            version: "1",
            timeout: 6e4,
            autoLoad: !1,
            remoteSort: !0,
            sortInfo: {
                field: "service",
                direction: "ASC"
            },
            baseParams: {
                limit: this.itemsPerPage,
                offset: 0,
                forceReload: this.forceReload
            },
            reader: new Ext.data.JsonReader({
                root: "OpenedFiles",
                totalProperty: "total"
            }, ["path", "filename", "service", "pid", "user", "host"]),
            listeners: {
                scope: this,
                beforeload: function(e, t) {
                    this.getStore().baseParams.forceReload = this.forceReload, this.kickable_list || this.getKickableList()
                },
                load: function(e, t, i) {
                    !0 === this.forceReload && (this.forceReload = !1)
                },
                exception: function(e, t, i, r, a, o) {
                    this.errorLoadingMsg()
                }
            }
        });
        return this.store = e, e
    },
    onLoad: function() {
        this.forceReload = !0;
        var e = this.getStore();
        e.removeAll();
        var t = {
            offset: 0,
            limit: this.itemsPerPage
        };
        e.load({
            params: t
        })
    },
    onDeactivate: function(e) {
        this.sendWebAPI({
            api: "SYNO.Core.FileHandle",
            method: "delete_db",
            version: 1
        })
    },
    onExport: function() {
        var e = {
            api: "SYNO.Core.FileHandle",
            method: "export",
            version: 1,
            params: {
                filter: this.searchField.getValue(),
                sort_by: this.store.sortInfo.field,
                sort_direction: this.store.sortInfo.direction
            }
        };
        this.owner.downloadWebAPI({
            webapi: e
        })
    },
    onRefresh: function() {
        this.searchField.onTriggerClick(), this.onLoad()
    },
    onSelectionChange: function() {
        0 === this.getSelectionModel().getSelections().length ? this.btnKill.disable() : this.btnKill.enable()
    },
    createToolBar: function() {
        return this.actionExport = new Ext.Action({
            text: _T("autoblock", "autoblock_export_ip_list"),
            itemId: "btn_export",
            handler: this.onExport,
            scope: this
        }), this.actionKill = new Ext.Action({
            text: _T("connections", "kick_connection"),
            itemId: "btn_kill",
            handler: this.onKick,
            disabled: !0,
            hidden: !_S("is_admin"),
            scope: this
        }), this.btnExport = new SYNO.ux.Button(this.actionExport), this.btnKill = new SYNO.ux.Button(this.actionKill), this.searchField = new SYNO.ux.TextFilter({
            itemId: "search",
            queryParam: "filter",
            store: this.getStore(),
            pageSize: this.itemsPerPage,
            emptyText: _T("common", "filter_label_text")
        }), new SYNO.ux.Toolbar({
            items: [this.btnExport, this.btnKill, "->", this.searchField]
        })
    },
    createBBar: function() {
        var e = new SYNO.ux.PagingToolbar({
            store: this.getStore(),
            displayInfo: !0,
            pageSize: this.itemsPerPage,
            refreshText: _T("log", "log_reload"),
            page: this,
            doRefresh: function() {
                this.page.onRefresh()
            }
        });
        return this.paging = e, e
    },
    createFBar: function() {
        return {
            xtype: "syno_toolbar",
            layout: "fit",
            style: "padding-top: 6px;",
            items: [{
                xtype: "syno_displayfield",
                htmlEncode: !1,
                style: "white-space: normal;",
                value: '<span class="syno-ux-note">' + _T("common", "note") + _T("common", "colon") + " </span>" + _T("connections", "file_handle_cannot_kick_msg")
            }]
        }
    },
    createSelectionModel: function() {
        return new Ext.grid.RowSelectionModel({
            singleSelect: !0,
            listeners: {
                selectionchange: {
                    fn: this.onSelectionChange,
                    scope: this
                }
            }
        })
    },
    createColumnModel: function() {
        var e = {
                id: "path",
                header: _T("common", "location"),
                dataIndex: "path",
                width: 210,
                align: "left",
                renderer: this.tipRenderer
            },
            t = {
                header: _T("common", "common_filename"),
                dataIndex: "filename",
                width: 110,
                align: "left",
                renderer: this.tipRenderer
            },
            i = {
                header: _T("rsrcmonitor", "service_name"),
                dataIndex: "service",
                width: 150,
                align: "left"
            },
            r = {
                header: _T("log", "log_account"),
                dataIndex: "user",
                width: 110,
                align: "left"
            },
            a = {
                header: _T("common", "ip_addr"),
                dataIndex: "host",
                width: 150,
                align: "left"
            };
        return new Ext.grid.ColumnModel({
            columns: [t, r, a, i, e],
            defaults: {
                sortable: !0,
                menuDisabled: !0
            }
        })
    },
    tipRenderer: function(e, t) {
        var i = Ext.util.Format.htmlEncode(e);
        return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(i) + '"', i
    },
    getKickableList: function() {
        this.owner.sendWebAPI({
            api: "SYNO.Core.FileHandle",
            method: "kickable_list",
            version: 1,
            scope: this,
            callback: function(e, t) {
                e ? this.kickable_list = t.kickable : this.errorLoadingMsg()
            }.bind(this)
        })
    },
    onKick: function() {
        var e = this.getSelectionModel().getSelections();
        if (0 === e.length) return void SYNO.Debug("No selected item found");
        this.getEl().mask(_T("common", "msg_waiting"), "x-mask-loading");
        var t = [e[0].get("pid")],
            i = e[0].get("service"),
            r = _S("user") === e[0].get("user"),
            a = "",
            o = "",
            n = -1 !== this.kickable_list.indexOf(i);
        if (a = r ? _T("connections", "file_handle_kick_self_msg") : _T("connections", "file_handle_kick_msg"), n) this.kickCfrmGrid = new SYNO.SDS.ResourceMonitor.FileHandle.KillConfirmGrid({
            owner: this.owner,
            itemId: "kickconfirm",
            pids: t,
            caller: this,
            message: a
        });
        else {
            o = _T("connections", "file_handle_cannot_kick_title"), a = _T("connections", "file_handle_cannot_kick_msg");
            new SYNO.SDS.ResourceMonitor.FileHandle.CannotKillDialog({
                owner: this.owner,
                message: a,
                title: o
            }).open(), this.getEl().unmask()
        }
    },
    openKickConfirmDialog: function(e) {
        var t = _T("connections", "kick_connection");
        new SYNO.SDS.ResourceMonitor.FileHandle.KillConfirmDialog({
            owner: this.owner,
            caller: this,
            pids: e,
            title: t,
            grid: this.kickCfrmGrid
        }).open(), this.getEl().unmask()
    },
    kickProcess: function(e) {
        this.getEl().mask(_T("common", "msg_waiting"), "x-mask-loading"), this.owner.sendWebAPI({
            api: "SYNO.Core.FileHandle",
            method: "kick",
            timeout: 6e4,
            params: {
                pids: e
            },
            version: 1,
            scope: this,
            callback: function(e, t) {
                this.getEl().unmask(), e ? this.onRefresh() : this.errorLoadingMsg()
            }
        })
    },
    errorLoadingMsg: function() {
        this.owner.getMsgBox().alert("title", _T("common", "error_system"))
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.ConnectionTab", {
    extend: "SYNO.SDS.Utils.TabPanel",
    constructor: function(e) {
        this.owner = e.owner;
        var t = Ext.apply({
            items: [new SYNO.SDS.ResourceMonitor.CurConn({
                itemId: "connected_users",
                appWin: e.appWin,
                title: _T("connections", "connections_title"),
                owner: this.owner
            }).getPanel(), new SYNO.SDS.ResourceMonitor.FileHandle.Main({
                itemId: "accessed_files",
                appWin: e.appWin,
                title: _T("connections", "accessed_files"),
                owner: this.owner
            })]
        }, e);
        this.callParent([t])
    }
}), 
/**
 * @class SYNO.SDS.ResourceMonitor.Instance
 * @extends SYNO.SDS.AppInstance
 * ResourceMonitor application instance class
 *
 */
Ext.define("SYNO.SDS.ResourceMonitor.Instance", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.ResourceMonitor.App"
}), Ext.define("SYNO.SDS.ResourceMonitor.App", {
    extend: "SYNO.SDS.PageListAppWindow",
    performancePage: "SYNO.SDS.ResourceMonitor.Performance.Main",
    activePage: "SYNO.SDS.ResourceMonitor.Performance.Main",
    pageTopFn: "SYNO.SDS.ResourceMonitor.Top.Main",
    pageServiceTreeFn: "SYNO.SDS.ResourceMonitor.TaskTab",
    constructor: function(e) {
        this.appInstance = e.appInstance, this.addEvents("afterlaunchpage"), this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = "yes" === _D("support_nvidia_gpu") ? 1200 : 1024,
            i = {
                cls: "resource-monitor-app-window",
                itemId: "mainWin",
                minWidth: t,
                minHeight: 574,
                width: t,
                height: 574,
                defaultMaximized: !0
            };
        return Ext.apply(i, e), i
    },
    getPageList: function(e) {
        var t;
        if (!this.pageList) {
            t = {
                region: "west",
                width: 240,
                listeners: {
                    scope: this,
                    single: !0,
                    load: {
                        fn: this.onLoad,
                        buffer: 50
                    }
                },
                onBeforeSelect: function(e, t, i) {
                    if (this.getSelectionModel().getSelectedNode()) {
                        var r = this.getSelectionModel().getSelectedNode().id,
                            a = r ? this.ownerCt.pageCt.items.map[r] : null;
                        if (!!a && a.el.isMasked()) return !1
                    }
                    return !!t.leaf
                }
            };
            var i = {
                listItems: [{
                    text: _T("rsrcmonitor", "performance"),
                    iconCls: "cate_icn_monitor",
                    help: "ResourceMonitor/rsrcmonitor_performance.html",
                    fn: "SYNO.SDS.ResourceMonitor.Performance.Main"
                }, {
                    text: _T("rsrcmonitor", "process"),
                    iconCls: "cate_icn_task_manager",
                    help: "ResourceMonitor/rsrcmonitor_processes.html",
                    fn: "SYNO.SDS.ResourceMonitor.Top.Main",
                    hidden: !!SYNO.API.GetKnownAPI("SYNO.Core.System.ProcessGroup")
                }, {
                    text: _T("rsrcmonitor", "taskmanager"),
                    iconCls: "cate_icn_task_manager",
                    help: "ResourceMonitor/rsrcmonitor_task_manager.html",
                    fn: "SYNO.SDS.ResourceMonitor.TaskTab",
                    hidden: !SYNO.API.GetKnownAPI("SYNO.Core.System.ProcessGroup"),
                    appWindow: this.findAppWindow()
                }, {
                    text: _T("connections", "title"),
                    iconCls: "cate_icn_connect",
                    help: "ResourceMonitor/rsrcmonitor_connection.html",
                    owner: this,
                    fn: "SYNO.SDS.ResourceMonitor.ConnectionTab"
                }, {
                    text: _T("rsrcmonitor", "speed_limit"),
                    iconCls: "cate_icn_speed",
                    help: "ResourceMonitor/rsrcmonitor_speed_limit.html",
                    fn: "SYNO.SDS.BandwidthControl.Status"
                }]
            };
            "yes" === this.findAppWindow()._D("support_performance_event") && i.listItems.push({
                text: _T("rsrcmonitor", "performance_event"),
                iconCls: "cate_icn_report",
                help: "ResourceMonitor/rsrcmonitor_performance_alarm.html",
                fn: "SYNO.SDS.ResourceMonitor.Perfalarm.Tab"
            }), i.listItems.push({
                text: _T("common", "common_settings"),
                iconCls: "cate_icn_setting",
                help: "ResourceMonitor/rsrcmonitor_settings.html",
                hidden: !_S("is_admin"),
                fn: "SYNO.SDS.ResourceMonitor.Setting.Main"
            }), Ext.apply(t, i), this.pageList = new SYNO.ux.ModuleList(t)
        }
        return this.pageList
    },
    onOpen: function(e) {
        this.callParent(arguments), this.checkModuleVisible()
    },
    onLoad: function(e) {
        this.callParent(arguments)
    },
    setStatusLoading: function(e) {
        !0 !== this.isStatusLoading && (e = e || {}, Ext.applyIf(e, {
            text: _T("common", "loading"),
            iconCls: "x-mask-loading"
        }), this.isStatusLoading = !0, this.getEl().mask(e.text, e.iconCls))
    },
    clearStatusLoading: function() {
        !0 === this.isStatusLoading && (this.getEl().unmask(), this.isStatusLoading = !1)
    },
    showAlert: function(e, t, i) {
        if ((e = e || _T("common", "commfail")) === _T("error", "volume_no_volumes") || e === _T("error", "db_connect_fail") && "yes" === this.findAppWindow()._D("usbstation")) {
            var r = new SYNO.SDS.MessageBoxV5({
                    owner: this
                }),
                a = r.fbButtons.ok;
            "yes" === this.findAppWindow()._D("usbstation") ? (e = _T("system", "require_pgsql"), e += (e ? "<br>" : "") + String.format(_T("pkgmgr", "prompt_enable_serviece"), _T("controlpanel", "metadata_title")), this.mon(a, "click", function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                    fn: "SYNO.SDS.AdminCenter.SystemDatabase.Main"
                })
            }, this)) : this.mon(a, "click", function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance")
            }, this), r.confirm(_T("tree", "leaf_rsrcmonitor"), e, null, this, Ext.MessageBox.OKCANCEL)
        } else this.getMsgBox().alert(_T("tree", "leaf_rsrcmonitor"), e, t, i)
    },
    checkModuleVisible: function() {
        var e = this.pageList,
            t = this.getActivePage().itemId;
        e.setModuleVisible(this.pageTopFn, !this.IsKnownAPI("SYNO.Core.System.ProcessGroup")), e.setModuleVisible(this.pageServiceTreeFn, this.IsKnownAPI("SYNO.Core.System.ProcessGroup")), this.pageTopFn !== t && this.pageServiceTreeFn !== t || this.selectPage(this.IsKnownAPI("SYNO.Core.System.ProcessGroup") ? this.pageServiceTreeFn : this.pageTopFn)
    },
    launchPage: function(e) {
        var t = this.pageCt,
            i = t.getComponent(e);
        return i || (i = this.createPage(e), t.add(i)), !!i && (t.layout.setActiveItem(e), this.activePage = i, i instanceof Ext.TabPanel && Ext.isFunction(i.setActiveTab) && i.setActiveTab(0), i.onPageActivate && i.onPageActivate(this.openParams), this.fireEvent("afterlaunchpage"), !0)
    },
    reloadPerformance: function() {
        this.pageCt.getComponent(this.performancePage) && this.pageCt.getComponent(this.performancePage).destroy()
    }
});
