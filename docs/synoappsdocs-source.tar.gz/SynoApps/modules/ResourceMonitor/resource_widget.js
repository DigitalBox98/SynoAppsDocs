/* Copyright (c) 2020 Synology Inc. All rights reserved. */

var _this3 = this;
Ext.ns("SYNO.SDS.ResourceMonitor.Performance.Chart"), 
/**
 * @class SYNO.SDS.ResourceMonitor.Performance.Detail.Header
 * @extends Ext.Container
 * ResourceMonitor performance detail class
 *
 */
Ext.define("SYNO.SDS.ResourceMonitor.Performance.Detail.Header", {
    extend: "Ext.Container",
    constructor: function(t) {
        var e = this,
            i = Ext.apply({
                layout: {
                    type: "hbox",
                    pack: "end"
                },
                height: 32,
                topLayer: t.topLayer,
                items: [],
                listeners: {
                    activate: this.onActivate,
                    scope: this
                }
            }, t.config);
        Ext.isEmpty(t.lun_field_button) || i.items.push(t.lun_field_button.button), Ext.isEmpty(t.device_view_all) || i.items.push(t.device_view_all), Ext.isEmpty(t.type_combo) || (e.type_label = e.createCustomLabel(_T("rsrcmonitor", "chart"), !1), e.type_combo = e.createTypeCombo(t.type_combo.data), i.items.push(e.type_label), i.items.push(e.type_combo)), Ext.isEmpty(t.lun_combo) || (i.items.push(t.lun_combo.label), i.items.push(t.lun_combo.combo)), e.history_label = e.createCustomLabel(_T("rsrcmonitor", "time_range"), !0), e.history_combo = e.createHistoryCombo(), i.items.push(e.history_label), i.items.push(e.history_combo), this.callParent([i])
    },
    createHistoryCombo: function() {
        return new SYNO.ux.ComboBox({
            xtype: "syno_combobox",
            itemId: "history_combo",
            width: 170,
            margins: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 8
            },
            triggerAction: "all",
            editable: !1,
            valueField: "history",
            displayField: "displayText",
            value: "current",
            mode: "local",
            autoScroll: !1,
            hidden: !0,
            store: new Ext.data.ArrayStore({
                fields: ["history", "displayText"],
                data: [
                    ["current", _T("rsrcmonitor", "realtime")],
                    ["week", _T("rsrcmonitor", "last_7_days")],
                    ["month", _T("rsrcmonitor", "last_30_days")],
                    ["half_year", _T("rsrcmonitor", "last_6_months")],
                    ["year", _T("rsrcmonitor", "last_12_months")]
                ]
            }),
            listeners: {
                select: {
                    scope: this,
                    fn: this.headerChange
                }
            }
        })
    },
    createTypeCombo: function(t) {
        return new SYNO.ux.ComboBox({
            itemId: "type_combo",
            width: 200,
            margins: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 8
            },
            triggerAction: "all",
            editable: !1,
            mode: "local",
            autoScroll: !1,
            valueField: "type",
            displayField: "displayText",
            value: t[0][0],
            store: new Ext.data.ArrayStore({
                fields: ["type", "displayText"],
                data: t
            }),
            listeners: {
                select: {
                    scope: this,
                    fn: this.headerChange
                }
            }
        })
    },
    createCustomLabel: function(t, e) {
        return new SYNO.ux.DisplayField({
            margins: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 20
            },
            style: "text-align: right;",
            width: "auto",
            value: t + ":",
            hidden: e
        })
    },
    headerChange: function() {
        var t = this.getContentConfig();
        this.topLayer.setTimeRange(t.history), this.fireEvent("contentSelect", t)
    },
    reloadContent: function(t) {
        this.history_combo && this.history_combo.setValue(t.history), this.type_combo && this.type_combo.setValue(t.type), this.fireEvent("contentSelect", t)
    },
    getContentConfig: function() {
        var t = {};
        return this.history_combo ? t.history = this.history_combo.value : t.history = "current", this.type_combo && (t.type = this.type_combo.value), this.lun_combo && (t.lun = this.lun_combo.value), t
    },
    setToRealTime: function() {
        var t = this;
        t.history_combo && (t.history_combo.setValue("current"), t.headerChange())
    },
    onActivate: function() {
        var t = this.getContentConfig();
        this.history_combo.hidden || t.history !== this.topLayer.time_range && (t.history = this.topLayer.time_range, this.reloadContent(t))
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Chart.Current", {
    extend: "Ext.Panel",
    totalTime: 180,
    constructor: function(t) {
        var e = this,
            i = {
                store: t.lines ? t.lines.map(function(i, a) {
                    return new SYNO.SDS.ResourceMonitor.Performance.DataSet({
                        totalTime: t.totalTime ? t.totalTime : e.totalTime,
                        itemId: i.itemId || "store" + a,
                        color: i.color,
                        lineStyle: i.lineStyle,
                        areaStyle: i.areaStyle,
                        lineName: i.lineName
                    })
                }, this) : [],
                border: !1,
                topLayer: t.topLayer,
                dataType: "normal"
            };
        Ext.apply(i, t), this.callParent([i])
    },
    initEvents: function() {
        var t = this;
        SYNO.SDS.ResourceMonitor.Performance.Chart.Current.superclass.initEvents.call(this, arguments), t.mon(t, "resize", function() {
            t.echarts && t.echarts.resize()
        }, t), t.mon(t.topLayer.appWin, "server_change", t.clearStoreData, t)
    },
    drawChart: function() {
        var t, e = this,
            i = [],
            a = 0;
        if (!(e.isDestroyed || !e.body || e.body.getSize(!0).width <= 1 || e.body.getSize(!0).height <= 1)) {
            for (a = 0; a < e.store.length; ++a) i.push(e.store[a].genSeries());
            t = e.getChartType(), t.series = i, e.primitiveLegend && (t.legend = SYNO.SDS.ResourceMonitor.Performance.Chart.Util.legendConfig, t.legend.data = [_T("rsrcmonitor", "rsrcmonitor_trans"), _T("rsrcmonitor", "rsrcmonitor_recv")]), e.canvasHeight && (t.height = e.canvasHeight), e.echarts || (e.echarts = echarts.init(e.body.dom)), e.echarts.setOption(t)
        }
    },
    updateStores: function(t) {
        var e = this,
            i = !1;
        Ext.each(e.store, function(e) {
            if (i = t.every(function(t, i, a) {
                    return e.itemId !== t.itemId
                })) return !1
        }), (i || t.length !== e.store.length) && (e.store = t.map(function(t) {
            return new SYNO.SDS.ResourceMonitor.Performance.DataSet({
                totalTime: e.totalTime,
                lineStyle: t.lineStyle,
                areaStyle: t.areaStyle,
                color: t.color,
                itemId: t.itemId,
                lineName: t.lineName
            })
        }))
    },
    pushValueById: function(t, e) {
        var i = this,
            a = 0;
        Ext.each(t, function(t, r, o) {
            for (a = 0; a < i.store.length; ++a)
                if (i.store[a].itemId === t.itemId) return void i.store[a].pushData(t.value, e)
        })
    },
    pushValue: function(t, e) {
        var i = this,
            a = 0,
            r = 0;
        for (a = i.store.length - 1; a >= 0; --a) i.store[a].pushData(t[a] + r, e), i.aggregate && (r += t[a])
    },
    clearStoreData: function() {
        var t = this,
            e = 0;
        for (e = t.store.length - 1; e >= 0; --e) t.store[e].clear()
    },
    getChartType: function() {
        var t = this,
            e = echarts.syno.getDefaultOptions(),
            i = 0,
            a = SYNO.SDS.ResourceMonitor.Performance.Chart.Util,
            r = a.chartConfig,
            o = a.tooltipConfig;
        switch (r.apply(e), o.apply(e.tooltip), e.tooltip.formatter = t.trackFormatter.createDelegate(t), e.xAxis.max = t.store[0] ? t.store[0].getLastTime() : 0, e.xAxis.min = Ext.max([e.xAxis.max - t.totalTime, 0]), e.xAxis.axisLabel.show = !1, e.grid.top = 20, e.grid.right = 5, e.grid.left = 42, e.grid.bottom = 20, t.dataType) {
            case "percent":
                i = 100;
                break;
            case "byte":
            case "bytes":
                i = t.getMaxDataValue(), i = !Ext.isNumber(i) || i < 102400 ? 102400 : Math.ceil(1.1 * i);
                break;
            case "timeus":
                i = t.getMaxDataValue(), i = !Ext.isNumber(i) || i < 10 ? 10 : Math.ceil(1.1 * i);
                break;
            case "normal":
            case "iops":
                i = t.getMaxDataValue(), i = !Ext.isNumber(i) || i < 10 ? 10 : Math.ceil(1.1 * i);
                break;
            default:
                return
        }
        return e.yAxis.min = 0, e.yAxis.max = i, e.yAxis.splitNumber = 5, e.yAxis.axisLabel.color = a.labelConfig.color, t.chartTitle && (e.yAxis.name = t.chartTitle, e.yAxis.nameTextStyle.color = a.labelConfig.color, e.yAxis.nameTextStyle.fontFamily = r.textStyle.fontFamily, e.yAxis.nameTextStyle.fontSize = r.textStyle.fontSize, e.yAxis.nameTextStyle.fontWeight = r.textStyle.fontWeight), echarts.syno.customizeAxis(e.yAxis, t.dataType), e
    },
    getMaxDataValue: function() {
        var t = this,
            e = 0,
            i = 0;
        for (i = 0; i < t.store.length; ++i) e < t.store[i].getMaxDataValue() && (e = t.store[i].getMaxDataValue());
        return e
    },
    trackFormatter: function(t) {
        var e, i, a, r = this,
            o = [],
            n = 0,
            s = 0,
            l = [],
            c = function(e) {
                return e.itemId === t[s].seriesId
            };
        for (e = new Date(1e3 * t[0].data[0]), e = SYNO.SDS.DateTimeFormatter(e, {
                type: "datetimesec"
            }), s = t.length - 1; s >= 0; --s) o[s] = t[s].data[1] - n, r.aggregate && (n += o[s]);
        for (s = 0; s < t.length; ++s) {
            var h = r.topLayer.numberUnit(o[s], r.dataType);
            i = h.num + " " + h.unit, r.lines && (a = r.lines.find(c)), l.push({
                name: t[s].seriesName,
                value: i,
                color: t[s].color,
                fontColor: r.lines && r.lines[s] && r.lines[s].fontColor ? r.lines[s].fontColor : t[s].color,
                order: r.lines ? a.trackOrder : 0
            })
        }
        return l = l.sort(function(t, e) {
            return t.order > e.order ? 1 : -1
        }), SYNO.SDS.ResourceMonitor.Performance.Chart.Util.getStyledInfoList(e, l)
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.Performance.Chart.History", {
    extend: "Ext.Panel",
    aggregate: !1,
    lines: [],
    timeAxis: "week",
    dataType: "percent",
    dataBase: 1,
    data: {},
    dataSize: 0,
    constructor: function(t) {
        var e = {
            topLayer: t.topLayer,
            border: !1
        };
        Ext.apply(e, t), this.callParent([e])
    },
    initEvents: function() {
        this.callParent(arguments), this.mon(this, "resize", function() {
            this.echarts && this.echarts.resize()
        }, this)
    },
    setChartConfig: function(t) {
        this.maxValue = 0, Ext.isDefined(t.aggregate) && (this.aggregate = t.aggregate), Ext.isDefined(t.lines) && (this.lines = t.lines), Ext.isDefined(t.timeAxis) && (this.timeAxis = t.timeAxis), Ext.isDefined(t.dataType) && (this.dataType = t.dataType), Ext.isDefined(t.dataBase) && (this.dataBase = t.dataBase), Ext.isDefined(t.data) && (this.data = t.data), Ext.isDefined(t.dataSize) && (this.dataSize = t.dataSize), Ext.isDefined(t.endTime) && (this.endTime = t.endTime), Ext.isDefined(t.timeInterval) && (this.timeInterval = t.timeInterval), Ext.isDefined(t.chartTitle) ? this.chartTitle = t.chartTitle : this.chartTitle = null
    },
    drawChart: function() {
        if (!(this.isDestroyed || !this.body || this.body.getSize(!0).width <= 1 || this.body.getSize(!0).height <= 1)) {
            this.echarts || (this.echarts = echarts.init(this.body.dom));
            var t = this.genSeries(),
                e = this.getChartType(t);
            this.primitiveLegend && (e.legend = SYNO.SDS.ResourceMonitor.Performance.Chart.Util.legendConfig, e.legend.data = [_T("rsrcmonitor", "rsrcmonitor_trans"), _T("rsrcmonitor", "rsrcmonitor_recv")]), this.canvasHeight && (e.height = this.canvasHeight), this.setHeight && (e.height = this.setHeight), this.setInterval && this.maxValue >= this.setInterval && ("Utilization" === this.chartName && (this.maxValue = Math.max(this.maxValue, 100)), "TransferRate" === this.chartName && (this.maxValue = Math.max(this.maxValue, 102400)), e.yAxis.interval = Math.ceil(this.maxValue / this.setInterval)), e.dataZoom = this.getDataZoom(), this.echarts.setOption(e, !0)
        }
    },
    genSeries: function() {
        var t = this,
            e = [],
            i = "bytes" === this.dataType ? this.dataBase : 1,
            a = this.aggregate ? this.aggregateData() : this.data;
        return this.lines.forEach(function(r) {
            var o = r.itemId,
                n = [],
                s = t.endTime;
            Ext.isDefined(a[o]) && (a[o].reverse().forEach(function(e) {
                n.push([1e3 * s, e * i]), s -= t.timeInterval, e * i > t.maxValue && (t.maxValue = e * i)
            }), e.push({
                type: "line",
                data: n.reverse(),
                lines: r.lineType,
                color: r.color,
                name: r.lineName,
                showSymbol: !1,
                symbol: "circle",
                symbolSize: 0,
                lineStyle: r.lineStyle,
                areaStyle: r.areaStyle,
                id: r.itemId
            }))
        }), e
    },
    aggregateData: function() {
        for (var t = 0, e = this.lines.length, i = SYNO.Util.copy(this.data), a = 0; a < this.dataSize; ++a) {
            t = 0;
            for (var r = e - 1; r >= 0; --r) t += i[this.lines[r].itemId][a], i[this.lines[r].itemId][a] = t
        }
        return i
    },
    getChartType: function(t) {
        var e = echarts.syno.getDefaultOptions(),
            i = SYNO.SDS.ResourceMonitor.Performance.Chart.Util.chartConfig;
        return e.grid.top = 20, e.grid.right = 5, e.grid.left = 42, e.grid.bottom = 74, e.textStyle = i.textStyle, e.yAxis.nameTextStyle.fontFamily = i.textStyle.fontFamily, e.yAxis.nameTextStyle.fontSize = i.textStyle.fontSize, e.series = t, this.setTooltipConfig(e), this.setYaxisConfig(e), this.setXaxisConfig(e), e
    },
    setYaxisConfig: function(t) {
        var e = SYNO.SDS.ResourceMonitor.Performance.Chart.Util.labelConfig,
            i = SYNO.SDS.ResourceMonitor.Performance.Chart.Util.chartConfig,
            a = this.maxValue;
        switch (this.dataType) {
            case "percent":
                t.yAxis.min = 0, t.yAxis.max = 100;
                break;
            case "byte":
            case "bytes":
                a = !Ext.isNumber(a) || a < 102400 ? 102400 : Math.ceil(1.1 * a), t.yAxis.min = 0, t.yAxis.max = a;
                break;
            case "timeus":
                a = !Ext.isNumber(a) || a < 10 ? 10 : Math.ceil(1.1 * a), t.yAxis.min = 0, t.yAxis.max = a;
                break;
            case "normal":
            case "iops":
                a = !Ext.isNumber(a) || a < 10 ? 10 : Math.ceil(1.1 * a), t.yAxis.min = 0, t.yAxis.max = a;
                break;
            default:
                return
        }
        this.chartTitle && (t.yAxis.name = this.chartTitle, t.yAxis.nameTextStyle.color = e.color, t.yAxis.nameTextStyle.fontFamily = i.textStyle.fontFamily, t.yAxis.nameTextStyle.fontSize = i.textStyle.fontSize, t.yAxis.nameTextStyle.fontWeight = i.textStyle.fontWeight), t.yAxis.axisLabel.color = e.color, echarts.syno.customizeAxis(t.yAxis, this.dataType)
    },
    setXaxisConfig: function(t) {
        var e = SYNO.SDS.ResourceMonitor.Performance.Chart.Util.labelConfig,
            i = t.xAxis;
        switch (i.type = "time", i.splitLine = {
                show: !1
            }, i.axisLabel.padding = [6, 0, 0, 0], i.axisLabel.color = e.color, i.axisLabel.showMaxLabel = !1, i.axisLabel.showMinLabel = !0, i.axisLabel.formatter = this.getFormatter(), this.timeAxis) {
            default:
            case "week":
            case "month":
                i.splitNumber = 7;
                break;
            case "half_year":
            case "year":
                i.splitNumber = 12
        }
    },
    setTooltipConfig: function(t) {
        SYNO.SDS.ResourceMonitor.Performance.Chart.Util.tooltipConfig.apply(t.tooltip, !0), t.tooltip.formatter = this.trackFormatter.createDelegate(this)
    },
    trackFormatter: function(t) {
        var e, i, a, r = this,
            o = [],
            n = [],
            s = 0,
            l = 0,
            c = function(e) {
                return e.itemId === t[l].seriesId
            };
        for (l = t.length - 1; l >= 0; --l) o[l] = t[l].data[1] - s, r.aggregate && (s += o[l]);
        for (l = 0; l < t.length; ++l) {
            var h = r.topLayer.numberUnit(o[l], r.dataType);
            e = h.num + " " + h.unit, r.lines && (i = r.lines.find(c)), n.push({
                name: t[l].seriesName,
                value: e,
                color: t[l].color,
                fontColor: r.lines && r.lines[l] && r.lines[l].fontColor ? r.lines[l].fontColor : t[l].color,
                order: r.lines ? i.trackOrder : 0
            })
        }
        return n = n.sort(function(t, e) {
            return t.order > e.order ? 1 : -1
        }), a = new Date(t[0].data[0]), a = SYNO.SDS.DateTimeFormatter(a, {
            type: "datetimesec"
        }), SYNO.SDS.ResourceMonitor.Performance.Chart.Util.getStyledInfoList(a, n)
    },
    getDataZoom: function() {
        return [{
            type: "inside",
            start: 66,
            end: 100,
            minSpan: 3
        }, {
            left: 36,
            right: 7,
            type: "syno_slider",
            height: 20,
            start: 66,
            end: 100,
            minSpan: 3,
            padding: 6,
            handleIcon: "M6,19c0,1.7-1.3,3-3,3s-3-1.3-3-3c0-1.3,0.8-2.4,2-2.8V0h2v16.2C5.2,16.6,6,17.7,6,19z",
            handleStyle: {
                color: "rgba(5, 127, 235, 1)"
            },
            textStyle: {
                fontSize: 12
            },
            handleSize: "110%",
            fillerColor: "rgba(21, 116, 232, 0.1)",
            borderColor: "rgba(198, 212, 224, 0.7)",
            backgroundColor: "rgba(250, 252, 255, 1)",
            yAxisMax: "percent" === this.dataType ? 100 : void 0,
            yAxisMin: "percent" === this.dataType ? -10 : void 0,
            dataBackground: {
                areaStyle: {
                    color: "rgba(21, 116, 232, 0.2)"
                },
                lineStyle: {
                    color: "rgba(117,148,191, 0.4)",
                    width: 1,
                    opacity: 1
                }
            },
            labelFormatter: this.getFormatter()
        }]
    },
    getFormatter: function() {
        switch (this.timeAxis) {
            case "week":
            case "month":
                return function(t) {
                    var e = new Date(t);
                    return ("0" + (e.getMonth() + 1)).slice(-2) + "/" + ("0" + e.getDate()).slice(-2) + " " + ("0" + e.getHours()).slice(-2) + ":" + ("0" + e.getMinutes()).slice(-2)
                };
            case "half_year":
            case "year":
                return function(t) {
                    var e = new Date(t);
                    return ("0" + (e.getMonth() + 1)).slice(-2) + "/" + ("0" + e.getDate()).slice(-2)
                }
        }
    }
}), SYNO.SDS.ResourceMonitor.Performance.Chart.Style = {
    fontColor: "rgba(65, 75, 85, 1)",
    fontFamily: "Verdana, Microsoft JhengHei, sans-serif"
}, SYNO.SDS.ResourceMonitor.Performance.Chart.Util = {
    minSizeOfChart: 120,
    chartConfig: {
        textStyle: {
            fontSize: 13,
            fontWeight: "normal",
            fontFamily: SYNO.SDS.ResourceMonitor.Performance.Chart.Style.fontFamily
        },
        apply: function(t) {
            var e = SYNO.SDS.ResourceMonitor.Performance.Chart.Util.chartConfig;
            t.textStyle = e.textStyle
        }
    },
    legendConfig: {
        x: "right",
        y: "top",
        itemGap: 40,
        itemWidth: 7.5,
        itemHeight: 9.5,
        top: -6,
        textStyle: {
            padding: [3, 0, 0, 3],
            color: SYNO.SDS.ResourceMonitor.Performance.Chart.Style.fontColor
        }
    },
    labelConfig: {
        color: SYNO.SDS.ResourceMonitor.Performance.Chart.Style.fontColor
    },
    tooltipConfig: {
        left: 46,
        top: 28,
        bottom: 28,
        border: 1,
        verticalPadding: 6,
        horizontalPadding: 8,
        infoHeight: 20,
        dateSectionHeight: 26,
        sliderbarHeight: 50,
        tableClass: "info-list-table",
        moreItemLabelClass: "info-list-more-item-label",
        textStyle: {
            fontFamily: SYNO.SDS.ResourceMonitor.Performance.Chart.Style.fontFamily,
            color: SYNO.SDS.ResourceMonitor.Performance.Chart.Style.fontColor
        },
        axisPointer: {
            lineStyle: {
                color: "#E64040",
                width: 2
            }
        },
        apply: function(t, e) {
            var i = SYNO.SDS.ResourceMonitor.Performance.Chart.Util.tooltipConfig;
            t.axisPointer = i.axisPointer, t.padding = [i.verticalPadding, i.horizontalPadding], t.position = i.positionFunc.createDelegate(_this3, e, !0)
        },
        positionFunc: function(t, e, i, a, r, o) {
            var n = SYNO.SDS.ResourceMonitor.Performance.Chart.Util;
            n.displayMoreItemLabelIfRequired(i, o);
            var s = n.tooltipConfig;
            return [s.left, s.top]
        }
    },
    getStyledInfoList: function(t, e) {
        var i, a;
        for (i = '<table class="info-list-table">', i += '<tr><td colspan="2" class="info-list-time-text">' + t + "</td></tr>", a = 0; a < e.length; ++a) i += '<tr style="color:' + e[a].fontColor + '"><td class="info-list-content-name">' + e[a].name + '</td><td align="right" class="info-list-content-value">' + e[a].value + "</td></tr>";
        return i += "</table>"
    },
    calculateTableHeight: function(t, e) {
        var i = getComputedStyle(t);
        return parseInt(i.height) - e
    },
    calculateMaximumTableHeight: function(t, e, i) {
        var a = SYNO.SDS.ResourceMonitor.Performance.Chart.Util,
            r = a.tooltipConfig,
            o = r.top,
            n = r.bottom,
            s = r.border,
            l = r.verticalPadding,
            c = getComputedStyle(t);
        return parseInt(c.height) - (o + n) - 2 * (l + s) - e - (i ? a.tooltipConfig.sliderbarHeight : 0)
    },
    getInfoNodeList: function(t) {
        var e = SYNO.SDS.ResourceMonitor.Performance.Chart.Util,
            i = e.tooltipConfig.tableClass;
        return t.querySelector(".".concat(i)).querySelectorAll("tr:not(:first-child)")
    },
    calculateMaximumInfoNum: function(t) {
        var e = SYNO.SDS.ResourceMonitor.Performance.Chart.Util,
            i = e.tooltipConfig.infoHeight,
            a = Math.floor(t / i) - 1;
        return Math.max(a, 0)
    },
    removeHiddenInfoNode: function(t, e) {
        for (var i = t.length, a = e; a < i; ++a) t[a].remove()
    },
    createMoreItemLabelTr: function(t) {
        var e = SYNO.SDS.ResourceMonitor.Performance.Chart.Util,
            i = e.tooltipConfig.moreItemLabelClass,
            a = document.createElement("td");
        a.classList.add(i), a.innerHTML = "".concat(t, " more items...");
        var r = document.createElement("tr");
        return r.appendChild(a), r
    },
    getTableBodyDom: function(t) {
        return t.querySelector("tbody")
    },
    displayMoreItemLabelIfRequired: function(t, e) {
        var i = SYNO.SDS.ResourceMonitor.Performance.Chart.Util,
            a = i.tooltipConfig.dateSectionHeight,
            r = i.calculateTableHeight(t, a),
            o = t.offsetParent,
            n = o ? i.calculateMaximumTableHeight(o, a, e) : _this3.minSizeOfChart;
        if (r > n) {
            var s = i.getInfoNodeList(t),
                l = i.calculateMaximumInfoNum(n);
            i.removeHiddenInfoNode(s, l);
            var c = s.length - l,
                h = i.createMoreItemLabelTr(c);
            i.getTableBodyDom(t).appendChild(h)
        }
    }
}, Ext.define("SYNO.SDS.ResourceMonitor.Performance.DataSet", {
    extend: "Ext.util.Observable",
    constructor: function(t) {
        this.data = [];
        var e = Ext.apply({
            totalTime: 360
        }, t);
        Ext.apply(this, e), this.callParent([e])
    },
    pushData: function(t, e) {
        var i = e - this.totalTime,
            a = 0;
        for (0 == this.data.length && this.data.push([e - SYNO.SDS.ResourceMonitor.Performance.CurrentInterval, 0]), this.data.push([e, t]), a = 0; this.data[a][0] < i; ++a);
        2 <= a && (this.data = this.data.slice(a - 2))
    },
    genSeries: function() {
        return {
            type: "line",
            data: this.data,
            lineStyle: this.lineStyle,
            areaStyle: this.areaStyle,
            symbol: "circle",
            symbolSize: 0,
            name: this.lineName,
            color: this.color,
            id: this.itemId,
            z: this.z
        }
    },
    getLastTime: function() {
        var t = this.data[this.data.length - 1];
        return t ? t[0] : 0
    },
    getMaxDataValue: function() {
        return this.data.reduce(function(t, e) {
            return Math.max(t, e[1])
        }, 0)
    },
    clear: function() {
        this.data.length = 0
    },
    getLastDataValue: function() {
        var t = this.data[this.data.length - 1];
        return t ? t[1] : 0
    }
}), Ext.ns("SYNO.SDS.ResourceMonitor"), Ext.define("SYNO.SDS.ResourceMonitor.MiniWidget", {
    extend: "SYNO.SDS._SystemTray.Component",
    constructor: function(t) {
        var e = this;
        t = Ext.apply(t, {
            baseCls: "resource-monitor-widget-mini"
        }), e.callParent(arguments)
    },
    onRender: function(t, e) {
        var i = this,
            a = new Ext.Template('<div class="{cls}">', '<div class="{cls}-content">', '<div class="{cls}-cpu-mem-wrap">', '<div class="{cls}-cpu">', '<div class="{cls}-cpu-text">CPU', "</div>", '<div class="{cls}-cpu-bar">', '<div class="{cls}-cpu-value">', "</div>", "</div>", '<div class="x-clear"></div>', "</div>", '<div class="{cls}-mem">', '<div class="{cls}-mem-text">RAM', "</div>", '<div class="{cls}-mem-bar">', '<div class="{cls}-mem-value">', "</div>", "</div>", '<div class="x-clear"></div>', "</div>", "</div>", '<div class="{cls}-up-down-wrap">', '<div class="{cls}-upload">', '<div class="{cls}-upload-text">', "</div>", '<div class="{cls}-upload-value">', "</div>", '<div class="x-clear"></div>', "</div>", '<div class="{cls}-download">', '<div class="{cls}-download-text">', "</div>", '<div class="{cls}-download-value">', "</div>", '<div class="x-clear"></div>', "</div>", "</div>", "</div>", "</div>");
        i.el = e ? a.insertBefore(e, {
            cls: i.baseCls
        }, !0) : a.append(t, {
            cls: i.baseCls
        }, !0), i.id && (i.el.dom.id = i.id), i.memValueBar = i.el.child(String.format("div.{0}-mem-value", i.baseCls)), i.cpuValueBar = i.el.child(String.format("div.{0}-cpu-value", i.baseCls)), i.uploadValue = i.el.child(String.format("div.{0}-upload-value", i.baseCls)), i.downloadValue = i.el.child(String.format("div.{0}-download-value", i.baseCls)), i.callParent(arguments)
    },
    afterRender: function() {
        var t = this;
        t.callParent(arguments), t.setCpuValue(0), t.setMemValue(0)
    },
    setCpuValue: function(t) {
        this.setValueBar(t, this.cpuValueBar)
    },
    setMemValue: function(t) {
        this.setValueBar(t, this.memValueBar)
    },
    setUploadValue: function(t, e) {
        this.setTransferValue(this.uploadValue, t, e, "upload")
    },
    setDownloadValue: function(t, e) {
        this.setTransferValue(this.downloadValue, t, e, "download")
    },
    setTransferValue: function(t, e, i, a) {
        var r = "",
            o = "";
        e = Ext.isNumber(e) ? e : 0, i = Ext.isString(i) ? i : "KB", e += "", o = Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(e + " " + i + "/s")), r += String.format('<div class="content value {1}" ext:qtip="{0}">{0}</div>', o, a), t.set({
            "ext:qtip": o
        }), t.update(r)
    },
    setValueBar: function(t, e) {
        var i = e.parent().getWidth();
        t = Ext.isNumber(t) ? Math.min(t, 100) : 100, e.removeClass("high"), t > 80 && e.addClass("high"), e.setWidth(i * t / 100), e.set({
            "ext:qtip": Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(t)) + "&#37;"
        }), e.parent().set({
            "ext:qtip": Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(t)) + "&#37;"
        })
    }
}), SYNO.SDS.ResourceMonitor.WidgetBriefChartMaxTime = 180, SYNO.SDS.ResourceMonitor.PollingInterval = 5, SYNO.SDS.ResourceMonitor.Widget = Ext.extend(Ext.Panel, {
    prevText: _JSLIBSTR("extlang", "prevpage"),
    nextText: _JSLIBSTR("extlang", "nextpage"),
    layout: "vbox",
    activeNetworkTrafficIndex: 0,
    cls: "resource-monitor-widget",
    minimizable: !0,
    toggleButtonCls: SYNO.SDS.ResourceMonitor.MiniWidget,
    taskButton: void 0,
    border: !1,
    constructor: function(t) {
        var e = SYNO.SDS.UserSettings.getProperty("SYNO.SDS._Widget.Instance", "restoreParams"),
            i = e && e.windowState && e.windowState.widgets ? e.windowState.widgets : [];
        Ext.each(i, function(t) {
            if ("SYNO.SDS.ResourceMonitor.Widget" === t.widgetClassName && t.widgetParams) return this.activeNetworkTrafficIndex = t.widgetParams.networkInterfaceIdx || 0, !1
        }, this), SYNO.SDS.ResourceMonitor.Widget.superclass.constructor.apply(this, arguments), this.initPanels()
    },
    onActivate: function() {
        this.isActive = !0, this.startPollingTask(), this.mask(_T("common", "loading"))
    },
    onDeactivate: function() {
        this.isActive = !1
    },
    getDefChartCfg: function() {
        return {
            collapsed: !1,
            baseCls: "resource-Monitor-widget-panel",
            totalRecords: SYNO.SDS.ResourceMonitor.BriefTotalRecords
        }
    },
    getStateParam: function() {
        return {
            networkInterfaceIdx: this.activeNetworkTrafficIndex
        }
    },
    startPollingTask: function() {
        var t = this;
        SYNO.SDS.SocketInst.register({
            api: "SYNO.Core.System.Utilization",
            version: 1,
            method: "get",
            params: {
                type: "current"
            }
        }, function(e) {
            t.onAjaxRequestDone(e.success, e.data)
        }, !0)
    },
    mask: Ext.emptyFn,
    unmask: Ext.emptyFn,
    initPanels: function() {
        this.cpuChart = this.initCpuChart(), this.memChart = this.initMemChart(), this.networkCharts = this.initNetworkPanel(), this.networkIOCmp = this.initNetworkIOCmp(), this.add([this.cpuChart, this.memChart, this.networkIOCmp, this.networkCharts]), this.doLayout()
    },
    initNetworkIOCmp: function() {
        return new SYNO.SDS.ResourceMonitor.NetworkInOutComponent({
            widget: this,
            selBtnWidth: 86,
            width: 296,
            height: 24
        })
    },
    initCpuChart: function() {
        return new SYNO.SDS.ResourceMonitor.PercentageComponent(Ext.apply(this.getDefChartCfg(), {
            itemId: "cpuUsage",
            title: "CPU",
            width: 296,
            height: 24
        }))
    },
    doCollapse: function() {
        this.networkCharts.hide(), this.getEl().setHeight(84), this.doLayout()
    },
    doExpand: function() {
        this.networkCharts.show(), this.getEl().setHeight(172), this.doLayout()
    },
    initMemChart: function() {
        return new SYNO.SDS.ResourceMonitor.PercentageComponent(Ext.apply(this.getDefChartCfg(), {
            itemId: "memoryUsage",
            title: "RAM",
            width: 296,
            height: 24
        }))
    },
    setActivePanel: function() {
        var t = this,
            e = t.networkCharts.get(t.activeNetworkTrafficIndex),
            i = t.networkCharts.getLayout();
        e || (t.activeNetworkTrafficIndex = 0), t.networkIOCmp.selBtn.setText(e.deviceName), i.setActiveItem(t.activeNetworkTrafficIndex), t.networkCharts.get(t.activeNetworkTrafficIndex).drawChart(), t.updateNetworkIOValue()
    },
    initNetworkPanel: function() {
        return new Ext.Panel(Ext.apply(this.getDefChartCfg(), {
            layout: "card",
            itemId: "network",
            activeItem: 0,
            collapsible: !1,
            border: !1,
            defaults: {
                border: !1
            },
            columnWidth: 1
        }))
    },
    onAjaxRequestDone: function(t, e, i, a) {
        var r = this,
            o = 0,
            n = null;
        !r.isDestroyed && t && (r.unmask(), o = e.cpu.user_load + e.cpu.system_load, r.cpuChart.setValue(o), r.memChart.setValue(e.memory.real_usage), r.updateNetworkCharts(e.network, e.time), r.taskButton && (n = r.networkIOCmp, r.taskButton.setMemValue(e.memory.real_usage), r.taskButton.setCpuValue(o), r.taskButton.setUploadValue(n.getConvertSize(n.TxValue), n.getUnit(n.TxValue)), r.taskButton.setDownloadValue(n.getConvertSize(n.RxValue), n.getUnit(n.RxValue)), r.taskButton.updateLayout()))
    },
    updateNetworkCharts: function(t, e) {
        var i, a = this,
            r = a.networkCharts;
        _S("ha_hide_ntb") && a.removeNTBInterfaces(t), a.updateNetworkInterfaces(t), Ext.each(t, function(t) {
            (i = r.get(t.device)) && i.pushValue([t.tx, t.rx], e)
        }, a), a.updateNetworkIOValue()
    },
    removeNTBInterfaces: function(t) {
        var e, i;
        e = t.find(function(t) {
            return "total" === t.device
        }), i = t.find(function(t) {
            return "ntb_eth0" === t.device
        }), e && i && (e.rx = e.rx - i.rx, e.tx = e.tx - i.tx, t.remove(i))
    },
    updateNetworkIOValue: function() {
        var t = this,
            e = t.networkIOCmp,
            i = t.networkCharts,
            a = i.get(t.activeNetworkTrafficIndex);
        a && e.update(a.RxSet.getLastDataValue(), a.TxSet.getLastDataValue())
    },
    updateNetworkInterfaces: function(t) {
        var e, i = this,
            a = i.networkCharts,
            r = !1,
            o = 0,
            n = 0,
            s = 0,
            l = [];
        a.items.each(function(e) {
            var i = Ext.each(t, function(t) {
                return t.device !== e.itemId
            });
            Ext.isDefined(i) || l.push(e)
        }), Ext.each(l, function(t) {
            a.remove(t)
        });
        var c, h = this.networkIOCmp.selMenu,
            u = function(t) {
                return parseInt(t.replace(/[^\d.]/g, ""), 10) || 0
            };
        for (o = 0, n = 0; o < t.length; ++o) {
            if (!a.get(t[o].device)) {
                c = SYNO.SDS.Utils.Network.idToString(t[o].device), e = new SYNO.SDS.ResourceMonitor.Widget.NetworkInterface({
                    itemId: t[o].device,
                    deviceName: c,
                    widget: this
                }), a.insert(n, e), r = !0;
                var d = new Ext.menu.Item({
                        text: c,
                        index: h.items ? h.items.items.length : 0,
                        scope: this,
                        hidden: !1
                    }),
                    m = h.items ? function(t, e) {
                        for (s = e.length - 1; s >= 0; s--)
                            if (u(t) >= u(e[s].text)) return s + 1
                    }(c, h.items.items) : 0;
                h.insert(m, d)
            }
            n++
        }(r || l.length > 0) && (this.setActivePanel(), this.doLayout())
    }
}), SYNO.SDS.ResourceMonitor.NetworkInOutComponent = Ext.extend(Ext.Panel, {
    RxValue: 0,
    TxValue: 0,
    constructor: function(t) {
        Ext.apply(this, t), SYNO.SDS.ResourceMonitor.NetworkInOutComponent.superclass.constructor.call(this, this.fillConfig()), this.mon(this, "afterrender", function() {
            this.drawChart()
        }, this), this.inLabel = this.getComponent("in"), this.outLabel = this.getComponent("out")
    },
    fillConfig: function() {
        return this.selBtn = new SYNO.ux.Button({
            itemId: "select-button",
            xtype: "syno_button",
            boxMaxWidth: 86,
            cls: "interface-selection-button",
            menu: this.selMenu = new SYNO.ux.Menu({
                cls: "resource-monitor-widget",
                listeners: {
                    itemclick: {
                        fn: this.onMenuClick,
                        scope: this
                    }
                }
            })
        }), {
            cls: "resource-Monitor-networkio-cmp",
            width: this.width,
            height: this.height,
            border: !1,
            items: [{
                xtype: "container",
                width: this.selBtnWidth,
                height: 24,
                items: [this.selBtn],
                style: "float: left;"
            }, {
                itemId: "out-graphic",
                xtype: "displayfield",
                cls: "networkio-cmp-icon out"
            }, {
                itemId: "out",
                xtype: "displayfield",
                cls: "networkio-cmp-label out",
                value: "0KB/s"
            }, {
                itemId: "in-graphic",
                xtype: "displayfield",
                cls: "networkio-cmp-icon in"
            }, {
                itemId: "in",
                xtype: "displayfield",
                cls: "networkio-cmp-label",
                value: "0KB/s"
            }]
        }
    },
    onMenuClick: function(t) {
        this.widget.activeNetworkTrafficIndex = t.index, this.widget.setActivePanel()
    },
    update: function(t, e) {
        var i = this;
        i.TxValue = e, i.RxValue = t, i.drawChart()
    },
    drawChart: function() {
        var t = this;
        t.inLabel.setValue(this.convertSize(t.RxValue)), t.outLabel.setValue(this.convertSize(t.TxValue))
    },
    convertSize: function(t) {
        var e = this.getUnit(t) + "/s";
        return this.getConvertSize(t) + " " + e
    },
    getConvertSize: function(t) {
        if (!t) return 0;
        var e = parseInt(Math.floor(Math.log(t) / Math.log(1024)), 10);
        return 0 === e ? parseFloat(t / 1024).toFixed(3) : parseFloat((t / Math.pow(1024, e)).toFixed(1))
    },
    getUnit: function(t) {
        return t ? ["KB", "MB", "GB", "TB", "PB", "EB", "ZB", "YB"][parseInt(Math.floor(Math.log(t) / Math.log(1048576)), 10)] : "KB"
    }
}), SYNO.SDS.ResourceMonitor.Widget.NetworkInterface = Ext.extend(Ext.Panel, {
    constructor: function(t) {
        this.RxSet = new SYNO.SDS.ResourceMonitor.Performance.DataSet({
            totalTime: SYNO.SDS.ResourceMonitor.WidgetBriefChartMaxTime,
            lineStyle: {
                width: 2
            },
            color: "#09B3B3"
        }), this.TxSet = new SYNO.SDS.ResourceMonitor.Performance.DataSet({
            totalTime: SYNO.SDS.ResourceMonitor.WidgetBriefChartMaxTime,
            lineStyle: {
                width: 2
            },
            color: "#1574E8"
        }), this.chart = new Ext.Panel({
            baseCls: "resource-Monitor-widget-base",
            cls: "echarts-wrapper"
        }), this.deviceName = t.deviceName;
        var e = {
            baseCls: "resource-Monitor-widget-panel",
            border: !1,
            width: 296,
            height: 84,
            items: this.chart
        };
        Ext.apply(e, t), SYNO.SDS.ResourceMonitor.Widget.NetworkInterface.superclass.constructor.call(this, e)
    },
    pushValue: function(t, e) {
        this.TxSet.pushData(t[0], e), this.RxSet.pushData(t[1], e), this.drawChart()
    },
    drawChart: function() {
        var t = echarts.syno.getDefaultOptions();
        t.height = 74, t.width = 200, t.backgroundColor = "rgba(0, 0, 0, 0)", t.xAxis.max = this.RxSet.getLastTime(), t.xAxis.min = this.RxSet.getLastTime() - this.RxSet.totalTime, t.xAxis.axisLabel.show = !1, t.yAxis.max = 102400 * Math.ceil(Math.max(this.RxSet.getMaxDataValue(), this.TxSet.getMaxDataValue()) / 102400), t.yAxis.min = 0, t.yAxis.axisLabel.margin = 10, echarts.syno.customizeAxis(t.yAxis, "byte"), t.yAxis.interval = t.yAxis.max / 5, t.grid.tooltip = {
            show: !1
        }, t.grid.top = 8, t.grid.left = 92, t.grid.right = 0, t.grid.bottom = 0, this.chart.echart || (this.chart.echart = echarts.init(this.chart.el.dom)), t.series = [this.RxSet.genSeries(), this.TxSet.genSeries()], this.chart.echart.getWidth() > 0 && this.chart.echart.getHeight() > 0 && this.chart.echart.setOption(t)
    },
    clearValues: function() {
        this.RxSet.clear(), this.TxSet.clear()
    }
}), Ext.define("SYNO.SDS.ResourceMonitor.PercentageComponent", {
    extend: "Ext.BoxComponent",
    title: "",
    value: 0,
    type: "horizontal",
    constructor: function(t) {
        Ext.apply(this, t), SYNO.SDS.ResourceMonitor.PercentageComponent.superclass.constructor.call(this, this.fillConfig())
    },
    fillConfig: function(t) {
        return {
            width: this.width,
            height: this.height,
            layout: "column",
            cls: "resource-monitor-percentage-cmp " + this.type,
            autoEl: {
                tag: "div",
                cn: [{
                    tag: "div",
                    cls: "percentage-cmp-title",
                    html: this.title
                }, {
                    tag: "div",
                    cls: "percentage-cmp-hbar-background",
                    cn: [{
                        tag: "div",
                        cls: "percentage-cmp-hbar-fill"
                    }]
                }, {
                    tag: "div",
                    cls: "percentage-cmp-value",
                    html: this.value + "%"
                }]
            }
        }
    },
    setValue: function(t) {
        this.value = t, this.fillPercent(t)
    },
    fillPercent: function(t) {
        var e = this.el.child("div.percentage-cmp-value"),
            i = this.el.child("div.percentage-cmp-hbar-fill"),
            a = this.el.child("div.percentage-cmp-hbar-background");
        if (i.removeClass("high"), t > 80 && i.addClass("high"), e.update(t + "%"), "vertical" === this.type) {
            var r = .74 * t;
            i.dom.style.height = r + "px"
        } else {
            var o = .01 * t * a.getWidth();
            i.dom.style.width = o + "px"
        }
        i.dom.setAttribute("ext:qtip", t + "%"), a.dom.setAttribute("ext:qtip", t + "%")
    }
});
