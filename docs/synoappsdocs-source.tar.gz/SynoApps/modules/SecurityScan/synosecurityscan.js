/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.define("SYNO.SDS.SecurityScan.HistoryDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(b) {
        this.owner = b.owner;
        this.reportStore = new SYNO.API.JsonStore({
            api: "SYNO.SecurityAdvisor.Report",
            method: "list",
            version: 1,
            root: "items",
            appWindow: this,
            fields: ["type", "datatime", "path", "path_real"]
        });
        this.reportList = new SYNO.ux.GridPanel({
            enableHdMenu: false,
            store: this.reportStore,
            columns: [{
                header: SYNO.SDS.SecurityScan._V("report", "title_type"),
                tooltip: SYNO.SDS.SecurityScan._V("report", "title_type"),
                sortable: true,
                width: 40,
                dataIndex: "type",
                renderer: function(c) {
                    if (c === "monthly") {
                        return SYNO.SDS.SecurityScan._V("report", "type_monthly")
                    } else {
                        return SYNO.SDS.SecurityScan._V("report", "type_daily")
                    }
                }
            }, {
                header: SYNO.SDS.SecurityScan._V("report", "title_report_date_range"),
                tooltip: SYNO.SDS.SecurityScan._V("report", "title_report_date_range"),
                sortable: true,
                width: 40,
                dataIndex: "datatime",
                renderer: function(d) {
                    var c = new Date(d);
                    var e;
                    if (7 == d.length) {
                        e = SYNO.SDS.DateTimeFormatter(c, {
                            type: "yearmonth"
                        })
                    } else {
                        e = SYNO.SDS.DateTimeFormatter(c, {
                            type: "date"
                        })
                    }
                    return e
                }
            }, {
                header: SYNO.SDS.SecurityScan._V("report", "title_report_path"),
                tooltip: SYNO.SDS.SecurityScan._V("report", "title_report_path"),
                sortable: false,
                width: 150,
                dataIndex: "path_real",
                scope: this,
                renderer: function(c) {
                    return this.tplAdd(c, "<a>" + c + "</a>")
                }
            }],
            disableSelection: true,
            listeners: {
                scope: this,
                rowclick: this.onRowClick
            }
        });
        var a = {
            width: 600,
            height: 520,
            layout: "fit",
            cls: "report-history",
            title: SYNO.SDS.SecurityScan._V("report", "title_report_list"),
            items: this.reportList,
            buttons: [{
                xtype: "syno_button",
                text: SYNO.SDS.SecurityScan._V("common", "alt_close"),
                handler: this.close,
                scope: this
            }]
        };
        Ext.apply(a, b);
        this.callParent([a]);
        this.setStatusBusy();
        this.reportStore.load();
        this.clearStatusBusy()
    },
    tplAdd: function(b, a) {
        b = Ext.util.Format.htmlEncode(b);
        b = b.replace("'", "&lsquo;");
        return "<div ext:qtip='" + b + "'>" + a + "</div>"
    },
    onRowClick: function(a, c) {
        var b = "/sar/report/" + a.store.getAt(c).get("path");
        window.open(Ext.urlAppend(b), "_blank")
    }
});
Ext.define("SYNO.SDS.SecurityScan.OverviewPanel", {
    extend: "SYNO.ux.Panel",
    iconStep: 0,
    sysProgress: 100,
    maxAlramSeverity: "",
    blOverviewStatusStoreUpdate: true,
    sysStatus: "firstScan",
    runningStatus: ["running", "stopping", "updating"],
    overviewStatusStoreField: ["status", "text", "desc", "progress", "elapsedTime", "lastScanTime"],
    iconStoreField: ["status"],
    statusBarStoreField: ["category", "categoryDesc", "statusDesc", "level", "isDone", "isEmpty", "progress", "lastProgress"],
    elmPool: {},
    constructor: function(a) {
        this.module = a.module;
        this.owner = a.appWin;
        Ext.apply(this, a);
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    onActivate: function() {
        this.setReportButton()
    },
    onPageActivate: function() {
        SYNO.SDS.SecurityScan.ResizePanel(this, true)
    },
    fillConfig: function(a) {
        this.mainWindow = SYNO.SDS.SecurityScan.Window;
        this.SecurityStatus = {
            running: {
                status: "running",
                text: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_scan"),
                desc: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_scan_desc")
            },
            stopping: {
                status: "stopping",
                text: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_stop"),
                desc: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_stop_desc")
            },
            updating: {
                status: "updating",
                text: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_update"),
                desc: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_update_desc")
            },
            warning: {
                status: "warning",
                text: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_warning"),
                desc: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_warning_desc")
            },
            crack: {
                status: "danger",
                text: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_danger"),
                desc: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_danger_desc")
            },
            danger: {
                status: "danger",
                text: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_danger"),
                desc: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_danger_desc")
            },
            risk: {
                status: "risk",
                text: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_risk"),
                desc: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_risk_desc")
            },
            outOfDate: {
                status: "outOfDate",
                text: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_outOfDate"),
                desc: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_outOfDate_desc")
            },
            firstScan: {
                status: "firstScan",
                text: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_firstScan"),
                desc: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_firstScan_desc")
            },
            safe: {
                status: "safe",
                text: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_safe"),
                desc: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_system_safe_desc")
            }
        };
        this.iconStore = new Ext.data.JsonStore({
            autoDestroy: true,
            fields: this.iconStoreField
        });
        this.overviewStatusStore = new Ext.data.JsonStore({
            autoDestroy: true,
            fields: this.overviewStatusStoreField
        });
        this.statusBarStore = new Ext.data.JsonStore({
            autoDestroy: true,
            fields: this.statusBarStoreField
        });
        this.statusBarInitStore = new Ext.data.JsonStore({
            autoDestroy: true,
            fields: this.statusBarStoreField
        });
        this.status = this.createStatusPanel();
        this.StatusField = this.createStatusBarPanel();
        var b = {
            border: false,
            cls: "securityscan-overview-panel-card",
            listeners: {
                scope: this,
                activate: {
                    fn: this.onActivate
                }
            },
            items: [this.status, this.StatusField]
        };
        Ext.apply(b, a);
        return b
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this.mainWindow.sysStatusStore, "load", this.onStoreLoadDone, this);
        this.mon(this.mainWindow.sysStatusStore, "update", this.onStoreLoadDone, this);
        this.mon(this.mainWindow.sysStatusStore, "add", this.onStoreLoadDone, this);
        this.mon(this.statusBarStore, "load", this.onStatusBarLoadDone, this);
        this.mon(this.mainWindow.specialRulesStore, "update", this.barAreaSet, this)
    },
    createStatusPanel: function() {
        return {
            xtype: "syno_panel",
            hideLabel: true,
            layout: "hbox",
            layoutConfig: {
                align: "stretch",
                pack: "start"
            },
            border: false,
            height: 160,
            items: [this.createIconPanel(), this.createOverviewStatusPanel()]
        }
    },
    createIconPanel: function() {
        var a = new Ext.DataView({
            tpl: new Ext.XTemplate('<tpl for=".">', '<div class="securityscan-overview-overviewStatus-icon securityscan-overview-overviewStatus-icon-{status}"></div>', "</tpl>", {
                compiled: true
            }),
            store: this.iconStore
        });
        return {
            xtype: "syno_panel",
            layout: "vbox",
            border: false,
            width: 96,
            layoutConfig: {
                align: "center",
                pack: "start"
            },
            items: [a]
        }
    },
    createOverviewStatusPanel: function() {
        var a = new Ext.DataView({
            height: (12 + 32) + 20 * 2 + 4,
            tpl: new Ext.XTemplate('<tpl for=".">', '<tpl if="this.progressShow(progress)">', '<div class="securityscan-overview-overviewStatus-text securityscan-overview-overviewStatus-text-{status}">{text} ({progress}%)</div>', "</tpl>", '<tpl if="this.progressShow(progress) === false">', '<div class="securityscan-overview-overviewStatus-text securityscan-overview-overviewStatus-text-{status}">{text}</div>', "</tpl>", '<tpl if="this.lastScanTimeShow(lastScanTime) === false">', '<div class="securityscan-overview-overviewStatus-desc">{desc}<br/>', '<tpl if="this.elapsedTimeShow(elapsedTime)">', SYNO.SDS.SecurityScan._V("securityscan", "securityscan_elapsed_time"), "{elapsedTime}</tpl>", "</div>", "</tpl>", '<tpl if="this.lastScanTimeShow(lastScanTime)">', '<div class="securityscan-overview-overviewStatus-desc">{desc}<br/>{lastScanTime}</div>', "</tpl>", "</tpl>", {
                progressShow: function(b) {
                    if (100 !== b) {
                        return true
                    } else {
                        return false
                    }
                },
                lastScanTimeShow: function(b) {
                    if ("" !== b) {
                        return true
                    } else {
                        return false
                    }
                },
                elapsedTimeShow: function(b) {
                    if (b && "" !== b) {
                        return true
                    } else {
                        return false
                    }
                },
                compiled: true
            }),
            store: this.overviewStatusStore
        });
        return {
            xtype: "syno_panel",
            hideLabel: true,
            layout: "vbox",
            layoutConfig: {
                align: "stretch",
                pack: "start"
            },
            flex: 7,
            border: false,
            items: [a, {
                xtype: "syno_panel",
                hideLabel: true,
                layout: "hbox",
                border: false,
                baseCls: "",
                layoutConfig: {
                    align: "end",
                    pack: "start",
                    defaultMargins: {
                        top: 12,
                        right: 6,
                        bottom: 0,
                        left: 0
                    }
                },
                items: [{
                    xtype: "syno_button",
                    text: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_scan"),
                    id: this.startScanButtonID = Ext.id(),
                    scope: this,
                    disabled: _S("demo_mode"),
                    handler: this.doStartScanAll
                }, {
                    xtype: "syno_button",
                    text: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_stop"),
                    id: this.stopScanButtonID = Ext.id(),
                    scope: this,
                    disabled: _S("demo_mode"),
                    handler: this.doStopScanAll,
                    hideLabel: true
                }, {
                    xtype: "syno_button",
                    text: SYNO.SDS.SecurityScan._V("securityscan", "button_report_create"),
                    id: this.reportButtonID = Ext.id(),
                    disabled: true,
                    handler: this.createReport,
                    scope: this
                }]
            }]
        }
    },
    setReportButton: function() {
        this.sendWebAPI({
            api: "SYNO.SecurityAdvisor.Conf.Location",
            method: "get",
            version: 1,
            scope: this,
            callback: function(c, b, a) {
                if (c) {
                    Ext.getCmp(this.reportButtonID).enable();
                    Ext.getCmp(this.reportButtonID).setTooltip()
                } else {
                    Ext.getCmp(this.reportButtonID).disable();
                    if (401 === b.code) {
                        Ext.getCmp(this.reportButtonID).setTooltip(SYNO.SDS.SecurityScan._V("securityscan", "overview_tooltip_setting_share"))
                    } else {
                        if (402 === b.code) {
                            Ext.getCmp(this.reportButtonID).setTooltip(SYNO.SDS.SecurityScan._V("securityscan", "overview_tooltip_share_path_wrong"))
                        } else {
                            this.mainWindow.getMsgBox().alert("securityscan", SYNO.SDS.SecurityScan._V("error", "error_error_system"))
                        }
                    }
                }
            }
        })
    },
    createReport: function() {
        this.getEl().mask(_T("securityscan", "report_generating"), "x-mask-loading");
        this.sendWebAPI({
            api: "SYNO.SecurityAdvisor.Report",
            method: "create",
            version: 1,
            scope: this,
            callback: function(c, b, a) {
                if (c) {
                    this.mainWindow.getMsgBox().confirm(SYNO.SDS.SecurityScan._V("report", "type_realtime"), SYNO.SDS.SecurityScan._V("securityscan", "gen_report_complete"), function(d) {
                        if ("yes" === d) {
                            window.open(Ext.urlAppend("/sar/report/timerange/tmp.html"), "_blank")
                        }
                    }, this, null, {
                        useMessageTitle: true
                    })
                } else {
                    this.mainWindow.getMsgBox().alert("securityscan", SYNO.SDS.SecurityScan._V("error", "error_error_system"))
                }
                this.getEl().unmask()
            }
        })
    },
    createStatusBarPanel: function() {
        return new Ext.DataView({
            tpl: this.createStatusBarTpl(),
            store: this.statusBarInitStore
        })
    },
    createStatusBarTpl: function() {
        var a = new Ext.XTemplate('<tpl for=".">', '<div class="securityscan-situation-container">', '<div id="container_{category}_ID" class="securityscan-label-container">', '<div class="first_area">', '<div class="securityscan-overview-bar-icon securityscan-overview-bar-icon-{category}"></div>', '<div class="securityscan-overview-bar-title">{categoryDesc}</div>', "</div>", '<div class="second_area">', '<div id="{category}_second_ID" class="securityscan-overview-bar-desc"></div>', "</div>", '<div class="third_area">', '<div id="{category}_third_ID" class="securityscan-progress-desc"></div>', "</div>", "</div>", '<div id="{category}_progress_bar_ID" style="width:{lastProgress}%;" class="securityscan-progress securityscan-bk-progress"></div>', "</div>", "</tpl>", {
            isDone: function(b) {
                return 100 === b ? true : false
            }
        });
        return a
    },
    startIconAnimate: function() {
        if (0 < this.iconStep) {
            var b = ("running-" + (this.iconStep % 24 + 1)).toString();
            var a = this;
            this.iconStore.loadData([{
                status: b
            }]);
            this.iconStep++;
            setTimeout(function() {
                a.startIconAnimate()
            }, 100)
        }
    },
    stopIconAnimate: function(a) {
        this.iconStep = 0;
        this.iconStore.loadData([{
            status: a
        }])
    },
    iconAreaSet: function() {
        if (0 <= this.runningStatus.indexOf(this.sysStatus)) {
            if (0 === this.iconStep) {
                this.iconStep = 1;
                this.startIconAnimate()
            }
        } else {
            this.stopIconAnimate(this.sysStatus)
        }
    },
    setScanningTime: function(a) {
        this.startScanningTime = a
    },
    getScanningTime: function() {
        return this.startScanningTime
    },
    stopOverviewStatusElapsedTime: function(a) {
        delete this.startScanningTime;
        if (a) {
            this.blOverviewStatusStoreUpdate = false
        }
    },
    overviewStatusAreaSet: function() {
        var c, a;
        if (!this.blOverviewStatusStoreUpdate) {
            return
        }
        if (0 <= this.runningStatus.indexOf(this.sysStatus)) {
            this.SecurityStatus[this.sysStatus].elapsedTime = this.mainWindow.timeRender(this.startScanningTime, false);
            this.SecurityStatus[this.sysStatus].lastScanTime = ""
        } else {
            this.stopOverviewStatusElapsedTime();
            this.SecurityStatus[this.sysStatus].elapsedTime = "";
            if (!this.mainWindow.lastScanTime) {
                this.SecurityStatus[this.sysStatus].lastScanTime = ""
            } else {
                c = this.mainWindow.timeRender(this.mainWindow.lastScanTime, true);
                a = SYNO.SDS.SecurityScan._V("securityscan", "securityscan_last_scan_time");
                this.SecurityStatus[this.sysStatus].lastScanTime = String.format(a, c)
            }
        }
        this.SecurityStatus[this.sysStatus].progress = this.sysProgress;
        this.overviewStatusStore.loadData([this.SecurityStatus[this.sysStatus]], false);
        this.overviewBtnSet(false);
        if (this.startScanningTime) {
            var b = this;
            setTimeout(function() {
                b.overviewStatusAreaSet()
            }, 500)
        }
    },
    ruleActionExtraGet: function(d, b) {
        var c, a;
        c = this.mainWindow.specialRuleRecordCheck(d, true);
        if (c) {
            if (c.get("isFail")) {
                a = c.get("actionExtra");
                if (a && a[b]) {
                    return a[b]
                }
            }
        }
        return ""
    },
    statusBarFontClsGet: function(a) {
        switch (a) {
            case "danger":
            case "risk":
                return "red-status";
            case "warning":
            case "outOfDate":
                return "orange-status";
            case "info":
            case "safe":
                return "green-status"
        }
    },
    statusHtmlwrapper: function(a, b) {
        return String.format('<font class="{0}">{1}</font>', a, b)
    },
    statusDescFill: function(d, c) {
        var f, e, b, a;
        for (f in c.fail) {
            if (c.fail.hasOwnProperty(f) && 0 < c.fail[f]) {
                if ("safe" === f || "info" === f || this.statusDescGet(d, f)) {
                    continue
                }
                e = String.format("securityscan_check_{0}_{1}", f, c.category);
                b = SYNO.SDS.SecurityScan._V("securityscan", e);
                if (b) {
                    a = this.statusBarFontClsGet(f);
                    b = String.format(b, c.fail[f]);
                    this.statusDescSet(d, f, this.statusHtmlwrapper(a, b))
                }
            }
        }
    },
    statusDescGet: function(b, c) {
        var a = {
            danger: 0,
            risk: 1,
            warning: 2,
            outOfDate: 3,
            info: 4,
            safe: 5
        };
        return b[a[c]]
    },
    statusDescSet: function(c, d, b) {
        var a = {
            danger: 0,
            risk: 1,
            warning: 2,
            outOfDate: 3,
            info: 4,
            safe: 5
        };
        c[a[d]] = b
    },
    barStatusDescGet: function(j) {
        var g;
        var d;
        var n = [];
        var m = "";
        var b = j.failSeverity;
        var h = "ruleDB.Update.DSM.check_latest_dsm";
        var c = "ruleDB.Update.Package.check_latest_pkg";
        var e = "ruleDB.User.Password.top50000StrengthCheck";
        if (100 !== j.progress) {
            d = "blue-status";
            m = SYNO.SDS.SecurityScan._V("securityscan", "securityscan_check_desc_" + j.category);
            if (j.runningItem) {
                m += "<br/>" + this.mainWindow.getStringKeyVal(j.runningItem, "desc_running")
            }
            return this.statusHtmlwrapper(d, m)
        }
        d = this.statusBarFontClsGet(b);
        if ("userInfo" === j.category) {
            if ("safe" === b || "info" === b) {
                if (this.mainWindow.specialRuleRecordCheck(e, true)) {
                    m = SYNO.SDS.SecurityScan._V("securityscan", "securityscan_check_pass_userInfo_passwrod") + "<br/>"
                }
                m += SYNO.SDS.SecurityScan._V("securityscan", "securityscan_check_pass_userInfo");
                if ("info" === b) {
                    m += "</br>" + SYNO.SDS.SecurityScan._V("securityscan", "securityscan_info_fail_desc")
                }
                return this.statusHtmlwrapper(d, m)
            }
            if ("risk" === b) {
                var l = this.ruleActionExtraGet(e, "FAIL_USERS_NUM");
                if ("" !== l && 0 < l) {
                    g = "securityscan_check_week_password";
                    m = String.format(SYNO.SDS.SecurityScan._V("securityscan", g), l);
                    this.statusDescSet(n, b, this.statusHtmlwrapper(d, m))
                }
            }
            this.statusDescFill(n, j)
        } else {
            if ("update" === j.category) {
                if ("safe" === b || "info" === b) {
                    var a = [];
                    if (this.mainWindow.specialRuleRecordCheck(h, true)) {
                        a.push(SYNO.SDS.SecurityScan._V("securityscan", "securityscan_check_pass_update_dsm"))
                    }
                    if (this.mainWindow.specialRuleRecordCheck(c, true)) {
                        a.push(SYNO.SDS.SecurityScan._V("securityscan", "securityscan_check_pass_update_package"))
                    }
                    if (0 === a.length) {
                        m = SYNO.SDS.SecurityScan._V("securityscan", "securityscan_check_pass_update")
                    } else {
                        if (2 === a.length) {
                            m = _T("securityscan", "securityscan_check_pass_update_dsm_package")
                        } else {
                            m = a.join("</br>")
                        }
                    }
                    if ("info" === b) {
                        m += "<br/>" + SYNO.SDS.SecurityScan._V("securityscan", "securityscan_info_fail_desc")
                    }
                    return this.statusHtmlwrapper(d, m)
                }
                if ("outOfDate" === b) {
                    var k = [],
                        i, f;
                    f = this.mainWindow.specialRuleRecordCheck(h, true);
                    if (f && f.get("isFail")) {
                        k.push(SYNO.SDS.SecurityScan._V("securityscan", "securityscan_check_outOfDate_updates_dsm"))
                    }
                    i = this.ruleActionExtraGet(c, "FAIL_PACKAGES_NUM");
                    if ("" !== i && 0 < i) {
                        k.push(String.format(SYNO.SDS.SecurityScan._V("securityscan", "securityscan_check_outOfDate_updates_package"), i))
                    }
                    m = k.join("<br/>");
                    this.statusDescSet(n, b, this.statusHtmlwrapper(d, m))
                }
                this.statusDescFill(n, j)
            } else {
                if ("safe" === b || "info" === b) {
                    g = "securityscan_check_pass_" + j.category;
                    m = SYNO.SDS.SecurityScan._V("securityscan", g);
                    if ("info" === b) {
                        m += "<br/>" + SYNO.SDS.SecurityScan._V("securityscan", "securityscan_info_fail_desc")
                    }
                    return this.statusHtmlwrapper(d, m)
                }
                this.statusDescFill(n, j)
            }
        }
        n = n.filter(function(o) {
            return o
        });
        return n.join("<br/>")
    },
    barAreaSet: function() {
        var a = 0;
        var c = {};
        var b = [];
        if (0 === this.mainWindow.sysStatusStore.data.length) {
            for (a = 0; a < this.mainWindow.totalCategories.length; a++) {
                c = {};
                c.category = this.mainWindow.totalCategories[a];
                c.categoryDesc = SYNO.SDS.SecurityScan._V("securityscan", "securityscan_category_" + this.mainWindow.totalCategories[a]);
                c.level = "";
                c.isEmpty = "";
                c.progress = 0;
                c.lastProgress = 0;
                c.statusDesc = "";
                b.push(c)
            }
            this.statusBarInitStore.loadData(b, false);
            b = b.filter(function(d) {
                return d
            });
            this.statusBarStore.loadData(b, false);
            return
        }
        this.mainWindow.sysStatusStore.each(function(f) {
            var d;
            var e = f.data;
            c = {};
            d = this.mainWindow.totalCategories.indexOf(e.category);
            if (0 > d) {
                return
            }
            c.category = e.category;
            c.categoryDesc = SYNO.SDS.SecurityScan._V("securityscan", "securityscan_category_" + e.category);
            c.isEmpty = e.total === 0 ? true : false;
            c.progress = e.progress;
            c.lastProgress = this.statusBarStore.getAt(d).get("progress");
            if (!c.isEmpty && 100 === c.progress) {
                c.level = e.failSeverity
            }
            if (c.isEmpty) {
                c.statusDesc = '<font color="#96A0AA">' + SYNO.SDS.SecurityScan._V("securityscan", "securityscan_check_empty") + "</font>"
            } else {
                c.statusDesc = this.barStatusDescGet(e)
            }
            b[d] = c
        }, this);
        b = b.filter(function(d) {
            return d
        });
        this.statusBarStore.loadData(b, false);
        if (0 === this.statusBarInitStore.getTotalCount()) {
            this.statusBarInitStore.loadData(b, false)
        }
    },
    onStoreLoadDone: function() {
        this.iconAreaSet();
        this.barAreaSet();
        this.overviewStatusAreaSet()
    },
    setClickHandler: function(b) {
        var a = Ext.get("container_" + b + "_ID");
        if (a) {
            a.on("click", function(d, c) {
                this.mainWindow.resultFilterKey = b;
                this.mainWindow.selectPage("SYNO.SDS.SecurityScan.ResultPanel")
            }, this)
        }
    },
    animateDone: function(e, d, c, g) {
        if (100 !== d && 100 === c) {
            var a = Ext.get(e + "_third_ID");
            var f = Ext.get("container_" + e + "_ID");
            var b = Ext.get(e + "_progress_bar_ID");
            if (a && f && b) {
                a.dom.innerHTML = "";
                a.removeClass("securityscan-progress-desc");
                a.addClass(["securityscan-overview-icon", "securityscan-overview-icon-" + g]);
                f.addClass(["securityscan-overview-bar-bk-" + g]);
                b.hide()
            }
        }
    },
    onStatusBarLoadDone: function() {
        this.statusBarStore.each(function(g) {
            var k = g.get("category");
            var h = g.get("lastProgress");
            var a = g.get("progress");
            var j = k + "_second_el";
            var l = k + "_third_el";
            this.elmPool[j] = Ext.get(k + "_second_ID");
            this.elmPool[l] = Ext.get(k + "_third_ID");
            if (!this.elmPool[j] || !this.elmPool[l]) {
                return
            }
            if (100 === a) {
                this.setClickHandler(k)
            }
            this.elmPool[j].dom.innerHTML = g.get("statusDesc");
            if (h !== a && !g.get("isEmpty")) {
                this.elmPool[l].dom.innerHTML = a + "%";
                var d = Ext.get(k + "_progress_bar_ID");
                var b = g.get("level");
                if (d) {
                    var f = this;
                    try {
                        d.animate({
                            width: {
                                to: (a / 100) * this.getWidth(),
                                from: (h / 100) * this.getWidth()
                            }
                        }, 0.5, null, "easeOut", "run");
                        setTimeout(function() {
                            f.animateDone(k, h, a, b)
                        }, 700)
                    } catch (i) {
                        console.log("Error: " + i)
                    }
                }
            }
        }, this)
    },
    doStartScanAll: function() {
        Ext.getCmp(this.reportButtonID).disable();
        this.mainWindow.doStartScan("ALL")
    },
    doStopScanAll: function() {
        this.mainWindow.doStopScan("ALL");
        this.setReportButton()
    },
    sysStatusSet: function(b, a) {
        this.sysStatus = b;
        this.sysProgress = a ? a : 0
    },
    overviewBtnSet: function(b) {
        var a = this.sysStatus;
        if (!this.startScanButtonEle) {
            this.startScanButtonEle = Ext.getCmp(this.startScanButtonID)
        }
        if (!this.stopScanButtonEle) {
            this.stopScanButtonEle = Ext.getCmp(this.stopScanButtonID)
        }
        if (b) {
            this.startScanButtonEle.disable();
            this.stopScanButtonEle.disable();
            return
        }
        switch (a) {
            case "running":
                this.startScanButtonEle.hide();
                this.stopScanButtonEle.show();
                if (!_S("demo_mode")) {
                    this.stopScanButtonEle.enable()
                }
                break;
            case "stopping":
            case "updating":
                this.startScanButtonEle.disable();
                this.stopScanButtonEle.disable();
                break;
            default:
                this.startScanButtonEle.show();
                if (!_S("demo_mode")) {
                    this.startScanButtonEle.enable()
                }
                this.stopScanButtonEle.hide();
                break
        }
        this.doLayout()
    },
    openFirstScanDialog: function() {
        var a = new SYNO.SDS.SecurityScan.OverviewPanel.FirstScanDialog({
            module: this.module,
            owner: this.owner
        });
        a.open()
    },
    isRunningStatus: function(a) {
        if (0 <= this.runningStatus.indexOf(a)) {
            return true
        } else {
            this.setReportButton();
            return false
        }
    },
    maxAlramSeveritySet: function(a) {
        this.maxAlramSeverity = a
    }
});
Ext.define("SYNO.SDS.SecurityScan.OverviewPanel.FirstScanDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.module = a.module;
        this.owner = a.owner;
        this.workID = Ext.id();
        this.homeID = Ext.id();
        this.workCheckListID = Ext.id();
        this.homeCheckListID = Ext.id();
        this.selectedID = this.homeID;
        this.mainWindow = SYNO.SDS.SecurityScan.Window;
        this.textStore = new Ext.data.JsonStore({
            fields: ["workBkCls", "homeBkCls"],
            data: [{
                workBkCls: "item-normal",
                homeBkCls: "item-selected"
            }]
        });
        Ext.apply(a, {
            title: SYNO.SDS.SecurityScan._V("securityscan", "first_security_level"),
            width: 740,
            height: 560,
            resizable: false,
            minimizable: false,
            cls: "securityscan-firstScan-window",
            closeAction: "onCloseX",
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "start"),
                width: 120,
                scope: this,
                btnStyle: "blue",
                handler: this.goStart
            }],
            items: [this.createDescPanel(), this.createSelectionPanel()]
        });
        this.callParent([a]);
        this.mon(this.textStore, "load", this.setClickHandler, this)
    },
    createDescPanel: function() {
        var a = {
            xtype: "syno_panel",
            cls: "securityscan-firstScan-descpanel",
            items: [{
                xtype: "syno_displayfield",
                cls: "descpanel-title",
                value: SYNO.SDS.SecurityScan._V("securityscan", "first_title")
            }, {
                xtype: "syno_displayfield",
                cls: "descpanel-desctext",
                value: SYNO.SDS.SecurityScan._V("securityscan", "first_title_desc")
            }]
        };
        return a
    },
    createSelectionPanel: function() {
        var a = new Ext.DataView({
            tpl: new Ext.XTemplate('<tpl for=".">', "<div>", '<div id="' + this.homeID + '" class="securityscan-firstScan-itemgroup item-left {homeBkCls}">', '<div class="securityscan-firstScan-item-pic home-icon"></div>', '<div class="securityscan-firstScan-item-title">' + SYNO.SDS.SecurityScan._V("securityscan", "securityscan_config_default_group_home") + "</div>", '<div class="securityscan-firstScan-item-desc">' + SYNO.SDS.SecurityScan._V("securityscan", "securityscan_config_default_group_home_desc") + "</div>", '<div class="securityscan-firstScan-item-checklist"><span id="' + this.homeCheckListID + '">' + SYNO.SDS.SecurityScan._V("securityscan", "first_view_checklist") + "</span></div>", "</div>", '<div id="' + this.workID + '" class="securityscan-firstScan-itemgroup item-right {workBkCls}">', '<div class="securityscan-firstScan-item-pic company-icon"></div>', '<div class="securityscan-firstScan-item-title">' + SYNO.SDS.SecurityScan._V("securityscan", "securityscan_config_default_group_company") + "</div>", '<div class="securityscan-firstScan-item-desc">' + SYNO.SDS.SecurityScan._V("securityscan", "securityscan_config_default_group_company_desc") + "</div>", '<div class="securityscan-firstScan-item-checklist"><span id="' + this.workCheckListID + '">' + SYNO.SDS.SecurityScan._V("securityscan", "first_view_checklist") + "</span></div>", "</div>", "</div>", "</tpl>", {
                compiled: true
            }),
            store: this.textStore,
            listeners: {
                afterrender: function(c) {
                    this.setClickHandler()
                },
                scope: this
            }
        });
        var b = {
            xtype: "syno_panel",
            cls: "securityscan-firstScan-selectionpanel",
            items: [a]
        };
        return b
    },
    showCheckList: function(b) {
        var c;
        switch (b) {
            case "home":
                c = _T("securityscan", "securityscan_config_default_group_home");
                break;
            case "company":
                c = _T("securityscan", "securityscan_config_default_group_company");
                break;
            default:
                return
        }
        var a = new SYNO.SDS.SecurityScan.SettingsPanel.ListDialog({
            module: this.module,
            owner: this,
            ownerForm: null,
            parentObj: null,
            group: b,
            title: c
        });
        a.open()
    },
    clickHomeHandler: function(c, a) {
        if (a.id === this.homeCheckListID) {
            this.showCheckList("home");
            return
        }
        var b = [];
        b.push({
            workBkCls: "item-normal",
            homeBkCls: "item-selected"
        });
        this.textStore.loadData(b, false)
    },
    clickWorkHandler: function(c, a) {
        if (a.id === this.workCheckListID) {
            this.showCheckList("company");
            return
        }
        var b = [];
        b.push({
            workBkCls: "item-selected",
            homeBkCls: "item-normal"
        });
        this.textStore.loadData(b, false)
    },
    setClickHandler: function() {
        Ext.get(this.homeID).on("click", this.clickHomeHandler, this);
        Ext.get(this.workID).on("click", this.clickWorkHandler, this)
    },
    goStart: function() {
        var b = [];
        var a = {};
        var c = Math.floor(Math.random() * 7);
        var e = Math.floor(Math.random() * 5) + 1;
        var d = Math.floor(Math.random() * 60);
        a.api = "SYNO.Core.SecurityScan.Conf";
        a.method = "set";
        a.version = 1;
        a.params = {
            Input: {
                argGroup: this.selectedID === this.workID ? "company" : "home",
                enableSchedule: true,
                weekday: c.toString(),
                hour: e,
                minute: d,
                scheduleTaskId: -1
            }
        };
        b.push(a);
        b.push({
            api: "SYNO.SecurityAdvisor.Conf",
            method: "init",
            version: 1,
            params: {
                type: "brandnew",
                argGroup: this.selectedID === this.workID ? "company" : "home",
                rules: []
            }
        });
        this.setStatusBusy();
        this.sendWebAPI({
            compound: {
                mode: "parallel",
                params: b
            },
            scope: this,
            callback: function(h, g, f) {
                if (h && !g.has_fail) {
                    this.mainWindow.doStartScan("ALL");
                    this.clearStatusBusy();
                    this.close()
                } else {
                    this.clearStatusBusy()
                }
            }
        })
    },
    onCloseX: function() {
        this.mainWindow.close()
    }
});
Ext.define("SYNO.SDS.SecurityScan.ResultPanel", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(a) {
        this.module = a.module;
        this.owner = a.appWin;
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        this.mainWindow = SYNO.SDS.SecurityScan.Window;
        this.tbarStore = new Ext.data.ArrayStore({
            fields: ["id", "display"],
            data: [
                [this.mainWindow.resultFilterID + "_ALL", SYNO.SDS.SecurityScan._V("securityscan", "securityscan_all")],
                [this.mainWindow.resultFilterID + "_malware", SYNO.SDS.SecurityScan._V("securityscan", "securityscan_category_malware")],
                [this.mainWindow.resultFilterID + "_systemCheck", SYNO.SDS.SecurityScan._V("securityscan", "securityscan_category_systemCheck")],
                [this.mainWindow.resultFilterID + "_userInfo", SYNO.SDS.SecurityScan._V("securityscan", "securityscan_category_userInfo")],
                [this.mainWindow.resultFilterID + "_network", SYNO.SDS.SecurityScan._V("securityscan", "securityscan_category_network")],
                [this.mainWindow.resultFilterID + "_update", SYNO.SDS.SecurityScan._V("securityscan", "securityscan_category_update")]
            ]
        });
        var b = this.createCategoryConfig();
        Ext.apply(b, a);
        return b
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this.mainWindow.allItemsStore, "load", this.onStoreLoadDone, this);
        this.mon(this.mainWindow.allItemsStore, "update", this.onStoreLoadDone, this);
        this.mon(this.mainWindow.allItemsStore, "add", this.onStoreLoadDone, this)
    },
    createCategoryConfig: function() {
        var b = [{
            header: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_label_status"),
            dataIndex: "status",
            sortable: true,
            width: 40,
            scope: this,
            renderer: function(f) {
                var d = SYNO.SDS.SecurityScan._V("securityscan", "securityscan_result_" + f);
                var e = this.valBeauty(f, "status");
                return this.tplAdd(d, e)
            }
        }, {
            header: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_label_level"),
            dataIndex: "severitySort",
            hideable: false,
            width: 50,
            sortable: true,
            renderer: function(j, g, i, f, h, d) {
                j = i.get("severity");
                if ("" === j) {
                    return ""
                }
                var e = SYNO.SDS.SecurityScan._V("securityscan", "securityscan_severity_" + j);
                return this.tplAdd(e, e)
            },
            scope: this
        }, {
            header: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_label_desc"),
            dataIndex: "strId",
            sortable: true,
            scope: this,
            renderer: function(i, f, h, e, g, d) {
                if ("pass" === h.get("status")) {
                    i = this.mainWindow.getTooltipStringKeyVal(i, "desc_good")
                } else {
                    if ("running" === h.get("status")) {
                        i = this.mainWindow.getTooltipStringKeyVal(i, "desc_running")
                    } else {
                        i = this.mainWindow.getTooltipStringKeyVal(i, "desc_bad")
                    }
                }
                return this.tplAdd(i, i)
            },
            width: 240
        }, {
            header: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_label_update"),
            dataIndex: "update",
            sortable: true,
            width: 60,
            scope: this,
            renderer: function(j, g, i, f, h, d) {
                if (!j || "" === j || "running" === i.get("status")) {
                    return ""
                }
                var e = this.mainWindow.timeRender(j, true);
                return this.tplAdd(e, e)
            }
        }];
        var c = new Ext.Toolbar({
            defaultType: "syno_button",
            items: this.getTbarItems()
        });
        var a = {
            tbar: c,
            title: "SYNO.ux.GridPanel",
            store: this.mainWindow.allItemsStore,
            height: this.mainWindow.getHeight() - 40,
            columns: b,
            viewConfig: {
                deferEmptyText: false,
                emptyText: this.viewShow(),
                markDirty: false
            },
            listeners: {
                rowclick: function(d, g, f) {
                    this.onBtnCheck()
                },
                rowdblclick: function(d, e) {
                    this.openDetailDialog()
                },
                scope: this
            }
        };
        return a
    },
    setFilter: function(c) {
        var b, a;
        this.getSelectionModel().clearSelections();
        this.onBtnCheck();
        a = this.tbarStore.find("id", c);
        b = this.tbarStore.getAt(a).get("display");
        Ext.getCmp(this.filterTbarID).setValue(b);
        this.mainWindow.storeFilter(c);
        this.viewShow()
    },
    viewShow: function() {
        if (this.getGridEl()) {
            if (0 === this.mainWindow.allItemsStore.data.length) {
                this.getGridEl().mask(_T("securityscan", "securityscan_check_empty"), "syno-ux-mask-info")
            } else {
                this.getGridEl().unmask(_T("securityscan", "securityscan_check_empty"), "syno-ux-mask-info")
            }
            this.getView().refresh()
        }
    },
    customGroupSet: function() {
        var a = {};
        var b = this.mainWindow.allItemsStore.snapshot || this.mainWindow.allItemsStore.data;
        var c = "";
        b.each(function(f) {
            var d = false;
            var e = f.get("id");
            Ext.each(this.removeItems, function(g) {
                if (g.get("id") === e) {
                    d = true;
                    return
                }
            }, this);
            if (!d) {
                c += " " + e
            }
        }, this);
        this.mainWindow.setStatusBusy();
        a.api = "SYNO.Core.SecurityScan.Conf";
        a.method = "group_set";
        a.version = 1;
        a.params = {
            items: c
        };
        this.mainWindow.apiSend.call(this, a, function(d) {
            this.getSelectionModel().clearSelections();
            this.onBtnCheck();
            this.mainWindow.clearStatusBusy();
            this.mainWindow.defGroup = "custom";
            Ext.each(this.removeItems, function(e) {
                this.mainWindow.allItemsStore.remove(e)
            }, this);
            this.mainWindow.onSysStatusPolling()
        }, function(d) {
            this.mainWindow.clearStatusBusy()
        })
    },
    beforeCustomGroupSet: function() {
        if ("custom" !== this.mainWindow.defGroup) {
            this.mainWindow.getMsgBox().confirm("securityscan", _T("securityscan", "confirm_group_change"), function(a) {
                if ("yes" === a) {
                    this.customGroupSet()
                }
            }, this)
        } else {
            this.customGroupSet()
        }
    },
    skipRule: function() {
        this.removeItems = "";
        var a = {};
        this.removeItems = this.getSelectionModel().getSelections();
        var b = this.mainWindow.allItemsStore.snapshot || this.mainWindow.allItemsStore.data;
        if (this.mainWindow.sysStatusRunning) {
            this.mainWindow.getMsgBox().alert("securityscan", _T("securityscan", "securityscan_error_is_scanning"));
            return
        }
        if (0 >= this.removeItems.length || 1 === b.length) {
            return
        }
        if ("" === this.mainWindow.defGroup) {
            a.api = "SYNO.Core.SecurityScan.Conf";
            a.method = "get";
            a.version = 1;
            a.params = {};
            this.mainWindow.setStatusBusy();
            this.mainWindow.apiSend.call(this, a, function(c) {
                this.mainWindow.clearStatusBusy();
                this.mainWindow.defGroup = c.defaultGroup;
                this.beforeCustomGroupSet()
            }, function(c) {
                this.mainWindow.clearStatusBusy()
            })
        } else {
            this.beforeCustomGroupSet()
        }
    },
    onScanBtnCheck: function() {
        var a = true;
        var c = this.mainWindow.allItemsStore.snapshot || this.mainWindow.allItemsStore.data;
        var b;
        if (!Ext.getCmp(this.scanBtnID)) {
            return
        }
        b = this.getSelectionModel().getSelections();
        if (0 >= b.length) {
            Ext.getCmp(this.scanBtnID).disable();
            return
        }
        c.each(function(d) {
            if ("running" === d.data.status) {
                a = false;
                return
            }
        }, this);
        if (a) {
            if (!_S("demo_mode")) {
                Ext.getCmp(this.scanBtnID).enable()
            }
        } else {
            Ext.getCmp(this.scanBtnID).disable()
        }
    },
    onViewBtnCheck: function() {
        var a;
        if (!Ext.getCmp(this.viewBtnID)) {
            return
        }
        a = this.getSelectionModel().getSelections();
        if (1 !== a.length) {
            Ext.getCmp(this.viewBtnID).disable()
        } else {
            Ext.getCmp(this.viewBtnID).enable()
        }
    },
    onSkipBtnCheck: function() {
        var a;
        if (!Ext.getCmp(this.skipBtnID)) {
            return
        }
        a = this.getSelectionModel().getSelections();
        if (this.mainWindow.sysStatusRunning) {
            Ext.getCmp(this.skipBtnID).disable();
            return
        }
        if (1 <= a.length) {
            if (!_S("demo_mode")) {
                Ext.getCmp(this.skipBtnID).enable()
            }
        } else {
            Ext.getCmp(this.skipBtnID).disable()
        }
    },
    onBtnCheck: function() {
        this.onScanBtnCheck();
        this.onViewBtnCheck();
        this.onSkipBtnCheck();
        this.setReportButton()
    },
    openDetailDialog: function() {
        var a = new SYNO.SDS.SecurityScan.ResultPanel.DetailDialog({
            module: this.module,
            owner: this.owner,
            seletedItem: this.getSelectionModel().getSelected().data
        });
        a.open()
    },
    onStoreLoadDone: function(a) {
        this.onBtnCheck();
        this.viewShow();
        this.getView().refresh()
    },
    getTbarItems: function() {
        var a = [{
            text: _T("securityscan", "view"),
            itemId: "view",
            tooltip: _T("securityscan", "view"),
            id: this.viewBtnID = Ext.id(),
            disabled: true || _S("demo_mode"),
            scope: this,
            handler: function(c, b) {
                this.openDetailDialog("add")
            }
        }, {
            text: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_scan"),
            itemId: "edit",
            tooltip: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_scan"),
            id: this.scanBtnID = Ext.id(),
            disabled: true,
            scope: this,
            handler: function(e, c) {
                var b, d = "";
                b = this.getSelectionModel().getSelections();
                if (0 < b.length) {
                    Ext.each(b, function(f) {
                        d += " " + f.get("id");
                        f.set("status", "running")
                    }, this);
                    this.mainWindow.doStartScan(d)
                } else {
                    this.mainWindow.getMsgBox().alert("securityscan", SYNO.SDS.SecurityScan._V("securityscan", "securityscan_alert_non_items"))
                }
            }
        }, {
            text: _T("common", "skip"),
            itemId: "skip",
            tooltip: _T("common", "skip"),
            id: this.skipBtnID = Ext.id(),
            disabled: true || _S("demo_mode"),
            scope: this,
            handler: function(c, b) {
                this.skipRule()
            }
        }, {
            text: SYNO.SDS.SecurityScan._V("report", "button_report_old_get"),
            scope: this,
            disabled: true,
            itemId: "histort_report_btn",
            handler: this.viewHistoryReport
        }, "->", {
            xtype: "syno_combobox",
            id: this.filterTbarID = Ext.id(),
            displayField: "display",
            valueField: "id",
            value: "ALL",
            store: this.tbarStore,
            autoSelect: false,
            tpl: '<tpl for="."><div class="x-combo-list-item">{display}</div><tpl if="xindex == 1"><hr size="1px" style="border-color: rgba(198,212,224,0.40); border-style: solid;"></tpl></tpl>',
            listeners: {
                select: this.onFilterSelect,
                beforeselect: this.onBeforeFilterSelect,
                scope: this
            }
        }];
        return a
    },
    valBeauty: function(c, b) {
        if ("" === c) {
            return c
        }
        if ("status" === b) {
            var a = '<div class="securityscan-result securityscan-result-{0}"></div>';
            if ("nonChecked" === c) {
                c = '<div style="text-align: center; font-size: 20px;"><font class="blue-status">-</font></div>'
            } else {
                c = String.format(a, c)
            }
        }
        return c
    },
    tplAdd: function(b, a) {
        if (!b) {
            return
        }
        b = Ext.util.Format.htmlEncode(b);
        return '<div ext:qtip="' + b + '">' + a + "</div>"
    },
    onBeforeFilterSelect: function(c, a, b) {
        if ("" === a.get("id")) {
            return false
        }
        return true
    },
    onFilterSelect: function(c, a, b) {
        var d = a.get("id");
        this.setFilter(d)
    },
    onPageActivate: function() {
        var a = String.format("{0}_{1}", this.mainWindow.resultFilterID, this.mainWindow.resultFilterKey);
        this.setFilter(a);
        this.onBtnCheck();
        this.viewShow();
        SYNO.SDS.SecurityScan.ResizePanel(this)
    },
    onPageDeactivate: function() {
        this.mainWindow.resultFilterKey = "ALL"
    },
    viewHistoryReport: function() {
        var a = new SYNO.SDS.SecurityScan.HistoryDialog({
            owner: this.appWin
        });
        a.open()
    },
    setReportButton: function() {
        var a = this.getTopToolbar().getComponent("histort_report_btn");
        this.sendWebAPI({
            api: "SYNO.SecurityAdvisor.Conf.Location",
            method: "get",
            version: 1,
            scope: this,
            callback: function(d, c, b) {
                if (d) {
                    a.enable();
                    a.setTooltip()
                } else {
                    a.disable();
                    if (401 === c.code) {
                        a.setTooltip(SYNO.SDS.SecurityScan._V("securityscan", "overview_tooltip_setting_share"))
                    } else {
                        if (402 === c.code) {
                            a.setTooltip(SYNO.SDS.SecurityScan._V("securityscan", "overview_tooltip_share_path_wrong"))
                        } else {
                            this.mainWindow.getMsgBox().alert("securityscan", SYNO.SDS.SecurityScan._V("error", "error_error_system"))
                        }
                    }
                }
            }
        })
    }
});
Ext.define("SYNO.SDS.SecurityScan.IdProtection.SearchField", {
    extend: "SYNO.ux.SearchField",
    initEvents: function() {
        this.searchPanel = this.owner.searchPanel;
        this.callParent(arguments);
        this.mon(Ext.getDoc(), "mousedown", this.onMouseDown, this);
        this.mon(this, "keypress", function(b, a) {
            if (a.getKey() === Ext.EventObject.ENTER) {
                this.searchPanel.setKeyWord(this.getValue());
                this.searchPanel.onSearch()
            }
        }, this)
    },
    isInnerComponent: function(c, b) {
        var a = false;
        b.items.each(function(d) {
            if (d instanceof Ext.form.ComboBox) {
                if (d.view && c.within(d.view.getEl())) {
                    a = true;
                    return false
                }
            } else {
                if (d instanceof SYNO.ux.DateTimeField) {
                    if (d.menu && c.within(d.menu.getEl())) {
                        a = true;
                        return false
                    }
                } else {
                    if (d instanceof Ext.form.CompositeField) {
                        if (this.isInnerComponent(c, d)) {
                            a = true;
                            return false
                        }
                    }
                }
            }
        }, this);
        return a
    },
    onMouseDown: function(a) {
        if (this.searchPanel && this.searchPanel.isVisible() && !this.searchPanel.isDestroyed && !this.searchPanel.inEl && !a.within(this.searchPanel.getEl()) && !a.within(this.searchtrigger) && !this.isInnerComponent(a, this.searchPanel.getForm())) {
            this.searchPanel.hide()
        }
    },
    onSearchTriggerClick: function() {
        if (this.searchPanel.isVisible()) {
            this.searchPanel.hide();
            return
        }
        this.searchPanel.getEl().alignTo(this.wrap, "tr-br?", [0, 1]);
        this.searchPanel.setKeyWord(this.getValue());
        this.searchPanel.focusKeyWord();
        this.searchPanel.show()
    },
    onTriggerClick: function() {
        this.setValue("");
        this.searchPanel.onReset()
    }
});
Ext.define("SYNO.SDS.SecurityScan.IdProtection.SearchFormPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(a) {
        this.owner = a.owner;
        this.module = a.module;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(a) {
        var b = [];
        b.push(this.createKeyword());
        b.push(this.createSeverity());
        b.push(this.createCustDate());
        b.push(this.createButtons());
        var c = Ext.apply({
            width: 368,
            heigh: 480,
            floating: true,
            labelAlign: "left",
            trackResetOnLoad: true,
            autoFlexcroll: false,
            defaults: {
                hideLabel: true,
                anchor: "100%"
            },
            listeners: {
                actionfailed: {
                    fn: function() {
                        this.form.reset()
                    },
                    scope: this
                }
            },
            keys: [{
                key: [10, 13],
                fn: function() {
                    this.onSearch()
                },
                scope: this
            }],
            items: b
        }, a);
        return c
    },
    createKeyword: function() {
        return [{
            xtype: "syno_displayfield",
            value: _T("log", "attr_keyword") + _T("common", "colon"),
            style: "margin-top: 0px",
            flex: 1
        }, {
            xtype: "syno_textfield",
            name: "keyword",
            style: "margin-bottom: 12px;",
            flex: 2
        }]
    },
    createSeverity: function() {
        return [{
            xtype: "syno_displayfield",
            value: _T("securityscan", "securityscan_label_level") + _T("common", "colon")
        }, {
            xtype: "syno_combobox",
            displayField: "display",
            valueField: "value",
            name: "severity",
            value: "all",
            style: "margin-bottom: 12px;",
            store: new Ext.data.ArrayStore({
                fields: ["value", "display"],
                data: [
                    ["all", _T("common", "show_all")],
                    ["high", _T("securityscan", "idprotection_severity_high")],
                    ["medium", _T("securityscan", "idprotection_severity_medium")]
                ]
            })
        }]
    },
    createCustDate: function() {
        var b = new SYNO.ux.DateTimeField({
            name: "date_from",
            editable: false,
            emptyText: _T("log", "date_from"),
            listeners: {
                scope: this,
                select: function(d, c) {
                    this.form.findField("date_to").setMinValue(c)
                }
            }
        });
        var a = new SYNO.ux.DateTimeField({
            name: "date_to",
            editable: false,
            emptyText: _T("log", "date_to"),
            listeners: {
                scope: this,
                select: function(d, c) {
                    this.form.findField("date_from").setMaxValue(c)
                }
            }
        });
        return [{
            xtype: "syno_displayfield",
            value: _T("time", "time_date") + _T("common", "colon")
        }, {
            xtype: "syno_compositefield",
            hideLabel: true,
            defaults: {
                flex: 1
            },
            defaultMargins: "0 8 0 0",
            items: [b, a]
        }]
    },
    createButtons: function() {
        return [{
            xtype: "syno_panel",
            border: false,
            layout: "hbox",
            layoutConfig: {
                align: "center",
                pack: "end",
                defaultMargins: {
                    top: 0,
                    right: 0,
                    bottom: 0,
                    left: 10
                }
            },
            cls: "securityscan-searchpanel-btn",
            padding: 0,
            style: "padding: 0px; padding-top: 20px;",
            items: [{
                xtype: "syno_button",
                cls: "securityscan-searchpanel-btn-reset",
                text: _T("common", "reset"),
                handler: this.onReset,
                scope: this
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                cls: "securityscan-searchpanel-btn-search",
                text: _T("log", "search"),
                handler: this.onSearch,
                scope: this
            }]
        }]
    },
    onSearch: function() {
        var c = this.form.getValues();
        var a = this.owner.store;
        for (var d in c) {
            if (c.hasOwnProperty(d)) {
                if (("date_from" === d || "date_to" === d) && "" !== c[d]) {
                    var b = Date.parseDate(c[d], SYNO.SDS.DateTimeUtils.GetDateFormat()).format("Y/m/d");
                    a.baseParams[d] = b
                } else {
                    a.baseParams[d] = c[d]
                }
            }
        }
        a.load()
    },
    onReset: function() {
        var c = this.form.getValues();
        var a = this.owner.store;
        for (var d in c) {
            if (c.hasOwnProperty(d)) {
                var b = this.form.findField(d);
                b.setValue("");
                a.baseParams[d] = ""
            }
        }
        a.load()
    },
    setKeyWord: function(a) {
        var b = this.form.findField("keyword");
        if (b) {
            b.setValue(a)
        }
    },
    focusKeyWord: function() {
        var a = this.form.findField("keyword");
        a.focus("", 1)
    }
});
Ext.define("SYNO.SDS.SecurityScan.IdProtection.GoogleMapLoader", {
    GMAP_API_URL: "https://maps.google.com/maps/api/js?libraries=places&key=AIzaSyCK-n7RohML-R4vaF4kHyGXDm5pJwoUhEI",
    extend: "Ext.util.Observable",
    loadScript: function(d, c) {
        if (window.google && window.google.maps) {
            if (d) {
                d.createDelegate(c)()
            }
            return
        }
        var b = this.GMAP_API_URL + "&callback=onGoogleMapLoaded";
        var a = document.createElement("script");
        if (d) {
            window.onGoogleMapLoaded = d.createDelegate(c)
        } else {
            window.onGoogleMapLoaded = Ext.emptyFn
        }
        a.type = "text/javascript";
        a.src = b;
        a.onload = (function() {
            this.fireEvent("loaded")
        }).createDelegate(this);
        document.body.appendChild(a)
    }
});
Ext.define("SYNO.SDS.SecurityScan.IdProtection.DetailDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(b) {
        this.module = b.module;
        this.owner = b.owner;
        this.mainWindow = SYNO.SDS.SecurityScan.Window;
        this.data = b.seletedItem;
        this.data.str_args.country = _T("Country", this.data.str_args.country_code);
        this.panel = this.createPanel();
        var a = {
            loadMask: true,
            width: 620,
            height: 500,
            resizable: false,
            title: SYNO.SDS.SecurityScan._V("securityscan", "event"),
            items: [this.panel],
            buttons: [{
                text: _T("common", "alt_close"),
                scope: this,
                handler: this.close
            }]
        };
        Ext.apply(a, b);
        this.callParent([a])
    },
    createPanel: function() {
        var f = {
            xtype: "syno_fieldset",
            collapsible: false,
            items: [{
                xtype: "syno_displayfield",
                fieldLabel: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_label_level"),
                scope: this,
                value: SYNO.SDS.SecurityScan._V("securityscan", "idprotection_severity_" + this.data.severity)
            }, {
                xtype: "syno_displayfield",
                fieldLabel: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_label_desc"),
                scope: this,
                value: SYNO.SDS.SecurityScan._T(this.data.str_section, this.data.str_id + "_symptom", this.data.str_args, true),
                htmlEncode: false
            }]
        };
        var e = {
            xtype: "syno_fieldset",
            title: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_detail_purpose"),
            collapsible: false,
            items: [{
                xtype: "syno_displayfield",
                scope: this,
                value: SYNO.SDS.SecurityScan._T(this.data.str_section, this.data.str_id + "_detail", this.data.str_args, true),
                htmlEncode: false
            }]
        };
        var c = [f, e];
        if (this.data.str_args.latitude !== undefined && this.data.str_args.longitude !== undefined) {
            var b = {
                xtype: "container",
                height: 100,
                items: [{
                    xtype: "container",
                    layout: "fit",
                    items: [this.mapContainer = new Ext.Container({
                        layout: "fit",
                        height: 100,
                        listeners: {
                            afterrender: {
                                fn: this.initMap,
                                scope: this
                            }
                        }
                    })]
                }]
            };
            c.push(b)
        }
        var d = {
            xtype: "syno_fieldset",
            title: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_setting_action_title"),
            collapsible: false,
            items: [{
                xtype: "syno_displayfield",
                scope: this,
                value: SYNO.SDS.SecurityScan._T(this.data.str_section, this.data.str_id + "_recommand", this.data.str_args, true),
                htmlEncode: false
            }]
        };
        c.push(d);
        var a = {
            border: false,
            height: 406,
            items: c
        };
        return new SYNO.ux.FormPanel(a)
    },
    initMap: function() {
        var c = this.data.str_args.latitude;
        var b = this.data.str_args.longitude;
        var a = this.mapContainer.getEl().dom;
        this.gmap = new window.google.maps.Map(a, {
            center: new window.google.maps.LatLng(c, b),
            minZoom: 1,
            zoom: 2,
            scrollwheel: true,
            mapTypeControl: false,
            streetViewControl: false,
            rotateControl: false
        });
        this.marker = new window.google.maps.Marker({
            position: new window.google.maps.LatLng(c, b),
            map: this.gmap,
            title: "Here",
            animation: window.google.maps.Animation.DROP
        })
    }
});
Ext.define("SYNO.SDS.SecurityScan.IdProtectionPanel", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(b) {
        this.module = b.module;
        this.owner = b.appWin;
        this.appWin = b.appWin;
        this.pageSize = 20;
        var a = new SYNO.SDS.SecurityScan.IdProtection.GoogleMapLoader();
        a.loadScript();
        this.callParent([this.fillConfig(b)])
    },
    onPageActivate: function() {
        SYNO.SDS.SecurityScan.ResizePanel(this)
    },
    fillConfig: function(a) {
        this.mainWindow = SYNO.SDS.SecurityScan.Window;
        this.store = this.getStore();
        this.searchPanel = this.initSearchForm();
        var e = new Ext.Toolbar({
            defaultType: "syno_button",
            items: this.getTbarItems()
        });
        var d = new SYNO.ux.PagingToolbar({
            store: this.store,
            pageSize: this.pageSize,
            displayButtons: true,
            displayInfo: true
        });
        var c = [{
            header: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_label_level"),
            dataIndex: "severity",
            hideable: false,
            width: 50,
            scope: this,
            renderer: function(g) {
                var f = SYNO.SDS.SecurityScan._V("securityscan", "idprotection_severity_" + g);
                return this.colorTplAdd(f, f, "securityscan-log-" + g)
            }
        }, {
            header: SYNO.SDS.SecurityScan._V("securityscan", "idprotection_label_time"),
            dataIndex: "create_time",
            hideable: false,
            width: 100,
            scope: this,
            renderer: function(g) {
                var f = new Date(g);
                var h = SYNO.SDS.DateTimeFormatter(f, {
                    type: "datetimesec"
                });
                return this.tplAdd(h, h)
            }
        }, {
            header: _T("personal_settings", "login_place"),
            dataIndex: "country",
            hideable: false,
            width: 60,
            scope: this,
            renderer: function(f) {
                return this.tplAdd(f, f)
            }
        }, {
            header: _T("personal_settings", "login_protocol"),
            dataIndex: "protocol",
            hideable: false,
            width: 60,
            scope: this,
            renderer: function(f) {
                return this.tplAdd(f, f)
            }
        }, {
            header: SYNO.SDS.SecurityScan._V("common", "user"),
            dataIndex: "user",
            hideable: false,
            width: 60,
            scope: this,
            renderer: function(f) {
                return this.tplAdd(f, f)
            }
        }, {
            header: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_label_desc"),
            dataIndex: "str_id",
            hideable: false,
            width: 200,
            scope: this,
            renderer: function(l, i, k, h, j, f) {
                var g = SYNO.SDS.SecurityScan._T(k.get("str_section"), l + "_symptom", k.get("str_args"));
                return this.tplAdd(g, g)
            }
        }];
        var b = {
            tbar: e,
            bbar: d,
            store: this.store,
            height: this.mainWindow.getHeight() - 40,
            enableHdMenu: false,
            columns: c,
            listeners: {
                activate: function() {
                    this.appWin.setStatusBusy();
                    this.activatePage()
                },
                rowclick: function(f, h, g) {
                    this.onBtnCheck()
                },
                rowdblclick: function(f, g) {
                    this.openDetailDialog()
                },
                scope: this
            }
        };
        Ext.apply(b, a);
        return b
    },
    activatePage: function() {
        this.sendWebAPI({
            api: "SYNO.Core.SecurityScan.Conf",
            method: "get",
            version: 1,
            scope: this,
            callback: function(c, b, a) {
                if (!c) {
                    SYNO.Debug("fail to call SYNO.Core.SecurityScan.Conf:get");
                    return
                }
                this.sendWebAPI({
                    api: "SYNO.SecurityAdvisor.Conf.Checklist",
                    method: "list",
                    params: {
                        group: b.defaultGroup
                    },
                    version: 1,
                    scope: this,
                    callback: function(f, e, d) {
                        if (!f) {
                            SYNO.Debug("fail to call SYNO.SecurityAdvisor.Conf.Checklist:list");
                            return
                        }
                        this.rules = e.items;
                        this.store.load()
                    }
                })
            }
        })
    },
    registerStatusEvent: function() {
        if (undefined !== this.gotoSettingId) {
            this.mon(Ext.fly(this.gotoSettingId), "click", function() {
                this.appWin.selectPage("SYNO.SDS.SecurityScan.SettingsPanel")
            }, this)
        }
    },
    checkStatus: function(h) {
        var j = _T("securityscan", "login_analysis_no_entry");
        var c = "no_entry";
        var g = false;
        var b;
        for (var d = 0; d < h.length; d++) {
            var f = h[d];
            if (f.enable) {
                g = true
            }
            if ("abnormal_login" == f.analyzer) {
                b = f
            }
        }
        if (!g) {
            c = "function_disabled"
        } else {
            if (b.is_learning) {
                var e = String.format("{0} {1} {2} {3}", b.remain_days, (b.remain_days > 1) ? _T("common", "time_days") : _T("common", "time_day"), b.remain_hours, (b.remain_hours > 1) ? _T("common", "time_hours") : _T("common", "time_hour"));
                var a = String.format(_T("securityscan", "login_analysis_learning_remain_time"), e, 14);
                j = String.format("{0}<br>{1}", _T("securityscan", "login_analysis_is_learning"), a);
                c = "learning"
            }
        }
        return {
            status: c,
            message: j
        }
    },
    initSearchForm: function() {
        var a = new SYNO.SDS.SecurityScan.IdProtection.SearchFormPanel({
            cls: "securityscan-searchpanel",
            renderTo: Ext.getBody(),
            shadow: false,
            hidden: true,
            owner: this
        });
        return a
    },
    initEmptyForm: function() {
        this.gotoSettingId = Ext.id();
        var a = String.format(_T("securityscan", "login_analysis_is_not_enabled"), String.format('<a class="link-font" id="{0}" href="#">', this.gotoSettingId), "</a>");
        return new Ext.BoxComponent({
            cls: "synopkg-empty-pkglist-mask",
            renderTo: this.getEl(),
            hidden: true,
            style: "margin-left: 1px",
            autoEl: {
                tag: "div",
                children: [{
                    tag: "div",
                    cls: "securityscan-empty-entry-icon"
                }, {
                    tag: "div",
                    cls: "synopkg-empty-pkglist-msg",
                    html: a
                }]
            }
        })
    },
    getStore: function() {
        var c = function(e, d) {
            if (d.str_args.country_code) {
                return _T("Country", d.str_args.country_code)
            } else {
                if (d.str_args.country_code_list) {
                    if (d.str_args.country_code_list.length === 0) {
                        if (d.str_args.has_any_public_src_ip) {
                            return _T("securityscan", "unknown_geoip_location")
                        } else {
                            return _T("securityscan", "private_network")
                        }
                    } else {
                        if (d.str_args.country_code_list.length === 1) {
                            return _T("Country", d.str_args.country_code_list[0])
                        } else {
                            return _T("securityscan", "multiple_countries")
                        }
                    }
                }
            }
            return "-"
        };
        var a = function(e, d) {
            if (d.str_args.protocol) {
                return d.str_args.protocol
            } else {
                if (d.str_args.protocol_list) {
                    if (d.str_args.protocol_list.length === 0) {
                        return "-"
                    } else {
                        if (d.str_args.protocol_list.length === 1) {
                            return d.str_args.protocol_list[0]
                        } else {
                            return _T("securityscan", "multiple_protocols")
                        }
                    }
                }
            }
            return "-"
        };
        var b = {
            autoDestroy: true,
            appWindow: this.appWin,
            scope: this,
            api: "SYNO.SecurityAdvisor.LoginActivity",
            method: "list",
            version: 1,
            remoteSort: false,
            defaultSortable: true,
            baseParams: {
                offset: 0,
                limit: this.pageSize
            },
            listeners: {
                exception: {
                    fn: function(g, h, i, f, e, d) {
                        this.appWin.clearStatusBusy()
                    },
                    scope: this
                },
                load: {
                    fn: function() {
                        this.onBtnCheck();
                        this.appWin.clearStatusBusy();
                        if (this.emptyPanel) {
                            this.emptyPanel.hide()
                        }
                        this.getEl().unmask();
                        if (0 === this.store.getTotalCount()) {
                            var d = this.checkStatus(this.rules);
                            if ("function_disabled" == d.status) {
                                if (!this.emptyPanel) {
                                    this.emptyPanel = this.initEmptyForm();
                                    this.registerStatusEvent()
                                }
                                this.emptyPanel.show()
                            } else {
                                this.getEl().mask(d.message, "syno-ux-mask-info")
                            }
                        }
                    },
                    scope: this
                }
            },
            root: "items",
            totalProperty: "total",
            fields: ["severity", "create_time", "str_id", "str_section", "str_args", "user", {
                name: "country",
                convert: c
            }, {
                name: "protocol",
                convert: a
            }]
        };
        return new SYNO.API.JsonStore(b)
    },
    getTbarItems: function() {
        var a = [{
            text: _T("securityscan", "view"),
            itemId: "view",
            tooltip: _T("securityscan", "view"),
            id: this.viewBtnID = Ext.id(),
            disabled: true,
            handler: this.openDetailDialog,
            scope: this
        }, "->", this.filter = new SYNO.SDS.SecurityScan.IdProtection.SearchField({
            iconStyle: "filter",
            itemId: "search",
            owner: this
        })];
        return a
    },
    tplAdd: function(b, a) {
        if (!b) {
            return
        }
        b = Ext.util.Format.htmlEncode(b);
        b = b.replace("'", "&lsquo;");
        return "<div ext:qtip='" + b + "'>" + a + "</div>"
    },
    colorTplAdd: function(c, b, a) {
        if (!c) {
            return
        }
        c = Ext.util.Format.htmlEncode(c);
        c = c.replace("'", "&lsquo;");
        return "<div ext:qtip='" + c + "'><span class='" + a + "'>" + b + "</span></div>"
    },
    onBtnCheck: function() {
        if (!Ext.getCmp(this.viewBtnID)) {
            return
        }
        if (1 === this.getSelectionModel().getSelections().length) {
            Ext.getCmp(this.viewBtnID).enable()
        } else {
            Ext.getCmp(this.viewBtnID).disable()
        }
    },
    openDetailDialog: function() {
        var a = new SYNO.SDS.SecurityScan.IdProtection.DetailDialog({
            module: this.module,
            owner: this.owner,
            seletedItem: this.getSelectionModel().getSelected().data
        });
        a.open()
    }
});
Ext.define("SYNO.SDS.SecurityScan.SettingsPanel", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(a) {
        this.appWin = a.appWin;
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)]);
        this.mon(this, "activate", this.loadConfig, this)
    },
    onPageActivate: function() {
        SYNO.SDS.SecurityScan.ResizePanel(this)
    },
    fillConfig: function(a) {
        this.mainWindow = SYNO.SDS.SecurityScan.Window;
        this.defaultBehaviorFieldSet = this.createDefaultBehaviorFieldSet();
        this.ScheduleBehaviorFieldSet = this.createScheduleBehaviorFieldSet();
        this.StorageBehaviorFieldSet = this.createStorageBehaviorFieldSet();
        var b = {
            border: false,
            autoScroll: true,
            useDefaultBtn: true,
            padding: 0,
            items: [this.defaultBehaviorFieldSet, this.ScheduleBehaviorFieldSet, this.StorageBehaviorFieldSet]
        };
        Ext.apply(b, a);
        return b
    },
    createDefaultBehaviorFieldSet: function() {
        var a = SYNO.SDS.SecurityScan._V("securityscan", "securityscan_config_default_group_home_desc") + " " + SYNO.SDS.SecurityScan._V("securityscan", "list_view_desc");
        a = String.format(a, '<a class="link-font" href="#">', "</a>");
        var b = {
            labelWidth: 72,
            title: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_config_default_group"),
            items: [{
                xtype: "syno_radio",
                name: "scanGroup",
                inputValue: "home",
                scope: this,
                handler: this.onScanGroupRatioClick,
                boxLabel: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_config_default_group_home"),
                checked: true
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                value: a,
                htmlEncode: false,
                listeners: {
                    scope: this,
                    single: true,
                    buffer: 80,
                    render: function(d) {
                        var c = d.el.first("a");
                        if (c) {
                            this.mon(c, "click", function(f) {
                                f.preventDefault();
                                this.onClickGroup("home")
                            }, this)
                        }
                    }
                }
            }, {
                xtype: "syno_radio",
                name: "scanGroup",
                inputValue: "company",
                scope: this,
                handler: this.onScanGroupRatioClick,
                boxLabel: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_config_default_group_company")
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                value: a,
                htmlEncode: false,
                listeners: {
                    scope: this,
                    single: true,
                    buffer: 80,
                    render: function(d) {
                        var c = d.el.first("a");
                        if (c) {
                            this.mon(c, "click", function(f) {
                                f.preventDefault();
                                this.onClickGroup("company")
                            }, this)
                        }
                    }
                }
            }, {
                xtype: "syno_radio",
                name: "scanGroup",
                inputValue: "custom",
                scope: this,
                handler: this.onScanGroupRatioClick,
                boxLabel: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_config_default_group_custom")
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                value: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_config_default_group_custom_desc")
            }, {
                xtype: "syno_button",
                text: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_config_custom_group"),
                indent: 1,
                id: this.customListBtn = Ext.id(),
                scope: this,
                handler: function() {
                    this.onClickGroup("custom")
                }
            }]
        };
        return new SYNO.ux.FieldSet(SYNO.LayoutConfig.fill(b))
    },
    createScheduleBehaviorFieldSet: function() {
        var a = {
            labelWidth: 200,
            title: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_schedule_name"),
            items: this.createScheduleTimeItems()
        };
        return new SYNO.ux.FieldSet(SYNO.LayoutConfig.fill(a))
    },
    createStorageBehaviorFieldSet: function() {
        var a = {
            labelWidth: 200,
            title: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_storage_name"),
            items: this.createStorageItems()
        };
        return new SYNO.ux.FieldSet(SYNO.LayoutConfig.fill(a))
    },
    onScanGroupRatioClick: function(a, b) {
        if (!a.checked) {
            return
        }
        if ("custom" === a.value) {
            Ext.getCmp(this.customListBtn).enable()
        } else {
            Ext.getCmp(this.customListBtn).disable()
        }
    },
    onClickGroup: function(b) {
        var c;
        switch (b) {
            case "home":
                c = _T("securityscan", "securityscan_config_default_group_home");
                break;
            case "company":
                c = _T("securityscan", "securityscan_config_default_group_company");
                break;
            case "custom":
                c = _T("securityscan", "securityscan_config_default_group_custom");
                break
        }
        var a = new SYNO.SDS.SecurityScan.SettingsPanel.ListDialog({
            module: this.module,
            owner: this.owner,
            ownerForm: this.form,
            parentObj: this,
            group: b,
            title: c
        });
        a.open()
    },
    createScheduleTimeItems: function() {
        return [{
            xtype: "syno_checkbox",
            name: "enableSchedule",
            boxLabel: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_config_schedule_desc"),
            hideLabel: true,
            listeners: {
                scope: this,
                check: this.onEnableSchedule
            }
        }, {
            xtype: "syno_schedulefield",
            indent: 1,
            fieldLabel: _T("schedule", "run_on_days"),
            name: "weekday",
            allowBlank: false,
            editable: false,
            width: 154
        }, {
            xtype: "syno_compositefield",
            fieldLabel: _T("schedule", "run_task"),
            name: "run_task_time",
            indent: 1,
            items: [{
                xtype: "syno_combobox",
                store: this.createTimeItemStore("hour"),
                displayField: "display",
                name: "hour",
                valueField: "value",
                triggerAction: "all",
                value: 0,
                mode: "local",
                width: 70
            }, {
                xtype: "syno_displayfield",
                value: ":",
                width: 2
            }, {
                xtype: "syno_combobox",
                store: this.createTimeItemStore("min"),
                displayField: "display",
                name: "minute",
                valueField: "value",
                triggerAction: "all",
                value: 0,
                width: 70,
                mode: "local"
            }]
        }]
    },
    createStorageItems: function() {
        return [{
            xtype: "syno_compositefield",
            fieldLabel: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_storage_location"),
            hideLabel: false,
            items: [{
                xtype: "syno_textfield",
                width: 180,
                name: "storage_location",
                readOnly: true,
                tabIndex: 2
            }, {
                xtype: "syno_button",
                text: _T("common", "choose"),
                scope: this,
                handler: this.choosedestHandler
            }]
        }, {
            xtype: "syno_checkbox",
            name: "enable_monthly_report",
            boxLabel: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_monthly_report_label"),
            hideLabel: true
        }, {
            xtype: "syno_checkbox",
            name: "enable_daily_report",
            boxLabel: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_daily_report_label"),
            hideLabel: true
        }, {
            xtype: "syno_displayfield",
            indent: 1,
            value: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_monthly_report_desc")
        }]
    },
    setReportCheckbox: function() {
        var a = this.getForm().findField("storage_location").getValue();
        if (0 < a.length) {
            this.getForm().findField("enable_monthly_report").enable();
            this.getForm().findField("enable_daily_report").enable()
        } else {
            this.getForm().findField("enable_monthly_report").disable();
            this.getForm().findField("enable_daily_report").disable()
        }
    },
    choosedestHandler: function(c, a) {
        var b;
        b = new SYNO.SDS.Utils.FileChooser.Chooser({
            owner: this.owner,
            usage: {
                type: "chooseDir"
            },
            superuser: true,
            treeFilter: function(e, d) {
                if (d && (d.spath === "/home" || d.spath === "/surveillance")) {
                    return false
                }
                return true
            },
            title: _T("common", "choose"),
            folderToolbar: true,
            superUser: true,
            enumCluster: true,
            enumC2Share: true,
            listeners: {
                scope: this,
                choose: this.onChooserSelect
            }
        }).show()
    },
    onChooserSelect: function(c, b) {
        var a = b.path.substr(1);
        this.getForm().findField("storage_location").setValue(a);
        c.close();
        this.setReportCheckbox()
    },
    createTimeItemStore: function(e) {
        var a = [];
        var c = {
            hour: 24,
            min: 60
        };
        if (e in c) {
            for (var d = 0; d < c[e]; d++) {
                a.push([d, String.leftPad(String(d), 2, "0")])
            }
            var b = new Ext.data.SimpleStore({
                fields: ["value", "display"],
                data: a
            });
            return b
        }
        return null
    },
    cancelHandler: function() {
        this.mainWindow.getMsgBox().confirm(_TT("SYNO.SDS.AV.Instance", "config", "restore_default"), SYNO.SDS.SecurityScan._V("securityscan", "securityscan_restore_desc"), function(a) {
            if ("yes" === a) {
                this.loadConfig()
            }
        }, this);
        return false
    },
    isGroupDirty: function() {
        return this.originalScanGroup !== this.getForm().findField("scanGroup").getGroupValue()
    },
    isScheduleDirty: function() {
        return this.getForm().findField("enableSchedule").isDirty() || this.getForm().findField("weekday").isDirty() || this.getForm().findField("hour").isDirty() || this.getForm().findField("minute").isDirty()
    },
    isStorageLocationDirty: function() {
        return this.getForm().findField("storage_location").isDirty()
    },
    isMonthlyReportDirty: function() {
        return this.getForm().findField("enable_monthly_report").isDirty()
    },
    isDailyReportDirty: function() {
        return this.getForm().findField("enable_daily_report").isDirty()
    },
    isDirty: function() {
        return this.isGroupDirty() || this.isScheduleDirty() || this.isStorageLocationDirty() || this.isMonthlyReportDirty() || this.isDailyReportDirty()
    },
    objectIsEmpty: function(b) {
        for (var a in b) {
            if (hasOwnProperty.call(b, a)) {
                return false
            }
        }
        return true
    },
    applyHandler: function() {
        var b = [];
        var c = {};
        var d = {};
        var a = false;
        if (!this.getForm().isValid()) {
            return
        }
        if (this.isGroupDirty()) {
            c.argGroup = this.getForm().findField("scanGroup").getGroupValue();
            d.group = this.getForm().findField("scanGroup").getGroupValue();
            a = true
        }
        if (this.isScheduleDirty()) {
            c.enableSchedule = this.getForm().findField("enableSchedule").getValue();
            c.weekday = this.getForm().findField("weekday").getValue();
            c.hour = this.getForm().findField("hour").getValue();
            c.minute = this.getForm().findField("minute").getValue();
            c.scheduleTaskId = this.scheduleTaskId;
            a = true
        }
        if (this.isStorageLocationDirty()) {
            d.location = this.getForm().findField("storage_location").getValue();
            a = true
        }
        if (this.isMonthlyReportDirty()) {
            d.enable_monthly_report = this.getForm().findField("enable_monthly_report").getValue();
            a = true
        }
        if (this.isDailyReportDirty()) {
            d.enable_daily_report = this.getForm().findField("enable_daily_report").getValue();
            a = true
        }
        if (!a) {
            this.mainWindow.getMsgBox().alert("securityscan", _T("error", "nochange_subject"));
            return
        }
        if (this.mainWindow.sysStatusRunning) {
            this.mainWindow.getMsgBox().alert("securityscan", _T("securityscan", "securityscan_error_is_scanning"));
            return
        }
        if (!this.objectIsEmpty(c)) {
            b.push({
                api: "SYNO.Core.SecurityScan.Conf",
                method: "set",
                version: 1,
                params: {
                    Input: c
                }
            })
        }
        if (!this.objectIsEmpty(d)) {
            b.push({
                api: "SYNO.SecurityAdvisor.Conf",
                method: "set",
                version: 1,
                params: d
            })
        }
        this.appWin.setStatusBusy({
            text: _T("common", "saving")
        });
        this.sendWebAPI({
            compound: {
                mode: "parallel",
                params: b
            },
            scope: this,
            callback: this.applyHandlerCallback
        })
    },
    applyHandlerCallback: function(c, b, a) {
        if (!c || b.has_fail) {
            this.getMsgBox().alert("securityscan", SYNO.SDS.SecurityScan._V("error", "error_error_system"));
            this.appWin.clearStatusBusy();
            if (this.confirmLostChangeReject) {
                this.confirmLostChangeReject()
            }
            return
        }
        this.form.setValues({
            scanGroup: this.getForm().findField("scanGroup").getGroupValue(),
            enableSchedule: this.getForm().findField("enableSchedule").getValue(),
            weekday: this.getForm().findField("weekday").getValue(),
            hour: this.getForm().findField("hour").getValue(),
            minute: this.getForm().findField("minute").getValue(),
            storage_location: this.getForm().findField("storage_location").getValue(),
            enable_monthly_report: this.getForm().findField("enable_monthly_report").getValue(),
            enable_daily_report: this.getForm().findField("enable_daily_report").getValue()
        });
        this.originalScanGroup = this.getForm().findField("scanGroup").getGroupValue();
        this.mainWindow.defGroup = this.originalScanGroup;
        if (b.result[0].data && b.result[0].data.hasOwnProperty("scheduleTaskId")) {
            this.scheduleTaskId = b.result[0].data.scheduleTaskId
        }
        this.mainWindow.onStatusPolling("ALL");
        this.mainWindow.onSysStatusPolling();
        this.appWin.clearStatusBusy();
        if (this.confirmSaveLostResolve) {
            this.confirmSaveLostResolve()
        }
    },
    loadConfig: function() {
        var a = [];
        a.push({
            api: "SYNO.Core.SecurityScan.Conf",
            method: "get",
            version: 1
        });
        a.push({
            api: "SYNO.SecurityAdvisor.Conf",
            method: "get",
            version: 1
        });
        this.appWin.setStatusBusy();
        this.sendWebAPI({
            compound: {
                mode: "parallel",
                params: a
            },
            scope: this,
            callback: function(f, e, c) {
                if (f && !e.has_fail) {
                    var d = e.result[0].data;
                    var b = e.result[1].data;
                    this.scheduleTaskId = d.scheduleTaskId;
                    this.originalScanGroup = d.defaultGroup;
                    if (!d.weekday) {
                        d.weekday = "1";
                        d.hour = 0;
                        d.minute = 0
                    }
                    this.form.setValues({
                        scanGroup: d.defaultGroup,
                        enableSchedule: d.enableSchedule,
                        weekday: d.weekday,
                        hour: d.hour,
                        minute: d.minute,
                        storage_location: b.location,
                        enable_monthly_report: b.enable_monthly_report,
                        enable_daily_report: b.enable_daily_report
                    });
                    this.mainWindow.defGroup = d.defaultGroup;
                    this.onScanGroupRatioClick(this.getForm().findField("scanGroup"), true);
                    this.setReportCheckbox();
                    this.onEnableSchedule(this.getForm().findField("enableSchedule"), d.enableSchedule)
                } else {
                    this.getMsgBox().alert("securityscan", SYNO.SDS.SecurityScan._V("error", "error_error_system"))
                }
                this.appWin.clearStatusBusy()
            }
        })
    },
    onPageDeactivate: function() {
        return !this.isDirty()
    },
    onPageConfirmLostChangeSave: function() {
        return new Promise(function(b, a) {
            this.confirmSaveLostResolve = b;
            this.confirmLostChangeReject = a;
            this.applyHandler()
        }.bind(this))
    },
    onEnableSchedule: function(a, b) {
        this.getForm().findField("weekday").setDisabled(!b);
        this.getForm().findField("run_task_time").setDisabled(!b)
    }
});
SYNO.SDS.SecurityScan.SettingsConfigurable = function(a) {
    var b = {
        "brute_force_attack.BruteForceAttack": {
            dialogTitle: _T("securityscan", "brute_force_attack_config"),
            configKeys: [{
                name: "thresh_minutes",
                label: _T("securityscan", "thresh_minutes"),
                minValue: 1,
                maxValue: (60 * 24)
            }, {
                name: "thresh_fails",
                label: _T("securityscan", "thresh_fails"),
                minValue: 1
            }]
        }
    };
    this.check = function() {
        return b.hasOwnProperty(a)
    };
    this.render = function(c, e, h) {
        var f = b[a];
        var g = f.configKeys;
        var d = [c];
        Ext.each(g, function(i) {
            if (h) {
                d.push(h(e[i.name]))
            } else {
                d.push(e[i.name])
            }
        }, this);
        return String.format.apply(String, d)
    };
    if (this.check()) {
        Ext.apply(this, b[a])
    }
};
Ext.define("SYNO.SDS.SecurityScan.SettingsPanel.ListDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.module = a.module;
        this.owner = a.owner;
        this.ownerForm = a.ownerForm;
        this.parentObj = a.parentObj;
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        this.group = a.group;
        this.mainWindow = SYNO.SDS.SecurityScan.Window;
        this.customListStore = this.createStore();
        this.gridPanel = this.createCategoryObj();
        var b = {
            width: 760,
            height: 550,
            resizable: false,
            title: a.title,
            items: [this.gridPanel]
        };
        if ("custom" == this.group) {
            b.buttons = [{
                btnStyle: "grey",
                text: _T("common", "alt_cancel"),
                scope: this,
                handler: this.oncancel
            }, {
                btnStyle: "blue",
                text: SYNO.SDS.SecurityScan._V("common", "save"),
                id: this.customListSaveID = Ext.id(),
                itemId: "customListSave",
                scope: this,
                disabled: _S("demo_mode"),
                handler: this.customListSave
            }]
        } else {
            b.buttons = [{
                btnStyle: "grey",
                text: _T("common", "alt_close"),
                scope: this,
                handler: this.oncancel
            }]
        }
        Ext.apply(b, a);
        return b
    },
    createStore: function() {
        var b = this.mainWindow.allItemsStoreField.concat(["scanType", "strSection"]);
        b.push("enabled");
        b.push("analyzer");
        b.push("label");
        b.push("config");
        var a = new Ext.data.JsonStore({
            sortInfo: {
                field: "category",
                direction: "ASC"
            },
            proxy: new Ext.data.MemoryProxy([]),
            fields: b
        });
        return a
    },
    createCategoryObj: function() {
        var d = this.group;
        var b = "custom" === d ? false : true;
        this.enableColumn = new SYNO.ux.EnableColumn({
            header: _T("common", "enabled"),
            dataIndex: "enabled",
            disableSelectAll: b,
            menuDisabled: true,
            sortable: true,
            width: 50,
            align: "center",
            tooltip: _T("common", "enabled"),
            isIgnore: function(g, f) {
                return "custom" !== d
            },
            renderer: function(h, g, f) {
                return SYNO.ux.EnableColumn.prototype.renderer(h, g, f)
            }
        });
        var c = [this.enableColumn, {
            header: SYNO.SDS.SecurityScan._V("report", "report_type"),
            dataIndex: "scanType",
            hideable: false,
            sortable: true,
            width: 50,
            renderer: function(l, i, k, h, j, g) {
                var f;
                if ("realtime" === l) {
                    f = SYNO.SDS.SecurityScan._V("helptoc", "securityscan_idprotection_name")
                } else {
                    f = SYNO.SDS.SecurityScan._V("helptoc", "securityscan_result_name")
                }
                return this.tplAdd(f, f)
            },
            scope: this
        }, {
            header: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_label_category"),
            dataIndex: "category",
            hideable: false,
            width: 50,
            sortable: true,
            renderer: function(k, h, j, g, i, f) {
                k = SYNO.SDS.SecurityScan._V("securityscan", "securityscan_category_" + k);
                return this.tplAdd(k, k)
            },
            scope: this
        }, {
            header: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_label_desc"),
            dataIndex: "strId",
            sortable: true,
            renderer: function(i, k, j, n, f, l) {
                var m;
                if ("realtime" === j.get("scanType")) {
                    var o = new SYNO.SDS.SecurityScan.SettingsConfigurable(j.get("id"));
                    i = this.mainWindow.getTooltipStringKeyVal(i, "desc", j.get("strSection"));
                    m = i;
                    if (o.check()) {
                        var h = j.get("config");
                        var g = i;
                        i = o.render(g, h);
                        m = o.render(g, h, function(p) {
                            return String.format('<a class="link securityscan-link" tabindex="-1"><b><{0}></b></a>', p)
                        })
                    }
                } else {
                    if ("pass" === j.get("status")) {
                        i = this.mainWindow.getTooltipStringKeyVal(i, "desc_good")
                    } else {
                        if ("running" === j.get("status")) {
                            i = this.mainWindow.getTooltipStringKeyVal(i, "desc_running")
                        } else {
                            i = this.mainWindow.getTooltipStringKeyVal(i, "desc_bad")
                        }
                    }
                    m = i
                }
                return this.tplAdd(i, m)
            },
            scope: this,
            width: 200
        }];
        var e = new Ext.Toolbar({
            defaultType: "syno_button",
            items: [{
                text: _T("securityscan", "view"),
                itemId: "view",
                id: this.viewBtnID = Ext.id(),
                disabled: true,
                tooltip: _T("securityscan", "view"),
                scope: this,
                handler: function(g, f) {
                    this.openDetailDialog()
                }
            }]
        });
        var a = new SYNO.ux.GridPanel({
            tbar: e,
            title: "SYNO.ux.GridPanel",
            plugins: [this.enableColumn],
            store: this.customListStore,
            columns: c,
            height: 455,
            listeners: {
                rowclick: function(f, h, g) {
                    Ext.getCmp(this.viewBtnID).enable()
                },
                rowdblclick: function(f, g) {
                    this.openDetailDialog()
                },
                cellclick: function(h, j, i, g) {
                    if (!g.getTarget("a", this.body)) {
                        return
                    }
                    var f = this.customListStore.getAt(j);
                    this.onConfigLinkClick(f)
                },
                scope: this
            }
        });
        return a
    },
    onConfigLinkClick: function(a) {
        var b = new SYNO.SDS.SecurityScan.SettingsPanel.AlertConfigDialog({
            owner: this,
            record: a
        });
        b.open()
    },
    valBeauty: function(c, b) {
        if ("" === c) {
            return c
        }
        if ("status" === b) {
            var a = '<div class="securityscan-result securityscan-result-{0}"></div>';
            if ("nonChecked" === c) {
                c = '<div style="text-align: center; font-size: 20px;"><font class="blue-status">-</font></div>'
            } else {
                if ("skip" === c) {
                    c = '<div style="text-align: center; "><font class="orange-status">' + SYNO.SDS.SecurityScan._V("securityscan", "securityscan_result_skip") + "</div>"
                } else {
                    c = String.format(a, c)
                }
            }
        }
        return c
    },
    customListSave: function() {
        var a = "";
        var d = [];
        var b = [];
        var e = true,
            c = true;
        this.customListStore.each(function(f) {
            if (f.data.enabled) {
                e = false;
                if ("realtime" !== f.data.scanType) {
                    c = false
                }
            }
        });
        if (e) {
            this.getMsgBox().alert("securityscan", SYNO.SDS.SecurityScan._V("securityscan", "securityscan_alert_non_items"));
            return
        }
        if (c) {
            this.getMsgBox().alert("securityscan", SYNO.SDS.SecurityScan._V("securityscan", "securityscan_alert_non_scan_items"));
            return
        }
        if (!this.isStoreChanged()) {
            this.close()
        }
        this.customListStore.each(function(g) {
            if (g.data.enabled) {
                if ("realtime" === g.data.scanType) {
                    var f = {};
                    f.analyzer = g.data.id.split(".")[0];
                    f.label = g.data.id.split(".")[1];
                    d.push(f)
                } else {
                    a += " " + g.data.id
                }
            }
        });
        b.push({
            api: "SYNO.Core.SecurityScan.Conf",
            method: "group_set",
            version: 1,
            params: {
                items: a
            }
        });
        b.push({
            api: "SYNO.SecurityAdvisor.Conf.Checklist",
            method: "set",
            version: 1,
            params: {
                items: d
            }
        });
        this.setStatusBusy({
            text: _T("common", "saving")
        });
        this.sendWebAPI({
            compound: {
                mode: "parallel",
                params: b
            },
            scope: this,
            callback: function(h, g, f) {
                if (h && !g.has_fail) {
                    this.ownerForm.setValues({
                        scanGroup: "custom"
                    });
                    this.parentObj.originalScanGroup = "custom";
                    this.mainWindow.defGroup = "custom";
                    this.mainWindow.onStatusPolling("ALL");
                    this.mainWindow.onSysStatusPolling();
                    this.close()
                } else {
                    this.getMsgBox().alert("securityscan", SYNO.SDS.SecurityScan._V("error", "error_error_system"))
                }
                this.clearStatusBusy()
            }
        })
    },
    isStoreChanged: function() {
        if (0 < this.customListStore.getModifiedRecords().length) {
            return true
        } else {
            return false
        }
    },
    tplAdd: function(b, a) {
        b = Ext.util.Format.htmlEncode(b);
        b = b.replace("'", "&lsquo;");
        return '<div ext:qtip="' + b + '">' + a + "</div>"
    },
    oncancel: function() {
        if (!this.isStoreChanged() || "custom" != this.group) {
            this.close()
        } else {
            this.confirmLostChangePromise({
                save: this.customListSave,
                cancel: Ext.emptyFn,
                dontSave: function() {
                    this.close()
                }
            }, this);
            return false
        }
    },
    openDetailDialog: function() {
        var a = new SYNO.SDS.SecurityScan.ResultPanel.DetailDialog({
            module: this.module,
            owner: this.owner,
            seletedItem: this.gridPanel.getSelectionModel().getSelected().data
        });
        a.open()
    },
    onStoreLoadDone: function(f) {
        var d = [];
        var c = f.result[0].data[this.mainWindow.respDataRoot];
        var a = f.result[1].data[this.mainWindow.respDataRoot];
        if ("" !== c && 0 < c.length) {
            d = d.concat(c)
        }
        if ("" !== a && 0 < a.length) {
            for (var b = 0; b < a.length; ++b) {
                var e = a[b];
                d.push({
                    scanType: "realtime",
                    id: e.analyzer + "." + e.label,
                    analyzer: e.analyzer,
                    label: e.label,
                    severity: e.severity,
                    category: e.category,
                    strId: e.str_id,
                    strSection: e.str_section,
                    config: e.config,
                    enabled: e.enable
                })
            }
        }
        this.customListStore.loadData(d, false)
    },
    onOpen: function() {
        var a = [];
        a.push({
            api: "SYNO.Core.SecurityScan.Conf",
            method: "group_enum",
            version: 1,
            params: {
                argGroup: this.group
            }
        });
        a.push({
            api: "SYNO.SecurityAdvisor.Conf.Checklist",
            method: "list",
            version: 1,
            params: {
                group: this.group
            }
        });
        this.setStatusBusy();
        this.sendWebAPI({
            compound: {
                mode: "parallel",
                params: a
            },
            scope: this,
            callback: function(d, c, b) {
                if (d && !c.has_fail) {
                    this.onStoreLoadDone(c)
                } else {
                    this.getMsgBox().alert("securityscan", SYNO.SDS.SecurityScan._V("error", "error_error_system"))
                }
                this.clearStatusBusy()
            }
        });
        this.callParent(arguments)
    }
});
Ext.define("SYNO.SDS.SecurityScan.SettingsPanel.AlertConfigDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(b) {
        this.configurable = new SYNO.SDS.SecurityScan.SettingsConfigurable(b.record.get("id"));
        this.formPanel = this.createFormPanel(b.record);
        var a = {
            title: this.configurable.dialogTitle,
            width: 500,
            height: 120 + 30 * this.configurable.configKeys.length,
            cls: "seucrityscan-alertconfigdialog",
            layout: "fit",
            items: [this.formPanel],
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "alt_close"),
                scope: this,
                handler: this.close
            }, {
                xtype: "syno_button",
                text: _T("common", "alt_apply"),
                btnStyle: "blue",
                scope: this,
                handler: this.onApply
            }]
        };
        Ext.apply(a, b);
        this.callParent([a])
    },
    createFormPanel: function(a) {
        var c = a.get("config");
        var b = [];
        Ext.each(this.configurable.configKeys, function(d) {
            var e = {
                xtype: "syno_numberfield",
                fieldLabel: d.label,
                name: d.name,
                value: c[d.name],
                minValue: d.minValue,
                maxValue: d.maxValue
            };
            b.push(e)
        });
        return new SYNO.SDS.Utils.FormPanel({
            border: false,
            items: b
        })
    },
    onApply: function() {
        var b = this.formPanel.getForm();
        if (!b.isDirty()) {
            this.close();
            return
        }
        if (!b.isValid()) {
            this.setStatusError({
                text: _T("common", "forminvalid")
            });
            return
        }
        var a = {};
        Ext.each(this.configurable.configKeys, function(c) {
            var e = c.name;
            var d = b.findField(e);
            a[e] = d.getValue()
        }, this);
        this.setStatusBusy({
            text: _T("common", "saving")
        });
        this.sendWebAPI({
            api: "SYNO.SecurityAdvisor.Conf.Checklist.Alert",
            method: "set",
            version: 1,
            params: {
                analyzer: this.record.get("analyzer"),
                label: this.record.get("label"),
                config: a
            },
            scope: this,
            callback: function(f, d, c) {
                this.clearStatusBusy();
                if (!f) {
                    var e = SYNO.API.Errors.core[d.code] || _T("common", "error_system");
                    this.getMsgBox().alert(null, e);
                    return
                }
                this.record.set("config", a);
                this.close()
            }
        })
    }
});
Ext.define("SYNO.SDS.SecurityScan.ResultPanel.DetailDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(b) {
        this.module = b.module;
        this.owner = b.owner;
        this.mainWindow = SYNO.SDS.SecurityScan.Window;
        this.data = b.seletedItem;
        this.panel = this.createPanel();
        this.form = this.panel.getForm();
        var a = {
            loadMask: true,
            width: 620,
            height: 500,
            resizable: true,
            title: SYNO.SDS.SecurityScan._V("securityscan", "event"),
            items: [this.panel],
            buttons: [{
                text: _T("common", "alt_close"),
                scope: this,
                handler: this.close
            }]
        };
        Ext.apply(a, b);
        this.callParent([a])
    },
    createPanel: function() {
        var j, e, b;
        if ("realtime" === this.data.scanType) {
            j = SYNO.SDS.SecurityScan._V("securityscan", "idprotection_severity_" + this.data.severity);
            e = this.mainWindow.getStringKeyVal(this.data.strId, "desc", this.data.strSection);
            b = this.mainWindow.getStringKeyVal(this.data.strId, "purpose", this.data.strSection);
            var g = new SYNO.SDS.SecurityScan.SettingsConfigurable(this.data.id);
            if (g.check()) {
                e = g.render(e, this.data.config)
            }
        } else {
            j = SYNO.SDS.SecurityScan._V("securityscan", "securityscan_severity_" + this.data.severity);
            e = this.data.status === "pass" ? this.mainWindow.getStringKeyVal(this.data.strId, "desc_good") : this.mainWindow.getStringKeyVal(this.data.strId, "desc_bad");
            b = this.mainWindow.getStringKeyVal(this.data.strId, "purpose")
        }
        var c = {
            xtype: "syno_fieldset",
            collapsible: false,
            items: [{
                xtype: "syno_displayfield",
                fieldLabel: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_label_level"),
                scope: this,
                value: j
            }, {
                xtype: "syno_displayfield",
                fieldLabel: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_label_desc"),
                scope: this,
                value: e,
                htmlEncode: false
            }]
        };
        var a = {
            xtype: "syno_fieldset",
            title: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_detail_purpose"),
            collapsible: false,
            items: [{
                xtype: "syno_displayfield",
                scope: this,
                value: b,
                htmlEncode: false
            }]
        };
        var h = [{
            xtype: "syno_displayfield",
            scope: this,
            value: this.actionStrGet(),
            htmlEncode: false
        }];
        h.push(this.actionMethodGet());
        var i = {
            xtype: "syno_fieldset",
            title: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_setting_action_title"),
            collapsible: false,
            items: h
        };
        var f = [c, a];
        if ("fail" === this.data.status) {
            f.push(i)
        }
        var d = {
            border: false,
            height: 406,
            padding: 0,
            items: f
        };
        return new SYNO.ux.FormPanel(d)
    },
    actionStrGet: function() {
        if (!this.data.action || "" === this.data.action || !this.data.action.actionKey) {
            return ""
        }
        var a, e, f, b, d;
        var c = /_T\([\"\' ]+(\w+)[\"\' ]+[, ]+[\"\' ]+(\w+)[\"\' ]+\)/g;
        var g = this.mainWindow.getStringKeyVal(this.data.strId, this.data.action.actionKey);
        for (var h in this.data.action.actionVar) {
            if (this.data.action.actionVar.hasOwnProperty(h)) {
                d = this.data.action.actionVar[h];
                e = d;
                while ((a = c.exec(d))) {
                    if (3 !== a.length) {
                        continue
                    }
                    f = a[1];
                    b = a[2];
                    e = e.replace(a[0], _T(f, b))
                }
                e = '<font class="securityscan-severity-font-highlight">' + e + "</font>";
                var i = new RegExp(h, "g");
                g = g.replace(i, e)
            }
        }
        return g
    },
    actionMethodGet: function() {
        var c;
        var f = this.data.method.methodAction;
        if (!this.data.method) {
            return ""
        }
        if ("link" === f) {
            var a, g, k;
            var j = this.data.method.methodActionVal;
            j = j.split(":");
            var e = j[0];
            var d = j[1];
            var b = this.data.method.methodLinkOpenAppStr;
            var i = function() {};
            if (!b) {
                a = ["tree", "leaf_control_panel"]
            } else {
                a = b.split(":")
            }
            if (2 == a.length) {
                g = _T.apply(null, a)
            } else {
                g = _TT.apply(null, a)
            }
            if (2 < j.length) {
                var h = j[2];
                c = '<a id="' + Ext.id() + '" class="link-font" href="#">' + g + "</a>";
                i = function(l) {
                    l.preventDefault();
                    SYNO.SDS.AppLaunch(e, {
                        fn: d,
                        tab: h
                    })
                }
            } else {
                c = '<a id="' + Ext.id() + '" class="link-font" href="#">' + g + "</a>";
                i = function(l) {
                    l.preventDefault();
                    SYNO.SDS.AppLaunch(e, {
                        fn: d
                    })
                }
            }
            k = String.format(SYNO.SDS.SecurityScan._V("securityscan", "securityscan_setting_link"), c);
            return [{
                xtype: "syno_displayfield",
                scope: this,
                value: k,
                htmlEncode: false,
                listeners: {
                    afterRender: function(m) {
                        var l = m.el.first("a");
                        if (l) {
                            l.addListener("click", i)
                        }
                    }
                }
            }]
        } else {
            if ("fixme" === f) {
                return [{
                    xtype: "syno_button",
                    text: SYNO.SDS.SecurityScan._V("securityscan", "securityscan_btn_fixme"),
                    id: this.fixmeBtnID = Ext.id(),
                    scope: this,
                    disabled: _S("demo_mode"),
                    handler: this.doFixmeItem
                }]
            }
        }
    },
    doFixmeItem: function() {
        this.setStatusBusy();
        this.mainWindow.doScan("fixme", this.data.id);
        this.close()
    }
});
Ext.ns("SYNO.SDS.SecurityScan");
/**
 * @class SYNO.SDS.SecurityScan.Instance
 * @extends SYNO.SDS.AppInstance
 * SecurityScan application instance class
 *
 */
Ext.define("SYNO.SDS.SecurityScan.Instance", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.SecurityScan.MainWindow"
});
SYNO.SDS.SecurityScan._V = function(b, a) {
    if ("rules" === b) {
        return _TT("SYNO.SDS.SecurityScan.Instance", b, a)
    } else {
        return _T(b, a)
    }
};
SYNO.SDS.SecurityScan._T = function(d, g, f, e) {
    var c = SYNO.SDS.SecurityScan._V(d, g);
    var h = '<font class="securityscan-severity-font-highlight">{0}</font>';
    var a = function(m, l, k) {
        var j = new RegExp(l, "ig");
        if (e === true) {
            return m.replace(j, String.format(h, k))
        } else {
            return m.replace(j, k)
        }
    };
    var i = function() {
        for (var j in f) {
            if (f.hasOwnProperty(j)) {
                c = a(c, "__" + j + "__", f[j])
            }
        }
    };
    var b = function() {
        if (!f.country_code_list) {
            return
        }
        var k;
        if (f.country_code_list.length === 0) {
            if (f.has_any_public_src_ip) {
                k = _T("securityscan", "unknown_geoip_location")
            } else {
                k = _T("securityscan", "private_network")
            }
        } else {
            var j = [];
            Ext.each(f.country_code_list, function(l) {
                j.push(_T("Country", l))
            });
            k = j.join()
        }
        c = a(c, "__COUNTRY_LIST__", k)
    };
    i();
    b();
    return c
};
SYNO.SDS.SecurityScan.ResizePanel = function(b, e) {
    var d = 240;
    var a = 41;
    var c = d;
    var f = a;
    if (e) {
        b.container.setStyle("padding", "16px 20px 16px 20px");
        c += 40
    } else {
        b.container.setStyle("padding", "16px 16px 0px 16px");
        c += 32;
        f += 16
    }
    b.container.setSize(b.appWin.getWidth() - d, b.appWin.getHeight() - a);
    b.setSize(b.appWin.getWidth() - c, b.appWin.getHeight() - f);
    b.doLayout()
};
Ext.define("SYNO.SDS.SecurityScan.MainWindow", {
    extend: "SYNO.SDS.PageListAppWindow",
    width: 990,
    height: 544,
    respDataRoot: "items",
    sysNeedUpdate: true,
    lastScanTime: "",
    sysStatusRunning: false,
    pollingEnabled: true,
    maxAlramSeverity: "",
    resultFilterID: "",
    resultFilterKey: "ALL",
    defGroup: "",
    showStatus: ["pass", "fail", "error", "running"],
    specialRulesStoreField: ["id", "exist", "isFail", "actionExtra"],
    sysStatusStoreField: ["category", "progress", "total", "failSeverity", "fail", "runningItem"],
    allItemsStoreField: ["id", "method", "severity", "category", "status", "action", "update", "strId", "severitySort"],
    totalCategories: ["malware", "systemCheck", "userInfo", "network", "update"],
    severitySort: {
        danger: 0,
        risk: 1,
        warning: 2,
        outOfDate: 3,
        info: 4
    },
    activePage: "SYNO.SDS.SecurityScan.OverviewPanel",
    constructor: function(a) {
        this.pageCt = new Ext.Panel({
            cls: "securityscan-overview-panel",
            layout: "card",
            padding: "16px 20px 16px 20px",
            border: false,
            frame: false,
            hideMode: "offsets",
            region: "center"
        });
        this.app = a.appWin;
        SYNO.SDS.SecurityScan.Window = this;
        this.specialRulesStore = new Ext.data.JsonStore({
            proxy: new Ext.data.MemoryProxy([]),
            fields: this.specialRulesStoreField,
            data: [{
                id: "ruleDB.Update.DSM.check_latest_dsm",
                exist: false,
                isFail: false,
                actionExtra: ""
            }, {
                id: "ruleDB.Update.Package.check_latest_pkg",
                exist: false,
                isFail: false,
                actionExtra: ""
            }, {
                id: "ruleDB.User.Password.top50000StrengthCheck",
                exist: false,
                isFail: false,
                actionExtra: ""
            }]
        });
        this.sysStatusStore = new Ext.data.JsonStore({
            proxy: new Ext.data.MemoryProxy([]),
            fields: this.sysStatusStoreField
        });
        this.allItemsStore = new Ext.data.JsonStore({
            sortInfo: {
                field: "status",
                direction: "ASC"
            },
            proxy: new Ext.data.MemoryProxy([]),
            fields: this.allItemsStoreField
        });
        var b = [{
            iconCls: "icon-securityscan-overview",
            text: SYNO.SDS.SecurityScan._V("helptoc", "securityscan_overview_name"),
            fn: "SYNO.SDS.SecurityScan.OverviewPanel",
            help: "SecurityScan/securityscan_overview.html"
        }, {
            iconCls: "icon-securityscan-securityscan",
            text: SYNO.SDS.SecurityScan._V("helptoc", "securityscan_result_name"),
            fn: "SYNO.SDS.SecurityScan.ResultPanel",
            help: "SecurityScan/securityscan_result.html"
        }, {
            iconCls: "icon-securityscan-loginanalysis",
            text: SYNO.SDS.SecurityScan._V("helptoc", "securityscan_idprotection_name"),
            fn: "SYNO.SDS.SecurityScan.IdProtectionPanel",
            help: "SecurityScan/securityscan_idprotection.html"
        }, {
            iconCls: "icon-securityscan-settings",
            text: SYNO.SDS.SecurityScan._V("common", "advanced"),
            fn: "SYNO.SDS.SecurityScan.SettingsPanel",
            disabled: "recovery_site" === _S("systemdr_role"),
            help: "SecurityScan/securityscan_advanced.html"
        }];
        var c = {
            cls: "syno-app-securityscan",
            width: this.width,
            height: this.height,
            minWidth: this.width,
            minHeight: this.height,
            resizable: true,
            listItems: b,
            listeners: {
                scope: this,
                beforeDestroy: function() {
                    if (SYNO.SDS.SecurityScan.Window) {
                        delete SYNO.SDS.SecurityScan.Window
                    }
                }
            }
        };
        return this.callParent([Ext.apply(c, a)])
    },
    onOpen: function(a) {
        this.timeDelayGet();
        this.callParent(a);
        this.sysStatusStore.loadData([], false);
        this.mon(this.getPageList().getSelectionModel(), "selectionchange", this.onSelectionModelChange, this);
        this.firstScanCheck()
    },
    firstScanCheck: function() {
        var a = {};
        a.api = "SYNO.Core.SecurityScan.Conf";
        a.method = "first_get";
        a.version = 1;
        a.params = {};
        this.firstQuery = true;
        this.apiSend.call(this, a, function(b) {
            if (b.firstScan || b.firstLogAnalyzer) {
                var c = this.pageCt.getComponent("SYNO.SDS.SecurityScan.OverviewPanel");
                c.openFirstScanDialog()
            } else {
                this.setStatusBusy();
                this.onStatusPolling("ALL");
                this.onSysStatusPolling();
                if (b.iscrack) {
                    this.getMsgBox().alert("securityScan_error", _T("securityscan", "framwork_modified_error"))
                }
            }
        })
    },
    getResultData: function() {
        return this.allItemsStore
    },
    onLoadResultDone: function(g) {
        var c, e, f;
        var j, a;
        var h, b, d;
        for (j in g) {
            if (g.hasOwnProperty(j)) {
                h = this.specialRulesStore.find("id", g[j].id);
                if (0 <= h) {
                    b = this.specialRulesStore.getAt(h);
                    b.beginEdit();
                    b.set("exist", true);
                    b.set("isFail", "fail" === g[j].status);
                    if (g[j].action && g[j].action.actionExtra) {
                        b.set("actionExtra", g[j].action.actionExtra)
                    }
                    b.endEdit()
                }
                c = this.allItemsStore.getById(g[j].id);
                if (c) {
                    c.beginEdit();
                    for (f = 0; f < this.allItemsStoreField.length; f++) {
                        e = this.allItemsStoreField[f];
                        if (g[j][e]) {
                            c.set(e, g[j][e])
                        }
                    }
                    c.data.severitySort = this.severitySort[g[j].severity];
                    c.endEdit()
                } else {
                    a = new Ext.data.Record(g[j]);
                    a.id = a.data.id;
                    a.data.severitySort = this.severitySort[g[j].severity];
                    this.allItemsStore.addSorted(a)
                }
            }
        }
        d = String.format("{0}_{1}", this.resultFilterID, this.resultFilterKey);
        this.storeFilter(d)
    },
    apiSend: function(a, d, c) {
        var b = function(f) {
            var e = null;
            if (f && c) {
                c.apply(this, [f])
            } else {
                this.onStatusPolling("ALL");
                this.onSysStatusPolling()
            }
            if (this.getMsgBox) {
                e = this.getMsgBox()
            } else {
                if (this.owner && this.owner.getMsgBox) {
                    e = this.owner.getMsgBox()
                } else {
                    return
                }
            }
            if (f && f.errinfo && f.errinfo.sec && f.errinfo.key) {
                e.alert("securityscan", SYNO.SDS.SecurityScan._V(f.errinfo.sec, f.errinfo.key))
            } else {
                e.alert("securityscan", SYNO.SDS.SecurityScan._V("error", "error_error_system"))
            }
        };
        a.scope = this;
        a.callback = function(g, f, e) {
            if (g && f.success) {
                d.apply(this, [f])
            } else {
                b.apply(this, [f])
            }
        };
        this.sendWebAPI(a)
    },
    onSysStatusPolling: function() {
        var a = {};
        var b = [];
        var c = this.pageCt.getComponent("SYNO.SDS.SecurityScan.OverviewPanel");
        a.api = "SYNO.Core.SecurityScan.Status";
        a.method = "system_get";
        a.version = 1;
        a.params = {};
        if (!this.pollingEnabled) {
            return
        }
        if (!this.firstQuery && !this.sysStatusRunning) {
            c.sysStatusSet("running");
            this.sysStatusRunning = true;
            this.sysStatusStore.loadData([], false)
        }
        this.apiSend.call(this, a, function(g) {
            var e = {};
            if (this.firstQuery) {
                this.firstQuery = false;
                this.clearStatusBusy()
            }
            if (!this.sysNeedUpdate || !c) {
                return
            }
            c.sysStatusSet(g.sysStatus, g.sysProgress);
            this.lastScanTime = g.lastScanTime;
            if (!g[this.respDataRoot]) {
                this.sysStatusStore.loadData([], false);
                this.getMsgBox().alert("TTT_securityScan_error", _T("error", "error_error_system"))
            } else {
                if (!c.getScanningTime()) {
                    c.setScanningTime(g.startTime)
                }
                c.maxAlramSeveritySet(g.maxAlarmSeverity);
                e = g[this.respDataRoot];
                for (var f in e) {
                    if (e.hasOwnProperty(f)) {
                        b.push(e[f])
                    }
                }
                this.sysStatusStore.loadData(b, false)
            }
            if (c.isRunningStatus(g.sysStatus)) {
                var d = this;
                setTimeout(function() {
                    d.onSysStatusPolling()
                }, 2000)
            } else {
                this.sysStatusRunning = false
            }
        }, function() {
            this.clearStatusBusy()
        })
    },
    onStatusPolling: function(a) {
        var b = {};
        b.api = "SYNO.Core.SecurityScan.Status";
        b.method = "rule_get";
        b.version = 1;
        b.params = {
            items: a
        };
        if (!this.pollingEnabled) {
            return
        }
        if ("ALL" === a) {
            this.specialRulesStore.each(function(c) {
                c.set("exist", false)
            });
            this.allItemsStore.removeAll(false)
        }
        this.apiSend.call(this, b, function(g) {
            var e = {};
            var f;
            var c = [];
            if (!g.isUpdating) {
                if (!g[this.respDataRoot]) {
                    this.onLoadResultDone({});
                    return
                }
                e = g[this.respDataRoot];
                for (f in e) {
                    if (e.hasOwnProperty(f)) {
                        if ("running" === e[f].status) {
                            c.push(e[f].id)
                        }
                    }
                }
                this.onLoadResultDone(e)
            }
            if (0 < c.length) {
                var d = this;
                setTimeout(function() {
                    var h;
                    h = c === "ALL" ? "ALL" : c.join(" ");
                    d.onStatusPolling(h)
                }, 2000)
            }
        })
    },
    doScan: function(f, d) {
        var c = {};
        var g = this.pageCt.getComponent("SYNO.SDS.SecurityScan.OverviewPanel");
        if (!g) {
            return
        }
        d = d.trim();
        c.api = "SYNO.Core.SecurityScan.Operation";
        c.method = f;
        c.version = 1;
        c.params = {
            items: d
        };
        g.sysStatusSet("running");
        this.sysStatusRunning = true;
        this.sysStatusStore.loadData([], false);
        g.overviewBtnSet(true);
        if ("ALL" !== d) {
            var a = d.split(" ");
            var e, b;
            for (b = 0; b < a.length; b++) {
                e = this.allItemsStore.find("id", a[b]);
                if (0 <= e) {
                    this.allItemsStore.getAt(e).set("update", "");
                    this.allItemsStore.getAt(e).set("status", "running")
                }
            }
        }
        this.apiSend.call(this, c, function(h) {
            g.overviewBtnSet(false);
            this.onStatusPolling(c.params.items);
            this.onSysStatusPolling()
        }, function(h) {
            g.overviewBtnSet(false);
            this.onStatusPolling(c.params.items);
            this.onSysStatusPolling()
        })
    },
    doStartScan: function(a) {
        var b = {};
        var c = this.pageCt.getComponent("SYNO.SDS.SecurityScan.OverviewPanel");
        if (!c) {
            return
        }
        if ("ALL" === a) {
            c.overviewBtnSet(true);
            c.sysStatusSet("updating");
            this.sysStatusStore.loadData([], false);
            b.api = "SYNO.Core.SecurityScan.Operation";
            b.method = "update";
            b.version = 1;
            b.params = {
                lang: _S("lang")
            };
            this.apiSend.call(this, b, function(d) {
                if (d.lang) {
                    SYNO.SDS.Strings["SYNO.SDS.SecurityScan.Instance"].rules = d.lang.rules
                }
                this.doScan("start", "ALL")
            }, function(d) {
                this.doScan("start", "ALL")
            })
        } else {
            this.doScan("start", a)
        }
    },
    doStopScan: function(a) {
        var b = {};
        var c = this.pageCt.getComponent("SYNO.SDS.SecurityScan.OverviewPanel");
        if (!c) {
            return
        }
        b.api = "SYNO.Core.SecurityScan.Operation";
        b.method = "stop";
        b.version = 1;
        b.params = {
            items: a
        };
        c.sysStatusSet("stopping");
        this.pollingEnabled = false;
        this.sysNeedUpdate = false;
        c.overviewBtnSet(true);
        c.overviewStatusAreaSet();
        this.apiSend.call(this, b, function(d) {
            this.sysNeedUpdate = true;
            this.pollingEnabled = true;
            this.onSysStatusPolling();
            this.onStatusPolling("ALL");
            c.overviewBtnSet(false)
        })
    },
    onClose: function() {
        var a = this.pageCt.getComponent("SYNO.SDS.SecurityScan.OverviewPanel");
        this.pollingEnabled = false;
        a.stopIconAnimate("");
        a.stopOverviewStatusElapsedTime(true);
        return this.callParent()
    },
    getTooltipStringKeyVal: function(c, a, b) {
        return this.getStringKeyVal(c, a, b, true)
    },
    getStringKeyVal: function(f, b, c, d) {
        var e = f + "_" + b;
        var a = c ? c : "rules";
        return SYNO.SDS.SecurityScan._V(a, e).split(new RegExp("<b>(.*?)</b>", "gs")).map(function(h, g) {
            h = Ext.util.Format.htmlEncode(h);
            if (0 !== g % 2) {
                h = String.format(d ? "<b>{0}</b>" : '<font class="securityscan-severity-font-highlight">{0}</font>', h)
            }
            return h
        }).join("")
    },
    specialRuleRecordCheck: function(d, c) {
        var a, b;
        a = this.specialRulesStore.find("id", d);
        if (0 <= a) {
            b = this.specialRulesStore.getAt(a);
            if (c) {
                if (b.get("exist")) {
                    return b
                } else {
                    return false
                }
            }
            return b
        }
        return false
    },
    timeDelayGet: function() {
        var b = {};
        b.api = "SYNO.Core.SecurityScan.Conf";
        b.method = "time_get";
        b.version = 1;
        b.params = {};
        var a = new Date();
        this.apiSend.call(this, b, function(c) {
            this.timeDelay = a.getTime() / 1000 - c.curTime
        })
    },
    diffSecsGet: function(c) {
        var a = new Date();
        var b = Date.UTC(a.getUTCFullYear(), a.getUTCMonth(), a.getUTCDate(), a.getUTCHours(), a.getUTCMinutes(), a.getUTCSeconds());
        b /= 1000;
        if (this.timeDelay) {
            return parseInt(b - c - this.timeDelay, 10)
        } else {
            return parseInt(b - c, 10)
        }
    },
    timeRender: function(c, a) {
        if (!c || isNaN(c)) {
            return ""
        }
        var b = 0;
        var d = this.diffSecsGet(c);
        var j = " " + SYNO.SDS.SecurityScan._V("securityscan", "securityscan_second");
        var g = " " + SYNO.SDS.SecurityScan._V("securityscan", "securityscan_minute");
        var e = " " + SYNO.SDS.SecurityScan._V("securityscan", "securityscan_hour");
        var l = " " + SYNO.SDS.SecurityScan._V("securityscan", "securityscan_day");
        var h = [{
            val: 1,
            limit: 60,
            str: j
        }, {
            val: 0,
            limit: 60,
            str: g
        }, {
            val: 0,
            limit: 24,
            str: e
        }, {
            val: 0,
            str: l
        }];
        for (var m = 0; m < h.length; m++) {
            if (0 < d) {
                if (h[m].limit) {
                    h[m].val = d % h[m].limit;
                    d /= h[m].limit;
                    d = parseInt(d, 10);
                    b = m
                } else {
                    h[m].val = d;
                    b = m;
                    break
                }
            }
        }
        if (a) {
            return h[b].val + h[b].str
        } else {
            var f = "";
            for (var k = b; k >= 0; k--) {
                f += h[k].val + h[k].str + " "
            }
            return f
        }
    },
    storeFilter: function(b) {
        var a = "",
            c;
        if (this.resultFilterID + "_ALL" === b) {
            this.allItemsStore.clearFilter(false);
            this.allItemsStore.filterBy(function(d, e) {
                if (0 > this.showStatus.indexOf(d.get("status"))) {
                    return false
                } else {
                    return true
                }
            }, this)
        } else {
            a = "category";
            c = b.split("_")[1];
            this.resultFilterKey = c;
            this.allItemsStore.filterBy(function(d, e) {
                if (0 <= this.showStatus.indexOf(d.get("status")) && c === d.get(a)) {
                    return true
                } else {
                    return false
                }
            }, this)
        }
        this.allItemsStore.sort("severitySort", "ASC");
        this.allItemsStore.sort("status", "ASC")
    },
    onSelectionModelChange: function() {
        var a = this.getActivePage();
        if (!a) {
            return
        }
        if ("SYNO.SDS.SecurityScan.OverviewPanel" === a.itemId) {
            this.getPageCt().addClass("securityscan-overview-panel")
        } else {
            this.getPageCt().removeClass("securityscan-overview-panel")
        }
    }
});
