/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function _slicedToArray(t, e) {
    return _arrayWithHoles(t) || _iterableToArrayLimit(t, e) || _nonIterableRest()
}

function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance")
}

function _iterableToArrayLimit(t, e) {
    var i = [],
        a = !0,
        n = !1,
        s = void 0;
    try {
        for (var r, o = t[Symbol.iterator](); !(a = (r = o.next()).done) && (i.push(r.value), !e || i.length !== e); a = !0);
    } catch (t) {
        n = !0, s = t
    } finally {
        try {
            a || null == o.return || o.return()
        } finally {
            if (n) throw s
        }
    }
    return i
}

function _arrayWithHoles(t) {
    if (Array.isArray(t)) return t
}

function asyncGeneratorStep(t, e, i, a, n, s, r) {
    try {
        var o = t[s](r),
            l = o.value
    } catch (t) {
        return void i(t)
    }
    o.done ? e(l) : Promise.resolve(l).then(a, n)
}

function _asyncToGenerator(t) {
    return function() {
        var e = this,
            i = arguments;
        return new Promise(function(a, n) {
            var s = t.apply(e, i);

            function r(t) {
                asyncGeneratorStep(s, a, n, r, o, "next", t)
            }

            function o(t) {
                asyncGeneratorStep(s, a, n, r, o, "throw", t)
            }
            r(void 0)
        })
    }
}

function _typeof(t) {
    return (_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
        return typeof t
    } : function(t) {
        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
    })(t)
}
Ext.ns("SYNO.SDS.PkgManApp.Utils"), SYNO.SDS.PkgManApp.Utils.Helper = {
    T: function(t, e) {
        return e ? _T(t, e) : _T("pkgmgr", t)
    },
    getAbsoluteURL: function(t, e) {
        var i = SYNO.SDS.PkgManApp.Window.jsConfig.jsBaseURL;
        return t ? e ? [i, e, t].join("/") : [i, t].join("/") : i
    },
    getIconFromServer: function(t, e, i) {
        i = i || !0;
        var a, n = 64 === (e = e || 64),
            s = SYNO.API.currentManager.getBaseURL("SYNO.Core.Package.Thumb.Server", "get", 1),
            r = SYNO.SDS.UIFeatures.test("isRetina");
        if (r) a = SYNO.SDS.PkgManApp.Utils.Helper.getAbsoluteURL(SYNO.SDS.PkgManApp.Config.DEFICON_256);
        else {
            var o = n ? SYNO.SDS.PkgManApp.Config.DEFICON_64 : SYNO.SDS.PkgManApp.Config.DEFICON_256;
            a = SYNO.SDS.PkgManApp.Utils.Helper.getAbsoluteURL(o)
        }
        return r && !Ext.isEmpty(t.thumbnail_retina) && t.thumbnail_retina[0] ? a = Ext.urlAppend(s, Ext.urlEncode(SYNO.API.EncodeParams({
            name: t.id,
            ver: t.version,
            link: n ? t.thumbnail_retina[0] : t.thumbnail_retina[1] || t.thumbnail_retina[0],
            size: n ? 128 : 256,
            bls: i
        }))) : !Ext.isEmpty(t.thumbnail) && t.thumbnail[0] ? a = Ext.urlAppend(s, Ext.urlEncode(SYNO.API.EncodeParams({
            name: t.id,
            ver: t.version,
            link: n ? t.thumbnail[0] : t.thumbnail[1] || t.thumbnail[0],
            size: e,
            bls: i
        }))) : t.icon && "" !== t.icon && (s === t.icon.substr(0, s.length) ? a = t.icon : "http://" === t.icon.substr(0, 7) ? a = window.location.protocol + t.icon.substr(5) : "https://" === t.icon.substr(0, 8) ? a = window.location.protocol + t.icon.substr(6) : Ext.isEmpty(t.icon) || (a = Ext.urlAppend(s, Ext.urlEncode(SYNO.API.EncodeParams({
            name: t.id,
            ver: t.version,
            size: e,
            bls: i
        }))))), a
    },
    getTransparentDataURI: function() {
        return "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVQYV2NgYAAAAAMAAWgmWQ0AAAAASUVORK5CYII="
    },
    getIconFromDS: function(t, e) {
        return e = e || 64, SYNO.SDS.UIFeatures.test("isRetina") && (e = 64 === e ? 128 : 256), Ext.urlAppend(SYNO.API.currentManager.getBaseURL("SYNO.Core.Package.Thumb", "get", 1), Ext.urlEncode(SYNO.API.EncodeParams({
            name: t.id,
            ver: t.version,
            size: e
        })))
    },
    hashCode: function(t) {
        var e = 0;
        if (0 === t.length) return e;
        for (var i = 0; i < t.length; i++) {
            e = (e << 5) - e + t.charCodeAt(i), e &= e
        }
        return e
    },
    versionCompare: function(t, e, i) {
        var a = e.split("-"),
            n = i.split("-"),
            s = a[0].split("."),
            r = n[0].split("."),
            o = 0,
            l = function(t, e) {
                var i = Math.max(t.length, e.length);
                t.push.apply(t, new Array(i - t.length).map(Number.prototype.valueOf, 0)), e.push.apply(e, new Array(i - e.length).map(Number.prototype.valueOf, 0))
            };
        l(s, r), 1 < a.length && s.push(a[1]), 1 < n.length && r.push(n[1]), l(s, r);
        for (var p = 0, g = s.length; p < g; p++) {
            if (Number(s[p]) > Number(r[p])) {
                o = 1;
                break
            }
            if (Number(s[p]) < Number(r[p])) {
                o = -1;
                break
            }
        }
        switch (t) {
            case "=":
                return 0 === o;
            case ">=":
                return o >= 0;
            case ">":
                return o > 0;
            case "<=":
                return o <= 0;
            case "<":
                return o < 0;
            default:
                return !1
        }
    },
    getCardWidth: function(t) {
        for (var e = 2; t > 250 * e + (e + 1);) e += 1;
        return (t - ((e -= 1) + 1)) / e
    },
    renderURL: function(t, e) {
        return String.format('<a target="_blank" href="{0}">{1}</a>', t, e || Ext.util.Format.htmlEncode(t))
    },
    getInstallationText: function(t, e, i, a, n) {
        return t ? this.T("status_installed") : e ? this.T("pkgmgr_pkg_upgrade") : i ? this.T("myds_pay_trail") : a ? this.T("myds_pay_buy") : n ? this.T("join_beta") : this.T("pkgmgr_pkg_install")
    },
    encodeMsg: function(t, e) {
        var i = t;
        return Ext.isDefined(t) ? e && (i = Ext.util.Format.stripTags(i)) : i = "", Ext.util.Format.htmlEncode(i)
    },
    getAdminPortUrl: function(t) {
        if (!t) return "";
        for (var e = "", i = 0; i < t.length; i++) e += String.format("<a href='{0}' target='_blank'>{0}</a>", t[0]), i > 0 && (e += ";");
        return e
    },
    getPriceFormatString: function(t, e) {
        var i, a = "";
        return Ext.isEmpty(t) || "object" !== _typeof(t) ? a : (i = e in t ? e : SYNO.SDS.PkgManApp.Config.DEFAULT_CURRENCY, a = String.format("{0} {1}", t[i], i))
    }
}, Ext.define("SYNO.SDS.PkgManApp.All.Banner", {
    extend: "Ext.DataView",
    helper: SYNO.SDS.PkgManApp.Utils.Helper,
    constructor: function(t) {
        SYNO.SDS.PkgManApp.Utils.Utils._initWinWrappers.call(this, t), this.callParent([this.fillConfig(t)]), this.mon(this.store, "load", this.onStoreLoad, this), this.mon(this._getSynoServerObj().store, "load", this.refresh, this), this.mon(this._getBetaServerObj().store, "load", this.refresh, this)
    },
    fillConfig: function(t) {
        this.tpl = this.createTpl();
        var e = {
            tpl: this.tpl,
            trackOver: !0,
            listeners: {
                click: this._onClick,
                mouseenter: this._onMouseEnter,
                afterrender: this.onAfterRender
            }
        };
        return Ext.apply(e, t), e
    },
    collectData: function(t, e) {
        var i = [];
        return Ext.each(t, function(t) {
            !SYNO.SDS.PkgManApp.Config.blBetaChannel && "package" === t.get("type") && t.get("beta") || "package" === t.get("type") && !t.get("beta") && Ext.isEmpty(this._getSynoServerObj().store.getById(t.get("keyword"))) || "package" === t.get("type") && t.get("beta") && Ext.isEmpty(this._getBetaServerObj().store.getById(t.get("keyword"))) || i.push(t.data)
        }, this), this.determineVisibility(i), i
    },
    determineVisibility: function(t) {
        0 < t.length ? this.show() : this.hide()
    },
    createTpl: function() {
        return new Ext.XTemplate("<div class=syno-pkg-banner-pager>", '<tpl for=".">', '<div class="button" data-target-id="{[xindex - 1]}">', "</div>", "</tpl>", "</div>", '<tpl for=".">', '<div class="syno-pkg-banner-item" data-keyword="{keyword}" data-type="{type}" data-link="{link}" data-beta="{beta}" style="background:url({[this.getBanner(values, xindex)]}) no-repeat;">', '<div style="{css_string}">', "<article>", '<div><img style="{css_icon}" src="{[this.getIcon(values, xindex)]}"/></div>', '<div style="{css_title}">{title}</div>', '<div style="{css_desc}">{descr}</div>', "</article>", '<div style="{css_triangle}"></div>', "</div>", "</div>", "</tpl>", {
            compiled: !0,
            disableFormats: !0,
            getIcon: this.getIcon.createDelegate(this),
            getBanner: this.getBanner.createDelegate(this)
        })
    },
    getBanner: function(t, e) {
        if (Ext.isEmpty(t.background)) return "";
        var i = SYNO.API.currentManager.getBaseURL("SYNO.Core.Package.Screenshot.Server", "get", 1);
        return Ext.urlAppend(i, Ext.urlEncode(SYNO.API.EncodeParams({
            name: "ReservedForBanner" + e,
            ver: this.helper.hashCode(t.background).toString(),
            link: t.background,
            index: this.helper.hashCode(t.background.substring(t.background.lastIndexOf("/") + 1))
        })))
    },
    getIcon: function(t, e) {
        if (Ext.isEmpty(t.icon)) return "";
        var i = SYNO.API.currentManager.getBaseURL("SYNO.Core.Package.Screenshot.Server", "get", 1);
        return Ext.urlAppend(i, Ext.urlEncode(SYNO.API.EncodeParams({
            name: "ReservedForBannerIcon" + e,
            ver: this.helper.hashCode(t.icon).toString(),
            link: t.icon,
            index: this.helper.hashCode(t.icon.substring(t.icon.lastIndexOf("/") + 1))
        })))
    },
    selectBanner: function(t) {
        this.getEl().select(".syno-pkg-banner-pager .button").each(function(e, i, a) {
            e.removeClass("selected"), a === t && e.addClass("selected")
        }, this), this.getEl().select(".syno-pkg-banner-item").each(function(e, i, a) {
            e.dom.style.display = "none", a === t && (e.dom.style.display = "block")
        }, this)
    },
    onStoreLoad: function() {
        this.selectBanner(0)
    },
    onAfterRender: function() {
        this.selectBanner(0)
    },
    _onClick: function(t, e, i) {
        var a = Ext.fly(i).findParent(".syno-pkg-banner-item");
        if (!Ext.isEmpty(a)) {
            var n, s = a.getAttribute("data-type"),
                r = a.getAttribute("data-keyword"),
                o = a.getAttribute("data-link"),
                l = a.getAttribute("data-beta");
            "url" === s && o ? window.open(o, "_blank", "") : "package" === s && r ? (n = "true" == l ? "SYNO.SDS.PkgManApp.Beta.Panel" : "SYNO.SDS.PkgManApp.All.Panel", SYNO.SDS.PkgManApp.Window.jumpTo(n, 1, r)) : "compilation" === s && r && (n = "SYNO.SDS.PkgManApp.SearchResult.Panel", SYNO.SDS.PkgManApp.Window.jumpTo(n, 0, null, r))
        }
    },
    _onMouseEnter: function(t, e, i) {
        var a = Ext.fly(i).findParent(".button");
        if (!Ext.isEmpty(a)) {
            var n = Number(a.getAttribute("data-target-id"));
            this.selectBanner(n)
        }
    },
    refresh: function() {
        this.callParent(arguments), this.onAfterRender()
    }
}), Ext.define("SYNO.SDS.PkgManApp.Detail.Status", {
    extend: "Ext.Container",
    helper: SYNO.SDS.PkgManApp.Utils.Helper,
    constructor: function(t) {
        SYNO.SDS.PkgManApp.Utils.Utils._initWinWrappers.call(this, t), this.callParent([this.fillConfig(t)])
    },
    fillConfig: function(t) {
        this.iconStore = this.createIconStore(), this.icon = this.createIcon(), this.statusArea = this.createStatusArea(), this.addTplRenderer();
        var e = {
            cls: "synopkg-detail-status",
            items: [this.icon, this.statusArea]
        };
        return Ext.apply(e, t), e
    },
    createIconStore: function() {
        return new Ext.data.JsonStore({
            autoDestroy: !0,
            fields: ["icon"]
        })
    },
    createIcon: function() {
        return new Ext.DataView({
            cls: "syno-pkg-detail-iconarea",
            tpl: new Ext.XTemplate('<tpl for=".">', '<img class="syno-pkg-icon-img" src="{[this.getTransparentDataURI()]}" style="background:url(\'{icon}\');background-size:128px;">', "</tpl>", {
                compiled: !0,
                disableFormats: !0,
                getTransparentDataURI: SYNO.SDS.PkgManApp.Utils.Helper.getTransparentDataURI.createDelegate(this)
            }),
            store: this.iconStore
        })
    },
    createStatusArea: function() {
        this.btnMenu = new SYNO.ux.Menu({
            cls: "synopkg-common-menu",
            items: [{
                text: this.helper.T("repair"),
                itemId: "repair",
                handler: this.onAction,
                scope: this
            }, {
                text: this.helper.T("pkgmgr_pkg_upgrade"),
                itemId: "upgrade",
                handler: this.onAction,
                scope: this
            }, {
                text: this.helper.T("common", "cancel"),
                itemId: "cancel",
                handler: this.onAction,
                scope: this
            }, {
                text: this.helper.T("pkgmgr_pkg_install"),
                itemId: "install",
                handler: this.onAction,
                scope: this
            }, {
                text: this.helper.T("open"),
                itemId: "open",
                handler: this.openPkg,
                scope: this
            }, {
                text: this.helper.T("pkgmgr_pkg_start"),
                itemId: "start",
                handler: this.startPkg,
                scope: this
            }, {
                text: this.helper.T("pkgmgr_pkg_stop"),
                itemId: "stop",
                handler: this.stopPkg,
                scope: this
            }, {
                text: this.helper.T("pkgmgr_pkg_uninstall"),
                itemId: "uninstall",
                handler: this.uninstallPkg,
                scope: this
            }, "-", {
                text: this.helper.T("auto_update_one"),
                itemId: "autoupdate",
                handler: this.toggleAutoUpdate,
                checked: !0,
                scope: this
            }]
        }), this.actionBtn = new SYNO.ux.SplitButton({
            text: this.helper.T("pkgmgr_pkg_install"),
            cls: "synopkg-detail-action-btn",
            minWidth: 124,
            handler: this.onAction,
            menu: this.btnMenu,
            scope: this
        }), this._isClickOnArrow = this.actionBtn.isClickOnArrow;
        var t = this;
        return new Ext.form.FormPanel({
            cls: "synopkg-detail-basic",
            itemId: "synopkg-detail-basic",
            hideLabels: !0,
            border: !1,
            clearCls: "",
            defaults: {
                xtype: "syno_displayfield"
            },
            items: [{
                cls: "synopkg-detail-basic-developer",
                name: "maintainer",
                value: "Synology"
            }, {
                itemCls: "synopkg-detail-basic-title-wrap",
                cls: "synopkg-detail-basic-title",
                name: "dname",
                setRawValue: function(e) {
                    var i = Ext.util.Format.htmlEncode(e);
                    return t.data.beta && (i += '<div class="synopkg-detail-basic-beta"></div>'), this.rendered ? this.el.dom.innerHTML = Ext.isEmpty(i) ? "" : i : this.value = i
                }
            }, {
                name: "status",
                itemCls: "synopkg-detail-basic-status-wrap",
                cls: "synopkg-detail-basic-status",
                setRawValue: function(e) {
                    var i = t.renderStatusOrCategories(e, t.data);
                    return this.rendered ? this.el.dom.innerHTML = Ext.isEmpty(i) ? "" : i : this.value = i
                }
            }, this.actionBtn, {
                itemCls: "synopkg-detail-basic-price-wrap",
                cls: "synopkg-detail-basic-price",
                name: "price",
                setRawValue: function(t) {
                    var e = Ext.util.Format.htmlEncode(SYNO.SDS.PkgManApp.Utils.Helper.getPriceFormatString(t, SYNO.SDS.PkgManApp.Window.synoAccountInfo.currency));
                    return this.rendered ? this.el.dom.innerHTML = Ext.isEmpty(e) ? "" : e : this.value = e
                }
            }, {
                itemCls: "synopkg-detail-basic-download-count-wrap",
                cls: "synopkg-detail-basic-download-count",
                name: "download_count",
                setRawValue: function(e) {
                    var i, a = t.data.price,
                        n = Ext.isEmpty(a) || "object" !== _typeof(a) ? "" : " / ",
                        s = "";
                    return Ext.isEmpty(e) || (i = Ext.isNumber(e) ? Ext.util.Format.number(e, "0,000") : e, s = n + t.helper.T("download_count") + " : " + i), this.rendered ? this.el.dom.innerHTML = Ext.isEmpty(s) ? "" : s : this.value = s
                }
            }]
        })
    },
    addTplRenderer: function() {
        this.icon.tpl.getIcon = this.getIcon
    },
    setStatusValue: function(t) {
        var e = this.statusArea.getForm();
        this.setActionBtn(), e.setValues(t)
    },
    _setHandler: function(t, e, i) {
        var a = i || null;
        t.setText(e), t.setHandler(a, this)
    },
    setActionBtn: function() {
        var t = this,
            e = this.actionBtn,
            i = this.btnMenu.items,
            a = this.data,
            n = [];
        e.enable(), this._setBtnAppearance(e, !0), e.menu = this.btnMenu, "stop" === a.status && _S("is_admin") && n.push("start"), "running" === a.status && !0 === a.pkgstartable && _S("is_admin") && n.push("stop"), (a.ctl_uninstall || "broken" === a.status && "arch" === a.broken_by) && _S("is_admin") && n.push("uninstall"), SYNO.SDS.PkgManApp.Utils.Utils.IsAutoUpdatable(a) && (n.push("autoupdate"), n.push(i.getCount() - 2), this.updateAutoUpdateUI(i, a.autoupdate));
        var s = this._getOperationInfo(a, this.panelName);
        switch (s.action) {
            case "open":
                n.push("open");
                break;
            case "repair":
                n.push("repair");
                break;
            case "upgrade":
                n.push("upgrade"), "running" === a.status && SYNO.SDS.PkgManApp.Utils.Utils.IsPkgOpenable(a) && n.push("open");
                break;
            case "install":
                _S("is_admin") && n.push("install");
                break;
            case "cancel":
                (n = []).push("cancel"), s.isButtonDisabled && e.disable()
        }
        "doing" === a.statusDesktop && "queueing" !== a.status && ("installing" === a.status ? (this._setHandler(e, _T("pkgmgr", "pkgmgr_pkg_install")), e.disable()) : (this._setHandler(e, _T("pkgmgr", a.status)), e.disable()));
        for (var r = 0, o = i.getCount(); r < o; r++) i.get(r).hide();
        if (0 === (n = n.filter(function(t, e) {
                return n.indexOf(t) === e
            })).length) this._setHandler(e, this.helper.T("pkgmgr", "status_installed")), e.disable();
        else if (1 === n.length) {
            var l = i.get(n[0]).text;
            "install" === n[0] && (l = this.helper.getInstallationText(!1, !1, !this.isCommunity() && a && 0 !== a.type && Ext.isEmpty(a.status) && !a.price, SYNO.SDS.PkgManApp.Utils.Utils.isBuyable(a) && !this.isCommunity(), this.data.beta)), this._setBtnAppearance(e, !1), this._setHandler(e, l, i.get(n[0]).handler)
        } else if (2 === n.length && this.data.silent_upgrade) this._setHandler(e, this.helper.T("common", "action"), function() {
            t.actionBtn.hasVisibleMenu() || t.actionBtn.ignoreNextClick ? t.actionBtn.hideMenu() : t.actionBtn.showMenu()
        }), n.forEach(function(t) {
            var e = i.get(t);
            e.itemId && e.show()
        }, this);
        else {
            var p = !0;
            i.items.forEach(function(t) {
                t.itemId ? (!t.itemId || -1 < n.indexOf(t.itemId)) && (p ? (this._setHandler(e, t.text, t.handler), p = !1) : t.show()) : 3 < n.length && this.data.silent_upgrade && t.show()
            }, this)
        }
    },
    _setBtnAppearance: function(t, e) {
        var i = t.getEl();
        e ? (i.select(".x-btn-split").first().setStyle("background-size", null), i.select(".x-btn-split").first().setStyle("padding-left", null), i.select(".arrow").first().setStyle("display", null), t.isClickOnArrow = this._isClickOnArrow) : (i.select(".x-btn-split").first().setStyle("background-size", 0), i.select(".x-btn-split").first().setStyle("padding-left", "18px"), i.select(".arrow").first().setStyle("display", "none"), t.isClickOnArrow = function() {
            return !1
        })
    },
    getIcon: function(t, e) {
        var i = this._getInstalledStore().getById(t.id);
        return i && i.data.version === t.version && i.data.dname ? this.helper.getIconFromDS(t, e) : this.getIconFromServerOrDSM(t, e)
    },
    onLoadData: function(t) {
        this.data = t, this.pkgname = t.id, this.iconStore.loadData([{
            icon: this.getIcon(t, 128)
        }]), this.setStatusValue(t)
    },
    openPkg: function() {
        SYNO.SDS.PkgManApp.Utils.Utils.OpenPkgApp(this.data)
    },
    startPkg: function() {
        var t = this._getInstalledStore().getById(this.pkgname);
        t && this._onStartPkg(t)
    },
    stopPkg: function() {
        var t = this._getInstalledStore().getById(this.pkgname);
        t && this._onStopPkg(t)
    },
    uninstallPkg: function() {
        var t = _asyncToGenerator(regeneratorRuntime.mark(function t() {
            var e;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        (e = this._getInstalledStore().getById(this.pkgname)) && this._onUninstallPkg(e);
                    case 2:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }));
        return function() {
            return t.apply(this, arguments)
        }
    }(),
    onAction: function() {
        var t = this._getOperationInfo(this.data, this.panelName);
        t.actionFunction && t.actionFunction()
    },
    toggleAutoUpdate: function(t) {
        var e = this,
            i = !t.checked;
        t.disable(), this.sendWebAPIPromise({
            single: !0,
            api: "SYNO.Core.Package.Setting.Update",
            method: i ? "add" : "delete",
            version: 1,
            params: {
                id: this.pkgname
            }
        }).then(function(t) {
            var a = e.btnMenu.items;
            e.updateAutoUpdateUI(a, i)
        }).finally(function() {
            t.enable()
        });
        var a = this._getInstalledStore().getById(this.pkgname);
        a && (a.data.autoupdate = i)
    },
    renderStatusOrCategories: function(t, e) {
        var i = this._getOperationInfo(this.data, this.panelName);
        if (!Ext.isEmpty(i.statusText)) return String.format('<font style="color:{0};">{1}</font>', i.statusColor, i.statusText);
        if (Ext.isArray(e.category)) {
            var a = [],
                n = SYNO.SDS.PkgManApp.Window.getStore("category");
            Ext.each(e.category, function(t) {
                n.getById(t) ? a.push(n.getById(t).get("dname")) : a.push(t)
            });
            var s = {
                color: "rgba(65,75,85,0.6)"
            };
            return s.text = Ext.util.Format.htmlEncode(a.join(", ")), String.format('<font style="color:{0};" ext:qtip="{1}">{1}</font>', s.color, s.text)
        }
        return ""
    },
    isCommunity: function() {
        return "community" === this.owner.targetStore
    },
    updateAutoUpdateUI: function(t, e) {
        var i = t.get("autoupdate");
        i.setChecked(e), i.checked ? i.addClass("synopkg-item-checked") : i.removeClass("synopkg-item-checked")
    }
}), Ext.define("SYNO.SDS.PkgManApp.Detail.Screenshot", {
    extend: "Ext.DataView",
    helper: SYNO.SDS.PkgManApp.Utils.Helper,
    constructor: function(t) {
        this.callParent([this.fillConfig(t)]), this.mon(this.store, "load", this.onStoreLoad, this)
    },
    fillConfig: function(t) {
        this.store = this.createStore(), this.tpl = this.createTpl(), this.addTplRenderer();
        var e = {
            cls: "synopkg-detail-screenshot",
            tpl: this.tpl,
            trackOver: !0,
            listeners: {
                mouseenter: this._onMouseEnter,
                afterrender: this.onAfterRender
            }
        };
        return Ext.apply(e, t), e
    },
    addTplRenderer: function() {},
    createStore: function() {
        return new Ext.data.JsonStore({
            autoDestroy: !0,
            fields: ["screenshot"]
        })
    },
    createTpl: function() {
        return new Ext.XTemplate("<div class=synopkg-detail-screenshot-pager>", '<tpl for=".">', '<div class="button" data-target-id="{[xindex - 1]}">', "</div>", "</tpl>", "</div>", '<tpl for=".">', '<img class="synopkg-detail-screenshot-item" src="{screenshot}"/>', "</tpl>")
    },
    selectScreenshot: function(t) {
        this.getEl().select(".synopkg-detail-screenshot-pager .button").each(function(e, i, a) {
            e.removeClass("selected"), a === t && e.addClass("selected")
        }, this), this.getEl().select(".synopkg-detail-screenshot-item").each(function(e, i, a) {
            e.dom.style.display = "none", a === t && (e.dom.style.display = "block")
        }, this)
    },
    onStoreLoad: function(t, e) {
        t.getCount() < 1 ? this.hide() : (this.show(), this.selectScreenshot(0))
    },
    onAfterRender: function() {
        this.selectScreenshot(0)
    },
    getScreenshot: function(t, e, i, a) {
        var n = SYNO.API.currentManager.getBaseURL(a ? "SYNO.Core.Package.Screenshot" : "SYNO.Core.Package.Screenshot.Server", "get", 1),
            s = Ext.urlAppend(n, Ext.urlEncode(SYNO.API.EncodeParams({
                name: e.id,
                ver: e.version,
                link: i,
                index: this.helper.hashCode(i.substring(i.lastIndexOf("/") + 1))
            })));
        return a && (s = Ext.urlAppend(s, Ext.urlEncode(SYNO.API.EncodeParams({
            newlink: a
        })))), s
    },
    _onMouseEnter: function(t, e, i) {
        var a = Ext.fly(i).findParent(".button");
        if (!Ext.isEmpty(a)) {
            var n = Number(a.getAttribute("data-target-id"));
            this.selectScreenshot(n)
        }
    },
    onLoadData: function(t) {
        var e = [];
        t && t.snapshot && t.snapshot.forEach(function(i, a) {
            var n = this.getScreenshot(a, t, i);
            e.push({
                screenshot: n
            })
        }, this), this.store.loadData(e)
    }
}), Ext.define("SYNO.SDS.PkgManApp.Detail.Container", {
    extend: "Ext.Container",
    helper: SYNO.SDS.PkgManApp.Utils.Helper,
    constructor: function(t) {
        SYNO.SDS.PkgManApp.Utils.Utils._initWinWrappers.call(this, t), this.callParent([this.fillConfig(t)])
    },
    fillConfig: function(t) {
        this.statusArea = this.createStatus(t), this.descAndChangelog = this.createDescAndChangelog(), this.relatedPkgs = this.createRelatedPkgs(), this.screenshot = this.createScreenshot(), this.info = this.createInfo(), this.feedbackBtn = this.createFeedbackBtn();
        var e = {
            autoFlexcroll: !0,
            cls: "syno-pkg-view syno-pkg-detail-container",
            style: {
                paddingBottom: "20px",
                paddingRight: "20px"
            },
            items: [this.statusArea, this.screenshot, this.descAndChangelog, this.relatedPkgs, this.info, this.feedbackBtn],
            listeners: {
                resize: this._onResize,
                deactivate: this.onDeactivate,
                activate: this.onActivate
            }
        };
        return Ext.apply(e, t), e
    },
    createRelatedPkgs: function() {
        return new SYNO.SDS.PkgManApp.Detail.RelatedPkgList({
            owner: this,
            style: {
                marginTop: "32px"
            },
            showTBar: !0,
            store: SYNO.SDS.PkgManApp.Window.getStore("stable"),
            viewType: "card",
            panelName: "SYNO.SDS.PkgManApp.All.Panel",
            headerText: this.helper.T("related_packages")
        })
    },
    _onResize: function() {
        this.getWidth(!0) > 976 && this.screenshot.getStore().getCount() > 0 ? (this.statusArea.addClass("synopkg-detail-status-wide"), this.screenshot.addClass("synopkg-detail-screenshot-wide")) : (this.statusArea.removeClass("synopkg-detail-status-wide"), this.screenshot.removeClass("synopkg-detail-screenshot-wide"))
    },
    createScreenshot: function() {
        return new SYNO.SDS.PkgManApp.Detail.Screenshot({})
    },
    createInfo: function() {
        var t = this;
        return new Ext.form.FormPanel({
            title: this.helper.T("other_information"),
            cls: "syno-pkg-detail-other",
            border: !1,
            clearCls: "",
            labelSeparator: "",
            labelAlign: "top",
            defaults: {
                xtype: "displayfield"
            },
            items: [{
                name: "maintainer",
                fieldLabel: this.helper.T("pkgmgr_pkg_maintainer"),
                cls: "synopkg-hyperlink",
                setRawValue: function(e) {
                    var i = t.getPkgData();
                    return e = e && i && !Ext.isEmpty(i.maintainer_url) ? t.helper.renderURL(i.maintainer_url, e) : e && !Ext.isEmpty(i.maintainer) && "Synology Inc." == i.maintainer ? t.helper.renderURL("http://www.synology.com", e) : Ext.util.Format.htmlEncode(e), this.rendered ? this.el.dom.innerHTML = Ext.isEmpty(e) ? "" : e : this.value = e
                }
            }, {
                name: "distributor",
                fieldLabel: this.helper.T("pkgmgr_pkg_distributor"),
                cls: "synopkg-hyperlink",
                setRawValue: function(e) {
                    var i = t.getPkgData();
                    return e = e && i && !Ext.isEmpty(i.distributor_url) ? t.helper.renderURL(i.distributor_url, e) : e && !Ext.isEmpty(i.distributor) && "Synology Inc." == i.distributor ? t.helper.renderURL("http://www.synology.com", e) : Ext.util.Format.htmlEncode(e), this.rendered ? this.el.dom.innerHTML = Ext.isEmpty(e) ? "" : e : this.value = e
                }
            }, {
                name: "installed_version",
                fieldLabel: this.helper.T("pkgmgr_installed_pkg_version")
            }, {
                name: "pkgtarget",
                fieldLabel: this.helper.T("pkgmgr_pkg_install_volume"),
                setValue: function(t) {
                    var e = Ext.isEmpty(t.path) ? "" : t.path;
                    return e && (e = "/usr/local/packages/" === e.substr(0, 20) ? _T("pkgmgr", "system_volume") : _T("volume", "volume") + " " + e.match(/^\/volume(\d*)\//)[1]), this.rendered ? this.el.dom.innerHTML = Ext.isEmpty(e) ? "" : e : this.value = e
                }
            }, {
                name: "download_count",
                fieldLabel: this.helper.T("download_count"),
                setValue: function(t) {
                    return t = Ext.isNumber(t) ? Ext.util.Format.number(t, "0,000") : t, this.setRawValue(t), this
                }
            }, {
                name: "newest_online_version",
                fieldLabel: this.helper.T("pkgmgr_pkg_version")
            }, {
                name: "category",
                fieldLabel: this.helper.T("category"),
                itemId: "category",
                setRawValue: function(t) {
                    var e = "";
                    if (t && Ext.isArray(t)) {
                        var i = SYNO.SDS.PkgManApp.Window.getStore("category");
                        Ext.each(t, function(t) {
                            var a;
                            a = i.getById(t) ? i.getById(t).get("dname") : t, e += String.format('<span data-id="{0}" class="syno-pkg-detail-category">{1}</span>', t, a)
                        })
                    }
                    return this.rendered ? this.el.dom.innerHTML = Ext.isEmpty(e) ? "" : e : this.value = e
                }
            }, {
                name: "url",
                fieldLabel: this.helper.T("pkgmgr_pkg_adminurl"),
                setRawValue: function(t) {
                    var e = SYNO.SDS.PkgManApp.Utils.Helper.getAdminPortUrl(t);
                    return this.rendered ? this.el.dom.innerHTML = Ext.isEmpty(e) ? "" : e : this.value = e
                }
            }]
        })
    },
    createFeedbackBtn: function() {
        return new SYNO.ux.Button({
            style: {
                marginTop: "16px"
            },
            text: this.helper.T("report"),
            handler: this.sendFeedback,
            scope: this
        })
    },
    sendFeedback: function() {
        var t = this.getPkgData();
        t.support_center ? SYNO.SDS.AppLaunch("SYNO.SDS.SupportForm.Application", {
            extra: {
                pkg_id: t.id,
                pkg_version: t.version
            }
        }) : t.pkgreporturl && window.open(t.pkgreporturl, "_blank", "")
    },
    createDescAndChangelog: function() {
        return new Ext.form.FormPanel({
            cls: "syno-pkg-detail-desc-changelog",
            border: !1,
            labelSeparator: "",
            labelAlign: "top",
            defaults: {
                xtype: "displayfield"
            },
            items: [{
                name: "desc",
                fieldLabel: this.helper.T("pkgmgr_pkg_description")
            }, {
                name: "changelog",
                itemId: "changelog",
                fieldLabel: this.helper.T("pkgmgr_pkg_changelog")
            }, {
                name: "replace_message",
                itemId: "replace_message",
                fieldLabel: _T("widget", "attention_status")
            }]
        })
    },
    setPkgId: function(t) {
        this.pkgId = t
    },
    setServerStore: function(t) {
        this.serverStore = t
    },
    onLoadData: function() {
        this.relatedPkgs.hide(), this.relatedPkgs._view.refresh();
        var t = this.getPkgData();
        this.screenshot.onLoadData(t), this.onUpdateStatusCallBack()
    },
    createStatus: function(t) {
        return new SYNO.SDS.PkgManApp.Detail.Status({
            owner: this,
            panelName: t.panelName
        })
    },
    setFieldValues: function(t, e) {
        (t = t.getForm()).reset(), t.setValues(e), t.items.each(function(t) {
            var e = t.getValue();
            Ext.isEmpty(e) || Ext.isNumber(e) && 0 === e ? t.hide() : t.show()
        })
    },
    getPkgData: function() {
        var t = SYNO.SDS.PkgManApp.Window.getStore("installed").getById(this.targetPkg),
            e = this.targetStore,
            i = {
                status: null,
                download_count: null,
                price: null
            },
            a = SYNO.SDS.PkgManApp.Window.getStore(e).getById(this.targetPkg);
        if (a) {
            var n = this._getOperationInfo(a.data, this.panelName);
            n.isInstalledInCurrentPage && (Ext.apply(i, t.data), i.installed_version = t.get("version"), i.id = t.get("id")), Ext.apply(i, a.data), n.targetRecord && n.targetRecord.get("dname") && Ext.apply(i, n.targetRecord.data), n.isInstalledInCurrentPage && ["dsm_apps", "dsm_app_launch_name", "status", "statusTitle", "statusDescription", "statusDesktop", "url", "broken_by", "progress"].forEach(function(e) {
                i[e] = t.get(e)
            })
        }
        if (i.replace_message = null, t && this._HasAvailableOperation(t.data) && t.data.available_operation.forcereplaced) {
            var s = t.data.available_operation.forcereplaced,
                r = this._getAvalRecByChannel(s.package, s.beta);
            "installed" == this.panel && r && r.data.replace_message && (i.changelog = null, i.replace_message = r.data.replace_message)
        }
        if ("installed" === e && "installed" === this.panel) {
            var o = SYNO.SDS.PkgManApp.Window.getStore("stable").getById(this.targetPkg) || SYNO.SDS.PkgManApp.Window.getStore("beta").getById(this.targetPkg);
            o && o.data.category && (i.category = o.data.category)
        }
        if ("installed" === e) {
            var l = SYNO.SDS.PkgManApp.Window.getStore("community").getById(this.targetPkg);
            l && (i.newest_online_version = l.get("version"));
            var p = SYNO.SDS.PkgManApp.Window.getStore("stable").getById(this.targetPkg),
                g = SYNO.SDS.PkgManApp.Window.getStore("beta").getById(this.targetPkg);
            p ? i.newest_online_version = p.get("version") : g && (i.newest_online_version = g.get("version") + " (beta)")
        } else i.newest_online_version = a.get("version");
        return i
    },
    onUpdateStatus: function() {
        this.pollingStatus && !this.pollingStatus.removed || (this.pollingStatus = this.addTask({
            interval: 1500,
            run: function() {
                this.onUpdateStatusCallBack()
            },
            scope: this
        })), this.pollingStatus.restart(!0)
    },
    onUpdateStatusCallBack: function() {
        var t = this.getPkgData();
        this.setFieldValues(this.info, t), this.setFieldValues(this.descAndChangelog, t), this.descAndChangelog.getComponent("changelog").label.dom.innerHTML = String.format(this.helper.T("pkgmgr_pkg_changelog"), t.version), this.statusArea.onLoadData(t), this.setFeedbackBtn(t), this.updateFleXcroll(), "installed" !== this.panel || t.status || SYNO.SDS.PkgManApp.Window.jumpTo("SYNO.SDS.PkgManApp.Installed.Panel", 0)
    },
    onActivate: function() {
        this.onLoadData(), this.onUpdateStatus(), this.scrollToTop(), this._onResize()
    },
    scrollToTop: function() {
        this.el.dom.fleXcroll && (this.el.dom.fleXcroll.setScrollPos(!1, 0), this.updateFleXcroll())
    },
    onDeactivate: function() {
        this.pollingStatus && this.pollingStatus.remove()
    },
    setFeedbackBtn: function(t) {
        t.pkgreporturl || t.support_center ? this.feedbackBtn.show() : this.feedbackBtn.hide()
    },
    setPkg: function(t) {
        this.targetPkg = t
    },
    isInstalledPage: function() {
        return "installed" === this.panel
    },
    bindCategoryClick: function() {
        var t = this.info.getComponent("category").getEl();
        t && t.select(".syno-pkg-detail-category").each(function(t, e, i) {
            var a = t.getAttribute("data-id");
            this.mun(t, "click"), this.mon(t, "click", function(t, e) {
                var i = {
                    scrollToTop: !0,
                    categoryId: a
                };
                SYNO.SDS.PkgManApp.Window.jumpTo("SYNO.SDS.PkgManApp.Category.Panel", "pkglist", null, null, i)
            }, this)
        }, this)
    }
}), Ext.define("SYNO.SDS.PkgManApp.Utils.PkgListCardView", {
    extend: "Ext.DataView",
    helper: SYNO.SDS.PkgManApp.Utils.Helper,
    constructor: function(t) {
        SYNO.SDS.PkgManApp.Utils.Utils._initWinWrappers.call(this, t), this.callParent([this.fillConfig(t)]), this.mon(this.store, "load", this._onStoreLoad, this), this.addEvents("widthset")
    },
    fillConfig: function(t) {
        this.tpl = this.createTpl(), this.addTplRenderer();
        var e = {
            listeners: {
                click: this._onClick,
                resize: this.onResize,
                activate: this.onActivate
            },
            tpl: this.tpl
        };
        return Ext.apply(e, t), e
    },
    createTpl: function() {
        return new Ext.XTemplate('<tpl for=".">', '<div data-id="{id}" class="syno-pkglist-card">', '<div class="syno-pkglist-iconarea">', '<div class="syno-pkglist-icon">', '<img class="syno-pkg-icon-img" src="{[this.getTransparentDataURI()]}"  style="background:url(\'{[this.getIcon(values, undefined)]}\');background-size:64px;">', "</div>", '<div class="syno-pkglist-price">', "<span>", "{[this.getPrice(values)]}", "</span>", "</div>", "</div>", '<div class="syno-pkglist-infoarea">', '<div class="syno-pkglist-info {[this.getInfoClass(values)]}">', '<span class="syno-pkglist-title" ext:qtip="{[this.getTitle(values)]}">', "{[this.getTitle(values)]}", "</span>", '<span class="syno-pkglist-subtitle">', "{[this.getSubTitle(values)]}", "</span>", "</div>", '<div class="syno-pkglist-btn">', "{[this.getActionBtn(values)]}", "</div>", "</div>", '<div class="syno-pkglist-badge {[this.getBetaClass(values)]}"></div>', "</div>", "</tpl>", {
            compiled: !0,
            disableFormats: !0,
            getActionBtn: this.getActionBtn.createDelegate(this),
            getSubTitle: this.getSubTitle.createDelegate(this),
            getTransparentDataURI: SYNO.SDS.PkgManApp.Utils.Helper.getTransparentDataURI.createDelegate(this)
        })
    },
    getBtnTemplate: function(t, e, i, a) {
        return String.format('<div ext:qtip="{0}">                <span cellspacing="0" class="x-btn syno-ux-button {1} {2} x-btn-noicon" style="width: auto; margin-left: 0px;">                    <em class="x-unselectable" unselectable="on">                        <button ext:qtip="{3}" type="button" class=" x-btn-text" aria-label="{3} {4}">                        {3}                        </button>                    </em>                </span>            </div>', _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "", e || "syno-ux-button-grey", i ? "x-item-disabled" : "", t, a || "")
    },
    addTplRenderer: function() {
        this.tpl.getBetaClass = this.getBetaClass, this.tpl.getInfoClass = this.getInfoClass, this.tpl.getPrice = this.getPrice, this.tpl.getIcon = this.getIcon, this.tpl.getTitle = this.getTitle
    },
    collectData: Ext.emptyFn,
    sortFunction: function(t, e) {
        var i = t.dname || t.id,
            a = e.dname || e.id;
        return i.localeCompare(a)
    },
    tryMapCategoryIdsToDnames: function(t) {
        var e = SYNO.SDS.PkgManApp.Window.getStore("category");
        return e && Ext.isArray(t) ? t.map(function(t) {
            var i = e.getById(t);
            return i ? "".concat(i.data.dname, " ").concat(t) : t
        }) : t
    },
    filterCollectData: function(t, e) {
        var i = Ext.getCmp("SYNO.SDS.PkgManApp.SearchResult.Panel").searchtext,
            a = [];
        return Ext.each(t, function(t) {
            if (Ext.isEmpty(i)) a.push(t.data);
            else
                for (var e = i.split(/\s+/), n = 0, s = e.length; n < s && !Ext.isEmpty(e[n]); n++)
                    if (this.checkTextMatch(t.data.dname, e[n]) || this.checkTextMatch(t.data.id, e[n]) || this.checkTextMatch(t.data.maintainer, e[n]) || this.checkTextMatch(this.tryMapCategoryIdsToDnames(t.data.category), e[n])) {
                        a.push(t.data);
                        break
                    }
        }, this), a.sort(function(t, e) {
            var a = this.getWeight(t, i),
                n = this.getWeight(e, i),
                s = t.dname || t.id,
                r = e.dname || e.id;
            return n > a ? 1 : a > n ? -1 : s < r ? -1 : s > r ? 1 : 0
        }.createDelegate(this)), this.determineVisibility(a), a
    },
    getWeight: function(t, e) {
        var i = 0,
            a = 0;
        if ("Synology Inc." == t.distributor && (a = 1), !Ext.isEmpty(e))
            if (this.checkTextMatch(t.id, this.getWordFullMatch(e)) || this.checkTextMatch(t.dname, this.getWordFullMatch(e))) i = 2 * Math.pow(10, 8);
            else if (this.checkTextMatch(t.dname, e)) i = Math.pow(10, 8);
        else if (this.checkTextMatch(t.id, e)) i = Math.pow(10, 7);
        else
            for (var n = e.split(/\s+/), s = 0, r = n.length; s < r && s < 20 && !Ext.isEmpty(n[s]); s++) this.checkTextMatch(t.id, this.getWordFullMatch(n[s])) || this.checkTextMatch(t.dname, this.getWordFullMatch(n[s])) ? i += 2 * Math.pow(10, 6) : this.checkTextMatch(t.dname, n[s]) ? i += Math.pow(10, 6) : this.checkTextMatch(t.id, n[s]) ? i += Math.pow(10, 5) : this.checkTextMatch(t.category, this.getWordFullMatch(n[s])) ? i += 2 * Math.pow(10, 4) : this.checkTextMatch(t.category, n[s]) ? i += Math.pow(10, 4) : this.checkTextMatch(t.maintainer, this.getWordFullMatch(n[s])) ? i += 2 * Math.pow(10, 2) : this.checkTextMatch(t.maintainer, n[s]) ? i += Math.pow(10, 2) : this.checkTextMatch(t.desc, this.getWordFullMatch(n[s])) || this.checkTextMatch(t.desc_enu, this.getWordFullMatch(n[s])) ? i += 2 * Math.pow(10, 0) : (this.checkTextMatch(t.desc, n[s]) || this.checkTextMatch(t.desc_enu, n[s])) && (i += Math.pow(10, 0));
        return 2 * i + a
    },
    getWordFullMatch: function(t) {
        return "(^| )" + t + "($| )"
    },
    checkTextMatch: function(t, e) {
        var i = new RegExp("[" + ["-", "[", "]", "/", "{", "}", "(", ")", "*", "+", "?", ".", "\\", "^", "$", "|"].join("\\") + "]", "g");
        if (e = function(t) {
                return t.replace(i, "\\$&")
            }(e), t)
            if (Ext.isArray(t)) {
                for (var a = 0; a < t.length; a++)
                    if (-1 != t[a].toLowerCase().search(e)) return !0
            } else if (Ext.isString(t) && -1 != t.toLowerCase().search(e)) return !0;
        return !1
    },
    onResize: function() {
        this.rendered && this.previousContainerWidth !== this.containerWidth && (this.previousContainerWidth = this.containerWidth, this.setCardWidth())
    },
    onActivate: function() {
        this.refresh(), this.setCardWidth()
    },
    _onStoreLoad: function() {
        this.setCardWidth()
    },
    setCardWidth: function() {
        if (this.rendered) {
            for (var t = this.getCardWidth(), e = this.getCardButtonMaxWidth(), i = this.getEl().select(".syno-pkglist-card").elements, a = 0; a < i.length; a++) {
                var n = Ext.fly(i[a]);
                n.setStyle("width", t + "px"), n.select(".x-btn-text").first().setStyle("max-width", e + "px")
            }
            this.fireEvent("widthset")
        }
    },
    getCardWidth: function() {
        return this.helper.getCardWidth(this.containerWidth)
    },
    getCardButtonMaxWidth: function() {
        return this.getCardWidth() - 96 - 1 - 8
    },
    getCardClass: function() {
        return ".syno-pkglist-card"
    },
    _onClick: function(t, e, i) {
        var a = Ext.fly(i).findParent(this.getCardClass());
        if (!Ext.isEmpty(a)) {
            var n, s = a.getAttribute("data-id");
            if (n = Ext.fly(i).findParent(".syno-ux-button", 3)) {
                if (!Ext.fly(n).hasClass("x-item-disabled")) {
                    var r = this.store.getById(s),
                        o = this._getOperationInfo(r.data, this.panelName);
                    o.actionFunction && o.actionFunction()
                }
            } else SYNO.SDS.PkgManApp.Window.jumpTo(this.panelName, "detail", s)
        }
    },
    determineVisibility: function(t) {
        var e = !0;
        e = 0 < t.length, this.owner && "SYNO.SDS.PkgManApp.Beta.Panel" === this.owner.panelName && !SYNO.SDS.PkgManApp.Config.blBetaChannel && (e = !1), e ? this.owner.show() : this.owner.hide()
    },
    getBetaClass: Ext.emptyFn,
    getInfoClass: function(t) {
        return t.beta ? "syno-pkglist-beta-info" : ""
    },
    getSubTitle: function(t) {
        var e = this.getActionStatus(t);
        if (e) return e;
        var i = [],
            a = SYNO.SDS.PkgManApp.Window.getStore("category");
        return Ext.each(t.category, function(t) {
            a.getById(t) ? i.push(a.getById(t).get("dname")) : i.push(t)
        }), String.format('<span ext:qtip="{0}">{0}</span>', i.join(", "))
    },
    getPrice: Ext.emptyFn,
    getIcon: Ext.emptyFn,
    onUpdate: function(t, e, i) {
        if (Ext.data.Record.COMMIT === i) {
            var a = SYNO.SDS.PkgManApp.Window.getActivePage().panelName;
            if (this.panelName === a || "SYNO.SDS.PkgManApp.SearchResult.Panel" === a) {
                var n = Ext.query(".syno-pkglist-card[data-id=" + e.id + "]", this.getTemplateTarget().dom)[0];
                if (void 0 !== n) {
                    var s = document.createElement("div");
                    this.tpl.overwrite(s, [e.data]);
                    var r = Ext.query(".syno-pkglist-card", s)[0];
                    Ext.fly(r).setStyle("width", this.getCardWidth() + "px"), Ext.fly(r).select(".x-btn-text").first().setStyle("max-width", this.getCardButtonMaxWidth() + "px"), r.innerHTML !== n.innerHTML && this.getTemplateTarget().dom.replaceChild(r, n)
                }
            }
        }
    },
    getActionBtn: function(t) {
        return this.getActionTemplate(t).actiontext
    },
    getActionTemplate: function(t, e) {
        var i = this._getOperationInfo(t, this.panelName),
            a = i.actionText,
            n = i.statusText,
            s = i.statusColor,
            r = i.buttonClass,
            o = i.isButtonDisabled,
            l = SYNO.SDS.PkgManApp.Window.getStore("installed").getById(t.id);
        if (l && "doing" !== l.data.statusDesktop && "loading" !== l.data.status && (n = ""), n) {
            var p = "..." === n.slice(-3),
                g = "<span class='" + ("syno-pkg-status" + (p ? " syno-pkg-anim-ellipsis" : "")) + "'>";
            g += "<font style='color:" + s + ";' ext:qtip='" + n + "'>", g += "&nbsp;", g += n, p && (g = g.slice(0, -3), g += '<span class="anim-dot dot-first">.</span>', g += '<span class="anim-dot dot-second">.</span>', g += '<span class="anim-dot dot-third">.</span>'), n = g += "</font></span>"
        }
        return {
            actiontext: this.getBtnTemplate(a, r, o, t.dname),
            statustext: n
        }
    },
    getActionStatus: function(t) {
        var e = this.getActionTemplate(t, !0),
            i = e.statustext;
        return t.progress < 0 && (this.modalWin && 0 !== this.modalWin.length ? t.qinst && SYNO.SDS.SystemTray.notifyMsg("SYNO.SDS.PkgManApp.Instance", _T("tree", "leaf_packagemanage"), e.statustext) : (i = "", this._getOwner().getMsgBox().alert(_T("tree", "leaf_packagemanage"), e.statustext, function() {
            e.callback && e.callback()
        }, this))), i
    },
    isCommunityPage: function() {
        return !1
    },
    isBeta: function() {
        return !1
    },
    getTitle: function(t) {
        return SYNO.SDS.PkgManApp.Utils.Helper.encodeMsg(t.dname || t.id)
    }
}), Ext.define("SYNO.SDS.PkgManApp.Utils.PkgListListView", {
    extend: "Ext.DataView",
    helper: SYNO.SDS.PkgManApp.Utils.Helper,
    constructor: function(t) {
        SYNO.SDS.PkgManApp.Utils.Utils._initWinWrappers.call(this, t), this.callParent([this.fillConfig(t)]), this.addEvents("widthset")
    },
    fillConfig: function(t) {
        this.tpl = this.createTpl();
        var e = {
            listeners: {
                click: this._onClick
            },
            tpl: this.tpl
        };
        return Ext.apply(e, t), e
    },
    createTpl: function() {
        return new Ext.XTemplate('<tpl for=".">', '<div data-id="{id}"  class="syno-pkglist-list">', '<div class="syno-pkglist-badge {[this.getBetaClass(values)]}"></div>', '<div class="syno-pkglist-iconarea">', '<div class="syno-pkglist-icon">', '<img class="syno-pkg-icon-img" src="{[this.getTransparentDataURI()]}"  style="background:url(\'{[this.getIcon(values, undefined)]}\');background-size:64px;">', "</div>", '<div class="syno-pkglist-info">', '<span ext:qtip="{[this.getTitle(values)]}" class="syno-pkglist-title">', "{[this.getTitle(values)]}", "</span>", '<span class="syno-pkglist-subtitle">', "{[this.getStatus(values)]}", "</span>", "</div>", "</div>", '<div class="syno-pkglist-descarea">', "<span>", "{[this.getDesc(values)]}", "</span>", "</div>", '<div class="syno-pkglist-btnarea">', '<div class="syno-pkglist-btn">', "{[this.getActionBtn(values)]}", "</div>", "</div>", "</div>", "</tpl>", {
            compiled: !0,
            disableFormats: !0,
            getDesc: this.getDesc.createDelegate(this),
            getIcon: this.getIcon.createDelegate(this),
            getTitle: this.getTitle.createDelegate(this),
            getActionBtn: this.getActionBtn.createDelegate(this),
            getBetaClass: this.getBetaClass.createDelegate(this),
            getStatus: this.getStatus.createDelegate(this),
            getTransparentDataURI: SYNO.SDS.PkgManApp.Utils.Helper.getTransparentDataURI.createDelegate(this)
        })
    },
    collectData: Ext.emptyFn,
    _onStoreLoad: Ext.emptyFn,
    getListClass: function() {
        return ".syno-pkglist-list"
    },
    _onClick: function(t, e, i) {
        var a = Ext.fly(i).findParent(this.getListClass());
        if (!Ext.isEmpty(a)) {
            var n, s = a.getAttribute("data-id");
            if ((n = Ext.fly(i).hasClass("syno-ux-button")) || (n = Ext.fly(i).findParent(".syno-ux-button", 3))) {
                if (!Ext.fly(n).hasClass("x-item-disabled")) {
                    var r = this._getInstalledStore().getById(s),
                        o = this._getOperationInfo(r.data, this.panelName);
                    o.actionFunction && o.actionFunction()
                }
            } else SYNO.SDS.PkgManApp.Window.jumpTo(this.panelName, 1, s)
        }
    },
    refresh: function() {
        this.callParent(arguments), this.fireEvent("widthset")
    },
    determineVisibility: function(t) {
        0 < t.length ? this.owner.show() : this.owner.hide()
    },
    getDesc: Ext.emptyFn,
    getStatus: function(t) {
        var e = this._getOperationInfo(t, this.panelName);
        return String.format('<font ext:qtip="{1}" class="syno-pkg-status" style="color:{0};">{1}</font>', e.statusColor, e.statusText)
    },
    getIcon: Ext.emptyFn,
    onUpdate: Ext.emptyFn,
    getTitle: function(t) {
        var e = this._getOperationInfo(t, this.panelName);
        return SYNO.SDS.PkgManApp.Utils.Helper.encodeMsg(e.targetRecord.get("dname"))
    },
    getBetaClass: Ext.emptyFn
}), Ext.define("SYNO.SDS.PkgManApp.Utils.PkgList", {
    extend: "Ext.Container",
    helper: SYNO.SDS.PkgManApp.Utils.Helper,
    constructor: function(t) {
        SYNO.SDS.PkgManApp.Utils.Utils._initWinWrappers.call(this, t), this.callParent([this.fillConfig(t)]), this.mon(this.store, "load", this.setGroupBtn, this)
    },
    fillConfig: function(t) {
        this.store = t.store, this.owner = t.owner, this.showTBarBtns = t.showTBarBtns, this.panelName = t.panelName, this.goSearch = t.goSearch;
        var e = [];
        t.showTBar && e.push(this.createTBar(t.headerText, t.showTBarBtns)), "card" === t.viewType ? this._view = this.createCardView() : this._view = this.createListView(), e.push(this._view), e.push({
            xtype: "box",
            cls: "x-clear"
        });
        var i = {
            items: e,
            cls: "syno-pkglist-container",
            listeners: {
                afterlayout: this._afterlayout,
                buffer: 1
            }
        };
        return Ext.apply(i, t), i
    },
    _activate: function() {
        "card" === this.viewType && this._view.fireEvent("activate")
    },
    _afterlayout: function(t, e) {
        "card" === this.viewType && this._view.fireEvent("resize")
    },
    setGroupBtn: function() {
        if (this.showTBarBtns) {
            this.repairBtn.hide(), this.upgradeBtn.hide();
            var t = !1,
                e = !1;
            this.store.each(function(i) {
                var a = i.data;
                "loading" !== a.status && a.operation.actionFunction && ("repair" === a.operation.action ? t = !0 : "upgrade" === a.operation.action && (e = !0))
            }, this), t && this.repairBtn.show(), e && this.upgradeBtn.show()
        }
    },
    createTBar: function(t, e) {
        var i = [{
            xtype: "displayfield",
            cls: "syno-pkglist-header",
            style: {
                fontSize: "15px"
            },
            value: t
        }];
        return e && (this.repairBtn = new SYNO.ux.Button({
            text: this.helper.T("repair_all"),
            btnStyle: "orange",
            width: "auto",
            hidden: !0,
            scope: this,
            handler: this.repairAll
        }), this.upgradeBtn = new SYNO.ux.Button({
            text: this.helper.T("update_all"),
            btnStyle: "green",
            width: "auto",
            hidden: !0,
            scope: this,
            handler: this.updateAll
        }), i.push("->"), i.push(this.repairBtn), i.push({
            xtype: "displayfield",
            width: "6px"
        }), i.push(this.upgradeBtn)), new SYNO.ux.Toolbar({
            style: {
                borderStyle: "none"
            },
            items: i
        })
    },
    repairAll: function() {
        this._onClickUpdateAll(!0)
    },
    updateAll: function() {
        this._onClickUpdateAll(!1)
    },
    createListView: function() {
        return new SYNO.SDS.PkgManApp.Utils.PkgListListView({
            store: this.store,
            panel: this.owner,
            owner: this
        })
    },
    setGroupBtnAndRefreshView: function() {
        this.setGroupBtn(), this._view.refresh(), this._view._onStoreLoad()
    },
    createCardView: function() {
        return new SYNO.SDS.PkgManApp.Utils.PkgListCardView({
            store: this.store,
            panel: this.owner,
            owner: this
        })
    }
}), Ext.define("SYNO.SDS.PkgManApp.All.SynologyCardView", {
    extend: "SYNO.SDS.PkgManApp.Utils.PkgListCardView",
    constructor: function(t) {
        this.callParent([t])
    },
    collectData: function(t, e) {
        if (this.goSearch) return this.filterCollectData(t, e);
        var i = [];
        return Ext.each(t, function(t) {
            0 > t.data.maintainer.indexOf("Synology") || i.push(t.data)
        }), this.determineVisibility(i), i
    },
    getBetaClass: function(t) {
        return ""
    },
    getPrice: function(t) {
        return SYNO.SDS.PkgManApp.Utils.Helper.getPriceFormatString(t.price, SYNO.SDS.PkgManApp.Window.synoAccountInfo.currency)
    },
    getIcon: SYNO.SDS.PkgManApp.Utils.Helper.getIconFromServer
}), Ext.define("SYNO.SDS.PkgManApp.All.SynologyPkgList", {
    extend: "SYNO.SDS.PkgManApp.Utils.PkgList",
    constructor: function(t) {
        this.callParent([t])
    },
    createCardView: function() {
        return new SYNO.SDS.PkgManApp.All.SynologyCardView({
            store: this.store,
            panel: this.owner,
            panelName: this.panelName,
            goSearch: this.goSearch,
            owner: this
        })
    }
}), Ext.define("SYNO.SDS.PkgManApp.All.ThirdPartyCardView", {
    extend: "SYNO.SDS.PkgManApp.Utils.PkgListCardView",
    constructor: function(t) {
        this.callParent([t])
    },
    collectData: function(t, e) {
        var i = [];
        return Ext.each(t, function(t) {
            0 <= t.data.maintainer.indexOf("Synology") || i.push(t.data)
        }), this.determineVisibility(i), i
    },
    getBetaClass: function(t) {
        return ""
    },
    getPrice: function(t) {
        return SYNO.SDS.PkgManApp.Utils.Helper.getPriceFormatString(t.price, SYNO.SDS.PkgManApp.Window.synoAccountInfo.currency)
    },
    getIcon: SYNO.SDS.PkgManApp.Utils.Helper.getIconFromServer
}), Ext.define("SYNO.SDS.PkgManApp.All.ThirdPartyPkgList", {
    extend: "SYNO.SDS.PkgManApp.Utils.PkgList",
    constructor: function(t) {
        this.callParent([t])
    },
    createCardView: function() {
        return new SYNO.SDS.PkgManApp.All.ThirdPartyCardView({
            store: this.store,
            panel: this.owner,
            panelName: this.panelName,
            owner: this
        })
    }
}), Ext.ns("SYNO.SDS.PkgManApp.All"), Ext.define("SYNO.SDS.PkgManApp.All.SortBtnItemMenu", {
    extend: "SYNO.ux.Menu",
    helper: SYNO.SDS.PkgManApp.Utils.Helper,
    constructor: function(t) {
        this.callParent([this.fillConfig(t)]), this.bindEvents(), this.addClass("test_class")
    },
    createItems: function() {
        var t = [{
            xtype: "menucheckitem",
            group: "type",
            itemId: "type_popularity",
            text: this.helper.T("sort_by_recent_popularity")
        }, {
            xtype: "menucheckitem",
            group: "type",
            itemId: "type_name",
            text: this.helper.T("sort_by_name"),
            checked: !0
        }, "-", {
            xtype: "menucheckitem",
            itemId: "filter_installed",
            text: this.helper.T("filter_installed")
        }];
        return Ext.each(t, function(t) {
            Ext.QuickTips.register({
                target: t,
                text: t.text
            })
        }), t
    },
    fillConfig: function(t) {
        var e = {
            hideOnScroll: !0,
            cls: "synopkg-common-menu",
            autoDestroy: !0,
            width: SYNO.SDS.PkgManApp.Config.SORT_MENU_WIDTH,
            items: this.createItems()
        };
        return Ext.apply(e, t), e
    },
    bindEvents: function() {
        Ext.each(this.items.items, function(t) {
            this.mon(t, "beforerender", function(t) {
                t.checked && t.addClass("synopkg-item-checked")
            }), this.mon(t, "checkchange", function(t, e) {
                e ? t.addClass("synopkg-item-checked") : t.removeClass("synopkg-item-checked")
            })
        })
    }
}), Ext.define("SYNO.SDS.PkgManApp.All.SortBtn", {
    extend: "SYNO.ux.ComboBox",
    helper: SYNO.SDS.PkgManApp.Utils.Helper,
    cls: "synopkg-sort-menu",
    filterInstalled: !1,
    constructor: function(t) {
        this.menu = new SYNO.SDS.PkgManApp.All.SortBtnItemMenu, this.callParent([this.fillConfig(t)]), this.bindEvents()
    },
    fillConfig: function(t) {
        var e = {
            allowBlank: !1,
            value: this.helper.T("sort_by_name"),
            width: SYNO.SDS.PkgManApp.Config.SORT_MENU_WIDTH
        };
        return Ext.apply(e, t), e
    },
    bindEvents: function() {
        this.mon(this.menu, "click", function(t, e) {
            "filter_installed" === e.itemId ? this.filterInstalled = e.checked : (this.setValue(e.text), this.setSortType(e.itemId)), this.owner.onFilterStore(!0)
        }, this)
    },
    onTriggerClick: function() {
        this.menu.show(this.el)
    },
    getSortType: function() {
        return this._sortType || "type_name"
    },
    setSortType: function(t) {
        this._sortType = t
    },
    sortStore: function(t) {
        var e = "dname",
            i = "ASC";
        "type_popularity" === this.getSortType() && (e = "recent_download_count", i = "DESC");
        t.data.sort("ASC", "ASC" == i ? function(t, i) {
            return Ext.isNumber(t.data[e]) ? t.data[e] - i.data[e] : t.data[e].localeCompare(i.data[e])
        } : function(t, i) {
            return Ext.isNumber(t.data[e]) ? i.data[e] - t.data[e] : i.data[e].localeCompare(t.data[e])
        }), t.fireEvent("datachanged", this)
    }
}), Ext.ns("SYNO.SDS.PkgManApp.Legal"), SYNO.SDS.PkgManApp.Legal = {
    TOSURL: "http://sy.to/5yaae",
    PrivacyURL: "http://sy.to/privacy",
    UDCURL: "http://sy.to/zvgxb",
    createLegalLinkContainer: function() {
        var t = [{
                link: SYNO.SDS.PkgManApp.Legal.TOSURL,
                text: SYNO.SDS.PkgManApp.Utils.Helper.T("termsofservice")
            }, {
                link: SYNO.SDS.PkgManApp.Legal.PrivacyURL,
                text: SYNO.SDS.PkgManApp.Utils.Helper.T("privacy_policy")
            }, {
                link: SYNO.SDS.PkgManApp.Legal.UDCURL,
                text: SYNO.SDS.PkgManApp.Utils.Helper.T("user_data_collection")
            }],
            e = "";
        return Ext.each(t, function(t) {
            e += String.format('<a href="{0}" target="_blank">{1}</a>', t.link, t.text)
        }), new Ext.Container({
            cls: "synopkg-tof-container synopkg-termlink",
            html: String.format("<center>{0}</center>", e)
        })
    }
}, Ext.define("SYNO.SDS.PkgManApp.All.Panel", {
    extend: "SYNO.ux.Panel",
    helper: SYNO.SDS.PkgManApp.Utils.Helper,
    pkgListPaddingRight: 20,
    constructor: function(t) {
        this.callParent([this.fillConfig(t)]), this.pkgLists.forEach(function(t) {
            this.mon(t._view, "widthset", this.updateListviewFleXcroll, this)
        }, this), this.mon(this.store, "load", this.onFilterStore, this), this.needFilter = !0, this.mon(this.store, "load", function() {
            this.getEl().unmask(), this.determineEmptyMask()
        }, this), this.mon(this.store, "exception", function() {
            this.getEl().unmask(), this.getEl().mask(this.helper.T("commfail"), "")
        }, this)
    },
    onPageDeactivate: function() {
        this.layout.activeItem.fireEvent("deactivate")
    },
    fillConfig: function(t) {
        this.panelName = "SYNO.SDS.PkgManApp.All.Panel", this.listView = this.createListView();
        var e = {
            layout: "card",
            cls: "synopkg-all-panel synopkg-module",
            border: !1,
            activeItem: 0,
            items: [this.listView, new SYNO.SDS.PkgManApp.Detail.Container({
                itemId: "detail",
                panel: "all",
                panelName: this.panelName,
                targetStore: "stable"
            })],
            store: SYNO.SDS.PkgManApp.Window.getStore("stable"),
            listeners: {
                activate: this._onActivate
            }
        };
        return Ext.apply(e, t), e
    },
    createBanner: function() {
        return new SYNO.SDS.PkgManApp.All.Banner({
            cls: "syno-pkg-banner",
            owner: this,
            store: SYNO.SDS.PkgManApp.Window.getStore("banner")
        })
    },
    createTBar: function() {
        return this.sortBtn = new SYNO.SDS.PkgManApp.All.SortBtn({
            owner: this,
            store: {
                xtype: "store"
            }
        }), new SYNO.ux.Toolbar({
            cls: "synopkg-category-toolbar",
            items: [this.sortBtn],
            style: {
                height: "32px",
                padding: "0",
                borderStyle: "none"
            }
        })
    },
    createEmptyMask: function() {
        return new Ext.BoxComponent({
            cls: "synopkg-empty-pkglist-mask",
            hidden: !0,
            autoEl: {
                tag: "div",
                children: [{
                    tag: "div",
                    cls: "synopkg-empty-pkglist-icon"
                }, {
                    tag: "div",
                    cls: "synopkg-empty-pkglist-msg",
                    html: _T("pkgmgr", "empty_pkg_list_due_to_beta")
                }]
            }
        })
    },
    createListView: function() {
        this.synologyPkgList = new SYNO.SDS.PkgManApp.All.SynologyPkgList({
            owner: this,
            style: {
                marginTop: "12px"
            },
            showTBar: !0,
            store: SYNO.SDS.PkgManApp.Window.getStore("stable"),
            viewType: "card",
            panelName: this.panelName,
            headerText: this.helper.T("synology")
        }), this.thirdPartyPkgList = new SYNO.SDS.PkgManApp.All.ThirdPartyPkgList({
            owner: this,
            style: {
                marginTop: "12px"
            },
            showTBar: !0,
            store: SYNO.SDS.PkgManApp.Window.getStore("stable"),
            viewType: "card",
            panelName: this.panelName,
            headerText: this.helper.T("thirdparty")
        }), this.banner = this.createBanner(), this.banner.hide(), this.emptyMask = this.createEmptyMask(), this.pkgLists = [this.synologyPkgList, this.thirdPartyPkgList], this.tofContainer = SYNO.SDS.PkgManApp.Legal.createLegalLinkContainer();
        var t = [this.banner, this.createTBar(), this.synologyPkgList, this.thirdPartyPkgList, this.tofContainer, this.emptyMask];
        return new Ext.Container({
            owner: this,
            autoFlexcroll: !0,
            cls: "syno-pkg-view",
            style: {
                paddingRight: this.pkgListPaddingRight + "px"
            },
            listeners: {
                resize: this._onResize
            },
            items: t
        })
    },
    updateListviewFleXcroll: function() {
        this.widthSetCount = this.widthSetCount || 0, this.widthSetCount = (this.widthSetCount + 1) % 2, 0 === this.widthSetCount && this.listView.updateFleXcroll()
    },
    _onResize: function(t, e, i, a, n) {
        this.owner.pkgLists.forEach(function(t) {
            t.getComponent(1).containerWidth = e - this.owner.pkgListPaddingRight
        }, this), this.owner.emptyMask.setHeight(i - 265)
    },
    onFilterStore: function(t) {
        this.isVisible() ? (this.store.suspendEvents(), this.store.filterBy(function(t) {
            return !this.sortBtn.filterInstalled || !SYNO.SDS.PkgManApp.Utils.Utils.isOnlyInstStatus(t.data)
        }, this), this.sortBtn.sortStore(this.store), this.store.resumeEvents(), t && this.refreshPkglistView()) : this.needFilter = !0
    },
    _onActivate: function(t) {
        var e = SYNO.SDS.PkgManApp.Window.getStore("stable");
        e.exception ? this.getEl().mask(this.helper.T("commfail"), "") : e.loading || 0 !== e.getTotalCount() ? e.loading ? this.getEl().mask(this.helper.T("common", "loading"), "x-mask-loading") : (this.needFilter && (this.needFilter = !1, this.onFilterStore(!1)), this.refreshPkglistView(), this.determineEmptyMask()) : e.reload()
    },
    determineEmptyMask: function() {
        0 === SYNO.SDS.PkgManApp.Window.getStore("stable").getTotalCount() ? this.showEmptyMask() : this.hideEmptyMask()
    },
    showEmptyMask: function() {
        this.emptyMask.hidden && (this.sortBtn.hide(), this.synologyPkgList.hide(), this.thirdPartyPkgList.hide(), this.tofContainer.hide(), this.emptyMask.show(), this.doLayout())
    },
    hideEmptyMask: function() {
        this.emptyMask.hidden || (this.sortBtn.show(), this.synologyPkgList.show(), this.thirdPartyPkgList.show(), this.tofContainer.show(), this.emptyMask.hide(), this.doLayout())
    },
    refreshPkglistView: function() {
        this.pkgLists.forEach(function(t) {
            t._activate()
        }, this)
    }
}), Ext.define("SYNO.SDS.PkgManApp.Beta.BetaCardView", {
    extend: "SYNO.SDS.PkgManApp.Utils.PkgListCardView",
    constructor: function(t) {
        this.callParent([t])
    },
    collectData: function(t, e) {
        if (this.goSearch) return this.filterCollectData(t, e);
        var i = [];
        return Ext.each(t, function(t) {
            i.push(t.data)
        }), i.sort(this.sortFunction), this.determineVisibility(i), i
    },
    getBetaClass: function(t) {
        return "syno-pkglist-beta"
    },
    getPrice: function(t) {
        return SYNO.SDS.PkgManApp.Utils.Helper.getPriceFormatString(t.price, SYNO.SDS.PkgManApp.Window.synoAccountInfo.currency)
    },
    isBeta: function() {
        return !0
    },
    getIcon: SYNO.SDS.PkgManApp.Utils.Helper.getIconFromServer
}), Ext.define("SYNO.SDS.PkgManApp.Beta.BetaPkgList", {
    extend: "SYNO.SDS.PkgManApp.Utils.PkgList",
    constructor: function(t) {
        this.callParent([t])
    },
    createCardView: function() {
        return new SYNO.SDS.PkgManApp.Beta.BetaCardView({
            store: this.store,
            panel: this.owner,
            panelName: this.panelName,
            goSearch: this.goSearch,
            owner: this
        })
    }
}), Ext.define("SYNO.SDS.PkgManApp.Beta.Panel", {
    extend: "SYNO.ux.Panel",
    helper: SYNO.SDS.PkgManApp.Utils.Helper,
    pkgListPaddingRight: 20,
    constructor: function(t) {
        this.callParent([this.fillConfig(t)]), this.mon(this.betaPkgList._view, "widthset", this.updateListviewFleXcroll, this);
        var e = SYNO.SDS.PkgManApp.Window.getStore("stable");
        this.mon(e, "load", function() {
            this.getEl().unmask(), this.determineEmptyMask()
        }, this), this.mon(e, "exception", function() {
            this.getEl().unmask(), this.getEl().mask(this.helper.T("commfail"), "")
        }, this)
    },
    onPageDeactivate: function() {
        this.layout.activeItem.fireEvent("deactivate")
    },
    fillConfig: function(t) {
        this.panelName = "SYNO.SDS.PkgManApp.Beta.Panel", this.listView = this.createListView();
        var e = {
            layout: "card",
            cls: "synopkg-module",
            border: !1,
            activeItem: 0,
            items: [this.listView, new SYNO.SDS.PkgManApp.Detail.Container({
                itemId: "detail",
                panel: "beta",
                panelName: this.panelName,
                targetStore: "beta"
            })],
            listeners: {
                activate: this._onActivate
            }
        };
        return Ext.apply(e, t), e
    },
    createListView: function() {
        this.betaPkgList = new SYNO.SDS.PkgManApp.Beta.BetaPkgList({
            owner: this,
            store: SYNO.SDS.PkgManApp.Window.getStore("beta"),
            panelName: this.panelName,
            viewType: "card"
        });
        var t = [this.betaPkgList, SYNO.SDS.PkgManApp.Legal.createLegalLinkContainer()];
        return new Ext.Container({
            owner: this,
            autoFlexcroll: !0,
            cls: "syno-pkg-view",
            style: {
                paddingRight: this.pkgListPaddingRight + "px"
            },
            listeners: {
                resize: this._onResize
            },
            items: t
        })
    },
    _onResize: function(t, e, i, a, n) {
        this.owner.betaPkgList && (this.owner.betaPkgList.getComponent(0).containerWidth = e - this.owner.pkgListPaddingRight)
    },
    _onActivate: function(t) {
        if (!SYNO.SDS.UserSettings.getProperty("SYNO.SDS.PkgManApp.Instance", "agreed_beta")) {
            var e = SYNO.SDS.PkgManApp.Window.termDialog;
            e && !e.hidden ? this.mon(e, "close", this.showAgreeBetaDialog.bind(this), {
                single: !0
            }) : this.showAgreeBetaDialog()
        }
        var i = SYNO.SDS.PkgManApp.Window.getStore("stable");
        i.exception ? this.getEl().mask(this.helper.T("commfail"), "") : i.loading || 0 !== i.getTotalCount() ? i.loading ? this.getEl().mask(this.helper.T("common", "loading"), "x-mask-loading") : (this.determineEmptyMask(), this.betaPkgList._activate()) : i.reload()
    },
    showAgreeBetaDialog: function() {
        SYNO.SDS.PkgManApp.Window.getMsgBox().show({
            title: this.helper.T("tree", "leaf_packagemanage"),
            msg: this.helper.T("pkgmgr", "update_channel_desc"),
            buttons: Ext.MessageBox.OK,
            fn: function(t) {
                "ok" === t && SYNO.SDS.UserSettings.setProperty("SYNO.SDS.PkgManApp.Instance", "agreed_beta", !0)
            },
            scope: this,
            cls: "syno-pkg-agree-beta-window"
        })
    },
    determineEmptyMask: function() {
        0 === SYNO.SDS.PkgManApp.Window.getStore("beta").getTotalCount() ? this.showEmptyMask() : this.hideEmptyMask()
    },
    showEmptyMask: function() {
        this.emptyMask ? this.emptyMask.show() : this.emptyMask = this.body.createChild({
            tag: "div",
            cls: "synopkg-empty-pkglist-mask",
            children: [{
                tag: "div",
                cls: "synopkg-empty-pkglist-icon"
            }, {
                tag: "div",
                cls: "synopkg-empty-pkglist-msg",
                html: _T("pkgmgr", "empty_beta_pkg_list")
            }]
        })
    },
    hideEmptyMask: function() {
        this.emptyMask && this.emptyMask.hide()
    },
    updateListviewFleXcroll: function() {
        this.listView.updateFleXcroll()
    }
}), Ext.define("SYNO.SDS.PkgManApp.Category.CategoryCards", {
    extend: "Ext.DataView",
    constructor: function(t) {
        function e(t) {
            var e = t.target.querySelector(".category-desc");
            e && e.classList.add("syno-pkg-ellipsis")
        }
        this.isRetina = SYNO.SDS.UIFeatures.test("isRetina");
        var i = {
            cls: "syno-pkg-categorycards-ct",
            tpl: this.createTpl(),
            itemSelector: ".syno-pkg-categorycard",
            trackOver: !0,
            listeners: {
                click: this.onCardClick,
                mouseenter: function(t, i, a) {
                    var n = a.querySelector(".syno-pkg-categorycard-desc"),
                        s = n && n.querySelector(".category-desc");
                    n && n.removeEventListener("transitionend", e), s && s.classList.remove("syno-pkg-ellipsis")
                },
                mouseleave: function(t, i, a) {
                    var n = a.querySelector(".syno-pkg-categorycard-desc");
                    n && n.addEventListener("transitionend", e)
                },
                scope: this
            }
        };
        Ext.apply(i, t), this.callParent([i])
    },
    createTpl: function() {
        return new Ext.XTemplate('<tpl for=".">', '<div data-id="{id}" class="syno-pkg-categorycard" style="{[this.getCardWidthStyle()]} background-image: url({[this.getBackground(values)]});">', '<div class="syno-pkg-categorycard-img" style="background-image: url({[this.getIcon(values)]});"></div>', '<div class="syno-pkg-categorycard-desc">', '<div class="category-title syno-pkg-ellipsis">{dname}</div>', '<div class="category-desc syno-pkg-ellipsis">{descr}</div>', "</div>", '<div class="syno-pkg-categorycard-desc-bottom"></div>', "</div>", "</tpl>", {
            compiled: !0,
            disableFormats: !0,
            getCardWidthStyle: this.getCardWidthStyle.bind(this),
            getBackground: this.getBackground.bind(this),
            getIcon: this.getIcon.bind(this)
        })
    },
    collectData: function(t, e) {
        var i = t.filter(function(t) {
            return "all" !== t.get("id")
        });
        return this.callParent([i, e])
    },
    onCardClick: function(t, e, i) {
        var a = {
            scrollToTop: !0,
            categoryId: i.getAttribute("data-id")
        };
        SYNO.SDS.PkgManApp.Window.jumpTo(this.owner.panelName, "pkglist", null, null, a)
    },
    setCardWidth: function(t) {
        var e, i, a = Ext.select(".syno-pkg-categorycard", !0, this.getEl().dom).elements;
        (!Ext.isNumber(t) || t <= 0) && (t = this.ownerCt.getWidth()), e = (t - 22 - 15 * ((i = t < 498 ? 1 : t < 930 ? 2 : t < 1096 ? 3 : t < 1650 ? 4 : 5) - 1)) / i, (e = Math.max(210, Math.floor(e))) !== this.cardWidth && (a.forEach(function(t) {
            return t.setWidth(e)
        }), this.cardWidth = e)
    },
    getCardWidthStyle: function() {
        return Ext.isNumber(this.cardWidth) ? "width:" + this.cardWidth + "px;" : ""
    },
    getBackground: function(t) {
        var e = t.bg && (this.isRetina ? t.bg[1] : t.bg[0]);
        if (!e) return "";
        var i = SYNO.API.Manager.getBaseURL("SYNO.Core.Package.CategoryImage", "get", 1);
        return Ext.urlAppend(i, Ext.urlEncode(SYNO.API.EncodeParams({
            name: t.id,
            type: "background",
            is_retina: this.isRetina,
            ver: SYNO.SDS.PkgManApp.Utils.Helper.hashCode(e).toString(),
            link: e
        })))
    },
    getIcon: function(t) {
        var e = t.icon && (this.isRetina ? t.icon[1] : t.icon[0]);
        if (!e) return "";
        var i = SYNO.API.Manager.getBaseURL("SYNO.Core.Package.CategoryImage", "get", 1);
        return Ext.urlAppend(i, Ext.urlEncode(SYNO.API.EncodeParams({
            name: t.id,
            type: "icon",
            is_retina: this.isRetina,
            ver: SYNO.SDS.PkgManApp.Utils.Helper.hashCode(e).toString(),
            link: e
        })))
    }
}), Ext.define("SYNO.SDS.PkgManApp.Category.Panel", {
    extend: "SYNO.ux.Panel",
    pkgListPaddingRight: 20,
    categoryPanelPaddingLeft: 16,
    constructor: function(t) {
        this.panelName = "SYNO.SDS.PkgManApp.Category.Panel", this.stablePkgStore = SYNO.SDS.PkgManApp.Window.getStore("stable"), this.categoryStore = SYNO.SDS.PkgManApp.Window.getStore("category");
        var e = {
            layout: "card",
            border: !1,
            activeItem: 0,
            panelName: this.panelName,
            cls: "syno-pkg-categories-panel synopkg-module",
            items: [this.getCardsPanel(), this.getPkgListPanel(), new SYNO.SDS.PkgManApp.Detail.Container({
                itemId: "detail",
                cls: "syno-pkg-categories-detail syno-pkg-view",
                panel: "category",
                panelName: this.panelName,
                targetStore: "stable"
            })]
        };
        Ext.apply(e, t), this.callParent([e]), this.mon(this.stablePkgStore, "load", this.onStablePkgStoreLoad, this), this.mon(this.stablePkgStore, "exception", this.determineStoreMask, this), this.mon(this.categoryStore, "load", this.resizeCategoryCards, this)
    },
    onPageActivate: function() {
        this.determineStoreMask(), this.resizeCategoryCards()
    },
    onPageDeactivate: function() {
        this.stablePkgStore.clearFilter()
    },
    onStablePkgStoreLoad: function() {
        this.determineStoreMask(), "pkglist" === this.layout.activeItem.itemId && this.currentCategoryId && this.jumpToCategory(this.currentCategoryId)
    },
    determineStoreMask: function() {
        this.stablePkgStore.exception || 0 === this.categoryStore.getTotalCount() ? this.getEl().mask(_T("pkgmgr", "commfail")) : this.getEl().unmask()
    },
    getCardsPanel: function() {
        return {
            xtype: "syno_panel",
            itemId: "categoryCards",
            cls: "syno-pkg-categories-cards syno-pkg-view",
            autoFlexcroll: !0,
            items: [{
                xtype: "box",
                itemId: "title",
                cls: "syno-pkg-category-pagetitle",
                html: _T("pkgmgr", "categories")
            }, new SYNO.SDS.PkgManApp.Category.CategoryCards({
                itemId: "cards",
                owner: this,
                store: this.categoryStore
            })],
            listeners: {
                activate: this.resizeCategoryCards,
                resize: this.resizeCategoryCards,
                scope: this
            }
        }
    },
    getPkgListPanel: function() {
        this.pkgLists = [new SYNO.SDS.PkgManApp.All.SynologyPkgList({
            owner: this,
            showTBar: !0,
            store: this.stablePkgStore,
            viewType: "card",
            panelName: this.panelName,
            headerText: _T("pkgmgr", "synology"),
            style: {
                marginBottom: "17px"
            }
        }), new SYNO.SDS.PkgManApp.All.ThirdPartyPkgList({
            owner: this,
            showTBar: !0,
            store: this.stablePkgStore,
            viewType: "card",
            panelName: this.panelName,
            headerText: _T("pkgmgr", "thirdparty")
        })];
        var t = [{
            xtype: "box",
            itemId: "title",
            ref: "../pkgListTitle",
            cls: "syno-pkg-category-pagetitle",
            html: _T("pkgmgr", "category")
        }];
        return t = t.concat(this.pkgLists), {
            xtype: "container",
            itemId: "pkglist",
            cls: "syno-pkg-view syno-pkg-categories-pkglist",
            autoFlexcroll: !0,
            style: {
                paddingRight: this.pkgListPaddingRight + "px",
                paddingBottom: "17px"
            },
            items: t,
            listeners: {
                resize: this.onPkgListResize,
                scope: this
            }
        }
    },
    onPkgListResize: function(t, e, i, a, n) {
        this.pkgLists.forEach(function(t) {
            t._view.containerWidth = e - this.pkgListPaddingRight - this.categoryPanelPaddingLeft
        }.bind(this))
    },
    resizeCategoryCards: function() {
        if (SYNO.SDS.PkgManApp.Window.getActivePage().panelName === this.panelName && "categoryCards" === this.layout.activeItem.itemId) {
            var t = this.getComponent("categoryCards");
            t.getComponent("cards").setCardWidth(t.getWidth() - this.categoryPanelPaddingLeft), t.updateFleXcroll()
        }
    },
    jumpToCategory: function(t) {
        this.currentCategoryId = t;
        var e = this.categoryStore.getById(t);
        this.pkgListTitle.update(e.get("dname") || t), this.stablePkgStore.filterBy(function(e) {
            return 0 <= e.get("category").indexOf(t)
        }), 0 === this.stablePkgStore.getCount() ? this.showPkglistEmptyMask() : (this.refreshPkglistView(), this.hidePkglistEmptyMask())
    },
    refreshPkglistView: function() {
        this.pkgLists.forEach(function(t) {
            t._activate()
        })
    },
    showPkglistEmptyMask: function() {
        if (this.pkglistEmptyMask) this.pkglistEmptyMask.show();
        else {
            var t = this.getComponent("pkglist");
            t.updateFleXcroll(), this.pkglistEmptyMask = t.el.createChild({
                tag: "div",
                cls: "synopkg-empty-pkglist-mask",
                children: [{
                    tag: "div",
                    cls: "synopkg-empty-pkglist-icon"
                }, {
                    tag: "div",
                    cls: "synopkg-empty-pkglist-msg",
                    html: _T("pkgmgr", "empty_pkg_list_due_to_beta")
                }]
            })
        }
    },
    hidePkglistEmptyMask: function() {
        this.pkglistEmptyMask && this.pkglistEmptyMask.hide()
    }
}), Ext.define("SYNO.SDS.PkgManApp.Community.CommunityCardView", {
    extend: "SYNO.SDS.PkgManApp.Utils.PkgListCardView",
    constructor: function(t) {
        this.callParent([t])
    },
    collectData: function(t, e) {
        if (this.goSearch) return this.filterCollectData(t, e);
        var i = [];
        return Ext.each(t, function(t) {
            i.push(t.data)
        }), i.sort(this.sortFunction), this.determineVisibility(i), i
    },
    getBetaClass: function(t) {
        return t.beta ? "syno-pkglist-beta" : ""
    },
    getSubTitle: function(t) {
        var e = this.getActionStatus(t);
        return e || String.format('<span ext:qtip="{0}">{0}</span>', t.maintainer || "")
    },
    getPrice: function(t) {
        return ""
    },
    getIcon: SYNO.SDS.PkgManApp.Utils.Helper.getIconFromServer
}), Ext.define("SYNO.SDS.PkgManApp.Community.CommunityPkgList", {
    extend: "SYNO.SDS.PkgManApp.Utils.PkgList",
    constructor: function(t) {
        this.callParent([t])
    },
    createCardView: function() {
        return new SYNO.SDS.PkgManApp.Community.CommunityCardView({
            store: this.store,
            panel: this.owner,
            panelName: this.panelName,
            goSearch: this.goSearch,
            owner: this
        })
    }
}), Ext.define("SYNO.SDS.PkgManApp.Community.Panel", {
    extend: "SYNO.ux.Panel",
    helper: SYNO.SDS.PkgManApp.Utils.Helper,
    pkgListPaddingRight: 20,
    constructor: function(t) {
        this.callParent([this.fillConfig(t)]), this.mon(this.communityPkgList._view, "widthset", this.updateListviewFleXcroll, this);
        var e = SYNO.SDS.PkgManApp.Window.getStore("community");
        this.mon(e, "load", function() {
            this.getEl().unmask()
        }, this), this.mon(e, "exception", function() {
            this.getEl().unmask(), this.getEl().mask(this.helper.T("commfail"), "")
        }, this)
    },
    onPageDeactivate: function() {
        this.layout.activeItem.fireEvent("deactivate")
    },
    fillConfig: function(t) {
        this.panelName = "SYNO.SDS.PkgManApp.Community.Panel", this.listView = this.createListView();
        var e = {
            layout: "card",
            cls: "synopkg-module",
            border: !1,
            activeItem: 0,
            items: [this.listView, new SYNO.SDS.PkgManApp.Detail.Container({
                itemId: "detail",
                panel: "community",
                panelName: this.panelName,
                targetStore: "community"
            })],
            listeners: {
                activate: this._onActivate
            }
        };
        return Ext.apply(e, t), e
    },
    createListView: function() {
        this.communityPkgList = new SYNO.SDS.PkgManApp.Community.CommunityPkgList({
            owner: this,
            store: SYNO.SDS.PkgManApp.Window.getStore("community"),
            panelName: this.panelName,
            viewType: "card"
        });
        var t = [this.communityPkgList, SYNO.SDS.PkgManApp.Legal.createLegalLinkContainer()];
        return new Ext.Container({
            owner: this,
            autoFlexcroll: !0,
            cls: "syno-pkg-view",
            style: {
                paddingRight: this.pkgListPaddingRight + "px"
            },
            listeners: {
                resize: this._onResize
            },
            items: t
        })
    },
    _onResize: function(t, e, i, a, n) {
        this.owner.communityPkgList && (this.owner.communityPkgList.getComponent(0).containerWidth = e - this.owner.pkgListPaddingRight)
    },
    _onActivate: function(t) {
        var e = SYNO.SDS.PkgManApp.Window.getStore("community");
        e.exception ? this.getEl().mask(this.helper.T("commfail"), "") : e.loading || 0 !== e.getTotalCount() ? e.loading ? this.getEl().mask(this.helper.T("common", "loading"), "x-mask-loading") : this.communityPkgList._activate() : e.reload()
    },
    updateListviewFleXcroll: function() {
        this.listView.updateFleXcroll()
    }
}), Ext.ns("SYNO.SDS.PkgManApp"), SYNO.SDS.PkgManApp.Config = {}, Ext.apply(SYNO.SDS.PkgManApp.Config, {
    RECOMMEND_LIST_BIG_NUMBER: 4,
    LIST_PKG_CELL_WIDTH: 152,
    SORT_MENU_WIDTH: 220,
    DEFAULT_CURRENCY: "USD",
    DEFICON_64: "images/package_center_64.png",
    DEFICON_256: "images/package_center_256.png",
    myDSRemindPassURL: "https://myds.synology.com/support/register_password_remind.php",
    myDSRegister: "https://myds.synology.com/support/register_form.php",
    agreed_tos_hash_key: "agreed_tos_hash",
    tos_hash_key: "tos_hash",
    tos_hash_timestamp_key: "tos_hash_timestamp"
}), SYNO.SDS.PkgManApp.SERVICE = {}, Ext.apply(SYNO.SDS.PkgManApp.SERVICE, {
    PKG_SERVICES_SSH: 1,
    PKG_SERVICES_PGSQL: 2
}), Ext.define("SYNO.SDS.PkgManApp.Detail.RelatedPkgCardView", {
    extend: "SYNO.SDS.PkgManApp.Utils.PkgListCardView",
    constructor: function(t) {
        this.callParent([t])
    },
    createTpl: function() {
        return new Ext.XTemplate('<tpl for=".">', '<div data-id="{id}" class="syno-pkglist-related-card">', '<div class="syno-pkglist-icon">', '<img class="syno-pkg-icon-img" src="{[this.getTransparentDataURI()]}" style="background:url(\'{[this.getIcon(values, undefined)]}\');background-size:64px;">', "</div>", '<div class="syno-pkglist-info">', '<span class="syno-pkglist-title">', "{[this.getTitle(values)]}", "</span>", '<span class="syno-pkglist-subtitle">', "{[this.getSubTitle(values)]}", "</span>", "</div>", '<div class="syno-pkglist-btn">', "{[this.getActionBtn(values)]}", "</div>", "</div>", "</tpl>", {
            compiled: !0,
            disableFormats: !0,
            getActionBtn: this.getActionBtn.createDelegate(this),
            getSubTitle: this.getSubTitle.createDelegate(this),
            getTransparentDataURI: SYNO.SDS.PkgManApp.Utils.Helper.getTransparentDataURI.createDelegate(this)
        })
    },
    collectData: function(t, e) {
        var i = [],
            a = this.owner.owner.getPkgData(),
            n = a.category,
            s = [],
            r = [],
            o = 3;
        return n && Ext.isArray(n) ? (n.forEach(function(t) {
            SYNO.SDS.PkgManApp.Window.getStore("category").getById(t).get("isCompilation") ? s.push(t) : r.push(t)
        }, this), (o = 3 - (i = this.getRelatedPkgs(t, i, o, a, s, !1, !1)).length) > 0 && (o = 3 - (i = this.getRelatedPkgs(t, i, o, a, n, !1, !1)).length), o > 0 && (o = 3 - (i = this.getRelatedPkgs(t, i, o, a, s, !1, !0)).length), o > 0 && (o = 3 - (i = this.getRelatedPkgs(t, i, o, a, n, !1, !0)).length), o > 0 && (o = 3 - (i = this.getRelatedPkgs(t, i, o, a, s, !0, !1)).length), o > 0 && (o = 3 - (i = this.getRelatedPkgs(t, i, o, a, n, !0, !1)).length), o > 0 && (o = 3 - (i = this.getRelatedPkgs(t, i, o, a, s, !0, !0)).length), o > 0 && (o = 3 - (i = this.getRelatedPkgs(t, i, o, a, n, !0, !0)).length), this.determineVisibility(i), i) : i
    },
    getRelatedPkgs: function(t, e, i, a, n, s, r) {
        return Ext.each(t, function(t) {
            var o = t.get("thirdparty") || !1;
            0 !== i && t.id !== a.id && (this._IsInstNormal(t.id) !== s || !this.categoryIntersect(t.get("category"), n) || o !== r || a.conflictpkgs && t.id in a.conflictpkgs || -1 != e.indexOf(t.data) || (e.push(t.data), i--))
        }, this), e
    },
    categoryIntersect: function(t, e) {
        var i = !1;
        return !(!Ext.isArray(t) || !Ext.isArray(e)) && (t.forEach(function(t) {
            e.forEach(function(e) {
                t === e && (i = !0)
            }, this)
        }, this), i)
    },
    getCardClass: function() {
        return ".syno-pkglist-related-card"
    },
    getBetaClass: function(t) {
        return ""
    },
    getSubTitle: function(t) {
        var e = this.getActionStatus(t);
        if (e) return e;
        var i = [],
            a = SYNO.SDS.PkgManApp.Window.getStore("category");
        return Ext.each(t.category, function(t) {
            a.getById(t) ? i.push(a.getById(t).get("dname")) : i.push(t)
        }), i.join(", ")
    },
    onViewResize: function() {},
    delayedViewResize: function() {},
    getIcon: SYNO.SDS.PkgManApp.Utils.Helper.getIconFromServer
}), Ext.define("SYNO.SDS.PkgManApp.Detail.RelatedPkgList", {
    extend: "SYNO.SDS.PkgManApp.Utils.PkgList",
    constructor: function(t) {
        this.callParent([t])
    },
    createCardView: function() {
        return new SYNO.SDS.PkgManApp.Detail.RelatedPkgCardView({
            store: this.store,
            panel: this.owner,
            panelName: this.panelName,
            owner: this
        })
    },
    refreshView: function() {},
    onViewResize: function() {}
}), Ext.define("SYNO.SDS.PkgManApp.Installed.CautionListView", {
    extend: "SYNO.SDS.PkgManApp.Utils.PkgListListView",
    constructor: function(t) {
        SYNO.SDS.PkgManApp.Utils.Utils._initWinWrappers.call(this, t), this.callParent([t])
    },
    collectData: function(t, e) {
        var i = [];
        return Ext.each(t, function(t) {
            t.data.dname && (this._IsOperationRequired(t.data) || this._IsInstalling(t.data) || "queueing" === t.data.status) && i.push(t.data)
        }, this), i.sort(this.sortFunction), this.determineVisibility(i), i
    },
    sortFunction: function(t, e) {
        var i, a, n = function(t) {
            return "repairing" === t.status ? 0 : "upgrading" === t.status ? 1 : "installing" === t.status ? 2 : "queueing" === t.status ? 3 : "version_limit" === t.statusOrigin && t.available_operation && Object.keys(t.available_operation).length > 0 ? 4 : "broken" === t.statusOrigin || "license_error" === t.statusOrigin || "broken_by_other" === t.statusOrigin ? 5 : "stopped_by_dep_limit" === t.statusOrigin ? 6 : "start_failed" === t.statusOrigin ? 7 : "version_limit" === t.statusOrigin && "non" !== t.limit_type && "system" !== t.limit_type ? 8 : "version_limit" === t.statusOrigin ? 9 : "running" === t.statusOrigin ? 10 : "stop" === t.statusOrigin ? 11 : SYNO.SDS.PkgManApp.Utils.Utils.isBrokenStatus(t) ? 9 : 12
        };
        if ((i = n(t)) === (a = n(e))) {
            var s = t.dname || t.id,
                r = e.dname || e.id;
            return s.localeCompare(r)
        }
        return i > a ? 1 : -1
    },
    getDesc: function(t) {
        return this._getOperationInfo(t, this.panelName).descriptionText
    },
    getActionBtn: function(t) {
        return null != t.operation.actionFunction ? this.getActionTemplate(t).actiontext : ""
    },
    getActionTemplate: function(t) {
        var e = this._getOperationInfo(t, this.panelName),
            i = e.actionText,
            a = e.statusText,
            n = e.statusColor,
            s = e.buttonClass,
            r = e.isButtonDisabled;
        if (a) {
            var o = "<div class='syno-pkg-status'>";
            o += "<font style='color:" + n + ";display:table;margin:auto;' ext:qtip='" + a + "'>", o += "&nbsp;", o += a, a = o += "</font></div>"
        }
        return {
            actiontext: this.getBtnTemplate(i, s, r, t.dname),
            statustext: a
        }
    },
    getBtnTemplate: function(t, e, i, a) {
        return String.format('<div ext:qtip="{0}">                <span cellspacing="0" class="x-btn syno-ux-button {1} {2} x-btn-noicon" style="width: auto; margin-left: 0px;">                    <em class="x-unselectable" unselectable="on">                        <button ext:qtip="{3}" type="button" class=" x-btn-text" aria-label="{3} {4}">                        {3}                        </button>                    </em>                </span>            </div>', _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "", e || "syno-ux-button-grey", i ? "x-item-disabled" : "", t, a || "")
    },
    getIcon: function(t, e) {
        var i = this._getOperationInfo(t, this.panelName);
        return i.targetRecord.data.source ? this.helper.getIconFromServer(i.targetRecord.data, e) : this.helper.getIconFromDS(i.targetRecord.data, e)
    },
    getBetaClass: function(t) {
        var e = this._getOperationInfo(t, this.panelName);
        return e.targetRecord && e.targetRecord.data.beta ? "syno-pkglist-beta syno-pkglist-list-beta" : ""
    }
}), Ext.define("SYNO.SDS.PkgManApp.Installed.CautionPkgList", {
    helper: SYNO.SDS.PkgManApp.Utils.Helper,
    extend: "SYNO.SDS.PkgManApp.Utils.PkgList",
    constructor: function(t) {
        this.callParent([t]), this.mon(SYNO.SDS.PkgManApp.Window.getStore("stable"), "load", this.setGroupBtnAndRefreshView, this), this.mon(SYNO.SDS.PkgManApp.Window.getStore("community"), "load", this.setGroupBtnAndRefreshView, this), this.mon(SYNO.SDS.PkgManApp.Window.getStore("installed"), "load", this.setGroupBtnAndRefreshView, this), this.mon(SYNO.SDS.PkgManApp.Window.getStore("stable"), "update", this.setGroupBtnAndRefreshView, this), this.mon(SYNO.SDS.PkgManApp.Window.getStore("community"), "update", this.setGroupBtnAndRefreshView, this), this.mon(SYNO.SDS.PkgManApp.Window.getStore("installed"), "update", this.setGroupBtnAndRefreshView, this), this.setGroupBtn()
    },
    createListView: function() {
        return new SYNO.SDS.PkgManApp.Installed.CautionListView({
            store: this.store,
            panel: this.owner,
            panelName: this.panelName,
            owner: this
        })
    }
}), Ext.define("SYNO.SDS.PkgManApp.Installed.InstalledCardView", {
    extend: "SYNO.SDS.PkgManApp.Utils.PkgListCardView",
    constructor: function(t) {
        this.callParent([t])
    },
    collectData: function(t, e) {
        if (this.goSearch) return this.filterCollectData(t, e);
        var i = [];
        return Ext.each(t, function(t) {
            t.data.dname && (this._IsOperationRequired(t.data) || this._IsInstalling(t.data) || "queueing" === t.data.status || i.push(t.data))
        }, this), i.sort(this.sortFunction), this.determineVisibility(i), i
    },
    sortFunction: function(t, e) {
        return e.updated_at.localeCompare(t.updated_at)
    },
    getBetaClass: function(t) {
        return t.beta ? "syno-pkglist-beta" : ""
    },
    getSubTitle: function(t) {
        if ("loading" === t.status) return String.format('<span ><font ext:qtip="{0}" class="syno-pkg-status" style="color:#057FEB;">{0}</font></span>', _T("pkgmgr", "loading"));
        if (t.updated_at) {
            var e = t.updated_at.split("/"),
                i = new Date(e[0], e[1] - 1, e[2]),
                a = SYNO.SDS.DateTimeFormatter(i, {
                    type: "date"
                });
            return String.format('<span ext:qtip="{0}">{0}</span>', a)
        }
        return ""
    },
    getPrice: function(t) {
        return ""
    },
    getIcon: SYNO.SDS.PkgManApp.Utils.Helper.getIconFromDS
}), Ext.define("SYNO.SDS.PkgManApp.Installed.InstalledPkgList", {
    extend: "SYNO.SDS.PkgManApp.Utils.PkgList",
    constructor: function(t) {
        this.callParent([t]), this.mon(SYNO.SDS.PkgManApp.Window.getStore("stable"), "load", this.setGroupBtnAndRefreshView, this), this.mon(SYNO.SDS.PkgManApp.Window.getStore("community"), "load", this.setGroupBtnAndRefreshView, this)
    },
    createCardView: function() {
        return new SYNO.SDS.PkgManApp.Installed.InstalledCardView({
            store: this.store,
            panel: this.owner,
            panelName: this.panelName,
            goSearch: this.goSearch,
            owner: this
        })
    }
}), Ext.define("SYNO.SDS.PkgManApp.Installed.Panel", {
    extend: "SYNO.ux.Panel",
    helper: SYNO.SDS.PkgManApp.Utils.Helper,
    pkgListPaddingRight: 20,
    constructor: function(t) {
        this.callParent([this.fillConfig(t)]), this.mon(this.cautionPkgList._view, "widthset", this.updateListviewFleXcroll, this), this.mon(this.installedPkgList._view, "widthset", this.updateListviewFleXcroll, this)
    },
    onPageDeactivate: function() {
        this.layout.activeItem.fireEvent("deactivate")
    },
    fillConfig: function(t) {
        this.panelName = "SYNO.SDS.PkgManApp.Installed.Panel", this.listView = this.createListView();
        var e = {
            layout: "card",
            cls: "synopkg-module",
            border: !1,
            activeItem: 0,
            items: [this.listView, new SYNO.SDS.PkgManApp.Detail.Container({
                itemId: "detail",
                panel: "installed",
                panelName: this.panelName,
                targetStore: "installed"
            })],
            listeners: {
                activate: this._onActivate
            }
        };
        return Ext.apply(e, t), e
    },
    createListView: function() {
        this.cautionPkgList = new SYNO.SDS.PkgManApp.Installed.CautionPkgList({
            owner: this,
            showTBar: !0,
            style: {
                marginBottom: "17px"
            },
            store: SYNO.SDS.PkgManApp.Window.getStore("installed"),
            viewType: "list",
            showTBarBtns: !0,
            panelName: this.panelName,
            headerText: this.helper.T("status_broken_title")
        }), this.installedPkgList = new SYNO.SDS.PkgManApp.Installed.InstalledPkgList({
            owner: this,
            showTBar: !0,
            store: SYNO.SDS.PkgManApp.Window.getStore("installed"),
            viewType: "card",
            panelName: this.panelName,
            headerText: this.helper.T("install_packages")
        });
        var t = [this.cautionPkgList, this.installedPkgList];
        return new Ext.Container({
            owner: this,
            autoFlexcroll: !0,
            cls: "syno-pkg-view",
            style: {
                paddingRight: this.pkgListPaddingRight + "px",
                paddingBottom: "17px"
            },
            listeners: {
                resize: this._onResize
            },
            items: t
        })
    },
    _onResize: function(t, e, i, a, n) {
        this.owner.installedPkgList && (this.owner.installedPkgList.getComponent(1).containerWidth = e - this.owner.pkgListPaddingRight)
    },
    _onActivate: function(t) {
        this.cautionPkgList._activate(), this.installedPkgList._activate()
    },
    updateListviewFleXcroll: function() {
        this.listView.updateFleXcroll()
    }
}), Ext.define("SYNO.SDS.PkgManApp.Term.Base", {
    extend: SYNO.ux.Panel,
    constructor: function(t) {
        Ext.apply(this, t);
        var e = {
            items: this.createItems(),
            cls: "syno-pkg-term-field",
            width: 680
        };
        this.callParent([Ext.apply(e, t)]), this.relayEvents(this.getCheckBox(), ["check"])
    },
    createItems: function() {
        return [{
            xtype: "box",
            cls: "syno-pkg-term-title",
            itemId: "syno-pkg-term-title",
            html: this.title
        }, {
            xtype: "container",
            itemId: "syno-pkg-term-container",
            items: [{
                xtype: "box",
                cls: "syno-pkg-term-subtitle",
                html: this.subTitle,
                height: 48
            }, new SYNO.ux.Panel({
                xtype: "box",
                cls: "syno-pkg-term-content",
                itemId: "syno-pkg-term-content",
                autoFlexcroll: !0,
                items: [{
                    xtype: "box",
                    cls: "syno-pkg-term-content-inner",
                    itemId: "syno-pkg-term-content-inner",
                    html: this.termContent
                }],
                height: 260
            }), {
                xtype: "syno_checkbox",
                itemId: "syno-pkg-term-check",
                height: 28,
                boxLabel: this.checkBoxMsg
            }]
        }]
    },
    isAgree: function() {
        return this.getCheckBox().getValue()
    },
    getCheckBox: function() {
        return this.getComponent("syno-pkg-term-container").getComponent("syno-pkg-term-check")
    }
}), Ext.define("SYNO.SDS.PkgManApp.Term.Service", {
    extend: SYNO.SDS.PkgManApp.Term.Base,
    constructor: function(t) {
        var e = {
            title: _T("pkgmgr", "termofservice_title"),
            subTitle: _T("pkgmgr", "termofservice_subtitle"),
            termContent: _T("pkgmgr", "termofservice_content"),
            checkBoxMsg: _T("pkgmgr", "termofservice_confirm")
        };
        this.callParent([Ext.apply(e, t)])
    }
}), Ext.define("SYNO.SDS.PkgManApp.TermDialog", {
    extend: SYNO.SDS.ModalWindow,
    constructor: function(t) {
        Ext.apply(this, t), this.closeOwner = !0;
        var e = {
            width: 720,
            height: 500,
            resizable: !1,
            autoFlexcroll: !0,
            buttonAlign: "center",
            cls: "syno-pkg-term",
            itemId: "syno-pkg-term",
            title: _T("tree", "leaf_packagemanage"),
            items: [this.createItems()],
            fbar: this.createFootBar()
        };
        this.callParent([Ext.apply(e, t)]), this.bindEvents()
    },
    createItems: function() {
        return [new SYNO.SDS.PkgManApp.Term.Service({
            itemId: "ToS",
            termCollapsed: !1
        })]
    },
    createFootBar: function() {
        var t = new Ext.Toolbar({
            items: [{
                xtype: "syno_button",
                itemId: "agree-button",
                cls: "syno-pkg-term-btn",
                text: _T("common", "ok"),
                btnStyle: "blue",
                scope: this,
                disabled: !0,
                handler: this.onClickOk
            }]
        });
        return this.btnOk = t.getComponent("agree-button"), Ext.QuickTips.register({
            target: this.btnOk,
            text: _T("pkgmgr", "term_remind")
        }), t
    },
    bindEvents: function() {
        var t = this.getComponent("ToS");
        this.mon(t, "check", function(e, i) {
            var a = !t.isAgree();
            this.btnOk.setDisabled(a), a ? Ext.QuickTips.register({
                target: this.btnOk,
                text: _T("pkgmgr", "term_remind")
            }) : Ext.QuickTips.unregister(this.btnOk)
        }, this, {
            delay: 10
        }), this.mon(this, "close", function() {
            this.closeOwner && this.owner.fireEvent.defer(10, this.owner, ["disagreeterm"])
        }, this)
    },
    onClickOk: function() {
        this.curr_term_version && SYNO.SDS.UserSettings.setProperty("SYNO.SDS.PkgManApp.Instance", "agreed_term_version", this.curr_term_version), this.closeOwner = !1, this.close()
    }
}), Ext.ns("SYNO.SDS.PkgManApp.Utils"), SYNO.SDS.PkgManApp.Utils.StoreHelper = {
    createInstalledStore: function() {
        return new SYNO.API.Store({
            autoLoad: !1,
            remoteSort: !1,
            proxy: new Ext.data.MemoryProxy([]),
            reader: new Ext.data.JsonReader({
                root: "packages",
                id: "id"
            }, [{
                name: "id"
            }, {
                name: "dname",
                mapping: "name"
            }, {
                name: "desc",
                mapping: "additional.description"
            }, {
                name: "desc_enu",
                mapping: "additional.description_enu"
            }, {
                name: "version"
            }, {
                name: "status",
                mapping: "additional.status"
            }, {
                name: "statusOrigin",
                mapping: "additional.status_origin"
            }, {
                name: "broken_by",
                mapping: "additional.broken_by"
            }, {
                name: "limit_type",
                mapping: "additional.limit_type"
            }, {
                name: "progress",
                mapping: "additional.installing_progress"
            }, {
                name: "maintainer",
                mapping: "additional.maintainer"
            }, {
                name: "maintainer_url",
                mapping: "additional.maintainer_url"
            }, {
                name: "distributor",
                mapping: "additional.distributor"
            }, {
                name: "distributor_url",
                mapping: "additional.distributor_url"
            }, {
                name: "url",
                mapping: "additional.url"
            }, {
                name: "pkgstartable",
                mapping: "additional.startable",
                type: "boolean"
            }, {
                name: "ctl_uninstall",
                mapping: "additional.ctl_uninstall",
                type: "boolean"
            }, {
                name: "pkgisuninstui",
                mapping: "additional.is_uninstall_pages"
            }, {
                name: "icon"
            }, {
                name: "pkgreporturl",
                mapping: "additional.report_beta_url"
            }, {
                name: "support_center",
                mapping: "additional.support_center"
            }, {
                name: "beta",
                mapping: "additional.beta",
                type: "boolean"
            }, {
                name: "support_url",
                mapping: "additional.support_url"
            }, {
                name: "dsm_apps",
                mapping: "additional.dsm_apps"
            }, {
                name: "dsm_app_page",
                mapping: "additional.dsm_app_page"
            }, {
                name: "dsm_app_launch_name",
                mapping: "additional.dsm_app_launch_name"
            }, {
                name: "pkgtarget",
                mapping: "additional.installed_info"
            }, {
                name: "install_type",
                mapping: "additional.install_type"
            }, {
                name: "inst_type"
            }, {
                name: "autoupdate",
                mapping: "additional.autoupdate"
            }, {
                name: "silent_upgrade",
                mapping: "additional.silent_upgrade"
            }, {
                name: "updated_at",
                mapping: "additional.updated_at"
            }, {
                name: "available_operation",
                mapping: "additional.available_operation"
            }, {
                name: "statusTitle"
            }, {
                name: "statusDescription"
            }, {
                name: "statusDesktop"
            }, {
                name: "installing_target",
                mapping: "additional.installing_target"
            }]),
            listeners: {
                scope: this
            }
        })
    },
    createBetaStore: function() {
        return new SYNO.API.Store({
            autoLoad: !1,
            remoteSort: !1,
            proxy: new Ext.data.MemoryProxy([]),
            reader: new Ext.data.JsonReader({
                root: "beta_packages",
                id: "id"
            }, this.getServerStoreItem())
        })
    },
    createBannerStore: function() {
        return new SYNO.API.Store({
            autoLoad: !1,
            remoteSort: !1,
            proxy: new Ext.data.MemoryProxy([]),
            reader: new Ext.data.JsonReader({
                root: "banners"
            }, [{
                name: "title"
            }, {
                name: "descr"
            }, {
                name: "background"
            }, {
                name: "icon"
            }, {
                name: "type"
            }, {
                name: "keyword"
            }, {
                name: "link"
            }, {
                name: "beta",
                type: "boolean"
            }, {
                name: "css_icon",
                mapping: "css.icon"
            }, {
                name: "css_title",
                mapping: "css.title"
            }, {
                name: "css_desc",
                mapping: "css.desc"
            }, {
                name: "css_triangle",
                mapping: "css.triangle"
            }, {
                name: "css_string",
                mapping: "css.string"
            }])
        })
    },
    createCategoryStore: function() {
        return new SYNO.API.Store({
            autoLoad: !1,
            remoteSort: !1,
            proxy: new Ext.data.MemoryProxy([]),
            reader: new Ext.data.JsonReader({
                root: "categories",
                id: "id"
            }, [{
                name: "id"
            }, {
                name: "dname"
            }, {
                name: "descr"
            }, {
                name: "bg"
            }, {
                name: "icon"
            }, {
                name: "isCompilation",
                type: "boolen"
            }])
        })
    },
    getServerStoreItem: function() {
        return [{
            name: "id"
        }, {
            name: "desc"
        }, {
            name: "desc_enu"
        }, {
            name: "changelog"
        }, {
            name: "version"
        }, {
            name: "icon"
        }, {
            name: "link"
        }, {
            name: "md5"
        }, {
            name: "source"
        }, {
            name: "dsm_apps"
        }, {
            name: "url"
        }, {
            name: "open"
        }, {
            name: "thumbnail"
        }, {
            name: "thumbnail_retina"
        }, {
            name: "snapshot"
        }, {
            name: "install_type"
        }, {
            name: "install_on_cold_storage"
        }, {
            name: "depsers"
        }, {
            name: "deppkgs"
        }, {
            name: "conflictpkgs"
        }, {
            name: "breakpkgs"
        }, {
            name: "replacepkgs"
        }, {
            name: "replaceforcepkgs"
        }, {
            name: "replace_message"
        }, {
            name: "maintainer"
        }, {
            name: "maintainer_url"
        }, {
            name: "distributor"
        }, {
            name: "distributor_url"
        }, {
            name: "blupgrade"
        }, {
            name: "beta"
        }, {
            name: "support_url"
        }, {
            name: "broken_by"
        }, {
            name: "thirdparty"
        }, {
            name: "info"
        }, {
            name: "dname",
            sortType: function(t) {
                return t ? t.toLowerCase() : ""
            }
        }, {
            name: "size",
            type: "int"
        }, {
            name: "progress",
            type: "float"
        }, {
            name: "qinst",
            type: "boolean"
        }, {
            name: "qupgrade",
            type: "boolean"
        }, {
            name: "qstart",
            type: "boolean"
        }, {
            name: "start",
            type: "boolean"
        }, {
            name: "download_count",
            type: "int"
        }, {
            name: "recent_download_count",
            type: "int"
        }, {
            name: "type",
            type: "int"
        }, {
            name: "price",
            type: "object"
        }, {
            name: "category"
        }]
    }
}, Ext.define("SYNO.SDS.PkgManApp.Utils.SearchField", {
    extend: "SYNO.ux.TextFilter",
    constructor: function(t) {
        this.callParent([this.fillConfig(t)])
    },
    fillConfig: function(t) {
        var e = {
            enableKeyEvents: !0,
            listeners: {
                keypress: this._onKeypress
            }
        };
        return Ext.apply(e, t), e
    },
    _onKeypress: function(t, e) {
        e.getKey() == Ext.EventObject.ENTER && (e.preventDefault(), this.isSearchPageActive() ? SYNO.SDS.PkgManApp.Window.pageCt.ownerCt.pageCt.getComponent("SYNO.SDS.PkgManApp.SearchResult.Panel")._onActivate() : SYNO.SDS.PkgManApp.Window.pageList.getNodeById("SYNO.SDS.PkgManApp.SearchResult.Panel").select())
    },
    onTriggerClick: function() {
        this.callParent(arguments), this.isSearchPageActive() && SYNO.SDS.PkgManApp.Window.pageList.getNodeById("SYNO.SDS.PkgManApp.All.Panel").select()
    },
    isSearchPageActive: function() {
        return SYNO.SDS.PkgManApp.Window.pageList.getNodeById("SYNO.SDS.PkgManApp.SearchResult.Panel").isSelected()
    },
    onResize: function() {}
}), Ext.define("SYNO.SDS.PkgManApp.SearchResult.Panel", {
    extend: "SYNO.ux.Panel",
    helper: SYNO.SDS.PkgManApp.Utils.Helper,
    pkgListPaddingRight: 20,
    constructor: function(t) {
        this.callParent([this.fillConfig(t)]), this.pkgLists.forEach(function(t) {
            this.mon(t._view, "widthset", this.updateListviewFleXcroll, this), this.mon(t._view.store, "load", this.determineEmptyResultMask, this)
        }, this)
    },
    fillConfig: function(t) {
        this.panelName = "SYNO.SDS.PkgManApp.SearchResult.Panel", this.listView = this.createListView();
        var e = {
            searchtext: "",
            id: "SYNO.SDS.PkgManApp.SearchResult.Panel",
            layout: "card",
            cls: "synopkg-module",
            border: !1,
            activeItem: 0,
            items: [this.listView, new SYNO.SDS.PkgManApp.Detail.Container({
                itemId: "detail"
            })],
            listeners: {
                activate: this._onActivate
            }
        };
        return Ext.apply(e, t), e
    },
    createDescriptionStore: function() {
        return new Ext.data.JsonStore({
            autoDestroy: !0,
            fields: ["title", "description"]
        })
    },
    createDescription: function() {
        return this.descriptionStore = this.createDescriptionStore(), new Ext.DataView({
            cls: "synopkg-search-result",
            tpl: new Ext.XTemplate('<tpl for=".">', '<div class="title">', "<span>{title}</span>", "</div>", '<div class="banner_robot">', '<div class="robot_head"></div>', '<span class="font">{description}</span>', "</div>", "</tpl>", {
                compiled: !0,
                disableFormats: !0
            }),
            style: {
                marginBottom: "17px"
            },
            store: this.descriptionStore
        })
    },
    createListView: function() {
        this.description = this.createDescription(), this.synologyPkgList = new SYNO.SDS.PkgManApp.All.SynologyPkgList({
            owner: this,
            style: {
                marginBottom: "17px"
            },
            showTBar: !0,
            store: SYNO.SDS.PkgManApp.Window.getStore("stable"),
            viewType: "card",
            panelName: "SYNO.SDS.PkgManApp.All.Panel",
            goSearch: !0,
            headerText: this.helper.T("class_all")
        }), this.betaPkgList = new SYNO.SDS.PkgManApp.Beta.BetaPkgList({
            owner: this,
            style: {
                marginBottom: "17px"
            },
            showTBar: !0,
            store: SYNO.SDS.PkgManApp.Window.getStore("beta"),
            viewType: "card",
            panelName: "SYNO.SDS.PkgManApp.Beta.Panel",
            goSearch: !0,
            headerText: this.helper.T("class_beta")
        }), this.communityPkgList = new SYNO.SDS.PkgManApp.Community.CommunityPkgList({
            owner: this,
            showTBar: !0,
            store: SYNO.SDS.PkgManApp.Window.getStore("community"),
            viewType: "card",
            panelName: "SYNO.SDS.PkgManApp.Community.Panel",
            goSearch: !0,
            headerText: this.helper.T("class_community")
        });
        var t = [this.description, this.synologyPkgList, this.betaPkgList, this.communityPkgList];
        return this.pkgLists = t.slice(1), new Ext.Container({
            owner: this,
            autoFlexcroll: !0,
            cls: "syno-pkg-view",
            style: {
                paddingRight: this.pkgListPaddingRight + "px",
                paddingBottom: "17px"
            },
            listeners: {
                resize: this._onResize
            },
            items: t
        })
    },
    _onResize: function(t, e, i, a, n) {
        this.owner.pkgLists.forEach(function(t) {
            t.getComponent(1).containerWidth = e - this.owner.pkgListPaddingRight
        }, this)
    },
    onPageDeactivate: function() {
        return SYNO.SDS.PkgManApp.Window.toolBar.searchField.setValue(""), !0
    },
    onLoadData: function() {
        this.searchtext = SYNO.SDS.PkgManApp.Window.toolBar.searchField.getValue().toLowerCase();
        var t = SYNO.SDS.PkgManApp.Window.getStore("category").getById(this.searchtext);
        Ext.each(this.pkgLists, function(t) {
            t.hide()
        }), t && t.get("isCompilation") ? (this.descriptionStore.loadData([{
            title: t.get("dname"),
            description: t.get("descr")
        }]), this.description.show(), this.synologyPkgList._activate()) : (this.description.hide(), Ext.each(this.pkgLists, function(t) {
            t._activate()
        })), this.determineEmptyResultMask(), this.scrollToTop()
    },
    determineEmptyResultMask: function() {
        var t = !1;
        Ext.each(this.pkgLists, function(e) {
            if (e.isVisible()) return t = !0, !1
        }, this), t ? this.hideEmptyResultMask() : this.showEmptyResultMask()
    },
    showEmptyResultMask: function() {
        this.emptyMask ? this.emptyMask.show() : this.emptyMask = this.body.createChild({
            tag: "div",
            cls: "synopkg-empty-pkglist-mask",
            children: [{
                tag: "div",
                cls: "synopkg-empty-pkglist-icon"
            }, {
                tag: "div",
                cls: "synopkg-empty-pkglist-msg",
                html: _T("search", "no_search_result")
            }]
        })
    },
    hideEmptyResultMask: function() {
        this.emptyMask && this.emptyMask.hide()
    },
    _onActivate: function() {
        SYNO.SDS.PkgManApp.Window.getStore("stable").clearFilter(), SYNO.SDS.PkgManApp.Window.setCurrentPage(this.panelName, 0, SYNO.SDS.PkgManApp.Window.toolBar.searchField.getValue()), this.onLoadData()
    },
    updateListviewFleXcroll: function() {
        this.listView.updateFleXcroll()
    },
    scrollToTop: function() {
        this.listView.el.dom.fleXcroll && (this.listView.el.dom.fleXcroll.setScrollPos(!1, 0), this.listView.updateFleXcroll())
    }
}), Ext.ns("SYNO.SDS.PkgManApp.Action"), SYNO.SDS.PkgManApp.Action = {}, Ext.apply(SYNO.SDS.PkgManApp.Action, {
    sendWebAPIInsensitivePromise: function() {
        var t = _asyncToGenerator(regeneratorRuntime.mark(function t(e) {
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.abrupt("return", new Promise(function(t, i) {
                            e.callback = function(e, i, a, n) {
                                t([e, i, a, n])
                            };
                            try {
                                this.sendWebAPI(e)
                            } catch (t) {
                                i(t)
                            }
                        }.bind(this)));
                    case 1:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }));
        return function(e) {
            return t.apply(this, arguments)
        }
    }(),
    _isQuickInstll: function(t) {
        if (this._getOtherServerObj().store.getById(t.id)) return !1;
        var e = !1 !== t.qinst;
        return (this._isUpgradable(t.id) || this._isUpgradableFromBetaToStable(t.id) || this._isRepairableFromBetaToStable(t.id) || this._isRepairableFromStableToBeta(t.id)) && (e = !1 !== t.qupgrade), t && t.info && !1 === t.info.blqinst && (e = !1), e
    },
    _isPkgInstalled: function(t) {
        return !!this._getInstalledStore().getById(t)
    },
    _isUpgradable: function(t) {
        var e = this._getInstalledStore().getById(t);
        if (!e) return !1;
        var i = e.data.available_operation;
        return !!i && !!(i.upgrade || i.repair || i.forcereplaced)
    },
    _isUpgradableFromBetaToStable: function(t) {
        var e = this._getInstalledStore().getById(t);
        if (!e || !0 === e.data.beta) return !1;
        var i = e.data.available_operation;
        if (!i) return !1;
        var a = i.upgrade || i.repair;
        return !!a && !1 === a.beta
    },
    _HasAvailableOperation: function(t) {
        return !(!t || !t.available_operation) && Object.keys(t.available_operation).length > 0
    },
    _IsOperationRequired: function(t) {
        return "loading" != t.status && ("doing" !== t.statusDesktop && ("error" === t.statusDesktop || this._HasAvailableOperation(t)))
    },
    _IsProgressDownloadingOrProcessing: function(t) {
        return t && (t.progress || t.info && t.info.status && t.info.status.includes("ing"))
    },
    _getProgressData: function(t, e) {
        if (e && e.data.available_operation.forcereplaced) {
            var i = e.data.available_operation.forcereplaced.package,
                a = SYNO.SDS.PkgManApp.Window.progressDatas[i];
            if (a && this._IsProgressDownloadingOrProcessing(a)) return a
        }
        var n = SYNO.SDS.PkgManApp.Window.progressDatas[t.id];
        return n && n.beta == t.beta && this._IsProgressDownloadingOrProcessing(n) ? n : null
    },
    _getOperationInfo: function(t, e) {
        var i = this,
            a = SYNO.SDS.PkgManApp.Window.getStore("installed").getById(t.id),
            n = !1;
        if (a) switch (e) {
            case "SYNO.SDS.PkgManApp.All.Panel":
            case "SYNO.SDS.PkgManApp.Category.Panel":
                a.beta && a.data.operation.targetRecord.data.beta || (n = !0);
                break;
            case "SYNO.SDS.PkgManApp.Beta.Panel":
                (a.beta || a.data.operation.targetRecord.data.beta) && (n = !0);
                break;
            case "SYNO.SDS.PkgManApp.Installed.Panel":
            case "SYNO.SDS.PkgManApp.Community.Panel":
                n = !0
        }
        var s = this._getProgressData(t, a);
        if (s) {
            var r = "",
                o = "",
                l = !1,
                p = t.statusDescription,
                g = this._getAvalRecByChannel(t.id, t.beta);
            return s.progress ? s.progress <= 1e-5 ? (r = _T("vpnc", "waiting"), o = "#057FEB") : (r = Math.floor(100 * s.progress) + "% ", r += _T("download", "download_task_downloading") + "...", o = "#057FEB") : "repairing" === s.info.status ? (r = _T("pkgmgr", "repairing"), o = "#057FEB", l = !0) : "upgrading" === s.info.status ? (r = _T("pkgmgr", "upgrading"), o = "#057FEB", l = !0) : (r = _T("pkgmgr", "installing"), o = "#057FEB", l = !0), a && (p = a.data.operation.descriptionText || p, g = a.data.operation.targetRec || g), {
                action: "cancel",
                actionText: _T("common", "cancel"),
                statusText: r,
                statusColor: o,
                descriptionText: p,
                buttonClass: "syno-ux-button-grey",
                isInstalledInCurrentPage: n,
                isButtonDisabled: l,
                targetRecord: g,
                actionFunction: function() {
                    i._onRequestCancelDownload(i._getAvalRecByChannel(t.id, t.beta))
                }
            }
        }
        var c = "SYNO.SDS.PkgManApp.Community.Panel" !== e && 0 !== t.type && !t.price,
            d = "SYNO.SDS.PkgManApp.Community.Panel" !== e && SYNO.SDS.PkgManApp.Utils.Utils.isBuyable(t),
            h = "SYNO.SDS.PkgManApp.Beta.Panel" === e,
            u = "";
        if (u = c ? _T("pkgmgr", "myds_pay_trail") : d ? _T("pkgmgr", "myds_pay_buy") : h ? _T("pkgmgr", "join_beta") : _T("pkgmgr", "pkgmgr_pkg_install"), !n) {
            var m = this._getAvalRecByChannel(t.id, t.beta);
            return {
                action: "install",
                actionText: u,
                statusText: "",
                statusColor: "",
                descriptionText: "",
                buttonClass: "",
                isInstalledInCurrentPage: !1,
                isButtonDisabled: !1,
                targetRecord: m,
                actionFunction: function() {
                    i._applyVersionAndBetaCheck(m, function() {
                        var t = this;
                        this._applyFeasibilityCheck({
                            type: "install_check",
                            packages: [m.id]
                        }).then(function(e) {
                            e && t._onClickInstall(m)
                        })
                    }.createDelegate(i))
                }
            }
        }
        return a.data.operation
    },
    _IsInstalling: function(t) {
        var e, i = SYNO.SDS.PkgManApp.Window.progressDatas;
        return t.id in i && t.beta == i[t.id].beta && (e = i[t.id]), !!t && ("installing" === t.status || "upgrading" === t.status || "repairing" === t.status || "downloading" === t.status || !!(e && e.info && e.info.installing && "starting" !== t.status && "stopping" !== t.status))
    },
    _GetProcessStatus: function(t, e) {
        var i, a = !0;
        switch (t) {
            case "installing":
                i = _T("pkgmgr", "installing"), e && (i = Math.floor(100 * e) + "% " + i);
                break;
            case "upgrading":
                i = _T("pkgmgr", "upgrading"), e && (i = Math.floor(100 * e) + "% " + i);
                break;
            case "uninstalling":
                i = _T("background_task", "task_processing") + "...";
                break;
            case "starting":
                i = _T("pkgmgr", "starting");
                break;
            case "stopping":
                i = _T("pkgmgr", "stopping");
                break;
            default:
                a = !1
        }
        return {
            status: t,
            msg: i,
            blProcessing: a
        }
    },
    _getOperableExceptReplaceTargetStoreById: function(t) {
        var e = "installed",
            i = this._getInstalledStore().getById(t).data.available_operation;
        i && (i.upgrade || i.repair) && (e = (i.upgrade || i.repair).beta ? "beta" : "stable");
        return SYNO.SDS.PkgManApp.Window.getStore(e).getById(t) || (e = "community"), e
    },
    _getUpgradeRec: function(t) {
        return this._isUpgradable(t) ? this._getAvalRec(t) : null
    },
    _isBuildPhaseGM: function() {
        return "GM" === (SYNO.SDS.Session.buildphase || "GM")
    },
    _hasNewVersion: function(t, e) {
        var i = this._getInstalledStore().getById(t);
        if (Ext.isEmpty(i)) return !1;
        var a = this._getAvalRecByChannel(i.id, e);
        return !Ext.isEmpty(a) && SYNO.SDS.PkgManApp.Utils.Helper.versionCompare(">=", a.get("version"), i.get("version"))
    },
    _isRepairable: function(t) {
        var e = this._getInstalledStore().getById(t.id);
        return !(Ext.isEmpty(e) || !SYNO.SDS.PkgManApp.Utils.Utils.isBrokenStatus(e.data)) && ((!e.data.pkgtarget || !e.data.pkgtarget.is_broken) && (!!e.data.available_operation.forcereplaced || (!!this._isRepairableStoppedByDepLimit(e.data) || (!!this._isStartFailed(e.data) || (this._isBuildPhaseGM() ? this._hasNewVersion(t.id, e.get("beta")) || this._isRepairableFromBetaToStable(t.id) : this._hasNewVersion(t.id, !0) || this._hasNewVersion(t.id, !1))))))
    },
    _isRepairableFromBetaToStable: function(t) {
        var e = this._getInstalledStore().getById(t);
        return !(Ext.isEmpty(e) || !SYNO.SDS.PkgManApp.Utils.Utils.isBrokenStatus(e.data) || !e.get("beta")) && this._hasNewVersion(t, !1)
    },
    _isRepairableFromStableToBeta: function(t) {
        var e = this._getInstalledStore().getById(t);
        return !(Ext.isEmpty(e) || !SYNO.SDS.PkgManApp.Utils.Utils.isBrokenStatus(e.data) || e.get("beta")) && (!this._hasNewVersion(t, !1) && this._hasNewVersion(t, !0) && !this._isBuildPhaseGM())
    },
    _getAvalRec: function(t) {
        return this._getSynoServerObj().store.getById(t) || this._getBetaServerObj().store.getById(t) || this._getOtherServerObj().store.getById(t)
    },
    _getAvalRecByChannel: function(t, e) {
        return e ? this._getBetaServerObj().store.getById(t) || this._getOtherServerObj().store.getById(t) : this._getSynoServerObj().store.getById(t) || this._getOtherServerObj().store.getById(t)
    },
    _getAvalReplacerRec: function(t) {
        var e = this._getSynoServerObj().store.getById(t);
        return e && Ext.isObject(e.data.replaceforcepkgs) ? e : (e = this._getBetaServerObj().store.getById(t)) && Ext.isObject(e.data.replaceforcepkgs) ? e : null
    },
    _getReplaceeRecsByReplacerId: function(t) {
        var e = this,
            i = this._getAvalReplacerRec(t);
        return i ? Object.keys(i.get("replaceforcepkgs")).map(function(t) {
            return e._getInstalledStore().getById(t)
        }).filter(function(t) {
            return t
        }) : []
    },
    _getReplaceeIdsByReplacerId: function(t) {
        return this._getReplaceeRecsByReplacerId(t).map(function(t) {
            return t.get("id")
        })
    },
    _onRequestInstall: function(t, e) {
        var i = 0;
        (this._isUpgradable(t.get("id")) || this._isRepairable(t.data)) && (i = 1), this.setStatusBusy(), this.sendWebAPI({
            api: "SYNO.Core.Package.Installation.Download",
            method: "check",
            version: 1,
            timeout: 36e5,
            params: {
                taskid: "@SYNOPKG_DOWNLOAD_" + t.get("id")
            },
            callback: function(a, n) {
                var s;
                if (this.clearStatusBusy(), s = this._getAvalRecByChannel(t.get("id"), t.get("beta")), a) this._applyCodesignCheck(n, function(t) {
                    this._prepareVolume(i, n, e, s, t)
                }.createDelegate(this), function() {
                    this._onRequestCancelDownload(t), e()
                }.createDelegate(this));
                else {
                    if (this.clearProgress(s.get("id")), !n || !n.code) return this._onResetInstPkgs(), void this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), String.format("{0} {1}", _T("pkgmgr", "system_error"), _T("pkgmgr", "contact_support_or_try_again")));
                    this._onCheckPKGFail(n, t.get("dname"))
                }
            },
            scope: this
        })
    },
    _onRequestCancelDownload: function(t) {
        this.setStatusBusy();
        var e = SYNO.SDS.PackageTaskMgr.getTask("@SYNOPKG_DOWNLOAD_" + t.get("id"));
        e ? e.cancel() : (this.clearProgress(t.get("id")), this.sendWebAPI({
            api: "SYNO.Core.Package.Installation",
            method: "cancel",
            version: 1,
            params: {
                taskid: "@SYNOPKG_DOWNLOAD_" + t.get("id")
            },
            callback: function(e, i) {
                this._onLoadPkgStore(t.get("id"), !1, function() {
                    this.clearStatusBusy()
                }.createDelegate(this))
            },
            scope: this
        }))
    },
    _onCheckInstall: function(t, e, i) {
        var a = !Ext.isFunction(e);
        a && this.setStatusBusy(), this._onCheckEnv(i, t, function(n, s) {
            if (a && this.clearStatusBusy(), n) {
                var r = !1 !== this._isQuickInstll(t.data) && !1 !== t.get("start") && !1 !== t.get("qstart") || !1 !== t.get("pkgstartable"),
                    o = [];
                if (s.volume_count && 0 !== s.volume_count || "system" === t.get("install_type")) {
                    var l = this._isUpgradable(t.get("id"));
                    if (!s.volume_list || s.volume_list.length <= 1 || !Ext.isEmpty(s.volume_path)) {
                        var p = Ext.isEmpty(s.volume_path) ? s.volume_list ? s.volume_list[0].mount_point : "" : s.volume_path;
                        l || !r ? this._onRequestQuickInstall(t, p, !!this._isRepairable(t.data) || void 0, e) : Ext.isFunction(e) ? this._onRequestQuickInstall(t, p, !0, e) : this._onRequestQuickInstall(t, p, !0)
                    } else {
                        for (var g = 0; g < s.volume_count; g++) {
                            var c = s.volume_list[g];
                            o.push({
                                mount_point: c.mount_point,
                                name: c.display,
                                description: c.desc
                            })
                        }
                        var d = new SYNO.SDS.PkgManApp.WizardDialog({
                            owner: this,
                            mode: l ? 1 : 0,
                            volumes: o
                        }, {
                            id: t.get("id"),
                            name: t.get("dname"),
                            version: t.get("version"),
                            description: t.get("desc"),
                            maintainer: t.get("maintainer"),
                            distributor: t.get("distributor"),
                            support_url: t.get("support_url"),
                            startable: r,
                            pkgqinst: !0,
                            pkgqinstrec: t,
                            install_type: t.get("install_type"),
                            install_on_cold_storage: t.get("install_on_cold_storage")
                        });
                        d.mon(d, "beforeclose", function() {
                            this.installing_fore_pkg = null, Ext.isFunction(e) && function() {
                                e()
                            }.defer(100), d.isFinished || this._onResetInstPkgs()
                        }, this, {
                            single: !0
                        }), d.isDestroyed || d.open()
                    }
                } else this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), _T("error", "volume_no_volumes"), function(t) {
                    "ok" === t && SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance"), this._onResetInstPkgs()
                })
            } else s && s.code ? this._onCheckEnvFail(s, t, e, {
                fn: this._onCheckInstall,
                args: [t, e, i],
                scope: this
            }) : (this._onResetInstPkgs(), this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), String.format("{0} {1}", _T("pkgmgr", "system_error"), _T("pkgmgr", "contact_support_or_try_again")), function() {
                Ext.isFunction(e) && e()
            }, this))
        })
    },
    _onRequestQuickInstall: function(t, e, i, a) {
        var n = !Ext.isFunction(a),
            s = this._isUpgradable(t.get("id")) ? "upgrade" : "install";
        SYNO.SDS.StatusNotifier.fireEvent("pkgctl", t.id, s, "pre"), n && this.setStatusBusy();
        var r = {
            name: t.get("id"),
            blqinst: this._isQuickInstll(t.data),
            volume_path: e,
            is_syno: "syno" === t.get("source"),
            beta: t.get("beta") || !1,
            installrunpackage: i
        };
        this.sendWebAPI({
            api: "SYNO.Core.Package.Installation",
            method: this._isPkgInstalled(t.get("id")) ? "upgrade" : "install",
            version: 1,
            params: r,
            callback: function(e, i) {
                if (n && this.clearStatusBusy(), !e || !i || i && 0 > i.progress) {
                    this._onResetInstPkgs();
                    var s = {
                        msg: String.format("{0} {1}", _T("pkgmgr", "system_error"), _T("pkgmgr", "contact_support_or_try_again")),
                        callback: Ext.emptyFn
                    };
                    i && i.code && (s = this._onCheckPKGFailMsg(t.get("dname"), i, String.format("{0} {1}", _T("pkgmgr", "system_error"), _T("pkgmgr", "contact_support_or_try_again")))), this.getMsgBox().confirm(t.get("dname") || _T("tree", "leaf_packagemanage"), s.msg, s.callback, this, s.buttons || Ext.MessageBox.OK)
                } else {
                    var r = new SYNO.SDS.PkgManApp.DownloadAction({
                        owner: this,
                        data: i,
                        id: t.get("id"),
                        beta: t.get("beta"),
                        foreground: !1
                    });
                    Ext.isFunction(a) && this.mon(r, "finish", function() {
                        return this.clearProgress(t.get("id")), a(), !0
                    }, this, {
                        single: !0
                    })
                }
            },
            scope: this
        })
    },
    _onCheckEnv: function(t, e, i) {
        this.setStatusBusy(), this.sendWebAPI({
            api: "SYNO.Core.Package.Installation",
            method: "check",
            version: 2,
            params: {
                depsers: e.get("depsers"),
                deppkgs: e.get("deppkgs"),
                conflictpkgs: e.get("conflictpkgs"),
                breakpkgs: e.get("breakpkgs"),
                replacepkgs: e.get("replacepkgs"),
                ver: e.get("version"),
                size: e.get("size"),
                id: e.get("id"),
                blupgrade: this._isUpgradable(e.get("id")),
                install_type: e.get("install_type"),
                install_on_cold_storage: e.get("install_on_cold_storage"),
                blCheckDep: !1
            },
            scope: this,
            callback: function(t, e) {
                this.clearStatusBusy(), Ext.isFunction(i) && i.apply(this, arguments)
            }
        })
    },
    _onRequestDownload: function(t, e, i, a) {
        e = Ext.isBoolean(e) ? e : this._isQuickInstll(t.data), this.setStatusBusy(), this._onCheckEnv(a, t, function(n, s) {
            this.clearStatusBusy(), n ? e || !s.is_occupied ? (this.setStatusBusy(), this.sendWebAPI({
                api: "SYNO.Core.Package.Installation",
                method: this._isPkgInstalled(t.get("id")) ? "upgrade" : "install",
                version: 1,
                timeout: 36e5,
                params: {
                    name: t.get("id"),
                    url: t.get("link"),
                    checksum: t.get("md5"),
                    filesize: t.get("size"),
                    type: t.get("type"),
                    blqinst: e,
                    operation: this._isUpgradable(t.get("id")) ? "upgrade" : "install"
                },
                callback: function(e, a) {
                    if (this.clearStatusBusy(), !e || !a) return this._onResetInstPkgs(), void this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), String.format("{0} {1}", _T("pkgmgr", "system_error"), _T("pkgmgr", "contact_support_or_try_again")), function() {}, this);
                    if (a && 0 > a.progress) {
                        if (this._onResetInstPkgs(), a.code && 4502 == a.code) return void this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), _T("error", "volume_no_volumes"), function(t) {
                            "ok" === t && SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance")
                        });
                        var n = String.format("{0} {1}", _T("pkgmgr", "system_error"), _T("pkgmgr", "contact_support_or_try_again"));
                        a.code && (n = SYNO.API.getErrorString(a.code)), this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), n, function() {
                            Ext.isFunction(i) && i()
                        }, this)
                    } else {
                        var s = new SYNO.SDS.PkgManApp.DownloadAction({
                            owner: this,
                            data: a,
                            id: t.get("id"),
                            beta: t.get("beta"),
                            foreground: !0
                        });
                        Ext.isFunction(i) && this.mon(s, "finish", function() {
                            return this._onRequestInstall(t, i), !1
                        }, this, {
                            single: !0
                        })
                    }
                },
                scope: this
            })) : this.getMsgBox().alert(t.get("dname"), _T("pkgmgr", "error_occupied"), function() {
                Ext.isFunction(i) && i()
            }, this) : s && s.code ? this._onCheckEnvFail(s, t, i, {
                fn: this._onRequestDownload,
                args: [t, e, i, a],
                scope: this
            }) : (this._onResetInstPkgs(), this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), String.format("{0} {1}", _T("pkgmgr", "system_error"), _T("pkgmgr", "contact_support_or_try_again")), function() {
                Ext.isFunction(i) && i()
            }, this))
        })
    },
    _onResetInstPkgs: function() {
        this.fore_pkg = [], this.back_pkg = [], this.installing_fore_pkg = null, this.start_pkg = []
    },
    _AlertByBox: function() {
        var t = _asyncToGenerator(regeneratorRuntime.mark(function t(e) {
            var i = this;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.abrupt("return", new Promise(function(t) {
                            i.getMsgBox().alert(_T("tree", "leaf_packagemanage"), e, function() {
                                t()
                            })
                        }));
                    case 1:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }));
        return function(e) {
            return t.apply(this, arguments)
        }
    }(),
    _ConfirmByGrid: function() {
        var t = _asyncToGenerator(regeneratorRuntime.mark(function t(e, i) {
            var a = this;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.abrupt("return", new Promise(function(t) {
                            a.getMsgBox().confirmGrid(_T("tree", "leaf_packagemanage"), e, i, function(e) {
                                t(e)
                            })
                        }));
                    case 1:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }));
        return function(e, i) {
            return t.apply(this, arguments)
        }
    }(),
    _ConfirmByBox: function() {
        var t = _asyncToGenerator(regeneratorRuntime.mark(function t(e) {
            var i = this;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.abrupt("return", new Promise(function(t) {
                            i.getMsgBox().confirm(_T("tree", "leaf_packagemanage"), e, function(e) {
                                t(e)
                            })
                        }));
                    case 1:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }));
        return function(e) {
            return t.apply(this, arguments)
        }
    }(),
    _ConfirmPackageWillBeStoppedDuringUpgrade: function() {
        var t = _asyncToGenerator(regeneratorRuntime.mark(function t(e, i) {
            var a, n, s;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return a = String.format(_T("pkgmgr", "error_upgrade_dep_statable_packages"), e.join(", "), i.join(", ")), n = _T("common", "cfrm_continue"), s = "".concat(a, "<br/>").concat(n), t.abrupt("return", this._ConfirmByBox(s));
                    case 4:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }));
        return function(e, i) {
            return t.apply(this, arguments)
        }
    }(),
    _confirmPkgPausedDuringUpgrade: function(t, e, i) {
        var a = String.format(_T("pkgmgr", "error_upgrade_dep_statable_packages"), t.join(", "), e.join(", "));
        a += "<br/>" + _T("common", "cfrm_continue"), this.getMsgBox().confirm(_T("tree", "leaf_packagemanage"), a, function(t, e) {
            "yes" === t ? i() : this._onResetInstPkgs()
        }, this)
    },
    _constructOperationMsg: function(t, e, i, a, n) {
        var s, r, o, l = {
            title: "",
            operations: [],
            blInstall: !1
        };
        n && 1 === n.length ? (s = n[0], o = (r = this._getAvalRecByChannel(s.id, s.beta)).get("beta") ? String.format("({0})", _T("pkgmgr", "beta")) : "", h = this._getInstalledStore().getById(s.id), Ext.isEmpty(h) ? l.title = String.format(_T("pkgmgr", "install_operation_desc"), r.get("dname") + o) : SYNO.SDS.PkgManApp.Utils.Utils.isBrokenStatus(h.data) ? l.title = String.format(_T("pkgmgr", "repair_operation_desc_plural"), r.get("dname") + o) : l.title = String.format(_T("pkgmgr", "upgrade_operation_desc"), r.get("dname") + o)) : l.title = String.format(_T("pkgmgr", "operation_desc")), l.title += String.format(" {0}", _T("common", "cfrm_continue").toLowerCase());
        for (var p = 0, g = e.length; p < g; p++)(Ext.isEmpty(s) || s.id !== e[p].pkg) && (o = (r = this._getAvalRecByChannel(e[p].pkg, e[p].beta)).get("beta") ? String.format("({0})", _T("pkgmgr", "beta")) : "", Ext.isEmpty(this._getInstalledStore().getById(e[p].pkg)) ? (l.operations.push(String.format(_T("pkgmgr", "install_pkg"), r.get("dname") + o)), l.blInstall = !0) : SYNO.SDS.PkgManApp.Utils.Utils.isBrokenStatus(this._getInstalledStore().getById(e[p].pkg).data) ? l.operations.push(String.format(_T("pkgmgr", "repair_pkg"), r.get("dname") + o)) : l.operations.push(String.format(_T("pkgmgr", "update_pkg"), r.get("dname") + o)));
        var c = function(t) {
            if (t.pkg === i[p]) return d = !0, !1
        };
        for (p = 0, g = i.length; p < g; p++) {
            var d = !1;
            if (Ext.each(e, c, this), !d) {
                var h = this._getInstalledStore().getById(i[p]);
                h && h.get("dname") ? l.operations.push(String.format(_T("pkgmgr", "stop_pkg"), h.get("dname"))) : l.operations.push(String.format(_T("pkgmgr", "stop_pkg"), i[p]))
            }
        }
        return l
    },
    _onClickInstall: function(t) {
        this._ExecutePackageOperations([{
            pkg: t.get("id"),
            operation: "install",
            version: t.get("version"),
            beta: t.get("beta") || !1
        }], [t.data])
    },
    _feasibilityCheckInstallAndStart: function() {
        var t = _asyncToGenerator(regeneratorRuntime.mark(function t(e, i, a) {
            var n;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        if (n = Object.keys(e).map(function(t) {
                                return {
                                    pkg: t,
                                    operation: "install",
                                    version: e[t].rec.get("version"),
                                    beta: e[t].rec.get("beta") || !1
                                }
                            }).concat(Object.keys(i).map(function(t) {
                                return {
                                    pkg: t,
                                    operation: "start",
                                    version: i[t].rec.get("version"),
                                    beta: i[t].rec.get("beta") || !1
                                }
                            })), 0 === Object.entries(e).length) {
                            t.next = 7;
                            break
                        }
                        return t.next = 4, this._applyFeasibilityCheck({
                            type: "install_check",
                            packages: Object.keys(e)
                        });
                    case 4:
                        if (t.sent) {
                            t.next = 7;
                            break
                        }
                        return t.abrupt("return", !1);
                    case 7:
                        return this._ExecutePackageOperations(n, a), t.abrupt("return", !0);
                    case 9:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }));
        return function(e, i, a) {
            return t.apply(this, arguments)
        }
    }(),
    _isStartFailed: function(t) {
        return "start_failed" === t.status || "start_failed" === t.statusOrigin
    },
    _isStoppedByDepLimit: function(t) {
        return "stopped_by_dep_limit" === t.status || "stopped_by_dep_limit" === t.statusOrigin
    },
    _isStoppedByDepLimitAndOnlyRepairParents: function(t) {
        if (!this._isStoppedByDepLimit(t)) return !1;
        var e = t.available_operation,
            i = [];
        if (e.redirect) {
            var a = !0,
                n = !1,
                s = void 0;
            try {
                for (var r, o = e.redirect[Symbol.iterator](); !(a = (r = o.next()).done); a = !0) {
                    var l = r.value,
                        p = this._getInstalledStore().getById(l.package);
                    p && SYNO.SDS.PkgManApp.Utils.Utils.isBrokenStatus(p.data) && !this._isRepairable(p.data) && i.push(p.data.id)
                }
            } catch (t) {
                n = !0, s = t
            } finally {
                try {
                    a || null == o.return || o.return()
                } finally {
                    if (n) throw s
                }
            }
        }
        return 0 == i.length
    },
    _GetConflictionMessage: function(t) {
        var e = new Map,
            i = !0,
            a = !1,
            n = void 0;
        try {
            for (var s, r = t[Symbol.iterator](); !(i = (s = r.next()).done); i = !0) {
                var o = s.value,
                    l = o.split("::")[0],
                    p = o.split("::")[1];
                e.has(l) || e.set(l, []), e.get(l).push(p)
            }
        } catch (t) {
            a = !0, n = t
        } finally {
            try {
                i || null == r.return || r.return()
            } finally {
                if (a) throw n
            }
        }
        var g = _T("pkgmgr", "install_fail") + "<br><br>";
        g += '<ul style="list-style: disc; margin-left: 10px">';
        var c = !0,
            d = !1,
            h = void 0;
        try {
            for (var u, m = e[Symbol.iterator](); !(c = (u = m.next()).done); c = !0) {
                var S = _slicedToArray(u.value, 2),
                    _ = S[0],
                    k = S[1];
                g += "<li>" + _ + ": " + String.format(_T("pkgmgr", "conflict_packages"), k.join(", ")) + "</li>"
            }
        } catch (t) {
            d = !0, h = t
        } finally {
            try {
                c || null == m.return || m.return()
            } finally {
                if (d) throw h
            }
        }
        return g += "</ul>"
    },
    _isRepairableStoppedByDepLimit: function(t) {
        if (!this._isStoppedByDepLimit(t)) return !1;
        var e = t.available_operation,
            i = [];
        if (e.redirect) {
            var a = !0,
                n = !1,
                s = void 0;
            try {
                for (var r, o = e.redirect[Symbol.iterator](); !(a = (r = o.next()).done); a = !0) {
                    var l = r.value,
                        p = this._getInstalledStore().getById(l.package);
                    p && SYNO.SDS.PkgManApp.Utils.Utils.isBrokenStatus(p.data) && !this._isRepairable(p.data) && i.push(p.data.id)
                }
            } catch (t) {
                n = !0, s = t
            } finally {
                try {
                    a || null == o.return || o.return()
                } finally {
                    if (n) throw s
                }
            }
        }
        if (0 == i.length) return !0;
        if (e.repair || e.upgrade || e.forcereplaced) {
            var g = e.repair || e.upgrade || e.forcereplaced,
                c = this._getAvalRecByChannel(g.package, g.beta);
            if (c && c.data.deppkgs) {
                for (var d = !1, h = Object.keys(c.data.deppkgs), u = 0; u < h.length; u++) {
                    var m = h[u];
                    i.includes(m) && (d = !0)
                }
                if (!d) return !0
            }
        }
        return !1
    },
    _onClickRepairStoppedByDepLimit: function(t) {
        var e = t.available_operation,
            i = [],
            a = [];
        if (e.redirect) {
            var n = !0,
                s = !1,
                r = void 0;
            try {
                for (var o, l = e.redirect[Symbol.iterator](); !(n = (o = l.next()).done); n = !0) {
                    var p = o.value,
                        g = this._getInstalledStore().getById(p.package);
                    g && SYNO.SDS.PkgManApp.Utils.Utils.isBrokenStatus(g.data) && (this._isRepairable(g.data) ? a.push(g.data.id) : i.push(g.data.id))
                }
            } catch (t) {
                s = !0, r = t
            } finally {
                try {
                    n || null == l.return || l.return()
                } finally {
                    if (s) throw r
                }
            }
        }
        if (i.length > 0 && (e.repair || e.upgrade || e.forcereplaced)) {
            var c = e.repair || e.upgrade || e.forcereplaced,
                d = this._getAvalRecByChannel(c.package, c.beta);
            if (d && d.data.deppkgs) {
                for (var h = !1, u = Object.keys(d.data.deppkgs), m = 0; m < u.length; m++) {
                    var S = u[m];
                    i.includes(S) && (h = !0)
                }
                h || a.push(t.id)
            }
        }
        this._onClickUpdateAll(!0, function(t) {
            return a.includes(t.data.id)
        }, [t])
    },
    _onClickUpdateAll: function(t, e, i) {
        if (Ext.isEmpty(this._getInstallAll_Background())) {
            var a = e || function() {
                    return !0
                },
                n = {};
            this._getUpgradePkg(t, this._getSynoServerObj().store, n, a), this._getUpgradePkg(t, this._getBetaServerObj().store, n, a), this._getUpgradePkg(t, this._getOtherServerObj().store, n, a);
            var s = {},
                r = [];
            if (t) {
                for (var o in n)
                    if (n.hasOwnProperty(o)) {
                        var l = this._getInstalledStore().getById(o);
                        this._isRepairableFromStableToBeta(o) && l && "version_limit" !== l.get("status") && r.push(n[o].rec.get("dname"))
                    } var p = !0,
                    g = !1,
                    c = void 0;
                try {
                    for (var d, h = this._getInstalledStore().data.items[Symbol.iterator](); !(p = (d = h.next()).done); p = !0) {
                        var u = d.value;
                        this._isStartFailed(u.data) && a(u) && (s[u.get("id")] = {
                            rec: u
                        })
                    }
                } catch (t) {
                    g = !0, c = t
                } finally {
                    try {
                        p || null == h.return || h.return()
                    } finally {
                        if (g) throw c
                    }
                }
            }
            0 !== r.length ? this.getMsgBox().confirm(_T("tree", "leaf_packagemanage"), String.format(_T("pkgmgr", "repairall_beta_confirm"), r.join(", ")), function(t, e) {
                "yes" === t && this._feasibilityCheckInstallAndStart(n, s, i)
            }, this) : this._feasibilityCheckInstallAndStart(n, s, i)
        } else this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), _T("pkgmgr", "error_occupied"))
    },
    _ExecutePackageOperations: function() {
        var t = _asyncToGenerator(regeneratorRuntime.mark(function t(e, i) {
            var a, n, s, r, o, l, p, g;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return a = e.filter(function(t) {
                            return "install" == t.operation
                        }), n = e.filter(function(t) {
                            return "start" == t.operation
                        }), this.setStatusBusy(), t.next = 5, this.sendWebAPIInsensitivePromise({
                            api: "SYNO.Core.Package.Installation",
                            method: "get_queue",
                            timeout: 9e5,
                            version: 1,
                            params: {
                                pkgs: a
                            }
                        });
                    case 5:
                        if (s = t.sent, r = _slicedToArray(s, 3), o = r[0], l = r[1], p = r[2], this.clearStatusBusy(), t.prev = 11, o) {
                            t.next = 15;
                            break
                        }
                        throw this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), String.format("{0} {1}", _T("pkgmgr", "system_error"), _T("pkgmgr", "contact_support_or_try_again"))), "system error";
                    case 15:
                        if (!(l.non_exist_pkgs.length > 0)) {
                            t.next = 18;
                            break
                        }
                        throw this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), _T("pkgmgr", "missing_pkgs") + "<br>" + l.non_exist_pkgs.join(", ")), "missing packages";
                    case 18:
                        if (!(l.conflicted_pkgs.length > 0)) {
                            t.next = 21;
                            break
                        }
                        throw this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), this._GetConflictionMessage(l.conflicted_pkgs)), "conflict packages";
                    case 21:
                        if (!(p.pkgs.length != l.queue.length || l.broken_pkgs.length > 0)) {
                            t.next = 31;
                            break
                        }
                        return g = this._constructOperationMsg(p.pkgs, l.queue, l.broken_pkgs, l.replaced_pkgs, i), t.next = 25, this._ConfirmByGrid(g.title, g.operations);
                    case 25:
                        if ("yes" == t.sent) {
                            t.next = 28;
                            break
                        }
                        throw "user not agree to do additional operations";
                    case 28:
                        if (_S("is_admin") || !g.blInstall) {
                            t.next = 31;
                            break
                        }
                        throw this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), _T("install_no_permission_alert")), "user has no permission to do fresh install";
                    case 31:
                        if (!(l.paused_pkgs.length > 0)) {
                            t.next = 37;
                            break
                        }
                        return t.next = 34, this._ConfirmPackageWillBeStoppedDuringUpgrade(l.cause_pausing_pkgs, l.paused_pkgs);
                    case 34:
                        if ("yes" == t.sent) {
                            t.next = 37;
                            break
                        }
                        throw "user does not agree to stop packages during upgrade";
                    case 37:
                        t.next = 43;
                        break;
                    case 39:
                        return t.prev = 39, t.t0 = t.catch(11), this._onResetInstPkgs(), t.abrupt("return", !1);
                    case 43:
                        return this._EnqueueOperations(l.queue, n), this._ExecuteNextQueuedOperation(), t.abrupt("return", !0);
                    case 46:
                    case "end":
                        return t.stop()
                }
            }, t, this, [
                [11, 39]
            ])
        }));
        return function(e, i) {
            return t.apply(this, arguments)
        }
    }(),
    _EnqueueOperations: function(t, e) {
        var i = {},
            a = !0,
            n = !1,
            s = void 0;
        try {
            for (var r, o = t[Symbol.iterator](); !(a = (r = o.next()).done); a = !0) {
                var l = r.value;
                i[l.pkg] = {
                    rec: this._getAvalRecByChannel(l.pkg, l.beta)
                }
            }
        } catch (t) {
            n = !0, s = t
        } finally {
            try {
                a || null == o.return || o.return()
            } finally {
                if (n) throw s
            }
        }
        var p = [];
        this._genDepGraphNodes(i, p);
        var g, c = SYNO.SDS.PkgManApp.Utils.Utils.tsort(p);
        c.splice(c.length - 1, 1), this.back_pkg = this.back_pkg || [], this.fore_pkg = this.fore_pkg || [];
        for (var d = 0; d < c.length; d++)(g = i[c[d]]) && (this.existsInForeBackPkgs(this.fore_pkg, g.rec.id) || this.fore_pkg.push(g.rec));
        for (var h in i) i.hasOwnProperty(h) && (g = i[h]) && (this.existsInForeBackPkgs(this.back_pkg, g.rec.id) || this.existsInForeBackPkgs(this.fore_pkg, g.rec.id) || this.back_pkg.push(g.rec));
        this.start_pkg = this.start_pkg || [];
        var u = !0,
            m = !1,
            S = void 0;
        try {
            for (var _, k = e[Symbol.iterator](); !(u = (_ = k.next()).done); u = !0) {
                var f = _.value;
                if (!i.hasOwnProperty(f.pkg)) {
                    var y = this._getInstalledStore().getById(f.pkg);
                    y && this.start_pkg.push(y)
                }
            }
        } catch (t) {
            m = !0, S = t
        } finally {
            try {
                u || null == k.return || k.return()
            } finally {
                if (m) throw S
            }
        }
    },
    _getUpgradePkg: function(t, e, i, a) {
        var n = this,
            s = e.snapshot || e.data,
            r = a || function() {
                return !0
            },
            o = [];
        this._getInstalledStore().each(function(t) {
            t.data.available_operation && t.data.available_operation.forcereplaced && o.push(t.data.available_operation.forcereplaced.package)
        }), s.items.filter(function(t) {
            return !i.hasOwnProperty(t.get("id"))
        }).filter(function(t) {
            return r(t)
        }).filter(function(e) {
            var i = n._getInstalledStore().getById(e.get("id"));
            if (i && "doing" === i.data.statusDesktop) return !1;
            if (SYNO.SDS.PkgManApp.Window.progressDatas[e.get("id")]) return !1;
            if (o.includes(e.get("id"))) return !0;
            if (!i) return !1;
            var a = i.data.available_operation;
            if (0 == Object.keys(a).length) return !1;
            if (a.start) return !1;
            if (SYNO.SDS.PkgManApp.Utils.Utils.isBrokenStatus(i.data)) {
                if (!t) return !1
            } else if (t) return !1;
            if (a.redirect) {
                if (t && n._isStoppedByDepLimitAndOnlyRepairParents(i.data)) return !1
            } else {
                var s = i.data.operation.targetRecord;
                if (s.data.id !== e.get("id") || s.data.beta !== e.get("beta")) return !1
            }
            return !0
        }).forEach(function(t) {
            i[t.get("id")] = {
                rec: t
            }
        })
    },
    _checkVersion: function(t, e) {
        if (Ext.isEmpty(t)) return null;
        if (Ext.isEmpty(e)) return t;
        for (var i in e)
            if (!this.helper.versionCompare(i, t.get("version"), e[i])) return null;
        return t
    },
    _IsInstNormal: function(t) {
        var e = this._getInstalledStore().getById(t);
        return !!e && ((!e.available_operation || !e.available_operation.upgrade) && !(!(e = this._getAvalRecByChannel(t, e.get("beta"))) || this._isRepairable(e.data)))
    },
    _IsInstingOrInsted: function(t) {
        var e, i, a;
        if (Ext.isEmpty(t)) return !0;
        for (e in t)
            if (t.hasOwnProperty(e)) {
                if (!(i = this._getSynoServerObj().store.getById(e) || this._getOtherServerObj().store.getById(e))) continue;
                if ((a = this.getProgressData(i).progress) > 0 && a <= 1) return !0;
                if (i = this._getInstalledStore().getById(e)) return !0
            } return !1
    },
    _IsInsting_Background: function() {
        return this._IsInstingOrInsted(this._getInstallAll_Background())
    },
    _IsInsting_Foreground: function() {
        return this._IsInstingOrInsted(this._getInstallAll_Foreground())
    },
    _genDepGraphNodes: function(t, e) {
        var i, a, n;
        if (!Ext.isEmpty(t))
            for (var s in t)
                if (t.hasOwnProperty(s)) {
                    if (i = t[s].rec, !this._isFirstBuy(i) && this._isQuickInstll(i.data) && !this._inQueue(t, i.get("deppkgs"))) continue;
                    for (n in e.push([i.get("id"), ""]), a = i.get("deppkgs") || {}) a.hasOwnProperty(n) && e.push([n, i.get("id")])
                }
    },
    _inQueue: function(t, e) {
        for (var i in e)
            if (e.hasOwnProperty(i) && t.hasOwnProperty(i)) return !0;
        return !1
    },
    _ExecuteNextQueuedOperation: function() {
        Ext.isEmpty(this.fore_pkg) || Ext.isEmpty(this.fore_pkg[0]) ? Ext.isEmpty(this.back_pkg) ? Ext.isEmpty(this.start_pkg) || this._StartAllPackages() : this._onInstallAll_Background() : this._onInstallAll_Foreground()
    },
    _StartAllPackages: function() {
        var t = _asyncToGenerator(regeneratorRuntime.mark(function t() {
            var e, i, a, n, s, r;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        e = !0, i = !1, a = void 0, t.prev = 3, n = this.start_pkg[Symbol.iterator]();
                    case 5:
                        if (e = (s = n.next()).done) {
                            t.next = 12;
                            break
                        }
                        return r = s.value, t.next = 9, this._onStartPkg(r);
                    case 9:
                        e = !0, t.next = 5;
                        break;
                    case 12:
                        t.next = 18;
                        break;
                    case 14:
                        t.prev = 14, t.t0 = t.catch(3), i = !0, a = t.t0;
                    case 18:
                        t.prev = 18, t.prev = 19, e || null == n.return || n.return();
                    case 21:
                        if (t.prev = 21, !i) {
                            t.next = 24;
                            break
                        }
                        throw a;
                    case 24:
                        return t.finish(21);
                    case 25:
                        return t.finish(18);
                    case 26:
                        this.start_pkg = [];
                    case 27:
                    case "end":
                        return t.stop()
                }
            }, t, this, [
                [3, 14, 18, 26],
                [19, , 21, 25]
            ])
        }));
        return function() {
            return t.apply(this, arguments)
        }
    }(),
    _onInstallAll_Foreground: function() {
        if (!(Ext.isEmpty(this.fore_pkg) || Ext.isEmpty(this.fore_pkg[0]) || this.installing_fore_pkg && this.existsInForeBackPkgs(this.fore_pkg, this.installing_fore_pkg.id))) {
            var t = this.fore_pkg[0];
            this.installing_fore_pkg = t, this._onInstallAll_One(t, !1)
        }
    },
    _onInstallAll_Background: function() {
        if (!Ext.isEmpty(this.back_pkg) && !Ext.isEmpty(this.back_pkg[0])) {
            var t;
            for (t = 0; t < this.back_pkg.length; t++) {
                var e = this.back_pkg[t];
                if (e) {
                    var i = e,
                        a = this.getProgressData(i).progress;
                    a > 0 && a < 1 || -1 === a || this._onInstallAll_One.defer(80, this, [e, !0])
                }
            }
            this.back_pkg = []
        }
    },
    _getInstallAll_Foreground: function() {
        return this.fore_pkg || []
    },
    _getInstallAll_Background: function() {
        return this.back_pkg || []
    },
    _onInstallAll_One: function(t, e, i) {
        var a = t.id;
        if (!this.isDestroyed)
            if (i = i || 0, t) {
                if (!_S("is_admin") && 0 != this._getReplaceeIdsByReplacerId(t.data.id).length) {
                    var n = t.get("dname"),
                        s = this._getReplaceeRecsByReplacerId(t.data.id).map(function(t) {
                            return t.get("dname")
                        }).join(", ");
                    return this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), String.format(_T("pkgmgr", "force_replace_no_permission"), n, s)), void this._onResetInstPkgs()
                }
                var r = this.getProgressData(t).progress,
                    o = t,
                    l = function() {
                        this.isDestroyed || (this.existsInForeBackPkgs(this.fore_pkg, a) && (this.fore_pkg.splice(void 0, 1), this.installing_fore_pkg = null), this._ExecuteNextQueuedOperation())
                    }.createDelegate(this);
                if (1 !== r && r > 0)
                    if (e) l();
                    else {
                        if (!(180 >= i)) return this._onResetInstPkgs(), void this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), _T("pkgmgr", "error_occupied"));
                        i++, this._onInstallAll_One.defer(1e3, this, [a, e, i])
                    }
                else this._isFirstBuy(o) || this._isLicenseError(o) ? this._onRequestSynoPkg(o, e, r, l) : e ? 1 === r ? l() : this._onCheckInstall(o, l) : this._onRequestDownload(o, e, l)
            } else this._ExecuteNextQueuedOperation()
    },
    _onLoadPkgStore: function() {
        var t = SYNO.SDS.PkgManApp.Window;
        t.onLoadPkgStore.apply(t, arguments)
    },
    _onLoadOtherPkgStore: function() {
        var t = SYNO.SDS.PkgManApp.Window;
        t.onLoadOtherPkgStore.apply(t, arguments)
    },
    _onLoadSynoPkgStore: function() {
        var t = SYNO.SDS.PkgManApp.Window;
        t.onLoadSynoPkgStore.apply(t, arguments)
    },
    _onLoadBetaPkgStore: function() {
        var t = SYNO.SDS.PkgManApp.Window;
        t.onLoadBetaPkgStore.apply(t, arguments)
    },
    _onRefresh: function(t) {
        t = !!Ext.isBoolean(t) && t, this._onLoadOtherPkgStore(!0, !1), this._onLoadSynoPkgStore(!0, !1), this._onLoadBetaPkgStore(!0, !1), this.fireEvent("pollinginstpage"), this.loadCfg()
    },
    _getSynoServerObj: function() {
        return SYNO.SDS.PkgManApp.Window.synoObj
    },
    _getBetaServerObj: function() {
        return SYNO.SDS.PkgManApp.Window.betaObj
    },
    _getOtherServerObj: function() {
        return SYNO.SDS.PkgManApp.Window.otherObj
    },
    _getInstalledStore: function() {
        return SYNO.SDS.PkgManApp.Window.getStore("installed")
    },
    _prepareVolume: function(t, e, i, a, n) {
        var s = new SYNO.SDS.PkgManApp.WizardDialog({
            owner: this,
            mode: t,
            check_codesign: void 0 === n || n,
            type: a ? a.get("type") : void 0
        }, e);
        s.mon(s, "beforeclose", function() {
            this.installing_fore_pkg = null, Ext.isFunction(i) && function() {
                i()
            }.defer(100), s.isFinished || this._onResetInstPkgs()
        }, this, {
            single: !0
        }), s.open()
    },
    _onRequestSynoPkg: function(t, e, i, a, n) {
        var s = {},
            r = this._isLicenseError(t);
        for (var o in SYNO.SDS.PkgManApp.Config) {
            if (SYNO.SDS.PkgManApp.Config.hasOwnProperty(o))
                if ("myds_id" === o || "auth_key" === o || "serial" === o) s[o] = SYNO.SDS.PkgManApp.Config[o];
                else "ds_" === o.substr(0, 3) && (s[o] = SYNO.SDS.PkgManApp.Config[o])
        }
        var l = function(n, s, o) {
            r ? (this._onStartPkg(t), Ext.isFunction(a) && a()) : 1 === i ? e ? Ext.isFunction(a) ? a() : this._onLoadPkgStore(t.get("id"), !1) : this._onRequestDownload(t, e, a, o) : e ? this._onCheckInstall(t, a, o) : this._onRequestDownload(t, e, a, o)
        }.createDelegate(this);
        this.setStatusBusy(), this._onCheckEnv(n, t, function(r, o) {
            if (this.clearStatusBusy(), r) return !e && o.is_occupied ? (this._onResetInstPkgs(), this.getMsgBox().alert(t.get("dname"), _T("pkgmgr", "error_occupied")), void(Ext.isFunction(a) && a())) : void(this._isFirstBuy(t) || this._isLicenseError(t) ? (this.setStatusBusy(), this.sendWebAPI({
                api: "SYNO.Core.Package.MyDS",
                method: "get",
                version: 1,
                params: {},
                callback: function(e, i) {
                    if (!this.isDestroyed)
                        if (this.clearStatusBusy(), e && Ext.isDefined(i) && Ext.isDefined(i.myds_id)) Ext.apply(SYNO.SDS.PkgManApp.Config, i), this._showMyDSDialog(s, t, l, o, n);
                        else if (Ext.isDefined(i) && 4571 == i.code) new SYNO.SDS.MyDSCenter.LoginDialog({
                        owner: this.owner,
                        listeners: {
                            scope: this,
                            cancel_login: this._onResetInstPkgs,
                            login_success: function(e, i, a) {
                                a ? this._showMyDSDialog(s, t, l, o, n) : this._onResetInstPkgs()
                            }
                        }
                    }).show();
                    else {
                        this._onResetInstPkgs();
                        var a = _T("common", "error_system");
                        i.code && (a = SYNO.API.getErrorString(i.code)), this.getMsgBox().alert(this.title, a, function() {}, this)
                    }
                },
                scope: this
            })) : l.call(this, this, o, n));
            o ? this._onCheckEnvFail(o, t, a, {
                fn: this._onRequestSynoPkg,
                args: [t, e, i, a, n],
                scope: this
            }) : (this._onResetInstPkgs(), this.getMsgBox().alert(t.get("dname") || _T("tree", "leaf_packagemanage"), String.format("{0} {1}", _T("pkgmgr", "system_error"), _T("pkgmgr", "contact_support_or_try_again")), function() {
                Ext.isFunction(a) && a()
            }, this))
        })
    },
    _onClickSynoPkgActionBtn: function(t, e) {
        var i = this.getProgressData(t).progress;
        Ext.isDefined(e) || (e = !1), this._IsInstalling(t.data) ? this._onLoadPkgStore(t.get("id"), !1) : i > 0 ? e || this._onRequestCancelDownload(t) : this._applyVersionAndBetaCheck(t, function() {
            var e = this;
            this._applyFeasibilityCheck({
                type: "install_check",
                packages: [t.id]
            }).then(function(i) {
                i && e._onClickInstall(t)
            })
        }.createDelegate(this))
    },
    _isFirstBuy: function(t) {
        var e = t.data;
        return !(!Ext.isEmpty(e.status) || "syno" !== t.data.source) && 0 !== e.type
    },
    _isLicenseError: function(t) {
        var e = t.data;
        return 0 !== e.type && "syno" === e.source && "license_error" === e.status
    },
    _PrepareOperationGridTitle: function(t, e) {
        var i = this._getInstalledStore().getById(t.pkg),
            a = i.get("beta") ? String.format("({0})", _T("pkgmgr", "beta")) : "";
        switch (t.operation) {
            case "start":
                return e.length > 1 ? String.format(_T("pkgmgr", "start_operation_desc_plural"), i.get("dname") + a) : String.format(_T("pkgmgr", "start_operation_desc"), i.get("dname") + a);
            case "stop":
                return e.length > 1 ? String.format(_T("pkgmgr", "stop_operation_desc_plural"), i.get("dname") + a) : String.format(_T("pkgmgr", "stop_operation_desc"), i.get("dname") + a);
            case "uninstall":
                return e.length > 1 ? String.format(_T("pkgmgr", "uninstall_operation_desc_plural"), i.get("dname") + a) : String.format(_T("pkgmgr", "uninstall_operation_desc"), i.get("dname") + a);
            default:
                throw "not supported operation: ".concat(t.operation)
        }
    },
    _PrepareOperationGridMessages: function(t, e) {
        var i = [],
            a = !0,
            n = !1,
            s = void 0;
        try {
            for (var r, o = e[Symbol.iterator](); !(a = (r = o.next()).done); a = !0) {
                var l = r.value;
                if (t.pkg != l.pkg) {
                    var p = this._getInstalledStore().getById(l.pkg),
                        g = p.get("beta") ? String.format("({0})", _T("pkgmgr", "beta")) : "";
                    switch (l.operation) {
                        case "start":
                            i.push(String.format(_T("pkgmgr", "start_pkg"), p.get("dname") + g));
                            break;
                        case "stop":
                            i.push(String.format(_T("pkgmgr", "stop_pkg"), p.get("dname") + g));
                            break;
                        case "uninstall":
                            i.push(String.format(_T("pkgmgr", "uninstall_pkg"), p.get("dname") + g));
                            break;
                        default:
                            throw "not supported operation: ".concat(l.operation)
                    }
                }
            }
        } catch (t) {
            n = !0, s = t
        } finally {
            try {
                a || null == o.return || o.return()
            } finally {
                if (n) throw s
            }
        }
        return i
    },
    _RunPackageOperations: function() {
        var t = _asyncToGenerator(regeneratorRuntime.mark(function t(e) {
            var i, a, n, s, r, o, l, p, g, c, d, h, u, m, S, _, k;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return this.setStatusBusy(), t.next = 3, this.sendWebAPIInsensitivePromise({
                            api: "SYNO.Core.Package",
                            method: "get_queue",
                            version: 1,
                            timeout: 9e5,
                            params: {
                                operations: e
                            }
                        });
                    case 3:
                        if (i = t.sent, a = _slicedToArray(i, 4), n = a[0], s = a[1], r = a[2], o = a[3], this.clearStatusBusy(), n) {
                            t.next = 13;
                            break
                        }
                        return this._showErrMsg(s, o, r), t.abrupt("return");
                    case 13:
                        if (!(l = s.steps.length > 1)) {
                            t.next = 22;
                            break
                        }
                        return p = this._PrepareOperationGridTitle(e[0], s.steps), g = this._PrepareOperationGridMessages(e[0], s.steps), t.next = 19, this._ConfirmByGrid(p, g);
                    case 19:
                        if ("yes" === t.sent) {
                            t.next = 22;
                            break
                        }
                        return t.abrupt("return");
                    case 22:
                        c = !0, d = !1, h = void 0, t.prev = 25, u = s.steps[Symbol.iterator]();
                    case 27:
                        if (c = (m = u.next()).done) {
                            t.next = 52;
                            break
                        }
                        S = m.value, _ = this._getInstalledStore().getById(S.pkg), k = !1, t.t0 = S.operation, t.next = "start" === t.t0 ? 34 : "stop" === t.t0 ? 38 : "uninstall" === t.t0 ? 42 : 46;
                        break;
                    case 34:
                        return t.next = 36, this._RunPackageStart(_, l);
                    case 36:
                        return k = t.sent, t.abrupt("break", 47);
                    case 38:
                        return t.next = 40, this._RunPackageStop(_, l);
                    case 40:
                        return k = t.sent, t.abrupt("break", 47);
                    case 42:
                        return t.next = 44, this._RunPackageUninstall(_, l);
                    case 44:
                        return k = t.sent, t.abrupt("break", 47);
                    case 46:
                        return t.abrupt("break", 47);
                    case 47:
                        if (k) {
                            t.next = 49;
                            break
                        }
                        return t.abrupt("break", 52);
                    case 49:
                        c = !0, t.next = 27;
                        break;
                    case 52:
                        t.next = 58;
                        break;
                    case 54:
                        t.prev = 54, t.t1 = t.catch(25), d = !0, h = t.t1;
                    case 58:
                        t.prev = 58, t.prev = 59, c || null == u.return || u.return();
                    case 61:
                        if (t.prev = 61, !d) {
                            t.next = 64;
                            break
                        }
                        throw h;
                    case 64:
                        return t.finish(61);
                    case 65:
                        return t.finish(58);
                    case 66:
                    case "end":
                        return t.stop()
                }
            }, t, this, [
                [25, 54, 58, 66],
                [59, , 61, 65]
            ])
        }));
        return function(e) {
            return t.apply(this, arguments)
        }
    }(),
    _RunPackageStart: function() {
        var t = _asyncToGenerator(regeneratorRuntime.mark(function t(e) {
            var i, a, n, s, r, o;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.next = 2, this._applyFeasibilityCheck({
                            type: "start_check",
                            packages: [e.id]
                        });
                    case 2:
                        if (t.sent) {
                            t.next = 5;
                            break
                        }
                        return t.abrupt("return", !1);
                    case 5:
                        return this.setStatusBusy(), SYNO.SDS.StatusNotifier.fireEvent("pkgctl", e.id, "start", "pre"), t.next = 9, this.sendWebAPIInsensitivePromise({
                            api: "SYNO.Core.Package.Control",
                            method: "start",
                            version: 1,
                            timeout: 36e5,
                            params: {
                                id: e.id,
                                dsm_apps: e.get("dsm_apps") ? e.get("dsm_apps").split(" ") : []
                            }
                        });
                    case 9:
                        return i = t.sent, a = _slicedToArray(i, 4), n = a[0], s = a[1], r = a[2], o = a[3], this.clearStatusBusy(), this._handleApplyDone(n, s, r, o), t.abrupt("return", n);
                    case 18:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }));
        return function(e) {
            return t.apply(this, arguments)
        }
    }(),
    _RunPackageStop: function() {
        var t = _asyncToGenerator(regeneratorRuntime.mark(function t(e, i) {
            var a, n, s, r, o, l;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.next = 2, this._applyFeasibilityCheck({
                            type: "stop_check",
                            packages: [e.id]
                        });
                    case 2:
                        if (t.sent) {
                            t.next = 5;
                            break
                        }
                        return t.abrupt("return", !1);
                    case 5:
                        if (i) {
                            t.next = 11;
                            break
                        }
                        return t.next = 8, this._ConfirmByBox(_T("pkgmgr", "pkgmgr_pkg_stop_warn"));
                    case 8:
                        if ("yes" === t.sent) {
                            t.next = 11;
                            break
                        }
                        return t.abrupt("return", !1);
                    case 11:
                        return this.setStatusBusy(), SYNO.SDS.StatusNotifier.fireEvent("pkgctl", e.id, "stop", "pre"), t.next = 15, this.sendWebAPIInsensitivePromise({
                            api: "SYNO.Core.Package.Control",
                            method: "stop",
                            version: 1,
                            timeout: 36e5,
                            params: {
                                id: e.id
                            }
                        });
                    case 15:
                        return a = t.sent, n = _slicedToArray(a, 4), s = n[0], r = n[1], o = n[2], l = n[3], this.clearStatusBusy(), this._handleApplyDone(s, r, o, l), t.abrupt("return", s);
                    case 24:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }));
        return function(e, i) {
            return t.apply(this, arguments)
        }
    }(),
    _RunPackageUninstall: function() {
        var t = _asyncToGenerator(regeneratorRuntime.mark(function t(e, i) {
            var a, n, s, r, o, l, p, g, c = this;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.next = 2, this._applyFeasibilityCheck({
                            type: "uninstall_check",
                            packages: [e.id]
                        });
                    case 2:
                        if (t.sent) {
                            t.next = 5;
                            break
                        }
                        return t.abrupt("return", !1);
                    case 5:
                        if (a = function() {
                                SYNO.SDS.PkgManApp.Window.pageList.getNodeById("SYNO.SDS.PkgManApp.Installed.Panel").isSelected() && (SYNO.SDS.PkgManApp.Window.setCurrentPage("SYNO.SDS.PkgManApp.Installed.Panel", 0), SYNO.SDS.PkgManApp.Window.pageCt.ownerCt.pageCt.getComponent("SYNO.SDS.PkgManApp.Installed.Panel").layout.setActiveItem(0)), SYNO.SDS.PkgManApp.Action.clearProgress(e.get("id"))
                            }, !e.get("pkgisuninstui")) {
                            t.next = 11;
                            break
                        }
                        return t.next = 9, new Promise(function(t) {
                            var i = new SYNO.SDS.PkgManApp.UninstallWizardDialog({
                                owner: c,
                                packagename: e.id,
                                dname: e.get("dname"),
                                dsm_apps: e.get("dsm_apps")
                            });
                            i.mon(i, "uninstalldone", function() {
                                t()
                            }), i.open()
                        });
                    case 9:
                        return a(), t.abrupt("return", !0);
                    case 11:
                        if (i) {
                            t.next = 17;
                            break
                        }
                        return t.next = 14, this._ConfirmByBox(_T("pkgmgr", "pkgmgr_pkg_uninstall_warn"));
                    case 14:
                        if ("yes" === t.sent) {
                            t.next = 17;
                            break
                        }
                        return t.abrupt("return", !1);
                    case 17:
                        return this.setStatusBusy(), SYNO.SDS.StatusNotifier.fireEvent("pkgctl", e.id, "uninstall", "pre"), t.next = 21, this.sendWebAPIInsensitivePromise({
                            api: "SYNO.Core.Package.Uninstallation",
                            method: "uninstall",
                            version: 1,
                            timeout: 36e5,
                            params: {
                                id: e.id,
                                dsm_apps: e.get("dsm_apps")
                            }
                        });
                    case 21:
                        if (n = t.sent, s = _slicedToArray(n, 4), r = s[0], o = s[1], l = s[2], p = s[3], this.clearStatusBusy(), !SYNO.SDS.PkgManApp.Window.isDestroyed) {
                            t.next = 30;
                            break
                        }
                        return t.abrupt("return", !1);
                    case 30:
                        return a(), r && l && l.id && ((g = this._getInstalledStore().getById(l.id)) && this._getInstalledStore().remove(g), this.clearProgress(l.id)), this._handleApplyDone(r, o, l, p), t.abrupt("return", r);
                    case 34:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }));
        return function(e, i) {
            return t.apply(this, arguments)
        }
    }(),
    _onStartPkg: function() {
        var t = _asyncToGenerator(regeneratorRuntime.mark(function t(e) {
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.next = 2, this._RunPackageOperations([{
                            pkg: e.get("id"),
                            version: e.get("version"),
                            beta: e.get("beta"),
                            operation: "start"
                        }]);
                    case 2:
                        return t.abrupt("return", t.sent);
                    case 3:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }));
        return function(e) {
            return t.apply(this, arguments)
        }
    }(),
    _onStopPkg: function() {
        var t = _asyncToGenerator(regeneratorRuntime.mark(function t(e) {
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.next = 2, this._RunPackageOperations([{
                            pkg: e.get("id"),
                            version: e.get("version"),
                            beta: e.get("beta"),
                            operation: "stop"
                        }]);
                    case 2:
                        return t.abrupt("return", t.sent);
                    case 3:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }));
        return function(e) {
            return t.apply(this, arguments)
        }
    }(),
    _onUninstallPkg: function() {
        var t = _asyncToGenerator(regeneratorRuntime.mark(function t(e) {
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return t.next = 2, this._RunPackageOperations([{
                            pkg: e.get("id"),
                            version: e.get("version"),
                            beta: e.get("beta"),
                            operation: "uninstall"
                        }]);
                    case 2:
                        return t.abrupt("return", t.sent);
                    case 3:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }));
        return function(e) {
            return t.apply(this, arguments)
        }
    }(),
    _showLog: function(t) {
        new SYNO.SDS.PkgManApp.LogDialog({
            owner: this
        }, t).open()
    },
    _showMyDSDialog: function(t, e, i, a, n) {
        new SYNO.SDS.PkgManApp.MyDSDialog({
            owner: this,
            myds_params: Ext.apply({
                appId: e.get("id"),
                version: e.get("version")
            }, t),
            type: e.data.type,
            listeners: {
                scope: this,
                payevent: i.createDelegate(this, [this, a, n]),
                payfailed: this._onResetInstPkgs
            }
        }).show()
    },
    getIconFromServerOrDSM: function(t, e, i) {
        var a = this._getAvalRec(t.id);
        return a ? SYNO.SDS.PkgManApp.Utils.Helper.getIconFromServer(a.data, e, i) : SYNO.SDS.PkgManApp.Utils.Helper.getIconFromDS(t, e)
    },
    existsInForeBackPkgs: function(t, e) {
        if (!Ext.isArray(t)) return !1;
        var i = !1;
        return t.forEach(function(t) {
            t.id === e && (i = !0)
        }, this), i
    },
    getRecFromSameChannel: function(t) {
        var e = this._getInstalledStore().getById(t).get("beta") ? "beta" : "stable";
        return SYNO.SDS.PkgManApp.Window.getStore(e).getById(t) || this._getOtherServerObj().store.getById(t)
    },
    getProgressData: function(t, e, i, a) {
        i = i || !1, a = a || !1, t ? (e = t.get("id"), i = t.get("beta")) : t = this._getAvalRecByChannel(e, i);
        var n = SYNO.SDS.PkgManApp.Window.progressDatas[e];
        return n && (a || i == (n.beta || !1)) ? n : {
            progress: t ? t.get("progress") : null
        }
    },
    clearProgress: function(t) {
        var e = this,
            i = SYNO.SDS.PkgManApp.Window.getStore("installed"),
            a = SYNO.SDS.PkgManApp.Window.getStore("stable"),
            n = SYNO.SDS.PkgManApp.Window.getStore("community"),
            s = SYNO.SDS.PkgManApp.Window.getStore("beta");
        [t].forEach(function(t) {
            delete SYNO.SDS.PkgManApp.Window.progressDatas[t], e.triggerUpdate(i, t), e.triggerUpdate(n, t), e.triggerUpdate(a, t), e.triggerUpdate(s, t)
        })
    },
    triggerUpdate: function(t, e) {
        var i = t.getById(e);
        void 0 !== i && t.fireEvent("update", t, i, Ext.data.Record.COMMIT)
    }
}), SYNO.SDS.PkgManApp.ActionUtils = {}, Ext.apply(SYNO.SDS.PkgManApp.ActionUtils, {
    _onCheckPKGFail: function(t, e, i) {
        var a = this._onCheckPKGFailMsg(e, t, void 0);
        i = Ext.isFunction(i) ? Ext.createInterceptor(a.callback, i, this) : a.callback, this.getMsgBox().confirm(e || _T("tree", "leaf_packagemanage"), a.msg, i, this, a.buttons || Ext.MessageBox.OK), this._onResetInstPkgs()
    },
    _onCheckEnvFail: function(t, e, i, a) {
        var n = e.get("dname"),
            s = this._onCheckPKGFailMsg(n, t, void 0);
        if (i = Ext.isFunction(i) ? Ext.createInterceptor(s.callback, i, this) : s.callback, t && 4552 === t.code && (t.errors.packages || t.errors.brokenPkgs || t.errors.replacedPkgs)) {
            var r = "";
            t.errors.packages && (r += String.format(_T("pkgmgr", "error_upgrade_dep_statable_packages"), n, t.errors.packages) + "<br/>"), t.errors.brokenPkgs && (r += String.format(_T("pkgmgr", "error_break_packages"), n, t.errors.brokenPkgs) + "<br/>"), t.errors.replacedPkgs && (r += String.format(_T("pkgmgr", "error_replace_packages"), n, t.errors.replacedPkgs) + "<br/>"), r += _T("common", "cfrm_continue"), this.getMsgBox().confirm(n || _T("tree", "leaf_packagemanage"), r, function(t) {
                "yes" === t ? (a.args && (a.args[a.args.length - 1] = {
                    blCheckDep: !1
                }), a.fn.apply(a.scope, a.args || [])) : this._onResetInstPkgs()
            }, this)
        } else this.getMsgBox().confirm(n || _T("tree", "leaf_packagemanage"), s.msg, i, this, s.buttons || Ext.MessageBox.OK), this._onResetInstPkgs()
    },
    _notifyServiceStatus: function(t, e, i, a) {
        if (i) {
            var n = SYNO.API.Util.GetReqByAPI(a, "SYNO.Core.Package", "get", "id") || i.id;
            n = SYNO.SDS.PkgManApp.Utils.Utils.unquote(n);
            var s = SYNO.API.Response.GetValByAPI(e, "SYNO.Core.Package", "get"),
                r = i.method;
            a && a.params && a.params.method && (r = a.params.method);
            for (var o = e.result ? e.result.length : 0, l = 0; l < o; l++)
                if (("install" === e.result[l].method || "upgrade" === e.result[l].method || "start" === e.result[l].method) && !0 === e.result[l].success) {
                    r = e.result[l].method;
                    break
                } this._notifyPackage(n, r, s || e, i), SYNO.SDS.StatusNotifier.fireEvent("thirdpartychanged", n, r, "uninstall" === r ? i.dsm_apps.split(" ") : ""), SYNO.SDS.StatusNotifier.fireEvent("pkgctl", n, r, "post", !0)
        }
    },
    _handleApplyDone: function(t, e, i, a) {
        t && e && !e.has_fail ? SYNO.API.Response.GetValByAPI(e, "SYNO.Core.Package.Installation", "install", "reboot") ? (this._showDoneMessage(t, e, i, a), SYNO.SDS.System.RebootWithMsg(_T("pkgmgr", "reboot_warn"))) : this._showDoneMessage(t, e, i, a) : this._showErrMsg(e, a, i), SYNO.SDS.PkgManApp.Window.mon(SYNO.SDS.PkgManApp.Window, "status_load", function() {
            this._onLoadSynoPkgStore(!0)
        }, this, {
            single: !0
        })
    },
    _notifyPackage: function(t, e, i, a) {
        var n = [];
        a && Ext.isArray(a.dsm_apps) ? n = a.dsm_apps : i && i.dsm_apps ? n = i.dsm_apps.split(" ") : i && i.additional && i.additional.dsm_apps && (n = i.additional.dsm_apps.split(" ")), SYNO.SDS.StatusNotifier.on("jsconfigLoaded", function() {
            "install" !== e && "upgrade" !== e || Ext.isEmpty(n) ? SYNO.SDS.AppView.refresh() : (SYNO.SDS.AppView.notifyInstalled(n), Ext.each(n, function(t) {
                var e = SYNO.SDS.Config.FnMap[t];
                e && e.config && e.config.useCSPRule && (SYNO.SDS.Config.CheckCSPRefresh || (SYNO.SDS.Config.CheckCSPRefresh = []), SYNO.SDS.Config.CheckCSPRefresh.push(t))
            }))
        }, this, {
            single: !0,
            delay: 100
        })
    },
    _parseDepPkg: function(t) {
        var e = [];
        for (var i in t)
            if (t.hasOwnProperty(i)) {
                var a = this._getAvalRec(i),
                    n = a ? a.get("dname") : i,
                    s = "";
                for (var r in t[i])
                    if (t[i].hasOwnProperty(r)) {
                        switch (Ext.util.Format.htmlDecode(r)) {
                            case ">=":
                                s = String.format(_T("pkgmgr", "version_bigger_equal"), n, t[i][r]);
                                break;
                            case "<=":
                                s = String.format(_T("pkgmgr", "version_less_equal"), n, t[i][r]);
                                break;
                            case "=":
                                s = String.format(_T("pkgmgr", "version_equal"), n, t[i][r]);
                                break;
                            case ">":
                                s = String.format(_T("pkgmgr", "version_bigger"), n, t[i][r]);
                                break;
                            case "<":
                                s = String.format(_T("pkgmgr", "version_less"), n, t[i][r]);
                                break;
                            default:
                                s = n
                        }
                        break
                    } e.push(s || n)
            } return e
    },
    _onCheckPKGFailMsg: function(t, e, i) {
        e = e && e.error || e || {};
        var a, n, s = i || _T("user", "user_file_upload_fail"),
            r = Ext.emptyFn,
            o = e;
        switch (o.code && (n = o.code, Ext.isObject(o.errors) && (o = o.errors)), n) {
            case 4502:
                var l = {};
                !0 === o.no_storage_pool ? (s = _T("pkgmgr", "error_no_volume_and_storage_pool"), l = {
                    width: 820,
                    height: 560,
                    title: _T("volume", "wizard_title_create_both"),
                    mode: "both"
                }) : (s = "generic" == o.required_volume_type ? _T("pkgmgr", "error_peta_volume_cannot_be_installed") : _T("pkgmgr", "error_no_volume"), l = {
                    width: 820,
                    height: 560,
                    title: _T("volume", "create_volume"),
                    mode: "volume"
                }), a = {
                    ok: _T("pkgmgr", "launch"),
                    cancel: !0
                }, r = function(t) {
                    "ok" === t && SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance", {
                        fn: "SYNO.SDS.StorageManager.Pool.Main",
                        vueWizard: "CreateWizardWindow",
                        modalParam: l
                    })
                };
                break;
            case 4503:
                s = _T("error", "volume_creating"), r = function(t) {
                    "ok" === t && SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance")
                };
                break;
            case 4526:
                var p, g, c, d = this._parseDepPkg(o.uninstall_packages);
                Ext.isEmpty(o.unstart_packages) || Ext.isEmpty(d) ? Ext.isEmpty(o.unstart_packages) ? (p = d, g = _T("pkgmgr", "depend_packages")) : (p = o.unstart_packages.split(", "), g = _T("pkgmgr", "depend_unstart")) : (p = d.concat(o.unstart_packages.split(", ")), g = _T("pkgmgr", "depend_uninst_unstart")), c = '<ul class="synopkg-ul-list" style="display: inline-block;">', c += p.map(function(t) {
                    return "<li>" + t + "</li>"
                }).join(""), c += "</ul>", s = String.format(g, "<br>" + c);
                break;
            case 4531:
                s = _T("pkgmgr", "pkgmgr_not_syno_publish");
                break;
            case 4532:
                s = _T("pkgmgr", "confirm_3rdparty_package_installation");
                break;
            case 4533:
                s = _T("pkgmgr", "pkgmgr_no_signature");
                break;
            case 4534:
                s = _T("pkgmgr", "pkgmgr_cert_expired");
                break;
            case 4535:
                s = _T("pkgmgr", "broken_package");
                break;
            case 4536:
                s = -1 != o.require_os.search("Surveillance") ? _T("pkgmgr", "pkgmgr_pkg_os_require_surveillance") : String.format(_T("pkgmgr", "pkgmgr_pkg_os_not_support"), o.current_os, o.require_os);
                break;
            case 4557:
                s = String.format(_T("pkgmgr", "high_privilege_config_not_allowed"), o.packageName);
                break;
            case 4582:
                s = String.format(_T("pkgmgr", "error_stop_dep_packages"), o.packages);
                break;
            case 4583:
                s = String.format(_T("pkgmgr", "version_less_than_limit"), o.current_version, o.require_version);
                break;
            case 4546:
                s = String.format(_T("pkgmgr", "downgrade_version"), o.current_version, o.install_version);
                break;
            case 4547:
            case 4552:
                s = t ? String.format(_T("pkgmgr", "error_upgrade_dep_packages_with_name"), o.packages, t) : String.format(_T("pkgmgr", "error_upgrade_dep_packages"), o.packages);
                break;
            case 4525:
                var h = this._decodeServiceErr(o.services);
                s = h.msg, r = h.callback;
                break;
            default:
                s = SYNO.SDS.PkgManApp.Utils.Utils.getWebAPIErr(!1, e, {}, t)
        }
        return t && (s = t + ":<br>" + s), {
            msg: s,
            buttons: a,
            callback: r
        }
    },
    _showDoneMessage: function(t, e, i, a) {
        var n, s, r, o, l = "",
            p = "",
            g = "msgbox";
        if (a && a.params) {
            var c = !1,
                d = SYNO.API.Response.GetValByAPI(e, "SYNO.Core.Package", "get", "additional");
            switch (d && "running" === d.status && (c = !0), SYNO.API.Util.GetReqByIndex(a, 0, "method")) {
                case "uninstall":
                    l = _T("pkgmgr", "pkgmgr_pkg_uninstall_success"), g = "toast";
                    break;
                case "install":
                    l = 1 === this.mode ? c ? "" : _T("pkgmgr", "pkgmgr_pkg_upgrade_wizard_done") : c ? "" : _T("pkgmgr", "pkgmgr_pkg_install_wizard_done");
                    break;
                case "upgrade":
                    l = c ? "" : _T("pkgmgr", "pkgmgr_pkg_upgrade_wizard_done")
            }
        }
        if (Ext.isArray(e.result))
            for (n = e.result, r = 0; r < n.length; r++)(o = SYNO.API.Response.GetValByIndex(e, r, "message")) && o !== p && (l += (l ? "<br>" : "") + o, p = o);
        else e.message && (l += (l ? "<br>" : "") + SYNO.SDS.PkgManApp.Utils.Utils.localizeMsg(e.message));
        if (Ext.isDefined(e.worker_message)) {
            var h = SYNO.SDS.PkgManApp.Utils.Utils.localizeWorkerMsg(e.worker_message);
            h && (l += (l ? "<br>" : "") + h)
        }
        if (l)
            if ("msgbox" === g) s = this.dname || this.pkgName || _T("tree", "leaf_packagemanage"), this.getMsgBox().alert(s, l, function() {
                this.isFinished = !0, this.goNext && this.goNext(null)
            }, this);
            else if ("toast" === g) {
            this.findAppWindow().getToastBox(l, !0)
        }
        l && "msgbox" === g || (this.isFinished = !0, this.goNext && this.goNext(null)), i && this._notifyServiceStatus(t, e, i, a)
    },
    _decodeServiceErr: function(t) {
        var e = null,
            i = null,
            a = "",
            n = _T("controlpanel", "leaf_service"),
            s = Object.keys(t)[0];
        switch (s) {
            case "sshd.service":
                a = _T("pkgmgr", "require_sshd"), n = _T("tree", "leaf_terminal"), e = "SYNO.SDS.AdminCenter.TerminalSNMP.Main", i = "terminal";
                break;
            case "pgsql-adapter.service":
                "yes" === _D("usbstation", "no") ? (a = _T("pkgmgr", "require_pgsql"), n = _T("metadata", "metadata_title"), e = "SYNO.SDS.AdminCenter.SystemDatabase.Main") : a = "activating" === t["pgsql-adapter.service"] ? _T("pkgmgr", "wait_pgsql") : String.format(_T("pkgmgr", "require_service"), "pgsql-adapter.service");
                break;
            case "atalk.service":
                a = String.format(_T("pkgmgr", "require_service"), _T("network", "apple_subject")), n = _T("tree", "leaf_file_services"), e = "SYNO.SDS.AdminCenter.FileService.Main", i = "afp";
                break;
            case "nfs-server.service":
                a = String.format(_T("pkgmgr", "require_service"), _T("tree", "leaf_nfs")), n = _T("tree", "leaf_file_services"), e = "SYNO.SDS.AdminCenter.FileService.Main", i = "nfs";
                break;
            case "syno-share.target":
            case "network.target":
            case "network-online.target":
            case "nginx.service":
            case "avahi.service":
            case "crond.service":
                a = String.format(_T("pkgmgr", "require_service"), s) + "<br>" + _T("pkgmgr", "contact_support");
                break;
            case "multi-user.target":
                a = String.format(_T("pkgmgr", "require_service"), s) + "<br>" + _T("pkgmgr", "contact_support_or_try_again");
                break;
            default:
                a = String.format(_T("pkgmgr", "require_service"), Object.keys(t).join(", "))
        }
        return e ? {
            msg: a + "<br>" + String.format(_T("pkgmgr", "prompt_enable_serviece"), n),
            callback: function(t) {
                "ok" === t && (SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                    fn: e,
                    tab: i
                }), this.goNext && this.goNext(null))
            }
        } : {
            msg: a,
            callback: function() {
                this.goNext && this.goNext(null)
            }
        }
    },
    _showErrMsg: function(t, e, i) {
        var a, n, s = String.format("{0} {1}", _T("pkgmgr", "system_error"), _T("pkgmgr", "contact_support_or_try_again")),
            r = this.dname || this.pkgName || _T("tree", "leaf_packagemanage");
        if (t) {
            s = "";
            var o, l, p, g, c = SYNO.API.Response.GetFirstError(t),
                d = !0;
            if (c) switch (o = SYNO.API.Response.GetFirstErrorIndex(t), "SYNO.Core.Package.Control" === (l = SYNO.API.Util.GetReqByIndex(e, o, "api")) ? (p = SYNO.API.Util.GetReqByIndex(e, o, "method"), g = SYNO.SDS.PkgManApp.Utils.Utils.unquote(SYNO.API.Util.GetReqByIndex(e, o, "id")), 0 === o ? (s = "start" === p ? _T("pkgmgr", "pkgmgr_pkg_start_failed") : _T("pkgmgr", "pkgmgr_pkg_stop_failed"), SYNO.SDS.StatusNotifier.fireEvent("pkgctl", g, p, "post", !1)) : (d = !0, s = this.mode ? _T("pkgmgr", "pkgmgr_pkg_upgrade_wizard_done") : _T("pkgmgr", "pkgmgr_pkg_install_wizard_done"))) : "SYNO.Core.Package" === l ? SYNO.API.Util.GetReqByAPI(e, "SYNO.Core.Package.Control", "start") ? (g = SYNO.SDS.PkgManApp.Utils.Utils.unquote(SYNO.API.Util.GetReqByAPI(e, "SYNO.Core.Package.Control", "start", "id")), SYNO.SDS.StatusNotifier.fireEvent("pkgctl", g, "start", "post", !1), s = _T("pkgmgr", "pkgmgr_pkg_start_failed")) : SYNO.API.Util.GetReqByAPI(e, "SYNO.Core.Package.Control", "stop") ? (g = SYNO.SDS.PkgManApp.Utils.Utils.unquote(SYNO.API.Util.GetReqByAPI(e, "SYNO.Core.Package.Control", "stop", "id")), SYNO.SDS.StatusNotifier.fireEvent("pkgctl", g, "stop", "post", !1), s = _T("pkgmgr", "pkgmgr_pkg_stop_failed")) : s = this.mode ? _T("pkgmgr", "pkgmgr_pkg_upgrade_wizard_done") : _T("pkgmgr", "pkgmgr_pkg_install_wizard_done") : "SYNO.Core.Package.Installation" === l ? "install" !== (p = SYNO.API.Util.GetReqByIndex(e, o, "method")) && "upgrade" !== p || (this.dname || this.pkgName ? (SYNO.SDS.StatusNotifier.fireEvent("pkgctl", this.pkgName, this.mode ? "upgrade" : "install", "post", !1), s = String.format(this.mode ? _T("pkgmgr", "upgrade_pkg_fail") : _T("pkgmgr", "install_pkg_fail"), this.dname || this.pkgName, "")) : s = this.mode ? _T("pkgmgr", "upgrade_fail") : _T("pkgmgr", "install_fail")) : "SYNO.Core.Package.Uninstallation" === l && (g = SYNO.SDS.PkgManApp.Utils.Utils.unquote(SYNO.API.Util.GetReqByIndex(e, o, "id")), SYNO.SDS.StatusNotifier.fireEvent("pkgctl", g, "uninstall", "post", !1)), n = c.code, c = c.errors || c, n) {
                case 4502:
                    s = _T("error", "volume_no_volumes"), a = function(t) {
                        "ok" === t && SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance")
                    };
                    break;
                case 4503:
                    s = _T("error", "volume_creating"), a = function(t) {
                        "ok" === t && SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance")
                    };
                    break;
                case 4525:
                    var h = this._decodeServiceErr(c.services);
                    d && (s = _T("pkgmgr", "pkgmgr_pkg_start_failed") + "<br>"), s += h.msg, a = h.callback;
                    break;
                case 4562:
                    s = String.format(_T("pkgmgr", "error_uninst_dep_packages"), c.packages);
                    break;
                case 4547:
                    s = this.dname || this.pkgName ? String.format(_T("pkgmgr", "error_upgrade_dep_packages_with_name"), c.packages, this.dname || this.pkgName) : String.format(_T("pkgmgr", "error_upgrade_dep_packages"), c.packages);
                    break;
                case 4552:
                    if ("check" === (p = SYNO.API.Util.GetReqByIndex(e, o, "method")) && e.compound) {
                        var u = this.dname || this.pkgName;
                        return s = "", c.packages && (s += String.format(_T("pkgmgr", "error_upgrade_dep_statable_packages"), u, c.packages) + "<br/>"), c.brokenPkgs && (s += String.format(_T("pkgmgr", "error_break_packages"), u, c.brokenPkgs) + "<br/>"), c.replacedPkgs && (s += String.format(_T("pkgmgr", "error_replace_packages"), u, c.replacedPkgs) + "<br/>"), s += _T("common", "cfrm_continue"), void this.getMsgBox().confirm(this.dname || _T("tree", "leaf_packagemanage"), s, function(t) {
                            "yes" === t && (this.setStatusBusy(), SYNO.API.Util.GetReqByIndex(e, o + 1).params.force = !0, this.sendWebAPI({
                                timeout: 36e5,
                                compound: {
                                    stopwhenerror: e.compound.stopwhenerror,
                                    params: e.compound.params.slice(1, e.compound.params.length)
                                },
                                scope: this,
                                callback: function(t, e, i, a) {
                                    this.clearStatusBusy(), this._handleApplyDone(t, e, i, a)
                                }
                            }))
                        }, this)
                    }
                    s = this.dname || this.pkgName ? String.format(_T("pkgmgr", "error_upgrade_dep_packages_with_name"), c.packages, this.dname || this.pkgName) : String.format(_T("pkgmgr", "error_upgrade_dep_packages"), c.packages);
                    break;
                case 4582:
                    s = String.format(_T("pkgmgr", "error_stop_dep_packages"), c.packages);
                    break;
                case 4546:
                    s = String.format(_T("pkgmgr", "downgrade_version"), c.current_version, c.install_version);
                    break;
                case 4583:
                case 4548:
                    s = String.format(_T("pkgmgr", "version_less_than_limit"), c.current_version, c.require_version);
                    break;
                default:
                    s = SYNO.SDS.PkgManApp.Utils.Utils.getWebAPIErr(!1, SYNO.API.Response.GetFirstError(t), {}, this.dname || this.pkgName, s)
            }
            c.message && "" !== c.message && (s += (s ? "<br>" : "") + SYNO.SDS.PkgManApp.Utils.Utils.localizeMsg(c.message, c.message, this.dsm_apps)), Ext.isDefined(c.worker_message) && (s += (s ? "<br>" : "") + SYNO.SDS.PkgManApp.Utils.Utils.localizeWorkerMsg(c.worker_message)), "" === s && (s = String.format("{0} {1}", _T("pkgmgr", "system_error"), _T("pkgmgr", "contact_support_or_try_again")))
        }
        this.getMsgBox().alert(r, s, a || function() {
            var t = SYNO.API.Util.GetReqByIndex(e, 0, "method");
            this.goNext && ("install" !== t && "check" !== t || 4580 === n) && this.goNext(null)
        }, this)
    },
    _applyFeasibilityCheck: function() {
        var t = _asyncToGenerator(regeneratorRuntime.mark(function t(e) {
            var i, a, n, s, r, o;
            return regeneratorRuntime.wrap(function(t) {
                for (;;) switch (t.prev = t.next) {
                    case 0:
                        return this.setStatusBusy(), t.next = 3, this.sendWebAPIInsensitivePromise({
                            api: "SYNO.Core.Package",
                            method: "feasibility_check",
                            version: 1,
                            params: e
                        });
                    case 3:
                        if (i = t.sent, a = _slicedToArray(i, 2), n = a[0], s = a[1], this.clearStatusBusy(), !n) {
                            t.next = 12;
                            break
                        }
                        return t.abrupt("return", !0);
                    case 12:
                        if (4556 !== s.code) {
                            t.next = 24;
                            break
                        }
                        if (r = SYNO.SDS.PkgManApp.Utils.Utils.GetFeasibilityMsgList(s.errors.reasons), "hard" !== s.errors.check_type) {
                            t.next = 20;
                            break
                        }
                        return t.next = 17, this._AlertByBox(_T("pkgmgr", e.type + "_alert") + r);
                    case 17:
                        return t.abrupt("return", !1);
                    case 20:
                        return t.next = 22, this._ConfirmByBox(_T("pkgmgr", e.type + "_confirm") + r);
                    case 22:
                        return o = t.sent, t.abrupt("return", "yes" === o);
                    case 24:
                        return t.abrupt("return", !1);
                    case 25:
                    case "end":
                        return t.stop()
                }
            }, t, this)
        }));
        return function(e) {
            return t.apply(this, arguments)
        }
    }(),
    _applyCodesignCheck: function(t, e, i) {
        if (t.hasOwnProperty("codesign_error")) {
            var a = {
                    code: t.codesign_error
                },
                n = this._onCheckPKGFailMsg(null, a),
                s = "4501" == t.codesign_error ? {
                    ok: !0
                } : {
                    yes: {
                        text: _T("common", "agree"),
                        btnStyle: "red"
                    },
                    cancel: {
                        text: Ext.MessageBox.buttonText.cancel
                    }
                },
                r = "4501" == t.codesign_error ? {} : {
                    icon: "confirm-delete-icon"
                };
            this.getMsgBox().confirm(_T("tree", "leaf_packagemanage"), n.msg, function(t) {
                "yes" === t ? e.call(this, !1) : i.call(this)
            }, this, s, r)
        } else e.call(this, !0)
    },
    _applyVersionAndBetaCheck: function(t, e) {
        var i = this._getInstalledStore().getById(t.id);
        if (i && this.helper.versionCompare(">", i.get("version"), t.get("version"))) {
            var a = String.format(this.helper.T("downgrade_version"), i.get("version"), t.get("version"));
            this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), a)
        } else i && !i.get("beta") && t.get("beta") && "version_limit" !== i.get("status") ? this.getMsgBox().confirm(_T("tree", "leaf_packagemanage"), String.format(this.helper.T("join_beta_confirm"), t.get("dname") || t.id), function(t) {
            "yes" === t && e.call(this)
        }, this) : e.call(this)
    }
}), SYNO.SDS.PkgManApp.DownloadAction = Ext.extend(Ext.util.Observable, {
    constructor: function(t, e) {
        if (this.owner = t.owner, this.foreground = t.foreground, this.id = t.id, this.beta = t.beta, !e) {
            var i = t.data.taskid || t.data.data.taskid;
            e = SYNO.SDS.PackageTaskMgr.addWebAPITask({
                id: i,
                interval: 1200,
                query: {
                    api: "SYNO.Core.Package.Installation",
                    method: "status",
                    version: 1,
                    params: {
                        task_id: i
                    }
                },
                cancel: {
                    api: "SYNO.Core.Package.Installation",
                    method: "cancel",
                    version: 1,
                    params: {
                        taskid: i
                    }
                }
            })
        }
        e.addCallback(this.onDownloadCallBack, this), this.foreground && this.showProgress("", _T("download", "download_task_downloading"), function() {
            this.onSetProgress(this.id, 0), e.cancel()
        }.createDelegate(this)), this.onSetProgress(this.id, 1e-5), this.addEvents({
            finish: !0
        }), SYNO.SDS.PkgManApp.DownloadAction.constructor.call(this)
    },
    onDownloadCallBack: function(t, e, i, a, n) {
        var s;
        if (this.owner.isDestroyed) "cancel" !== e && i && (this.owner._notifyPackage(this.id, this.blupgrad ? "upgrade" : "install", n), SYNO.SDS.StatusNotifier.fireEvent("thirdpartychanged", this.id, this.blupgrad ? "upgrade" : "install"), SYNO.SDS.StatusNotifier.fireEvent("pkgctl", this.id, this.blupgrad ? "upgrade" : "install", "post", !0));
        else if ((s = this.beta ? this.owner._getBetaServerObj().store.getById(this.id) || this.owner._getOtherServerObj().store.getById(this.id) : this.owner._getSynoServerObj().store.getById(this.id) || this.owner._getOtherServerObj().store.getById(this.id)) && !s.isDestroyed) return "cancel" === e ? this.onCancelTask(t, n) : void(i ? this.onFinishTask(a, n) : (a || n && n.installing) && this.onProgressTask(a, n))
    },
    onCancelTask: function(t, e) {
        var i = !0;
        return this.foreground && (this.owner._onResetInstPkgs(), this.owner.getMsgBox().hide()), e && e.code ? (this.owner.getMsgBox().alert(_T("tree", "leaf_packagemanage"), SYNO.API.getErrorString(e.code)), 4506 === e.code && (i = !1, t.restart(!0))) : this.onSetProgress(this.id, 0), SYNO.SDS.PkgManApp.Window.clearStatusBusy(), this.owner._onLoadPkgStore(this.id, !1), i
    },
    onFinishTask: function(t, e) {
        var i;
        i = this.beta ? this.owner._getBetaServerObj().store.getById(this.id) || this.owner._getOtherServerObj().store.getById(this.id) : this.owner._getSynoServerObj().store.getById(this.id) || this.owner._getOtherServerObj().store.getById(this.id), e && e.success ? this.foreground ? this.onSetProgress(this.id, Ext.isDefined(t) ? t : 1, e) : this.onSetProgress(this.id, null, null, !0) : this.onSetProgress(this.id), this.owner.fireEvent("pollinginstpage");
        var a = this.owner._getInstalledStore().getById(i.id),
            n = a && a.available_operation && (a.available_operation.upgrade || a.available_operation.repair);
        if (this.foreground) {
            if (this.owner.getMsgBox().hide(), !e || !e.success) return this.owner.getMsgBox().alert(_T("tree", "leaf_packagemanage"), _T("pkgmgr", "download_fail")), void this.owner._onResetInstPkgs();
            !1 !== this.fireEvent("finish") && this.owner._onRequestInstall(i)
        } else this.owner._notifyPackage(this.id, n ? "upgrade" : "install", e), SYNO.SDS.StatusNotifier.fireEvent("thirdpartychanged", this.id, n ? "upgrade" : "install"), SYNO.SDS.StatusNotifier.fireEvent("pkgctl", this.id, n ? "upgrade" : "install", "post", e.success), this.fireEvent("finish")
    },
    onProgressTask: function(t, e) {
        var i;
        (e && e.success && this.onSetProgress(this.id, t, e), this.foreground && t) && (i = "<center>" + (100 * t).toFixed(0) + "&#37;</center>", this.owner.getMsgBox().updateProgress(t, i, this.msg))
    },
    showProgress: function(t, e, i) {
        this.msg = e;
        var a = {
                title: t,
                msg: e,
                width: 300,
                progress: !0,
                progressText: "<center>0&#37;</center>",
                closable: !1,
                buttons: Ext.Msg.CANCEL,
                fn: i
            },
            n = this.owner.getMsgBox();
        this.owner.mon(this.owner.msgBox, "beforeshow", SYNO.SDS.PkgManApp.Utils.Utils.setGlobalValue, this), this.owner.mon(this.owner.msgBox, "beforeclose", SYNO.SDS.PkgManApp.Utils.Utils.cleanGlobalValue, this), n.show(a)
    },
    onSetProgress: function(t, e, i, a) {
        var n = this;
        [t].forEach(function(t) {
            if (n.owner.progressDatas[t] = {
                    progress: e,
                    info: i,
                    beta: n.beta,
                    blNewlyInstalled: a
                }, n.owner.triggerUpdate(n.owner.stores.installed, t), n.owner.triggerUpdate(n.owner.stores.stable, t), n.owner.triggerUpdate(n.owner.stores.beta, t), n.owner.triggerUpdate(n.owner.stores.community, t), i && i.dsm_apps) {
                var s = i.dsm_apps.split(" ");
                Ext.each(s, function(t) {
                    var e = SYNO.SDS.AppMgr.getByAppName(t);
                    Ext.each(e, function(t) {
                        t.destroy()
                    }), SYNO.SDS.JSLoad.RemoveJSSatusByAppName(t)
                })
            }
        })
    }
}), Ext.ns("SYNO.SDS.PkgManApp.Utils.Utils"), SYNO.SDS.PkgManApp.Utils.Utils = {
    mode: {
        open: "open",
        more: "more"
    },
    localizeMsg: function(t, e, i) {
        var a, n, s;
        return (n = (t = t.replace(/[\r\n]+/g, "")).split(":")).length < 2 ? t : (a = n.join(":"), s = this.getFirstDsmAppName(i), n[1] = SYNO.SDS.UIString.GetLocalizedString(a, s), !e || "" === e || n[1] && n[1] !== a ? (n.shift(), String.format.apply(String, n)) : e)
    },
    localizeArrMsg: function(t, e, i) {
        var a = [];
        Ext.isArray(t) || (t = [t]);
        for (var n = 0; n < t.length; n++) Ext.isString(t[n]) ? a.push(SYNO.SDS.UIString.GetLocalizedString(t[n], i)) : a.push(t[n]);
        var s = String.format.apply(String, a);
        return e ? Ext.util.Format.stripTags(s) : s
    },
    localizeWorkerMsg: function(t) {
        var e = "";
        return Ext.isArray(t) ? (Ext.each(t, function(t) {
            var i = Ext.isObject(t) ? function(t) {
                var e = Ext.isString(t.message) ? t.message : "",
                    i = Ext.isString(t.message_i18n) ? t.message_i18n.split(":", 3) : [],
                    a = Ext.isArray(t.args) ? t.args : [];
                if (2 === i.length) a.unshift(_T(i[0], i[1]));
                else {
                    if (3 !== i.length) return e;
                    a.unshift(_TT(i[0], i[1], i[2]))
                }
                return String.format.apply(String, a) || e
            }(t) : "";
            Ext.isEmpty(i) || (e += Ext.isEmpty(e) ? i : "<br>" + i)
        }), e) : ""
    },
    getFirstDsmAppName: function(t) {
        var e;
        if (Ext.isArray(t)) {
            if (t.length > 0) return t[0]
        } else {
            if (!Ext.isString(t)) return "";
            if ((e = t.split(" ")).length > 0) return e[0]
        }
    },
    tsort: function(t) {
        var e = {},
            i = [],
            a = {},
            n = function(t) {
                this.id = t, this.afters = []
            };
        Ext.each(t, function(t) {
            var i = t[0],
                a = t[1];
            e[i] || (e[i] = new n(i)), e[a] || (e[a] = new n(a)), e[i].afters.push(a)
        });
        var s = function t(n, s) {
            var r = e[n],
                o = r.id;
            a[n] || (Ext.isArray(s) || (s = []), s.push(o), a[n] = !0, Ext.each(r.afters, function(e) {
                s.indexOf(e) >= 0 ? SYNO.Debug("cycle: " + e + " is in " + o) : t(e.toString(), SYNO.Util.copy(s))
            }), i.unshift(o))
        };
        for (var r in e) e.hasOwnProperty(r) && s(r, e[r]);
        return i
    },
    getWebAPIErr: function(t, e, i, a, n) {
        if (!t) {
            if (e && e.code < 400) return SYNO.API.CheckResponse(t, e, i);
            var s = e;
            e.code && Ext.isObject(e.errors) && (s = e.errors);
            var r = s.message && "" !== s.message || s.worker_message && "" !== s.worker_message;
            switch (e.code) {
                case 4500:
                case 4501:
                    return n || _T("pkgmgr", "system_error") + " " + _T("pkgmgr", "contact_support_or_try_again");
                case 4502:
                    return _T("pkgmgr", "pkgmgr_space_not_ready");
                case 4503:
                    return _T("error", "volume_creating");
                case 4504:
                    return _T("pkgmgr", "error_sys_no_space");
                case 4505:
                    return _T("error", "no_external_devices");
                case 4507:
                    switch (s.action) {
                        case "stop":
                            return String.format(_T("pkgmgr", "pkg_given_operation_timeout"), _T("pkgmgr", "pkgmgr_pkg_stop"));
                        default:
                            return s.action
                    }
                    case 4508:
                        return String.format(_T("pkgmgr", "verify_pkg_fail"), s.packageName, _T("pkgmgr", "contact_support_or_try_again"));
                    case 4520:
                        return _T("error", "error_space_not_enough");
                    case 4521:
                        return _T("pkgmgr", "pkgmgr_file_not_package") + " " + _T("pkgmgr", "contact_developer");
                    case 4522:
                        return _T("pkgmgr", "broken_package");
                    case 4523:
                        return String.format(_T("pkgmgr", "pkgmgr_pkg_required_newer_version"), s.firmware);
                    case 4524:
                        return String.format(_T("pkgmgr", "conflict_packages"), s.packages);
                    case 4525:
                    case 4526:
                        break;
                    case 4527:
                        return String.format(_T("pkgmgr", "port_conflict"), s.port);
                    case 4528:
                        return String.format(_T("pkgmgr", "pkgmgr_pkg_not_support_platform"), _D("product"));
                    case 4529:
                        return _T("pkgmgr", "pkgmgr_pkg_cannot_upgrade");
                    case 4530:
                        return _T("pkgmgr", "error_occupied");
                    case 4536:
                        return -1 != s.require_os.search("Surveillance") ? _T("pkgmgr", "pkgmgr_pkg_os_require_surveillance") : String.format(_T("pkgmgr", "pkgmgr_pkg_os_not_support"), s.current_os, s.require_os);
                    case 4537:
                        return String.format(_T("pkgmgr", "pkgmgr_pkg_required_older_version"), s.firmware);
                    case 4538:
                        return String.format(_T("pkgmgr", "pkgmgr_pkg_required_newer_version"), s.firmware);
                    case 4539:
                        return String.format(_T("pkgmgr", "pkgmgr_worker_violation"), '<a href="https://sy.to/zuoui" target="_blank">', "</a>");
                    case 4540:
                        return _T("pkgmgr", "pkgmgr_file_install_failed");
                    case 4541:
                        return _T("pkgmgr", "upgrade_fail");
                    case 4543:
                        return _T("pkgmgr", "pkgmgr_file_not_package");
                    case 4544:
                        return _T("pkgmgr", "pkgmgr_pkg_install_already");
                    case 4545:
                        return _T("pkgmgr", "pkgmgr_pkg_not_available");
                    case 4546:
                        break;
                    case 4547:
                    case 4552:
                        return a ? String.format(_T("pkgmgr", "error_upgrade_dep_packages_with_name"), s.packages, a) : String.format(_T("pkgmgr", "error_upgrade_dep_packages"), s.packages);
                    case 4548:
                        return _T("pkgmgr", "install_version_less_than_limit");
                    case 4549:
                        return _T("pkgmgr", "depend_cycle");
                    case 4550:
                        return String.format(_T("pkgmgr", "install_pkg_fail"), s.packageName, r ? "" : _T("pkgmgr", "contact_support_or_try_again"));
                    case 4551:
                        return String.format(_T("pkgmgr", "repair_pkg_fail"), s.packageName, r ? "" : _T("pkgmgr", "contact_support_or_try_again"));
                    case 4560:
                        return _T("pkgmgr", "pkgmgr_pkg_uninstall_failed");
                    case 4562:
                        break;
                    case 4580:
                        return _T("pkgmgr", "pkgmgr_pkg_start_failed");
                    case 4581:
                        return _T("pkgmgr", "pkgmgr_pkg_stop_failed");
                    case 4582:
                    case 4583:
                        break;
                    case 4584:
                        if (!Ext.isEmpty(s.unstart_packages)) return _T("pkgmgr", "start_depend_unstart") + "<br>" + s.unstart_packages
            }
            return n || SYNO.API.getErrorString(e.code) || String.format("{0} {1}", _T("pkgmgr", "system_error"), _T("pkgmgr", "contact_support_or_try_again"))
        }
    },
    _initWinWrappers: function(t) {
        this._getOwner = function() {
            return this.owner ? this.owner : t && t.owner ? this.owner = t.owner : this === SYNO.SDS.PkgManApp.Window ? SYNO.SDS.PkgManApp.Window : this.owner = SYNO.SDS.PkgManApp.Window
        }, Ext.each(["_getAbsoluteURL", "_getEllipsis"], function(t) {
            this[t] = function() {
                var e = SYNO.SDS.PkgManApp.Window;
                return e[t].apply(e, arguments)
            }
        }, this), Ext.each(["_getCurId", "_getHistoryInfo"], function(t) {
            this[t] = function() {
                return SYNO.SDS.PkgManApp.Util[t].apply(SYNO.SDS.PkgManApp.Window, arguments)
            }
        }, this), Ext.iterate(SYNO.SDS.PkgManApp.Action, function(t, e) {
            SYNO.SDS.PkgManApp.Action.hasOwnProperty(t) && (this[t] = function() {
                var t = SYNO.SDS.PkgManApp.Window;
                return e.apply(t, arguments)
            })
        }, this), Ext.iterate(SYNO.SDS.PkgManApp.ActionUtils, function(t, e) {
            SYNO.SDS.PkgManApp.ActionUtils.hasOwnProperty(t) && (this instanceof SYNO.SDS.PkgManApp.UninstallWizardDialog || this instanceof SYNO.SDS.PkgManApp.WizardDialog ? this[t] = e.createDelegate(this) : this[t] = function() {
                var t = SYNO.SDS.PkgManApp.Window;
                return e.apply(t, arguments)
            })
        }, this)
    },
    _getCurId: function() {
        return SYNO.SDS.PkgManApp.Window.getPanelScope("SYNO.SDS.PkgManApp.PathHistoryMgr").getCurId()
    },
    _getHistoryInfo: function() {
        return SYNO.SDS.PkgManApp.Window.getPanelScope("SYNO.SDS.PkgManApp.PathHistoryMgr").getHistoryInfo()
    },
    encodedMsg: function(t, e) {
        var i = t;
        return Ext.isDefined(t) ? e && (i = Ext.util.Format.stripTags(i)) : i = "", Ext.util.Format.htmlEncode(i)
    },
    isOnlyInstStatus: function(t) {
        var e = SYNO.SDS.PkgManApp.Window.getStore("installed").getById(t.id);
        return (!e || !SYNO.SDS.PkgManApp.Utils.Utils.isBrokenStatus(e.data)) && ((!e || !e.data.available_operation || !e.data.available_operation.upgrade && !e.data.available_operation.forcereplaced) && !!e)
    },
    isBrokenStatus: function(t) {
        if (Ext.isEmpty(t)) return !1;
        var e = t;
        return Ext.isObject(t) && (e = t.statusOrigin || t.status, Ext.isObject(t.additional) && (e = t.status || t.additional.status)), "broken" === e || "version_limit" === e || "non_support" === e || "builtin" === e || "license_error" === e || "broken_by_other" === e || "stopped_by_dep_limit" === e || "start_failed" === e
    },
    getBrokenStatus: function(t) {
        if (Ext.isEmpty(t)) return !1;
        var e = t;
        return Ext.isObject(t) && (e = t.status, Ext.isObject(t.additional) && (e = t.status || t.additional.status)), e
    },
    getBrokenStr: function(t) {
        return _T("pkgmgr", "repair")
    },
    isBuyable: function(t) {
        return t && 0 !== t.type && t.price
    },
    getValue: function(t, e) {
        return Ext.isObject(t) ? t.additional && void 0 !== t.additional[e] ? t.additional[e] : void 0 !== t[e] ? t[e] : "" : t || ""
    },
    setGlobalValue: function() {
        SYNO.SDS.PkgManApp.isRunningPkgForeground = !0
    },
    cleanGlobalValue: function() {
        SYNO.SDS.PkgManApp.isRunningPkgForeground = void 0
    },
    GetFeasibilityMsgList: function(t) {
        var e = "";
        return Ext.each(t, function(t) {
            e += String.format("<li>{0}</li>", SYNO.SDS.Utils.GetFeasibilityCheckMsg(t))
        }), String.format("<ul>{0}</ul>", e)
    },
    AppLaunch: function(t, e) {
        var i = SYNO.SDS.Config.FnMap[t];
        Ext.isEmpty(i) || ("url" === (i = i.config).type || "standalone" === i.type || "legacy" === i.type && "url" === i.urlDefMode ? SYNO.SDS.WindowLaunch(i.jsID, e) : SYNO.SDS.AppLaunch(i.jsID, e))
    },
    GetAppNameToOpen: function(t) {
        return t.dsm_app_launch_name ? t.dsm_app_launch_name : t.dsm_apps ? Ext.isArray(t.dsm_apps) ? t.dsm_apps[0] : t.dsm_apps.split(" ")[0] : void 0
    },
    IsPkgOpenable: function(t) {
        if ("running" !== t.status) return !1;
        var e = this.GetAppNameToOpen(t);
        return e ? SYNO.SDS.StatusNotifier.isAppLaunchable(e) && SYNO.SDS.StatusNotifier.isAppEnabled(e) : !(!t.url || !t.url[0])
    },
    OpenPkgApp: function(t) {
        var e = this.GetAppNameToOpen(t);
        e ? t.dsm_app_page ? this.AppLaunch(e, {
            fn: t.dsm_app_page
        }) : this.AppLaunch(e) : t.url && t.url[0] && window.open(t.url[0], "_blank", "")
    },
    unquote: function(t) {
        return t.replace(/^"(.*)"$/, "$1")
    },
    IsAutoUpdatable: function(t) {
        return !!t.silent_upgrade && ("version_limit" !== t.status || (!t.limit_type || "non" !== t.limit_type && "system" !== t.limit_type))
    }
}, SYNO.SDS.PkgManApp.ModalWindow = Ext.extend(SYNO.SDS.ModalWindow, {
    _getAbsoluteURL: function() {
        return this._getOwner()._getAbsoluteURL.apply(this._getOwner(), arguments)
    },
    _getOwner: function() {
        return this.owner ? this.owner : this === SYNO.SDS.PkgManApp.Window ? SYNO.SDS.PkgManApp.Window : this.owner = SYNO.SDS.PkgManApp.Window
    }
}), Ext.ns("SYNO.SDS.PkgManApp"), SYNO.SDS.PkgManApp.SettingDialog = Ext.extend(SYNO.SDS.ModalWindow, {
    constructor: function(t) {
        SYNO.SDS.PkgManApp.SettingDialog.superclass.constructor.call(this, Ext.apply(t, {
            dsmStyle: "v5",
            title: _T("download", "download_table_heading_setting"),
            width: 700,
            height: 580,
            layout: "fit",
            border: !1,
            items: [{
                xtype: "syno_tabpanel",
                plain: !0,
                itemId: "tab",
                activeTab: _S("is_admin") ? "general" : "autoupdate_tab",
                deferredRender: !1,
                items: this.createTabItems()
            }],
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: this.close
            }, {
                text: _T("common", "ok"),
                scope: this,
                btnStyle: "blue",
                handler: this.saveHandler
            }],
            keys: [{
                key: [10, 13],
                fn: this.saveHandler,
                scope: this
            }, {
                key: 27,
                fn: this.close,
                scope: this
            }],
            listeners: {
                scope: this,
                afterlayout: {
                    fn: this.onAfterLayout,
                    single: !0
                },
                beforeclose: this.onCloseHandler
            }
        })), this.defineBehaviors()
    },
    defineBehaviors: function() {
        this.channelForm = this.get("tab").get("channel"), this.generalForm = this.get("tab").get("general"), this.feedPanel = this.get("tab").get("feed_tab")
    },
    createTabItems: function() {
        var t = [],
            e = new Ext.data.SimpleStore({
                fields: ["mount_point", "display", "size_free", "description"],
                data: []
            });
        return t.push({
            xtype: "syno_formpanel",
            itemId: "general",
            border: !1,
            trackResetOnLoad: !0,
            title: _T("common", "general"),
            items: [this.vol_fieldset = new SYNO.ux.FieldSet({
                xtype: "syno_fieldset",
                title: _T("pkgmgr", "default_vol"),
                hidden: !0,
                items: [{
                    xtype: "syno_displayfield",
                    value: _T("pkgmgr", "default_vol_desc")
                }, {
                    xtype: "syno_message_combobox",
                    itemId: "default_vol",
                    name: "default_vol",
                    fieldLabel: _T("pkgmgr", "default_vol"),
                    store: e,
                    displayField: "display",
                    descriptionField: "description",
                    valueField: "mount_point",
                    grow: !0,
                    width: 300,
                    indent: 0,
                    tpl: new Ext.XTemplate('<tpl for=".">', "<tpl if=\"mount_point === 'no_default_vol'\">", '<div class="x-combo-list-item" style="height: 26px">', "</tpl>", "<tpl if=\"mount_point !== 'no_default_vol'\">", '<div ext:qtip="{description:htmlEncode}" class="x-combo-list-item" style="height: 52px">', "</tpl>", '<div class="sds-combo-list-item-name">{display}</div>', '<div class="sds-combo-list-item-description">{description}</div>', "</div>", "</tpl>"),
                    listeners: {
                        scope: this,
                        select: function(t) {
                            var e = t.ownerCt.ownerCt.form.findField("volume_status_text");
                            e.hide();
                            var i = t.getStore(),
                                a = i.findExact("mount_point", t.getValue());
                            0 !== a && 209715200 >= parseInt(i.getAt(a).get("size_free"), 10) ? (e.setValue('<font color="red">' + _T("status", "status_no_space") + "</font>"), e.show()) : t.isDirty() || Ext.isEmpty(e.originalValue) || (e.setValue(e.originalValue), e.show())
                        }
                    }
                }, {
                    fieldLabel: "",
                    labelStyle: "color:red;width:180px",
                    xtype: "syno_displayfield",
                    htmlEncode: !1,
                    name: "volume_status_text",
                    value: ""
                }]
            }), {
                xtype: "syno_fieldset",
                title: _T("tree", "leaf_notification"),
                items: [{
                    xtype: "syno_displayfield",
                    value: _T("pkgmgr", "notification_desc")
                }, {
                    xtype: "syno_checkbox",
                    name: "enable_email",
                    boxLabel: _T("autoblock", "autoblock_notify")
                }, {
                    xtype: "syno_checkbox",
                    name: "enable_dsm",
                    boxLabel: _T("pkgmgr", "desktop_notification")
                }]
            }]
        }), t.push({
            xtype: "syno_formpanel",
            itemId: "channel",
            border: !1,
            trackResetOnLoad: !0,
            title: _T("pkgmgr", "update_channel"),
            items: [{
                xtype: "syno_displayfield",
                value: _T("pkgmgr", "update_channel_desc"),
                htmlEncode: !1
            }, {
                xtype: "syno_checkbox",
                boxLabel: _T("pkgmgr", "update_channel_beta_yes"),
                name: "update_channel"
            }]
        }), t.push(this.createPackageUpdatePanel()), SYNO.SDS.Utils.isInAliDSM() || t.push(this.createFeedGridPanel()), t
    },
    createFeedStore: function() {
        return new Ext.data.Store({
            autoLoad: !!_S("is_admin"),
            autoDestroy: !0,
            remoteSort: !1,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.Core.Package.Feed",
                method: "list",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "items",
                id: "feed"
            }, [{
                name: "name"
            }, {
                name: "feed"
            }])
        })
    },
    colRender: function(t, e, i, a, n, s) {
        var r = Ext.util.Format.htmlEncode(t);
        return e.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(r) + '"', r
    },
    onDeleteHandler: function(t, e, i) {
        var a = t.ownerCt.ownerCt.getSelectionModel().getSelections();
        a.length < 1 || this.getMsgBox().confirm(_T("tree", "leaf_packagemanage"), _T("common", "remove_cfrmrmv"), function(t) {
            if ("yes" == t) {
                for (var e = [], n = 0; n < a.length; n++) e.push(a[n].get(i));
                this.setStatusBusy({
                    text: _T("filetable", "filetable_deleting")
                });
                var s = {
                    list: Ext.encode(e)
                };
                this.sendWebAPI({
                    api: "SYNO.Core.Package.Feed",
                    method: "delete",
                    params: s,
                    callback: this.onDeleteDone,
                    version: 1,
                    scope: this
                })
            }
        }, this)
    },
    createFeedGridPanel: function() {
        this.feedstore = this.createFeedStore();
        var t = {
            title: _T("pkgmgr", "feed_server"),
            itemId: "feed_tab",
            store: this.feedstore,
            autoExpandColumn: "feed",
            enableColumnMove: !1,
            enableHdMenu: !1,
            stripeRows: !0,
            colModel: new Ext.grid.ColumnModel({
                columns: [{
                    header: _T("common", "name"),
                    dataIndex: "name",
                    width: 100,
                    renderer: this.colRender
                }, {
                    header: _T("pkgmgr", "feed"),
                    dataIndex: "feed",
                    id: "feed",
                    renderer: this.colRender
                }]
            }),
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: !1,
                listeners: {
                    scope: this,
                    buffer: 100,
                    selectionchange: this.updateBtn
                }
            }),
            tbar: {
                items: [{
                    xtype: "syno_button",
                    text: _T("common", "add"),
                    itemId: "add",
                    scope: this,
                    handler: function() {
                        this.onEditHandler()
                    }
                }, {
                    xtype: "syno_button",
                    text: _T("common", "alt_edit"),
                    itemId: "edit",
                    disabled: !0,
                    scope: this,
                    handler: function() {
                        this.onEditHandler(this.feedPanel.getSelectionModel().getSelected())
                    }
                }, {
                    xtype: "syno_button",
                    text: _T("common", "delete"),
                    itemId: "delete",
                    disabled: !0,
                    scope: this,
                    handler: function(t) {
                        this.onDeleteHandler(t, "feed", "feed")
                    }
                }]
            }
        };
        return new SYNO.ux.GridPanel(t)
    },
    onEditHandler: function(t) {
        new SYNO.SDS.PkgManApp.FeedDialog({
            owner: this
        }, {
            jsConfig: this.jsConfig,
            blEdit: !!t,
            success: function() {
                this.feedstore.reload()
            },
            scope: this
        }).load(t)
    },
    updateBtn: function(t) {
        if (!this.isDestroyed) {
            var e = t.grid,
                i = e.getTopToolbar(),
                a = e.getSelectionModel().getSelections();
            "feed_tab" === t.grid.itemId && (i.getComponent("delete").setDisabled(0 === a.length), i.getComponent("edit").setDisabled(1 !== a.length))
        }
    },
    onSetVolField: function(t) {
        var e = this.generalForm.form;
        if (!t.volume_list || 1 >= t.volume_list.length || !t.volume_list && !t.volume_status) this.vol_fieldset.hide();
        else {
            this.vol_fieldset.show();
            var i = e.findField("default_vol").store,
                a = [
                    ["no_default_vol", _T("pkgmgr", "no_default_vol"), void 0, ""]
                ];
            if (Ext.each(t.volume_list, function(t, e, i) {
                    a.push([t.mount_point, t.display, t.size_free, Ext.util.Format.htmlEncode(t.desc)])
                }, this), i.loadData(a), Ext.isEmpty(t.default_vol)) e.setValues({
                default_vol: "no_default_vol"
            });
            else if (e.setValues({
                    default_vol: t.default_vol
                }), !Ext.isEmpty(t.volume_status)) {
                var n = _T("volume", "volume_status_crashed");
                "no_space" === t.volume_status && (n = _T("status", "status_no_space")), e.setValues({
                    volume_status_text: '<font class="red-status">' + n + "</font>"
                })
            }
        }
    },
    onAfterLayout: function() {
        this.setStatusBusy(), this.sendWebAPI({
            api: "SYNO.Core.Package.Setting",
            method: "get",
            version: 1,
            callback: function(t, e) {
                t && e ? (this.generalForm.getForm().setValues(e), this.channelForm.getForm().setValues(e), this.updateAllForm.getForm().setValues(e), this.updateAllForm.getForm().setValues({
                    autoupdateall: e.autoupdateall ? "autoupdateall_all" : "autoupdateall_some"
                }), this.mailset = e.mailset, this.onSetVolField(e), this.generalForm.updateScroller(), this.clearStatusBusy()) : this.getMsgBox().alert(this.title, String.format("{0} {1}", _T("pkgmgr", "system_error"), _T("pkgmgr", "contact_support_or_try_again")))
            },
            scope: this
        }), this.tabPanel = this.get("tab"), _S("is_admin") || (this.tabPanel.hideTabStripItem("general"), this.tabPanel.hideTabStripItem("channel"), this.tabPanel.hideTabStripItem("feed_tab"))
    },
    saveHandler: function() {
        var t = this.generalForm.getForm();
        this.mailset || !t.findField("enable_email").getValue() ? this.isAnyFormDirty() ? this.onSendSaveHandler() : this.doClose() : this.getMsgBox().show({
            title: this.title,
            msg: _T("pkgmgr", "pkg_email_set_err"),
            buttons: Ext.MessageBox.OKCANCEL,
            fn: function(t) {
                "ok" == t && SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                    fn: "SYNO.SDS.AdminCenter.Notification.Main"
                })
            },
            scope: this
        })
    },
    onSendSaveHandler: function() {
        var t = this.channelForm.getForm(),
            e = this.generalForm.getForm(),
            i = this.updateAllForm.getForm(),
            a = [];
        this.setStatusBusy({
            text: _T("common", "saving")
        });
        var n = i.findField("autoupdateall").getValue(),
            s = i.findField("enable_autoupdate").getValue(),
            r = {
                update_channel: t.findField("update_channel").getValue() ? "beta" : "stable",
                enable_email: e.findField("enable_email").getValue(),
                enable_dsm: e.findField("enable_dsm").getValue(),
                enable_autoupdate: s,
                autoupdateall: n
            };
        if (s && !n) {
            var o = this.updateAllGrid.getStore().getModifiedRecords();
            (o && o.length || i.findField("autoupdateall").isDirty()) && (this.updateAllGrid.getStore().each(function(t) {
                t.data.autoupdate && a.push(t.id)
            }), r.packages = Ext.encode(a))
        }
        var l = e.findField("default_vol");
        l.isDirty() && Ext.apply(r, {
            default_vol: l.getValue()
        }), this.sendWebAPI({
            api: "SYNO.Core.Package.Setting",
            method: "set",
            version: 1,
            timeout: 36e5,
            params: r,
            callback: function(t, e) {
                if (this.isUpdateChannelSwitched() && ("beta" !== r.update_channel || SYNO.SDS.UserSettings.getProperty("SYNO.SDS.PkgManApp.Instance", "agreed_beta") || SYNO.SDS.UserSettings.setProperty("SYNO.SDS.PkgManApp.Instance", "agreed_beta", !0), this.setForceReload()), t) SYNO.SDS.PkgManApp.Window.loadCfg(function() {
                    this.clearStatusBusy(), this.doClose()
                }.createDelegate(this));
                else {
                    if (this.clearStatusBusy(), !e || !e.code) return void this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), String.format("{0} {1}", _T("pkgmgr", "system_error"), _T("pkgmgr", "contact_support_or_try_again")));
                    this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), SYNO.API.getErrorString(e.code))
                }
            },
            scope: this
        })
    },
    onCloseHandler: function() {
        var t = this;
        return !this.isAnyFormDirty() || (this.confirmLostChangePromise({
            save: function() {
                t.saveHandler()
            },
            cancel: Ext.emptyFn,
            dontSave: function() {
                t.doClose()
            }
        }, this), !1)
    },
    isUpdateChannelSwitched: function() {
        return this.channelForm.getForm().findField("update_channel").isDirty()
    },
    setForceReload: function() {
        this.owner._onRefresh && this.owner._onRefresh()
    },
    isAnyFormDirty: function() {
        var t = this.getAllForms(),
            e = !1;
        return !!this.updateAllForm.getForm().isDirty() || (!Ext.isEmpty(this.updateAllGrid.getStore().getModifiedRecords()) || (Ext.each(t, function(t, i, a) {
            if (t.isDirty()) return e = !0, !1
        }, this), e))
    },
    getAllForms: function() {
        var t = [];
        return this.get("tab").items.each(function(e, i, a) {
            if (e.getForm) {
                var n = e.getForm();
                t.push(n)
            }
        }, this), t
    },
    onDeleteDone: function(t, e, i, a) {
        this.clearStatusBusy(), t ? "SYNO.Core.Package.Feed" === a.params.api && this.feedstore.reload() : e && Ext.isDefined(e.code) ? this.setStatusError({
            text: SYNO.API.getErrorString(e.code)
        }) : this.setStatusError()
    },
    getUpdateStore: function() {
        return this.update_store ? this.update_store : (this.update_store = new SYNO.API.Store({
            autoLoad: !0,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.Core.Package",
                method: "list",
                version: 1,
                listeners: {
                    scope: this,
                    beforeload: function(t, e) {
                        var i = t.activeRequest.read;
                        i && Ext.Ajax.abort(i)
                    }
                }
            }),
            sortInfo: {
                field: "name",
                direction: "ASC"
            },
            baseParams: {
                additional: ["silent_upgrade", "autoupdate", "status"]
            },
            reader: new Ext.data.JsonReader({
                root: "packages",
                id: "id"
            }, [{
                name: "id"
            }, {
                name: "name"
            }, {
                name: "silent_upgrade",
                mapping: "additional.silent_upgrade"
            }, {
                name: "autoupdate",
                mapping: "additional.autoupdate"
            }, {
                name: "status",
                mapping: "additional.status"
            }, {
                name: "limit_type",
                mapping: "additional.limit_type"
            }])
        }), this.update_store)
    },
    createPackageUpdatePanel: function() {
        this.updateAllColumn = new SYNO.ux.EnableColumn({
            bindRowClick: !0,
            dataIndex: "autoupdate",
            align: "center",
            width: 40,
            sortable: !1,
            hideable: !1,
            menuDisabled: !0,
            enableFastSelectAll: !0,
            isIgnore: function(t, e) {
                return !SYNO.SDS.PkgManApp.Utils.Utils.IsAutoUpdatable(e.data)
            },
            renderer: function(t, e, i) {
                return SYNO.SDS.PkgManApp.Utils.Utils.IsAutoUpdatable(i.data) || (t = "disabled", e.css = "x-item-disabled"), String.format('<div class="syno-ux-grid-enable-column-{0}">&nbsp;</div>', "disabled" === t ? "disabled" : t ? "checked" : "unchecked")
            }
        });
        var t = {
            loadMask: !0,
            disabled: !0,
            cls: "syno-pkg-gridpanel",
            margins: {
                left: 30,
                right: 30
            },
            region: "center",
            itemId: "grid",
            store: this.getUpdateStore(),
            autoExpandColumn: "name",
            enableColumnMove: !1,
            enableHdMenu: !1,
            stripeRows: !0,
            plugins: [this.updateAllColumn],
            colModel: new Ext.grid.ColumnModel({
                columns: [this.updateAllColumn, {
                    id: "name",
                    header: _T("common", "name"),
                    dataIndex: "name",
                    width: 100,
                    renderer: function(t, e, i, a, n, s) {
                        var r = Ext.util.Format.htmlEncode(t);
                        return e.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(r) + '"', r
                    }
                }]
            })
        };
        return this.updateAllGrid = new SYNO.ux.GridPanel(t), {
            title: _T("pkgmgr", "auto_update"),
            itemId: "autoupdate_tab",
            layout: "border",
            items: [this.updateAllForm = new SYNO.ux.FormPanel({
                autoHeight: !0,
                region: "north",
                xtype: "syno_formpanel",
                trackResetOnLoad: !0,
                autoFlexcroll: !1,
                items: [{
                    xtype: "syno_checkbox",
                    boxLabel: _T("pkgmgr", "auto_update_enable"),
                    name: "enable_autoupdate",
                    listeners: {
                        scope: this,
                        check: function(t, e) {
                            var i = this.updateAllForm.getForm();
                            i.findField("autoupdateall_some").setDisabled(!e), i.findField("autoupdateall_all").setDisabled(!e), e ? i.findField("autoupdateall_some").getValue() && (this.updateAllGrid.setDisabled(!1), this.updateAllNote.setDisabled(!1)) : (this.updateAllGrid.setDisabled(!e), this.updateAllNote.setDisabled(!e))
                        }
                    }
                }, {
                    xtype: "syno_displayfield",
                    value: String.format(_T("pkgmgr", "auto_update_desc"), _D("product")),
                    indent: 1
                }, {
                    dataIndex: "autoupdateall_all",
                    disabled: !0,
                    xtype: "syno_radio",
                    boxLabel: _T("pkgmgr", "auto_update_all_packages"),
                    checked: !0,
                    name: "autoupdateall",
                    hideLabel: !0,
                    inputValue: "autoupdateall_all",
                    indent: 1
                }, {
                    dataIndex: "autoupdateall_some",
                    disabled: !0,
                    xtype: "syno_radio",
                    boxLabel: _T("pkgmgr", "auto_update_some_packages"),
                    name: "autoupdateall",
                    hideLabel: !0,
                    inputValue: "autoupdateall_some",
                    indent: 1,
                    listeners: {
                        scope: this,
                        check: function(t, e) {
                            e && 0 === this.update_store.getTotalCount() && this.update_store.load();
                            var i = t.disabled || !e;
                            this.updateAllGrid.setDisabled(i), this.updateAllNote.setDisabled(i)
                        }
                    }
                }]
            }), this.updateAllGrid, this.updateAllNote = new SYNO.ux.DisplayField({
                region: "south",
                xtype: "syno_displayfield",
                indent: 1,
                html: String.format('<span class="syno-pkg-note">{0}</span>: {1}', _T("common", "note"), _T("pkgmgr", "auto_update_note_desc") || "Grayed-out packages do not support auto updates.")
            })]
        }
    }
}), Ext.define("SYNO.SDS.PkgManApp.FeedDialog", {
    extend: SYNO.SDS.ModalWindow,
    constructor: function(t, e) {
        Ext.apply(this, e || {}), this.owner = t.owner;
        var i = this.fillConfig(t);
        this.callParent([i]), this.defineBehaviors()
    },
    fillConfig: function(t) {
        var e = {
            owner: t.owner,
            width: 550,
            height: 210,
            minWidth: 100,
            minHeight: 120,
            collapsible: !1,
            constrainHeader: !0,
            monitorResize: !0,
            title: this.blEdit ? _T("common", "alt_edit") : _T("common", "add"),
            layout: "fit",
            items: [this.initFormConfig()],
            buttons: [{
                text: _T("common", "cancel"),
                handler: this.onCloseHandler,
                scope: this
            }, {
                text: _T("common", "ok"),
                btnStyle: "blue",
                handler: this.onApplyHandler,
                scope: this
            }],
            keys: [{
                key: [10, 13],
                fn: this.onApplyHandler,
                scope: this
            }, {
                key: 27,
                fn: this.onCloseHandler,
                scope: this
            }]
        };
        return Ext.apply(e, t), e
    },
    initFormConfig: function() {
        return {
            xtype: "syno_formpanel",
            itemId: "formpanel",
            labelAlign: "left",
            trackResetOnLoad: !0,
            waitMsgTarget: !0,
            border: !1,
            labelWidth: 150,
            items: [{
                xtype: "syno_textfield",
                itemId: "name",
                fieldLabel: _T("common", "name"),
                name: "name",
                width: 320
            }, {
                xtype: "syno_textfield",
                itemId: "feed",
                allowBlank: !1,
                fieldLabel: _T("pkgmgr", "feed"),
                name: "feed",
                width: 320
            }]
        }
    },
    defineBehaviors: function() {
        this.form = this.get("formpanel").form
    },
    onCloseHandler: function() {
        this.close()
    },
    onApplyHandler: function() {
        var t = this.form;
        if (t.isValid())
            if (t.isDirty()) {
                var e = {
                    name: Ext.util.Format.trim(t.findField("name").getValue()),
                    feed: Ext.util.Format.trim(t.findField("feed").getValue())
                };
                this.blEdit && Ext.apply(e, {
                    orifeed: t.findField("feed").originalValue
                });
                var i = {
                    list: Ext.encode(e)
                };
                this.setStatusBusy({
                    text: _T("common", "saving")
                }), this.sendWebAPI({
                    api: "SYNO.Core.Package.Feed",
                    params: i,
                    version: 1,
                    method: this.blEdit ? "set" : "add",
                    callback: this.SaveDone,
                    scope: this
                })
            } else this.onCloseHandler()
    },
    load: function(t) {
        t && this.form.loadRecord(t), this.show()
    },
    SaveDone: function(t, e) {
        if (this.clearStatusBusy(), t) this.success.call(this.scope), SYNO.SDS.PkgManApp.Window.loadCfg(), this.close();
        else if (e && Ext.isDefined(e.code)) {
            if (this.setStatusError({
                    text: SYNO.API.getErrorString(e.code)
                }), e.errors && e.errors.fields) {
                var i = !0,
                    a = !1,
                    n = void 0;
                try {
                    for (var s, r = e.errors.fields[Symbol.iterator](); !(i = (s = r.next()).done); i = !0) {
                        var o = s.value;
                        "feed" === o ? this.form.findField("feed").markInvalid() : "name" === o && this.form.findField("name").markInvalid()
                    }
                } catch (t) {
                    a = !0, n = t
                } finally {
                    try {
                        i || null == r.return || r.return()
                    } finally {
                        if (a) throw n
                    }
                }
            }
        } else this.setStatusError({
            text: _T("error", "save"),
            clear: !0
        })
    },
    setStatusBusy: function() {
        this.getFooterToolbar().disable(), this.getKeyMap().disable(), this.callParent(arguments)
    },
    clearStatusBusy: function() {
        this.callParent(arguments), this.getFooterToolbar().enable(), this.getKeyMap().enable()
    }
}), Ext.namespace("SYNO.SDS.PkgManApp"), Ext.define("SYNO.SDS.PkgManApp.WizardDialog", {
    extend: "SYNO.SDS.Wizard.ModalWindow",
    enumInstallMode: Object.freeze({
        install: 1,
        upgrade: 2,
        repair: 4
    }),
    constructor: function(t, e) {
        SYNO.SDS.PkgManApp.Utils.Utils._initWinWrappers.call(this, t), this.upload_task_id = null, this.uploadFilename = null, this.isFinished = !1, this.mode = t.mode, this.orimode = this.mode, this.type = t.type, this.check_codesign = !0;
        var i = [];
        if (e || i.push(this.getBasicPanel({
                itemId: "uploadStep",
                nextId: "licenceStep"
            })), e && !e.licence || i.push(this.getLicencePanelConfig({
                itemId: "licenceStep",
                nextId: "volumeStep"
            })), i.push(this.getVolumePanelConfig({
                itemId: "volumeStep",
                nextId: "applyStep"
            })), i.push(this.getInfoPanelConfig({
                itemId: "applyStep",
                nextId: null
            })), SYNO.SDS.PkgManApp.WizardDialog.superclass.constructor.call(this, Ext.apply(t, {
                dsmStyle: "v5",
                title: 3 === this.orimode ? _T("pkgmgr", "install_upgrade_title") : this.orimode ? _T("pkgmgr", "pkgmgr_pkg_upgrade") : _T("pkgmgr", "pkgmgr_pkg_install"),
                width: 700,
                height: 500,
                cls: "synopkg-wizard-window",
                steps: i
            })), this.mon(this, "beforeshow", function() {
                SYNO.SDS.PkgManApp.Utils.Utils.setGlobalValue()
            }), Ext.EventManager.on(window, "unload", this.onSyncCleanTmp, this), SYNO.SDS.StatusNotifier.on("logout", this.onSyncCleanTmp, this), this.mon(this, "beforeclose", function() {
                SYNO.SDS.PkgManApp.Action.clearProgress(this.pkgName), this.onAsyncCleanTmp(), SYNO.SDS.PkgManApp.Utils.Utils.cleanGlobalValue()
            }, this), e) {
            var a;
            e.errmsg ? (e && e.dname && (a = e.dname), this._onCheckPKGFail(e, a)) : this.onCheckPKGDone(e, !1)
        } else {
            var n = this.getStep("uploadStep").getForm();
            n.on("actioncomplete", function(t, e) {
                var i = this;
                if (Ext.get(this.id).unmask(), e.success && e.result) {
                    var a = e.result.data,
                        n = SYNO.SDS.PkgManApp.Utils.Utils.getValue(a, "id");
                    this.mode = "non_installed" !== a.additional.status ? 1 : 0, this._applyFeasibilityCheck({
                        type: "install_check",
                        packages: [n]
                    }).then(function(t) {
                        t && i._applyCodesignCheck(a, function(t) {
                            this.check_codesign = t, this.onCheckPKGDone(a, !0)
                        }.createDelegate(i), function() {
                            this.upload_task_id = SYNO.SDS.PkgManApp.Utils.Utils.getValue(a, "task_id"), this.onAsyncCleanTmp()
                        }.createDelegate(i))
                    })
                } else this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), _T("error", "error_unknown"))
            }, this), n.on("actionfailed", function(t, e) {
                this._onCheckPKGFail(e.result)
            }, this)
        }
    },
    onCheckPKGDone: function(t, e) {
        var i = SYNO.SDS.PkgManApp.Utils.Utils;
        this.upload_task_id = i.getValue(t, "task_id"), this.uploadFilename = t.filename, this.pkgName = i.getValue(t, "id"), this.dname = i.getValue(t, "name"), this.pkgVersion = i.getValue(t, "version"), this.desc = i.getValue(t, "description"), this.maintainer = i.getValue(t, "maintainer"), this.pkgDistributor = i.getValue(t, "distributor"), this.pkgLicence = i.getValue(t, "licence"), this.pkgCanRun = !i.getValue(t, "install_reboot") && i.getValue(t, "startable"), this.pkgqinst = t.pkgqinst, this.pkgqinstrec = t.pkgqinstrec, this.break_pkgs = i.getValue(t, "break_pkgs"), this.replace_pkgs = i.getValue(t, "replace_pkgs"), this.install_type = i.getValue(t, "install_type"), this.install_on_cold_storage = i.getValue(t, "install_on_cold_storage"), this.originalStatus = i.getValue(t, "status"), this.dsm_apps = [];
        var a = i.getValue(t, "dsm_apps");
        Ext.isString(a) && (this.dsm_apps = a.split(" ")), this.isUploaed = !0;
        var n = i.getValue(t, "install_pages");
        if (n) {
            if (Ext.isString(n)) try {
                n = Ext.decode(decodeURIComponent(n))
            } catch (t) {
                n = Ext.decode(window.unescape(n))
            }
            if (!Ext.isArray(n)) return void this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), String.format(_T("pkgmgr", "install_pkg_fail"), this.dname, _T("pkgmgr", "contact_developer_or_try_again")), function() {
                this.close()
            }, this);
            var s = this.parseCustomui(n);
            s[s.length - 1].nextId = "applyStep", this.customuiIds = this.appendSteps(s)
        } else this.customuiIds = void 0;
        switch (Ext.isEmpty(SYNO.SDS.PkgManApp.Config.def_void) || (this.installVolume = SYNO.SDS.PkgManApp.Config.def_void), this.blUpgradeOrRepair = !1, this.orimode) {
            case 0:
                this.installMode = this.enumInstallMode.install;
                break;
            case 1:
                this.installMode = i.isBrokenStatus(t) ? this.enumInstallMode.repair : this.enumInstallMode.upgrade, this.blUpgradeOrRepair = !0;
                break;
            default:
                if ("non_installed" == this.originalStatus) {
                    this.installMode = this.enumInstallMode.install;
                    break
                }
                this.installMode = i.isBrokenStatus(t) ? this.enumInstallMode.repair : this.enumInstallMode.upgrade, this.blUpgradeOrRepair = !0
        }
        var r = this.dname || this.pkgName || "";
        r && (r += " - "), this.blUpgradeOrRepair ? this.setTitle(r + _T("pkgmgr", "pkgmgr_pkg_upgrade")) : this.setTitle(r + _T("pkgmgr", "pkgmgr_pkg_install")), Ext.get(this.id).mask(_T("common", "msg_waiting"), "x-mask-loading");
        var o = [{
            api: "SYNO.Core.Package.Setting.Volume",
            method: "get",
            version: 1
        }, {
            api: "SYNO.Core.Storage.Volume",
            method: "list",
            version: 1,
            params: {
                offset: 0,
                limit: -1,
                location: "internal",
                option: this.install_on_cold_storage ? "include_cold_storage" : ""
            }
        }];
        this.sendWebAPI({
            compound: {
                stopwhenerror: !1,
                params: o
            },
            scope: this,
            callback: function(a, n, s, r) {
                if ((Ext.get(this.id).unmask(), !a || n.has_fail) && 1 === SYNO.API.Response.GetFirstErrorIndex(n)) {
                    var o = SYNO.API.Response.GetFirstError(n);
                    return void this.getMsgBox().alert("", SYNO.API.Erros.core[o.code] || _T("common", "commfail"))
                }
                var l = SYNO.API.Response.GetValByAPI(n, "SYNO.Core.Storage.Volume", "list", "volumes"),
                    p = [];
                this.installVolume = SYNO.API.Response.GetValByAPI(n, "SYNO.Core.Package.Setting.Volume", "get", "default_vol"), l && 0 !== l.length && l.forEach(function(t) {
                    t.readonly || p.push({
                        mount_point: t.volume_path,
                        name: SYNO.SDS.Utils.StorageUtils.VolumeNameSizeRenderer(t),
                        description: t.description
                    })
                }), Ext.isEmpty(p) && "system" !== this.install_type ? this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), _T("error", "volume_no_volumes"), function(t) {
                    "ok" === t && SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance"), this.goNext(null)
                }, this) : (this.volumes = p, i.getValue(t, "licence") ? this.goNext("licenceStep", e) : this.volumes && this.volumes.length > 1 && !this.blUpgradeOrRepair && Ext.isEmpty(this.installVolume) && "system" !== this.install_type ? this.goNext("volumeStep", e) : this.customuiIds && this.customuiIds.length > 0 ? this.goNext(this.customuiIds[0], e) : e ? this.goNext("applyStep", e) : this.goNext("applyStep", e) && this.goNext(this.getActiveStep().getNext(), e))
            }
        })
    },
    parseCustomui: function parseCustomui(pkgcustomui) {
        var step_title, i, j, type, synotype, steps = [],
            desc, textType;
        for (i = 0; i < pkgcustomui.length; i++)
            if (Ext.isArray(pkgcustomui[i].items)) {
                var item, items = pkgcustomui[i].items,
                    compitems = [],
                    config, keys = ["labelHtmlEncode", "labelStyle", "style"],
                    pkguicfg = pkgcustomui[i],
                    labelWidth_array = [];
                for (j = 0; j < items.length; j++) {
                    if (type = items[j].type, textType = void 0, "multiselect" === type) synotype = "syno_checkbox";
                    else if ("singleselect" === type) synotype = "syno_radio";
                    else if ("textfield" === type) synotype = "syno_textfield";
                    else if ("password" === type) synotype = "syno_textfield", textType = "password";
                    else if ("combobox" === type) synotype = "syno_combobox";
                    else {
                        if (type || items[j].subitems || !Ext.isString(items[j].desc)) continue;
                        keys = keys.concat(["htmlEncode"]), item = items[j], config = {
                            xtype: "syno_displayfield",
                            htmlEncode: !1,
                            value: SYNO.SDS.UIString.GetLocalizedString(item.desc, this.dsm_apps[0]) || item.desc
                        }, Ext.copyTo(config, item, keys), compitems.push(config)
                    }
                    if (Ext.isArray(items[j].subitems)) {
                        var subitems = items[j].subitems,
                            v, items_desc_indent = 0;
                        items[j].desc && (compitems.push({
                            xtype: "syno_displayfield",
                            htmlEncode: !1,
                            value: SYNO.SDS.UIString.GetLocalizedString(items[j].desc, this.dsm_apps[0]) || items[j].desc
                        }), items_desc_indent = 30);
                        for (var k = 0; k < subitems.length; k++) {
                            if (item = subitems[k], config = {
                                    xtype: synotype,
                                    name: "singleselect" === type ? "radiogroup_" + j : item.key,
                                    htmlEncode: !1,
                                    invalid_next_disabled_v2: pkguicfg.invalid_next_disabled_v2,
                                    itemId: item.key
                                }, textType && Ext.apply(config, {
                                    textType: textType
                                }), "password" === type || "textfield" === type || "combobox" === type) {
                                if (!item.hidden) {
                                    var strDesc = ("string" == typeof item.desc ? item.desc : "") + "： ",
                                        desc_labelWidth = Ext.util.TextMetrics.measure(this.el, strDesc).width + items_desc_indent;
                                    item.indent && (desc_labelWidth += 30 * item.indent), labelWidth_array.push(desc_labelWidth)
                                }
                                if (config.width = 285, "combobox" === type) {
                                    var id = Ext.id();
                                    Ext.apply(config, Ext.apply(item, {
                                        id: id
                                    })), Ext.isObject(item.api_store) && (config.mode = "remote", config.store = new SYNO.API.JsonStore(Ext.apply(item.api_store, {
                                        autoDestroy: !0,
                                        autoLoad: !0,
                                        appWindow: this,
                                        listeners: {
                                            single: !0,
                                            load: function(t, e) {
                                                if (e && e[0] && e[0].id) {
                                                    var i = Ext.getCmp(id);
                                                    i && i.setValue(e[0].id)
                                                }
                                            }
                                        }
                                    })), delete config.api_store)
                                } else Ext.apply(config, item);
                                if (item.emptyText && (config.emptyText = item.emptyText), item.defaultValue && (config.value = item.defaultValue), Ext.isObject(item.validator)) {
                                    if (v = item.validator, Ext.isBoolean(v.allowBlank) && (config.allowBlank = v.allowBlank), Ext.isNumber(v.minLength) && (config.minLength = v.minLength), Ext.isNumber(v.maxLength) && (config.maxLength = v.maxLength), Ext.isString(v.vtype) && (config.vtype = v.vtype), Ext.isObject(v.regex) && Ext.isString(v.regex.expr)) try {
                                        var regex;
                                        eval(String.format("regex = {0};", v.regex.expr)), config.regex = regex, Ext.isString(v.regex.errorText) && (config.regexText = Ext.util.Format.htmlEncode(v.regex.errorText))
                                    } catch (t) {
                                        return SYNO.Debug(t), !0
                                    }
                                    Ext.isString(v.fn) && (config.fnstring = v.fn, config.validator = function(val) {
                                        try {
                                            var fn;
                                            eval(String.format("fn = function(){0};", this.fnstring));
                                            var ret = fn(val, this, this.ownerCt);
                                            return Ext.isString(ret) ? Ext.util.Format.htmlEncode(ret) : ret
                                        } catch (t) {
                                            return SYNO.Debug(t), !0
                                        }
                                    })
                                }
                            } else Ext.isBoolean(item.defaultValue) && (config.checked = item.defaultValue), Ext.isObject(item.validator) && (v = item.validator, Ext.isString(v.fn) && (config.fnstring = v.fn, config.getErrors = function(val) {
                                try {
                                    var fn;
                                    eval(String.format("fn = function(){0};", this.fnstring));
                                    var r = fn(this.getValue(), this, this.ownerCt);
                                    if (Ext.isBoolean(r)) return !1 === r ? [""] : [];
                                    if (Ext.isString(r)) try {
                                        this.ownerCt.ownerCt.owner.getMsgBox().alert(_T("tree", "leaf_packagemanage"), r)
                                    } catch (t) {}
                                    return Ext.isString(r) ? Ext.util.Format.htmlEncode(r) : []
                                } catch (t) {
                                    return SYNO.Debug(t), []
                                }
                            }));
                            desc = SYNO.SDS.UIString.GetLocalizedString(item.desc, this.dsm_apps[0]) || item.desc, desc && (config.boxLabel = config.fieldLabel = desc), 0 === k && "singleselect" === type && (config.checked = !0), items[j].desc && (config.indent = 1), "combobox" === type && (keys = keys.concat(["autoSelect", "displayField", "editable", "forceSelection", "handleHeight", "listAlign", "listEmptyText", "listWidth", "maxHeight", "minChars", "minHeight", "minListWidth", "mode", "pageSize", "queryDelay", "queryParam", "resizable", "selectOnFocus", "store", "title", "triggerAction", "typeAhead", "typeAheadDelay", "valueField"])), "password" !== type && "textfield" !== type && "combobox" !== type || (keys = keys.concat(["blankText", "grow", "growMax", "growMin", "htmlEncode", "maxLengthText", "minLengthText"])), keys = keys.concat(["disabled", "height", "hidden", "invalidText", "margins", "preventMark", "width"]), Ext.copyTo(config, item, keys), config.listeners = {
                                buffer: 100,
                                check: function() {
                                    (this.invalid_next_disabled_v2 && this.ownerCt && this.ownerCt.getForm || void 0 === this.invalid_next_disabled_v2 && pkguicfg.invalid_next_disabled && this.ownerCt && this.ownerCt.getForm) && this.ownerCt.owner.getButton("next").setDisabled(!this.ownerCt.getForm().isValid())
                                },
                                change: function(t, e, i) {
                                    this.ownerCt && this.ownerCt.owner && this.ownerCt.owner.getActiveStep && this.ownerCt != this.ownerCt.owner.getActiveStep() || (this.invalid_next_disabled_v2 && this.ownerCt && this.ownerCt.getForm || void 0 === this.invalid_next_disabled_v2 && pkguicfg.invalid_next_disabled && this.ownerCt && this.ownerCt.getForm) && this.ownerCt.owner.getButton("next").setDisabled(!this.ownerCt.getForm().isValid())
                                }
                            }, compitems.push(config)
                        }
                    }
                }
                step_title = pkguicfg.step_title, config = {
                    headline: SYNO.SDS.UIString.GetLocalizedString(step_title, this.dsm_apps[0]) || step_title,
                    xtype: "syno_formpanel",
                    border: !1,
                    items: compitems,
                    labelWidth: labelWidth_array.length > 0 ? Ext.max(labelWidth_array) : 200,
                    invalid_next_disabled_v2: pkguicfg.invalid_next_disabled_v2,
                    checkState: function() {
                        SYNO.SDS.Wizard.Step.prototype.checkState.apply(this, arguments), (this.invalid_next_disabled_v2 && this.getForm || void 0 === this.invalid_next_disabled_v2 && pkguicfg.invalid_next_disabled && this.getForm) && this.owner.getButton("next").setDisabled(!this.getForm().isValid())
                    },
                    activateParam: pkguicfg.activate_v2,
                    activate: function activate() {
                        var fn;
                        this.activateParam ? (eval(String.format("fn = function(){0};", this.activateParam)), fn(this, this.ownerCt)) : pkguicfg.activeate && (eval(String.format("fn = function(){0};", pkguicfg.activeate)), fn(this, this.ownerCt))
                    },
                    deactivateParam: pkguicfg.deactivate_v2,
                    deactivate: function deactivate(action) {
                        var fn, r;
                        if (this.deactivateParam) {
                            if (eval(String.format("fn = function(){0};", this.deactivateParam)), r = fn(this, this.ownerCt, action), Ext.isBoolean(r)) return r
                        } else if (pkguicfg.deactivate && (eval(String.format("fn = function(){0};", pkguicfg.deactivate)), r = fn(this, this.ownerCt, action), Ext.isBoolean(r))) return r;
                        return !("next" === action && this.getForm && !this.getForm().isValid())
                    },
                    listeners: {
                        afterlayout: {
                            fn: function(t) {
                                t.body.query("a").forEach(function(t) {
                                    t.getAttribute("data-syno-app") && t.addEventListener("click", SYNO.SDS.Utils.Notify.BindEvent)
                                })
                            },
                            single: !0,
                            scope: this
                        }
                    }
                }, steps.push(config)
            } return steps
    },
    getBasicPanel: function(t) {
        return new SYNO.SDS.Utils.FormPanel(Ext.apply({
            labelWidth: 200,
            headline: _T("pkgmgr", "pkgmgr_pkg_install_wizard_upload_title"),
            webapi: {
                api: "SYNO.Core.Package.Installation",
                method: "upload",
                version: 1
            },
            fileUpload: !0,
            border: !1,
            items: [{
                xtype: "box",
                html: _T("service", "service_file_nofileselected_tip"),
                style: {
                    lineHeight: "20px",
                    padding: "4px 0"
                }
            }, {
                xtype: "hidden",
                name: "additional",
                value: Ext.encode(["description", "maintainer", "distributor", "startable", "dsm_apps", "status", "install_reboot", "install_type", "install_on_cold_storage", "break_pkgs", "replace_pkgs"])
            }, {
                fieldLabel: _T("common", "file"),
                xtype: "syno_filebutton",
                name: "file"
            }],
            activate: function() {
                this.owner.isUploaed = !1, 3 === this.owner.orimode && this.owner.setTitle(_T("pkgmgr", "install_upgrade_title")), "uploadStep" === t.itemId && this.owner.onSendCleanTmp(!0)
            },
            getNext: function() {
                return this.owner.isUploaed ? this.nextId : "" === this.getForm().findField("file").getValue() ? (this.owner.getMsgBox().alert(_T("tree", "leaf_packagemanage"), _T("error", "error_nochoosefile")), !1) : (Ext.get(this.owner.id).mask(_T("common", "msg_waiting"), "x-mask-loading"), this.getForm().doAction("submit"), !1)
            }
        }, t))
    },
    getLicencePanelConfig: function(t) {
        return Ext.apply({
            hideMode: "offsets",
            headline: _T("pkgmgr", "license_title"),
            xtype: "syno_formpanel",
            border: !1,
            items: [{
                xtype: "box",
                html: _T("pkgmgr", "license_desc_short"),
                style: {
                    lineHeight: "20px",
                    marginBottom: "12px"
                }
            }, {
                hideLabel: !0,
                xtype: "syno_textarea",
                name: "licence",
                autoCreate: {
                    tag: "textarea",
                    autocomplete: "off",
                    wrap: "Physical"
                },
                readOnly: !0,
                cls: "selectabletext allowDefCtxMenu",
                width: 620,
                height: 220,
                value: ""
            }, {
                xtype: "syno_checkbox",
                boxLabel: _T("pkgmgr", "license_accept"),
                name: "checklicence",
                listeners: {
                    scope: this,
                    check: function(t, e) {
                        this.getButton("next").setDisabled(!e)
                    }
                }
            }],
            checkState: function() {
                SYNO.SDS.Wizard.Step.prototype.checkState.apply(this, arguments), this.getForm().findField("checklicence").setValue(!1), this.owner.getButton("next").setDisabled(!0)
            },
            activate: function() {
                try {
                    this.getForm().findField("licence").setValue(decodeURIComponent(this.owner.pkgLicence))
                } catch (t) {
                    this.getForm().findField("licence").setValue(window.unescape(this.owner.pkgLicence))
                }
            },
            getNext: function() {
                return this.owner.volumes.length > 1 && !this.owner.blUpgradeOrRepair && Ext.isEmpty(this.owner.installVolume) && "system" !== this.owner.install_type ? "volumeStep" : this.owner.customuiIds && this.owner.customuiIds.length > 0 ? this.owner.customuiIds[0] : "applyStep"
            }
        }, t)
    },
    getVolumePanelConfig: function(t) {
        var e, i, a = new Ext.data.Record.create([{
            name: "name"
        }, {
            name: "mount_point"
        }, {
            name: "description"
        }]);
        this.volumeStore = new Ext.data.ArrayStore({
            fields: ["mount_point", "name", "description"],
            data: []
        });
        var n = new SYNO.ux.MessageComboBox({
            store: this.volumeStore,
            name: "voulme_list",
            displayField: "name",
            descriptionField: "description",
            valueField: "mount_point",
            mode: "local",
            editable: !1,
            hideLabel: !0,
            triggerAction: "all",
            width: 285
        });
        return Ext.apply({
            headline: _T("pkgmgr", "pkgmgr_pkg_install_wizard_selectvol_title"),
            xtype: "syno_formpanel",
            border: !1,
            items: [n, {
                xtype: "syno_displayfield",
                height: 240
            }, {
                xtype: "syno_checkbox",
                boxLabel: _T("pkgmgr", "be_default_vol"),
                name: "be_default_vol"
            }],
            activate: function() {
                if (this.owner.blSetDefaultVol = !1, this.getForm().findField("be_default_vol").setVisible(!this.owner.install_on_cold_storage), !n.getValue() && (this.owner.volumeStore.removeAll(), this.owner.volumes)) {
                    for (e = 0; e < this.owner.volumes.length; e++) i = new a({
                        name: this.owner.volumes[e].name,
                        mount_point: this.owner.volumes[e].mount_point,
                        description: Ext.util.Format.htmlEncode(this.owner.volumes[e].description)
                    }), this.owner.volumeStore.add(i);
                    n.setValue(this.owner.volumes[0].mount_point)
                }
            },
            getNext: function() {
                var t = this.getForm().findField("be_default_vol").getValue(),
                    e = this.getForm().findField("voulme_list").getValue();
                if (this.owner.blSetDefaultVol) return this.owner.installVolume = e, this.owner.customuiIds && this.owner.customuiIds.length > 0 ? this.owner.customuiIds[0] : "applyStep";
                this.owner.setStatusBusy({
                    text: _T("common", "saving")
                });
                var i = this.owner.volumeStore.findExact("mount_point", e),
                    a = t ? this.owner.volumeStore.getAt(i).get("mount_point") : "";
                return this.owner.sendWebAPI({
                    api: "SYNO.Core.Package.Setting.Volume",
                    method: "set",
                    version: 1,
                    params: {
                        default_vol: a
                    },
                    scope: this.owner,
                    callback: function(t, e) {
                        this.clearStatusBusy(), t ? (this.blSetDefaultVol = !0, this.goNext(this.getActiveStep().getNext())) : e && e.code ? this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), SYNO.API.getErrorString(e.code)) : this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), String.format("{0} {1}", _T("pkgmgr", "system_error"), _T("pkgmgr", "contact_support_or_try_again")))
                    }
                }), !1
            }
        }, t)
    },
    getInfoPanelConfig: function(t) {
        return Ext.apply({
            headline: _T("pkgmgr", "pkgmgr_pkg_install_wizard_summary_title"),
            xtype: "syno_formpanel",
            items: [{
                xtype: "box",
                itemId: "synopkg_wizard_summary_desc",
                html: _T("pkgmgr", "pkgmgr_pkg_install_wizard_summary_desc"),
                style: {
                    lineHeight: "20px",
                    marginBottom: "4px"
                }
            }, {
                xtype: "syno_gridpanel",
                border: !1,
                stripeRows: !0,
                height: 255,
                viewConfig: {
                    getRowClass: function(t) {
                        return "description" === t.data.id ? "syno-pkg-wizard-desc" : ""
                    }
                },
                columns: [{
                    header: _T("status", "header_item"),
                    width: 100,
                    sortable: !1,
                    dataIndex: "name",
                    renderer: function(t, e) {
                        var i = Ext.util.Format.htmlEncode(t);
                        return e.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(i) + '"', i
                    }
                }, {
                    header: _T("status", "header_value"),
                    width: 220,
                    sortable: !1,
                    dataIndex: "value",
                    renderer: function(t, e) {
                        var i = Ext.util.Format.htmlEncode(t);
                        return e.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(i) + '"', i
                    }
                }],
                store: this.getDetailsStore()
            }, {
                xtype: "syno_checkbox",
                itemCls: "syno-wizard-grid-button",
                boxLabel: _T("pkgmgr", "install_runpackage"),
                name: "runafterinstall"
            }],
            activate: function() {
                this.owner.loadInfo();
                var t = this.owner.pkgCanRun && !this.owner.blUpgradeOrRepair,
                    e = this.getForm().findField("runafterinstall");
                e.setVisible(t), e.setValue(t), 1 === this.owner.mode ? this.getComponent("synopkg_wizard_summary_desc").update(_T("pkgmgr", "pkgmgr_pkg_upgrade_wizard_summary_desc")) : this.getComponent("synopkg_wizard_summary_desc").update(_T("pkgmgr", "pkgmgr_pkg_install_wizard_summary_desc"))
            },
            getNext: function() {
                var t = this.getForm().findField("runafterinstall").getValue(),
                    e = this.owner.enumInstallMode.install === this.owner.installMode && t === this.owner.pkgCanRun || this.owner.enumInstallMode.repair === this.owner.installMode || this.owner.enumInstallMode.upgrade === this.owner.installMode && "running" === this.owner.originalStatus;
                if (this.owner.pkgqinst) {
                    var i = this.owner.owner,
                        a = this.owner.pkgqinstrec,
                        n = this.owner.installVolume;
                    return this.owner.goNext(null), i._onRequestQuickInstall(a, n, e), !1
                }
                var s = this.owner.blUpgradeOrRepair ? _T("pkgmgr", "upgrading") : _T("pkgmgr", "installing");
                this.owner.setStatusBusy({
                    text: s
                });
                var r = [{
                    api: "SYNO.Core.Package.Installation",
                    method: "check",
                    version: 2,
                    params: {
                        id: this.owner.pkgName,
                        install_type: this.owner.install_type,
                        install_on_cold_storage: this.owner.install_on_cold_storage,
                        breakpkgs: "" === this.owner.break_pkgs ? null : this.owner.break_pkgs,
                        blCheckDep: !!this.owner.getStep("uploadStep"),
                        replacepkgs: "" === this.owner.replace_pkgs ? null : this.owner.replace_pkgs
                    }
                }, {
                    api: "SYNO.Core.Package.Installation",
                    method: SYNO.SDS.PkgManApp.Action._isPkgInstalled(this.owner.pkgName) ? "upgrade" : "install",
                    version: 1,
                    params: {
                        volume_path: this.owner.installVolume,
                        extra_values: Ext.encode(this.owner.getCustData()),
                        type: this.type || 0,
                        check_codesign: this.owner.check_codesign,
                        force: !this.owner.getStep("uploadStep"),
                        installrunpackage: e
                    }
                }];
                this.owner.upload_task_id ? r[1].params.task_id = this.owner.upload_task_id : r[1].params.path = this.owner.uploadFilename, r.push({
                    api: "SYNO.Core.Package",
                    method: "get",
                    version: 1,
                    params: {
                        id: this.owner.pkgName,
                        additional: ["status", "dsm_apps"]
                    }
                });
                var o = function(t) {
                    var e = t.getById(this.owner.pkgName);
                    if (e && !this.owner.isDestroyed) {
                        var i, a = e.data.progress,
                            n = e.data.status,
                            r = this.owner._GetProcessStatus(n, a);
                        r.blProcessing ? i = "stopping" === n ? _T("pkgmgr", "upgrading") : r.msg : a && (i = Math.floor(100 * a) + "% " + s, this.owner.el.mask(Math.floor(100 * a) + "% " + s, "x-mask-loading")), this.owner.el.mask(i || s, "x-mask-loading")
                    }
                };
                return SYNO.SDS.StatusNotifier.fireEvent("pkgctl", this.owner.pkgName, this.owner.blUpgradeOrRepair ? "upgrade" : "install", "pre"), this.sendWebAPI({
                    timeout: 36e5,
                    compound: {
                        stopwhenerror: !0,
                        params: r
                    },
                    scope: this,
                    callback: function(t, e, i, a) {
                        t && e && !e.has_fail || this.owner.el.unmask(), this.mun(this.owner.owner.stores.installed, "load", o, this), this.owner.clearStatusBusy(), this.owner._handleApplyDone(t, e, i, a)
                    }
                }), this.owner.dsm_apps && Ext.each(this.owner.dsm_apps, function(t) {
                    var e = SYNO.SDS.AppMgr.getByAppName(t);
                    Ext.each(e, function(t) {
                        t.window && t.window.close()
                    }), SYNO.SDS.JSLoad.RemoveJSSatusByAppName(t)
                }), this.owner.owner.fireEvent("pollinginstpage"), this.mon(this.owner.owner.stores.installed, "load", o, this), !1
            }
        }, t)
    },
    getCustData: function() {
        var t = {};
        return Ext.each(this.customuiIds, function(e) {
            var i = this.getStep(e).getForm(),
                a = {};
            i.items.each(function(t) {
                "displayfield" !== t.getXType() && "syno_displayfield" !== t.getXType() && (a[t.itemId] = t.getValue())
            }), Ext.apply(t, a)
        }, this), t
    },
    getDetailsStore: function() {
        return this.store = new Ext.data.JsonStore({
            autoLoad: !1,
            autoDestroy: !0,
            root: "items",
            fields: ["id", "name", "value"]
        }), this.store
    },
    loadInfo: function() {
        var t = [{
            id: "name",
            name: _T("pkgmgr", "pkgmgr_pkg_name"),
            value: this.dname || this.pkgName
        }, {
            id: "version",
            name: _T("pkgmgr", "pkgmgr_pkg_version"),
            value: this.pkgVersion
        }, {
            id: "maintainer",
            name: _T("pkgmgr", "pkgmgr_pkg_maintainer"),
            value: this.maintainer
        }];
        if (this.pkgDistributor && t.push({
                id: "distributor",
                name: _T("pkgmgr", "pkgmgr_pkg_distributor"),
                value: this.pkgDistributor
            }), "system" === this.install_type) t.push({
            id: "volume",
            name: _T("pkgmgr", "pkgmgr_pkg_install_volume"),
            value: _T("pkgmgr", "system_volume")
        });
        else if (this.volumes && 1 <= this.volumes.length)
            for (var e = 0; e < this.volumes.length; e++)
                if (this.volumes[e].mount_point == this.installVolume) {
                    t.push({
                        id: "volume",
                        name: _T("pkgmgr", "pkgmgr_pkg_install_volume"),
                        value: this.volumes[e].name
                    });
                    break
                } t.push({
            id: "description",
            name: _T("pkgmgr", "pkgmgr_pkg_description"),
            value: this.desc
        }), this.store.loadData({
            items: t
        })
    },
    onSyncCleanTmp: function() {
        Ext.EventManager.un(window, "unload", this.onSyncCleanTmp, this), SYNO.SDS.StatusNotifier.un("logout", this.onSyncCleanTmp, this), this.onSendCleanTmp(!1)
    },
    onAsyncCleanTmp: function() {
        Ext.EventManager.un(window, "unload", this.onSyncCleanTmp, this), SYNO.SDS.StatusNotifier.un("logout", this.onSyncCleanTmp, this), this.onSendCleanTmp(!0)
    },
    onSendCleanTmp: function(t) {
        var e;
        this.uploadFilename ? (e = {
            path: this.uploadFilename
        }, this.sendWebAPI({
            api: "SYNO.Core.Package.Installation",
            method: "delete",
            version: 1,
            params: e,
            async: t,
            timeout: t ? 3e4 : 1e3
        })) : this.upload_task_id && (e = {
            task_id: this.upload_task_id
        }, this.sendWebAPI({
            api: "SYNO.Core.Package.Installation",
            method: "clean",
            version: 1,
            params: e,
            async: t,
            timeout: t ? 3e4 : 1e3
        })), this.uploadFilename = null, this.upload_task_id = null
    }
}), SYNO.SDS.PkgManApp.UninstallWizardDialog = Ext.extend(SYNO.SDS.PkgManApp.WizardDialog, {
    constructor: function(t) {
        SYNO.SDS.PkgManApp.Utils.Utils._initWinWrappers.call(this, t), this.packagename = t.packagename, this.dname = t.dname, this.dsm_apps = [], t.dsm_apps && (this.dsm_apps = t.dsm_apps.split(" ")), SYNO.SDS.PkgManApp.WizardDialog.superclass.constructor.call(this, Ext.apply(t, {
            dsmStyle: "v5",
            title: _T("tree", "leaf_packagemanage"),
            width: 700,
            height: 500,
            cls: "synopkg-wizard-window",
            steps: [this.getBasicPanel({
                itemId: "confirmStep",
                nextId: !0
            })]
        })), this.mon(this, "beforeshow", function() {
            Ext.get(this.id).mask(_T("common", "msg_waiting"), "x-mask-loading"), SYNO.SDS.PkgManApp.Utils.Utils.setGlobalValue()
        }), this.mon(this, "beforeclose", function() {
            SYNO.SDS.PkgManApp.Utils.Utils.cleanGlobalValue()
        }, this), this.loadUIfile()
    },
    goNext: function(t) {
        SYNO.SDS.PkgManApp.WizardDialog.superclass.goNext.apply(this, arguments), t && null === this.getActiveStep().nextId && this.getButton("next").setText(_T("pkgmgr", "pkgmgr_pkg_uninstall"))
    },
    getBasicPanel: function(t) {
        return Ext.apply({
            headline: _T("pkgmgr", "pkgmgr_pkg_uninstall"),
            xtype: "syno_formpanel",
            border: !1,
            items: [{
                xtype: "syno_displayfield",
                value: _T("pkgmgr", "pkgmgr_pkg_uninstall_warn")
            }]
        }, t)
    },
    processSingleStep: function(t, e) {
        return t.headline = String.format(_T("pkgmgr", "uninstall_wizard_title"), e), t
    },
    loadUIfile: function() {
        var t = {
            id: this.packagename,
            additional: ["uninstall_pages"]
        };
        this.sendWebAPI({
            api: "SYNO.Core.Package",
            method: "get",
            version: 1,
            params: t,
            scope: this,
            callback: this.handelloadUIfileDone
        })
    },
    handelloadUIfileDone: function(t, e, i, a) {
        if (Ext.get(this.id).unmask(), t && e.additional && void 0 !== e.additional.uninstall_pages) {
            var n = e.additional.uninstall_pages,
                s = [];
            if (n) {
                if (Ext.isString(n)) try {
                    n = Ext.decode(decodeURIComponent(n))
                } catch (t) {
                    n = Ext.decode(window.unescape(n))
                }
                if (!Ext.isArray(n)) return void this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), String.format(_T("pkgmgr", "uninstall_pkg_fail"), this.dname, _T("pkgmgr", "contact_developer_or_try_again")), function() {
                    this.close()
                }, this);
                0 === n.length && (n = [{
                    items: [{
                        desc: ""
                    }]
                }]), (s = this.parseCustomui(n)).length > 0 && (s[s.length - 1].getNext = function() {
                    var t = this.owner.getActiveStep();
                    if (t && Ext.isFunction(t.deactivate) && !1 === t.deactivate("next")) return !1;
                    this.owner.setStatusBusy();
                    var e = {
                        id: this.owner.packagename,
                        extra_values: Ext.encode(this.owner.getCustData()),
                        dsm_apps: this.owner.dsm_apps
                    };
                    return SYNO.SDS.StatusNotifier.fireEvent("pkgctl", e.id, "uninstall", "pre"), this.sendWebAPI({
                        api: "SYNO.Core.Package.Uninstallation",
                        method: "uninstall",
                        version: 1,
                        params: e,
                        timeout: 36e5,
                        scope: this,
                        callback: function(t, e, i, a) {
                            if (!this.owner.isDestroyed && t && this.owner.fireEvent("uninstalldone"), a && a.params && a.params.id) {
                                var n = SYNO.SDS.PkgManApp.Action._getInstalledStore().getById(a.params.id);
                                n && SYNO.SDS.PkgManApp.Action._getInstalledStore().remove(n)
                            }
                            this.owner.clearStatusBusy(), this.owner._handleApplyDone(t, e, i, a)
                        }
                    }), !1
                })
            }
            1 === s.length ? (this.customuiIds = this.appendSteps(this.processSingleStep(s[0], e.name)), this.goNext(this.customuiIds[0], !1)) : s.length > 0 ? (this.customuiIds = this.appendSteps(s), this.getActiveStep().nextId = this.customuiIds[0]) : (this.customuiIds = void 0, this._showErrMsg())
        } else this._showErrMsg(e)
    }
}), Ext.define("SYNO.SDS.PkgManApp.Toolbar", {
    extend: "SYNO.ux.Toolbar",
    helper: SYNO.SDS.PkgManApp.Utils.Helper,
    constructor: function(t) {
        this.callParent([this.fillConfig(t)])
    },
    fillConfig: function(t) {
        var e = {
            height: 40,
            cls: "synopkg-toolbar",
            backStack: [],
            forwardStack: [],
            currentPage: {},
            items: [this.createItems()]
        };
        return Ext.apply(e, t), e
    },
    createItems: function() {
        return this.searchField = new SYNO.SDS.PkgManApp.Utils.SearchField({
            width: "100%",
            owner: this,
            style: {
                width: "calc(100% - 30px - 3px)"
            }
        }), this.backBtn = new Ext.Action({
            cls: "synopkg-toolbar-back-btn synopkg-icon-btn",
            iconCls: "synopkg-toolbar-back-icon synopkg-btn-icon",
            scope: this,
            handler: this.jumpBack,
            height: 28,
            disabled: !0
        }), this.nextBtn = new Ext.Action({
            cls: "synopkg-toolbar-next-btn synopkg-icon-btn",
            iconCls: "synopkg-toolbar-next-icon synopkg-btn-icon",
            scope: this,
            handler: this.jumpForward,
            height: 28,
            disabled: !0
        }), this.refreshBtn = new Ext.Action({
            iconCls: "synopkg-toolbar-refresh-icon synopkg-btn-icon",
            scope: this,
            handler: this.onClickRefreshBtn,
            height: 28,
            disabled: !1
        }), [this.backBtn, this.nextBtn, this.refreshBtn, this.searchField, {
            xtype: "displayfield",
            width: 16
        }, new Ext.Action({
            scope: this,
            hidden: !_S("is_admin"),
            handler: function() {
                this.owner._prepareVolume(3)
            },
            height: 28,
            text: this.helper.T("install_upgrade_title")
        }), new Ext.Action({
            scope: this,
            handler: function() {
                new SYNO.SDS.PkgManApp.SettingDialog({
                    owner: this.owner
                }).show()
            },
            height: 28,
            text: this.helper.T("common", "common_settings")
        })]
    },
    setNavBtn: function() {
        this.backBtn.disable(), this.nextBtn.disable(), this.backStack.length > 0 && this.backBtn.enable(), this.forwardStack.length > 0 && this.nextBtn.enable()
    },
    onClickRefreshBtn: function() {
        if (!this.owner.getStore("stable").loading) {
            var t = this.refreshBtn;
            this.owner.setStatusBusy(), t.disable(), this.owner.onLoadSynoPkgStore(!0, function() {
                this.clearStatusBusy(), t.enable()
            })
        }
        this.owner.getStore("community").loading || this.owner.onLoadOtherPkgStore()
    },
    jumpTo: function(t, e, i, a, n) {
        this.currentPage.tab === t && this.currentPage.card === e && this.currentPage.pkgId === i && this.currentPage.searchtext === a && this.currentPage.categoryId === (n && n.categoryId) || (this.backStack.push(this.currentPage), this.currentPage = {
            tab: t,
            card: e,
            pkgId: i,
            categoryId: n && n.categoryId,
            searchtext: a
        }, this._jumpTo(this.currentPage, n), this.forwardStack.length = 0, this.setNavBtn())
    },
    _jumpTo: function(t, e) {
        this.owner.pageList.getNodeById(t.tab).select();
        var i = this.owner.pageCt.getComponent(t.tab);
        t.pkgId && i.getComponent(t.card).setPkg(t.pkgId), t.searchtext && (this.searchField.setValue(t.searchtext), i.onLoadData()), i.layout.setActiveItem(t.card), t.pkgId && i.getComponent(t.card).onActivate(), t.categoryId && Ext.isFunction(i.jumpToCategory) && i.jumpToCategory(t.categoryId), e && !0 === e.scrollToTop && i.getComponent(t.card).resetScroller()
    },
    jumpBack: function() {
        this.forwardStack.push(this.currentPage), this.currentPage = this.backStack.pop(), this._jumpTo(this.currentPage), this.backStack.length < 1 && this.backBtn.disable(), this.setNavBtn()
    },
    jumpForward: function() {
        this.backStack.push(this.currentPage), this.currentPage = this.forwardStack.pop(), this._jumpTo(this.currentPage), this.forwardStack.length < 1 && this.nextBtn.disable(), this.setNavBtn()
    },
    setCurrentPage: function(t, e, i) {
        t === this.currentPage.tab && e === this.currentPage.card && this.currentPage.searchtext === i || (this.currentPage.tab && this.backStack.push(this.currentPage), this.currentPage = {
            tab: t,
            card: e,
            searchtext: i
        }, this.forwardStack.length = 0, this.setNavBtn())
    }
}), 
/**
 * @class SYNO.SDS.PkgManApp.Instance
 * @extends SYNO.SDS.AppInstance
 * PkgMan application instance class
 *
 */
 Ext.define("SYNO.SDS.PkgManApp.Instance", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.PkgManApp.MainWindow"
}), Ext.define("SYNO.SDS.PkgManApp.MainWindow", {
    extend: "SYNO.SDS.PageListAppWindow",
    defaultWinSize: {
        width: 1060,
        height: 580
    },
    minWinSize: {
        width: 880,
        height: 580
    },
    helper: SYNO.SDS.PkgManApp.Utils.Helper,
    storeHelper: SYNO.SDS.PkgManApp.Utils.StoreHelper,
    constructor: function(t) {
        SYNO.SDS.PkgManApp.Window = this, this.synopkglistHash = 0, this.progressDatas = {}, this.synoAccountInfo = {}, SYNO.SDS.PkgManApp.Utils.Utils._initWinWrappers.call(this, t), this.initStoreObjs(), this.callParent([this.fillConfig(t)]), this.mon(this.pageList, "click", this.setToListView), this.mon(this, "pollinginstpage", this._restartInstalledListPolling, this, {
            buffer: 1e3
        }), this.mon(this, "pollingserverlistcheck", this.startServerListCheckPolling, this), this.mon(this, "disagreeterm", function() {
            this.close()
        }), this.addEvents("status_load")
    },
    fillConfig: function(t) {
        this.createStores();
        var e = [{
            text: this.helper.T("install_packages"),
            iconCls: "icon-installed",
            fn: "SYNO.SDS.PkgManApp.Installed.Panel"
        }, {
            text: this.helper.T("class_all"),
            iconCls: "icon-dsm-apps",
            hidden: !_S("is_admin"),
            allowAdminOnly: !0,
            fn: "SYNO.SDS.PkgManApp.All.Panel"
        }, {
            text: this.helper.T("categories"),
            iconCls: "icon-category",
            hidden: !0,
            allowAdminOnly: !0,
            fn: "SYNO.SDS.PkgManApp.Category.Panel"
        }, {
            text: this.helper.T("class_beta"),
            iconCls: "icon-beta",
            hidden: !0,
            fn: "SYNO.SDS.PkgManApp.Beta.Panel"
        }, {
            text: this.helper.T("class_community"),
            iconCls: "icon-community",
            hidden: !0,
            fn: "SYNO.SDS.PkgManApp.Community.Panel"
        }, {
            hidden: !0,
            fn: "SYNO.SDS.PkgManApp.SearchResult.Panel"
        }];
        this.toolBar = new SYNO.SDS.PkgManApp.Toolbar({
            owner: this,
            disabled: !0
        });
        var i = {
            width: this.defaultWinSize.width,
            height: this.defaultWinSize.height,
            minWidth: this.minWinSize.width,
            minHeight: this.minWinSize.height,
            cls: "synopkg-window",
            tbar: this.toolBar,
            listItems: e,
            activePage: "SYNO.SDS.PkgManApp.Installed.Panel",
            listeners: {
                activate: this.onActivate,
                deactivate: this.onDeactivate
            }
        };
        return Ext.apply(i, t), i
    },
    getPageCt: function() {
        return this.pageCt || (this.pageCt = new Ext.Panel({
            layout: "card",
            padding: "0 16px 12px 0",
            border: !1,
            frame: !1,
            hideMode: "offsets",
            region: "center"
        })), this.pageCt
    },
    onOpen: function(t) {
        this.callParent(arguments), this.loadCfg(), this.createPollingTask(t)
    },
    onRequest: function(t) {
        this.callParent(arguments), this.processOpenParam(t)
    },
    setToListView: function(t) {
        var e = t.ownerTree.ownerCt.pageCt.getComponent(t.id);
        e && (SYNO.SDS.PkgManApp.Window.setCurrentPage(e.panelName, 0), e.layout.setActiveItem(0))
    },
    setDynamicTabs: function(t, e) {
        t ? this.pageList.getNodeById("SYNO.SDS.PkgManApp.Beta.Panel").getUI().show() : (this.pageList.getNodeById("SYNO.SDS.PkgManApp.Beta.Panel").isSelected() && this.pageList.getNodeById("SYNO.SDS.PkgManApp.Installed.Panel").select(), this.pageList.getNodeById("SYNO.SDS.PkgManApp.Beta.Panel").getUI().hide()), e ? this.pageList.getNodeById("SYNO.SDS.PkgManApp.Community.Panel").getUI().show() : (this.pageList.getNodeById("SYNO.SDS.PkgManApp.Community.Panel").isSelected() && this.pageList.getNodeById("SYNO.SDS.PkgManApp.Installed.Panel").select(), this.pageList.getNodeById("SYNO.SDS.PkgManApp.Community.Panel").getUI().hide())
    },
    _handleConfigData: function(t, e) {
        t && e && !Ext.isEmpty(e.myPayBaseURL) ? (Ext.apply(SYNO.SDS.PkgManApp.Config, e), Ext.apply(SYNO.SDS.PkgManApp.Config, {
            myDSURL: SYNO.SDS.PkgManApp.Config.myPayBaseURL + "/api/purchase5_1.html"
        })) : e.code ? this.getMsgBox().alert(this.title, SYNO.API.getErrorString(e.code)) : this.getMsgBox().alert(this.title, this.helper.T("common", "commfail")), this.pageList.getNodeById("SYNO.SDS.PkgManApp.SearchResult.Panel").getUI().hide(), _S("is_admin") && this.setDynamicTabs(e.blBetaChannel, e.blOtherServer)
    },
    _handleTermData: function(t, e) {
        t && e ? this.showTermDialog(e) : this.showTermDialog()
    },
    loadCfg: function(t) {
        this.setStatusBusy(), this.sendWebAPI({
            api: "SYNO.Core.Package.Info",
            method: "get",
            version: 1,
            scope: this,
            callback: function(e, i) {
                this.clearStatusBusy(), e && (this._handleConfigData(i.config.success, i.config), this._handleTermData(i.term.success, i.term), this.stores.stable.reload(), this.stores.community.reload(), t && t())
            }
        })
    },
    createPollingTask: function(t) {
        var e = this;
        this.pageList.el.mask(), this._pollingAdditionalFields = ["description", "description_enu", "beta", "distributor", "distributor_url", "maintainer", "maintainer_url", "dsm_apps", "dsm_app_page", "dsm_app_launch_name", "report_beta_url", "support_center", "startable", "installed_info", "support_url", "is_uninstall_pages", "install_type", "autoupdate", "silent_upgrade", "installing_progress", "ctl_uninstall", "updated_at"], this.sendWebAPI({
            api: "SYNO.Core.Package",
            method: "list",
            version: 2,
            scope: this,
            params: {
                additional: this._pollingAdditionalFields
            },
            callback: function(e, i) {
                if (e && !this.isDestroyed) {
                    this.onData(i), this.pageList.el.unmask(), this.toolBar.enable();
                    var a = this.getInitialPanelName();
                    this.blForceSelectPage = !0, this.pageList.getNodeById(a).select(), this.blForceSelectPage = !1, SYNO.SDS.PkgManApp.Window.setCurrentPage(a, 0), this._pollingAdditionalFields.push("status", "url", "available_operation"), t && (this.processOpenParam(t), t = null), this._restartInstalledListPolling()
                }
            }
        }), SYNO.SDS.Packages.registerPackageStatusChange(function() {
            e.isDestroyed || (e.onData({
                packages: Object.values(SYNO.SDS.Packages.getAllPackagesGroupByPkgId())
            }), e.updateNotificationBubble(), e.fireEvent("status_load"))
        }), SYNO.SDS.Packages.registerAllPackagesChange(function(t) {
            e.isDestroyed || t && !t.includes("available_operation") || (e.onData({
                packages: Object.values(SYNO.SDS.Packages.getAllPackagesGroupByPkgId())
            }), e.updateNotificationBubble(), e.fireEvent("status_load"))
        }), this.serverListCheckPolling = this.addWebAPITask({
            id: "serverListCheckPolling",
            scope: this,
            interval: 15e3,
            api: "SYNO.Core.Package.Server",
            method: "get_hash",
            version: 1,
            callback: function(t, e) {
                this.isDestroyed ? this.serverListCheckPolling.stop() : t && e && e.hasOwnProperty("hash") && e.hash && (this.synopkglistHash && e.hash != this.synopkglistHash && this.onLoadSynoPkgStore(!0), this.synopkglistHash = e.hash)
            }
        })
    },
    _restartInstalledListPolling: function() {
        var t = this;
        this.instListInstantGet || (this.instListInstantGet = setTimeout(function() {
            SYNO.SDS.Packages.getData(t._pollingAdditionalFields), t.instListInstantGet = null
        }, 2e3), this.instListPolling && clearInterval(this.instListPolling), this.lastRequestDone = !0, this.instListPolling = setInterval(function() {
            t.lastRequestDone && (t.lastRequestDone = !1, SYNO.SDS.Packages.getData(t._pollingAdditionalFields).finally(function() {
                t.lastRequestDone = !0
            }))
        }, 15e3))
    },
    getInitialPanelName: function() {
        return "7.0" === _S("productversion") && !this._isBuildPhaseGM() && _S("is_admin") && SYNO.SDS.PkgManApp.Config.blBetaChannel ? "SYNO.SDS.PkgManApp.Beta.Panel" : _S("is_admin") ? "SYNO.SDS.PkgManApp.All.Panel" : "SYNO.SDS.PkgManApp.Installed.Panel"
    },
    processOpenParam: function(t) {
        t.action ? this.beforeAction(t) : this.onLaunchPage(t)
    },
    beforeAction: function(t) {
        var e = this._getSynoServerObj().store;
        this.installData = t, 0 === e.getTotalCount() || e.loading ? (this.mon(e, "load", this.onLoadCallBack, this), e.reload()) : this.doAction(t, e)
    },
    doAction: function(t, e) {
        t && ("open" === t.action ? this.doOpenAction(t, e) : "install" === t.action && this.doInstallAction(t, e))
    },
    onLoadCallBack: function(t, e) {
        this.mun(t, "load", this.onLoadCallBack, this), this.doAction(this.installData, t)
    },
    doOpenAction: function(t, e) {
        var i = t.packages[0];
        if (this.stores.installed.getById(i)) this.jumpTo("SYNO.SDS.PkgManApp.Installed.Panel", 1, i);
        else if (this.stores.stable.getById(i)) this.jumpTo("SYNO.SDS.PkgManApp.All.Panel", 1, i);
        else {
            if (this.stores.beta.getById(i)) {
                if (SYNO.SDS.PkgManApp.Config.blBetaChannel) return void this.jumpTo("SYNO.SDS.PkgManApp.Beta.Panel", 1, i);
                var a = this.stores.beta.getById(i),
                    n = this.helper.encodeMsg(a.get("dname") || a.get("id")),
                    s = String.format(_T("pkgmgr", "msg_enable_beta_to_open_beta_pkg"), n);
                this.getMsgBox().alert(_T("tree", "leaf_packagemanage"), s)
            }
            this.jumpTo("SYNO.SDS.PkgManApp.All.Panel")
        }
    },
    doInstallAction: function(t, e) {
        var i = 0,
            a = [],
            n = "";
        for (i = 0; i < t.packages.length; i++) {
            var s = e.getById(t.packages[i]);
            s && this._isQuickInstll(s.data) && !this._isFirstBuy(s) && !this._isLicenseError(s) && SYNO.SDS.PkgManApp.Utils.Utils.mode.open !== s.data.open ? this._onClickSynoPkgActionBtn(s, !0) : s && SYNO.SDS.PkgManApp.Utils.Utils.mode.open !== s.data.open && a.push(s)
        }
        if (1 === a.length && this._onClickSynoPkgActionBtn(a[0], !0), 1 < a.length) {
            for (i = 1; i < a.length; i++) n = n + a[i].id + " ";
            n = String.format(_T("pkgmgr", "auto_install"), a[0].id, n), this.getMsgBox().alert("title", n, function() {
                this._onClickSynoPkgActionBtn(a[0], !0)
            }, this)
        }
    },
    onData: function(t) {
        var e = this.stores.installed,
            i = {};
        for (var a in e.each(function(t) {
                this.clearStatus(this.stores.stable, t.id), this.clearStatus(this.stores.beta, t.id), this.clearStatus(this.stores.community, t.id), i[t.id] = t
            }, this), e.suspendEvents(), e.loadData(t), e.resumeEvents(), e.each(function(t) {
                var e = this.getProgressData(t);
                e && e.blNewlyInstalled && delete SYNO.SDS.PkgManApp.Window.progressDatas[t.get("id")], this.blOnFirstDataFinished || (t.data.status = "loading", t.data.available_operation = {}), i[t.id] = t, this._setupInstalledOperationInfo(t)
            }, this), e.fireEvent("datachanged", e), e.fireEvent("load", e, e.data.items), i) i.hasOwnProperty(a) && (this.triggerUpdate(this.stores.stable, a), this.triggerUpdate(this.stores.beta, a), this.triggerUpdate(this.stores.community, a));
        this.blOnFirstDataFinished = !0
    },
    _setupInstalledOperationInfo: function(t) {
        var e = this,
            i = t.data,
            a = "",
            n = "",
            s = "",
            r = "",
            o = i.statusDescription,
            l = "",
            p = null,
            g = !1,
            c = t;
        switch ("doing" === i.statusDesktop && (g = !0, n = _T("pkgmgr", "status_installed"), s = i.statusTitle, r = "#009E05"), "downloading" === i.status && (a = "cancel", n = _T("common", "cancel"), s = i.statusTitle, r = "#057FEB", l = "syno-ux-button-grey"), "loading" === i.status && (l = "", g = !0, n = _T("pkgmgr", "status_installed"), s = _T("pkgmgr", "loading"), r = "#057FEB"), "running" === i.status && (s = i.statusTitle, r = "#009E05", SYNO.SDS.PkgManApp.Utils.Utils.IsPkgOpenable(i) ? (l = "syno-pkg-button-open syno-ux-button-grey", a = "open", n = _T("pkgmgr", "open"), p = function() {
                SYNO.SDS.PkgManApp.Utils.Utils.OpenPkgApp(i)
            }) : (g = !0, l = "syno-ux-button-grey", n = _T("pkgmgr", "status_installed"))), "stop" === i.status && (s = i.statusTitle, r = "rgba(65,75,85,0.60)", l = "syno-pkg-button-run syno-ux-button-grey", a = "start", n = _T("pkgmgr", "pkgmgr_pkg_start"), p = function() {
                e._onStartPkg(t)
            }), i.status) {
            case "start_failed":
            case "stopped_by_dep_limit":
            case "version_limit":
                r = "rgba(65,75,85,0.60)";
                break;
            case "broken":
            case "license_error":
            case "broken_by_other":
                r = "#E64040"
        }
        if (this._HasAvailableOperation(i)) {
            s = i.statusTitle;
            var d = i.available_operation;
            if (SYNO.SDS.PkgManApp.Utils.Utils.isBrokenStatus(i) ? (l = "syno-pkg-button-repair syno-ux-button-orange", n = _T("pkgmgr", "repair"), g = "doing" === i.statusDesktop) : (d.upgrade || d.forcereplaced) && (l = "syno-ux-button-green", n = _T("pkgmgr", "pkgmgr_pkg_upgrade"), "running" === i.status && (s = _T("pkgmgr", "pkgmgr_pkg_update_available"), r = "#009E05"), g = "doing" === i.statusDesktop), d.start) {
                var h = d.start,
                    u = this._getInstalledStore().getById(h.package);
                u && (a = "repair", p = function() {
                    e._onStartPkg(u)
                }, c = u)
            } else if (d.redirect) this._isRepairableStoppedByDepLimit(i) && (a = "repair", p = function() {
                e._onClickRepairStoppedByDepLimit(i)
            });
            else if (d.repair || d.upgrade || d.forcereplaced) {
                var m = d.repair || d.upgrade || d.forcereplaced,
                    S = this._getAvalRecByChannel(m.package, m.beta);
                S && (p = function() {
                    e._applyVersionAndBetaCheck(S, function() {
                        var t = this;
                        this._applyFeasibilityCheck({
                            type: "install_check",
                            packages: [S.id]
                        }).then(function(e) {
                            e && t._onClickInstall(S)
                        })
                    }.createDelegate(e))
                }, SYNO.SDS.PkgManApp.Utils.Utils.isBrokenStatus(i) ? (a = "repair", "version_limit" === i.status && (s = _T("pkgmgr", "status_version_limit"), r = "#F58414"), "version_limit" === i.statusOrigin && (o = _T("pkgmgr", "broken_version_desc"))) : (a = "upgrade", o = String.format("{0}: {1}<br/>{2}", _T("pkgmgr", "pkgmgr_pkg_version"), S.get("version"), S.get("changelog"))), d.forcereplaced ? (o = S.data.replace_message, c = t) : c = S)
            }
            p || (l = "", g = !0, n = _T("pkgmgr", "status_installed"))
        }
        if (!this._HasAvailableOperation(i) && SYNO.SDS.PkgManApp.Utils.Utils.isBrokenStatus(i) && (l = "", g = !0, n = _T("pkgmgr", "status_installed"), s = i.statusTitle, "version_limit" === i.statusOrigin && this._isBuildPhaseGM() && !i.beta && this._hasNewVersion(i.id, !0) && (o = _T("pkgmgr", "broken_version_update_to_beta_desc"))), "queueing" === i.status && (r = "#057FEB", o = i.statusDescription, g = !1), "upgrading" === i.status && (l = "syno-ux-button-green", a = "upgrade", n = _T("pkgmgr", "pkgmgr_pkg_upgrade"), r = "#057FEB"), "repairing" === i.status && (l = "syno-pkg-button-repair syno-ux-button-orange", a = "repair", n = _T("pkgmgr", "repair"), r = "#057FEB"), "installing" === i.status && (l = "", a = "install", n = _T("common", "cancel"), r = "#057FEB"), "installing" === i.status || "upgrading" === i.status || "repairing" === i.status && !SYNO.SDS.PkgManApp.Utils.Utils.isBrokenStatus(i.statusOrigin)) {
            var _ = this._getAvalRecByChannel(t.data.id, t.data.installing_target.beta);
            o = _ ? "" == _.get("changelog") ? _.get("desc") : _.get("changelog") : t.get("desc")
        }
        i.pkgtarget && i.pkgtarget.is_broken && (o = String.format(_T("pkgmgr", "pkg_volume_broken_desc"), _T("volume", "storage_manager")), a = "", p = null, g = !0), t.data.operation = {
            action: a,
            actionText: n,
            statusText: s,
            statusColor: r,
            descriptionText: o,
            buttonClass: l,
            isInstalledInCurrentPage: !0,
            isButtonDisabled: g,
            targetRecord: c,
            actionFunction: p
        }
    },
    clearStatus: function(t, e) {
        var i = t.getById(e);
        void 0 !== i && ["dsm_apps", "status", "url", "broken_by"].forEach(function(t) {
            i.data[t] = ""
        }, this)
    },
    onActivate: function() {
        this.callParent(arguments)
    },
    onDeactivate: function() {
        this.isVisible() || clearInterval(this.instListPolling), this.callParent(arguments)
    },
    onClose: function() {
        if (this.isUpdating() && !window.confirm(_T("pkgmgr", "close_updateall_confirm"))) return !1;
        clearInterval(this.instListPolling), this.callParent(arguments)
    },
    getStore: function(t) {
        return this.stores[t]
    },
    startServerListCheckPolling: function() {
        this.serverListCheckPolling.start()
    },
    initStoreObjs: function() {
        this.synoObj = {
            blFirstLoadStore: !1
        }, this.otherObj = {
            blFirstLoadStore: !1
        }, this.betaObj = {
            blFirstLoadStore: !1
        }
    },
    onLoadPkgStore: function(t, e, i) {
        this.synoObj.store.getById(t) ? this.onLoadSynoPkgStore(e, i) : this.betaObj.store.getById(t) ? this.onLoadBetaPkgStore(e, i) : this.onLoadOtherPkgStore(e, i)
    },
    onLoadOtherPkgStore: function(t, e) {
        this.onLoadPkgStoreFn(this.otherObj, t, e)
    },
    onLoadSynoPkgStore: function(t, e) {
        this.onLoadPkgStoreFn(this.synoObj, t, e)
    },
    onLoadBetaPkgStore: function(t, e) {
        this.onLoadPkgStoreFn(this.betaObj, t, e)
    },
    onLoadPkgStoreFn: function(t, e, i) {
        !1 === i ? t.store.reload() : t.store.load({
            callback: i,
            scope: this
        })
    },
    createStore: function(t) {
        var e = t === this.synoObj,
            i = new Ext.data.Store({
                autoLoad: !1,
                autoDestroy: !1,
                remoteSort: !1,
                baseParams: {
                    blforcereload: !1,
                    blloadothers: !e
                },
                proxy: new SYNO.API.Proxy({
                    api: "SYNO.Core.Package.Server",
                    method: "list",
                    version: 2,
                    listeners: {
                        scope: this,
                        load: function(i, a) {
                            if (e) {
                                var n = {
                                    categories: [{
                                        id: "all",
                                        dname: this.helper.T("class_all")
                                    }].concat(a.categories)
                                };
                                SYNO.SDS.PkgManApp.Window.getStore("category").loadData(n), SYNO.SDS.PkgManApp.Window.getStore("beta").loadData(a), SYNO.SDS.PkgManApp.Window.getStore("banner").loadData(a)
                            }!t.blFirstLoadStore && e && (this.fireEvent("pollingserverlistcheck"), t.blFirstLoadStore = !0)
                        }
                    }
                }),
                reader: new Ext.data.JsonReader({
                    root: "packages",
                    id: "id"
                }, this.storeHelper.getServerStoreItem()),
                listeners: {
                    scope: this,
                    beforeLoad: this._onBeforeLoad,
                    exception: this._onExceptionLoad,
                    load: this._onAfterLoad
                }
            });
        return this.addManagedComponent(i), i
    },
    updateNotificationBubble: function() {
        var t = 0;
        this._getInstalledStore().each(function(e) {
            this._IsOperationRequired(e.data) && t++
        }, this), this.previousOperablePkgNum != t && (this.previousOperablePkgNum = t, t > 0 ? SYNO.SDS.PkgManApp.Window.setNotification("SYNO.SDS.PkgManApp.Installed.Panel", t) : SYNO.SDS.PkgManApp.Window.clearNotification("SYNO.SDS.PkgManApp.Installed.Panel"))
    },
    _onBeforeLoad: function(t, e) {
        Ext.isEmpty(e) || Ext.isEmpty(e.params) || (t.loading = !0)
    },
    _onAfterLoad: function(t, e, i) {
        var a = this;
        Ext.isEmpty(i) || (t.exception = !1, t.loading = !1, this.serverStoreFirstLoaded || (this._restartInstalledListPolling(), this.stores.installed.each(function(t) {
            a._setupInstalledOperationInfo(t)
        }), this.serverStoreFirstLoaded = !0))
    },
    _onExceptionLoad: function(t, e, i, a) {
        var n = a.params.blloadothers ? "community" : "stable";
        this.getStore(n).exception = !0
    },
    setCurrentPage: function() {
        this.toolBar.setCurrentPage.apply(this.toolBar, arguments)
    },
    jumpTo: function() {
        this.toolBar.jumpTo.apply(this.toolBar, arguments)
    },
    createStores: function() {
        this.stores = {}, this.stores.installed = this.storeHelper.createInstalledStore(), this.betaObj.store = this.stores.beta = this.storeHelper.createBetaStore(), this.stores.category = this.storeHelper.createCategoryStore(), this.stores.banner = this.storeHelper.createBannerStore(), this.synoObj.store = this.stores.stable = this.createStore(this.synoObj), this.otherObj.store = this.stores.community = this.createStore(this.otherObj)
    },
    isUpdating: function() {
        return !this._IsInsting_Background()
    },
    showTermDialog: function(t) {
        this.termDialog = new SYNO.SDS.PkgManApp.TermDialog({
            owner: this,
            curr_term_version: t ? t.curr_term_version : void 0
        }), t && t.hasOwnProperty("agreed_term_version") && t.curr_term_version == t.agreed_term_version || this.termDialog.show()
    },
    onBeforeSelect: function(t, e, i) {
        return !!this.blForceSelectPage || !(e.attributes.allowAdminOnly && !_S("is_admin")) && this.callParent(arguments)
    }
});
