/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.PkgManApp"), SYNO.SDS.PkgManApp.Config = {}, Ext.apply(SYNO.SDS.PkgManApp.Config, {
    RECOMMEND_LIST_BIG_NUMBER: 4,
    LIST_PKG_CELL_WIDTH: 152,
    SORT_MENU_WIDTH: 220,
    DEFAULT_CURRENCY: "USD",
    DEFICON_64: "images/package_center_64.png",
    DEFICON_256: "images/package_center_256.png",
    myDSRemindPassURL: "https://myds.synology.com/support/register_password_remind.php",
    myDSRegister: "https://myds.synology.com/support/register_form.php",
    agreed_tos_hash_key: "agreed_tos_hash",
    tos_hash_key: "tos_hash",
    tos_hash_timestamp_key: "tos_hash_timestamp"
}), SYNO.SDS.PkgManApp.SERVICE = {}, Ext.apply(SYNO.SDS.PkgManApp.SERVICE, {
    PKG_SERVICES_SSH: 1,
    PKG_SERVICES_PGSQL: 2
}), Ext.ns("SYNO.SDS.PkgManApp"), SYNO.SDS.PkgManApp.CustMyDSDialog = Ext.extend(SYNO.SDS.ModalWindow, {
    dsmStyle: "v5",
    _SYNOMyDSParams: {},
    constructor: function(t) {
        if (t = t || {}, this._SYNOMyDSObj = {
                _blSetTransparent: !1,
                _blInitMydsWrong: !1,
                timeoutDuration: 6e4,
                type: 0,
                appId: t.appId,
                params: {},
                blBuyItem: !1
            }, SYNO.SDS.Config.FnMap["SYNO.SDS.PkgManApp.MyDSDialog"]) {
            this._SYNOMyDSObj._iframeMyDSId = Ext.id();
            var e, s = function(t) {
                    try {
                        Ext.EventManager.removeAll(t), Ext.destroy(t), t = void 0
                    } catch (t) {}
                },
                i = function() {
                    var i = function(t, e) {
                            var s = "";
                            if (t && t.errinfo && t.errinfo.sec && t.errinfo.key && "myds_register" === t.errinfo.key) this.fireEvent("payfailed", this), this.close(), new SYNO.SDS.MyDSCenter.LoginDialog({
                                owner: this.owner
                            }).show();
                            else if (t && Ext.isObject(t.result) && !Ext.isEmpty(t.result.msg) && "badauth" !== t.result.code && "good" !== t.result.code) this.getMsgBox().alert(this.title, t.result.msg, function() {
                                this.fireEvent("payfailed", this), this.close()
                            }, this);
                            else if (t && Ext.isObject(t.result) && t.result.code) {
                                switch (t.result.code) {
                                    case "good":
                                        if (t.info && 0 === t.info.way) return this.fireEvent("payfailed", this), void this.close.defer(100, this);
                                        var i = function(t) {
                                            this.fireEvent("payevent", this, t), this.close()
                                        }.createDelegate(this);
                                        return t.result && !Ext.isEmpty(t.result.msg) ? this.getMsgBox().alert(this.title, t.result.msg, function(e) {
                                            "ok" === e ? i(t) : (this.fireEvent("payfailed", this), this.close())
                                        }, this) : i.defer(100, this, [t]), void(2 === this._SYNOMyDSObj.type && this._SYNOMyDSObj.appId && this.sendWebAPI({
                                            api: "SYNO.Core.Package.MyDS.Purchase",
                                            method: "save",
                                            version: 1,
                                            params: {
                                                appId: this._SYNOMyDSObj.appId
                                            }
                                        }));
                                    case "account_unverified":
                                        s = _T("pkgmgr", "myds_error_activate");
                                        break;
                                    case "badconn":
                                    case "badsys":
                                        s = _T("pkgmgr", "fail_connect_server");
                                        break;
                                    default:
                                        s = _T("pkgmgr", "myds_error_illegal"), SYNO.Debug(t)
                                }
                                this.getMsgBox().alert(this.title, s, function() {
                                    this.fireEvent("payfailed", this), this.close()
                                }, this)
                            } else t && t.errinfo && t.errinfo.sec && t.errinfo.key && (s = _T(t.errinfo.sec, t.errinfo.key)), this.getMsgBox().alert(this.title, s || String.format("{0} {1}", _T("pkgmgr", "system_error"), _T("pkgmgr", "contact_support_or_try_again")), function() {
                                this.fireEvent("payfailed", this), this.close()
                            }, this)
                        },
                        a = function t(a) {
                            if (a || (this.setTitle(" "), this.layout.setActiveItem(this.get("syno-myds-connect")), this.setStatusBusy()), this._SYNOMyDSObj._blMyDSIframeLoad) {
                                var n = this._SYNOMyDSObj.iframeDom ? this._SYNOMyDSObj.iframeDom : Ext.get(this._SYNOMyDSObj._iframeMyDSId).dom,
                                    o = Ext.isIE ? n.contentWindow.document : n.contentDocument || window.frames[n.id].document;
                                if (!o.blready) return this.clearStatusBusy(), void this.getMsgBox().alert(this.title, String.format("{0} {1}", _T("pkgmgr", "system_error"), _T("pkgmgr", "contact_support_or_try_again")), function() {
                                    this.fireEvent("payfailed", this), this.close()
                                }, this);
                                e = function(t, e, s) {
                                    var i = t.getElementById(e),
                                        a = i || t.createElement("iframe");
                                    return a.setAttribute("id", e), a.setAttribute("name", e), a.setAttribute("src", s), a.setAttribute("frameBorder", "0"), a.setAttribute("style", "background-color: transparent;border: 0px none; width: 100%; height: 100%;"), Ext.isIE8 && a.setAttribute("allowTransparency", "true"), a.style.setAttribute && a.style.setAttribute("cssText", "background-color: transparent;border: 0px none; width: 100%; height: 100%;"), i || t.body.appendChild(a), a
                                }(o, "myds_iframe", SYNO.SDS.PkgManApp.Config.myDSURL + "?d=" + (new Date).getTime());
                                var r = setTimeout(function() {
                                    if (s.call(this, e), !this.isDestroyed) {
                                        this.clearStatusBusy();
                                        var t = _T("pkgmgr", "fail_connect_to_buy");
                                        0 === this._SYNOMyDSObj.type ? this.getMsgBox().confirm(this.title, t, function(t) {
                                            "yes" === t && this._SYNOMyDSObj.type, this.fireEvent("payfailed", this), this.close()
                                        }, this) : this.getMsgBox().alert(this.title, t, function(t) {
                                            this.fireEvent("payfailed", this), this.close()
                                        }, this)
                                    }
                                }.createDelegate(this), this._SYNOMyDSObj.timeoutDuration);
                                Ext.EventManager.on(e, "load", function() {
                                    if (r)
                                        if (clearTimeout(r), r = null, this.isDestroyed) s.call(this, e);
                                        else {
                                            this.clearStatusBusy(), Ext.EventManager.on(window, "unload", function() {
                                                    s.call(this, e)
                                                }, this), this.mon(this, "beforeclose", function() {
                                                    s.call(this, e)
                                                }, this),
                                                function() {
                                                    this.isDestroyed || this.layout.activeItem !== this.get("syno-myds-login") && (this.maximize(), this.layout.setActiveItem(this.get("syno-myds-iframe")))
                                                }.defer(1e3, this), this._SYNOMyDSObj.blInitMsg || (this._SYNOMyDSObj.blInitMsg = !0, function(t, e) {
                                                    window.postMessage ? Ext.EventManager.on(t, "message", function(t) {
                                                        t.browserEvent.origin === SYNO.SDS.PkgManApp.Config.myPayBaseURL ? Ext.isString(t.browserEvent.data) ? i.call(this, Ext.decode(t.browserEvent.data), !0) : i.call(this, t.browserEvent.data, !0) : this.getMsgBox().alert(this.title, String.format("{0} {1}", _T("pkgmgr", "system_error"), _T("pkgmgr", "contact_support_or_try_again")), function() {
                                                            this.fireEvent("payfailed", this), this.close()
                                                        }, this)
                                                    }, this) : (this._SYNOMyDSObj.msgTask && !this._SYNOMyDSObj.msgTask.removed || (this._SYNOMyDSObj.msgTask = this.addTask({
                                                        interval: 500,
                                                        run: function() {
                                                            if (this.isDestroyed) this._SYNOMyDSObj.msgTask.stop();
                                                            else {
                                                                var t = e.location.hash,
                                                                    s = /^#?\d+&/;
                                                                t !== this._SYNOMyDSObj.last_hash && s.test(t) && (this._SYNOMyDSObj.last_hash = t, i.call(this, Ext.decode(decodeURIComponent(t.replace(s, ""))), !0), e.location.hash = "")
                                                            }
                                                        },
                                                        scope: this
                                                    }), this.mon(this, "beforeclose", function() {
                                                        this._SYNOMyDSObj._blMyDSIframeLoad && this._SYNOMyDSObj.msgTask && this._SYNOMyDSObj.msgTask.remove()
                                                    }, this)), this._SYNOMyDSObj.msgTask.start(!0))
                                                }.call(this, n.contentWindow, o)), this._SYNOMyDSParams = this._SYNOMyDSParams || {};
                                            var t = SYNO.Util.copy(this._SYNOMyDSParams);
                                            (function(t, e) {
                                                try {
                                                    window.postMessage ? t.postMessage(Ext.encode(e), SYNO.SDS.PkgManApp.Config.myPayBaseURL) : t.location.hash = "#" + (new Date).getTime() + "&" + Ext.encode(e)
                                                } catch (t) {
                                                    window.console
                                                }
                                            }).call(this, e.contentWindow, Ext.apply(Ext.apply(t, this.get("syno-myds-login").form.getValues()), this._SYNOMyDSObj.params))
                                        }
                                }, this, {
                                    single: !0
                                }), Ext.EventManager.on(e, "error", function() {
                                    r && (clearTimeout(r), r = null, this.isDestroyed ? s.call(this, e) : (this.clearStatusBusy(), Ext.EventManager.on(window, "unload", function() {
                                        s.call(this, e)
                                    }, this), this.mon(this, "beforeclose", function() {
                                        s.call(this, e)
                                    }, this), this.getMsgBox().alert(this.title, _T("pkgmgr", "fail_connect_server"), function() {
                                        this.fireEvent("payfailed", this), this.close()
                                    }, this)))
                                }, this, {
                                    single: !0
                                })
                            } else t.defer(100, this, [!0])
                        };
                    this.get("syno-myds-login").form.setValues(this._SYNOMyDSParams), Ext.isEmpty(this._SYNOMyDSObj._MyDSIdField.getValue()) ? (this.setStatusBusy(), this.sendWebAPI({
                        api: "SYNO.Core.Package.MyDS",
                        method: "get",
                        version: 1,
                        params: {
                            appId: t.appId || ""
                        },
                        callback: function(t, e) {
                            if (!this.isDestroyed)
                                if (this.clearStatusBusy(), t && Ext.isDefined(e)) Ext.apply(SYNO.SDS.PkgManApp.Config, e), Ext.apply(SYNO.SDS.PkgManApp.Config, {
                                    myPayBaseURL: e.myPayBaseURL
                                }), Ext.apply(SYNO.SDS.PkgManApp.Config, {
                                    myDSURL: SYNO.SDS.PkgManApp.Config.myPayBaseURL + "/api/purchase5_1.html"
                                }), delete e.ds_sn, this.get("syno-myds-login").form.setValues(e), a.call(this);
                                else if (Ext.isDefined(e) && 4571 == e.code) {
                                this.fireEvent("payfailed", this), this.close(), new SYNO.SDS.MyDSCenter.LoginDialog({
                                    owner: this.owner
                                }).show()
                            } else {
                                var s = _T("common", "error_system");
                                e.code && (s = SYNO.API.getErrorString(e.code)), this.getMsgBox().alert(this.title, s, function() {
                                    this.fireEvent("payfailed", this), this.close()
                                }, this)
                            }
                        },
                        scope: this
                    })) : a.call(this)
                };
            t.tools = t.tools || [], t.tools.push({
                id: "close",
                handler: function() {
                    this.fireEvent("payfailed", this), this.close()
                },
                scope: this
            }), t.items = t.items || [], t.items.push.apply(t.items, [{
                itemId: "syno-myds-connect",
                trackResetOnLoad: !0,
                xtype: "syno_formpanel",
                border: !1,
                items: [{
                    xtype: "container",
                    width: 450,
                    height: 260,
                    style: "display:table;height:300px;text-align:center;",
                    html: "<div class='syno-pkg-connect-text' style='display:table-cell;vertical-align:middle;'>" + '<table cellspacing="0" style="width: auto;margin: auto;"><tbody><tr><td><div class="syno-pkg-connect-icon"></div></td><td>&nbsp;' + _T("pkgmgr", "myds_connecting") + "</td></tr></tbody></table></div>"
                }]
            }, {
                itemId: "syno-myds-iframe",
                xtype: "container",
                html: String.format('<iframe id="{0}" src="{1}" frameborder="0" allowTransparency="true" style="background-color: transparent;border: 0px none; width: 100%; height: 100%;"></iframe>', this._SYNOMyDSObj._iframeMyDSId, Ext.urlAppend(SYNO.API.currentManager.getBaseURL("SYNO.Core.Package.FakeIFrame", "get", 1))),
                listeners: {
                    scope: this,
                    single: !0,
                    afterlayout: function(t) {
                        var i = this._SYNOMyDSObj.iframeDom ? this._SYNOMyDSObj.iframeDom : Ext.get(this._SYNOMyDSObj._iframeMyDSId).dom;
                        Ext.EventManager.on(i, "load", function() {
                            this.isDestroyed ? s.call(this, e) : (Ext.EventManager.on(window, "unload", function() {
                                s.call(this, i)
                            }, this), this.mon(this, "beforeclose", function() {
                                s.call(this, i)
                            }, this), this._SYNOMyDSObj._blMyDSIframeLoad = !0)
                        }, this), Ext.EventManager.on(i, "error", function() {
                            this.isDestroyed ? s.call(this, e) : (Ext.EventManager.on(window, "unload", function() {
                                s.call(this, i)
                            }, this), this.mon(this, "beforeclose", function() {
                                s.call(this, i)
                            }, this), this._SYNOMyDSObj._blMyDSIframeLoad = !0)
                        }, this)
                    }
                }
            }, {
                hidden: !0,
                itemId: "syno-myds-login",
                trackResetOnLoad: !0,
                xtype: "syno_formpanel",
                border: !1,
                items: [{
                    xtype: "hidden",
                    name: "serial"
                }, {
                    xtype: "hidden",
                    name: "language",
                    value: _S("lang")
                }, {
                    xtype: "hidden",
                    name: "ds_timezone"
                }, {
                    xtype: "hidden",
                    name: "ds_unique"
                }, {
                    xtype: "hidden",
                    name: "ds_major"
                }, {
                    xtype: "hidden",
                    name: "ds_minor"
                }, {
                    xtype: "hidden",
                    name: "ds_build"
                }, this._SYNOMyDSObj._MyDSIdField = new Ext.form.Hidden({
                    xtype: "hidden",
                    name: "myds_id"
                }), {
                    xtype: "hidden",
                    name: "auth_key"
                }],
                listeners: {
                    scope: this,
                    activate: function() {
                        this._SYNOMyDSObj.blBuyItem && i.call(this)
                    }
                }
            }]), Ext.each(t.items, function(t) {
                t.tools = [{
                    id: "close",
                    handler: function() {
                        this.fireEvent("payfailed", this), this.close()
                    },
                    scope: this
                }]
            }, this), SYNO.SDS.PkgManApp.CustMyDSDialog.superclass.constructor.call(this, Ext.apply(t, {
                title: t.title || this.title || _T("pkgmgr", "myds_title"),
                cls: "syno-pkg-myds-dailog " + (t.cls || ""),
                layout: "card",
                resizable: !1,
                useStatusBar: !1,
                modal: !0,
                constrain: !0,
                constrainHeader: !0,
                renderTo: document.body
            })), Ext.EventManager.onWindowResize(this.center, this), this.mon(this, "beforeshow", function() {
                return !Ext.isIE6 && !Ext.isIE7 || (window.alert(_T("pkgmgr", "upgrade_ie_browser")), !1)
            }, this), this.mon(this, "afterlayout", this.center, this), this.mon(this, "beforeclose", function() {
                Ext.EventManager.removeResizeListener(this.center, this)
            }, this), this.mon(this, "show", function() {
                this.maskEl.addClass("syno-pkg-myds-mask")
            }, this, {
                single: !0
            }), Ext.apply(this._SYNOMyDSObj, {
                type: t.type || 0
            }), Ext.apply(this._SYNOMyDSObj, {
                timeoutDuration: (this._SYNOMyDSObj.type, 6e4)
            }), t.myds_params && (Ext.apply(this._SYNOMyDSParams, t.myds_params || {}), this.get("syno-myds-login").form.setValues(t.myds_params), i.call(this)), Ext.isEmpty(this._SYNOMyDSObj._MyDSIdField.getValue()) && this.mon(this, "beforeshow", function() {
                this.setStatusBusy(), this.sendWebAPI({
                    api: "SYNO.Core.Package.MyDS",
                    method: "get",
                    version: 1,
                    params: {
                        appId: t.appId || ""
                    },
                    callback: function(t, e) {
                        if (!this.isDestroyed)
                            if (this.clearStatusBusy(), t && Ext.isDefined(e)) Ext.apply(SYNO.SDS.PkgManApp.Config, e), Ext.apply(SYNO.SDS.PkgManApp.Config, {
                                myPayBaseURL: e.myPayBaseURL
                            }), Ext.apply(SYNO.SDS.PkgManApp.Config, {
                                myDSURL: SYNO.SDS.PkgManApp.Config.myPayBaseURL + "/api/purchase5_1.html"
                            }), delete e.ds_sn, this.get("syno-myds-login").form.setValues(e), this.layout.activeItem === this.get("syno-myds-login") && i.call(this);
                            else if (Ext.isDefined(e) && 4571 == e.code) {
                            this.fireEvent("payfailed", this), this.close(), new SYNO.SDS.MyDSCenter.LoginDialog({
                                owner: this.owner
                            }).show()
                        } else {
                            var s = _T("common", "error_system");
                            e.code && (s = SYNO.API.getErrorString(e.code)), this.getMsgBox().alert(this.title, s, function() {
                                this.fireEvent("payfailed", this), this.close()
                            }, this)
                        }
                    },
                    scope: this
                })
            })
        }
    },
    _onGoMyDS: function(t) {
        if ((t = t || {}) && t.appId && (this._SYNOMyDSObj.appId = t.appId), this._SYNOMyDSObj.appId) {
            if (Ext.isEmpty(this._SYNOMyDSObj._MyDSIdField.getValue())) return this.fireEvent("payfailed", this), this.close(), void new SYNO.SDS.MyDSCenter.LoginDialog({
                owner: this.owner
            }).show();
            this._SYNOMyDSObj.type = 2, this._SYNOMyDSObj.blBuyItem = !0, this._SYNOMyDSObj.timeoutDuration = 6e4, Ext.apply(this._SYNOMyDSObj.params, t || {}), this.layout.setActiveItem(this.get("syno-myds-login"))
        } else SYNO.Debug("Can't get appId")
    },
    center: function() {
        var t = this.el.getAlignToXY(Ext.getBody(), "c-c");
        return this.setPagePosition(t[0], t[1]), this
    }
}), 
/**
 * @class SYNO.SDS.PkgManApp.MyDSDialog
 * @extends SYNO.SDS.PkgManApp.CustMyDSDialog
 * PkgMan MyDS dialog class
 *
 */
SYNO.SDS.PkgManApp.MyDSDialog = Ext.extend(SYNO.SDS.PkgManApp.CustMyDSDialog, {
    constructor: function(t) {
        Ext.apply(this, t), SYNO.SDS.PkgManApp.MyDSDialog.superclass.constructor.call(this, Ext.apply(t, {
            dsmStyle: "v5",
            resizable: !1,
            width: 480,
            height: 330,
            border: !1,
            activeItem: 0,
            layout: "card"
        }))
    }
});
