/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.Share.CustomColumn
 * @extends SYNO.ux.EnableColumn
 * Share custom column class
 *
 */
Ext.define("SYNO.SDS.Share.CustomColumn", {
    extend: "SYNO.ux.EnableColumn",
    constructor: function(e) {
        var i = Ext.apply({
            header: _T("share", "share_permission_acl"),
            shareRecord: void 0,
            ownerGrid: void 0,
            userId: void 0,
            applyCallback: void 0,
            applyTarget: this,
            width: 120,
            align: "center",
            disableSelectAll: !0,
            renderer: function(e, i, t) {
                var r = this.shareRecord ? this.shareRecord.data : t.data,
                    s = !1;
                return s = Ext.isFunction(this.ownerGrid.isAdminGroupMember) ? this.ownerGrid.isAdminGroupMember() : Ext.isDefined(this.ownerGrid.owner.isAdminGroup) ? this.ownerGrid.owner.isAdminGroup : t.get("is_admin"), SYNO.SDS.ControlPanel.Share.isCustomizable(r) && !s || (e = "disabled"), SYNO.SDS.Share.renderCheckBox.call(this, e, i, t)
            }
        }, e);
        this.callParent([i])
    },
    onCellClick: function(e, i, t) {
        if (this.isLockCustomSetting) return void this.ownerGrid.owner.getMsgBox().alert(this.title, _T("user", "lock_setting"));
        if (!(Ext.isFunction(e.isAdminGroupMember) ? e.isAdminGroupMember() : Ext.isDefined(e.owner.isAdminGroup) ? e.owner.isAdminGroup : e.getSelectionModel().getSelected().get("is_admin"))) {
            if (Ext.isFunction(this.ownerGrid.isChanged) && Ext.isFunction(this.ownerGrid.getWebAPI) && Ext.isFunction(this.ownerGrid.getShareInfoForS2S) || SYNO.Debug('One of "isChanged" and "getWebAPI" and "getShareInfoForS2S" is missing!'), !Ext.isFunction(this.ownerGrid.isChanged) || !Ext.isFunction(this.ownerGrid.getWebAPI) || !this.ownerGrid.isChanged()) return void this.initEditorDialog(e, i);
            this.ownerGrid.owner.getMsgBox().confirm(this.ownerGrid.title, _T("share", "share_save_chg_before_reload"), function(t) {
                if ("yes" === t) {
                    var r = this.ownerGrid.getWebAPI();
                    if (0 === r.length) return SYNO.Debug("Permission is changed but getWebAPI returns nothing!"), void this.initEditorDialog(e, i);
                    var s = Ext.apply(r[0], {
                        scope: this,
                        callback: function(t, r, s, n) {
                            this.owner.clearStatusBusy(), t ? (this.ownerGrid.getStore().commitChanges(), this.initEditorDialog(e, i)) : this.owner.getMsgBox().alert(this.ownerGrid.title, SYNO.API.Erros.core[r.code] || _T("common", "commfail"))
                        }
                    });
                    SYNO.SDS.Utils.S2S.confirmIfSyncShareAffected(!1, this.ownerGrid.getShareInfoForS2S(), {
                        dialogTitle: this.ownerGrid.title,
                        dialogMsg: _T("s2s", "s2s_warn_share_change_priv"),
                        dialogOwner: this.owner,
                        continueHandler: function() {
                            this.owner.setStatusBusy({
                                text: _T("common", "saving")
                            }), this.owner.sendWebAPI(s)
                        },
                        abortHandler: Ext.EmptyFn,
                        scope: this
                    })
                }
            }, this)
        }
    },
    initEditorDialog: function(e, i) {
        var t = this.shareRecord ? this.shareRecord : e.getSelectionModel().getSelected();
        if (Ext.isObject(t) && t.data && SYNO.SDS.ControlPanel.Share.isCustomizable(t.data)) {
            if (t = t.data, this.userId) return void this.launchEditorDialog(t);
            this.owner.sendWebAPI({
                api: "SYNO.Core.User",
                version: 1,
                method: "get",
                params: {
                    name: this.owner._S("user")
                },
                scope: this,
                callback: function(e, i, r, s) {
                    e ? (this.userId = i.users[0].uid, this.launchEditorDialog(t)) : this.owner.getMsgBox().alert(_T("tree", "leaf_user"), _T("user", "failed_load_user"))
                }
            })
        }
    },
    launchEditorDialog: function(e) {
        var i = e.vol_path || e.share_path.replace("/" + e.name, ""),
            t = new SYNO.SDS.Share.PropertyDialog({
                title: String.format(_T("share", "share_edit_title"), e.name),
                module: this.module,
                owner: this.owner,
                hideAdvPermPanel: !0,
                hideInfoPanel: !0,
                privilegeType: "aclPrivilege",
                userId: this.userId,
                openConfig: this.ownerGrid.getOpenConfig(),
                source: "remote",
                rec: [new Ext.data.Record({
                    name: e.name,
                    is_aclmode: e.is_aclmode,
                    isshare: !0,
                    is_sync_share: e.is_sync_share,
                    isdir: !0,
                    vol_path: i,
                    real_path: e.share_path,
                    filename: e.name,
                    file_id: "/" + e.name
                })]
            });
        t.mon(t, "callback", this.onSaveProperty, this, {
            single: !0
        }), t.load()
    },
    onSaveProperty: function(e, i, t) {
        function r(e, i) {
            var t = _T("property", "error_save_property");
            return !e && (Ext.isDefined(i.code) && (t = SYNO.API.getErrorString(i.code)), this.owner.getMsgBox().alert(_T("filetable", "filetable_properties"), t), !0)
        }
        if (!r.call(this, i, t) && Ext.isDefined(t.task_id)) {
            this.owner.setStatusBusy({
                text: _T("common", "saving")
            });
            var s = this.owner.pollReg({
                webapi: {
                    api: "SYNO.Core.ACL",
                    method: "status",
                    version: 1,
                    params: {
                        task_id: t.task_id
                    }
                },
                interval: 3,
                immediate: !0,
                status_callback: function(e, i, t) {
                    (!e || e && !0 === i.finished) && (this.owner.pollUnreg(s), this.owner.clearStatusBusy(), Ext.isFunction(this.applyCallback) && Ext.isObject(this.applyTarget) && this.applyCallback.call(this.applyTarget), r.call(this, e, i))
                },
                scope: this
            })
        }
    }
});
