/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function _templateObject() {
    var e = _taggedTemplateLiteral(['\n\t\t<tpl for=".">\n\t\t\t<div class="acl-combo-list-item x-combo-list-item x-form-check-wrap syno-ux-form-check-wrap {[values.disable?"x-item-disabled":""]}" >\n\t\t\t\t<input type="checkbox" class="syno-ux-checkbox-icon x-form-checkbox x-form-field" {[values.check?"checked":""]} value="{[values.state]}"/>\n\t\t\t\t<div class="syno-ux-checkbox-icon {[values.check ? "syno-ux-cb-checked" : ""]} {[values.disable ? "syno-ux-cb-disabled" : ""]}">\n\t\t\t\t</div>\n\t\t\t\t<span class="syno-ux-checkbox-label">{state}</span>\n\t\t\t</div>\n\t\t</tpl>\n\t']);
    return _templateObject = function() {
        return e
    }, e
}

function _taggedTemplateLiteral(e, t) {
    return t || (t = e.slice(0)), Object.freeze(Object.defineProperties(e, {
        raw: {
            value: Object.freeze(t)
        }
    }))
}

function _slicedToArray(e, t) {
    return _arrayWithHoles(e) || _iterableToArrayLimit(e, t) || _nonIterableRest()
}

function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance")
}

function _iterableToArrayLimit(e, t) {
    var i = [],
        s = !0,
        r = !1,
        o = void 0;
    try {
        for (var a, n = e[Symbol.iterator](); !(s = (a = n.next()).done) && (i.push(a.value), !t || i.length !== t); s = !0);
    } catch (e) {
        r = !0, o = e
    } finally {
        try {
            s || null == n.return || n.return()
        } finally {
            if (r) throw o
        }
    }
    return i
}

function _arrayWithHoles(e) {
    if (Array.isArray(e)) return e
}

function _typeof(e) {
    return (_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
        return typeof e
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    })(e)
}
Ext.namespace("SYNO.SDS.ControlPanel.Share"), Ext.apply(SYNO.SDS.ControlPanel.Share, {
    MAX_ITEMS_PER_PAGE: 50,
    URL_SHAREMAN_HANDLE: "modules/shareman.cgi",
    SHARE_INFO: 1,
    SHARE_PERMISSION: 2,
    NFS_PRIVILEGE: 3,
    isHomes: function(e) {
        return "homes" === e.toLowerCase()
    },
    isGlusterVol: function(e) {
        return "G" === e[0]
    },
    passLenValidator: function(e) {
        return !(!this.getItemCt || !this.getItemCt() || this.getItemCt().isDisplayed()) || (-1 !== e.indexOf("=") || -1 !== e.indexOf(",") || -1 !== e.indexOf(":") ? _T("error", "error_bad_field") : e.length < 8 ? String.format(_T("error", "error_passlen"), "8") : !(e.length > 64) || String.format(_T("error", "error_passlen_too_long"), "64"))
    },
    passDecryptValidator: function(e) {
        return !(!this.getItemCt || !this.getItemCt() || this.getItemCt().isDisplayed()) || (-1 !== e.indexOf("=") || -1 !== e.indexOf(",") ? _T("error", "error_bad_field") : e.length < 8 ? String.format(_T("error", "error_passlen"), "8") : !(e.length > 64) || String.format(_T("error", "error_passlen_too_long"), "64"))
    },
    getShareRecordInstance: function(e) {
        return new(Ext.data.Record.create([{
            name: "name",
            mapping: "name"
        }, {
            name: "name_org",
            mapping: "name"
        }, {
            name: "description",
            mapping: "description"
        }, {
            name: "is_hidden",
            mapping: "is_hidden"
        }, {
            name: "is_disable_list",
            mapping: "is_disable_list"
        }, {
            name: "is_disable_modify",
            mapping: "is_disable_modify"
        }, {
            name: "is_disable_download",
            mapping: "is_disable_download"
        }, {
            name: "encryption",
            mapping: "encryption"
        }, {
            name: "enc_passwd",
            mapping: "enc_passwd"
        }, {
            name: "enc_auto_mount",
            mapping: "enc_auto_mount"
        }, {
            name: "vol_id",
            mapping: "vol_id"
        }]))(e)
    },
    getNFSRuleRecordInstance: function(e) {
        return new(Ext.data.Record.create([{
            name: "host_position"
        }, {
            name: "access_right"
        }, {
            name: "root_mapping"
        }, {
            name: "async"
        }]))(e)
    },
    ExportKeyIframe: function(e, t) {
        var i = t.getAbsoluteURL(SYNO.SDS.ControlPanel.Share.URL_SHAREMAN_HANDLE) + "?action=exportkey&sharename=" + e,
            s = document.getElementById("syno-frame-exportkey");
        i = Ext.urlAppend(i), s ? s.src = i : s = Ext.DomHelper.append(document.body, {
            tag: "iframe",
            id: "syno-frame-exportkey",
            frameBorder: 0,
            width: 0,
            height: 0,
            css: "display: none; visibility: hidden; height: 1px;",
            src: i
        })
    },
    VolumeRender: function(e) {
        return "usb" === e ? _T("status", "status_usb") : "sata" === e ? _T("status", "status_sata") : "G" === e[0] ? _T("status", "status_gluster") : SYNO.SDS.ControlPanel.Share.VolIDRender(e)
    },
    VolIDRender: function(e) {
        var t = SYNO.SDS.ControlPanel.Share.ParseID(e);
        return "ebox" == t.location ? String.format("{0} {1} ({2})", _T("volume", "volume"), t.id, _T("volume", "volume_disk_source_ebox")) : String.format("{0} {1}", _T("volume", "volume"), t.id)
    },
    ParseID: function(e) {
        var t = {
            id: 0,
            location: ""
        };
        return isNaN(e) && "X" == e.charAt(0) ? (t.id = e.substring(1), t.location = "ebox") : (t.id = e, t.location = "internal"), t
    },
    isCustomizable: function(e) {
        return !0 === e.is_aclmode && 1 !== e.encryption
    }
}), Ext.define("SYNO.SDS.Share.Permission.SearchField", {
    extend: "SYNO.ux.SearchField",
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = {
            itemIdPrefix: "filter_",
            iconStyle: "search",
            itemId: "search",
            emptyText: _T("share", "share_filter_text"),
            width: 180,
            queryParam: "substr",
            currentFilter: "all"
        };
        return Ext.apply(t, e), t
    },
    getSearchText: function() {
        return this.getValue()
    },
    getMenu: function() {
        if (this.menu) return this.menu;
        var e = [];
        return e.push({
            text: _T("common", "show_all"),
            checked: !1,
            itemId: this.itemIdPrefix + "all",
            checkHandler: this.setSearchFilter
        }), e.push({
            text: _T("share", "share_permission_any"),
            checked: !1,
            itemId: this.itemIdPrefix + "any",
            checkHandler: this.setSearchFilter
        }), e.push({
            text: _T("share", "share_permission_none"),
            checked: !1,
            itemId: this.itemIdPrefix + "deny",
            checkHandler: this.setSearchFilter
        }), e.push({
            text: _T("share", "share_permission_writable"),
            checked: !1,
            itemId: this.itemIdPrefix + "writable",
            checkHandler: this.setSearchFilter
        }), e.push({
            text: _T("share", "share_permission_readonly"),
            checked: !1,
            itemId: this.itemIdPrefix + "readonly",
            checkHandler: this.setSearchFilter
        }), this.hideCustom || e.push({
            text: _T("share", "share_permission_acl"),
            checked: !1,
            itemId: this.itemIdPrefix + "custom",
            checkHandler: this.setSearchFilter
        }), this.menu = new SYNO.ux.Menu({
            defaults: {
                group: "permission_type",
                scope: this
            },
            items: e,
            cls: "syno-ux-check-menu",
            listeners: {
                scope: this,
                beforeshow: function(e) {
                    e.items.get(this.itemIdPrefix + this.getSearchFilter()).setChecked(!0)
                }
            }
        })
    },
    setSearchFilter: function(e) {
        var t = e.itemId.substr(this.itemIdPrefix.length);
        t !== this.currentFilter && (this.currentFilter = t, this.fireEvent("filterChanged", this.currentFilter))
    },
    getSearchFilter: function() {
        return this.currentFilter || "all"
    },
    removeItemFromMenu: function(e) {
        this.menu.remove(this.itemIdPrefix + e)
    }
}), Ext.namespace("SYNO.SDS.Share"), SYNO.SDS.Share.renderCheckBox = function(e, t, i) {
    var s = "disabled" === e ? "disabled" : e ? "checked" : "unchecked",
        r = "disabled" !== s && "checked" === s,
        o = i ? i.id + "_" + this.dataIndex : Ext.id(),
        a = "disabled" === s ? _T("common", "disabled") : _JSLIBSTR("uicommon", "enable_column_" + s),
        n = "disabled" === s;
    return t = t || {}, t.cellAttr = String.format('aria-label="{0} {1}" aria-checked="{2}" aria-disabled="{3}" role="checkbox"', Ext.util.Format.stripTags(this.orgHeader), a, r, n), String.format('<div class="syno-ux-grid-enable-column-{0}" id="{1}"></div>', s, o)
}, Ext.define("SYNO.SDS.Share.InfoColumn", {
    extend: "Ext.grid.Column",
    constructor: function(e) {
        var t = Ext.apply({
            header: " ",
            width: 30,
            align: "center",
            renderer: function(e) {
                return e ? String.format('<div class="syno-ux-whitetip-icon" ext:wtip="{0}" draggable="false" ext:wwidth="" ext:iclass="wtip-text-wrapper"></div>', _T("share", "share_permission_complicated")) : ""
            }
        }, e);
        this.callParent([t])
    }
}), Ext.define("SYNO.SDS.Share.ShareGrid", {
    extend: "SYNO.ux.GridPanel",
    DEFAULT_ROLES: [
        ["system", _T("share", "share_system_user")],
        ["local_user", _T("share", "share_local_user")]
    ],
    GROUP_ROLES: [
        ["local_group", _T("share", "share_local_group")]
    ],
    DOMAIN_ROLES: [
        ["domain_user", _T("share", "share_domain_user")],
        ["domain_group", _T("share", "share_domain_group")]
    ],
    LDAP_ROLES: [
        ["ldap_user", _T("share", "ldap_user")],
        ["ldap_group", _T("share", "ldap_group")]
    ],
    constructor: function(e) {
        this.pollingId = void 0, this.pageSize = 50, this.store = this.createStore(e), this.showHomesWarning = !0;
        var t = {
            header: _T("share", "share_permission_readonly"),
            dataIndex: "is_readonly",
            id: "is_readonly",
            disableSelectAll: !0,
            width: 120
        };
        e.isAdvancedMode || (t = Ext.apply(t, {
            isIgnore: function(e, t) {
                return t.get("is_admin") && this.isAclMode
            },
            renderer: function(e, t, i) {
                var s = this.scope;
                return i.get("is_admin") && s.isAclMode && (e = "disabled"), SYNO.SDS.Share.renderCheckBox.call(this, e, t, i)
            }
        })), this.colRo = new SYNO.ux.EnableColumn(t), this.colRw = new SYNO.ux.EnableColumn({
            header: _T("share", "share_permission_writable"),
            dataIndex: "is_writable",
            id: "is_writable",
            disableSelectAll: !0,
            width: 120
        }), this.colNa = new SYNO.ux.EnableColumn({
            header: _T("share", "share_permission_none"),
            dataIndex: "is_deny",
            id: "is_deny",
            disableSelectAll: !0,
            width: 120
        });
        var i = [this.colNa, this.colRw, this.colRo],
            s = [this.colRo, this.colRw, this.colNa];
        e.colCu && (this.colCu = e.colCu, i.push(this.colCu), s.push(this.colCu)), this.isShowPreview = e.isShowPreview, this.isShowPreview && (this.colInherit = new Ext.grid.Column({
            header: _T("share", "share_inherit"),
            id: "inherit",
            dataIndex: "inherit",
            align: "left",
            useHtmlEncodeRender: !1,
            width: 120,
            renderer: SYNO.SDS.AdminCenter.Share.Utils.colorizePermission
        }), i.unshift(this.colInherit), this.colPreview = new Ext.grid.Column({
            header: _T("share", "share_preview"),
            id: "preview",
            dataIndex: "preview",
            align: "left",
            useHtmlEncodeRender: !1,
            width: 120
        }), i.unshift(this.colPreview)), i.unshift({
            id: "name",
            header: _T("share", "share_name"),
            dataIndex: "name",
            width: 100,
            align: "left",
            renderer: function(e, t) {
                return "ftp" === e.toLowerCase() ? "Anonymous FTP/Presto/WebDAV" : e
            }
        });
        var r = Ext.apply({
            title: _T("share", "share_rights"),
            layout: "fit",
            cls: "without-dirty-red-grid",
            store: this.store,
            width: 720,
            height: 440,
            autoExpandMax: 160,
            autoExpandMin: 160,
            autoExpandColumn: "name",
            enableColumnMove: !1,
            enableHdMenu: !1,
            hideMode: "offsets",
            colModel: new Ext.grid.ColumnModel({
                defaults: {
                    align: "center"
                },
                columns: i
            }),
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: !0
            }),
            plugins: s,
            tbar: this.createTopToolbar(e),
            bbar: new SYNO.ux.PagingToolbar({
                store: e.store || this.store,
                pageSize: this.pageSize,
                displayInfo: !0
            })
        }, e);
        this.callParent([r]), this.mon(this, "cellclick", this.onGridCellClick, this), this.mon(this, "afterlayout", function(e, t) {
            this.mon(this.getSelectionModel(), "spacepressed", this.onGridCellSpacePressed, this)
        }, this, {
            single: !0
        }), this.mon(this, "afterlayout", function(e, t) {
            e.getView().updateScroller()
        }, this), this.mon(this.nameFilter, "filterChanged", this.onTypeFilterChange, this), this.mon(this.colNa, "click", function(e, t, i, s) {
            var r = t.getStore().getAt(i);
            this.showHomesWarning && "homes" === this.shareRecord.get("name").toLowerCase() && !0 === this.shareRecord.get("is_aclmode") && !0 === r.get("is_deny") && (this.owner.getMsgBox().alert(this.title, _T("share", "warn_deny_rule_homes")), this.showHomesWarning = !1)
        }, this), this.groupsOfDelegatedUser = [], _S("is_admin") || this.sendWebAPI({
            api: "SYNO.Core.User",
            version: 1,
            method: "get",
            params: {
                name: _S("user"),
                additional: ["member_of"]
            },
            scope: this,
            callback: function(e, t, i) {
                if (!e) return void this.owner.getMsgBox().alert(this.title, SYNO.API.Errors.core[t.code] || _T("common", "commfail"));
                t.users && t.users[0].member_of && (this.groupsOfDelegatedUser = t.users[0].member_of)
            }
        })
    },
    createStore: function(e) {
        return new SYNO.API.JsonStore({
            autoDestroy: !0,
            remoteSort: !0,
            appWindow: e.owner,
            api: "SYNO.Core.Share.Permission",
            method: "list",
            version: 1,
            baseParams: {
                offset: 0,
                limit: this.pageSize,
                is_unite_permission: e.isAdvancedMode || !1,
                with_inherit: e.isShowPreview || !1
            },
            listeners: {
                exception: {
                    scope: this,
                    fn: this.onStoreException
                },
                beforeload: {
                    scope: this,
                    fn: this.onBeforeLoad
                },
                load: {
                    scope: this,
                    fn: this.onLoad
                }
            },
            root: "items",
            idProperty: "name",
            totalProperty: "total",
            fields: ["name", "is_writable", "is_readonly", "is_deny", "is_custom", "is_admin", "inherit", {
                name: "preview",
                persist: !1
            }]
        })
    },
    getFinalPermission: function(e) {
        return "na" === e.data.inherit ? "na" : "cu" === e.data.inherit ? e.data.is_deny ? "na" : "cu" : "rw" === e.data.inherit ? e.data.is_deny ? "na" : e.data.is_custom ? "cu" : "rw" : e.data.is_deny ? "na" : e.data.is_custom ? "cu" : e.data.is_writable ? "rw" : "-" !== e.data.inherit || e.data.is_readonly ? e.data.is_admin && e.data.is_aclmode ? "rw" : "ro" : "na"
    },
    checkPreview: function(e) {
        e.data.preview = SYNO.SDS.AdminCenter.Share.Utils.colorizePermission(this.getFinalPermission(e)), this.getView().refreshRow(e)
    },
    checkPreviewAll: function() {
        this.getStore().each(function(e) {
            this.checkPreview(e)
        }, this)
    },
    createTopToolbar: function(e) {
        var t = new SYNO.ux.Toolbar({
            items: [{
                xtype: "syno_combobox",
                itemId: "roleFilter",
                valueField: "role",
                displayField: "display",
                store: {
                    xtype: "arraystore",
                    autoDestroy: !0,
                    fields: ["role", "display"]
                },
                mode: "local",
                triggerAction: "all",
                editable: !1,
                forceSelection: !0,
                width: 260,
                listeners: {
                    beforeselect: {
                        scope: this,
                        fn: this.onRoleFilterSelect
                    }
                }
            }, "->", {
                xtype: "syno_displayfield",
                value: _T("helptoc", "directory_service_domain") + ": ",
                hidden: !0,
                width: 85,
                itemId: "domainListLabel"
            }, {
                xtype: "syno_combobox",
                itemId: "domainFilter",
                valueField: "value",
                displayField: "domain",
                store: {
                    xtype: "arraystore",
                    autoDestroy: !0,
                    fields: ["domain", "value", "comment"]
                },
                hidden: !0,
                width: 150,
                resizable: !0,
                mode: "local",
                triggerAction: "all",
                editable: !1,
                value: "",
                forceSelection: !0,
                tpl: '<tpl for="."><div ext:qtip="{comment}" class="x-combo-list-item">{domain}</div></tpl>',
                listeners: {
                    beforeselect: {
                        scope: this,
                        fn: this.onDomainFilterSelect
                    }
                }
            }, this.nameFilter = new SYNO.SDS.Share.Permission.SearchField({
                owner: this,
                appWin: this.appWin,
                pageSize: this.pageSize,
                store: this.store,
                hideCustom: e.hideCustomColumn
            })]
        });
        return this.roleFilter = t.getComponent("roleFilter"), this.domainFilter = t.getComponent("domainFilter"), this.domainListLabel = t.getComponent("domainListLabel"), t
    },
    onGridCellSpacePressed: function(e, t) {
        var i = e.grid,
            s = i.getStore(),
            r = s.indexOf(e.getSelected()),
            o = e.getColIdx();
        0 <= o && this.onGridCellClick(i, r, o, t)
    },
    onGridCellClick: function(e, t, i, s) {
        var r = e.getStore().getAt(t),
            o = e.getColumnModel().getDataIndex(i);
        if (!_S("is_admin") && "is_deny" === o && r.getChanges().hasOwnProperty("is_deny") && -1 != this.roleFilter.getValue().search("group") && -1 != this.groupsOfDelegatedUser.indexOf(r.id) && !0 === r.get("is_deny") && this.owner.getMsgBox().alert(this.title, String.format(_T("delegation", "warn_denied_access"), r.get("name"), _T("share", "share_permission_none"), this.shareRecord.get("name"))), !_S("is_admin") && "is_writable" === o && r.getChanges().hasOwnProperty("is_writable") && !1 === this.shareRecord.get("user_priv_rw") && !0 === r.get("is_writable")) return r.set("is_writable", !1), e.colRw.checkSelectAll(e.getStore()), void this.owner.getMsgBox().alert(this.title, _T("error", "error_privilege_not_enough"));
        if (function(e) {
                return "is_readonly" === e || "is_writable" === e || "is_deny" === e
            }(o))
            if (!0 === r.get(o)) ! function(e, t, i) {
                "is_readonly" !== e && (t.set("is_readonly", !1), i.colRo.checkSelectAll(i.getStore())), "is_writable" !== e && (t.set("is_writable", !1), i.colRw.checkSelectAll(i.getStore())), "is_deny" !== e && (t.set("is_deny", !1), i.colNa.checkSelectAll(i.getStore())), "is_custom" !== e && t.set("is_custom", !1)
            }(o, r, e);
            else {
                var a = r.getChanges();
                a.hasOwnProperty("is_custom") && r.set("is_custom", !a.is_custom)
            } this.isShowPreview && this.checkPreview(r)
    },
    isChanged: function() {
        return 0 !== this.store.getModifiedRecords().length
    },
    getShareInfoForS2S: function() {
        return {
            name: this.shareRecord.get("name"),
            is_sync_share: this.shareRecord.get("is_sync_share"),
            permissions: this.getModifiedPermissions(),
            no_check_permission: !1
        }
    },
    getModifiedPermissions: function() {
        var e = this.getWebAPI(),
            t = [];
        return 1 === e.length && Ext.each(e[0].params.permissions, function(e) {
            t.push({
                is_readonly: e.is_readonly,
                is_deny: e.is_deny,
                is_writable: e.is_writable,
                is_custom: !!e.is_custom
            })
        }), t
    },
    onStoreException: function(e, t, i, s, r, o) {
        this.owner.clearStatusBusy(), r.isTimeout ? this.owner.getMsgBox().alert(this.title, _T("error", "error_timeout")) : 2626 === r.code ? this.restartPolling() : (SYNO.Debug("Store exception: options:", e, t, i, s, r, o), this.owner.getMsgBox().alert(this.title, SYNO.API.Errors.core[r.code] || _T("common", "commfail")))
    },
    onBeforeLoad: function(e, t) {
        return this.owner.setStatusBusy({
            text: _T("common", "loading")
        }), !this.isChanged() || (this.owner.clearStatusBusy(), this.owner.getMsgBox().confirm(this.title, _T("share", "share_save_chg_before_reload"), function(e) {
            "yes" === e ? SYNO.SDS.Utils.S2S.confirmIfSyncShareAffected(!1, this.getShareInfoForS2S(), {
                dialogTitle: this.title,
                dialogMsg: _T("s2s", "s2s_warn_share_change_priv"),
                dialogOwner: this.owner,
                continueHandler: function() {
                    var e = this.getWebAPI();
                    this.sendApplyRequest(e, t)
                },
                abortHandler: function() {
                    this.store.rejectChanges(), this.store.load(t)
                },
                scope: this
            }) : (this.store.rejectChanges(), this.store.load(t))
        }, this), !1)
    },
    onLoad: function() {
        this.prevRole = void 0, this.getView().el.unmask(), this.owner.clearStatusBusy(), this.getSelectionModel().selectFirstRow(), this.isShowPreview && this.checkPreviewAll()
    },
    onRoleFilterSelect: function(e, t) {
        var i = t.data.role;
        this.prevRole = e.getValue(), this.store.baseParams.user_group_type = i, "domain_user" === i || "domain_group" === i ? this.showDomainFilter(!0) : this.showDomainFilter(!1), this.stopPolling(), this.store.load({
            params: {
                offset: 0
            }
        })
    },
    onDomainFilterSelect: function(e, t) {
        this.store.baseParams.domain = t.data.value, this.store.load({
            params: {
                offset: 0
            }
        })
    },
    onTypeFilterChange: function(e) {
        this.store.baseParams.permission_type = e, this.store.load({
            params: {
                offset: 0
            }
        })
    },
    showDomainFilter: function(e) {
        this.domainListLabel.setVisible(e), this.domainFilter.setVisible(e)
    },
    loadPermissions: function(e, t) {
        this.shareRecord = e, this.colRo.isAclMode = e.get("is_aclmode"), this.colCu && (this.colCu.shareRecord = e);
        var i = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.Directory.LDAP", "get", "enable_client"),
            s = 2702 === SYNO.API.Response.GetValByAPI(t, "SYNO.Core.Directory.LDAP", "get", "error"),
            r = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.Directory.Domain", "get", "enable_domain"),
            o = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.Directory.Domain", "test_dc", "test_join_success"),
            a = "yes" === this._D("supportdomain") && SYNO.API.Response.GetValByAPI(t, "SYNO.Core.Directory.Domain", "get_domain_list", "domain_list"),
            n = this.roleFilter.getStore(),
            l = this.domainFilter.getStore(),
            d = [];
        if (n.loadData(this.DEFAULT_ROLES), n.loadData(this.GROUP_ROLES, !0), i && s && n.loadData(this.LDAP_ROLES, !0), r && o && 0 !== a.length && (n.loadData(this.DOMAIN_ROLES, !0), Ext.each(a, function(e) {
                "object" === _typeof(e) ? e[1] ? d.push(e) : d.push([_T("directory_service", "domainou_list_all_items"), e[1], e[2]]) : d.push([e, e, e])
            }, this), l.loadData(d), this.domainFilter.getValue() || this.domainFilter.setValue(d[0][1] || ""), this.store.baseParams.domain = this.domainFilter.getValue(), 1 === SYNO.API.Response.GetValByAPI(t, "SYNO.Core.Directory.Domain", "get", "manage_mode") ? this.domainListLabel.setValue(_T("directory_service", "organizational_unit") + ": ") : this.domainListLabel.setValue(_T("helptoc", "directory_service_domain") + ": ")), this.showDomainFilter(!1), this.roleFilter.setValue("local_user"), this.nameFilter.reset(), Ext.isDefined(this.colCu) && !0 !== e.get("is_aclmode")) {
            var h = this.getColumnModel().getIndexById("is_custom");
            h >= 0 && this.getColumnModel().setHidden(h, !0), this.nameFilter.removeItemFromMenu("custom")
        }
        var c = this.getColumnModel().getIndexById("is_writable");
        e.get("readonly") && this.getColumnModel().setHidden(c, !0), this.store.baseParams.name = e.get("name"), this.store.baseParams.user_group_type = this.roleFilter.getValue(), this.store.load()
    },
    getOpenConfig: function() {
        var e = this.getSelectionModel().getSelected().get("name"),
            t = "user",
            i = this.roleFilter.getValue();
        return "local_group" === i || "domain_group" === i || "ldap_group" === i ? t = "group" : "http" === e && (t = "group"), {
            userName: e,
            userType: t,
            userIsInternal: "system" === this.roleFilter.getValue() && "ftp" !== e
        }
    },
    getWebAPI: function() {
        var e = [];
        Ext.each(this.store.getModifiedRecords(), function(t) {
            e.push({
                name: t.data.name,
                is_readonly: t.data.is_readonly,
                is_writable: t.data.is_writable,
                is_deny: t.data.is_deny,
                is_custom: t.data.is_custom
            })
        }, this);
        var t = {
            name: this.shareRecord.get("name"),
            user_group_type: this.prevRole || this.roleFilter.getValue(),
            permissions: e
        };
        return this.isAdvancedMode && (t.is_share_permission = !0), 0 === e.length ? [] : [{
            api: "SYNO.Core.Share.Permission",
            method: "set",
            version: 1,
            params: t
        }]
    },
    sendApplyRequest: function(e, t) {
        this.owner.setStatusBusy({
            text: _T("common", "saving")
        }), this.owner.sendWebAPI(Ext.apply(e[0], {
            scope: this,
            callback: function(e, i) {
                if (this.owner.clearStatusBusy(), e) return this.store.commitChanges(), this.store.load(t), void(i && i.is_ftp_anonymous_chroot_conflict && this.confirmToShowFTPAdvancedSetting());
                this.owner.getMsgBox().alert(this.title, SYNO.API.Errors.core[i.code] || _T("common", "commfail"))
            }
        }))
    },
    confirmToShowFTPAdvancedSetting: function(e) {
        this.owner.setStatusBusy({
            text: _T("common", "loading")
        }), this.sendWebAPI({
            api: "SYNO.Core.FileServ.FTP.Security",
            method: "set",
            params: {
                anonymous_chroot: !1,
                anonymous_chroot_share: ""
            },
            version: 1,
            scope: this,
            callback: function(t, i, s) {
                this.owner.clearStatusBusy(), this.owner.getMsgBox().confirm(this.title, _T("ftp", "ftp_cfrm_reset_anonymous_chroot"), function(t) {
                    Ext.isObject(e) && !0 === e.closeDialog && this.owner.close(), "yes" === t && (this.owner.close(), this.findAppWindow().startModule("SYNO.SDS.AdminCenter.FileService.Main", {
                        tab: "ftp",
                        launchAdvanceDialog: !0
                    }))
                }, this)
            }
        })
    },
    restartPolling: function() {
        if (!this.pollingId) {
            var e = this,
                t = function t(i, s) {
                    if (s >= i.length) return void e.store.load();
                    e.getKnownAPI("SYNO.Core.Directory.Domain") && e.sendWebAPI({
                        api: "SYNO.Core.Directory.Domain",
                        method: "update_status",
                        version: 1,
                        params: {
                            task_id: i[s]
                        },
                        scope: e,
                        callback: function(r, o, a, n) {
                            if (r && "updating" === o.status) return void e.startPolling(a.task_id);
                            t(i, s + 1)
                        }
                    })
                };
            this.getView().el.mask(_T("directory_service", "warr_db_not_ready")), this.pollList({
                task_id_prefix: "DomainUpdate",
                extra_group_tasks: ["admin"],
                scope: this,
                callback: function(e, i, s, r) {
                    e && Ext.isArray(i.admin) && t(i.admin, 0)
                }
            })
        }
    },
    startPolling: function(e) {
        this.pollingId = this.pollReg({
            webapi: {
                api: "SYNO.Core.Directory.Domain",
                method: "update_status",
                version: 1,
                params: {
                    task_id: e
                }
            },
            interval: 5,
            immediate: !0,
            scope: this,
            status_callback: function(e, t, i, s) {
                e && Ext.isDefined(t) && "finish" !== t.status || (this.stopPolling(), this.store.load())
            }
        })
    },
    stopPolling: function() {
        this.pollingId && (this.pollUnreg(this.pollingId), this.pollingId = void 0)
    }
}), Ext.define("SYNO.SDS.Share.AdvanceForm", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        var t = Ext.apply({
            title: _T("share", "share_advance_permissions"),
            trackResetOnLoad: !0,
            items: [{
                xtype: "syno_fieldset",
                title: _T("share", "share_advanced_settings"),
                id: this.advSettingsSet = Ext.id(),
                collapsible: !0,
                items: [{
                    xtype: "syno_displayfield",
                    value: _T("share", "share_advance_privileges_desc")
                }, {
                    xtype: "syno_checkbox",
                    name: "disable_list",
                    boxLabel: _T("share", "share_disable_list")
                }, {
                    xtype: "syno_checkbox",
                    itemId: "disable_modify",
                    name: "disable_modify",
                    boxLabel: _T("share", "share_disable_modify")
                }, {
                    xtype: "syno_checkbox",
                    name: "disable_download",
                    boxLabel: _T("share", "share_disable_download")
                }]
            }, {
                xtype: "syno_fieldset",
                title: _T("share", "share_reset_privileges"),
                collapsible: !0,
                itemId: "advFieldSet",
                items: [{
                    xtype: "syno_displayfield",
                    htmlEncode: !1,
                    value: _T("share", "share_reset_privileges_desc")
                }, {
                    xtype: "syno_checkbox",
                    name: "unite_permission",
                    boxLabel: _T("share", "share_reset_description")
                }, {
                    xtype: "syno_button",
                    id: this.btnAdvance = Ext.id(),
                    indent: 1,
                    text: _T("share", "share_permission_button"),
                    scope: this,
                    handler: function() {
                        new SYNO.SDS.Share.PermissionDialog({
                            owner: this.owner,
                            module: this.module,
                            hideCustomColumn: !0,
                            isAdvancedMode: !0
                        }).loadPermissionData(this.shareRecord)
                    }
                }, {
                    xtype: "syno_displayfield",
                    htmlEncode: !1,
                    value: '<span class="syno-ux-note">' + _T("common", "note") + _T("common", "colon") + ' </span><br><ul style="list-style-type: disc; list-style-position: inside;"><li>' + _T("share", "notice_adv_permission_necessity") + "</li><li>" + _T("share", "notice_s2s_permission") + "</li></ul>"
                }]
            }]
        }, e);
        this.callParent([t]), this.mon(this, "afterlayout", function() {
            new SYNO.ux.Utils.EnableCheckGroup(this.getForm(), "unite_permission", [this.btnAdvance])
        }, this, {
            single: !0
        })
    },
    loadPermissions: function(e, t) {
        SYNO.SDS.ControlPanel.Share.isHomes(e.get("name")) && Ext.getCmp(this.advSettingsSet).hide(), this.shareRecord = e, this.getForm().setValues(SYNO.API.Response.GetValByAPI(t, "SYNO.Core.Share", "get")), e.get("readonly") && this.getForm().findField("disable_modify").disable(), e.get("is_aclmode") || this.getComponent("advFieldSet").hide()
    },
    isAdvPermissionDisabled: function() {
        var e = this.getForm().findField("unite_permission");
        return e.isDirty() && !1 === e.getValue()
    },
    getWebAPI: function() {
        var e = this.shareRecord.get("name"),
            t = this.getForm(),
            i = {};
        return Ext.each(["disable_list", "disable_modify", "disable_download"], function(e) {
            i[e] = t.findField(e).getValue()
        }, this), this.getForm().isDirty() ? [{
            api: "SYNO.Core.Share",
            method: "set",
            version: 1,
            params: {
                name: e,
                shareinfo: {
                    name: e,
                    vol_path: this.shareRecord.get("vol_path"),
                    unite_permission: t.findField("unite_permission").getValue(),
                    advanceperm: i
                }
            }
        }] : []
    }
}), Ext.define("SYNO.SDS.Share.PermissionDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.gridPanel = new SYNO.SDS.Share.ShareGrid({
            module: e.module,
            owner: this,
            itemId: "sharegrid",
            hideCustomColumn: e.hideCustomColumn || !1,
            isAdvancedMode: e.isAdvancedMode || !1
        }), this.formPanel = new SYNO.SDS.Share.AdvanceForm({
            module: e.module,
            owner: this,
            itemId: "advperm"
        });
        var t = Ext.apply({
            width: 800,
            height: 470,
            minWidth: 550,
            minHeight: 370,
            layout: "fit",
            closeAction: "onCancel",
            items: [{
                xtype: "syno_tabpanel",
                plain: !0,
                itemId: "tab",
                activeTab: 0,
                items: [this.gridPanel]
            }],
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: this.onCancel
            }, {
                text: _T("common", "save"),
                scope: this,
                btnStyle: "blue",
                handler: this.savePermissionWithConfirm
            }]
        }, e);
        this.callParent([t]), this.mon(this, "close", function() {
            this.gridPanel.stopPolling()
        }, this)
    },
    isChanged: function() {
        return this.gridPanel.isChanged() || this.formPanel.getForm().isDirty()
    },
    isShareGridHidden: function() {
        return !!this.getComponent("tab") && "none" === this.getComponent("tab").getTabEl("sharegrid").style.display
    },
    remoteSavePermission: function() {
        if (!this.isChanged()) return void this.close();
        var e = this.isShareGridHidden() ? [] : this.gridPanel.getWebAPI(),
            t = this.formPanel.getWebAPI(),
            i = this.isAdvancedMode ? e : e.concat(t);
        i.length > 0 && this.sendApplyRequest(i)
    },
    savePermissionWithConfirm: function() {
        if (!this.isChanged()) return void this.close();
        var e = {
            name: this.shareRecord.get("name"),
            is_sync_share: this.shareRecord.get("is_sync_share"),
            permissions: [],
            no_check_permission: !1
        };
        this.gridPanel.disabled || (e.permissions = this.gridPanel.getModifiedPermissions()), !this.formPanel.disabled && this.formPanel.isAdvPermissionDisabled() && (e.no_check_permission = !0), SYNO.SDS.Utils.S2S.confirmIfSyncShareAffected(!1, e, {
            dialogTitle: this.title,
            dialogMsg: _T("s2s", "s2s_warn_share_change_priv"),
            dialogOwner: this,
            continueHandler: function() {
                this.remoteSavePermission()
            },
            abortHandler: Ext.EmptyFn,
            scope: this
        })
    },
    sendApplyRequest: function(e) {
        this.setStatusBusy({
            text: _T("common", "saving")
        }), this.sendWebAPI({
            params: {},
            compound: {
                stopwhenerror: !1,
                params: e
            },
            scope: this,
            callback: function(e, t) {
                this.clearStatusBusy();
                var i = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.Share.Permission", "set");
                if (e && !t.has_fail) return SYNO.SDS.StatusNotifier.fireEvent("sharefolderchanged", "permission"), i && i.is_ftp_anonymous_chroot_conflict ? void this.gridPanel.confirmToShowFTPAdvancedSetting() : void(Ext.isFunction(this.successHandler) ? this.successHandler() : this.close());
                this.getMsgBox().alert(this.title, Ext.isObject(i) ? SYNO.API.Errors.core[i.code] : _T("common", "commfail"))
            }
        })
    },
    onCancel: function() {
        if (!this.isChanged()) return void this.close();
        this.confirmLostChangePromise({
            save: this.savePermissionWithConfirm,
            dontSave: this.close,
            cancel: Ext.emptyFn
        }, this)
    },
    loadPermissionData: function(e) {
        var t = e.get("vol_path") || e.get("real_path");
        t = t.toLowerCase();
        var i = 0 === t.indexOf("/volumeusb") || 0 === t.indexOf("/volumesd") || 0 === t.indexOf("/volumesata"),
            s = e.get("vol_path");
        s || (i ? (s = e.get("real_path"), "yes" === this._D("usbstation", "no") && (s = s.replace(/\/@sharebin\/.*/, ""))) : s = e.get("real_path").replace(e.get("path"), ""), e.set("vol_path", s));
        var r = [{
            api: "SYNO.Core.Directory.LDAP",
            method: "get",
            version: 1
        }, {
            api: "SYNO.Core.Share",
            method: "get",
            version: 1,
            params: {
                name: e.get("name"),
                additional: ["disable_list", "disable_modify", "disable_download", "unite_permission", "is_aclmode"]
            }
        }, {
            api: "SYNO.Core.Storage.Volume",
            method: "get",
            version: 1,
            params: {
                volume_path: s
            }
        }];
        this.gridPanel.getKnownAPI("SYNO.Core.Directory.Domain") && (r.push({
            api: "SYNO.Core.Directory.Domain",
            method: "get",
            version: 1
        }), r.push({
            api: "SYNO.Core.Directory.Domain",
            method: "test_dc",
            version: 1
        }), "yes" === this._D("supportdomain") && r.push({
            api: "SYNO.Core.Directory.Domain",
            method: "get_domain_list",
            version: 2
        })), this.setStatusBusy({
            text: _T("common", "loading")
        }), this.sendWebAPI({
            params: {},
            compound: {
                stopwhenerror: !1,
                params: r
            },
            scope: this,
            callback: function(t, i, s) {
                if (this.clearStatusBusy(), !t || i.has_fail) {
                    var r = SYNO.API.Response.GetFirstError(i);
                    return void this.getMsgBox().alert("share", SYNO.API.Errors.core[r.code] || _T("common", "commfail"))
                }
                var o = SYNO.API.Response.GetValByAPI(i, "SYNO.Core.Directory.Domain", "get", "enable_domain"),
                    a = SYNO.API.Response.GetValByAPI(i, "SYNO.Core.Directory.Domain", "test_dc", "test_join_success");
                o && !a && this.owner.getMsgBox().alert("warning_msg", _T("share", "warning_directory_service_offline"));
                var n = SYNO.API.Response.GetValByAPI(i, "SYNO.Core.Storage.Volume", "get").volume,
                    l = "";
                if (l = this.isAdvancedMode ? _T("share", "share_adv_edit_title") : _T("share", "share_edit_title"), n.readonly ? this.setTitle(String.format(l, String.format('{0}<span class="red-status">({1})</span>', e.get("name"), _T("common", "readonly")))) : this.setTitle(String.format(l, e.get("name"))), e.set("share_path", n.volume_path + "/" + e.get("name")), e.set("readonly", n.readonly), e.set("is_aclmode", SYNO.API.Response.GetValByAPI(i, "SYNO.Core.Share", "get", "is_aclmode")), e.set("is_sync_share", SYNO.API.Response.GetValByAPI(i, "SYNO.Core.Share", "get", "is_sync_share")), !_S("is_admin")) {
                    var d = SYNO.API.Response.GetValByAPI(i, "SYNO.Core.Share", "get", "user_priv_rw");
                    void 0 !== d && e.set("user_priv_rw", d)
                }
                this.shareRecord = e, this.gridPanel.disabled || SYNO.SDS.Share.PermissionDialog.prototype.isShareGridHidden.call(this) || ("photo" === e.get("name").toLowerCase() && !0 === SYNO.API.Response.GetValByAPI(i, "SYNO.Core.Share", "get", "mask_permission_tab") && (this.gridPanel.addListener("activate", function() {
                    this.gridPanel.mask(_T("share", "photo_permission_control_notify"))
                }, this), this.gridPanel.addListener("deactivate", function() {
                    this.gridPanel.unmask()
                }, this)), this.gridPanel.loadPermissions(e, i)), this.formPanel.disabled || this.formPanel.loadPermissions(e, i)
            }
        }), this.show()
    }
}), Ext.namespace("SYNO.SDS.Share"), Ext.define("SYNO.SDS.Share.PropertyDialogEnum", {
    statics: {
        privilegeType: {
            acl: "aclPrivilege",
            posix: "posixPrivilege",
            none: "noPrivilege"
        }
    }
}), Ext.define("SYNO.SDS.Share.PropertyDialog", {
    extend: "SYNO.SDS.Share.PermissionDialog",
    tabs: null,
    gTargetFiles: null,
    gDirPaths: null,
    constructor: function(e) {
        this.owner = e.owner;
        var t = Ext.applyIf(this.CreateTabsConfig(e.rec, e.source), e),
            i = e.privilegeType;
        this.ns = SYNO.SDS.ControlPanel.Share, this.tabs = function() {
            var s = [];
            return SYNO.SDS.Share.PropertyDialogEnum.privilegeType.acl !== i || e.rec[0].get("is_snapshot") || s.push({
                title: _T("acl_editor", "permission"),
                layout: "fit",
                items: this.aclPanel = new SYNO.SDS.Share.ACLPrivilege(Ext.apply({
                    isFirstLoad: !0,
                    openConfig: e.openConfig
                }, t))
            }), s
        }.call(this);
        var s = _T("filetable", "filetable_properties");
        e.isShareForceRO && (s += " (" + _T("common", "readonly") + ")");
        var r = Ext.apply({
            width: 750,
            height: _S("diskless") ? 320 : 590,
            shadow: !0,
            minWidth: 600,
            minHeight: _S("diskless") ? 320 : 400,
            collapsible: !1,
            constrainHeader: !0,
            plain: !0,
            title: s,
            layout: "fit",
            items: [{
                xtype: "syno_tabpanel",
                activeTab: 0,
                plain: !0,
                itemId: "tab",
                layoutOnTabChange: !0,
                items: this.tabs,
                deferredRender: !1
            }],
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: this.cancelHandler
            }, {
                btnStyle: "blue",
                text: _T("common", "save"),
                scope: this,
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : void 0,
                handler: this.saveHandler
            }],
            keys: [{
                key: 27,
                fn: this.cancelHandler,
                scope: this
            }],
            listeners: {
                afterlayout: {
                    fn: this.center,
                    scope: this,
                    single: !0
                },
                error: {
                    fn: this.errorHandler,
                    scope: this
                },
                beforeclose: {
                    fn: this.beforecloseHandler,
                    scope: this
                }
            }
        }, e);
        SYNO.SDS.Share.PermissionDialog.superclass.constructor.call(this, r);
        var o = this.getComponent("tab");
        o.hideTabStripItem("snapshotgrid"), _S("is_admin") && e.rec[0].get("isshare") && (SYNO.SDS.Share.PropertyDialogEnum.privilegeType.posix === i ? o.unhideTabStripItem("sharegrid") : o.hideTabStripItem("sharegrid"))
    },
    cancelHandler: function() {
        this.checkModified() ? this.getMsgBox().confirm(_T("filetable", "filetable_properties"), _T("common", "confirm_lostchange"), function(e) {
            "yes" == e && this.close()
        }, this) : this.close()
    },
    saveHandler: function() {
        if (_S("demo_mode")) return void this.getMsgBox().alert(_T("filetable", "filetable_properties"), _JSLIBSTR("uicommon", "error_demo"));
        if (this.checkModified()) {
            if (!this.validateData()) return;
            this.saveProperty(this.collectData())
        } else this.close()
    },
    errorHandler: function(e) {
        this.getMsgBox().alert(_T("error", "error_error"), e, this.close, this)
    },
    load: function() {
        if ("" !== this.rec) {
            var e = SYNO.SDS.Share.PropertyDialogEnum.privilegeType.none === this.privilegeType ? 320 : 590,
                t = SYNO.SDS.Desktop ? SYNO.SDS.Desktop.getEl().getHeight() : Ext.lib.Dom.getViewHeight();
            t < e && (e = t), this.setSize(this.width, e), this.LoadTabs(), this.show().center()
        }
    },
    LoadTabs: function() {
        for (var e = 0; e < this.tabs.length; ++e) Ext.isFunction(this.tabs[e].items.loadData) ? this.tabs[e].items.loadData() : Ext.isFunction(this.tabs[e].loadData) && this.tabs[e].loadData()
    },
    CreateTabsConfig: function(e, t) {
        var i, s, r, o, a = [],
            n = !1,
            l = [],
            d = null,
            h = [];
        if (e.length > 1) {
            for (n = !0, o = 0; o < e.length; o++) a.push(e[o].get("real_path")), r = e[o].get("file_id"), e[0].get("isdir") ? l.push(r) : l.push(r.substr(0, r.lastIndexOf("/"))), h.push(e[o].get("file_id"));
            i = a.join("_SYNOFM_"), d = l.join("_SYNOFM_"), s = h
        } else n = !1, i = e[0].get("real_path"), r = e[0].get("file_id"), d = e[0].get("isdir") ? r : r.substr(0, r.lastIndexOf("/")), s = e[0].get("file_id");
        return this.gTargetFiles = i, this.gAPITargetFiles = s, this.gDirPaths = d, {
            owner: this,
            gblMultiFiles: n,
            gTargetFiles: this.gTargetFiles,
            gAPITargetFiles: this.gAPITargetFiles,
            gDirPaths: this.gDirPaths
        }
    },
    checkModified: function(e, t) {
        for (var i = 0; i < this.tabs.length; ++i) {
            var s = null,
                r = null;
            if (Ext.isFunction(this.tabs[i].items.checkModified)) {
                if (!1 === t) continue;
                s = this.tabs[i].items.checkModified, r = this.tabs[i].items
            } else if (Ext.isFunction(this.tabs[i].checkShareModified)) {
                if (!1 === e) continue;
                s = this.tabs[i].checkShareModified, r = this.tabs[i]
            }
            if (Ext.isFunction(s) && !0 === s.call(r)) return !0
        }
        return !1
    },
    validateData: function() {
        for (var e = 0; e < this.tabs.length; ++e)
            if (Ext.isFunction(this.tabs[e].items.validateData) && !1 === this.tabs[e].items.validateData()) return this.getComponent("tab").setActiveTab(e), !1;
        return !0
    },
    collectData: function() {
        for (var e = {
                file_path: this.gTargetFiles,
                files: this.gTargetFiles,
                dirPaths: this.gDirPaths
            }, t = 0; t < this.tabs.length; ++t) Ext.isFunction(this.tabs[t].items.collectData) && Ext.apply(e, this.tabs[t].items.collectData());
        return e
    },
    saveProperty: function(e) {
        var t = this.formPanel && this.formPanel.isAdvPermissionDisabled(),
            i = this.aclPanel && this.aclPanel.checkModified(),
            s = {
                name: this.rec[0].get("name"),
                is_sync_share: this.rec[0].get("is_sync_share"),
                permissions: [],
                no_check_permission: !1
            };
        this.rec[0].get("isshare") && (this.gridPanel && !this.isShareGridHidden() ? s.permissions = this.gridPanel.getModifiedPermissions() : i && (s.permissions = [{
            is_readonly: !1,
            is_deny: !1,
            is_writable: !1,
            is_custom: !0
        }]), t && (s.no_check_permission = !0)), SYNO.SDS.Utils.S2S.confirmIfSyncShareAffected(!1, s, {
            dialogTitle: this.title,
            dialogMsg: _T("s2s", "s2s_warn_share_change_priv"),
            dialogOwner: this,
            continueHandler: function() {
                if (this.propertyVal = e, this.checkModified(!0, !1)) return void this.remoteSavePermission();
                this.successHandler()
            },
            abortHandler: Ext.EmptyFn,
            scope: this
        })
    },
    successHandler: function() {
        if (!this.checkModified(!1)) return void this.close();
        var e = [""];
        return SYNO.SDS.Share.PropertyDialogEnum.privilegeType.acl === this.privilegeType ? void this.sendWebAPI({
            api: "SYNO.Core.ACL",
            method: "check_self_denied",
            version: 1,
            scope: this,
            params: this.propertyVal,
            callback: function(t, i, s) {
                t && i.is_denied ? this.getMsgBox().confirm("", _T("acl_editor", "alert_set_self_denied_acl"), function(t) {
                    "yes" === t && this.setACL(e)
                }, this) : this.setACL(e)
            }
        }) : void 0
    },
    setACL: function(e) {
        this.sendWebAPI({
            api: "SYNO.Core.ACL",
            method: "set",
            version: 1,
            scope: this,
            params: this.propertyVal,
            callback: function(t, i, s) {
                s.nodeIdArr = e, s.is_acl = !0, this.savePropertyCB(s, t, i)
            }
        })
    },
    savePropertyCB: function(e, t, i) {
        this.fireEvent("callback", e, t, i), this.close()
    },
    beforecloseHandler: function() {
        for (var e = 0; e < this.tabs.length; ++e) Ext.isFunction(this.tabs[e].items.onClose) && this.tabs[e].items.onClose()
    }
}), Ext.define("SYNO.SDS.Share.ACLPrivilege", {
    extend: "SYNO.ux.GridPanel",
    ACE_Store: null,
    editorDialog: null,
    loadingStatus: "success",
    isInherieted: !1,
    originInherieted: !1,
    modifiedACL: !1,
    isRealACL: !0,
    hasChangePerm: !1,
    max_explicit_num: 200,
    domainInfo: {
        mode: "none",
        scopeList: []
    },
    constructor: function(e) {
        this.isHomes = "homes" === e.rec[0].get("filename").toLowerCase() && !0 === e.rec[0].get("isshare");
        var t = function(e, t) {
            return SYNO.SDS.Share.ACLPrivilege.Utils.PrintPermission(t.permission) + SYNO.SDS.Share.ACLPrivilege.Utils.PrintInherit(t.inherit)
        };
        this.ACE_Store = new Ext.data.Store({
            autoDestroy: !0,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.Core.ACL",
                method: "get",
                version: 1,
                appWindow: this,
                listeners: {
                    beforeload: {
                        fn: function() {
                            this.loadingStatus = "loading", this.getEl().mask(_T("common", "loading"), "x-mask-loading")
                        },
                        scope: this
                    },
                    load: {
                        fn: this.afterProxySuccessLoad,
                        scope: this
                    },
                    exception: {
                        fn: function(e, t, i, s, r, o) {
                            this.loadingStatus = _T("common", "error_system"), Ext.isDefined(r.code) && (this.loadingStatus = SYNO.API.getErrorString(r.code)), this.getEl().mask(this.loadingStatus)
                        },
                        scope: this
                    }
                }
            }),
            reader: new Ext.data.JsonReader({
                root: "acl",
                totalProperty: "total",
                id: "acl",
                fields: [{
                    name: "user_type",
                    mapping: "owner_type"
                }, {
                    name: "user_name",
                    mapping: "owner_name"
                }, {
                    name: "user_is_internal",
                    mapping: "owner_is_internal"
                }, {
                    name: "type",
                    mapping: "permission_type"
                }, {
                    name: "permission",
                    convert: t
                }, {
                    name: "level"
                }]
            }),
            baseParams: {
                type: "all",
                file_path: e.gTargetFiles
            },
            pruneModifiedRecords: !0,
            aclSort: function() {
                this.sort([{
                    field: "level",
                    direction: "ASC"
                }, {
                    field: "type",
                    direction: "DESC"
                }, {
                    field: "user_type",
                    direction: "DESC"
                }, {
                    field: "user_name",
                    direction: "ASC"
                }], "ASC")
            },
            listeners: {
                load: {
                    fn: function(e) {
                        this.aclSort()
                    }
                }
            }
        });
        var i = Ext.apply({
            store: this.ACE_Store,
            autoExpandColumn: "user_name",
            cls: "syno-share-property-dialog",
            colModel: new Ext.grid.ColumnModel([{
                header: "",
                datatIndex: "user_type",
                width: 34,
                fixed: !0,
                sortable: !1,
                menuDisabled: !0,
                hideable: !1,
                renderer: function(e, t, i) {
                    return e = i.get("user_type"), i.get("user_is_internal") ? '<div class="acl-grid-item-internal" style="width: 26px; height: 26px; margin-left: -4px;"> </div>' : "user" === e ? '<div class="acl-grid-item-user" style="width: 26px; height: 26px; margin-left: -4px;"> </div>' : '<div class="acl-grid-item-group" style="width: 26px; height: 26px; margin-left: -4px;"> </div>'
                }
            }, {
                id: "user_name",
                header: _T("acl_editor", "user_or_group"),
                datatIndex: "user_name",
                width: 400,
                sortable: !1,
                menuDisabled: !0,
                renderer: function(e, t, i, s) {
                    return i.get("user_name")
                }
            }, {
                header: _T("acl_editor", "type"),
                datatIndex: "type",
                width: 80,
                sortable: !1,
                menuDisabled: !0,
                renderer: function(e, t, i, s) {
                    return e = i.get("type"), "deny" === e ? _T("acl_editor", "deny") : _T("acl_editor", "allow")
                }
            }, {
                header: _T("acl_editor", "permission"),
                datatIndex: "permission",
                width: 130,
                sortable: !1,
                menuDisabled: !0,
                renderer: {
                    fn: this.simplePermission,
                    scope: this
                }
            }, {
                header: "level",
                dataIndex: "level",
                hidden: !0,
                hideable: !1,
                sortable: !1,
                menuDiabled: !0
            }]),
            selModel: new Ext.grid.RowSelectionModel({
                listeners: {
                    selectionchange: {
                        fn: function(e) {
                            this.updateToolBarBts()
                        },
                        scope: this
                    }
                }
            }),
            stripeRows: !0,
            tbar: [{
                xtype: "syno_button",
                text: _T("common", "create"),
                itemId: "addbt",
                handler: this.onAddBtClick,
                scope: this
            }, {
                xtype: "syno_button",
                text: _T("common", "delete"),
                itemId: "deletebt",
                handler: this.onDeleteBtClickHandler,
                scope: this,
                disabled: !0
            }, {
                xtype: "syno_button",
                text: e.isShareForceRO ? _T("acl_editor", "view") : _T("common", "alt_edit"),
                itemId: "modifybt",
                handler: this.onModifyBtClick,
                scope: this,
                disabled: !0
            }, new SYNO.ux.Button({
                text: _T("mount", "adv_opt"),
                itemId: "advancebt",
                tabIndex: -1,
                menu: new SYNO.ux.Menu({
                    items: [{
                        text: _T("acl_editor", "remove_inherited"),
                        itemId: "removeInherited",
                        handler: this.removeInherited,
                        scope: this
                    }, {
                        text: _T("acl_editor", "make_inherited_explicit"),
                        itemId: "makeInheritedExplicit",
                        handler: this.makeInheritedExplicit,
                        scope: this
                    }, {
                        text: _T("acl_editor", "add_inherited"),
                        itemId: "addInherited",
                        handler: this.addInherited,
                        scope: this
                    }, {
                        xtype: "menuseparator",
                        itemId: "inherietMenuSP"
                    }, {
                        text: _T("acl_editor", "effective_permission_inspector"),
                        itemId: "inspector",
                        handler: this.onInspectorBtClick,
                        scope: this
                    }]
                })
            })],
            bbar: [{
                xtype: "syno_checkbox",
                boxLabel: _T("property", "privilege_recursive"),
                hideMode: "display",
                itemId: "acl_privilage_recur",
                listeners: {
                    check: {
                        fn: function(e, t) {
                            this.updateAdvancedBt()
                        },
                        scope: this
                    }
                }
            }],
            forceLayout: !0,
            viewConfig: {
                forceFit: !0,
                getRowClass: function(e, t, i, s) {
                    if (e.data.level > 0) return "x-grid-record-gray"
                }
            },
            listeners: {
                afterlayout: {
                    fn: function() {
                        "success" === this.loadingStatus ? this.getEl().unmask() : "loading" === this.loadingStatus ? this.getEl().mask(_T("common", "loading"), "x-mask-loading") : this.getEl().mask(this.loadingStatus)
                    },
                    scope: this
                },
                rowdblclick: {
                    fn: function(e, t, i) {
                        this.onModifyBtClick()
                    },
                    scope: this
                }
            }
        }, e);
        SYNO.SDS.Share.ACLPrivilege.superclass.constructor.call(this, i), this.addClass("acl-grid")
    },
    afterProxySuccessLoad: function(e, t, i) {
        this.isRealACL = t.is_acl, !0 === this.isShareForceRO ? this.hasChangePerm = !1 : !0 === this.isRealACL ? this.hasChangePerm = t.change_permission : (this.hasChangePerm = !1, t.acl_editable ? !0 === _S("is_admin") ? this.hasChangePerm = !0 : Ext.isDefined(this.rec[0].get("uid")) ? this.rec[0].get("uid") === this.userId && (this.hasChangePerm = !0) : this.rec[0].get("owner") === _S("user") && (this.hasChangePerm = !0) : this.hasChangePerm = !1), this.isInherieted = t.is_inherited, this.originInherieted = this.isInherieted, this.updateAdvancedBt(), this.updateToolBarBts(), !1 === this.hasChangePerm && this.getBottomToolbar().get("acl_privilage_recur").disable(), this.loadingStatus = "success", this.getEl().unmask()
    },
    getEditorDialog: function() {
        return null === this.editorDialog && (this.editorDialog = new SYNO.SDS.Share.ACLPrivilege.EditorDialog({
            owner: this.owner,
            findAppWindow: this.findAppWindow
        }), this.mon(this.editorDialog, "addACE", this.addACE, this), this.mon(this.editorDialog, "deleteACE", this.deleteACE, this)), this.editorDialog
    },
    loadData: function() {
        this.rec[0].get("isdir") ? this.getBottomToolbar().get("acl_privilage_recur").enable() : this.getBottomToolbar().get("acl_privilage_recur").disable(), this.owner.setStatusBusy({
            text: _T("common", "saving")
        }), this.owner.sendWebAPI({
            api: "SYNO.Core.ACL",
            method: "get_ui_info",
            version: 1,
            scope: this,
            callback: function(e, t) {
                this.owner.clearStatusBusy();
                var i = {
                    mode: "none",
                    scopeList: []
                };
                e && t.directoryServiceInfo && (i.mode = t.directoryServiceInfo.type, i.scopeList = t.directoryServiceInfo.items), this.domainInfo = i, this.ACE_Store.load({
                    scope: this,
                    callback: this.launchEditor
                })
            }
        })
    },
    launchEditor: function() {
        if (this.isFirstLoad && Ext.isObject(this.openConfig)) {
            this.isFirstLoad = !1;
            var e = "none",
                t = 0,
                i = 0;
            this.getStore().each(function(s) {
                if (s.get("user_type") === this.openConfig.userType && s.get("user_name").toLowerCase() === this.openConfig.userName.toLowerCase()) {
                    if ("once" === e) return e = "twice", !1;
                    e = "once", i = t
                }
                t++
            }, this), "none" === e ? this.onAddBtClick() : "once" === e && (this.getSelectionModel().selectRow(i), this.onModifyBtClick())
        }
    },
    checkModified: function() {
        return !!this.modifiedACL || (this.isInherieted !== this.originInherieted || !0 === this.getBottomToolbar().get("acl_privilage_recur").getValue())
    },
    validateData: function() {
        return !0
    },
    collectData: function() {
        var e = [],
            t = this.modifiedACL || !this.isRealACL || this.isInherieted !== this.originInherieted;
        return t && this.ACE_Store.each(function(t) {
            var i = {};
            return 0 !== t.get("level") || (i.owner_type = t.get("user_type"), "owner" == i.owner_type ? i.owner_name = "Owner" : "everyone" == i.owner_type ? i.owner_name = "Everyone" : i.owner_name = t.get("user_name"), i.permission_type = t.get("type"), i.permission = SYNO.SDS.Share.ACLPrivilege.Utils.ParsePermissionString(t.get("permission").substr(0, 13)), i.inherit = SYNO.SDS.Share.ACLPrivilege.Utils.ParseInheritString(t.get("permission").substr(13, 4)), e.push(i), !0)
        }), {
            change_acl: t,
            rules: e,
            inherited: this.isInherieted,
            acl_recur: this.getBottomToolbar().get("acl_privilage_recur").getValue()
        }
    },
    onClose: function() {
        this.ACE_Store.removeAll()
    },
    checkIfExceedExplicitCount: function(e) {
        function t(e) {
            0 === e.get("level") && ++i
        }
        var i = 0;
        return this.ACE_Store.each(t, this), !((i += e) <= this.max_explicit_num) && (this.owner.getMsgBox().alert(_T("error", "error_error"), _T("acl_editor", "acl_rules_reach_limit") + "<br>" + _T("acl_editor", "acl_rules_reach_limit_report").replace("_count_", i).replace("_maxCount_", this.max_explicit_num)), !0)
    },
    onAddBtClick: function() {
        if (!this.checkIfExceedExplicitCount(1)) {
            var e = 0 !== arguments.length ? {} : {
                    isFirstLoad: !0,
                    openConfig: this.openConfig
                },
                t = this.max_explicit_num;
            this.getStore().each(function(e) {
                0 === e.get("level") && t--
            }), this.getEditorDialog().load(Ext.apply({
                mode: "add",
                file_id: this.rec[0].get("file_id"),
                isdir: this.rec[0].get("isdir"),
                multiselect: !this.openConfig,
                acl_quota: t,
                domainInfo: this.domainInfo
            }, e))
        }
    },
    onDeleteBtClickHandler: function() {
        if (this.isHomes)
            for (var e = this.getSelectionModel(), t = e.getSelections(), i = function(e) {
                    "yes" == e && this.onDeleteBtClick()
                }, s = 0; s < t.length; ++s) {
                var r = t[s].data;
                if ("everyone" === r.user_type && "allow" == r.type && 2 == r.permission.search("x")) return void this.owner.getMsgBox().confirm(_T("common", "reminder"), _T("share", "warn_delete_homes_everyone_acl"), i, this)
            }
        this.onDeleteBtClick()
    },
    onDeleteBtClick: function() {
        var e = this.getSelectionModel(),
            t = e.getSelections();
        this.ACE_Store.suspendEvents(!1);
        for (var i = 0; i < t.length; ++i) this.deleteACE(t[i]);
        this.ACE_Store.resumeEvents(), this.ACE_Store.aclSort(), e.selectRow(e.last < e.lastActive ? e.last : e.lastActive), e.selectLastRow(), !1 === e.hasSelection() && e.selectLastRow()
    },
    onModifyBtClick: function() {
        var e = this.getSelectionModel(),
            t = e.getSelections();
        if (0 !== t.length) {
            var i = this.hasChangePerm;
            Ext.each(t, function(e) {
                0 !== e.get("level") && (i = !1)
            }, this);
            var s = t.length > 1 && i;
            this.getEditorDialog().load({
                mode: i ? "edit" : "view",
                aceRC: t,
                file_id: this.rec[0].get("file_id"),
                isdir: this.rec[0].get("isdir"),
                multiselect: s,
                domainInfo: this.domainInfo
            })
        }
    },
    onInspectorBtClick: function() {
        this.getEditorDialog().load({
            mode: "inspector",
            file_id: this.rec[0].get("file_id"),
            file_path: this.rec[0].get("real_path"),
            file_name: this.rec[0].get("filename"),
            isdir: !1,
            multiselect: !1,
            domainInfo: {
                mode: "none",
                scopeList: []
            }
        })
    },
    addACE: function(e, t) {
        for (; this.mergeACEwithStoreRecords(e););
        var i = new Ext.data.Record(e);
        !1 === t ? this.ACE_Store.add(i) : this.ACE_Store.addSorted(i), this.getSelectionModel().selectRecords([i]), this.modifiedACL = !0, this.updateAdvancedBt(), this.isHomes && "deny" === e.type && 2 == e.permission.search("x") && this.owner.getMsgBox().alert(_T("common", "reminder"), _T("share", "warn_deny_rule_homes_acl"))
    },
    deleteACE: function(e) {
        0 === e.get("level") && this.ACE_Store.remove(e), this.modifiedACL = !0, this.updateAdvancedBt()
    },
    mergeACEwithStoreRecords: function(e) {
        var t, i, s, r, o, a = !1,
            n = !1;
        for (r = 0; r < this.ACE_Store.getCount(); ++r)
            if (t = this.ACE_Store.getAt(r), 0 === t.get("level") && t.get("type") === e.type && t.get("user_name").toLowerCase() === e.user_name.toLowerCase() && t.get("user_type") === e.user_type) {
                for (i = t.get("permission"), n = !1, s = "", o = 0; o < 17; ++o) s = "-" !== e.permission.charAt(o) ^ (15 === o || 16 === o) ? s.concat(e.permission.charAt(o)) : s.concat(i.charAt(o));
                n = i === s || e.permission === s || (i.substr(13, 4) === e.permission.substr(13, 4) || i.substr(0, 13) === e.permission.substr(0, 13) && (e.permission.charAt(16) === i.charAt(16) || e.permission.charAt(13) === i.charAt(13) && e.permission.charAt(14) === i.charAt(14))), !0 === n && (e.permission = s, this.ACE_Store.removeAt(r), a = !0, --r)
            } return a
    },
    removeInherited: function() {
        this.getStore().filterBy(function(e, t) {
            return !(e.get("level") > 0)
        }), this.isInherieted = !1, this.getStore().commitChanges(), this.updateAdvancedBt()
    },
    makeInheritedExplicit: function() {
        var e = 0;
        this.getStore().each(function(t) {
            t.get("level") > 0 && ++e
        }, this), this.checkIfExceedExplicitCount(e) || (this.ACE_Store.suspendEvents(!1), this.getStore().each(function(e) {
            e.get("level") > 0 && (e.set("level", 0), this.addACE(e.data, !1))
        }, this), this.ACE_Store.resumeEvents(), this.ACE_Store.aclSort(), this.getStore().commitChanges(), this.isInherieted = !1, this.modifiedACL = !0, this.updateAdvancedBt())
    },
    addInherited: function() {
        this.el.isMasked() || this.el.mask(_T("common", "loading"), "x-mask-loading"), this.sendWebAPI({
            api: "SYNO.Core.ACL",
            method: "get",
            version: 1,
            scope: this,
            params: {
                type: "inherite",
                file_path: this.gTargetFiles
            },
            callback: function(e, t, i) {
                if (!this.isDestroyed) {
                    if (!e) {
                        var s = _T("common", "error_system");
                        return Ext.isDefined(t.code) && (s = SYNO.API.getErrorString(t.code)), this.el.mask(s), !1
                    }
                    this.getStore().loadData(t, !0), this.isInherieted = !0, this.updateAdvancedBt(), this.el.unmask()
                }
            }
        })
    },
    simplePermission: function(e, t, i) {
        var s = !1,
            r = !1,
            o = !1;
        if (e = i.get("permission"), "-" !== e.substr(15, 1)) return _T("acl_editor", "perm_custom");
        if ("Co" === e.substr(11, 2)) o = !0;
        else if ("--" !== e.substr(11, 2)) return _T("acl_editor", "perm_custom");
        if ("r" === e.charAt(0) && "x" === e.charAt(2) && "a" === e.charAt(6) && "R" === e.charAt(8) && "c" === e.charAt(10)) s = !0;
        else if ("r" === e.charAt(0) || "x" === e.charAt(2) || "a" === e.charAt(6) || "R" === e.charAt(8) || "c" === e.charAt(10)) return _T("acl_editor", "perm_custom");
        if ("w" === e.charAt(1) && "p" === e.charAt(3) && "d" === e.charAt(4) && "D" === e.charAt(5) && "A" === e.charAt(7) && "W" === e.charAt(9)) r = !0;
        else if ("w" === e.charAt(1) || "p" === e.charAt(3) || "d" === e.charAt(4) || "D" === e.charAt(5) || "A" === e.charAt(7) || "W" === e.charAt(9)) return _T("acl_editor", "perm_custom");
        return o ? s && r ? _T("acl_editor", "perm_full_control") : _T("acl_editor", "perm_custom") : s && r ? _T("filetable", "filetable_read") + " & " + _T("filetable", "filetable_write") : s ? _T("filetable", "filetable_read") : r ? _T("filetable", "filetable_write") : _T("acl_editor", "perm_custom")
    },
    updateToolBarBts: function() {
        for (var e = this.getSelectionModel(), t = e.getSelections(), i = !0, s = !0, r = !0, o = 0; o < t.length; ++o)
            if (0 !== t[o].get("level")) {
                r = !1;
                break
            } 0 >= t.length ? (i = !1, s = !1) : t.length > 1 && !r && (i = !0, s = !1), this.getTopToolbar().get("addbt").setDisabled(!this.hasChangePerm), this.getTopToolbar().get("deletebt").setDisabled(!(r && i && this.hasChangePerm)), this.getTopToolbar().get("modifybt").setDisabled(!s), this.hasChangePerm && r ? this.getTopToolbar().get("modifybt").setText(_T("common", "alt_edit")) : this.getTopToolbar().get("modifybt").setText(_T("acl_editor", "view"))
    },
    updateAdvancedBt: function() {
        var e = this.rec[0].get("isshare");
        this.isInherieted && this.hasChangePerm && !e ? (this.getTopToolbar().get("advancebt").menu.get("removeInherited").show(), this.getTopToolbar().get("advancebt").menu.get("makeInheritedExplicit").show()) : (this.getTopToolbar().get("advancebt").menu.get("removeInherited").hide(), this.getTopToolbar().get("advancebt").menu.get("makeInheritedExplicit").hide()), !1 === this.isInherieted && this.hasChangePerm && !e ? this.getTopToolbar().get("advancebt").menu.get("addInherited").show() : this.getTopToolbar().get("advancebt").menu.get("addInherited").hide(), !1 === this.hasChangePerm || e ? this.getTopToolbar().get("advancebt").menu.get("inherietMenuSP").hide() : this.getTopToolbar().get("advancebt").menu.get("inherietMenuSP").show(), this.checkModified() ? this.getTopToolbar().get("advancebt").menu.get("inspector").setDisabled(!0) : this.getTopToolbar().get("advancebt").menu.get("inspector").setDisabled(!1)
    }
}), Ext.define("SYNO.SDS.Share.ACLPrivilege.Utils", {
    statics: {
        PrintPermission: function(e) {
            return SYNO.SDS.Share.ACLPrivilege.Utils._PrintACLObject(SYNO.SDS.Share.ACLPrivilege.Utils._permission, e)
        },
        PrintInherit: function(e) {
            return SYNO.SDS.Share.ACLPrivilege.Utils._PrintACLObject(SYNO.SDS.Share.ACLPrivilege.Utils._inherit, e)
        },
        ParsePermissionString: function(e) {
            return SYNO.SDS.Share.ACLPrivilege.Utils._ParseACLString(SYNO.SDS.Share.ACLPrivilege.Utils._permission, e)
        },
        ParseInheritString: function(e) {
            return SYNO.SDS.Share.ACLPrivilege.Utils._ParseACLString(SYNO.SDS.Share.ACLPrivilege.Utils._inherit, e)
        },
        _PrintACLObject: function(e, t) {
            return e.reduce(function(e, i) {
                var s = _slicedToArray(i, 3),
                    r = s[0],
                    o = s[1],
                    a = s[2];
                return e + (t[r] !== a ? o : "-")
            }, "")
        },
        _ParseACLString: function(e, t) {
            return e.reduce(function(e, i) {
                var s = _slicedToArray(i, 3),
                    r = s[0],
                    o = s[1],
                    a = s[2];
                return e[r] = -1 !== t.indexOf(o) == !a, e
            }, {})
        },
        _permission: [
            ["read_data", "r", !1],
            ["write_data", "w", !1],
            ["exe_file", "x", !1],
            ["append_data", "p", !1],
            ["delete", "d", !1],
            ["delete_sub", "D", !1],
            ["read_attr", "a", !1],
            ["write_attr", "A", !1],
            ["read_ext_attr", "R", !1],
            ["write_ext_attr", "W", !1],
            ["read_perm", "c", !1],
            ["change_perm", "C", !1],
            ["take_ownership", "o", !1]
        ],
        _inherit: [
            ["child_files", "f", !1],
            ["child_folders", "d", !1],
            ["this_folder", "i", !0],
            ["all_descendants", "n", !0]
        ]
    }
}), Ext.define("SYNO.SDS.Share.ACLPrivilege.SelectableReadOnlyText", {
    extend: "SYNO.ux.TextField",
    constructor: function(e) {
        var t = Ext.apply({}, e);
        t.cls = "selectabletext ".concat(e.cls), t.readOnly = !0, this.callParent([t])
    }
}), Ext.define("SYNO.SDS.Share.ACLPrivilege.InheritCombo", {
    extend: "SYNO.ux.ComboBox",
    tpl: String.raw(_templateObject()),
    constructor: function(e) {
        var t = new Ext.data.SimpleStore({
                fields: ["id", "state", "check", "disable"],
                idIndex: 0,
                data: [
                    ["self", _T("acl_editor", "this_folder"), !1, !1],
                    ["cfolder", _T("acl_editor", "child_folders"), !1, !1],
                    ["cfile", _T("acl_editor", "child_files"), !1, !1],
                    ["descendants", _T("acl_editor", "all_descendants"), !1, !1]
                ]
            }),
            i = Ext.apply({
                fieldLabel: _T("acl_editor", "apply_to"),
                editable: !1,
                displayField: "state",
                store: t,
                mode: "local",
                triggerAction: "all",
                typeAhead: !0,
                selectOnFocus: !0,
                itemReadOnly: !1
            }, e);
        this.callParent([i])
    },
    onSelect: function(e) {
        this.itemReadOnly || (e.set("check", !e.get("check")), this._updateStatus())
    },
    setPermValue: function(e) {
        var t = this.getStore(),
            i = t.getById("self"),
            s = t.getById("cfolder"),
            r = t.getById("cfile"),
            o = t.getById("descendants");
        i.set("check", "-" === e.charAt(2)), s.set("check", "d" === e.charAt(1)), r.set("check", "f" === e.charAt(0)), o.set("check", "-" === e.charAt(3)), this._updateStatus()
    },
    getPermValue: function() {
        var e = [],
            t = this.getStore(),
            i = t.getById("self"),
            s = t.getById("cfolder"),
            r = t.getById("cfile"),
            o = t.getById("descendants");
        return e.push(r.get("check") ? "f" : "-"), e.push(s.get("check") ? "d" : "-"), e.push(i.get("check") ? "-" : "i"), e.push(o.get("check") ? "-" : "n"), e.join("")
    },
    _updateStatus: function() {
        var e = !1,
            t = !0,
            i = [];
        this.store.each(function(s) {
            s.get("check") ? ("cfolder" !== s.get("id") && "cfile" !== s.get("id") || (e = !0), ("descendants" !== s.get("id") || e) && i.push(s.get("state"))) : t = !1
        }), t ? this.setValue(_T("acl_editor", "all_scope")) : this.setValue(i.join(", ")), Ext.QuickTips.unregister(this.getEl()), Ext.QuickTips.register({
            target: this.getEl(),
            text: i.join("<br>")
        }), e ? this.store.getById("descendants").set("disable", !1) : (this.store.getById("descendants").set("check", !1), this.store.getById("descendants").set("disable", !0))
    }
}), Ext.define("SYNO.SDS.Share.ACLPrivilege.UserGrpOptionButton", {
    extend: "SYNO.ux.Button",
    constructor: function(e) {
        var t = {
                defaults: {
                    checked: !1
                },
                cls: "syno-ux-check-menu",
                width: 184,
                items: e.menuItems,
                listeners: {
                    scope: this,
                    itemclick: this.onMenuItemClick
                }
            },
            i = Ext.apply({
                cls: "acl-multiselect-filter-btn",
                iconCls: "syno-share-filter-btn",
                menuAlign: "tr-br?",
                menu: t,
                handler: function(e) {
                    e.showMenu()
                }
            }, e);
        this.callParent([i]), this.addEvents(["filterChanged"])
    },
    getItemValues: function() {
        var e = {};
        return this.menu.items.each(function(t) {
            e[t.itemId] = t.checked
        }, this), e
    },
    onMenuItemClick: function(e) {
        this.menu.items.each(function(t) {
            t.itemId !== e.itemId && t.setChecked(!1)
        }, this), this.fireEvent("filterChanged", this, {
            text: e.text,
            itemId: e.itemId,
            checked: !e.checked
        })
    }
}), Ext.define("SYNO.SDS.Share.ACLPrivilege.EditorDomainScopeCombo", {
    extend: "SYNO.ux.ComboBox",
    tpl: new Ext.XTemplate('\n\t<tpl for=".">\n\t<tpl if="Ext.isEmpty(values.value)">\n\t\t<div class="x-combo-list-item"> {values.display:htmlEncode} </div>\n\t</tpl>\n\t<tpl if="!Ext.isEmpty(values.value)">\n\t\t<div class="x-combo-list-item" ext:qtip="{[this.doubleEncode(values.value)]}">\n\t\t\t{values.display:htmlEncode}\n\t\t</div>\n\t</tpl>\n\t</tpl>\n\t', {
        doubleEncode: function(e) {
            return Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(e))
        }
    }),
    constructor: function(e) {
        this.store = new Ext.data.JsonStore({
            autoDestory: !0,
            idIndex: 0,
            root: "scopeList",
            idProperty: "value",
            fields: [{
                name: "display",
                mapping: "name"
            }, {
                name: "value",
                mapping: "detail"
            }]
        });
        var t = Ext.apply({
            mode: "local",
            allowBlank: !1,
            selectOnFocus: !0,
            itemReadOnly: !0,
            autoSelect: !0,
            typeAhead: !0,
            displayField: "display",
            valueField: "value",
            store: this.store
        }, e);
        this.callParent([t])
    },
    reconfigure: function(e) {
        var t = Ext.value(e.scopeList, []),
            i = !1;
        "domain:domain" === e.mode ? (this.fieldLabel = _T("acl_editor", "domain_scope_domain"), this.label.dom.innerText = "".concat(_T("acl_editor", "domain_scope_domain"), ":")) : "domain:ou" === e.mode ? (this.fieldLabel = _T("acl_editor", "domain_scope_ou"), this.label.dom.innerText = "".concat(_T("acl_editor", "domain_scope_ou"), ":")) : i = !0, Ext.isEmpty(t) && (i = !0);
        var s = {
            scopeList: [{
                name: _T("directory_service", "domainou_list_all_items"),
                detail: ""
            }].concat(t)
        };
        this.setVisible(!i), this.store.loadData(s), this.setValue(this.store.getAt(0).get("value"))
    },
    getValue: function() {
        return this.hidden ? "" : this.callParent(arguments)
    }
}), Ext.define("SYNO.SDS.Share.ACLPrivilege.EditorInfoPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        var t = new SYNO.API.Store({
            appWindow: e.appWindow,
            autoDestroy: !0,
            pruneModifiedRecords: !0,
            api: "SYNO.Core.ACL",
            method: "list_owners",
            version: 2,
            remoteSort: !0,
            reader: new Ext.data.JsonReader({
                root: "owners",
                totalProperty: "total",
                id: "value",
                fields: [{
                    name: "type"
                }, {
                    name: "name"
                }, {
                    name: "detail",
                    convert: function(e, t) {
                        var i = t.description || t.email || t.fullname,
                            s = [];
                        return s.push(Ext.value(t.description, "--")), s.push(Ext.value(t.email, "--")), s.push(Ext.value(t.fullname, "--")), i ? s.join(" / ") : ""
                    }
                }, {
                    name: "value",
                    convert: function(e, t) {
                        return "".concat(t.type, ":").concat(t.name)
                    }
                }, {
                    name: "iconType",
                    convert: function(e, t) {
                        return t.internal ? "internal" : t.type
                    }
                }, {
                    name: "checked"
                }]
            }),
            paramNames: {
                start: "offset",
                limit: "limit"
            },
            baseParams: {
                searchScope: [{
                    type: "builtin"
                }, {
                    type: "local"
                }, {
                    type: "ldap"
                }, {
                    type: "domain"
                }, {
                    type: "internal"
                }],
                keywordFields: {
                    name: !0
                }
            },
            listeners: {
                scope: this,
                beforeload: this.beforeStoreLoad
            }
        });
        this.domainScopeCombo = new SYNO.SDS.Share.ACLPrivilege.EditorDomainScopeCombo(Ext.apply({
            fieldLabel: _T("acl_editor", "domain_scope_domain"),
            listeners: {
                scope: this,
                select: function() {
                    this.ownerCombo.lastQuery = void 0
                }
            }
        }, e.domainScopeConfig)), this.ownerCombo = new SYNO.SDS.Share.ACLPrivilege.MultiSelectUserGrpCombo({
            fieldLabel: _T("acl_editor", "user_or_group"),
            itemId: "cmb_owner",
            queryParam: "keyword",
            store: t
        }), this.ownerComboFilter = new SYNO.SDS.Share.ACLPrivilege.UserGrpOptionButton({
            menuItems: [{
                text: _T("acl_editor", "usrgrp_filteroption_description"),
                itemId: "description"
            }, {
                text: _T("acl_editor", "usrgrp_filteroption_email"),
                itemId: "email"
            }, {
                text: _T("acl_editor", "usrgrp_filteroption_fullname"),
                itemId: "fullname"
            }],
            listeners: {
                scope: this,
                filterChanged: this.onFilterChanged
            }
        });
        var i = Ext.apply({
            autoScroll: !1,
            autoFlexcroll: !1,
            trackResetOnLoad: !0,
            hideMode: "display",
            border: !1,
            labelPad: 8,
            labelWidth: 200,
            defaults: {
                width: 352,
                listWidth: 352
            },
            items: [new SYNO.SDS.Share.ACLPrivilege.SelectableReadOnlyText({
                itemId: "file_name",
                fieldLabel: _T("common", "common_filename")
            }), this.domainScopeCombo, {
                xtype: "syno_compositefield",
                items: [Ext.apply(this.ownerCombo, {
                    width: 299,
                    listWidth: 299
                }), Ext.apply(this.ownerComboFilter, {
                    width: 47
                })]
            }, new SYNO.SDS.Share.ACLPrivilege.SelectableReadOnlyText({
                itemId: "inheriet_from",
                fieldLabel: _T("acl_editor", "inheriet_from")
            }), {
                xtype: "syno_combobox",
                fieldLabel: _T("acl_editor", "type"),
                itemId: "cmb_type",
                store: new Ext.data.ArrayStore({
                    fields: ["ace_type", "type"],
                    data: [
                        [_T("acl_editor", "allow"), "allow"],
                        [_T("acl_editor", "deny"), "deny"]
                    ]
                }),
                value: "allow",
                displayField: "ace_type",
                valueField: "type",
                triggerAction: "all",
                editable: !1,
                resizable: !1,
                allowBlank: !1,
                forceSelection: !0
            }, new SYNO.SDS.Share.ACLPrivilege.InheritCombo({
                itemId: "cmb_apply",
                maxHeight: 360
            })]
        }, e);
        this.callParent([i])
    },
    beforeStoreLoad: function(e, t) {
        var i = this.ownerComboFilter.getItemValues(),
            s = this.domainScopeCombo.getValue();
        t.params.keywordFields = Ext.apply({}, i, e.baseParams.keywordFields), Ext.isEmpty(s) || (t.params.searchScope = [], e.baseParams.searchScope.forEach(function(e) {
            "domain" === e.type ? t.params.searchScope.push(Ext.apply({}, {
                config: {
                    bindon: s
                }
            }, e)) : t.params.searchScope.push(e)
        }))
    },
    onFilterChanged: function(e, t) {
        t.checked ? this.getOwnerCombo().emptyText = String.format(_T("acl_editor", "usrgrp_emptytext_with_other"), _T("acl_editor", "usrgrp_filteroption_".concat(t.itemId, "_inline"))) : this.getOwnerCombo().emptyText = _T("acl_editor", "usrgrp_emptytext"), this.getOwnerCombo().applyEmptyText()
    },
    getOwnerCombo: function() {
        return this.ownerCombo
    },
    getOwnerComboFilter: function() {
        return this.ownerComboFilter
    },
    getDomainCombo: function() {
        return this.domainScopeCombo
    }
}), Ext.define("SYNO.SDS.Share.ACLPrivilege.EditorTreePanel", {
    extend: "SYNO.ux.TreePanel",
    constructor: function(e) {
        var t = new Ext.tree.TreeLoader({
                preloadChildren: !0,
                clearOnLoad: !1,
                baseAttrs: {
                    cls: "node_no_display",
                    uiProvider: SYNO.SDS.Share.ACLPrivilege.TreeNodeUI,
                    leaf: !0
                }
            }),
            i = Ext.apply({
                cls: "acl-tree",
                border: !1,
                enableDD: !1,
                useArrows: !0,
                rootVisible: !1,
                allNodeCheckable: !0,
                loader: t,
                root: new Ext.tree.AsyncTreeNode({
                    id: "tree_root",
                    expanded: !0,
                    children: this._getTreeNodeStructure()
                })
            }, e);
        this.callParent([i])
    },
    setAllNodeCheckable: function(e) {
        this.allNodeCheckable = e, this.getRootNode().eachChild(function(t) {
            t.getUI().setCheckable(e)
        })
    },
    _getTreeNodeStructure: function() {
        return [{
            text: _T("acl_editor", "administration"),
            id: "admin",
            leaf: !1,
            children: [{
                text: _T("acl_editor", "change_permissions"),
                id: "change_perm"
            }, {
                text: _T("acl_editor", "take_ownership"),
                id: "change_owner"
            }]
        }, {
            text: _T("filetable", "filetable_read"),
            id: "read",
            leaf: !1,
            children: [{
                text: _T("acl_editor", "travers_folder_execute_file"),
                id: "exe_file"
            }, {
                text: _T("acl_editor", "list_folder_read_data"),
                id: "read_data"
            }, {
                text: _T("acl_editor", "read_attributes"),
                id: "read_attr"
            }, {
                text: _T("acl_editor", "read_extended_atrributes"),
                id: "read_ext_attr"
            }, {
                text: _T("acl_editor", "read_permissions"),
                id: "read_perm"
            }]
        }, {
            text: _T("filetable", "filetable_write"),
            id: "write",
            leaf: !1,
            children: [{
                text: _T("acl_editor", "create_files_write_data"),
                id: "write_data"
            }, {
                text: _T("acl_editor", "create_folders_append_data"),
                id: "append_data"
            }, {
                text: _T("acl_editor", "write_attributes"),
                id: "write_attr"
            }, {
                text: _T("acl_editor", "write_extended_attributes"),
                id: "write_ext_attr"
            }, {
                text: _T("acl_editor", "delete_subfolders_and_files"),
                id: "delete_sub"
            }, {
                text: _T("acl_editor", "delete"),
                id: "delete"
            }]
        }]
    }
}), Ext.define("SYNO.SDS.Share.ACLPrivilege.EditorDialog", {
    extend: "SYNO.SDS.ModalWindow",
    permTreeTbl: [
        ["/tree_root/read/read_data", "r", !0],
        ["/tree_root/write/write_data", "w", !0],
        ["/tree_root/read/exe_file", "x", !0],
        ["/tree_root/write/append_data", "p", !0],
        ["/tree_root/write/delete", "d", !0],
        ["/tree_root/write/delete_sub", "D", !0],
        ["/tree_root/read/read_attr", "a", !0],
        ["/tree_root/write/write_attr", "A", !0],
        ["/tree_root/read/read_ext_attr", "R", !0],
        ["/tree_root/write/write_ext_attr", "W", !0],
        ["/tree_root/read/read_perm", "c", !0],
        ["/tree_root/admin/change_perm", "C", !0],
        ["/tree_root/admin/change_owner", "o", !0]
    ],
    WIN_HEIGHT: 580,
    constructor: function(e) {
        var t = Ext.apply({
            width: 600,
            height: this.WIN_HEIGHT,
            resizable: !1,
            collapsible: !1,
            bodyStyle: "padding: 0 20px 4px 20px;",
            closeAction: "hide",
            items: [new SYNO.SDS.Share.ACLPrivilege.EditorInfoPanel({
                appWindow: this,
                itemId: "info_panel",
                minHeight: 70,
                bodyStyle: "padding: 16px 0 0 0"
            }), new SYNO.SDS.Share.ACLPrivilege.EditorTreePanel({
                itemId: "perm_tree",
                title: _T("acl_editor", "permission"),
                autoHeight: !1,
                bodyStyle: "padding: 4px 2px 0px 4px;"
            })],
            buttons: [{
                text: _T("common", "cancel"),
                itemId: "cancel_btn",
                scope: this,
                handler: function() {
                    this.hide(), this.body.unmask()
                }
            }, {
                btnStyle: "blue",
                text: _T("common", "done"),
                itemId: "save_btn",
                handler: this.saveHandler,
                scope: this
            }],
            listeners: {
                scope: this,
                hide: function() {
                    this.getTaskRunner().stopAll()
                }
            }
        }, e);
        this.callParent([t]), this.addClass("acl-permission-win")
    },
    adjustDialog: function() {
        var e = SYNO.SDS.Desktop.getEl().getHeight(),
            t = this.getHeight(),
            i = this.get("info_panel").getHeight(),
            s = this.get("perm_tree").getHeight(),
            r = Math.min(this.WIN_HEIGHT, e),
            o = r - (t - i - s) - i;
        this.get("perm_tree").setHeight(o)
    },
    load: function(e) {
        Ext.apply(this, e), this.show(), this.fillComponent(), this.center()
    },
    fillComponent: function() {
        this.setupWindow(), this.fillFileName(), this.fillOwner(), this.fillInherietForm(), this.fillType(), this.fillPermission(), this.adjustDialog()
    },
    setupWindow: function() {
        this.getFooterToolbar().getComponent("save_btn").setVisible(!0), "edit" === this.mode || "add" === this.mode ? this.setTitle(_T("acl_editor", "permission_editor")) : "view" === this.mode ? (this.setTitle(_T("acl_editor", "permission_viewer")),
            this.getFooterToolbar().getComponent("save_btn").setVisible(!1)) : (this.setTitle(_T("acl_editor", "effective_permission_inspector")), this.getFooterToolbar().getComponent("save_btn").setVisible(!1))
    },
    fillFileName: function() {
        var e = this.get("info_panel").get("file_name");
        if ("inspector" !== this.mode) return void e.hide();
        e.show(), e.setValue(this.file_name)
    },
    fillOwner: function() {
        var e = this.get("info_panel").getOwnerCombo(),
            t = this.get("info_panel").getOwnerComboFilter(),
            i = this.get("info_panel").getDomainCombo(),
            s = [];
        e.reconfigure({
            multiselect: this.multiselect
        }), i.reconfigure(this.domainInfo), e.setReadOnly(!1), t.setDisabled(!1), "edit" === this.mode || "view" === this.mode ? (Ext.each(this.aceRC, function(e) {
            var t = new Ext.data.Record({
                name: e.get("user_name"),
                type: e.get("user_type"),
                iconType: e.get("user_is_internal") ? "internal" : e.get("user_type")
            });
            s.push(t)
        }), e.setValue(s), "view" === this.mode && (e.setReadOnly(!0), t.setDisabled(!0), i.setVisible(!1))) : this.isFirstLoad && "add" === this.mode && Ext.isObject(this.openConfig) ? (this.isFirstLoad = !1, s = [new Ext.data.Record({
            name: this.openConfig.userName,
            type: this.openConfig.userType,
            iconType: this.openConfig.userIsInternal ? "internal" : this.openConfig.userType
        })], e.setValue(s)) : e.clearValue(), "inspector" === this.mode ? (this.mon(e, "valueset", this.doInspect, this), e.getStore().baseParams.searchScope = [{
            type: "builtin",
            config: {
                owner: !1
            }
        }, {
            type: "local"
        }, {
            type: "ldap"
        }, {
            type: "domain"
        }], delete e.lastQuery) : (this.mun(e, "valueset", this.doInspect, this), e.getStore().baseParams.searchScope = [{
            type: "builtin"
        }, {
            type: "local"
        }, {
            type: "ldap"
        }, {
            type: "domain"
        }, {
            type: "internal"
        }], delete e.lastQuery)
    },
    fillInherietForm: function() {
        var e = this.get("info_panel").get("inheriet_from");
        if ("inspector" === this.mode) return void e.hide();
        e.show();
        var t = this.file_id;
        if (-1 !== ["add", "edit"].indexOf(this.mode)) t = "<" + _T("acl_editor", "not_inherited") + ">";
        else
            for (var i = 0; i < this.aceRC[0].get("level"); ++i) t = t.substr(0, t.lastIndexOf("/"));
        e.setValue(t)
    },
    fillType: function() {
        var e = this.get("info_panel").get("cmb_type");
        if ("inspector" === this.mode) return void e.hide();
        if (e.show(), e.setReadOnly(!1), -1 === ["edit", "view"].indexOf(this.mode) || this.multiselect) e.setValue("allow");
        else {
            var t = this.aceRC[0].get("type");
            e.setValue(t), "view" === this.mode && e.setReadOnly(!0)
        }
    },
    fillPermission: function() {
        var e = this.get("perm_tree"),
            t = this.get("info_panel").get("cmb_apply");
        e.setAllNodeCheckable(!0);
        var i = "-----------------"; - 1 === ["edit", "view"].indexOf(this.mode) || this.multiselect ? ("add" === this.mode || this.multiselect) && (i = this.isdir ? "-------------fd--" : "----------------n") : i = this.aceRC[0].get("permission"), this.fillApplyCmb(i.substr(13, 4)), this.fillPermissionTree(i), "view" === this.mode || "inspector" === this.mode ? (e.setAllNodeCheckable(!1), t.itemReadOnly = !0) : t.itemReadOnly = !1
    },
    fillApplyCmb: function(e) {
        var t = this.get("info_panel").get("cmb_apply");
        this.isdir ? t.show() : t.hide(), t.setPermValue(e)
    },
    fillPermissionTree: function(e) {
        function t(e, t) {
            e && t.ui.onCheckChange(r ? 2 : 1)
        }
        var i = this.get("perm_tree"),
            s = i.allNodeCheckable;
        i.setAllNodeCheckable(!0);
        for (var r = !0, o = 0; o < this.permTreeTbl.length; ++o) r = e.charAt(o) === this.permTreeTbl[o][1], !1 === this.permTreeTbl[o][2] && (r = !r), i.selectPath(this.permTreeTbl[o][0], "", t);
        i.setAllNodeCheckable(s)
    },
    doInspect: function(e) {
        var t = e.getValue();
        !e.valueNotFound() && t && "" !== t && (this.body.mask(_T("common", "loading"), "x-mask-loading"), this.sendWebAPI({
            api: "SYNO.Core.ACL",
            method: "inspect",
            version: 1,
            scope: this,
            params: {
                file_path: this.file_path,
                owner_type: t[0].get("type"),
                owner_name: t[0].get("name")
            },
            callback: function(e, t, i) {
                if (!this.isDestroyed)
                    if (e && t.permission) {
                        var s = SYNO.SDS.Share.ACLPrivilege.Utils.PrintPermission(t.permission);
                        this.fillPermissionTree(s), this.body.unmask()
                    } else {
                        var r = _T("common", "error_system");
                        Ext.isDefined(t.code) && (r = SYNO.API.getErrorString(t.code)), this.body.mask(r)
                    }
            }
        }))
    },
    saveHandler: function() {
        if ("view" === this.mode || "inspector" === this.mode) return void this.hide();
        var e = this.getACE();
        if (null !== e) {
            if ("add" === this.mode && e.length > this.acl_quota) {
                var t = _T("acl_editor", "acl_rules_reach_limit_report").replace("_count_", e.length).replace("_maxCount_", this.acl_quota);
                return void this.setStatusError({
                    text: t,
                    clear: !0
                })
            }
            var i = [];
            Ext.each(e, function(e) {
                i.push({
                    api: "SYNO.Core.ACL",
                    method: "check_admin",
                    version: 1,
                    params: {
                        owner_name: e.user_name,
                        owner_type: e.user_type
                    }
                })
            }, this), this.setStatusBusy({
                text: _T("common", "saving")
            }), this.sendWebAPI({
                params: {},
                compound: {
                    stopwhenerror: !0,
                    params: i
                },
                scope: this,
                callback: function(t, i, s) {
                    var r = !1,
                        o = "";
                    if (this.clearStatusBusy(), !t || i.has_fail) {
                        var a = SYNO.API.Util.GetFirstError(i);
                        return void this.setStatusError({
                            text: SYNO.API.getErrorString(a.code),
                            clear: !0
                        })
                    }
                    if (Ext.each(i.result, function(e, t) {
                            return r = r || e.data.is_admin, r && (o = s.compound[t].owner_name), !r
                        }), r) {
                        var n = String.format(_T("acl_editor", "adming_shouldnt_set_acl_perm"), o);
                        return void this.getMsgBox().confirm(_T("common", "reminder"), n, function(t) {
                            "yes" === t && (this.doAddACEToList(e), this.hide())
                        }, this)
                    }
                    this.doAddACEToList(e), this.hide()
                }
            })
        }
    },
    doAddACEToList: function(e) {
        "edit" === this.mode ? (this.aceRC.forEach(function(e) {
            this.fireEvent("deleteACE", e)
        }, this), Ext.each(e, function(e) {
            this.fireEvent("addACE", e)
        }, this)) : Ext.each(e, function(e) {
            this.fireEvent("addACE", e)
        }, this)
    },
    getACE: function() {
        var e = this.get("info_panel").getOwnerCombo(),
            t = e.getValue(),
            i = this.getPermission(),
            s = this.get("info_panel").get("cmb_type"),
            r = [],
            o = !0;
        return Ext.each(t, function(e) {
            r.push({
                user_type: e.get("type"),
                user_name: e.get("name"),
                user_is_internal: "internal" === e.get("iconType"),
                level: 0,
                type: s.getValue(),
                permission: i
            })
        }), Ext.isEmpty(r) ? (this.setStatusError({
            text: _T("acl_editor", "error_invalid_user_or_group"),
            clear: !0
        }), null) : (Ext.each(r, function(t) {
            this.verifyACE(t, e) || (o = !1)
        }, this), o ? r : null)
    },
    getPermission: function() {
        function e(e, t) {
            e && t.attributes.checked ? i += s : i += r
        }
        for (var t = this.get("perm_tree"), i = "", s = "", r = "", o = 0; o < this.permTreeTbl.length; ++o) this.permTreeTbl[o][2] ? (s = this.permTreeTbl[o][1], r = "-") : (s = "-", r = this.permTreeTbl[o][1]), t.selectPath(this.permTreeTbl[o][0], "", e);
        var a = this.get("info_panel").get("cmb_apply");
        return i += a.getPermValue()
    },
    verifyACE: function(e, t) {
        return t.valueNotFound() || null === e.user_name || "" === e.user_name || null === e.user_type || "" === e.user_type ? (this.setStatusError({
            text: _T("acl_editor", "error_invalid_user_or_group"),
            clear: !0
        }), !1) : "-------------" === e.permission.substr(0, 13) ? (this.setStatusError({
            text: _T("acl_editor", "error_empty_permission"),
            clear: !0
        }), !1) : !this.isdir || !e.permission.match("--in") || (this.get("info_panel").get("cmb_apply").focus(), this.get("info_panel").get("cmb_apply").expand(), this.setStatusError({
            text: _T("acl_editor", "error_empty_apply_to"),
            clear: !0
        }), !1)
    },
    isTheSameACE: function(e, t) {
        return e.get("level") === t.level && e.get("permission") === t.permission && e.get("type") === t.type && e.get("user_name") === t.user_name && e.get("user_type") === t.user_type
    }
}), Ext.define("SYNO.SDS.Share.ACLPrivilege.TreeNodeUI", {
    extend: "Ext.tree.TriTreeNodeUI",
    checkable: !0,
    checkCheckbox: function(e) {
        this.checkbox.checked = this.values[e], this.checkbox.className = this.checkedCls[e], this.node.attributes.checked = this.checkbox.checked
    },
    onCheckChange: function(e) {
        if (!1 !== this.checkable) {
            this.checkCheckbox(e), this.node.firstChild && this.updateChild(this.node.firstChild, e), !0 !== this.node.parentNode.isRoot && this.updateParent(this.node.parentNode, e);
            var t = this.checkbox.checked;
            this.fireEvent("checkchange", this.node, t)
        }
    },
    updateParent: function(e, t) {
        if (t != this.getCheckIndex(e)) {
            var i = this.checkchildstate(e);
            e.getUI().checkCheckbox(i), e.getUI().wrap.setAttribute("aria-checked", Ext.tree.TriTreeNodeUI.ARIATRISTATE[i]), !0 !== e.parentNode.isRoot && this.updateParent(e.parentNode, i)
        }
    },
    updateChild: function(e, t) {
        var i = e;
        do {
            !0 !== i.getUI().rendered && i.getUI().render(), i.getUI().checkCheckbox(t), i.getUI().wrap.setAttribute("aria-checked", Ext.tree.TriTreeNodeUI.ARIATRISTATE[t]), i.firstChild && this.updateChild(i.firstChild, t), i = i.nextSibling
        } while (i)
    },
    checkchildstate: function(e) {
        var t = e.firstChild;
        if (!t) return this.err;
        for (var i = this.getCheckIndex(t); t;) {
            if (this.getCheckIndex(t) !== i) return Ext.tree.TriTreeNodeUI.GRAYSTATE;
            t = t.nextSibling
        }
        return i
    },
    onDblClick: function(e) {},
    onSelectedChange: function(e) {},
    onOver: function(e) {},
    setCheckable: function(e) {
        this.checkable = e, this.node.eachChild(function(t) {
            t.getUI().setCheckable(e)
        })
    }
}), 
/**
 * @class SYNO.SDS.Share.ACLPrivilege.IconCombo
 * @extends SYNO.ux.ComboBox
 * Share ACL privilege icon combo class
 *
 */
Ext.define("SYNO.SDS.Share.ACLPrivilege.IconCombo", {
    extend: "SYNO.ux.ComboBox",
    defaultValue: null,
    initComponent: function() {
        Ext.apply(this, {
            tpl: '\n\t\t\t\t<tpl for=".">\n\t\t\t\t<div class="x-combo-list-item acl-icon-combo-item '.concat(this.iconClsPrefix, "{").concat(this.iconClsField, '}"\n\t\t\t\t\t role="option" aria-label="{').concat(this.displayField, '}" id={[Ext.id]}>\n\t\t\t\t\t{').concat(this.displayField, "}\n\t\t\t\t</div>\n\t\t\t\t</tpl>\n\t\t\t")
        }), SYNO.SDS.Share.ACLPrivilege.IconCombo.superclass.initComponent.call(this)
    },
    onRender: function(e, t) {
        SYNO.SDS.Share.ACLPrivilege.IconCombo.superclass.onRender.call(this, e, t), this.el.addClass("acl-icon-combo-input")
    },
    onFocus: function(e, t) {
        SYNO.SDS.Share.ACLPrivilege.IconCombo.superclass.onFocus.call(this, e, t), this.getRawValue() === this.valueNotFoundText && (this.clearValue(), this.clearIconCls())
    },
    clearIconCls: function() {
        null !== this.iconCls && (this.removeClass("acl-icon-combo-icon"), this.removeClass(this.iconCls), this.iconCls = null)
    },
    setIconCls: function(e) {
        this.clearIconCls(), this.addClass("acl-icon-combo-icon"), this.iconCls = this.iconClsPrefix + e, this.addClass(this.iconCls)
    },
    setValue: function(e) {
        SYNO.SDS.Share.ACLPrivilege.IconCombo.superclass.setValue.call(this, e);
        var t = this.store.query(this.valueField, this.getValue()).itemAt(0);
        t ? (this.setIconCls(t.get(this.iconClsField)), this.fireEvent("valueset", this)) : this.clearIconCls()
    },
    setDefaultValue: function(e, t, i) {
        var s = this.valueField;
        this.valueField = null, SYNO.SDS.Share.ACLPrivilege.IconCombo.superclass.setValue.call(this, e), this.setIconCls(t), this.defaultValue = e, this.value = i, this.valueField = s
    },
    assertValue: function() {
        this.getRawValue() !== this.defaultValue && SYNO.SDS.Share.ACLPrivilege.IconCombo.superclass.assertValue.call(this)
    },
    valueNotFound: function() {
        return this.lastSelectionText === this.valueNotFoundText
    }
}), Ext.define("SYNO.SDS.Share.ACLPrivilege.UserGrpCombo", {
    extend: "SYNO.SDS.Share.ACLPrivilege.IconCombo",
    labelStyle: "margin-left: 0px; width: 180px;",
    displayField: "name",
    iconClsField: "type",
    iconClsPrefix: "acl-combo-item-",
    valueField: "value",
    triggerAction: "all",
    mode: "remote",
    pageSize: 50,
    editable: !0,
    listEmptyText: _T("acl_editor", "error_invalid_user_or_group"),
    valueNotFoundText: _T("acl_editor", "error_invalid_user_or_group"),
    grow: !0,
    maxHeight: 360,
    minChars: 1,
    typeAhead: !0
}), Ext.define("SYNO.SDS.Share.ACLPrivilege.MultiSelectIconCombo", {
    extend: "SYNO.ux.ComboBox",
    multiselect: !1,
    showDetail: !0,
    selectedField: [],
    lastValueField: "",
    constructor: function(e) {
        var t = new Ext.XTemplate('\n<tpl for=".">\n\t<div class="x-combo-list-item x-form-check-wrap syno-ux-form-check-wrap {[(this.combo.showDetail && values.detail) ? "acl-item-large" : ""]}"\n\t\t\trole="option"\n\t\t\taria-label="{'.concat(e.displayField, '}"}\n\t\t\t>\n\t\t<tpl if="this.combo.multiselect">\n\t\t<div class="acl-item-checkbox">\n\t\t\t<div class="syno-ux-checkbox-icon {[values.checked ? "syno-ux-cb-checked" : ""]}"></div>\n\t\t</div>\n\t\t</tpl>\n\t\t<div class="acl-item-category-icon">\n\t\t\t<div class="').concat(e.iconClsPrefix, "{").concat(e.iconClsField, '}"></div>\n\t\t</div>\n\t\t<div class="acl-item-desc">\n\t\t\t<div>\n\t\t\t\t<div class="item-title"\n\t\t\t\t\t ext:qtip="{[this.combo._printTipMessage(values,"').concat(e.displayField, '")]}">\n\t\t\t\t\t{[values["').concat(e.displayField, '"]]}\n\t\t\t\t</div>\n\t\t\t\t<tpl if="this.combo.showDetail && values.detail">\n\t\t\t\t<div class="item-status">\n\t\t\t\t{[Ext.util.Format.htmlEncode(values.detail)]}\n\t\t\t\t</div>\n\t\t\t\t</tpl>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n</tpl>\n\t\t'), {
                combo: this
            }),
            i = Ext.apply({
                cls: "acl-multiselect-icon-combo",
                listClass: "x-layer x-combo-list syno-ux-combobox-list acl-multiselect-icon-combo",
                tpl: t
            }, e);
        this.callParent([i]), this.mon(this.store, "load", this.updateStoreChecked, this), this.addListener("expand", this.expandCleanValueField, this), this.addListener("blur", this.updateValueField, this)
    },
    reconfigure: function(e) {
        this.store = Ext.value(e.store, this.store), this.multiselect = Ext.value(e.multiselect, this.multiselect), this.showDetail = Ext.value(e.showDetaul, this.showDetail), this.setValue([])
    },
    onSelect: function(e, t) {
        if (!1 !== this.fireEvent("beforeselect", this, e, t)) {
            var i = e.copy();
            if (this.multiselect) {
                var s = !e.get("checked");
                e.set("checked", s), s ? this.selectedField.push(i) : this.selectedField = this.selectedField.filter(function(t) {
                    return t.get(this.displayField) !== e.get(this.displayField)
                }, this)
            } else this.setValue([i]), this.collapse();
            this.fireEvent("select", this, e, t)
        }
    },
    _printTipMessage: function(e, t) {
        return e.detail ? "".concat(e[t], "<br/>").concat(function(e) {
            return Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(e))
        }(e.detail)) : e[t]
    },
    clearIconCls: Ext.emptyFn,
    clearValue: function() {
        this.selectedField = [], this.store.each(function(e) {
            e.set("checked", !1)
        }), this.store.commitChanges(), this.updateValueField()
    },
    setValue: function(e) {
        if (!Ext.isArray(e)) throw Error("invalid selectedField");
        this.selectedField = e, this.updateStoreChecked(), this.updateValueField(), Ext.isEmpty(this.selectedField) || this.fireEvent("valueset", this)
    },
    getValue: function() {
        return this.selectedField
    },
    expandCleanValueField: function() {
        this.getRawValue() === this.lastValueField && this.setRawValue("")
    },
    updateStoreChecked: function() {
        this.store.each(function(e) {
            var t = e.get(this.displayField),
                i = this.selectedField.find(function(e) {
                    return t === e.get(this.displayField)
                }, this);
            e.set("checked", Boolean(i))
        }, this), this.store.commitChanges()
    },
    updateValueField: function() {
        if (Ext.QuickTips.unregister(this.getEl()), 0 === this.selectedField.length) return this.lastValueField = "", this.setRawValue(""), this.removeClass("acl-icon-combo-icon"), this.removeClass(this.iconCls), this.iconCls = null, void this.syncSize();
        if (this.lastValueField = this.joinSelectedField(", "), this.setRawValue(this.lastValueField), this.removeClass("acl-icon-combo-icon"), this.removeClass(this.iconCls), this.iconCls = null, 1 === this.selectedField.length) {
            var e = this.selectedField[0].get("type"),
                t = this.selectedField[0].get(this.iconClsField);
            this.addClass("acl-icon-combo-icon"), this.iconCls = "".concat(this.iconClsPrefix).concat(t || e), this.addClass(this.iconCls)
        }
        this.syncSize(), Ext.QuickTips.register({
            target: this.getEl(),
            text: this.getRawValue()
        })
    },
    joinSelectedField: function(e) {
        return this.selectedField.map(function(e) {
            return e.get(this.displayField)
        }, this).join(e)
    },
    assertValue: Ext.emptyFn,
    valueNotFound: function() {
        return 0 === this.selectedField.length
    },
    setRawValue: function(e) {
        this.callParent([e]), this.originalValue = e
    }
}), Ext.define("SYNO.SDS.Share.ACLPrivilege.MultiSelectUserGrpCombo", {
    extend: "SYNO.SDS.Share.ACLPrivilege.MultiSelectIconCombo",
    constructor: function(e) {
        var t = Ext.apply({
            displayField: "name",
            iconClsField: "iconType",
            iconClsPrefix: "acl-combo-item-",
            valueField: "value",
            triggerAction: "all",
            mode: "remote",
            pageSize: 50,
            lazyInit: !1,
            editable: !0,
            listEmptyText: _T("acl_editor", "error_invalid_user_or_group"),
            grow: !0,
            maxHeight: 360,
            minChars: 0,
            autoSelect: !1
        }, e);
        this.callParent([t])
    }
}), Ext.namespace("SYNO.SDS.CPUtils"), SYNO.SDS.CPUtils.createTimeItemStore = function(e) {
    var t = [],
        i = {
            hour: 24,
            min: 60,
            sec: 60
        };
    if (e in i) {
        for (var s = 0; s < i[e]; s++) t.push([s, String.leftPad(String(s), 2, "0")]);
        return new Ext.data.SimpleStore({
            id: 0,
            fields: ["value", "display"],
            data: t
        })
    }
    return null
}, SYNO.SDS.CPUtils.clearInvalidOnDisabled = function(e) {
    e.items.each(function(e, t, i) {
        e.isFormField && e.clearInvalid && e.mon(e, "disable", e.clearInvalid, e)
    })
}, SYNO.SDS.CPUtils.formErrinfoString = function(e, t) {
    var i = Ext.isString(t) ? t : "";
    if (e && !0 !== e.success && e.errinfo) {
        var s = e.errinfo;
        i = _T(s.sec, s.key), "" === i && (i = String.format("{0}:{1}", s.sec, s.key)), Ext.isString(s.desc) && (i = String.format("{0} ({1})", i, s.desc)), Ext.isNumber(s.line) && (i = String.format("{0} ({1})", i, s.line))
    }
    return i
}, SYNO.SDS.CPUtils.reportAjaxResponse = function(e, t, i, s) {
    var r = "",
        o = null;
    if (e) {
        if (Ext.isString(t.responseText)) try {
            o = Ext.decode(t.responseText)
        } catch (e) {
            SYNO.Debug("exception: responseText:", t.responseText), r = "Unknown exception"
        }
        r = SYNO.SDS.CPUtils.formErrinfoString(o, r)
    } else r = _T("common", "commfail");
    return r && i && (s = s || this, i.call(s, r)), o
}, SYNO.SDS.CPUtils.reportFormFail = function(e, t, i, s) {
    var r;
    if (t.failureType === Ext.form.Action.CLIENT_INVALID) r = _T("common", "forminvalid");
    else if (t.failureType === Ext.form.Action.CONNECT_FAILURE) r = _T("common", "commfail");
    else if (Ext.isObject(t.result.errinfo)) {
        var o = t.result.errinfo;
        r = _T(o.sec, o.key), "" === r && (r = String.format("{0}{1}", o.sec, o.key)), Ext.isNumber(o.line) && (r = String.format("{0} ({1})", r, o.line))
    } else r = t.failureType === Ext.form.Action.SERVER_INVALID ? _T("error", "error_bad_field") : _T("common", "error_system");
    r && i && (s = s || this, i.call(s, r))
};
