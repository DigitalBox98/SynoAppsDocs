/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.namespace("SYNO.SDS.AdminCenter.Share.PermissionReport"), 
/**
 * @class SYNO.SDS.AdminCenter.Share.PermissionReport.TrayApp
 * @extends SYNO.SDS.AppInstance
 * Share application instance class
 *
 */
SYNO.SDS.AdminCenter.Share.PermissionReport.TrayApp = Ext.extend(SYNO.SDS.AppInstance, {
    initInstance: function(t) {
        this.trayItem = this.trayItem || [], this.trayItem[0] || (this.trayItem[0] = new SYNO.SDS.AdminCenter.Share.PermissionReport.Tray({
            appInstance: this
        }), this.addInstance(this.trayItem[0]), this.trayItem[0].open(t))
    }
}), Ext.define("SYNO.SDS.AdminCenter.Share.PermissionReport.Tray", {
    extend: "SYNO.SDS.Tray.ArrowTray",
    initPanel: function() {
        return new SYNO.SDS.AdminCenter.Share.PermissionReport.Traypanel({
            module: this
        })
    }
}), Ext.define("SYNO.SDS.AdminCenter.Share.PermissionReport.Traypanel", {
    extend: "SYNO.SDS.Tray.Panel",
    constructor: function(t) {
        this.POLLING_INTERVAL = 5, this.cancelJobList = [];
        var e = Ext.apply({
            module: t.module,
            hidden: !0,
            title: _T("perm_report", "export_report_title"),
            width: 320,
            cls: "permission-report-tray sds-window-v5",
            id: "permission-report-background-task",
            bodyCssClass: "permission-report-tray-body",
            renderTo: document.body
        }, t);
        this.callParent([e]), this.startPolling()
    },
    createObjs: function(t, e, i, s) {
        this.closeBox = new Ext.Component({
            cls: "close-btn-wrap",
            html: '<div class="close-btn"></div>',
            bgtaskid: i,
            owner: this,
            listeners: {
                render: function(t) {
                    t.getEl().on({
                        click: function() {
                            t.owner.cancelJobList.push(t.bgtaskid), t.owner.sendWebAPI({
                                api: "SYNO.Core.Share.PermissionReport",
                                version: 1,
                                method: "export_stop",
                                params: {
                                    bg_taskid: t.bgtaskid
                                }
                            }), t.owner.removeCancelJob()
                        }
                    })
                }
            }
        });
        var n = Ext.util.Format.number(e, "0,000"),
            r = String.format(_T("perm_report", "export_progress_desc"), n);
        return {
            xtype: "container",
            cls: "permission-report-tray-content",
            bgtaskid: i,
            id: "tray-item-" + String(s),
            items: [{
                xtype: "container",
                cls: "permission-report-tray-search-icon"
            }, {
                xtype: "container",
                width: "auto",
                items: [{
                    xtype: "syno_displayfield",
                    cls: "desc",
                    html: r
                }, {
                    xtype: "syno_displayfield",
                    cls: "time",
                    html: String.format(_T("perm_report", "tray_starting_time"), t)
                }, this.closeBox]
            }]
        }
    },
    getItems: function() {
        return this.items.items
    },
    removeJob: function(t) {
        for (var e = this.getItems(), i = 0; i < e.length; i++)
            if (e[i] && e[i].bgtaskid === t) {
                this.remove(e[i]), this.doLayout();
                break
            } this.items.length <= 0 && this.removePanel()
    },
    removeCancelJob: function() {
        for (var t = 0; t < this.cancelJobList.length; t++) this.removeJob(this.cancelJobList[t])
    },
    startPolling: function() {
        this.polling_id || (this.polling_id = this.pollReg({
            interval: this.POLLING_INTERVAL,
            immediate: !0,
            webapi: {
                api: "SYNO.Core.Share.PermissionReport",
                method: "export_bg_status",
                version: 1
            },
            scope: this,
            status_callback: this.polling_callback
        }))
    },
    stopPolling: function() {
        this.pollUnreg(this.polling_id), this.polling_id = void 0
    },
    polling_callback: function(t, e, i) {
        for (var s = this.cancelJobList, n = [], r = [], o = 1, a = 0; a < e.length; a++) e[a].finished || (-1 < s.indexOf(e[a].id) ? n.push(e[a].id) : (r.push(this.createObjs(e[a].time, e[a].output, e[a].id, o)), o++));
        this.removeAll(), this.add(r), this.doLayout(), this.items.length > 0 ? this.module.setTaskButtonVisible(!0) : this.removePanel(), this.cancelJobList = n
    },
    removePanel: function() {
        this.module.onClose(), this.stopPolling(), this.module.setTaskButtonVisible(!1)
    }
});
