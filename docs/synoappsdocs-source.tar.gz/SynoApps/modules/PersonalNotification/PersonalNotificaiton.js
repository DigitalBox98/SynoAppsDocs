/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.PersonalNotification");
/**
 * @class SYNO.SDS.PersonalNotification.SettingFormPanel
 * @extends SYNO.ux.FormPanel
 * PersonalNotification setting form panel class
 *
 */
Ext.define("SYNO.SDS.PersonalNotification.SettingFormPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(a) {
        if (!a || !a.pkgName || !a.appWin) {
            SYNO.Debug("Error: no config.pkgName or config.appWin input.");
            return
        }
        if (false === a.buttons) {
            a.fbar = false
        }
        this.pkgName = a.pkgName;
        this.appWin = a.appWin;
        this.mobileDisabled = a.mobileDisabled || false;
        this.test_mail_tag = a.test_mail_tag;
        this.callParent([this.fillConfig(a)]);
        this.mon(this, "afterlayout", this.onAfterLayout, this, {
            single: true
        })
    },
    action: function(a) {
        if ("save" === a) {
            this.applyForm()
        } else {
            if ("cancel" === a) {
                this.cancelForm()
            }
        }
    },
    fillConfig: function(b) {
        var c = {
            get: {},
            set: {}
        };
        c.set["package"] = c.get["package"] = this.pkgName;
        var a = {
            itemId: "SettingFormPanel",
            title: _T("notification", "notify_settings"),
            trackResetOnLoad: true,
            webapi: {
                api: "SYNO.Core.PersonalNotification.Settings",
                methods: {
                    get: "get",
                    set: "set"
                },
                version: 1,
                params: c
            },
            items: [{
                xtype: "syno_checkbox",
                name: "email_enable",
                boxLabel: _T("notification", "mail_notification_enable")
            }, {
                xtype: "syno_combobox",
                name: "email_provider",
                allowBlank: false,
                indent: 1,
                width: 280,
                fieldLabel: _T("mail", "mail_from_desc"),
                value: "",
                valueField: "value",
                displayField: "account",
                mode: "remote",
                listeners: {
                    beforequery: function(d) {
                        delete d.combo.lastQuery
                    }
                },
                store: new SYNO.API.Store({
                    autoDestroy: true,
                    appWindow: this.appWin,
                    api: "SYNO.PersonMailAccount",
                    method: "get",
                    version: 1,
                    reader: new Ext.data.JsonReader({
                        root: "data",
                        fields: [{
                            name: "value",
                            convert: this.composeMailValue
                        }, {
                            name: "account",
                            convert: this.composeMailDislpayName
                        }]
                    }),
                    listeners: {
                        exception: this.luanchMailSettings,
                        load: this.onLoadMail,
                        scope: this
                    }
                })
            }, {
                xtype: "syno_textfield",
                name: "email_recipient",
                width: 280,
                maxlength: 256,
                indent: 1,
                fieldLabel: _T("notification", "mail_recipient"),
                allowBlank: false,
                vtype: "email"
            }, {
                xtype: "syno_checkbox",
                name: "mobile_enable",
                hidden: b.mobileDisabled,
                boxLabel: _T("pushservice", "pushservice_mobile_enable")
            }, {
                xtype: "syno_button",
                text: _T("pushservice", "pushservice_manage_mobile_device"),
                hidden: b.mobileDisabled,
                indent: 1,
                id: this.mobileManBtnId = Ext.id(),
                scope: this,
                handler: this.onClickManMobileBtn
            }, {
                disabled: this.appWin._S("demo_mode"),
                tooltip: this.appWin._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                xtype: "syno_button",
                text: _T("pushservice", "pushservice_send_test_notification"),
                id: this.testBtnId = Ext.id(),
                scope: this,
                handler: this.onClickTestNotificationBtn
            }],
            buttons: [{
                xtype: "syno_button",
                btnStyle: "blue",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                text: _T("common", "commit"),
                scope: this,
                handler: this.applyForm
            }, {
                xtype: "syno_button",
                btnStyle: "grey",
                text: _T("common", "reset"),
                scope: this,
                handler: this.cancelForm
            }]
        };
        return this.addsStatusBar(Ext.apply(a, b))
    },
    onAfterLayout: function() {
        this.loadForm();
        this.enableCheckGroup();
        this.getForm().isDirty = function() {
            if (this.findField("email_enable").getValue() && "" === this.findField("email_provider").getValue()) {
                return true
            }
            var a = false;
            this.items.each(function(b) {
                if (b.isDirty()) {
                    a = true;
                    return false
                }
            });
            return a
        }
    },
    loadForm: function() {
        var a = SYNO.ux.Utils.getApiArray(this, "get", 0, 3)[0];
        Ext.apply(a, {
            scope: this,
            callback: function(c, b) {
                if (c) {
                    if (b.email_provider) {
                        this.form.findField("email_provider").getStore().loadData({
                            data: [Ext.decode(b.email_provider)]
                        })
                    }
                    if (b.mobile_enable && this.mobileDisable) {
                        b.mobile_enable = false
                    }
                    this.form.setValues(b);
                    if (b.email_enable) {
                        this.form.findField("email_provider").getStore().reload()
                    }
                }
            }
        });
        this.sendWebAPI(a)
    },
    applyForm: function() {
        if (this.isDirty() && this.isValid()) {
            var b = this.form.getFieldValues();
            var a = SYNO.ux.Utils.getApiArray(this, "set", 0, 3)[0];
            Ext.apply(a.params, b);
            Ext.apply(a, {
                scope: this,
                callback: function(d, c) {
                    this.setStatusOK();
                    if (d) {
                        this.form.setValues(b)
                    }
                }
            });
            this.setStatusBusy({
                text: _T("common", "saving")
            });
            this.sendWebAPI(a)
        }
    },
    cancelForm: function() {
        this.getForm().reset()
    },
    isValid: function() {
        return this.getForm().isValid()
    },
    isDirty: function() {
        return this.getForm().isDirty()
    },
    enableCheckGroup: function() {
        var a, b;
        a = new SYNO.ux.Utils.EnableCheckGroup(this.form, "email_enable", ["email_recipient", "email_provider"]);
        b = new SYNO.ux.Utils.EnableCheckGroup(this.form, "mobile_enable", [this.mobileManBtnId])
    },
    composeMailDislpayName: function(a, d) {
        var c = d.sender_account || d.account;
        var b = SYNO.SDS.App.MailDialog.Utils.getEmailProviderName(d.email_type);
        return c + " (" + b + ")"
    },
    composeMailValue: function(a, b) {
        return Ext.encode({
            account: b.account,
            sender_account: b.sender_account,
            alias: b.alias,
            email_type: b.email_type
        })
    },
    onLoadMail: function(a) {
        var c = this.form.findField("email_provider");
        var b = c.getValue();
        if (0 < b.length) {
            if (-1 < a.find("value", b)) {
                c.setValue(b)
            } else {
                return this.appWin.getMsgBox().alert("", _T("mail", "email_setting_not_exist"), function() {
                    c.clearValue();
                    c.originalValue = ""
                }, this)
            }
        }
        if (!a.data.length) {
            this.luanchMailSettings()
        }
    },
    luanchMailSettings: function() {
        this.appWin.getMsgBox().confirm("Title", _T("mail", "mail_setup_hint"), function(a) {
            if ("yes" === a) {
                SYNO.SDS.AppLaunch("SYNO.SDS.App.PersonalSettings.Instance", {
                    tab: "emailAccountForm"
                })
            }
        }, this)
    },
    onClickManMobileBtn: function() {
        var a = new SYNO.SDS.PersonalNotification.PairedMobileDialog({
            owner: this.appWin,
            pkgName: this.pkgName
        });
        a.open()
    },
    onClickTestNotificationBtn: function() {
        var a = {
            user: this._S("user")
        };
        a["package"] = this.pkgName;
        if (this.test_mail_tag) {
            a.tag = this.test_mail_tag
        }
        this.sendWebAPI({
            api: "SYNO.Core.PersonalNotification.Event",
            method: "fire",
            version: 1,
            params: a,
            scope: this,
            callback: function(c, b) {
                this.appWin.getMsgBox().alert(_T("notification", "pushservice"), _T("pushservice", "pushservice_test_notification_sent"))
            }
        })
    }
});
Ext.ns("SYNO.SDS.PersonalNotification");
Ext.define("SYNO.SDS.PersonalNotification.FilterGridPanel", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(a) {
        if (!a || !a.pkgName || !a.appWin) {
            SYNO.Debug("Error: no config.pkgName or config.appWin input.");
            return
        }
        this.pkgName = a.pkgName;
        this.appWin = a.appWin;
        this.mobileDisabled = a.mobileDisabled || false;
        Ext.apply(this, {
            filterSettingData: null,
            defaultFilterValue: "All",
            targets: ["mail", "mobile", "desktop"]
        });
        this.callParent([this.fillConfig(a)])
    },
    action: function(a) {
        if ("save" === a) {
            this.onClickSaveSetting()
        } else {
            if ("cancel" === a) {
                this.reset()
            }
        }
    },
    fillConfig: function(e) {
        var c = new SYNO.ux.EnableColumn({
            id: "mail",
            header: _T("helptoc", "notification_email"),
            width: 100,
            sortable: false,
            dataIndex: "mail",
            align: "center",
            enableFastSelectAll: true
        });
        var b = new SYNO.ux.EnableColumn({
            id: "mobile",
            hidden: e.mobileDisabled,
            header: _T("pushservice", "pushservice_mobile"),
            width: 100,
            sortable: false,
            dataIndex: "mobile",
            align: "center",
            enableFastSelectAll: true
        });
        var f = new SYNO.ux.EnableColumn({
            id: "desktop",
            header: _T("notification", "title_desktop"),
            width: 100,
            sortable: false,
            dataIndex: "desktop",
            align: "center",
            enableFastSelectAll: true
        });
        var a = new Ext.grid.ColumnModel({
            columns: [{
                header: _T("notification", "notification_title"),
                width: 200,
                sortable: true,
                parentid: this.id,
                dataIndex: "title",
                id: "title",
                renderer: function(i, g, h) {
                    if (0 > h.data.warnPercent) {
                        return String.format('<div ext:qtip="{0}">{0}</div>', i)
                    }
                    return String.format('<div ext:qtip="{0}">{0}<a href = javascript:void(0) tabindex="-1"><{1}%></a></div>', i, h.data.warnPercent)
                }
            }, c, b, f, {
                header: "Group",
                sortable: false,
                dataIndex: "group",
                hidden: true
            }]
        });
        this.filterSettingStore = new Ext.data.GroupingStore({
            reader: new Ext.data.JsonReader({
                idProperty: "name",
                fields: [{
                    name: "name"
                }, {
                    name: "title"
                }, {
                    name: "mail"
                }, {
                    name: "desktop"
                }, {
                    name: "mobile"
                }, {
                    name: "group"
                }, {
                    name: "warnPercent"
                }, {
                    name: "pkg_name"
                }]
            }),
            data: [],
            groupField: "group",
            autoDestroy: true
        });
        var d = {
            itemId: "filterTab",
            title: _T("notification", "notification_filter"),
            listeners: {
                activate: this.onCategoryChange,
                cellclick: this.onGridCellClick,
                scope: this
            },
            store: this.filterSettingStore,
            colModel: a,
            plugins: [c, b, f],
            enableColLock: false,
            enableHdMenu: false,
            enableColumnMove: false,
            colMail: c,
            colMobile: b,
            colDesktop: f,
            clicksToEdit: 1,
            sm: new Ext.grid.RowSelectionModel({
                singleSelect: true
            }),
            stripeRows: true,
            tbar: new Ext.Toolbar({
                items: this.getTbarItems(),
                id: this.tbarId = Ext.id()
            }),
            view: new SYNO.ux.GroupingView({
                showGroupName: false,
                enableGroupingMenu: false
            })
        };
        if (false === e.buttons) {
            d.tbar = false
        }
        return Ext.apply(d, e)
    },
    reset: function() {
        this.notificationFilter.setValue(this.defaultFilterValue);
        this.filterSettingData = null
    },
    onGridCellClick: function(a, d, b, c) {},
    getTbarItems: function() {
        var a = new Ext.data.ArrayStore({
            autoDestroy: true,
            fields: ["display", "value"],
            data: [
                [_T("notification", "category_all"), "All"]
            ]
        });
        this.notificationFilter = new SYNO.ux.ComboBox({
            width: 200,
            maxHeight: 400,
            valueField: "value",
            displayField: "display",
            store: a,
            triggerAction: "all",
            mode: "local",
            editable: false,
            resizable: true,
            value: this.defaultFilterValue,
            tpl: '<tpl for="."><div role="option" aria-label="{display}" id="{[Ext.id()]}" class="x-combo-list-item {additionalCls}"><tpl if="(value != \'\')"><li></tpl>{display}<tpl if="(value != \'\')"></li></tpl></div></tpl>',
            listeners: {
                scope: this,
                select: this.onCategoryChange,
                beforeselect: this.onBeforeCategoryChange
            }
        });
        return [{
            xtype: "syno_button",
            id: this.saveBtnId = Ext.id(),
            text: _T("common", "save"),
            scope: this,
            handler: this.onClickSaveSetting
        }, "->", this.notificationFilter]
    },
    onBeforeCategoryChange: function(d, b, c) {
        if ("" === b.get("value")) {
            return false
        }
        var a = this.getStore().getModifiedRecords();
        if (0 === a.length) {
            return true
        }
        this.notificationFilter.collapse();
        return confirm(_T("common", "confirm_lostchange"))
    },
    onCategoryChange: function() {
        if (null === this.filterSettingData) {
            this.loadFilterSetting()
        } else {
            this.getStore().rejectChanges();
            this.filterSettingStore.loadData(this.filterSettingData[this.notificationFilter.getValue()])
        }
        this.colMail.checkSelectAll(this.getStore());
        this.colMobile.checkSelectAll(this.getStore());
        this.colDesktop.checkSelectAll(this.getStore())
    },
    loadFilterSetting: function() {
        this.appWin.setStatusBusy({
            text: _T("common", "loading")
        });
        this.sendWebAPI({
            api: "SYNO.Core.PersonalNotification.Filter",
            method: "list",
            version: 1,
            params: {
                packages: this.pkgName
            },
            scope: this,
            callback: function(d, c) {
                this.appWin.clearStatusBusy();
                if (d) {
                    this.filterSettingStore.loadData(c[this.notificationFilter.getValue()]);
                    this.filterSettingData = c;
                    var b = [
                        [_T("notification", "category_all"), "All"],
                        [_T("notification", "label_by_importantce"), ""],
                        [_T("notification", "category_important"), "Important"],
                        [_T("notification", "category_information"), "Information"],
                        [_T("notification", "label_by_category"), ""]
                    ];
                    for (var a in c) {
                        if (c.hasOwnProperty(a)) {
                            if (-1 < ["all", "important", "information"].indexOf(a.toLowerCase())) {
                                continue
                            }
                            b.push([a, a])
                        }
                    }
                    this.notificationFilter.getStore().loadData(b)
                } else {
                    this.appWin.getMsgBox().alert(_T("tree", "leaf_notification"), _T("common", "error_system"))
                }
            }
        })
    },
    onClickSaveSetting: function() {
        var a = this.getStore().getModifiedRecords();
        if (0 === a.length) {
            this.appWin.getMsgBox().alert(_T("tree", "leaf_notification"), _T("error", "nochange_subject"));
            return
        }
        var d, c;
        var e = [];
        for (d = 0; d < a.length; d++) {
            var b = [];
            for (c = 0; c < this.targets.length; c++) {
                if (a[d].get(this.targets[c])) {
                    b.push(this.targets[c])
                }
            }
            var f = {
                name: a[d].get("name"),
                conf: b
            };
            f["package"] = a[d].get("pkg_name");
            e.push(f)
        }
        this.appWin.setStatusBusy({
            text: _T("common", "saving")
        });
        this.sendWebAPI({
            compound: {
                stopwhenerror: true,
                params: [{
                    api: "SYNO.Core.PersonalNotification.Filter",
                    method: "set",
                    version: 1,
                    params: {
                        settings: e
                    }
                }, {
                    api: "SYNO.Core.PersonalNotification.Filter",
                    method: "list",
                    version: 1,
                    params: {
                        packages: this.pkgName
                    }
                }]
            },
            scope: this,
            callback: function(i, h, g) {
                this.appWin.clearStatusBusy();
                if (!i || h.has_fail || !h.result[0].success) {
                    this.appWin.getMsgBox().alert(_T("tree", "leaf_notification"), _T("common", "error_system"));
                    return
                }
                this.appWin.setStatusOK();
                if (h.result[1].success) {
                    this.filterSettingData = h.result[1].data;
                    if (this.getStore()) {
                        this.getStore().commitChanges()
                    }
                }
            }
        })
    },
    isValid: function() {
        return true
    },
    isDirty: function() {
        var a = this.getStore().getModifiedRecords();
        return (0 < a.length)
    }
});
Ext.ns("SYNO.SDS.PersonalNotification");
Ext.define("SYNO.SDS.PersonalNotification.TestFormPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(a) {
        if (!a || !a.pkgName || !a.appWin) {
            SYNO.Debug("Error: no config.pkgName or config.appWin input.");
            return
        }
        this.pkgName = a.pkgName;
        this.appWin = a.appWin;
        this.callParent([this.fillConfig(a)]);
        this.mon(this, "activate", this.onAfterLayout, this, {
            single: true
        })
    },
    fillConfig: function(b) {
        var c = {
            get: {},
            set: {}
        };
        c.set["package"] = c.get["package"] = this.pkgName;
        var a = {
            itemId: "TestFormPanel",
            title: "Send Notification",
            items: [{
                xtype: "syno_textfield",
                fieldLabel: "User",
                name: "user",
                value: this.appWin._S("user")
            }, {
                xtype: "syno_textfield",
                fieldLabel: "Package",
                name: "package",
                value: this.pkgName
            }, {
                xtype: "syno_combobox",
                name: "tag",
                allowBlank: false,
                width: 320,
                fieldLabel: _T("notification", "notification_title"),
                value: "TestMail",
                valueField: "name",
                displayField: "title",
                store: new SYNO.API.Store({
                    autoDestroy: true,
                    appWindow: this.appWin,
                    api: "SYNO.Core.PersonalNotification.Filter",
                    method: "list",
                    version: 1,
                    baseParams: {
                        packages: this.pkgName
                    },
                    reader: new Ext.data.JsonReader({
                        root: "All",
                        fields: [{
                            name: "name"
                        }, {
                            name: "title"
                        }]
                    })
                })
            }, {
                xtype: "syno_displayfield",
                value: "Hash values:"
            }, {
                xtype: "syno_compositefield",
                items: [{
                    xtype: "syno_textfield",
                    name: "key_1",
                    fieldLabel: "key 1"
                }, {
                    xtype: "syno_textfield",
                    name: "value_1",
                    fieldLabel: "value 1"
                }]
            }, {
                xtype: "syno_compositefield",
                items: [{
                    xtype: "syno_textfield",
                    name: "key_2",
                    fieldLabel: "key 2"
                }, {
                    xtype: "syno_textfield",
                    name: "value_2",
                    fieldLabel: "value 2"
                }]
            }, {
                xtype: "syno_compositefield",
                items: [{
                    xtype: "syno_textfield",
                    name: "key_3",
                    fieldLabel: "key 3"
                }, {
                    xtype: "syno_textfield",
                    name: "value_3",
                    fieldLabel: "value 3"
                }]
            }, {
                xtype: "syno_compositefield",
                items: [{
                    xtype: "syno_textfield",
                    name: "key_4",
                    fieldLabel: "key 4"
                }, {
                    xtype: "syno_textfield",
                    name: "value_4",
                    fieldLabel: "value 4"
                }]
            }, {
                xtype: "syno_compositefield",
                items: [{
                    xtype: "syno_textfield",
                    name: "key_5",
                    fieldLabel: "key 5"
                }, {
                    xtype: "syno_textfield",
                    name: "value_5",
                    fieldLabel: "value 5"
                }]
            }, {
                xtype: "syno_button",
                text: _T("pushservice", "pushservice_send_test_notification"),
                id: this.testBtnId = Ext.id(),
                scope: this,
                handler: this.onClickTestNotificationBtn
            }, {
                xtype: "syno_button",
                text: "create in window",
                scope: this,
                handler: this.onClickCreateWindow
            }]
        };
        return Ext.apply(a, b)
    },
    onAfterLayout: function() {
        this.form.findField("tag").getStore().load()
    },
    onClickCreateWindow: function() {
        var a = new SYNO.SDS.PersonalNotification.Window({
            owner: this.appWin,
            pkgName: this.pkgName
        });
        a.open()
    },
    onClickTestNotificationBtn: function() {
        var d = this.form.getValues();
        for (var b = 1; b < 6; b++) {
            var a = "key_" + b;
            var c = "value_" + b;
            if (!d[a].empty() && !d[c].empty()) {
                if (!d.extra_info) {
                    d.extra_info = {}
                }
                d.extra_info[d[a]] = d[c]
            }
            delete d[a];
            delete d[c]
        }
        this.sendWebAPI({
            api: "SYNO.Core.PersonalNotification.Event",
            method: "fire",
            version: 1,
            params: d,
            scope: this,
            callback: function(f, e) {
                this.appWin.getMsgBox().alert(_T("notification", "pushservice"), _T("pushservice", "pushservice_test_notification_sent"))
            }
        })
    }
});
Ext.ns("SYNO.SDS.PersonalNotification");
Ext.define("SYNO.SDS.PersonalNotification.TabPanel", {
    extend: "SYNO.SDS.Utils.TabPanel",
    constructor: function(a) {
        if (!a || !a.pkgName || !a.appWin) {
            SYNO.Debug("Error: no override.pkgName or override.appWin input.");
            return
        }
        this.pkgName = a.pkgName;
        this.appWin = a.appWin;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            activeTab: 0,
            items: [this.SettingFormPanel = new SYNO.SDS.PersonalNotification.SettingFormPanel(b), this.FilterGridPanel = new SYNO.SDS.PersonalNotification.FilterGridPanel(b)]
        };
        if (b.enableTest) {
            a.items.push(this.TestPanel = new SYNO.SDS.PersonalNotification.TestFormPanel(b))
        }
        return Ext.apply(a, b)
    }
});
Ext.ns("SYNO.SDS.PersonalNotification");
Ext.define("SYNO.SDS.PersonalNotification.Window", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.owner = a.owner;
        if (!a || !a.pkgName) {
            SYNO.Debug("Error: no config.pkgName input.");
            return
        }
        this.tabpanel = new SYNO.SDS.PersonalNotification.TabPanel(Ext.apply(a, {
            appWin: this
        }));
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            owner: b.owner,
            closable: true,
            resizable: true,
            autoDestroy: true,
            showHelp: false,
            width: 850,
            height: 500,
            boxMinWidth: 850,
            boxMinHeight: 500,
            layout: "fit",
            items: [this.tabpanel]
        };
        return a
    }
});
