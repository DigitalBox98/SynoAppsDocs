/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.FileTaskMonitor.BackgroundTaskTray");
/**
 * @class SYNO.SDS.FileTaskMonitor.BackgroundTaskTray.TrayItem
 * @extends SYNO.SDS.FileTaskMonitor.BasicTrayItem
 * FileTaskMonitor background task tray class
 *
 */
SYNO.SDS.FileTaskMonitor.BackgroundTaskTray.TrayItem = Ext.extend(SYNO.SDS.FileTaskMonitor.BasicTrayItem, {
    animIcon: "sds-tray-item-ani-bgtask",
    staticIcon: "sds-tray-item-static-bgtask",
    initPanelImpl: function() {
        var a = new SYNO.SDS.FileTaskMonitor.BackgroundTaskTray.Panel({
            module: this,
            baseURL: this.jsConfig.jsBaseURL
        });
        return a
    },
    onClick: function() {
        if (0 < this.panel.getStore().getCount()) {
            SYNO.SDS.FileTaskMonitor.BackgroundTaskTray.TrayItem.superclass.onClick.apply(this, arguments)
        } else {
            if (0 < this.appInstance.getLocalGrid().getStore().getCount()) {
                var a = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileTaskMonitor.Instance")[0].window;
                a.onOpen({});
                a.activeTabPanel("local")
            }
        }
    },
    showTray: function() {
        this.setAnimIcon();
        this.taskButton.show()
    },
    hideTray: function() {
        var a = this.panel.getStore(),
            b = this.appInstance.getLocalGrid().getStore();
        if (0 >= a.getCount() && 0 >= b.getCount()) {
            this.taskButton.hide();
            this.panel.hide()
        } else {
            if (this.isTaskAllStop(a) && this.isTaskAllStop(b)) {
                this.setStaticIcon()
            }
        }
    },
    isTaskAllStop: function(a) {
        var b = true;
        a.each(function(c) {
            if (c.get("status") === "NOT_STARTED" || c.get("status") === "PROCESSING") {
                b = false;
                return false
            }
        }, this);
        return b
    }
});
SYNO.SDS.FileTaskMonitor.BackgroundTaskTray.Panel = Ext.extend(SYNO.SDS.FileTaskMonitor.BKMonitorGrid, {
    constructor: function(a) {
        this.fileds = ["cancelable", "id", "title", "progress", "processed_num", "processed_size", "total", "processing_path", "status"];
        SYNO.SDS.FileTaskMonitor.BKMonitorGrid.superclass.constructor.call(this, Ext.apply({
            title: _T("background_task", "background_task"),
            hidden: true,
            header: true,
            hideHeaders: true,
            floating: true,
            width: 320,
            height: 300,
            cls: "sds-tray-panel sds-filemonitor-tray-panel",
            renderTo: document.body,
            shadow: false,
            autoHeight: true,
            autoExpandColumn: null,
            plugins: [new SYNO.CellActions({
                actionWidth: 24,
                tpl: '<tpl for="actions"><div class="ux-cell-value {cls}"><div class="ux-cell-actions"><div class="ux-cell-action {cls}" qtip="{qtip}" style="{style}">&#160;</div></div></div></tpl>',
                listeners: {
                    action: {
                        scope: this,
                        fn: this.onClickCancel
                    }
                }
            })],
            store: new Ext.data.JsonStore({
                autoDestroy: true,
                idProperty: "id",
                fields: this.fileds
            }),
            colModel: this.initColumnModel(a.baseURL),
            sm: new Ext.grid.RowSelectionModel({
                singleSelect: true
            }),
            bbar: [{
                xtype: "syno_button",
                cls: "task-tray-select-all-btn",
                text: _T("background_task", "background_task_all"),
                scope: this,
                handler: function() {
                    var b = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileTaskMonitor.Instance")[0].window;
                    b.onOpen({});
                    b.activeTabPanel("background");
                    this.hide()
                }
            }],
            view: this.getView()
        }, a))
    },
    getView: function() {
        if (!this.view) {
            this.view = new Ext.grid.GridView(Ext.apply(this.viewConfig || {}, {
                forceFit: false,
                borderWidth: 0,
                initTemplates: function() {
                    Ext.grid.GridView.prototype.initTemplates.apply(this, arguments);
                    var a = ['<tr class="x-grid3-row-body-tr" style="{bodyStyle}">', '<td colspan="{cols}" class="x-grid3-body-cell" tabIndex="0" hidefocus="on">', '<div class="x-grid3-row-body">{body}</div>', "</td>", "</tr>"].join(""),
                        b = ['<table class="x-grid3-row-table" border="0" cellspacing="0" cellpadding="0" style="{tstyle}">', "<tbody>", "<tr>{cells}</tr>", this.enableRowBody ? a : "", "</tbody>", "</table>"].join("");
                    this.templates.row = new Ext.Template('<div class="x-grid3-row {alt}" style="{tstyle}">' + b + "</div>");
                    this.templates.row.disableFormats = true;
                    this.templates.row.compile()
                },
                onLayout: function() {
                    this.scrollOffset = 0
                }
            }))
        }
        return this.view
    },
    initColumnModel: function(c) {
        var d = new SYNO.SDS.Utils.ProgressBar({
            barWidth: 250,
            barHeight: 6,
            showValueText: true,
            isTray: true
        });
        var b = new Ext.XTemplate('<div ext:qtip="{name}" class="sds-filemonitor-tray-text"><span class="sds-filemonitor-tray-action-text">{actionname}:</span><span class="sds-filemonitor-tray-file-text">&nbsp;{name}</span></div>', "<table><tbody><tr><td>{progressBar}</td>", '<td><div class="sds-filemonitor-tray-row-text"><span class="progress-text" style="display: inline;"></span>', "</div></td></tr></tbody></table>");
        var e = new Ext.XTemplate('<div class="sds-filemonitor-tray-text"><span class="sds-filemonitor-tray-action-text">{actionname}:</span><span class="sds-filemonitor-tray-file-text">&nbsp;{name}</span></div>', '<div class="sds-filemonitor-tray-row-text">{progressBar}</div>');
        var a = new Ext.grid.ColumnModel({
            defaults: {
                menuDisabled: true
            },
            columns: [{
                id: "status",
                align: "left",
                width: 266,
                renderer: function(p, g, l, o, s, r) {
                    var k = l.data;
                    var q = Ext.util.Format.htmlEncode(l.data.title);
                    g.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(q) + '"';
                    var m = l.data.title.split(":", 2);
                    var i = m[0];
                    var f = (m.length === 1) ? "" : Ext.util.Format.htmlEncode(m[1]);
                    var h = (100 * l.data.progress).toFixed(1);
                    if ("NOT_STARTED" === l.get("status")) {
                        return b.apply({
                            actionname: i,
                            name: f,
                            progressBar: _T("background_task", "task_waiting")
                        })
                    } else {
                        if (l.data.progress > 0) {
                            var j = "";
                            if (0 < h) {
                                var n = k.total;
                                if (Ext.isNumber(n) && 0 < n) {
                                    if (Ext.isNumber(k.processed_num)) {
                                        j = (k.processed_num || 0) + " / " + n
                                    } else {
                                        if (Ext.isNumber(k.processed_size)) {
                                            j = Ext.util.Format.fileSize(k.processed_size) + " / " + Ext.util.Format.fileSize(n)
                                        } else {
                                            j = Ext.util.Format.fileSize((k.progress * n).toFixed(0)) + " / " + Ext.util.Format.fileSize(n)
                                        }
                                    }
                                }
                            }
                            return b.apply({
                                actionname: i,
                                name: f,
                                progressBar: d.fill(h, null, false, j),
                                invprogress: 100 - h
                            })
                        }
                    }
                    return e.apply({
                        actionname: i,
                        name: f,
                        progressBar: d.fill(0, null, false, _T("background_task", "task_processing"))
                    })
                }
            }, {
                dataIndex: "id",
                align: "right",
                width: 38,
                cellActions: [{
                    iconIndex: "cancelable",
                    qtip: _T("common", "cancel")
                }]
            }]
        });
        return a
    },
    onAdd: function(a) {
        SYNO.SDS.FileTaskMonitor.BackgroundTaskTray.Panel.superclass.onAdd.apply(this, arguments);
        this.doFilterRecordCount();
        this.module.showTray()
    },
    onRemove: function(a) {
        SYNO.SDS.FileTaskMonitor.BackgroundTaskTray.Panel.superclass.onRemove.apply(this, arguments);
        this.doFilterRecordCount();
        this.module.hideTray()
    },
    doFilterRecordCount: function() {
        var c = 0,
            a = this.getStore();

        function b() {
            return c-- <= 5
        }
        a.clearFilter();
        c = a.getCount();
        a.filterBy(b)
    }
});
