/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.namespace("SYNO.SDS.App.Ext4FsGoWrongApp");
/**
 * @class SYNO.SDS.App.Ext4FsGoWrongApp.Instance
 * @extends SYNO.SDS.AppInstance
 * Ext4FsGoWrongApp instance class
 *
 */
SYNO.SDS.App.Ext4FsGoWrongApp.Instance = Ext.extend(SYNO.SDS.AppInstance, {
    shouldNotifyMsg: function(a, b) {
        this.win.show();
        return false
    },
    initInstance: function(a) {
        if (!this.win) {
            this.win = new SYNO.SDS.App.Ext4FsGoWrongApp.DiskScan({
                appInstance: this
            });
            this.addInstance(this.win);
            this.win.setTitle(_T("volume", "volume_fsck_notification"))
        }
        this.sendWebAPI({
            api: "SYNO.Storage.CGI.Check",
            method: "should_ask_for_fsck_scan",
            version: 1,
            scope: this,
            callback: function(c, b) {
                if (c && b.shouldAskForFsckScan) {
                    this.win.show()
                }
            }
        })
    },
    onOpen: function(a) {
        this.initInstance(a)
    }
});
SYNO.SDS.App.Ext4FsGoWrongApp.DiskScan = Ext.extend(SYNO.SDS.AppWindow, {
    needShow: true,
    needLoad: true,
    resetAskForDiskScan: function() {
        this.sendWebAPI({
            api: "SYNO.Storage.CGI.Check",
            method: "remove_ask_for_fsck_scan",
            version: 1
        })
    },
    sendConfirmVolumeRemap: function() {
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Storage.CGI.Check",
            method: "do_disk_scan",
            version: 1,
            scope: this,
            callback: function(b, a) {
                this.clearStatusBusy();
                if (!b) {
                    this.setStatusError()
                }
            }
        })
    },
    ignoreHandler: function() {
        this.resetAskForDiskScan();
        this.hide()
    },
    reboot: function() {
        SYNO.SDS.System.Reboot()
    },
    getSysMsgBox: function(a) {
        if (!this.msgBox || this.msgBox.isDestroyed) {
            this.msgBox = new SYNO.SDS.MessageBoxV5({
                modal: true,
                draggable: false,
                renderTo: document.body
            })
        }
        return this.msgBox.getWrapper()
    },
    prepareHAFSCK: function() {
        this.sendConfirmVolumeRemap();
        this.rebootHACluster()
    },
    rebootHACluster: function() {
        var a = {};
        a.mode = "reboot_ha";
        this.sendWebAPI({
            api: "SYNO.SHA.Panel.Action",
            version: 1,
            method: "reboot_ha",
            params: a,
            callback: function(e, c, d, b) {
                if (e) {
                    if (c.success) {
                        SYNO.SDS.StatusNotifier.fireEvent("halt");
                        this.getSysMsgBox().show({
                            closable: false,
                            maxWidth: 300,
                            title: _D("product"),
                            msg: _T("system", "reboot_desc2")
                        })
                    } else {
                        if (c.errinfo.app) {
                            this.appWin.getMsgBox().alert(_TT("SYNO.SDS.HA.Instance", "app", "app_name"), _TT("SYNO.SDS.HA.Instance", c.errinfo.sec, c.errinfo.key))
                        } else {
                            this.appWin.getMsgBox().alert(_TT("SYNO.SDS.HA.Instance", "app", "app_name"), _T(c.errinfo.sec, c.errinfo.key))
                        }
                    }
                } else {
                    SYNO.Debug("Ajax load failure " + c)
                }
            },
            scope: this
        })
    },
    rebootNowHandler: function() {
        this.sendConfirmVolumeRemap();
        this.reboot();
        this.hide()
    },
    setRebootAfterRebuild: function() {
        this.sendWebAPI({
            api: "SYNO.Storage.CGI.Check",
            method: "reboot_after_rebuild",
            version: 1
        })
    },
    rebootAfterRebuildHandler: function() {
        this.sendConfirmVolumeRemap();
        this.setRebootAfterRebuild();
        this.hide()
    },
    rebootLaterHandler: function() {
        this.sendConfirmVolumeRemap();
        this.hide()
    },
    rebootNowHAHandler: function() {
        this.setStatusBusy();
        this.getMsgBox().confirm(_TT("SYNO.SDS.HA.Instance", "app", "app_name"), _TT("SYNO.SDS.HA.Instance", "overview", "warning_file_system_check"), function(a) {
            if ("yes" === a) {
                this.prepareHAFSCK();
                this.hide()
            } else {
                this.clearStatusBusy();
                this.hide()
            }
        }, this)
    },
    runVolumeScanHandler: function() {
        this.resetAskForDiskScan();
        var a = this.form.getValues().reboot_scan;
        if ("now" === a) {
            if (_S("ha_running")) {
                this.rebootNowHAHandler()
            } else {
                this.rebootNowHandler()
            }
        } else {
            if ("wait" === a) {
                this.rebootAfterRebuildHandler()
            } else {
                this.rebootLaterHandler()
            }
        }
    },
    constructor: function(b) {
        this.owner = b.owner;
        this.module = b.module;
        this.panel = this.createPanel();
        this.form = this.panel.getForm();
        var a = Ext.apply({
            title: _T("volume", "volume_fsck_notification"),
            width: 560,
            height: 330,
            minimizable: false,
            maximizable: false,
            showHelp: false,
            resizable: false,
            padding: "16px 20px 12px 20px",
            cls: "syno-disk-message-handler",
            items: [this.panel],
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "alt_ignore"),
                id: this.ignoreButtonID = Ext.id(),
                handler: this.ignoreHandler,
                scope: this
            }, {
                xtype: "syno_button",
                text: _T("common", "run"),
                btnStyle: "blue",
                id: this.runVolumeScanButtonID = Ext.id(),
                handler: this.runVolumeScanHandler,
                scope: this
            }]
        }, b);
        SYNO.SDS.App.Ext4FsGoWrongApp.DiskScan.superclass.constructor.call(this, a);
        this.on("beforeclose", function(c) {
            this.hide();
            return false
        });
        this.on("beforeshow", function(d) {
            if (false === this.needLoad) {
                this.needLoad = true;
                return this.needShow
            }
            var c;
            if (!Ext.isDefined(this.launchAppLinkID)) {
                this.launchAppLinkID = Ext.id()
            }
            c = String.format('<a href="#" id="{0}" class="link-font">{1}</a>', this.launchAppLinkID, _T("log", "log_viewer_title"));
            Ext.getCmp(this.runVolumeScanButtonID).enable();
            Ext.getCmp(this.ignoreButtonID).enable();
            this.sendWebAPI({
                api: "SYNO.Storage.CGI.Check",
                method: "is_building",
                version: 1,
                scope: this,
                callback: function(f, e) {
                    if (!f) {
                        return
                    }
                    this.needShow = true;
                    if (e.isBuilding) {
                        Ext.getCmp(this.diskScanLabelID).setValue(String.format(_T("volume", "volume_fsck_wait4building"), c));
                        Ext.getCmp(this.rebootScanNowRadioID).hide();
                        Ext.getCmp(this.rebootScanAfterRebuildRadioID).show();
                        Ext.getCmp(this.rebootScanAfterRebuildRadioID).setValue(true);
                        if (_S("ha_running")) {
                            this.needShow = false
                        }
                    } else {
                        Ext.getCmp(this.diskScanLabelID).setValue(String.format(_T("volume", "volume_fsck"), c));
                        Ext.getCmp(this.rebootScanAfterRebuildRadioID).hide();
                        Ext.getCmp(this.rebootScanNowRadioID).show();
                        Ext.getCmp(this.rebootScanNowRadioID).setValue(true);
                        if (_S("ha_running")) {
                            Ext.getCmp(this.rebootScanLaterRadioID).disable();
                            this.needShow = true
                        }
                    }
                    this.mon(Ext.fly(this.launchAppLinkID), "click", function() {
                        SYNO.SDS.AppLaunch("SYNO.SDS.LogCenter.BuiltIn", {
                            fn: "SYNO.SDS.LogCenter.LogSearch"
                        })
                    }, this);
                    this.needLoad = false;
                    this.show()
                }
            });
            return false
        })
    },
    createPanel: function() {
        var a = {
            border: false,
            items: [{
                xtype: "syno_displayfield",
                htmlEncode: false,
                id: this.diskScanLabelID = Ext.id()
            }, {
                xtype: "syno_displayfield",
                value: ""
            }, {
                xtype: "syno_radio",
                boxLabel: _T("volume", "volume_scan_reboot_after_rebuild"),
                id: this.rebootScanAfterRebuildRadioID = Ext.id(),
                name: "reboot_scan",
                hidden: true,
                inputValue: "wait"
            }, {
                xtype: "syno_radio",
                boxLabel: _T("volume", "volume_scan_reboot_immediately"),
                id: this.rebootScanNowRadioID = Ext.id(),
                name: "reboot_scan",
                checked: true,
                inputValue: "now"
            }, {
                xtype: "syno_radio",
                boxLabel: _T("volume", "volume_scan_reboot_later"),
                id: this.rebootScanLaterRadioID = Ext.id(),
                name: "reboot_scan",
                inputValue: "later"
            }]
        };
        return new Ext.form.FormPanel(a)
    }
});
