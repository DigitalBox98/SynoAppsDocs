/* Copyright (c) 2020 Synology Inc. All rights reserved. */

(function(d) {
    if (typeof d.echarts === "undefined") {
        return
    }
    var n = Math.log(10);
    var g = function(s, p, v) {
        var u = (p - s) / v,
            t = Math.pow(10, Math.floor(Math.log(u) / n)),
            r = u / t,
            q = 10;
        if (r < 1.5) {
            q = 1
        } else {
            if (r < 3) {
                q = 2
            } else {
                if (r < 7.5) {
                    q = 5
                }
            }
        }
        return q * t
    };
    var j = function(q) {
        var r = 1024,
            p = "KB";
        if (q.max > 10 * 1024 * 1024) {
            r = 1024 * 1024;
            p = "MB"
        } else {
            if (q.max < 100 * 1024) {
                q.max = 100 * 1024
            }
        }
        if (q.min < 0) {
            q.min = 0
        }
        q.interval = g(q.min / r, q.max / r, q.splitNumber || 5) * r;
        q.axisLabel.formatter = function(s) {
            return Math.round(s / r)
        };
        if (q.name) {
            q.name += " (" + p + ")"
        }
    };
    var m = function(p) {
        j(p);
        if (p.name) {
            p.name = p.name.substr(0, p.name.length - 1) + "/s)"
        }
    };
    var l = function(q) {
        var r = 1,
            s = 1000,
            p = "us";
        if (q.max >= 10 * s * s) {
            r = s * s;
            p = "s"
        } else {
            if (q.max >= 10 * s) {
                r = s;
                p = "ms"
            } else {
                if (q.max < 100) {
                    q.max = 100
                }
            }
        }
        if (q.min < 0) {
            q.min = 0
        }
        q.interval = g(q.min / r, q.max / r, q.splitNumber || 5) * r;
        q.axisLabel.formatter = function(t) {
            return Math.round(t / r)
        };
        if (q.name) {
            q.name += " (" + p + ")"
        }
    };
    var k = function(q) {
        var r = 1,
            p = _T("common", "time_seconds");
        if (q.max >= 24 * 60 * 60) {
            r = 24 * 60 * 60;
            p = _T("common", "time_days")
        } else {
            if (q.max >= 10 * 60 * 60) {
                r = 60 * 60;
                p = _T("common", "time_hours")
            } else {
                if (q.max >= 10 * 60) {
                    r = 60;
                    p = _T("common", "time_minutes")
                } else {
                    if (q.max < 10) {
                        q.max = 10
                    }
                }
            }
        }
        if (q.min < 0) {
            q.min = 0
        }
        q.interval = g(q.min / r, q.max / r, q.splitNumber || 5) * r;
        q.axisLabel.formatter = function(s) {
            return Math.round(s / r)
        };
        if (q.name) {
            q.name += " (" + p + ")"
        }
    };
    var f = function(q) {
        var r = 1024,
            p = _T("common", "size_kb");
        if (q.max >= 10 * 1024 * 1024 * 1024 * 1024) {
            r = 1024 * 1024 * 1024 * 1024;
            p = _T("common", "size_tb")
        } else {
            if (q.max >= 10 * 1024 * 1024 * 1024) {
                r = 1024 * 1024 * 1024;
                p = _T("common", "size_gb")
            } else {
                if (q.max >= 10 * 1024 * 1024) {
                    r = 1024 * 1024;
                    p = _T("common", "size_mb")
                } else {
                    if (q.max < 10 * 1024) {
                        q.max = 10 * 1024
                    }
                }
            }
        }
        if (q.min < 0) {
            q.min = 0
        }
        q.interval = g(q.min / r, q.max / r, q.splitNumber || 5) * r;
        q.axisLabel.formatter = function(s) {
            return Math.round(s / r)
        };
        if (q.name) {
            q.name += " (" + p + ")"
        }
    };
    var i = function(p, q) {
        switch (q) {
            case "byte":
                return j(p);
            case "bytes":
                return m(p);
            case "timeus":
                return l(p);
            case "lagtime":
                return k(p);
            case "datasize":
                return f(p);
            default:
                return
        }
    };
    var h = function() {
        return {
            type: "value",
            axisTick: {
                show: false
            },
            axisLine: {
                show: false
            },
            axisLabel: {
                margin: 6
            }
        }
    };
    var a = function() {
        var p = h();
        p.splitLine = false;
        return p
    };
    var e = function() {
        var p = h();
        if (!p.splitLine) {
            p.splitLine = {}
        }
        if (!p.splitLine.lineStyle) {
            p.splitLine.lineStyle = {}
        }
        p.splitLine.lineStyle.color = "#C6D4E0";
        p.splitLine.lineStyle.opacity = 0.4;
        p.nameRotate = 0.006;
        p.nameTextStyle = {
            fontSize: 12,
            fontWeight: "bold",
            fontFamily: "Verdana",
            align: "left"
        };
        p.nameGap = 10;
        return p
    };
    var c = function() {
        return {
            show: true,
            backgroundColor: "#FAFCFF",
            borderColor: "rgba(198,212,224,0.7)"
        }
    };
    var o = function() {
        return {
            trigger: "axis",
            transitionDuration: 0,
            axisPointer: {
                type: "line",
                axis: "x",
                lineStyle: {
                    color: "#3C76FF",
                    width: 2
                }
            },
            backgroundColor: "rgba(255,255,255,0.85)",
            padding: [6, 10],
            borderWidth: 1,
            borderColor: "rgba(198,212,224,0.7)",
            borderRadius: 3
        }
    };
    var b = function() {
        return {
            backgroundColor: "#FFFFFF",
            grid: c(),
            tooltip: o(),
            xAxis: a(),
            yAxis: e(),
            animation: false
        }
    };
    d.echarts.syno = {
        getDefaultOptions: b,
        customizeAxis: i
    }
})(this);