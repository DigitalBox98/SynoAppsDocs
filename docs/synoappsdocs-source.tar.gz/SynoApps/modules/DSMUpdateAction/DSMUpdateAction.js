/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.DSMUpdateAction.Instance
 * @extends SYNO.SDS.AppInstance
 * DSMUpdateAction application instance class
 *
 */
Ext.define("SYNO.SDS.DSMUpdateAction.Instance", {
    extend: "SYNO.SDS.AppInstance",
    msgBox: null,
    statics: {
        getMsgBox: function() {
            if (!this.msgBox || this.msgBox.isDestroyed) {
                this.msgBox = new SYNO.SDS.MessageBoxV5({
                    modal: true,
                    draggable: false,
                    renderTo: document.body
                })
            }
            return this.msgBox.getWrapper()
        },
        checkAutoUpdate: function() {
            SYNO.API.Request({
                api: "SYNO.Core.Upgrade.AutoUpgrade",
                method: "status",
                version: 1,
                scope: this,
                callback: function(d, a, c, b) {
                    if (!d) {
                        return
                    }
                    if (!a.autoupdate_status) {
                        return
                    }
                    if ("preparing" === a.autoupdate_status) {
                        this.getMsgBox().confirm(_T("update", "autoupdate_title"), _T("update", "autoupdate_noti_cancel_confirm_text"), this.cancelAutoUpdate, this);
                        return
                    } else {
                        if ("running" === a.autoupdate_status) {
                            this.getMsgBox().alert(_T("update", "autoupdate_title"), _T("update", "autoupdate_cancel_failed_running"))
                        } else {
                            this.getMsgBox().alert(_T("update", "autoupdate_title"), _T("update", "autoupdate_cancel_failed_no_task"))
                        }
                    }
                }
            })
        },
        cancelAutoUpdate: function(a) {
            if ("yes" !== a) {
                return
            }
            var b = _T("update", "autoupdate_cancel_failed");
            SYNO.API.Request({
                api: "SYNO.Core.Upgrade.AutoUpgrade",
                method: "cancel",
                version: 1,
                scope: this,
                callback: function(f, c, e, d) {
                    if (!f) {
                        if (c && c.code) {
                            b = SYNO.API.getErrorString(c.code)
                        }
                    } else {
                        b = _T("update", "autoupdate_cancel_success")
                    }
                    this.getMsgBox().alert(_T("update", "autoupdate_title"), b)
                }
            })
        }
    }
});
