/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.Utils.FileChooserV6");
/**
 * @class SYNO.SDS.Utils.FileChooser.CrtFdrDialogV6
 * FileChooser dialogV6 class
 *
 */
SYNO.SDS.Utils.FileChooser.CrtFdrDialogV6 = function(b) {
    this.checkName = true;
    Ext.apply(this, b || {});
    var a = this.init();
    var c = {
        owner: this.owner,
        width: 450,
        height: 180,
        cls: this.cls,
        shadow: true,
        minWidth: 500,
        minHeight: 150,
        collapsible: false,
        autoScroll: false,
        constrainHeader: true,
        title: _T("filetable", "filetable_create_folder"),
        layout: "fit",
        items: [a],
        buttons: [{
            text: _T("common", "common_cancel"),
            scope: this,
            handler: this.closeHandler
        }, {
            btnStyle: "blue",
            text: _T("common", "common_submit"),
            scope: this,
            handler: this.saveFolderName
        }],
        keys: [{
            key: [10, 13],
            fn: this.saveFolderName,
            scope: this
        }, {
            key: 27,
            fn: this.closeHandler,
            scope: this
        }],
        listeners: {
            afterlayout: {
                fn: function() {
                    this.focusEl = this.crtFdrForm.get("name");
                    this.center()
                },
                scope: this,
                single: true
            }
        }
    };
    this.addEvents({
        callback: true
    });
    SYNO.SDS.Utils.FileChooser.CrtFdrDialogV6.superclass.constructor.call(this, c)
};
Ext.extend(SYNO.SDS.Utils.FileChooser.CrtFdrDialogV6, SYNO.SDS.ModalWindow, {
    init: function() {
        var a = {
            labelWidth: 75,
            labelAlign: "top",
            trackResetOnLoad: true,
            waitMsgTarget: true,
            border: false,
            items: [{
                xtype: "syno_textfield",
                itemId: "name",
                fieldLabel: _T("filetable", "filetable_fill_name"),
                name: "name",
                width: 400,
                maxlength: 255
            }],
            listeners: {
                actionfailed: {
                    fn: this.closeHandler,
                    scope: this
                }
            }
        };
        var b = new Ext.form.FormPanel(a);
        this.crtFdrForm = b;
        return b
    },
    callbackHandler: function() {
        this.fireEvent("callback")
    },
    closeHandler: function() {
        this.hide();
        this.callbackHandler()
    },
    saveFolderName: function() {
        var a = "";
        if (!this.crtFdrForm || !this.crtFdrForm.form.findField("name")) {
            this.closeHandler();
            return
        }
        a = this.crtFdrForm.form.findField("name").getValue();
        a = Ext.util.Format.trim(a);
        if (!a) {
            this.getMsgBox().alert(_T("filetable", "filetable_create_folder"), _T("error", "error_empty_name"));
            return
        }
        if (this.checkName) {
            if (!SYNO.SDS.Utils.FileChooser.Utils.checkFileLen(a)) {
                this.getMsgBox().alert(_T("filetable", "filetable_create_folder"), _T("error", "error_long_path"));
                return
            }
            if (SYNO.SDS.Utils.FileChooser.Utils.isNameReserved(a)) {
                this.getMsgBox().alert(_T("filetable", "filetable_create_folder"), _T("error", "error_reserved_name"));
                return
            }
            if (SYNO.SDS.Utils.FileChooser.Utils.isNameCharIllegal(a)) {
                this.getMsgBox().alert(_T("filetable", "filetable_create_folder"), _T("error", "error_reserved_name"));
                return
            }
        }
        this.fdrName = a;
        this.callbackHandler()
    },
    resetDialogForm: function() {
        if (this.crtFdrForm) {
            this.crtFdrForm.form.reset()
        }
    },
    getFolderName: function() {
        return this.fdrName
    },
    resetFolderName: function() {
        this.fdrName = null
    },
    setParentDir: function(a) {
        this.parentDir = a
    },
    setCheckName: function(a) {
        if (SYNO.SDS.Utils.FileChooser.Utils.isLocalSource(a)) {
            this.checkName = false
        } else {
            this.checkName = true
        }
    },
    getParentDir: function() {
        return this.parentDir
    },
    load: function() {
        this.resetDialogForm();
        this.resetFolderName();
        this.show()
    }
});
Ext.namespace("SYNO.SDS.Utils.FileChooserV6");
Ext.define("SYNO.SDS.Utils.FileChooserV6.Chooser", {
    extend: "SYNO.SDS.ModalWindow",
    rootId: "fm_root",
    supportMultiSelect: true,
    pageSize: (!Ext.isIE || Ext.isModernIE) ? 1000 : 250,
    constructor: function(b) {
        this.owner = b.owner;
        var a = Ext.apply({
            width: 700,
            height: 500,
            title: "File Chooser",
            border: false,
            useStatusBar: false,
            buttons: false,
            cls: "file_chooser_mainpanel_v6",
            closeOwnerWhenNoShare: false,
            closeOwnerNumber: 1,
            gotoComplete: false,
            gotoPath: "",
            appName: "",
            enumGluster: false,
            enumCluster: false,
            enumC2Share: false,
            enumColdStorage: false,
            enumSnapshot: false,
            enumRecycle: true,
            needrw: true,
            hideFavorites: false,
            layout: {
                type: "vbox",
                align: "stretch",
                pack: "start"
            },
            items: [{
                layout: "border",
                border: false,
                flex: 1,
                items: []
            }],
            superuser: false,
            usage: {
                type: "open",
                multiple: false
            }
        }, b);
        if (a.usage.type === "chooseDir" || a.usage.type === "chooseFile") {
            a.windowSize = "small";
            a.bodyStyle = "padding: 8px 20px";
            a.width = 480
        } else {
            a.bodyStyle = "padding: 8px 12px"
        }
        if (a.folderToolbar) {
            a.tbar = {
                xtype: "syno_toolbar",
                style: {
                    padding: (a.windowSize === "small" ? "0 20px" : "0 12px")
                },
                items: [{
                    xtype: "syno_button",
                    text: _T("common", "refresh"),
                    tooltip: _T("common", "refresh"),
                    handler: function() {
                        if (this.usage.type === "chooseDir") {
                            var h = this.tree.getRootNode().childNodes || [];
                            var c = Ext.emptyFn,
                                d = function() {
                                    this.onTreeRootExpand(this.tree.getRootNode())
                                };
                            for (var e = 0; e < h.length; e++) {
                                var f = h[e];
                                if ("fm_root" === f.id) {
                                    c = d
                                }
                                f.reload(c, this)
                            }
                        } else {
                            var j = this.tree.selModel;
                            var g = j.getSelectedNode();
                            this.onTreeSelectionChange(j, g)
                        }
                    },
                    scope: this
                }, {
                    xtype: "syno_button",
                    text: _T("filetable", "filetable_create_folder"),
                    tooltip: _T("filetable", "filetable_create_folder"),
                    handler: this.createFolder,
                    scope: this
                }]
            }
        }
        a.items.push(this.initBottomPanelConfig(a));
        switch (a.usage.type) {
            case "open":
            case "save":
                a.items[0].items.push(this.initTreeConfig(a));
                a.items[0].items.push(this.initGridConfig(a));
                break;
            case "chooseDir":
                a.items[0].items.push(this.initTreeConfig(a));
                break;
            case "chooseFile":
                a.items[0].items.push(this.initGridConfig(a));
                break
        }
        if (SYNO.SDS.Utils.FileChooser.Utils.isVFSPath(a.gotoPath)) {
            a.gotoPath = ""
        }
        this.callParent([Ext.apply(a, b)]);
        this.findBy(function(c) {
            if (c.getItemId() === "tree") {
                this.tree = c
            } else {
                if (c.getItemId() === "grid") {
                    this.grid = c
                } else {
                    if (c.getItemId() === "bottomFieldset") {
                        this.bottomFieldset = c
                    }
                }
            }
        }, this);
        this.addEvents("choose", "cancel")
    },
    initTreeLoader: function(b) {
        if ("" !== this.appName) {
            SYNO.SDS.Utils.FileChooser.Utils.UpdateConfigByCapability(b, this.appName)
        }
        var a = new SYNO.API.TreeLoader({
            api: "SYNO.Core.File",
            method: "list",
            version: 1,
            requestMethod: "POST",
            appWindow: b.owner,
            clearOnLoad: false,
            createNode: function(c, d) {
                c = SYNO.SDS.Utils.FileChooser.Utils.ParseTreeNode(c, d);
                if (!c.spath) {
                    c.spath = c.path
                }
                if ((!b.enumGluster && c.is_gluster) || (!b.enumCluster && c.is_cluster) || (!b.enumSnapshot && c.is_snapshot) || (!b.enumRecycle && c.is_recycle_bin) || (!b.enumColdStorage && c.is_cold_storage) || (!b.enumC2Share && c.is_c2share) || (Ext.isFunction(b.treeFilter) && false === b.treeFilter(this, c))) {
                    c.cls = (c.cls || "") + (" node_display_none");
                    c.hideNode = true
                }
                if (Ext.isDefined(c.children) && Ext.isArray(c.children.files) && c.children.files.length > 0) {
                    c.expanded = true
                }
                return SYNO.API.TreeLoader.prototype.createNode.call(this, c)
            },
            processResponse: function(g, f, m, p) {
                var q = g.responseText;
                try {
                    var c = g.responseData || Ext.decode(q);
                    if ("fm_root" === f.id) {
                        c = c.data
                    } else {
                        if ("fm_fav_root" === f.id) {
                            c = c.data.favorites
                        } else {
                            c = c.data.files
                        }
                    }
                    f.beginUpdate();
                    for (var h = 0, j = c.length; h < j; h++) {
                        var d = this.createNode(c[h], f);
                        if (d) {
                            var l = f.appendChild(d);
                            this.doNodeload(l)
                        }
                    }
                    f.endUpdate();
                    this.runCallback(m, p || f, [f])
                } catch (k) {
                    this.handleFailure(g)
                }
            },
            doNodeload: function(e) {
                if (!e.attributes.children) {
                    return
                }
                var d = e.attributes.children.files;
                e.beginUpdate();
                for (var c = 0; c < d.length; c++) {
                    var f = e.appendChild(this.createNode(d[c], e));
                    this.doNodeload(f)
                }
                e.endUpdate()
            },
            listeners: {
                scope: this,
                beforeload: function(d, c) {
                    if ("fm_root" === c.id) {
                        d.api = "SYNO.Core.File";
                        d.baseParams = {
                            superuser: this.superuser,
                            needrw: !!this.needrw,
                            folder_path: "/",
                            status_filter: "valid",
                            support_enum_cold_storage: b.enumColdStorage
                        }
                    } else {
                        if ("fm_fav_root" === c.id) {
                            d.api = "SYNO.FileStation.Favorite";
                            d.baseParams = {
                                status_filter: "valid",
                                needrw: !!this.needrw,
                                enum_cluster: !!this.enumCluster,
                                additional: "real_path,size,owner,time,perm,type,mount_point_type,is_recycle_bin"
                            }
                        } else {
                            d.api = "SYNO.Core.File";
                            d.baseParams = {
                                superuser: this.superuser,
                                filetype: "dir",
                                folder_path: c.id.substr(c.id.indexOf("/")),
                                additional: ["real_path", "size", "owner", "time", "perm", "type", "mount_point_type", "is_recycle_bin"],
                                status_filter: "valid",
                                goto_path: !this.gotoComplete ? this.gotoPath : "",
                                support_enum_cold_storage: b.enumColdStorage
                            }
                        }
                    }
                },
                load: function(m, g) {
                    var j;
                    var n;
                    var h = {};
                    if (g.id === "fm_fav_root") {
                        n = g.ui;
                        var c, o = g.parentNode;
                        for (j = 0; j < o.childNodes.length; j++) {
                            if ("fm_root" === o.childNodes[j].id) {
                                c = o.childNodes[j]
                            }
                        }
                        Ext.each(c.childNodes, function(i) {
                            if (i && i.attributes) {
                                h[i.attributes.path] = true
                            }
                        });
                        var d = [];
                        Ext.each(g.childNodes, function(i) {
                            d.push(i)
                        });
                        for (j = 0; j < d.length; j++) {
                            var e = d[j];
                            if (e && e.attributes && true !== h[e.attributes.path]) {
                                g.removeChild(e)
                            }
                        }
                        if (n) {
                            if (!g.childNodes || 0 >= g.childNodes.length) {
                                n.hide()
                            } else {
                                n.show()
                            }
                        }
                        return
                    } else {
                        if (g.id !== "fm_root") {
                            return
                        }
                    }
                    var f;
                    for (j = 0; j < g.childNodes.length; j++) {
                        f = g.childNodes[j];
                        if (!f.attributes.hideNode) {
                            this.tree.getNodeById(f.id).select();
                            break
                        }
                    }
                    if (!this.gotoComplete && !Ext.isEmpty(this.gotoPath)) {
                        if (this.gotoPath.indexOf("/", 1) !== -1) {
                            var l = SYNO.SDS.Utils.FileChooser.Utils.getShareNodeByPath(this.tree, this.gotoPath);
                            if (!l) {
                                this.gotoComplete = true;
                                if (Ext.isDefined(f)) {
                                    f.select()
                                }
                                return
                            }
                            this.getEl().mask(_T("common", "loading"), "x-mask-loading");
                            l.reload(function() {
                                this.getEl().unmask();
                                this.gotoComplete = true;
                                var i = this.tree.getNodeById(SYNO.SDS.Utils.FileChooser.Utils.source.remote + this.gotoPath);
                                if (Ext.isDefined(i)) {
                                    i.select()
                                } else {
                                    if (Ext.isDefined(f)) {
                                        f.select()
                                    }
                                }
                            }, this)
                        } else {
                            this.gotoComplete = true;
                            var k = this.tree.getNodeById(SYNO.SDS.Utils.FileChooser.Utils.source.remote + this.gotoPath);
                            if (Ext.isDefined(k)) {
                                k.select()
                            } else {
                                if (Ext.isDefined(f)) {
                                    f.select()
                                }
                            }
                        }
                    }
                }
            }
        });
        return a
    },
    initBottomPanelConfig: function(c) {
        var a = 36,
            b = 32,
            f = 8;
        var e = {
            cls: c.usage.type === "chooseDir" ? "folder_chooser_bottompanel_v6" : "file_chooser_bottompanel_v6",
            border: false,
            layout: {
                type: "hbox",
                align: "stretch",
                pack: "start"
            },
            items: [{
                xtype: "syno_fieldset",
                itemId: "bottomFieldset",
                flex: 1,
                items: []
            }, {
                width: 220,
                border: false,
                layout: {
                    type: "vbox",
                    align: "stretch",
                    pack: "start"
                },
                items: [{
                    border: false,
                    flex: 1
                }, {
                    xtype: "container",
                    cls: "button-group",
                    items: [{
                        xtype: "syno_button",
                        btnStyle: "blue",
                        text: (c.usage.type === "save" ? _T("common", "save") : _T("common", "choose")),
                        minWidth: 80,
                        autoHeight: true,
                        scope: this,
                        handler: this.applyHandler
                    }, {
                        xtype: "syno_button",
                        text: _T("common", "cancel"),
                        minWidth: 80,
                        autoHeight: true,
                        scope: this,
                        handler: this.cancelHandler
                    }]
                }]
            }]
        };
        if (c.usage.type == "save") {
            e.items[0].items.push({
                xtype: "syno_textfield",
                fieldLabel: _T("common", "file_name"),
                width: 250,
                value: c.usage.oldFilename,
                listeners: {
                    afterrender: function(g) {
                        var h = g.value.lastIndexOf(".");
                        (function(i, j) {
                            if (-1 == j) {
                                i.selectText()
                            } else {
                                i.selectText(0, j)
                            }
                        }).defer(500, this, [g, h])
                    }
                }
            });
            f += b
        }
        if (Ext.isArray(c.comboOption)) {
            for (var d = 0; d < c.comboOption.length; d++) {
                e.items[0].items.push({
                    xtype: "syno_combobox",
                    fieldLabel: c.comboOption[d].label,
                    value: c.comboOption[d].value,
                    store: new Ext.data.ArrayStore({
                        fields: ["value", "name"],
                        data: c.comboOption[d].data
                    }),
                    valueField: "value",
                    displayField: "name",
                    width: 250,
                    listeners: {
                        scope: this,
                        select: this.onComboOptionChange
                    }
                })
            }
            f += b * c.comboOption.length
        }
        e.height = Math.max(a, f - 4) + 8;
        return e
    },
    initTreeConfig: function(b) {
        var a = this.initTreeLoader(b);
        var c = {
            id: "fm_top_root",
            allowDrag: false,
            allowDrop: false,
            children: []
        };
        c.children.push({
            type: SYNO.SDS.Utils.FileChooser.Utils.source.remote,
            loader: a,
            cls: "root_node",
            text: this._S("hostname"),
            draggable: false,
            allowDrop: false,
            expanded: true,
            id: this.rootId,
            listeners: {
                expand: {
                    fn: this.onTreeRootExpand,
                    scope: this,
                    single: true
                }
            }
        });
        if (SYNO.SDS.StatusNotifier.isAppHasPrivilege("SYNO.SDS.App.FileStation3.Instance") && !b.hideFavorites) {
            c.children.unshift({
                type: SYNO.SDS.Utils.FileChooser.Utils.source.remotefav,
                loader: this.initTreeLoader(b),
                cls: "root_node",
                text: _T("favorite", "my_favorite"),
                draggable: false,
                allowDrop: false,
                expanded: true,
                id: "fm_fav_root",
                hidden: true,
                listeners: {
                    expand: {
                        fn: this.onTreeRootExpand,
                        scope: this,
                        single: true
                    }
                }
            })
        }
        var d = {
            itemId: "tree",
            rootVisible: false,
            useGradient: false,
            cls: "file_chooser_treepanel_v6",
            region: (b.usage.type === "chooseDir" ? "center" : "west"),
            bodyStyle: "padding: 0px 12px 0px 0px",
            width: 200,
            xtype: "syno_treepanel",
            border: false,
            collapsable: true,
            split: true,
            useArrows: true,
            root: (new Ext.tree.AsyncTreeNode(c)),
            selModel: new Ext.tree.DefaultSelectionModel({
                listeners: {
                    selectionchange: {
                        fn: this.onTreeSelectionChange,
                        scope: this,
                        buffer: 100
                    },
                    beforeselect: {
                        fn: this.onTreeBeforeSelect,
                        scope: this
                    }
                }
            })
        };
        return d
    },
    initGridConfig: function(e) {
        var c;
        if (e.usage.type === "chooseFile") {
            c = {
                filetype: "file",
                folder_path: e.usage.folder_path
            }
        } else {
            c = {}
        }
        var a = function(f, g) {
            if (!Ext.isDefined(e) || !Ext.isDefined(e.columnCfg) || !Ext.isDefined(e.columnCfg[f]) || !Ext.isDefined(e.columnCfg[f][g])) {
                return false
            }
            return e.columnCfg[f][g]
        };
        this.gridStore = new Ext.data.Store({
            autoLoad: (e.usage.type === "chooseFile" ? true : false),
            proxy: new SYNO.API.Proxy({
                api: "SYNO.Core.File",
                method: "list",
                version: 1,
                appWindow: e.owner,
                listeners: {
                    scope: this,
                    beforeload: function(f, g) {
                        var h = f.activeRequest.read;
                        if (h) {
                            Ext.Ajax.abort(h)
                        }
                    }
                }
            }),
            reader: new Ext.data.JsonReader({
                root: "files",
                id: "path"
            }, [{
                name: "file_id",
                mapping: "path"
            }, {
                name: "path",
                mapping: (e && e.owner && SYNO.SDS.LDAP && (e.owner instanceof SYNO.SDS.LDAP.AppWindow)) ? "additional.real_path" : "path"
            }, {
                name: "filename",
                mapping: "name"
            }, {
                name: "filesize",
                mapping: "additional.size"
            }, {
                name: "mt",
                mapping: "additional.time.mtime"
            }, {
                name: "ct",
                mapping: "additional.time.crtime"
            }, {
                name: "at",
                mapping: "additional.time.atime"
            }, {
                name: "privilege",
                mapping: "additional.perm.posix"
            }, {
                name: "fileprivilege",
                convert: function(h, f) {
                    var g = f.additional.perm.acl,
                        i;
                    if (g.append) {
                        i |= SYNO.SDS.Utils.FileChooser.Utils.Mode_Append
                    }
                    if (g.del) {
                        i |= SYNO.SDS.Utils.FileChooser.Utils.Mode_Del
                    }
                    if (g.exec) {
                        i |= SYNO.SDS.Utils.FileChooser.Utils.Mode_Exec
                    }
                    if (g.read) {
                        i |= SYNO.SDS.Utils.FileChooser.Utils.Mode_Read
                    }
                    if (g.write) {
                        i |= SYNO.SDS.Utils.FileChooser.Utils.Mode_Write
                    }
                    return i
                }
            }, {
                name: "isacl",
                mapping: "additional.perm.is_acl_mode"
            }, {
                name: "icon"
            }, {
                name: "type",
                mapping: "additional.type"
            }, {
                name: "real_path",
                mapping: "additional.real_path"
            }, {
                name: "isdir"
            }, {
                name: "owner",
                mapping: "additional.owner.user"
            }, {
                name: "group",
                mapping: "additional.owner.group"
            }, {
                name: "uid",
                mapping: "additional.owner.uid"
            }, {
                name: "gid",
                mapping: "additional.owner.gid"
            }, {
                name: "mountType",
                mapping: "additional.mount_point_type"
            }]),
            remoteSort: true,
            paramNames: {
                start: "offset",
                limit: "limit",
                sort: "sort_by",
                dir: "sort_direction"
            },
            sortInfo: {
                field: "name",
                direction: "ASC"
            },
            baseParams: Ext.apply({
                superuser: e.superuser,
                sort_by: "name",
                additional: ["real_path", "size", "owner", "time", "perm", "type", "mount_point_type"]
            }, c),
            autoDestroy: true,
            listeners: {
                scope: this,
                beforeload: function(g, h) {
                    this.grid.mask(_T("common", "loading"));
                    var k = h.params;
                    var j = g.fields.get(g.sortInfo.field);
                    var i = j ? (j.mapping || j.name) : "name";
                    i = i.split(".", 3);
                    k.sort_by = i[2] || i[1] || i[0];
                    if (Ext.isFunction(this.getFilterPattern)) {
                        var f = this.bottomFieldset.items.items.slice(this.usage.type === "save" ? 1 : 0);
                        k.pattern = this.getFilterPattern(f)
                    }
                    return k
                },
                load: function(f) {
                    this.grid.unmask()
                },
                exception: function(h, i, j, g, k, f) {
                    this.grid.mask(SYNO.API.getErrorString(k.code))
                }
            }
        });
        var d = [{
            id: "filename",
            header: _T("common", "common_filename"),
            dataIndex: "filename",
            width: a("filename", "width") || undefined,
            hidden: a("filename", "hidden") || false,
            renderer: function(h, j, i, n, g, m) {
                if (Ext.isEmpty(i.data.icon)) {
                    i.data.icon = SYNO.SDS.Utils.FileChooser.Utils.getThumbName(i.data)
                }
                var l = Ext.util.Format.htmlEncode(h);
                if (!Ext.isIE || Ext.isModernIE) {
                    j.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(l) + '"'
                }
                var k = i.get("icon");
                var f = '<div class="{0}"><img width="16" height="16" src="{1}" align="absmiddle" />&nbsp;{2}</div>';
                if (i.get("mountType") === "remotefail") {
                    k = "remotefailmountpoint.png"
                }
                return String.format(f, "", SYNO.SDS.UIFeatures.IconSizeManager.getIconPath("webman/modules/FileBrowser/images/{1}/files_ext/" + k, "FileType"), l)
            }
        }, {
            header: _T("common", "common_filesize"),
            dataIndex: "filesize",
            width: a("filesize", "width") || 80,
            hidden: a("filesize", "hidden") || false,
            align: "right",
            renderer: function(h, g, f) {
                if (f.get("isdir")) {
                    return ""
                } else {
                    return Ext.util.Format.fileSize(h)
                }
            }
        }, {
            header: _T("filetable", "filetable_title_file_type"),
            dataIndex: "type",
            width: a("type", "width") || 80,
            hidden: a("type", "hidden") || false,
            align: "left",
            renderer: function(k, i, f, h, j, g) {
                if (f.get("isdir")) {
                    return _T("filetable", "filetable_folder")
                }
                if (k) {
                    return Ext.util.Format.htmlEncode(k.toUpperCase()) + " " + _T("filetable", "filetable_file")
                }
                return _T("filetable", "filetable_file")
            }
        }, {
            header: _T("filetable", "filetable_mtime"),
            dataIndex: "mt",
            width: a("mt", "width") || 160,
            hidden: a("mt", "hidden") || true,
            align: "right",
            renderer: this.timeRender
        }, {
            header: _T("filetable", "filetable_ctime"),
            dataIndex: "ct",
            width: a("ct", "width") || 160,
            hidden: a("ct", "hidden") || true,
            align: "right",
            renderer: this.timeRender
        }, {
            header: _T("filetable", "filetable_atime"),
            dataIndex: "at",
            width: a("at", "width") || 160,
            hidden: a("at", "hidden") || true,
            align: "right",
            renderer: this.timeRender
        }, {
            header: _T("filetable", "filetable_privilege"),
            dataIndex: "privilege",
            width: a("privilege", "width") || 80,
            hidden: a("privilege", "hidden") || true,
            align: "right",
            renderer: (function(p, o, k, s, g, q) {
                var l = k.data.privilege,
                    h = "",
                    r = "",
                    m = "";
                var f = 0,
                    j = 0,
                    n = 0;
                var i = parseInt(l, 10);
                if (i >= 100) {
                    f = Math.floor(i / 100);
                    i -= f * 100
                }
                if (i >= 10) {
                    j = Math.floor(i / 10);
                    i -= j * 10
                }
                n = i;
                h += (f & 4) ? "r" : "-";
                h += (f & 2) ? "w" : "-";
                h += (f & 1) ? "x" : "-";
                r += (j & 4) ? "r" : "-";
                r += (j & 2) ? "w" : "-";
                r += (j & 1) ? "x" : "-";
                m += (n & 4) ? "r" : "-";
                m += (n & 2) ? "w" : "-";
                m += (n & 1) ? "x" : "-";
                return h + r + m
            }).createDelegate(this)
        }];
        if (!e.owner._S("diskless")) {
            d.push({
                header: _T("filetable", "filetable_owner"),
                dataIndex: "owner",
                width: a("owner", "width") || 80,
                hidden: a("owner", "hidden") || true,
                align: "right",
                renderer: function(k, i, f, h, j, g) {
                    if (f.get("mountType") === "remotefail") {
                        return ""
                    }
                    if (k === "") {
                        return f.get("uid")
                    }
                    return k
                }
            }, {
                header: _T("filetable", "filetable_group"),
                dataIndex: "group",
                width: a("group", "width") || 80,
                hidden: a("group", "hidden") || true,
                align: "right",
                renderer: function(k, i, f, h, j, g) {
                    if (f.get("mountType") === "remotefail") {
                        return ""
                    }
                    if (k === "") {
                        return f.get("gid")
                    }
                    return k
                }
            })
        }
        var b = {
            itemId: "grid",
            region: "center",
            xtype: "syno_gridpanel",
            cls: "file_chooser_gridpanel_v6",
            enableColumnHide: false,
            bbar: this.createPagingToolbar(),
            listeners: {
                rowdblclick: {
                    fn: this.onGridRowDbClick,
                    scope: this
                },
                rowclick: {
                    fn: this.onGridRowClick,
                    scope: this
                }
            },
            store: this.gridStore,
            colModel: new Ext.grid.ColumnModel({
                defaults: {
                    sortable: true
                },
                columns: d
            }),
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: ("open" !== e.usage.type || false === e.usage.multiple)
            }),
            view: new SYNO.ux.FleXcroll.grid.BufferView({
                cacheSize: 30,
                scrollDelay: false,
                forceFit: true
            })
        };
        return b
    },
    createPagingToolbar: function() {
        var a = new SYNO.ux.PagingToolbar({
            store: this.gridStore,
            pageSize: this.pageSize,
            smallStyle: true,
            displayInfo: true,
            showRefreshBtn: true,
            displayButtons: false,
            listeners: {
                change: function(b, c) {
                    this.setButtonsVisible(c.total > b.pageSize)
                }
            }
        });
        return a
    },
    getCurrentSource: function() {
        return this.tree.getSelectionModel().getSelectedNode().attributes.type
    },
    onTreeRootExpand: function(b) {
        if (b.firstChild) {
            b.firstChild.select()
        }
        if ("fm_root" === b.id && b.childNodes && b.childNodes.length < 1 && !this._S("diskless")) {
            var c;
            var a;
            if (true === this._S("is_admin")) {
                c = this._S("standalone") ? _T("filebrowser", "prompt_noshare_standalone") : _T("filebrowser", "prompt_noshare");
                a = function(e) {
                    if ("ok" == e) {
                        if (this._S("standalone")) {
                            this.close();
                            return
                        }
                        if (this.closeOwnerWhenNoShare) {
                            var f = this;
                            for (var d = 0; d < this.closeOwnerNumber; d++) {
                                f = f.owner
                            }
                            f.close()
                        } else {
                            this.close()
                        }
                        if (!this.findAppWindow()) {
                            throw "Cannot find app window"
                        }
                        SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", Ext.apply({}, {
                            fn: "SYNO.SDS.AdminCenter.Share.Main"
                        }, this.findAppWindow().openConfig))
                    } else {
                        this.close()
                    }
                }
            } else {
                c = _T("download", "user_no_share_folder");
                a = function() {
                    this.close()
                }
            }
            this.getMsgBox().show({
                title: this.title,
                msg: c,
                width: 300,
                buttons: Ext.MessageBox.OKCANCEL,
                scope: this,
                fn: a
            })
        }
    },
    onTreeBeforeSelect: function(c, a, b) {
        if (!this.gotoComplete && !Ext.isEmpty(this.gotoPath)) {
            return false
        }
        if (this.rootId === a.id || "fm_fav_root" === a.id) {
            return false
        }
        return true
    },
    onTreeSelectionChange: function(c, b) {
        if (!this.grid) {
            return
        }
        if (!b) {
            return
        }
        var a = this.grid.getStore();
        a.removeAll();
        if (b.attributes) {
            a.baseParams.folder_path = b.attributes.spath
        }
        a.baseParams.filetype = "all";
        a.load({
            params: {
                offset: 0,
                limit: this.pageSize
            }
        })
    },
    onGridRowClick: function(c, f, d) {
        if ("save" == this.usage.type) {
            var b, a = c.getStore().getAt(f);
            if (a.data.isdir) {
                b = this.usage.oldFilename
            } else {
                b = a.data.filename
            }
            var g = b.lastIndexOf(".");
            this.bottomFieldset.items.items[0].setValue(b);
            if (-1 == g) {
                this.bottomFieldset.items.items[0].selectText()
            } else {
                this.bottomFieldset.items.items[0].selectText(0, g)
            }
        }
    },
    onGridRowDbClick: function(c, f, d) {
        var a = c.getStore().getAt(f),
            g = a.get("file_id"),
            b = g.substr(0, g.lastIndexOf("/"));
        if (a.get("isdir")) {
            this.tree.getNodeById(this.getCurrentSource() + b).expand(false, false, function() {
                this.tree.getNodeById(this.getCurrentSource() + g).select()
            }, this);
            return
        }
        this.applyHandler()
    },
    timeRender: function(a) {
        return a ? SYNO.SDS.DateTimeFormatter(new Date(a * 1000)) : ""
    },
    applyHandler: function() {
        var h = {},
            d = null,
            e, b, g, k;
        var c = (this.usage.type == "save") ? 1 : 0;
        var j = this.bottomFieldset.items.items;
        if (this.comboOption) {
            d = [];
            for (var f = c; f < j.length; f++) {
                d.push(j[f].value)
            }
        }
        if ("open" == this.usage.type) {
            if (this.usage.multiple) {
                e = this.grid.selModel.getSelections();
                if (0 === e.length) {
                    this.getMsgBox().alert("", _T("filetable", "filetable_select_one"));
                    return
                } else {
                    if (1 === e.length && e[0].data.isdir) {
                        b = e[0].id;
                        g = b.substr(0, b.lastIndexOf("/"));
                        this.tree.getNodeById(this.getCurrentSource() + g).expand(false, false, function() {
                            this.tree.getNodeById(this.getCurrentSource() + b).select()
                        }, this);
                        return
                    }
                }
                h.records = e
            } else {
                e = this.grid.selModel.getSelected();
                if (!e) {
                    this.getMsgBox().alert("", _T("filetable", "filetable_select_one"));
                    return
                }
                if (e.data.isdir) {
                    b = e.id;
                    g = b.substr(0, b.lastIndexOf("/"));
                    this.tree.getNodeById(this.getCurrentSource() + g).expand(false, false, function() {
                        this.tree.getNodeById(this.getCurrentSource() + b).select()
                    }, this);
                    return
                } else {
                    h.path = e.data.path;
                    h.fullpath = e.data.real_path
                }
            }
            this.fireEvent("choose", this, h, d)
        } else {
            if ("save" == this.usage.type) {
                var a = Ext.util.Format.trim(this.bottomFieldset.items.items[0].value);
                e = this.grid.selModel.getSelected();
                if (e && e.data.isdir) {
                    b = e.id;
                    g = b.substr(0, b.lastIndexOf("/"));
                    this.tree.getNodeById(this.getCurrentSource() + g).expand(false, false, function() {
                        this.tree.getNodeById(this.getCurrentSource() + b).select()
                    }, this);
                    return
                }
                if (!a) {
                    this.getMsgBox().alert("", _T("error", "error_empty_name"));
                    return
                }
                if (!SYNO.SDS.Utils.FileChooser.Utils.checkFileLen(a)) {
                    this.getMsgBox().alert("", _T("error", "error_long_path"));
                    return
                }
                if (SYNO.SDS.Utils.FileChooser.Utils.isNameReserved(a)) {
                    this.getMsgBox().alert("", _T("error", "error_reserved_name"));
                    return
                }
                if (SYNO.SDS.Utils.FileChooser.Utils.isNameCharIllegal(a)) {
                    this.getMsgBox().alert("", _T("error", "error_reserved_name"));
                    return
                }
                if (-1 !== (k = this.grid.store.findExact("filename", a))) {
                    if (this.grid.store.getAt(k).data.isdir) {
                        this.getMsgBox().alert("", _T("error", "error_file_exist"));
                        return
                    }
                    this.getMsgBox().confirm("", _T("filetable", "confirm_overwrite"), function(i) {
                        if ("yes" !== i) {
                            return
                        }
                        e = this.grid.selModel.getSelected();
                        h.path = this.tree.selModel.getSelectedNode().attributes.spath + "/" + a;
                        this.fireEvent("choose", this, h, d)
                    }, this);
                    return
                } else {
                    h.path = this.tree.selModel.getSelectedNode().attributes.spath + "/" + a;
                    this.fireEvent("choose", this, h, d)
                }
            } else {
                if ("chooseDir" == this.usage.type) {
                    this.applyHandlerWhenChoosingDir(h, d)
                } else {
                    if ("chooseFile" == this.usage.type) {
                        e = this.grid.selModel.getSelected();
                        if (!e) {
                            this.getMsgBox().alert("", _T("filetable", "filetable_select_one"));
                            return
                        }
                        h.path = e.data.path;
                        this.fireEvent("choose", this, h, d)
                    }
                }
            }
        }
    },
    applyHandlerWhenChoosingDir: function(a, c) {
        var b = this.tree.selModel.getSelectedNode();
        if (!b || b.attributes.hideNode) {
            return
        }
        a.path = b.attributes.spath;
        a.fullpath = b.attributes.path;
        this.fireEvent("choose", this, a, c)
    },
    cancelHandler: function() {
        this.fireEvent("cancel", this);
        this.close()
    },
    onComboOptionChange: function() {
        this.gridStore.reload()
    },
    createFolder: function() {
        var e = this.tree.selModel;
        var c = e.getSelectedNode();
        if (!c || c.attributes.hideNode) {
            return
        }
        if (this._S("is_admin") !== true && this._S("domainUser") !== "true") {
            var b = false,
                a;
            if (c.parentNode.id !== "fm_root") {
                a = SYNO.SDS.Utils.FileChooser.Utils.getShareRight(this.tree, c)
            } else {
                a = c.attributes.right;
                b = true
            }
            if (!SYNO.SDS.Utils.FileChooser.Utils.checkShareRight(a, SYNO.SDS.Utils.FileChooser.Utils.RW)) {
                this.getMsgBox().alert(_T("filetable", "filetable_create_folder"), _T("error", "error_privilege_not_enough"));
                return false
            }
            if (!b) {
                var d = {
                    right: c.attributes.aclRight,
                    needRight: SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.DestFolder.Create
                };
                if (!SYNO.SDS.Utils.FileChooser.Utils.checkFileRight.call(this, d)) {
                    this.getMsgBox().alert(_T("filetable", "filetable_create_folder"), _T("error", "error_privilege_not_enough"));
                    return false
                }
            }
        }
        if (!this.crtDialog || this.crtDialog.isDestroyed) {
            this.crtDialog = new SYNO.SDS.Utils.FileChooser.CrtFdrDialog({
                RELURL: this.RELURL,
                owner: this,
                cls: this.initialConfig.cls
            })
        }
        this.crtDialog.mon(this.crtDialog, "callback", this.onCrtFdrHide, this, {
            single: true
        });
        this.crtDialog.setParentDir(c.attributes.spath);
        this.crtDialog.load()
    },
    onCrtFdrHide: function() {
        var b = this.crtDialog.getFolderName();
        var d = this.tree.selModel;
        var c = d.getSelectedNode();
        if (!c || !b) {
            return
        }
        var a = c.attributes.spath;
        this.sendWebAPI({
            api: "SYNO.Core.File",
            method: "create",
            params: {
                superuser: this.superuser,
                type: "folder",
                name: b,
                dest: a
            },
            version: 1,
            scope: this,
            callback: function(e, g) {
                this.crtDialog.hide();
                if (!e) {
                    this.getMsgBox().alert("", SYNO.API.getErrorString(g.code));
                    return
                }
                var h = this.tree.selModel;
                var f = h.getSelectedNode();
                this.onTreeSelectionChange(h, f);
                f.reload(function() {
                    var i = this.tree.getNodeById(f.id + "/" + this.crtDialog.getFolderName());
                    if (i) {
                        i.select()
                    }
                }, this);
                SYNO.SDS.StatusNotifier.fireEvent("filechanged", null, a)
            }
        })
    }
});
