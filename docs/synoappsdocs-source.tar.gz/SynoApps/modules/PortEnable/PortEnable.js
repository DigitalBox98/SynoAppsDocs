/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.PortEnable.Instance
 * @extends SYNO.SDS.AppInstance
 * PortEnable application instance class
 *
 */
Ext.define("SYNO.SDS.PortEnable.Instance", {
    extend: "SYNO.SDS.AppInstance",
    initInstance: function(a) {
        if (!this.win) {
            SYNO.SDS.StatusNotifier.addListener("thirdpartychanged", this.portCheck, this);
            SYNO.SDS.StatusNotifier.addListener("servicechanged", this.portCheck, this);
            SYNO.SDS.StatusNotifier.addListener("checkserviceblocked", this.portCheck, this);
            this._serviceName = [];
            this._serviceInfo = [];
            this.win = new SYNO.SDS.PortEnable.Dialog({
                appInstance: this
            });
            this.addInstance(this.win);
            this.win.alignTo(document.body, "c-c");
            this.checkTask = new Ext.util.DelayedTask()
        }
    },
    portCheck: function(c, b, a) {
        if (!(c instanceof Array)) {
            if (c && '"' === c[0] && '"' === c[c.length - 1]) {
                c = c.slice(c.indexOf('"') + 1, c.lastIndexOf('"'))
            }
        }
        if (Ext.isObject(a)) {
            this.win.setCallback(a)
        }
        switch (b) {
            case "checkserviceblocked":
                c.map(function(d) {
                    this._serviceName.push(d)
                }, this);
                this.checkTask.delay(500, this.isPortBlock, this, ["isDirectID"]);
                break;
            case "install":
                this.isPkgEnable(c);
                break;
            case "start":
                this._serviceName.push(c);
                this.isPortBlock("package");
                break;
            case true:
                this._serviceName.push(c);
                this.checkTask.delay(500, this.isPortBlock, this, ["service"]);
                break
        }
    },
    isPkgEnable: function(a) {
        this.sendWebAPI({
            api: "SYNO.DSM.PortEnable",
            version: 1,
            method: "is_pkg_enable",
            params: {
                name: a
            },
            callback: function(e, c, d, b) {
                if (e) {
                    if (true === c.pkgEnable) {
                        this._serviceName.push(a);
                        this.isPortBlock("package")
                    }
                }
            },
            scope: this
        })
    },
    isPortBlock: function(a) {
        this.sendWebAPI({
            api: "SYNO.DSM.PortEnable",
            version: 1,
            method: "is_port_block",
            params: {
                name: this._serviceName,
                isPkg: ("package" === a) ? true : false,
                isDirectID: ("isDirectID" === a) ? true : false
            },
            callback: function(e, c, d, b) {
                if (!e) {
                    this.win.doCallback("error");
                    this.win.getMsgBox().alert(_T("firewall", "firewall_port_management"), SYNO.API.getErrorString(c.code));
                    return
                }
                if (c.portcheck && !c.isPortAllow) {
                    SYNO.SDS.PortEnable.serviceInfoParsing(c, this._serviceInfo);
                    this.win.store.loadData(this._serviceInfo, false);
                    this.win.formPanel.getForm().findField("noprompt").setValue(false);
                    this.win.open()
                } else {
                    this.win.doCallback("succ")
                }
            },
            scope: this
        });
        this._serviceName.length = 0
    }
});
Ext.define("SYNO.SDS.PortEnable.Dialog", {
    extend: "SYNO.SDS.Window",
    constructor: function(a) {
        var b = this.fillConfig(a);
        this.callParent([b]);
        this.getKeyMap().on(27, this.onEsc, this)
    },
    fillConfig: function(a) {
        this.descPanel = this.createDescPanel();
        this.gridPanel = this.createGridPanel();
        this.formPanel = this.createFormPanel();
        var b = {
            title: _T("firewall", "firewall_port_management"),
            closable: false,
            modal: true,
            useDefualtKey: false,
            onEsc: function() {
                this.hide()
            },
            maximizable: false,
            resizable: false,
            dsmStyle: "v5",
            height: 400,
            width: 700,
            items: [this.descPanel, this.gridPanel, this.formPanel],
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "cancel"),
                handler: function() {
                    this.doCallback("cancel");
                    this.onClose()
                },
                scope: this
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                text: _T("common", "apply"),
                handler: this.onAllow,
                scope: this
            }]
        };
        Ext.apply(b, a);
        b = this.addStatusBar(b);
        return b
    },
    createDescPanel: function() {
        var a = {
            height: 65,
            border: false,
            layout: "form",
            trackResetOnLoad: true,
            items: [{
                xtype: "syno_displayfield",
                value: _T("firewall", "firewall_port_block_info"),
                indent: 1
            }]
        };
        return new SYNO.ux.FormPanel(a)
    },
    createFormPanel: function() {
        var a = {
            border: false,
            layout: "form",
            trackResetOnLoad: true,
            items: [{
                xtype: "syno_checkbox",
                name: "noprompt",
                boxLabel: _T("firewall", "firewall_no_prompt"),
                indent: 1
            }, {
                xtype: "syno_displayfield",
                fieldLabel: "Note",
                hideLabel: true,
                indent: 1,
                htmlEncode: false,
                value: '<span class="syno-ux-note">Note: </span>' + String.format(_T("firewall", "firewall_no_prompt_desc"), '<a class="link-font">' + _T("controlpanel", "leaf_firewall") + "</a>"),
                listeners: {
                    render: function(c) {
                        var b = c.el.first("a");
                        if (b) {
                            this.mon(b, "click", function() {
                                SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                                    fn: "SYNO.SDS.AdminCenter.Security.Main",
                                    tab: "FirewallTab"
                                });
                                this.toFront()
                            }, this)
                        }
                    },
                    scope: this,
                    single: true,
                    buffer: 80
                }
            }]
        };
        return new SYNO.ux.FormPanel(a)
    },
    createGridPanel: function() {
        var c = function(g, f) {
            f.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(g) + '"';
            return g
        };
        this.store = new Ext.data.ArrayStore({
            autoDestroy: false,
            fields: ["enabled", "id", "name", "ports", "desc", "protocol"],
            data: []
        });
        var b = {
            header: _T("firewall", "firewall_policy_allow"),
            dataIndex: "enabled",
            width: 80,
            menuDisabled: true,
            align: "center"
        };
        var e = new SYNO.ux.EnableColumn(b);
        var a = new Ext.grid.ColumnModel([e, {
            width: 120,
            header: _T("firewall", "firewall_system_port_column_desc"),
            dataIndex: "name",
            align: "center",
            sortable: true,
            renderer: c
        }, {
            header: _T("firewall", "firewall_protocol"),
            dataIndex: "protocol",
            width: 125,
            align: "center",
            sortable: true,
            renderer: c
        }, {
            header: _T("firewall", "firewall_ports"),
            width: 125,
            dataIndex: "ports",
            sortable: true,
            align: "center",
            renderer: c
        }, {
            header: _T("pkgmgr", "pkgmgr_pkg_description"),
            width: 225,
            dataIndex: "desc",
            align: "center",
            sortable: true,
            renderer: c
        }]);
        var d = {
            height: 160,
            padding: "0 32px",
            ds: this.store,
            cm: a,
            loadMask: false,
            cls: "without-dirty-red-grid",
            enableColLock: true,
            enableColumnMove: false,
            enableHdMenu: false,
            selModel: new Ext.grid.RowSelectionModel({}),
            plugins: [e]
        };
        return new SYNO.ux.GridPanel(d)
    },
    onAllow: function() {
        var a = this.getAllowSection();
        var b = this.formPanel.getForm().findField("noprompt").getValue();
        if (0 === a.length && !b) {
            this.doCallback("cancel");
            this.onClose();
            return
        }
        this.setStatusBusy({
            text: _T("common", "saving")
        });
        if (0 === a.length && b) {
            this.sendWebAPI({
                api: "SYNO.Core.Security.Firewall.Conf",
                version: 1,
                method: "set",
                params: {
                    enable_port_check: false
                },
                callback: function(c) {
                    this.clearStatusBusy();
                    if (!c) {
                        this.getMsgBox().alert("disable_port_check error");
                        return
                    }
                    this.doCallback("succ");
                    this.onClose()
                },
                scope: this
            });
            return
        }
        this.sendWebAPI({
            api: "SYNO.DSM.PortEnable",
            version: 1,
            method: "open_block_port",
            params: {
                sectionList: a,
                prompt: !this.formPanel.getForm().findField("noprompt").getValue()
            },
            callback: function(f, d, e) {
                this.clearStatusBusy();
                if (!f) {
                    var c = SYNO.API.getErrorString(d.code);
                    if (Ext.isDefined(d.errors) && Ext.isDefined(d.errors.sec) && Ext.isDefined(d.errors.key)) {
                        c = _T(d.errors.sec, d.errors.key)
                    }
                    this.doCallback("error");
                    this.getMsgBox().alert(this.title, c, function(g) {
                        if ("ok" === g) {
                            this.onClose()
                        }
                    }, this);
                    return
                }
                this.doCallback("succ");
                this.onClose()
            },
            scope: this
        })
    },
    getAllowSection: function() {
        var a = [];
        this.store.each(function(b) {
            if (true === b.get("enabled")) {
                a.push(b.get("id"))
            }
        });
        return a
    },
    onClose: function() {
        this.hide()
    },
    doCallback: function(a) {
        switch (a) {
            case "succ":
                if (Ext.isFunction(this.cbSucc)) {
                    this.cbSucc.call(this.cbScope || this)
                }
                break;
            case "cancel":
                if (Ext.isFunction(this.cbCancel)) {
                    this.cbCancel.call(this.cbScope || this)
                }
                break;
            case "error":
                if (Ext.isFunction(this.cbError)) {
                    this.cbError.call(this.cbScope || this)
                }
                break;
            default:
                return
        }
    },
    setCallback: function(a) {
        this.cbSucc = Ext.isFunction(a.Succ) ? a.Succ : Ext.emptyFn;
        this.cbCancel = Ext.isFunction(a.Cancel) ? a.Cancel : Ext.emptyFn;
        this.cbError = Ext.isFunction(a.Error) ? a.Error : Ext.emptyFn;
        this.cbScope = a.scope
    }
});
SYNO.SDS.PortEnable.serviceInfoParsing = function(e, b) {
    if (!e || !e.services) {
        return false
    }
    var h = e.services;
    var c;
    var a = "";
    var f = "";
    var g = "";
    var j = [];
    b.length = 0;
    for (var d = 0; d < h.length; d++) {
        g = "";
        c = h[d];
        if (-1 < j.indexOf(c.id)) {
            continue
        }
        if ("" !== c.name.app && "" !== c.name.section && "" !== c.name.key) {
            a = _TT(c.name.app, c.name.section, c.name.key)
        } else {
            if ("" !== c.name.section && "" !== c.name.key) {
                a = _T(c.name.section, c.name.key)
            } else {
                a = c.name.defaultStr
            }
        }
        if ("" !== c.desc.app && "" !== c.desc.section && "" !== c.desc.key) {
            f = _TT(c.desc.app, c.desc.section, c.desc.key)
        } else {
            if ("" !== c.desc.section && "" !== c.desc.key) {
                f = _T(c.desc.section, c.desc.key)
            } else {
                f = c.desc.defaultStr
            }
        }
        g = c.dst_ports.join();
        b.push([true, c.id, a, g, f, c.protocol]);
        j.push(c.id)
    }
    return true
};
