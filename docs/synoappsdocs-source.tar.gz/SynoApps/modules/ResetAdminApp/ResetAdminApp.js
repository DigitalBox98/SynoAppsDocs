! function(e) {
    var t = {};

    function s(n) {
        if (t[n]) return t[n].exports;
        var r = t[n] = {
            i: n,
            l: !1,
            exports: {}
        };
        return e[n].call(r.exports, r, r.exports, s), r.l = !0, r.exports
    }
    s.m = e, s.c = t, s.d = function(e, t, n) {
        s.o(e, t) || Object.defineProperty(e, t, {
            enumerable: !0,
            get: n
        })
    }, s.r = function(e) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(e, "__esModule", {
            value: !0
        })
    }, s.t = function(e, t) {
        if (1 & t && (e = s(e)), 8 & t) return e;
        if (4 & t && "object" == typeof e && e && e.__esModule) return e;
        var n = Object.create(null);
        if (s.r(n), Object.defineProperty(n, "default", {
                enumerable: !0,
                value: e
            }), 2 & t && "string" != typeof e)
            for (var r in e) s.d(n, r, function(t) {
                return e[t]
            }.bind(null, r));
        return n
    }, s.n = function(e) {
        var t = e && e.__esModule ? function() {
            return e.default
        } : function() {
            return e
        };
        return s.d(t, "a", t), t
    }, s.o = function(e, t) {
        return Object.prototype.hasOwnProperty.call(e, t)
    }, s.p = "", s(s.s = 5)
}([function(e, t, s) {}, function(e, t, s) {}, function(e, t) {
    e.exports = Vue
}, function(e, t, s) {
    "use strict";
    var n = s(0);
    s.n(n).a
}, function(e, t, s) {
    "use strict";
    var n = s(1);
    s.n(n).a
}, function(e, t, s) {
    "use strict";
    s.r(t);
    var n = s(2),
        r = s.n(n),
        i = function() {
            var e = this.$createElement,
                t = this._self._c || e;
            return t("v-app-instance", {
                attrs: {
                    "class-name": "SYNO.SDS.App.ResetAdminApp.Instance",
                    "syno-id": "reset-admin-app-instance",
                    "can-open": this.canOpen,
                    fullsize: !0,
                    "should-launch": this.shouldLaunch
                }
            }, [t("v-app-window", {
                ref: "appWindow",
                staticClass: "syno-reset-admin-app",
                attrs: {
                    "syno-id": "reset-admin-app-window",
                    "default-maximized": !0,
                    closable: !1,
                    resizable: !1,
                    alwaysOnTop: !0
                }
            }, [t("v-perfect-scrollbar", [t(this.step, {
                tag: "component",
                attrs: {
                    adminList: this.adminList
                },
                on: {
                    "goto-step": this.onGotoStep
                }
            })], 1)], 1)], 1)
        };
    i._withStripped = !0;
    var o = function() {
        var e = this,
            t = e.$createElement,
            s = e._self._c || t;
        return s("div", {
            staticClass: "login-page-common-layout"
        }, [s("div", {
            staticClass: "area-top"
        }, [s("div", {
            staticClass: "header"
        }, [s("div", {
            staticClass: "title"
        }, [e._v("\n        " + e._s(e.$i18n("reset_admin", "reset_admin_title")) + "\n      ")]), e._v(" "), s("div", {
            staticClass: "desc"
        }, [e._v("\n        " + e._s(e.$i18n("reset_admin", "reset_admin_desc")) + "\n      ")])])]), e._v(" "), e._m(0), e._v(" "), s("div", {
            staticClass: "area-center-right"
        }, [s("form", {
            staticClass: "common-simple-form"
        }, [s("div", {
            staticClass: "reset-admin-username-field"
        }, [1 >= this.adminList.length ? s("textfield", {
            ref: "username",
            attrs: {
                disabled: !0
            },
            on: {
                submit: e.onSubmit
            },
            model: {
                value: e.username,
                callback: function(t) {
                    e.username = t
                },
                expression: "username"
            }
        }) : s("div", {
            staticClass: "login-textfield"
        }, [s("div", {
            staticClass: "input-container"
        }, [s("v-select", {
            ref: "username",
            staticClass: "reset-admin-combobox",
            attrs: {
                width: "100%",
                "syno-id": "reset-admin-combobox",
                readonly: "",
                options: e.selectOptions,
                placeholder: e.$i18n("reset_admin", "admin_account")
            },
            on: {
                select: e.onUserSelect,
                submit: e.onSubmit
            },
            model: {
                value: e.username,
                callback: function(t) {
                    e.username = t
                },
                expression: "username"
            }
        })], 1), e._v(" "), s("div", {
            staticClass: "border bottom-border"
        })]), e._v(" "), 0 < this.adminList.length ? s("v-whitetip", {
            attrs: {
                content: e.$i18n("reset_admin", "admin_account_tooltip")
            }
        }) : e._e()], 1), e._v(" "), s("textfield", {
            ref: "password",
            attrs: {
                type: "password",
                placeholder: e.$i18n("user", "user_passwd_new")
            },
            on: {
                submit: e.onSubmit
            },
            model: {
                value: e.password,
                callback: function(t) {
                    e.password = t
                },
                expression: "password"
            }
        }), e._v(" "), s("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.passwordStrenghLevel > -1,
                expression: "passwordStrenghLevel > -1"
            }],
            class: [{
                "login-password-strength": !0
            }, {
                weak: 0 === e.passwordStrenghLevel
            }, {
                medium: 1 === e.passwordStrenghLevel
            }, {
                strong: 2 === e.passwordStrenghLevel
            }]
        }, [s("div", {
            staticClass: "strength-block block-1"
        }), e._v(" "), s("div", {
            staticClass: "strength-block block-2"
        }), e._v(" "), s("div", {
            staticClass: "strength-block block-3"
        }), e._v(" "), s("span", [e._v(e._s(e.passwordStrengthText))])]), e._v(" "), s("textfield", {
            ref: "confirmPassword",
            attrs: {
                type: "password",
                placeholder: e.$i18n("user", "user_repswd")
            },
            on: {
                submit: e.onSubmit
            },
            model: {
                value: e.confirmPassword,
                callback: function(t) {
                    e.confirmPassword = t
                },
                expression: "confirmPassword"
            }
        }), e._v(" "), s("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: "" !== e.confirmPassError,
                expression: "confirmPassError !== ''"
            }],
            staticClass: "confirm-pass-error",
            domProps: {
                innerHTML: e._s(e.confirmPassError)
            }
        }), e._v(" "), s("login-button", {
            attrs: {
                disabled: e.isButtonDisabled
            },
            on: {
                click: e.onSubmit
            }
        }, [e._v("\n        " + e._s(e.$i18n("common", "submit")) + "\n      ")]), e._v(" "), s("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.msgShow,
                expression: "msgShow"
            }],
            staticClass: "msg",
            class: e.msgCls
        }, [s("loading-icon"), e._v(" "), s("div", {
            staticClass: "text",
            domProps: {
                innerHTML: e._s(e.msgText)
            }
        })], 1), e._v(" "), s("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: e.is2faEnabled,
                expression: "is2faEnabled"
            }],
            staticClass: "reset-admin-note"
        }, [s("span", {
            staticClass: "syno-ux-note"
        }, [e._v("\n          " + e._s(e.$i18n("common", "note") + e.$i18n("common", "colon") + " ") + "\n        ")]), e._v(" "), s("span", [e._v(" " + e._s(e.$i18n("reset_admin", "reset_otp_note")) + " ")])])], 1)])])
    };
    o._withStripped = !0;
    var a = function() {
        var e = this,
            t = e.$createElement,
            s = e._self._c || t;
        return s("div", {
            staticClass: "login-textfield",
            class: {
                error: e.error
            }
        }, [s("span", {
            class: e.icon,
            style: e.iconStyles
        }), e._v(" "), s("div", {
            staticClass: "input-container"
        }, [s("input", {
            ref: "input",
            class: {
                "has-after-input": e.$slots["after-input"]
            },
            attrs: {
                "syno-id": e.synoId,
                type: e.type,
                placeholder: e.placeholder,
                autofocus: !!e.autofocus,
                name: e.autofillname,
                autocomplete: e.autofillname,
                disabled: e.disabled,
                tabindex: e.tabindex
            },
            domProps: {
                value: e.value
            },
            on: {
                focus: e.onFocus,
                input: e.onInput,
                keydown: e.onKeydown
            }
        }), e._v(" "), e._t("after-input")], 2), e._v(" "), s("div", {
            staticClass: "border active-border",
            style: {
                background: e.bordercolor
            }
        }), e._v(" "), s("div", {
            staticClass: "border bottom-border"
        }), e._v(" "), s("div", {
            staticClass: "border error-border"
        })])
    };

    function l(e, t, s, n, r, i, o, a) {
        var l, c = "function" == typeof e ? e.options : e;
        if (t && (c.render = t, c.staticRenderFns = s, c._compiled = !0), n && (c.functional = !0), i && (c._scopeId = "data-v-" + i), o ? (l = function(e) {
                (e = e || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) || "undefined" == typeof __VUE_SSR_CONTEXT__ || (e = __VUE_SSR_CONTEXT__), r && r.call(this, e), e && e._registeredComponents && e._registeredComponents.add(o)
            }, c._ssrRegister = l) : r && (l = a ? function() {
                r.call(this, this.$root.$options.shadowRoot)
            } : r), l)
            if (c.functional) {
                c._injectStyles = l;
                var u = c.render;
                c.render = function(e, t) {
                    return l.call(t), u(e, t)
                }
            } else {
                var d = c.beforeCreate;
                c.beforeCreate = d ? [].concat(d, l) : [l]
            } return {
            exports: e,
            options: c
        }
    }
    a._withStripped = !0;
    var c = l({
        props: {
            value: {
                type: String,
                default: ""
            },
            type: {
                type: String,
                default: ""
            },
            icon: {
                type: Object,
                default: function() {
                    return {}
                }
            },
            iconUri: {
                type: String,
                default: ""
            },
            placeholder: {
                type: String,
                default: ""
            },
            autofocus: Boolean,
            bordercolor: {
                type: String,
                default: ""
            },
            autofillname: {
                type: String,
                default: ""
            },
            disabled: {
                type: Boolean,
                default: !1
            },
            tabindex: {
                type: Number,
                default: 0
            },
            synoId: {
                type: String,
                default: ""
            }
        },
        data: function() {
            return {
                error: !1
            }
        },
        computed: {
            iconStyles: function() {
                var e = {};
                return this.iconUri && (e.backgroundImage = "url(" + this.iconUri + ")"), e
            }
        },
        watch: {
            value: function(e) {
                void 0 !== e && this.validate()
            }
        },
        methods: {
            onFocus: function(e) {
                this.$emit("focus", e)
            },
            onInput: function(e) {
                this.$emit("input", e.target.value)
            },
            onKeydown: function(e) {
                "Enter" === e.key && this.$emit("submit")
            },
            focus: function() {
                this.$refs.input.focus()
            },
            validate: function() {
                return "password" === this.type || (this.error = !this.value, !this.error)
            }
        }
    }, a, [], !1, null, null, null);
    c.options.__file = "login/js/components/textfield.vue";
    var u = c.exports,
        d = function() {
            var e = this.$createElement,
                t = this._self._c || e;
            return t("button", {
                staticClass: "login-button",
                class: this.buttonClass,
                attrs: {
                    type: "button"
                },
                on: {
                    click: this.onClick
                }
            }, [t("div", {
                staticClass: "text"
            }, [this._t("default")], 2), this._v(" "), t("div", {
                staticClass: "spinner"
            }, [t("svg", {
                staticClass: "circle",
                attrs: {
                    viewBox: "0 0 32 32",
                    width: "32px",
                    height: "32px",
                    focusable: "false"
                }
            }, [t("g", {
                attrs: {
                    stroke: "none",
                    "stroke-width": "1",
                    fill: "none",
                    "fill-rule": "evenodd"
                }
            }, [t("g", {
                attrs: {
                    fill: "#FFFFFF"
                }
            }, [t("path", {
                attrs: {
                    d: "M28,16 C28,14.8954305 28.8954305,14 30,14 C31.1045695,14 32,14.8954305 32,16 C32,24.836556 24.836556,32 16,32 C7.163444,32 0,24.836556 0,16 C0,7.163444 7.163444,0 16,0 C17.1045695,0 18,0.8954305 18,2 C18,3.1045695 17.1045695,4 16,4 C9.372583,4 4,9.372583 4,16 C4,22.627417 9.372583,28 16,28 C22.627417,28 28,22.627417 28,16 Z"
                }
            })])])])])])
        };

    function p(e, t, s) {
        return t in e ? Object.defineProperty(e, t, {
            value: s,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : e[t] = s, e
    }
    d._withStripped = !0;
    var m = l({
        props: {
            disabled: Boolean,
            color: {
                type: String,
                default: "blue"
            },
            size: {
                type: String,
                default: ""
            },
            spin: {
                type: Boolean,
                default: !1
            }
        },
        computed: {
            buttonClass: function() {
                return [p({}, "login-button-".concat(this.color), this.color), p({}, "login-button-".concat(this.size), this.size), {
                    disable: this.disabled
                }, {
                    spin: this.spin
                }]
            }
        },
        methods: {
            onClick: function(e) {
                this.disabled || this.spin || this.$emit("click", e)
            }
        }
    }, d, [], !1, null, null, null);
    m.options.__file = "login/js/components/loginButton.vue";
    var f = m.exports,
        h = function() {
            var e = this.$createElement;
            this._self._c;
            return this._m(0)
        };
    h._withStripped = !0;
    s(3);
    var v = l({}, h, [function() {
        var e = this.$createElement,
            t = this._self._c || e;
        return t("div", {
            staticClass: "loading-icon"
        }, [t("i", [t("i")])])
    }], !1, null, "0b20bb9e", null);

    function _(e, t, s, n, r, i, o) {
        try {
            var a = e[i](o),
                l = a.value
        } catch (e) {
            return void s(e)
        }
        a.done ? t(l) : Promise.resolve(l).then(n, r)
    }

    function g(e) {
        return function() {
            var t = this,
                s = arguments;
            return new Promise((function(n, r) {
                var i = e.apply(t, s);

                function o(e) {
                    _(i, n, r, o, a, "next", e)
                }

                function a(e) {
                    _(i, n, r, o, a, "throw", e)
                }
                o(void 0)
            }))
        }
    }
    v.options.__file = "login/js/components/loadingIcon.vue";
    var b, w = l({
        mixins: [],
        components: {
            textfield: u,
            "login-button": f,
            "loading-icon": v.exports
        },
        props: {
            adminList: {
                type: Array,
                default: []
            }
        },
        data: function() {
            return {
                username: "",
                password: "",
                confirmPassword: "",
                confirmPassError: "",
                msgText: "",
                msgCls: "",
                msgShow: !1,
                passwordStrenghLevel: -1,
                is2faEnabled: !1,
                disableSubmit: !1
            }
        },
        watch: {
            confirmPassError: function(e) {
                this.$refs.confirmPassword.error = "" !== e
            },
            adminList: function(e) {
                0 >= e.length ? this.username = "admin" : 1 == e.length ? (this.username = e[0].name, this.is2faEnabled = e[0].is_2fa_enabled) : this.username = ""
            },
            password: function(e) {
                var t, s = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : 250;
                return function() {
                    for (var n = this, r = arguments.length, i = new Array(r), o = 0; o < r; o++) i[o] = arguments[o];
                    var a = function() {
                        clearTimeout(t), e.apply(n, i)
                    };
                    clearTimeout(t), t = setTimeout(a, s)
                }
            }(g(regeneratorRuntime.mark((function e() {
                var t, s = arguments;
                return regeneratorRuntime.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return t = s.length > 0 && void 0 !== s[0] ? s[0] : "", e.next = 3, this.getPasswordStrengthLevel(t);
                        case 3:
                            this.passwordStrenghLevel = e.sent;
                        case 4:
                        case "end":
                            return e.stop()
                    }
                }), e, this)
            }))), 250)
        },
        computed: {
            selectOptions: function() {
                return this.adminList.map((function(e) {
                    return {
                        label: e.name,
                        value: e.name,
                        is_2fa_enabled: e.is_2fa_enabled
                    }
                }))
            },
            isButtonDisabled: function() {
                return 0 == this.username.length || 0 == this.password.length || 0 == this.confirmPassword.length || this.disableSubmit
            },
            passwordStrengthText: function() {
                var e = [_T("welcome", "passwd_weak"), _T("welcome", "passwd_medium"), _T("welcome", "passwd_strong")];
                return this.passwordStrenghLevel < 0 || e.length <= this.passwordStrenghLevel ? "" : e[this.passwordStrenghLevel]
            }
        },
        methods: {
            onSubmit: function() {
                var e = this;
                this.confirmPassError = "", this.msgShow = !1, this.password === this.confirmPassword ? (this.disableSubmit = !0, this.setLoading(), SYNO.SDS.StatusNotifier.fireEvent("halt"), synowebapi.promises.request({
                    api: "SYNO.Entry.Request",
                    version: 1,
                    method: "request",
                    encryption: ["password"],
                    compound: {
                        stopwhenerror: !0,
                        params: this.getWebapiRequests()
                    }
                }).then((function(t) {
                    if (t.has_fail) return e.setError(e.getErrorMsg(t)), void(e.disableSubmit = !1);
                    e.$emit("goto-step", "reset-admin-success-step")
                })).catch((function(t) {
                    SYNO.Debug.error(t), e.setError(e.getErrorMsg(t)), e.disableSubmit = !1
                }))) : this.confirmPassError = _T("login", "forget_pass_comfirm_password_error")
            },
            onUserSelect: function(e) {
                this.is2faEnabled = e.is_2fa_enabled
            },
            getErrorMsg: function(e) {
                var t = "";
                if (3121 === SYNO.API.Response.GetFirstError(e).code) {
                    var s = [_T("login", "password_formation_rules"), _T("login", "need_longer_password"), _T("login", "exclude_username")].reduce((function(e, t) {
                        return "".concat(e, "<li>").concat(t, "</li>")
                    }), "");
                    t = _T("login", "possible_reasons_are").replace("{0}", '<br/><ul align="left">'.concat(s, "</ul>"))
                } else t = SYNO.API.getErrorString(e);
                return t
            },
            getWebapiRequests: function() {
                var e = [{
                    api: "SYNO.Core.User",
                    method: "set",
                    version: 1,
                    params: {
                        name: this.username,
                        password: this.password,
                        expired: "normal"
                    }
                }, {
                    api: "SYNO.Core.ResetAdmin",
                    method: "disable",
                    version: 1
                }];
                return this.is2faEnabled && e.push({
                    api: "SYNO.SecureSignIn.Method.Admin",
                    method: "reset",
                    version: 1,
                    params: {
                        account: this.username
                    }
                }), "admin" !== this.username ? e.push({
                    api: "SYNO.Core.User",
                    method: "set",
                    version: 1,
                    params: {
                        name: "admin",
                        expired: "now",
                        password: function() {
                            var e = function(e) {
                                    return Math.floor(Math.random() * e)
                                },
                                t = "abcdefghijklmnopqrstuvwxyz",
                                s = "ABCDEFGHIJKLMNOPQRSTUVWXYZ",
                                n = "~`!@#$%^&*()-_+={[}]|\\:;\"'<,>.?/",
                                r = "1234567890" + t + s + n,
                                i = 16 + e(32),
                                o = [],
                                a = 0;
                            for (Ext.each(["1234567890", t, s, n], (function(t) {
                                    o[a++] = t[e(t.length)]
                                })); a < i;) o[a++] = r[e(r.length)];
                            for (; 0 !== a;) {
                                var l = e(a--),
                                    c = o[a];
                                o[a] = o[l], o[l] = c
                            }
                            return o.join("")
                        }()
                    }
                }) : e.push({
                    api: "SYNO.API.Auth",
                    method: "logout",
                    version: 6
                }), e
            },
            getPasswordStrengthLevel: (b = g(regeneratorRuntime.mark((function e() {
                var t, s, n, r, i = arguments;
                return regeneratorRuntime.wrap((function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return t = i.length > 0 && void 0 !== i[0] ? i[0] : "", e.next = 3, synowebapi.promises.request({
                                api: "SYNO.Core.User.PasswordMeter",
                                method: "evaluate",
                                version: "1",
                                encryption: ["password"],
                                params: {
                                    password: t
                                }
                            });
                        case 3:
                            return s = e.sent, n = s.score, r = Math.floor(n / 2), e.abrupt("return", r);
                        case 7:
                        case "end":
                            return e.stop()
                    }
                }), e, this)
            }))), function() {
                return b.apply(this, arguments)
            }),
            setError: function(e, t) {
                this.msgText = e || _T("error", "error_error_system"), this.msgCls = t || "error", this.msgShow = !0
            },
            setLoading: function(e, t) {
                this.msgText = e || _T("common", "msg_waiting"), this.msgCls = t || "loading", this.msgShow = !0
            },
            setMsg: function(e, t) {
                this.msgText = e, this.msgCls = t || "", this.msgShow = !0
            }
        }
    }, o, [function() {
        var e = this.$createElement,
            t = this._self._c || e;
        return t("div", {
            staticClass: "area-center-left"
        }, [t("div", {
            staticClass: "img-new-password"
        })])
    }], !1, null, null, null);
    w.options.__file = "src/reset-admin-steps/reset-admin-step.vue";
    var S = w.exports,
        C = function() {
            var e = this,
                t = e.$createElement,
                s = e._self._c || t;
            return s("div", {
                staticClass: "login-page-common-layout"
            }, [s("div", {
                staticClass: "area-top"
            }, [s("div", {
                staticClass: "header"
            }, [s("div", {
                staticClass: "title"
            }, [e._v("\n        " + e._s(e.$i18n("forgot_pass", "change_success_title")) + "\n      ")]), e._v(" "), s("div", {
                staticClass: "desc"
            }, [e._v("\n        " + e._s(e.$i18n("forgot_pass", "change_success_desc")) + "\n      ")])])]), e._v(" "), s("div", {
                staticClass: "area-center"
            }, [s("div", {
                staticClass: "img-new-password-success"
            }), e._v(" "), s("login-button", {
                staticClass: "btn-login-now",
                on: {
                    click: e.gotoLogin
                }
            }, [e._v("\n      " + e._s(e.$i18n("forgot_pass", "login_now")) + "\n    ")])], 1)])
        };
    C._withStripped = !0;
    var y = l({
        mixins: [],
        components: {
            "login-button": f
        },
        data: function() {
            return {}
        },
        methods: {
            gotoLogin: function() {
                window.location = "/"
            }
        }
    }, C, [], !1, null, null, null);

    function x(e, t, s, n, r, i, o) {
        try {
            var a = e[i](o),
                l = a.value
        } catch (e) {
            return void s(e)
        }
        a.done ? t(l) : Promise.resolve(l).then(n, r)
    }
    y.options.__file = "src/reset-admin-steps/reset-admin-success-step.vue";
    var E, P, $ = {
            mixins: [],
            components: {
                ResetAdminStep: S,
                ResetAdminSuccessStep: y.exports
            },
            data: function() {
                return {
                    adminList: [],
                    step: "reset-admin-step"
                }
            },
            methods: {
                canOpen: (E = regeneratorRuntime.mark((function e() {
                    return regeneratorRuntime.wrap((function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (_S("is_admin") && "admin" === _S("user")) {
                                    e.next = 2;
                                    break
                                }
                                return e.abrupt("return", !1);
                            case 2:
                                return e.next = 4, this.resetAdminInfoLoad();
                            case 4:
                                return e.abrupt("return", e.sent);
                            case 5:
                            case "end":
                                return e.stop()
                        }
                    }), e, this)
                })), P = function() {
                    var e = this,
                        t = arguments;
                    return new Promise((function(s, n) {
                        var r = E.apply(e, t);

                        function i(e) {
                            x(r, s, n, i, o, "next", e)
                        }

                        function o(e) {
                            x(r, s, n, i, o, "throw", e)
                        }
                        i(void 0)
                    }))
                }, function() {
                    return P.apply(this, arguments)
                }),
                resetAdminInfoLoad: function() {
                    var e = this;
                    return SYNO.API.RequestPromise({
                        api: "SYNO.Core.ResetAdmin",
                        method: "get",
                        version: 1
                    }).then((function(t) {
                        return e.adminList = t.admin_list, t.reset_admin
                    })).catch((function(e) {
                        return SYNO.Debug.error(e), !1
                    }))
                },
                onGotoStep: function(e) {
                    this.step = e
                },
                shouldLaunch: function() {
                    return !0
                }
            }
        },
        O = (s(4), l($, i, [], !1, null, null, null));
    O.options.__file = "src/App.vue";
    var L = O.exports;
    Ext.namespace("SYNO.SDS.App.ResetAdminApp"), 
/**
 * @class SYNO.SDS.App.ResetAdminApp.Instance
 * ResetAdmin application instance class
 *
 */    
    SYNO.SDS.App.ResetAdminApp.Instance = r.a.extend({
        template: "<App/>",
        components: {
            App: L
        }
    })
}]);
