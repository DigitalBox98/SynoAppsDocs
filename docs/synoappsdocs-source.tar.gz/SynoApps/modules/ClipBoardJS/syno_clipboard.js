/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.ClipBoardUtil
 * @extends Ext.util.Observable
 * ClipBoard util class
 *
 */
Ext.define("SYNO.SDS.ClipBoardUtil", {
    extend: "Ext.util.Observable",
    fixedText: false,
    inputText: "",
    clipAction: "copy",
    constructor: function(a) {
        Ext.apply(this, a);
        if (!this.handlerId || (!this.fixedText && !this.clipTarget && !this.getTargetFn)) {
            SYNO.Debug("Wrong Inupt")
        }
        this.callParent(arguments);
        this.initEvents();
        this.initClipBoard()
    },
    setClipText: function(b) {
        var a = Ext.get(this.handlerId);
        this.inputText = b;
        if (a) {
            a.set({
                "data-clipboard-text": this.inputText
            })
        }
    },
    initEvents: function() {
        this.addEvents("clipsucceed", "clipfailed")
    },
    initClipBoard: function() {
        if (Ext.isIE8) {
            return
        }
        var f = this,
            d = Ext.get(f.handlerId),
            a = {},
            c, g = {},
            b = ["text", "target"],
            e;
        if (!d) {
            SYNO.Debug("Cannot Find Handler Element");
            return
        }
        if (f.fixedText) {
            a["data-clipboard-text"] = f.inputText
        } else {
            if (Ext.isString(f.clipTarget)) {
                f.clipTarget = Ext.getDom(f.clipTarget)
            } else {
                if (f.clipTarget instanceof Ext.Element) {
                    f.clipTarget = f.clipTarget.dom
                } else {
                    if (f.clipTarget instanceof Ext.Component) {
                        f.clipTarget = f.clipTarget.getEl().dom
                    }
                }
            }
            if (f.clipTarget instanceof HTMLElement) {
                a["data-clipboard-target"] = "#" + f.clipTarget.id
            }
            if (f.clipAction !== "copy") {
                a["data-clipboard-action"] = "cut"
            }
        }
        Ext.each(b, function(h) {
            e = h.charAt(0).toUpperCase() + h.slice(1);
            if (f["get" + e + "Fn"]) {
                g[h] = f["get" + e + "Fn"].createDelegate(f["get" + e + "Scope"] || window)
            }
        });
        d.set(a);
        c = new Clipboard("#" + d.id, g);
        c.on("success", function(h) {
            f.fireEvent("clipsucceed", h)
        });
        c.on("error", function(h) {
            f.fireEvent("clipfailed", h)
        });
        this.clipBoard = c
    },
    destroy: function() {
        if (!this.clipBoard) {
            return
        }
        this.clipBoard.destroy();
        this.clipBoard = null
    }
});
Ext.define("SYNO.SDS.Utils.ClipBoardButton", {
    extend: "SYNO.ux.Button",
    constructor: function(a) {
        if (!a.clipCfg) {
            SYNO.Debug("clipCfg is needed");
            return
        }
        this.addEvents("clipsucceed", "clipfailed");
        var b = {
            tooltip: (a.clipCfg && a.clipCfg.clipAction === "cut") ? _T("filebrowser", "filetable_cut") : _T("filebrowser", "filetable_copy")
        };
        this.callParent([Ext.apply(b, a)])
    },
    afterRender: function() {
        this.callParent(arguments);
        var a = this.clipCfg || {},
            b = new SYNO.SDS.ClipBoardUtil(Ext.apply(a, {
                handlerId: this.btnEl.id
            }));
        this.relayEvents(b, ["clipsucceed", "clipfailed"]);
        this.mon(this, "clipfailed", this.onClipFailed, this);
        this.clipboardUtil = b
    },
    onClipFailed: function(a) {
        if (this.appWin) {
            this.appWin.getMsgBox().alert(_T("error", "error_error"), _T("error", "clip_failed"))
        }
    },
    onClick: function(a) {
        if ((a && this.disabled) || Ext.isIE8) {
            a.stopEvent()
        }
        if (Ext.isIE8) {
            this.fireEvent("clipfailed")
        }
        this.callParent(arguments)
    },
    destroy: function() {
        if (this.clipboardUtil) {
            this.clipboardUtil.destroy();
            this.clipboardUtil = null
        }
        this.callParent(arguments)
    }
});
Ext.define("SYNO.SDS.Utils.ClipBoardComposite", {
    extend: "SYNO.ux.CompositeField",
    BTN_CUT_CLASS: "clipboard-btn-cut",
    BTN_COPY_CLASS: "clipboard-btn-copy",
    disableWhenEmpty: true,
    constructor: function(a) {
        this.initFields(a);
        this.addEvents("clipsucceed", "clipfailed");
        this.callParent(arguments)
    },
    initFields: function(a) {
        var b = this,
            c;
        a.textFieldCfg = a.textFieldCfg || {};
        a.btnCfg = a.btnCfg || {};
        b.textFieldId = Ext.id();
        a.textFieldCfg.id = b.textFieldId;
        b.textField = new SYNO.ux.TextField(Ext.apply(a.textFieldCfg, {
            enableKeyEvents: true,
            setValue: function(d) {
                SYNO.ux.TextField.superclass.setValue.call(b.textField, d);
                b.updateBtnStatus()
            }
        }));
        if (a.disableWhenEmpty) {
            c = !a.textFieldCfg.value
        } else {
            c = (a.btnCfg && Ext.isDefined(a.btnCfg.disabled)) ? a.btnCfg.disabled : false
        }
        a.btnCfg.clipCfg = a.btnCfg.clipCfg || {};
        a.btnCfg.clipCfg.clipTarget = b.textFieldId;
        b.btn = new SYNO.SDS.Utils.ClipBoardButton(Ext.apply(a.btnCfg, {
            disabled: c
        }));
        if (a.btnCfg.clipCfg.clipAction && a.btnCfg.clipCfg.clipAction === "cut") {
            b.btn.addClass(b.BTN_CUT_CLASS)
        } else {
            b.btn.addClass(b.BTN_COPY_CLASS)
        }
        if (a.items) {
            if (!Ext.isArray(a.items)) {
                a.items = [a.items]
            }
        } else {
            a.items = []
        }
        a.items.push(b.textField);
        a.items.push(b.btn);
        delete a.textFieldCfg;
        delete a.btnCfg;
        return a
    },
    enable: function() {
        this.textField.enable();
        if (this.label) {
            this.label.removeClass(this.disabledClass)
        }
        this.btn.enable()
    },
    disable: function() {
        this.textField.disable();
        if (this.label) {
            this.label.addClass(this.disabledClass)
        }
        this.btn.disable()
    },
    afterRender: function() {
        this.callParent(arguments);
        this.relayEvents(this.btn, ["clipsucceed", "clipfailed"]);
        this.mon(this, "clipfailed", this.onClipFailed, this);
        this.mon(this, "clipsucceed", this.updateBtnStatus, this);
        this.mon(this.textField, "keyup", this.updateBtnStatus, this, {
            buffer: 200
        })
    },
    onClipFailed: function(a) {
        if (this.appWin) {
            this.appWin.getMsgBox().alert(_T("error", "error_error"), _T("error", "clip_failed"))
        }
    },
    updateBtnStatus: function() {
        if (!this.disableWhenEmpty) {
            return
        }
        this.btn.setDisabled(Ext.isEmpty(this.textField.getValue()))
    }
});
