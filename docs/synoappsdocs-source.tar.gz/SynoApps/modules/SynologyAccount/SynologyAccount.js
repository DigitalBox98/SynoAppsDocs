/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function asyncGeneratorStep(e, t, n, i, r, s, o) {
    try {
        var a = e[s](o),
            c = a.value
    } catch (e) {
        return void n(e)
    }
    a.done ? t(c) : Promise.resolve(c).then(i, r)
}

function _asyncToGenerator(e) {
    return function() {
        var t = this,
            n = arguments;
        return new Promise(function(i, r) {
            var s = e.apply(t, n);

            function o(e) {
                asyncGeneratorStep(s, i, r, o, a, "next", e)
            }

            function a(e) {
                asyncGeneratorStep(s, i, r, o, a, "throw", e)
            }
            o(void 0)
        })
    }
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _defineProperties(e, t) {
    for (var n = 0; n < t.length; n++) {
        var i = t[n];
        i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(e, i.key, i)
    }
}

function _createClass(e, t, n) {
    return t && _defineProperties(e.prototype, t), n && _defineProperties(e, n), e
}
 /**
 * @class SYNO.SDS.SynologyAccount 
 * SynologyAccount object class
 *
 */  
SYNO.SDS.SynologyAccount = Object.create(null, {}), SYNO.SDS.SynologyAccount.WebLogin = function() {
    function e() {
        _classCallCheck(this, e), this._registerUrl = "", this._loginUrl = "", this._events = [], this._pkceClient = null
    }
    return _createClass(e, [{
        key: "initialize",
        value: function() {
            var e = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return e.next = 2, this.getUrl();
                        case 2:
                        case "end":
                            return e.stop()
                    }
                }, e, this)
            }));
            return function() {
                return e.apply(this, arguments)
            }
        }()
    }, {
        key: "getUrl",
        value: function() {
            var e = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t, n, i;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return e.prev = 0, e.next = 3, synowebapi.promises.request({
                                api: "SYNO.Entry.Request",
                                method: "request",
                                version: 1,
                                timeout: 3e4,
                                compound: {
                                    mode: "parallel",
                                    stopwhenerror: !1,
                                    params: [{
                                        api: "SYNO.Core.MyDSCenter.Login",
                                        method: "pkce_config_get",
                                        version: 1
                                    }, {
                                        api: "SYNO.Core.MyDSCenter",
                                        method: "available_servers",
                                        version: 2
                                    }]
                                }
                            });
                        case 3:
                            !0 !== (t = e.sent).has_fail && ((n = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.MyDSCenter.Login", "pkce_config_get")) && (this._pkceConfigLogin = n.login, this._pkceConfigRegister = n.register, this._loginUrl = this._pkceConfigLogin.auth_endpoint, this._registerUrl = this._pkceConfigRegister.auth_endpoint), (i = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.MyDSCenter", "available_servers")) && (this._availableServers = i)), e.next = 10;
                            break;
                        case 7:
                            e.prev = 7, e.t0 = e.catch(0), SYNO.Debug(e.t0);
                        case 10:
                        case "end":
                            return e.stop()
                    }
                }, e, this, [
                    [0, 7]
                ])
            }));
            return function() {
                return e.apply(this, arguments)
            }
        }()
    }, {
        key: "pkceClientCallback",
        value: function() {
            var e = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
                var n, i;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            if (t) {
                                e.next = 4;
                                break
                            }
                            return this.emit("close"), this.unregister(), e.abrupt("return");
                        case 4:
                            if (!t.message) {
                                e.next = 10;
                                break
                            }
                            return this.emit("reject", t.message), this.emit("processed"), this.unregister(), this._isProcessing = !1, e.abrupt("return");
                        case 10:
                            return e.prev = 10, this._isProcessing = !0, this.emit("processing"), n = {}, n = this._isRegister ? this._pkceConfigRegister : this._pkceConfigLogin, e.next = 17, synowebapi.promises.request({
                                api: "SYNO.Core.MyDSCenter.Login",
                                method: "pkce_login",
                                version: 1,
                                params: {
                                    code_challenge: t.challenge,
                                    grant_code: t.code,
                                    client_id: n.client_id,
                                    token_endpoint: n.token_endpoint,
                                    redirect_uri: n.login_redirect_uri
                                }
                            });
                        case 17:
                            i = e.sent, this.emit("resolve", i), e.next = 24;
                            break;
                        case 21:
                            e.prev = 21, e.t0 = e.catch(10), this.emit("reject", e.t0);
                        case 24:
                            return e.prev = 24, this.emit("processed"), this.unregister(), this._isProcessing = !1, e.finish(24);
                        case 29:
                        case "end":
                            return e.stop()
                    }
                }, e, this, [
                    [10, 21, 24, 29]
                ])
            }));
            return function(t) {
                return e.apply(this, arguments)
            }
        }()
    }, {
        key: "popLoginWeb",
        value: function(e, t, n) {
            this._isRegister = !1, this.popWeb(this._pkceConfigLogin, e, t, n)
        }
    }, {
        key: "popCreateWeb",
        value: function(e, t, n) {
            this._isRegister = !0, this.popWeb(this._pkceConfigRegister, e, t, n)
        }
    }, {
        key: "popWeb",
        value: function(e, t, n, i) {
            this.unregister(), this.register(), this.on("resolve", t), this.on("reject", n), this.on("close", i), this._pkceClient = new synocredential.PKCEClient({
                url: e.auth_endpoint,
                client_id: e.client_id,
                audience: e.audience,
                scope: e.scope,
                redirect_uri: e.login_redirect_uri,
                callback: this.pkceClientCallback.bind(this)
            }), this._pkceClient.execute()
        }
    }, {
        key: "popLogoutWeb",
        value: function(e) {
            this._pkceClient = new synocredential.PKCEClient({
                end_session_url: this._pkceConfigLogin.end_session_endpoint,
                logout_redirect_uri: this._pkceConfigLogin.logout_redirect_uri
            }), this._pkceClient.logout(e)
        }
    }, {
        key: "cancel",
        value: function() {
            this.unregister(), this._pkceClient && this._pkceClient.cancel()
        }
    }, {
        key: "register",
        value: function() {
            window.addEventListener("message", this.listener)
        }
    }, {
        key: "unregister",
        value: function() {
            window.removeEventListener("message", this.listener), this.un()
        }
    }, {
        key: "un",
        value: function(e) {
            void 0 === e ? this._events = [] : Ext.isString(e) && delete this._events[e]
        }
    }, {
        key: "on",
        value: function(e, t) {
            this._events[e] = this._events[e] || [], Ext.isFunction(t) && this._events[e].push(t)
        }
    }, {
        key: "listened",
        value: function(e) {
            return Ext.isString(e) && this._events.hasOwnProperty(e) && Ext.isArray(this._events[e])
        }
    }, {
        key: "emit",
        value: function(e, t) {
            this.listened(e) && this._events[e].forEach(function(e) {
                e(t)
            })
        }
    }, {
        key: "registerUrl",
        get: function() {
            return this._registerUrl
        }
    }, {
        key: "loginUrl",
        get: function() {
            return this._loginUrl
        }
    }, {
        key: "isProcessing",
        get: function() {
            return this._isProcessing
        }
    }], [{
        key: "create",
        value: function() {
            var e = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                var t;
                return regeneratorRuntime.wrap(function(e) {
                    for (;;) switch (e.prev = e.next) {
                        case 0:
                            return t = new SYNO.SDS.SynologyAccount.WebLogin, e.next = 3, t.initialize();
                        case 3:
                            return e.abrupt("return", t);
                        case 4:
                        case "end":
                            return e.stop()
                    }
                }, e, this)
            }));
            return function() {
                return e.apply(this, arguments)
            }
        }()
    }]), e
}();
