/* Copyright (c) 2020 Synology Inc. All rights reserved. */

if (window.d3) {
    Ext.define("SYNO.SDS.DataDrivenDocuments", {
        statics: {
            DrawHelper: window.d3
        }
    });
    window.d3 = undefined
};