/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.SystemInfoApp");
/**
 * @class SYNO.SDS.SystemInfoApp.StorageUsageWidget
 * @extends Ext.Panel
 * SystemInfoApp storage usage widget class
 *
 */
SYNO.SDS.SystemInfoApp.StorageUsageWidget = Ext.extend(Ext.Panel, {
    isUSBStation: null,
    supportBuildinStorage: null,
    widgetLayout: "fit",
    toggleButtonCls: SYNO.SDS._Widget.MiniWidget,
    charts: [],
    constructor: function constructor(a) {
        this.individualVols = [];
        this.storageGrid = new SYNO.SDS._Widget.GridPanel({
            itemId: "storageGrid",
            cls: "sds-widget-gridpanel sys-storage-grid",
            store: this.store = this.getStorageDataStore(),
            cm: this.getStorageColumnModel(a),
            autoLoad: false,
            autoDestroy: false,
            listeners: {
                afterrender: {
                    fn: this.activateStorageView,
                    scope: this,
                    single: true,
                    buffer: 80
                }
            }
        });
        this.isUSBStation = "yes" === _D("usbstation", "no");
        this.supportBuildinStorage = "yes" === _D("support_buildin_storage", "no");
        this.cgiHandler = this.jsConfig.jsBaseURL + "/SystemInfo.cgi";
        var b = Ext.apply(this.getConfig(), a);
        SYNO.SDS.SystemInfoApp.StorageUsageWidget.superclass.constructor.call(this, b);
        this.volinfos = null;
        this.isActive = false
    },
    getConfig: function getConfig() {
        return {
            border: false,
            layout: "fit",
            defaults: {
                border: false
            },
            items: [this.storageGrid]
        }
    },
    activateStorageView: function activateStorageView() {
        var b = null;
        var c = {};
        b = this.cgiHandler;
        c = {
            query: "storage"
        };
        this.pollTask = this.pollTask || this.addAjaxTask({
            id: "storage_widget_pooling_task",
            interval: 60 * 1000,
            url: b,
            params: c,
            method: "POST",
            success: this.loadStorageInfo,
            failure: function a(d, e) {
                SYNO.Debug("Ajax load failure " + d.responseText)
            },
            scope: this
        });
        if (this.isActive) {
            this.mask(_T("common", "loading"));
            this.pollTask.start()
        }
    },
    loadStorageInfo: function loadStorageInfo(b, h) {
        if (!this.isActive) {
            return
        }
        var g = Ext.decode(b.responseText);
        var a = null;
        var f, c;
        var e = null;
        var d = 0;
        if (this.isUSBStation) {
            a = [];
            for (f = 0; g.devices && f < g.devices.length; ++f) {
                e = g.devices[f];
                if (e.partitions && e.partitions.length > 0) {
                    for (c = 0; c < e.partitions.length; ++c) {
                        if (!Ext.isDefined(e.partitions[c].share_name) || Ext.isEmpty(e.partitions[c].share_name)) {
                            continue
                        }
                        a.push({
                            status: e.partitions[c].status,
                            total_size: parseInt(e.partitions[c].total_size_mb, 10) * 1024 * 1024,
                            used_size: parseInt(e.partitions[c].used_size_mb, 10) * 1024 * 1024,
                            volume: e.partitions[c].share_name,
                            volstr: e.partitions[c].share_name
                        });
                        ++d
                    }
                } else {
                    ++d
                }
            }
        } else {
            a = g.vol_info
        }
        if (a === null || a === "") {
            a = []
        }
        if (this.supportBuildinStorage && this.isUSBStation) {
            a.unshift({
                status: g.vol_info[0].status,
                total_size: g.vol_info[0].total_size,
                used_size: g.vol_info[0].used_size,
                volume: g.vol_info[0].volume,
                volstr: _T("system", "system_volume")
            })
        }
        d = a.length;
        if (this.isDestroyed) {
            return
        }
        this.total_vols = d;
        this.volinfos = a;
        this.volinfos.sort(function(j, i) {
            var l, k;
            if (-1 < j.volume.indexOf("volume") && -1 === i.volume.indexOf("volume")) {
                return -1
            }
            if (-1 === j.volume.indexOf("volume") && -1 < i.volume.indexOf("volume")) {
                return 1
            }
            if (-1 < j.volume.indexOf("volume") && -1 < i.volume.indexOf("volume")) {
                if (parseInt(j.volume.replace("volume_", ""), 10) > parseInt(i.volume.replace("volume_", ""), 10)) {
                    return 1
                } else {
                    return -1
                }
            }
            l = j.volume.replace("usbshare", "").replace("-", "");
            k = i.volume.replace("usbshare", "").replace("-", "");
            while (l.length < 4) {
                l += "0"
            }
            while (k.length < 4) {
                k += "0"
            }
            if (l > k) {
                return 1
            }
            return -1
        });
        this.loadInfo()
    },
    onActivate: function onActivate() {
        this.isActive = true;
        var a = this.pollTask;
        if (a) {
            a.start()
        }
    },
    onDeactivate: function onDeactivate() {
        this.isActive = false;
        var a = this.pollTask;
        if (a) {
            a.stop()
        }
        this.unmask()
    },
    mask: function mask(a) {
        this.getEl().mask(a)
    },
    unmask: function unmask() {
        this.getEl().unmask()
    },
    getStorageColumnModel: function getStorageColumnModel(b) {
        if (this.cmSystemLog) {
            return this.cmSystemLog
        }
        var a = new Ext.grid.ColumnModel({
            columns: [{
                dataIndex: "storageVolInfo",
                width: b.cmWidth || 290,
                renderer: function c(g, f, d) {
                    var e = this.convertChartConfig(g, g.total_size || 1, g.used_size || 0, 0);
                    e.volume = g.volume;
                    var h = this.getChartDisplayHtml(e);
                    return h
                },
                scope: this
            }]
        });
        this.cmSystemLog = a;
        return a
    },
    getStorageDataStore: function getStorageDataStore() {
        if (this.dsSystemLog) {
            return this.dsSystemLog
        }
        var a = new Ext.data.Store({
            reader: new Ext.data.ArrayReader({}, [{
                name: "id"
            }, {
                name: "storageVolInfo"
            }])
        });
        this.dsSystemLog = a;
        return a
    },
    loadInfo: function loadInfo() {
        var b = this.total_vols || 0;
        if (0 === b) {
            this.mask(_T("volume", "volume_novolume"))
        } else {
            this.unmask()
        }
        this.individualVols = [];
        for (var a = 0; a < this.total_vols; a++) {
            this.individualVols.push([a, this.volinfos[a]])
        }
        this.storageGrid.store.loadData(this.individualVols)
    },
    doLoad: function doLoad() {
        if (this.rendered) {
            this.mask();
            this.loadInfo();
            this.unmask()
        }
    },
    convertChartConfig: function convertChartConfig(d, e, j, g) {
        var b = {};
        var h = SYNO.SDS.Utils.StorageUtils;
        var f, i;
        var a = "";
        a = d.volstr || h.SpaceIDParser(d.volume).str || "";
        f = parseInt(e, 10);
        i = Math.max(parseInt(j, 10), 0);
        var c = null;
        if (this.isUSBStation) {
            c = SYNO.SDS.Utils.ExternalDevices.getStatus(d.status)
        } else {
            c = h.UiRenderHelper.StatusNameRender(d.status)
        }
        b = {
            volstr: a,
            diskUsed: i,
            diskAvailable: f - i,
            diskTotal: f,
            volStatus: c,
            rawVolStatus: d.status
        };
        return b
    },
    encode: function encode(a) {
        return Ext.util.Format.htmlEncode(a)
    },
    getSizeStr: function getSizeStr(b, a) {
        if (b) {
            return "-"
        }
        return SYNO.SDS.Utils.StorageUtils.UiRenderHelper.SizeRender(a)
    },
    getChartDisplayHtml: function getChartDisplayHtml(f) {
        var b = String.format("{0} ({1})", f.volstr, f.volStatus);
        var c = 182;
        var i = 0 === f.diskUsed && 1 === f.diskTotal;
        var d = this.getSizeStr(i, f.diskUsed);
        var k = this.getSizeStr(i, f.diskTotal);
        var h = d + " / " + k;
        var j = f.diskUsed / f.diskTotal;
        var e = String.format("{0}%", i ? "-" : Math.floor(100 * j));
        var g = i ? 0 : c * j;
        var a = String.format('<div class="syno-sysinfo-storage-usage-volume-box"><div class="icon-block"><div class="icon-volume-img"></div><div class="icon-volume-status {0}"></div></div><div class="data-block"><div class="volume-name-status" ext:qtip="{1}">{2}</div><div class="usage-bar-container"><div class="usage-bar-bg"><div class="usage-bar-fill" style="width: {3}px"></div></div></div><div class="usage-text" ext:qtip="{4}">{5}</div><div class="usage-ratio-text">{6}</div></div></div>', this.getVolStatusLevel(f.rawVolStatus), this.encode(b), b, g, this.encode(h), h, e);
        return a
    },
    getVolStatusLevel: function getVolStatusLevel(b) {
        var a = "acting";
        var d = {
            normal: ["normal"],
            danger: ["danger", "crashed", "degrade", "missing", "read_only"],
            attention: ["attention"]
        };
        var c = Object.keys(d);
        Ext.each(c, function(e) {
            if (-1 !== d[e].indexOf(b)) {
                a = e;
                return false
            }
        });
        return a
    }
});
