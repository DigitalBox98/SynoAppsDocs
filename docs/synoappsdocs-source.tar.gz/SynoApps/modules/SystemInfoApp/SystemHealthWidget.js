/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function _toConsumableArray(a) {
    return _arrayWithoutHoles(a) || _iterableToArray(a) || _nonIterableSpread()
}

function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function _iterableToArray(a) {
    if (Symbol.iterator in Object(a) || Object.prototype.toString.call(a) === "[object Arguments]") {
        return Array.from(a)
    }
}

function _arrayWithoutHoles(a) {
    if (Array.isArray(a)) {
        for (var c = 0, b = new Array(a.length); c < a.length; c++) {
            b[c] = a[c]
        }
        return b
    }
}

function _slicedToArray(a, b) {
    return _arrayWithHoles(a) || _iterableToArrayLimit(a, b) || _nonIterableRest()
}

function _nonIterableRest() {
    throw new TypeError("Invalid attempt to destructure non-iterable instance")
}

function _iterableToArrayLimit(e, d) {
    var h = [];
    var a = true;
    var g = false;
    var f = undefined;
    try {
        for (var c = e[Symbol.iterator](), j; !(a = (j = c.next()).done); a = true) {
            h.push(j.value);
            if (d && h.length === d) {
                break
            }
        }
    } catch (b) {
        g = true;
        f = b
    } finally {
        try {
            if (!a && c["return"] != null) {
                c["return"]()
            }
        } finally {
            if (g) {
                throw f
            }
        }
    }
    return h
}

function _arrayWithHoles(a) {
    if (Array.isArray(a)) {
        return a
    }
}
Ext.ns("SYNO.SDS.SystemInfoApp");

Ext.define("SYNO.SDS.SystemInfoApp.Mini.SystemHealthWidget", {
    extend: "SYNO.SDS._SystemTray.Component",
    constructor: function constructor(a) {
        a = Ext.apply(a, {
            cls: "syno-sysinfo-system-health-mini",
            height: 32
        });
        this.callParent(arguments)
    },
    afterRender: function afterRender() {
        this.callParent(arguments);
        this.setDefaultStatus()
    },
    getIcon: function getIcon(b) {
        var a = SYNO.SDS.SystemInfoApp.RuleMappingUtil.getIcon(b.type);
        var c = _S("hostname");
        return '<div class = "'.concat(a, '" ext:qtip="').concat(b.message, '"></div>\n\t\t\t\t<div class = "system-health-widget-mini-hostname">').concat(c, "</div>")
    },
    setDefaultStatus: function setDefaultStatus() {
        this.setStatus(SYNO.SDS.SystemInfoApp.RuleMappingUtil.getDefaultStatus())
    },
    setStatus: function setStatus(a) {
        this.update(this.getIcon(a))
    }
});
/**
 * @class SYNO.SDS.SystemInfoApp.SystemHealthWidget
 * @extends Ext.Panel
 * SystemInfoApp system health widget class
 *
 */
Ext.define("SYNO.SDS.SystemInfoApp.SystemHealthWidget", {
    extend: "Ext.Panel",
    minimizable: true,
    toggleButtonCls: SYNO.SDS.SystemInfoApp.Mini.SystemHealthWidget,
    taskButton: undefined,
    polling_id: null,
    constructor: function constructor(a) {
        this.initializeSouthTable();
        var b = Ext.apply(this.getConfig(), a);
        SYNO.SDS.SystemInfoApp.SystemHealthWidget.superclass.constructor.call(this, b);
        this.westIcon = this.getIconComponent();
        this.centerContent = this.getContentComponent();
        this.isActive = false;
        this.timestamp = null;
        this.uptime = null;
        this.appSetting = SYNO.SDS.SystemInfoApp.SystemHealthDefaultApp
    },
    getConfig: function getConfig() {
        return {
            layout: "fit",
            border: false,
            defaults: {
                border: false
            },
            items: [this.getViewConfig()],
            listeners: {
                scope: this,
                render: {
                    fn: this.loadInfo,
                    single: true
                }
            }
        }
    },
    getViewConfig: function getViewConfig() {
        return {
            itemId: "layoutPanel",
            layout: "vbox",
            height: "100%",
            border: false,
            padding: "4px 12px 5px 12px",
            cls: "syno-sysinfo-system-health",
            defaults: {
                border: false
            },
            items: [{
                xtype: "container",
                itemId: "northPanel",
                width: 296,
                cls: "syno-sysinfo-system-health-status",
                items: [{
                    xtype: "box",
                    itemId: "westIcon"
                }, {
                    xtype: "box",
                    itemId: "centerContent",
                    region: "center"
                }]
            }, {
                region: "south",
                height: 84,
                width: 296,
                items: this.southTable
            }]
        }
    },
    doCollapse: function doCollapse() {
        this.getEl().setHeight(84);
        this.doLayout()
    },
    doExpand: function doExpand() {
        this.getEl().setHeight(172);
        this.doLayout()
    },
    setStatus: function setStatus(b) {
        var a = this.getContentComponent();
        if (this.taskButton) {
            this.taskButton.setStatus(b)
        }
        if (!this.rendered) {
            return
        }
        this.getIconComponent().update(this.getIcon(b));
        a.update(this.formatContent(b));
        this.getComponent("layoutPanel").getComponent("northPanel").doLayout()
    },
    setApp: function setApp(a) {
        this.appSetting = a
    },
    getIcon: function getIcon(b) {
        var a = SYNO.SDS.SystemInfoApp.RuleMappingUtil.getIcon(b.type);
        return '<div class = "'.concat(a, '"></div>')
    },
    formatContent: function formatContent(c) {
        var a = SYNO.SDS.SystemInfoApp.RuleMappingUtil.getContent(c.type);
        var e = '<div class = "syno-sysinfo-system-health-content" ext:qtip="{0}">{0}</div>';
        var d = '<div class = "syno-sysinfo-system-health-summary {0}" ext:qtip="{1}">{1}</div>';
        var b = String.format(d, a, c.title);
        var f = String.format(e, c.message);
        return '<div class="syno-sysinfo-system-health-content-wrap">' + b + f + "</div>"
    },
    getIconComponent: function getIconComponent() {
        return this.getComponent("layoutPanel").getComponent("northPanel").getComponent("westIcon")
    },
    getContentComponent: function getContentComponent() {
        return this.getComponent("layoutPanel").getComponent("northPanel").getComponent("centerContent")
    },
    startPolling: function startPolling() {
        if (this.polling_id) {
            return
        }
        this.polling_id = this.pollReg({
            interval: 60,
            immediate: true,
            scope: this,
            webapi: {
                api: "SYNO.Core.System.SystemHealth",
                method: "get",
                version: 1
            },
            status_callback: this.polling_callback
        })
    },
    stopPolling: function stopPolling() {
        if (this.polling_id) {
            this.pollUnreg(this.polling_id);
            this.polling_id = null
        }
    },
    polling_callback: function polling_callback(b, a) {
        if (!b) {
            SYNO.Debug("webapi polling failure");
            this.unmask();
            return
        }
        this.setInfo(a)
    },
    loadInfo: function loadInfo() {
        if (this.isActive) {
            this.mask(_T("common", "loading"));
            this.startPolling()
        }
    },
    onClickTitle: function onClickTitle() {
        SYNO.SDS.AppLaunch(this.appSetting.appInstance, this.appSetting.launchParam)
    },
    onActivate: function onActivate() {
        this.isActive = true;
        this.loadInfo()
    },
    onDeactivate: function onDeactivate() {
        this.isActive = false;
        var a = this.getUpdateUptimeTask();
        if (a) {
            a.stop()
        }
        this.stopPolling();
        this.unmask()
    },
    mask: Ext.emptyFn,
    unmask: Ext.emptyFn,
    formatOptTime: function formatOptTime(h) {
        var g = "";
        var f = h.indexOf(":", 0);
        var a = h.substring(0, f);
        var d = h.indexOf(":", f + 1);
        var c = parseInt(h.substring(f + 1, d), 10);
        var e = parseInt(h.substring(d + 1, h.length), 10);
        a = parseInt(a, 10);
        c += (e - e % 60) / 60;
        a += (c - c % 60) / 60;
        var b = (a - a % 24) / 24;
        a = a % 24;
        c = c % 60;
        e = e % 60;
        a = String.leftPad(a, 2, "0");
        c = String.leftPad(c, 2, "0");
        e = String.leftPad(e, 2, "0");
        g = b ? String.format("{0} {1} ", b, _T("status", "status_day")) : "";
        g += a || g !== "" ? String.format("{0}{1}", a, ":") : "";
        g += c || g !== "" ? String.format("{0}{1}", c, ":") : "";
        g += e || g !== "" ? String.format("{0}", e) : "";
        return g
    },
    setInfo: function setInfo(e) {
        if (this.isDestroyed) {
            return
        }
        this.unmask();
        this.timestamp = new Date();
        this.uptime = e.uptime;
        var c = this.parseRule(e.rule),
            a = _slicedToArray(c, 2),
            d = a[0],
            b = a[1];
        this.setApp(d);
        this.setStatus(b);
        if (!this.rendered) {
            return
        }
        this.updateInterfaces(e.interfaces);
        this.getUpdateUptimeTask().stop();
        this.getUpdateUptimeTask().start()
    },
    getUpdateUptimeTask: function getUpdateUptimeTask() {
        this.updateTask = this.updateTask || this.addTask({
            id: "task_update_uptime",
            interval: 1 * 1000,
            run: this.updateUptime,
            scope: this
        });
        return this.updateTask
    },
    sortMenuItemText: function sortMenuItemText(c, a) {
        var d = parseInt(c.text.replace(/[^\d.]/g, ""), 10) || 0;
        var b = parseInt(a.text.replace(/[^\d.]/g, ""), 10) || 0;
        return d - b
    },
    updateIP: function updateIP(b) {
        var c = b.displayIP;
        var a = String.format('<p ext:qtip="{1}" class="syno-sysinfo-system-health-south-data">{0}</p>', c, Ext.util.Format.htmlEncode(c));
        this.southTable.items.items[3].update(a);
        this.ipBtn.setText(b.text);
        this.ipBtn.setTooltip(b.text);
        this.lastSelectedId = b.interfaceID
    },
    updateInterfaces: function updateInterfaces(g) {
        this.interfaces = g;
        this.ipBtn.menu.removeAll();
        this.lastSelectedId = this.lastSelectedId || "";
        var f = -1,
            d, c;
        var k = [];
        var a = function a() {
            var j = this.displayIP;
            var i = String.format('<p ext:qtip="{1}" class="syno-sysinfo-system-health-south-data">{0}</p>', j, Ext.util.Format.htmlEncode(j));
            this.parentWidget.southTable.items.items[3].update(i);
            this.parentWidget.ipBtn.setText(this.text);
            this.parentWidget.ipBtn.setTooltip(this.text);
            this.parentWidget.lastSelectedId = this.interfaceID
        };
        for (d = 0; d < this.interfaces.length; d++) {
            var h = d;
            var b = this.interfaces[h];
            var e = SYNO.SDS.Utils.Network.idToString(b.id, b.type);
            k[d] = new Ext.menu.Item({
                interfaceID: b.id,
                text: e,
                tooltip: e,
                displayIP: Ext.util.Format.htmlEncode(b.ip),
                parentWidget: this,
                listeners: {
                    click: {
                        fn: a,
                        scope: k[d]
                    }
                }
            })
        }
        k.sort(this.sortMenuItemText);
        for (c = 0; c < k.length; c++) {
            this.ipBtn.menu.addMenuItem(k[c]);
            if (this.lastSelectedId === k[c].interfaceID) {
                f = c;
                this.updateIP(k[c])
            }
        }
        if (f == -1 && this.interfaces) {
            this.updateIP(k[0])
        }
    },
    initializeSouthTable: function initializeSouthTable() {
        var b = Ext.util.Format.htmlEncode(_T("tcpip", "server_name"));
        var c = Ext.util.Format.htmlEncode(_S("hostname"));
        var a = Ext.util.Format.htmlEncode(_T("widget", "sys_uptime"));
        this.ipBtn = new SYNO.ux.Button({
            text: _T("common", "ip_addr"),
            tooltip: _T("common", "ip_addr"),
            cls: "sys-info-btn",
            menu: new SYNO.ux.Menu({
                items: []
            })
        });
        this.southTable = new Ext.Panel({
            layout: "table",
            itemId: "southTable",
            cls: "sys-info-south-table",
            margins: 0,
            height: 84,
            layoutConfig: {
                columns: 2,
                cellCls: "sys-info-row"
            },
            items: [{
                xtype: "box",
                html: String.format('<p ext:qtip="{1}" class="syno-sysinfo-system-health-south-title">{0}</p>', b, Ext.util.Format.htmlEncode(b))
            }, {
                xtype: "box",
                html: String.format('<p ext:qtip="{1}" class="syno-sysinfo-system-health-south-data">{0}</p>', c, Ext.util.Format.htmlEncode(c))
            }, {
                cellCls: "sys-info-row x-row-alt row-left",
                items: this.ipBtn
            }, {
                xtype: "box",
                cellCls: "sys-info-row x-row-alt",
                html: ""
            }, {
                xtype: "box",
                html: String.format('<p ext:qtip="{1}" class="syno-sysinfo-system-health-south-title">{0}</p>', a, Ext.util.Format.htmlEncode(a))
            }, {
                xtype: "box",
                html: ""
            }]
        })
    },
    updateUptime: function updateUptime() {
        try {
            var a = new Date();
            var l = this.timestamp;
            var i = this.uptime;
            var n = Math.round((a.getTime() - l.getTime()) / 1000);
            var p = n % (60 * 60) % 60;
            var c = (n - p) % (60 * 60) / 60;
            var j = (n - c * 60 - p) / 60 / 60;
            var b = i.split(":");
            var f = parseInt(b[0], 10) + j;
            var g = parseInt(b[1], 10) + c;
            var k = parseInt(b[2], 10) + p;
            if (this.southTable) {
                var d = Ext.util.Format.htmlEncode(this.formatOptTime([f, g, k].join(":")));
                var o = String.format('<p ext:qtip="{1}" class="syno-sysinfo-system-health-south-data">{0}</p>', d, Ext.util.Format.htmlEncode(d));
                this.southTable.items.items[5].update(o)
            }
        } catch (e) {
            SYNO.Debug("Fail to update uptime" + e);
            this.onDeactivate();
            this.onActivate()
        }
    },
    destroy: function destroy() {
        var a = this;
        a.onDeactivate();
        if (a.taskButton) {
            Ext.destroy(a.taskButton)
        }
        if (a.southGrid && a.southGrid.getStore()) {
            a.southGrid.getStore().destroy()
        }
        SYNO.SDS.SystemInfoApp.SystemHealthWidget.superclass.destroy.call(this)
    },
    parseRule: function parseRule(c) {
        var a = function a(e) {
            var d = function d(g) {
                return g.map(function(h) {
                    return _T.apply(void 0, _toConsumableArray(h.split(":")))
                })
            };
            var f = e.description;
            return {
                type: e.type,
                title: SYNO.SDS.SystemInfoApp.RuleMappingUtil.getTitle(e.type),
                message: f.description_use_formatted ? String.format.apply(String, [_T.apply(void 0, _toConsumableArray(f.description_format.split(":")))].concat(_toConsumableArray(f.description_params))) : String.format.apply(String, [f.description_format].concat(_toConsumableArray(d(f.description_params))))
            }
        };
        var b = function b(d) {
            return SYNO.SDS.SystemInfoApp.RuleMappingUtil.parseApp(d)
        };
        return [b(c), a(c)]
    }
});
SYNO.SDS.SystemInfoApp.RuleMappingUtil = {
    TYPE_DANGER: 0,
    TYPE_ATTENTION: 1,
    TYPE_NORMAL: 2,
    parseApp: function parseApp(a) {
        switch (a.id) {
            case "syno_system_status_warning":
            case "external_volume":
            case "volume_usage":
            case "enclosure_status_abnormal":
            case "ebox_status_warning":
            case "storagemanager_overview_danger":
            case "storage_is_attention":
            case "temperature_warning":
            default:
                return {
                    appInstance: "SYNO.SDS.StorageManager.Instance", launchParam: {
                        fn: "SYNO.SDS.StorageManager.Pool.Main"
                    }
                };
            case "system_crashed_warning":
            case "disk_status_warning":
                return {
                    appInstance: "SYNO.SDS.StorageManager.Instance", launchParam: {
                        fn: "SYNO.SDS.StorageManager.Overview.Main",
                        skipFirstTime: true
                    }
                };
            case "disk_health_status_error":
                return {
                    appInstance: "SYNO.SDS.StorageManager.Instance", launchParam: {
                        fn: "SYNO.SDS.StorageManager.Disk.Main"
                    }
                };
            case "ups_status_abnormal":
                return {
                    appInstance: "SYNO.SDS.AdminCenter.Application", launchParam: {
                        fn: "SYNO.SDS.AdminCenter.HardwareControl.Main"
                    }
                };
            case "securityscan_status_danger":
                return {
                    appInstance: "SYNO.SDS.SecurityScan.Instance"
                };
            case "ha_status_warning":
                return {
                    appInstance: "SYNO.SDS.HA.Instance"
                };
            case "aha_status_warning":
                return {
                    appInstance: "SYNO.SDS.AHA.Instance"
                };
            case "system_health":
                return {
                    appInstance: "SYNO.SDS.AdminCenter.Application", launchParam: {
                        fn: "SYNO.SDS.AdminCenter.InfoCenter.Main"
                    }
                };
            case "san_status_warning":
                return {
                    appInstance: "SYNO.SDS.iSCSI.Application", launchParam: {
                        fn: "SYNO.SDS.iSCSI.MainWindow"
                    }
                }
        }
    },
    getDefaultStatus: function getDefaultStatus() {
        return {
            type: this.TYPE_NORMAL,
            title: _T("widget", "good_status"),
            message: _T("widget", "system_ok")
        }
    },
    getIcon: function getIcon(a) {
        switch (a) {
            case this.TYPE_DANGER:
                return "syno-sysinfo-system-health-west-emergency";
            case this.TYPE_ATTENTION:
                return "syno-sysinfo-system-health-west-warning";
            case this.TYPE_NORMAL:
            default:
                return "syno-sysinfo-system-health-west-normal"
        }
    },
    getContent: function getContent(a) {
        switch (a) {
            case this.TYPE_DANGER:
                return "syno-sysinfo-system-health-content-header-emergency red-status";
            case this.TYPE_ATTENTION:
                return "syno-sysinfo-system-health-content-header-warning";
            case this.TYPE_NORMAL:
            default:
                return "syno-sysinfo-system-health-content-header-normal"
        }
    },
    getTitle: function getTitle(a) {
        switch (a) {
            case this.TYPE_DANGER:
                return _T("widget", "danger_status");
            case this.TYPE_ATTENTION:
                return _T("widget", "attention_status");
            case this.TYPE_NORMAL:
            default:
                return _T("widget", "good_status")
        }
    }
};
