! function(t) {
    var e = {};

    function n(r) {
        if (e[r]) return e[r].exports;
        var s = e[r] = {
            i: r,
            l: !1,
            exports: {}
        };
        return t[r].call(s.exports, s, s.exports, n), s.l = !0, s.exports
    }
    n.m = t, n.c = e, n.d = function(t, e, r) {
        n.o(t, e) || Object.defineProperty(t, e, {
            enumerable: !0,
            get: r
        })
    }, n.r = function(t) {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(t, Symbol.toStringTag, {
            value: "Module"
        }), Object.defineProperty(t, "__esModule", {
            value: !0
        })
    }, n.t = function(t, e) {
        if (1 & e && (t = n(t)), 8 & e) return t;
        if (4 & e && "object" == typeof t && t && t.__esModule) return t;
        var r = Object.create(null);
        if (n.r(r), Object.defineProperty(r, "default", {
                enumerable: !0,
                value: t
            }), 2 & e && "string" != typeof t)
            for (var s in t) n.d(r, s, function(e) {
                return t[e]
            }.bind(null, s));
        return r
    }, n.n = function(t) {
        var e = t && t.__esModule ? function() {
            return t.default
        } : function() {
            return t
        };
        return n.d(e, "a", e), e
    }, n.o = function(t, e) {
        return Object.prototype.hasOwnProperty.call(t, e)
    }, n.p = "", n(n.s = 66)
}([function(t, e) {
    t.exports = Vuex
}, function(t, e, n) {
    var r = n(51),
        s = "object" == typeof self && self && self.Object === Object && self,
        i = r || s || Function("return this")();
    t.exports = i
}, function(t, e, n) {
    var r = n(104),
        s = n(110);
    t.exports = function(t, e) {
        var n = s(t, e);
        return r(n) ? n : void 0
    }
}, function(t, e) {
    t.exports = function(t) {
        var e = typeof t;
        return null != t && ("object" == e || "function" == e)
    }
}, function(t, e) {
    t.exports = function(t) {
        return null != t && "object" == typeof t
    }
}, function(t, e, n) {
    var r = n(94),
        s = n(95),
        i = n(96),
        a = n(97),
        o = n(98);

    function c(t) {
        var e = -1,
            n = null == t ? 0 : t.length;
        for (this.clear(); ++e < n;) {
            var r = t[e];
            this.set(r[0], r[1])
        }
    }
    c.prototype.clear = r, c.prototype.delete = s, c.prototype.get = i, c.prototype.has = a, c.prototype.set = o, t.exports = c
}, function(t, e, n) {
    var r = n(49);
    t.exports = function(t, e) {
        for (var n = t.length; n--;)
            if (r(t[n][0], e)) return n;
        return -1
    }
}, function(t, e, n) {
    var r = n(38),
        s = n(106),
        i = n(107),
        a = r ? r.toStringTag : void 0;
    t.exports = function(t) {
        return null == t ? void 0 === t ? "[object Undefined]" : "[object Null]" : a && a in Object(t) ? s(t) : i(t)
    }
}, function(t, e, n) {
    var r = n(2)(Object, "create");
    t.exports = r
}, function(t, e, n) {
    var r = n(120);
    t.exports = function(t, e) {
        var n = t.__data__;
        return r(e) ? n["string" == typeof e ? "string" : "hash"] : n.map
    }
}, function(t, e, n) {
    var r = n(53),
        s = n(54);
    t.exports = function(t, e, n, i) {
        var a = !n;
        n || (n = {});
        for (var o = -1, c = e.length; ++o < c;) {
            var l = e[o],
                u = i ? i(n[l], t[l], l, n, t) : void 0;
            void 0 === u && (u = t[l]), a ? s(n, l, u) : r(n, l, u)
        }
        return n
    }
}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {}, function(t, e, n) {
    var r = n(92);
    t.exports = function(t) {
        return r(t, 5)
    }
}, function(t, e, n) {
    var r = n(2)(n(1), "Map");
    t.exports = r
}, function(t, e, n) {
    var r = n(1).Symbol;
    t.exports = r
}, function(t, e, n) {
    var r = n(55),
        s = n(134),
        i = n(59);
    t.exports = function(t) {
        return i(t) ? r(t) : s(t)
    }
}, function(t, e) {
    var n = Array.isArray;
    t.exports = n
}, function(t, e) {
    t.exports = function(t) {
        return t.webpackPolyfill || (t.deprecate = function() {}, t.paths = [], t.children || (t.children = []), Object.defineProperty(t, "loaded", {
            enumerable: !0,
            get: function() {
                return t.l
            }
        }), Object.defineProperty(t, "id", {
            enumerable: !0,
            get: function() {
                return t.i
            }
        }), t.webpackPolyfill = 1), t
    }
}, function(t, e) {
    t.exports = function(t) {
        return function(e) {
            return t(e)
        }
    }
}, function(t, e, n) {
    (function(t) {
        var r = n(51),
            s = e && !e.nodeType && e,
            i = s && "object" == typeof t && t && !t.nodeType && t,
            a = i && i.exports === s && r.process,
            o = function() {
                try {
                    var t = i && i.require && i.require("util").types;
                    return t || a && a.binding && a.binding("util")
                } catch (t) {}
            }();
        t.exports = o
    }).call(this, n(41)(t))
}, function(t, e) {
    var n = Object.prototype;
    t.exports = function(t) {
        var e = t && t.constructor;
        return t === ("function" == typeof e && e.prototype || n)
    }
}, function(t, e, n) {
    var r = n(55),
        s = n(137),
        i = n(59);
    t.exports = function(t) {
        return i(t) ? r(t, !0) : s(t)
    }
}, function(t, e, n) {
    var r = n(142),
        s = n(60),
        i = Object.prototype.propertyIsEnumerable,
        a = Object.getOwnPropertySymbols,
        o = a ? function(t) {
            return null == t ? [] : (t = Object(t), r(a(t), (function(e) {
                return i.call(t, e)
            })))
        } : s;
    t.exports = o
}, function(t, e, n) {
    var r = n(146),
        s = n(37),
        i = n(147),
        a = n(148),
        o = n(149),
        c = n(7),
        l = n(52),
        u = l(r),
        p = l(s),
        d = l(i),
        f = l(a),
        m = l(o),
        h = c;
    (r && "[object DataView]" != h(new r(new ArrayBuffer(1))) || s && "[object Map]" != h(new s) || i && "[object Promise]" != h(i.resolve()) || a && "[object Set]" != h(new a) || o && "[object WeakMap]" != h(new o)) && (h = function(t) {
        var e = c(t),
            n = "[object Object]" == e ? t.constructor : void 0,
            r = n ? l(n) : "";
        if (r) switch (r) {
            case u:
                return "[object DataView]";
            case p:
                return "[object Map]";
            case d:
                return "[object Promise]";
            case f:
                return "[object Set]";
            case m:
                return "[object WeakMap]"
        }
        return e
    }), t.exports = h
}, function(t, e, n) {
    var r = n(152);
    t.exports = function(t) {
        var e = new t.constructor(t.byteLength);
        return new r(e).set(new r(t)), e
    }
}, function(t, e) {
    t.exports = function(t, e) {
        return t === e || t != t && e != e
    }
}, function(t, e, n) {
    var r = n(7),
        s = n(3);
    t.exports = function(t) {
        if (!s(t)) return !1;
        var e = r(t);
        return "[object Function]" == e || "[object GeneratorFunction]" == e || "[object AsyncFunction]" == e || "[object Proxy]" == e
    }
}, function(t, e, n) {
    (function(e) {
        var n = "object" == typeof e && e && e.Object === Object && e;
        t.exports = n
    }).call(this, n(105))
}, function(t, e) {
    var n = Function.prototype.toString;
    t.exports = function(t) {
        if (null != t) {
            try {
                return n.call(t)
            } catch (t) {}
            try {
                return t + ""
            } catch (t) {}
        }
        return ""
    }
}, function(t, e, n) {
    var r = n(54),
        s = n(49),
        i = Object.prototype.hasOwnProperty;
    t.exports = function(t, e, n) {
        var a = t[e];
        i.call(t, e) && s(a, n) && (void 0 !== n || e in t) || r(t, e, n)
    }
}, function(t, e, n) {
    var r = n(125);
    t.exports = function(t, e, n) {
        "__proto__" == e && r ? r(t, e, {
            configurable: !0,
            enumerable: !0,
            value: n,
            writable: !0
        }) : t[e] = n
    }
}, function(t, e, n) {
    var r = n(127),
        s = n(128),
        i = n(40),
        a = n(56),
        o = n(131),
        c = n(132),
        l = Object.prototype.hasOwnProperty;
    t.exports = function(t, e) {
        var n = i(t),
            u = !n && s(t),
            p = !n && !u && a(t),
            d = !n && !u && !p && c(t),
            f = n || u || p || d,
            m = f ? r(t.length, String) : [],
            h = m.length;
        for (var v in t) !e && !l.call(t, v) || f && ("length" == v || p && ("offset" == v || "parent" == v) || d && ("buffer" == v || "byteLength" == v || "byteOffset" == v) || o(v, h)) || m.push(v);
        return m
    }
}, function(t, e, n) {
    (function(t) {
        var r = n(1),
            s = n(130),
            i = e && !e.nodeType && e,
            a = i && "object" == typeof t && t && !t.nodeType && t,
            o = a && a.exports === i ? r.Buffer : void 0,
            c = (o ? o.isBuffer : void 0) || s;
        t.exports = c
    }).call(this, n(41)(t))
}, function(t, e) {
    t.exports = function(t) {
        return "number" == typeof t && t > -1 && t % 1 == 0 && t <= 9007199254740991
    }
}, function(t, e) {
    t.exports = function(t, e) {
        return function(n) {
            return t(e(n))
        }
    }
}, function(t, e, n) {
    var r = n(50),
        s = n(57);
    t.exports = function(t) {
        return null != t && s(t.length) && !r(t)
    }
}, function(t, e) {
    t.exports = function() {
        return []
    }
}, function(t, e, n) {
    var r = n(62),
        s = n(63),
        i = n(46),
        a = n(60),
        o = Object.getOwnPropertySymbols ? function(t) {
            for (var e = []; t;) r(e, i(t)), t = s(t);
            return e
        } : a;
    t.exports = o
}, function(t, e) {
    t.exports = function(t, e) {
        for (var n = -1, r = e.length, s = t.length; ++n < r;) t[s + n] = e[n];
        return t
    }
}, function(t, e, n) {
    var r = n(58)(Object.getPrototypeOf, Object);
    t.exports = r
}, function(t, e, n) {
    var r = n(62),
        s = n(40);
    t.exports = function(t, e, n) {
        var i = e(t);
        return s(t) ? i : r(i, n(t))
    }
}, function(t, e) {
    t.exports = Vue
}, function(t, e, n) {
    t.exports = n(164)
}, function(t, e, n) {
    "use strict";
    var r = n(11);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(12);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(13);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(14);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(15);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(16);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(17);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(18);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(19);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(20);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(21);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(22);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(23);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(24);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(25);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(26);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(27);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(28);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(29);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(30);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(31);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(32);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(33);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(34);
    n.n(r).a
}, function(t, e, n) {
    "use strict";
    var r = n(35);
    n.n(r).a
}, function(t, e, n) {
    var r = n(93),
        s = n(124),
        i = n(53),
        a = n(126),
        o = n(136),
        c = n(139),
        l = n(140),
        u = n(141),
        p = n(143),
        d = n(144),
        f = n(145),
        m = n(47),
        h = n(150),
        v = n(151),
        _ = n(157),
        g = n(40),
        b = n(56),
        y = n(159),
        w = n(3),
        S = n(161),
        x = n(39),
        k = n(45),
        T = {};
    T["[object Arguments]"] = T["[object Array]"] = T["[object ArrayBuffer]"] = T["[object DataView]"] = T["[object Boolean]"] = T["[object Date]"] = T["[object Float32Array]"] = T["[object Float64Array]"] = T["[object Int8Array]"] = T["[object Int16Array]"] = T["[object Int32Array]"] = T["[object Map]"] = T["[object Number]"] = T["[object Object]"] = T["[object RegExp]"] = T["[object Set]"] = T["[object String]"] = T["[object Symbol]"] = T["[object Uint8Array]"] = T["[object Uint8ClampedArray]"] = T["[object Uint16Array]"] = T["[object Uint32Array]"] = !0, T["[object Error]"] = T["[object Function]"] = T["[object WeakMap]"] = !1, t.exports = function t(e, n, D, O, P, C) {
        var A, j = 1 & n,
            N = 2 & n,
            E = 4 & n;
        if (D && (A = P ? D(e, O, P, C) : D(e)), void 0 !== A) return A;
        if (!w(e)) return e;
        var $ = g(e);
        if ($) {
            if (A = h(e), !j) return l(e, A)
        } else {
            var U = m(e),
                R = "[object Function]" == U || "[object GeneratorFunction]" == U;
            if (b(e)) return c(e, j);
            if ("[object Object]" == U || "[object Arguments]" == U || R && !P) {
                if (A = N || R ? {} : _(e), !j) return N ? p(e, o(A, e)) : u(e, a(A, e))
            } else {
                if (!T[U]) return P ? e : {};
                A = v(e, U, j)
            }
        }
        C || (C = new r);
        var M = C.get(e);
        if (M) return M;
        C.set(e, A), S(e) ? e.forEach((function(r) {
            A.add(t(r, n, D, r, e, C))
        })) : y(e) && e.forEach((function(r, s) {
            A.set(s, t(r, n, D, s, e, C))
        }));
        var Y = $ ? void 0 : (E ? N ? f : d : N ? k : x)(e);
        return s(Y || e, (function(r, s) {
            Y && (r = e[s = r]), i(A, s, t(r, n, D, s, e, C))
        })), A
    }
}, function(t, e, n) {
    var r = n(5),
        s = n(99),
        i = n(100),
        a = n(101),
        o = n(102),
        c = n(103);

    function l(t) {
        var e = this.__data__ = new r(t);
        this.size = e.size
    }
    l.prototype.clear = s, l.prototype.delete = i, l.prototype.get = a, l.prototype.has = o, l.prototype.set = c, t.exports = l
}, function(t, e) {
    t.exports = function() {
        this.__data__ = [], this.size = 0
    }
}, function(t, e, n) {
    var r = n(6),
        s = Array.prototype.splice;
    t.exports = function(t) {
        var e = this.__data__,
            n = r(e, t);
        return !(n < 0) && (n == e.length - 1 ? e.pop() : s.call(e, n, 1), --this.size, !0)
    }
}, function(t, e, n) {
    var r = n(6);
    t.exports = function(t) {
        var e = this.__data__,
            n = r(e, t);
        return n < 0 ? void 0 : e[n][1]
    }
}, function(t, e, n) {
    var r = n(6);
    t.exports = function(t) {
        return r(this.__data__, t) > -1
    }
}, function(t, e, n) {
    var r = n(6);
    t.exports = function(t, e) {
        var n = this.__data__,
            s = r(n, t);
        return s < 0 ? (++this.size, n.push([t, e])) : n[s][1] = e, this
    }
}, function(t, e, n) {
    var r = n(5);
    t.exports = function() {
        this.__data__ = new r, this.size = 0
    }
}, function(t, e) {
    t.exports = function(t) {
        var e = this.__data__,
            n = e.delete(t);
        return this.size = e.size, n
    }
}, function(t, e) {
    t.exports = function(t) {
        return this.__data__.get(t)
    }
}, function(t, e) {
    t.exports = function(t) {
        return this.__data__.has(t)
    }
}, function(t, e, n) {
    var r = n(5),
        s = n(37),
        i = n(111);
    t.exports = function(t, e) {
        var n = this.__data__;
        if (n instanceof r) {
            var a = n.__data__;
            if (!s || a.length < 199) return a.push([t, e]), this.size = ++n.size, this;
            n = this.__data__ = new i(a)
        }
        return n.set(t, e), this.size = n.size, this
    }
}, function(t, e, n) {
    var r = n(50),
        s = n(108),
        i = n(3),
        a = n(52),
        o = /^\[object .+?Constructor\]$/,
        c = Function.prototype,
        l = Object.prototype,
        u = c.toString,
        p = l.hasOwnProperty,
        d = RegExp("^" + u.call(p).replace(/[\\^$.*+?()[\]{}|]/g, "\\$&").replace(/hasOwnProperty|(function).*?(?=\\\()| for .+?(?=\\\])/g, "$1.*?") + "$");
    t.exports = function(t) {
        return !(!i(t) || s(t)) && (r(t) ? d : o).test(a(t))
    }
}, function(t, e) {
    var n;
    n = function() {
        return this
    }();
    try {
        n = n || new Function("return this")()
    } catch (t) {
        "object" == typeof window && (n = window)
    }
    t.exports = n
}, function(t, e, n) {
    var r = n(38),
        s = Object.prototype,
        i = s.hasOwnProperty,
        a = s.toString,
        o = r ? r.toStringTag : void 0;
    t.exports = function(t) {
        var e = i.call(t, o),
            n = t[o];
        try {
            t[o] = void 0;
            var r = !0
        } catch (t) {}
        var s = a.call(t);
        return r && (e ? t[o] = n : delete t[o]), s
    }
}, function(t, e) {
    var n = Object.prototype.toString;
    t.exports = function(t) {
        return n.call(t)
    }
}, function(t, e, n) {
    var r, s = n(109),
        i = (r = /[^.]+$/.exec(s && s.keys && s.keys.IE_PROTO || "")) ? "Symbol(src)_1." + r : "";
    t.exports = function(t) {
        return !!i && i in t
    }
}, function(t, e, n) {
    var r = n(1)["__core-js_shared__"];
    t.exports = r
}, function(t, e) {
    t.exports = function(t, e) {
        return null == t ? void 0 : t[e]
    }
}, function(t, e, n) {
    var r = n(112),
        s = n(119),
        i = n(121),
        a = n(122),
        o = n(123);

    function c(t) {
        var e = -1,
            n = null == t ? 0 : t.length;
        for (this.clear(); ++e < n;) {
            var r = t[e];
            this.set(r[0], r[1])
        }
    }
    c.prototype.clear = r, c.prototype.delete = s, c.prototype.get = i, c.prototype.has = a, c.prototype.set = o, t.exports = c
}, function(t, e, n) {
    var r = n(113),
        s = n(5),
        i = n(37);
    t.exports = function() {
        this.size = 0, this.__data__ = {
            hash: new r,
            map: new(i || s),
            string: new r
        }
    }
}, function(t, e, n) {
    var r = n(114),
        s = n(115),
        i = n(116),
        a = n(117),
        o = n(118);

    function c(t) {
        var e = -1,
            n = null == t ? 0 : t.length;
        for (this.clear(); ++e < n;) {
            var r = t[e];
            this.set(r[0], r[1])
        }
    }
    c.prototype.clear = r, c.prototype.delete = s, c.prototype.get = i, c.prototype.has = a, c.prototype.set = o, t.exports = c
}, function(t, e, n) {
    var r = n(8);
    t.exports = function() {
        this.__data__ = r ? r(null) : {}, this.size = 0
    }
}, function(t, e) {
    t.exports = function(t) {
        var e = this.has(t) && delete this.__data__[t];
        return this.size -= e ? 1 : 0, e
    }
}, function(t, e, n) {
    var r = n(8),
        s = Object.prototype.hasOwnProperty;
    t.exports = function(t) {
        var e = this.__data__;
        if (r) {
            var n = e[t];
            return "__lodash_hash_undefined__" === n ? void 0 : n
        }
        return s.call(e, t) ? e[t] : void 0
    }
}, function(t, e, n) {
    var r = n(8),
        s = Object.prototype.hasOwnProperty;
    t.exports = function(t) {
        var e = this.__data__;
        return r ? void 0 !== e[t] : s.call(e, t)
    }
}, function(t, e, n) {
    var r = n(8);
    t.exports = function(t, e) {
        var n = this.__data__;
        return this.size += this.has(t) ? 0 : 1, n[t] = r && void 0 === e ? "__lodash_hash_undefined__" : e, this
    }
}, function(t, e, n) {
    var r = n(9);
    t.exports = function(t) {
        var e = r(this, t).delete(t);
        return this.size -= e ? 1 : 0, e
    }
}, function(t, e) {
    t.exports = function(t) {
        var e = typeof t;
        return "string" == e || "number" == e || "symbol" == e || "boolean" == e ? "__proto__" !== t : null === t
    }
}, function(t, e, n) {
    var r = n(9);
    t.exports = function(t) {
        return r(this, t).get(t)
    }
}, function(t, e, n) {
    var r = n(9);
    t.exports = function(t) {
        return r(this, t).has(t)
    }
}, function(t, e, n) {
    var r = n(9);
    t.exports = function(t, e) {
        var n = r(this, t),
            s = n.size;
        return n.set(t, e), this.size += n.size == s ? 0 : 1, this
    }
}, function(t, e) {
    t.exports = function(t, e) {
        for (var n = -1, r = null == t ? 0 : t.length; ++n < r && !1 !== e(t[n], n, t););
        return t
    }
}, function(t, e, n) {
    var r = n(2),
        s = function() {
            try {
                var t = r(Object, "defineProperty");
                return t({}, "", {}), t
            } catch (t) {}
        }();
    t.exports = s
}, function(t, e, n) {
    var r = n(10),
        s = n(39);
    t.exports = function(t, e) {
        return t && r(e, s(e), t)
    }
}, function(t, e) {
    t.exports = function(t, e) {
        for (var n = -1, r = Array(t); ++n < t;) r[n] = e(n);
        return r
    }
}, function(t, e, n) {
    var r = n(129),
        s = n(4),
        i = Object.prototype,
        a = i.hasOwnProperty,
        o = i.propertyIsEnumerable,
        c = r(function() {
            return arguments
        }()) ? r : function(t) {
            return s(t) && a.call(t, "callee") && !o.call(t, "callee")
        };
    t.exports = c
}, function(t, e, n) {
    var r = n(7),
        s = n(4);
    t.exports = function(t) {
        return s(t) && "[object Arguments]" == r(t)
    }
}, function(t, e) {
    t.exports = function() {
        return !1
    }
}, function(t, e) {
    var n = /^(?:0|[1-9]\d*)$/;
    t.exports = function(t, e) {
        var r = typeof t;
        return !!(e = null == e ? 9007199254740991 : e) && ("number" == r || "symbol" != r && n.test(t)) && t > -1 && t % 1 == 0 && t < e
    }
}, function(t, e, n) {
    var r = n(133),
        s = n(42),
        i = n(43),
        a = i && i.isTypedArray,
        o = a ? s(a) : r;
    t.exports = o
}, function(t, e, n) {
    var r = n(7),
        s = n(57),
        i = n(4),
        a = {};
    a["[object Float32Array]"] = a["[object Float64Array]"] = a["[object Int8Array]"] = a["[object Int16Array]"] = a["[object Int32Array]"] = a["[object Uint8Array]"] = a["[object Uint8ClampedArray]"] = a["[object Uint16Array]"] = a["[object Uint32Array]"] = !0, a["[object Arguments]"] = a["[object Array]"] = a["[object ArrayBuffer]"] = a["[object Boolean]"] = a["[object DataView]"] = a["[object Date]"] = a["[object Error]"] = a["[object Function]"] = a["[object Map]"] = a["[object Number]"] = a["[object Object]"] = a["[object RegExp]"] = a["[object Set]"] = a["[object String]"] = a["[object WeakMap]"] = !1, t.exports = function(t) {
        return i(t) && s(t.length) && !!a[r(t)]
    }
}, function(t, e, n) {
    var r = n(44),
        s = n(135),
        i = Object.prototype.hasOwnProperty;
    t.exports = function(t) {
        if (!r(t)) return s(t);
        var e = [];
        for (var n in Object(t)) i.call(t, n) && "constructor" != n && e.push(n);
        return e
    }
}, function(t, e, n) {
    var r = n(58)(Object.keys, Object);
    t.exports = r
}, function(t, e, n) {
    var r = n(10),
        s = n(45);
    t.exports = function(t, e) {
        return t && r(e, s(e), t)
    }
}, function(t, e, n) {
    var r = n(3),
        s = n(44),
        i = n(138),
        a = Object.prototype.hasOwnProperty;
    t.exports = function(t) {
        if (!r(t)) return i(t);
        var e = s(t),
            n = [];
        for (var o in t)("constructor" != o || !e && a.call(t, o)) && n.push(o);
        return n
    }
}, function(t, e) {
    t.exports = function(t) {
        var e = [];
        if (null != t)
            for (var n in Object(t)) e.push(n);
        return e
    }
}, function(t, e, n) {
    (function(t) {
        var r = n(1),
            s = e && !e.nodeType && e,
            i = s && "object" == typeof t && t && !t.nodeType && t,
            a = i && i.exports === s ? r.Buffer : void 0,
            o = a ? a.allocUnsafe : void 0;
        t.exports = function(t, e) {
            if (e) return t.slice();
            var n = t.length,
                r = o ? o(n) : new t.constructor(n);
            return t.copy(r), r
        }
    }).call(this, n(41)(t))
}, function(t, e) {
    t.exports = function(t, e) {
        var n = -1,
            r = t.length;
        for (e || (e = Array(r)); ++n < r;) e[n] = t[n];
        return e
    }
}, function(t, e, n) {
    var r = n(10),
        s = n(46);
    t.exports = function(t, e) {
        return r(t, s(t), e)
    }
}, function(t, e) {
    t.exports = function(t, e) {
        for (var n = -1, r = null == t ? 0 : t.length, s = 0, i = []; ++n < r;) {
            var a = t[n];
            e(a, n, t) && (i[s++] = a)
        }
        return i
    }
}, function(t, e, n) {
    var r = n(10),
        s = n(61);
    t.exports = function(t, e) {
        return r(t, s(t), e)
    }
}, function(t, e, n) {
    var r = n(64),
        s = n(46),
        i = n(39);
    t.exports = function(t) {
        return r(t, i, s)
    }
}, function(t, e, n) {
    var r = n(64),
        s = n(61),
        i = n(45);
    t.exports = function(t) {
        return r(t, i, s)
    }
}, function(t, e, n) {
    var r = n(2)(n(1), "DataView");
    t.exports = r
}, function(t, e, n) {
    var r = n(2)(n(1), "Promise");
    t.exports = r
}, function(t, e, n) {
    var r = n(2)(n(1), "Set");
    t.exports = r
}, function(t, e, n) {
    var r = n(2)(n(1), "WeakMap");
    t.exports = r
}, function(t, e) {
    var n = Object.prototype.hasOwnProperty;
    t.exports = function(t) {
        var e = t.length,
            r = new t.constructor(e);
        return e && "string" == typeof t[0] && n.call(t, "index") && (r.index = t.index, r.input = t.input), r
    }
}, function(t, e, n) {
    var r = n(48),
        s = n(153),
        i = n(154),
        a = n(155),
        o = n(156);
    t.exports = function(t, e, n) {
        var c = t.constructor;
        switch (e) {
            case "[object ArrayBuffer]":
                return r(t);
            case "[object Boolean]":
            case "[object Date]":
                return new c(+t);
            case "[object DataView]":
                return s(t, n);
            case "[object Float32Array]":
            case "[object Float64Array]":
            case "[object Int8Array]":
            case "[object Int16Array]":
            case "[object Int32Array]":
            case "[object Uint8Array]":
            case "[object Uint8ClampedArray]":
            case "[object Uint16Array]":
            case "[object Uint32Array]":
                return o(t, n);
            case "[object Map]":
                return new c;
            case "[object Number]":
            case "[object String]":
                return new c(t);
            case "[object RegExp]":
                return i(t);
            case "[object Set]":
                return new c;
            case "[object Symbol]":
                return a(t)
        }
    }
}, function(t, e, n) {
    var r = n(1).Uint8Array;
    t.exports = r
}, function(t, e, n) {
    var r = n(48);
    t.exports = function(t, e) {
        var n = e ? r(t.buffer) : t.buffer;
        return new t.constructor(n, t.byteOffset, t.byteLength)
    }
}, function(t, e) {
    var n = /\w*$/;
    t.exports = function(t) {
        var e = new t.constructor(t.source, n.exec(t));
        return e.lastIndex = t.lastIndex, e
    }
}, function(t, e, n) {
    var r = n(38),
        s = r ? r.prototype : void 0,
        i = s ? s.valueOf : void 0;
    t.exports = function(t) {
        return i ? Object(i.call(t)) : {}
    }
}, function(t, e, n) {
    var r = n(48);
    t.exports = function(t, e) {
        var n = e ? r(t.buffer) : t.buffer;
        return new t.constructor(n, t.byteOffset, t.length)
    }
}, function(t, e, n) {
    var r = n(158),
        s = n(63),
        i = n(44);
    t.exports = function(t) {
        return "function" != typeof t.constructor || i(t) ? {} : r(s(t))
    }
}, function(t, e, n) {
    var r = n(3),
        s = Object.create,
        i = function() {
            function t() {}
            return function(e) {
                if (!r(e)) return {};
                if (s) return s(e);
                t.prototype = e;
                var n = new t;
                return t.prototype = void 0, n
            }
        }();
    t.exports = i
}, function(t, e, n) {
    var r = n(160),
        s = n(42),
        i = n(43),
        a = i && i.isMap,
        o = a ? s(a) : r;
    t.exports = o
}, function(t, e, n) {
    var r = n(47),
        s = n(4);
    t.exports = function(t) {
        return s(t) && "[object Map]" == r(t)
    }
}, function(t, e, n) {
    var r = n(162),
        s = n(42),
        i = n(43),
        a = i && i.isSet,
        o = a ? s(a) : r;
    t.exports = o
}, function(t, e, n) {
    var r = n(47),
        s = n(4);
    t.exports = function(t) {
        return s(t) && "[object Set]" == r(t)
    }
}, function(t, e, n) {}, function(t, e, n) {
    "use strict";
    n.r(e);
    var r = function() {
        var t = this,
            e = t.$createElement,
            n = t._self._c || e;
        return n("v-app-instance", {
            attrs: {
                "syno-id": "personal-settings-app-instance",
                "class-name": "SYNO.SDS.App.PersonalSettings.Instance"
            },
            on: {
                openparamchanged: t.handleParams
            }
        }, [n("v-app-window", {
            ref: "appWindow",
            staticClass: "sds-personal-settings-window",
            attrs: {
                "syno-id": "personal-settings-app-window",
                width: "850",
                height: "574",
                resizable: !1,
                "before-close": t.beforeClose,
                "help-params": t.helpParams,
                "window-name": "SYNO.SDS.App.PersonalSettings.AppWindow"
            }
        }, [n("div", {
            staticClass: "syno-sds-personal"
        }, [n("v-tabs", {
            staticClass: "syno-sds-personal-tabs",
            attrs: {
                "syno-id": "src-app-tabs-0",
                "active-tab-key": t.tabKey,
                id: "tabs",
                "has-fbar": !0
            },
            on: {
                change: t.onTabChange,
                cancel: t.onCancel,
                confirm: t.onConfirm
            }
        }, [n("v-tab-pane", {
            attrs: {
                "syno-id": "src-app-tab-pane-0",
                "tab-key": "account",
                tab: t.T("tree", "leaf_account")
            }
        }, [n("account-page", {
            ref: "account",
            on: {
                loading: t.onLoading
            }
        })], 1), t._v(" "), n("v-tab-pane", {
            attrs: {
                "syno-id": "src-app-tab-pane-1",
                "tab-key": "display-preferences",
                tab: t.T("personal_settings", "display_preferences")
            }
        }, [n("display-preferences-page", {
            ref: "display-preferences"
        })], 1), t._v(" "), n("v-tab-pane", {
            staticClass: "email-tab",
            attrs: {
                "syno-id": "src-app-tab-pane-2",
                "tab-key": "email",
                tab: t.T("mail", "mail_delivery")
            }
        }, [n("email-page", {
            ref: "email"
        })], 1), t._v(" "), t.supportQuota ? n("v-tab-pane", {
            attrs: {
                "syno-id": "src-app-tab-pane-3",
                "tab-key": "quota",
                tab: t.T("user", "user_quota_capacity")
            }
        }, [n("quota-page", {
            ref: "quota"
        })], 1) : t._e(), t._v(" "), n("v-tab-pane", {
            attrs: {
                "syno-id": "src-app-tab-pane-4",
                "tab-key": "others",
                tab: t.T("helptoc", "personal_others")
            }
        }, [n("other-page", {
            ref: "others"
        })], 1)], 1)], 1)])], 1)
    };
    r._withStripped = !0;
    var s = function() {
        var t = this,
            e = t.$createElement,
            n = t._self._c || e;
        return n("div", {
            staticClass: "account-page"
        }, [n("v-perfect-scrollbar", {
            ref: "scrollbar"
        }, [n("v-form", {
            ref: "form",
            attrs: {
                "syno-id": "pages-account-page-form-0",
                model: t.user,
                rules: t.rules
            }
        }, [n("div", {
            staticClass: "fieldset-body"
        }, [n("v-form-item", {
            staticClass: "account-form-item",
            attrs: {
                label: t.T("user", "user_account") + ":",
                prop: "username"
            }
        }, [n("span", {
            staticClass: "account-name"
        }, [t._v(t._s(t.user.username))]), t._v(" "), t.smartBlockEnabled ? n("a", {
            staticClass: "protection",
            on: {
                click: function(e) {
                    return e.preventDefault(), t.onClickAccountProtection(e)
                }
            }
        }, [t._v(" (" + t._s(t.T("tree", "leaf_smartblock")) + ")")]) : t._e()]), t._v(" "), n("v-form-item", {
            attrs: {
                label: t.T("user", "user_fullname") + ":",
                prop: "fullname"
            }
        }, [n("v-input", {
            attrs: {
                "syno-id": "pages-account-page-input-0",
                name: "fullname",
                placeholder: "",
                disabled: t.isFullNameDisabled,
                maxlength: 63
            },
            model: {
                value: t.user.fullname,
                callback: function(e) {
                    t.$set(t.user, "fullname", e)
                },
                expression: "user.fullname"
            }
        })], 1), t._v(" "), n("v-form-item", {
            attrs: {
                label: t.T("user", "user_email") + ":",
                prop: "email"
            }
        }, [n("v-input", {
            attrs: {
                "syno-id": "pages-account-page-input-1",
                name: "email",
                placeholder: "",
                disabled: t.isEmailDisabled
            },
            model: {
                value: t.user.email,
                callback: function(e) {
                    t.$set(t.user, "email", e)
                },
                expression: "user.email"
            }
        }), t._v(" "), n("v-whitetip", {
            attrs: {
                slot: "after",
                content: t.T("user", "email_desc")
            },
            slot: "after"
        })], 1), t._v(" "), n("v-form-item", {
            attrs: {
                label: t.T("language", "lang_display_field"),
                prop: "combobox"
            }
        }, [n("lang-select", {
            model: {
                value: t.user.lang,
                callback: function(e) {
                    t.$set(t.user, "lang", e)
                },
                expression: "user.lang"
            }
        })], 1), t._v(" "), n("div", {
            staticClass: "display"
        }, [t._v("\n\t\t\t\t\t" + t._s(t.T("personal_settings", "watch_current_login_status")) + "\n\t\t\t\t")]), t._v(" "), n("v-button", {
            attrs: {
                "syno-id": "pages-account-page-button-0"
            },
            on: {
                click: t.onClickAccountActivity
            }
        }, [t._v("\n\t\t\t\t\t" + t._s(t.T("personal_settings", "current_login_status")) + "\n\t\t\t\t")])], 1), t._v(" "), n("v-fieldset", {
            staticClass: "password-field-set",
            attrs: {
                title: t.passwordFieldSet,
                collapsible: !1
            }
        }, [n("div", {
            staticClass: "display"
        }, [t._v("\n\t\t\t\t\t" + t._s(t.signinDescription) + "\n\t\t\t\t")]), t._v(" "), n("div", {
            staticClass: "password-field"
        }, [n("div", {
            staticClass: "label text inline"
        }, [t._v("\n\t\t\t\t\t\t" + t._s(t.passwordLabel) + ":\n\t\t\t\t\t")]), t._v(" "), n("div", {
            staticClass: "last-changed-desc text inline",
            domProps: {
                innerHTML: t._s(t.passwordLastChangeLocale)
            }
        }), t._v(" "), n("v-button", {
            staticClass: "btn",
            attrs: {
                "syno-id": "pages-account-page-button-1",
                disabled: t.isPasswordDisabled
            },
            on: {
                click: t.onClickChangePassword
            }
        }, [t._v("\n\t\t\t\t\t\t" + t._s(t.changePasswordText) + "\n\t\t\t\t\t")])], 1)]), t._v(" "), n("v-fieldset", {
            ref: "advance_signin_method",
            staticClass: "signin-field-set",
            attrs: {
                title: t.signinFieldSet,
                collapsible: !1
            }
        }, [n("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: !t.isSecureSigninEnabled,
                expression: "!isSecureSigninEnabled"
            }],
            staticClass: "secure-signin-empty",
            domProps: {
                innerHTML: t._s(t.secureSigninDisabledText)
            }
        })])], 1)], 1)], 1)
    };
    s._withStripped = !0;
    var i = {
        methods: {
            T: function(t, e) {
                var n = _T(t, e);
                return n && "" !== n ? n : "".concat(t, ":").concat(e)
            }
        }
    };
    var a = {
            mounted: function() {
                this.$parent.$options.appWindow ? this.$options.appWindow = this.$parent.$options.appWindow : this.$options.appWindow = function t(e) {
                    return e ? e.$refs.appWindow ? e.$refs.appWindow : t(e.$parent) : null
                }(this.$parent)
            }
        },
        o = n(0),
        c = n.n(o),
        l = function() {
            var t = this,
                e = t.$createElement;
            return (t._self._c || e)("v-select", {
                attrs: {
                    "syno-id": "components-lang-select-select-0",
                    readonly: "",
                    width: 270,
                    name: "lang-select",
                    options: t.allLang
                },
                model: {
                    value: t.model,
                    callback: function(e) {
                        t.model = e
                    },
                    expression: "model"
                }
            })
        };

    function u(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            })))), r.forEach((function(e) {
                p(t, e, n[e])
            }))
        }
        return t
    }

    function p(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }

    function d(t, e, n, r, s, i, a, o) {
        var c, l = "function" == typeof t ? t.options : t;
        if (e && (l.render = e, l.staticRenderFns = n, l._compiled = !0), r && (l.functional = !0), i && (l._scopeId = "data-v-" + i), a ? (c = function(t) {
                (t = t || this.$vnode && this.$vnode.ssrContext || this.parent && this.parent.$vnode && this.parent.$vnode.ssrContext) || "undefined" == typeof __VUE_SSR_CONTEXT__ || (t = __VUE_SSR_CONTEXT__), s && s.call(this, t), t && t._registeredComponents && t._registeredComponents.add(a)
            }, l._ssrRegister = c) : s && (c = o ? function() {
                s.call(this, (l.functional ? this.parent : this).$root.$options.shadowRoot)
            } : s), c)
            if (l.functional) {
                l._injectStyles = c;
                var u = l.render;
                l.render = function(t, e) {
                    return c.call(e), u(t, e)
                }
            } else {
                var p = l.beforeCreate;
                l.beforeCreate = p ? [].concat(p, c) : [c]
            } return {
            exports: t,
            options: l
        }
    }
    l._withStripped = !0;
    var f = d({
        model: {
            prop: "lang",
            event: "input"
        },
        props: {
            lang: {
                type: String,
                default: "def"
            }
        },
        data: function() {
            return {}
        },
        mounted: function() {
            this.listLangs()
        },
        computed: u({}, Object(o.mapState)("LangModule", ["allLang"]), {
            model: {
                set: function(t) {
                    this.$emit("input", t)
                },
                get: function() {
                    return this.lang
                }
            }
        }),
        methods: u({}, Object(o.mapActions)("LangModule", ["listLangs"]))
    }, l, [], !1, null, null, null);
    f.options.__file = "src/components/lang-select.vue";
    var m = f.exports;

    function h(t) {
        return t = t || {},
            function(e, n, r) {
                if (!t.required && "" === n) return !0;
                return !!/^[a-zA-Z0-9!#$%&'*+\-/=?^_`{|}~."\\,()<>]+@([a-zA-Z0-9_&%!#+\-.]+)$/.test(n) || new Error(_JSLIBSTR("vtype", "bad_email"))
            }
    }

    function v(t, e, n, r, s, i, a) {
        try {
            var o = t[i](a),
                c = o.value
        } catch (t) {
            return void n(t)
        }
        o.done ? e(c) : Promise.resolve(c).then(r, s)
    }

    function _(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise((function(r, s) {
                var i = t.apply(e, n);

                function a(t) {
                    v(i, r, s, a, o, "next", t)
                }

                function o(t) {
                    v(i, r, s, a, o, "throw", t)
                }
                a(void 0)
            }))
        }
    }

    function g(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            })))), r.forEach((function(e) {
                b(t, e, n[e])
            }))
        }
        return t
    }

    function b(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }
    var y, w, S, x = {
            mixins: [i, a],
            data: function() {
                return {
                    fields: {},
                    rules: {
                        email: {
                            validator: h()
                        }
                    },
                    saAvailable: !1,
                    secureSigninDisabledText: _S("is_admin") ? String.format(this.T("secure_signin", "service_disabled_note_admin"), '<a class="link-font empty-text-link" href="#">', "</a>") : this.T("secure_signin", "service_disabled_note_user")
                }
            },
            computed: g({}, Object(o.mapState)("UserModule", ["user", "passwordLastChangeLocale", "hasEmail", "isLDAP", "isDomain"]), Object(o.mapState)("SmartBlockModule", {
                smartBlockEnabled: "enabled"
            }), {
                isSecureSigninEnabled: function() {
                    return SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.SecureSignIn.Instance")
                },
                isPasswordDisabled: function() {
                    return !!this.user.disallowchpasswd || !this.isDomain && !this.user.editable
                },
                isEmailDisabled: function() {
                    return !this.user.editable || this.isLDAP
                },
                isFullNameDisabled: function() {
                    return !this.user.editable || this.isLDAP
                },
                passwordFieldSet: function() {
                    return this.T("common", "password")
                },
                signinFieldSet: function() {
                    return this.T("personal_settings", "sign_in_method")
                },
                signinDescription: function() {
                    return this.T("personal_settings", "protect_password_desc")
                },
                changePasswordText: function() {
                    return this.T("personal_settings", "change_password")
                },
                passwordLabel: function() {
                    return this.T("user", "user_passwd")
                }
            }),
            mounted: (S = _(regeneratorRuntime.mark((function t() {
                var e, n = this;
                return regeneratorRuntime.wrap((function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return this.$emit("loading", !0), this.getAccountType(), t.prev = 2, t.next = 5, Promise.all([this.getUser(), this.getSmartBlockEnabledStatus()]);
                        case 5:
                            t.next = 11;
                            break;
                        case 7:
                            t.prev = 7, t.t0 = t.catch(2), e = String.format(this.T("error", "error_load_system_settings"), '<a href="https://www.synology.com/company/contact_us" target="_blank">', "</a>"), this.$options.appWindow.getMsgBox().alert("", e);
                        case 11:
                            this.$emit("loading", !1), this.isSecureSigninEnabled ? SYNO.SDS.JSLoader.JSLoadFn("SYNO.SDS.SecureSignIn.Instance").then((function() {
                                var t = new SYNO.SDS.SecureSignIn.AdvanceSigninMethod({
                                    propsData: {
                                        appWindow: n.$options.appWindow
                                    }
                                });
                                t.$mount(), t.$on("loading", (function(t) {
                                    n.$emit("loading", t)
                                })), n.$refs.advance_signin_method.$refs.body.appendChild(t.$el)
                            })) : this.$el.getElementsByClassName("empty-text-link").forEach((function(t) {
                                t.addEventListener("click", (function(t) {
                                    t.stopPropagation(), SYNO.SDS.AppLaunch("SYNO.SDS.PkgManApp.Instance", {
                                        action: "open",
                                        packages: ["SecureSignIn"]
                                    })
                                }))
                            }));
                        case 13:
                        case "end":
                            return t.stop()
                    }
                }), t, this, [
                    [2, 7]
                ])
            }))), function() {
                return S.apply(this, arguments)
            }),
            methods: g({}, Object(o.mapActions)("UserModule", ["getUser", "getAccountType", "applyUser", "getMailAccount"]), Object(o.mapActions)("SmartBlockModule", ["getSmartBlockEnabledStatus"]), Object(o.mapActions)("ActionModule", ["refreshEmail"]), {
                updateScrollbar: function() {
                    this.$refs.scrollbar.update()
                },
                onClickChangePassword: (w = _(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                this.$options.appWindow.openModalWindow(SYNO.SDS.App.PersonalSettings.Vue.ChangePassword);
                            case 1:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return w.apply(this, arguments)
                }),
                onClickAccountActivity: function() {
                    this.$options.appWindow.openModalWindow(SYNO.SDS.App.PersonalSettings.Vue.AccountActivity)
                },
                onClickAccountProtection: function() {
                    this.$options.appWindow.openModalWindow(SYNO.SDS.App.PersonalSettings.Vue.AccountProtectionDialog)
                },
                applyForm: (y = _(regeneratorRuntime.mark((function t() {
                    var e, n;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (e = !1, n = !0, !this.$refs.form) {
                                    t.next = 6;
                                    break
                                }
                                return t.next = 5, this.$refs.form.validate();
                            case 5:
                                n = t.sent;
                            case 6:
                                if (!n) {
                                    t.next = 11;
                                    break
                                }
                                return t.next = 9, this.applyUser({
                                    disableOTP: e
                                });
                            case 9:
                                t.next = 12;
                                break;
                            case 11:
                                throw new Error(this.T("common", "forminvalid"));
                            case 12:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return y.apply(this, arguments)
                })
            }),
            components: {
                LangSelect: m
            }
        },
        k = (n(67), n(68), d(x, s, [], !1, null, "38230d33", null));
    k.options.__file = "src/pages/account-page.vue";
    var T = k.exports,
        D = function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("div", {
                staticClass: "display-preferences-page"
            }, [n("v-form", {
                ref: "form",
                attrs: {
                    "syno-id": "pages-display-preferences-page-form-0"
                }
            }, [n("v-fieldset", {
                staticClass: "first",
                attrs: {
                    title: t.T("personal_settings", "date_and_time"),
                    collapsible: !1
                }
            }, [n("v-form-item", {
                attrs: {
                    label: t.T("personal_settings", "date_format")
                }
            }, [n("date-select", {
                model: {
                    value: t.date_format,
                    callback: function(e) {
                        t.date_format = e
                    },
                    expression: "date_format"
                }
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    label: t.T("personal_settings", "time_format")
                }
            }, [n("time-select", {
                model: {
                    value: t.time_format,
                    callback: function(e) {
                        t.time_format = e
                    },
                    expression: "time_format"
                }
            })], 1)], 1), t._v(" "), n("v-fieldset", {
                attrs: {
                    title: t.T("personal_settings", "desktop"),
                    collapsible: !1
                }
            }, [n("v-form-item", {
                attrs: {
                    label: t.T("personal_settings", "menu_style")
                }
            }, [n("v-select", {
                attrs: {
                    "syno-id": "pages-display-preferences-page-select-0",
                    readonly: "",
                    width: 270,
                    name: "menu-style-select",
                    options: t.menuStyle
                },
                model: {
                    value: t.preferences.menu_style,
                    callback: function(e) {
                        t.$set(t.preferences, "menu_style", e)
                    },
                    expression: "preferences.menu_style"
                }
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    label: t.T("personal_settings", "classical_desktop")
                }
            }, [n("v-select", {
                attrs: {
                    "syno-id": "pages-display-preferences-page-select-1",
                    readonly: "",
                    width: 270,
                    name: "icon-size-select",
                    options: t.iconSize
                },
                model: {
                    value: t.preferences.icon_size,
                    callback: function(e) {
                        t.$set(t.preferences, "icon_size", e)
                    },
                    expression: "preferences.icon_size"
                }
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    label: t.T("personal_settings", "text_color")
                }
            }, [n("v-color-picker", {
                attrs: {
                    "syno-id": "pages-display-preferences-page-color-picker-0",
                    "custom-options": t.customize_colors
                },
                on: {
                    showcustom: function(e) {
                        t.showCustomColorPanel = !0, t.customColorPanel = "text"
                    }
                },
                model: {
                    value: t.preferences.wallpaper.text_color,
                    callback: function(e) {
                        t.$set(t.preferences.wallpaper, "text_color", e)
                    },
                    expression: "preferences.wallpaper.text_color"
                }
            })], 1), t._v(" "), t.showCustomColorPanel ? n("v-modal-window", t._b({
                ref: "customColorWindow",
                attrs: {
                    "syno-id": "pages-display-preferences-page-modal-window-0",
                    inline: ""
                }
            }, "v-modal-window", t.colorWindowConfig, !1), [n("v-color-custom-panel", {
                attrs: {
                    "syno-id": "pages-display-preferences-page-color-custom-panel-0",
                    initial: t.customColorPanelInitalValue
                },
                on: {
                    colorselected: t.colorChanged,
                    colorselectcanceled: t.closeCustomColorWindow
                }
            })], 1) : t._e(), t._v(" "), n("v-form-item", {
                attrs: {
                    "hide-label": ""
                }
            }, [n("v-checkbox", {
                attrs: {
                    "syno-id": "pages-display-preferences-page-checkbox-0"
                },
                model: {
                    value: t.preferences.wallpaper.customize_background,
                    callback: function(e) {
                        t.$set(t.preferences.wallpaper, "customize_background", e)
                    },
                    expression: "preferences.wallpaper.customize_background"
                }
            }, [t._v("\n\t\t\t\t\t\t" + t._s(t.T("personal_settings", "customize_background")) + "\n\t\t\t\t\t")])], 1), t._v(" "), n("div", {
                staticClass: "wallpaper-block",
                class: {
                    disabled: !t.preferences.wallpaper.customize_background
                }
            }, [n("thumbnail", {
                staticClass: "thumbnail",
                attrs: {
                    disabled: t.customizeDisable,
                    "display-type": t.preferences.wallpaper.customize_background_type,
                    "bg-image-pos": t.preferences.wallpaper.wallpaper_position,
                    "bg-image-url": t.thumbnailUrl,
                    "is_thumbnail-bg-image": t.isThumbnailBgImage,
                    "bg-color": t.preferences.wallpaper.background_color,
                    "empty-wallpaper": t.emptyWallpaper
                }
            }), t._v(" "), n("div", {
                staticClass: "right-side-info"
            }, [n("v-form-item", {
                attrs: {
                    "hide-label": ""
                }
            }, [n("v-select", {
                attrs: {
                    "syno-id": "pages-display-preferences-page-select-2",
                    disabled: t.customizeDisable,
                    readonly: "",
                    width: 270,
                    name: "icon-size-select",
                    options: t.customType
                },
                model: {
                    value: t.preferences.wallpaper.customize_background_type,
                    callback: function(e) {
                        t.$set(t.preferences.wallpaper, "customize_background_type", e)
                    },
                    expression: "preferences.wallpaper.customize_background_type"
                }
            })], 1), t._v(" "), "image" === t.preferences.wallpaper.customize_background_type ? n("div", {
                staticClass: "info-block image"
            }, [n("v-form-item", {
                attrs: {
                    "hide-label": ""
                }
            }, [n("v-button", {
                attrs: {
                    "syno-id": "pages-display-preferences-page-button-0",
                    disabled: t.customizeDisable
                },
                on: {
                    click: t.onSelectWallpaper
                }
            }, [t._v("\n\t\t\t\t\t\t\t\t\t" + t._s(t.T("personal_settings", "select_image")) + "\n\t\t\t\t\t\t\t\t")])], 1), t._v(" "), n("v-form-multiple-item", {
                attrs: {
                    "hide-label": ""
                }
            }, [n("v-form-item", {
                attrs: {
                    "hide-label": ""
                }
            }, [n("v-select", {
                attrs: {
                    "syno-id": "pages-display-preferences-page-select-3",
                    disabled: t.customizeDisable,
                    readonly: "",
                    width: 270,
                    name: "wallpaper-pos-select",
                    options: t.wallpaperPos
                },
                model: {
                    value: t.preferences.wallpaper.wallpaper_position,
                    callback: function(e) {
                        t.$set(t.preferences.wallpaper, "wallpaper_position", e)
                    },
                    expression: "preferences.wallpaper.wallpaper_position"
                }
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    "hide-label": ""
                }
            }, [n("v-color-picker", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: t.isFitOrCenter,
                    expression: "isFitOrCenter"
                }],
                attrs: {
                    "syno-id": "pages-display-preferences-page-color-picker-1",
                    disabled: t.customizeDisable,
                    readonly: "",
                    width: 270,
                    initial: t.preferences.wallpaper.background_color,
                    "custom-options": t.customize_colors
                },
                on: {
                    showcustom: function(e) {
                        t.showCustomColorPanel = !0, t.customColorPanel = "background"
                    }
                },
                model: {
                    value: t.preferences.wallpaper.background_color,
                    callback: function(e) {
                        t.$set(t.preferences.wallpaper, "background_color", e)
                    },
                    expression: "preferences.wallpaper.background_color"
                }
            })], 1)], 1)], 1) : n("div", {
                staticClass: "info-block color"
            }, [n("v-form-item", {
                attrs: {
                    "hide-label": ""
                }
            }, [n("v-color-picker", {
                attrs: {
                    "syno-id": "pages-display-preferences-page-color-picker-2",
                    disabled: t.customizeDisable,
                    readonly: "",
                    width: 270,
                    initial: t.preferences.wallpaper.background_color,
                    "custom-options": t.customize_colors
                },
                on: {
                    showcustom: function(e) {
                        t.showCustomColorPanel = !0, t.customColorPanel = "background"
                    }
                },
                model: {
                    value: t.preferences.wallpaper.background_color,
                    callback: function(e) {
                        t.$set(t.preferences.wallpaper, "background_color", e)
                    },
                    expression: "preferences.wallpaper.background_color"
                }
            })], 1)], 1)], 1)], 1)], 1)], 1)], 1)
        };
    D._withStripped = !0;
    var O = function() {
        var t = this,
            e = t.$createElement,
            n = t._self._c || e;
        return n("div", {
            ref: "wrapper",
            staticClass: "personal-settings-thumbnail",
            class: {
                disabled: t.disabled
            },
            style: {
                backgroundColor: t.bgColor
            }
        }, [n("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: "image" === t.displayType,
                expression: "displayType === 'image'"
            }],
            staticClass: "thumbnail-wrapper"
        }, [n("img", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: "fill" === this.bgImagePos || "fit" === this.bgImagePos,
                expression: "this.bgImagePos === 'fill' || this.bgImagePos === 'fit'"
            }],
            ref: "img",
            staticClass: "thumb-img",
            style: t.imgStyle,
            attrs: {
                src: t.currentBgImageUrl
            },
            on: {
                load: function(e) {
                    t.imgLoaded = !0
                }
            }
        }), t._v(" "), n("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: "stretch" === this.bgImagePos,
                expression: "this.bgImagePos === 'stretch'"
            }],
            staticClass: "img",
            style: t.bgImageStyle
        }, [n("img", {
            ref: "img",
            staticClass: "stretch-thumb-img",
            attrs: {
                src: t.currentBgImageUrl
            },
            on: {
                load: function(e) {
                    t.imgLoaded = !0
                }
            }
        })]), t._v(" "), n("div", {
            directives: [{
                name: "show",
                rawName: "v-show",
                value: "center" === this.bgImagePos || "tile" === this.bgImagePos,
                expression: "this.bgImagePos === 'center' || this.bgImagePos === 'tile'"
            }],
            staticClass: "img",
            style: t.bgImageStyle
        })])])
    };
    O._withStripped = !0;
    var P = {
            props: {
                displayType: {
                    type: String
                },
                bgColor: {
                    type: String
                },
                bgImagePos: {
                    type: String
                },
                disabled: {
                    type: Boolean
                },
                bgImageUrl: {
                    type: String
                },
                emptyWallpaper: {
                    type: Boolean
                }
            },
            data: function() {
                return {
                    imgLoaded: !1
                }
            },
            computed: {
                currentBgImageUrl: function() {
                    if (this.imgLoaded = !1, this.bgImageUrl) return this.bgImageUrl;
                    var t = "1x";
                    return SYNO.SDS.UIFeatures.IconSizeManager.isRetinaMode() && (t = "2x"), "webman/resources/images/".concat(t, "/default_wallpaper/dsm7_01.jpg?v=").concat(_S("version"))
                },
                imgStyle: function() {
                    return this.getImgStyle()
                },
                bgImageStyle: function() {
                    return this.getBgImageStyle()
                }
            },
            mounted: function() {},
            methods: {
                getBgImageStyle: function() {
                    var t = this.bgImagePos,
                        e = this.$refs.wrapper,
                        n = this.imgLoaded;
                    if (e && n) {
                        var r = this.$refs.img.naturalWidth,
                            s = this.$refs.img.naturalHeight,
                            i = window.innerWidth,
                            a = window.innerHeight;
                        return "center" === t ? {
                            width: e.offsetWidth,
                            height: e.offsetHeight,
                            backgroundColor: this.bgColor,
                            backgroundImage: "url(" + this.currentBgImageUrl + ")",
                            backgroundPosition: "50% 50%",
                            backgroundRepeat: "no-repeat",
                            backgroundSize: "".concat(r * (e.offsetWidth / i), "px ").concat(s * (e.offsetHeight / a), "px"),
                            visibility: "visible"
                        } : "stretch" === t ? {
                            width: e.offsetWidth,
                            height: e.offsetHeight,
                            backgroundColor: this.bgColor,
                            backgroundImage: "url(" + this.currentBgImageUrl + ")",
                            backgroundRepeat: "no-repeat",
                            visibility: "visible"
                        } : "tile" === t ? {
                            width: e.offsetWidth,
                            height: e.offsetHeight,
                            backgroundColor: this.bgColor,
                            backgroundImage: "url(" + this.currentBgImageUrl + ")",
                            backgroundRepeat: "repeat",
                            backgroundSize: "".concat(r * (e.offsetWidth / i), "px ").concat(s * (e.offsetHeight / a), "px"),
                            visibility: "visible"
                        } : void 0
                    }
                },
                getImgStyle: function() {
                    var t = this.bgImagePos,
                        e = this.imgLoaded,
                        n = {
                            width: void 0,
                            height: void 0,
                            left: void 0,
                            top: void 0
                        };
                    if (!this.$refs.img || !e) return n;
                    var r = this.$refs.img.naturalWidth / this.$refs.img.naturalHeight;
                    return "fill" === t ? this.getStyleFromFill(r) : "fit" === t ? this.getStyleFromFit(r) : n
                },
                getStyleFromFill: function(t) {
                    var e = this.$refs.wrapper;
                    return e.offsetWidth > e.offsetHeight * t ? this.fitByWidth(e.offsetWidth, e.offsetHeight, t) : this.fitByHeight(e.offsetWidth, e.offsetHeight, t)
                },
                getStyleFromFit: function(t) {
                    var e = this.$refs.wrapper;
                    return e.offsetWidth > e.offsetHeight * t ? this.fitByHeight(e.offsetWidth, e.offsetHeight, t) : this.fitByWidth(e.offsetWidth, e.offsetHeight, t)
                },
                fitByWidth: function(t, e, n) {
                    return {
                        width: t + "px",
                        height: t / n + "px",
                        left: 0,
                        top: (e - t / n) / 2 + "px"
                    }
                },
                fitByHeight: function(t, e, n) {
                    return {
                        width: e * n + "px",
                        height: e + "px",
                        left: (t - e * n) / 2 + "px",
                        top: 0
                    }
                }
            }
        },
        C = (n(69), d(P, O, [], !1, null, "1167c30c", null));
    C.options.__file = "src/components/thumbnail.vue";
    var A = C.exports,
        j = function() {
            var t = this,
                e = t.$createElement;
            return (t._self._c || e)("v-select", {
                attrs: {
                    "syno-id": "components-date-format-select-0",
                    readonly: "",
                    width: 270,
                    name: "date-select",
                    options: t.allDateFormat
                },
                model: {
                    value: t.model,
                    callback: function(e) {
                        t.model = e
                    },
                    expression: "model"
                }
            })
        };
    j._withStripped = !0;
    var N = d({
        model: {
            prop: "date",
            event: "input"
        },
        props: {
            date: {
                type: String,
                default: "system"
            }
        },
        data: function() {
            return {}
        },
        computed: {
            allDateFormat: function() {
                return SYNO.SDS.DateTimeUtils.CreateDateFormatArray(!0).reduce((function(t, e) {
                    return t.push({
                        value: e[0],
                        label: e[1]
                    }), t
                }), [])
            },
            model: {
                set: function(t) {
                    this.$emit("input", t)
                },
                get: function() {
                    return this.date
                }
            }
        },
        mounted: function() {}
    }, j, [], !1, null, null, null);
    N.options.__file = "src/components/date-format.vue";
    var E = N.exports,
        $ = function() {
            var t = this,
                e = t.$createElement;
            return (t._self._c || e)("v-select", {
                attrs: {
                    "syno-id": "components-time-format-select-0",
                    readonly: "",
                    width: 270,
                    name: "time-select",
                    options: t.allTimeFormat
                },
                model: {
                    value: t.model,
                    callback: function(e) {
                        t.model = e
                    },
                    expression: "model"
                }
            })
        };
    $._withStripped = !0;
    var U = d({
        model: {
            prop: "time",
            event: "input"
        },
        props: {
            time: {
                type: String,
                default: "system"
            }
        },
        data: function() {
            return {}
        },
        computed: {
            allTimeFormat: function() {
                return SYNO.SDS.DateTimeUtils.CreateTimeFormatArray(!0).reduce((function(t, e) {
                    return t.push({
                        value: e[0],
                        label: e[1]
                    }), t
                }), [])
            },
            model: {
                set: function(t) {
                    this.$emit("input", t)
                },
                get: function() {
                    return this.time
                }
            }
        },
        mounted: function() {}
    }, $, [], !1, null, null, null);
    U.options.__file = "src/components/time-format.vue";
    var R = U.exports;

    function M(t, e, n, r, s, i, a) {
        try {
            var o = t[i](a),
                c = o.value
        } catch (t) {
            return void n(t)
        }
        o.done ? e(c) : Promise.resolve(c).then(r, s)
    }

    function Y(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise((function(r, s) {
                var i = t.apply(e, n);

                function a(t) {
                    M(i, r, s, a, o, "next", t)
                }

                function o(t) {
                    M(i, r, s, a, o, "throw", t)
                }
                a(void 0)
            }))
        }
    }

    function I(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            })))), r.forEach((function(e) {
                z(t, e, n[e])
            }))
        }
        return t
    }

    function z(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }

    function B(t) {
        return t && t.volumes ? t.volumes : []
    }

    function F(t) {
        var e = Object.assign({}, t, {
            useRetina: !0
        });
        return SYNO.SDS.Desktop.setBackground(e)
    }
    var L, W, q, V, H = {
            mixins: [i, a],
            data: function() {
                return {
                    colorWindowConfig: {
                        title: _T("personal_settings", "customize_color"),
                        showClose: !1,
                        showMaximize: !1,
                        resizable: !1,
                        showMinimize: !1,
                        height: "auto",
                        width: 436
                    },
                    showCustomColorPanel: !1,
                    thumbnailUrl: void 0,
                    isThumbnailBgImage: !1,
                    customColorPanel: "text",
                    menuStyle: [{
                        label: this.T("personal_settings", "menu_style_fullscreen"),
                        value: "fullscreen"
                    }, {
                        label: this.T("personal_settings", "menu_style_dropdown"),
                        value: "classical"
                    }],
                    iconSize: [{
                        label: this.T("personal_settings", "desktop_style_normal"),
                        value: "normal"
                    }, {
                        label: this.T("personal_settings", "desktop_style_classical"),
                        value: "classical"
                    }],
                    customType: [{
                        label: this.T("personal_settings", "image"),
                        value: "image"
                    }, {
                        label: this.T("personal_settings", "color"),
                        value: "color"
                    }],
                    wallpaperPos: [{
                        label: this.T("dsmoption", "login_background_position_fill"),
                        value: "fill"
                    }, {
                        label: this.T("dsmoption", "login_background_position_center"),
                        value: "center"
                    }, {
                        label: this.T("dsmoption", "login_background_position_fit"),
                        value: "fit"
                    }, {
                        label: this.T("dsmoption", "login_background_position_stretch"),
                        value: "stretch"
                    }, {
                        label: this.T("dsmoption", "login_background_position_tile"),
                        value: "tile"
                    }]
                }
            },
            computed: I({}, Object(o.mapState)("PreferencesModule", ["preferences", "originPreferences", "new_image", "customize_colors", "emptyWallpaper"]), Object(o.mapGetters)("PreferencesModule", ["isWallpaperDirty"]), {
                customColorPanelInitalValue: function() {
                    return "text" === this.customColorPanel ? this.preferences.wallpaper.text_color : this.preferences.wallpaper.background_color
                },
                isFitOrCenter: function() {
                    var t = this.preferences.wallpaper.wallpaper_position;
                    return "fit" === t || "center" === t
                },
                date_format: {
                    get: function() {
                        return this.$store.state.PreferencesModule.date_format
                    },
                    set: function(t) {
                        this.$store.commit("PreferencesModule/SET_DATE", t)
                    }
                },
                time_format: {
                    get: function() {
                        return this.$store.state.PreferencesModule.time_format
                    },
                    set: function(t) {
                        this.$store.commit("PreferencesModule/SET_TIME", t)
                    }
                },
                customizeDisable: function() {
                    return !this.preferences.wallpaper.customize_background
                }
            }),
            mounted: function() {
                var t = this;
                this.getPreferences(), this.getCustomizedColors(), this.getFormats(), this.emptyWallpaper || (this.thumbnailUrl = Ext.urlAppend("webapi/entry.cgi", Ext.urlEncode({
                    api: "SYNO.Core.PersonalSettings",
                    method: "wallpaper",
                    version: 1,
                    id: this.preferences.wallpaper.wallpaper
                }))), this.$watch("preferences.wallpaper.customize_background", (function(e) {
                    e && "image" === t.preferences.wallpaper.customize_background_type && t.setNewImageFlag(e), F(t.preferences.wallpaper)
                })), this.$watch("preferences.wallpaper.wallpaper_path", (function() {
                    F(t.preferences.wallpaper)
                })), this.$watch("preferences.wallpaper.wallpaper_position", (function() {
                    F(t.preferences.wallpaper)
                })), this.$watch("preferences.wallpaper.customize_background_type", (function(e) {
                    "color" === e ? t.setNewImageFlag(!1) : t.setNewImageFlag(!0), F(t.preferences.wallpaper)
                })), this.$watch("preferences.wallpaper.background_color", (function() {
                    F(t.preferences.wallpaper)
                })), this.$watch("preferences.wallpaper.text_color", (function() {
                    SYNO.SDS.Desktop.updateTextColor(t.preferences.wallpaper)
                }), {
                    deep: !0
                })
            },
            methods: I({}, Object(o.mapActions)("PreferencesModule", ["getPreferences", "getFormats", "setNewWallpaper", "applyFormats", "applyPreferences", "getCustomizedColors", "addCustomizedColor", "setNewImageFlag"]), {
                restoreSettings: function() {
                    !0 !== _S("standalone") && (this.isWallpaperDirty() && F(this.originPreferences.wallpaper), SYNO.SDS.Desktop.updateTextColor(this.originPreferences.wallpaper)), SYNO.SDS.AppView.destroy(), SYNO.SDS.AppView = SYNO.SDS.CreateActiveAppView()
                },
                colorChanged: function(t) {
                    "text" === this.customColorPanel ? this.preferences.wallpaper.text_color = t : this.preferences.wallpaper.background_color = t, this.addCustomizedColor(t), this.closeCustomColorWindow()
                },
                closeCustomColorWindow: function() {
                    this.$refs.customColorWindow.close(), this.showCustomColorPanel = !1
                },
                backgroundColorChanged: function(t) {
                    this.preferences.wallpaper.text_color = t, this.addCustomizedColor(t), this.showCustomColorPanel = !1
                },
                onSelectWallpaper: (V = Y(regeneratorRuntime.mark((function t() {
                    var e = this;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (t.prev = 0, !0 !== _S("is_admin")) {
                                    t.next = 4;
                                    break
                                }
                                return t.next = 4, this.loadVolumeInfo();
                            case 4:
                                this.wallpaperSelector ? this.wallpaperSelector.show() : (this.wallpaperSelector = new SYNO.SDS.Utils.ImageSelector({
                                    owner: this.$options.appWindow,
                                    maxImageSizeKB: 8192,
                                    enumCluster: !0
                                }, "desktop", "background"), this.$options.appWindow.openModalWindow(this.wallpaperSelector), this.wallpaperSelector.mon(this.wallpaperSelector, "choose", this.onSelectWallpaperDone, this), this.wallpaperSelector.mon(this.wallpaperSelector, "close", (function() {
                                    e.wallpaperSelector = null
                                }))), t.next = 10;
                                break;
                            case 7:
                                t.prev = 7, t.t0 = t.catch(0), SYNO.Debug.error(t.t0);
                            case 10:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [0, 7]
                    ])
                }))), function() {
                    return V.apply(this, arguments)
                }),
                onSelectWallpaperDone: function(t) {
                    this.setNewWallpaper({
                        wallpaper_path: t.data.path,
                        wallpaper_hd_path: t.data.hd_path,
                        wallpaper_ext: t.data.type,
                        wallpaper_type: t.data.apply_type
                    });
                    var e = function(t) {
                        return t.replace(/is_thumbnail=(true)/, "is_thumbnail=false").replace(/1x/, "2x").replace(/thumbnail_(\d*)\./, "dsm7_$1.")
                    }(t.data.url);
                    this.thumbnailUrl = e, this.isThumbnailBgImage = !0, this.wallpaperSelector.hide()
                },
                loadVolumeInfo: (q = Y(regeneratorRuntime.mark((function t() {
                    var e;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.$emit("loading"), t.prev = 1, t.next = 4, synowebapi.promises.request({
                                    api: "SYNO.Core.Storage.Volume",
                                    method: "list",
                                    params: {
                                        limit: -1,
                                        offset: 0,
                                        location: "" === _D("usbstation") ? "internal" : "external"
                                    },
                                    version: 1
                                });
                            case 4:
                                if (e = t.sent, this.$emit("clear"), !1 !== this.checkVolume(B(e))) {
                                    t.next = 8;
                                    break
                                }
                                throw new Error;
                            case 8:
                                t.next = 13;
                                break;
                            case 10:
                                throw t.prev = 10, t.t0 = t.catch(1), new Error(t.t0);
                            case 13:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [1, 10]
                    ])
                }))), function() {
                    return q.apply(this, arguments)
                }),
                checkVolume: (W = Y(regeneratorRuntime.mark((function t(e) {
                    var n;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (Ext.isArray(e) && 0 !== e.length) {
                                    t.next = 8;
                                    break
                                }
                                if ("" === (n = "yes" === _D("usbstation", "no") ? _T("volume", "volume_share_noexternal") : _T("volume", "volume_share_volumeno"))) {
                                    t.next = 8;
                                    break
                                }
                                return t.next = 5, this.$options.appWindow.getMsgBox().alert("", n);
                            case 5:
                                return "confirm" === t.sent && SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance"), t.abrupt("return", !1);
                            case 8:
                                return t.abrupt("return", !0);
                            case 9:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function(t) {
                    return W.apply(this, arguments)
                }),
                applyForm: function() {
                    var t = Y(regeneratorRuntime.mark((function t() {
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return this.applyFormats(), t.next = 3, this.applyPreferences();
                                case 3:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this)
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }),
            watch: {
                "preferences.menu_style": function(t, e) {
                    e && window.setTimeout((function() {
                        SYNO.SDS.AppView.destroy(), SYNO.SDS.AppView = "classical" === t ? SYNO.SDS.CreateAppView(null, {
                            dropdown: !0
                        }) : SYNO.SDS.CreateAppView(null, {
                            dropdown: !1
                        })
                    }), 50)
                },
                showCustomColorPanel: (L = Y(regeneratorRuntime.mark((function t(e) {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (!e) {
                                    t.next = 4;
                                    break
                                }
                                return t.next = 3, this.$nextTick();
                            case 3:
                                this.$options.appWindow.openModalWindow(this.$refs.customColorWindow);
                            case 4:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function(t) {
                    return L.apply(this, arguments)
                })
            },
            components: {
                Thumbnail: A,
                DateSelect: E,
                TimeSelect: R
            }
        },
        K = (n(70), n(71), d(H, D, [], !1, null, "e256321a", null));
    K.options.__file = "src/pages/display-preferences-page.vue";
    var G = K.exports,
        Q = function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-spin", {
                staticClass: "syno-sds-personal-settings-email-page-spin",
                attrs: {
                    tip: t.T("common", "loading"),
                    spinning: t.loading
                }
            }, [n("div", {
                staticClass: "email-page"
            }, [n("div", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: !t.loading && 0 === t.total,
                    expression: "!loading && total === 0"
                }],
                staticClass: "empty-page"
            }, [n("div", {
                staticClass: "icon"
            }), t._v(" "), n("div", {
                staticClass: "desc"
            }, [t._v("\n\t\t\t\t" + t._s(t.T("personal_settings", "empty_desc")) + "\n\t\t\t")]), t._v(" "), n("div", {
                staticClass: "action"
            }, [n("v-button", {
                attrs: {
                    "syno-id": "pages-email-page-button-0",
                    suffix: "blue"
                },
                on: {
                    click: t.onAdd
                }
            }, [t._v("\n\t\t\t\t\t" + t._s(t.T("common", "add")) + "\n\t\t\t\t")])], 1)]), t._v(" "), n("div", {
                staticClass: "toolbar"
            }, [n("v-button", {
                attrs: {
                    "syno-id": "pages-email-page-button-1",
                    suffix: "blue"
                },
                on: {
                    click: t.onAdd
                }
            }, [t._v("\n\t\t\t\t" + t._s(t.T("common", "add")) + "\n\t\t\t")]), t._v(" "), n("v-button", {
                attrs: {
                    "syno-id": "pages-email-page-button-2",
                    disabled: t.editDisabled
                },
                on: {
                    click: t.onEdit
                }
            }, [t._v("\n\t\t\t\t" + t._s(t.T("common", "alt_edit")) + "\n\t\t\t")]), t._v(" "), n("v-button", {
                attrs: {
                    "syno-id": "pages-email-page-button-3",
                    disabled: t.deleteDisabled
                },
                on: {
                    click: t.preDelete
                }
            }, [t._v("\n\t\t\t\t" + t._s(t.T("common", "delete")) + "\n\t\t\t")]), t._v(" "), n("v-button", {
                attrs: {
                    "syno-id": "pages-email-page-button-4",
                    disabled: t.setDefaultDisabled
                },
                on: {
                    click: t.setDefault
                }
            }, [t._v("\n\t\t\t\t" + t._s(t.T("mail", "set_default")) + "\n\t\t\t")])], 1), t._v(" "), n("v-data-table", {
                ref: "table",
                staticClass: "email-data-table data-table",
                attrs: {
                    "syno-id": "pages-email-page-data-table-0",
                    data: t.loadData,
                    columns: t.columns,
                    "response-params-name": t.paramsName,
                    pagination: !1
                },
                on: {
                    dataloaded: t.onDataLoaded,
                    rowclick: t.onRowClick,
                    rowclear: t.onRowClear
                }
            })], 1)])
        };

    function J(t, e, n, r, s, i, a) {
        try {
            var o = t[i](a),
                c = o.value
        } catch (t) {
            return void n(t)
        }
        o.done ? e(c) : Promise.resolve(c).then(r, s)
    }

    function Z(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise((function(r, s) {
                var i = t.apply(e, n);

                function a(t) {
                    J(i, r, s, a, o, "next", t)
                }

                function o(t) {
                    J(i, r, s, a, o, "throw", t)
                }
                a(void 0)
            }))
        }
    }

    function X(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            })))), r.forEach((function(e) {
                tt(t, e, n[e])
            }))
        }
        return t
    }

    function tt(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }

    function et(t, e) {
        return e <= 1
    }

    function nt() {
        return SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.MailClient.Application")
    }

    function rt(t) {
        return "yahoomail" !== t.email_type && "aolmail" !== t.email_type && !("synomail" === t.email_type && !nt())
    }
    Q._withStripped = !0;
    var st, it, at, ot, ct = {
            mixins: [i, a],
            data: function() {
                var t = this;
                return {
                    total: void 0,
                    loading: !1,
                    selectedRow: null,
                    paramsName: {
                        results: "data"
                    },
                    columns: [{
                        title: this.T("notification", "label_smtp_provider"),
                        fn: function(e) {
                            return t.getProvider(e.email_type)
                        }
                    }, {
                        title: this.T("mail", "application_title"),
                        fn: function(t) {
                            return t.auth && "custom" != t.email_type ? t.account : t.sender_account
                        }
                    }, {
                        title: this.T("common", "status"),
                        fn: function(e) {
                            switch (e.state) {
                                case 1:
                                    return "gmail" !== e.email_type ? t.T("mail", "contact_synced") : t.T("mail", "mail_gmail_status");
                                case 0:
                                    var n = "-";
                                    return "synomail" !== e.email_type || nt() || (n = t.T("common", "disabled")), n;
                                case -1:
                                    return t.T("error", "error_auth");
                                case -2:
                                    return t.T("mail", "mail_smtp_failed");
                                default:
                                    return t.T("download", "download_status_unknown")
                            }
                        }
                    }, {
                        title: this.T("mail", "default_use"),
                        getHtml: function(t) {
                            return t.is_default ? '\n\t\t\t\t\t\t\t<div class="default-use" aria-label="'.concat(_T("mail", "default_account"), '"></div>\n\t\t\t\t\t\t') : ""
                        }
                    }]
                }
            },
            computed: X({}, Object(o.mapState)("ActionModule", ["refreshEmailDataTable"]), {
                editDisabled: function() {
                    return !this.selectedRow || !rt(this.selectedRow)
                },
                deleteDisabled: function() {
                    return !this.selectedRow
                },
                setDefaultDisabled: function() {
                    return !this.selectedRow || (!rt(this.selectedRow) || this.selectedRow.is_default)
                }
            }),
            watch: {
                refreshEmailDataTable: function(t) {
                    t && (this.$refs.table.refresh(), this.actionDone("refreshEmailDataTable"))
                }
            },
            mounted: function() {},
            methods: X({}, Object(o.mapActions)("ActionModule", ["actionDone"]), {
                onDataLoaded: function(t) {
                    this.total = t.length
                },
                onAdd: (ot = Z(regeneratorRuntime.mark((function t() {
                    var e = this;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                this.$options.appWindow.openModalWindow(SYNO.SDS.App.PersonalSettings.Vue.EmailWizard, {
                                    firstCreate: 0 === this.total
                                }).window.$on("close", (function() {
                                    e.$refs.table.refresh()
                                }));
                            case 2:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return ot.apply(this, arguments)
                }),
                onEdit: function() {
                    var t = this,
                        e = this.selectedRow;
                    this.$options.appWindow.openModalWindow(SYNO.SDS.App.PersonalSettings.Vue.EmailEdit, {
                        email: e
                    }).window.$on("close", (function() {
                        t.$refs.table.refresh()
                    }))
                },
                setDefault: (at = Z(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.prev = 0, this.loading = !0, t.next = 4, synowebapi.promises.request({
                                    api: "SYNO.PersonMailAccount",
                                    method: "update",
                                    version: "1",
                                    params: {
                                        alias: this.selectedRow.alias,
                                        is_default: !0
                                    }
                                });
                            case 4:
                                SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_alias", this.selectedRow.alias), SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_type", this.selectedRow.email_type), this.$refs.table.refresh(), t.next = 12;
                                break;
                            case 9:
                                t.prev = 9, t.t0 = t.catch(0), this.$options.appWindow.getMsgBox().alert("", this.T("error", "error_error_system"));
                            case 12:
                                return t.prev = 12, this.loading = !1, t.finish(12);
                            case 15:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [0, 9, 12, 15]
                    ])
                }))), function() {
                    return at.apply(this, arguments)
                }),
                preDelete: (it = Z(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (e = this.selectedRow, n = this.total, !(e.is_default && n > 1)) {
                                    t.next = 4;
                                    break
                                }
                                this.$options.appWindow.getMsgBox().alert("", this.T("mail", "delete_default_alert")), t.next = 12;
                                break;
                            case 4:
                                if (!et(this.selectedRow, this.total)) {
                                    t.next = 11;
                                    break
                                }
                                return t.next = 7, this.$options.appWindow.getMsgBox().confirmDelete(this.T("mail", "delete_confirm"), this.T("mail", "delete_last_one"));
                            case 7:
                                "confirm" === t.sent && this.onDelete(), t.next = 12;
                                break;
                            case 11:
                                this.onDelete();
                            case 12:
                            case "end":
                                return t.stop()
                        }
                        var e, n
                    }), t, this)
                }))), function() {
                    return it.apply(this, arguments)
                }),
                onDelete: (st = Z(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.prev = 0, this.loading = !0, t.next = 4, synowebapi.promises.request({
                                    api: "SYNO.PersonMailAccount",
                                    method: "delete",
                                    version: "1",
                                    params: {
                                        email_type: this.selectedRow.email_type,
                                        alias: this.selectedRow.alias
                                    }
                                });
                            case 4:
                                this.selectedRow.is_default && (SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_type", ""), SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_alias", ""), SYNO.SDS.UserSettings.save()), this.$refs.table.refresh(), t.next = 11;
                                break;
                            case 8:
                                t.prev = 8, t.t0 = t.catch(0), this.$options.appWindow.getMsgBox().alert("", this.T("error", "error_error_system"));
                            case 11:
                                return t.prev = 11, this.loading = !1, t.finish(11);
                            case 14:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [0, 8, 11, 14]
                    ])
                }))), function() {
                    return st.apply(this, arguments)
                }),
                onRowClick: function(t) {
                    this.selectedRow = t.row
                },
                onRowClear: function() {
                    this.selectedRow = null
                },
                getProvider: function(t) {
                    return "gmail" === t ? "Gmail" : "hotmail" === t ? "Outlook" : "yahoomail" === t ? "Yahoo!" : "aolmail" === t ? "AOL" : "synomail" == t ? "MailPlus" : "Customize"
                },
                loadData: function(t) {
                    var e = Object.assign(t);
                    return synowebapi.promises.request({
                        api: "SYNO.PersonMailAccount",
                        method: "get",
                        version: "1",
                        params: e
                    })
                },
                applyForm: function() {}
            })
        },
        lt = (n(72), d(ct, Q, [], !1, null, null, null));
    lt.options.__file = "src/pages/email-page.vue";
    var ut = lt.exports,
        pt = function() {
            var t = this.$createElement,
                e = this._self._c || t;
            return e("div", {
                staticClass: "quota-page"
            }, [e("v-data-table", {
                ref: "quota",
                staticClass: "quota",
                attrs: {
                    "syno-id": "pages-quota-page-data-table-0",
                    data: this.loadQuota,
                    columns: this.columns,
                    "enable-hd-menu": !1,
                    "show-paging-bar": !1,
                    "tree-table": !!this.supportShareUserQuota
                }
            })], 1)
        };
    pt._withStripped = !0;
    var dt = {
            components: {},
            mixins: [i],
            data: function() {
                return {
                    supportShareQuota: "yes" === _D("support_share_quota", "no"),
                    supportShareUserQuota: "yes" === _D("support_share_user_quota", "no"),
                    columns: []
                }
            },
            computed: {},
            mounted: function() {
                var t, e, n;
                this.columns = (t = this.supportShareQuota, e = this.supportShareUserQuota, n = [{
                    title: e ? _T("common", "volume_share") : _T("user", "user_volume"),
                    fn: function(t) {
                        var e = t.name;
                        return e.includes("share:") ? e.replace("share:", "") : "X" === e.charAt(0) ? String.format("{0} {1}({2})", _T("volume", "volume"), e.substring(1), _T("volume", "volume_disk_source_ebox")) : String.format("{0} {1}", _T("volume", "volume"), e)
                    }
                }], t && (n.push({
                    title: _T("share", "share_quota"),
                    fn: function(t) {
                        var e = t.share_quota;
                        return 0 === e ? _T("user", "user_quota_nolimit") : "-" === e ? "-" : void 0 === e || "NotSupport" === e ? "" : SYNO.SDS.Utils.CapacityRender(e, 0)
                    }
                }), n.push({
                    title: _T("share", "share_size"),
                    fn: function(t) {
                        var e = t.share_used;
                        return "-" === e ? "-" : void 0 === e || "NotSupport" === e ? "" : SYNO.SDS.Utils.CapacityRender(e, 3)
                    }
                })), n.push({
                    title: t ? _T("personal_settings", "user_quota_capacity") : _T("user", "user_quota_capacity"),
                    fn: function(t) {
                        var e = t.quota;
                        return 0 === e ? _T("user", "user_quota_nolimit") : "NotSupport" === e ? "" : SYNO.SDS.Utils.CapacityRender(e, 0)
                    }
                }), n.push({
                    title: _T("user", "acnt_used_cap"),
                    fn: function(t) {
                        var e = t.used;
                        return "NotSupport" === e ? "" : SYNO.SDS.Utils.CapacityRender(e, 3)
                    }
                }), n)
            },
            methods: {
                loadQuota: function(t) {
                    var e = Object.assign(t);
                    return synowebapi.promises.request({
                        api: "SYNO.Core.PersonalSettings",
                        method: "quota",
                        version: "1",
                        params: e
                    })
                },
                applyForm: function() {}
            }
        },
        ft = (n(73), d(dt, pt, [], !1, null, null, null));
    ft.options.__file = "src/pages/quota-page.vue";
    var mt = ft.exports,
        ht = function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("div", {
                staticClass: "other-page"
            }, [n("v-form", {
                ref: "form",
                attrs: {
                    "syno-id": "pages-other-page-form-0",
                    model: t.fields
                }
            }, t._l(t.visibleFields, (function(e, r) {
                return n("v-form-item", {
                    key: r,
                    ref: r,
                    refInFor: !0,
                    attrs: {
                        prop: r,
                        "hide-label": ""
                    }
                }, [n("v-checkbox", {
                    attrs: {
                        "syno-id": "pages-other-page-checkbox-" + r,
                        name: r
                    },
                    model: {
                        value: t.formSettings[e.settingKey],
                        callback: function(n) {
                            t.$set(t.formSettings, e.settingKey, n)
                        },
                        expression: "formSettings[item.settingKey]"
                    }
                }, [t._v("\n\t\t\t\t" + t._s(e.labelText) + "\n\t\t\t")])], 1)
            })), 1), t._v("\n\t" + t._s() + "\n")], 1)
        };

    function vt(t, e) {
        return function(t) {
            if (Array.isArray(t)) return t
        }(t) || function(t, e) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(t))) return;
            var n = [],
                r = !0,
                s = !1,
                i = void 0;
            try {
                for (var a, o = t[Symbol.iterator](); !(r = (a = o.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
            } catch (t) {
                s = !0, i = t
            } finally {
                try {
                    r || null == o.return || o.return()
                } finally {
                    if (s) throw i
                }
            }
            return n
        }(t, e) || function(t, e) {
            if (!t) return;
            if ("string" == typeof t) return _t(t, e);
            var n = Object.prototype.toString.call(t).slice(8, -1);
            "Object" === n && t.constructor && (n = t.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(t);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return _t(t, e)
        }(t, e) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function _t(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
        return r
    }

    function gt(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            })))), r.forEach((function(e) {
                bt(t, e, n[e])
            }))
        }
        return t
    }

    function bt(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }
    ht._withStripped = !0;
    var yt = {
            mixins: [i],
            data: function() {
                return {
                    fields: {
                        rememberWindowState: {
                            labelText: _T("personal_settings", "remember_window_state"),
                            settingKey: "rememberWindowState"
                        },
                        enableTaskbarThumbnail: {
                            labelText: _T("personal_settings", "enable_taskbar_thumbnail"),
                            settingKey: "enableTaskbarThumbnail"
                        },
                        hotkeyEnabled: {
                            labelText: _T("hotkey_manager", "enable_desktop_hotkeys"),
                            settingKey: "hotkeyEnabled"
                        },
                        disableAccessibility: {
                            labelText: _T("personal_settings", "disable_accessibility"),
                            settingKey: "disableAccessibility"
                        },
                        enableDesktopNotification: {
                            labelText: _T("notification", "enable_chrome_desktop_notification"),
                            settingKey: "enableDesktopNotification",
                            isHidden: !this.hasNotification()
                        }
                    }
                }
            },
            computed: gt({
                visibleFields: function() {
                    for (var t = {}, e = Object.entries(this.fields), n = 0; n < e.length; n++) {
                        var r = vt(e[n], 2),
                            s = r[0],
                            i = r[1];
                        i.isHidden || (t[s] = i)
                    }
                    return t
                }
            }, Object(o.mapState)("OthersModule", ["formSettings"])),
            mounted: function() {
                this.loadForm()
            },
            methods: gt({}, Object(o.mapActions)("OthersModule", ["getSettings", "applySettings"]), {
                hasNotification: function() {
                    return Ext.isSecure && window.Notification && "denied" !== window.Notification.permission
                },
                loadForm: function() {
                    this.getSettings()
                },
                applyForm: function() {
                    this.applySettings(), this.triggerApplyPostAction()
                },
                triggerApplyPostAction: function() {
                    this.$refs.hotkeyEnabled[0].isDirty && SYNO.SDS.Desktop.hotkeyPlugin.setHotkeyEnabled(this.formSettings.hotkeyEnabled), this.$refs.disableAccessibility[0].isDirty && SYNO.SDS.initAccesibilityPlugin()
                }
            })
        },
        wt = (n(74), d(yt, ht, [], !1, null, "6d2bf2b0", null));
    wt.options.__file = "src/pages/other-page.vue";
    var St = wt.exports;

    function xt(t, e, n, r, s, i, a) {
        try {
            var o = t[i](a),
                c = o.value
        } catch (t) {
            return void n(t)
        }
        o.done ? e(c) : Promise.resolve(c).then(r, s)
    }

    function kt(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise((function(r, s) {
                var i = t.apply(e, n);

                function a(t) {
                    xt(i, r, s, a, o, "next", t)
                }

                function o(t) {
                    xt(i, r, s, a, o, "throw", t)
                }
                a(void 0)
            }))
        }
    }

    function Tt(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }
    var Dt, Ot, Pt, Ct, At = "save",
        jt = "dont_save",
        Nt = {
            mixins: [i],
            components: {
                AccountPage: T,
                EmailPage: ut,
                DisplayPreferencesPage: G,
                QuotaPage: mt,
                OtherPage: St
            },
            data: function() {
                return {
                    tabKeys: ["account", "display-preferences", "email", "quota", "others"],
                    currentPage: void 0,
                    currentTabKey: void 0,
                    tabKey: "account",
                    loading: !1
                }
            },
            watch: {
                loading: function(t) {
                    t ? this.$refs.appWindow.setStatusBusy() : this.$refs.appWindow.clearStatus()
                }
            },
            computed: function(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? Object(arguments[e]) : {},
                        r = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                        return Object.getOwnPropertyDescriptor(n, t).enumerable
                    })))), r.forEach((function(e) {
                        Tt(t, e, n[e])
                    }))
                }
                return t
            }({}, Object(o.mapGetters)("PreferencesModule", {
                isDesktopStyleDirty: "isDesktopStyleDirty",
                isDateFormatDirty: "isDateFormatDirty",
                isTimeFormatDirty: "isTimeFormatDirty",
                preferencesDirtyCheck: "leaveCheckDirty"
            }), Object(o.mapGetters)("UserModule", {
                isLangDirty: "isLangDirty",
                userDirtyCheck: "leaveCheckDirty"
            }), Object(o.mapGetters)("OthersModule", {
                othersDirtyCheck: "leaveCheckDirty"
            }), {
                supportQuota: function() {
                    return "yes" === _D("supportquota", "no")
                },
                helpParams: function() {
                    switch (this.currentTabKey) {
                        case "account":
                            return "MainMenu/account.html";
                        case "display-preferences":
                            return "MainMenu/displaypreference.html";
                        case "email":
                            return "MainMenu/emailaccount.html";
                        case "quota":
                            return "MainMenu/volumeusage.html";
                        case "others":
                            return "MainMenu/others.html"
                    }
                    return "MainMenu/Options_desc.html"
                }
            }),
            created: function() {
                this.$store.commit("RESET")
            },
            mounted: function() {
                var t = kt(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.next = 2, this.$nextTick();
                            case 2:
                                this.currentPage = this.$refs.account, this.currentTabKey = this.tabKey;
                            case 4:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                })));
                return function() {
                    return t.apply(this, arguments)
                }
            }(),
            methods: {
                handleParams: function(t, e) {
                    e.tab && (this.tabKey = e.tab)
                },
                onTabChange: function(t) {
                    this.currentPage = this.$refs[t], this.currentTabKey = t
                },
                showRefreshConfirmDialogIfNeeded: function(t, e, n, r) {
                    if (t || e || n || r) {
                        var s = _T("personal_settings", "refresh_confirm") + "<ul><br>" + (r ? "<li>" + _T("personal_settings", "lang_changed") + "</li>" : "") + (t ? "<li>" + _T("personal_settings", "desktop_setting_changed") + "</li>" : "") + "</ul>";
                        SYNO.SDS.Desktop.getMsgBox().confirm("", s, (function(t) {
                            "yes" === t && SYNO.SDS.UserSettings.save({
                                callback: function() {
                                    window.onbeforeunload = null, window.onbeforeunload = SYNO.SDS.onBeforeUnloadForApplication, location.reload()
                                }
                            })
                        }), this)
                    }
                },
                applyForm: function() {
                    var t = kt(regeneratorRuntime.mark((function t() {
                        var e, n, r, s, i, a = this;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return e = this.isDesktopStyleDirty, n = this.isDateFormatDirty, r = this.isTimeFormatDirty, s = this.isLangDirty, this.loading = !0, i = this.tabKeys.map((function(t) {
                                        if (a.$refs[t]) return a.$refs[t].applyForm()
                                    })), t.prev = 3, t.next = 6, Promise.all(i);
                                case 6:
                                    this.loading = !1, this.showRefreshConfirmDialogIfNeeded(e, n, r, s), t.next = 14;
                                    break;
                                case 10:
                                    throw t.prev = 10, t.t0 = t.catch(3), this.$refs.appWindow.getMsgBox().alert("", t.t0.message, null, {
                                        useHtml: !0
                                    }), t.t0;
                                case 14:
                                    return t.prev = 14, this.loading = !1, t.finish(14);
                                case 17:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this, [
                            [3, 10, 14, 17]
                        ])
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                restoreSettings: (Ct = kt(regeneratorRuntime.mark((function t() {
                    var e, n = this;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return e = this.tabKeys.map((function(t) {
                                    if (n.$refs[t] && n.$refs[t].restoreSettings) return n.$refs[t].restoreSettings()
                                })), t.prev = 1, t.next = 4, Promise.all(e);
                            case 4:
                                t.next = 8;
                                break;
                            case 6:
                                t.prev = 6, t.t0 = t.catch(1);
                            case 8:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [1, 6]
                    ])
                }))), function() {
                    return Ct.apply(this, arguments)
                }),
                onConfirm: (Pt = kt(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.prev = 0, t.next = 3, this.applyForm();
                            case 3:
                                this.$refs.appWindow.doClose(), t.next = 9;
                                break;
                            case 6:
                                t.prev = 6, t.t0 = t.catch(0), SYNO.Debug.error(t.t0);
                            case 9:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [0, 6]
                    ])
                }))), function() {
                    return Pt.apply(this, arguments)
                }),
                onCancel: function() {
                    this.$refs.appWindow.close()
                },
                isDirty: function() {
                    return this.preferencesDirtyCheck() || this.userDirtyCheck() || this.othersDirtyCheck()
                },
                confirmLostMsgBox: (Ot = kt(regeneratorRuntime.mark((function t() {
                    var e;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.next = 2, this.$refs.appWindow.getMsgBox().confirmLostChange();
                            case 2:
                                if ((e = t.sent) !== At) {
                                    t.next = 8;
                                    break
                                }
                                return t.next = 6, this.applyForm();
                            case 6:
                                t.next = 14;
                                break;
                            case 8:
                                if (e !== jt) {
                                    t.next = 13;
                                    break
                                }
                                return t.next = 11, this.restoreSettings();
                            case 11:
                                t.next = 14;
                                break;
                            case 13:
                                return t.abrupt("return", !1);
                            case 14:
                                return t.abrupt("return", !0);
                            case 15:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return Ot.apply(this, arguments)
                }),
                beforeClose: (Dt = kt(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (!this.isDirty()) {
                                    t.next = 6;
                                    break
                                }
                                return t.next = 3, this.confirmLostMsgBox();
                            case 3:
                                if (!1 !== t.sent) {
                                    t.next = 6;
                                    break
                                }
                                return t.abrupt("return", !1);
                            case 6:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return Dt.apply(this, arguments)
                }),
                onLoading: function(t) {
                    this.loading = t
                }
            }
        },
        Et = (n(75), d(Nt, r, [], !1, null, null, null));
    Et.options.__file = "src/App.vue";
    var $t = Et.exports,
        Ut = function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-wizard-window", {
                ref: "window",
                attrs: {
                    "syno-id": "windows-email-wizard-wizard-window-0",
                    title: t.T("mail", "email_wizard_title"),
                    width: "640",
                    height: "490"
                }
            }, [n("v-wizard", {
                attrs: {
                    "syno-id": "windows-email-wizard-wizard-0",
                    "active-step-key": "welcome",
                    "next-step-disabled": t.nextStepDisabled,
                    "previous-step-disabled": t.previousStepDisabled
                }
            }, [n("welcome", {
                attrs: {
                    "step-key": "welcome",
                    "email-type": t.saveData.email_type,
                    "empty-text": t.emptyText
                },
                on: {
                    "update:emailType": function(e) {
                        return t.$set(t.saveData, "email_type", e)
                    },
                    "update:email-type": function(e) {
                        return t.$set(t.saveData, "email_type", e)
                    },
                    "update:emptyText": function(e) {
                        t.emptyText = e
                    },
                    "update:empty-text": function(e) {
                        t.emptyText = e
                    }
                }
            }), t._v(" "), n("custom-email-setting", {
                attrs: {
                    "step-key": "custom_email_setting",
                    "first-create": t.firstCreate,
                    "save-data": t.saveData
                },
                on: {
                    "update:saveData": function(e) {
                        t.saveData = e
                    },
                    "update:save-data": function(e) {
                        t.saveData = e
                    },
                    "display-error": t.displayError,
                    close: t.onClose
                }
            }), t._v(" "), n("gmail-setting", {
                attrs: {
                    "first-create": t.firstCreate,
                    "save-data": t.saveData
                },
                on: {
                    "update:saveData": function(e) {
                        t.saveData = e
                    },
                    "update:save-data": function(e) {
                        t.saveData = e
                    },
                    "disable-footer-button": t.disableFooterButton,
                    close: t.onClose,
                    "display-error": t.displayError
                }
            }), t._v(" "), n("normal-email-setting", {
                attrs: {
                    "first-create": t.firstCreate,
                    "save-data": t.saveData
                },
                on: {
                    "update:saveData": function(e) {
                        t.saveData = e
                    },
                    "update:save-data": function(e) {
                        t.saveData = e
                    },
                    "disable-footer-button": t.disableFooterButton,
                    close: t.onClose,
                    "display-error": t.displayError
                }
            }), t._v(" "), n("syno-mail-setting", {
                attrs: {
                    "first-create": t.firstCreate,
                    "save-data": t.saveData
                },
                on: {
                    "update:saveData": function(e) {
                        t.saveData = e
                    },
                    "update:save-data": function(e) {
                        t.saveData = e
                    },
                    "display-error": t.displayError,
                    close: t.onClose
                }
            })], 1)], 1)
        };
    Ut._withStripped = !0;
    var Rt = function() {
        var t = this,
            e = t.$createElement,
            n = t._self._c || e;
        return n("v-wizard-step", {
            ref: "step",
            staticClass: "syno-sds-personalsetting-welcome-page",
            attrs: {
                "syno-id": "email-wizard-steps-welcome-wizard-step-0",
                "step-key": t.stepKey,
                headline: t.T("mail", "add_email_title"),
                "next-step-key": t.nextStepKey,
                "pre-enter-next-step": t.prepareToNext
            }
        }, [n("div", {
            staticClass: "desc"
        }, [t._v("\n\t\t" + t._s(t.T("mail", "add_email_desc")) + "\n\t")]), t._v(" "), n("div", {
            staticClass: "listboxes"
        }, [t._l(t.boxes, (function(e) {
            return [n("div", {
                class: {
                    active: t.selectedBox && t.selectedBox.type === e.type, "email-provider-template": "custom" !== e.type, "email-provider-custom": "custom" === e.type
                },
                attrs: {
                    role: "option"
                },
                on: {
                    click: function(n) {
                        t.selectedBox = e
                    },
                    dblclick: function(n) {
                        return t.onSelectDone(e)
                    }
                }
            }, ["" !== e.img ? n("img", {
                attrs: {
                    src: e.img,
                    draggable: "false",
                    width: "200",
                    height: "60"
                }
            }) : [t._v("\n\t\t\t\t\t" + t._s(e.name) + "\n\t\t\t\t")]], 2)]
        }))], 2)])
    };
    Rt._withStripped = !0;
    var Mt = {
            mounted: function() {
                this.$parent.$options.window ? this.$options.window = this.$parent.$options.window : this.$options.window = function t(e) {
                    return e ? e.$refs.window ? e.$refs.window : t(e.$parent) : null
                }(this.$parent)
            }
        },
        Yt = (_T("mail", "mail_gmail_desc"), _T("mail", "mail_authentication"), _T("mail", "mail_reauth"), _T("mail", "mail_authentication_success"), _T("mail", "sync_fail"), _T("mail", "mail_syncpage_desc"), _T("mail", "sync_contact"), _T("mail", "unsync_contact"), _T("mail", "sync_success"), _T("mail", "sync_fail"), function(t, e) {
            if (t) return "hotmail" === e && !t.includes("@hotmail.com") && !t.includes("@outlook.com") || ("yahoomail" === e && !t.includes("@yahoo.com") || "aolmail" === e && !t.includes("@aol.com"))
        }),
        It = function(t) {
            return "gmail" === t ? "Gmail" : "hotmail" === t ? "Outlook" : "yahoomail" === t ? "Yahoo!" : "aolmail" === t ? "AOL" : "Custom"
        },
        zt = function() {
            return SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.MailClient.Application")
        },
        Bt = {
            mixins: [i, Mt],
            props: {
                emailType: String,
                nextStepkey: String,
                stepKey: String
            },
            data: function() {
                return {
                    boxes: [],
                    selectedBox: null,
                    nextStepKey: "custom_email_setting"
                }
            },
            mounted: function() {
                this.boxes = [{
                    name: "MailPlus",
                    type: "synomail",
                    img: this.getIconSrc("synomail"),
                    text: "user@domain.com"
                }, {
                    name: "Gmail",
                    type: "gmail",
                    img: this.getIconSrc("gmail"),
                    text: "user@gmail.com"
                }, {
                    name: "Outlook",
                    type: "hotmail",
                    img: this.getIconSrc("outlook"),
                    text: "user@hotmail.com"
                }, {
                    name: "Customize",
                    type: "custom",
                    img: "",
                    text: "user@domain.com"
                }], zt() || this.boxes.splice(0, 1)
            },
            methods: {
                getIconSrc: function(t) {
                    var e = "mail_" + t;
                    return SYNO.SDS.UIFeatures.test("isRetina") && (e += "_2x"), "../../../webman/modules/PersonalSettings/images/" + (e += ".png")
                },
                onSelectDone: function(t) {
                    this.selectedBox = t, this.$emit("update:emailType", this.selectedBox.type), this.$emit("update:emptyText", this.selectedBox.text), this.$refs.step.nextStep()
                },
                prepareToNext: function() {
                    var t;
                    if (!this.selectedBox || !this.selectedBox.type) return this.$options.window.getMsgBox().alert("", _T("mail", "add_email_desc")), !1;
                    var e = this.selectedBox.type;
                    this.$emit("update:emailType", e), this.$emit("update:emptyText", this.selectedBox.text), t = "custom" === e ? "custom_email_setting" : "gmail" === e ? "gmail_setting" : "synomail" === e ? "synomail_setting" : "normal_email_setting", this.nextStepKey = t
                }
            }
        },
        Ft = (n(76), d(Bt, Rt, [], !1, null, null, null));
    Ft.options.__file = "src/email-wizard-steps/welcome.vue";
    var Lt = Ft.exports,
        Wt = function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("div", [n("v-wizard-step", {
                staticClass: "syno-sds-personalsetting-normal-setting",
                attrs: {
                    "syno-id": "email-wizard-steps-normal-email-setting-wizard-step-0",
                    "step-key": "normal_email_setting",
                    "next-step-key": t.nextVerifyStep,
                    headline: t.T("mail", "email_settings_title"),
                    "pre-enter-next-step": t.prepareToNext
                }
            }, [n("v-form", {
                ref: "form",
                attrs: {
                    "syno-id": "email-wizard-steps-normal-email-setting-form-0",
                    model: t.fields,
                    rules: t.rules
                }
            }, [n("v-form-item", {
                attrs: {
                    label: t.T("mail", "application_title") + ":",
                    prop: "account"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "email-wizard-steps-normal-email-setting-input-0",
                    name: "account"
                },
                model: {
                    value: t.fields.account,
                    callback: function(e) {
                        t.$set(t.fields, "account", e)
                    },
                    expression: "fields.account"
                }
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    label: t.T("notification", "alert_smtp_pass") + ":",
                    prop: "password"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "email-wizard-steps-normal-email-setting-input-1",
                    name: "password",
                    type: "password"
                },
                model: {
                    value: t.fields.password,
                    callback: function(e) {
                        t.$set(t.fields, "password", e)
                    },
                    expression: "fields.password"
                }
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    label: t.T("notification", "label_smtp_sender_name") + ":",
                    prop: "senderName"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "email-wizard-steps-normal-email-setting-input-2",
                    name: "senderName",
                    placeholder: t.emptyText
                },
                model: {
                    value: t.fields.senderName,
                    callback: function(e) {
                        t.$set(t.fields, "senderName", e)
                    },
                    expression: "fields.senderName"
                }
            }), t._v(" "), n("v-whitetip", {
                attrs: {
                    slot: "after",
                    content: String.format(t.T("mail", "sender_name_hint"), t.T("notification", "alert_smtp_user"))
                },
                slot: "after"
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    prop: "defaultUse",
                    "hide-label": ""
                }
            }, [n("v-checkbox", {
                attrs: {
                    "syno-id": "email-wizard-steps-normal-email-setting-checkbox-0",
                    disabled: t.defaultUseDisabled
                },
                model: {
                    value: t.fields.defaultUse,
                    callback: function(e) {
                        t.$set(t.fields, "defaultUse", e)
                    },
                    expression: "fields.defaultUse"
                }
            }, [t._v("\n\t\t\t\t\t" + t._s(t.T("mail", "default_use_checkbox")) + "\n\t\t\t\t")])], 1), t._v(" "), n("div", {
                staticClass: "composite"
            }, [n("v-button", {
                attrs: {
                    "syno-id": "email-wizard-steps-normal-email-setting-button-0"
                },
                on: {
                    click: t.onTestConnect
                }
            }, [t._v("\n\t\t\t\t\t" + t._s(t.T("mail", "mail_test_connection")) + "\n\t\t\t\t")]), t._v(" "), n("span", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: t.status.showSucc,
                    expression: "status.showSucc"
                }],
                staticClass: "succ-icon"
            }), t._v(" "), n("span", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: t.status.showError,
                    expression: "status.showError"
                }],
                staticClass: "status-error"
            }, [t._v("\n\t\t\t\t\t" + t._s(t.T("mail", "mail_setting_error")) + "\n\t\t\t\t")])], 1)], 1)], 1), t._v(" "), n("v-wizard-step", {
                staticClass: "syno-sds-personalsetting-normal-verify",
                attrs: {
                    "syno-id": "email-wizard-steps-normal-email-setting-wizard-step-1",
                    "step-key": "normal_verify",
                    headline: t.T("mail", "email_settings_title"),
                    finished: t.finished
                }
            }, [n("v-form", {
                attrs: {
                    "syno-id": "email-wizard-steps-normal-email-setting-form-1"
                }
            }, [n("div", {
                staticClass: "desc"
            }, [t._v("\n\t\t\t\t" + t._s(t.T("mail", "mail_syncpage_desc")) + "\n\t\t\t")]), t._v(" "), n("div", {
                staticClass: "desc"
            }, [t._v("\n\t\t\t\t" + t._s(t.T("mail", "mail_syncpage_note")) + "\n\t\t\t")]), t._v(" "), n("div", {
                staticClass: "auth-info"
            }, [n("v-button", {
                attrs: {
                    "syno-id": "email-wizard-steps-normal-email-setting-button-1"
                },
                on: {
                    click: t.onSyncClick
                }
            }, [t._v("\n\t\t\t\t\t" + t._s(t.btnText) + "\n\t\t\t\t")]), t._v(" "), n("span", {
                staticClass: "note",
                class: t.authNote.cls
            }, [t._v("\n\t\t\t\t\t" + t._s(t.authNote.text) + "\n\t\t\t\t")])], 1)])], 1)], 1)
        };
    Wt._withStripped = !0;
    var qt = {
        data: function() {
            return {
                popup: null
            }
        },
        methods: {
            onVerifyAuth: function() {
                this.register(this.onAuthCallback.bind(this), "_syncContactOAuthCallback");
                var t = window.location.href.indexOf("/", window.location.protocol.length + 2),
                    e = "http://synooauth.synology.com/email/login.php?callback=_syncContactOAuthCallback&host=" + (window.location.href.slice(0, t) + "/webman/modules/PersonalSettings/index_ds.php") + "&type=" + this.currentData.email_type + "&version=2";
                this.popup = window.open(e, "mywindow", "menubar=1,resizable=0,width=600,height=520, top=100, left=300"), this.addPopupTimer()
            },
            onCancelAuth: function() {
                this.btnText = this.authInfo.btnText, this.authInfo.verified = !1, this.currentData.access_token = "", this.currentData.refresh_token = "", this.currentData.expires_in = "", this.authNote.text = ""
            },
            onAuthCallback: function(t) {
                if (t.token) {
                    if (this.currentData.access_token = t.token, t.refresh_token && (this.currentData.refresh_token = t.refresh_token), t.expires_in && parseInt(t.expires_in, 10)) {
                        var e = new Date,
                            n = parseInt(e.getTime() / 1e3, 10) + parseInt(t.expires_in, 10) - 100;
                        this.currentData.expires_in = n.toString()
                    }
                    this.authInfo.verified = !0, this.btnText = this.authInfo.unsyncText, this.showAuthMessage(!0)
                } else this.showAuthMessage(!1)
            },
            showAuthMessage: function(t) {
                this.authNote = t ? {
                    text: this.authInfo.syncSuccess,
                    cls: "success"
                } : {
                    text: this.authInfo.syncFailed,
                    cls: "error"
                }
            },
            register: function(t, e) {
                if (Ext.isIE || Ext.isIE11) window[e] = t;
                else {
                    var n = this;
                    this.receiveMessage = function(r) {
                        if (r.data && r.origin === window.location.origin && !/setImmediate/.test(r.data)) try {
                            var s = JSON.parse(r.data);
                            if (s.callback !== e) return;
                            t.call(n, s)
                        } catch (t) {}
                    }, window.addEventListener("message", this.receiveMessage)
                }
            },
            unregister: function() {
                Ext.isIE || Ext.isIE11 || window.removeEventListener("message", this.receiveMessage)
            },
            addPopupTimer: function() {
                var t = this;
                if (this.popup && !this.popup.closed) var e = window.setInterval((function() {
                    t.popup.closed && (t.unregister(), window.clearInterval(e), e = null)
                }), 1e3)
            },
            doClosePopup: function() {
                this.popup && !this.popup.closed && this.popup.close()
            }
        }
    };

    function Vt(t, e) {
        return function(t) {
            if (Array.isArray(t)) return t
        }(t) || function(t, e) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(t))) return;
            var n = [],
                r = !0,
                s = !1,
                i = void 0;
            try {
                for (var a, o = t[Symbol.iterator](); !(r = (a = o.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
            } catch (t) {
                s = !0, i = t
            } finally {
                try {
                    r || null == o.return || o.return()
                } finally {
                    if (s) throw i
                }
            }
            return n
        }(t, e) || function(t, e) {
            if (!t) return;
            if ("string" == typeof t) return Ht(t, e);
            var n = Object.prototype.toString.call(t).slice(8, -1);
            "Object" === n && t.constructor && (n = t.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(t);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return Ht(t, e)
        }(t, e) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function Ht(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
        return r
    }

    function Kt(t, e, n, r, s, i, a) {
        try {
            var o = t[i](a),
                c = o.value
        } catch (t) {
            return void n(t)
        }
        o.done ? e(c) : Promise.resolve(c).then(r, s)
    }

    function Gt(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise((function(r, s) {
                var i = t.apply(e, n);

                function a(t) {
                    Kt(i, r, s, a, o, "next", t)
                }

                function o(t) {
                    Kt(i, r, s, a, o, "throw", t)
                }
                a(void 0)
            }))
        }
    }
    var Qt, Jt, Zt, Xt, te = {
            mixins: [i, qt, Mt],
            props: {
                emptyText: String,
                saveData: Object,
                nextStepkey: String,
                defaultUseProp: Boolean,
                firstCreate: Boolean,
                stepKey: String
            },
            data: function() {
                return {
                    nextVerifyStep: "normal_verify",
                    nextStepResolve: null,
                    nextStepReject: null,
                    status: {
                        showError: !1,
                        showSucc: !1
                    },
                    defaultUseDisabled: !1,
                    authInfo: {
                        desc: _T("mail", "mail_syncpage_desc"),
                        btnText: _T("mail", "sync_contact"),
                        unsyncText: _T("mail", "unsync_contact"),
                        syncSuccess: _T("mail", "sync_success"),
                        syncFailed: _T("mail", "sync_fail"),
                        verified: !1
                    },
                    authNote: {
                        cls: "",
                        text: ""
                    },
                    btnText: this.T("mail", "sync_contact"),
                    currentData: this.saveData,
                    fields: {
                        senderName: null,
                        account: null,
                        password: null,
                        defaultUse: !1
                    },
                    rules: {
                        account: {
                            validator: h({
                                required: !0
                            })
                        },
                        password: {
                            required: !0
                        }
                    }
                }
            },
            computed: {
                testParams: function() {
                    return {
                        email_type: this.currentData.email_type,
                        account: this.fields.account,
                        passwd: this.fields.password,
                        auth: !0,
                        tls: !0
                    }
                },
                params: function() {
                    return {
                        email_type: this.currentData.email_type,
                        account: this.fields.account,
                        passwd: this.fields.password,
                        auth: !0,
                        tls: !0,
                        sender_account: this.fields.senderAccount,
                        sender_name: this.fields.senderName,
                        is_default: this.fields.defaultUse
                    }
                },
                filterCurrentData: function() {
                    var t = Object.assign({}, this.currentData);
                    for (var e in t) null !== t[e] && void 0 !== t[e] || delete t[e];
                    return t
                }
            },
            watch: {
                firstCreate: {
                    handler: function(t) {
                        this.fields.defaultUse = t, this.defaultUseDisabled = t
                    },
                    immediate: !0
                },
                "saveData.email_type": function(t) {
                    this.nextVerifyStep = "aolmail" === t ? null : "normal_verify"
                }
            },
            mounted: function() {},
            methods: {
                onSyncClick: function() {
                    !1 === this.authInfo.verified ? this.onVerifyAuth() : this.onCancelAuth()
                },
                finished: (Xt = Gt(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.$options.window.setStatusBusy(), Object.assign(this.currentData, this.params), this.currentData.alias = this.currentData.account || this.currentData.sender_account, this.currentData.is_default = this.fields.defaultUse, this.currentData.sender_name = this.params.sender_name || this.params.sender_account, t.prev = 5, t.next = 8, synowebapi.promises.request({
                                    api: "SYNO.PersonMailAccount",
                                    method: "set",
                                    version: 1,
                                    params: this.filterCurrentData,
                                    encryption: ["passwd", "access_token", "refresh_token"]
                                });
                            case 8:
                                this.$emit("update:saveData", this.currentData), this.$emit("close"), t.next = 15;
                                break;
                            case 12:
                                t.prev = 12, t.t0 = t.catch(5), this.$emit("display-error", t.t0);
                            case 15:
                                return t.prev = 15, this.$options.window.clearStatusBusy(), t.finish(15);
                            case 18:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [5, 12, 15, 18]
                    ])
                }))), function() {
                    return Xt.apply(this, arguments)
                }),
                onClickMessageBtn: (Zt = Gt(regeneratorRuntime.mark((function t(e) {
                    var n, r, s, i;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (this.nextStepResolve && this.nextStepReject) {
                                    t.next = 2;
                                    break
                                }
                                return t.abrupt("return");
                            case 2:
                                if ("confirm" !== e) {
                                    t.next = 16;
                                    break
                                }
                                return t.next = 5, this.testConnect();
                            case 5:
                                if (n = t.sent, r = Vt(n, 2), s = r[0], i = r[1], !1 !== s) {
                                    t.next = 13;
                                    break
                                }
                                return this.$emit("display-error", i), this.nextStepReject(), t.abrupt("return");
                            case 13:
                                this.nextStepResolve(), t.next = 17;
                                break;
                            case 16:
                                this.nextStepReject();
                            case 17:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function(t) {
                    return Zt.apply(this, arguments)
                }),
                prepareToNext: function() {
                    var t = this;
                    return new Promise((function(e, n) {
                        t.nextStepResolve = e, t.nextStepReject = n;
                        var r = It(t.currentData.email_type),
                            s = String.format(t.T("mail", "email_setting_alert"), t.fields.account, r);
                        Yt(t.fields.account, t.currentData.email_type) ? t.$options.window.getMsgBox().confirm("", s).then((function(e) {
                            t.onClickMessageBtn(e)
                        })) : t.testConnect().then((function(r) {
                            var s = Vt(r, 2),
                                i = s[0],
                                a = s[1];
                            if (!1 === i) return "validate" === a ? t.$options.window.getMsgBox().alert("", _T("mail", "mail_setting_error")) : a && a.code ? t.$emit("display-error", a) : t.$options.window.getMsgBox().alert("", _T("mail", "mail_setting_error")), n(), !1;
                            e()
                        }))
                    }))
                },
                onTestConnect: (Jt = Gt(regeneratorRuntime.mark((function t() {
                    var e, n, r, s;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.status.showError = !1, this.status.showSucc = !1, t.next = 4, this.testConnect();
                            case 4:
                                e = t.sent, n = Vt(e, 2), r = n[0], s = n[1], !0 === r ? this.status.showSucc = !0 : "validate" === s ? this.$options.window.getMsgBox().alert("", _T("common", "forminvalid")) : this.status.showError = !0;
                            case 9:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return Jt.apply(this, arguments)
                }),
                testConnect: (Qt = Gt(regeneratorRuntime.mark((function t() {
                    var e, n;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.$options.window.setStatusBusy(), t.next = 3, this.$refs.form.validate();
                            case 3:
                                if (e = t.sent) {
                                    t.next = 7;
                                    break
                                }
                                return this.$options.window.clearStatusBusy(), t.abrupt("return", [!1, "validate"]);
                            case 7:
                                return t.prev = 7, t.next = 10, synowebapi.promises.request({
                                    api: "SYNO.PersonMailAccount",
                                    method: "test",
                                    version: 1,
                                    params: this.testParams,
                                    encryption: ["passwd"]
                                });
                            case 10:
                                e = !0, t.next = 17;
                                break;
                            case 13:
                                t.prev = 13, t.t0 = t.catch(7), n = t.t0, e = !1;
                            case 17:
                                return t.prev = 17, this.$options.window.clearStatusBusy(), t.finish(17);
                            case 20:
                                return t.abrupt("return", [e, n]);
                            case 21:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [7, 13, 17, 20]
                    ])
                }))), function() {
                    return Qt.apply(this, arguments)
                })
            }
        },
        ee = (n(77), d(te, Wt, [], !1, null, null, null));
    ee.options.__file = "src/email-wizard-steps/normal-email-setting.vue";
    var ne = ee.exports,
        re = function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-wizard-step", {
                staticClass: "syno-sds-personalsetting-synomail-setting",
                attrs: {
                    "syno-id": "email-wizard-steps-synomail-setting-wizard-step-0",
                    "step-key": "synomail_setting",
                    headline: t.T("mail", "email_settings_title"),
                    finished: t.finished
                },
                on: {
                    activate: t.onActivate
                }
            }, [n("v-form", {
                ref: "form",
                attrs: {
                    "syno-id": "email-wizard-steps-synomail-setting-form-0",
                    model: t.fields
                }
            }, [n("div", {
                staticClass: "desc"
            }, [t._v("\n\t\t\t" + t._s(t.T("mail", "synomail_desc")) + "\n\t\t")]), t._v(" "), n("v-form-item", {
                attrs: {
                    label: t.T("notification", "alert_smtp_user")
                }
            }, [n("v-select", {
                ref: "select",
                attrs: {
                    "syno-id": "email-wizard-steps-synomail-setting-select-0",
                    name: "select",
                    options: t.synomail,
                    readonly: ""
                },
                model: {
                    value: t.fields.account,
                    callback: function(e) {
                        t.$set(t.fields, "account", e)
                    },
                    expression: "fields.account"
                }
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    prop: "defaultUse",
                    "hide-label": ""
                }
            }, [n("v-checkbox", {
                attrs: {
                    "syno-id": "email-wizard-steps-synomail-setting-checkbox-0",
                    disabled: t.defaultUseDisabled
                },
                model: {
                    value: t.fields.defaultUse,
                    callback: function(e) {
                        t.$set(t.fields, "defaultUse", e)
                    },
                    expression: "fields.defaultUse"
                }
            }, [t._v("\n\t\t\t\t" + t._s(t.T("mail", "default_use_checkbox")) + "\n\t\t\t")])], 1)], 1)], 1)
        };

    function se(t, e, n, r, s, i, a) {
        try {
            var o = t[i](a),
                c = o.value
        } catch (t) {
            return void n(t)
        }
        o.done ? e(c) : Promise.resolve(c).then(r, s)
    }

    function ie(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise((function(r, s) {
                var i = t.apply(e, n);

                function a(t) {
                    se(i, r, s, a, o, "next", t)
                }

                function o(t) {
                    se(i, r, s, a, o, "throw", t)
                }
                a(void 0)
            }))
        }
    }

    function ae(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            })))), r.forEach((function(e) {
                oe(t, e, n[e])
            }))
        }
        return t
    }

    function oe(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }
    re._withStripped = !0;
    var ce, le = {
            mixins: [i, Mt],
            props: {
                emptyText: String,
                saveData: Object,
                defaultUseProp: Boolean,
                firstCreate: Boolean,
                stepKey: String
            },
            data: function() {
                return {
                    status: {
                        showError: !1,
                        showSucc: !1
                    },
                    defaultUseDisabled: !1,
                    currentData: this.saveData,
                    fields: {
                        senderName: null,
                        account: null,
                        password: null,
                        defaultUse: !1
                    }
                }
            },
            mounted: function() {},
            methods: ae({}, Object(o.mapActions)("MailModule", ["getSynoMailConfig"]), {
                onActivate: (ce = ie(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.$options.window.setStatusBusy(), t.next = 3, this.getSynoMailConfig();
                            case 3:
                                this.synomail.length > 0 && this.$refs.select.select(0), this.$options.window.clearStatusBusy();
                            case 5:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return ce.apply(this, arguments)
                }),
                finished: function() {
                    var t = ie(regeneratorRuntime.mark((function t() {
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return this.$options.window.setStatusBusy(), Object.assign(this.currentData, this.params), this.currentData.alias = this.currentData.account || this.currentData.sender_account, this.currentData.is_default = this.fields.defaultUse, this.currentData.sender_name = this.params.sender_name || this.params.sender_account, t.prev = 5, t.next = 8, synowebapi.promises.request({
                                        api: "SYNO.PersonMailAccount",
                                        method: "set",
                                        version: 1,
                                        params: this.filterCurrentData,
                                        encryption: ["passwd"]
                                    });
                                case 8:
                                    this.$emit("update:saveData", this.currentData), this.$emit("close"), t.next = 15;
                                    break;
                                case 12:
                                    t.prev = 12, t.t0 = t.catch(5), this.$emit("display-error", t.t0);
                                case 15:
                                    return t.prev = 15, this.$options.window.clearStatusBusy(), t.finish(15);
                                case 18:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this, [
                            [5, 12, 15, 18]
                        ])
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }),
            computed: ae({}, Object(o.mapState)("MailModule", ["synomail"]), {
                params: function() {
                    return {
                        email_type: this.currentData.email_type,
                        account: this.fields.account,
                        passwd: this.fields.password,
                        auth: !0,
                        tls: !0,
                        sender_account: this.fields.senderAccount,
                        sender_name: this.fields.senderName,
                        is_default: this.fields.defaultUse
                    }
                },
                filterCurrentData: function() {
                    var t = Object.assign({}, this.currentData);
                    for (var e in t) null !== t[e] && void 0 !== t[e] || delete t[e];
                    return t
                }
            }),
            watch: {
                firstCreate: {
                    handler: function(t) {
                        this.fields.defaultUse = t, this.defaultUseDisabled = t
                    },
                    immediate: !0
                }
            }
        },
        ue = (n(78), d(le, re, [], !1, null, null, null));
    ue.options.__file = "src/email-wizard-steps/synomail-setting.vue";
    var pe = ue.exports,
        de = function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-wizard-step", {
                staticClass: "syno-sds-personalsetting-custom-email-setting",
                attrs: {
                    "syno-id": "email-wizard-steps-custom-email-setting-wizard-step-0",
                    "step-key": t.stepKey,
                    headline: t.T("mail", "email_settings_title"),
                    finished: t.finished
                }
            }, [n("v-form", {
                ref: "form",
                attrs: {
                    "syno-id": "email-wizard-steps-custom-email-setting-form-0",
                    model: t.fields,
                    rules: t.rules
                }
            }, [n("v-form-item", {
                attrs: {
                    label: t.T("notification", "alert_smtp") + ":",
                    prop: "host"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "email-wizard-steps-custom-email-setting-input-0",
                    name: "host"
                },
                model: {
                    value: t.fields.host,
                    callback: function(e) {
                        t.$set(t.fields, "host", e)
                    },
                    expression: "fields.host"
                }
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    label: t.T("notification", "alert_port") + ":",
                    prop: "port"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "email-wizard-steps-custom-email-setting-input-1",
                    name: "port"
                },
                model: {
                    value: t.fields.port,
                    callback: function(e) {
                        t.$set(t.fields, "port", e)
                    },
                    expression: "fields.port"
                }
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    prop: "enableAuth",
                    "hide-label": ""
                }
            }, [n("v-checkbox", {
                attrs: {
                    "syno-id": "email-wizard-steps-custom-email-setting-checkbox-0"
                },
                model: {
                    value: t.fields.enableAuth,
                    callback: function(e) {
                        t.$set(t.fields, "enableAuth", e)
                    },
                    expression: "fields.enableAuth"
                }
            }, [t._v("\n\t\t\t\t" + t._s(t.T("notification", "alert_smtp_need_auth")) + "\n\t\t\t")])], 1), t._v(" "), n("v-form-item", {
                staticClass: "indent-1",
                attrs: {
                    label: t.T("notification", "alert_smtp_user") + ":",
                    prop: "account"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "email-wizard-steps-custom-email-setting-input-2",
                    name: "account",
                    disabled: !t.fields.enableAuth
                },
                model: {
                    value: t.fields.account,
                    callback: function(e) {
                        t.$set(t.fields, "account", e)
                    },
                    expression: "fields.account"
                }
            })], 1), t._v(" "), n("v-form-item", {
                staticClass: "indent-1",
                attrs: {
                    label: t.T("notification", "alert_smtp_pass") + ":",
                    prop: "password"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "email-wizard-steps-custom-email-setting-input-3",
                    name: "password",
                    type: "password",
                    disabled: !t.fields.enableAuth
                },
                model: {
                    value: t.fields.password,
                    callback: function(e) {
                        t.$set(t.fields, "password", e)
                    },
                    expression: "fields.password"
                }
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    prop: "tls",
                    "hide-label": ""
                }
            }, [n("v-checkbox", {
                attrs: {
                    "syno-id": "email-wizard-steps-custom-email-setting-checkbox-1"
                },
                model: {
                    value: t.fields.tls,
                    callback: function(e) {
                        t.$set(t.fields, "tls", e)
                    },
                    expression: "fields.tls"
                }
            }, [t._v("\n\t\t\t\t" + t._s(t.T("notification", "alert_use_ssl")) + "\n\t\t\t")])], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    label: t.T("notification", "label_smtp_sender_mail") + ":",
                    prop: "senderAccount"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "email-wizard-steps-custom-email-setting-input-4",
                    name: "senderAccount"
                },
                model: {
                    value: t.fields.senderAccount,
                    callback: function(e) {
                        t.$set(t.fields, "senderAccount", e)
                    },
                    expression: "fields.senderAccount"
                }
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    label: t.T("notification", "label_smtp_sender_name") + ":",
                    prop: "senderName"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "email-wizard-steps-custom-email-setting-input-5",
                    name: "senderName",
                    placeholder: t.emptyText
                },
                model: {
                    value: t.fields.senderName,
                    callback: function(e) {
                        t.$set(t.fields, "senderName", e)
                    },
                    expression: "fields.senderName"
                }
            }), t._v(" "), n("v-whitetip", {
                attrs: {
                    slot: "after",
                    content: String.format(t.T("mail", "sender_name_hint"), t.T("notification", "label_smtp_sender_mail"))
                },
                slot: "after"
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    prop: "defaultUse",
                    "hide-label": ""
                }
            }, [n("v-checkbox", {
                attrs: {
                    "syno-id": "email-wizard-steps-custom-email-setting-checkbox-2",
                    disabled: t.defaultUseDisabled
                },
                model: {
                    value: t.fields.defaultUse,
                    callback: function(e) {
                        t.$set(t.fields, "defaultUse", e)
                    },
                    expression: "fields.defaultUse"
                }
            }, [t._v("\n\t\t\t\t" + t._s(t.T("mail", "default_use_checkbox")) + "\n\t\t\t")])], 1), t._v(" "), n("div", {
                staticClass: "composite"
            }, [n("v-button", {
                attrs: {
                    "syno-id": "email-wizard-steps-custom-email-setting-button-0"
                },
                on: {
                    click: t.onTestConnect
                }
            }, [t._v("\n\t\t\t\t" + t._s(t.T("mail", "mail_test_connection")) + "\n\t\t\t")]), t._v(" "), n("span", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: t.status.showSucc,
                    expression: "status.showSucc"
                }],
                staticClass: "succ-icon"
            }), t._v(" "), n("span", {
                directives: [{
                    name: "show",
                    rawName: "v-show",
                    value: t.status.showError,
                    expression: "status.showError"
                }],
                staticClass: "status-error"
            }, [t._v("\n\t\t\t\t" + t._s(t.T("mail", "mail_setting_error")) + "\n\t\t\t")])], 1)], 1)], 1)
        };

    function fe(t, e) {
        return function(t) {
            if (Array.isArray(t)) return t
        }(t) || function(t, e) {
            if ("undefined" == typeof Symbol || !(Symbol.iterator in Object(t))) return;
            var n = [],
                r = !0,
                s = !1,
                i = void 0;
            try {
                for (var a, o = t[Symbol.iterator](); !(r = (a = o.next()).done) && (n.push(a.value), !e || n.length !== e); r = !0);
            } catch (t) {
                s = !0, i = t
            } finally {
                try {
                    r || null == o.return || o.return()
                } finally {
                    if (s) throw i
                }
            }
            return n
        }(t, e) || function(t, e) {
            if (!t) return;
            if ("string" == typeof t) return me(t, e);
            var n = Object.prototype.toString.call(t).slice(8, -1);
            "Object" === n && t.constructor && (n = t.constructor.name);
            if ("Map" === n || "Set" === n) return Array.from(t);
            if ("Arguments" === n || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(n)) return me(t, e)
        }(t, e) || function() {
            throw new TypeError("Invalid attempt to destructure non-iterable instance.\nIn order to be iterable, non-array objects must have a [Symbol.iterator]() method.")
        }()
    }

    function me(t, e) {
        (null == e || e > t.length) && (e = t.length);
        for (var n = 0, r = new Array(e); n < e; n++) r[n] = t[n];
        return r
    }

    function he(t, e, n, r, s, i, a) {
        try {
            var o = t[i](a),
                c = o.value
        } catch (t) {
            return void n(t)
        }
        o.done ? e(c) : Promise.resolve(c).then(r, s)
    }

    function ve(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise((function(r, s) {
                var i = t.apply(e, n);

                function a(t) {
                    he(i, r, s, a, o, "next", t)
                }

                function o(t) {
                    he(i, r, s, a, o, "throw", t)
                }
                a(void 0)
            }))
        }
    }
    de._withStripped = !0;
    var _e = {
            mixins: [i, Mt],
            props: {
                emptyText: String,
                saveData: Object,
                nextStepkey: String,
                firstCreate: Boolean,
                stepKey: String
            },
            data: function() {
                return {
                    currentData: this.saveData,
                    status: {
                        showError: !1,
                        showSucc: !1
                    },
                    showStatusError: !1,
                    defaultUseDisabled: !1,
                    fields: {
                        host: null,
                        port: null,
                        enableAuth: !1,
                        account: null,
                        password: null,
                        tls: !1,
                        senderAccount: null,
                        senderName: null,
                        defaultUse: !1
                    },
                    rules: {
                        host: {
                            required: !0
                        },
                        port: {
                            required: !0
                        },
                        account: {
                            required: !0
                        },
                        password: {
                            required: !0
                        },
                        senderAccount: {
                            validator: h({
                                required: !0
                            })
                        }
                    }
                }
            },
            computed: {
                imgStatusSrc: function() {
                    return SYNO.SDS.UIFeatures.test("isRetina") ? "../../../webman/modules/PersonalSettings/images/2x/icon_success.png" : "../../../webman/modules/PersonalSettings/images/1x/icon_success.png"
                },
                params: function() {
                    return {
                        email_type: this.currentData.email_type,
                        account: this.fields.account,
                        passwd: this.fields.password,
                        host: this.fields.host,
                        port: this.fields.port,
                        auth: this.fields.enableAuth,
                        tls: this.fields.tls,
                        sender_account: this.fields.senderAccount,
                        sender_name: this.fields.senderName
                    }
                }
            },
            watch: {
                firstCreate: {
                    handler: function(t) {
                        this.fields.defaultUse = t, this.defaultUseDisabled = t
                    },
                    immediate: !0
                }
            },
            mounted: function() {},
            methods: {
                onTestConnect: function() {
                    var t = ve(regeneratorRuntime.mark((function t() {
                        var e, n;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return this.status.showError = !1, this.status.showSucc = !1, t.next = 4, this.$refs.form.validate();
                                case 4:
                                    if (t.sent) {
                                        t.next = 8;
                                        break
                                    }
                                    return this.$options.window.getMsgBox().alert("", _T("common", "forminvalid")), t.abrupt("return", !1);
                                case 8:
                                    return t.next = 10, this.testConnect();
                                case 10:
                                    e = t.sent, n = fe(e, 1), !0 === n[0] ? this.status.showSucc = !0 : this.status.showError = !0;
                                case 14:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this)
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                testConnect: function() {
                    var t = ve(regeneratorRuntime.mark((function t() {
                        var e, n;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return this.$options.window.setStatusBusy(), t.prev = 1, t.next = 4, synowebapi.promises.request({
                                        api: "SYNO.PersonMailAccount",
                                        method: "test",
                                        version: 1,
                                        params: this.params,
                                        encryption: ["passwd"]
                                    });
                                case 4:
                                    e = !0, t.next = 11;
                                    break;
                                case 7:
                                    t.prev = 7, t.t0 = t.catch(1), n = t.t0, e = !1;
                                case 11:
                                    return t.prev = 11, this.$options.window.clearStatusBusy(), t.finish(11);
                                case 14:
                                    return t.abrupt("return", [e, n]);
                                case 15:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this, [
                            [1, 7, 11, 14]
                        ])
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                finished: function() {
                    var t = ve(regeneratorRuntime.mark((function t() {
                        var e, n, r, s;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return t.next = 2, this.$refs.form.validate();
                                case 2:
                                    if (t.sent) {
                                        t.next = 6;
                                        break
                                    }
                                    return this.$options.window.getMsgBox().alert("", _T("common", "forminvalid")), t.abrupt("return");
                                case 6:
                                    return t.next = 8, this.testConnect();
                                case 8:
                                    if (e = t.sent, n = fe(e, 2), r = n[0], s = n[1], !1 !== r) {
                                        t.next = 15;
                                        break
                                    }
                                    return s && s.code ? this.$emit("display-error", s) : this.$options.window.getMsgBox().alert("", _T("mail", "mail_setting_error")), t.abrupt("return");
                                case 15:
                                    return this.$options.window.setStatusBusy(), Object.assign(this.currentData, this.params), this.currentData.alias = this.params.host + "_" + (this.params.account || this.params.sender_account), this.currentData.is_default = this.fields.defaultUse, this.currentData.sender_name = this.params.sender_name || this.params.sender_account, t.prev = 20, t.next = 23, synowebapi.promises.request({
                                        api: "SYNO.PersonMailAccount",
                                        method: "set",
                                        version: 1,
                                        params: this.currentData,
                                        encryption: ["passwd"]
                                    });
                                case 23:
                                    this.$emit("update:saveData", this.currentData), this.$emit("close"), t.next = 30;
                                    break;
                                case 27:
                                    t.prev = 27, t.t0 = t.catch(20), this.$emit("display-error", t.t0);
                                case 30:
                                    return t.prev = 30, this.$options.window.clearStatusBusy(), t.finish(30);
                                case 33:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this, [
                            [20, 27, 30, 33]
                        ])
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }()
            }
        },
        ge = (n(79), d(_e, de, [], !1, null, null, null));
    ge.options.__file = "src/email-wizard-steps/custom-email-setting.vue";
    var be = ge.exports,
        ye = function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("div", [n("v-wizard-step", {
                staticClass: "syno-sds-personalsetting-gmail-setting",
                attrs: {
                    "syno-id": "email-wizard-steps-gmail-setting-wizard-step-0",
                    "step-key": "gmail_setting",
                    "next-step-key": "gmail_verify",
                    headline: t.T("mail", "email_settings_title")
                }
            }, [n("v-form", {
                ref: "form",
                attrs: {
                    "syno-id": "email-wizard-steps-gmail-setting-form-0",
                    model: t.fields
                }
            }, [n("v-form-item", {
                attrs: {
                    label: t.T("notification", "label_smtp_sender_name") + ":",
                    prop: "senderName"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "email-wizard-steps-gmail-setting-input-0",
                    name: "senderName",
                    placeholder: t.emptyText
                },
                model: {
                    value: t.fields.senderName,
                    callback: function(e) {
                        t.$set(t.fields, "senderName", e)
                    },
                    expression: "fields.senderName"
                }
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    prop: "defaultUse"
                }
            }, [n("v-checkbox", {
                attrs: {
                    "syno-id": "email-wizard-steps-gmail-setting-checkbox-0",
                    disabled: t.defaultUseDisabled
                },
                model: {
                    value: t.fields.defaultUse,
                    callback: function(e) {
                        t.$set(t.fields, "defaultUse", e)
                    },
                    expression: "fields.defaultUse"
                }
            }, [t._v("\n\t\t\t\t\t" + t._s(t.T("mail", "default_use_checkbox")) + "\n\t\t\t\t")])], 1)], 1)], 1), t._v(" "), n("v-wizard-step", {
                staticClass: "syno-sds-personalsetting-gmail-verify",
                attrs: {
                    "syno-id": "email-wizard-steps-gmail-setting-wizard-step-1",
                    "step-key": "gmail_verify",
                    headline: t.T("mail", "mail_gmail_title"),
                    finished: t.finished
                },
                on: {
                    activate: t.verifyActivate,
                    deactivate: t.verifyDeactivate
                }
            }, [n("v-form", {
                ref: "form",
                attrs: {
                    "syno-id": "email-wizard-steps-gmail-setting-form-1",
                    model: t.fields
                }
            }, [n("div", {
                staticClass: "desc"
            }, [t._v("\n\t\t\t\t" + t._s(t.T("mail", "mail_gmail_desc")) + "\n\t\t\t")]), t._v(" "), n("div", {
                staticClass: "auth-info"
            }, [n("v-button", {
                attrs: {
                    "syno-id": "email-wizard-steps-gmail-setting-button-0"
                },
                on: {
                    click: t.onAuthClick
                }
            }, [t._v("\n\t\t\t\t\t" + t._s(t.btnText) + "\n\t\t\t\t")]), t._v(" "), n("span", {
                staticClass: "note",
                class: t.authNote.cls
            }, [t._v("\n\t\t\t\t\t" + t._s(t.authNote.text) + "\n\t\t\t\t")])], 1)])], 1)], 1)
        };

    function we(t, e, n, r, s, i, a) {
        try {
            var o = t[i](a),
                c = o.value
        } catch (t) {
            return void n(t)
        }
        o.done ? e(c) : Promise.resolve(c).then(r, s)
    }
    ye._withStripped = !0;
    var Se = {
            mixins: [i, qt, Mt],
            props: {
                emptyText: String,
                saveData: Object,
                nextStepkey: String,
                defaultUseProp: Boolean,
                firstCreate: Boolean,
                stepKey: String
            },
            data: function() {
                return {
                    authInfo: {
                        desc: _T("mail", "mail_gmail_desc"),
                        btnText: _T("mail", "mail_authentication"),
                        unsyncText: _T("mail", "mail_reauth"),
                        syncSuccess: _T("mail", "mail_authentication_success"),
                        syncFailed: _T("mail", "sync_fail"),
                        verified: !1
                    },
                    defaultUseDisabled: !1,
                    authNote: {
                        cls: "",
                        text: ""
                    },
                    verified: !1,
                    btnText: this.T("mail", "mail_authentication"),
                    currentData: this.saveData,
                    fields: {
                        senderName: null,
                        defaultUse: !1
                    }
                }
            },
            computed: {
                params: function() {
                    return {
                        sender_name: this.fields.senderName,
                        is_default: this.fields.defaultUse
                    }
                },
                filterCurrentData: function() {
                    var t = Object.assign({}, this.currentData);
                    for (var e in t) null !== t[e] && void 0 !== t[e] || delete t[e];
                    return t
                }
            },
            watch: {
                firstCreate: {
                    handler: function(t) {
                        this.fields.defaultUse = t, this.defaultUseDisabled = t
                    },
                    immediate: !0
                },
                "authInfo.verified": function(t) {
                    t ? this.$emit("disable-footer-button", "next", !1) : this.$emit("disable-footer-button", "next", !0)
                }
            },
            mounted: function() {},
            methods: {
                onAuthClick: function() {
                    !1 === this.authInfo.verified ? this.onVerifyAuth() : this.onCancelAuth()
                },
                verifyActivate: function() {
                    !1 === this.authInfo.verified && this.$emit("disable-footer-button", "next", !0)
                },
                verifyDeactivate: function() {
                    this.$emit("disable-footer-button", "next", !1)
                },
                finished: function() {
                    var t, e = (t = regeneratorRuntime.mark((function t() {
                        var e;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return Object.assign(this.currentData, this.params), this.currentData.alias = this.currentData.account || this.currentData.sender_account || "", this.currentData.sender_name = this.currentData.sender_name || this.currentData.account, this.$options.window.setStatusBusy(), t.prev = 4, t.next = 7, synowebapi.promises.request({
                                        api: "SYNO.PersonMailAccount",
                                        method: "set",
                                        version: 1,
                                        params: this.filterCurrentData,
                                        encryption: ["passwd", "access_token", "refresh_token"]
                                    });
                                case 7:
                                    e = t.sent, this.currentData.alias = e.account.alias, this.$emit("update:saveData", this.currentData), this.$emit("close"), t.next = 16;
                                    break;
                                case 13:
                                    t.prev = 13, t.t0 = t.catch(4), this.$emit("display-error", t.t0);
                                case 16:
                                    return t.prev = 16, this.$options.window.clearStatusBusy(), t.finish(16);
                                case 19:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this, [
                            [4, 13, 16, 19]
                        ])
                    })), function() {
                        var e = this,
                            n = arguments;
                        return new Promise((function(r, s) {
                            var i = t.apply(e, n);

                            function a(t) {
                                we(i, r, s, a, o, "next", t)
                            }

                            function o(t) {
                                we(i, r, s, a, o, "throw", t)
                            }
                            a(void 0)
                        }))
                    });
                    return function() {
                        return e.apply(this, arguments)
                    }
                }()
            }
        },
        xe = (n(80), d(Se, ye, [], !1, null, null, null));

    function ke(t, e, n, r, s, i, a) {
        try {
            var o = t[i](a),
                c = o.value
        } catch (t) {
            return void n(t)
        }
        o.done ? e(c) : Promise.resolve(c).then(r, s)
    }
    xe.options.__file = "src/email-wizard-steps/gmail-setting.vue";
    var Te, De, Oe = d({
        components: {
            Welcome: Lt,
            NormalEmailSetting: ne,
            CustomEmailSetting: be,
            GmailSetting: xe.exports,
            SynoMailSetting: pe
        },
        mixins: [i],
        props: {
            firstCreate: {
                type: Boolean,
                default: !1
            }
        },
        data: function() {
            return {
                saveData: {
                    email_type: null,
                    alias: null,
                    auth: null,
                    tls: null,
                    test_connect: null,
                    is_default: null,
                    sender_name: null,
                    access_token: null,
                    refresh_token: null,
                    expires_in: null
                },
                nextStepDisabled: !1,
                previousStepDisabled: !1,
                emptyText: null
            }
        },
        watch: {},
        mounted: function() {},
        methods: {
            displayError: function(t) {
                var e = this.T("error", "error_error_system");
                if (t.code) {
                    var n = t.code;
                    8006 === n ? e = this.T("mail", "account_already_saved") : 8011 === n ? e = this.T("mail", "mail_setting_error") : 8014 === n && (e = this.T("mail", "mail_contact_error"))
                }
                this.$refs.window.getMsgBox().alert("", e)
            },
            disableFooterButton: function(t, e) {
                "next" === t ? this.nextStepDisabled = e : this.previousStepDisabled = e
            },
            onClose: (Te = regeneratorRuntime.mark((function t() {
                return regeneratorRuntime.wrap((function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return t.next = 2, this.$nextTick();
                        case 2:
                            this.saveData.is_default && (SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_type", this.saveData.email_type), SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_alias", this.saveData.alias)), this.$refs.window.close();
                        case 4:
                        case "end":
                            return t.stop()
                    }
                }), t, this)
            })), De = function() {
                var t = this,
                    e = arguments;
                return new Promise((function(n, r) {
                    var s = Te.apply(t, e);

                    function i(t) {
                        ke(s, n, r, i, a, "next", t)
                    }

                    function a(t) {
                        ke(s, n, r, i, a, "throw", t)
                    }
                    i(void 0)
                }))
            }, function() {
                return De.apply(this, arguments)
            })
        }
    }, Ut, [], !1, null, null, null);
    Oe.options.__file = "src/windows/email-wizard.vue";
    var Pe = Oe.exports,
        Ce = function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-modal-window", {
                ref: "window",
                attrs: {
                    "syno-id": "windows-email-edit-modal-window-0",
                    width: "492",
                    height: "auto",
                    "show-close": !1,
                    title: t.T("common", "alt_edit")
                }
            }, [n("div", {
                staticClass: "syno-sds-personalsetting-email-edit"
            }, [n("v-panel", {
                attrs: {
                    "syno-id": "windows-email-edit-panel-0",
                    confirm: t.onConfirm,
                    cancel: t.onClose,
                    loading: t.loading,
                    "loading-type": "statusbar",
                    "fluid-footer": ""
                }
            }, [t.isSynomail ? n("v-form", {
                ref: "form",
                attrs: {
                    slot: "body",
                    "syno-id": "windows-email-edit-form-0"
                },
                slot: "body"
            }, [n("div", {
                staticClass: "desc"
            }, [t._v("\n\t\t\t\t\t" + t._s(t.T("mail", "synomail_desc")) + "\n\t\t\t\t")]), t._v(" "), n("v-form-item", {
                attrs: {
                    label: t.T("notification", "alert_smtp_user") + ":"
                }
            }, [n("v-select", {
                ref: "select",
                attrs: {
                    "syno-id": "windows-email-edit-select-0",
                    name: "select",
                    options: t.synomail,
                    readonly: ""
                },
                model: {
                    value: t.fields.account,
                    callback: function(e) {
                        t.$set(t.fields, "account", e)
                    },
                    expression: "fields.account"
                }
            })], 1)], 1) : t.isCustomize ? n("v-form", {
                ref: "form",
                attrs: {
                    slot: "body",
                    "syno-id": "windows-email-edit-form-1",
                    model: t.fields,
                    rules: t.rules
                },
                slot: "body"
            }, [n("v-form-item", {
                attrs: {
                    label: t.T("notification", "alert_smtp") + ":",
                    prop: "host"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "windows-email-edit-input-0",
                    name: "host"
                },
                model: {
                    value: t.fields.host,
                    callback: function(e) {
                        t.$set(t.fields, "host", e)
                    },
                    expression: "fields.host"
                }
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    label: t.T("notification", "alert_port") + ":",
                    prop: "port"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "windows-email-edit-input-1",
                    name: "port"
                },
                model: {
                    value: t.fields.port,
                    callback: function(e) {
                        t.$set(t.fields, "port", e)
                    },
                    expression: "fields.port"
                }
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    prop: "enableAuth",
                    "hide-label": ""
                }
            }, [n("v-checkbox", {
                attrs: {
                    "syno-id": "windows-email-edit-checkbox-0"
                },
                model: {
                    value: t.fields.enableAuth,
                    callback: function(e) {
                        t.$set(t.fields, "enableAuth", e)
                    },
                    expression: "fields.enableAuth"
                }
            }, [t._v("\n\t\t\t\t\t\t" + t._s(t.T("notification", "alert_smtp_need_auth")) + "\n\t\t\t\t\t")])], 1), t._v(" "), n("v-form-item", {
                staticClass: "indent-1",
                attrs: {
                    label: t.T("notification", "alert_smtp_user") + ":",
                    prop: "account"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "windows-email-edit-input-2",
                    name: "account",
                    disabled: !t.fields.enableAuth
                },
                model: {
                    value: t.fields.account,
                    callback: function(e) {
                        t.$set(t.fields, "account", e)
                    },
                    expression: "fields.account"
                }
            })], 1), t._v(" "), n("v-form-item", {
                ref: "passwdField",
                staticClass: "indent-1",
                attrs: {
                    label: t.T("notification", "alert_smtp_pass") + ":",
                    prop: "password"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "windows-email-edit-input-3",
                    name: "password",
                    type: "password",
                    disabled: !t.fields.enableAuth,
                    "show-password-visibility-icon": !1
                },
                model: {
                    value: t.fields.password,
                    callback: function(e) {
                        t.$set(t.fields, "password", e)
                    },
                    expression: "fields.password"
                }
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    prop: "tls"
                }
            }, [n("v-checkbox", {
                attrs: {
                    "syno-id": "windows-email-edit-checkbox-1"
                },
                model: {
                    value: t.fields.tls,
                    callback: function(e) {
                        t.$set(t.fields, "tls", e)
                    },
                    expression: "fields.tls"
                }
            }, [t._v("\n\t\t\t\t\t\t" + t._s(t.T("notification", "alert_use_ssl")) + "\n\t\t\t\t\t")])], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    label: t.T("notification", "label_smtp_sender_mail") + ":",
                    prop: "senderAccount"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "windows-email-edit-input-4",
                    name: "senderAccount"
                },
                model: {
                    value: t.fields.senderAccount,
                    callback: function(e) {
                        t.$set(t.fields, "senderAccount", e)
                    },
                    expression: "fields.senderAccount"
                }
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    label: t.T("notification", "label_smtp_sender_name") + ":",
                    prop: "senderName"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "windows-email-edit-input-5",
                    name: "senderName"
                },
                model: {
                    value: t.fields.senderName,
                    callback: function(e) {
                        t.$set(t.fields, "senderName", e)
                    },
                    expression: "fields.senderName"
                }
            })], 1)], 1) : n("v-form", {
                ref: "form",
                attrs: {
                    slot: "body",
                    "syno-id": "windows-email-edit-form-2",
                    model: t.fields,
                    rules: t.rules
                },
                slot: "body"
            }, [n("v-form-item", {
                attrs: {
                    label: t.T("notification", "alert_smtp_user") + ":",
                    prop: "account"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "windows-email-edit-input-6",
                    name: "account",
                    disabled: t.isGmail
                },
                model: {
                    value: t.fields.account,
                    callback: function(e) {
                        t.$set(t.fields, "account", e)
                    },
                    expression: "fields.account"
                }
            })], 1), t._v(" "), t.isGmail ? t._e() : n("v-form-item", {
                ref: "passwdField",
                attrs: {
                    label: t.T("notification", "alert_smtp_pass") + ":",
                    prop: "password"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "windows-email-edit-input-7",
                    name: "password",
                    type: "password",
                    "show-password-visibility-icon": !1
                },
                model: {
                    value: t.fields.password,
                    callback: function(e) {
                        t.$set(t.fields, "password", e)
                    },
                    expression: "fields.password"
                }
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    label: t.T("notification", "label_smtp_sender_name") + ":",
                    prop: "senderName"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "windows-email-edit-input-8",
                    name: "senderName"
                },
                model: {
                    value: t.fields.senderName,
                    callback: function(e) {
                        t.$set(t.fields, "senderName", e)
                    },
                    expression: "fields.senderName"
                }
            })], 1), t._v(" "), n("div", {
                staticClass: "auth-info"
            }, [n("v-button", {
                attrs: {
                    "syno-id": "windows-email-edit-button-0"
                },
                on: {
                    click: t.onSyncClick
                }
            }, [t._v("\n\t\t\t\t\t\t" + t._s(t.btnText) + "\n\t\t\t\t\t")]), t._v(" "), n("span", {
                staticClass: "note",
                class: t.authNote.cls
            }, [t._v("\n\t\t\t\t\t\t" + t._s(t.authNote.text) + "\n\t\t\t\t\t")])], 1)], 1)], 1)], 1)])
        };

    function Ae(t, e, n, r, s, i, a) {
        try {
            var o = t[i](a),
                c = o.value
        } catch (t) {
            return void n(t)
        }
        o.done ? e(c) : Promise.resolve(c).then(r, s)
    }

    function je(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise((function(r, s) {
                var i = t.apply(e, n);

                function a(t) {
                    Ae(i, r, s, a, o, "next", t)
                }

                function o(t) {
                    Ae(i, r, s, a, o, "throw", t)
                }
                a(void 0)
            }))
        }
    }

    function Ne(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            })))), r.forEach((function(e) {
                Ee(t, e, n[e])
            }))
        }
        return t
    }

    function Ee(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }
    Ce._withStripped = !0;
    var $e, Ue = {
            components: {},
            mixins: [i, qt],
            props: {
                email: {
                    type: Object
                }
            },
            data: function() {
                return {
                    loading: !1,
                    _fields: null,
                    oldAlias: null,
                    reqParams: null,
                    btnText: _T("mail", "sync_contact"),
                    normalInfo: {
                        desc: _T("mail", "mail_syncpage_desc"),
                        btnText: _T("mail", "sync_contact"),
                        unsyncText: _T("mail", "unsync_contact"),
                        syncSuccess: _T("mail", "sync_success"),
                        syncFailed: _T("mail", "sync_fail"),
                        verified: !1
                    },
                    gmailInfo: {
                        desc: _T("mail", "mail_gmail_desc"),
                        btnText: _T("mail", "mail_authentication"),
                        unsyncText: _T("mail", "mail_reauth"),
                        syncSuccess: _T("mail", "mail_authentication_success"),
                        syncFailed: _T("mail", "sync_fail"),
                        verified: !1
                    },
                    authNote: {
                        cls: "",
                        text: ""
                    },
                    rules: {
                        host: {
                            required: !0
                        },
                        port: {
                            required: !0
                        },
                        account: {
                            required: !0
                        },
                        password: {
                            required: !0
                        },
                        senderAccount: {
                            validator: h({
                                required: !0
                            })
                        }
                    }
                }
            },
            computed: Ne({}, Object(o.mapState)("MailModule", ["synomail"]), {
                currentData: function() {
                    return this.email
                },
                fields: function() {
                    var t = {
                        host: null,
                        port: null,
                        enableAuth: null,
                        tls: null,
                        senderName: null,
                        senderAccount: null,
                        account: null,
                        password: null
                    };
                    if (!this.email) return this.$data._fields = t, t;
                    var e = this.email;
                    return 1 === e.state && (this.btnText = this.authInfo.unsyncText, this.authInfo.verified = !0), t.host = e.host, t.port = e.port, t.enableAuth = e.auth, t.tls = "true" === e.tls, t.senderName = e.sender_name, t.senderAccount = e.sender_account, t.account = e.account, t.password = "00000000", this.$data._fields = t, this.$data._fields
                },
                params: function() {
                    var t = {
                        auth: this.fields.enableAuth ? "true" : "false",
                        tls: this.fields.tls ? "true" : "false",
                        sender_name: this.fields.senderName,
                        account: this.fields.account,
                        email_type: this.email.email_type
                    };
                    return this.isCustomize && (t.host = this.fields.host, t.port = this.fields.port, t.sender_account = this.fields.senderAccount), void 0 !== this.email.access_token && (t.access_token = this.email.access_token), void 0 !== this.email.refresh_token && (t.refresh_token = this.email.refresh_token), void 0 !== this.email.expires_in && (t.expires_in = this.email.expires_in), t
                },
                isCustomize: function() {
                    return this.email && "custom" === this.email.email_type
                },
                isSynomail: function() {
                    return this.email && "synomail" === this.email.email_type
                },
                isGmail: function() {
                    return this.email && "gmail" === this.email.email_type
                },
                authInfo: function() {
                    return "gmail" === this.email.email_type ? this.gmailInfo : this.normalInfo
                }
            }),
            mounted: function() {
                var t = je(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.onSpinning(!0), t.next = 3, this.getSynoMailConfig();
                            case 3:
                                this.synomail.length > 0 && this.$refs.select.select(0), this.onSpinning(!1);
                            case 5:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                })));
                return function() {
                    return t.apply(this, arguments)
                }
            }(),
            methods: Ne({}, Object(o.mapActions)("MailModule", ["getSynoMailConfig"]), {
                onSyncClick: function() {
                    !1 === this.authInfo.verified || this.isGmail ? this.onVerifyAuth() : this.onCancelAuth()
                },
                composeParams: function() {
                    this.reqParams = Object.assign({}, this.params), this.$refs.passwdField && this.$refs.passwdField.isDirty && (this.reqParams.passwd = this.fields.password), this.oldAlias = this.reqParams.alias, this.reqParams.test_connect = this.isNeedTestConnect(this.reqParams.email_type), this.reqParams.alias = this.reqParams.account || this.reqParams.sender_account, "custom" === this.reqParams.email_type && (this.reqParams.alias = "".concat(this.reqParams.host, "_").concat(this.reqParams.alias)), this.reqParams.sender_name = this.reqParams.sender_name || this.reqParams.sender_account || this.reqParams.account
                },
                onClose: function() {
                    this.$refs.window.close()
                },
                onConfirm: function() {
                    var t = je(regeneratorRuntime.mark((function t() {
                        var e, n;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    if (this.composeParams(), e = It(this.reqParams.email_type), n = String.format(this.T("mail", "email_setting_alert"), this.reqParams.account, e), !Yt(this.reqParams.account, this.reqParams.email_type)) {
                                        t.next = 9;
                                        break
                                    }
                                    return t.next = 6, this.$refs.window.getMsgBox().confirm("", n);
                                case 6:
                                    return "confirm" === t.sent && this.onApply(), t.abrupt("return");
                                case 9:
                                    this.onApply();
                                case 10:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this)
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                isNeedTestConnect: function(t) {
                    return "gmail" !== t && "synomail" !== t
                },
                filterParams: function(t) {
                    var e = Object.assign({}, t);
                    for (var n in e) null !== e[n] && void 0 !== e[n] && "" !== e[n] || delete e[n];
                    return e
                },
                displayError: function(t) {
                    var e;
                    switch (t) {
                        case 116:
                            e = _JSLIBSTR("common", "error_demo");
                            break;
                        case 8007:
                            e = _T("mail", "account_already_saved");
                            break;
                        case 8011:
                            e = _T("mail", "mail_setting_error");
                            break;
                        default:
                            e = _T("error", "error_error_system")
                    }
                    this.$refs.window.getMsgBox().alert("", e)
                },
                onApply: ($e = je(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.onSpinning(!0), t.prev = 1, t.next = 4, synowebapi.promises.request({
                                    api: "SYNO.PersonMailAccount",
                                    method: "update",
                                    version: 1,
                                    params: this.filterParams(this.reqParams),
                                    encryption: ["passwd"]
                                });
                            case 4:
                                this.oldAlias === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_alias") && (SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_alias", this.reqParams.alias), SYNO.SDS.UserSettings.save()), this.onClose(), t.next = 11;
                                break;
                            case 8:
                                t.prev = 8, t.t0 = t.catch(1), this.displayError(t.t0.code);
                            case 11:
                                return t.prev = 11, this.onSpinning(!1), t.finish(11);
                            case 14:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [1, 8, 11, 14]
                    ])
                }))), function() {
                    return $e.apply(this, arguments)
                }),
                onSpinning: function(t) {
                    this.loading = !!t
                },
                isAccountCanEdit: function(t) {
                    return !("synomail" === this.email.email_type && !this.isSynoMailClientEnable())
                },
                isSynoMailClientEnable: function() {
                    return SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.MailClient.Application")
                }
            })
        },
        Re = (n(81), d(Ue, Ce, [], !1, null, null, null));
    Re.options.__file = "src/windows/email-edit.vue";
    var Me = Re.exports,
        Ye = function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-modal-window", {
                ref: "window",
                class: "sds-personal-settings-window",
                attrs: {
                    "syno-id": "dialogs-change-password-modal-window-0",
                    width: "418",
                    height: "240",
                    title: t.title,
                    "close-hook": t.onClose
                }
            }, [n("div", {
                staticClass: "change-password dialog",
                attrs: {
                    "fluid-footer": ""
                }
            }, [n("v-panel", {
                attrs: {
                    "syno-id": "dialogs-change-password-panel-0",
                    "has-fbar": !0,
                    cancel: t.onCancel,
                    confirm: t.onApply,
                    "loading-type": "statusbar",
                    loading: t.loading,
                    "show-status-bar": t.showStatusBar,
                    "status-bar-state": t.statusBarState,
                    "error-text": t.errorText,
                    "fluid-footer": ""
                },
                on: {
                    "update:showStatusBar": function(e) {
                        t.showStatusBar = e
                    },
                    "update:show-status-bar": function(e) {
                        t.showStatusBar = e
                    }
                }
            }, [n("template", {
                slot: "body"
            }, [n("v-form", {
                ref: "form",
                attrs: {
                    "syno-id": "dialogs-change-password-form-0",
                    rules: t.rules
                }
            }, [n("v-form-item", {
                attrs: {
                    label: t.T("user", "user_passwd_current") + ":"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "dialogs-change-password-input-0",
                    name: "password",
                    type: "password",
                    placeholder: "",
                    maxlength: 127
                },
                model: {
                    value: t.password.fields.currentPassword,
                    callback: function(e) {
                        t.$set(t.password.fields, "currentPassword", e)
                    },
                    expression: "password.fields.currentPassword"
                }
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    label: t.T("user", "user_passwd_new") + ":",
                    prop: "newPassword"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "dialogs-change-password-input-1",
                    name: "password",
                    type: "password",
                    "strength-checker": t.strengthChecker,
                    maxlength: 127
                },
                model: {
                    value: t.password.fields.newPassword,
                    callback: function(e) {
                        t.$set(t.password.fields, "newPassword", e)
                    },
                    expression: "password.fields.newPassword"
                }
            })], 1), t._v(" "), n("v-form-item", {
                attrs: {
                    label: t.T("user", "user_repswd") + ":",
                    prop: "confirmPassword"
                }
            }, [n("v-input", {
                attrs: {
                    "syno-id": "dialogs-change-password-input-2",
                    name: "password",
                    type: "password",
                    placeholder: "",
                    maxlength: 127
                },
                model: {
                    value: t.password.fields.confirmPassword,
                    callback: function(e) {
                        t.$set(t.password.fields, "confirmPassword", e)
                    },
                    expression: "password.fields.confirmPassword"
                }
            })], 1)], 1)], 1)], 2)], 1)])
        };

    function Ie(t, e, n, r, s, i, a) {
        try {
            var o = t[i](a),
                c = o.value
        } catch (t) {
            return void n(t)
        }
        o.done ? e(c) : Promise.resolve(c).then(r, s)
    }

    function ze(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise((function(r, s) {
                var i = t.apply(e, n);

                function a(t) {
                    Ie(i, r, s, a, o, "next", t)
                }

                function o(t) {
                    Ie(i, r, s, a, o, "throw", t)
                }
                a(void 0)
            }))
        }
    }

    function Be(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            })))), r.forEach((function(e) {
                Fe(t, e, n[e])
            }))
        }
        return t
    }

    function Fe(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }
    Ye._withStripped = !0;
    var Le = {
            mixins: [i],
            data: function() {
                return {
                    title: _T("personal_settings", "change_password"),
                    showStatusBar: !1,
                    statusBarState: "loading",
                    loading: !1,
                    errorText: this.T("common", "forminvalid"),
                    rules: {
                        newPassword: {
                            validator: this.validatePassword
                        },
                        confirmPassword: {
                            validator: this.validateConfirmPassword
                        }
                    }
                }
            },
            computed: Be({}, Object(o.mapState)("UserModule", ["user", "password", "isLDAP", "isDomain"])),
            mounted: function() {
                var t = ze(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (!this.isDomain && !this.isLDAP) {
                                    t.next = 4;
                                    break
                                }
                                this.rules = {
                                    confirmPassword: this.validateConfirmPassword
                                }, t.next = 8;
                                break;
                            case 4:
                                return t.next = 6, this.getPasswordPolicy();
                            case 6:
                                this.validator = new SYNO.SDS.Utils.CheckStrongPassword, this.validator.passwordPolicy = Be({}, this.password.rules);
                            case 8:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                })));
                return function() {
                    return t.apply(this, arguments)
                }
            }(),
            methods: Be({}, Object(o.mapActions)("UserModule", ["getUser", "getPasswordPolicy", "applyNewPassword", "clearPassword"]), {
                onApply: function() {
                    var t = ze(regeneratorRuntime.mark((function t() {
                        var e, n;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    return this.showStatusBar = !0, this.loading = !0, this.statusBarState = "loading", t.prev = 3, t.next = 6, this.$refs.form.validate();
                                case 6:
                                    if (e = t.sent, r = this.password.fields.currentPassword, s = this.password.fields.newPassword, r !== s || !r) {
                                        t.next = 9;
                                        break
                                    }
                                    throw {
                                        text: this.T("error", "same_password_as_previous")
                                    };
                                case 9:
                                    if (e) {
                                        t.next = 11;
                                        break
                                    }
                                    throw {
                                        text: this.T("common", "forminvalid")
                                    };
                                case 11:
                                    return t.next = 13, this.applyNewPassword();
                                case 13:
                                    this.$refs.window.close(), t.next = 21;
                                    break;
                                case 16:
                                    t.prev = 16, t.t0 = t.catch(3), n = this.T("common", "error_system"), n = t.t0.code ? SYNO.API.Errors.core[t.t0.code] : t.t0.text, this.$refs.window.getMsgBox().alert("", n);
                                case 21:
                                    return t.prev = 21, this.loading = !1, this.showStatusBar = !1, t.finish(21);
                                case 25:
                                case "end":
                                    return t.stop()
                            }
                            var r, s
                        }), t, this, [
                            [3, 16, 21, 25]
                        ])
                    })));
                    return function() {
                        return t.apply(this, arguments)
                    }
                }(),
                onCancel: function() {
                    this.$refs.window.close()
                },
                onClose: function() {
                    this.clearPassword()
                },
                validatePassword: function(t, e, n) {
                    try {
                        if (!this.password.fields.newPassword) return !0;
                        var r = this.validator.isPasswordValid(this.password.fields.newPassword, this.user.username, this.user.fullname);
                        return !0 === r || new Error(r)
                    } catch (t) {
                        SYNO.Debug.error(t)
                    }
                },
                validateConfirmPassword: function(t, e, n) {
                    try {
                        return !this.password.fields.newPassword || (this.password.fields.newPassword === this.password.fields.confirmPassword || new Error(_JSLIBSTR("vtype", "password_confirm_failed")))
                    } catch (t) {
                        SYNO.Debug.error(t)
                    }
                },
                strengthChecker: function(t) {
                    var e = ["weak", "medium", "strong"],
                        n = [_T("welcome", "passwd_weak"), _T("welcome", "passwd_medium"), _T("welcome", "passwd_strong")];
                    return synowebapi.promises.request({
                        api: "SYNO.Core.User.PasswordMeter",
                        method: "evaluate",
                        version: "1",
                        encryption: ["password"],
                        params: {
                            password: t
                        }
                    }).then((function(t) {
                        var r = function(t) {
                            return Math.floor(t / 2)
                        }(t.score);
                        return {
                            strength: e[r],
                            strengthText: n[r]
                        }
                    }))
                }
            })
        },
        We = (n(82), d(Le, Ye, [], !1, null, "7d9f0a6b", null));
    We.options.__file = "src/dialogs/change-password.vue";
    var qe = We.exports,
        Ve = function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-modal-window", {
                ref: "window",
                class: "sds-personal-settings-account-activity-window sds-personal-settings-window",
                attrs: {
                    "syno-id": "dialogs-account-activity-modal-window-0",
                    width: "700",
                    "min-height": "490",
                    height: "490",
                    title: t.T("personal_settings", "current_login_status"),
                    resizable: ""
                }
            }, [n("div", {
                staticClass: "account-activity dialog"
            }, [n("v-tabs", {
                staticClass: "account-activity-tabs",
                attrs: {
                    "syno-id": "dialogs-account-activity-tabs-0",
                    "active-tab-key": "connected_users",
                    "has-fbar": !0
                },
                scopedSlots: t._u([{
                    key: "fbar",
                    fn: function() {
                        return [n("div", {
                            staticClass: "default pull-right"
                        }, [n("v-button", {
                            attrs: {
                                "syno-id": "dialogs-account-activity-button-1",
                                suffix: "cancel",
                                type: "footbar"
                            },
                            on: {
                                click: t.onClose
                            }
                        }, [t._v(t._s(t.T("common", "close")))])], 1)]
                    },
                    proxy: !0
                }])
            }, [n("v-tab-pane", {
                attrs: {
                    "syno-id": "dialogs-account-activity-tab-pane-0",
                    "tab-key": "connected_users",
                    tab: t.T("connections", "connections_title")
                }
            }, [n("v-data-table", {
                ref: "connection_users",
                staticClass: "connected-users data-table",
                attrs: {
                    "syno-id": "dialogs-account-activity-data-table-0",
                    loading: t.loading,
                    "loading-text": t.loadingText,
                    data: t.loadConnectedUsers,
                    columns: t.connection.columns,
                    "page-size": 20,
                    pagination: !1
                },
                scopedSlots: t._u([{
                    key: "td",
                    fn: function(e) {
                        var r = e.column,
                            s = e.item;
                        return ["kick_connection" === r.fieldKey ? n("span", [t.canBeKicked(s) ? n("div", {
                            staticClass: "kill-connection",
                            on: {
                                click: function(e) {
                                    return t.preKickedConnection(s)
                                }
                            }
                        }) : t._e()]) : t._e()]
                    }
                }])
            })], 1), t._v(" "), n("v-tab-pane", {
                attrs: {
                    "syno-id": "dialogs-account-activity-tab-pane-1",
                    "tab-key": "login_history",
                    tab: t.T("personal_settings", "current_login_history")
                }
            }, [n("div", {
                staticClass: "toolbar"
            }, [n("v-button", {
                attrs: {
                    "syno-id": "dialogs-account-activity-button-0",
                    disabled: !t.isSelected()
                },
                on: {
                    click: function(e) {
                        return t.openLoginHistory()
                    }
                }
            }, [t._v("\n\t\t\t\t\t\t" + t._s(t.T("personal_settings", "manage_trust_info")) + "\n\t\t\t\t\t")])], 1), t._v(" "), n("v-data-table", {
                ref: "login_history",
                staticClass: "login-history data-table",
                attrs: {
                    "syno-id": "dialogs-account-activity-data-table-1",
                    loading: t.loading,
                    "loading-text": t.loadingText,
                    "response-params-name": t.loginHistory.paramsName,
                    data: t.loadLoginHistory,
                    columns: t.loginHistory.columns,
                    "page-size": 50,
                    pagination: !0
                },
                on: {
                    rowclick: t.onLoginHistoryClick,
                    rowdblclick: t.onLoginHistoryDblClick
                }
            })], 1)], 1)], 1)])
        };

    function He(t, e, n, r, s, i, a) {
        try {
            var o = t[i](a),
                c = o.value
        } catch (t) {
            return void n(t)
        }
        o.done ? e(c) : Promise.resolve(c).then(r, s)
    }

    function Ke(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise((function(r, s) {
                var i = t.apply(e, n);

                function a(t) {
                    He(i, r, s, a, o, "next", t)
                }

                function o(t) {
                    He(i, r, s, a, o, "throw", t)
                }
                a(void 0)
            }))
        }
    }

    function Ge(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }
    Ve._withStripped = !0;
    var Qe, Je, Ze = {
            mixins: [i],
            data: function() {
                var t = this;
                return {
                    loading: !1,
                    loadingText: this.T("common", "loading"),
                    loginHistory: {
                        columns: [{
                            title: this.T("log", "log_time"),
                            fn: function(t) {
                                return SYNO.SDS.DateTimeFormatter(new Date(t.time), {
                                    type: "datetime"
                                })
                            }
                        }, {
                            title: this.T("personal_settings", "login_protocol"),
                            field: "protocol"
                        }, {
                            title: this.T("common", "ip_addr"),
                            field: "ip"
                        }, {
                            title: this.T("personal_settings", "login_place"),
                            fn: function(e) {
                                return e.is_public_ip ? e.country ? t.T("Country", e.country) : t.T("personal_settings", "geoip_lookup_failed") : t.T("personal_settings", "private_ip")
                            }
                        }, {
                            title: this.T("log", "log_action"),
                            field: "event",
                            tooltip: !0
                        }],
                        paramsName: {
                            results: "items"
                        }
                    },
                    connection: {
                        columns: [{
                            title: this.T("log", "log_time"),
                            fn: function(t) {
                                return SYNO.SDS.DateTimeFormatter(new Date(t.time), {
                                    type: "datetime"
                                })
                            }
                        }, {
                            title: this.T("log", "log_account"),
                            field: "who"
                        }, {
                            title: this.T("log", "log_client"),
                            field: "from"
                        }, {
                            title: this.T("tree", "services"),
                            field: "type"
                        }, {
                            title: this.T("log", "log_resource"),
                            field: "descr"
                        }, {
                            title: this.T("connections", "kick_connection"),
                            fieldKey: "kick_connection"
                        }]
                    }
                }
            },
            computed: {},
            mounted: function() {},
            methods: function(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? Object(arguments[e]) : {},
                        r = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                        return Object.getOwnPropertyDescriptor(n, t).enumerable
                    })))), r.forEach((function(e) {
                        Ge(t, e, n[e])
                    }))
                }
                return t
            }({}, Object(o.mapActions)("AccountActivityModule", ["selectedLoginHistory"]), Object(o.mapGetters)("AccountActivityModule", ["isSelected"]), {
                openLoginHistory: function() {
                    this.$refs.window.openModalWindow(SYNO.SDS.App.PersonalSettings.Vue.LoginHistoryDialog)
                },
                onLoginHistoryClick: function(t) {
                    var e = t.row;
                    this.selectedLoginHistory(e)
                },
                onLoginHistoryDblClick: function(t, e) {
                    this.selectedLoginHistory(e), this.openLoginHistory()
                },
                canBeKicked: function(t) {
                    return t.can_be_kicked
                },
                loadConnectedUsers: function(t) {
                    var e = Object.assign(t);
                    return e = Object.assign(e, {
                        target: "LOCAL",
                        logtype: "connection",
                        dir: "desc"
                    }), synowebapi.promises.request({
                        api: "SYNO.Core.CurrentConnection",
                        method: "list_by_user",
                        version: "1",
                        params: e
                    })
                },
                loadLoginHistory: function(t) {
                    var e = Object.assign(t);
                    return synowebapi.promises.request({
                        api: "SYNO.Core.SyslogClient.PersonalActivity",
                        version: "1",
                        method: "loginhistory",
                        params: e
                    })
                },
                isKickedSelf: function(t) {
                    return t.who === _S("user")
                },
                preKickedConnection: (Je = Ke(regeneratorRuntime.mark((function t(e) {
                    var n, r;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (!1 !== e.can_be_kicked) {
                                    t.next = 2;
                                    break
                                }
                                return t.abrupt("return");
                            case 2:
                                if (n = [], r = [], "HTTP/HTTPS" === e.type ? r.push({
                                        who: e.who,
                                        from: e.from
                                    }) : n.push({
                                        pid: e.pid,
                                        type: e.type,
                                        who: e.who,
                                        from: e.from
                                    }), !this.isKickedSelf(e)) {
                                    t.next = 12;
                                    break
                                }
                                return t.next = 8, this.$refs.window.getMsgBox().confirm("", _T("connections", "confirm_kick_self"));
                            case 8:
                                "confirm" === t.sent && this.kickConnection(n, r), t.next = 13;
                                break;
                            case 12:
                                this.kickConnection(n, r);
                            case 13:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function(t) {
                    return Je.apply(this, arguments)
                }),
                kickConnection: (Qe = Ke(regeneratorRuntime.mark((function t(e, n) {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.loading = !0, t.prev = 1, t.next = 4, synowebapi.promises.request({
                                    api: "SYNO.Core.CurrentConnection",
                                    method: "kick_connection",
                                    timeout: 45e4,
                                    params: {
                                        service_conn: e,
                                        http_conn: n
                                    },
                                    version: 1
                                });
                            case 4:
                                this.loading = !1, t.next = 10;
                                break;
                            case 7:
                                t.prev = 7, t.t0 = t.catch(1), this.loadingText = SYNO.API.Errors.core[t.t0.code] || this.T("common", "commfail");
                            case 10:
                                return t.prev = 10, this.$refs.connection_users.loadData(), t.finish(10);
                            case 13:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [1, 7, 10, 13]
                    ])
                }))), function(t, e) {
                    return Qe.apply(this, arguments)
                }),
                onClose: function() {
                    this.$refs.window.close()
                }
            }),
            components: {}
        },
        Xe = (n(83), n(84), d(Ze, Ve, [], !1, null, "d0011528", null));
    Xe.options.__file = "src/dialogs/account-activity.vue";
    var tn = Xe.exports,
        en = function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-modal-window", {
                ref: "window",
                class: "sds-personal-settings-login-history-window sds-personal-settings-window",
                attrs: {
                    "syno-id": "dialogs-login-history-modal-window-0",
                    width: "500",
                    height: "auto",
                    title: t.T("personal_settings", "login_history_inspect")
                }
            }, [n("v-panel", {
                staticClass: "login-history dialog",
                attrs: {
                    "syno-id": "dialogs-login-history-panel-0",
                    "loading-type": "statusbar",
                    loading: t.loading,
                    "show-status-bar": t.showStatusBar,
                    "status-bar-state": t.statusBarState,
                    "fluid-footer": ""
                },
                on: {
                    "update:showStatusBar": function(e) {
                        t.showStatusBar = e
                    },
                    "update:show-status-bar": function(e) {
                        t.showStatusBar = e
                    }
                },
                scopedSlots: t._u([{
                    key: "body",
                    fn: function() {
                        return [n("div", {
                            staticClass: "container"
                        }, [n("v-fieldset", {
                            attrs: {
                                title: t.T("personal_settings", "basic_info"),
                                collapsible: !1
                            }
                        }, [n("div", {
                            staticClass: "display-field-wrapper"
                        }, [n("div", {
                            staticClass: "display-field field"
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.T("personal_settings", "login_username")) + "\n\t\t\t\t\t\t")]), t._v(" "), n("div", {
                            staticClass: "display-field value"
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.user.username) + "\n\t\t\t\t\t\t")])]), t._v(" "), n("div", {
                            staticClass: "display-field-wrapper"
                        }, [n("div", {
                            staticClass: "display-field field"
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.T("log", "log_time")) + "\n\t\t\t\t\t\t")]), t._v(" "), n("div", {
                            staticClass: "display-field value"
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t._f("dateTimeFormat")(t.details.time)) + "\n\t\t\t\t\t\t")])])]), t._v(" "), n("v-fieldset", {
                            attrs: {
                                title: t.T("personal_settings", "trust_info"),
                                collapsible: !1
                            }
                        }, [n("div", {
                            staticClass: "display-field-wrapper"
                        }, [n("div", {
                            staticClass: "display-field field"
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.T("personal_settings", "login_token")) + "\n\t\t\t\t\t\t")]), t._v(" "), n("div", {
                            staticClass: "display-field value trust-status"
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.details.token_status) + "\n\t\t\t\t\t\t")]), t._v(" "), t.isTrusted() ? n("v-button", {
                            staticClass: "untrust-button",
                            attrs: {
                                "syno-id": "dialogs-login-history-button-0"
                            },
                            on: {
                                click: t.showUntrustDialog
                            }
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.T("personal_settings", "set_login_untrusted")) + "\n\t\t\t\t\t\t")]) : t._e()], 1), t._v(" "), n("div", {
                            staticClass: "display-field-wrapper"
                        }, [n("div", {
                            staticClass: "display-field field"
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.T("personal_settings", "login_ip_address")) + "\n\t\t\t\t\t\t")]), t._v(" "), n("div", {
                            staticClass: "display-field value"
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.details.ip_status) + "\n\t\t\t\t\t\t")])])]), t._v(" "), n("v-fieldset", {
                            attrs: {
                                title: t.T("personal_settings", "extra_info"),
                                collapsible: !1
                            }
                        }, [t.details.protocol ? n("div", {
                            staticClass: "display-field-wrapper"
                        }, [n("div", {
                            staticClass: "display-field field"
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.T("personal_settings", "login_protocol")) + "\n\t\t\t\t\t\t")]), t._v(" "), n("div", {
                            staticClass: "display-field value"
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.details.protocol) + "\n\t\t\t\t\t\t")])]) : t._e(), t._v(" "), t.details.country ? n("div", {
                            staticClass: "display-field-wrapper"
                        }, [n("div", {
                            staticClass: "display-field field"
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.T("common", "country")) + "\n\t\t\t\t\t\t")]), t._v(" "), n("div", {
                            staticClass: "display-field value"
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.details.country_status) + "\n\t\t\t\t\t\t")])]) : t._e(), t._v(" "), t.details.os ? n("div", {
                            staticClass: "display-field-wrapper"
                        }, [n("div", {
                            staticClass: "display-field field"
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.T("personal_settings", "login_operating_system")) + "\n\t\t\t\t\t\t")]), t._v(" "), n("div", {
                            staticClass: "display-field value"
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.details.os) + "\n\t\t\t\t\t\t")])]) : t._e(), t._v(" "), t.details.browser ? n("div", {
                            staticClass: "display-field-wrapper"
                        }, [n("div", {
                            staticClass: "display-field field"
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.T("personal_settings", "login_browser")) + "\n\t\t\t\t\t\t")]), t._v(" "), n("div", {
                            staticClass: "display-field value"
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.details.browser) + "\n\t\t\t\t\t\t")])]) : t._e()])], 1)]
                    },
                    proxy: !0
                }, {
                    key: "fbar",
                    fn: function() {
                        return [n("div", {
                            staticClass: "default pull-right"
                        }, [n("v-button", {
                            attrs: {
                                "syno-id": "dialogs-login-history-button-1",
                                suffix: "cancel",
                                type: "footbar"
                            },
                            on: {
                                click: t.onClose
                            }
                        }, [t._v(t._s(t.T("common", "close")))])], 1)]
                    },
                    proxy: !0
                }])
            })], 1)
        };

    function nn(t, e, n, r, s, i, a) {
        try {
            var o = t[i](a),
                c = o.value
        } catch (t) {
            return void n(t)
        }
        o.done ? e(c) : Promise.resolve(c).then(r, s)
    }

    function rn(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise((function(r, s) {
                var i = t.apply(e, n);

                function a(t) {
                    nn(i, r, s, a, o, "next", t)
                }

                function o(t) {
                    nn(i, r, s, a, o, "throw", t)
                }
                a(void 0)
            }))
        }
    }

    function sn(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            })))), r.forEach((function(e) {
                an(t, e, n[e])
            }))
        }
        return t
    }

    function an(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }
    en._withStripped = !0;
    var on, cn = {
            mixins: [i],
            data: function() {
                return {
                    loading: !1,
                    showStatusBar: !1,
                    statusBarState: "loading"
                }
            },
            computed: sn({}, Object(o.mapState)("UserModule", ["user"]), Object(o.mapState)("AccountActivityModule", ["details"])),
            mounted: function() {
                var t = rn(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.loading = !0, t.next = 3, this.getPersonalActivity();
                            case 3:
                                this.loading = !1;
                            case 4:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                })));
                return function() {
                    return t.apply(this, arguments)
                }
            }(),
            methods: sn({}, Object(o.mapActions)("AccountActivityModule", ["getPersonalActivity", "untrustAll", "clearRecord"]), Object(o.mapGetters)("AccountActivityModule", ["isTrusted"]), {
                onClose: function() {
                    this.$refs.window.close()
                },
                untrust: (on = rn(regeneratorRuntime.mark((function t() {
                    var e;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.showStatusBar = !0, this.loading = !0, this.statusBarState = "loading", t.prev = 3, t.next = 6, Promise.all([this.untrustAll(), this.clearRecord()]);
                            case 6:
                                this.statusBarState = "success", t.next = 14;
                                break;
                            case 9:
                                t.prev = 9, t.t0 = t.catch(3), e = SYNO.API.Errors.core[t.t0.code] || _T("common", "error_system"), this.$refs.window.getMsgBox().alert("", e), this.statusBarState = "error";
                            case 14:
                                return t.prev = 14, this.loading = !1, t.finish(14);
                            case 17:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [3, 9, 14, 17]
                    ])
                }))), function() {
                    return on.apply(this, arguments)
                }),
                showUntrustDialog: function() {
                    "confirm" === this.$refs.window.getMsgBox().confirm("", _T("personal_settings", "set_login_untrusted_confirm")) && this.untrust()
                }
            }),
            components: {},
            filters: {
                dateTimeFormat: function(t) {
                    return SYNO.SDS.DateTimeFormatter(new Date(t), {
                        type: "datetimesec"
                    })
                }
            }
        },
        ln = (n(85), d(cn, en, [], !1, null, "a2fc417a", null));
    ln.options.__file = "src/dialogs/login-history.vue";
    var un = ln.exports,
        pn = function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-modal-window", {
                ref: "window",
                class: "sds-personal-settings-account-protection-window sds-personal-settings-window",
                attrs: {
                    "syno-id": "dialogs-account-protection-modal-window-0",
                    width: "720",
                    height: "auto",
                    title: t.T("tree", "leaf_smartblock")
                }
            }, [n("v-panel", {
                staticClass: "account-protection dialog",
                attrs: {
                    "syno-id": "dialogs-account-protection-panel-0",
                    loading: t.loading,
                    "loading-type": "statusbar",
                    "show-status-bar": t.loading,
                    "fluid-footer": ""
                },
                scopedSlots: t._u([{
                    key: "body",
                    fn: function() {
                        return [t.locked ? n("div", {
                            staticClass: "banner locked"
                        }, [n("div", {
                            staticClass: "img status"
                        }), t._v(" "), n("div", {
                            staticClass: "content"
                        }, [n("div", {
                            staticClass: "title"
                        }, [t._v("\n\t\t\t\t\t\t" + t._s(t.T("smartblock", "been_locked_title")) + "\n\t\t\t\t\t")]), t._v(" "), n("div", {
                            staticClass: "desc"
                        }, [t._v("\n\t\t\t\t\t\t" + t._s(t.T("smartblock", "been_locked_desc")) + "\n\t\t\t\t\t")]), t._v(" "), n("div", {
                            staticClass: "action"
                        }, [n("v-button", {
                            attrs: {
                                "syno-id": "dialogs-account-protection-button-0"
                            },
                            on: {
                                click: t.pardonUser
                            }
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.T("smartblock", "unlock_self")) + "\n\t\t\t\t\t\t")])], 1)])]) : n("div", {
                            staticClass: "banner"
                        }, [n("div", {
                            staticClass: "img status"
                        }), t._v(" "), n("div", {
                            staticClass: "content"
                        }, [n("div", {
                            staticClass: "title"
                        }, [t._v("\n\t\t\t\t\t\t" + t._s(t.T("smartblock", "enabled_title")) + "\n\t\t\t\t\t")]), t._v(" "), n("div", {
                            staticClass: "desc"
                        }, [t._v("\n\t\t\t\t\t\t" + t._s(t.T("smartblock", "enabled_desc")) + "\n\t\t\t\t\t")])])]), t._v(" "), n("div", {
                            staticClass: "info"
                        }, [n("v-fieldset", {
                            attrs: {
                                title: t.T("smartblock", "client_trust_settings"),
                                collapsible: !1
                            }
                        }, [n("div", {
                            staticClass: "desc"
                        }), t._v(" "), n("div", {
                            staticClass: "display-field field"
                        }, [t._v("\n\t\t\t\t\t\t" + t._s(t.T("smartblock", "trust_self_desc")) + "\n\t\t\t\t\t")]), t._v(" "), n("div", {
                            staticClass: "form-item"
                        }, [n("v-button", {
                            attrs: {
                                "syno-id": "dialogs-account-protection-button-1",
                                disabled: t.current_trusted
                            },
                            on: {
                                click: t.trustUser
                            }
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.current_trusted ? t.T("smartblock", "current_client_trusted") : t.T("smartblock", "trust_self")) + "\n\t\t\t\t\t\t")]), t._v(" "), n("v-whitetip", {
                            scopedSlots: t._u([{
                                key: "default",
                                fn: function() {
                                    return [n("div", {
                                        staticClass: "syno-sds-personal-settings-trust-settings"
                                    }, [n("div", {
                                        staticClass: "tip-title"
                                    }, [t._v("\n\t\t\t\t\t\t\t\t\t\t" + t._s(t.T("smartblock", "when_trust_client_title")) + "\n\t\t\t\t\t\t\t\t\t")]), t._v(" "), n("div", {
                                        staticClass: "tip-content"
                                    }, [n("div", {
                                        staticClass: "sub-title"
                                    }, [t._v(" " + t._s(t.T("smartblock", "trust_client")) + " ")]), t._v(" "), n("div", {
                                        staticClass: "sub-content"
                                    }, [t._v(" " + t._s(t.T("smartblock", "trust_client_desc")) + " ")])]), t._v(" "), n("div", {
                                        staticClass: "tip-content"
                                    }, [n("div", {
                                        staticClass: "sub-title"
                                    }, [t._v(" " + t._s(t.T("smartblock", "untrust_client")) + " ")]), t._v(" "), n("div", {
                                        staticClass: "sub-content"
                                    }, [t._v(" " + t._s(t.T("smartblock", "untrust_client_desc")))])])])]
                                },
                                proxy: !0
                            }])
                        })], 1), t._v(" "), n("div", {
                            staticClass: "form-item"
                        }, [n("v-button", {
                            attrs: {
                                "syno-id": "dialogs-account-protection-button-2"
                            },
                            on: {
                                click: t.openTrustedCientsDialog
                            }
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.T("smartblock", "smartblock_trust_manage")) + "\n\t\t\t\t\t\t")])], 1)])], 1)]
                    },
                    proxy: !0
                }, {
                    key: "fbar",
                    fn: function() {
                        return [n("div", {
                            staticClass: "default pull-right"
                        }, [n("v-button", {
                            attrs: {
                                "syno-id": "dialogs-account-protection-button-3",
                                suffix: "cancel",
                                type: "footbar"
                            },
                            on: {
                                click: t.onClose
                            }
                        }, [t._v(t._s(t.T("common", "close")))])], 1)]
                    },
                    proxy: !0
                }])
            })], 1)
        };

    function dn(t, e, n, r, s, i, a) {
        try {
            var o = t[i](a),
                c = o.value
        } catch (t) {
            return void n(t)
        }
        o.done ? e(c) : Promise.resolve(c).then(r, s)
    }

    function fn(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise((function(r, s) {
                var i = t.apply(e, n);

                function a(t) {
                    dn(i, r, s, a, o, "next", t)
                }

                function o(t) {
                    dn(i, r, s, a, o, "throw", t)
                }
                a(void 0)
            }))
        }
    }

    function mn(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            })))), r.forEach((function(e) {
                hn(t, e, n[e])
            }))
        }
        return t
    }

    function hn(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }
    pn._withStripped = !0;
    var vn, _n = {
            mixins: [i],
            data: function() {
                return {
                    loading: !1
                }
            },
            computed: mn({}, Object(o.mapState)("SmartBlockModule", ["locked", "current_trusted"])),
            mounted: function() {
                var t = fn(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                this.refresh();
                            case 1:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                })));
                return function() {
                    return t.apply(this, arguments)
                }
            }(),
            methods: mn({}, Object(o.mapActions)("SmartBlockModule", ["getSmartBlockLockedStatus", "getCurrentTrustedStatus", "pardonUser", "trustUser"]), {
                refresh: (vn = fn(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.loading = !0, t.next = 3, Promise.all([this.getSmartBlockLockedStatus(), this.getCurrentTrustedStatus()]);
                            case 3:
                                this.loading = !1;
                            case 4:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return vn.apply(this, arguments)
                }),
                onClose: function() {
                    this.$refs.window.close()
                },
                openTrustedCientsDialog: function() {
                    this.$refs.window.openModalWindow(SYNO.SDS.App.PersonalSettings.Vue.TrustedClientsDialog)
                }
            }),
            components: {}
        },
        gn = (n(86), n(87), d(_n, pn, [], !1, null, "787aeaf6", null));
    gn.options.__file = "src/dialogs/account-protection.vue";
    var bn = gn.exports,
        yn = function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-modal-window", {
                ref: "window",
                class: "sds-personal-settings-trusted-clients-window sds-personal-settings-window",
                attrs: {
                    "syno-id": "dialogs-trusted-clients-modal-window-0",
                    width: "680",
                    height: "auto",
                    title: t.T("smartblock", "manage_trust_title")
                }
            }, [n("v-panel", {
                staticClass: "trusted-clients dialog",
                attrs: {
                    "syno-id": "dialogs-trusted-clients-panel-0",
                    "fluid-footer": ""
                },
                scopedSlots: t._u([{
                    key: "body",
                    fn: function() {
                        return [n("div", {
                            staticClass: "toolbar"
                        }, [n("v-button", {
                            attrs: {
                                "syno-id": "dialogs-trusted-clients-button-0"
                            },
                            on: {
                                click: t.onDistrust
                            }
                        }, [t._v("\n\t\t\t\t\t" + t._s(t.T("smartblock", "action_distrust")) + "\n\t\t\t\t")])], 1), t._v(" "), n("v-data-table", {
                            ref: "trusted_client",
                            staticClass: "trusted-clients-data-table data-table",
                            attrs: {
                                "syno-id": "dialogs-trusted-clients-data-table-0",
                                loading: t.loading,
                                data: t.loadSmartBlockDevices,
                                columns: t.columns,
                                "response-params-name": t.paramsName,
                                "enable-hd-menu": !1,
                                pagination: !1
                            },
                            on: {
                                rowclick: t.onRowClick,
                                rowclear: t.onRowClear
                            },
                            scopedSlots: t._u([{
                                key: "td",
                                fn: function(e) {
                                    var r = e.column,
                                        s = e.item;
                                    return ["current_client" === r.fieldKey && s.id === t.current_id ? n("span", {
                                        staticClass: "td-content-wrapper"
                                    }, [n("div", {
                                        staticClass: "img current-client"
                                    })]) : t._e()]
                                }
                            }])
                        })]
                    },
                    proxy: !0
                }, {
                    key: "fbar",
                    fn: function() {
                        return [n("div", {
                            staticClass: "default pull-right"
                        }, [n("v-button", {
                            attrs: {
                                "syno-id": "dialogs-trusted-clients-button-1",
                                suffix: "cancel",
                                type: "footbar"
                            },
                            on: {
                                click: t.onClose
                            }
                        }, [t._v(t._s(t.T("common", "close")))])], 1)]
                    },
                    proxy: !0
                }])
            })], 1)
        };

    function wn(t, e, n, r, s, i, a) {
        try {
            var o = t[i](a),
                c = o.value
        } catch (t) {
            return void n(t)
        }
        o.done ? e(c) : Promise.resolve(c).then(r, s)
    }

    function Sn(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }
    yn._withStripped = !0;
    var xn, kn = {
            mixins: [i],
            data: function() {
                return {
                    loading: !1,
                    selectedRow: null,
                    paramsName: {
                        results: "devices"
                    },
                    columns: [{
                        title: this.T("smartblock", "created_time"),
                        fn: function(t) {
                            return SYNO.SDS.DateTimeFormatter(new Date(1e3 * t.time), {
                                type: "datetime"
                            })
                        },
                        width: 208
                    }, {
                        title: this.T("common", "ip_addr"),
                        field: "ip",
                        width: 130
                    }, {
                        title: this.T("smartblock", "user_agent"),
                        field: "agent",
                        width: 184
                    }, {
                        title: this.T("smartblock", "current_client"),
                        useSlot: !0,
                        fieldKey: "current_client"
                    }]
                }
            },
            computed: function(t) {
                for (var e = 1; e < arguments.length; e++) {
                    var n = null != arguments[e] ? Object(arguments[e]) : {},
                        r = Object.keys(n);
                    "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                        return Object.getOwnPropertyDescriptor(n, t).enumerable
                    })))), r.forEach((function(e) {
                        Sn(t, e, n[e])
                    }))
                }
                return t
            }({}, Object(o.mapState)("SmartBlockModule", ["locked", "current_id"])),
            mounted: function() {},
            methods: {
                onRowClear: function() {
                    this.selectedRow = null
                },
                onRowClick: function(t) {
                    this.selectedRow = t.row
                },
                loadSmartBlockDevices: function(t) {
                    var e = Object.assign(t);
                    return e.limit = 999999, synowebapi.promises.request({
                        api: "SYNO.Core.SmartBlock.User",
                        method: "list",
                        version: 1,
                        params: e
                    })
                },
                onDistrust: (xn = function(t) {
                    return function() {
                        var e = this,
                            n = arguments;
                        return new Promise((function(r, s) {
                            var i = t.apply(e, n);

                            function a(t) {
                                wn(i, r, s, a, o, "next", t)
                            }

                            function o(t) {
                                wn(i, r, s, a, o, "throw", t)
                            }
                            a(void 0)
                        }))
                    }
                }(regeneratorRuntime.mark((function t() {
                    var e;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (this.selectedRow) {
                                    t.next = 2;
                                    break
                                }
                                return t.abrupt("return");
                            case 2:
                                return e = [this.selectedRow.id], t.prev = 3, t.next = 6, synowebapi.promises.request({
                                    api: "SYNO.Core.SmartBlock.User",
                                    version: 1,
                                    method: "distrust",
                                    params: {
                                        devices: e
                                    }
                                });
                            case 6:
                                this.$refs.trusted_client.reload(), t.next = 12;
                                break;
                            case 9:
                                t.prev = 9, t.t0 = t.catch(3), SYNO.Debug.error(t.t0.stack);
                            case 12:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [3, 9]
                    ])
                }))), function() {
                    return xn.apply(this, arguments)
                }),
                onClose: function() {
                    this.$refs.window.close()
                }
            }
        },
        Tn = (n(88), n(89), d(kn, yn, [], !1, null, "f3ab96f6", null));
    Tn.options.__file = "src/dialogs/trusted-clients.vue";
    var Dn = Tn.exports,
        On = function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-modal-window", {
                ref: "window",
                class: "sds-personal-settings-trusted-device-window sds-personal-settings-window",
                attrs: {
                    "syno-id": "dialogs-trusted-device-modal-window-0",
                    width: "640",
                    height: "auto",
                    title: t.T("trustdevice", "manage_trust_device")
                }
            }, [n("v-panel", {
                staticClass: "trusted-device dialog",
                attrs: {
                    "syno-id": "dialogs-trusted-device-panel-0",
                    loading: t.loading,
                    "loading-type": "statusbar",
                    "show-status-bar": t.showStatusBar,
                    "status-bar-state": t.statusBarState,
                    "success-text": t.successText,
                    "fluid-footer": ""
                },
                on: {
                    "update:showStatusBar": function(e) {
                        t.showStatusBar = e
                    },
                    "update:show-status-bar": function(e) {
                        t.showStatusBar = e
                    }
                },
                scopedSlots: t._u([{
                    key: "body",
                    fn: function() {
                        return [n("div", {
                            staticClass: "desc-info"
                        }, [t._v("\n\t\t\t\t" + t._s(t.T("trustdevice", "manage_trusted_device_desc")) + "\n\t\t\t")]), t._v(" "), n("div", {
                            staticClass: "block-wrapper"
                        }, [n("div", {
                            staticClass: "current-device block"
                        }, [n("div", {
                            staticClass: "icn in-middle"
                        }), t._v(" "), n("div", {
                            staticClass: "content in-middle"
                        }, [n("div", {
                            staticClass: "title"
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.self_trusted ? String.format(t.T("trustdevice", "this_device_trusted"), t.ctimeLocale) : t.T("trustdevice", "this_device_untrusted")) + "\n\t\t\t\t\t\t")]), t._v(" "), n("div", {
                            staticClass: "action"
                        }, [n("v-button", {
                            attrs: {
                                "syno-id": "dialogs-trusted-device-button-0"
                            },
                            on: {
                                click: t.onToggleTrustedMode
                            }
                        }, [t._v("\n\t\t\t\t\t\t\t" + t._s(t.self_trusted ? t.T("trustdevice", "untrust_this_device") : t.T("trustdevice", "trust_this_device")) + "\n\t\t\t\t\t\t\t")])], 1)])]), t._v(" "), n("div", {
                            staticClass: "others-device block"
                        }, [n("div", {
                            staticClass: "icn in-middle"
                        }), t._v(" "), n("div", {
                            staticClass: "content in-middle"
                        }, [n("div", {
                            staticClass: "title"
                        }, [t._v("\n\t\t\t\t\t\t  " + t._s(t.T("trustdevice", "other_devices_trusted")) + "\n\t\t\t\t\t\t")]), t._v(" "), n("div", {
                            staticClass: "desc"
                        }, [t._v("\n\t\t\t\t\t\t  " + t._s(t.T("trustdevice", "other_devices_trusted_desc")) + "\n\t\t\t\t\t\t")]), t._v(" "), n("div", {
                            staticClass: "action"
                        }, [n("v-button", {
                            attrs: {
                                "syno-id": "dialogs-trusted-device-button-1"
                            },
                            on: {
                                click: t.onUntrustOthersDevices
                            }
                        }, [t._v("\n\t\t\t\t\t\t\t\t" + t._s(t.T("trustdevice", "untrust_other_devices")) + "\n\t\t\t\t\t\t\t")])], 1)])])])]
                    },
                    proxy: !0
                }, {
                    key: "fbar",
                    fn: function() {
                        return [n("div", {
                            staticClass: "default pull-right"
                        }, [n("v-button", {
                            attrs: {
                                "syno-id": "dialogs-trusted-device-button-2",
                                suffix: "cancel",
                                type: "footbar"
                            },
                            on: {
                                click: t.onClose
                            }
                        }, [t._v(t._s(t.T("common", "close")))])], 1)]
                    },
                    proxy: !0
                }])
            })], 1)
        };

    function Pn(t, e, n, r, s, i, a) {
        try {
            var o = t[i](a),
                c = o.value
        } catch (t) {
            return void n(t)
        }
        o.done ? e(c) : Promise.resolve(c).then(r, s)
    }

    function Cn(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise((function(r, s) {
                var i = t.apply(e, n);

                function a(t) {
                    Pn(i, r, s, a, o, "next", t)
                }

                function o(t) {
                    Pn(i, r, s, a, o, "throw", t)
                }
                a(void 0)
            }))
        }
    }

    function An(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            })))), r.forEach((function(e) {
                jn(t, e, n[e])
            }))
        }
        return t
    }

    function jn(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }
    On._withStripped = !0;
    var Nn, En, $n, Un = {
            mixins: [i],
            data: function() {
                return {
                    loading: !1,
                    showStatusBar: !1,
                    statusBarState: "loading",
                    successText: this.T("common", "setting_applied")
                }
            },
            computed: An({}, Object(o.mapState)("TrustedDeviceModule", ["info", "self_trusted", "ctimeLocale"])),
            mounted: function() {
                var t = Cn(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.loading = !0, t.next = 3, this.getDeviceInfo();
                            case 3:
                                this.loading = !1;
                            case 4:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                })));
                return function() {
                    return t.apply(this, arguments)
                }
            }(),
            methods: An({}, Object(o.mapActions)("TrustedDeviceModule", ["getDeviceInfo", "trust", "untrustThisDevice", "untrustOtherDevices"]), {
                onClose: function() {
                    this.$refs.window.close()
                },
                onToggleTrustedMode: ($n = Cn(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (this.loading = !0, this.showStatusBar = !0, this.successText = this.T("common", "setting_applied"), this.statusBarState = "loading", t.prev = 4, !this.self_trusted) {
                                    t.next = 10;
                                    break
                                }
                                return t.next = 8, this.untrustThisDevice();
                            case 8:
                                t.next = 12;
                                break;
                            case 10:
                                return t.next = 12, this.trust();
                            case 12:
                                this.statusBarState = "success", t.next = 18;
                                break;
                            case 15:
                                t.prev = 15, t.t0 = t.catch(4), this.statusBarState = "error";
                            case 18:
                                return t.prev = 18, this.loading = !1, t.finish(18);
                            case 21:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [4, 15, 18, 21]
                    ])
                }))), function() {
                    return $n.apply(this, arguments)
                }),
                onUntrustOthersDevices: (En = Cn(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return t.next = 2, this.$refs.window.getMsgBox().confirm(_T("trustdevice", "confirm_revoke_all_devices_title"), _T("trustdevice", "confirm_revoke_all_devices_desc"), {
                                    cancel: {
                                        type: "footbar",
                                        text: _T("common", "cancel")
                                    },
                                    confirm: {
                                        type: "footbar",
                                        text: _T("trustdevice", "confirm_revoke_all_devices"),
                                        color: "blue"
                                    }
                                });
                            case 2:
                                "confirm" === t.sent && this.untrustOthersDevices();
                            case 4:
                            case "end":
                                return t.stop()
                        }
                    }), t, this)
                }))), function() {
                    return En.apply(this, arguments)
                }),
                untrustOthersDevices: (Nn = Cn(regeneratorRuntime.mark((function t() {
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return this.loading = !0, this.showStatusBar = !0, this.successText = this.T("trustdevice", "revoked_all_trusted_success"), this.statusBarState = "loading", t.prev = 4, t.next = 7, this.untrustOtherDevices();
                            case 7:
                                this.statusBarState = "success", t.next = 13;
                                break;
                            case 10:
                                t.prev = 10, t.t0 = t.catch(4), this.statusBarState = "error";
                            case 13:
                                return t.prev = 13, this.loading = !1, t.finish(13);
                            case 16:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [4, 10, 13, 16]
                    ])
                }))), function() {
                    return Nn.apply(this, arguments)
                })
            }),
            components: {}
        },
        Rn = (n(90), d(Un, On, [], !1, null, "5c6a6569", null));
    Rn.options.__file = "src/dialogs/trusted-device.vue";
    var Mn = Rn.exports,
        Yn = function() {
            var t = this,
                e = t.$createElement,
                n = t._self._c || e;
            return n("v-message-box-window", {
                ref: "window",
                class: "syno-sds-personal-settings-identity-verification",
                attrs: {
                    "syno-id": "dialogs-identity-verification-message-box-window-0",
                    "do-confirm": t.onConfirm,
                    "loading-type": "spin"
                },
                scopedSlots: t._u([{
                    key: "content",
                    fn: function(e) {
                        var r = e.content;
                        return [n("v-form", {
                            attrs: {
                                "syno-id": "dialogs-identity-verification-form-0"
                            }
                        }, [n("v-form-item", {
                            attrs: {
                                textonly: "",
                                "hide-label": ""
                            }
                        }, [t._v("\n\t\t\t\t" + t._s(r) + "\n\t\t\t")]), t._v(" "), t.showEnterPasswordHint ? n("v-form-item", {
                            attrs: {
                                textonly: "",
                                "hide-label": ""
                            }
                        }, [t._v("\n\t\t\t\t" + t._s(t.T("personal_settings", "enter_password_to_continue")) + "\n\t\t\t")]) : t._e(), t._v(" "), n("v-form-item", {
                            ref: "password-form-item",
                            attrs: {
                                label: t.T("user", "user_passwd_current") + ":"
                            }
                        }, [n("v-input", {
                            attrs: {
                                "syno-id": "dialogs-identity-verification-input-0",
                                name: "password",
                                type: "password",
                                placeholder: ""
                            },
                            on: {
                                keyup: function(e) {
                                    return !e.type.indexOf("key") && t._k(e.keyCode, "enter", 13, e.key, "Enter") ? null : t.onEnter(e)
                                }
                            },
                            model: {
                                value: t.password,
                                callback: function(e) {
                                    t.password = e
                                },
                                expression: "password"
                            }
                        })], 1)], 1)]
                    }
                }])
            })
        };
    Yn._withStripped = !0;
    var In = {
            components: {},
            mixins: [i],
            props: {
                showEnterPasswordHint: {
                    type: Boolean,
                    default: !1
                }
            },
            data: function() {
                return {
                    password: ""
                }
            },
            computed: {},
            mounted: function() {},
            methods: {
                onEnter: function() {
                    this.$refs.window.onConfirmButton()
                },
                onConfirm: function() {
                    var t = this;
                    return this.$refs.window.setStatus("loading"), new Promise((function(e, n) {
                        return synowebapi.promises.request({
                            api: "SYNO.Core.User.PasswordConfirm",
                            method: "auth",
                            version: "1",
                            encryption: ["password"],
                            params: {
                                password: t.password
                            }
                        }).then((function(n) {
                            t.$refs["password-form-item"].resetInvalid(), e("confirm"), t.$refs.window.onClose()
                        })).catch((function(e) {
                            SYNO.Debug.error(e), t.$refs["password-form-item"].setInvalid(SYNO.API.Errors.core[e.code])
                        })).finally((function() {
                            t.$refs.window && t.$refs.window.setStatus("clear")
                        }))
                    }))
                }
            }
        },
        zn = (n(91), d(In, Yn, [], !1, null, null, null));
    zn.options.__file = "src/dialogs/identity-verification.vue";
    var Bn = zn.exports,
        Fn = n(65),
        Ln = n.n(Fn);

    function Wn(t) {
        return (Wn = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
            return typeof t
        } : function(t) {
            return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
        })(t)
    }

    function qn(t) {
        return "[object Date]" === Object.prototype.toString.apply(t)
    }

    function Vn(t) {
        var e = t instanceof Array ? [] : {};
        for (var n in t) null != t[n] && "object" === Wn(t[n]) ? e[n] = Vn(t[n]) : e[n] = t[n];
        return e
    }

    function Hn(t, e) {
        if (Wn(t) !== Wn(e)) return !1;
        if (qn(t) || qn(e)) return !(!qn(e) || !qn(t)) && t.getTime() === e.getTime();
        if ("object" === Wn(t)) {
            var n = Object.keys(t),
                r = Object.keys(e);
            if (n.length !== r.length) return !1;
            for (var s = 0; s < n.length; s++) {
                var i = n[s];
                if (!Object.prototype.hasOwnProperty.call(e, i)) return !1;
                if (!1 === Hn(t[i], e[i])) return !1
            }
            return !0
        }
        return t === e
    }

    function Kn(t, e, n, r, s, i, a) {
        try {
            var o = t[i](a),
                c = o.value
        } catch (t) {
            return void n(t)
        }
        o.done ? e(c) : Promise.resolve(c).then(r, s)
    }

    function Gn(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise((function(r, s) {
                var i = t.apply(e, n);

                function a(t) {
                    Kn(i, r, s, a, o, "next", t)
                }

                function o(t) {
                    Kn(i, r, s, a, o, "throw", t)
                }
                a(void 0)
            }))
        }
    }

    function Qn(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            })))), r.forEach((function(e) {
                Jn(t, e, n[e])
            }))
        }
        return t
    }

    function Jn(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }

    function Zn(t, e) {
        var n = function(t) {
                var e = [];
                for (var n in t.user) Object.prototype.hasOwnProperty.call(t.user, n) && t.user[n] !== t.originUser[n] && e.push(n);
                return e
            }(t),
            r = {},
            s = !0,
            i = !1,
            a = void 0;
        try {
            for (var o, c = n[Symbol.iterator](); !(s = (o = c.next()).done); s = !0) {
                var l = o.value;
                r[l] = t.user[l]
            }
        } catch (t) {
            i = !0, a = t
        } finally {
            try {
                s || null == c.return || c.return()
            } finally {
                if (i) throw a
            }
        }
        return e && (r.disableOTP = !0), r
    }

    function Xn(t) {
        return synowebapi.promises.request({
            api: "SYNO.Core.NormalUser",
            method: "set",
            version: 2,
            params: {
                password: t.password.fields.newPassword,
                old_password: t.password.fields.currentPassword
            },
            encryption: ["password", "old_password"]
        })
    }

    function tr(t) {
        return synowebapi.promises.request({
            api: "SYNO.Core.Directory.Domain",
            method: "set_password",
            version: 1,
            params: {
                password: t.password.fields.newPassword,
                old_password: t.password.fields.currentPassword
            },
            encryption: ["password", "old_password"]
        })
    }

    function er(t) {
        return synowebapi.promises.request({
            api: "SYNO.Core.Directory.LDAP.User",
            method: "set_pwd",
            version: 1,
            params: {
                new_pwd: t.password.fields.newPassword,
                old_pwd: t.password.fields.currentPassword
            },
            encryption: ["new_pwd", "old_pwd"]
        })
    }
    var nr, rr, sr = {
            namespaced: !0,
            state: {
                user: {
                    OTP_enable: void 0,
                    OTP_enforced: void 0,
                    disallowchpasswd: void 0,
                    editable: void 0,
                    email: void 0,
                    fullname: void 0,
                    username: void 0,
                    lang: void 0,
                    password_last_change: void 0,
                    change_password_url: void 0
                },
                isLDAP: void 0,
                isDomain: void 0,
                password: {
                    fields: {
                        currentPassword: void 0,
                        newPassword: void 0,
                        confirmPassword: void 0
                    },
                    rules: {}
                },
                hasEmail: void 0,
                passwordLastChangeLocale: void 0,
                originUser: {}
            },
            mutations: {
                UPDATE_USER: function(t, e) {
                    var n;
                    t.user = Qn({}, e), 0 === t.user.password_last_change ? t.passwordLastChangeLocale = '<span class="orange-status">' + _T("user", "user_acnt_mustchange") + "</span>" : 0 < t.user.password_last_change ? t.passwordLastChangeLocale = _T("personal_settings", "password_last_changed") + " : " + (n = new Date(24 * t.user.password_last_change * 60 * 60 * 1e3), SYNO.SDS.DateTimeFormatter(n, {
                        type: "date"
                    })) : t.passwordLastChangeLocale = _T("personal_settings", "password_last_changed") + " : -", t.originUser = Qn({}, e)
                },
                UPDATE_ACCOUNT_TYPE: function(t, e) {
                    t.isLDAP = !1, t.isDomain = !1, "ldap" === e ? t.isLDAP = !0 : "domain" === e && (t.isDomain = !0)
                },
                UPDATE_PASSWORD_RULES: function(t, e) {
                    t.password.rules = Qn({}, e)
                },
                CLEAR_PASSWORD_FIELDS: function(t) {
                    t.password.fields = {
                        currentPassword: void 0,
                        newPassword: void 0,
                        confirmPassword: void 0
                    }
                },
                SYNC_USER: function(t, e) {
                    t.originUser = Qn({}, t.user)
                },
                UPDATE_HAS_EMAIL: function(t, e) {
                    t.hasEmail = e
                }
            },
            getters: {
                isLangDirty: function(t) {
                    return t.originUser.lang !== t.user.lang
                },
                leaveCheckDirty: function(t) {
                    return function() {
                        return !Hn(t.originUser, t.user)
                    }
                }
            },
            actions: {
                clearPassword: function(t) {
                    var e = t.commit;
                    try {
                        e("CLEAR_PASSWORD_FIELDS")
                    } catch (t) {
                        throw SYNO.Debug.error(t), t
                    }
                },
                applyNewPassword: (rr = Gn(regeneratorRuntime.mark((function t(e) {
                    var n, r;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                if (n = e.commit, r = e.state, t.prev = 1, !r.isDomain) {
                                    t.next = 7;
                                    break
                                }
                                return t.next = 5, tr(r);
                            case 5:
                                t.next = 14;
                                break;
                            case 7:
                                if (!r.isLDAP) {
                                    t.next = 12;
                                    break
                                }
                                return t.next = 10, er(r);
                            case 10:
                                t.next = 14;
                                break;
                            case 12:
                                return t.next = 14, Xn(r);
                            case 14:
                                n("CLEAR_PASSWORD_FIELDS"), t.next = 21;
                                break;
                            case 17:
                                throw t.prev = 17, t.t0 = t.catch(1), SYNO.Debug.error(t.t0), t.t0;
                            case 21:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [1, 17]
                    ])
                }))), function(t) {
                    return rr.apply(this, arguments)
                }),
                applyUser: function(t, e) {
                    var n = t.commit,
                        r = t.state,
                        s = e.disableOTP;
                    return SYNO.SDS.UserSettings.setProperty("Personal", "lang", r.user.lang), Promise.all([new Promise((function(t, e) {
                        SYNO.SDS.UserSettings.save({
                            callback: function() {
                                return t()
                            }
                        })
                    })), synowebapi.promises.request({
                        api: "SYNO.Core.NormalUser",
                        method: "set",
                        version: 2,
                        params: Zn(r, s)
                    })]).then((function(t) {
                        n("SYNC_USER")
                    })).catch((function(t) {
                        SYNO.Debug.error(t.stack)
                    }))
                },
                getPasswordPolicy: function(t) {
                    var e = t.commit;
                    return synowebapi.promises.request({
                        api: "SYNO.Core.User.PasswordPolicy",
                        method: "get",
                        version: 1
                    }).then((function(t) {
                        var n = t.strong_password || {};
                        n.strong_password_enable = Object.keys(n).length > 0, e("UPDATE_PASSWORD_RULES", n)
                    })).catch((function(t) {
                        SYNO.Debug.error(t.stack)
                    }))
                },
                getMailAccount: (nr = Gn(regeneratorRuntime.mark((function t(e) {
                    var n, r, s, i, a;
                    return regeneratorRuntime.wrap((function(t) {
                        for (;;) switch (t.prev = t.next) {
                            case 0:
                                return n = e.commit, (r = []).push({
                                    api: "SYNO.Core.Notification.Mail.Conf",
                                    method: "getEnable",
                                    version: 1
                                }), r.push({
                                    api: "SYNO.PersonMailAccount",
                                    method: "get",
                                    version: 1
                                }), t.prev = 4, t.next = 7, synowebapi.promises.request({
                                    params: {},
                                    compound: {
                                        params: r
                                    },
                                    scope: this
                                });
                            case 7:
                                s = t.sent, i = SYNO.API.Response.GetValByAPI(s, "SYNO.Core.Notification.Mail.Conf", "getEnable", "enable_mail"), a = SYNO.API.Response.GetValByAPI(s, "SYNO.PersonMailAccount", "get", "data"), n("UPDATE_HAS_EMAIL", i || a.length > 0), t.next = 17;
                                break;
                            case 13:
                                throw t.prev = 13, t.t0 = t.catch(4), SYNO.Debug.error(t.t0.stack), t.t0;
                            case 17:
                            case "end":
                                return t.stop()
                        }
                    }), t, this, [
                        [4, 13]
                    ])
                }))), function(t) {
                    return nr.apply(this, arguments)
                }),
                getUser: function(t) {
                    var e = t.commit;
                    return synowebapi.promises.request({
                        api: "SYNO.Core.NormalUser",
                        method: "get",
                        version: 1
                    }).then((function(t) {
                        var n = SYNO.SDS.UserSettings.getProperty("Personal", "lang") || "def";
                        t.lang = n, e("UPDATE_USER", t)
                    })).catch((function(t) {
                        SYNO.Debug.error(t.stack)
                    }))
                },
                getAccountType: function(t) {
                    (0, t.commit)("UPDATE_ACCOUNT_TYPE", _S("authType"))
                }
            }
        },
        ir = {
            namespaced: !0,
            state: {
                allLang: []
            },
            mutations: {
                UPDATE_LANGS: function(t, e) {
                    t.allLang = e
                }
            },
            actions: {
                listLangs: function(t) {
                    var e = t.commit,
                        n = SYNO.SDS.Utils.getSupportedLanguage();
                    n.unshift(["def", _T("common", "sys_default_setting")]), e("UPDATE_LANGS", n.reduce((function(t, e) {
                        return t.push({
                            value: e[0],
                            label: e[1]
                        }), t
                    }), []))
                }
            }
        };

    function ar(t, e, n, r, s, i, a) {
        try {
            var o = t[i](a),
                c = o.value
        } catch (t) {
            return void n(t)
        }
        o.done ? e(c) : Promise.resolve(c).then(r, s)
    }

    function or(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise((function(r, s) {
                var i = t.apply(e, n);

                function a(t) {
                    ar(i, r, s, a, o, "next", t)
                }

                function o(t) {
                    ar(i, r, s, a, o, "throw", t)
                }
                a(void 0)
            }))
        }
    }

    function cr(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }

    function lr(t) {
        var e = [],
            n = [],
            r = !0,
            s = !1,
            i = void 0;
        try {
            for (var a, o = t.items[Symbol.iterator](); !(r = (a = o.next()).done); r = !0) {
                var c = a.value;
                c.from === fr.details.ip && ("HTTP/HTTPS" === c.type ? n.push({
                    who: c.who,
                    from: c.from
                }) : e.push({
                    pid: c.pid,
                    type: c.type,
                    who: c.who,
                    from: c.from
                }))
            }
        } catch (t) {
            s = !0, i = t
        } finally {
            try {
                r || null == o.return || o.return()
            } finally {
                if (s) throw i
            }
        }
        return {
            serviceConns: e,
            httpConns: n
        }
    }
    var ur, pr, dr, fr = {
            details: {
                token_status: void 0,
                ip_status: void 0,
                country: void 0,
                country_status: void 0,
                browser: void 0,
                ip: void 0,
                ip_trusted: void 0,
                is_public_ip: void 0,
                os: void 0,
                protocol: void 0,
                time: void 0,
                token_recorded: void 0,
                token_trusted: void 0,
                user: void 0
            },
            selected: {
                login_history: void 0
            }
        },
        mr = {
            UPDATE_PERSONAL_ACTIVITY: function(t, e) {
                var n;
                t.details = function(t) {
                        for (var e = 1; e < arguments.length; e++) {
                            var n = null != arguments[e] ? Object(arguments[e]) : {},
                                r = Object.keys(n);
                            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                                return Object.getOwnPropertyDescriptor(n, t).enumerable
                            })))), r.forEach((function(e) {
                                cr(t, e, n[e])
                            }))
                        }
                        return t
                    }({}, e), (n = t.details).token_recorded ? n.token_trusted ? n.token_status = _T("personal_settings", "info_is_trusted") : n.token_status = _T("personal_settings", "info_is_untrusted") : n.token_status = _T("personal_settings", "info_is_unavailable"),
                    function(t) {
                        var e = t.details;
                        e.ip ? e.is_public_ip ? e.ip_trusted ? e.ip_status = "".concat(e.ip, ", ").concat(_T("personal_settings", "info_is_trusted")) : e.ip_status = "".concat(e.ip, ", ").concat(_T("personal_settings", "info_is_untrusted")) : e.ip_status = "".concat(e.ip, ", ").concat(_T("personal_settings", "ignore_private_ip")) : e.ip_status = _T("personal_settings", "info_is_unavailable")
                    }(t),
                    function(t) {
                        var e = t.details;
                        e.country ? e.country_status = e.country : e.country_status = _T("personal_settings", "geoip_lookup_failed")
                    }(t)
            },
            UPDATE_SELECT_LOGIN_HISTORY: function(t, e) {
                t.selected.login_history = e
            }
        },
        hr = {
            selectedLoginHistory: function(t, e) {
                (0, t.commit)("UPDATE_SELECT_LOGIN_HISTORY", e)
            },
            getPersonalActivity: function(t, e) {
                var n = t.commit,
                    r = t.state;
                return synowebapi.promises.request({
                    api: "SYNO.Core.SyslogClient.PersonalActivity",
                    method: "get",
                    version: 1,
                    params: {
                        db_path: r.selected.login_history.db_path,
                        record_id: r.selected.login_history.id
                    }
                }).then((function(t) {
                    n("UPDATE_PERSONAL_ACTIVITY", t.record)
                })).catch((function(t) {
                    SYNO.Debug.error(t.stack)
                }))
            },
            listCurrentConnection: (dr = or(regeneratorRuntime.mark((function t(e, n) {
                var r;
                return regeneratorRuntime.wrap((function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return t.prev = 0, t.next = 3, synowebapi.promises.request({
                                api: "SYNO.Core.CurrentConnection",
                                method: "list_by_user",
                                version: "1"
                            });
                        case 3:
                            return r = t.sent, t.abrupt("return", r);
                        case 7:
                            throw t.prev = 7, t.t0 = t.catch(0), SYNO.Debug.error(t.t0.stack), t.t0;
                        case 11:
                        case "end":
                            return t.stop()
                    }
                }), t, this, [
                    [0, 7]
                ])
            }))), function(t, e) {
                return dr.apply(this, arguments)
            }),
            untrustAll: (pr = or(regeneratorRuntime.mark((function t(e, n) {
                var r, s, i, a, o;
                return regeneratorRuntime.wrap((function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return e.commit, e.state, r = e.dispatch, t.next = 3, r("listCurrentConnection");
                        case 3:
                            return s = t.sent, i = lr(s), a = i.serviceConns, o = i.httpConns, t.prev = 5, t.next = 8, synowebapi.promises.request({
                                api: "SYNO.Core.CurrentConnection",
                                method: "kick_connection",
                                version: 1,
                                timeout: 45e4,
                                params: {
                                    service_conn: a,
                                    http_conn: o
                                }
                            });
                        case 8:
                            t.next = 14;
                            break;
                        case 10:
                            throw t.prev = 10, t.t0 = t.catch(5), SYNO.Debug.error(t.t0.stack), t.t0;
                        case 14:
                        case "end":
                            return t.stop()
                    }
                }), t, this, [
                    [5, 10]
                ])
            }))), function(t, e) {
                return pr.apply(this, arguments)
            }),
            clearRecord: (ur = or(regeneratorRuntime.mark((function t(e, n) {
                var r;
                return regeneratorRuntime.wrap((function(t) {
                    for (;;) switch (t.prev = t.next) {
                        case 0:
                            return e.commit, r = e.state, t.prev = 1, t.next = 4, synowebapi.promises.request({
                                api: "SYNO.Core.SyslogClient.PersonalActivity",
                                method: "clear",
                                version: 1,
                                params: {
                                    record_id: r.selected.login_history.id
                                }
                            });
                        case 4:
                            t.next = 10;
                            break;
                        case 6:
                            throw t.prev = 6, t.t0 = t.catch(1), SYNO.Debug.error(t.t0.stack), t.t0;
                        case 10:
                        case "end":
                            return t.stop()
                    }
                }), t, this, [
                    [1, 6]
                ])
            }))), function(t, e) {
                return ur.apply(this, arguments)
            })
        },
        vr = {
            namespaced: !0,
            state: fr,
            mutations: mr,
            actions: hr,
            getters: {
                isTrusted: function(t) {
                    return t.details.token_recorded && t.details.token_trusted
                },
                isSelected: function(t) {
                    return t.selected.login_history
                }
            }
        },
        _r = {
            namespaced: !0,
            state: {
                locked: void 0,
                current_trusted: void 0,
                current_id: void 0,
                enabled: void 0
            },
            mutations: {
                UPDATE_LOCKED_STATUS: function(t, e) {
                    t.locked = e
                },
                UPDATE_ENABLED_STATUS: function(t, e) {
                    t.enabled = e
                },
                UPDATE_CURRENT_TRUSTED: function(t, e) {
                    t.current_trusted = e.current_trusted, t.current_id = e.current_id
                }
            },
            actions: {
                trustUser: function(t, e) {
                    t.commit, t.state;
                    var n = t.dispatch;
                    return synowebapi.promises.request({
                        api: "SYNO.Core.SmartBlock.User",
                        method: "trust",
                        version: 1
                    }).then((function(t) {
                        n("getCurrentTrustedStatus")
                    })).catch((function(t) {
                        SYNO.Debug.error(t.stack)
                    }))
                },
                pardonUser: function(t, e) {
                    t.commit, t.state;
                    var n = t.dispatch;
                    return synowebapi.promises.request({
                        api: "SYNO.Core.SmartBlock.User",
                        method: "pardon",
                        version: 1
                    }).then((function(t) {
                        return n("getSmartBlockLockedStatus")
                    })).catch((function(t) {
                        SYNO.Debug.error(t.stack)
                    }))
                },
                getSmartBlockLockedStatus: function(t, e) {
                    var n = t.commit;
                    t.state;
                    return synowebapi.promises.request({
                        api: "SYNO.Core.SmartBlock.User",
                        method: "locked",
                        version: 1
                    }).then((function(t) {
                        n("UPDATE_LOCKED_STATUS", t.locked)
                    })).catch((function(t) {
                        SYNO.Debug.error(t.stack)
                    }))
                },
                getSmartBlockEnabledStatus: function(t, e) {
                    var n = t.commit;
                    t.state;
                    return synowebapi.promises.request({
                        api: "SYNO.Core.SmartBlock.User",
                        method: "enabled",
                        version: 1
                    }).then((function(t) {
                        n("UPDATE_ENABLED_STATUS", t.enabled)
                    })).catch((function(t) {
                        SYNO.Debug.error(t.stack)
                    }))
                },
                getCurrentTrustedStatus: function(t, e) {
                    var n = t.commit;
                    t.state;
                    return synowebapi.promises.request({
                        api: "SYNO.Core.SmartBlock.Device",
                        method: "get",
                        version: 1
                    }).then((function(t) {
                        n("UPDATE_CURRENT_TRUSTED", {
                            current_trusted: !0,
                            current_id: t.id
                        })
                    })).catch((function(t) {
                        n("UPDATE_CURRENT_TRUSTED", {
                            current_trusted: !1,
                            current_id: null
                        })
                    }))
                }
            }
        };

    function gr(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }
    var br = {
            namespaced: !0,
            state: {
                self_trusted: void 0,
                info: {
                    ctime: void 0,
                    device: void 0,
                    id: void 0,
                    mtime: void 0,
                    name: void 0
                },
                ctimeLocale: void 0
            },
            mutations: {
                UPDATE_INFO: function(t, e) {
                    var n;
                    t.info = function(t) {
                        for (var e = 1; e < arguments.length; e++) {
                            var n = null != arguments[e] ? Object(arguments[e]) : {},
                                r = Object.keys(n);
                            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                                return Object.getOwnPropertyDescriptor(n, t).enumerable
                            })))), r.forEach((function(e) {
                                gr(t, e, n[e])
                            }))
                        }
                        return t
                    }({}, e), t.ctimeLocale = (n = new Date(1e3 * t.info.ctime), SYNO.SDS.DateTimeFormatter(n, {
                        type: "date"
                    }))
                },
                UNTRUST: function(t) {
                    t.self_trusted = !1
                },
                TRUST: function(t) {
                    t.self_trusted = !0
                }
            },
            actions: {
                getDeviceInfo: function(t) {
                    var e = t.commit;
                    return synowebapi.promises.request({
                        api: "SYNO.Core.TrustDevice",
                        method: "get",
                        version: 1
                    }).then((function(t) {
                        e("UPDATE_INFO", t), e("TRUST")
                    })).catch((function(t) {
                        e("UNTRUST")
                    }))
                },
                trust: function(t) {
                    var e, n, r = t.commit;
                    return synowebapi.promises.request({
                        api: "SYNO.Core.TrustDevice",
                        version: 1,
                        method: "create",
                        params: {
                            name: (e = "others", n = "others", Ext.isLinux ? e = "Linux" : Ext.isMac ? e = "Mac" : Ext.isWindows && (e = "Windows"), Ext.isGecko ? n = "FireFox" : Ext.isIE ? n = "IE" : Ext.isChrome ? n = "Chrome" : Ext.isOpera ? n = "Opera" : Ext.isSafari ? n = "Safari" : Ext.isEdge && (n = "Edge"), "".concat(e, "-").concat(n))
                        }
                    }).then((function(t) {
                        r("UPDATE_INFO", t), r("TRUST")
                    })).catch((function(t) {
                        SYNO.Debug.error(t)
                    }))
                },
                untrustThisDevice: function(t) {
                    var e = t.commit;
                    return synowebapi.promises.request({
                        api: "SYNO.Core.TrustDevice",
                        version: 1,
                        method: "delete"
                    }).then((function(t) {
                        e("UNTRUST")
                    })).catch((function(t) {
                        throw SYNO.Debug.error(t), t
                    }))
                },
                untrustOtherDevices: function(t) {
                    t.commit;
                    return synowebapi.promises.request({
                        api: "SYNO.Core.TrustDevice",
                        version: 1,
                        method: "delete_others"
                    }).then((function(t) {})).catch((function(t) {
                        throw SYNO.Debug.error(t), t
                    }))
                }
            }
        },
        yr = n(36),
        wr = n.n(yr);

    function Sr(t, e, n, r, s, i, a) {
        try {
            var o = t[i](a),
                c = o.value
        } catch (t) {
            return void n(t)
        }
        o.done ? e(c) : Promise.resolve(c).then(r, s)
    }

    function xr(t) {
        return function() {
            var e = this,
                n = arguments;
            return new Promise((function(r, s) {
                var i = t.apply(e, n);

                function a(t) {
                    Sr(i, r, s, a, o, "next", t)
                }

                function o(t) {
                    Sr(i, r, s, a, o, "throw", t)
                }
                a(void 0)
            }))
        }
    }

    function kr(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            })))), r.forEach((function(e) {
                Tr(t, e, n[e])
            }))
        }
        return t
    }

    function Tr(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }
    var Dr, Or, Pr;

    function Cr() {
        return SYNO.SDS.ThemeProvider.getThemeCls() === SYNO.SDS.DSM.Themer.BUSINESS
    }

    function Ar() {
        var t = SYNO.SDS.UserSettings.getProperty("Desktop", "desktopStyle");
        return t || (t = Cr() ? "classical" : "normal")
    }

    function jr(t, e) {
        return t.background_color !== e.background_color || t.customize_background !== e.customize_background || t.customize_background_type !== e.customize_background_type || t.index !== e.index || t.wallpaper !== e.wallpaper || t.wallpaper_path !== e.wallpaper_path || t.wallpaper_position !== e.wallpaper_position || t.wallpaper_type !== e.wallpaper_type || t.text_color !== e.text_color || e.newImage
    }

    function Nr(t) {
        for (var e = 1; e < arguments.length; e++) {
            var n = null != arguments[e] ? Object(arguments[e]) : {},
                r = Object.keys(n);
            "function" == typeof Object.getOwnPropertySymbols && (r = r.concat(Object.getOwnPropertySymbols(n).filter((function(t) {
                return Object.getOwnPropertyDescriptor(n, t).enumerable
            })))), r.forEach((function(e) {
                Er(t, e, n[e])
            }))
        }
        return t
    }

    function Er(t, e, n) {
        return e in t ? Object.defineProperty(t, e, {
            value: n,
            enumerable: !0,
            configurable: !0,
            writable: !0
        }) : t[e] = n, t
    }
    var $r = {
            UserModule: sr,
            LangModule: ir,
            AccountActivityModule: vr,
            SmartBlockModule: _r,
            TrustedDeviceModule: br,
            PreferencesModule: {
                namespaced: !0,
                state: {
                    originPreferences: {},
                    originDateFormat: void 0,
                    originTimeFormat: void 0,
                    emptyWallpaper: !1,
                    preferences: {
                        menu_style: void 0,
                        icon_size: void 0,
                        wallpaper: {
                            customize_background: void 0,
                            background_color: void 0,
                            classical_desktop: void 0,
                            customize_color: void 0,
                            customize_wallpaper: void 0,
                            wallpaper: void 0,
                            wallpaper_ext: void 0,
                            wallpaper_path: void 0,
                            wallpaper_position: "fill",
                            wallpaper_type: void 0,
                            customize_background_type: void 0,
                            text_color: void 0,
                            version: void 0,
                            newImage: !1
                        },
                        version: void 0
                    },
                    date_format: void 0,
                    time_format: void 0,
                    customize_colors: void 0
                },
                mutations: {
                    MIGRATE_FROM_OLD_VERSION: function(t) {
                        var e;
                        t.preferences.wallpaper.version && 2 === t.preferences.wallpaper.version || (t.preferences.wallpaper && (t.preferences.wallpaper.customize_background = !(!t.preferences.wallpaper.customize_wallpaper && !t.preferences.wallpaper.customize_color), t.preferences.wallpaper.customize_background ? t.preferences.wallpaper.customize_background_type = t.preferences.wallpaper.customize_wallpaper ? "image" : "color" : (t.preferences.wallpaper.customize_background_type = "image", t.preferences.wallpaper.wallpaper_path = (e = "1x", SYNO.SDS.UIFeatures.IconSizeManager.isRetinaMode() && (e = "2x"), "/usr/syno/synoman/webman/resources/images/".concat(e, "/default_wallpaper/dsm7_01.jpg")))), t.preferences.wallpaper.customize_color || (t.preferences.wallpaper.background_color = "#FFFFFF", t.preferences.wallpaper.text_color = void 0), delete t.preferences.wallpaper.customize_color, delete t.preferences.wallpaper.customize_wallpaper, t.preferences.version = 2, t.preferences.wallpaper.version = 2)
                    },
                    UPDATE_PREF: function(t, e) {
                        e.menu_style && (t.preferences.menu_style = e.menu_style), e.icon_size && (t.preferences.icon_size = e.icon_size), e.wallpaper && (t.preferences.wallpaper = Object.assign(t.preferences.wallpaper, e.wallpaper))
                    },
                    SET_EMPTY_WALLPAPER: function(t, e) {
                        t.emptyWallpaper = e
                    },
                    COMMIT_PREF: function(t, e) {
                        t.originPreferences = wr()(t.preferences)
                    },
                    UPDATE_DATE: function(t, e) {
                        t.date_format = e, t.originDateFormat = t.date_format
                    },
                    UPDATE_TIME: function(t, e) {
                        t.time_format = e, t.originTimeFormat = t.time_format
                    },
                    SET_DATE: function(t, e) {
                        t.date_format = e
                    },
                    SET_TIME: function(t, e) {
                        t.time_format = e
                    },
                    UPDATE_CUSTOMIZED_COLORS: function(t, e) {
                        t.customize_colors = e
                    },
                    SET_NEW_IMAGE: function(t, e) {
                        t.preferences.wallpaper.newImage = e
                    },
                    ADD_CUSTMIZED_COLOR: function(t, e) {
                        t.customize_colors.unshift(e), t.customize_colors.length > 30 && (t.customize_colors = t.customize_colors.slice(0, 30))
                    }
                },
                getters: {
                    isDesktopStyleDirty: function(t) {
                        return t.originPreferences.icon_size !== t.preferences.icon_size
                    },
                    isDateFormatDirty: function(t) {
                        return t.originDateFormat !== t.date_format
                    },
                    isTimeFormatDirty: function(t) {
                        return t.originTimeFormat !== t.time_format
                    },
                    isWallpaperDirty: function(t) {
                        return function() {
                            var e = t.originPreferences,
                                n = t.preferences;
                            return jr(e.wallpaper, n.wallpaper)
                        }
                    },
                    leaveCheckDirty: function(t) {
                        return function() {
                            var e = t.originPreferences,
                                n = t.preferences;
                            return !Hn(e.icon_size, n.icon_size) || !Hn(e.menu_style, n.menu_style) || jr(e.wallpaper, n.wallpaper) || !Hn(t.originDateFormat, t.date_format) || !Hn(t.originTimeFormat, t.time_format)
                        }
                    }
                },
                actions: {
                    applyFormats: function(t) {
                        t.commit;
                        var e = t.state;
                        SYNO.SDS.DateTimeUtils.SetUserFormat("date", e.date_format), SYNO.SDS.DateTimeUtils.SetUserFormat("time", e.time_format)
                    },
                    getPreferences: (Pr = xr(regeneratorRuntime.mark((function t(e) {
                        var n;
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    (n = e.commit)("SET_EMPTY_WALLPAPER", !SYNO.SDS.UserSettings.getProperty("Desktop", "wallpaper")), n("UPDATE_PREF", {
                                        menu_style: (r = void 0, r = SYNO.SDS.UserSettings.getProperty("Desktop", "appMenuStyle"), r || (r = Cr() ? "classical" : "fullscreen")),
                                        icon_size: Ar(),
                                        wallpaper: kr({}, SYNO.SDS.UserSettings.getProperty("Desktop", "wallpaper"))
                                    }), n("MIGRATE_FROM_OLD_VERSION"), n("COMMIT_PREF");
                                case 5:
                                case "end":
                                    return t.stop()
                            }
                            var r
                        }), t, this)
                    }))), function(t) {
                        return Pr.apply(this, arguments)
                    }),
                    getFormats: function(t) {
                        var e = t.commit;
                        e("UPDATE_DATE", SYNO.SDS.DateTimeUtils.GetDateFormat()), e("UPDATE_TIME", SYNO.SDS.DateTimeUtils.GetTimeFormat())
                    },
                    restorePreferences: (Or = xr(regeneratorRuntime.mark((function t(e) {
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    e.state;
                                case 1:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this)
                    }))), function(t) {
                        return Or.apply(this, arguments)
                    }),
                    applyPreferences: function(t) {
                        var e = t.dispatch,
                            n = t.commit,
                            r = t.state;
                        return new Promise((function(t, s) {
                            var i, a;
                            r.preferences.wallpaper.wallpaper = 1 + (r.preferences.wallpaper.wallpaper || 0), SYNO.SDS.UserSettings.setProperty("Desktop", "wallpaper", (i = r.preferences.wallpaper, a = ["customize_background", "background_color", "classical_desktop", "customize_color", "customize_wallpaper", "wallpaper", "wallpaper_ext", "wallpaper_path", "wallpaper_position", "wallpaper_type", "customize_background_type", "text_color", "version", "newImage"], Object.keys(i).filter((function(t) {
                                return a.includes(t)
                            })).reduce((function(t, e) {
                                return t[e] = i[e], t
                            }), {}))), SYNO.SDS.UserSettings.setProperty("Desktop", "appMenuStyle", r.preferences.menu_style), SYNO.SDS.UserSettings.setProperty("Desktop", "desktopStyle", r.preferences.icon_size), SYNO.SDS.UserSettings.save({
                                callback: function() {
                                    n("COMMIT_PREF"), e("setNewImageFlag", !1), SYNO.SDS.UserSettings.setProperty("Desktop", "wallpaper", function(t) {
                                        var e = ["customize_background", "background_color", "classical_desktop", "customize_color", "customize_wallpaper", "wallpaper", "wallpaper_ext", "wallpaper_path", "wallpaper_position", "wallpaper_type", "customize_background_type", "text_color", "version"];
                                        return Object.keys(t).filter((function(t) {
                                            return e.includes(t)
                                        })).reduce((function(e, n) {
                                            return e[n] = t[n], e
                                        }), {})
                                    }(r.preferences.wallpaper)), t()
                                }
                            })
                        }))
                    },
                    setNewWallpaper: (Dr = xr(regeneratorRuntime.mark((function t(e, n) {
                        return regeneratorRuntime.wrap((function(t) {
                            for (;;) switch (t.prev = t.next) {
                                case 0:
                                    (0, e.commit)("UPDATE_PREF", {
                                        wallpaper: kr({}, n, {
                                            newImage: !0
                                        })
                                    });
                                case 2:
                                case "end":
                                    return t.stop()
                            }
                        }), t, this)
                    }))), function(t, e) {
                        return Dr.apply(this, arguments)
                    }),
                    setNewImageFlag: function(t, e) {
                        (0, t.commit)("SET_NEW_IMAGE", e)
                    },
                    getCustomizedColors: function(t) {
                        (0, t.commit)("UPDATE_CUSTOMIZED_COLORS", SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "cusomized_colors") || [])
                    },
                    addCustomizedColor: function(t, e) {
                        var n = t.commit,
                            r = t.state;
                        n("ADD_CUSTMIZED_COLOR", e), SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "cusomized_colors", r.customize_colors)
                    }
                }
            },
            OthersModule: {
                namespaced: !0,
                state: {
                    settings: {},
                    formSettings: {},
                    originFormSettings: {}
                },
                mutations: {
                    UPDATE_SETTINGS: function(t, e) {
                        t.settings = Nr({}, e)
                    },
                    UPDATE_FORM_SETTINGS: function(t, e) {
                        t.formSettings = Nr({}, e), t.originFormSettings = wr()(t.formSettings)
                    }
                },
                getters: {
                    leaveCheckDirty: function(t) {
                        return function() {
                            return !Hn(t.originFormSettings, t.formSettings)
                        }
                    }
                },
                actions: {
                    getSettings: function(t) {
                        var e = t.commit,
                            n = {
                                rememberWindowState: SYNO.SDS.UserSettings.getProperty("Desktop", "rememberWindowState") || !1,
                                enableTaskbarThumbnail: !1 !== SYNO.SDS.UserSettings.getProperty("Desktop", "enableTaskbarThumbnail"),
                                hotkeyDisabled: SYNO.SDS.UserSettings.getProperty("Desktop", "hotkey_disabled"),
                                disableAccessibility: SYNO.SDS.UserSettings.getProperty("Desktop", "disableAccessibility") || !1,
                                enableDesktopNotification: SYNO.SDS.UserSettings.getProperty("Desktop", "enableDesktopNotification") || !1
                            };
                        e("UPDATE_SETTINGS", n), e("UPDATE_FORM_SETTINGS", function(t) {
                            return {
                                rememberWindowState: t.rememberWindowState,
                                enableTaskbarThumbnail: t.enableTaskbarThumbnail,
                                hotkeyEnabled: !t.hotkeyDisabled,
                                disableAccessibility: t.disableAccessibility,
                                enableDesktopNotification: t.enableDesktopNotification
                            }
                        }(n))
                    },
                    applySettings: function(t) {
                        var e = t.commit,
                            n = t.state;
                        e("UPDATE_SETTINGS", function(t) {
                            return {
                                rememberWindowState: t.rememberWindowState,
                                enableTaskbarThumbnail: t.enableTaskbarThumbnail,
                                hotkeyDisabled: !t.hotkeyEnabled,
                                disableAccessibility: t.disableAccessibility,
                                enableDesktopNotification: t.enableDesktopNotification
                            }
                        }(n.formSettings));
                        var r = n.settings;
                        SYNO.SDS.UserSettings.setProperty("Desktop", "rememberWindowState", r.rememberWindowState), SYNO.SDS.UserSettings.setProperty("Desktop", "enableTaskbarThumbnail", r.enableTaskbarThumbnail), SYNO.SDS.UserSettings.setProperty("Desktop", "hotkey_disabled", r.hotkeyDisabled), SYNO.SDS.UserSettings.setProperty("Desktop", "disableAccessibility", r.disableAccessibility), SYNO.SDS.UserSettings.setProperty("Desktop", "enableDesktopNotification", r.enableDesktopNotification)
                    }
                }
            },
            ActionModule: {
                namespaced: !0,
                state: {
                    refreshEmailDataTable: void 0
                },
                mutations: {
                    UPDATE_REFRESH_FLAG: function(t, e) {
                        t[e.key] = e.value
                    }
                },
                actions: {
                    refreshEmail: function(t) {
                        (0, t.commit)("UPDATE_REFRESH_FLAG", {
                            key: "refreshEmailDataTable",
                            value: !0
                        })
                    },
                    actionDone: function(t, e) {
                        (0, t.commit)("UPDATE_REFRESH_FLAG", {
                            key: e,
                            value: !1
                        })
                    }
                }
            },
            MailModule: {
                namespaced: !0,
                state: {
                    synomail: []
                },
                mutations: {
                    UPDATE_SYNO_MAIL_CONFIG: function(t, e) {
                        t.synomail = e.reduce((function(t, e) {
                            return t.push({
                                label: e.mail,
                                value: e.mail
                            }), t
                        }), [])
                    }
                },
                actions: {
                    getSynoMailConfig: function(t) {
                        var e = t.commit;
                        return synowebapi.promises.request({
                            api: "SYNO.MailClient.Setting.SMTP",
                            method: "list",
                            version: 1
                        }).then((function(t) {
                            e("UPDATE_SYNO_MAIL_CONFIG", t.smtp)
                        })).catch((function(t) {}))
                    }
                }
            }
        },
        Ur = Object.create(null);
    for (var Rr in $r) {
        var Mr = $r[Rr];
        Ur[Rr] = Vn(Mr.state)
    }
    var Yr = new c.a.Store({
            modules: $r,
            mutations: {
                RESET: function(t) {
                    for (var e in Ur) {
                        var n = Ur[e];
                        t[e] = Vn(n)
                    }
                }
            }
        }),
        Ir = Ln.a.extend({
            store: Yr
        });
    n(163);
    Ext.namespace("SYNO.SDS.App.PersonalSettings.Vue"), 
/**
 * @class SYNO.SDS.App.PersonalSettings.Vue.TrustedDeviceDialog
 * PersonalSettings trusted device dialog class
 *
 */
    SYNO.SDS.App.PersonalSettings.Vue.TrustedDeviceDialog = Ir.extend(Mn), SYNO.SDS.App.PersonalSettings.Vue.TrustedClientsDialog = Ir.extend(Dn), SYNO.SDS.App.PersonalSettings.Vue.AccountProtectionDialog = Ir.extend(bn), SYNO.SDS.App.PersonalSettings.Vue.LoginHistoryDialog = Ir.extend(un), SYNO.SDS.App.PersonalSettings.Vue.IdentityVerificationDialog = Ir.extend(Bn), SYNO.SDS.App.PersonalSettings.Vue.AccountActivity = Ir.extend(tn), SYNO.SDS.App.PersonalSettings.Vue.ChangePassword = Ir.extend(qe), // @require: SYNO.SDS.OTPWizard.MainWindow
        // @require: SYNO.SDS.Utils.ImageSelector
        SYNO.SDS.App.PersonalSettings.Instance = Ir.extend($t), SYNO.SDS.App.PersonalSettings.Vue.EmailWizard = Ir.extend(Pe), SYNO.SDS.App.PersonalSettings.Vue.EmailEdit = Ir.extend(Me)
}]);
