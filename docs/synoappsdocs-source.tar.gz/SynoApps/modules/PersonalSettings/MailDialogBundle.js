/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.App.MailDialog.Application
 * @extends SYNO.SDS.AppInstance
 * PersonalSettings mail dialog application instance class
 *
 */
Ext.define("SYNO.SDS.App.MailDialog.Application", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.App.MailDialog.MainWindow",
    constructor: function() {
        this.callParent(arguments)
    }
});
Ext.define("SYNO.SDS.App.MailDialog.MainWindow", {
    extend: "SYNO.SDS.AppWindow",
    constructor: function() {
        this.isSetAttach = false;
        this.contactCacheData = {};
        this.email_type = SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_type");
        this.alias = SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_alias");
        var a = this.fillConfig();
        this.callParent([a])
    },
    fillConfig: function() {
        Ext.apply(this);
        var a = {
            owner: this.owner,
            width: 700,
            autoHeight: true,
            collapsible: false,
            resizable: false,
            showHelp: true,
            maximizable: false,
            title: _T("mail", "application_title"),
            buttons: [{
                text: _T("common", "cancel"),
                handler: this.onClose,
                scope: this
            }, {
                btnStyle: "blue",
                itemId: "submit_button",
                text: _T("common", "send"),
                handler: this.onBeforeConfirm,
                disabled: _S("demo_mode"),
                scope: this
            }],
            items: this.initPanel()
        };
        return a
    },
    initPanel: function() {
        var e = this;
        e.store = new Ext.data.JsonStore({
            fields: ["name", "address"],
            data: [],
            sortInfo: {
                field: "address",
                direction: "ASC"
            }
        });
        e.attachmentStore = new Ext.data.JsonStore({
            fields: ["filename", "path", "filesize", "formatsize", "deleted"],
            data: []
        });
        e.comboStore = new Ext.data.ArrayStore({
            fields: ["alias", "value", "account"],
            data: []
        });
        var c = new Ext.XTemplate('<tpl for="."><div class="x-combo-list-item" style="height: 53px"><div style="margin-left:10px"><tpl if="name!=address;"><div style="height:20px;margin-top:4px;font-weight:bold;">{name:htmlEncode}</div></tpl><div class="syno-mail-contactaccount">{address:htmlEncode}</div></div></div></tpl>');
        var f = new Ext.XTemplate('<tpl for="."><div class="x-combo-list-item" style="width:375px;border-color:transparent;"><div style="max-width:250px;overflow:hidden;float:left;text-overflow:ellipsis; white-space:nowrap;">{filename}</div> <div style="margin-left:5px;float:left;">({formatsize})</div></div></tpl>');
        var h = new Ext.XTemplate('<tpl if"name!=null && name!=&quot;&quot;";>{name:htmlEncode}</tpl><tpl if="name==null || name==&quot;&quot;">{address:htmlEncode}</tpl>');
        var g = function(j) {
            var i = new RegExp("^" + j.query + "|\\s+" + j.query, "gi");
            this.store.filterBy(function(k) {
                if (k.data.name && null !== k.data.name.match(i)) {
                    return true
                }
                if (k.data.address && null !== k.data.address.match(i)) {
                    return true
                }
                return false
            });
            j.combo.onLoad();
            return false
        };
        var d = function(j, i) {
            if ("" === i) {
                return
            }
            j.addNewItem({
                name: i,
                address: i
            }, true)
        };
        var b = {
            autoFlexcroll: true,
            autoHeight: true,
            cls: "mail-dialog-superboxselect",
            useGradient: false,
            items: [{
                xtype: "syno_superboxselect",
                fieldLabel: _T("mail", "mail_to_desc"),
                expandBtnCls: "mail-dialog-superboxselect-expand",
                itemId: "mail_to_field",
                width: 465,
                hideTrigger: true,
                typeAhead: false,
                allowBlank: false,
                displayField: "name",
                displayFieldTpl: h,
                vtype: "email",
                valueField: "address",
                allowAddNewData: true,
                addNewDataOnBlur: true,
                mode: "local",
                tpl: c,
                listeners: {
                    newitem: d,
                    beforequery: g,
                    scope: this
                },
                store: e.store
            }, {
                xtype: "syno_superboxselect",
                fieldLabel: _T("mail", "mail_cc_desc"),
                itemId: "mail_cc_field",
                expandBtnCls: "mail-dialog-superboxselect-expand",
                width: 465,
                hideTrigger: true,
                typeAhead: true,
                displayField: "name",
                displayFieldTpl: h,
                valueField: "address",
                vtype: "email",
                allowAddNewData: true,
                addNewDataOnBlur: true,
                mode: "local",
                tpl: c,
                listeners: {
                    newitem: d,
                    beforequery: g,
                    scope: this
                },
                store: e.store
            }, {
                xtype: "syno_combobox",
                fieldLabel: _T("mail", "mail_from_desc"),
                itemId: "mail_from",
                value: "",
                displayField: "account",
                width: 465,
                store: e.comboStore,
                listeners: {
                    select: function(j, k, i) {
                        this.email_type = k.data.value;
                        this.alias = k.data.alias;
                        this.loadContactData(this.email_type, this.alias)
                    },
                    scope: this
                }
            }, {
                xtype: "syno_textfield",
                fieldLabel: _T("mail", "mail_subject"),
                itemId: "mail_subject",
                width: 465
            }, {
                xtype: "syno_displayfield"
            }, {
                xtype: "syno_tinymce",
                itemId: "htmleditor",
                owner: this,
                height: 200,
                width: 650,
                mceConfig: {
                    plugins: ["textcolor", "filestation_attachment", "syno_fontselect", "syno_fontsizeselect"],
                    toolbar: "syno_fontselect syno_fontsizeselect | forecolor backcolor | bold italic underline | alignleft aligncenter alignright | numlist bullist removeformat | filestation_attachment",
                    statusbar: false,
                    forced_root_block: "div",
                    extended_valid_elements: "img[class|src|border=0|alt|title|hspace|vspace|width|height|align|name|ref|adjust|content_id]",
                    menubar: false
                },
                listeners: {
                    beforeAddAttach: this.checkAttach,
                    initialize: function(j, i) {
                        this.onLoadData();
                        this.initAttachment(j, i)
                    },
                    scope: this
                }
            }, {
                xtype: "syno_displayfield"
            }, {
                xtype: "syno_superboxselect",
                cls: "mail-ie8-superboxselect",
                fieldLabel: _T("mail", "mail_attachment"),
                itemId: "mail_attachment",
                expandBtnCls: "mail-dialog-superboxselect-expand",
                width: 465,
                hideTrigger: true,
                typeAhead: false,
                editable: false,
                displayField: "filename",
                valueField: "path",
                allowAddNewData: true,
                addNewDataOnBlur: true,
                mode: "local",
                displayFieldTpl: f,
                hidden: !Ext.isIE8,
                disabled: !Ext.isIE8,
                store: e.attachmentStore
            }]
        };
        var a = new SYNO.ux.FormPanel(b);
        this.panel = a;
        return a
    },
    onOpen: function(d) {
        this.setStatusBusy();
        this.appTitle = (Ext.isEmpty(d.appTitle)) ? "tree:leaf_filebrowser" : d.appTitle;
        this.appName = (Ext.isEmpty(d.appName)) ? "dsm" : d.appName;
        this.email_type = (Ext.isString(d.email_type)) ? d.email_type : this.email_type;
        this.alias = (Ext.isString(d.alias)) ? d.alias : this.alias;
        this.taskid = (Ext.isString(d.taskid)) ? d.taskid : "";
        this.mailContent = (Ext.isString(d.content)) ? d.content : "";
        this.attachmentList = (Ext.isArray(d.data)) ? d.data : this.parseObjectAttachment(d.data);
        this.inlineAttachment = (Ext.isObject(d.content_attachment)) ? this.parseObjectAttachment(d.content_attachment) : [];
        var b = 0,
            c = this.panel.getComponent("htmleditor").getEditor();
        if (c && !this.isSetAttach) {
            if (Ext.isIE8) {
                this.addAttachRecord(this.attachmentList)
            } else {
                for (b = 0; b < this.attachmentList.length; b++) {
                    var a = this.attachmentList[b];
                    c.plugins.filestation_attachment.addAttachRecord(a)
                }
            }
        }
        this.callParent(arguments)
    },
    initAttachment: function(d, c) {
        var b = 0;
        c.plugins.filestation_attachment.initMode(c);
        if (!this.isSetAttach && this.attachmentList) {
            this.isSetAttach = true;
            if (Ext.isIE8) {
                this.addAttachRecord(this.attachmentList)
            } else {
                for (b = 0; b < this.attachmentList.length; b++) {
                    var a = this.attachmentList[b];
                    c.plugins.filestation_attachment.addAttachRecord(a)
                }
            }
        }
    },
    onBeforeConfirm: function() {
        if ("" === this.panel.getComponent("mail_to_field").getValue()) {
            this.getMsgBox().alert("Title", _T("mail", "mailto_alert"));
            return
        }
        if ("" === this.panel.getComponent("mail_subject").getValue()) {
            this.getMsgBox().confirm("Title", _T("mail", "mail_subject_alert"), function(a) {
                if ("yes" === a) {
                    this.onConfirm()
                }
            }, this);
            return
        }
        this.onConfirm()
    },
    onConfirm: function() {
        var g = this;
        var j = this.panel.getComponent("mail_to_field").getValue().split(",");
        var a = this.panel.getComponent("mail_cc_field").getValue();
        var h = this.panel.getComponent("mail_subject").getValue();
        var e = this.BodyValueGet();
        var c = 0,
            d = [],
            f;
        var k = this.getAttachArray();
        for (c = 0; c < k.length; c++) {
            f = k[c];
            d.push({
                path: f.path,
                filesize: f.filesize,
                symlink: (Ext.isEmpty(f.symlink)) ? "" : f.symlink,
                app_name: (Ext.isEmpty(f.app_name)) ? "dsm" : f.app_name,
                deleted: (Ext.isEmpty(f.deleted)) ? false : f.deleted
            })
        }
        var b = {
            app_name: this.appName,
            app_title: this.appTitle,
            email_type: this.email_type,
            alias: this.alias,
            to: Ext.encode(j),
            subject: h,
            body: e,
            attachment: Ext.encode(d),
            inline_attachment: Ext.encode(this.inlineAttachment)
        };
        if (!Ext.isEmpty(a)) {
            b.cc = Ext.encode(a.split(","))
        }
        if (this.taskid && "" !== this.taskid) {
            b.taskid = this.taskid
        }
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.PersonMailAccount.Mail",
            method: "send",
            version: 1,
            params: b,
            callback: function(n, i, l) {
                if (n) {
                    g.onAddBkgTask(i.taskid);
                    this.canClosed = true;
                    this.close()
                } else {
                    var m = SYNO.SDS.App.MailDialog.Utils.APIErrorGet(i.code);
                    g.getMsgBox().alert("Title", m)
                }
                this.clearStatusBusy()
            },
            scope: this
        })
    },
    onAddBkgTask: function(a) {
        var d = this.panel.getComponent("mail_from").getValue();
        var c = this.panel.getComponent("mail_to_field").getValue().split(",");
        var b = Ext.util.Format.htmlEncode(this.panel.getComponent("mail_subject").getValue());
        SYNO.SDS.MailTaskMgr.addWebAPITask({
            id: a,
            title: b || d,
            sender: d,
            reciever: c,
            subject: b,
            query: {
                api: "SYNO.PersonMailAccount.Mail",
                method: "status",
                version: 1,
                params: {
                    taskid: a
                }
            },
            cancel: {
                api: "SYNO.PersonMailAccount.Mail",
                method: "stop",
                version: 1,
                params: {
                    taskid: a
                }
            }
        })
    },
    setFormData: function(g) {
        var c = 0,
            e = this,
            b = [];
        var f = g.to.concat(g.cc);
        var a = null;
        for (c = 0; c < f.length; c++) {
            a = f[c];
            b.push({
                name: a,
                address: a
            })
        }
        this.store.loadData(b, true);
        this.panel.getComponent("mail_to_field").setValue(g.to.toString());
        this.panel.getComponent("mail_cc_field").setValue(g.cc.toString());
        this.panel.getComponent("mail_subject").setValue(g.subject);
        this.BodyValueSet(g.body);
        if (Ext.isIE8) {
            this.addAttachRecord(g.attachment)
        } else {
            var d = e.panel.getComponent("htmleditor").getEditor();
            for (c = 0; c < g.attachment.length; c++) {
                a = g.attachment[c];
                d.plugins.filestation_attachment.addAttachRecord({
                    path: a.path,
                    filesize: a.filesize
                })
            }
        }
        if (!Ext.isEmpty(g.inline_attachment)) {
            this.inlineAttachment = g.inline_attachment
        }
    },
    onLoadData: function() {
        var a = [];
        a.push({
            api: "SYNO.PersonMailAccount",
            method: "get",
            version: 1
        });
        a.push({
            api: "SYNO.PersonMailAccount.Contacts",
            method: "list",
            version: 1,
            params: {
                email_type: this.email_type,
                alias: this.alias
            }
        });
        if (this.taskid) {
            a.push({
                api: "SYNO.PersonMailAccount.Mail",
                method: "status",
                version: 1,
                params: {
                    taskid: this.taskid
                }
            })
        }
        this.sendWebAPI({
            params: {},
            compound: {
                params: a
            },
            scope: this,
            callback: function(f, b, e, c) {
                this.clearStatusBusy();
                if (f) {
                    this.setAccountData(b.result);
                    if (this.taskid) {
                        if (b.result[2].error) {
                            var d = SYNO.SDS.App.MailDialog.Utils.APIErrorGet(b.result[2].error.code);
                            this.getMsgBox().alert("Title", d)
                        } else {
                            this.setFormData(b.result[2].data)
                        }
                    }
                } else {
                    this.getMsgBox().alert("Title", _T("error", "error_error_system"))
                }
            }
        })
    },
    setAccountData: function(e) {
        var f = 0,
            b, k = false;
        var a, c, l = {},
            g = "confirm";
        this.BodyValueSet(this.mailContent);
        if (e[0].error) {
            b = SYNO.SDS.App.MailDialog.Utils.APIErrorGet(e[0].error.code);
            this.getMsgBox().alert("Title", b, function() {
                this.doClose()
            }, this);
            return
        }
        a = e[0].data.data;
        for (f = 0; f < a.length; f++) {
            var d = a[f];
            var h, j;
            if (d.is_default) {
                l.account = d.sender_account || d.account;
                j = SYNO.SDS.App.MailDialog.Utils.getEmailProviderName(d.email_type);
                l.account = l.account + " (" + j + ")";
                l.alias = d.alias;
                l.email_type = d.email_type
            }
            if (d.email_type === "synomail" && !this.isSynoMailClientEnable()) {
                continue
            }
            h = d.sender_account || d.account;
            j = SYNO.SDS.App.MailDialog.Utils.getEmailProviderName(d.email_type);
            h = h + " (" + j + ")";
            this.comboStore.loadData([
                [d.alias, d.email_type, h]
            ], true)
        }
        if (0 === a.length) {
            if (true === _S("standalone")) {
                b = _T("mail", "mail_setup_in_dsm");
                g = "alert"
            } else {
                b = _T("mail", "mail_setup_hint")
            }
            k = true
        }
        if (l.email_type === "synomail" && !this.isSynoMailClientEnable()) {
            b = _T("mail", "default_alert");
            k = true
        }
        if (k) {
            this.getMsgBox()[g]("Title", b, function(i) {
                if ("yes" === i) {
                    SYNO.SDS.AppLaunch("SYNO.SDS.App.PersonalSettings.Instance", {
                        tab: "email"
                    })
                }
                this.doClose()
            }, this);
            return
        }
        this.panel.getComponent("mail_from").setValue(l.account);
        if (e[1].error) {
            b = SYNO.SDS.App.MailDialog.Utils.APIErrorGet(e[1].error.code);
            b = String.format(b, this.email_type);
            this.setStatusError({
                text: b,
                clear: true
            });
            return
        }
        c = e[1].data.result;
        this.contactCacheData[this.alias] = c;
        this.store.loadData(c, true)
    },
    checkAttach: function(d, k, m, n) {
        var e, c, a, l = 0,
            g = 0;
        var h = m.records;
        var f = this.getAttachArray();
        var b = SYNO.SDS.App.MailDialog.Utils.getAttachLimitByType(this.email_type);
        if (Ext.isEmpty(this.email_type)) {
            return true
        }
        for (e = 0; e < f.length; e++) {
            g++;
            l += f[e].filesize;
            for (c = 0; c < h.length; c++) {
                if (h[c].data.path === f[e].path) {
                    g--;
                    l -= f[e].filesize;
                    break
                }
            }
        }
        if (10 < g + h.length) {
            a = String.format(_T("mail", "filenum_limit_alert"), 10);
            this.getMsgBox().alert("Title", a);
            return false
        }
        for (e = 0; e < h.length; e++) {
            if (h[e].data.isdir) {
                a = _T("mail", "filedir_limit_alert");
                this.getMsgBox().alert("Title", a);
                return false
            }
            l += h[e].data.filesize
        }
        if (b * 1024 * 1024 < l) {
            a = String.format(_T("mail", "filesize_limit_alert"), b);
            this.getMsgBox().alert("Title", a);
            return false
        }
        if (Ext.isIE8) {
            this.addAttachRecord(m.records, k);
            return false
        }
        return true
    },
    addAttachRecord: function(a, b) {
        var c = this.panel.getComponent("mail_attachment");
        a.each(function(d) {
            var e = {};
            if (Ext.isDefined(d.path)) {
                e.path = d.path;
                e.filename = e.path.substring(e.path.lastIndexOf("/") + 1);
                e.filesize = d.filesize;
                e.formatsize = Ext.util.Format.fileSize(d.filesize);
                e.deleted = (Ext.isEmpty(d.deleted)) ? false : d.deleted
            } else {
                e.path = d.get("path");
                e.filename = e.path.substring(e.path.lastIndexOf("/") + 1);
                e.filesize = d.get("filesize");
                e.formatsize = Ext.util.Format.fileSize(d.get("filesize"))
            }
            c.addNewItem(e)
        });
        if (Ext.isDefined(b)) {
            b.close()
        }
    },
    getAttachArray: function() {
        var a = [];
        if (Ext.isIE8) {
            var c = this.panel.getComponent("mail_attachment");
            var b = c.getSelectedRecords();
            b.each(function(d) {
                a.push(d.data)
            })
        } else {
            a = this.panel.getComponent("htmleditor").getEditor().plugins.filestation_attachment.getAttachArray()
        }
        return a
    },
    BodyValueGet: function() {
        var b = this.panel.getComponent("htmleditor").getDoc();
        Ext.iterate(b.querySelectorAll("img,input[content_id]"), function(d, c) {
            var e = d.getAttribute("content_id");
            if (e) {
                e = "cid:" + e;
                d.setAttribute("src", e)
            }
        });
        var a = b.body.innerHTML;
        return a
    },
    BodyValueSet: function(a) {
        var b = this.panel.getComponent("htmleditor").getDoc();
        b.body.innerHTML = a
    },
    parseObjectAttachment: function(c) {
        var a = [],
            b = this.appName;
        if (!Ext.isObject(c)) {
            return a
        }
        Ext.iterate(c, function(d, e) {
            a.push({
                app_name: b,
                path: e.name,
                symlink: e.symlink,
                filesize: e.size,
                cid: d,
                deleted: e.remove
            })
        });
        return a
    },
    loadContactData: function(b, a) {
        if (this.contactCacheData[a]) {
            this.store.loadData(this.contactCacheData[a]);
            return
        }
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.PersonMailAccount.Contacts",
            method: "list",
            version: 1,
            params: {
                email_type: b,
                alias: a
            },
            callback: function(f, c, d) {
                if (f) {
                    this.contactCacheData[a] = c.result;
                    this.store.loadData(c.result)
                } else {
                    var e = SYNO.SDS.App.MailDialog.Utils.APIErrorGet(c.code);
                    e = String.format(e, this.email_type);
                    this.setStatusError({
                        text: e,
                        clear: true
                    })
                }
                this.clearStatusBusy()
            },
            scope: this
        })
    },
    onClose: function() {
        if (this.canClosed) {
            this.callParent(arguments);
            return true
        }
        this.getMsgBox().confirm("Title", _T("mail", "mail_leave_desc"), function(a) {
            if ("yes" === a) {
                this.onBeforeClose()
            }
        }, this);
        return false
    },
    onBeforeClose: function() {
        var c = 0,
            e = [],
            b;
        var a = this.getAttachArray();
        if ("dsm" === this.appName) {
            this.canClosed = true;
            this.close();
            return
        }
        for (c = 0; c < a.length; c++) {
            b = a[c];
            e.push({
                path: b.path,
                filesize: b.filesize,
                symlink: (Ext.isEmpty(b.symlink)) ? "" : b.symlink,
                app_name: (Ext.isEmpty(b.app_name)) ? "dsm" : b.app_name,
                deleted: (Ext.isEmpty(b.deleted)) ? false : b.deleted
            })
        }
        var d = {
            attachment: Ext.encode(e),
            inline_attachment: Ext.encode(this.inlineAttachment)
        };
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.PersonMailAccount.Mail",
            method: "clean",
            version: 1,
            params: d,
            callback: function(h, f, g) {
                this.clearStatusBusy();
                this.canClosed = true;
                this.close()
            },
            scope: this
        })
    },
    onClickHelp: function() {
        var a = "SYNO.SDS.App.FileStation3.Instance:FileBrowser/emailaccount.html";
        SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
            topic: a
        }, false)
    },
    isSynoMailClientEnable: function() {
        return SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.MailClient.Application")
    }
});
Ext.namespace("SYNO.SDS.App.MailDialog.Utils");
Ext.define("SYNO.SDS.App.MailDialog.Utils.checkFn", {});
Ext.define("SYNO.SDS.App.MailDialog.Utils.launchFn", {});
Ext.apply(SYNO.SDS.App.MailDialog.Utils, {
    className: "SYNO.SDS.App.MailDialog.Application",
    launchFn: function(d) {
        var e = 0,
            c = 0,
            f = [],
            g;
        var a = SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_type");
        var b = SYNO.SDS.App.MailDialog.Utils.getAttachLimitByType(a);
        if (10 < d.length) {
            g = String.format(_T("mail", "filenum_limit_alert"), 10);
            this.ownerCt.getMsgBox().alert("Title", g);
            return
        }
        for (e = 0; e < d.length; e++) {
            if (d[e].data.isdir) {
                g = _T("mail", "filedir_limit_alert");
                this.ownerCt.getMsgBox().alert("Title", g);
                return
            }
            c += d[e].data.filesize
        }
        if (!Ext.isEmpty(a) && b * 1024 * 1024 < c) {
            g = String.format(_T("mail", "filesize_limit_alert"), b);
            this.ownerCt.getMsgBox().alert("Title", g);
            return
        }
        for (e = 0; e < d.length; e++) {
            f.push(d[e].data)
        }
        SYNO.SDS.AppLaunch("SYNO.SDS.App.MailDialog.Application", {
            data: f
        })
    },
    launchMailFn: function(a) {
        SYNO.SDS.AppLaunch("SYNO.SDS.App.MailDialog.Application", a)
    },
    checkFn: function(b, a) {
        if (1 === a.length && a[0].data.isdir) {
            return false
        }
        return true
    },
    getAttachLimitByType: function(a) {
        if ("gmail" === a) {
            return 25
        } else {
            if ("hotmail" === a) {
                return 25
            } else {
                if ("yahoomail" === a) {
                    return 25
                } else {
                    if ("aolmail" === a) {
                        return 25
                    } else {
                        return 15
                    }
                }
            }
        }
    },
    APIErrorGet: function(a) {
        switch (a) {
            case 116:
                return _JSLIBSTR("uicommon", "error_demo");
            case 8001:
            case 8002:
            case 8003:
            case 8004:
                return _T("error", "error_error_system");
            case 8005:
                return _T("error", "error_privilege_not_enough");
            case 8006:
            case 8007:
            case 8008:
            case 8009:
            case 8010:
            case 8011:
                return _T("error", "error_error_system");
            case 8012:
                return _T("mail", "sync_expire");
            case 8013:
                return _T("error", "error_error_system");
            default:
                return _T("error", "error_error_system")
        }
    },
    getEmailProviderName: function(a) {
        if ("gmail" === a) {
            return "Gmail"
        } else {
            if ("hotmail" === a) {
                return "Outlook"
            } else {
                if ("yahoomail" === a) {
                    return "Yahoo!"
                } else {
                    if ("aolmail" === a) {
                        return "AOL"
                    } else {
                        if ("synomail" === a) {
                            return "MailPlus"
                        } else {
                            return "Custom"
                        }
                    }
                }
            }
        }
    }
});
