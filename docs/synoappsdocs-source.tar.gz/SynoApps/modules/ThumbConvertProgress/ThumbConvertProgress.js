/* Copyright (c) 2020 Synology Inc. All rights reserved. */

 /**
 * @class SYNO.SDS.ThumbConvertProgress.Application
 * @extends SYNO.SDS.AppInstance
 * ThumbConvertProgress application instance class
 *
 */  
 Ext.define("SYNO.SDS.ThumbConvertProgress.Application", {
    extend: "SYNO.SDS.AppInstance",
    trayItem: [],
    initInstance: function(a) {
        this.trayItem[0] = new SYNO.SDS.ThumbConvertProgress.Tray({
            AppInstance: this
        });
        this.addInstance(this.trayItem);
        this.trayItem[0].open(a)
    }
});
Ext.define("SYNO.SDS.ThumbConvertProgress.Tray", {
    extend: "SYNO.SDS.Tray.ArrowTray",
    initPanel: function() {
        var b = this;
        var a = new SYNO.SDS.ThumbConvertProgress.Panel({
            module: b
        });
        return a
    },
    onMouseDown: function(b) {
        var a = this.panel.field_combo.list;
        if (typeof(a) != "undefined" && b.within(a.dom)) {
            return
        }
        return this.superclass().onMouseDown.apply(this, [b])
    },
    onClick: function() {
        var a = this;
        window.a = this;
        if (a.panel.isVisible()) {
            a.taskButton.toggle(false);
            a.panel.hide()
        } else {
            a.panel.show();
            a.panel.el.anchorTo(a.taskButton.el, a.arrowAlignPosition, [6, 7])
        }
    }
});
Ext.define("SYNO.SDS.ThumbConvertProgress.Panel", {
    extend: "SYNO.SDS.Tray.Panel",
    IDLE_PAUSED_POLLING_INTERVAL: 60,
    CONVERTING_POLLING_INTERVAL: 5,
    MODE_ALWAYS: "always",
    COMBOBOX_STORE_DATA_IN_ALWAYS_MODE: [
        [1, String.format(_T("thumb_conv_progress", "delay_hours"), "1")],
        [3, String.format(_T("thumb_conv_progress", "delay_hours"), "3")],
        [6, String.format(_T("thumb_conv_progress", "delay_hours"), "6")],
        [-1, _T("thumb_conv_progress", "delay_forever")]
    ],
    DAY_DISPLAY_LIST: [_JSLIBSTR("uicommon", "schedule_abbre_sun"), _JSLIBSTR("uicommon", "schedule_abbre_mon"), _JSLIBSTR("uicommon", "schedule_abbre_tue"), _JSLIBSTR("uicommon", "schedule_abbre_wed"), _JSLIBSTR("uicommon", "schedule_abbre_thu"), _JSLIBSTR("uicommon", "schedule_abbre_fri"), _JSLIBSTR("uicommon", "schedule_abbre_sat")],
    constructor: function(a) {
        this.bar = new SYNO.SDS.ThumbConvertProgress.Bar();
        this.module = a.module;
        this.staticIconCls = "sds-tray-item-static-creating-thumbnail";
        this.aniIconCls = "sds-tray-item-ani-creating-thumbnail";
        this.isScheduleMode = false;
        var b = Ext.apply({
            module: a.module,
            title: _T("convert_progress", "title"),
            width: 360,
            autoHeight: true,
            cls: "sds-tray-thumbnail-progress-panel",
            style: "height: auto",
            bodyCssClass: "sds-tray-thumbnail-progress-panel-body",
            renderTo: document.body,
            padding: "0 8px 8px 8px",
            items: this.createObjs(),
            listeners: {
                afterrender: this.addClickHandlers,
                scope: this
            }
        }, a);
        this.callParent([b]);
        this.getCmpsAsMembers();
        this.polling_interval = this.IDLE_PAUSED_POLLING_INTERVAL;
        this.startPolling()
    },
    addClickHandlers: function() {
        this.body.query("a").forEach(function(a) {
            if (a.getAttribute("data-syno-app")) {
                a.addEventListener("click", SYNO.SDS.Utils.Notify.BindEvent)
            }
        })
    },
    createObjs: function() {
        var a = [{
            xtype: "container",
            cls: "thumb_conv_progress_bar",
            width: "auto",
            items: [{
                xtype: "syno_displayfield",
                cls: "thumb_conv_progress_desc",
                htmlEncode: false,
                id: this.field_photo = Ext.id()
            }, {
                xtype: "box",
                id: this.field_photo_bar = Ext.id(),
                data: this.bar.createApplyConfig(0),
                tpl: this.bar
            }]
        }, {
            xtype: "container",
            cls: "thumb_conv_progress_bar",
            width: "auto",
            items: [{
                xtype: "syno_displayfield",
                cls: "thumb_conv_progress_desc",
                htmlEncode: false,
                id: this.field_video = Ext.id()
            }, {
                xtype: "box",
                id: this.field_video_bar = Ext.id(),
                data: this.bar.createApplyConfig(0),
                tpl: this.bar
            }]
        }, {
            xtype: "container",
            cls: "thumb_conv_progress_bar",
            width: "auto",
            items: [{
                xtype: "syno_compositefield",
                hideLabel: true,
                cls: "thumb_conv_progress_desc",
                items: [{
                    xtype: "syno_displayfield",
                    id: this.field_status = Ext.id(),
                    htmlEncode: false,
                    cls: "syno_thumb_status_div"
                }]
            }, this.createComboBoxConfig(), {
                xtype: "syno_button",
                cls: "thumb_conv_progress_pause_resume_btn",
                width: 30,
                height: 28,
                id: this.field_pause = Ext.id(),
                scope: this,
                handler: this.onPauseBtnClick
            }, {
                xtype: "syno_displayfield",
                value: this.createNoteText(),
                htmlEncode: false,
                cls: "thumb_conv_progress_note_desc",
                id: this.field_note = Ext.id(),
                listeners: {
                    render: function(c) {
                        var b = c.el.first("u");
                        if (b) {
                            this.mon(b, "click", function(d) {
                                d.preventDefault();
                                SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                                    fn: "SYNO.SDS.AdminCenter.MediaIndex.Main"
                                })
                            }, this)
                        }
                    },
                    scope: this,
                    single: true,
                    buffer: 80
                }
            }]
        }];
        return a
    },
    createNoteText: function() {
        var a = '<a class="link-font" style="cursor: pointer" data-syno-app="SYNO.SDS.AdminCenter.Application" data-syno-fn="SYNO.SDS.AdminCenter.MediaIndex.Main">' + _T("thumb_conv_progress", "set_up_schedule") + "</a>";
        var b = String.format(_T("thumb_conv_progress", "desc_with_set_up_schedule"), a);
        return ('<font class="syno-ux-note">' + _T("common", "note") + ": </font>" + b)
    },
    createComboBoxConfig: function() {
        var a = {
            xtype: "syno_combobox",
            name: "delay_hours",
            id: this.field_combo = Ext.id(),
            value: 1,
            displayField: "display",
            width: 292,
            valueField: "value",
            store: new Ext.data.ArrayStore({
                fields: ["value", "display"],
                data: this.COMBOBOX_STORE_DATA_IN_ALWAYS_MODE
            }),
            listeners: {
                afterrender: function(b) {
                    b.wrap.addClass("thumb_conv_progress_delay_hour")
                }
            }
        };
        return a
    },
    getCmpsAsMembers: function() {
        var b = ["field_photo_bar", "field_video_bar", "field_pause", "field_combo", "field_status", "field_video", "field_photo", "field_note"];
        for (var a = 0; a < b.length; ++a) {
            this[b[a]] = Ext.getCmp(this[b[a]])
        }
    },
    startPolling: function() {
        if (this.polling_id) {
            this.stopPolling()
        }
        this.polling_id = this.pollReg({
            interval: this.polling_interval,
            immediate: true,
            scope: this,
            webapi: {
                api: "SYNO.Core.MediaIndexing.MediaConverter",
                method: "status",
                version: 2
            },
            status_callback: this.polling_callback
        })
    },
    stopPolling: function() {
        if (!this.polling_id) {
            return
        }
        this.pollUnreg(this.polling_id);
        this.polling_id = null
    },
    polling_callback: function(g, d, f, b) {
        if (g) {
            this.isScheduleMode = this.MODE_ALWAYS !== d.mode;
            this.updateComboboxStore(d);
            this.setStatusDesc(d);
            this.updateBtn(d.status);
            this.setPhotoProgress(d);
            this.setVideoProgress(d);
            var e = d.status === "converting" || d.status === "paused";
            this.module.setTaskButtonVisible(e);
            var a = d.status === "paused" ? this.staticIconCls : this.aniIconCls;
            this.module.taskButton.setIconClass(a);
            if (!e) {
                this.hide()
            }
            var c = (d.status === "converting");
            this.doLayout();
            this.correctResize();
            this.updatePollingInterval(c)
        } else {}
    },
    updatePollingInterval: function(a) {
        var b = a ? this.CONVERTING_POLLING_INTERVAL : this.IDLE_PAUSED_POLLING_INTERVAL;
        if (b !== this.polling_interval) {
            this.polling_interval = b;
            this.stopPolling();
            this.startPolling()
        }
    },
    correctResize: function() {
        var b = ["field_photo", "field_photo_bar", "field_video", "field_video_bar", "field_combo", "field_status", "field_note"];
        var a = 90;
        for (var c = 0; c < b.length; ++c) {
            a += this[b[c]].getHeight()
        }
        this.onResize(this.getWidth(), a)
    },
    getPauseTimeLeftString: function(b) {
        if (-1 === b) {
            return ""
        }
        var a = Math.floor(b / 3600);
        var c = Math.floor(b / 60) % 60;
        if (0 === a && 0 === c) {
            return ""
        }
        var d = [];
        if (1 === a) {
            d.push("1");
            d.push(_T("common", "time_hour"))
        } else {
            if (0 < a) {
                d.push(a);
                d.push(_T("common", "time_hours"))
            }
        }
        if (1 === c) {
            d.push("1");
            d.push(_T("common", "time_minute"))
        } else {
            if (0 < c) {
                d.push(c);
                d.push(_T("common", "time_minutes"))
            }
        }
        return " (" + String.format(_T("thumb_conv_progress", "resume_in"), d.join(" ")) + ")"
    },
    setStatusDesc: function(e) {
        var b = e.status;
        var a = e.pause_time_left;
        var d = {
            idle: _T("thumb_conv_progress", "conv_status_idle"),
            converting: '<font class="thumb_conv_progress_loading">' + _T("thumb_conv_progress", "status_converting") + "</font>",
            paused: (this.isScheduleMode ? _T("thumb_conv_progress", "conv_status_scheduled") : _T("thumb_conv_progress", "conv_status_paused")) + this.getPauseTimeLeftString(a),
            stopped: _T("thumb_conv_progress", "conv_status_stopped")
        };
        var c = this.addLabelFont(_T("thumb_conv_progress", "label_conv_status") + ": ");
        this.field_status.setValue(c + d[b]);
        this.doLayout()
    },
    setPhotoProgress: function(f) {
        var d = f.photo_total;
        var b = f.thumb_total;
        var g = f.thumb_remain;
        var a = f.thumb_complete;
        var h = this.addLabelFont(_T("fileindex", "type_photo") + ": ");
        var c = 0;
        var e = 0;
        if (a > b) {
            c = 0.8;
            e = Math.floor(a / 3)
        } else {
            c = b === 0 ? 0 : (b - g) / b;
            e = d
        }
        h += String.format(_T("thumb_conv_progress", "str_photo_total_desc"), e);
        this.field_photo.setValue(h);
        this.field_photo_bar.update(this.bar.createApplyConfig(c, e))
    },
    setVideoProgress: function(d) {
        var b = d.video_total;
        var c = d.video_remain;
        var e = this.addLabelFont(_T("thumb_conv_progress", "videos") + ": ");
        var a = (b === 0 ? 0 : (b - c) / b);
        e += String.format(_T("thumb_conv_progress", "str_video_total_desc"), b);
        this.field_video.setValue(e);
        this.field_video_bar.update(this.bar.createApplyConfig(a, b))
    },
    updateBtn: function(a) {
        var c = a === "paused";
        var e = a === "converting";
        var b = c ? "syno_thumb_conv_btn_resume" : "syno_thumb_conv_btn_pause";
        var d = c ? _T("common", "continue") : (this.isScheduleMode ? _T("common", "skip") : _T("common", "pause"));
        this.field_combo.setDisabled(!e);
        this.field_pause.setDisabled(!e && !c);
        this.field_pause.setIconClass(b);
        this.field_pause.setTooltip(d);
        this.isPaused = c
    },
    getWeekString: function(a) {
        var b = 0;
        var c = [];
        a.forEach(function(e, d) {
            if (e === true) {
                b++;
                c.push(this.DAY_DISPLAY_LIST[d])
            }
        }, this);
        if (b === 7) {
            return _JSLIBSTR("uicommon", "schedule_daily")
        }
        if (b === 2 && true === a[0] && true === a[6]) {
            return _JSLIBSTR("uicommon", "schedule_weekend")
        }
        if (b === 5 && true === a[1] && true === a[2] && true === a[3] && true === a[4] && true === a[5]) {
            return _JSLIBSTR("uicommon", "schedule_weekdays")
        }
        return c.join(",")
    },
    updateComboboxStore: function(d) {
        var b = this.field_combo.getStore();
        if (d.mode === this.MODE_ALWAYS) {
            if (d.status !== "paused") {
                b.loadData(this.COMBOBOX_STORE_DATA_IN_ALWAYS_MODE);
                this.field_combo.setValue(1)
            }
            return
        }
        var c = this.getWeekString(d.week);
        var g = d.start.hour;
        var f = ("00" + g).slice(-2) + ":00";
        var e = g + d.duration;
        var a;
        if (24 > e) {
            a = ("00" + e).slice(-2) + ":00"
        } else {
            a = ("00" + (e - 24)).slice(-2) + ":00 " + _T("convert_setting", "tomorrow")
        }
        b.loadData([
            [0, String.format("{0}({1} - {2})", c, f, a)]
        ]);
        this.field_combo.setValue(0)
    },
    onPauseBtnClick: function() {
        var b = this.isPaused ? "resume" : "pause";
        var a = {};
        if (!this.isScheduleMode && !this.isPaused) {
            a = {
                delay_hours: this.field_combo.getValue()
            }
        }
        this.stopPolling();
        this.field_pause.disable();
        this.field_combo.disable();
        this.sendWebAPI({
            params: {},
            compound: {
                stopwhenerror: false,
                params: [{
                    api: "SYNO.Core.MediaIndexing.MediaConverter",
                    method: b,
                    version: 2,
                    params: a
                }, {
                    api: "SYNO.Core.MediaIndexing.MediaConverter",
                    method: "status",
                    version: 2,
                    params: {}
                }]
            },
            scope: this,
            callback: function(f, d, c) {
                var e = d.result[1];
                this.polling_callback(e.success, e.data, {}, {});
                this.startPolling()
            }
        })
    },
    addLabelFont: function(a) {
        return '<font class="syno_thumb_label_font">' + a + "</font>"
    }
});
Ext.define("SYNO.SDS.ThumbConvertProgress.Bar", {
    extend: "Ext.XTemplate",
    defaultConf: {
        barWidth: 282,
        barHeight: 6,
        value: 0,
        showValueText: true,
        cls: "sds-ux-progressbar"
    },
    constructor: function(a) {
        Ext.apply(this, this.defaultConf);
        Ext.apply(this, a);
        SYNO.SDS.ThumbConvertProgress.Bar.superclass.constructor.call(this, '<div class="thumb_conv_progress_desc">', '<div class="{cls} syno-percentage-cmp">', '<div class="percentage-cmp-hbar-background" style="width:{barWidth}px; height:{barHeight}px;">', '<div class="percentage-cmp-hbar-fill {fill_bar_class}" style="width:{fillW}px; height:{barHeight}px;" ></div>', "</div>", '<tpl if="(showValueText)">', '<div class="percentage-cmp-value"> ', "{value}%</div>", "</tpl>", "</div>", "</div>")
    },
    createApplyConfig: function(f, e) {
        var d = Math.round(f * 100);
        var c = f * this.barWidth;
        if (c !== 0 && c < 6) {
            c = 6
        }
        var a = d === 100 ? "full-progress" : "";
        var b = {
            barHeight: this.barHeight,
            barWidth: this.barWidth,
            fillW: c,
            value: d,
            showValueText: this.showValueText && e > 0,
            cls: this.cls,
            fill_bar_class: a
        };
        return b
    }
});
