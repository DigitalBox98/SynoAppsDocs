/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.define("SYNO.SDS.LogCenter.EchartsPanelDevice", {
    extend: "Ext.Panel",
    initialChartType: null,
    chartType: null,
    constructor: function(b) {
        var a = {
            margins: {
                top: 10,
                right: 10,
                bottom: 10,
                left: 0
            },
            border: false,
            flex: 2
        };
        this.initialChartType = SYNO.SDS.Utils.clone(b.chartType);
        Ext.apply(a, b);
        this.callParent([a])
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this, "afterlayout", function() {
            if (!this.collapsed) {
                this.drawChart()
            }
        }, this);
        this.mon(this, "expand", function() {
            this.drawChart()
        }, this);
        if (this.store) {
            this.mon(this.store, "datachanged", this.drawChart, this)
        }
    },
    genOption: function(d) {
        var b, c = false,
            a = {
                type: "pie",
                data: [],
                label: {
                    normal: {
                        show: false
                    }
                },
                radius: "55",
                center: ["50%", "65"],
                itemStyle: {
                    borderColor: "white",
                    borderWidth: 0
                }
            };
        d.color = [];
        if (this.store) {
            for (b = 0; b < this.store.getCount(); b++) {
                var e = this.store.getAt(b);
                a.data.push({
                    name: e.get("device"),
                    value: e.get("percent")
                });
                d.color.push(this.dataSet[b].color);
                if (e.get("percent") > 0.995) {
                    c = true
                }
            }
        }
        d.grid.show = false;
        d.series = a;
        if (!c) {
            Object.assign(d.series.itemStyle, {
                borderWidth: 0.5
            })
        }
    },
    drawChart: function() {
        if (0 === this.store.getCount()) {
            return
        }
        if (!this.chartInstance) {
            this.chartInstance = echarts.init(this.body.dom)
        }
        var a = echarts.syno.getDefaultOptions();
        this.genOption(a);
        this.chartInstance.setOption(a)
    },
    onResize: function() {
        this.callParent(arguments);
        this.drawChart()
    }
});
Ext.define("SYNO.SDS.LogCenter.EchartsPanel", {
    extend: "Ext.Panel",
    store: null,
    totalRecords: 0,
    constructor: function(b) {
        var a = {
            margins: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0
            },
            border: false
        };
        Ext.apply(a, b);
        this.callParent([a])
    },
    initEvents: function() {
        this.callParent(arguments);
        if (this.header) {
            this.mon(this.header, "dblclick", this.toggleCollapse, this)
        }
        this.mon(this, "afterlayout", function() {
            if (!this.collapsed) {
                this.drawChart()
            }
        }, this);
        this.mon(this, "expand", function() {
            this.drawChart()
        }, this);
        if (this.store) {
            this.mon(this.store, "datachanged", this.drawChart, this)
        }
    },
    reload: function(d, b) {
        var c = this;
        if (c.isVisible()) {
            var a = c.getEl();
            a.mask(_T("common", "loading"));
            d.apply(b || c, arguments);
            a.unmask()
        } else {
            d.apply(b || c, arguments)
        }
    },
    genOption: function(d) {
        var c, a, f = null;
        var b = [];
        var e = 10;
        for (a = 0; a < this.dataSet.length; a++) {
            b[a] = {
                type: "line",
                symbol: "circle",
                symbolSize: 0,
                data: []
            }
        }
        if (this.store) {
            for (c = 0; c < this.store.getCount(); c++) {
                f = this.store.getAt(c);
                for (a = 0; a < this.dataSet.length; a++) {
                    e = Math.max(f.get(this.dataSet[a].y), e);
                    b[a].data.push([f.get(this.dataSet[a].x), f.get(this.dataSet[a].y)]);
                    b[a].name = f.get(this.dataSet[a].dev)
                }
            }
        }
        Object.assign(d, {
            series: b,
            height: 228
        });
        d.color = [];
        for (a = 0; a < this.dataSet.length; a++) {
            d.color.push(this.dataSet[a].color)
        }
        Object.assign(d.xAxis, {
            type: "time",
            axisTick: {
                show: false
            },
            axisLine: {
                show: false
            },
            splitLine: false,
            splitNumber: 6
        });
        Object.assign(d.xAxis.axisLabel, {
            showMinLabel: false,
            showMaxLabel: false,
            textStyle: {
                fontFamily: "Verdana",
                color: "rgba(65, 75, 85, 1)",
                fontSize: 12
            },
            formatter: function(g) {
                return SYNO.SDS.DateTimeFormatter(new Date(g), {
                    type: "time"
                })
            }
        });
        Object.assign(d.yAxis, {
            min: 0,
            max: this.ceilY(e)
        });
        Object.assign(d.yAxis.axisLabel, {
            textStyle: {
                fontFamily: "Verdana",
                color: "rgba(65, 75, 85, 1)",
                margin: 6,
                fontSize: 12
            }
        });
        Object.assign(d.grid, {
            left: 27,
            right: 9,
            top: 10,
            borderColor: "rgba(198,212,224,0.70)"
        });
        Object.assign(d.tooltip, {
            position: [35, 18],
            formatter: this.trackFormatter.createDelegate(this)
        });
        Object.assign(d.tooltip.axisPointer.lineStyle, {
            color: "#E64040"
        })
    },
    drawChart: function() {
        if (this.collapsed || this.isDestroyed) {
            return true
        }
        if (!this.chartInstance) {
            this.chartInstance = echarts.init(this.body.dom)
        }
        var a = echarts.syno.getDefaultOptions();
        this.genOption(a);
        this.chartInstance.setOption(a)
    },
    onResize: function() {
        this.callParent(arguments);
        if (this.chartInstance) {
            this.chartInstance.resize()
        }
        this.drawChart()
    },
    ceilY: function(b) {
        var a = 1;
        while (b > 10) {
            b = Math.floor(b / 10);
            a *= 10
        }
        if (b != 10) {
            b += 1
        }
        return b * a
    },
    trackFormatter: function(d) {
        var b = new Date(d[0].data[0]);
        var e = b.format("Y/m/d H:i:s");
        var f = [];
        var a;
        for (a = 0; a < d.length; ++a) {
            f.push({
                name: d[a].seriesName,
                value: d[a].data[1],
                color: d[a].color
            })
        }
        var c;
        c = '<table class="syno-syslog info-list-table">';
        c += '<tr><td colspan="2" class="info-list-time time-text">' + e + "</td></tr>";
        for (a = 0; a < f.length; ++a) {
            c += '<tr class="info-list-table" style="color:' + f[a].color + '"><td class="info-list-name">' + f[a].name + '</td><td align="right" class="info-list-value">' + f[a].value + "</td></tr>"
        }
        c += "</table>";
        return c
    }
});
Ext.define("SYNO.SDS.LogCenter.LogView", {
    extend: "SYNO.ux.Panel",
    constructor: function(a) {
        var b;
        a.owner = a.appWin;
        this.FLOTR_EPS = 72;
        this.FLOTR_DEV = 28;
        this.PANEL_LOG = 36 + 19 * 4;
        this.PANEL_STATICS_HEIGHT = 322 + 3;
        this.PANEL_STATICS_WIDTH = 675;
        this.PANEL_EPS_HEIGHT = 264;
        this.PANEL_EPS_WIDTH = 490;
        this.PANEL_DEV_HEIGHT = 228;
        this.PANEL_DEV_WIDTH = 200;
        this.PANEL_EPSDEVSEL_HEIGHT = 30;
        this.TOTAL = "#B06DF2";
        this.DEV_1 = "#32B7F9";
        this.DEV_2 = "#1DA601";
        this.DEV_3 = "#FABB00";
        this.OTHERS = "#96A0AA";
        this.fsNumberShow = true;
        this.EpsScale = SYNO.SDS.LogCenter.SCALE_6MIN;
        this.LogScaleDesc = null;
        this.IntDev = [];
        this.SrcDevDesc = [];
        this.SrcDevPer = [];
        this.SrcDevCombo = [];
        this.LastEpsResult = [];
        this.LastEpsTime = 0;
        Ext.apply(this, a);
        b = this.fillConfig(a);
        this.callParent([b])
    },
    initEvents: function() {
        this.mon(this, "afterlayout", function(a, b) {
            Ext.get("overlay_btn_pause").addListener("click", function(c, d) {
                this.onClickPause()
            }, this);
            Ext.get("overlay_plus").addListener("click", function(c, d) {
                this.onClickPlus()
            }, this);
            Ext.get("overlay_minus").addListener("click", function(c, d) {
                this.onClickMinus()
            }, this);
            Ext.getCmp(this.SrcDevCombo[0]).addListener("select", function(c, d) {
                this.onSelectDevice(0)
            }, this);
            Ext.getCmp(this.SrcDevCombo[1]).addListener("select", function(c, d) {
                this.onSelectDevice(1)
            }, this);
            Ext.getCmp(this.SrcDevCombo[2]).addListener("select", function(c, d) {
                this.onSelectDevice(2)
            }, this);
            Ext.getCmp(this.SrcDevCombo[0]).addListener("beforequery", function(c, d) {
                Ext.getCmp(this.SrcDevCombo[0]).getStore().baseParams.dev_1 = Ext.getCmp(this.SrcDevCombo[0]).getValue();
                Ext.getCmp(this.SrcDevCombo[0]).getStore().baseParams.dev_2 = Ext.getCmp(this.SrcDevCombo[1]).getValue();
                Ext.getCmp(this.SrcDevCombo[0]).getStore().baseParams.dev_3 = Ext.getCmp(this.SrcDevCombo[2]).getValue()
            }, this);
            Ext.getCmp(this.SrcDevCombo[1]).addListener("beforequery", function(c, d) {
                Ext.getCmp(this.SrcDevCombo[1]).getStore().baseParams.dev_1 = Ext.getCmp(this.SrcDevCombo[0]).getValue();
                Ext.getCmp(this.SrcDevCombo[1]).getStore().baseParams.dev_2 = Ext.getCmp(this.SrcDevCombo[1]).getValue();
                Ext.getCmp(this.SrcDevCombo[1]).getStore().baseParams.dev_3 = Ext.getCmp(this.SrcDevCombo[2]).getValue()
            }, this);
            Ext.getCmp(this.SrcDevCombo[2]).addListener("beforequery", function(c, d) {
                Ext.getCmp(this.SrcDevCombo[2]).getStore().baseParams.dev_1 = Ext.getCmp(this.SrcDevCombo[0]).getValue();
                Ext.getCmp(this.SrcDevCombo[2]).getStore().baseParams.dev_2 = Ext.getCmp(this.SrcDevCombo[1]).getValue();
                Ext.getCmp(this.SrcDevCombo[2]).getStore().baseParams.dev_3 = Ext.getCmp(this.SrcDevCombo[2]).getValue()
            }, this);
            this.fsNumber.addListener("collapse", function(c, d) {
                this.fsNumberShow = false;
                this.PanelLog.setHeight(this.appWin.getInnerHeight() - 100);
                this.PanelLog.doLayout()
            }, this);
            this.fsNumber.addListener("expand", function(c, d) {
                this.fsNumberShow = true;
                this.PanelLog.setHeight(this.appWin.getInnerHeight() - this.PANEL_STATICS_HEIGHT - 107);
                this.PanelLog.doLayout()
            }, this);
            this.appWin.addListener("resize", function(d, f, c) {
                var e = this.appWin.getInnerHeight() - this.PANEL_STATICS_HEIGHT - 107;
                if (!this.fsNumberShow) {
                    e = this.appWin.getInnerHeight() - 100
                }
                this.PanelLog.setHeight(e);
                this.PanelLog.doLayout()
            }, this)
        }, this, {
            single: true
        });
        this.mon(this, "resize", this.updatePanelWidth, this)
    },
    updatePanelWidth: function() {
        var a = this.getWidth() - 86;
        this.PanelEps.setWidth(a - this.PANEL_DEV_WIDTH - 24);
        this.EpsChartPanel.onResize();
        this.DevicePanel.onResize();
        this.PanelLog.setWidth(a + 8);
        this.panelStatistic.setWidth(a)
    },
    createEpsPanel: function() {
        this.EpsStore = new Ext.data.SimpleStore({
            autoDestroy: true,
            fields: ["value", "display"],
            data: [],
            pruneModifiedRecords: true
        });
        this.dataSet = [{
            x: "time",
            y: "eps",
            dev: "dev",
            color: this.TOTAL,
            show: true
        }, {
            x: "time",
            y: "dev1",
            dev: "dev1_name",
            color: this.DEV_1,
            show: false
        }, {
            x: "time",
            y: "dev2",
            dev: "dev2_name",
            color: this.DEV_2,
            show: false
        }, {
            x: "time",
            y: "dev3",
            dev: "dev3_name",
            color: this.DEV_3,
            show: false
        }];
        this.EpsChartPanel = new SYNO.SDS.LogCenter.EchartsPanel({
            collapsible: false,
            store: this.EpsStore,
            flex: 1,
            height: 264,
            hideMode: "offsets",
            totalRecords: 0,
            itemId: "eps_echarts",
            dataSet: this.dataSet
        });
        return this.EpsChartPanel
    },
    createDevicePanel: function() {
        this.DevStore = new Ext.data.SimpleStore({
            autoDestroy: true,
            fields: ["value", "display"],
            data: [],
            pruneModifiedRecords: true
        });
        this.DevicePanel = new SYNO.SDS.LogCenter.EchartsPanelDevice({
            collapsible: false,
            store: this.DevStore,
            height: 126,
            hideMode: "offsets",
            border: false,
            totalRecords: 0,
            itemId: "device_echarts",
            dataSet: [{
                x: "device",
                y: "percent",
                dev: "dev",
                color: this.DEV_1
            }, {
                x: "device",
                y: "percent",
                dev: "dev",
                color: this.DEV_2
            }, {
                x: "device",
                y: "percent",
                dev: "dev",
                color: this.DEV_3
            }, {
                x: "device",
                y: "percent",
                dev: "dev",
                color: this.OTHERS
            }]
        });
        this.SrcDevDesc[0] = Ext.id();
        this.SrcDevDesc[1] = Ext.id();
        this.SrcDevDesc[2] = Ext.id();
        this.SrcDevDesc[3] = Ext.id();
        this.SrcDevPer[0] = Ext.id();
        this.SrcDevPer[1] = Ext.id();
        this.SrcDevPer[2] = Ext.id();
        this.SrcDevPer[3] = Ext.id();
        return new SYNO.ux.Panel({
            border: true,
            height: this.PANEL_DEV_HEIGHT,
            cls: "syno-syslog-white-bg",
            items: [this.DevicePanel, this.createSourceDesc(this.SrcDevDesc[0], this.SrcDevPer[0], "syno-syslog-blue-box"), this.createSourceDesc(this.SrcDevDesc[1], this.SrcDevPer[1], "syno-syslog-green-box"), this.createSourceDesc(this.SrcDevDesc[2], this.SrcDevPer[2], "syno-syslog-yellow-box"), this.createSourceDesc(this.SrcDevDesc[3], this.SrcDevPer[3], "syno-syslog-grey-box")]
        })
    },
    createSourceDesc: function(c, b, a) {
        return new SYNO.ux.Panel({
            border: false,
            layout: "hbox",
            padding: "2px 18px 2px 18px",
            items: [{
                xtype: "displayfield",
                cls: a
            }, {
                xtype: "displayfield",
                width: 8
            }, {
                id: c,
                xtype: "displayfield",
                labelAlign: "right",
                value: "",
                height: 20,
                flex: 1,
                cls: "syno-syslog-device-desc"
            }, {
                id: b,
                xtype: "displayfield",
                value: "",
                height: 20,
                width: 32,
                cls: "syno-syslog-device-percent"
            }]
        })
    },
    storeIntDevGet: function() {
        return new SYNO.API.Store({
            proxy: new SYNO.API.Proxy({
                api: "SYNO.Core.SyslogClient.Status",
                method: "device_enum",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "items",
                totalProperty: "total",
                id: "value"
            }, [{
                name: "value",
                mapping: "value"
            }, {
                name: "display",
                mapping: "display"
            }]),
            baseParams: {
                action: "dev_enum",
                dev_1: "",
                dev_2: "",
                dev_3: ""
            }
        })
    },
    createOverlayIconPause: function() {
        return new Ext.Container({
            border: false,
            id: "overlay_btn_pause",
            cls: "syno-syslog-polling-pause"
        })
    },
    createOverlayIconPlus: function() {
        return new Ext.Container({
            border: false,
            id: "overlay_plus",
            cls: "syno-syslog-scale-plus"
        })
    },
    createOverlayIconMinus: function() {
        return new Ext.Container({
            border: false,
            id: "overlay_minus",
            cls: "syno-syslog-scale-minus"
        })
    },
    createXAxisLeftMask: function() {
        return new Ext.Container({
            border: false,
            cls: "syno-syslog-eps-left-mask"
        })
    },
    createXAxisRightMask: function() {
        return new Ext.Container({
            border: false,
            cls: "syno-syslog-eps-right-mask"
        })
    },
    createDev: function(b, a) {
        return new SYNO.ux.Panel({
            border: false,
            items: [{
                xtype: "syno_combobox",
                width: 150,
                mode: "remote",
                id: b,
                value: "None",
                editable: false,
                store: this.storeIntDevGet(),
                forceSelection: true,
                allowBlank: false,
                displayField: "display",
                valueField: "value",
                typeAhead: true,
                triggerAction: "all",
                lazyRender: true,
                listeners: {
                    beforequery: function(c) {
                        delete c.combo.lastQuery
                    }
                }
            }]
        })
    },
    createEpsDevSel: function() {
        this.SrcDevCombo[0] = Ext.id();
        this.SrcDevCombo[1] = Ext.id();
        this.SrcDevCombo[2] = Ext.id();
        return new SYNO.ux.Panel({
            layout: "hbox",
            height: this.PANEL_EPSDEVSEL_HEIGHT,
            border: false,
            items: [{
                xtype: "displayfield",
                width: 24
            }, this.createDev(this.SrcDevCombo[0], "syno-syslog-blue-box"), {
                xtype: "displayfield",
                width: 6
            }, this.createDev(this.SrcDevCombo[1], "syno-syslog-green-box"), {
                xtype: "displayfield",
                width: 6
            }, this.createDev(this.SrcDevCombo[2], "syno-syslog-yellow-box")]
        })
    },
    createChartPanel: function() {
        return new SYNO.ux.Panel({
            layout: "hbox",
            border: false,
            height: this.PANEL_EPS_HEIGHT,
            items: [this.createEpsContainer(), this.createPanelDev()]
        })
    },
    createEpsContainer: function() {
        this.OverlayIconPause = this.createOverlayIconPause();
        this.OverlayIconPlus = this.createOverlayIconPlus();
        this.OverlayIconMinus = this.createOverlayIconMinus();
        this.PanelEps = new SYNO.ux.Panel({
            height: this.PANEL_EPS_HEIGHT,
            border: false,
            items: [this.createEpsPanel(), this.OverlayIconPause, this.OverlayIconPlus, this.OverlayIconMinus]
        });
        return this.PanelEps
    },
    createPanelDev: function() {
        this.PanelDevice = new SYNO.ux.Panel({
            width: this.PANEL_DEV_WIDTH,
            border: false,
            cls: "piechart-top-space",
            items: [this.createDevicePanel()]
        });
        return this.PanelDevice
    },
    createPanelStatistic: function() {
        this.XAxisLeftMask = this.createXAxisLeftMask();
        this.XAxisRightMask = this.createXAxisRightMask();
        this.panelStatistic = new SYNO.ux.Panel({
            boxMinWidth: this.PANEL_STATICS_WIDTH,
            height: this.PANEL_STATICS_HEIGHT,
            border: false,
            cls: "syno-syslog-statistic-panel",
            items: [{
                xtype: "displayfield",
                id: this.LogScaleDesc = Ext.id(),
                itemId: "log_scale",
                cls: "syno-syslog-overview-title",
                value: _TT("SYNO.SDS.LogCenter.BuiltIn", "logview", "utilization") + " (" + _TT("SYNO.SDS.LogCenter.BuiltIn", "logstatus", "interval_6_mins") + ")"
            }, this.XAxisLeftMask, this.XAxisRightMask, this.createChartPanel(), {
                xtype: "displayfield",
                value: "",
                height: 11
            }, this.createEpsDevSel()]
        });
        return this.panelStatistic
    },
    fillConfig: function(a) {
        this.PanelLog = new SYNO.SDS.LogCenter.LogPanel();
        this.fsNumber = new SYNO.ux.FieldSet({
            name: "fs_number",
            title: _TT("SYNO.SDS.LogCenter.BuiltIn", "logstatus", "eps_statistic"),
            collapsible: true,
            cls: "overview-statistic",
            items: [this.createPanelStatistic()]
        });
        this.fsLog = new SYNO.ux.FieldSet({
            title: String.format(_TT("SYNO.SDS.LogCenter.BuiltIn", "logstatus", "latest_log"), 50),
            name: "fs_latest",
            collapsible: true,
            cls: "overview-log",
            items: [this.PanelLog]
        });
        var b = {
            cls: "syno-syslog-overview-panel",
            labelAlign: "left",
            border: false,
            trackResetOnLoad: true,
            autoFlexcroll: true,
            padding: "16px 20px 16px 20px",
            items: [{
                xtype: "syno_panel",
                border: false,
                cls: "syno-syslog-overview-panel-card",
                style: "margin-bottom: 8px;",
                items: [this.fsNumber]
            }, {
                xtype: "syno_panel",
                border: false,
                cls: "syno-syslog-overview-panel-card",
                items: [this.fsLog]
            }]
        };
        Ext.apply(b, a);
        return b
    },
    updateEpsChart: function(b) {
        var a;
        if (!b) {
            return
        }
        this.EpsStore.removeAll();
        for (a = 0; a < b.length; a++) {
            this.EpsStore.add(new Ext.data.Record(Ext.applyIf({
                time: parseInt(b[a].time_stamp, 10) * 1000,
                eps: parseInt(b[a].log_count, 10),
                dev1: parseInt(b[a].dev_1, 10),
                dev2: parseInt(b[a].dev_2, 10),
                dev3: parseInt(b[a].dev_3, 10),
                dev: "Total",
                dev1_name: Ext.getCmp(this.SrcDevCombo[0]).getValue(),
                dev2_name: Ext.getCmp(this.SrcDevCombo[1]).getValue(),
                dev3_name: Ext.getCmp(this.SrcDevCombo[2]).getValue()
            })))
        }
        this.EpsStore.fireEvent("datachanged")
    },
    updateEmptyDevice: function() {
        this.DevicePanel.drawEmptyChart();
        Ext.getCmp(this.SrcDevDesc[0]).setValue("None");
        Ext.getCmp(this.SrcDevDesc[1]).setValue("None");
        Ext.getCmp(this.SrcDevDesc[2]).setValue("None");
        Ext.getCmp(this.SrcDevDesc[3]).setValue("None");
        Ext.getCmp(this.SrcDevPer[0]).setValue(" ");
        Ext.getCmp(this.SrcDevPer[1]).setValue(" ");
        Ext.getCmp(this.SrcDevPer[2]).setValue(" ");
        Ext.getCmp(this.SrcDevPer[3]).setValue(" ")
    },
    showMultiDeviceInfo: function(a) {
        if (a) {
            this.PanelDevice.show();
            this.DevicePanel.show();
            Ext.getCmp(this.SrcDevCombo[0]).show();
            Ext.getCmp(this.SrcDevCombo[1]).show();
            Ext.getCmp(this.SrcDevCombo[2]).show()
        } else {
            this.PanelDevice.hide();
            this.DevicePanel.hide();
            Ext.getCmp(this.SrcDevCombo[0]).hide();
            Ext.getCmp(this.SrcDevCombo[1]).hide();
            Ext.getCmp(this.SrcDevCombo[2]).hide()
        }
        this.dataSet[1].show = a;
        this.dataSet[2].show = a;
        this.dataSet[3].show = a
    },
    updateDeviceChart: function(c) {
        var b, a = 0;
        if (!c) {
            this.updateEmptyDevice();
            return
        }
        for (b = 0; b < c.length; b++) {
            a += parseInt(c[b].log_count, 10)
        }
        this.DevStore.removeAll();
        for (b = 0; b < c.length; b++) {
            this.DevStore.add(new Ext.data.Record(Ext.applyIf({
                device: c[b].log_device,
                percent: parseInt(c[b].log_count, 10) / a,
                dev: c[b].log_device
            })))
        }
        for (b = c.length; b < SYNO.SDS.LogCenter.DEV_MAX + 1; b++) {
            this.DevStore.add(new Ext.data.Record(Ext.applyIf({
                device: 0,
                percent: 0,
                dev: ""
            })))
        }
        this.DevStore.fireEvent("datachanged")
    },
    updateDevInfo: function(a) {
        var h = 0,
            d = 0;
        var j = [],
            g = [],
            c = [];
        if (!a) {
            return
        }
        j[0] = Ext.getCmp(this.SrcDevCombo[0]);
        j[1] = Ext.getCmp(this.SrcDevCombo[1]);
        j[2] = Ext.getCmp(this.SrcDevCombo[2]);
        g[0] = Ext.getCmp(this.SrcDevDesc[0]);
        g[1] = Ext.getCmp(this.SrcDevDesc[1]);
        g[2] = Ext.getCmp(this.SrcDevDesc[2]);
        g[3] = Ext.getCmp(this.SrcDevDesc[3]);
        c[0] = Ext.getCmp(this.SrcDevPer[0]);
        c[1] = Ext.getCmp(this.SrcDevPer[1]);
        c[2] = Ext.getCmp(this.SrcDevPer[2]);
        c[3] = Ext.getCmp(this.SrcDevPer[3]);
        for (d = 0; d < a.length; d++) {
            h += parseInt(a[d].log_count, 10)
        }
        for (d = 0; d < a.length; d++) {
            var k, b, f, e, l;
            if ("" === a[d].log_device || "_NONE_" === a[d].log_device) {
                j[d].setValue("None");
                g[d].setValue("None: ");
                c[d].setValue("0%");
                continue
            }
            if (d < SYNO.SDS.LogCenter.DEV_MAX) {
                j[d].setValue(a[d].log_device);
                this.IntDev[d] = a[d].log_device
            }
            k = parseInt(a[d].log_count, 10) / h;
            b = Math.round(k * 100);
            f = Ext.util.Format.ellipsis(a[d].log_device, 11);
            e = f + ": ";
            l = a[d].log_device;
            g[d].setValue(e);
            g[d].el.dom.qtip = l;
            c[d].setValue(b + "%")
        }
    },
    updateRecentLogs: function(a) {
        if (!a) {
            this.PanelLog.dataUpdate([]);
            return
        }
        this.PanelLog.dataUpdate(a)
    },
    updateScalingCtrl: function() {
        var a = _TT("SYNO.SDS.LogCenter.BuiltIn", "logview", "utilization") + " (" + SYNO.SDS.LogCenter.GetScaleDescription(this.EpsScale) + ")";
        Ext.getCmp(this.LogScaleDesc).setValue(a);
        if (this.EpsScale === SYNO.SDS.LogCenter.SCALE_6MIN) {
            Ext.getCmp("overlay_plus").disable()
        } else {
            Ext.getCmp("overlay_plus").enable()
        }
        if (this.EpsScale === SYNO.SDS.LogCenter.SCALE_1DAY) {
            Ext.getCmp("overlay_minus").disable()
        } else {
            Ext.getCmp("overlay_minus").enable()
        }
    },
    updateStore: function(a, c) {
        if (this.fsNumberShow) {
            var b = this.server_enable;
            this.showMultiDeviceInfo(b);
            if (b) {
                this.updateDeviceChart(c.device);
                this.updateDevInfo(c.device)
            }
            this.updateEpsChart(c.eps);
            this.updateScalingCtrl()
        }
        this.updateRecentLogs(c.logs)
    },
    onAjaxRequestDone: function(h, e, g, b) {
        if (this.isDestroyed) {
            return
        }
        if (h) {
            var f = {};
            var a = [],
                c = [],
                d = [];
            Ext.each(e.result, function(i) {
                if (i.hasOwnProperty("data")) {
                    if ("latestlog_get" === i.method) {
                        f.logs = [];
                        if (i.data.hasOwnProperty("logs")) {
                            f.logs = i.data.logs
                        }
                    } else {
                        if ("eps_get" === i.method) {
                            f.eps = [];
                            if (i.data.hasOwnProperty("eps")) {
                                f.eps = i.data.eps
                            }
                        } else {
                            if ("cnt_get" === i.method) {
                                f.device = [];
                                if (i.data.hasOwnProperty("device")) {
                                    f.device = i.data.device
                                }
                            }
                        }
                    }
                }
            });
            this.latestResp = f;
            c = this.LastEpsResult;
            if (f.eps) {
                d = f.eps
            }
            c.splice(0, d.length);
            a = c.concat(d);
            f.eps = a;
            this.updateStore(1, f);
            this.LastEpsResult = a;
            if (0 !== a.length) {
                this.setLastEpsTime(a[a.length - 1].time_stamp)
            }
        }
    },
    startPollingTask: function() {
        var b = {
            api: "SYNO.Core.SyslogClient.Status",
            method: "latestlog_get",
            version: "1"
        };
        var a = {
            api: "SYNO.Core.SyslogClient.Status",
            method: "eps_get",
            version: "1",
            params: {
                dev_1: this.IntDev[0],
                dev_2: this.IntDev[1],
                dev_3: this.IntDev[2],
                scale: this.EpsScale,
                date_from: this.getLastEpsTime()
            }
        };
        var c = {
            api: "SYNO.Core.SyslogClient.Status",
            method: "cnt_get",
            version: "1",
            params: {
                dev_1: this.IntDev[0],
                dev_2: this.IntDev[1],
                dev_3: this.IntDev[2]
            }
        };
        this.task = this.addWebAPITask({
            id: "task_get_syslog_status",
            interval: 3000,
            webapi: {
                compound: {
                    stopwhenerror: false,
                    params: [b, a, c]
                }
            },
            callback: this.onAjaxRequestDone,
            scope: this
        });
        this.task.start()
    },
    stopPollingTask: function() {
        this.task.stop();
        this.removeTask("task_get_syslog_status")
    },
    getLastEpsTime: function() {
        return this.LastEpsTime
    },
    setLastEpsTime: function(a) {
        this.LastEpsTime = a
    },
    resumePollingTask: function() {
        if (this.PauseStatus) {
            this.changeStatusPlay()
        } else {
            this.startPollingTask()
        }
    },
    reloadAllLogs: function() {
        this.setLastEpsTime(0)
    },
    onSelectDevice: function(a) {
        this.stopPollingTask();
        var c = this.SrcDevCombo[a];
        var b = Ext.getCmp(c).getValue();
        this.IntDev[a] = b;
        this.reloadAllLogs();
        this.resumePollingTask()
    },
    onChangeScale: function(a) {
        if ((this.EpsScale === SYNO.SDS.LogCenter.SCALE_6MIN && a) || (this.EpsScale === SYNO.SDS.LogCenter.SCALE_1DAY && !a)) {
            return
        }
        this.stopPollingTask();
        if (a) {
            this.EpsScale--
        } else {
            this.EpsScale++
        }
        this.reloadAllLogs();
        this.resumePollingTask()
    },
    changeStatusPlay: function() {
        Ext.getCmp("overlay_btn_pause").removeClass("syno-syslog-polling-play");
        Ext.getCmp("overlay_btn_pause").addClass("syno-syslog-polling-pause");
        this.startPollingTask();
        this.PauseStatus = false
    },
    changeStatusPause: function() {
        Ext.getCmp("overlay_btn_pause").removeClass("syno-syslog-polling-pause");
        Ext.getCmp("overlay_btn_pause").addClass("syno-syslog-polling-play");
        this.stopPollingTask();
        this.PauseStatus = true
    },
    onClickPause: function() {
        if (this.PauseStatus) {
            this.changeStatusPlay()
        } else {
            this.changeStatusPause()
        }
    },
    onClickPlus: function() {
        this.onChangeScale(true)
    },
    onClickMinus: function() {
        this.onChangeScale(false)
    },
    onPageActivate: function() {
        if (SYNO.SDS.LogCenter.Utils.isPluginsAvailable()) {
            this.appWin.sendWebAPI({
                api: "SYNO.LogCenter.RecvRule",
                method: "list",
                version: 1,
                callback: function(e, c, d, b) {
                    if (e) {
                        this.server_enable = (c.total > 0) ? true : false;
                        this.showMultiDeviceInfo(this.server_enable)
                    }
                },
                scope: this
            })
        }
        this.EpsScale = SYNO.SDS.LogCenter.SCALE_6MIN;
        this.resumePollingTask();
        var a = this.appWin.getInnerHeight() - this.PANEL_STATICS_HEIGHT - 107;
        if (!this.fsNumberShow) {
            a = this.appWin.getInnerHeight() - 100
        }
        this.PanelLog.setHeight(a);
        SYNO.SDS.LogCenter.ResizePanel(this, true)
    },
    onPageDeactivate: function() {
        this.stopPollingTask();
        this.reloadAllLogs()
    }
});
Ext.define("SYNO.SDS.LogCenter.LogPanel", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(b) {
        var d = [{
            dataIndex: "ldate",
            header: _TT("SYNO.SDS.LogCenter.BuiltIn", "logattr", "attr_date"),
            width: 90,
            align: "left",
            renderer: function(f) {
                return SYNO.SDS.DateTimeFormatter(Date.parseDate(f, "Y-m-d"), {
                    type: "date"
                })
            }
        }, {
            dataIndex: "ltime",
            header: _TT("SYNO.SDS.LogCenter.BuiltIn", "logattr", "attr_time"),
            width: 90,
            align: "left",
            renderer: function(f) {
                return SYNO.SDS.DateTimeFormatter(Date.parseDate(f, "H:i:s"), {
                    type: "timesec"
                })
            }
        }, {
            dataIndex: "prio",
            header: _TT("SYNO.SDS.LogCenter.BuiltIn", "logattr", "attr_priority"),
            width: 90,
            align: "left",
            renderer: SYNO.SDS.LogCenter.LevelRenderer
        }, {
            dataIndex: "host",
            header: _TT("SYNO.SDS.LogCenter.BuiltIn", "logattr", "attr_host"),
            width: 100,
            align: "left"
        }, {
            dataIndex: "fac",
            header: _TT("SYNO.SDS.LogCenter.BuiltIn", "logattr", "attr_facility"),
            width: 90,
            align: "left"
        }, {
            dataIndex: "prog",
            header: _TT("SYNO.SDS.LogCenter.BuiltIn", "logattr", "attr_program"),
            width: 100,
            align: "left"
        }, {
            dataIndex: "msg",
            name: "msg",
            id: "msg",
            header: _TT("SYNO.SDS.LogCenter.BuiltIn", "logattr", "attr_msg"),
            width: 100,
            align: "left",
            hideable: false,
            menuDisabled: true,
            renderer: SYNO.SDS.LogCenter.LogRenderer
        }];
        var a = new Ext.grid.ColumnModel({
            defaults: {
                sortable: false,
                menuDisabled: false
            },
            columns: d
        });
        var e = this.logDSInitJson();
        var c = {
            height: 148,
            boxMinHeight: 400,
            viewConfig: {
                forceFit: false,
                trackResetOnLoad: false,
                templates: {
                    cell: new Ext.XTemplate('<td class="x-grid3-col x-grid3-cell x-grid3-td-{id} x-selectable {css}" style="{style}" tabIndex="0" {cellAttr}>', '<div class="{this.selectableCls} x-grid3-cell-inner x-grid3-col-{id}" {attr}>{value}</div>', "</td>", {
                        selectableCls: SYNO.SDS.Utils.SelectableCLS
                    })
                }
            },
            title: null,
            ds: e,
            cm: a,
            loadMask: true,
            autoExpandMin: 50,
            autoExpandColumn: "msg",
            monitorWindowResize: true,
            enableColumnMove: false,
            enableDragDrop: false,
            enableColLock: false,
            stripeRows: true
        };
        this.dsLog = e;
        this.callParent([c])
    },
    logDSInitJson: function() {
        var b = ["id", "host", "ip", "fac", "prio", "llevel", "utcsec", "tzoffset", "ldate", "ltime", "prog", "msg"];
        var a = new Ext.data.JsonStore({
            autoDestroy: true,
            root: "data",
            fields: b
        });
        return a
    },
    dataUpdate: function(a) {
        this.dsLog.loadData({
            data: a
        }, false)
    }
});
Ext.define("SYNO.SDS.LogCenter.GeneralLogBuilder", {
    extend: "Object",
    create: function(e) {
        var d = [
                ["system", _T("log", "log_link_system")],
                ["netbackup", _T("log", "log_link_netbkp")]
            ],
            h = _T("log", "general"),
            g = "general",
            c = "general";
        var b = this.getStore(e.appInst),
            f = this.getColumnModel(),
            a = {
                logType: d,
                title: h,
                itemId: g,
                fileTitle: c,
                ds: b,
                cm: f
            };
        Ext.applyIf(e, a);
        return new SYNO.SDS.LogCenter.BaseLog(e)
    },
    getStore: function(a) {
        var b = new SYNO.API.Store({
            appWindow: a,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.Core.SyslogClient.Log",
                method: "list",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "items",
                totalProperty: "total"
            }, ["logtype", "level", "time", "who", "descr"]),
            remoteSort: false,
            sortInfo: {
                field: "time",
                direction: "DESC"
            },
            autoDestroy: true
        });
        return b
    },
    getColumnModel: function() {
        var b = SYNO.SDS.LogCenter.LevelRenderer,
            c = SYNO.SDS.LogCenter.Utils.datetimeRenderer,
            d = SYNO.SDS.LogCenter.Utils.htmlEncodeRender;
        var a = new Ext.grid.ColumnModel({
            columns: [{
                header: _TT("SYNO.SDS.LogCenter.BuiltIn", "logattr", "attr_priority"),
                menuText: _T("log", "logattr"),
                dataIndex: "level",
                width: 90,
                renderer: b
            }, {
                header: _T("tree", "leaf_log"),
                dataIndex: "logtype",
                width: 90,
                renderer: d
            }, {
                header: _T("log", "log_time"),
                dataIndex: "time",
                width: 160,
                renderer: c
            }, {
                header: _T("log", "log_account"),
                dataIndex: "who",
                width: 120,
                renderer: d
            }, {
                id: "descr",
                header: _T("log", "log_action"),
                dataIndex: "descr",
                css: "white-space:normal;",
                width: 300,
                hideable: false,
                menuDisabled: true,
                renderer: d
            }],
            defaults: {
                sortable: false,
                menuDisabled: false
            }
        });
        return a
    }
});
Ext.define("SYNO.SDS.LogCenter.ConnectionLogBuilder", {
    extend: "Object",
    create: function(e) {
        var d = [
                ["connection", _T("log", "log_link_connection")]
            ],
            h = _T("log", "log_link_connection"),
            g = "connection",
            c = "log_link_connection";
        var b = this.getStore(e.appInst),
            f = this.getColumnModel(),
            a = {
                logType: d,
                title: h,
                itemId: g,
                fileTitle: c,
                ds: b,
                cm: f
            };
        Ext.applyIf(e, a);
        return new SYNO.SDS.LogCenter.BaseLog(e)
    },
    getStore: function(a) {
        var b = new SYNO.API.Store({
            appWindow: a,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.Core.SyslogClient.Log",
                method: "list",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "items",
                totalProperty: "total"
            }, ["logtype", "level", "time", "who", "descr"]),
            remoteSort: false,
            sortInfo: {
                field: "time",
                direction: "DESC"
            },
            autoDestroy: true
        });
        return b
    },
    getColumnModel: function getLogCM() {
        var b = SYNO.SDS.LogCenter.LevelRenderer,
            c = SYNO.SDS.LogCenter.Utils.datetimeRenderer,
            d = SYNO.SDS.LogCenter.Utils.htmlEncodeRender;
        var a = new Ext.grid.ColumnModel({
            columns: [{
                menuText: _T("log", "logattr"),
                header: _TT("SYNO.SDS.LogCenter.BuiltIn", "logattr", "attr_priority"),
                dataIndex: "level",
                width: 90,
                renderer: b
            }, {
                header: _T("tree", "leaf_log"),
                dataIndex: "logtype",
                width: 90,
                renderer: d
            }, {
                header: _T("log", "log_time"),
                dataIndex: "time",
                width: 160,
                renderer: c
            }, {
                header: _T("log", "log_account"),
                dataIndex: "who",
                width: 120,
                renderer: d
            }, {
                id: "descr",
                header: _T("log", "log_action"),
                dataIndex: "descr",
                css: "white-space:normal;",
                width: 300,
                hideable: false,
                menuDisabled: true,
                renderer: d
            }],
            defaults: {
                sortable: false,
                menuDisabled: false
            }
        });
        return a
    }
});
Ext.define("SYNO.SDS.LogCenter.BaseLogUI", {
    extend: "Ext.Panel",
    itemsPerPage: 1000,
    logType: [
        ["syslog", _T("log", "log_link_system")]
    ],
    title: _T("tree", "leaf_log"),
    itemId: "logPanel",
    appInst: undefined,
    baseURL: undefined,
    topwin: undefined,
    store: undefined,
    columnModel: undefined,
    constructor: function(a) {
        Ext.copyTo(this, a, ["listeners", "baseURL", "topwin", "appInst", "logType", "eventType", "title", "itemId", "jsConfig"]);
        this.store = a.ds;
        this.columnModel = a.cm;
        this.itemsPerPage = a.appInst.appInstance.getUserSettings(this.itemId + "-dsPageLimit") || this.itemsPerPage;
        Ext.apply(a, this);
        this.callParent([a])
    },
    getPageRecordStore: function() {
        var a = new Ext.data.SimpleStore({
            fields: ["value", "display"],
            data: [
                [100, 100],
                [500, 500],
                [1000, 1000],
                [3000, 3000]
            ]
        });
        return a
    },
    initPageComboBox: function(a) {
        var b = new SYNO.ux.ComboBox({
            name: "page_rec",
            hiddenName: "page_rec",
            hiddenId: Ext.id(),
            store: a,
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            value: this.itemsPerPage,
            editable: false,
            width: 70,
            mode: "local",
            listeners: {
                select: {
                    fn: this.onChangeDisplayRecord,
                    scope: this
                }
            }
        });
        return b
    },
    initPagingToolbar: function() {
        var a = new SYNO.ux.PagingToolbar({
            store: this.store,
            displayInfo: true,
            displayButtons: true,
            pageSize: this.itemsPerPage,
            smallVerticalPadding: true,
            cls: "log-toolbar",
            items: [{
                xtype: "tbtext",
                style: "padding-right: 4px",
                text: _T("common", "items_perpage")
            }, this.initPageComboBox(this.getPageRecordStore())]
        });
        return a
    },
    initSearchForm: function() {
        var a = new SYNO.SDS.LogCenter.SearchFormPanel({
            cls: "syno-syslog-searchpanel",
            renderTo: Ext.getBody(),
            shadow: false,
            jsConfig: this.jsConfig,
            hidden: true,
            owner: this,
            logType: this.logType
        });
        a.hideItems(["logType", "logTypeLabel"]);
        return a
    },
    initComponent: function() {
        this.searchPanel = this.initSearchForm();
        this.paging = this.initPagingToolbar();
        this.grid = new SYNO.ux.GridPanel({
            view: new SYNO.ux.FleXcroll.grid.BufferView({
                scrollDelay: false,
                borderHeight: 1,
                forceFit: false,
                templates: {
                    cell: new Ext.XTemplate('<td class="x-grid3-col x-grid3-cell x-grid3-td-{id} x-selectable {css}" style="{style}" tabIndex="0" {cellAttr}>', '<div class="{this.selectableCls} x-grid3-cell-inner x-grid3-col-{id}" {attr}>{value}</div>', "</td>", {
                        selectableCls: SYNO.SDS.Utils.SelectableCLS
                    })
                },
                emptyText: ['<div class="syno-dataview">', '<div class="empty-text-wrap">', '<div class="empty-text-inner-wrap">', '<div class="empty-text-icon"></div>', '<div class="empty-text">', _T("log", "no_log_available"), "</div>", "</div>", "</div>", "</div>"].join("")
            }),
            region: "center",
            plugins: "menutextcolumnmodelplugin",
            store: this.store,
            colModel: this.columnModel,
            bbar: this.paging,
            loadMask: true,
            autoExpandColumn: "descr",
            cls: "syno-syslog-remove-sort-icon",
            stripeRows: true
        });
        Ext.apply(this, {
            itemId: this.itemId,
            border: false,
            header: false,
            layout: "border",
            items: [this.grid]
        });
        this.callParent([this])
    }
});
Ext.define("SYNO.SDS.LogCenter.BaseLog", {
    extend: "SYNO.SDS.LogCenter.BaseLogUI",
    searchBuffer: 200,
    constructor: function(a) {
        this.callParent([a]);
        this.searchBuffer = a.searchBuffer || this.searchBuffer;
        this.lastColumeWidth = []
    },
    initEvents: function() {
        this.mon(this.searchPanel, "search", this.onSearch, this, {
            buffer: this.searchBuffer
        });
        this.mon(this, "activate", this.onActive, this);
        this.mon(this.grid.getStore(), "load", this.onAfterStoreLoad, this);
        this.mon(this.grid.getStore(), "beforeload", this.onBeforeStoreLoad, this);
        this.mon(this.grid.getStore(), "loadexception", this.onLoadException, this)
    },
    onChangeDisplayRecord: function(c, d, b) {
        var a = this.grid.getStore();
        if (this.itemsPerPage !== c.getValue()) {
            this.itemsPerPage = c.getValue();
            this.paging.pageSize = this.itemsPerPage;
            a.load({
                params: {
                    start: 0,
                    limit: this.itemsPerPage
                }
            });
            this.appInst.appInstance.setUserSettings(this.itemId + "-dsPageLimit", this.itemsPerPage)
        }
    },
    getLogTypes: function(a) {
        var b = [];
        this.logType.forEach(function(c) {
            b.push(c[0])
        });
        return b.join(a || ",")
    },
    isTheSame: function(b, a) {
        for (var c in a) {
            if (a[c] !== b[c]) {
                return false
            }
        }
        return true
    },
    onSearch: function(b, c) {
        var a = this.grid.getStore();
        if (!this.isTheSame(a.baseParams, c)) {
            Ext.apply(a.baseParams, c);
            this.loadData()
        }
    },
    onActive: function() {
        var a = this.grid.getStore(),
            b = {
                target: "LOCAL",
                logtype: this.getLogTypes(),
                date_from: 0,
                date_to: 0,
                keyword: "",
                level: ""
            };
        Ext.applyIf(a.baseParams, b);
        if (this.requestLogType) {
            Ext.apply(a.baseParams, {
                logtype: this.requestLogType
            })
        }
        this.loadData();
        delete this.requestLogType
    },
    loadData: function() {
        var a = this.grid.getStore(),
            b = {
                start: 0,
                limit: this.itemsPerPage
            };
        a.load({
            params: b
        })
    },
    onLoadException: function(a, c, e, b) {
        if (!e.items) {
            var d = SYNO.API.getErrorString(e.code);
            if (5008 == e.code) {
                d = _T("log", "no_active_log")
            }
            this.grid.getGridEl().mask(d)
        }
    },
    saveColumnWidth: function() {
        this.lastColumeWidth = [];
        for (var a = 0; a < this.columnModel.columns.length; a++) {
            this.lastColumeWidth.push(this.columnModel.getColumnWidth(a))
        }
    },
    restoreColumnWidth: function() {
        for (var a = 0; a < this.lastColumeWidth.length; a++) {
            this.columnModel.setColumnWidth(a, this.lastColumeWidth[a], false)
        }
    },
    onBeforeStoreLoad: function(a, b) {
        this.saveColumnWidth();
        this.grid.getGridEl().unmask()
    },
    onAfterStoreLoad: function(a, f, d) {
        this.restoreColumnWidth();
        var e, c;
        var b = this.grid.view.el.query(".contentwrapper");
        if (f.length < 1) {
            b[0].style.height = "100%";
            this.topwin.enableExportButton(false);
            this.topwin.enableClearButton(false)
        } else {
            b[0].style.height = "";
            this.topwin.enableExportButton(true);
            this.topwin.enableClearButton(true)
        }
        e = a.reader.jsonData;
        c = '<div class="{0}" ext:qtip="{1}">{2}</div>';
        this.setPagingToolbar(a, this.grid, this.paging)
    },
    setPagingToolbar: function(a, b, c) {
        this.setPagingToolbarVisible(c, a.getTotalCount() > this.itemsPerPage)
    },
    setPagingToolbarVisible: function(b, c) {
        var a = 0;
        for (a = 0; a < 13; a++) {
            if (a === 9 || a === 10 || a === 11) {
                continue
            }
            b.items.items[a].setVisible(c)
        }
        b.setButtonsVisible(true)
    },
    setLogLevelText: function(b, a, c, e, d) {
        if (b) {
            d = d || "0";
            b.setText(String.format(a, c, e, d))
        }
    },
    onExportCSV: function() {
        this.onLogSave("csv")
    },
    onExportHtml: function() {
        this.onLogSave("html")
    },
    onLogSave: function(a) {
        if (_S("demo_mode")) {
            this.appInst.getMsgBox().alert(this.appInst.title, _JSLIBSTR("uicommon", "error_demo"));
            return
        }
        this.saveLog(a)
    },
    saveLog: function(b) {
        var a = this.grid.getStore();
        this.appInst.downloadWebAPI({
            webapi: {
                api: "SYNO.Core.SyslogClient.Log",
                version: 1,
                method: "export",
                params: {
                    target: a.baseParams.target,
                    logtype: a.baseParams.logtype,
                    level: a.baseParams.level,
                    sort: a.sortInfo.field,
                    dir: a.sortInfo.direction,
                    date_from: a.baseParams.date_from,
                    date_to: a.baseParams.date_to,
                    keyword: a.baseParams.keyword,
                    format: b
                }
            }
        })
    },
    onLogClear: function() {
        if (_S("demo_mode")) {
            this.appInst.getMsgBox().alert(this.appInst.title, _JSLIBSTR("uicommon", "error_demo"));
            return
        }
        this.topwin.getMsgBox().confirm(_T("tree", "leaf_log"), _T("log", "log_cfrm_clear"), function(a, b) {
            if (a === "yes") {
                this.clearLog()
            }
        }, this)
    },
    clearLog: function() {
        var a = this.grid.getStore();
        a.load({
            params: {
                action: "clear",
                logtype: this.getLogTypes()
            }
        })
    },
    destroy: function() {
        if (this.rowNav) {
            Ext.destroy(this.rowNav);
            this.rowNav = null
        }
        this.callParent([this])
    }
});
Ext.define("SYNO.SDS.LogCenter.FileTransferLog", {
    extend: "SYNO.SDS.LogCenter.BaseLog",
    initSearchForm: function() {
        var a = new SYNO.SDS.LogCenter.SearchFormPanel({
            cls: "syno-syslog-searchpanel",
            renderTo: Ext.getBody(),
            shadow: false,
            jsConfig: this.jsConfig,
            hidden: true,
            owner: this,
            eventType: this.eventType,
            logType: this.logType
        });
        a.hideItems(["logLevel", "logLevelLabel"]);
        a.allLogType = "filexfer";
        return a
    },
    initPagingToolbar: function() {
        var a = new SYNO.ux.PagingToolbar({
            store: this.store,
            displayInfo: true,
            pageSize: this.itemsPerPage,
            showRefreshBtn: true,
            items: ["-", _T("common", "items_perpage"), this.initPageComboBox(this.getPageRecordStore()), "-"]
        });
        return a
    },
    onLoadException: function(a, c, e, b) {
        if (!e.items) {
            var d = SYNO.API.getErrorString(e.code);
            if (5008 == e.code) {
                d = _T("log", "no_active_log")
            }
            this.grid.getGridEl().mask(d);
            this.topwin.enableExportButton(false);
            this.topwin.enableClearButton(false)
        }
    },
    onAfterStoreLoad: function(a, d, c) {
        var b = this.grid.view.el.query(".contentwrapper");
        if (d.length < 1) {
            b[0].style.height = "100%";
            this.topwin.enableExportButton(false);
            this.topwin.enableClearButton(false)
        } else {
            b[0].style.height = "";
            this.topwin.enableExportButton(true);
            this.topwin.enableClearButton(true)
        }
    }
});
Ext.define("SYNO.SDS.LogCenter.FileTransferLogBuilder", {
    extend: "Object",
    create: function(b) {
        var h = [
                ["ftp", _T("log", "log_ftp_xfer")],
                ["filestation", _T("log", "log_filebrowser_xfer")],
                ["webdav", _T("log", "log_webdav_xfer")],
                ["cifs", _T("log", "log_smb_xfer")],
                ["afp", _T("log", "log_afp_xfer")],
                ["tftp", _T("log", "log_tftp_xfer")]
            ],
            g = _T("log", "file_transfer"),
            f = "fileTransfer",
            c = "file_transfer";
        var a = {
            cifs: ["create", "delete", "write", "read", "move", "rename", "permission change"],
            ftp: ["download", "upload", "append", "delete", "move", "create folder", "delete folder"],
            afp: ["create folder", "create", "delete", "move", "read", "write"],
            tftp: ["download", "upload"],
            webdav: ["download", "upload", "delete", "move", "copy", "lock", "unlock"]
        };
        var i = this.getStore(b.appInst),
            d = this.getColumnModel(),
            e = {
                logType: h,
                eventType: a,
                title: g,
                itemId: f,
                fileTitle: c,
                ds: i,
                cm: d
            };
        Ext.applyIf(b, e);
        return new SYNO.SDS.LogCenter.FileTransferLog(b)
    },
    getStore: function(a) {
        var b = new SYNO.API.Store({
            appWindow: a,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.Core.SyslogClient.Log",
                method: "list",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "items",
                totalProperty: "total"
            }, ["logtype", "time", "ip", "username", "cmd", "filesize", "descr", "isdir"]),
            sortInfo: {
                field: "time",
                direction: "DESC"
            },
            autoDestroy: true,
            remoteSort: false
        });
        return b
    },
    getColumnModel: function getLogCM() {
        var c = SYNO.SDS.LogCenter.Utils.datetimeRenderer;
        var e = SYNO.SDS.LogCenter.Utils.htmlEncodeRender;
        var d = function(g, f) {
            g = (g === "true") ? _T("common", "folder") : _T("common", "file");
            return e(g, f)
        };
        var b = function(k, i, f, h, j, g) {
            if (f.get("isdir") === "true" || f.get("cmd") === "create" || f.get("cmd") === "AFP_CREATEFILE") {
                k = "NA"
            }
            return e(k, i)
        };
        var a = new Ext.grid.ColumnModel({
            columns: [{
                header: _T("tree", "leaf_log"),
                dataIndex: "logtype",
                width: 90,
                renderer: e
            }, {
                header: _T("log", "log_time"),
                dataIndex: "time",
                width: 160,
                renderer: c
            }, {
                header: _T("pppoe", "pppoe_IP"),
                dataIndex: "ip",
                width: 105,
                renderer: e
            }, {
                header: _T("log", "log_account"),
                dataIndex: "username",
                width: 115,
                renderer: e
            }, {
                header: _T("log", "log_action"),
                dataIndex: "cmd",
                width: 100,
                renderer: e
            }, {
                header: _T("log", "log_file_folder"),
                dataIndex: "isdir",
                width: 100,
                renderer: d
            }, {
                header: _T("log", "log_filesize"),
                dataIndex: "filesize",
                width: 100,
                renderer: b
            }, {
                id: "descr",
                header: _T("log", "log_filename"),
                dataIndex: "descr",
                width: 300,
                hideable: false,
                menuDisabled: true,
                renderer: e
            }],
            defaults: {
                sortable: false,
                forceFit: false,
                menuDisabled: false
            }
        });
        return a
    }
});
Ext.define("SYNO.SDS.LogCenter.DiskLogBuilder", {
    extend: "Object",
    create: function(e) {
        var d = [
                ["disk", _T("log", "disk_related")]
            ],
            h = _T("log", "disk_related"),
            g = "disk",
            c = "disk_related";
        var b = this.getStore(e.appInst),
            f = this.getColumnModel(),
            a = {
                logType: d,
                title: h,
                itemId: g,
                fileTitle: c,
                ds: b,
                cm: f
            };
        Ext.applyIf(e, a);
        return new SYNO.SDS.LogCenter.BaseLog(e)
    },
    getStore: function(a) {
        var b = new SYNO.API.Store({
            appWindow: a,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.Core.SyslogClient.Log",
                method: "list",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "items",
                totalProperty: "total"
            }, ["level", "time", "model", "serial", "container", "slot", "msg"]),
            remoteSort: false,
            sortInfo: {
                field: "time",
                direction: "DESC"
            },
            autoDestroy: true
        });
        return b
    },
    getColumnModel: function getLogCM() {
        var b = SYNO.SDS.LogCenter.LevelRenderer,
            c = SYNO.SDS.LogCenter.Utils.datetimeRenderer,
            d = SYNO.SDS.LogCenter.Utils.htmlEncodeRender;
        var a = new Ext.grid.ColumnModel({
            columns: [{
                menuText: _T("log", "logattr"),
                header: _TT("SYNO.SDS.LogCenter.BuiltIn", "logattr", "attr_priority"),
                dataIndex: "level",
                width: 90,
                renderer: b
            }, {
                header: _T("log", "log_time"),
                dataIndex: "time",
                width: 160,
                renderer: c
            }, {
                header: _T("volume", "volume_diskmodel"),
                dataIndex: "model",
                width: 80,
                renderer: d
            }, {
                header: _T("smart", "smart_disk_serial"),
                dataIndex: "serial",
                width: 80,
                renderer: d
            }, {
                header: _T("volume", "volume_e_unit"),
                dataIndex: "container",
                width: 60,
                renderer: d
            }, {
                header: _T("dsmoption", "login_logo_position"),
                dataIndex: "slot",
                width: 60,
                renderer: d
            }, {
                id: "descr",
                header: _T("log", "log_action"),
                dataIndex: "msg",
                css: "white-space:normal;",
                width: 100,
                hideable: false,
                menuDisabled: true,
                renderer: d
            }],
            defaults: {
                sortable: false,
                menuDisabled: false
            }
        });
        return a
    }
});
Ext.define("SYNO.SDS.LogCenter.SHALogBuilder", {
    extend: "Object",
    create: function(a) {
        var h = [
                ["sha", _T("log", "sha")]
            ],
            g = _T("log", "sha"),
            f = "sha",
            b = "sha";
        var i = this.getStore(a.appInst),
            d = this.getColumnModel(),
            e = {
                logType: h,
                title: g,
                itemId: f,
                fileTitle: b,
                ds: i,
                cm: d
            };
        Ext.applyIf(a, e);
        var c = new SYNO.SDS.LogCenter.BaseLog(a);
        c.onLogSave = function(k) {
            var j = this.grid.getStore();
            this.appInst.downloadWebAPI({
                webapi: {
                    api: "SYNO.SHA.Panel.Log",
                    version: 1,
                    method: "export",
                    params: {
                        target: j.baseParams.target,
                        logtype: j.baseParams.logtype,
                        level: j.baseParams.level,
                        sort: j.sortInfo.field,
                        dir: j.sortInfo.direction,
                        date_from: j.baseParams.date_from,
                        date_to: j.baseParams.date_to,
                        keyword: j.baseParams.keyword,
                        format: k
                    }
                }
            })
        };
        return c
    },
    getStore: function(a) {
        var b = new SYNO.API.Store({
            appWindow: a,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.SHA.Panel.Log",
                method: "query",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                idProperty: "id",
                root: "logs",
                totalProperty: "summary.total",
                fields: [{
                    name: "level",
                    mapping: "level"
                }, {
                    name: "time",
                    mapping: "time"
                }, {
                    name: "user",
                    mapping: "username"
                }, {
                    name: "event",
                    mapping: "event"
                }]
            }),
            remoteSort: false,
            sortInfo: {
                field: "time",
                direction: "DESC"
            },
            autoDestroy: true
        });
        return b
    },
    getColumnModel: function getLogCM() {
        var b = SYNO.SDS.LogCenter.LevelRenderer,
            d = SYNO.SDS.LogCenter.Utils.htmlEncodeRender,
            c = SYNO.SDS.LogCenter.Utils.datetimeRenderer;
        var a = new Ext.grid.ColumnModel({
            columns: [{
                menuText: _T("log", "logattr"),
                header: _TT("SYNO.SDS.LogCenter.BuiltIn", "logattr", "attr_priority"),
                dataIndex: "level",
                width: 90,
                renderer: b
            }, {
                header: _T("log", "log_time"),
                dataIndex: "time",
                width: 160,
                renderer: c
            }, {
                header: _T("log", "log_account"),
                dataIndex: "user",
                width: 160,
                renderer: d
            }, {
                id: "descr",
                header: _T("log", "log_action"),
                dataIndex: "event",
                css: "white-space:normal;",
                width: 100,
                hideable: false,
                menuDisabled: true,
                renderer: d
            }],
            defaults: {
                sortable: false,
                menuDisabled: false
            }
        });
        return a
    }
});
Ext.define("SYNO.SDS.LogCenter.MultiSelectedDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        Ext.apply(this, a);
        this.orginalValue = this.combo.getMultiValue ? this.combo.getMultiValue().toString() : this.combo.getValue();
        this.orginalDisplayValue = this.combo.getRawValue();
        this.attriFormPanel = this.createAttriFormPanel();
        var b = {
            width: 335,
            height: 380,
            resizable: false,
            title: a.title,
            comboName: a.combo.name,
            layout: "fit",
            closable: true,
            autoScroll: true,
            owner: a.owner,
            items: [this.attriFormPanel],
            buttons: [{
                text: _T("common", "cancel"),
                itemId: "cancel",
                handler: this.onCancel,
                scope: this
            }, {
                text: _T("common", "apply"),
                itemId: "apply",
                btnStyle: "blue",
                handler: this.onOk,
                scope: this
            }]
        };
        SYNO.SDS.LogCenter.MultiSelectedDialog.superclass.constructor.call(this, b);
        this.initEvent()
    },
    initEvent: function() {
        this.mon(this, "close", this.onClose, this)
    },
    createAttriFormPanel: function() {
        var g = this.combo.getStore(),
            a = [],
            d = this.combo.displayField,
            c = this.combo.valueField,
            f, e;
        a.push({
            xtype: "syno_displayfield",
            indent: 0,
            value: _T("log", "title_select_desc") + _T("common", "colon")
        });
        g.each(function(i) {
            f = i.get(c);
            e = i.get(d);
            if (g.indexOf(i) === 0 || f === "more") {
                return true
            }
            var h = {
                xtype: "syno_checkbox",
                indent: 0,
                name: i.get(c),
                boxLabel: i.get(d)
            };
            a.push(h)
        }, this);
        var b = {
            labelWidth: 190,
            labelAlign: "left",
            border: false,
            autoHeight: true,
            trackResetOnLoad: true,
            items: a
        };
        return new Ext.form.FormPanel(b)
    },
    setCheckBox: function() {
        var d = this.attriFormPanel.getForm(),
            b = this.combo,
            e = b.getStore(),
            c = b.getMultiValue() || [],
            a = b.valueField;
        c = c.length > 0 ? c : [b.getValue()];
        e.each(function(g) {
            var f = g.get(a);
            if (c.indexOf(f) !== -1 && d.findField(f)) {
                d.findField(f).setValue(true)
            }
        }, this)
    },
    showUp: function() {
        if (this.getFlagCustomOptionWindowShow(this.comboName)) {
            return
        }
        this.setFlagCustomOptionWindowShow(this.comboName, true);
        this.setCheckBox();
        this.open();
        this.getEl().dom.style.zIndex = "11001"
    },
    onOk: function() {
        var f = this.attriFormPanel.getForm(),
            c = this.combo,
            g = c.getStore(),
            a = [],
            e = [],
            d = c.displayField,
            b = c.valueField;
        g.each(function(k) {
            var h = k.get(b),
                j = k.get(d),
                i = f.findField(h);
            if (i && i.getValue()) {
                a.push(j);
                e.push(h)
            }
        }, this);
        if (a.length === g.getCount() - 2) {
            c.setValue(this.emptyValue)
        } else {
            if (0 < a.length) {
                c.setRawValue(a.toString())
            } else {
                c.setValue(this.emptyValue)
            }
        }
        c.setMultiValue(e);
        c.fireEvent("select", c);
        this.isOK = true;
        Ext.Element.prototype.frame.apply(c.el, this.anim);
        this.close()
    },
    getFlagCustomOptionWindowShow: function(a) {
        return this.parentPanel.flagCustomOptionWindowShow[a]
    },
    setFlagCustomOptionWindowShow: function(b, a) {
        this.parentPanel.flagCustomOptionWindowShow[b] = a
    },
    onCancel: function() {
        this.close()
    },
    onClose: function() {
        var a = this.combo;
        if (!this.isOK) {
            a.setMultiValue(this.orginalValue);
            a.setRawValue(this.orginalDisplayValue)
        }
        this.setFlagCustomOptionWindowShow(this.comboName, false)
    }
});
Ext.define("SYNO.SDS.LogCenter.AdvancedSearchField", {
    extend: "SYNO.ux.SearchField",
    validator: SYNO.SDS.LogCenter.KeywordValidator,
    initEvents: function() {
        this.callParent(arguments);
        this.mon(Ext.getDoc(), "mousedown", this.onMouseDown, this);
        this.mon(this, "keypress", function(b, a) {
            if (a.getKey() === Ext.EventObject.ENTER) {
                if (!this.validate()) {
                    return
                }
                this.searchPanel.setKeyWord(this.getValue());
                this.searchPanel.onSearch()
            }
        }, this)
    },
    isInnerComponent: function(c, b) {
        var a = false;
        b.items.each(function(d) {
            if (d instanceof Ext.form.ComboBox) {
                if (d.view && c.within(d.view.getEl())) {
                    a = true;
                    return false
                }
            } else {
                if (d instanceof SYNO.ux.DateTimeField) {
                    if (d.isWithinEl(c)) {
                        a = true;
                        return false
                    }
                } else {
                    if (d instanceof Ext.form.CompositeField) {
                        if (this.isInnerComponent(c, d)) {
                            a = true;
                            return false
                        }
                    }
                }
            }
        }, this);
        return a
    },
    onMouseDown: function(b) {
        var a = this.searchPanel;
        if (a && a.isVisible() && !a.isDestroyed && !a.inEl && !b.within(a.getEl()) && !b.within(this.searchtrigger) && !this.isInnerComponent(b, this.searchPanel.getForm())) {
            a.hide()
        }
    },
    onSearchTriggerClick: function() {
        if (this.searchPanel.isVisible()) {
            this.searchPanel.hide();
            return
        }
        this.searchPanel.getEl().alignTo(this.wrap, "tr-br?", [0, 1]);
        this.searchPanel.show();
        this.searchPanel.setKeyWord(this.getValue())
    },
    onTriggerClick: function() {
        this.callParent();
        this.searchPanel.onReset();
        this.searchPanel.onSearch()
    }
});
Ext.define("SYNO.SDS.LogCenter.SearchFormPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(a) {
        this.dateType = {
            custom: 1,
            today: 2,
            yesterday: 4,
            lastweek: 8,
            lastmonth: 16
        };
        this.dataRange = [
            [this.dateType.custom, _T("log", "date_custom")],
            [this.dateType.today, _T("log", "date_today")],
            [this.dateType.yesterday, _T("log", "date_yesterday")],
            [this.dateType.lastweek, _T("log", "date_lastweek")],
            [this.dateType.lastmonth, _T("log", "date_lastmonth")]
        ];
        this.logLevelType = {
            info: "info",
            warn: "warning",
            error: "err"
        };
        this.logLevel = [
            [this.logLevelType.info, _T("log", "info_level")],
            [this.logLevelType.warn, _T("log", "warn_level")],
            [this.logLevelType.error, _T("log", "error_level")]
        ];
        this.defaultAnimation = ["#000", 1, {
            duration: 0.35
        }];
        this.dateFormat = SYNO.SDS.DateTimeUtils.GetDateFormat();
        Ext.apply(this, a || {});
        var b = this.fillConfig(a);
        this.callParent([b]);
        this.defineBehaviors();
        this.mon(this, "afterlayout", this.addToolTip, this, {
            single: true
        })
    },
    initComponent: function() {
        this.callParent([this]);
        this.addEvents("search")
    },
    getAllLogType: function(a) {
        var b = [];
        a.forEach(function(c) {
            b.push(c[0])
        });
        return b.join(",")
    },
    getAllLogDisplayText: function(a) {
        var b = [];
        a.forEach(function(c) {
            b.push(c[1])
        });
        return b.join(",")
    },
    fillConfig: function(h) {
        var d, j, e, m, a, g, f, b, l, k;
        var i = [];
        this.logType = h.logType;
        this.eventType = h.eventType;
        this.allLogType = this.getAllLogType(h.logType);
        this.allLogDisplayText = this.getAllLogDisplayText(h.logType);
        this.flagCustomOptionWindowShow = {};
        d = this.createKeyword();
        j = this.createFriendlyDate();
        e = this.createCustDate();
        m = this.createLevel();
        a = this.createType(h);
        g = this.createPrio();
        f = this.createHost();
        b = this.createProgram();
        l = this.createCategory();
        k = this.createEvent(h);
        i.push(d);
        i.push(j);
        i.push(e);
        i.push(m);
        i.push(a);
        i.push(k);
        if (this.allLogType === "recvlog") {
            i.push(g);
            i.push(f);
            i.push(b);
            i.push(l)
        }
        i.push({
            xtype: "toolbar",
            border: false,
            itemId: "btns",
            toolbarCls: "syno-syslog-searchpanel-btn",
            style: "padding: 0px; padding-top: 12px;",
            items: [{
                xtype: "lctbtext",
                itemId: "search-loading",
                text: ""
            }, {
                xtype: "lctbtext",
                itemId: "msg",
                height: 26,
                style: "-webkit-text-size-adjust:none;font-size:11px;color:red;height:26px;overflow:hidden;",
                text: ""
            }, {
                xtype: "tbfill"
            }, {
                itemId: "btn_stop",
                xtype: "syno_button",
                btnStyle: "blue",
                cls: "syno-syslog-searchpanel-btn-reset",
                text: "Stop",
                hidden: true,
                handler: this.onStop,
                scope: this
            }, {
                xtype: "syno_button",
                cls: "syno-syslog-searchpanel-btn-reset",
                text: _T("common", "reset"),
                handler: this.onReset,
                scope: this
            }, {
                itemId: "btn_search",
                xtype: "syno_button",
                btnStyle: "blue",
                cls: "syno-syslog-searchpanel-btn-search",
                text: _T("log", "search"),
                handler: this.onSearch,
                scope: this
            }]
        });
        var c = {
            width: 368,
            heigh: 480,
            floating: true,
            labelAlign: "left",
            trackResetOnLoad: true,
            waitMsgTarget: true,
            autoFlexcroll: false,
            defaults: {
                hideLabel: true,
                anchor: "100%"
            },
            items: i,
            listeners: {
                actionfailed: {
                    fn: function() {
                        this.setMsg("");
                        this.form.reset()
                    },
                    scope: this
                },
                beforeshow: {
                    fn: function() {
                        this.doLayout()
                    },
                    single: true
                },
                show: {
                    fn: this.doLayout,
                    single: true
                },
                beforehide: {
                    fn: function() {
                        if (Object.values(this.flagCustomOptionWindowShow).some(function(n) {
                                return n
                            })) {
                            return false
                        }
                    }
                }
            },
            keys: [{
                key: [10, 13],
                fn: function() {
                    if (!this.isVisible()) {
                        return
                    }
                    if (!this.btnSearch.hidden && !this.btnSearch.disabled) {
                        this.onSearch()
                    } else {
                        if (!this.btnStop.hidden && !this.btnStop.disabled) {
                            this.onStop()
                        }
                    }
                },
                scope: this
            }]
        };
        return c
    },
    setComboBoxValue: function(b, a) {
        this.frameAnimation(b.el, this.defaultAnimation);
        if (b.setMultiValue) {
            b.setMultiValue(a.split(","))
        }
    },
    getComboBoxValue: function(b) {
        var a = this.getForm().findField(b);
        return a.getMultiValue ? a.getMultiValue().toString() : a.getValue()
    },
    multiSelect: function(c, e, a, d, b) {
        Ext.applyIf(c, {
            setMultiValue: function(f) {
                if (!Ext.isArray(f)) {
                    f = [f]
                }
                this.multiValue = f
            },
            getMultiValue: function() {
                return this.multiValue && this.multiValue.length > 0 ? this.multiValue : this.getValue().split(",")
            }
        });
        if ("more" === e.get("value")) {
            this.attriWin = new SYNO.SDS.LogCenter.MultiSelectedDialog({
                title: d,
                combo: c,
                emptyValue: b,
                anim: this.defaultAnimation,
                owner: this.owner.appInst,
                parentPanel: this
            });
            this.attriWin.showUp();
            c.collapse();
            return false
        }
    },
    createTpl: function() {
        return new Ext.XTemplate('<tpl for=".">', '<div class="x-combo-list-item" ext:qtip="{displayText}">', "{displayText}", "</div>", "</tpl>")
    },
    logSelect: function(d, a, b) {
        var c = d.getValue();
        if ("more" === c && _T("log", "more_item") + "..." !== d.getRawValue()) {
            return
        }
        this.setComboBoxValue(d, c)
    },
    createKeyword: function() {
        return [{
            xtype: "syno_displayfield",
            value: _T("log", "attr_keyword") + _T("common", "colon"),
            flex: 1
        }, {
            xtype: "syno_textfield",
            msgTarget: "qtip",
            validateOnBlur: true,
            validationEvent: "blur",
            name: "keyword",
            style: "margin-bottom: 12px;",
            flex: 2,
            validator: SYNO.SDS.LogCenter.KeywordValidator,
            anchor: "91%"
        }]
    },
    setDate: function(c, b, a) {
        if (a === true) {
            this.frameAnimation(this.form.findField("searchdatefrom").el, this.defaultAnimation);
            this.frameAnimation(this.form.findField("searchdateto").el, this.defaultAnimation)
        }
        this.form.findField("searchdatefrom").setMaxValue(b);
        this.form.findField("searchdateto").setMinValue(c);
        this.form.findField("searchdatefrom").setValue(c);
        this.form.findField("searchdateto").setValue(b)
    },
    getFromToDate: function(c) {
        var e, d, b = new Date();
        if (c === this.dateType.today) {
            e = b;
            d = b
        } else {
            if (c === this.dateType.yesterday) {
                e = b.add(Date.DAY, -1);
                d = e
            } else {
                if (c === this.dateType.lastweek) {
                    var a = b.getDay();
                    e = b.add(Date.DAY, -7 - a);
                    d = e.add(Date.DAY, 6)
                } else {
                    if (c === this.dateType.lastmonth) {
                        b = b.add(Date.MONTH, -1);
                        e = b.getFirstDateOfMonth();
                        d = b.getLastDateOfMonth()
                    }
                }
            }
        }
        return {
            from: e,
            to: d
        }
    },
    friendlyDateSelect: function(c, e, a) {
        var b = e.get("id"),
            d = this.getFromToDate(b);
        this.setDate(d.from, d.to, true)
    },
    getFriendlyDateStore: function() {
        var a = this.dataRange;
        return new Ext.data.ArrayStore({
            autoDestroy: true,
            fields: ["id", "displayText"],
            data: a
        })
    },
    createFriendlyDate: function() {
        this.FriendlyDate = new SYNO.ux.ComboBox({
            mode: "local",
            editable: false,
            name: "dateRange",
            tpl: this.createTpl(),
            store: this.getFriendlyDateStore(),
            displayField: "displayText",
            valueField: "id",
            triggerAction: "all",
            lazyRender: true,
            flex: 6,
            value: this.dateType.custom,
            style: "margin-bottom: 12px;",
            listeners: {
                scope: this,
                beforequery: function(a) {
                    delete a.combo.lastQuery
                },
                beforeselect: this.friendlyDateSelect
            }
        });
        return [{
            xtype: "syno_displayfield",
            value: _T("log", "date_range") + _T("common", "colon"),
            flex: 1
        }, this.FriendlyDate]
    },
    createCustDate: function() {
        this.DateFrom = new SYNO.ux.DateTimeField({
            name: "searchdatefrom",
            editable: false,
            format: this.dateFormat,
            emptyText: _T("log", "date_from"),
            value: "",
            style: "margin-bottom: 12px;",
            listeners: {
                scope: this,
                select: function(b, a) {
                    this.form.findField("searchdateto").setMinValue(a)
                }
            }
        });
        this.DateTo = new SYNO.ux.DateTimeField({
            name: "searchdateto",
            editable: false,
            format: this.dateFormat,
            emptyText: _T("log", "date_to"),
            value: "",
            listeners: {
                scope: this,
                select: function(b, a) {
                    this.form.findField("searchdatefrom").setMaxValue(a)
                }
            }
        });
        return [{
            xtype: "syno_displayfield",
            value: _T("time", "time_date") + _T("common", "colon")
        }, {
            xtype: "syno_compositefield",
            hideLabel: true,
            defaults: {
                flex: 1
            },
            defaultMargins: "0 8 0 0",
            items: [this.DateFrom, this.DateTo]
        }]
    },
    getLogLevelStore: function() {
        var a = this.logLevel.slice(0, this.logLevel.length);
        if (a.length > 1) {
            a.splice(0, 0, ["", _T("log", "log_all")]);
            a.push(["more", _T("log", "more_item") + "..."])
        }
        return new Ext.data.ArrayStore({
            autoDestroy: true,
            fields: ["value", "displayText"],
            data: a
        })
    },
    multiLogLevelSelect: function(b, c, a) {
        this.multiSelect(b, c, a, _T("log", "logattr"), "")
    },
    createLevel: function() {
        this.LogLevel = new SYNO.ux.ComboBox({
            xtype: "syno_combobox",
            mode: "local",
            editable: false,
            name: "logLevel",
            tpl: this.createTpl(),
            store: this.getLogLevelStore(),
            displayField: "displayText",
            valueField: "value",
            triggerAction: "all",
            lazyRender: true,
            flex: 3,
            value: "",
            listeners: {
                scope: this,
                beforequery: function(a) {
                    delete a.combo.lastQuery
                },
                beforeselect: this.multiLogLevelSelect,
                select: this.logSelect
            }
        });
        return [{
            xtype: "syno_displayfield",
            name: "logLevelLabel",
            value: _T("log", "logattr") + _T("common", "colon"),
            flex: 1
        }, this.LogLevel]
    },
    getLogTypeStore: function(a) {
        a = a.slice(0, a.length);
        if (a.length > 1) {
            a.splice(0, 0, ["", _T("log", "log_all")]);
            a.push(["more", _T("log", "more_item") + "..."])
        }
        return new Ext.data.ArrayStore({
            autoDestroy: true,
            fields: ["value", "displayText"],
            data: a
        })
    },
    multiLogSelect: function(b, c, a) {
        this.multiSelect(b, c, a, _T("tree", "leaf_log"), "")
    },
    multiLogChange: function(e, d) {
        var b = this.form.findField("eventType");
        var a = this.getLegalEvents(d, this.eventType);
        var c = function(f) {
            var h = this.getComboBoxValue("eventType");
            if ("" === h) {
                return false
            }
            var g = function(j) {
                var i = f.find(function(k) {
                    return (k[0] === j)
                });
                return (undefined !== i)
            };
            return !h.split(",").every(g)
        }.bind(this);
        b.getStore().loadData(a);
        if (2 < a.length) {
            b.setDisabled(false);
            if (c(a)) {
                b.setValue("");
                this.setComboBoxValue(b, "")
            }
        } else {
            b.setDisabled(true);
            b.setValue("");
            this.setComboBoxValue(b, "")
        }
    },
    logTypeSelect: function(d, a, b, c) {
        this.logSelect(d, a, b, c);
        this.multiLogChange(d, d.getMultiValue().toString());
        d.fireEvent("blur")
    },
    getLogConfig: function(b, a) {
        this.LogTypeCombobox = new SYNO.ux.ComboBox({
            name: "logType",
            hiddenName: "logType",
            editable: false,
            tpl: this.createTpl(),
            mode: "local",
            store: this.getLogTypeStore(b),
            displayField: "displayText",
            valueField: "value",
            triggerAction: "all",
            lazyRender: true,
            flex: a || 3,
            value: "",
            style: "margin-bottom: 12px;",
            listeners: {
                scope: this,
                beforequery: function(c) {
                    delete c.combo.lastQuery
                },
                beforeselect: this.multiLogSelect,
                select: this.logTypeSelect
            }
        });
        this.LogTypeLabel = new SYNO.ux.DisplayField({
            name: "logType",
            flex: a || 3,
            value: this.logType.length < 2 ? "" : this.allLogDisplayText
        });
        if (!Ext.isArray(b)) {
            b = [b]
        }
        return b.length < 2 ? this.LogTypeLabel : this.LogTypeCombobox
    },
    createType: function(a) {
        return [{
            xtype: "syno_displayfield",
            name: "logTypeLabel",
            value: this.logType.length < 2 ? "" : _T("tree", "leaf_log") + _T("common", "colon"),
            flex: 3
        }, this.getLogConfig(a.logType, a.flex)]
    },
    multiEventSelect: function(b, c, a) {
        this.multiSelect(b, c, a, _T("log", "log_action"), "")
    },
    getEventConfig: function(c, b) {
        var a = this.getLogEventStore("", c);
        this.eventTypeCombobox = new SYNO.ux.ComboBox({
            name: "eventType",
            hiddenName: "eventType",
            editable: false,
            tpl: this.createTpl(),
            mode: "local",
            store: a,
            displayField: "displayText",
            valueField: "value",
            triggerAction: "all",
            lazyRender: true,
            flex: b || 3,
            value: "",
            style: "margin-bottom: 12px;",
            hidden: (c) ? false : true,
            disabled: (2 < a.getCount()) ? false : true,
            listeners: {
                scope: this,
                beforequery: function(d) {
                    delete d.combo.lastQuery
                },
                beforeselect: this.multiEventSelect,
                select: this.logSelect
            }
        });
        return this.eventTypeCombobox
    },
    createEvent: function(a) {
        return [{
            xtype: "syno_displayfield",
            name: "eventTypeLabel",
            value: _T("log", "log_action") + _T("common", "colon"),
            hidden: (a.eventType) ? false : true,
            flex: 3
        }, this.getEventConfig(a.eventType, a.flex)]
    },
    getLegalEvents: function(c, d) {
        var b = [];
        var a = [];
        var f = Object.keys(SYNO.SDS.LogCenter.FileProtocolEventMap);
        var e = {};
        if ("" === c) {
            b = (d) ? Object.keys(d) : []
        } else {
            b = c.split(",")
        }
        if (d) {
            b.forEach(function(g) {
                if (!d.hasOwnProperty(g)) {
                    return
                }
                d[g].forEach(function(h) {
                    if (!e[h]) {
                        e[h] = true
                    }
                })
            });
            f.forEach(function(g) {
                if (true === e[g]) {
                    a.push([g, SYNO.SDS.LogCenter.FileProtocolEventMap[g]])
                }
            })
        }
        a.splice(0, 0, ["", _T("log", "log_all")]);
        a.push(["more", _T("log", "more_item") + "..."]);
        return a
    },
    getLogEventStore: function(a, b) {
        return new Ext.data.ArrayStore({
            autoDestroy: true,
            fields: ["value", "displayText"],
            data: this.getLegalEvents(a, b)
        })
    },
    priorStoreGet: function() {
        var a = [
            ["", _T("log", "log_all")],
            ["emerg", "Emergency"],
            ["alert", "Alert"],
            ["crit", "Critical"],
            ["err", "Error"],
            ["warning", "Warning"],
            ["notice", "Notice"],
            ["info", "Information"],
            ["debug", "Debug"],
            ["more", _T("log", "more_item") + "..."]
        ];
        return new Ext.data.SimpleStore({
            autoDestroy: true,
            fields: ["value", "displayText"],
            data: a
        })
    },
    multiAttrPrioSelect: function(b, c, a) {
        this.multiSelect(b, c, a, _TT("SYNO.SDS.LogCenter.BuiltIn", "logattr", "attr_priority"), "")
    },
    createPrio: function() {
        this.LogPrio = new SYNO.ux.ComboBox({
            xtype: "syno_combobox",
            name: "prio",
            editable: false,
            store: this.priorStoreGet(),
            tpl: this.createTpl(),
            displayField: "displayText",
            valueField: "value",
            triggerAction: "all",
            lazyRender: true,
            value: "",
            listeners: {
                scope: this,
                beforeselect: this.multiAttrPrioSelect,
                select: this.logSelect
            }
        });
        return [{
            xtype: "syno_displayfield",
            name: "prioLabel",
            value: _TT("SYNO.SDS.LogCenter.BuiltIn", "logattr", "attr_priority") + _T("common", "colon")
        }, this.LogPrio]
    },
    logAttriDbSet: function(a) {
        this.LogHost.getStore().baseParams.db_path = a;
        this.LogProgram.getStore().baseParams.db_path = a;
        this.LogCategory.getStore().baseParams.db_path = a
    },
    logAttriStoreGet: function(a) {
        return new SYNO.API.Store({
            proxy: new SYNO.API.Proxy({
                api: "SYNO.Core.SyslogClient.Status",
                method: "attr_enum",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "items",
                totalProperty: "total",
                id: "value"
            }, [{
                name: "value",
                mapping: "value"
            }, {
                name: "displayText",
                mapping: "displayText"
            }]),
            remoteSort: true,
            baseParams: {
                attr: a,
                db_path: "LOCALARCH"
            },
            pruneModifiedRecords: true,
            data: {
                total: 1,
                items: [{
                    value: "",
                    displayText: _T("log", "log_all")
                }]
            }
        })
    },
    hostNameStoreGet: function() {
        return this.logAttriStoreGet("host")
    },
    multiAttrHostSelect: function(b, c, a) {
        this.multiSelect(b, c, a, _TT("SYNO.SDS.LogCenter.BuiltIn", "logattr", "attr_host"), "")
    },
    createHost: function() {
        this.LogHost = new SYNO.ux.ComboBox({
            xtype: "syno_combobox",
            name: "host",
            editable: false,
            mode: "remote",
            store: this.hostNameStoreGet(),
            tpl: this.createTpl(),
            displayField: "displayText",
            valueField: "value",
            triggerAction: "all",
            lazyRender: true,
            value: "",
            listeners: {
                scope: this,
                beforequery: function(a) {
                    delete a.combo.lastQuery
                },
                beforeselect: this.multiAttrHostSelect,
                select: this.logSelect
            }
        });
        return [{
            xtype: "syno_displayfield",
            name: "hostLabel",
            value: _TT("SYNO.SDS.LogCenter.BuiltIn", "logattr", "attr_host") + _T("common", "colon")
        }, this.LogHost]
    },
    progStoreGet: function() {
        return this.logAttriStoreGet("prog")
    },
    multiAttrProgSelect: function(b, c, a) {
        this.multiSelect(b, c, a, _TT("SYNO.SDS.LogCenter.BuiltIn", "logattr", "attr_program"), "")
    },
    createProgram: function() {
        this.LogProgram = new SYNO.ux.ComboBox({
            xtype: "syno_combobox",
            name: "prog",
            editable: false,
            mode: "remote",
            store: this.progStoreGet(),
            tpl: this.createTpl(),
            displayField: "displayText",
            valueField: "value",
            triggerAction: "all",
            lazyRender: true,
            value: "",
            listeners: {
                scope: this,
                beforequery: function(a) {
                    delete a.combo.lastQuery
                },
                beforeselect: this.multiAttrProgSelect,
                select: this.logSelect
            }
        });
        return [{
            xtype: "syno_displayfield",
            name: "progLabel",
            value: _TT("SYNO.SDS.LogCenter.BuiltIn", "logattr", "attr_program") + _T("common", "colon")
        }, this.LogProgram]
    },
    facStoreGet: function() {
        return this.logAttriStoreGet("fac")
    },
    multiAttrFacSelect: function(b, c, a) {
        this.multiSelect(b, c, a, _TT("SYNO.SDS.LogCenter.BuiltIn", "logattr", "attr_facility"), "")
    },
    createCategory: function() {
        this.LogCategory = new SYNO.ux.ComboBox({
            xtype: "syno_combobox",
            name: "fac",
            mode: "remote",
            editable: false,
            store: this.facStoreGet(),
            tpl: this.createTpl(),
            displayField: "displayText",
            valueField: "value",
            triggerAction: "all",
            lazyRender: true,
            value: "",
            listeners: {
                scope: this,
                beforequery: function(a) {
                    delete a.combo.lastQuery
                },
                beforeselect: this.multiAttrFacSelect,
                select: this.logSelect
            }
        });
        return [{
            xtype: "syno_displayfield",
            name: "facLabel",
            value: _TT("SYNO.SDS.LogCenter.BuiltIn", "logattr", "attr_facility") + _T("common", "colon")
        }, this.LogCategory]
    },
    hideItems: function(b) {
        var c;
        if (!Ext.isArray(b)) {
            b = [b]
        }
        for (var a = b.length - 1; a >= 0; a--) {
            c = this.form.findField(b[a]);
            if (c) {
                c.setVisible(false)
            }
        }
    },
    showSearchIcon: function() {
        var b = this.get("btns"),
            a = b.get("search-loading");
        a.getEl().addClass("search-loading")
    },
    hideSearchIcon: function() {
        var b = this.get("btns"),
            a = b.get("search-loading");
        a.getEl().removeClass("search-loading")
    },
    frameAnimation: function(a, b) {
        if (a && a.isVisible()) {
            Ext.Element.prototype.frame.apply(a, b)
        }
    },
    defineBehaviors: function() {
        var a = this.get("btns");
        this.btnSearch = a.get("btn_search");
        this.btnStop = a.get("btn_stop")
    },
    setMsg: function(c) {
        var a = this.get("btns");
        var b = a.get("msg");
        b.setText(c);
        if (c.trim() !== "") {
            this.frameAnimation(b.el, this.defaultAnimation)
        }
    },
    setKeyWord: function(a) {
        var b = this.form.findField("keyword");
        if (b && Ext.isString(a)) {
            b.setValue(a)
        }
        b.focus("", 1)
    },
    onShowHideBtn: function(a) {
        if (a) {
            this.btnSearch.hide();
            this.btnStop.show()
        } else {
            this.btnSearch.show();
            this.btnStop.hide()
        }
    },
    onEnableDisableBtn: function(a) {
        if (a) {
            this.btnSearch.enable();
            this.btnStop.enable()
        } else {
            this.btnSearch.disable();
            this.btnStop.disable()
        }
    },
    isOwnerDestroyed: function() {
        return (this.owner && this.owner.isDestroyed)
    },
    showMsg: function(b, a) {
        if (!this.isOwnerDestroyed()) {
            this.owner.getMsgBox().alert(b, a)
        }
    },
    hideMsg: function() {
        if (!this.isOwnerDestroyed()) {
            this.owner.getMsgBox().hide()
        }
    },
    isFieldDirty: function(a) {
        return this.form.findField(a).isDirty()
    },
    validateForm: function() {
        if (!this.form.isValid()) {
            return false
        }
        return this.isFieldDirty("searchdatefrom") || this.isFieldDirty("searchdateto") || this.isFieldDirty("keyword")
    },
    getIp: function(b) {
        var d = /^([1-9][0-9]{0,1}|1[013-9][0-9]|12[0-689]|2[01][0-9]|22[0-3])([.]([1-9]{0,1}[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])){2}[.]([1-9][0-9]{0,1}|1[0-9]{2}|2[0-4][0-9]|25[0-4])$/,
            e = /^([1-9][0-9]{0,1}|1[013-9][0-9]|12[0-689]|2[01][0-9]|22[0-3])([.]([1-9]{0,1}[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])){1}[.]([1-9][0-9]{0,1}|1[0-9]{2}|2[0-4][0-9]|25[0-4])$/,
            c = /^([1-9][0-9]{0,1}|1[013-9][0-9]|12[0-689]|2[01][0-9]|22[0-3])([.]([1-9]{0,1}[0-9]|1[0-9]{2}|2[0-4][0-9]|25[0-5])){1}$/,
            a = /^([1-9][0-9]{0,1}|1[013-9][0-9]|12[0-689]|2[01][0-9]|22[0-3])$/;
        if (d.test(b)) {
            return b
        } else {
            if (e.test(b)) {
                return b + "/24"
            } else {
                if (c.test(b)) {
                    return b + "/16"
                } else {
                    if (a.test(b)) {
                        return b + "/8"
                    } else {
                        return ""
                    }
                }
            }
        }
    },
    onSearch: function(c, h) {
        var b, g, i, j, d, k, a;
        var f;
        b = this.getForm();
        g = b.findField("keyword").getValue();
        i = b.findField("searchdatefrom").getRawValue();
        j = b.findField("searchdateto").getRawValue();
        d = this.getComboBoxValue("logLevel");
        k = this.logType.length > 1 ? this.getComboBoxValue("logType") : this.allLogType;
        a = this.getComboBoxValue("eventType");
        if (this.allLogType === "recvlog") {
            f = {
                keyword: "*" + g + "*",
                date_from: i ? Date.parseDate(i + " 00:00:00", this.dateFormat + " H:i:s").getTime() / 1000 : 0,
                date_to: j ? Date.parseDate(j + " 23:59:59", this.dateFormat + " H:i:s").getTime() / 1000 : 0,
                level: this.getComboBoxValue("prio"),
                hostname: this.getComboBoxValue("host"),
                program: this.getComboBoxValue("prog"),
                category: this.getComboBoxValue("fac")
            }
        } else {
            f = {
                keyword: g,
                date_from: i ? Date.parseDate(i + " 00:00:00", this.dateFormat + " H:i:s").getTime() / 1000 : 0,
                date_to: j ? Date.parseDate(j + " 23:59:59", this.dateFormat + " H:i:s").getTime() / 1000 : 0,
                level: d,
                logtype: k || this.allLogType,
                eventType: (a) ? a.split(",") : [],
                ip: this.getIp(g)
            }
        }
        if (b.findField("keyword").isValid()) {
            this.fireEvent("search", this, f);
            b.findField("keyword").clearInvalid()
        }
    },
    onReset: function() {
        this.form.items.each(function(a) {
            if (a.isDirty()) {
                this.frameAnimation(a.el, this.defaultAnimation)
            }
        }, this);
        this.setMsg("");
        this.form.reset();
        this.form.findField("searchdatefrom").setMaxValue(null);
        this.form.findField("searchdateto").setMinValue(null);
        this.form.findField("logLevel").multiValue = "";
        this.form.findField("logType").multiValue = "";
        this.form.findField("eventType").multiValue = "";
        if (this.allLogType === "recvlog") {
            this.form.findField("prio").multiValue = "";
            this.form.findField("host").multiValue = "";
            this.form.findField("prog").multiValue = "";
            this.form.findField("fac").multiValue = ""
        }
        this.onSearch()
    },
    addToolTip: function() {
        SYNO.ux.AddTip(this.getForm().findField("keyword").getEl(), SYNO.SDS.LogCenter.StringGet("common", "opsearch_hint"))
    }
});
Ext.define("SYNO.SDS.LogCenter.Comp.TextItem", {
    extend: "Ext.Toolbar.TextItem",
    onRender: function(b, a) {
        this.autoEl = {
            cls: "xtb-text",
            html: this.text || "",
            "ext:qtip": this.text || ""
        };
        SYNO.SDS.LogCenter.Comp.TextItem.superclass.onRender.call(this, b, a)
    },
    setText: function(a) {
        SYNO.SDS.LogCenter.Comp.TextItem.superclass.setText.call(this, a);
        if (this.rendered) {
            this.el.set({
                "ext:qtip": a
            })
        }
    }
});
Ext.reg("lctbtext", SYNO.SDS.LogCenter.Comp.TextItem);
Ext.define("SYNO.SDS.LogCenter.LocalLog", {
    extend: "SYNO.ux.Panel",
    constructor: function(a) {
        Ext.apply(this, a);
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    storeLogSrcGet: function() {
        if (SYNO.SDS.LogCenter.Utils.isPluginsAvailable()) {
            return new SYNO.API.Store({
                proxy: new SYNO.API.Proxy({
                    appWindow: this.appWin,
                    api: "SYNO.LogCenter.Log",
                    method: "get_remotearch_subfolder",
                    version: 1
                }),
                reader: new Ext.data.JsonReader({
                    root: "host_list"
                }, ["value", "display"]),
                remoteSort: false,
                autoDestroy: true
            })
        } else {
            var a = [
                ["local", _TT("SYNO.SDS.LogCenter.BuiltIn", "logsearch", "local_logs")]
            ];
            return new Ext.data.SimpleStore({
                autoDestroy: true,
                fields: ["value", "display"],
                data: a
            })
        }
    },
    storeLogTypeGet: function() {
        var a = [
            ["general", _T("log", "general")],
            ["connection", _T("log", "log_link_connection")],
            ["fileTransfer", _T("log", "file_transfer")],
            ["disk", _T("log", "disk_related")]
        ];
        if (true === _S("ha_running")) {
            a.push(["sha", _T("log", "sha")])
        }
        return new Ext.data.SimpleStore({
            autoDestroy: true,
            fields: ["value", "display"],
            data: a
        })
    },
    initToolbar: function() {
        var a = new Ext.Toolbar({
            style: {
                border: "0px",
                padding: "0px"
            }
        });
        var b;
        this.ClearButton = new SYNO.ux.Button({
            text: _TT("SYNO.SDS.LogCenter.BuiltIn", "logview", "btn_clear"),
            handler: this.onClearLog,
            scope: this
        });
        this.ExportButton = new SYNO.ux.SplitButton({
            text: _TT("SYNO.SDS.LogCenter.BuiltIn", "logview", "btn_export"),
            handler: this.onExportHtml,
            scope: this,
            menu: {
                items: [{
                    text: _T("log", "html_type"),
                    handler: this.onExportHtml,
                    scope: this
                }, {
                    text: _T("log", "csv_type"),
                    handler: this.onExportCSV,
                    scope: this
                }]
            }
        });
        this.srcStore = this.storeLogSrcGet();
        b = {
            name: "log_src",
            width: 163,
            editable: false,
            store: this.srcStore,
            forceSelection: true,
            allowBlank: false,
            displayField: "display",
            valueField: "value",
            typeAhead: true,
            triggerAction: "all",
            lazyRender: true,
            value: "local",
            listeners: {
                scope: this,
                select: function(d, e, c) {
                    this.onClickLatest("LOCAL")
                }
            }
        };
        if (SYNO.SDS.LogCenter.Utils.isPluginsAvailable()) {
            b.model = "local";
            b.listeners.render = function(c) {
                c.store.load({
                    callback: function(e, d, f) {
                        this.ChangeSrcCombo.setRawValue(e[0].data.display)
                    },
                    scope: this
                })
            };
            b.listeners.select = function(d, e, c) {
                if ("local" === e.data.value) {
                    if ("local" != this.PreSrcComboOpt) {
                        this.ChangeTypeCombo.store.removeAt(0)
                    }
                    this.ChangeTypeCombo.setValue("general");
                    this.onClickLatest("LOCAL")
                } else {
                    if ("local" == this.PreSrcComboOpt) {
                        this.ChangeTypeCombo.store.insert(0, new Ext.data.Record({
                            value: "ExtReceiveLog",
                            display: "All"
                        }))
                    }
                    this.ChangeTypeCombo.setValue("ExtReceiveLog");
                    if ("receive" === e.data.value) {
                        this.onClickLatest("REMOTEARCH")
                    } else {
                        this.onClickLatest(e.data.value)
                    }
                }
                this.PreSrcComboOpt = e.data.value
            };
            b.listeners.beforeselect = this.onBeforeSrcSelect
        }
        this.ChangeSrcCombo = new SYNO.ux.ComboBox(b);
        if (SYNO.SDS.LogCenter.Utils.isPluginsAvailable()) {
            this.ChangeSrcCombo.show()
        } else {
            this.ChangeSrcCombo.hide()
        }
        this.ChangeTypeCombo = new SYNO.ux.ComboBox({
            name: "log_type",
            width: 190,
            editable: false,
            store: this.storeLogTypeGet(),
            forceSelection: true,
            allowBlank: false,
            displayField: "display",
            valueField: "value",
            typeAhead: true,
            triggerAction: "all",
            lazyRender: true,
            value: "general",
            listeners: {
                scope: this,
                select: this.onChangeLogType,
                beforeselect: this.onBeforeTypeSelect
            }
        });
        this.SearchField = new SYNO.SDS.LogCenter.AdvancedSearchField({
            iconStyle: "filter",
            owner: this
        });
        this.SearchField.searchPanel = this.generalLog.searchPanel;
        a.add(this.ClearButton);
        a.add(this.ExportButton);
        a.add("->");
        a.add(this.ChangeSrcCombo);
        a.add(this.ChangeTypeCombo);
        a.add(this.SearchField);
        return a
    },
    createPanelComponent: function(c) {
        var d, b;
        var a = {
            jsConfig: this.jsConfig,
            baseURL: this.jsConfig.jsBaseURL,
            topwin: this,
            appInst: this.appWin
        };
        switch (c) {
            case "general":
                d = new SYNO.SDS.LogCenter.GeneralLogBuilder(Ext.apply({}, a));
                break;
            case "connection":
                d = new SYNO.SDS.LogCenter.ConnectionLogBuilder(Ext.apply({}, a));
                break;
            case "fileTransfer":
                d = new SYNO.SDS.LogCenter.FileTransferLogBuilder(Ext.apply({}, a));
                break;
            case "disk":
                d = new SYNO.SDS.LogCenter.DiskLogBuilder(Ext.apply({}, a));
                break;
            case "sha":
                d = new SYNO.SDS.LogCenter.SHALogBuilder(Ext.apply({}, a));
                break;
            case "ExtGeneral":
                d = new SYNO.SDS.LogCenter.ExtGeneralLogBuilder(Ext.apply({}, a));
                break;
            case "ExtConnection":
                d = new SYNO.SDS.LogCenter.ExtConnectionLogBuilder(Ext.apply({}, a));
                break;
            case "ExtFileTransfer":
                d = new SYNO.SDS.LogCenter.ExtFileTransferLogBuilder(Ext.apply({}, a));
                break;
            case "ExtReceiveLog":
                d = new SYNO.SDS.LogCenter.ExtReceiveLogBuilder(Ext.apply({}, a));
                break;
            default:
                break
        }
        b = d.create(Ext.apply({}, a));
        return b
    },
    fillConfig: function(a) {
        var c = [];
        this.generalLog = this.createPanelComponent("general");
        this.PreSrcComboOpt = "local";
        c.push(this.generalLog);
        var b = {
            title: _TT("SYNO.SDS.LogCenter.BuiltIn", "logsearch", "cur_db"),
            border: false,
            trackResetOnLoad: true,
            tbar: this.initToolbar(),
            layout: "card",
            activeItem: 0,
            items: c
        };
        Ext.apply(b, a);
        return b
    },
    showChangeSrcCombo: function(a) {
        if (a) {
            this.ChangeSrcCombo.show()
        } else {
            this.ChangeSrcCombo.hide()
        }
    },
    showChangeTypeCombo: function(a) {
        if (a) {
            this.ChangeTypeCombo.show()
        } else {
            this.ChangeTypeCombo.hide()
        }
    },
    enableExportButton: function(a) {
        this.ExportButton.setDisabled(!a)
    },
    enableClearButton: function(a) {
        this.ClearButton.setDisabled(!a)
    },
    enableChangeTypeCombo: function(a) {
        this.ChangeTypeCombo.setDisabled(!a)
    },
    doSwitchPage: function() {
        var c = this.ChangeSrcCombo.getValue();
        var b = this.ChangeTypeCombo.getValue();
        var d, a;
        if ("local" === c) {
            d = "LOCAL"
        } else {
            if ("receive" === c) {
                d = "REMOTEARCH"
            } else {
                d = this.dbpath
            }
        }
        if ("local" === c) {
            switch (b) {
                case "general":
                    a = this.generalLog;
                    break;
                case "connection":
                    a = this.connectionLog;
                    break;
                case "fileTransfer":
                    a = this.fileTransferLog;
                    break;
                case "disk":
                    a = this.diskLog;
                    break;
                case "sha":
                    a = this.shaLog;
                    break;
                default:
                    a = this.generalLog;
                    break
            }
        } else {
            switch (b) {
                case "general":
                    b = "ExtGeneral";
                    a = this.ExtGeneralLog;
                    break;
                case "connection":
                    b = "ExtConnection";
                    a = this.ExtConnectionLog;
                    break;
                case "fileTransfer":
                    b = "ExtFileTransfer";
                    a = this.ExtFileTransferLog;
                    break;
                case "ExtReceiveLog":
                    b = "ExtReceiveLog";
                    a = this.ExtReceiveLog;
                    break;
                default:
                    b = "ExtReceiveLog";
                    a = this.ExtReceiveLog;
                    break
            }
            a.searchPanel.logAttriDbSet(d);
            a.dbpath = d
        }
        Ext.apply(a.grid.getStore().baseParams, {
            target: d
        });
        if (a.grid.getStore().baseParams.keyword === undefined) {
            this.SearchField.setValue("")
        } else {
            this.SearchField.setValue(a.grid.getStore().baseParams.keyword)
        }
        this.SearchField.searchPanel = a.searchPanel;
        this.getLayout().setActiveItem(b);
        a.onActive()
    },
    getLogType: function(b) {
        var a;
        switch (b) {
            case "ftpxfer":
                a = "ftp";
                break;
            case "dsmfmxfer":
                a = "filestation";
                break;
            case "webdavxfer":
                a = "webdav";
                break;
            case "smbxfer":
                a = "cifs";
                break;
            case "afpxfer":
                a = "afp";
                break;
            case "tftpxfer":
                a = "tftp";
                break;
            default:
                break
        }
        return a
    },
    forceSwitchPage: function(a, b) {
        if ("fileTransfer" === a) {
            a = "fileTransfer"
        }
        if (undefined === this.fileTransferLog) {
            this.fileTransferLog = this.createPanelComponent("fileTransfer");
            this.add(this.fileTransferLog)
        }
        this.ChangeSrcCombo.setValue("local");
        this.ChangeTypeCombo.setValue(a);
        if ("fileTransfer" === a) {
            this.fileTransferLog.grid.getStore().baseParams.logtype = this.getLogType(b)
        }
        this.doSwitchPage()
    },
    onClickLatest: function(a) {
        this.dbpath = a;
        this.doSwitchPage()
    },
    onChangeLogType: function() {
        this.doSwitchPage()
    },
    doExport: function(b) {
        var a;
        var d = this.ChangeSrcCombo.getValue();
        var c = this.ChangeTypeCombo.getValue();
        if ("local" === d) {
            switch (c) {
                case "general":
                    a = this.generalLog;
                    break;
                case "connection":
                    a = this.connectionLog;
                    break;
                case "fileTransfer":
                    a = this.fileTransferLog;
                    break;
                case "disk":
                    a = this.diskLog;
                    break;
                case "sha":
                    a = this.shaLog;
                    break;
                default:
                    a = this.generalLog;
                    break
            }
        } else {
            switch (c) {
                case "general":
                    a = this.ExtGeneralLog;
                    break;
                case "connection":
                    a = this.ExtConnectionLog;
                    break;
                case "fileTransfer":
                    a = this.ExtFileTransferLog;
                    break;
                default:
                    a = this.ExtReceiveLog;
                    break
            }
        }
        a.onLogSave(b)
    },
    onExportHtml: function() {
        this.doExport("html")
    },
    onExportCSV: function() {
        this.doExport("csv")
    },
    onClearLogDone: function(d, b, c, a) {
        if (d) {
            this.getActivePage().loadData()
        } else {
            this.appWin.getMsgBox().alert(_TT("SYNO.SDS.LogCenter.BuiltIn", "app", "app_name"), _T("common", "error_system"))
        }
        this.appWin.clearStatusBusy()
    },
    onClearLog: function() {
        var e = this.ChangeSrcCombo.getValue();
        var c, b, d, a;
        if ("local" == e) {
            c = "native";
            b = this.getActivePage().grid.getStore().baseParams.logtype;
            a = "SYNO.Core.SyslogClient.Log";
            if ("sha" == b) {
                a = "SYNO.SHA.Panel.Log"
            }
        } else {
            c = "archive";
            b = this.ChangeTypeCombo.getValue();
            d = this.dbpath;
            a = "SYNO.LogCenter.Log"
        }
        this.appWin.getMsgBox().confirmDelete(_TT("SYNO.SDS.LogCenter.BuiltIn", "app", "app_name"), _T("log", "log_cfrm_clear"), function(f) {
            if ("yes" === f) {
                this.appWin.setStatusBusy();
                this.appWin.sendWebAPI({
                    api: a,
                    version: 1,
                    method: "clear",
                    params: {
                        category: c,
                        logtype: b,
                        path: d
                    },
                    callback: this.onClearLogDone,
                    scope: this
                })
            }
        }, this)
    },
    onActivate: function() {
        this.getActivePage().grid.getStore().load()
    },
    getActivePage: function() {
        return this.getLayout().activeItem
    },
    onBeforeTypeSelect: function(d, a, b, c) {
        if ("connection" === a.data.value && undefined === this.connectionLog) {
            this.connectionLog = this.createPanelComponent("connection");
            this.add(this.connectionLog)
        } else {
            if ("fileTransfer" === a.data.value && undefined === this.fileTransferLog) {
                this.fileTransferLog = this.createPanelComponent("fileTransfer");
                this.add(this.fileTransferLog)
            } else {
                if ("disk" === a.data.value && undefined === this.diskLog) {
                    this.diskLog = this.createPanelComponent("disk");
                    this.add(this.diskLog)
                } else {
                    if ("sha" === a.data.value && undefined === this.shaLog) {
                        this.shaLog = this.createPanelComponent("sha");
                        this.add(this.shaLog)
                    }
                }
            }
        }
    },
    onBeforeSrcSelect: function(c, a, b) {
        if (undefined === this.ExtReceiveLog) {
            this.ExtReceiveLog = this.createPanelComponent("ExtReceiveLog");
            this.add(this.ExtReceiveLog);
            this.ExtGeneralLog = this.createPanelComponent("ExtGeneral");
            this.add(this.ExtGeneralLog);
            this.ExtConnectionLog = this.createPanelComponent("ExtConnection");
            this.add(this.ExtConnectionLog);
            this.ExtFileTransferLog = this.createPanelComponent("ExtFileTransfer");
            this.add(this.ExtFileTransferLog)
        }
    }
});
Ext.define("SYNO.SDS.LogCenter.LogSearch", {
    extend: "SYNO.ux.TabPanel",
    uiconfig: {},
    constructor: function(a) {
        var b;
        Ext.apply(this, a);
        b = this.fillConfig(a);
        this.callParent([b]);
        this.mon(this.pluginLoader, "load", function(c, d, e) {
            Ext.each(this.LogCenterPluginMap, function(h, f, g) {
                if (h.fn === d) {
                    h.isLoaded = true;
                    return false
                }
            }, this)
        }, this);
        this.mon(SYNO.SDS.StatusNotifier, "servicechanged", this.getPlugins, this);
        this.mon(SYNO.SDS.StatusNotifier, "appprivilegechanged", this.getPlugins, this);
        this.mon(SYNO.SDS.StatusNotifier, "jsconfigLoaded", this.getPlugins, this)
    },
    initEvents: function() {
        this.callParent();
        this.addListener("beforetabchange", this.onBeforeTabChange, this)
    },
    fillConfig: function(a) {
        var b;
        this.LogPanelLocal = new SYNO.SDS.LogCenter.LocalLog({
            itemId: "local",
            appWin: a.appWin,
            jsConfig: a.jsConfig,
            owner: this
        });
        b = {
            cls: "syno-syslog-searchpanel-padding",
            labelAlign: "left",
            border: false,
            trackResetOnLoad: true,
            items: [this.LogPanelLocal]
        };
        this.pluginLoader = SYNO.SDS.LogCenter.PluginLoader;
        this.getPlugins();
        Ext.iterate(this.LogCenterPluginMap, function(d, c) {
            b.items.push({
                title: _TT("SYNO.SDS.LogCenter.Application", "logsearch", c.title),
                itemId: c.itemId
            })
        });
        Ext.apply(b, a);
        return b
    },
    getPlugins: function() {
        var e = this,
            g, b, d, f = {},
            c, a;
        if (!SYNO.SDS.LogCenter.Utils.isPluginsAvailable()) {
            e.LogCenterPluginMap = f;
            return
        }
        for (b in SYNO.SDS.Config.FnMap) {
            if (SYNO.SDS.Config.FnMap.hasOwnProperty(b)) {
                g = SYNO.SDS.Config.FnMap[b];
                d = g.config;
                c = null;
                if (!Ext.isObject(d) || !Ext.isObject(d.logcenter_logbrowse_extern)) {
                    continue
                }
                c = d.logcenter_logbrowse_extern;
                a = {
                    itemId: c.itemId,
                    title: c.title,
                    fn: c.fn,
                    isCreated: false,
                    isLoaded: false
                };
                e.pluginLoader.loadModule(c.fn);
                f[c.itemId] = a
            }
        }
        e.LogCenterPluginMap = f
    },
    onGetUIConfigDone: function(d, b, c, a) {
        this.LogPanelLocal.onActivate()
    },
    getUIConfig: function() {
        this.appWin.setStatusBusy();
        this.appWin.clearStatusBusy()
    },
    onPageActivate: function(a) {
        this.getUIConfig();
        SYNO.SDS.LogCenter.ResizePanel(this, true);
        if (SYNO.SDS.LogCenter.Utils.isPluginsAvailable()) {
            this.startPollingTask()
        }
        this.onPageFocus(a)
    },
    onPageFocus: function(a) {
        if (a && a.logType) {
            this.LogPanelLocal.forceSwitchPage(a.logType, a.protocol)
        }
    },
    onPageDeactivate: function() {
        this.stopPollingTask()
    },
    startPollingTask: function() {
        if (typeof(this.polling_id) !== "undefined") {
            return
        }
        this.polling_id = this.appWin.pollReg({
            scope: this,
            webapi: {
                api: "SYNO.LogCenter.Log",
                version: 1,
                method: "get_remotearch_subfolder"
            },
            interval: 60,
            immediate: true,
            status_callback: function(g, e, f, c) {
                if (g) {
                    var h = false;
                    for (var a = 0; a < e.host_list.length; a++) {
                        var b = this.LogPanelLocal.srcStore.getAt(a).data;
                        if (e.host_list[a].value !== b.value) {
                            h = true
                        }
                    }
                    if (h) {
                        this.LogPanelLocal.srcStore.loadData(e);
                        var d = this.LogPanelLocal.ChangeSrcCombo;
                        d.setValue("local");
                        d.fireEvent("select", d, this.LogPanelLocal.srcStore.getAt(0), 0)
                    }
                }
                this.stopPollingTask()
            }
        })
    },
    stopPollingTask: function() {
        if (this.polling_id === undefined) {
            return
        }
        this.pollUnreg(this.polling_id);
        delete this.polling_id
    },
    onBeforeTabChange: function(d, b, e) {
        if (Ext.isObject(this.LogCenterPluginMap[b.itemId])) {
            var a = this.LogCenterPluginMap[b.itemId];
            var c = Ext.namespace(a.fn);
            if (false === a.isCreated) {
                d.remove(a.itemId);
                d.add(new c({
                    itemId: a.itemId,
                    appWin: d.appWin,
                    jsConfig: d.jsConfig,
                    owner: d
                }));
                a.isCreated = true
            }
        }
        return true
    }
});
Ext.define("SYNO.SDS.LogCenter.NotifySetting", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(a) {
        var b;
        Ext.apply(this, a);
        b = this.fillConfig(a);
        this.callParent([b])
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this, "afterlayout", function(a, c) {
            var b = this.getForm();
            b.findField("cf_eps").mon(this, "afterlayout", function(e, f) {
                var d;
                d = new SYNO.ux.Utils.EnableCheckGroup(b, "eps_enable", ["eps_number"])
            }, this, {
                single: true
            });
            b.findField("cf_sev").mon(this, "afterlayout", function(d, e) {
                var f;
                f = new SYNO.ux.Utils.EnableCheckGroup(b, "severity_enable", ["severity_threshold"])
            }, this, {
                single: true
            });
            b.findField("cf_pat").mon(this, "afterlayout", function(d, e) {
                var f;
                f = new SYNO.ux.Utils.EnableCheckGroup(b, "keyword_enable", ["keyword_1", "keyword_2", "keyword_3"])
            }, this, {
                single: true
            })
        }, this, {
            single: true
        })
    },
    storeLogLevelGet: function() {
        var a = [
            [0, "Emergency"],
            [1, "Alert, Emergency"],
            [2, "Critical, Alert, Emergency"],
            [3, "Error, Critical, Alert, Emergency"]
        ];
        return new Ext.data.SimpleStore({
            autoDestroy: true,
            fields: ["value", "display"],
            data: a
        })
    },
    fillConfig: function(a) {
        var c = 300;
        var b = {
            labelAlign: "left",
            border: false,
            trackResetOnLoad: true,
            useDefaultBtn: true,
            items: [{
                xtype: "syno_fieldset",
                title: _TT("SYNO.SDS.LogCenter.BuiltIn", "ntfsetting", "fs_notify_rule"),
                width: "570",
                height: "400",
                items: [{
                    xtype: "syno_displayfield",
                    value: _TT("SYNO.SDS.LogCenter.BuiltIn", "ntfsetting", "desc_edit_rule")
                }, {
                    name: "cf_eps",
                    xtype: "syno_compositefield",
                    hideLabel: true,
                    items: [{
                        name: "eps_enable",
                        xtype: "syno_checkbox",
                        boxLabel: _TT("SYNO.SDS.LogCenter.BuiltIn", "ntfsetting", "eps_rule"),
                        width: c
                    }, {
                        name: "eps_number",
                        xtype: "syno_numberfield",
                        width: SYNO.SDS.LogCenter.NotifyFieldWidth,
                        emptyText: _TT("SYNO.SDS.LogCenter.BuiltIn", "ntfsetting", "desc_eps_empty"),
                        allowBlank: false,
                        maxlength: 10,
                        vtype: "number",
                        value: 10,
                        validator: function(e) {
                            var d = /^\d+$/;
                            if (!d.test(e)) {
                                return false
                            }
                            if (10 > e) {
                                return false
                            }
                            return true
                        }
                    }]
                }, {
                    name: "cf_sev",
                    xtype: "syno_compositefield",
                    hideLabel: true,
                    items: [{
                        name: "severity_enable",
                        xtype: "syno_checkbox",
                        boxLabel: _TT("SYNO.SDS.LogCenter.BuiltIn", "ntfsetting", "sev_rule"),
                        width: c
                    }, {
                        name: "severity_threshold",
                        xtype: "syno_combobox",
                        width: SYNO.SDS.LogCenter.NotifyFieldWidth,
                        mode: "local",
                        emptyText: _TT("SYNO.SDS.LogCenter.BuiltIn", "ntfsetting", "desc_sev_empty"),
                        editable: false,
                        store: this.storeLogLevelGet(),
                        forceSelection: true,
                        allowBlank: false,
                        displayField: "display",
                        valueField: "value",
                        typeAhead: true,
                        triggerAction: "all",
                        lazyRender: true
                    }]
                }, {
                    name: "cf_pat",
                    xtype: "syno_compositefield",
                    hideLabel: true,
                    items: [{
                        name: "keyword_enable",
                        xtype: "syno_checkbox",
                        boxLabel: _TT("SYNO.SDS.LogCenter.BuiltIn", "ntfsetting", "keyword_rule"),
                        width: c
                    }, {
                        name: "keyword_1",
                        xtype: "syno_textfield",
                        width: SYNO.SDS.LogCenter.NotifyFieldWidth,
                        allowBlank: true,
                        maxlength: 256,
                        emptyText: _TT("SYNO.SDS.LogCenter.BuiltIn", "ntfsetting", "desc_keyword_empty"),
                        maskRe: /[^"\\]/,
                        regex: /^[^"\\]*$/
                    }]
                }, {
                    name: "keyword_2",
                    xtype: "syno_textfield",
                    style: "margin-left:120px",
                    width: SYNO.SDS.LogCenter.NotifyFieldWidth,
                    allowBlank: true,
                    maxlength: 256,
                    emptyText: _TT("SYNO.SDS.LogCenter.BuiltIn", "ntfsetting", "desc_keyword_empty"),
                    maskRe: /[^"\\]/,
                    regex: /^[^"\\]*$/
                }, {
                    name: "keyword_3",
                    xtype: "syno_textfield",
                    style: "margin-left:120px",
                    width: SYNO.SDS.LogCenter.NotifyFieldWidth,
                    allowBlank: true,
                    maxlength: 256,
                    emptyText: _TT("SYNO.SDS.LogCenter.BuiltIn", "ntfsetting", "desc_keyword_empty"),
                    maskRe: /[^"\\]/,
                    regex: /^[^"\\]*$/
                }]
            }],
            webapi: {
                api: "SYNO.Core.SyslogClient.Setting.Notify",
                methods: {
                    get: "get",
                    set: "set"
                },
                version: 1
            }
        };
        Ext.apply(b, a);
        return b
    },
    checkEPS: function() {
        var f = true;
        var a = this.getForm().findField("eps_enable").getValue();
        var b = this.getForm().findField("eps_number");
        var e = b.getValue();
        var c = /^\d+$/;
        var d = _T("common", "forminvalid");
        if (true === a) {
            if (!c.test(e)) {
                d = _TT("SYNO.SDS.LogCenter.BuiltIn", "ntfsetting", "err_invalid_eps");
                f = false
            }
            if (f && 10 > e) {
                d = String.format(_TT("SYNO.SDS.LogCenter.BuiltIn", "ntfsetting", "err_invalid_value_desc"), "10");
                f = false
            }
        }
        if (!f) {
            b.markInvalid();
            this.setStatusError({
                text: d,
                clear: true
            })
        }
        return f
    },
    checkKeyWords: function() {
        var b;
        var e = true;
        var d = true;
        var a = [this.getForm().findField("keyword_1"), this.getForm().findField("keyword_2"), this.getForm().findField("keyword_3")];
        for (b = 0; b < a.length; b++) {
            d = d & (a[b].getValue() === "");
            if (!a[b].validate()) {
                e = false
            }
            try {
                new RegExp(a[b].getValue())
            } catch (c) {
                a[b].markInvalid();
                e = false
            }
        }
        if (d) {
            for (b = 0; b < a.length; b++) {
                a[b].markInvalid()
            }
            e = false
        }
        if (!e) {
            this.setStatusError({
                text: _T("common", "forminvalid"),
                clear: true
            })
        }
        return e
    },
    onBeforeAction: function(a, d) {
        var c = true;
        if ("get" === d) {
            return true
        }
        if (this.checkFormDirty && !this.isFormDirty()) {
            var b = _T("error", "nochange_subject");
            this.setStatusError({
                text: b,
                clear: true
            });
            return false
        }
        if (!this.checkEPS()) {
            c = false
        }
        if (this.getForm().findField("keyword_enable").getValue() && !this.checkKeyWords()) {
            c = false
        }
        return c
    },
    onPageActivate: function() {
        this.loadForm();
        SYNO.SDS.LogCenter.ResizePanel(this)
    },
    onPageConfirmLostChangeSave: function() {
        return new Promise(function(b, a) {
            this.savePromise = {
                resolve: b,
                reject: a
            };
            this.applyHandler()
        }.bind(this))
    },
    onApiSuccess: function(c, b, a) {
        if (c === "set" && this.savePromise) {
            this.savePromise.resolve();
            this.savePromise = null
        }
        this.callParent(arguments)
    },
    onApiFailure: function(c, b, a) {
        if (c === "set" && this.savePromise) {
            this.savePromise.reject();
            this.savePromise = null
        }
        this.callParent(arguments)
    },
    processReturnData: function(d, c, b) {
        this.callParent(arguments);
        if (0 === c.notify_setting) {
            this.appWin.getMsgBox().confirm(_TT("SYNO.SDS.LogCenter.BuiltIn", "listpanel", "notify_setting"), _TT("SYNO.SDS.LogCenter.BuiltIn", "ntfsetting", "confirm_notify_setting"), function(e) {
                if ("yes" === e) {
                    SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                        fn: "SYNO.SDS.AdminCenter.Notification.Main"
                    })
                }
            }, this)
        }
        for (var a = 0; a < c.result.length; a++) {
            if (c.result[a].api == "SYNO.Core.SyslogClient.Setting.Notify" && c.result[a].method == "set" && c.result[a].error) {
                switch (c.result[a].error.code) {
                    default:
                        this.setStatusError({
                            text: _T("common", "forminvalid"),
                            clear: true
                        });
                        break
                }
            }
        }
    }
});
Ext.ns("SYNO.SDS.LogCenter.Util");
SYNO.SDS.LogCenter.DEV_MAX = 3;
SYNO.SDS.LogCenter.LIST_LOGSTATUS = 0;
SYNO.SDS.LogCenter.LIST_LOGSEARCH = 1;
SYNO.SDS.LogCenter.LIST_SVR = 2;
SYNO.SDS.LogCenter.LIST_ARCH = 3;
SYNO.SDS.LogCenter.LIST_NOTIFY = 4;
SYNO.SDS.LogCenter.LIST_LOG = 5;
SYNO.SDS.LogCenter.SCALE_6MIN = 0;
SYNO.SDS.LogCenter.SCALE_1HR = 1;
SYNO.SDS.LogCenter.SCALE_6HR = 2;
SYNO.SDS.LogCenter.SCALE_1DAY = 3;
SYNO.SDS.LogCenter.GetScaleDescription = function(b) {
    var a = [_TT("SYNO.SDS.LogCenter.BuiltIn", "logstatus", "interval_6_mins"), _TT("SYNO.SDS.LogCenter.BuiltIn", "logstatus", "interval_1_hour"), _TT("SYNO.SDS.LogCenter.BuiltIn", "logstatus", "interval_6_hours"), _TT("SYNO.SDS.LogCenter.BuiltIn", "logstatus", "interval_1_day")];
    return a[b]
};
SYNO.SDS.LogCenter.NotifyFieldWidth = 300;
SYNO.SDS.LogCenter.LevelMapping = {
    emerg: "Emergency",
    alert: "Alert",
    crit: _T("log", "crit_level"),
    err: _T("log", "error_level"),
    warn: _T("log", "warn_level"),
    warning: _T("log", "warn_level"),
    notice: "Notice",
    info: _T("log", "info_level"),
    debug: "Debug",
    any: "Any"
};
SYNO.SDS.LogCenter.FileProtocolEventMap = {
    create: _T("service", "transfer_log_create"),
    "create folder": _T("service", "transfer_log_create_folder"),
    upload: _T("service", "transfer_log_upload"),
    download: _T("service", "transfer_log_download"),
    "delete": _T("service", "transfer_log_delete"),
    "delete folder": _T("service", "transfer_log_delete_folder"),
    read: _T("service", "transfer_log_read"),
    write: _T("service", "transfer_log_write"),
    append: _T("service", "transfer_log_append"),
    move: _T("service", "transfer_log_move"),
    rename: _T("service", "transfer_log_rename"),
    "permission change": _T("service", "transfer_log_permission_change"),
    copy: _T("service", "transfer_log_copy"),
    lock: _T("service", "transfer_log_lock"),
    unlock: _T("service", "transfer_log_unlock"),
    "property set": _T("service", "transfer_log_property_set")
};
SYNO.SDS.LogCenter.multiAttriWinTitle = function(b) {
    var a = {
        prio: SYNO.SDS.LogCenter.StringGet("logattr", "title_select_prio"),
        prog: SYNO.SDS.LogCenter.StringGet("logattr", "title_select_prog"),
        host: SYNO.SDS.LogCenter.StringGet("logattr", "title_select_host"),
        fac: SYNO.SDS.LogCenter.StringGet("logattr", "title_select_fac")
    };
    return a[b]
};
SYNO.SDS.LogCenter.logAttriStringGet = function(a) {
    if ("Any" === a) {
        return "any"
    }
    return a
};
SYNO.SDS.LogCenter.StringGet = function(c, a) {
    var b = _TT("SYNO.SDS.LogCenter.BuiltIn", c, a);
    if (undefined === b || null === b || "" === b) {
        return _T(c, a)
    }
    return b
};
SYNO.SDS.LogCenter.RenderLevelIcon = function(d, a) {
    var b = 0;
    var c = 1;
    if (b === parseInt(d, 10)) {
        return SYNO.SDS.LogCenter.LevelRenderer("info", a)
    } else {
        if (c === parseInt(d, 10)) {
            return SYNO.SDS.LogCenter.LevelRenderer("warning", a)
        } else {
            return SYNO.SDS.LogCenter.LevelRenderer("alert", a)
        }
    }
};
SYNO.SDS.LogCenter.LevelRenderer = function(b, a) {
    switch (b) {
        case "emerg":
        case "alert":
        case "crit":
        case "err":
            return '<span class="log-err">' + SYNO.SDS.LogCenter.LevelMapping[b] + "</span>";
        case "warn":
        case "warning":
        case "notice":
            return '<span class="log-warning">' + SYNO.SDS.LogCenter.LevelMapping[b] + "</span>";
        case "info":
        case "debug":
            return '<span class="log-info">' + SYNO.SDS.LogCenter.LevelMapping[b] + "</span>";
        default:
            return "Undefined"
    }
};
SYNO.SDS.LogCenter.RenderLogContent = function(b, a) {
    if (null !== a) {
        a.attr = 'ext:qtip="' + b + '"'
    }
    return b
};
SYNO.SDS.LogCenter.TransModeRenderer = function(a) {
    if ("udp" === a) {
        return "UDP"
    } else {
        return "TCP"
    }
};
SYNO.SDS.LogCenter.LogRenderer = function(c, b) {
    var a = Ext.util.Format.htmlEncode(c);
    b.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(a) + '"';
    return a
};
SYNO.SDS.LogCenter.logRotateDayToStr = function(a) {
    var b = {
        "0": _TT("SYNO.SDS.LogCenter.BuiltIn", "svrinfo", "rotate_never"),
        "182": _TT("SYNO.SDS.LogCenter.BuiltIn", "svrinfo", "rotate_sixmonth"),
        "365": _TT("SYNO.SDS.LogCenter.BuiltIn", "svrinfo", "rotate_oneyear"),
        "730": _TT("SYNO.SDS.LogCenter.BuiltIn", "svrinfo", "rotate_twoyear"),
        "1095": _TT("SYNO.SDS.LogCenter.BuiltIn", "svrinfo", "rotate_threeyear")
    };
    return b[a]
};
SYNO.SDS.LogCenter.pageRecordStoreGet = function() {
    var a = new Ext.data.SimpleStore({
        fields: ["value", "display"],
        data: [
            [25, 25],
            [50, 50],
            [75, 75],
            [100, 100],
            [150, 150],
            [200, 200],
            [300, 300]
        ]
    });
    return a
};
SYNO.SDS.LogCenter.runTimeFormat = function(d) {
    if (0 >= d) {
        return "0 hour(s) 0 min(s) 0 sec(s)"
    }
    var e = d,
        a = 0,
        b = 0,
        c = 0;
    a = Math.floor(d / 3600);
    e -= (a * 3600);
    b = Math.floor(e / 60);
    e -= (b * 60);
    c = e;
    return (a + " hour(s) " + b + " min(s) " + c + " sec(s)")
};
SYNO.SDS.LogCenter.TimeGet = function(e) {
    var c = new Date(e);
    var a = c.getHours().toString();
    var b = c.getMinutes().toString();
    if (1 === a.length) {
        a = "0" + a
    }
    if (1 === b.length) {
        b = "0" + b
    }
    return a + ":" + b
};
SYNO.SDS.LogCenter.clone = function(b) {
    if (null === b || "object" !== typeof b) {
        return b
    }
    var c = b.constructor();
    for (var a in b) {
        if (b.hasOwnProperty(a)) {
            c[a] = b[a]
        }
    }
    return c
};
SYNO.SDS.LogCenter.Utils = {
    logTypeRenderer: function(b) {
        var a = "";
        switch (b) {
            case "syslog":
                a = _T("log", "log_link_system");
                break;
            case "connlog":
                a = _T("log", "log_link_connection");
                break;
            case "ftpxfer":
                a = _T("log", "log_ftp_xfer");
                break;
            case "dsmfmxfer":
                a = _T("log", "log_webdav_xfer");
                break;
            case "webdavxfer":
                a = _T("log", "log_link_connection");
                break;
            case "smbxfer":
                a = _T("log", "log_smb_xfer");
                break;
            case "afpxfer":
                a = _T("log", "log_afp_xfer");
                break;
            case "tftpxfer":
                a = _T("log", "log_tftp_xfer");
                break;
            case "bkplog":
                a = _T("log", "log_link_backup");
                break;
            case "copylog":
                a = _T("log", "log_link_copy");
                break;
            case "netbkplog":
                a = _T("log", "log_link_netbkp");
                break;
            case "bkpserverlog":
                a = _T("log", "log_link_backup_server");
                break;
            case "cmslog":
                a = "CMS";
                break;
            case "disklog":
                a = _T("log", "disk_related");
                break;
            default:
                a = _T("log", "log_link_system")
        }
        return a
    },
    datetimeRenderer: function(b, a) {
        var c = SYNO.SDS.DateTimeFormatter(new Date(b), {
            type: "datetimesec"
        });
        a.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(c) + '"';
        return c
    },
    htmlEncodeRender: function(c, b) {
        var a = Ext.util.Format.htmlEncode(c);
        b.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(a) + '"';
        return a
    },
    isPackageInstall: function(b) {
        var a = false;
        Ext.ComponentMgr.all.each(function(d) {
            if (d.externalDeviceJson && d.externalDeviceJson.data && d.externalDeviceJson.data.packages) {
                a = (b in d.externalDeviceJson.data.packages);
                return false
            }
        });
        return a
    },
    isPluginsAvailable: function() {
        return (SYNO.SDS.Packages.isStart("SYNO.SDS.LogCenter.Application") && SYNO.SDS.Config.FnMap.hasOwnProperty("SYNO.SDS.LogCenter.ExtReceiveLog"))
    }
};
Ext.define("SYNO.SDS.LogCenter.TodayTipDateFieldPlugin", {
    extend: "Ext.Component",
    todayTip: "{0}",
    init: function(a) {
        if (a.menu === null) {
            a.menu = new Ext.menu.DateMenu({
                hideOnClick: false,
                focusOnSelect: false
            });
            a.menu.picker.todayTip = this.todayTip
        }
    }
});
Ext.preg("todaytipdatefieldplugin", SYNO.SDS.LogCenter.TodayTipDateFieldPlugin);
Ext.define("SYNO.SDS.LogCenter.MenuTextColumnModelPlugin", {
    extend: "Ext.Component",
    init: function(a) {
        var c = a.getView(),
            b = a.getColumnModel();
        b.getColumnMenuText = this.getColumnMenuText;
        c.beforeColMenuShow = this.beforeColMenuShow
    },
    getColumnMenuText: function(a) {
        return this.config[a].menuText || this.config[a].header
    },
    beforeColMenuShow: function() {
        var e = this,
            b = e.cm,
            d = b.getColumnCount(),
            a = e.colMenu,
            c;
        a.removeAll();
        for (c = 0; c < d; c++) {
            if (b.config[c].hideable !== false) {
                a.add(new Ext.menu.CheckItem({
                    text: b.getColumnMenuText ? b.getColumnMenuText(c) : b.getColumnHeader(c),
                    itemId: "col-" + b.getColumnId(c),
                    checked: !b.isHidden(c),
                    disabled: b.config[c].hideable === false,
                    hideOnClick: false
                }))
            }
        }
    }
});
Ext.preg("menutextcolumnmodelplugin", SYNO.SDS.LogCenter.MenuTextColumnModelPlugin);
SYNO.SDS.LogCenter.KeywordValidator = function(a) {
    var b = true;
    if (a.match(/^ *(AND|OR|NOT|\( *\)) *$/) !== null || a.match(/(AND|OR|NOT) *$|^ *(AND|OR)/) !== null || a.match(/(AND|OR|NOT) *(AND|OR)/) !== null || a.match(/\([^)]*\(|\)[^(]*\)/) !== null || a.match(/\([^)]*$|^[^(]*\)/) !== null || a.match(/\( *(AND|OR|NOT) *\)/) !== null || a.match(/\(.*(AND|OR|NOT) *\)|\( *(AND|OR).*\)/) !== null || a.match(/\(.*(AND|OR|NOT) *(AND|OR).*\)/) !== null) {
        b = SYNO.SDS.LogCenter.StringGet("common", "error_opsearch")
    }
    return b
};
SYNO.SDS.LogCenter.ResizePanel = function(b, e) {
    var d = 240;
    var a = 41;
    var c = d;
    var f = a;
    if (e) {
        b.container.setStyle("padding", "0px")
    } else {
        b.container.setStyle("padding", "16px 16px 0px 16px");
        c += 32;
        f += 16
    }
    b.container.setSize(b.appWin.getWidth() - d, b.appWin.getHeight() - a);
    b.setSize(b.appWin.getWidth() - c, b.appWin.getHeight() - f);
    b.doLayout()
};

/**
 * @class SYNO.SDS.LogCenter.BuiltIn
 * @extends SYNO.SDS.AppInstance
 * LogCenter application instance class
 *
 */
Ext.define("SYNO.SDS.LogCenter.BuiltIn", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.LogCenter.MainWindow"
});
Ext.define("SYNO.SDS.LogCenter.PluginTipDlg", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(a) {
        var b = {
            width: 480,
            minHeight: 120,
            autoHeight: true,
            resizable: false,
            draggable: false,
            header: false,
            cls: "x-window-dlg",
            padding: "24px 30px 0",
            elements: "body",
            items: [{
                xtype: "syno_displayfield",
                cls: "ext-mb-title",
                value: _TT("SYNO.SDS.LogCenter.BuiltIn", "app", "advanced_tip_title")
            }, {
                xtype: "syno_displayfield",
                hideLabel: true,
                value: _TT("SYNO.SDS.LogCenter.BuiltIn", "app", "plugin_desc")
            }, {
                itemId: "noAutoLaunch",
                xtype: "syno_checkbox",
                checked: SYNO.SDS.UserSettings.getProperty("SYNO.SDS.LogCenter.BuiltIn", "nolaunch") || false,
                boxLabel: _TT("SYNO.SDS.LogCenter.BuiltIn", "app", "no_tip_again")
            }],
            fbar: {
                items: [{
                    xtype: "syno_button",
                    text: _T("common", "ok"),
                    btnStyle: "blue",
                    handler: this.saveSettings,
                    scope: this
                }]
            }
        };
        Ext.apply(b, a);
        return b
    },
    getNoLaunchField: function() {
        return this.getComponent("noAutoLaunch")
    },
    saveSettings: function() {
        var a = this.getNoLaunchField().getValue();
        SYNO.SDS.UserSettings.setProperty("SYNO.SDS.LogCenter.BuiltIn", "nolaunch", a);
        this.close()
    }
});
Ext.define("SYNO.SDS.LogCenter.PluginLoader", {
    extend: "Ext.util.Observable",
    singleton: true,
    constructor: function() {
        var a = this;
        a.callParent(arguments);
        a.addEvents("load")
    },
    loadModule: function(a) {
        try {
            var c = SYNO.SDS.Config.FnMap[a];
            if (!c) {
                return false
            }
            SYNO.SDS.JSLoad(a, function() {
                this.fireEvent("load", this, a, c)
            }, this)
        } catch (b) {
            SYNO.Debug("Fail to add module" + b);
            return false
        }
        return true
    }
});
Ext.define("SYNO.SDS.LogCenter.MainWindow", {
    extend: "SYNO.SDS.PageListAppWindow",
    activePage: "SYNO.SDS.LogCenter.LogView",
    constructor: function(a) {
        this.pageCt = new Ext.Panel({
            padding: "0px",
            layout: "card",
            border: false,
            frame: false,
            hideMode: "offsets",
            region: "center"
        });
        var b = Ext.apply({
            width: 1005,
            height: 580,
            minWidth: 800,
            minHeight: 580,
            cls: "syno-syslog",
            listItems: [{
                text: _T("helptoc", "logcenter_overview"),
                fn: "SYNO.SDS.LogCenter.LogView",
                iconCls: "icon-overview",
                help: "LogCenter/logcenter_overview.html"
            }, {
                text: _T("helptoc", "logcenter_browse"),
                fn: "SYNO.SDS.LogCenter.LogSearch",
                iconCls: "icon-search",
                help: "LogCenter/logcenter_search.html"
            }, {
                text: _T("helptoc", "logcenter_notification"),
                fn: "SYNO.SDS.LogCenter.NotifySetting",
                iconCls: "icon-log-notifications",
                disabled: "recovery_site" === _S("systemdr_role"),
                help: "LogCenter/logcenter_notification.html"
            }]
        }, a);
        Ext.override(Ext.grid.GridView, {
            handleHdDown: function(i, g) {
                if (Ext.fly(g).hasClass("x-grid3-hd-btn")) {
                    i.stopEvent();
                    var h = this.findHeaderCell(g);
                    Ext.fly(h).addClass("x-grid3-hd-menu-open");
                    var f = this.getCellIndex(h);
                    this.hdCtxIndex = f;
                    var d = this.hmenu.items,
                        c = this.cm;
                    var j = c.isSortable(f);
                    d.get("asc").setVisible(j);
                    d.get("desc").setVisible(j);
                    d.get("columns").previousSibling().setVisible(j);
                    this.hmenu.on("hide", function() {
                        Ext.fly(h).removeClass("x-grid3-hd-menu-open")
                    }, this, {
                        single: true
                    });
                    this.hmenu.show(g, "tl-bl?")
                }
            }
        });
        this.pluginLoader = SYNO.SDS.LogCenter.PluginLoader;
        this.getPlugins();
        Ext.iterate(this.LogCenterPluginMap, function(d, c) {
            b.listItems.push({
                text: c.text,
                fn: c.fn,
                iconCls: c.iconCls,
                help: c.help
            })
        });
        this.callParent([b]);
        this.mon(this.pluginLoader, "load", function(c, d, e) {
            Ext.each(this.LogCenterPluginMap, function(h, f, g) {
                if (h.fn === d) {
                    h.isLoaded = true;
                    return false
                }
            }, this)
        }, this);
        this.mon(this, "show", this.triggerTipDlg, this, {
            single: true
        });
        this.mon(SYNO.SDS.StatusNotifier, "thirdpartychanged", this.onPkgChanged, this);
        this.mon(SYNO.SDS.StatusNotifier, "servicechanged", this.getPlugins, this);
        this.mon(SYNO.SDS.StatusNotifier, "appprivilegechanged", this.getPlugins, this);
        this.mon(SYNO.SDS.StatusNotifier, "jsconfigLoaded", this.getPlugins, this)
    },
    onPkgChanged: function(b, a) {
        if ('"LogCenter"' != b) {
            return
        }
        this.close()
    },
    getPlugins: function() {
        var d = this,
            g, b, c, e = {},
            f, a;
        if (!SYNO.SDS.LogCenter.Utils.isPluginsAvailable()) {
            d.LogCenterPluginMap = e;
            return
        }
        for (b in SYNO.SDS.Config.FnMap) {
            if (SYNO.SDS.Config.FnMap.hasOwnProperty(b)) {
                g = SYNO.SDS.Config.FnMap[b];
                c = g.config;
                f = null;
                if (!Ext.isObject(c) || !Ext.isObject(c.logcenter_mainwindow_extern)) {
                    continue
                }
                f = c.logcenter_mainwindow_extern;
                a = {
                    name: f.name,
                    text: f.text,
                    fn: f.fn,
                    iconCls: f.iconCls,
                    help: f.help,
                    isLoaded: false,
                    data: f
                };
                d.pluginLoader.loadModule(f.fn);
                e[f.name] = a
            }
        }
        d.LogCenterPluginMap = e
    },
    errMsgShow: function(a) {
        var b = "";
        if (a) {
            b = _TT("SYNO.SDS.LogCenter.BuiltIn", a.sec, a.key);
            if (undefined === b || "" === b) {
                b = _T(a.sec, a.key)
            }
            if (Ext.isNumber(a.line)) {
                b = String.format("{0} ({1})", b, a.line)
            }
        } else {
            b = SYNO.SDS.LogCenter.StringGet("common", "error_system")
        }
        this.getMsgBox().alert(_TT("SYNO.SDS.LogCenter.BuiltIn", "app", "app_name"), b)
    },
    triggerTipDlg: function() {
        this.selectPage(this.getOpenConfig("fn"));
        if (!SYNO.SDS.LogCenter.Application && true !== SYNO.SDS.UserSettings.getProperty("SYNO.SDS.LogCenter.BuiltIn", "nolaunch")) {
            new SYNO.SDS.LogCenter.PluginTipDlg({
                owner: this
            }).show()
        }
    },
    onOpen: function(a) {
        a.fn = (a.logType) ? "SYNO.SDS.LogCenter.LogSearch" : "SYNO.SDS.LogCenter.LogView";
        this.callParent([a]);
        if (a.logType) {
            this.getActivePage().LogPanelLocal.forceSwitchPage(a.logType, a.protocol)
        }
    },
    onRequest: function(a) {
        a.fn = (a.logType) ? "SYNO.SDS.LogCenter.LogSearch" : "SYNO.SDS.LogCenter.LogView";
        this.callParent([a])
    },
    getHelpParam: function() {
        switch (this.getActivePage().itemId) {
            case "SYNO.SDS.LogCenter.LogView":
                return "SYNO.SDS.LogCenter.BuiltIn:LogCenter/logcenter_overview.html";
            case "SYNO.SDS.LogCenter.LogSearch":
                return "SYNO.SDS.LogCenter.BuiltIn:LogCenter/logcenter_search.html";
            case "SYNO.SDS.LogCenter.NotifySetting":
                return "SYNO.SDS.LogCenter.BuiltIn:LogCenter/logcenter_notification.html";
            case "SYNO.SDS.LogCenter.ArchiveSetting":
                return "SYNO.SDS.LogCenter.Application:logcenter_archive.html";
            case "SYNO.SDS.LogCenter.ClientSetting":
                return "SYNO.SDS.LogCenter.Application:logcenter_client.html";
            case "SYNO.SDS.LogCenter.ServerSetting":
                return "SYNO.SDS.LogCenter.Application:logcenter_server.html";
            case "SYNO.SDS.LogCenter.ServiceLogPanel":
                return "SYNO.SDS.LogCenter.Application:logcenter_history.html";
            default:
                return "SYNO.SDS.LogCenter.BuiltIn"
        }
    },
    onClickHelp: function() {
        var a = this.getHelpParam();
        if (_S("standalone")) {
            SYNO.SDS.WindowLaunch("SYNO.SDS.HelpBrowser.Application", {
                topic: a
            })
        } else {
            SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                topic: a
            }, false)
        }
    }
});
