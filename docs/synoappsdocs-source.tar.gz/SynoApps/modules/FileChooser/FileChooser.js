/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.namespace("SYNO.SDS.Utils.FileChooser.Utils");
/**
 * @class SYNO.SDS.Utils.FileChooser.Utils
 * FileChooser utils class
 *
 */
Ext.apply(SYNO.SDS.Utils.FileChooser.Utils, {
    ThumbSize: {
        SMALL: "S",
        MEDIUM: "M",
        LARGE: "L"
    },
    hotKey: "hotKey",
    source: {
        local: "local",
        localh: "localh",
        remote: "remote",
        remotes: "remotes",
        remotev: "remotev",
        remoter: "remoter",
        remotefav: "remotefav"
    },
    isRemoteSource: function(a) {
        var b = SYNO.SDS.Utils.FileChooser.Utils.source;
        return (a && a.substr(0, 6) === b.remote && a !== b.remotes)
    },
    isLocalSource: function(a) {
        var b = SYNO.SDS.Utils.FileChooser.Utils.source;
        return (a && a.substr(0, 5) === b.local)
    },
    isFavSource: function(a) {
        var b = SYNO.SDS.Utils.FileChooser.Utils.source;
        return (a.substr(0, 9) === b.remotefav)
    },
    getWebAPIErrStr: function(a, c, b) {
        if (!c) {
            return _T("error", "error_error_system")
        }
        switch (c.code) {
            case 400:
                return _T("error", "error_error_system");
            case 401:
                return _T("error", "error_error_system");
            case 402:
                return _T("error", "error_error_system");
            case 403:
                return _T("error", "error_invalid_user_group");
            case 404:
                return _T("error", "error_invalid_user_group");
            case 405:
                return _T("error", "error_invalid_user_group");
            case 406:
                return _T("error", "error_testjoin");
            case 407:
                return _T("error", "error_privilege_not_enough");
            case 408:
                return _T("error", "error_no_path");
            case 409:
                return _T("error", "error_privilege_not_enough");
            case 410:
                return _T("error", "conn_rv_fail");
            case 411:
                return _T("error", "error_fs_ro");
            case 412:
                return _T("error", "error_long_path");
            case 413:
                return _T("error", "error_encryption_long_path");
            case 414:
                return _T("error", "error_file_exist");
            case 415:
                return _T("error", "error_quota_not_enough");
            case 416:
                return _T("error", "error_space_not_enough");
            case 417:
                return _T("error", "error_io");
            case 418:
                return _T("error", "error_reserved_name");
            case 419:
                return _T("error", "error_fat_reserved_name");
            case 420:
                return _T("error", "error_error_system");
            case 421:
                return _T("error", "error_folder_busy");
            case 599:
                return "";
            case 600:
                return _T("search", "no_search_cache");
            case 800:
                return String.format(_T("favorite", "same_favorite_path"), Ext.util.Format.htmlEncode(c.errors[0].path), Ext.util.Format.htmlEncode(c.errors[0].name));
            case 801:
                return String.format(_T("favorite", "same_favorite_name"), Ext.util.Format.htmlEncode(c.errors[0].name));
            case 802:
                return _T("favorite", "over_limit");
            case 900:
                return _T("error", "delete_error_rmdir");
            case 1004:
                return _T("error", "error_overwrite_fail");
            case 1005:
                return _T("error", "error_select_conflict");
            case 1006:
                return _T("error", "mvcp_filename_illegal");
            case 1007:
                return _T("error", "mvcp_file_too_big");
            case 1100:
                return _T("error", "error_error_system");
            case 1101:
                return _T("error", "error_too_many_folder");
            case 1200:
                return _T("error", "error_error_system");
            case 1300:
                return _T("error", "error_error_system");
            case 1301:
                return _T("compress", "compress_error_long_name");
            case 1400:
                return _T("error", "error_error_system");
            case 1401:
                return _T("error", "error_invalid_archive");
            case 1402:
                return _T("error", "error_invalid_archive_data");
            case 1403:
                return _T("error", "extract_passwd_missing");
            case 1404:
                return _T("error", "error_error_system");
            case 1405:
                return _T("error", "error_error_system");
            case 1800:
                return _T("upload", "upload_error_data");
            case 1801:
                return _T("upload", "upload_error_timeout");
            case 1802:
                return _T("upload", "upload_nofile");
            case 1803:
                return _T("connections", "kick_connection");
            case 1804:
                return _T("error", "mvcp_file_too_big");
            case 1805:
                return _T("error", "error_select_conflict");
            case 2001:
                return _T("error", "over_account_limit");
            case 2002:
                return _T("error", "unknown_db_error");
            default:
                return _T("error", "error_error_system")
        }
    },
    getWebAPIErr: function(h, d, b) {
        var j, f, a, e, g, c;
        if (!h) {
            if (!d) {
                return _T("error", "error_error_system")
            } else {
                if (d && d.code < 400) {
                    return SYNO.API.CheckResponse(h, d, b)
                } else {
                    j = d.errors;
                    if (d.code !== 800 && d.code !== 801 && j && Ext.isArray(j) && j && 0 < j.length) {
                        c = (j.length > 15) ? 15 : j.length;
                        g = _T("error", "error_files");
                        for (f = 0; f < c; f++) {
                            e = j[f];
                            g += "<br>" + Ext.util.Format.htmlEncode(Ext.util.Format.ellipsis(e.path, 36));
                            a = SYNO.SDS.Utils.FileChooser.Utils.getWebAPIErr(h, e, b);
                            if (a) {
                                g += "&nbsp;(" + a + ")"
                            }
                        }
                        if (c < j.length) {
                            g += "<br>..."
                        }
                    }
                    if (!g) {
                        g = SYNO.SDS.Utils.FileChooser.Utils.getWebAPIErrStr(h, d, b)
                    }
                    return g
                }
            }
        }
    },
    isCompressFile: function(a, d) {
        d = d.toLowerCase();
        if (-1 !== SYNO.SDS.Utils.FileChooser.Utils.archive_type.indexOf(d)) {
            return true
        }
        var b = a.split("."),
            c;
        if (2 < b.length) {
            c = b[b.length - 1].toLowerCase();
            if (-1 !== SYNO.SDS.Utils.FileChooser.Utils.archive_type.indexOf(c) && (d === "001" || d === "000")) {
                return true
            }
        }
        return false
    },
    getPathSeparator: function(b) {
        var a = b ? SYNO.SDS.Utils.FileChooser.Utils.isLocalSource(b) : false;
        return (a && Ext.isWindows) ? "\\" : "/"
    },
    checkFileLen: function(b, c) {
        var a = unescape(encodeURIComponent(b)).length;
        if (c) {
            a += c
        }
        return (a <= 255)
    },
    getLangText: function(a) {
        return _T(a.section, a.key)
    },
    isNameReserved: function(b) {
        var a = b.toLowerCase();
        return ("@eaDir" == a)
    },
    isNameCharIllegal: function(a) {
        if (-1 != a.indexOf(":") || -1 != a.indexOf("/")) {
            return true
        } else {
            return false
        }
    },
    ParseArrToFileName: function(d, c, e) {
        var a = e ? e : "/";
        var g = [];
        var f, b;
        for (b = 0; b < d.length; b++) {
            g.push(SYNO.SDS.Utils.FileChooser.Utils.parseFullPathToFileName(d[b], a))
        }
        f = g.join(", ");
        return f
    },
    ParseArr: function(c, b) {
        var d = [],
            a;
        for (a = 0; a < c.length; a++) {
            d.push(c[a].get(b))
        }
        return d
    },
    ParsePairArr: function(d, c, b) {
        var e = [],
            a;
        for (a = 0; a < d.length; a++) {
            e.push({
                file: d[a].get(c),
                path: b[a]
            })
        }
        return e
    },
    ParseArrToJSON: function(c, b) {
        var d = [],
            a;
        for (a = 0; a < c.length; a++) {
            d.push(c[a].get(b))
        }
        return Ext.util.JSON.encode(d)
    },
    GetSeesionID: function() {
        var b = "id",
            c, a;
        if (document.cookie.length > 0) {
            c = document.cookie.indexOf(b + "=");
            if (c != -1) {
                c = c + b.length + 1;
                a = document.cookie.indexOf(";", c);
                if (a == -1) {
                    a = document.cookie.length
                }
                return unescape(document.cookie.substring(c, a))
            }
        }
        return ""
    },
    isConflictTargetPath: function(e, b, d) {
        var a = d ? d : "/";
        var c = "";
        var g = "";
        if (b.length < e.length) {
            var f = e.lastIndexOf(a);
            if (d === "\\" && e[f - 1] === ":") {
                f++
            }
            g = e.substring(f);
            return (b + g == e)
        } else {
            if (b.length == e.length) {
                return (b == e)
            } else {
                c = b.substring(0, e.length);
                g = b.substring(e.length);
                return ((c == e) && (a == g.charAt(0)))
            }
        }
    },
    isSubNotEqualPath: function(e, b, d) {
        var a = d ? d : "/";
        var c = "";
        var f = "";
        if (b.length <= e.length) {
            return false
        } else {
            c = b.substring(0, e.length);
            f = b.substring(e.length);
            return ((c == e) && (a == f.charAt(0)))
        }
    },
    getParentDirArr: function(g, e) {
        var b = e ? e : "/";
        var a = [];
        var h = -1;
        var f = "";
        if (!(g instanceof Array)) {
            h = g.lastIndexOf(b);
            f = g.substring(0, h);
            if ("\\" === b && -1 === f.indexOf(b)) {
                f += "\\"
            }
            a.push(f);
            return a
        }
        var d = g[0].data || g[0];
        a = this.getParentDirArr(d.file_id, b);
        for (var c = 0; c < g.length; c++) {
            d = g[c].data || g[c];
            if (!(d.isdir)) {
                continue
            }
            f = d.file_id;
            h = f.lastIndexOf(b);
            f = f.substring(0, h);
            if ("\\" === b && -1 === f.indexOf(b)) {
                f += "\\"
            }
            if (!this.strElementInArray(f, a)) {
                a.push(f)
            }
        }
        return a
    },
    strElementInArray: function(c, a) {
        for (var b = 0; b < a.length; b++) {
            if (c == a[b]) {
                return true
            }
        }
        return false
    },
    replaceDLNameSpecChars: function(a) {
        var b = /[\/\\\:\?\>\<\*\"\;\|\#\%]/g;
        return a.replace(b, "-")
    },
    checkIfNeedRedirect: function(c, a, b) {
        if ((b && "login" == c) || ("error" == c && "error_testjoin" == a)) {
            if ("true" == this._S("customized")) {
                SYNO.SDS.Utils.Logout.action()
            } else {
                window.location = "/index.cgi"
            }
            alert(_T(c, a));
            return true
        }
        return false
    },
    parseFullPathToFileName: function(d, c) {
        var b = c ? c : "/";
        var a = "";
        var e = d.lastIndexOf(b);
        if (-1 == e) {
            e = d.lastIndexOf(b === "\\" ? "/" : "\\")
        }
        a = d.substring(e + 1);
        return a
    },
    isParentDir: function(d, c) {
        if (!d || !c) {
            return false
        }
        var b = d.lastIndexOf("/");
        if (-1 == b || 0 === b) {
            return false
        }
        var a = d.substring(0, b);
        return (a == c)
    },
    isWinParentDir: function(d, c) {
        if (!d || !c) {
            return false
        }
        var b = d.lastIndexOf("\\");
        if (b < 2) {
            return false
        }
        var a;
        if (d.length != 3) {
            a = d.substring(0, b + 1)
        } else {
            a = d
        }
        return (a == c)
    },
    utfencode: function(b) {
        b = b.replace(/\r\n/g, "\n");
        var a = "";
        for (var e = 0; e < b.length; e++) {
            var d = b.charCodeAt(e);
            if (d < 128) {
                a += String.fromCharCode(d)
            } else {
                if ((d > 127) && (d < 2048)) {
                    a += String.fromCharCode((d >> 6) | 192);
                    a += String.fromCharCode((d & 63) | 128)
                } else {
                    a += String.fromCharCode((d >> 12) | 224);
                    a += String.fromCharCode(((d >> 6) & 63) | 128);
                    a += String.fromCharCode((d & 63) | 128)
                }
            }
        }
        return a
    },
    bin2hex: function(d) {
        d = SYNO.SDS.Utils.FileChooser.Utils.utfencode(d);
        var c, e = 0,
            b = [];
        d += "";
        e = d.length;
        for (c = 0; c < e; c++) {
            b[c] = d.charCodeAt(c).toString(16).replace(/^([\da-f])$/, "0$1")
        }
        return b.join("")
    },
    checkPointInBox: function(c, b, a) {
        if (b < c.x || a < c.y) {
            return false
        }
        return ((c.right > b) && (c.bottom > a))
    },
    getBaseName: function(e, d) {
        var c = d ? d : "/";
        if (!Ext.isDefined(e)) {
            return ""
        }
        var b = "";
        var a = e.lastIndexOf(c);
        if (a != -1) {
            b = e.substr(a + 1)
        }
        return b
    },
    getExt: function(b) {
        var c = SYNO.SDS.Utils.FileChooser.Utils.getBaseName(b);
        b = !c ? b : c;
        var a = b.lastIndexOf(".");
        if (-1 === a) {
            return ""
        }
        return b.substr(a + 1).toLowerCase()
    },
    getFullSize: function(a) {
        var b = 0;
        b = parseFloat(a);
        if (!Ext.isString(a)) {
            return b
        }
        if (a.indexOf("KB") > 0) {
            b *= 1024
        } else {
            if (a.indexOf("MB") > 0) {
                b *= 1048576
            } else {
                if (a.indexOf("GB") > 0) {
                    b *= 1073741824
                }
            }
        }
        return b
    },
    doesIncludeMountPoint: function(a) {
        if (a) {
            Ext.each(a, function(b) {
                if (b.data && "" !== b.data.mountType) {
                    return true
                }
            })
        }
        return false
    },
    isShareByPath: function(a) {
        if (-1 === (a.indexOf("/", 1))) {
            return true
        }
        return false
    },
    getRemoteTreeParams: function(b, a) {
        delete b.baseParams.folder_path;
        delete b.baseParams.type;
        if (a.id === "fm_fav_root") {
            b.api = "SYNO.FileStation.Favorite";
            b.method = "list";
            b.version = 1;
            b.dataroot = ["data", "favorites"]
        } else {
            if (a.id === "fm_root") {
                b.api = "SYNO.FileStation.List";
                b.method = "list_share";
                b.version = 1;
                b.dataroot = ["data", "shares"]
            } else {
                if (a.id === "fm_rf_root") {
                    b.api = "SYNO.FileStation.VirtualFolder";
                    b.method = "list";
                    b.version = 1;
                    b.dataroot = ["data", "folders"];
                    b.baseParams.type = "cifs"
                } else {
                    if (a.id === "fm_vd_root") {
                        b.api = "SYNO.FileStation.VirtualFolder";
                        b.method = "list";
                        b.version = 1;
                        b.dataroot = ["data", "folders"];
                        b.baseParams.type = "iso"
                    } else {
                        b.api = "SYNO.FileStation.List";
                        b.method = "list";
                        b.version = 1;
                        b.dataroot = ["data", "files"];
                        b.baseParams.folder_path = SYNO.API.EscapeStr(a.id.substr(a.id.indexOf("/")))
                    }
                }
            }
        }
    },
    CapabilityGetByKey: function(b, a) {
        if (SYNO.SDS.Config.FnMap.hasOwnProperty(a)) {
            var d = SYNO.SDS.Config.FnMap[a];
            if (d.config.hasOwnProperty(b)) {
                return d.config[b]
            }
        }
        var c = _D(b, "").split(",").indexOf(a);
        return (-1 !== c)
    },
    UpdateConfigByCapability: function(b, a) {
        b.enumC2Share = this.CapabilityGetByKey("support_c2_share", a);
        b.enumColdStorage = this.CapabilityGetByKey("support_cold_storage_share", a)
    },
    ParseTreeNode: function(a, d) {
        var b;
        var c = 0;
        if ("fm_root" === d.id) {
            b = Ext.apply(a, {
                leaf: false,
                draggable: false,
                qtip: a.text
            });
            switch (d.id) {
                case "fm_fav_root":
                    b.type = SYNO.SDS.Utils.FileChooser.Utils.source.remotefav;
                    break;
                default:
                    b.type = SYNO.SDS.Utils.FileChooser.Utils.source.remote;
                    break
            }
        } else {
            c += a.additional.perm.acl.exec ? SYNO.SDS.Utils.FileChooser.Utils.Mode_Exec : 0;
            c += a.additional.perm.acl.write ? SYNO.SDS.Utils.FileChooser.Utils.Mode_Write : 0;
            c += a.additional.perm.acl.read ? SYNO.SDS.Utils.FileChooser.Utils.Mode_Read : 0;
            c += a.additional.perm.acl.append ? SYNO.SDS.Utils.FileChooser.Utils.Mode_Append : 0;
            c += a.additional.perm.acl.del ? SYNO.SDS.Utils.FileChooser.Utils.Mode_Del : 0;
            b = {
                id: d.attributes.type + a.path,
                leaf: false,
                draggable: false,
                gid: a.additional.owner.gid,
                uid: a.additional.owner.uid,
                spath: a.path,
                path: a.additional.real_path,
                right: a.additional.perm.posix,
                aclRight: c,
                qtip: a.name,
                text: a.name,
                mountType: a.additional.mount_point_type,
                is_snapshot: a.is_snapshot,
                is_recycle_bin: a.additional.is_recycle_bin,
                type: d.attributes.type,
                children: a.children
            }
        }
        return b
    },
    isRecycleBinFolder: function(b) {
        if (!b) {
            return false
        }
        var a = b.split("/", 7);
        return (a.length === 3 && a[2] === "#recycle") || (a.length === 4 && a[1] === "homes" && a[3] === "#recycle") || (a.length === 6 && a[1] === "homes" && a[5] === "#recycle")
    },
    getThumbName: function(d) {
        var b = "misc.png";
        if (d.isdir) {
            var c = d.mountType;
            if (!Ext.isEmpty(c)) {
                switch (c) {
                    case "remote":
                        return "remotemountpoint.png";
                    case "remotefail":
                        return "remotefailmountpoint.png";
                    case "iso":
                        return "isomountpoint.png"
                }
            }
            if (SYNO.SDS.Utils.FileChooser.Utils.isRecycleBinFolder(d.path)) {
                return "recycle_bin.png"
            }
            return "folder.png"
        }
        var a = d.type;
        if (!a) {
            return b
        }
        a = a.toLowerCase();
        if (-1 !== SYNO.SDS.Utils.FileChooser.Utils.icon_type.indexOf(a)) {
            return a + ".png"
        }
        return b
    },
    onMailTo: function(c) {
        var b = "My DS Shared File Links";
        var d = c;
        var a = "mailto:?subject=" + b + "&body=" + d;
        window.open(a, "_blank")
    },
    GuessMode: function(c) {
        var a = c.split(".");
        var b = a.length > 1 ? a.pop().toLowerCase() : null;
        if (!Ext.isEmpty(b)) {
            if (SYNO.SDS.Utils.FileChooser.Utils.TextFileExtensions.hasOwnProperty(b)) {
                return SYNO.SDS.Utils.FileChooser.Utils.TextFileExtensions[b]
            } else {
                return "plain_text"
            }
        }
        return "plain_text"
    },
    isVFSPath: function(a) {
        if (!a) {
            return false
        }
        if ("/" !== a.charAt(0)) {
            return true
        }
        return false
    }
});
SYNO.SDS.Utils.FileChooser.Utils.FTP_PRIV_DISABLE_LIST = 1;
SYNO.SDS.Utils.FileChooser.Utils.FTP_PRIV_DISABLE_MODIFY = 2;
SYNO.SDS.Utils.FileChooser.Utils.FTP_PRIV_DISABLE_DOWNLOAD = 4;
SYNO.SDS.Utils.FileChooser.Utils.NA = 1;
SYNO.SDS.Utils.FileChooser.Utils.RW = 2;
SYNO.SDS.Utils.FileChooser.Utils.RO = 4;
SYNO.SDS.Utils.FileChooser.Utils.Mode_Exec = 1;
SYNO.SDS.Utils.FileChooser.Utils.Mode_Write = 2;
SYNO.SDS.Utils.FileChooser.Utils.Mode_Read = 4;
SYNO.SDS.Utils.FileChooser.Utils.Mode_Append = 8;
SYNO.SDS.Utils.FileChooser.Utils.Mode_Del = 512;
SYNO.SDS.Utils.FileChooser.Utils.Mode_All = 8191;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege = {};
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.SrcFolder = {};
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.DestFolder = {};
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.SrcFile = {};
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.DestFolder.Create = SYNO.SDS.Utils.FileChooser.Utils.Mode_Exec | SYNO.SDS.Utils.FileChooser.Utils.Mode_Append;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.SrcFile.Copy = SYNO.SDS.Utils.FileChooser.Utils.Mode_Read;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.DestFolder.Copy = SYNO.SDS.Utils.FileChooser.Utils.Mode_Write | SYNO.SDS.Utils.FileChooser.Utils.Mode_Exec;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.DestFolder.CopyDir = SYNO.SDS.Utils.FileChooser.Utils.Mode_Read | SYNO.SDS.Utils.FileChooser.Utils.Mode_Exec;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.SrcFile.Move = SYNO.SDS.Utils.FileChooser.Utils.Mode_Del;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.DestFolder.Move = SYNO.SDS.Utils.FileChooser.Utils.Mode_Write | SYNO.SDS.Utils.FileChooser.Utils.Mode_Exec;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.DestFolder.MoveDir = SYNO.SDS.Utils.FileChooser.Utils.Mode_Read | SYNO.SDS.Utils.FileChooser.Utils.Mode_Exec;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.SrcFile.Delete = SYNO.SDS.Utils.FileChooser.Utils.Mode_Del;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.DestFolder.Upload = SYNO.SDS.Utils.FileChooser.Utils.Mode_Write | SYNO.SDS.Utils.FileChooser.Utils.Mode_Exec;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.DestFolder.UploadDir = SYNO.SDS.Utils.FileChooser.Utils.Mode_Exec | SYNO.SDS.Utils.FileChooser.Utils.Mode_Append;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.SrcFile.Download = SYNO.SDS.Utils.FileChooser.Utils.Mode_Read;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.SrcFolder.Download = SYNO.SDS.Utils.FileChooser.Utils.Mode_Read | SYNO.SDS.Utils.FileChooser.Utils.Mode_Exec;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.DestFolder.Navigate = SYNO.SDS.Utils.FileChooser.Utils.Mode_Exec;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.SrcFile.Extract = SYNO.SDS.Utils.FileChooser.Utils.Mode_Read;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.DestFolder.Extract = SYNO.SDS.Utils.FileChooser.Utils.Mode_Read | SYNO.SDS.Utils.FileChooser.Utils.Mode_Write | SYNO.SDS.Utils.FileChooser.Utils.Mode_Exec;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.DestFolder.ExtractDir = SYNO.SDS.Utils.FileChooser.Utils.Mode_Read | SYNO.SDS.Utils.FileChooser.Utils.Mode_Write | SYNO.SDS.Utils.FileChooser.Utils.Mode_Exec;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.SrcFile.Compress = SYNO.SDS.Utils.FileChooser.Utils.Mode_Read;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.SrcFolder.Compress = SYNO.SDS.Utils.FileChooser.Utils.Mode_Read | SYNO.SDS.Utils.FileChooser.Utils.Mode_Exec;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.DestFolder.Compress = SYNO.SDS.Utils.FileChooser.Utils.Mode_Read | SYNO.SDS.Utils.FileChooser.Utils.Mode_Write | SYNO.SDS.Utils.FileChooser.Utils.Mode_Exec;
SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.DestFolder.Mount = SYNO.SDS.Utils.FileChooser.Utils.Mode_Read | SYNO.SDS.Utils.FileChooser.Utils.Mode_Write | SYNO.SDS.Utils.FileChooser.Utils.Mode_Exec;
SYNO.SDS.Utils.FileChooser.Utils.checkShareRight = function(a, b) {
    var c;
    if (a == "NA") {
        c = SYNO.SDS.Utils.FileChooser.Utils.NA
    } else {
        if (a == "RW") {
            c = SYNO.SDS.Utils.FileChooser.Utils.RW
        } else {
            if (a == "RO") {
                c = SYNO.SDS.Utils.FileChooser.Utils.RO
            }
        }
    }
    if (b & c) {
        return true
    }
    return false
};
SYNO.SDS.Utils.FileChooser.Utils.checkFileRight = function(b) {
    if (this._S("is_admin") === true || this._S("domainUser") == "true") {
        return true
    }
    var c = b.right;
    var a = c & ~(SYNO.SDS.Utils.FileChooser.Utils.Mode_All & ~b.needRight);
    if (a == b.needRight) {
        return true
    }
    return false
};
SYNO.SDS.Utils.FileChooser.Utils.parseMode = function(c) {
    var e = 0;
    var b = 0,
        d = 0,
        a = 0;
    e = parseInt(c, 10);
    if (e >= 100) {
        b = Math.floor(e / 100);
        e -= b * 100
    }
    if (e >= 10) {
        d = Math.floor(e / 10);
        e -= d * 10
    }
    a = e;
    return {
        owner: b,
        group: d,
        others: a
    }
};
SYNO.SDS.Utils.FileChooser.Utils.getShareNodeByPath = function(b, c) {
    var a;
    if ((a = c.indexOf("/", 1)) != -1) {
        return b.getNodeById(SYNO.SDS.Utils.FileChooser.Utils.source.remote + c.substring(0, a))
    } else {
        return b.getNodeById(SYNO.SDS.Utils.FileChooser.Utils.source.remote + c)
    }
    return null
};
SYNO.SDS.Utils.FileChooser.Utils.getShareRight = function(b, d) {
    var a;
    if (d.parentNode.id === "fm_root") {
        return d.attributes.right
    }
    var e = d.attributes.spath,
        f;
    if ((a = e.indexOf("/", 1)) != -1) {
        var c = e.substring(0, a);
        f = b.getNodeById(SYNO.SDS.Utils.FileChooser.Utils.source.remote + c)
    } else {
        f = b.getNodeById(SYNO.SDS.Utils.FileChooser.Utils.source.remote + e)
    }
    if (f) {
        return f.attributes.right
    }
    return null
};
SYNO.SDS.Utils.FileChooser.Utils.getShareRightBySPath = function(b, d) {
    var e, a;
    if ((a = d.indexOf("/", 1)) != -1) {
        var c = d.substring(0, a);
        e = b.getNodeById(SYNO.SDS.Utils.FileChooser.Utils.source.remote + c)
    } else {
        e = b.getNodeById(SYNO.SDS.Utils.FileChooser.Utils.source.remote + d)
    }
    if (e) {
        return e.attributes.right
    }
    return null
};
SYNO.SDS.Utils.FileChooser.Utils.getShareFtpRight = function(a, b) {
    var c = b.attributes.path;
    return SYNO.SDS.Utils.FileChooser.Utils.getShareFtpRightByPath(a, c)
};
SYNO.SDS.Utils.FileChooser.Utils.getShareFtpRightByPath = function(b, d) {
    var e, a;
    if ((a = d.indexOf("/", 1)) != -1) {
        var c = d.substring(0, a);
        e = b.getNodeById(SYNO.SDS.Utils.FileChooser.Utils.source.remote + c)
    } else {
        e = b.getNodeById(SYNO.SDS.Utils.FileChooser.Utils.source.remote + d)
    }
    if (e) {
        return e.attributes.ftpright
    }
    return null
};
SYNO.SDS.Utils.FileChooser.Utils.getZipName = function(b) {
    var a = b.lastIndexOf(".");
    b = b.substr(0, a);
    a = b.lastIndexOf(".");
    if (b.substr(a + 1).toLowerCase() == "tar") {
        b = b.substr(0, a)
    }
    return b
};
SYNO.SDS.Utils.FileChooser.Utils.getImageName = function(b) {
    var a = b.lastIndexOf(".");
    if (-1 === a) {
        return ""
    }
    b = b.substr(0, a);
    return b
};
Ext.apply(SYNO.SDS.Utils.FileChooser.Utils, {
    icon_type: ["acc", "ai", "avi", "bmp", "doc", "exe", "fla", "folder", "gif", "htm", "indd", "iso", "jpg", "js", "misc", "mp3", "pdf", "png", "ppt", "psd", "rar", "swf", "tar", "ttf", "txt", "wma", "xls", "ico", "tif", "tiff", "ufo", "raw", "arw", "srf", "sr2", "dcr", "k25", "kdc", "cr2", "crw", "nef", "mrw", "ptx", "pef", "raf", "3fr", "erf", "mef", "mos", "orf", "rw2", "dng", "x3f", "jpe", "jpeg", "html", "3gp", "3g2", "asf", "dat", "divx", "dvr-ms", "m2t", "m2ts", "m4v", "mkv", "mp4", "mts", "mov", "qt", "tp", "trp", "ts", "vob", "wmv", "xvid", "ac3", "amr", "rm", "rmvb", "ifo", "mpeg", "mpg", "mpe", "m1v", "m2v", "mpeg1", "mpeg2", "mpeg4", "ogv", "webm", "aac", "flac", "m4a", "ogg", "pcm", "wav", "cda", "mid", "mp2", "mka", "mpc", "ape", "ra", "ac3", "dts", "bin", "img", "mds", "nrg", "daa", "docx", "wri", "rtf", "xla", "xlb", "xlc", "xld", "xlk", "xll", "xlm", "xlt", "xlv", "xlw", "xlsx", "xlsm", "xlsb", "xltm", "xlam", "pptx", "pps", "ppsx", "ade", "adp", "adn", "accdr", "accdb", "accdt", "mdb", "mda", "mdn", "mdt", "mdw", "mdf", "mde", "accde", "mam", "maq", "mar", "mat", "maf", "flv", "f4v", "7z", "bz2", "gz", "zip", "tgz", "tbz", "ttc", "otf", "css", "actproj", "ad", "akp", "applescript", "as", "asax", "asc", "ascx", "asm", "asmx", "asp", "aspx", "asr", "c", "cc", "php", "jsx", "xml", "xhtml", "mhtml", "cpp", "cs", "cxx"],
    archive_type: ["zip", "gz", "tar", "tgz", "tbz", "bz2", "rar", "7z", "iso"],
    image_type: ["iso"],
    DocumentFileTypes: "docx,wri,rtf,xla,xlb,xlc,xld,xlk,xll,xlm,xlt,xlv,xlw,xlsx,xlsm,xlsb,xltm,xlam,pptx,pps,ppsx,pdf,txt,doc,xls,ppt",
    ImageFileTypes: "ico,tif,tiff,ufo,raw,arw,srf,sr2,dcr,k25,kdc,cr2,crw,nef,mrw,ptx,pef,raf,3fr,erf,mef,mos,orf,rw2,dng,x3f,jpg,jpg,jpeg,png,gif,bmp",
    VideoFileTypes: "3gp,3g2,asf,dat,divx,dvr-ms,m2t,m2ts,m4v,mkv,mp4,mts,mov,qt,tp,trp,ts,vob,wmv,xvid,ac3,amr,rm,rmvb,ifo,mpeg,mpg,mpe,m1v,m2v,mpeg1,mpeg2,mpeg4,ogv,webm,flv,avi,swf,f4v",
    AudioFileTypes: "aac,flac,m4a,ogg,pcm,wav,cda,mid,mp2,mka,mpc,ape,ra,ac3,dts,wma,mp3",
    WebPageFileTypes: "html,htm,css,actproj,ad,akp,applescript,as,asax,asc,ascx,asm,asmx,asp,aspx,asr,c,cc,php,jsx,xml,xhtml,mhtml,cpp,cs,cxx,js",
    DiscFileTypes: "bin,img,mds,nrg,daa,iso",
    ZippedFileTypes: "7zi,bz2,gz,zip,tgz,tbz,rar,tar"
});
Ext.ns("SYNO.SDS.Utils.FileChooser");
SYNO.SDS.Utils.FileChooser.CrtFdrDialog = function(b) {
    this.checkName = true;
    Ext.apply(this, b || {});
    var a = this.init();
    var c = {
        owner: this.owner,
        width: 450,
        autoHeight: true,
        cls: this.cls,
        shadow: true,
        minWidth: 500,
        minHeight: 150,
        collapsible: false,
        autoScroll: false,
        constrainHeader: true,
        title: _T("filetable", "filetable_create_folder_title"),
        layout: "fit",
        items: [a],
        buttons: [{
            text: _T("common", "common_cancel"),
            scope: this,
            handler: this.closeHandler
        }, {
            btnStyle: "blue",
            text: _T("common", "common_submit"),
            scope: this,
            handler: this.saveFolderName
        }],
        keys: [{
            key: [10, 13],
            fn: this.saveFolderName,
            scope: this
        }, {
            key: 27,
            fn: this.closeHandler,
            scope: this
        }],
        listeners: {
            afterlayout: {
                fn: function() {
                    this.focusEl = this.crtFdrForm.get("name");
                    this.center()
                },
                scope: this,
                single: true
            }
        }
    };
    this.addEvents({
        callback: true
    });
    SYNO.SDS.Utils.FileChooser.CrtFdrDialog.superclass.constructor.call(this, c)
};
Ext.extend(SYNO.SDS.Utils.FileChooser.CrtFdrDialog, SYNO.SDS.ModalWindow, {
    init: function() {
        var a = {
            labelWidth: 75,
            autoHeight: true,
            labelAlign: "top",
            trackResetOnLoad: true,
            cls: "file_chooser_crt_fdr",
            waitMsgTarget: true,
            border: false,
            items: [{
                xtype: "syno_textfield",
                itemId: "name",
                itemCls: "textfield-form-item",
                fieldLabel: _T("filetable", "filetable_fill_name"),
                name: "name",
                width: 410,
                maxlength: 255
            }],
            listeners: {
                actionfailed: {
                    fn: this.closeHandler,
                    scope: this
                }
            }
        };
        var b = new Ext.form.FormPanel(a);
        this.crtFdrForm = b;
        return b
    },
    callbackHandler: function() {
        this.fireEvent("callback")
    },
    closeHandler: function() {
        this.hide();
        this.callbackHandler()
    },
    saveFolderName: function() {
        var a = "";
        if (!this.crtFdrForm || !this.crtFdrForm.form.findField("name")) {
            this.closeHandler();
            return
        }
        a = this.crtFdrForm.form.findField("name").getValue();
        a = Ext.util.Format.trim(a);
        if (!a) {
            this.getMsgBox().alert(_T("filetable", "filetable_create_folder_title"), _T("error", "error_empty_name"));
            return
        }
        if (this.checkName) {
            if (!SYNO.SDS.Utils.FileChooser.Utils.checkFileLen(a)) {
                this.getMsgBox().alert(_T("filetable", "filetable_create_folder_title"), _T("error", "error_long_path"));
                return
            }
            if (SYNO.SDS.Utils.FileChooser.Utils.isNameReserved(a)) {
                this.getMsgBox().alert(_T("filetable", "filetable_create_folder_title"), _T("error", "error_reserved_name"));
                return
            }
            if (SYNO.SDS.Utils.FileChooser.Utils.isNameCharIllegal(a)) {
                this.getMsgBox().alert(_T("filetable", "filetable_create_folder_title"), _T("error", "error_reserved_name"));
                return
            }
        }
        this.fdrName = a;
        this.callbackHandler()
    },
    resetDialogForm: function() {
        if (this.crtFdrForm) {
            this.crtFdrForm.form.reset()
        }
    },
    getFolderName: function() {
        return this.fdrName
    },
    resetFolderName: function() {
        this.fdrName = null
    },
    setParentDir: function(a) {
        this.parentDir = a
    },
    setCheckName: function(a) {
        if (SYNO.SDS.Utils.FileChooser.Utils.isLocalSource(a)) {
            this.checkName = false
        } else {
            this.checkName = true
        }
    },
    getParentDir: function() {
        return this.parentDir
    },
    load: function() {
        this.resetDialogForm();
        this.resetFolderName();
        this.show()
    }
});
Ext.namespace("SYNO.SDS.Utils.FileChooser");
Ext.define("SYNO.SDS.Utils.FileChooser.Chooser", {
    extend: "SYNO.SDS.ModalWindow",
    rootId: "fm_root",
    supportMultiSelect: true,
    pageSize: (!Ext.isIE || Ext.isModernIE) ? 1000 : 250,
    constructor: function(c) {
        this.owner = c.owner;
        var a = Ext.apply({
            width: 700,
            height: 500,
            title: "File Chooser",
            border: false,
            useStatusBar: false,
            cls: "file_chooser_mainpanel",
            closeOwnerWhenNoShare: false,
            closeOwnerNumber: 1,
            gotoComplete: false,
            gotoPath: "",
            appName: "",
            enumGluster: false,
            enumCluster: false,
            enumC2Share: false,
            enumSnapshot: false,
            enumColdStorage: false,
            enumRecycle: true,
            needrw: true,
            hideFavorites: false,
            layout: {
                type: "vbox",
                align: "stretch",
                pack: "start"
            },
            items: [{
                layout: "border",
                cls: "file_chooser_panel",
                border: false,
                flex: 1,
                items: []
            }],
            superuser: false,
            usage: {
                type: "open",
                multiple: false
            }
        }, c);
        this.cfg = a;
        if (a.usage.type === "chooseDir" || a.usage.type === "chooseFile") {
            a.windowSize = "small";
            a.bodyStyle = "padding: 8px 20px 12px 20px";
            a.width = 480
        } else {
            a.windowSize = "large";
            a.bodyStyle = "padding: 0px 0px 0px 0px"
        }
        var b = {};
        switch (a.usage.type) {
            case "open":
            case "save":
                if (a.folderToolbar) {
                    b.bodyStyle = "padding: 0px 12px 0px 12px"
                } else {
                    b.bodyStyle = "padding: 8px 12px 0px 12px"
                }
                b.bwrapStyle = "padding: 0;";
                a.items[0].items.push(this.initTreeConfig(a, b, a.folderToolbar));
                a.items[0].items.push(this.initGridConfig(a));
                a.items.push(this.initBottomPanelConfig(a));
                a.items[0].cls += " save";
                break;
            case "chooseDir":
                b.bodyStyle = "padding: 0px 0px 0px 0px";
                a.items[0].items.push(this.initTreeConfig(a, b, false));
                a = Ext.apply(a, this.initFbar());
                a.items[0].cls += " dir";
                if (a.folderToolbar) {
                    this.initFolderToolbar(a)
                }
                break;
            case "chooseFile":
                a.items[0].items.push(this.initGridConfig(a));
                a = Ext.apply(a, this.initFbar());
                a.items[0].cls += " file";
                if (a.folderToolbar) {
                    a = this.initFolderToolbar(a)
                }
                break
        }
        if (SYNO.SDS.Utils.FileChooser.Utils.isVFSPath(a.gotoPath)) {
            a.gotoPath = ""
        }
        this.callParent([Ext.apply(a, c)]);
        this.findBy(function(d) {
            if (d.getItemId() === "tree") {
                this.tree = d
            } else {
                if (d.getItemId() === "grid") {
                    this.grid = d
                } else {
                    if (d.getItemId() === "bottomFieldset") {
                        this.bottomFieldset = d
                    }
                }
            }
        }, this);
        this.addEvents("choose", "cancel")
    },
    isSmallWindow: function() {
        return this.cfg.usage.type === "chooseDir" || this.cfg.usage.type === "chooseFile"
    },
    initFolderToolbar: function(a) {
        a.tbar = {
            xtype: "syno_toolbar",
            border: false,
            style: {
                padding: this.isSmallWindow() ? "0 20px" : "16px 12px 8px 12px"
            },
            items: [{
                xtype: "syno_button",
                tooltip: _T("common", "refresh"),
                iconCls: this.isSmallWindow() ? null : "file_chooser_refresh_btn",
                text: this.isSmallWindow() ? _T("common", "refresh") : undefined,
                width: this.isSmallWindow() ? undefined : 95,
                handler: function() {
                    if (this.usage.type === "chooseDir") {
                        var g = this.tree.getRootNode().childNodes || [];
                        var b = Ext.emptyFn,
                            c = function() {
                                this.onTreeRootExpand(this.tree.getRootNode())
                            };
                        for (var d = 0; d < g.length; d++) {
                            var e = g[d];
                            if ("fm_root" === e.id) {
                                b = c
                            }
                            e.reload(b, this)
                        }
                    } else {
                        var h = this.tree.selModel;
                        var f = h.getSelectedNode();
                        this.onTreeSelectionChange(h, f)
                    }
                },
                scope: this
            }, {
                xtype: "syno_button",
                tooltip: _T("filetable", "filetable_create_folder_title"),
                iconCls: this.isSmallWindow() ? null : "file_chooser_create_btn",
                text: this.isSmallWindow() ? _T("filetable", "filetable_create_folder_title") : null,
                width: this.isSmallWindow() ? undefined : 95,
                handler: this.createFolder,
                scope: this
            }]
        };
        return a
    },
    initTreeLoader: function(b) {
        if ("" !== this.appName) {
            SYNO.SDS.Utils.FileChooser.Utils.UpdateConfigByCapability(b, this.appName)
        }
        var a = new SYNO.API.TreeLoader({
            api: "SYNO.Core.File",
            method: "list",
            version: 1,
            requestMethod: "POST",
            appWindow: b.owner,
            clearOnLoad: false,
            createNode: function(c, d) {
                c = SYNO.SDS.Utils.FileChooser.Utils.ParseTreeNode(c, d);
                if (!c.spath) {
                    c.spath = c.path
                }
                if ((!b.enumGluster && c.is_gluster) || (!b.enumCluster && c.is_cluster) || (!b.enumSnapshot && c.is_snapshot) || (!b.enumRecycle && c.is_recycle_bin) || (!b.enumColdStorage && c.is_cold_storage) || (!b.enumC2Share && c.is_c2share) || (Ext.isFunction(b.treeFilter) && false === b.treeFilter(this, c))) {
                    c.cls = (c.cls || "") + (" node_display_none");
                    c.hideNode = true
                }
                if (Ext.isDefined(c.children) && Ext.isArray(c.children.files) && c.children.files.length > 0) {
                    c.expanded = true
                }
                return SYNO.API.TreeLoader.prototype.createNode.call(this, c)
            },
            processResponse: function(g, f, m, p) {
                var q = g.responseText;
                try {
                    var c = g.responseData || Ext.decode(q);
                    if ("fm_root" === f.id) {
                        c = c.data
                    } else {
                        if ("fm_fav_root" === f.id) {
                            c = c.data.favorites
                        } else {
                            c = c.data.files
                        }
                    }
                    f.beginUpdate();
                    for (var h = 0, j = c.length; h < j; h++) {
                        var d = this.createNode(c[h], f);
                        if (d && !(d.attributes && d.attributes.hideNode === true)) {
                            var l = f.appendChild(d);
                            this.doNodeload(l)
                        }
                    }
                    f.endUpdate();
                    this.runCallback(m, p || f, [f])
                } catch (k) {
                    this.handleFailure(g)
                }
            },
            doNodeload: function(e) {
                if (!e.attributes.children) {
                    return
                }
                var d = e.attributes.children.files;
                e.beginUpdate();
                for (var c = 0; c < d.length; c++) {
                    var f = e.appendChild(this.createNode(d[c], e));
                    this.doNodeload(f)
                }
                e.endUpdate()
            },
            listeners: {
                scope: this,
                beforeload: function(d, c) {
                    if ("fm_root" === c.id) {
                        d.api = "SYNO.Core.File";
                        d.baseParams = {
                            superuser: this.superuser,
                            needrw: !!this.needrw,
                            folder_path: "/",
                            status_filter: "valid",
                            support_enum_cold_storage: b.enumColdStorage
                        }
                    } else {
                        if ("fm_fav_root" === c.id) {
                            d.api = "SYNO.FileStation.Favorite";
                            d.baseParams = {
                                status_filter: "valid",
                                needrw: !!this.needrw,
                                enum_cluster: !!this.enumCluster,
                                additional: "real_path,size,owner,time,perm,type,mount_point_type,is_recycle_bin"
                            }
                        } else {
                            d.api = "SYNO.Core.File";
                            d.baseParams = {
                                superuser: this.superuser,
                                filetype: "dir",
                                folder_path: c.id.substr(c.id.indexOf("/")),
                                additional: ["real_path", "size", "owner", "time", "perm", "type", "mount_point_type", "is_recycle_bin"],
                                status_filter: "valid",
                                goto_path: !this.gotoComplete ? this.gotoPath : "",
                                support_enum_cold_storage: b.enumColdStorage
                            }
                        }
                    }
                },
                load: function(m, g) {
                    var j;
                    var n;
                    var h = {};
                    if (g.id === "fm_fav_root") {
                        n = g.ui;
                        var c, o = g.parentNode;
                        for (j = 0; j < o.childNodes.length; j++) {
                            if ("fm_root" === o.childNodes[j].id) {
                                c = o.childNodes[j]
                            }
                        }
                        Ext.each(c.childNodes, function(i) {
                            if (i && i.attributes) {
                                h[i.attributes.path] = true
                            }
                        });
                        var d = [];
                        Ext.each(g.childNodes, function(i) {
                            d.push(i)
                        });
                        for (j = 0; j < d.length; j++) {
                            var e = d[j];
                            if (e && e.attributes && true !== h[e.attributes.path]) {
                                g.removeChild(e)
                            }
                        }
                        if (n) {
                            if (!g.childNodes || 0 >= g.childNodes.length) {
                                n.hide()
                            } else {
                                n.show()
                            }
                        }
                        return
                    } else {
                        if (g.id !== "fm_root") {
                            return
                        }
                    }
                    var f;
                    for (j = 0; j < g.childNodes.length; j++) {
                        f = g.childNodes[j];
                        if (!f.attributes.hideNode) {
                            this.tree.getNodeById(f.id).select();
                            break
                        }
                    }
                    if (!this.gotoComplete && !Ext.isEmpty(this.gotoPath)) {
                        if (this.gotoPath.indexOf("/", 1) !== -1) {
                            var l = SYNO.SDS.Utils.FileChooser.Utils.getShareNodeByPath(this.tree, this.gotoPath);
                            if (!l) {
                                this.gotoComplete = true;
                                if (Ext.isDefined(f)) {
                                    f.select()
                                }
                                return
                            }
                            this.getEl().mask(_T("common", "loading"), "x-mask-loading");
                            l.reload(function() {
                                this.getEl().unmask();
                                this.gotoComplete = true;
                                var i = this.tree.getNodeById(SYNO.SDS.Utils.FileChooser.Utils.source.remote + this.gotoPath);
                                if (Ext.isDefined(i)) {
                                    i.select()
                                } else {
                                    if (Ext.isDefined(f)) {
                                        f.select()
                                    }
                                }
                            }, this)
                        } else {
                            this.gotoComplete = true;
                            var k = this.tree.getNodeById(SYNO.SDS.Utils.FileChooser.Utils.source.remote + this.gotoPath);
                            if (Ext.isDefined(k)) {
                                k.select()
                            } else {
                                if (Ext.isDefined(f)) {
                                    f.select()
                                }
                            }
                        }
                    }
                }
            }
        });
        return a
    },
    initFbar: function() {
        return {
            useStatusBar: true,
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "cancel"),
                minWidth: 80,
                autoHeight: true,
                scope: this,
                handler: this.cancelHandler
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                text: _T("common", "choose"),
                minWidth: 80,
                autoHeight: true,
                scope: this,
                handler: this.applyHandler
            }]
        }
    },
    initBottomPanelConfig: function(c) {
        var a = 38,
            b = 34,
            f = 12;
        var e = {
            cls: c.usage.type === "chooseDir" ? "folder_chooser_bottompanel" : "file_chooser_bottompanel",
            border: false,
            bwrapStyle: "padding: 0;",
            layout: {
                type: "hbox",
                align: "stretch",
                pack: "start"
            },
            items: [{
                xtype: "syno_fieldset",
                cls: "fieldset",
                itemId: "bottomFieldset",
                flex: 1,
                items: []
            }, {
                width: 300,
                border: false,
                layout: {
                    type: "vbox",
                    align: "stretch",
                    pack: "end"
                },
                items: [{
                    xtype: "container",
                    cls: "button-group",
                    items: [{
                        xtype: "syno_button",
                        text: _T("common", "cancel"),
                        autoHeight: true,
                        scope: this,
                        handler: this.cancelHandler
                    }, {
                        xtype: "syno_button",
                        btnStyle: "blue",
                        cls: "bottom-panel-apply-btn",
                        text: (c.usage.type === "save" ? _T("common", "save") : _T("common", "choose")),
                        autoHeight: true,
                        scope: this,
                        handler: this.applyHandler
                    }]
                }]
            }]
        };
        if (c.usage.type == "save") {
            e.items[0].items.push({
                xtype: "syno_textfield",
                fieldLabel: _T("common", "file_name"),
                width: 250,
                value: c.usage.oldFilename,
                listeners: {
                    afterrender: function(g) {
                        var h = g.value.lastIndexOf(".");
                        (function(i, j) {
                            if (-1 == j) {
                                i.selectText()
                            } else {
                                i.selectText(0, j)
                            }
                        }).defer(500, this, [g, h])
                    }
                }
            });
            f += b
        }
        if (Ext.isArray(c.comboOption)) {
            for (var d = 0; d < c.comboOption.length; d++) {
                e.items[0].items.push({
                    xtype: "syno_combobox",
                    fieldLabel: c.comboOption[d].label,
                    value: c.comboOption[d].value,
                    store: new Ext.data.ArrayStore({
                        fields: ["value", "name"],
                        data: c.comboOption[d].data
                    }),
                    valueField: "value",
                    displayField: "name",
                    width: 250,
                    listeners: {
                        scope: this,
                        select: this.onComboOptionChange
                    }
                })
            }
            f += b * c.comboOption.length
        }
        e.height = Math.max(a, f - 6) + 9;
        return e
    },
    initTreeConfig: function(c, b, e) {
        var a = this.initTreeLoader(c);
        var d = {
            id: "fm_top_root",
            allowDrag: false,
            allowDrop: false,
            children: []
        };
        d.children.push({
            type: SYNO.SDS.Utils.FileChooser.Utils.source.remote,
            loader: a,
            cls: "root_node",
            text: this._S("hostname"),
            draggable: false,
            allowDrop: false,
            expanded: true,
            id: this.rootId,
            listeners: {
                expand: {
                    fn: this.onTreeRootExpand,
                    scope: this,
                    single: true
                }
            }
        });
        if (SYNO.SDS.StatusNotifier.isAppHasPrivilege("SYNO.SDS.App.FileStation3.Instance") && !c.hideFavorites) {
            d.children.unshift({
                type: SYNO.SDS.Utils.FileChooser.Utils.source.remotefav,
                loader: this.initTreeLoader(c),
                cls: "root_node",
                text: _T("favorite", "my_favorite"),
                draggable: false,
                allowDrop: false,
                expanded: true,
                id: "fm_fav_root",
                hidden: true,
                listeners: {
                    expand: {
                        fn: this.onTreeRootExpand,
                        scope: this,
                        single: true
                    }
                }
            })
        }
        var f = {
            itemId: "tree",
            rootVisible: false,
            useGradient: false,
            cls: "file_chooser_treepanel",
            region: (c.usage.type === "chooseDir" ? "center" : "west"),
            width: 220,
            xtype: "syno_treepanel",
            border: false,
            collapsable: true,
            split: true,
            useArrows: true,
            root: (new Ext.tree.AsyncTreeNode(d)),
            selModel: new Ext.tree.DefaultSelectionModel({
                listeners: {
                    selectionchange: {
                        fn: this.onTreeSelectionChange,
                        scope: this,
                        buffer: 100
                    },
                    beforeselect: {
                        fn: this.onTreeBeforeSelect,
                        scope: this
                    }
                }
            })
        };
        Ext.apply(f, b);
        if (e) {
            f = this.initFolderToolbar(f)
        }
        return f
    },
    initGridConfig: function(f, e) {
        e = e || {};
        var c;
        if (f.usage.type === "chooseFile") {
            c = {
                filetype: "file",
                folder_path: f.usage.folder_path
            }
        } else {
            c = {}
        }
        var a = function(g, h) {
            if (!Ext.isDefined(f) || !Ext.isDefined(f.columnCfg) || !Ext.isDefined(f.columnCfg[g]) || !Ext.isDefined(f.columnCfg[g][h])) {
                return false
            }
            return f.columnCfg[g][h]
        };
        this.gridStore = new Ext.data.Store({
            autoLoad: (f.usage.type === "chooseFile" ? true : false),
            proxy: new SYNO.API.Proxy({
                api: "SYNO.Core.File",
                method: "list",
                version: 1,
                appWindow: f.owner,
                listeners: {
                    scope: this,
                    beforeload: function(g, h) {
                        var i = g.activeRequest.read;
                        if (i) {
                            Ext.Ajax.abort(i)
                        }
                    }
                }
            }),
            reader: new Ext.data.JsonReader({
                root: "files",
                id: "path"
            }, [{
                name: "file_id",
                mapping: "path"
            }, {
                name: "path",
                mapping: (f && f.owner && SYNO.SDS.LDAP && (f.owner instanceof SYNO.SDS.LDAP.AppWindow)) ? "additional.real_path" : "path"
            }, {
                name: "filename",
                mapping: "name"
            }, {
                name: "filesize",
                mapping: "additional.size"
            }, {
                name: "mt",
                mapping: "additional.time.mtime"
            }, {
                name: "ct",
                mapping: "additional.time.crtime"
            }, {
                name: "at",
                mapping: "additional.time.atime"
            }, {
                name: "privilege",
                mapping: "additional.perm.posix"
            }, {
                name: "fileprivilege",
                convert: function(i, g) {
                    var h = g.additional.perm.acl,
                        j;
                    if (h.append) {
                        j |= SYNO.SDS.Utils.FileChooser.Utils.Mode_Append
                    }
                    if (h.del) {
                        j |= SYNO.SDS.Utils.FileChooser.Utils.Mode_Del
                    }
                    if (h.exec) {
                        j |= SYNO.SDS.Utils.FileChooser.Utils.Mode_Exec
                    }
                    if (h.read) {
                        j |= SYNO.SDS.Utils.FileChooser.Utils.Mode_Read
                    }
                    if (h.write) {
                        j |= SYNO.SDS.Utils.FileChooser.Utils.Mode_Write
                    }
                    return j
                }
            }, {
                name: "isacl",
                mapping: "additional.perm.is_acl_mode"
            }, {
                name: "icon"
            }, {
                name: "type",
                mapping: "additional.type"
            }, {
                name: "real_path",
                mapping: "additional.real_path"
            }, {
                name: "isdir"
            }, {
                name: "owner",
                mapping: "additional.owner.user"
            }, {
                name: "group",
                mapping: "additional.owner.group"
            }, {
                name: "uid",
                mapping: "additional.owner.uid"
            }, {
                name: "gid",
                mapping: "additional.owner.gid"
            }, {
                name: "mountType",
                mapping: "additional.mount_point_type"
            }]),
            remoteSort: true,
            paramNames: {
                start: "offset",
                limit: "limit",
                sort: "sort_by",
                dir: "sort_direction"
            },
            sortInfo: {
                field: "name",
                direction: "ASC"
            },
            baseParams: Ext.apply({
                superuser: f.superuser,
                sort_by: "name",
                additional: ["real_path", "size", "owner", "time", "perm", "type", "mount_point_type"]
            }, c),
            autoDestroy: true,
            listeners: {
                scope: this,
                beforeload: function(h, i) {
                    this.grid.mask(_T("common", "loading"));
                    var l = i.params;
                    var k = h.fields.get(h.sortInfo.field);
                    var j = k ? (k.mapping || k.name) : "name";
                    j = j.split(".", 3);
                    l.sort_by = j[2] || j[1] || j[0];
                    if (Ext.isFunction(this.getFilterPattern)) {
                        var g = this.bottomFieldset.items.items.slice(this.usage.type === "save" ? 1 : 0);
                        l.pattern = this.getFilterPattern(g)
                    }
                    return l
                },
                load: function(g) {
                    this.grid.unmask()
                },
                exception: function(i, j, k, h, l, g) {
                    this.grid.el.mask(SYNO.API.getErrorString(l.code))
                }
            }
        });
        var d = [{
            id: "filename",
            header: _T("common", "common_filename"),
            dataIndex: "filename",
            width: a("filename", "width") || undefined,
            hidden: a("filename", "hidden") || false,
            renderer: function(i, k, j, o, h, n) {
                if (Ext.isEmpty(j.data.icon)) {
                    j.data.icon = SYNO.SDS.Utils.FileChooser.Utils.getThumbName(j.data)
                }
                var m = Ext.util.Format.htmlEncode(i);
                if (!Ext.isIE || Ext.isModernIE) {
                    k.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(m) + '"'
                }
                var l = j.get("icon");
                var g = '<div><span class="icon-type" style="background-image: url(\'{0}\'); width:16px; height:16px;"></span>{1}</div>';
                if (j.get("mountType") === "remotefail") {
                    l = "remotefailmountpoint.png"
                }
                return String.format(g, SYNO.SDS.UIFeatures.IconSizeManager.getIconPath("webman/modules/FileBrowser/images/{1}/files_ext/" + l, "FileType"), m)
            }
        }, {
            header: _T("common", "common_filesize"),
            dataIndex: "filesize",
            width: a("filesize", "width") || 80,
            hidden: a("filesize", "hidden") || false,
            renderer: function(i, h, g) {
                if (g.get("isdir")) {
                    return ""
                } else {
                    return Ext.util.Format.fileSize(i)
                }
            }
        }, {
            header: _T("filetable", "filetable_title_file_type"),
            dataIndex: "type",
            width: a("type", "width") || 80,
            hidden: a("type", "hidden") || false,
            renderer: function(l, j, g, i, k, h) {
                if (g.get("isdir")) {
                    return _T("filetable", "filetable_folder")
                }
                if (l) {
                    return Ext.util.Format.htmlEncode(l.toUpperCase()) + " " + _T("filetable", "filetable_file")
                }
                return _T("filetable", "filetable_file")
            }
        }, {
            header: _T("filetable", "filetable_mtime"),
            dataIndex: "mt",
            width: a("mt", "width") || 160,
            hidden: a("mt", "hidden") || true,
            renderer: this.timeRender
        }, {
            header: _T("filetable", "filetable_ctime"),
            dataIndex: "ct",
            width: a("ct", "width") || 160,
            hidden: a("ct", "hidden") || true,
            renderer: this.timeRender
        }, {
            header: _T("filetable", "filetable_atime"),
            dataIndex: "at",
            width: a("at", "width") || 160,
            hidden: a("at", "hidden") || true,
            renderer: this.timeRender
        }, {
            header: _T("filetable", "filetable_privilege"),
            dataIndex: "privilege",
            width: a("privilege", "width") || 80,
            hidden: a("privilege", "hidden") || true,
            renderer: (function(q, p, l, t, h, r) {
                var m = l.data.privilege,
                    i = "",
                    s = "",
                    n = "";
                var g = 0,
                    k = 0,
                    o = 0;
                var j = parseInt(m, 10);
                if (j >= 100) {
                    g = Math.floor(j / 100);
                    j -= g * 100
                }
                if (j >= 10) {
                    k = Math.floor(j / 10);
                    j -= k * 10
                }
                o = j;
                i += (g & 4) ? "r" : "-";
                i += (g & 2) ? "w" : "-";
                i += (g & 1) ? "x" : "-";
                s += (k & 4) ? "r" : "-";
                s += (k & 2) ? "w" : "-";
                s += (k & 1) ? "x" : "-";
                n += (o & 4) ? "r" : "-";
                n += (o & 2) ? "w" : "-";
                n += (o & 1) ? "x" : "-";
                return i + s + n
            }).createDelegate(this)
        }];
        if (!f.owner._S("diskless")) {
            d.push({
                header: _T("filetable", "filetable_owner"),
                dataIndex: "owner",
                width: a("owner", "width") || 80,
                hidden: a("owner", "hidden") || true,
                renderer: function(l, j, g, i, k, h) {
                    if (g.get("mountType") === "remotefail") {
                        return ""
                    }
                    if (l === "") {
                        return g.get("uid")
                    }
                    return l
                }
            }, {
                header: _T("filetable", "filetable_group"),
                dataIndex: "group",
                width: a("group", "width") || 80,
                hidden: a("group", "hidden") || true,
                renderer: function(l, j, g, i, k, h) {
                    if (g.get("mountType") === "remotefail") {
                        return ""
                    }
                    if (l === "") {
                        return g.get("gid")
                    }
                    return l
                }
            })
        }
        var b = {
            itemId: "grid",
            region: "center",
            xtype: "syno_gridpanel",
            cls: "file_chooser_gridpanel",
            bbar: this.createPagingToolbar(),
            listeners: {
                rowdblclick: {
                    fn: this.onGridRowDbClick,
                    scope: this
                },
                rowclick: {
                    fn: this.onGridRowClick,
                    scope: this
                }
            },
            store: this.gridStore,
            colModel: new Ext.grid.ColumnModel({
                defaults: {
                    sortable: true
                },
                columns: d
            }),
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: ("open" !== f.usage.type || false === f.usage.multiple)
            }),
            view: new SYNO.ux.FleXcroll.grid.BufferView({
                cacheSize: 30,
                scrollDelay: false,
                forceFit: true
            })
        };
        Ext.apply(b, e);
        return b
    },
    createPagingToolbar: function() {
        var a = new SYNO.ux.PagingToolbar({
            store: this.gridStore,
            pageSize: this.pageSize,
            smallStyle: true,
            displayInfo: true,
            showRefreshBtn: true,
            displayButtons: false,
            listeners: {
                change: function(b, c) {
                    this.setButtonsVisible(c.total > b.pageSize)
                }
            }
        });
        return a
    },
    getCurrentSource: function() {
        return this.tree.getSelectionModel().getSelectedNode().attributes.type
    },
    onTreeRootExpand: function(c) {
        if (c.firstChild) {
            c.firstChild.select()
        }
        if ("fm_root" === c.id && c.childNodes && c.childNodes.length < 1 && !this._S("diskless")) {
            var d;
            var a;
            var b;
            if (true === this._S("is_admin")) {
                d = this._S("standalone") ? _T("filebrowser", "prompt_noshare_standalone") : _T("filebrowser", "prompt_noshare");
                b = Ext.MessageBox.OKCANCEL;
                a = function(f) {
                    if ("ok" == f) {
                        if (this._S("standalone")) {
                            this.close();
                            return
                        }
                        if (this.closeOwnerWhenNoShare) {
                            var g = this;
                            for (var e = 0; e < this.closeOwnerNumber; e++) {
                                g = g.owner
                            }
                            g.close()
                        } else {
                            this.close()
                        }
                        if (!this.findAppWindow()) {
                            throw "Cannot find app window"
                        }
                        SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", Ext.apply({}, {
                            fn: "SYNO.SDS.AdminCenter.Share.Main"
                        }, this.findAppWindow().openConfig))
                    } else {
                        this.close()
                    }
                }
            } else {
                b = Ext.MessageBox.OK;
                d = _T("download", "user_no_share_folder");
                a = function() {
                    this.close()
                }
            }
            this.getMsgBox().show({
                title: this.title,
                msg: d,
                width: 300,
                buttons: b,
                scope: this,
                fn: a
            })
        }
    },
    onTreeBeforeSelect: function(c, a, b) {
        if (!this.gotoComplete && !Ext.isEmpty(this.gotoPath)) {
            return false
        }
        if (this.rootId === a.id || "fm_fav_root" === a.id) {
            return false
        }
        return true
    },
    onTreeSelectionChange: function(c, b) {
        if (!this.grid) {
            return
        }
        if (!b) {
            return
        }
        var a = this.grid.getStore();
        a.removeAll();
        if (b.attributes) {
            a.baseParams.folder_path = b.attributes.spath
        }
        a.baseParams.filetype = "all";
        a.load({
            params: {
                offset: 0,
                limit: this.pageSize
            }
        })
    },
    onGridRowClick: function(c, f, d) {
        if ("save" == this.usage.type) {
            var b, a = c.getStore().getAt(f);
            if (a.data.isdir) {
                b = this.usage.oldFilename
            } else {
                b = a.data.filename
            }
            var g = b.lastIndexOf(".");
            this.bottomFieldset.items.items[0].setValue(b);
            if (-1 == g) {
                this.bottomFieldset.items.items[0].selectText()
            } else {
                this.bottomFieldset.items.items[0].selectText(0, g)
            }
        }
    },
    onGridRowDbClick: function(c, f, d) {
        var a = c.getStore().getAt(f),
            g = a.get("file_id"),
            b = g.substr(0, g.lastIndexOf("/"));
        if (a.get("isdir")) {
            this.tree.getNodeById(this.getCurrentSource() + b).expand(false, false, function() {
                this.tree.getNodeById(this.getCurrentSource() + g).select()
            }, this);
            return
        }
        this.applyHandler()
    },
    timeRender: function(a) {
        return a ? (new Date(a * 1000)).toLocaleString() : ""
    },
    applyHandler: function() {
        var h = {},
            d = null,
            e, b, g, k;
        var c = (this.usage.type == "save") ? 1 : 0,
            j = null;
        if (this.bottomFieldset) {
            j = this.bottomFieldset.items.items
        }
        if (this.comboOption && j) {
            d = [];
            for (var f = c; f < j.length; f++) {
                d.push(j[f].value)
            }
        }
        if ("open" == this.usage.type) {
            if (this.usage.multiple) {
                e = this.grid.selModel.getSelections();
                if (0 === e.length) {
                    this.getMsgBox().alert("", _T("filetable", "filetable_select_one"));
                    return
                } else {
                    if (1 === e.length && e[0].data.isdir) {
                        b = e[0].id;
                        g = b.substr(0, b.lastIndexOf("/"));
                        this.tree.getNodeById(this.getCurrentSource() + g).expand(false, false, function() {
                            this.tree.getNodeById(this.getCurrentSource() + b).select()
                        }, this);
                        return
                    }
                }
                h.records = e
            } else {
                e = this.grid.selModel.getSelected();
                if (!e) {
                    this.getMsgBox().alert("", _T("filetable", "filetable_select_one"));
                    return
                }
                if (e.data.isdir) {
                    b = e.id;
                    g = b.substr(0, b.lastIndexOf("/"));
                    this.tree.getNodeById(this.getCurrentSource() + g).expand(false, false, function() {
                        this.tree.getNodeById(this.getCurrentSource() + b).select()
                    }, this);
                    return
                } else {
                    h.path = e.data.path;
                    h.fullpath = e.data.real_path
                }
            }
            this.fireEvent("choose", this, h, d)
        } else {
            if ("save" == this.usage.type) {
                var a = Ext.util.Format.trim(this.bottomFieldset.items.items[0].value);
                e = this.grid.selModel.getSelected();
                if (e && e.data.isdir) {
                    b = e.id;
                    g = b.substr(0, b.lastIndexOf("/"));
                    this.tree.getNodeById(this.getCurrentSource() + g).expand(false, false, function() {
                        this.tree.getNodeById(this.getCurrentSource() + b).select()
                    }, this);
                    return
                }
                if (!a) {
                    this.getMsgBox().alert("", _T("error", "error_empty_name"));
                    return
                }
                if (!SYNO.SDS.Utils.FileChooser.Utils.checkFileLen(a)) {
                    this.getMsgBox().alert("", _T("error", "error_long_path"));
                    return
                }
                if (SYNO.SDS.Utils.FileChooser.Utils.isNameReserved(a)) {
                    this.getMsgBox().alert("", _T("error", "error_reserved_name"));
                    return
                }
                if (SYNO.SDS.Utils.FileChooser.Utils.isNameCharIllegal(a)) {
                    this.getMsgBox().alert("", _T("error", "error_reserved_name"));
                    return
                }
                if (-1 !== (k = this.grid.store.findExact("filename", a))) {
                    if (this.grid.store.getAt(k).data.isdir) {
                        this.getMsgBox().alert("", _T("error", "error_file_exist"));
                        return
                    }
                    this.getMsgBox().confirm("", _T("filetable", "confirm_overwrite"), function(i) {
                        if ("yes" !== i) {
                            return
                        }
                        e = this.grid.selModel.getSelected();
                        h.path = this.tree.selModel.getSelectedNode().attributes.spath + "/" + a;
                        this.fireEvent("choose", this, h, d)
                    }, this);
                    return
                } else {
                    h.path = this.tree.selModel.getSelectedNode().attributes.spath + "/" + a;
                    this.fireEvent("choose", this, h, d)
                }
            } else {
                if ("chooseDir" == this.usage.type) {
                    this.applyHandlerWhenChoosingDir(h, d)
                } else {
                    if ("chooseFile" == this.usage.type) {
                        e = this.grid.selModel.getSelected();
                        if (!e) {
                            this.getMsgBox().alert("", _T("filetable", "filetable_select_one"));
                            return
                        }
                        h.path = e.data.path;
                        this.fireEvent("choose", this, h, d)
                    }
                }
            }
        }
    },
    applyHandlerWhenChoosingDir: function(b, e) {
        var d = this.tree.selModel.getSelectedNode();
        if (!d || d.attributes.hideNode) {
            return
        }
        var a = false;
        var c = d;
        while (c) {
            if (!c.attributes) {
                break
            }
            if (true === c.attributes.is_c2share) {
                a = true;
                break
            }
            c = c.parentNode
        }
        b.path = d.attributes.spath;
        b.fullpath = d.attributes.path;
        b.is_in_c2share = a;
        this.fireEvent("choose", this, b, e)
    },
    cancelHandler: function() {
        this.fireEvent("cancel", this);
        this.close()
    },
    onComboOptionChange: function() {
        this.gridStore.reload()
    },
    createFolder: function() {
        var e = this.tree.selModel;
        var c = e.getSelectedNode();
        if (!c || c.attributes.hideNode) {
            return
        }
        if (this._S("is_admin") !== true && this._S("domainUser") !== "true") {
            var b = false,
                a;
            if (c.parentNode.id !== "fm_root") {
                a = SYNO.SDS.Utils.FileChooser.Utils.getShareRight(this.tree, c)
            } else {
                a = c.attributes.right;
                b = true
            }
            if (!SYNO.SDS.Utils.FileChooser.Utils.checkShareRight(a, SYNO.SDS.Utils.FileChooser.Utils.RW)) {
                this.getMsgBox().alert(_T("filetable", "filetable_create_folder_title"), _T("error", "error_privilege_not_enough"));
                return false
            }
            if (!b) {
                var d = {
                    right: c.attributes.aclRight,
                    needRight: SYNO.SDS.Utils.FileChooser.Utils.ReqPrivilege.DestFolder.Create
                };
                if (!SYNO.SDS.Utils.FileChooser.Utils.checkFileRight.call(this, d)) {
                    this.getMsgBox().alert(_T("filetable", "filetable_create_folder_title"), _T("error", "error_privilege_not_enough"));
                    return false
                }
            }
        }
        if (!this.crtDialog || this.crtDialog.isDestroyed) {
            this.crtDialog = new SYNO.SDS.Utils.FileChooser.CrtFdrDialog({
                RELURL: this.RELURL,
                owner: this,
                cls: this.initialConfig.cls
            })
        }
        this.crtDialog.mon(this.crtDialog, "callback", this.onCrtFdrHide, this, {
            single: true
        });
        this.crtDialog.setParentDir(c.attributes.spath);
        this.crtDialog.load()
    },
    onCrtFdrHide: function() {
        var b = this.crtDialog.getFolderName();
        var d = this.tree.selModel;
        var c = d.getSelectedNode();
        if (!c || !b) {
            return
        }
        var a = c.attributes.spath;
        this.sendWebAPI({
            api: "SYNO.Core.File",
            method: "create",
            params: {
                superuser: this.superuser,
                type: "folder",
                name: b,
                dest: a
            },
            version: 1,
            scope: this,
            callback: function(e, g) {
                this.crtDialog.hide();
                if (!e) {
                    this.getMsgBox().alert("", SYNO.API.getErrorString(g.code));
                    return
                }
                var h = this.tree.selModel;
                var f = h.getSelectedNode();
                this.onTreeSelectionChange(h, f);
                f.reload(function() {
                    var i = this.tree.getNodeById(f.id + "/" + this.crtDialog.getFolderName());
                    if (i) {
                        i.select()
                    }
                }, this);
                SYNO.SDS.StatusNotifier.fireEvent("filechanged", null, a)
            }
        })
    }
});
