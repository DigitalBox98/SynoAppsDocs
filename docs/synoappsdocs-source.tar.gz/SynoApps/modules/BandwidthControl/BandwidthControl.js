/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.namespace("SYNO.SDS.BandwidthControl"), SYNO.SDS.BandwidthControl.SchedulePanelConfig = function(e, t) {
    var i = "";
    "FileStation" === t ? i = _T("bandwidth", "protocol_desc_file_station") : "WebDAV" === t ? i = _T("bandwidth", "protocol_desc_webdav") : "FTP" === t ? i = _T("bandwidth", "protocol_desc_ftp") : "NetworkBackup" === t && (i = _T("bandwidth", "protocol_desc_rsync"));
    var n = function(t) {
        Ext.getCmp(e.BandwidthSettingBtnId).setDisabled(!t)
    };
    return e.bandwidthSettingEnable = function(t) {
        Ext.getCmp(e.bandwidth_desc).setDisabled(!t), Ext.getCmp(e.bandwidth_disable).setDisabled(!t), Ext.getCmp(e.bandwidth_enable).setDisabled(!t), Ext.getCmp(e.bandwidth_schedule).setDisabled(!t), Ext.getCmp(e.bandwidth_disable).checked && n(!1)
    }, {
        xtype: "panel",
        layout: "form",
        border: !1,
        padding: 0,
        webapi: {
            api: "SYNO.Core.BandwidthControl.Protocol",
            methods: {
                get: "get",
                set: "set"
            },
            params: {
                get: {
                    protocol: t
                },
                set: {
                    protocol: t
                }
            },
            version: 1
        },
        listeners: {
            scope: this,
            afterlayout: function() {
                new SYNO.ux.Utils.EnableRadioGroup(e.getScheduleForm(), t + "_policy", {
                    scheduled: [e.BandwidthSettingScheduleBtn]
                })
            }
        },
        items: [{
            xtype: "syno_displayfield",
            id: e.bandwidth_desc = Ext.id(),
            value: i
        }, {
            xtype: "syno_radio",
            name: t + "_policy",
            id: e.bandwidth_disable = Ext.id(),
            inputValue: "disabled",
            indent: 1,
            boxLabel: _T("bandwidth", "disable_limit_option"),
            listeners: {
                check: function(e, t) {
                    n(!t)
                },
                enable: function() {
                    n(!0)
                },
                disable: function() {
                    n(!1)
                }
            }
        }, {
            xtype: "syno_radio",
            name: t + "_policy",
            id: e.bandwidth_enable = Ext.id(),
            inputValue: "enabled",
            indent: 1,
            boxLabel: _T("bandwidth", "enable_limit")
        }, {
            xtype: "syno_compositefield",
            hideLabel: !0,
            indent: 1,
            items: [{
                xtype: "syno_radio",
                name: t + "_policy",
                id: e.bandwidth_schedule = Ext.id(),
                inputValue: "scheduled",
                boxLabel: _T("bandwidth", "schedule_limit"),
                scope: e,
                handler: function(e, t) {
                    if (t) {
                        var i = Ext.getCmp(this.schedule_plan);
                        "" === i.getValue() && i.setValue("1".repeat(168))
                    }
                }
            }, {
                xtype: "syno_button",
                id: e.BandwidthSettingScheduleBtn = Ext.id(),
                indent: 1,
                tabIndex: -1,
                text: _T("bandwidth", "schedule_plan"),
                scope: this,
                handler: SYNO.SDS.BandwidthControl.SchedulePlanWinOpen.createDelegate(e, ["service"])
            }]
        }, {
            xtype: "syno_button",
            id: e.BandwidthSettingBtnId = Ext.id(),
            indent: 1,
            name: "bandwidth_user_btn",
            text: _T("bandwidth", "bandwidth_brief_desc"),
            scope: this,
            handler: function() {
                new SYNO.SDS.BandwidthControl.MainWindow({
                    owner: e.findWindow(),
                    protocol: t
                }).open()
            }
        }, {
            xtype: "hidden",
            name: t + "_schedule_plan",
            id: e.schedule_plan = Ext.id()
        }]
    }
}, SYNO.SDS.BandwidthControl.SchedulePlanWinOpen = function(e, t, i) {
    var n = "service" === e ? {
        scheduleField: Ext.getCmp(this.schedule_plan).getValue()
    } : {
        protocol: t.data.protocol,
        scheduleField: t.data.schedule_plan,
        defUpRate: t.data.upload_limit_1,
        defDownRate: t.data.download_limit_1,
        cusUpRate: t.data.upload_limit_2,
        cusDownRate: t.data.download_limit_2,
        groupUpRate: t.data.upload_result,
        groupDownRate: t.data.download_result
    };
    new SYNO.SDS.BandwidthControl.SchedulePlanWin({
        owner: this.findWindow(),
        winType: e,
        blUser: i,
        scheduleConfig: n,
        listeners: {
            scope: this,
            beforeclose: function() {
                "service" === e ? Ext.getCmp(this.schedule_plan).setValue(n.scheduleField) : (t.set("schedule_plan", n.scheduleField), t.set("upload_limit_1", n.defUpRate), t.set("download_limit_1", n.defDownRate), t.set("upload_limit_2", n.cusUpRate), t.set("download_limit_2", n.cusDownRate))
            }
        }
    }).open()
}, Ext.define("SYNO.SDS.BandwidthControl.ScheduleTable", {
    extend: "SYNO.ux.ScheduleTable",
    constructor: function(e) {
        if (this.rateCompList = [], "service" === e.winType) return void this.callParent([e]);
        var t = [Ext.id(), Ext.id(), Ext.id(), Ext.id()],
            i = [{
                xtype: "syno_displayfield",
                value: _T("bandwidth", "schedule_plan_desc"),
                style: "margin-bottom: 6px"
            }, this.createCompositefieldConfig(e, _T("bandwidth", "limit_default_setting"), !0, t[0], t[1]), this.createCompositefieldConfig(e, _T("bandwidth", "limit_customize_setting"), !0, t[2], t[3])];
        e.blUser && i.push(this.createCompositefieldConfig(e, _T("bandwidth", "group_speed_limit"), !1, Ext.id(), Ext.id()));
        var n = Ext.apply({
            cls: "syno-sds-bw2-schedule-table-panel",
            showButtonOnTop: !1,
            customizeItems: [{
                xtype: "syno_formpanel",
                autoHeight: !0,
                padding: "0px 0px 8px 0px",
                items: i
            }]
        }, e);
        this.callParent([n]), t.forEach(function(e) {
            this.rateCompList.push(Ext.getCmp(e))
        }, this)
    },
    createCompositefieldConfig: function(e, t, i, n, o) {
        var a = function(t) {
                return "FileStation" !== e.owner.protocol && "FileStation" !== e.scheduleConfig.protocol || (!t || (0 === parseInt(t, 10) || 10 <= parseInt(t, 10) || _WFT("bandwidth", "bandwidth_min_rate")))
            },
            d = e.scheduleConfig.groupUpRate,
            s = e.scheduleConfig.groupDownRate;
        return {
            xtype: "syno_compositefield",
            width: 320,
            labelWidth: 374,
            fieldLabel: t,
            style: "padding-left: 8px;",
            items: [{
                xtype: "syno_numberfield",
                id: n,
                maxlength: 9,
                width: 116,
                disabled: !i,
                allowBlank: !0,
                emptyText: _T("dhcp_server", "unlimited"),
                vtype: "number",
                validationEvent: "keyup",
                value: !i && d ? d : void 0,
                validator: a
            }, {
                xtype: "syno_displayfield",
                value: "/"
            }, {
                xtype: "syno_numberfield",
                id: o,
                maxlength: 9,
                width: 116,
                disabled: !i,
                allowBlank: !0,
                emptyText: _T("dhcp_server", "unlimited"),
                vtype: "number",
                validationEvent: "keyup",
                value: !i && s ? s : void 0,
                validator: a
            }, {
                xtype: "syno_displayfield",
                width: 54,
                value: "(" + _T("bandwidth", "speed_unit") + ")"
            }]
        }
    },
    isValid: function() {
        for (var e = 0; e < this.rateCompList.length; e++)
            if (!this.rateCompList[e].isValid()) return !1;
        return !0
    },
    setRates: function(e) {
        for (var t = 0; t < this.rateCompList.length; t++) this.rateCompList[t].setValue(e[t] ? e[t] : "")
    },
    getRates: function() {
        for (var e = [], t = 0; t < this.rateCompList.length; t++) e.push(this.rateCompList[t].getValue() ? this.rateCompList[t].getValue() : 0);
        return e
    }
}), Ext.define("SYNO.SDS.BandwidthControl.SchedulePlanWin", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.scheduleConfig = e.scheduleConfig, this.winType = e.winType, this.scheduleTable = new SYNO.SDS.BandwidthControl.ScheduleTable(e);
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = SYNO.SDS.BandwidthControl.ProtocolName(this.scheduleConfig.protocol, this.scheduleConfig.protocol_ui),
            i = {
                owner: e.owner,
                autoHeight: !0,
                width: "user" === this.winType ? 742 : 683,
                resizable: !1,
                closeAction: "onCancel",
                padding: "16px 20px 14px 20px",
                title: t ? String.format(_T("bandwidth", "adv_setting_title"), t) : _T("schedule", "schedule_title"),
                layout: "fit",
                items: [this.scheduleTable],
                buttons: [{
                    text: _T("common", "cancel"),
                    scope: this,
                    handler: this.onCancel
                }, {
                    btnStyle: "blue",
                    text: _T("common", "save"),
                    scope: this,
                    handler: this.okHandler
                }]
            };
        return Ext.apply(i, e)
    },
    isDirty: function() {
        var e = this.scheduleTable.getSchedule(),
            t = this.scheduleTable.getRates();
        return this.scheduleConfig.scheduleField !== e || this.scheduleConfig.defUpRate !== t[0] || this.scheduleConfig.defDownRate !== t[1] || this.scheduleConfig.cusUpRate !== t[2] || this.scheduleConfig.cusDownRate !== t[3]
    },
    okHandler: function() {
        if (!this.isDirty()) return void this.close();
        if (!this.scheduleTable.isValid()) return void this.setStatusError({
            text: _T("common", "forminvalid"),
            clear: !0
        });
        if (this.scheduleConfig.scheduleField = this.scheduleTable.getSchedule(), "user" === this.winType) {
            var e = this.scheduleTable.getRates();
            this.scheduleConfig.defUpRate = e[0], this.scheduleConfig.defDownRate = e[1], this.scheduleConfig.cusUpRate = e[2], this.scheduleConfig.cusDownRate = e[3]
        }
        this.close()
    },
    onCancel: function() {
        if (!this.isDirty()) return void this.close();
        this.confirmLostChangePromise({
            save: this.okHandler,
            dontSave: this.close,
            cancel: Ext.emptyFn
        }, this)
    },
    onShow: function() {
        Ext.isEmpty(this.scheduleConfig.scheduleField) || this.scheduleTable.setSchedule(this.scheduleConfig.scheduleField), "user" === this.winType && this.scheduleTable.setRates([this.scheduleConfig.defUpRate, this.scheduleConfig.defDownRate, this.scheduleConfig.cusUpRate, this.scheduleConfig.cusDownRate])
    }
}), SYNO.SDS.BandwidthControl.reConstructApiKey = function(e, t, i) {
    var n = {};
    return void 0 === i ? n : ("get" === e ? (n[t + "_policy"] = i.policy, n[t + "_schedule_plan"] = i.schedule_plan) : "set" === e && (n.protocol = t, n.policy = i[t + "_policy"], n.schedule_plan = i[t + "_schedule_plan"]), n)
}, Ext.namespace("SYNO.SDS.BandwidthControl"), SYNO.SDS.BandwidthControl.ProtocolName = function(e, t) {
    return "FileStation" === e ? "File Station" : "WebDAV" === e ? "WebDAV" : "FTP" === e ? "FTP" : "NetworkBackup" === e ? "Rsync" : Ext.isString(t) ? -1 === t.indexOf(":") ? t : SYNO.SDS.UIString.GetLocalizedString(t) : e
}, SYNO.SDS.BandwidthControl.ProtocolTitle = function(e, t, i) {
    return SYNO.SDS.BandwidthControl.ProtocolName(e, i && i.data ? i.data.protocol_ui : void 0)
}, Ext.define("SYNO.SDS.BandwidthControl.ColumnModel", {
    extend: "Ext.grid.ColumnModel",
    constructor: function(e) {
        this.store = e.store, this.protocol = e.protocol, this.ownerType = e.ownerType.split("_")[1];
        var t = this.createColumnConfig();
        this.callParent([t])
    },
    createColumnConfig: function() {
        var e = "user" === this.ownerType ? _T("bandwidth", "mode_disable_user") : _T("bandwidth", "mode_disable"),
            t = function(e, t, i) {
                return "scheduled" === i.get("policy") && (t.attr = 'style="color:#aaaaaa;"'), e
            },
            i = this.protocol,
            n = new SYNO.ux.NumberField({
                allowBlank: !1,
                allowNegative: !1,
                allowDecimals: !1,
                validationEvent: "keyup",
                maxLength: 9,
                validateOnBlur: !0,
                validator: function(e) {
                    return "FileStation" !== i || (10 <= parseInt(e, 10) || 0 === parseInt(e, 10) || _WFT("bandwidth", "bandwidth_min_rate"))
                }
            }),
            o = new SYNO.ux.ComboBox({
                name: "modeSelect",
                hiddenName: "modeSelect",
                displayField: "display",
                valueField: "value",
                triggerAction: "all",
                hideLabel: !0,
                typeAhead: !0,
                editable: !1,
                forceSelection: !0,
                valueNotFoundText: e,
                mode: "local",
                tpl: '<tpl for="."><div id=[{Ext.id()}] class="x-combo-list-item" role="option" aria-label="{display}" ext:qtip="{display}">{display}</div></tpl>',
                store: new Ext.data.ArrayStore({
                    fields: ["display", "value"],
                    data: [
                        [e, "disabled"],
                        [_T("bandwidth", "mode_enable"), "enabled"],
                        [_T("bandwidth", "mode_schedule"), "scheduled"]
                    ],
                    autoDestroy: !0
                })
            }),
            a = [];
        return a.push({
            header: _T("bandwidth", "bandwidth_account_name"),
            dataIndex: "name",
            sortable: !0,
            renderer: function(e, t) {
                return t.attr = String.format('ext:qtip="{0}"', e), e
            }
        }), "user" === this.ownerType && a.push({
            header: _T("bandwidth", "bandwidth_preview") + " (UL/DL)",
            dataIndex: "preview",
            renderer: function(e, i, n) {
                t(e, i, n);
                var o = 0,
                    a = 0,
                    d = n.get("policy"),
                    s = _T("dhcp_server", "unlimited");
                return "scheduled" === d ? "".concat(_T("bandwidth", "mode_schedule")) : ("enabled" === d ? (o = n.get("upload_limit_1"), a = n.get("download_limit_1")) : (o = n.get("upload_result"), a = n.get("download_result")), 0 === o && (o = s), 0 === a && (a = s), "".concat(o, " / ").concat(a))
            }
        }), a = a.concat([{
            header: _T("bandwidth", "bandwidth_up_rate") + " (KB/s)",
            dataIndex: "upload_limit_1",
            editor: n,
            renderer: t
        }, {
            header: _T("bandwidth", "bandwidth_down_rate") + " (KB/s)",
            dataIndex: "download_limit_1",
            editor: n,
            renderer: t
        }, {
            header: _T("bandwidth", "mode"),
            dataIndex: "policy",
            editor: o,
            renderer: function(t) {
                var i = e;
                return "enabled" === t && (i = _T("bandwidth", "mode_enable")), "scheduled" === t && (i = _T("bandwidth", "mode_schedule")), i
            }
        }, {
            dataIndex: "schedule_plan",
            hidden: !0
        }, {
            dataIndex: "upload_limit_2",
            hidden: !0
        }, {
            dataIndex: "download_limit_2",
            hidden: !0
        }])
    },
    isCellEditable: function(e, t) {
        var i = this.store.getAt(t),
            n = "user" === this.ownerType ? 4 : 3;
        return ("scheduled" !== i.get("policy") || e === n) && this.callParent(arguments)
    }
}), Ext.define("SYNO.SDS.BandwidthControl.EditorGridPanel", {
    extend: "SYNO.ux.EditorGridPanel",
    constructor: function(e) {
        this.ownerType = e.ownerType.split("_")[1], this.pageSize = e.pageSize, this.schedulePlanBtn = new SYNO.ux.Button({
            name: "schedulePlanBtn",
            text: _T("bandwidth", "schedule_plan_" + this.ownerType),
            disabled: !0,
            tabIndex: -1,
            scope: this,
            handler: this.onSchedulePlanBtnClick
        });
        var t = {
            store: e.store,
            enableHdMenu: !1,
            enableColumnMove: !1,
            clicksToEdit: 1,
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: !0,
                listeners: {
                    scope: this,
                    selectionchange: this.onRowSelectionChange
                }
            }),
            listeners: {
                scope: this,
                afterrender: function() {
                    this.getStore().load()
                }
            },
            tbar: new SYNO.ux.Toolbar({
                items: [this.schedulePlanBtn, "->", new SYNO.ux.TextFilter({
                    emptyText: _T("connections", "search_connections"),
                    store: e.store,
                    pageSize: this.pageSize
                })]
            }),
            bbar: new SYNO.ux.PagingToolbar({
                store: e.store,
                pageSize: this.pageSize,
                displayInfo: !0
            })
        };
        Ext.apply(t, e), this.callParent([t])
    },
    onRowSelectionChange: function(e) {
        this.schedulePlanBtn.setDisabled(0 === e.getCount())
    },
    onSchedulePlanBtnClick: function() {
        var e = this.selModel.getSelected();
        if (e) {
            e.data.schedule_plan = Ext.value(e.data.schedule_plan, "1".repeat(168)), e.data.upload_limit_2 = Ext.value(e.data.upload_limit_2, 0), e.data.download_limit_2 = Ext.value(e.data.download_limit_2, 0);
            var t = {
                scheduleField: e.data.schedule_plan,
                defUpRate: e.data.upload_limit_1,
                defDownRate: e.data.download_limit_1,
                cusUpRate: e.data.upload_limit_2,
                cusDownRate: e.data.download_limit_2
            };
            new SYNO.SDS.BandwidthControl.SchedulePlanWin({
                owner: this.owner,
                winType: "user",
                blUser: "user" === this.ownerType,
                scheduleConfig: t,
                listeners: {
                    scope: this,
                    close: function() {
                        e.set("schedule_plan", t.scheduleField), e.set("upload_limit_1", t.defUpRate), e.set("download_limit_1", t.defDownRate), e.set("upload_limit_2", t.cusUpRate), e.set("download_limit_2", t.cusDownRate)
                    }
                }
            }).open()
        }
    }
}), Ext.define("SYNO.SDS.BandwidthControl.MainWindow", {
    extend: "SYNO.SDS.ModalWindow",
    pageSize: 25,
    constructor: function(e) {
        var t = [];
        ["local", "ldap", "domain"].forEach(function(i) {
            ["user", "group"].forEach(function(n) {
                var o = i + "_" + n;
                t.push(this.initBandwidthGrid({
                    owner: this,
                    protocol: e.protocol,
                    ownerType: o,
                    title: _T("bandwidth", "bandwidth_" + o + "_tab_title"),
                    itemId: "bandwidth_" + o + "_tab",
                    pageSize: this.pageSize
                }))
            }, this)
        }, this), this.tabPanel = new SYNO.ux.TabPanel({
            plain: !0,
            activeTab: 0,
            items: t
        }), this.callParent([Ext.apply({
            title: _T("bandwidth", "bandwidth_settings"),
            autoDestroy: !0,
            width: 820,
            height: 500,
            border: !1,
            plain: !0,
            layout: "fit",
            closeAction: "onCancel",
            items: [this.tabPanel],
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: this.onCancel
            }, {
                btnStyle: "blue",
                text: _T("common", "save"),
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                scope: this,
                handler: this.onApply
            }]
        }, e)]), this.tabPanel.hideTabStripItem("bandwidth_domain_user_tab"), this.tabPanel.hideTabStripItem("bandwidth_domain_group_tab"), this.tabPanel.hideTabStripItem("bandwidth_ldap_user_tab"), this.tabPanel.hideTabStripItem("bandwidth_ldap_group_tab");
        var i = [{
            api: "SYNO.Core.Directory.Domain",
            method: "get",
            version: 1
        }, {
            api: "SYNO.Core.Directory.Domain",
            method: "test_dc",
            version: 1
        }, {
            api: "SYNO.Core.Directory.LDAP",
            method: "get",
            version: 1
        }];
        this.sendWebAPI({
            params: {},
            compound: {
                stopwhenerror: !1,
                params: i
            },
            scope: this,
            callback: function(e, t) {
                if (!this.isDestroyed) {
                    var i = t.result;
                    e && !t.has_fail && (i[0].data.enable_domain && i[1].data.test_join_success && (this.tabPanel.unhideTabStripItem("bandwidth_domain_user_tab"), this.tabPanel.unhideTabStripItem("bandwidth_domain_group_tab")), i[2].data.enable_client && (this.tabPanel.unhideTabStripItem("bandwidth_ldap_user_tab"), this.tabPanel.unhideTabStripItem("bandwidth_ldap_group_tab")))
                }
            }
        })
    },
    checkDirty: function() {
        for (var e = 0; e < this.tabPanel.items.items.length; ++e)
            if (0 < this.tabPanel.items.items[e].getStore().getModifiedRecords().length) return !0;
        return !1
    },
    onCancel: function() {
        if (!this.checkDirty()) return void this.close();
        this.confirmLostChangePromise({
            save: this.onApply,
            dontSave: this.close,
            cancel: Ext.emptyFn
        }, this)
    },
    onApply: function() {
        if (!this.checkDirty()) return void this.close();
        this.setStatusBusy({
            text: _T("common", "saving")
        }), this.sendWebAPI({
            api: "SYNO.Core.BandwidthControl",
            method: "set",
            version: 1,
            params: this.serializeApplyData(),
            callback: this.applyDone,
            scope: this
        })
    },
    onBeforeStoreLoad: function(e, t) {
        if (this.setStatusBusy(), e.getModifiedRecords(), 0 >= e.getModifiedRecords().length) return !0;
        this.clearStatusBusy();
        var i = _T("share", "share_save_chg_before_reload"),
            n = function(i) {
                "yes" === i ? this.saveBandwidthSetting(e, t) : (e.rejectChanges(), e.load(t))
            };
        return this.getMsgBox().confirm(this.title, i, n, this), !1
    },
    onStoreLoad: function() {
        this.clearStatusBusy()
    },
    saveBandwidthSetting: function(e, t) {
        var i = function(i) {
            if (this.clearStatusBusy(), !i) return void this.getMsgBox().alert(this.title, _T("common", "error_system"));
            e.commitChanges(), e.load(t)
        };
        this.setStatusBusy({
            text: _T("common", "saving")
        }), this.sendWebAPI({
            api: "SYNO.Core.BandwidthControl",
            method: "set",
            version: 1,
            params: this.serializeApplyData(),
            callback: i,
            scope: this
        })
    },
    serializeApplyData: function() {
        for (var e = [], t = function(t) {
                e.push(t.data)
            }, i = 0; i < this.tabPanel.items.items.length; ++i) 0 < this.tabPanel.items.items[i].getStore().getModifiedRecords().length && Ext.each(this.tabPanel.items.items[i].getStore().getModifiedRecords(), t);
        return {
            bandwidths: e
        }
    },
    applyDone: function() {
        this.clearStatusBusy(), this.close()
    },
    initBandwidthGrid: function(e) {
        return e.store = new SYNO.API.JsonStore({
            api: "SYNO.Core.BandwidthControl",
            method: "list",
            version: 1,
            baseParams: {
                protocol: e.protocol,
                owner_type: e.ownerType,
                offset: 0,
                limit: e.pageSize
            },
            fields: ["name", "protocol", "owner_type", "policy", "schedule_plan", "upload_result", "upload_limit_1", "upload_limit_2", "download_result", "download_limit_1", "download_limit_2"],
            root: "bandwidths",
            sortInfo: {
                field: "name",
                direction: "ASC"
            },
            totalProperty: "total",
            remoteSort: !1,
            appWindow: this,
            listeners: {
                scope: this,
                beforeload: this.onBeforeStoreLoad,
                load: this.onStoreLoad
            }
        }), e.colModel = new SYNO.SDS.BandwidthControl.ColumnModel(e), new SYNO.SDS.BandwidthControl.EditorGridPanel(e)
    }
}), 
/**
 * @class SYNO.SDS.BandwidthControl.Status
 * @extends SYNO.ux.GridPanel
 * BandwidthControl status class
 *
 */
Ext.define("SYNO.SDS.BandwidthControl.Status", {
    extend: "SYNO.ux.GridPanel",
    itemsPerPage: 50,
    multipleSort: !1,
    constructor: function(e) {
        this.appWin = e.appWin, this.appInst = e.appWin.appInstance;
        var t = Ext.apply({
            store: this.getStatusStore(),
            colModel: this.getStatusCM(),
            tbar: this.getTBar(),
            bbar: this.getBBar(),
            sm: new Ext.grid.RowSelectionModel({
                listeners: {
                    selectionchange: {
                        fn: this.updateToolBarBts,
                        scope: this,
                        buffer: 80
                    }
                }
            }),
            listeners: {
                scope: this,
                activate: this.onActivate,
                deactivate: this.onDeactivate,
                rowcontextmenu: this.showGridCtxMenu,
                sortchange: this.onGridSortChanged,
                headermousedown: this.onGridHeaderMouseDown
            }
        }, e);
        return this.callParent([t])
    },
    getTBar: function() {
        return this.searchField = new SYNO.ux.TextFilter({
            emptyText: _T("connections", "search_connections"),
            store: this.getStatusStore(),
            pageSize: this.itemsPerPage,
            disabled: !0
        }), new SYNO.ux.Toolbar({
            items: [{
                text: _T("log", "log_reload"),
                itemId: "bt_refresh",
                disabled: !0,
                handler: function() {
                    this.getEl().mask(_T("common", "msg_waiting"), "x-mask-loading"), this.pagingToolBar.doRefresh()
                },
                scope: this
            }, {
                text: _T("connections", "kick_connection_br"),
                itemId: "bt_kick1",
                disabled: !0,
                hidden: !_S("is_admin"),
                handler: this.kickConnection,
                scope: this
            }, "->", this.searchField]
        })
    },
    getBBar: function() {
        if (this.pagingToolBar) return this.pagingToolBar;
        var e = new SYNO.ux.PagingToolbar({
            store: this.getStatusStore(),
            displayInfo: !0,
            pageSize: this.itemsPerPage,
            refreshText: _T("log", "log_reload")
        });
        return this.pagingToolBar = e, e
    },
    onActivate: function(e) {
        if (this.appWin.hasOpenConfig("is_cms_open") || e && e.targetReady) {
            var t = this.appWin.getTargetData();
            if (0 > t.id) return;
            "localhost" === t.target_type ? this.appWin.openConfig.cms_id = void 0 : "client" === t.target_type && (this.appWin.openConfig.cms_id = t.id)
        }
        var i = this.getTopToolbar(),
            n = this.getStore();
        this.getEl().mask(_T("common", "msg_waiting"), "x-mask-loading"), n.removeAll(), n.load(), this.getUpdateTask().stop(), this.getUpdateTask().start(), i.getComponent("bt_refresh").enable(), this.searchField.enable()
    },
    onDeactivate: function() {
        var e = this.getUpdateTask();
        e && e.stop()
    },
    onGridHeaderMouseDown: function(e, t) {
        0 === t && (this.multipleSort = !0)
    },
    onGridSortChanged: function(e, t) {
        if (!t || !t.field || "protocol" !== t.field) return void(e.store._multiSortInfo = void 0);
        if (this.multipleSort) {
            this.multipleSort = !1;
            var i = [{
                field: "protocol_desc",
                direction: t.direction
            }, {
                field: "transfer_type",
                direction: "DESC"
            }];
            e.store.sort(i, "ASC"), e.store._multiSortInfo = i
        }
    },
    refresh: function() {
        this.pagingToolBar.doRefresh()
    },
    getUpdateTask: function() {
        return this.updateTask = this.updateTask || this.addTask({
            id: "task_update_status",
            interval: 1e4,
            run: this.refresh,
            scope: this
        }), this.updateTask
    },
    onChangeItemsPerPage: function() {
        var e = this.itemsPerPageComb.getValue();
        e !== this.itemsPerPage && (this.itemsPerPage = e, this.pagingToolBar.pageSize = e, this.searchField.pageSize = e, this.pagingToolBar.moveFirst(), this.appInst.setUserSettings("bwstatusItemsPage", this.itemsPerPage))
    },
    getStatusStore: function() {
        return this.store ? this.store : (this.store = new SYNO.API.Store({
            autoLoad: !1,
            api: "SYNO.Core.BandwidthControl.Status",
            method: "list",
            version: 1,
            appWindow: this.appWin,
            baseParams: {
                offset: 0,
                limit: this.itemsPerPage
            },
            reader: new Ext.data.JsonReader({
                root: "status",
                totalProperty: "total"
            }, ["pid", "protocol", "owner_type", "name", "transfer_type", "filename", "speed", "speed_limit", "progress", "protocol_desc"]),
            sortInfo: {
                field: "owner_type",
                direction: "DESC"
            },
            listeners: {
                scope: this,
                load: function(e, t) {
                    Ext.each(t, function(e) {
                        var t = e.get("protocol"),
                            i = this.getProtocolDesc(t);
                        e.set("protocol_desc", i)
                    }, this), e.commitChanges(), e._multiSortInfo && e.sort(e._multiSortInfo, "ASC"), this.getEl().unmask()
                }
            },
            remoteSort: !1
        }), this.appWin.addManagedComponent(this.store), this.store)
    },
    getStatusCM: function() {
        if (this.cm) return this.cm;
        var e = new Ext.grid.ColumnModel({
            columns: [{
                header: _T("bandwidth", "bandwidth_protocol"),
                dataIndex: "protocol",
                width: 150,
                renderer: this.protocolRender,
                scope: this
            }, {
                header: _T("bandwidth", "bandwidth_owner_type"),
                dataIndex: "owner_type",
                width: 10,
                hidden: !0
            }, {
                header: _T("bandwidth", "bandwidth_account_name"),
                dataIndex: "name",
                width: 120,
                renderer: this.accountNameRender
            }, {
                header: _T("bandwidth", "bandwidth_transfer_type"),
                dataIndex: "transfer_type",
                width: 10,
                hidden: !0
            }, {
                header: _T("bandwidth", "bandwidth_filename"),
                dataIndex: "filename",
                width: 120,
                renderer: this.htmlEncodeRender
            }, {
                header: _T("bandwidth", "bandwidth_transfer_speed") + " (KB/s)",
                dataIndex: "speed",
                width: 100
            }, {
                header: _T("bandwidth", "bandwidth_transfer_speed_limit") + " (KB/s)",
                dataIndex: "speed_limit",
                width: 100
            }, {
                header: _T("bandwidth", "bandwidth_progress") + " (%)",
                dataIndex: "progress",
                width: 100
            }],
            defaults: {
                sortable: !0,
                menuDisabled: !0,
                align: "left"
            }
        });
        return this.cm = e, e
    },
    getProtocolDesc: function(e) {
        var t = "Unknown";
        return "FileStation" === e ? t = "File Station" : "WebDAV" === e ? t = "WebDAV" : "FTP" === e ? t = "FTP" : "NetworkBackup" === e && (t = "Rsync"), t
    },
    protocolRender: function(e, t, i) {
        var n = i.get("transfer_type"),
            o = this.getProtocolDesc(e),
            a = '<img src="webman/modules/BandwidthControl/images/1x/icon_download_queue.png" />';
        return "upload" === n && (a = '<img src="webman/modules/BandwidthControl/images/1x/icon_upload_queue.png" />'), a + " " + o
    },
    htmlEncodeRender: function(e, t) {
        var i = Ext.util.Format.htmlEncode(e);
        return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(i) + '"', i
    },
    accountNameRender: function(e, t, i) {
        var n = i.get("owner_type"),
            o = '<img src="webman/modules/BandwidthControl/images/1x/Group.png" />';
        return "user" === n && (o = '<img src="webman/modules/BandwidthControl/images/1x/User.png" />'), o + " " + e
    },
    showGridCtxMenu: function(e, t, i) {
        if (_S("is_admin")) {
            i.preventDefault();
            var n = e.getSelectionModel();
            n.isSelected(t) || n.selectRow(t), this.getGridCtxMenu().showAt(i.getXY())
        }
    },
    getGridCtxMenu: function() {
        return this.BWStatusRowCtxMenu || (this.BWStatusRowCtxMenu = new SYNO.ux.Menu({
            ignoreParentClicks: !0,
            items: [{
                itemId: "kick_conn1",
                text: _T("connections", "kick_connection"),
                handler: this.kickConnection,
                scope: this
            }]
        }), this.appWin.addManagedComponent(this.BWStatusRowCtxMenu)), this.BWStatusRowCtxMenu
    },
    kickConnection: function() {
        var e = this.getSelectionModel(),
            t = e.getSelections();
        if (0 !== t.length) {
            for (var i = [], n = 0; n < t.length; ++n) "-" !== t[n].get("pid") && i.push({
                pid: t[n].get("pid"),
                name: t[n].get("name"),
                transfer_type: t[n].get("transfer_type")
            });
            this.doKickConnection(i)
        }
    },
    doKickConnection: function(e) {
        this.getEl().mask(_T("common", "msg_waiting"), "x-mask-loading"), this.appWin.sendWebAPI({
            api: "SYNO.Core.BandwidthControl.Status",
            method: "delete",
            version: 1,
            single: !0,
            timeout: 45e4,
            params: {
                pid: e
            },
            scope: this,
            callback: function(e) {
                this.getEl().unmask(), this.pagingToolBar.doRefresh()
            }
        })
    },
    updateToolBarBts: function(e) {
        var t = 0,
            i = e.getSelections(),
            n = this.getTopToolbar(),
            o = n.getComponent("bt_kick1"),
            a = this.getGridCtxMenu().get("kick_conn1");
        if (0 === i.length || _S("demo_mode")) return o.disable(), void a.disable();
        for (t = 0; t < i.length && "group" !== i[t].get("owner_type"); ++t);
        t >= i.length ? (o.enable(), a.enable()) : (o.disable(), a.disable())
    }
});
