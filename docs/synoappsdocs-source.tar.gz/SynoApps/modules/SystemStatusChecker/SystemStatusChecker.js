/* Copyright (c) 2020 Synology Inc. All rights reserved. */

 /**
 * @class SYNO.SDS.SystemStatusChecker.Instance
 * @extends SYNO.SDS.AppInstance
 * SystemStatusChecker application instance class
 *
 */  
Ext.define("SYNO.SDS.SystemStatusChecker.Instance", {
    extend: "SYNO.SDS.AppInstance",
    initInstance: function(a) {
        if (!this.win) {
            this.win = new SYNO.SDS.Window({
                appInstance: this
            });
            this.addInstance(this.win);
            this.askSystemStatus()
        }
    },
    askSystemStatus: function() {
        this.sendWebAPI({
            api: "SYNO.Core.System.Status",
            method: "get",
            version: 1,
            scope: this,
            callback: function(b, a) {
                if (!b) {
                    SYNO.Debug.error("[Error]: ", a)
                } else {
                    this.checkSystemStatus(a)
                }
            }
        })
    },
    checkSystemStatus: function(a) {
        if (a.is_system_crashed) {
            SYNO.SDS.SystemStatusChecker.Action.NotifySystemCrashed()
        }
        if (a.show_beep_panel) {
            SYNO.SDS.SystemStatusChecker.Action.LaunchBeepModule()
        }
        if (a.upgrade_ready) {
            SYNO.SDS.SystemStatusChecker.Action.LaunchUpgradeModule()
        }
        SYNO.SDS.SystemStatusChecker.Action.NotifyBeep(a)
    }
});
Ext.define("SYNO.SDS.SystemStatusChecker.Action", {
    statics: {
        GetMsgBox: function() {
            return new SYNO.SDS.MessageBoxV5({
                modal: true,
                draggable: false,
                renderTo: document.body,
                isAlwaysOnTop: function() {
                    return true
                }
            })
        },
        SystemStatusListGen: function(c, b, e) {
            var h;
            var g = c;
            var j = g.split("&");
            var d = "";
            for (var f = 0; f < j.length; f++) {
                if (b === "volRender") {
                    var a = SYNO.SDS.Utils.StorageUtils.SpaceIDParser(j[f]);
                    h = a.str
                } else {
                    if (b === "failed_fan_only_one") {
                        h = _T("system", "system_fan")
                    } else {
                        if (b === "cpu_failed_fan") {
                            h = _T("system", "cpu_fan")
                        } else {
                            h = b + j[f]
                        }
                    }
                }
                d += h + _T("common", "colon") + " " + e + "<br>"
            }
            return d
        },
        NotifySystemCrashed: function() {
            SYNO.SDS.SystemTray.notifyMsg("", _T("error", "error_system_abnormal_warning"), _T("error", "error_system_abnormal_steps"), 0, false)
        },
        NotifyDiskWcacheCrashed: function() {
            var c = "";
            var j = (SYNO.SDS.UserSettings.getProperty("Desktop", "HDDWCacheCrash") === true) ? true : false;
            if (!j) {
                var g = Ext.id();
                var h = Ext.id();
                var a = "<a id = '" + h + '\' class="pathlink"">' + _T("smart", "cache_management") + "</a>";
                c += _T("sata", "sata_wcachecrashed_detect") + "<br><br>";
                c += _T("sata", "sata_wcachecrashed_firmware_update").replace("@", a);
                c += "<br><br><input type='checkbox' id='" + g + "' autocomplete='off' class=' x-form-checkbox x-form-field'>";
                c += "<label class='x-form-cb-label' style='top: -2px;'>" + _WFT("java", "java_not_remind") + "</label>";
                var i = SYNO.SDS.SystemTray.notifyMsg("", _T("sata", "sata_wcachecrashed_title"), c, 0, false);
                var e = Ext.get(h);
                var f = function() {
                    SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance", {
                        tabname: "disk",
                        isCache: true
                    })
                };
                e.on("click", f, this);
                var b = Ext.get(g);
                var d = function() {
                    SYNO.SDS.UserSettings.setProperty("Desktop", "HDDWCacheCrash", true)
                };
                b.on("click", d, this);
                i.mon(i, "destory", function() {
                    e.un("click", f, this);
                    b.un("click", d, this)
                }, this)
            }
        },
        NotifyBeep: function(b) {
            var a = "";
            if (b.failed_fan) {
                a += this.SystemStatusListGen(b.failed_fan, _T("system", "system_fan"), _T("pkgmgr", "pkgmgr_pkg_stop"))
            }
            if (b.failed_fan_only_one) {
                a += this.SystemStatusListGen(b.failed_fan_only_one, "failed_fan_only_one", _T("pkgmgr", "pkgmgr_pkg_stop"))
            }
            if (b.cpu_failed_fan) {
                a += this.SystemStatusListGen(b.cpu_failed_fan, "cpu_failed_fan", _T("pkgmgr", "pkgmgr_pkg_stop"))
            }
            if (b.degrade_vol) {
                a += this.SystemStatusListGen(b.degrade_vol, "volRender", _T("volume", "volume_status_degrade"));
                SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance")
            }
            if (b.crashed_vol && !_S("ha_safemode")) {
                a += this.SystemStatusListGen(b.crashed_vol, "volRender", _T("volume", "volume_status_crashed"));
                SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance")
            }
            if (b.readonly_vol && !_S("ha_safemode")) {
                a += this.SystemStatusListGen(b.readonly_vol, "volRender", _T("volume", "volume_status_ro"));
                SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance")
            }
            if (b.creating_vol) {
                this.GetMsgBox().confirm(_T("volume", "storage_manager"), _T("volume", "volume_status_creating"), function(c) {
                    if ("yes" === c) {
                        SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance")
                    }
                }, this)
            } else {
                if (b.building_vol) {
                    this.GetMsgBox().confirm(_T("volume", "storage_manager"), _T("volume", "volume_status_background_rebuilding"), function(c) {
                        if ("yes" === c) {
                            SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance")
                        }
                    }, this)
                } else {
                    if (b.vol_done) {
                        this.GetMsgBox().alert(_T("volume", "storage_manager"), _T("volume", "volume_status_can_use"))
                    }
                }
            }
            if (b.failed_power) {
                a += this.SystemStatusListGen(b.failed_power, _T("system", "power_supply"), _T("common", "status_abnormal"))
            }
            if (!Ext.isEmpty(a)) {
                SYNO.SDS.SystemTray.notifyMsg("", _T("system", "system_beep_remind"), a, 0, false)
            }
        },
        LaunchBeepModule: function() {
            SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                fn: "SYNO.SDS.AdminCenter.HardwareControl.Main",
                beepWarn: true
            })
        },
        LaunchUpgradeModule: function() {
            SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                fn: "SYNO.SDS.AdminCenter.Update_Reset.Main"
            })
        }
    }
});
