/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.HotkeyMgr.DesktopPanel
 * @extends SYNO.ux.FormPanel
 * HotkeyMgr desktop panel class
 *
 */
Ext.define("SYNO.SDS.HotkeyMgr.DesktopPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(a) {
        this.owner = a.owner;
        var b = {
            items: this.getTipConf(),
            defaults: {
                listeners: {
                    afterrender: this.renderHotkeyLabel,
                    scope: this
                }
            }
        };
        Ext.apply(b, a);
        this.callParent([b]);
        this.on("afterrender", this.createEnableGroup, this)
    },
    createEnableGroup: function() {
        var a;
        a = new SYNO.ux.Utils.EnableCheckGroup(this.getForm(), "enable_hotkey_check", this.getDescFieldNames())
    },
    getDescFieldNames: function() {
        var b = this.getTipConf();
        var a = [];
        Ext.each(b, function(c) {
            if (c.xtype === "syno_displayfield" && c.name) {
                a.push(c.name)
            }
        });
        return a
    },
    renderHotkeyLabel: function(b) {
        var a = SYNO.SDS.HotkeyMgr.Utils.getColoredLabel(b.fieldLabel, "+");
        b.label.update(a)
    },
    getTipConf: function() {
        var b = SYNO.SDS.UserSettings.getProperty("Desktop", "hotkey_disabled");
        var a = [{
            xtype: "syno_checkbox",
            boxLabel: _T("hotkey_manager", "enable_desktop_hotkeys"),
            name: "enable_hotkey_check",
            checked: (b === true) ? false : true,
            listeners: {
                check: function(d, c) {
                    this.enableDesktopHotkey(c)
                },
                scope: this
            }
        }, {
            xtype: "syno_displayfield",
            fieldLabel: "Shift + ?",
            name: "luanch_manager",
            value: _T("hotkey_manager", "luanch_manager")
        }, {
            xtype: "syno_displayfield",
            fieldLabel: "Alt + W",
            name: "switch_win_desc",
            value: _T("hotkey_manager", "switch_active_window")
        }, {
            xtype: "syno_displayfield",
            fieldLabel: "Alt + Q",
            name: "toggle_win_desc",
            value: _T("hotkey_manager", "toggle_all_window")
        }, {
            xtype: "syno_displayfield",
            fieldLabel: "Alt + A",
            name: "main_menu_desc",
            value: _T("hotkey_manager", "open_main_menu")
        }, {
            xtype: "syno_displayfield",
            fieldLabel: "Alt + S",
            name: "focus_desktop_desc",
            value: _T("hotkey_manager", "focus_desktop")
        }, {
            xtype: "syno_displayfield",
            fieldLabel: "Alt + H",
            name: "launch_help_desc",
            value: _T("hotkey_manager", "launch_help")
        }, {
            xtype: "syno_displayfield",
            fieldLabel: "Ctrl + F",
            name: "open_searchbox_desc",
            value: _T("hotkey_manager", "open_searchbox")
        }];
        return a
    },
    enableDesktopHotkey: function(a) {
        SYNO.SDS.Desktop.hotkeyPlugin.setHotkeyEnabled(a)
    }
});
Ext.define("SYNO.SDS.HotkeyMgr.CmpPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(a) {
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(a) {
        var b = {
            autoFlexcroll: true,
            store: this.getHotkeyStore(),
            cls: "component-hotkeypanel white-scrollerbar",
            listeners: {
                afterrender: this.onAfterRender,
                scope: this
            }
        };
        return Ext.apply(b, a)
    },
    onAfterRender: function() {
        this.getHotkeyStore().load()
    },
    getAbsoluteURL: function(a) {
        var b = String.format("{0}/{1}", this.owner.jsConfig.jsBaseURL, a);
        return b
    },
    getHotkeyStore: function() {
        if (this.hotkeyStore) {
            return this.hotkeyStore
        }
        this.hotkeyStore = new Ext.data.JsonStore({
            url: this.getAbsoluteURL("cmp_hotkey.json"),
            root: "components",
            fields: ["name", "keys"],
            idProperty: "name",
            listeners: {
                load: this.onKeyMapLoad,
                scope: this
            }
        });
        return this.hotkeyStore
    },
    initColModel: function() {
        var a = new Ext.grid.ColumnModel({
            columns: [{
                id: "keyname",
                header: _T("hotkey_manager", "key"),
                renderer: function(c) {
                    var e = SYNO.SDS.UIString.GetLocalizedString(c);
                    var b = (e.indexOf("+") > 0) ? "+" : "/";
                    var d = SYNO.SDS.HotkeyMgr.Utils.getColoredLabel(e, b);
                    return d
                }
            }, {
                id: "fn",
                header: _T("hotkey_manager", "fn"),
                renderer: function(b) {
                    return SYNO.SDS.UIString.GetLocalizedString(b)
                }
            }]
        });
        return a
    },
    onKeyMapLoad: function(b, e, h) {
        var d, f, c, a;
        var g = function(j, l) {
            var i = this,
                k = i.scroller.dom;
            if (!i.autoFlexcroll) {
                return
            }
            if (k.clientWidth === k.offsetWidth) {
                i.scrollOffset = 0
            } else {
                i.scrollOffset = undefined
            }
            this.fitColumns(false);
            i.updateScrollbar(k)
        };
        for (d = 0; d < e.length; d++) {
            f = e[d];
            c = new SYNO.ux.GridPanel({
                cls: "syno-hotkeymap-grid",
                title: SYNO.SDS.UIString.GetLocalizedString(f.get("name")),
                height: (f.get("keys").length + 1) * 28 + 14,
                view: new SYNO.ux.FleXcroll.grid.BufferView({
                    onLayout: g
                }),
                colModel: this.initColModel(),
                enableHdMenu: false,
                store: new Ext.data.JsonStore({
                    idProperty: "keyname",
                    fields: ["keyname", "fn"],
                    data: f.get("keys")
                })
            });
            a = new SYNO.ux.FieldSet({
                title: SYNO.SDS.UIString.GetLocalizedString(f.get("name")),
                collapsed: true,
                collapsible: true,
                items: c
            });
            this.add(a)
        }
        this.doLayout()
    }
});
SYNO.SDS.HotkeyMgr.Utils = {
    getColoredLabel: function(f, d) {
        var c = f.split(d);
        var a = c.length;
        var b, e = [];
        for (b = 0; b < a; b++) {
            e.push('<span class="key">' + c[b].trim() + "</span>")
        }
        return e.join(" " + d + " ")
    }
};
Ext.define("SYNO.SDS.HotkeyMgr.Instance", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.HotkeyMgr.Window"
});
Ext.define("SYNO.SDS.HotkeyMgr.Window", {
    extend: "SYNO.SDS.AppWindow",
    constructor: function(a) {
        this.callParent([this.fillConfig(a)]);
        this.on("show", this.alignCenter, this);
        Ext.EventManager.onWindowResize(this.alignCenter, this);
        this.registerCloseEvents()
    },
    registerCloseEvents: function() {
        this.mon(Ext.getDoc(), "mousedown", this.onMouseDown, this);
        this.on("deactivate", this.onWinDeactivate, this)
    },
    fillConfig: function(a) {
        this.tabPanel = new SYNO.ux.TabPanel({
            activeItem: 0,
            items: [this.desktopPanel = new SYNO.SDS.HotkeyMgr.DesktopPanel({
                title: _T("hotkey_manager", "desktop_hotkey"),
                useGradient: false
            }), this.compPanel = new SYNO.SDS.HotkeyMgr.CmpPanel({
                title: _T("hotkey_manager", "cmp_hotkey"),
                useGradient: false,
                appWindow: this,
                owner: this
            })]
        });
        return Ext.apply({
            width: 680,
            height: 580,
            showHelp: false,
            minimizable: false,
            maximizable: false,
            toggleMinimizable: false,
            autoRestoreSizePos: false,
            resizable: false,
            draggable: false,
            layout: "fit",
            cls: "hotkey-manager",
            items: [this.tabPanel]
        }, a)
    },
    onOpen: function(a) {
        this.openTarget = a.target;
        this.callParent(arguments)
    },
    onRequest: function(a) {
        this.openTarget = a.target;
        this.callParent(arguments)
    },
    onMouseDown: function(a) {
        if (!a.within(this.el)) {
            this.onWinDeactivate()
        }
    },
    onWinDeactivate: function() {
        this.onClose();
        this.close()
    },
    onClose: function() {
        if (this.openTarget) {
            this.openTarget.focus()
        }
    },
    alignCenter: function() {
        this.el.alignTo(Ext.getBody(), "c-c", [0, 20])
    },
    destroy: function() {
        Ext.EventManager.removeResizeListener(this.alignCenter, this);
        SYNO.SDS.HotkeyMgr.Window.superclass.destroy.apply(this, arguments)
    }
});
