/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.Utils.SharingManager.SharingDateDialog
 * @extends SYNO.SDS.ModalWindow
 * SharingManager date dialog class
 *
 */
Ext.define("SYNO.SDS.Utils.SharingManager.SharingDateDialog", {
    extend: "SYNO.SDS.ModalWindow",
    oriValue: null,
    constructor: function(a) {
        this.formPanel = this.createFormPanel(a);
        var b = {
            width: 480,
            height: 430,
            resizable: false,
            collapsible: false,
            layout: "fit",
            title: _T("sharing", "customize_duration"),
            buttons: [{
                text: _T("common", "close"),
                scope: this,
                handler: this.close
            }, {
                text: _T("common", "save"),
                btnStyle: "blue",
                scope: this,
                handler: this.onSaveBtn
            }],
            items: [this.formPanel]
        };
        Ext.apply(b, a);
        this.callParent([b])
    },
    createFormPanel: function(a) {
        return new SYNO.ux.FormPanel({
            defaults: {
                anchor: "100%"
            },
            updateFormForScrollbar: true,
            items: [{
                xtype: "syno_checkbox",
                name: "start_at_enable",
                boxLabel: _T("sharing", "enable_start_at"),
                listeners: {
                    scope: this,
                    check: function(e, d) {
                        var c = this.formPanel.getComponent("start_at_date");
                        var b = this.formPanel.getComponent("start_at_time");
                        if (d) {
                            c.enable();
                            b.enable()
                        } else {
                            c.disable();
                            b.disable()
                        }
                    }
                }
            }, {
                xtype: "syno_datefield",
                name: "start_at_date",
                itemId: "start_at_date",
                editable: false,
                disabled: true,
                format: SYNO.SDS.DateTimeUtils.GetDateFormat(),
                indent: 1,
                allowBlank: false,
                fieldLabel: _T("sharing", "start_at_date"),
                listeners: {
                    select: this.onSelectStartDate,
                    scope: this
                }
            }, {
                xtype: "syno_timefield",
                name: "start_at_time",
                itemId: "start_at_time",
                editable: false,
                disabled: true,
                format: SYNO.SDS.DateTimeUtils.GetTimeSecFormat(),
                indent: 1,
                fieldLabel: _T("sharing", "start_at_time"),
                validator: this.isValidTime.createDelegate(this)
            }, {
                xtype: "syno_checkbox",
                name: "expire_at_enable",
                boxLabel: _T("sharing", "enable_expire_at"),
                listeners: {
                    scope: this,
                    check: function(e, d) {
                        var c = this.formPanel.getComponent("expire_at_date");
                        var b = this.formPanel.getComponent("expire_at_time");
                        if (d) {
                            c.enable();
                            b.enable()
                        } else {
                            c.disable();
                            b.disable()
                        }
                    }
                }
            }, {
                xtype: "syno_datefield",
                name: "expire_at_date",
                itemId: "expire_at_date",
                editable: false,
                disabled: true,
                minValue: new Date(),
                format: SYNO.SDS.DateTimeUtils.GetDateFormat(),
                indent: 1,
                allowBlank: false,
                fieldLabel: _T("sharing", "expire_at_date"),
                listeners: {
                    enable: this.onExpandExpireDate,
                    select: this.onSelectExpireDate,
                    scope: this
                }
            }, {
                xtype: "syno_timefield",
                name: "expire_at_time",
                itemId: "expire_at_time",
                minValue: "0:00",
                editable: false,
                disabled: true,
                format: SYNO.SDS.DateTimeUtils.GetTimeSecFormat(),
                indent: 1,
                fieldLabel: _T("sharing", "expire_at_time"),
                validator: this.isValidExpireTime.createDelegate(this),
                listeners: {
                    select: function() {
                        this.formPanel.getComponent("start_at_time").validate()
                    },
                    expand: function(d) {
                        var c = this.formPanel.getComponent("expire_at_date");
                        if (this.isToday(c.getValue())) {
                            var f = this.getMinExpiredDateTime();
                            var b = ("0" + f.getHours()).slice(-2),
                                e = ("0" + f.getMinutes()).slice(-2);
                            d.setMinValue(b + ":" + e)
                        }
                    },
                    scope: this
                }
            }, {
                xtype: "syno_checkbox",
                name: "expire_times_enable",
                boxLabel: _T("sharing", "enable_expire_times"),
                listeners: {
                    scope: this,
                    check: function(c, b) {
                        var d = this.formPanel.getComponent("expire_times");
                        if (b) {
                            d.enable()
                        } else {
                            d.disable()
                        }
                    }
                }
            }, {
                xtype: "syno_numberfield",
                name: "expire_times",
                itemId: "expire_times",
                disabled: true,
                indent: 1,
                minValue: 0,
                maxlength: 4,
                value: 0,
                vtype: "number",
                fieldLabel: _T("sharing", "remaining_times")
            }]
        })
    },
    setValues: function(a) {
        this.formPanel.getForm().setValues(a);
        this.oriValue = this.getValues()
    },
    getValues: function() {
        var a = this.formPanel.getForm().getValues();
        a.expire_at_enable = "true" === a.expire_at_enable;
        a.start_at_enable = "true" === a.start_at_enable;
        a.expire_times_enable = "true" === a.expire_times_enable;
        a.expire_times = parseInt(a.expire_times, 10);
        return a
    },
    getFinalValues: function() {
        return this.oriValue
    },
    isValid: function() {
        return this.formPanel.getForm().isValid()
    },
    onSaveBtn: function() {
        if (!this.isValid()) {
            this.getMsgBox().alert("", _T("common", "forminvalid"));
            return
        }
        this.oriValue = this.getValues();
        this.close()
    },
    onSelectStartDate: function(d, c) {
        var e = this.formPanel.getComponent("expire_at_date");
        var a = this.formPanel.getComponent("start_at_time");
        var b = new Date();
        if (c > b) {
            e.setMinValue(c)
        } else {
            e.setMinValue(b)
        }
        if ("" === a.getValue()) {
            a.setValue("0:00")
        }
        this.formPanel.getComponent("start_at_time").validate()
    },
    onExpandExpireDate: function(d) {
        var b = this.formPanel.getComponent("start_at_date");
        var e = this.formPanel.getComponent("expire_at_date");
        var a = b.getValue(),
            c = new Date();
        if (a > c) {
            e.setMinValue(a)
        } else {
            e.setMinValue(c)
        }
    },
    onSelectExpireDate: function(c, b) {
        var d = this.formPanel.getComponent("expire_at_time");
        if (this.isToday(b)) {
            var e = this.getMinExpiredDateTime();
            var a = this.getDateObj(c.getValue(), d.getValue());
            if (a < e) {
                d.setValue(e)
            }
            d.setMinValue(e)
        } else {
            d.setMinValue("0:00")
        }
        if ("" === d.getValue()) {
            d.setValue("0:00")
        }
        this.formPanel.getComponent("start_at_time").validate()
    },
    isValidTime: function() {
        var f = this.formPanel.getComponent("start_at_date");
        var e = this.formPanel.getComponent("expire_at_date");
        if (!f || !e) {
            return true
        }
        if (this.isSameDate(f.getValue(), e.getValue())) {
            var d = this.formPanel.getComponent("start_at_time"),
                c = this.formPanel.getComponent("expire_at_time"),
                a = this.getDateObj(f.getValue(), d.getValue()),
                b = this.getDateObj(e.getValue(), c.getValue());
            if (a < b) {
                return true
            } else {
                return String.format(_T("sharing", "time_set_error"), _T("sharing", "start_at_time"), _T("sharing", "expire_at_time"))
            }
        } else {
            return true
        }
    },
    isValidExpireTime: function() {
        var c = this.formPanel.getComponent("expire_at_date"),
            b = this.formPanel.getComponent("expire_at_time"),
            a = this.getDateObj(c.getValue(), b.getValue());
        if (this.isToday(c.getValue()) && a < this.getMinExpiredDateTime()) {
            return String.format(_JSLIBSTR("extlang", "invalidtime"), b.getValue())
        }
        return true
    },
    isSameDate: function(b, a) {
        if (!b || !a) {
            return false
        }
        return b.getYear() == a.getYear() && b.getMonth() == a.getMonth() && b.getDate() == a.getDate()
    },
    isToday: function(b) {
        var a = new Date();
        return this.isSameDate(a, b)
    },
    getDateObj: function(a, c) {
        var b = a.format("Y-m-d");
        if ("" !== c) {
            b += (Ext.isIE || Ext.isIE11) ? "T" : " ";
            b += c
        }
        return new Date(b)
    },
    getMinExpiredDateTime: function() {
        var d = new Date(),
            a = d.getHours(),
            c = d.getMinutes(),
            b = 15;
        c = Math.ceil(c / b) * b;
        if (60 === c) {
            c = 0;
            a++;
            if (a == 24) {
                return this.getDateObj(d, "23:59")
            }
        }
        return this.getDateObj(d, a + ":" + c)
    }
});
Ext.define("SYNO.SDS.Utils.SharingManager.EditSharingDialog", {
    extend: "SYNO.SDS.ModalWindow",
    params: null,
    oriValue: null,
    deleteWhenCancel: null,
    fakePwd: "1234567890",
    webapi: {
        set: {
            api: "SYNO.Core.Sharing",
            method: "set",
            version: 1
        }
    },
    constructor: function(a) {
        this.formPanel = this.createFormPanel(a);
        this.actionGroup = this.createActionGroup();
        this.tbar = this.createTBar();
        this.params = {};
        Ext.apply(this.params, a.params);
        delete a.params;
        this.sharingDateObj = {};
        var b = {
            cls: "syno-sharing-manager-edit-sharing-dialog",
            width: 700,
            height: 500,
            resizable: false,
            collapsible: false,
            layout: "fit",
            title: _T("sharing", "sharing_links"),
            closeAction: "onCloseBtn",
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: this.onCloseBtn
            }, {
                text: _T("common", "save"),
                btnStyle: "blue",
                scope: this,
                handler: this.onSaveBtn
            }],
            listeners: {
                scope: this,
                afterrender: this.onAfterRender
            },
            items: [this.formPanel]
        };
        Ext.apply(b, a);
        this.callParent([b])
    },
    getSharingLinkDisplayFieldConfig: function(a) {
        return {
            xtype: "syno_displayfield",
            hideLabel: true,
            value: String.format(_T("sharing", "full_instruction"), '<a class="pathlink" tabIndex="0">' + _T("common", "buildin_mail") + "</a>", '<a class="pathlink" tabIndex="0">' + _T("common", "mail") + "</a>"),
            htmlEncode: false,
            listeners: {
                render: function(c) {
                    var b = c.el.child("a:nth-child(1)");
                    var d = c.el.child("a:nth-child(2)");
                    this.mon(b, "click", this.onBuildInMail, this);
                    this.mon(d, "click", this.onMail, this);
                    b.addKeyListener(Ext.EventObject.SPACE, this.onBuildInMail, this);
                    b.addKeyListener(Ext.EventObject.ENTER, this.onBuildInMail, this);
                    d.addKeyListener(Ext.EventObject.SPACE, this.onMail, this);
                    d.addKeyListener(Ext.EventObject.ENTER, this.onMail, this)
                },
                scope: this,
                single: true,
                buffer: 80
            }
        }
    },
    getSharingLinkTextAreaConfig: function(a) {
        return {
            xtype: "syno_textarea",
            name: "url",
            readOnly: true,
            autoFlexcroll: true,
            selectOnFocus: true,
            fieldLabel: _T("sharing", "sharing_link")
        }
    },
    getUserStore: function(a) {
        var b = new SYNO.API.JsonStore({
            autoDestroy: true,
            api: "SYNO.Core.ACL",
            method: "list_owners",
            version: 1,
            root: "owners",
            appWindow: a.owner,
            idProperty: "value",
            fields: ["name", "type", {
                name: "value",
                convert: function(d, c) {
                    return c.name + ":" + c.type
                }
            }],
            remoteSort: true,
            pruneModifiedRecords: true,
            baseParams: {
                type: "all"
            }
        });
        return b
    },
    getSecurityFieldConfigs: function(b) {
        var d = this.getUserStore(b);
        var f = new Ext.XTemplate('<tpl for=".">', '<div class="x-combo-list-item acl-icon-combo-item acl-combo-item-{type}" id="{[Ext.id()]}" aria-label="{name:htmlEncode}" role="option">{name}</div>', "</tpl>");
        var a = new Ext.XTemplate('<div class="acl-icon-combo-item acl-combo-item-{type} sharing-combo-item-{type}" id="{[Ext.id()]}" aria-label="{name:htmlEncode}" role="option">{name}</div>');
        var e = _S("is_admin") || b.enableListUserGrp;
        var c = new SYNO.ux.FieldSet({
            itemId: "secure_fieldset",
            disabled: true,
            defaults: {
                anchor: "100%"
            },
            items: [{
                xtype: "syno_radio",
                name: "protect_type",
                tabIndex: -1,
                inputValue: "user",
                boxLabel: _T("sharing", "share_dsm_user"),
                listeners: {
                    scope: this,
                    check: function(i, h) {
                        var g = c.getComponent("protect_users_groups");
                        if (h) {
                            g.enable()
                        } else {
                            g.disable()
                        }
                    }
                }
            }, {
                xtype: "syno_superboxselect",
                name: "protect_users_groups",
                itemId: "protect_users_groups",
                indent: 1,
                tabIndex: -1,
                valueField: "value",
                displayField: "name",
                displayFieldTpl: a,
                tpl: f,
                triggerAction: "all",
                mode: (e) ? "remote" : "local",
                queryParam: "prefix",
                minChars: 2,
                allowQueryAll: e,
                listEmptyText: e ? _T("error", "error_invalid_user_group") : "",
                pageSize: 50,
                disabled: true,
                editable: true,
                allowBlank: false,
                blankText: _T("sharing", "dsm_user_alert"),
                grow: true,
                typeAhead: true,
                allowAddNewData: true,
                addNewDataOnBlur: true,
                store: d,
                fieldLabel: _T("helptoc", "personal_account"),
                listeners: {
                    listInitialized: function() {
                        this.mon(d, "load", this.onUserStoreLoad, this)
                    },
                    scope: this
                }
            }, {
                xtype: "syno_radio",
                name: "protect_type",
                inputValue: "password",
                tabIndex: -1,
                boxLabel: _T("sharing", "share_public_user"),
                listeners: {
                    scope: this,
                    check: function(h, g) {
                        var i = c.getComponent("protect_password");
                        if (g) {
                            i.enable()
                        } else {
                            i.disable()
                        }
                    }
                }
            }, {
                xtype: "syno_textfield",
                name: "protect_password",
                itemId: "protect_password",
                tabIndex: -1,
                indent: 1,
                disabled: true,
                allowBlank: false,
                textType: "password",
                fieldLabel: _T("sharing", "enter_password"),
                listeners: {
                    scope: this,
                    focus: this.onProtectPasswordFocus
                }
            }]
        });
        return [{
            xtype: "syno_checkbox",
            name: "protect_type_enable",
            boxLabel: _T("sharing", "restrict_sharing"),
            tabIndex: -1,
            listeners: {
                scope: this,
                check: function(i, h) {
                    var g = c.find("name", "protect_type");
                    if (h) {
                        c.enable();
                        if (!g.reduce(function(j, k) {
                                return j || k.checked
                            }, false)) {
                            g[0].setValue(true)
                        }
                    } else {
                        c.disable();
                        Ext.each(g, function(j) {
                            j.setValue(false)
                        })
                    }
                }
            }
        }, c]
    },
    getFormItemConfigs: function(a) {
        return [].concat(this.getSharingLinkDisplayFieldConfig(a)).concat(this.getSharingLinkTextAreaConfig(a)).concat(this.getSecurityFieldConfigs(a))
    },
    createFormPanel: function(a) {
        return new SYNO.ux.FormPanel({
            defaults: {
                anchor: "100%"
            },
            updateFormForScrollbar: true,
            items: this.getFormItemConfigs(a)
        })
    },
    createActionGroup: function() {
        return new SYNO.ux.Utils.ActionGroup([new Ext.Action({
            text: _T("sharing", "exp_after"),
            itemId: "validate_date",
            scope: this,
            handler: this.onValidateDateBtn
        }), new Ext.Action({
            text: _T("sharing", "get_qrcode"),
            tabindex: -1,
            itemId: "qrcode",
            scope: this,
            handler: this.onQRCodeBtn
        })])
    },
    createTBar: function() {
        return new SYNO.ux.Toolbar({
            style: {
                padding: "0 20px"
            },
            defaultType: "syno_button",
            items: [this.actionGroup.getArray()]
        })
    },
    setValues: function(a) {
        var b;
        if (a.expire_at) {
            b = Date.parseDate(a.expire_at, "Y-m-d H:i:s");
            this.sharingDateObj.expire_at_date = SYNO.SDS.DateTimeFormatter(b, {
                type: "date"
            });
            this.sharingDateObj.expire_at_time = SYNO.SDS.DateTimeFormatter(b, {
                type: "timesec"
            });
            this.sharingDateObj.expire_at_enable = true
        }
        if (a.start_at) {
            b = Date.parseDate(a.start_at, "Y-m-d H:i:s");
            this.sharingDateObj.start_at_date = SYNO.SDS.DateTimeFormatter(b, {
                type: "date"
            });
            this.sharingDateObj.start_at_time = SYNO.SDS.DateTimeFormatter(b, {
                type: "timesec"
            });
            this.sharingDateObj.start_at_enable = true
        }
        if (a.expire_times) {
            this.sharingDateObj.expire_times = a.expire_times;
            this.sharingDateObj.expire_times_enable = true
        }
        if (a.protect_type && "none" !== a.protect_type) {
            a.protect_type_enable = true
        }
        if ("password" === a.protect_type) {
            a.protect_password = this.fakePwd
        }
        var c = this.formPanel.getComponent("secure_fieldset").getComponent("protect_users_groups");
        c.enable();
        if (a.protect_users || a.protect_groups) {
            a.protect_users_groups = [];
            if (a.protect_users) {
                Ext.each(a.protect_users, function(d) {
                    a.protect_users_groups.push(d + ":user");
                    c.addNewItem({
                        name: Ext.util.Format.htmlEncode(d),
                        type: "user",
                        value: d + ":user"
                    })
                })
            }
            if (a.protect_groups) {
                Ext.each(a.protect_groups, function(d) {
                    a.protect_users_groups.push(d + ":group");
                    c.addNewItem({
                        name: Ext.util.Format.htmlEncode(d),
                        type: "group",
                        value: d + ":group"
                    })
                })
            }
        }
        c.disable();
        this.isProtectPasswordEdited = false;
        this.params.app = (undefined !== this.params.app) ? this.params.app : {};
        this.params.project_name = (undefined !== this.params.project_name) ? this.params.project_name : "";
        this.params.sharing_id = a.hash;
        Ext.apply(this.params.app, a.app);
        this.params.redirect_type = (undefined !== this.params.redirect_type) ? this.params.redirect_type : a.redirect_type;
        this.params.redirect_uri = (undefined !== this.params.redirect_uri) ? this.params.redirect_uri : a.redirect_uri;
        this.params.auto_gc = (undefined !== this.params.auto_gc) ? this.params.auto_gc : a.auto_gc;
        this.params.enable_match_ip = (undefined !== this.params.enable_match_ip) ? this.params.enable_match_ip : a.enable_match_ip;
        this.params.enabled = (undefined !== this.params.enabled) ? this.params.enabled : a.enabled;
        this.params.url = a.url;
        this.params.qrcode = a.qrcode;
        a.url = (Ext.isArray(a.url)) ? a.url.join("\n") : a.url;
        this.formPanel.getForm().setValues(a);
        this.oriValue = this.getValues()
    },
    getValues: function() {
        var b = this.formPanel.getForm().getValues();
        var a, c;
        if (this.sharingDateObj.expire_at_enable) {
            a = Date.parseDate(this.sharingDateObj.expire_at_date, SYNO.SDS.DateTimeUtils.GetDateFormat()).format("Y-m-d");
            if (this.sharingDateObj.expire_at_time) {
                a += " " + Date.parseDate(this.sharingDateObj.expire_at_time, SYNO.SDS.DateTimeUtils.GetTimeSecFormat()).format("H:i:s")
            } else {
                a += " 23:59:59"
            }
            b.expire_at = a
        } else {
            b.expire_at = ""
        }
        if (this.sharingDateObj.start_at_enable) {
            a = Date.parseDate(this.sharingDateObj.start_at_date, SYNO.SDS.DateTimeUtils.GetDateFormat()).format("Y-m-d");
            if (this.sharingDateObj.start_at_time) {
                a += " " + Date.parseDate(this.sharingDateObj.start_at_time, SYNO.SDS.DateTimeUtils.GetTimeSecFormat()).format("H:i:s")
            } else {
                a += " 00:00:00"
            }
            b.start_at = a
        } else {
            b.start_at = ""
        }
        if (this.sharingDateObj.expire_times_enable) {
            b.expire_times = this.sharingDateObj.expire_times
        } else {
            b.expire_times = 0
        }
        if ("true" !== b.protect_type_enable) {
            b.protect_type = "none"
        }
        if (b.protect_users_groups) {
            if (!Ext.isArray(b.protect_users_groups)) {
                b.protect_users_groups = [b.protect_users_groups]
            }
            b.protect_users = [];
            b.protect_groups = [];
            Ext.each(b.protect_users_groups, function(d) {
                if ((c = d.match(/(.*):user$/))) {
                    b.protect_users.push(c[1])
                } else {
                    if ((c = d.match(/(.*):group$/))) {
                        b.protect_groups.push(c[1])
                    }
                }
            })
        }
        if (!b.protect_password || ((this.fakePwd === b.protect_password) && !this.isProtectPasswordEdited)) {
            delete b.protect_password
        }
        if ("password" === b.protect_type && !b.protect_password) {
            delete b.protect_type
        }
        if (!b.redirect_uri) {
            delete b.redirect_uri
        }
        Ext.apply(b, this.params);
        return b
    },
    getFinalValues: function() {
        return this.oriValue
    },
    isValid: function() {
        return this.formPanel.getForm().isValid()
    },
    isUsersGroup: function(a) {
        if (!a) {
            return false
        }
        if ("guest" === a || "users" === a || a.match(/^users@.*/i) || a.match(/.*\\Domain Users$/i)) {
            return true
        }
        return false
    },
    handleErrors: function(c) {
        SYNO.Debug.error(c);
        this.setStatusError(_T("common", "error_system"));
        switch (c.code) {
            case 1009:
                var b = this.formPanel.getComponent("secure_fieldset").getComponent("protect_users_groups");
                b.markInvalid(_T("sharing", "error_entry_user"));
                break;
            case 1010:
                var a = this.formPanel.getComponent("secure_fieldset").getComponent("protect_password");
                a.markInvalid(_T("sharing", "error_entry_passwd"));
                break
        }
    },
    onUserComboNewItem: function(d, c) {
        if (!c || this.isUsersGroup(c)) {
            return
        }
        var b = ("@" === c[0]) ? "group" : "user";
        var a = ("@" === c[0]) ? c.substr(1, c.length) : c;
        d.addNewItem({
            name: Ext.util.Format.htmlEncode(a),
            type: b,
            value: a + ":" + b
        }, true)
    },
    onUserStoreLoad: function(b, a, d) {
        var e = this.formPanel.getComponent("secure_fieldset").getComponent("protect_users_groups"),
            c = e.pageTb;
        Ext.each(a, function(f) {
            if (this.isUsersGroup(f.data.name)) {
                b.remove(f)
            }
        }, this);
        if (this.disableLastPage === true && c.getPageData().activePage === this.lastPage - 1) {
            c.setBtnText(c.btn4, "");
            c.next.disable();
            c.last.disable()
        }
        if (b.getCount() <= 0) {
            this.disableLastPage = true;
            this.lastPage = c.getPageData().activePage;
            if (1 < this.lastPage) {
                c.jumpPageByOffset(-1)
            }
        }
    },
    onAfterRender: function() {
        var a = this.formPanel.getComponent("secure_fieldset").getComponent("protect_users_groups");
        if (!_S("is_admin")) {
            this.mon(a, "newitem", this.onUserComboNewItem, this)
        }
    },
    onProtectPasswordFocus: function(a) {
        a.setValue(null);
        this.isProtectPasswordEdited = true
    },
    onDateDialogClose: function(a) {
        this.sharingDateObj = a.getFinalValues()
    },
    onBuildInMail: function() {
        var b = "",
            c = this.getValues().url,
            a = this.getValues().qrcode;
        if (Ext.isArray(c)) {
            Ext.iterate(c, function(e, d) {
                b += this.getURLDiv(e, a[d])
            }, this)
        } else {
            b = this.getURLDiv(c, a)
        }
        SYNO.SDS.AppLaunch("SYNO.SDS.App.MailDialog.Application", {
            content: b
        })
    },
    getURLDiv: function(a, c) {
        var b = c ? '<img src="' + c + '"></img>' : "";
        return b + "<div>" + Ext.util.Format.htmlEncode(a) + "</div>"
    },
    onMail: function() {
        var a = this.getValues();
        var b = "My DS Shared File Links";
        var d = a.url;
        var c = "mailto:?subject=" + b + "&body=" + d;
        window.open(c, "_blank")
    },
    onSaveBtn: function() {
        if (!this.isValid()) {
            return
        }
        var a = this.getValues();
        if (SYNO.ux.Utils.checkObjectConsistency(a, this.oriValue)) {
            this.close();
            return
        }
        this.setStatusBusy();
        this.sendWebAPI(Ext.apply({
            params: a,
            scope: this,
            callback: function(e, c, d, b) {
                this.clearStatusBusy();
                if (!e) {
                    this.handleErrors(c)
                } else {
                    this.oriValue = a;
                    this.close()
                }
            }
        }, this.webapi.set))
    },
    onCloseBtn: function() {
        var a = this.getValues();
        if (this.deleteWhenCancel) {
            this.sendWebAPI({
                api: "SYNO.Core.Sharing",
                method: "delete",
                version: 1,
                params: {
                    sharing_id: a.sharing_id
                },
                scope: this,
                callback: function(e, c, d, b) {
                    if (!e) {
                        SYNO.Debug.error(c);
                        this.owner.getMsgBox().alert(_T("common", "share"), _T("common", "error_system"))
                    }
                    this.close()
                }
            })
        } else {
            this.close()
        }
    },
    onValidateDateBtn: function() {
        var a = new SYNO.SDS.Utils.SharingManager.SharingDateDialog({
            owner: this
        });
        a.setValues(this.sharingDateObj);
        a.open();
        this.mon(a, "close", this.onDateDialogClose, this)
    },
    onQRCodeBtn: function() {
        var a = this.getValues();
        var b = new SYNO.SDS.Utils.QRCodeDialog({
            owner: this,
            url: a.url,
            qrcode: a.qrcode
        });
        b.open()
    }
});
Ext.define("SYNO.SDS.Utils.SharingManager.CreateSharingDialog", {
    extend: "SYNO.SDS.Utils.SharingManager.EditSharingDialog",
    constructor: function() {
        this.callParent(arguments)
    },
    onGetSharingCallback: function(d, b, c, a) {
        this.clearStatusBusy();
        if (!d) {
            SYNO.Debug.error(b);
            this.owner.getMsgBox().alert(_T("common", "share"), _T("common", "error_system"));
            this.close();
            return
        }
        this.setValues(b);
        this.deleteWhenCancel = true
    },
    onCreateSharingCallback: function(d, b, c, a) {
        if (!d) {
            this.clearStatusBusy();
            SYNO.Debug.error(b);
            this.owner.getMsgBox().alert(_T("common", "share"), _T("common", "error_system"));
            this.close();
            return
        }
        this.sendWebAPI({
            api: "SYNO.Core.Sharing",
            method: "get",
            version: 1,
            params: {
                sharing_id: b.sharing_id
            },
            scope: this,
            callback: this.onGetSharingCallback
        })
    },
    onAfterRender: function() {
        this.callParent(arguments);
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Core.Sharing",
            method: "set",
            version: 1,
            params: this.params,
            scope: this,
            callback: this.onCreateSharingCallback
        })
    }
});
Ext.define("SYNO.SDS.Utils.SharingManager.SharingPanel", {
    extend: "SYNO.ux.GridPanel",
    pageSize: 50,
    constructor: function(a) {
        this.store = this.createStore(a);
        this.actionGroup = this.createActionGroup();
        this.tbar = this.createTBar();
        this.bbar = this.createBBar();
        var b = {
            trackResetOnLoad: false,
            title: _T("sharing", "sharing_all"),
            tbar: this.tbar,
            bbar: this.bbar,
            store: this.store,
            colModel: new Ext.grid.ColumnModel({
                columns: [{
                    header: _T("common", "user"),
                    dataIndex: "owner_user"
                }, {
                    header: String.format("hash"),
                    dataIndex: "hash"
                }]
            }),
            selModel: new Ext.grid.RowSelectionModel({
                listeners: {
                    scope: this,
                    selectionchange: this.onRowSelectionChange
                }
            }),
            listeners: {
                scope: this,
                beforedestroy: this.onBeforeDestroy,
                rowdblclick: this.onEditBtn
            }
        };
        Ext.apply(b, a);
        this.callParent([b])
    },
    createActionGroup: function() {
        return new SYNO.ux.Utils.ActionGroup([new Ext.Action({
            text: _T("common", "alt_edit"),
            itemId: "edit",
            disabled: true,
            scope: this,
            handler: this.onEditBtn
        }), new Ext.Action({
            text: _T("common", "delete"),
            itemId: "delete",
            disabled: true,
            scope: this,
            handler: this.onDeleteBtn
        }), new Ext.Action({
            text: _T("sharing", "clean_badlinks"),
            itemId: "gc",
            scope: this,
            handler: this.onGCBtn
        })])
    },
    createTBar: function() {
        return new SYNO.ux.Toolbar({
            defaultType: "syno_button",
            items: [this.actionGroup.getArray()]
        })
    },
    createBBar: function() {
        return new SYNO.ux.PagingToolbar({
            pageSize: this.pageSize,
            store: this.store,
            loadMask: true,
            displayInfo: true,
            showRefreshBtn: true
        })
    },
    createStore: function(b) {
        var a = ["app", "auto_gc", "enable_match_ip", "enabled", "expire_at", "expire_times", "hash", "owner_user", "project_name", "protect_groups", "protect_type", "protect_users", "redirect_type", "redirect_uri", "start_at", "use_count", "url", "qrcode"];
        return new SYNO.API.JsonStore({
            api: "SYNO.Core.Sharing",
            method: "list",
            version: 1,
            autoLoad: true,
            root: "sharings",
            appWindow: b.owner,
            fields: a,
            idProperty: "hash",
            baseParams: {
                offset: 0,
                limit: -1,
                project_name: b.params.project_name,
                all_entry: (b.params.all_entry) ? true : false
            }
        })
    },
    refreshPagingTool: function() {
        var a = this.getBottomToolbar();
        if (a) {
            a.doRefresh()
        }
    },
    doGC: function() {
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Core.Sharing",
            method: "trigger_gc",
            version: 1,
            params: {
                project_name: this.params.project_name,
                all_entry: (this.params.all_entry) ? true : false
            },
            scope: this,
            callback: function(d, b, c, a) {
                this.owner.clearStatusBusy();
                if (!d) {
                    SYNO.Debug.error(b);
                    this.owner.getMsgBox().alert(_T("common", "share"), _T("common", "error_system"))
                }
                this.refreshPagingTool()
            }
        })
    },
    doDelete: function(a) {
        this.owner.setStatusBusy();
        var b = a.map(function(c) {
            return {
                api: "SYNO.Core.Sharing",
                method: "delete",
                version: 1,
                params: {
                    sharing_id: c.data.hash
                }
            }
        });
        this.sendWebAPI({
            compound: {
                stopwhenerror: false,
                params: b
            },
            scope: this,
            callback: function(f, d, e, c) {
                this.owner.clearStatusBusy();
                if (!f) {
                    SYNO.Debug.error(d);
                    this.owner.getMsgBox().alert(_T("common", "share"), _T("common", "error_system"))
                }
                this.refreshPagingTool()
            }
        })
    },
    onBeforeDestroy: function() {
        this.store.destroy()
    },
    onRowSelectionChange: function() {
        var a = this.getSelectionModel().getSelections();
        this.actionGroup.get("delete").setDisabled(a.length === 0);
        this.actionGroup.get("edit").setDisabled(a.length !== 1)
    },
    onEditBtn: function() {
        var a = this.getSelectionModel().getSelected();
        if (!a) {
            return
        }
        var b = new SYNO.SDS.Utils.SharingManager.EditSharingDialog({
            owner: this.owner,
            params: this.params
        });
        b.setValues(a.data);
        b.open();
        this.mon(b, "close", this.refreshPagingTool, this)
    },
    onDeleteBtn: function() {
        var a = this.getSelectionModel().getSelections();
        if (a.length === 0) {
            return
        }
        var c = _T("common", "delete");
        var b = _T("sharing", "delete_confirm");
        this.owner.getMsgBox().confirmDelete(c, b, function(d) {
            if ("yes" === d) {
                this.doDelete(a)
            }
        }, this)
    },
    onGCBtn: function() {
        var b = _T("sharing", "clean_badlinks");
        var a = _T("sharing", "clean_confirm");
        this.owner.getMsgBox().confirmDelete(b, a, function(c) {
            if ("yes" === c) {
                this.doGC()
            }
        }, this)
    }
});
Ext.define("SYNO.SDS.Utils.SharingManager.SharingEntryDialog", {
    extend: "SYNO.SDS.ModalWindow",
    params: null,
    constructor: function(a) {
        this.formPanel = this.createFormPanel(a);
        this.params = {};
        Ext.apply(this.params, a.params);
        delete a.params;
        this.oriValue = {};
        var b = {
            width: 550,
            height: 350,
            resizable: false,
            collapsible: false,
            layout: "fit",
            title: _T("sharing", "sharing_link"),
            buttons: [{
                text: _T("common", "close"),
                scope: this,
                handler: this.close
            }],
            items: [this.formPanel]
        };
        Ext.apply(b, a);
        this.callParent([b])
    },
    createFormPanel: function(a) {
        return new SYNO.ux.FormPanel({
            defaults: {
                anchor: "100%"
            },
            updateFormForScrollbar: true,
            items: [{
                xtype: "syno_textarea",
                name: "url",
                readOnly: true,
                autoFlexcroll: true,
                selectOnFocus: true,
                fieldLabel: _T("sharing", "sharing_link")
            }, {
                xtype: "syno_datefield",
                name: "expire_at_date",
                disabled: true,
                format: SYNO.SDS.DateTimeUtils.GetDateFormat(),
                fieldLabel: _T("sharing", "expire_at_date")
            }, {
                xtype: "syno_timefield",
                name: "expire_at_time",
                disabled: true,
                format: SYNO.SDS.DateTimeUtils.GetTimeSecFormat(),
                fieldLabel: _T("sharing", "expire_at_time")
            }, {
                xtype: "syno_datefield",
                name: "start_at_date",
                disabled: true,
                format: SYNO.SDS.DateTimeUtils.GetDateFormat(),
                fieldLabel: _T("sharing", "start_at_date")
            }, {
                xtype: "syno_timefield",
                name: "start_at_time",
                disabled: true,
                format: SYNO.SDS.DateTimeUtils.GetTimeSecFormat(),
                fieldLabel: _T("sharing", "start_at_time")
            }, {
                xtype: "syno_numberfield",
                name: "expire_times",
                itemId: "expire_times",
                disabled: true,
                minValue: 0,
                value: 0,
                fieldLabel: _T("sharing", "expire_times")
            }]
        })
    },
    setValues: function(a) {
        var b;
        this.params.app = (undefined !== this.params.app) ? this.params.app : {};
        this.params.project_name = (undefined !== this.params.project_name) ? this.params.project_name : "";
        this.params.sharing_id = a.hash;
        Ext.apply(this.params.app, a.app);
        this.params.redirect_type = (undefined !== this.params.redirect_type) ? this.params.redirect_type : a.redirect_type;
        this.params.redirect_uri = (undefined !== this.params.redirect_uri) ? this.params.redirect_uri : a.redirect_uri;
        this.params.auto_gc = (undefined !== this.params.auto_gc) ? this.params.auto_gc : a.auto_gc;
        this.params.enable_match_ip = (undefined !== this.params.enable_match_ip) ? this.params.enable_match_ip : a.enable_match_ip;
        this.params.enabled = (undefined !== this.params.enabled) ? this.params.enabled : a.enabled;
        this.params.url = a.url;
        this.params.qrcode = a.qrcode;
        this.oriValue = {};
        Ext.apply(this.oriValue, a);
        Ext.apply(this.oriValue, this.params);
        if (this.oriValue.expire_at) {
            b = Date.parseDate(this.oriValue.expire_at, "Y-m-d H:i:s");
            this.oriValue.expire_at_date = SYNO.SDS.DateTimeFormatter(b, {
                type: "date"
            });
            this.oriValue.expire_at_time = SYNO.SDS.DateTimeFormatter(b, {
                type: "timesec"
            });
            this.oriValue.expire_at_enable = true
        }
        if (this.oriValue.start_at) {
            b = Date.parseDate(this.oriValue.start_at, "Y-m-d H:i:s");
            this.oriValue.start_at_date = SYNO.SDS.DateTimeFormatter(b, {
                type: "date"
            });
            this.oriValue.start_at_time = SYNO.SDS.DateTimeFormatter(b, {
                type: "timesec"
            });
            this.oriValue.start_at_enable = true
        }
        if (this.oriValue.expire_times) {
            this.oriValue.expire_times = a.expire_times;
            this.oriValue.expire_times_enable = true
        }
        if (this.oriValue.protect_type && "none" !== this.oriValue.protect_type) {
            this.oriValue.protect_type_enable = true
        }
        this.formPanel.getForm().setValues(this.oriValue)
    }
});
Ext.define("SYNO.SDS.Utils.SharingManager.ShareWithMePanel", {
    extend: "SYNO.ux.GridPanel",
    pageSize: 50,
    sharingEntryDialog: "SYNO.SDS.Utils.SharingManager.SharingEntryDialog",
    constructor: function(a) {
        this.store = this.createStore(a);
        this.bbar = this.createBBar();
        if (!a.sharingEntryDialog) {
            delete a.sharingEntryDialog
        }
        var b = {
            title: _T("sharing", "share_with_me"),
            bbar: this.bbar,
            store: this.store,
            colModel: new Ext.grid.ColumnModel({
                columns: [{
                    header: _T("common", "user"),
                    dataIndex: "owner_user"
                }, {
                    header: String.format("hash"),
                    dataIndex: "hash"
                }]
            }),
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: true
            }),
            listeners: {
                scope: this,
                beforedestroy: this.onBeforeDestroy,
                rowdblclick: this.onShowSharingEntryDialog
            }
        };
        Ext.apply(b, a);
        this.callParent([b])
    },
    createBBar: function() {
        return new SYNO.ux.PagingToolbar({
            pageSize: this.pageSize,
            store: this.store,
            loadMask: true,
            displayInfo: true,
            showRefreshBtn: true
        })
    },
    createStore: function(b) {
        var a = ["app", "auto_gc", "enable_match_ip", "enabled", "expire_at", "expire_times", "hash", "owner_user", "project_name", "protect_groups", "protect_type", "protect_users", "redirect_type", "redirect_uri", "start_at", "use_count", "url", "qrcode"];
        return new SYNO.API.JsonStore({
            api: "SYNO.Core.Sharing",
            method: "list",
            version: 1,
            autoLoad: true,
            root: "sharings",
            appWindow: b.owner,
            fields: a,
            baseParams: {
                offset: 0,
                limit: -1,
                project_name: b.params.project_name,
                all_entry: (b.params.all_entry) ? true : false,
                share_with_me: true
            }
        })
    },
    refreshPagingTool: function() {
        this.getBottomToolbar().doRefresh()
    },
    onBeforeDestroy: function() {
        this.store.destroy()
    },
    onShowSharingEntryDialog: function() {
        var a = this.getSelectionModel().getSelected();
        if (!a || !this.sharingEntryDialog) {
            return
        }
        var c = Ext.getClassByName(this.sharingEntryDialog);
        var b = new c({
            owner: this.owner,
            params: this.params
        });
        b.setValues(a.data);
        b.open();
        this.mon(b, "close", this.refreshPagingTool, this)
    }
});
Ext.define("SYNO.SDS.Utils.SharingManager.Manager", {
    extend: "SYNO.SDS.ModalWindow",
    params: null,
    constructor: function(a) {
        this.tabPanel = this.createTabPanel(a);
        var b = {
            width: 800,
            height: 350,
            minWidth: 800,
            minHeight: 350,
            shadow: true,
            collapsible: false,
            layout: "fit",
            title: _T("sharing", "sharing_manager"),
            buttons: [{
                text: _T("common", "close"),
                scope: this,
                handler: this.close
            }],
            items: [this.tabPanel]
        };
        Ext.apply(b, a);
        this.callParent([b])
    },
    createTabPanel: function(a) {
        return new SYNO.ux.TabPanel({
            activeTab: 0,
            items: [new SYNO.SDS.Utils.SharingManager.SharingPanel({
                owner: this,
                params: a.params
            }), new SYNO.SDS.Utils.SharingManager.ShareWithMePanel({
                owner: this,
                params: a.params,
                sharingEntryDialog: a.sharingEntryDialog
            })]
        })
    }
});
