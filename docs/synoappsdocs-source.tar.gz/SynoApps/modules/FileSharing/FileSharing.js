/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.Utils.FileSharing");
/**
 * @class SYNO.SDS.Utils.FileSharing"
 * FileSharing utils class
 *
 */
Ext.define("SYNO.SDS.Utils.FileSharing", {
    statics: {
        showSharingManageWindow: function() {
            SYNO.SDS.AppLaunch("SYNO.SDS.App.FileStation3.Instance");
            SYNO.SDS.Utils.FileSharing.deferShowDialog()
        },
        deferShowDialog: function(a) {
            Ext.defer(function() {
                var b = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileStation3.Instance");
                if (!b[b.length - 1] || !b[b.length - 1].window) {
                    SYNO.SDS.Utils.FileSharing.deferShowDialog();
                    return
                }
                var d = b[b.length - 1].window;
                var c = new SYNO.FileStation.SharingManager.Manger({
                    owner: d,
                    webfm: d.panelObj,
                    activeTab: 1,
                    RELURL: "webman/modules/FileBrowser/webfm/"
                });
                c.show()
            }, 500, this)
        }
    }
});
