/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function _objectSpread(e) {
    for (var t = 1; t < arguments.length; t++) {
        var r = null != arguments[t] ? arguments[t] : {},
            n = Object.keys(r);
        "function" == typeof Object.getOwnPropertySymbols && (n = n.concat(Object.getOwnPropertySymbols(r).filter(function(e) {
            return Object.getOwnPropertyDescriptor(r, e).enumerable
        }))), n.forEach(function(t) {
            _defineProperty(e, t, r[t])
        })
    }
    return e
}

function _defineProperty(e, t, r) {
    return t in e ? Object.defineProperty(e, t, {
        value: r,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = r, e
}

function _toConsumableArray(e) {
    return _arrayWithoutHoles(e) || _iterableToArray(e) || _nonIterableSpread()
}

function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function _iterableToArray(e) {
    if (Symbol.iterator in Object(e) || "[object Arguments]" === Object.prototype.toString.call(e)) return Array.from(e)
}

function _arrayWithoutHoles(e) {
    if (Array.isArray(e)) {
        for (var t = 0, r = new Array(e.length); t < e.length; t++) r[t] = e[t];
        return r
    }
}

function asyncGeneratorStep(e, t, r, n, a, o, i) {
    try {
        var s = e[o](i),
            l = s.value
    } catch (e) {
        return void r(e)
    }
    s.done ? t(l) : Promise.resolve(l).then(n, a)
}

function _asyncToGenerator(e) {
    return function() {
        var t = this,
            r = arguments;
        return new Promise(function(n, a) {
            var o = e.apply(t, r);

            function i(e) {
                asyncGeneratorStep(o, n, a, i, s, "next", e)
            }

            function s(e) {
                asyncGeneratorStep(o, n, a, i, s, "throw", e)
            }
            i(void 0)
        })
    }
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _defineProperties(e, t) {
    for (var r = 0; r < t.length; r++) {
        var n = t[r];
        n.enumerable = n.enumerable || !1, n.configurable = !0, "value" in n && (n.writable = !0), Object.defineProperty(e, n.key, n)
    }
}

function _createClass(e, t, r) {
    return t && _defineProperties(e.prototype, t), r && _defineProperties(e, r), e
}
Ext.ns("SYNO.SDS.WebStation.Errors"), SYNO.SDS.WebStation.Errors.GetMessage = function(e, t) {
    var r = _T("error", "error_error_system"),
        n = {
            1007: _TT("SYNO.SDS.WebStation.Application", "error", "err_fqdn_invalid"),
            1008: _TT("SYNO.SDS.WebStation.Application", "error", "err_port_invalid"),
            1009: _TT("SYNO.SDS.WebStation.Application", "error", "err_port_conflict"),
            1015: _TT("SYNO.SDS.WebStation.Application", "error", "err_root_invalid"),
            1017: _TT("SYNO.SDS.WebStation.Application", "error", "err_php_invalid"),
            1018: _TT("SYNO.SDS.WebStation.Application", "error", "err_backend_invalid"),
            1021: _T("app_port_alias", "err_fqdn_duplicated"),
            1022: _TT("SYNO.SDS.WebStation.Application", "error", "err_vhost_acl"),
            1304: _TT("SYNO.SDS.WebStation.Application", "error", "bad_service"),
            1307: _TT("SYNO.SDS.WebStation.Application", "error", "err_port_conflict"),
            1308: _TT("SYNO.SDS.WebStation.Application", "error", "err_port_conflict"),
            1309: _TT("SYNO.SDS.WebStation.Application", "error", "err_port_conflict"),
            1310: _TT("SYNO.SDS.WebStation.Application", "error", "err_alias_conflict")
        };
    return n[e] && (r = n[e]), t && t(e, r), r
}, 
/**
 * @class SYNO.SDS.WebStation.Util
 * WebStation util
 *
 */
Ext.ns("SYNO.SDS.WebStation.Util"), SYNO.SDS.WebStation.Util.PackageInfo = null, SYNO.SDS.WebStation.Util.DestructPackageInfo = function() {
    delete SYNO.SDS.WebStation.Util.PackageInfo, SYNO.SDS.WebStation.Util.PackageInfo = null
}, SYNO.SDS.WebStation.Util.CreatePackageInfo = function() {
    var e = {
            api: "SYNO.WebStation.PHP",
            method: "get",
            version: 1
        },
        t = {
            api: "SYNO.Core.Package",
            method: "list",
            version: 2,
            params: {
                additional: ["status", "provide_pkgs"]
            }
        },
        r = {
            api: "SYNO.Core.Package.Server",
            method: "list",
            version: 2
        },
        n = {
            api: "SYNO.Core.Package.Info",
            method: "get",
            version: 1
        };
    SYNO.SDS.WebStation.Util.PackageInfo = new(function() {
        function s() {
            _classCallCheck(this, s), this.useBetaPackages = !1, this.php = void 0, this.corePackage = void 0, this.corePackageServer = void 0, this._packageData = void 0, this.updatingPromise = Promise.resolve(), this.Update()
        }
        return _createClass(s, [{
            key: "Get",
            value: function() {
                var e = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, this.updatingPromise;
                            case 2:
                                return e.abrupt("return", JSON.parse(JSON.stringify(this._packageData)));
                            case 3:
                            case "end":
                                return e.stop()
                        }
                    }, e, this)
                }));
                return function() {
                    return e.apply(this, arguments)
                }
            }()
        }, {
            key: "GetPackageNameByIndex",
            value: function() {
                var e = _asyncToGenerator(regeneratorRuntime.mark(function e(t, r) {
                    var n;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, this.updatingPromise;
                            case 2:
                                if (["server", "php"].includes(t)) {
                                    e.next = 4;
                                    break
                                }
                                return e.abrupt("return");
                            case 4:
                                return n = this._packageData.backendData[t].find(function(e) {
                                    return e.id === r
                                }), e.abrupt("return", void 0 === n ? JSON.parse(JSON.stringify(n.pkgID)) : null);
                            case 6:
                            case "end":
                                return e.stop()
                        }
                    }, e, this)
                }));
                return function(t, r) {
                    return e.apply(this, arguments)
                }
            }()
        }, {
            key: "GetBackendMap",
            value: function() {
                var e = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
                    var r, n = arguments;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return r = n.length > 1 && void 0 !== n[1] ? n[1] : "all", e.next = 3, this.updatingPromise;
                            case 3:
                                if (["server", "php", "all"].includes(t)) {
                                    e.next = 5;
                                    break
                                }
                                return e.abrupt("return");
                            case 5:
                                if ("all" !== r) {
                                    e.next = 9;
                                    break
                                }
                                return e.abrupt("return", JSON.parse(JSON.stringify(this._packageData.backendData[t])));
                            case 9:
                                return e.abrupt("return", JSON.parse(JSON.stringify(this._packageData.backendData[t].find(function(e) {
                                    return e.id === r
                                }))));
                            case 10:
                            case "end":
                                return e.stop()
                        }
                    }, e, this)
                }));
                return function(t) {
                    return e.apply(this, arguments)
                }
            }()
        }, {
            key: "GetStatusByPkgID",
            value: function() {
                var e = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
                    var r;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, this.updatingPromise;
                            case 2:
                                if ((r = this._packageData.install).hasOwnProperty(t)) {
                                    e.next = 5;
                                    break
                                }
                                return e.abrupt("return", "not_installed");
                            case 5:
                                if ("running" !== r[t].additional.status) {
                                    e.next = 9;
                                    break
                                }
                                return e.abrupt("return", "enabled");
                            case 9:
                                if ("stop" !== r[t].additional.status) {
                                    e.next = 13;
                                    break
                                }
                                return e.abrupt("return", "disabled");
                            case 13:
                                return e.abrupt("return", "-");
                            case 14:
                            case "end":
                                return e.stop()
                        }
                    }, e, this)
                }));
                return function(t) {
                    return e.apply(this, arguments)
                }
            }()
        }, {
            key: "queryPackages",
            value: function() {
                var e = _asyncToGenerator(regeneratorRuntime.mark(function e(t, r) {
                    var n, a, o, i;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, this.updatingPromise;
                            case 2:
                                if (["install", "official"].includes(t)) {
                                    e.next = 4;
                                    break
                                }
                                return e.abrupt("return");
                            case 4:
                                for (n = {}, a = Object.values(this._packageData[t]), o = 0; o < a.length; o++) i = a[o], r(i) && (n[i.id] = i);
                                return e.abrupt("return", n);
                            case 8:
                            case "end":
                                return e.stop()
                        }
                    }, e, this)
                }));
                return function(t, r) {
                    return e.apply(this, arguments)
                }
            }()
        }, {
            key: "fetchCorePackageInfo",
            value: function() {
                var e = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                    var t;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.next = 2, synowebapi.promises.request(n);
                            case 2:
                                t = e.sent, this.useBetaPackages = !!t.config.blBetaChannel;
                            case 4:
                            case "end":
                                return e.stop()
                        }
                    }, e, this)
                }));
                return function() {
                    return e.apply(this, arguments)
                }
            }()
        }, {
            key: "fetchWebStationPhpAndCorePackage",
            value: function() {
                var r = _asyncToGenerator(regeneratorRuntime.mark(function r() {
                    var n, a, o, i, s;
                    return regeneratorRuntime.wrap(function(r) {
                        for (;;) switch (r.prev = r.next) {
                            case 0:
                                return n = [e, t], r.next = 3, synowebapi.promises.request({
                                    compound: {
                                        stopwhenerror: !0,
                                        params: n
                                    }
                                });
                            case 3:
                                if (a = r.sent, o = a.has_fail, i = a.result, !o) {
                                    r.next = 9;
                                    break
                                }
                                throw s = i.find(function(e) {
                                    return !e.success
                                }), new Error("".concat(s.api, " fail"));
                            case 9:
                                return this.php = i.find(function(t) {
                                    return t.api === e.api
                                }).data, this.corePackage = i.find(function(e) {
                                    return e.api === t.api
                                }).data, r.abrupt("return");
                            case 12:
                            case "end":
                                return r.stop()
                        }
                    }, r, this)
                }));
                return function() {
                    return r.apply(this, arguments)
                }
            }()
        }, {
            key: "fetchOnceCorePackageServer",
            value: function() {
                var e = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (!this.corePackageServer) {
                                    e.next = 2;
                                    break
                                }
                                return e.abrupt("return");
                            case 2:
                                return e.next = 4, synowebapi.promises.request(r);
                            case 4:
                                return this.corePackageServer = e.sent, e.abrupt("return");
                            case 6:
                            case "end":
                                return e.stop()
                        }
                    }, e, this)
                }));
                return function() {
                    return e.apply(this, arguments)
                }
            }()
        }, {
            key: "Update",
            value: function() {
                return this.updatingPromise = this._Update(), this.updatingPromise
            }
        }, {
            key: "_Update",
            value: function() {
                var e = _asyncToGenerator(regeneratorRuntime.mark(function e() {
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                return e.prev = 0, e.next = 3, this.fetchCorePackageInfo();
                            case 3:
                                return e.next = 5, this.fetchWebStationPhpAndCorePackage();
                            case 5:
                                return e.next = 7, this.fetchOnceCorePackageServer();
                            case 7:
                                e.next = 12;
                                break;
                            case 9:
                                e.prev = 9, e.t0 = e.catch(0), SYNO.Debug.error(e.t0);
                            case 12:
                                this.makePackageData();
                            case 13:
                            case "end":
                                return e.stop()
                        }
                    }, e, this, [
                        [0, 9]
                    ])
                }));
                return function() {
                    return e.apply(this, arguments)
                }
            }()
        }, {
            key: "makePackageData",
            value: function() {
                var e, t = function(e, t) {
                        var r = [a, o, i];
                        if (void 0 === e) return r;
                        var n = _toConsumableArray(e.packages).concat(_toConsumableArray(t ? e.beta_packages : []));
                        return r.concat(_toConsumableArray(n)).reduce(function(e, t) {
                            return _objectSpread({}, e, _defineProperty({}, t.id, t))
                        }, {})
                    }(this.corePackageServer, this.useBetaPackages),
                    r = ((e = this.corePackage).packages.forEach(function(e) {
                        e.dname = e.name, e.provides = e.additional.provide_pkgs ? Object.keys(e.additional.provide_pkgs).find(function(e) {
                            return "PHP" === e
                        }) : ""
                    }), e.packages.reduce(function(e, t) {
                        return _objectSpread({}, e, _defineProperty({}, t.id, t))
                    }, {})),
                    n = function() {
                        var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {},
                            t = arguments.length > 1 ? arguments[1] : void 0,
                            r = arguments.length > 2 ? arguments[2] : void 0;
                        return Object.values(_objectSpread({}, t, r)).filter(function(e) {
                            return "PHP" === e.provides
                        }).map(function(t) {
                            var r = null !== e.meta_data ? e.meta_data.find(function(e) {
                                return e.name === t.id
                            }) : void 0;
                            return {
                                id: void 0 === r ? null : parseInt(r.id, 10),
                                pkgID: t.id,
                                name: t.dname
                            }
                        })
                    }(this.php, r, t);
                this._packageData = {
                    official: t,
                    install: r,
                    backendData: {
                        server: [{
                            id: 0,
                            pkgID: void 0,
                            name: "Nginx"
                        }, {
                            id: 1,
                            pkgID: "Apache2.2",
                            name: "Apache HTTP Server 2.2"
                        }, {
                            id: 2,
                            pkgID: "Apache2.4",
                            name: "Apache HTTP Server 2.4"
                        }],
                        php: n
                    }
                }
            }
        }]), s
    }());
    var a = {
            provides: "WEBSTATION_SERVICE",
            auto_upgrade_from: "4.7.4-0136",
            blupgrade: !1,
            breakpkgs: null,
            category: ["utilities"],
            changelog: '<ol style="list-style: decimal; padding-left: 30px;"><li>修正有關 WordPress 的多項安全性弱點( CVE-2018-1000773、 CVE-2018-20147、 CVE-2018-20148、 CVE-2018-20149、 CVE-2018-20150、 CVE-2018-20151、CVE-2018-20152、CVE-2018-20153、CVE-2019-8942、CVE-2019-8943、CVE-2019-9787）。</li><li>升級至 5.2.0 版本。</li></ol>',
            conflictpkgs: null,
            deppkgs: {
                "Apache2.2": {
                    ">=": "2.2.31-0005"
                },
                MariaDB10: "",
                "PHP5.6": {
                    ">=": "5.6.39-0058"
                },
                WebStation: {
                    ">=": "2.0.0-0065"
                }
            },
            desc: "WordPress 是開放原始碼 (open source) 的部落格發佈平台，採用的技術為 PHP 及 MySQL。此套件可讓您在 Synology NAS 上架設 WordPress 部落格。",
            distributor: "Synology Inc.",
            distributor_url: "http://www.synology.com/",
            dname: "WordPress",
            download_count: 1214293,
            id: "WordPress",
            link: "https://global.download.synology.com/download/Package/spk/WordPress/5.2.0-0152/WordPress-5.2.0-0152.spk",
            maintainer: "WordPress",
            maintainer_url: "http://tw.wordpress.org/",
            md5: "17ab8a772a6bb34a0b56e4028bb4e317",
            package: "WordPress",
            price: null,
            qstart: !0,
            recent_download_count: 58796,
            replaceforcepkgs: null,
            replacepkgs: null,
            silent_upgrade: !0,
            size: 9963520,
            source: "syno",
            start: !0,
            thirdparty: !0,
            thumbnail: ["https://global.download.synology.com/download/Package/img/WordPress/5.2.0-0152/thumb_72.png", "https://global.download.synology.com/download/Package/img/WordPress/5.2.0-0152/thumb_120.png", "https://global.download.synology.com/download/Package/img/WordPress/5.2.0-0152/thumb_256.png"],
            thumbnail_retina: ["https://global.download.synology.com/download/Package/img/WordPress/5.2.0-0152/thumb_256.png", "https://global.download.synology.com/download/Package/img/WordPress/5.2.0-0152/thumb_256.png"],
            type: 0,
            version: "5.2.0-0152"
        },
        o = {
            provides: "WEBSTATION_SERVICE",
            auto_upgrade_from: "1.28.2-0123",
            blupgrade: !1,
            breakpkgs: null,
            category: ["utilities"],
            changelog: '<ol style="list-style: decimal; padding-left: 30px;"><li>升級至 1.30.0 版本以修正多項關於 MediaWiki 的安全性問題 (CVE-2017-8814、CVE-2017-8812、CVE-2017-8815、CVE-2017-8810、CVE-2017-8809、CVE-2017-8808、CVE-2017-8811)。</li></ol>',
            conflictpkgs: null,
            deppkgs: {
                "Apache2.2": {
                    ">=": "2.2.31-0005"
                },
                MariaDB10: "",
                "PHP5.6": {
                    ">=": "5.6.17-0017"
                },
                WebStation: {
                    ">=": "2.0.0-0065"
                }
            },
            desc: "MediaWiki 是一套極為強大、擴充度高、功能豐富的開放原始碼 wiki 套件，使用 PHP 來處理、呈現資料庫 (如 MySQL) 中儲存的資料。目前廣泛地運用在維基百科與其它 wiki 上。使用者可充分利用其功能與擴充來編輯 wiki 頁面。",
            distributor: "Synology Inc.",
            distributor_url: "http://www.synology.com/",
            dname: "MediaWiki",
            download_count: 326392,
            id: "MediaWiki",
            link: "https://global.download.synology.com/download/Package/spk/MediaWiki/1.30.0-0131/MediaWiki-1.30.0-0131.spk",
            maintainer: "MediaWiki",
            maintainer_url: "http://www.mediawiki.org/",
            md5: "bf31a63406d424d344d1eeeac9682164",
            package: "MediaWiki",
            price: null,
            qstart: !0,
            recent_download_count: 3152,
            replaceforcepkgs: null,
            replacepkgs: null,
            silent_install: !0,
            silent_upgrade: !0,
            size: 31600640,
            snapshot: ["https://global.download.synology.com/download/Package/img/MediaWiki/1.30.0-0131/screenshot_01.png"],
            source: "syno",
            start: !0,
            thirdparty: !0,
            thumbnail: ["https://global.download.synology.com/download/Package/img/MediaWiki/1.30.0-0131/thumb_72.png", "https://global.download.synology.com/download/Package/img/MediaWiki/1.30.0-0131/thumb_120.png", "https://global.download.synology.com/download/Package/img/MediaWiki/1.30.0-0131/thumb_256.png"],
            thumbnail_retina: ["https://global.download.synology.com/download/Package/img/MediaWiki/1.30.0-0131/thumb_256.png", "https://global.download.synology.com/download/Package/img/MediaWiki/1.30.0-0131/thumb_256.png"],
            type: 0,
            version: "1.30.0-0131"
        },
        i = {
            provides: "WEBSTATION_SERVICE",
            blupgrade: !1,
            breakpkgs: null,
            category: ["utilities"],
            changelog: '<p>問題修正</p><ol style="list-style: decimal; padding-left: 30px;"><li>修正有關 phpMyAdmin 的安全性弱點。</li><li>修正匯入大型檔案時可能會失敗的問題。</li></ol>',
            conflictpkgs: null,
            deppkgs: {
                "PHP5.6": {
                    ">=": "5.6.17-0017"
                },
                WebStation: {
                    ">=": "1.0-0036"
                }
            },
            desc: "phpMyAdmin 是免費的軟體工具，設計用來管理 MySQL 資料庫。只要安裝此套件即可在 DiskStation 上管理 MySQL 資料庫。",
            distributor: "Synology Inc.",
            distributor_url: "http://www.synology.com/",
            dname: "phpMyAdmin",
            download_count: 5739571,
            id: "phpMyAdmin",
            link: "https://global.download.synology.com/download/Package/spk/phpMyAdmin/4.8.4-0179/phpMyAdmin-4.8.4-0179.spk",
            maintainer: "phpMyAdmin devel team",
            maintainer_url: "http://www.phpmyadmin.net",
            md5: "cee8c448ab80993d199d7ebd523dd3e0",
            package: "phpMyAdmin",
            price: null,
            qinst: !0,
            qstart: !0,
            qupgrade: !0,
            recent_download_count: 240005,
            replaceforcepkgs: null,
            replacepkgs: null,
            silent_install: !0,
            silent_uninstall: !0,
            silent_upgrade: !0,
            size: 5785600,
            snapshot: ["https://global.download.synology.com/download/Package/img/phpMyAdmin/4.8.4-0179/screenshot_01.png"],
            source: "syno",
            start: !0,
            thirdparty: !0,
            thumbnail: ["https://global.download.synology.com/download/Package/img/phpMyAdmin/4.8.4-0179/thumb_72.png", "https://global.download.synology.com/download/Package/img/phpMyAdmin/4.8.4-0179/thumb_256.png"],
            thumbnail_retina: ["https://global.download.synology.com/download/Package/img/phpMyAdmin/4.8.4-0179/thumb_256.png", "https://global.download.synology.com/download/Package/img/phpMyAdmin/4.8.4-0179/thumb_256.png"],
            type: 0,
            version: "4.8.4-0179"
        }
}, SYNO.SDS.WebStation.Util.HomeShareStatus = {
    StatusNormal: 0,
    StatusNotEnable: 1,
    StatusIsEncrypted: 2,
    StatusBackendNotExist: 3,
    StatusUnknownError: 4
}, SYNO.SDS.WebStation.Util.getReqCompoundParam = function(e, t) {
    if (!(t instanceof Array)) return null;
    for (var r = 0; r < t.length; r++)
        if (!1 !== SYNO.ux.Utils.checkApiConsistency(e, t[r])) return t[r];
    return null
}, SYNO.SDS.WebStation.Util.getSuccessRespCompoundData = function(e, t) {
    if (!(t.result instanceof Array)) return null;
    for (var r = 0; r < t.result.length; r++) {
        var n = t.result[r];
        if (!1 !== SYNO.ux.Utils.checkApiConsistency(e, n)) {
            if (!0 === n.has_fail || !1 === n.success) break;
            return t.result[r].data ? t.result[r].data : null
        }
    }
    return null
}, SYNO.SDS.WebStation.Util.getFailRespCompoundParam = function(e, t) {
    if (!1 === t.has_fail) return null;
    if (!(t.result instanceof Array)) return null;
    for (var r = 0; r < t.result.length; r++) {
        var n = t.result[r];
        if (e == n.api && !1 === n.success) return n.error
    }
    return null
}, SYNO.SDS.WebStation.Util.genVhostLink = function(e, t, r, n, a) {
    var o = "",
        i = a && 0 !== a.length,
        s = !(n && 0 !== n.length) || e && i,
        l = s ? 443 : 80,
        c = s ? a : n,
        u = !1,
        p = -1,
        d = !0,
        g = !1,
        h = void 0;
    try {
        for (var f, y = c[Symbol.iterator](); !(d = (f = y.next()).done); d = !0) {
            var S = f.value;
            S == l ? u = !0 : p = S
        }
    } catch (e) {
        g = !0, h = e
    } finally {
        try {
            d || null == y.return || y.return()
        } finally {
            if (g) throw h
        }
    }
    var m = -1 == p || t && u;
    return o = s ? "https://" : "http://", o += null === r ? window.location.hostname : r, !1 === m && (o += ":".concat(p)), o
}, SYNO.SDS.WebStation.Util.genAliasLink = function(e, t) {
    var r = "";
    return r = e ? "https://" : "http://", r += window.location.hostname, r += "/" + t
}, SYNO.SDS.WebStation.Util.geti18nString = function(e, t) {
    if (null === e) return t || "";
    var r = e.split(":");
    return 3 === r.length ? _TT.apply(void 0, _toConsumableArray(r)) : 2 === r.length ? _T.apply(void 0, _toConsumableArray(r)) : t || e
};
