/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function _objectSpread(e) {
    for (var t = 1; t < arguments.length; t++) {
        var i = null != arguments[t] ? arguments[t] : {},
            a = Object.keys(i);
        "function" == typeof Object.getOwnPropertySymbols && (a = a.concat(Object.getOwnPropertySymbols(i).filter(function(e) {
            return Object.getOwnPropertyDescriptor(i, e).enumerable
        }))), a.forEach(function(t) {
            _defineProperty(e, t, i[t])
        })
    }
    return e
}

function _defineProperty(e, t, i) {
    return t in e ? Object.defineProperty(e, t, {
        value: i,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = i, e
}

function _toConsumableArray(e) {
    return _arrayWithoutHoles(e) || _iterableToArray(e) || _nonIterableSpread()
}

function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function _iterableToArray(e) {
    if (Symbol.iterator in Object(e) || "[object Arguments]" === Object.prototype.toString.call(e)) return Array.from(e)
}

function _arrayWithoutHoles(e) {
    if (Array.isArray(e)) {
        for (var t = 0, i = new Array(e.length); t < e.length; t++) i[t] = e[t];
        return i
    }
}

function asyncGeneratorStep(e, t, i, a, n, o, r) {
    try {
        var s = e[o](r),
            l = s.value
    } catch (e) {
        return void i(e)
    }
    s.done ? t(l) : Promise.resolve(l).then(a, n)
}

function _asyncToGenerator(e) {
    return function() {
        var t = this,
            i = arguments;
        return new Promise(function(a, n) {
            var o = e.apply(t, i);

            function r(e) {
                asyncGeneratorStep(o, a, n, r, s, "next", e)
            }

            function s(e) {
                asyncGeneratorStep(o, a, n, r, s, "throw", e)
            }
            r(void 0)
        })
    }
}
Ext.define("SYNO.SDS.WebStation.Overview", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        this.module = e.module, this.appWin = e.appWin, this.owner = e.owner, this.status = new SYNO.SDS.WebStation.Status({
            module: this.module,
            appWin: this.appWin
        }), this.backend = new SYNO.SDS.WebStation.SupportBackend({
            module: this.module,
            appWin: this.appWin
        }), this.service = new SYNO.SDS.WebStation.SupportService({
            module: this.module,
            appWin: this.appWin
        });
        this.compoundAPIs = [{
            api: "SYNO.WebStation.Status",
            method: "get",
            version: 1
        }, {
            api: "SYNO.WebStation.WebService.Service",
            method: "list",
            version: 1,
            params: {
                all: !0
            }
        }, {
            api: "SYNO.WebStation.WebService.Portal",
            method: "list",
            version: 1
        }];
        var t = this.fillConfig(e);
        this.callParent([t]), this.mon(SYNO.SDS.StatusNotifier, "thirdpartychanged", this.onPkgChanged, this)
    },
    fillConfig: function(e) {
        var t = {
            itemId: "Overview",
            autoFlexcroll: !0,
            useDefaultBtn: !1,
            items: [{
                xtype: "syno_fieldset",
                title: _T("log", "general"),
                bwrapCfg: {
                    padding: 0
                },
                items: [this.status]
            }, {
                xtype: "syno_fieldset",
                title: _TT("SYNO.SDS.WebStation.Application", "status", "support_backend"),
                bwrapCfg: {
                    padding: 0
                }
            }, this.backend, {
                xtype: "syno_fieldset",
                title: _TT("SYNO.SDS.WebStation.Application", "status", "support_service_pkg"),
                bwrapCfg: {
                    padding: 0
                }
            }, this.service],
            listeners: {
                scope: this,
                resize: this.onPanelResize
            }
        };
        return Ext.apply(t, e), t
    },
    onPageActivate: function() {
        this.getRemoteData()
    },
    onPkgChanged: function(e) {
        "WebStation" !== e && this.getRemoteData()
    },
    onPanelResize: function(e, t, i, a, n, o) {
        this.status.refreshWidth(t), this.backend.refreshWidth(t), this.service.refreshWidth(t)
    },
    getRemoteData: function() {
        this.appWin.sendWebAPI({
            compound: {
                stopwhenerror: !0,
                params: this.compoundAPIs
            },
            scope: this,
            callback: this.webapiDone
        })
    },
    webapiDone: function() {
        var e = _asyncToGenerator(regeneratorRuntime.mark(function e(t, i, a) {
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        return this.status.webapiDone(t, i, a), e.next = 3, this.backend.webapiDone(t, i, a);
                    case 3:
                        return e.next = 5, this.service.webapiDone(t, i, a);
                    case 5:
                        this.doLayout();
                    case 6:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return function(t, i, a) {
            return e.apply(this, arguments)
        }
    }()
}), Ext.define("SYNO.SDS.WebStation.Status", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        this.module = e.module, this.appWin = e.appWin, this.owner = e.owner;
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = {
            itemId: "Status",
            autoHeight: !0,
            labelSeparator: _T("common", "colon"),
            items: [this.createGeneralStatus()]
        };
        return Ext.apply(t, e), t
    },
    createGeneralStatus: function() {
        var e = [];
        return e.push({
            xtype: "syno_displayfield",
            id: this.default_backend_status = Ext.id(),
            fieldLabel: _TT("SYNO.SDS.WebStation.Application", "status", "default_server_status"),
            name: "default_backend_status",
            htmlEncode: !1,
            value: "--",
            isDirty: function() {
                return !1
            }
        }, {
            xtype: "syno_displayfield",
            id: this.userdir_status = Ext.id(),
            fieldLabel: _TT("SYNO.SDS.WebStation.Application", "status", "personal_website_status"),
            name: "userdir_status",
            htmlEncode: !1,
            value: "--",
            isDirty: function() {
                return !1
            }
        }, {
            xtype: "syno_displayfield",
            id: this.web_service_portal_status = Ext.id(),
            fieldLabel: _TT("SYNO.SDS.WebStation.Application", "status", "web_service_portal_status"),
            name: "web_service_portal_status",
            htmlEncode: !1,
            value: "--",
            isDirty: function() {
                return !1
            }
        }), e
    },
    webapiDone: function(e, t, i) {
        if (!0 === e) {
            var a = t.result[0];
            !0 === a.success && (a.data.available_php_backend = a.data.available_php_backend || [], this.setDefaultBackendStatus(a.data), this.setUserdirStatus(a.data), this.setWebServicePortalStatus(t))
        }
    },
    setDefaultBackendStatus: function(e) {
        var t, i;
        this.checkBackendStatus(e, e.backend, e.php) ? (t = _T("helpbrowser", "font_normal"), i = "green") : (t = _T("common", "status_abnormal"), i = "red");
        var a = String.format('<font class="{0}-status">{1}</font>', i, t);
        this.getForm().findField("default_backend_status").setValue(a)
    },
    setWebServicePortalStatus: function(e) {
        var t = e.result[0],
            i = e.result[1],
            a = e.result[2];
        if (0 !== t.data.VirtualHost.total || 0 !== a.data.portals.length) {
            var n = {};
            i.data.services && i.data.services.forEach(function(e) {
                e.enable && (n[e.id] = e)
            });
            var o, r, s = 0,
                l = 0;
            a.data.portals && a.data.portals.forEach(function(e) {
                e.enable && !n[e.service] && ("alias" === e.type ? s++ : "server" === e.type && l++)
            }), 0 === t.data.VirtualHost.error && 0 === l || 0 === s ? 0 !== t.data.VirtualHost.error || 0 !== l ? (o = "".concat(_T("common", "status_abnormal"), " (").concat(_TT("SYNO.SDS.WebStation.Application", "title", "vhost"), ")"), r = "red") : 0 !== s ? (o = "".concat(_T("common", "status_abnormal"), " (").concat(_T("app_port_alias", "desc_alias"), ")"), r = "red") : (o = _T("helpbrowser", "font_normal"), r = "green") : (o = "".concat(_T("common", "status_abnormal"), " (").concat(_TT("SYNO.SDS.WebStation.Application", "title", "vhost_and_alias"), ")"), r = "red");
            var d = String.format('<font class="{0}-status">{1}</font>', r, o);
            this.getForm().findField("web_service_portal_status").setValue(d)
        } else this.getForm().findField("web_service_portal_status").setValue("--")
    },
    setUserdirStatus: function(e) {
        var t = "green",
            i = _T("common", "enabled");
        e.userdir && e.home_share_status === SYNO.SDS.WebStation.Util.HomeShareStatus.StatusNormal ? this.checkBackendStatus(e, e.userdir_backend, e.userdir_php) || (i = _T("common", "status_abnormal"), t = "red") : (i = _T("common", "disabled"), t = "syno-webstation-grey");
        var a = String.format('<font class="{0}-status">{1}</font>', t, i);
        this.getForm().findField("userdir_status").setValue(a)
    },
    checkBackendStatus: function(e, t, i) {
        var a = !1;
        if (null !== i) {
            for (var n = 0; n < e.php_profiles.profiles.length; n++)
                if (i === e.php_profiles.profiles[n].uuid) {
                    a = !0;
                    break
                }
        } else a = !0;
        return !!a && -1 != e.available_server_backend.indexOf(t)
    },
    errorHandling: function(e) {},
    refreshWidth: function(e) {
        this.setWidth(e)
    }
}), Ext.define("SYNO.SDS.WebStation.SupportBackend", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(e) {
        this.support_backend_store = new Ext.data.SimpleStore({
            fields: ["backend", "status"],
            data: []
        });
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = new Ext.grid.ColumnModel({
                defaults: {
                    menuDisabled: !1,
                    sortable: !1
                },
                columns: [{
                    header: _TT("SYNO.SDS.WebStation.Application", "common", "name"),
                    dataIndex: "backend",
                    align: "left",
                    sortable: !1
                }, {
                    header: _TT("SYNO.SDS.WebStation.Application", "common", "status"),
                    dataIndex: "status",
                    align: "left",
                    sortable: !1,
                    renderer: function(e) {
                        if ("not_installed" === e) {
                            var t = _TT("SYNO.SDS.WebStation.Application", "common", "not_installed");
                            return '<span class="syno-webstation-grey-status" style="padding-right:8px;">'.concat(t, "</span>")
                        }
                        if ("enabled" === e) {
                            var i = _T("common", "enabled");
                            return '<span class="green-status" style="padding-right:8px;">'.concat(i, "</span>")
                        }
                        if ("disabled" === e) {
                            var a = _T("common", "disabled");
                            return '<span class="syno-webstation-grey-status" style="padding-right:8px;">'.concat(a, "</span>")
                        }
                        return "-"
                    }
                }, {
                    xtype: "actioncolumn",
                    header: _TT("SYNO.SDS.WebStation.Application", "status", "management"),
                    align: "center",
                    sortable: !1,
                    renderer: function(e, t, i, a, n, o) {
                        if ("Nginx" == i.get("backend")) return "<font> -- </font>"
                    },
                    items: [{
                        getClass: function(e, t, i) {
                            return "Nginx" == i.get("backend") ? "" : "syno-webstation-management"
                        },
                        handler: function(e, t, i) {
                            var a = e.store.getAt(t).get("backend"),
                                n = SYNO.SDS.WebStation.Util.PackageInfo._packageData.backendData,
                                o = Object.values(n).flat().filter(function(e) {
                                    return "Nginx" !== e.name
                                }).find(function(e) {
                                    return e.name === a
                                });
                            void 0 !== o && SYNO.SDS.AppLaunch("SYNO.SDS.PkgManApp.Instance", {
                                action: "open",
                                packages: [o.pkgID]
                            })
                        }
                    }]
                }]
            }),
            i = new Ext.grid.RowSelectionModel({
                singleSelect: !0
            }),
            a = {
                title: _TT("SYNO.SDS.WebStation.Application", "status", "support_backend"),
                autoHeight: !1,
                hideHeaders: !1,
                enableColumnHide: !1,
                colModel: t,
                selModel: i,
                store: this.support_backend_store
            };
        return Ext.apply(a, e), a
    },
    webapiDone: function() {
        var e = _asyncToGenerator(regeneratorRuntime.mark(function e(t, i, a) {
            var n;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        if (!0 !== t) {
                            e.next = 6;
                            break
                        }
                        if (!0 !== (n = i.result[0]).success) {
                            e.next = 6;
                            break
                        }
                        return n.data.available_php_backend = n.data.available_php_backend || [], e.next = 6, this.setSupportBackend(n.data);
                    case 6:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return function(t, i, a) {
            return e.apply(this, arguments)
        }
    }(),
    setSupportBackend: function() {
        var e = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
            var i, a, n, o, r, s;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        return i = [], e.next = 3, SYNO.SDS.WebStation.Util.PackageInfo.Get();
                    case 3:
                        a = e.sent.backendData, n = _toConsumableArray(a.server).concat(_toConsumableArray(a.php)), o = 0;
                    case 6:
                        if (!(o < n.length)) {
                            e.next = 20;
                            break
                        }
                        if ("Nginx" !== (r = n[o]).name) {
                            e.next = 12;
                            break
                        }
                        e.t0 = "enabled", e.next = 15;
                        break;
                    case 12:
                        return e.next = 14, SYNO.SDS.WebStation.Util.PackageInfo.GetStatusByPkgID(r.pkgID);
                    case 14:
                        e.t0 = e.sent;
                    case 15:
                        s = e.t0, i.push([r.name, s]);
                    case 17:
                        o++, e.next = 6;
                        break;
                    case 20:
                        this.support_backend_store.loadData(i), this.refreshHeight();
                    case 22:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return function(t) {
            return e.apply(this, arguments)
        }
    }(),
    refreshHeight: function() {
        var e = this.support_backend_store.getCount();
        this.setHeight(42 + 29 * e)
    },
    refreshWidth: function(e) {
        this.setWidth(e)
    }
}), Ext.define("SYNO.SDS.WebStation.SupportService", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(e) {
        this.support_service_store = new Ext.data.SimpleStore({
            fields: ["category", "status"],
            data: []
        });
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        var t = new Ext.grid.ColumnModel({
                defaults: {
                    menuDisabled: !1,
                    sortable: !1
                },
                columns: [{
                    header: _TT("SYNO.SDS.WebStation.Application", "common", "name"),
                    dataIndex: "category",
                    align: "left",
                    sortable: !1
                }, {
                    header: _TT("SYNO.SDS.WebStation.Application", "common", "status"),
                    dataIndex: "status",
                    align: "left",
                    sortable: !1,
                    renderer: function(e) {
                        if ("not_installed" === e) {
                            var t = _TT("SYNO.SDS.WebStation.Application", "common", "not_installed");
                            return '<span class="syno-webstation-grey-status" style="padding-right:8px;">'.concat(t, "</span>")
                        }
                        if ("enabled" === e) {
                            var i = _T("common", "enabled");
                            return '<span class="green-status" style="padding-right:8px;">'.concat(i, "</span>")
                        }
                        if ("disabled" === e) {
                            var a = _T("common", "disabled");
                            return '<span class="syno-webstation-grey-status" style="padding-right:8px;">'.concat(a, "</span>")
                        }
                        return "-"
                    }
                }, {
                    xtype: "actioncolumn",
                    header: _TT("SYNO.SDS.WebStation.Application", "status", "management"),
                    align: "center",
                    sortable: !1,
                    items: [{
                        getClass: function() {
                            return "syno-webstation-management"
                        },
                        handler: function(e, t, i) {
                            var a = e.store.getAt(t).get("category");
                            void 0 !== a && SYNO.SDS.AppLaunch("SYNO.SDS.PkgManApp.Instance", {
                                action: "open",
                                packages: [a]
                            })
                        }
                    }]
                }]
            }),
            i = new Ext.grid.RowSelectionModel({
                singleSelect: !0
            }),
            a = {
                title: _TT("SYNO.SDS.WebStation.Application", "status", "support_service_pkg"),
                autoHeight: !1,
                enableColumnHide: !1,
                colModel: t,
                selModel: i,
                store: this.support_service_store
            };
        return Ext.apply(a, e), a
    },
    webapiDone: function() {
        var e = _asyncToGenerator(regeneratorRuntime.mark(function e(t, i, a) {
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        if (!0 !== t || !0 !== i.result[1].success) {
                            e.next = 4;
                            break
                        }
                        return e.next = 3, this.setSupportService(i.result[1].data.services);
                    case 3:
                        this.refreshHeight();
                    case 4:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return function(t, i, a) {
            return e.apply(this, arguments)
        }
    }(),
    setSupportService: function() {
        var e = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
            var i, a, n, o, r, s, l, d;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        return i = [], a = t.map(function(e) {
                            return e.category
                        }), e.next = 4, SYNO.SDS.WebStation.Util.PackageInfo.queryPackages("install", function(e) {
                            return a.includes(e.id) && "WebStation" !== e.id
                        });
                    case 4:
                        return n = e.sent, e.next = 7, SYNO.SDS.WebStation.Util.PackageInfo.queryPackages("install", function(e) {
                            return e.additional.provide_pkgs ? e.additional.provide_pkgs.hasOwnProperty("WEBSTATION_SERVICE") : 0
                        });
                    case 7:
                        return o = e.sent, e.next = 10, SYNO.SDS.WebStation.Util.PackageInfo.queryPackages("official", function(e) {
                            return e.provides ? e.provides.includes("WEBSTATION_SERVICE") : 0
                        });
                    case 10:
                        r = e.sent, s = Object.values(_objectSpread({}, n, o, r)), l = 0;
                    case 13:
                        if (!(l < s.length)) {
                            e.next = 25;
                            break
                        }
                        return d = s[l], e.t0 = i, e.t1 = SYNO.SDS.WebStation.Util.geti18nString(d.dname), e.next = 19, SYNO.SDS.WebStation.Util.PackageInfo.GetStatusByPkgID(d.id);
                    case 19:
                        e.t2 = e.sent, e.t3 = [e.t1, e.t2], e.t0.push.call(e.t0, e.t3);
                    case 22:
                        l++, e.next = 13;
                        break;
                    case 25:
                        return this.support_service_store.loadData(i), e.abrupt("return");
                    case 27:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return function(t) {
            return e.apply(this, arguments)
        }
    }(),
    refreshHeight: function() {
        var e = this.support_service_store.getCount();
        this.setHeight(42 + 29 * e)
    },
    refreshWidth: function(e) {
        this.setWidth(e)
    }
}), Ext.define("SYNO.SDS.WebStation.Web.PHPAdvancedSetting", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.module = e.module, this.owner = e.owner, this.default_settings = e.default_settings, this.available_php_backend = e.available_php_backend, this.webapi = e.webapi, this.isEditProfile = e.isEditProfile;
        var t = [];
        this.general_settings_form = this.createGeneralSettingForm({
            title: _TT("SYNO.SDS.WebStation.Application", "php", "settings"),
            owner: this,
            module: this.module
        }), this.php_extension_form = this.createExtensionGrid({
            title: _TT("SYNO.SDS.WebStation.Application", "php", "extensions"),
            owner: this,
            module: this.module
        }), this.fpm_setting_form = this.createFpmSettingForm({
            title: _TT("SYNO.SDS.WebStation.Application", "php_advanced_setting", "fpm_setting"),
            owner: this,
            module: this.module
        }), this.core_setting_column = this.createCoreSettingColumn({
            title: _TT("SYNO.SDS.WebStation.Application", "php_advanced_setting", "core_setting"),
            owner: this,
            module: this.module
        }), t.push(this.general_settings_form), t.push(this.php_extension_form), t.push(this.fpm_setting_form), t.push(this.core_setting_column), this.callParent([Ext.apply({
            title: e.title,
            width: 750,
            height: 580,
            layout: "fit",
            items: [{
                xtype: "syno_tabpanel",
                itemId: "php_advanced_setting",
                plain: !0,
                activeTab: 0,
                deferredRender: !1,
                items: t
            }],
            closeAction: "onCancel",
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: this.onCancel
            }, {
                text: this.isEditProfile ? _T("common", "save") : _T("common", "create"),
                btnStyle: "blue",
                disabled: this._S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                scope: this,
                handler: this.onApply
            }]
        }, e)]), this.mon(this, "afterlayout", this.updateView, this)
    },
    setInitData: function() {
        this.profile = {
            profile_name: "",
            profile_desc: "",
            backend: this.available_php_backend[0],
            default_profile: null,
            custom_open_basedir: !1,
            display_errors: !1,
            enable_cache: !1,
            enable_xdebug: !1,
            extensions: [],
            fpm_settings: {
                mode: "dynamic",
                max_children: 20,
                max_spare_servers: 3,
                min_spare_servers: 1,
                start_servers: 2
            },
            open_basedir: "",
            php_settings: {}
        }
    },
    setData: function(e) {
        this.profile = e, e.default_profile && (this.profile.backend = e.default_profile.backend, this.profile.enable = e.default_profile.enable, this.profile.profile_desc = e.default_profile.profile_desc, this.profile.profile_name = e.default_profile.profile_name)
    },
    updateView: function() {
        var e = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t, i;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        return this.current_backend = this.profile.backend, t = this.general_settings_form.getForm(), e.next = 4, this.updateGeneralSettingDefaultField();
                    case 4:
                        t.setValues(this.profile), t.clearInvalid(), (i = this.fpm_setting_form.getForm()).setValues(this.profile.fpm_settings), i.clearInvalid(), this.updateCoreSettingSimpleStore(), this.updateExtensionSimpleStore();
                    case 11:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return function() {
            return e.apply(this, arguments)
        }
    }(),
    updateGeneralSettingDefaultField: function() {
        var e = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        if (this.profile) {
                            e.next = 2;
                            break
                        }
                        return e.abrupt("return");
                    case 2:
                        if (!this.profile.default_profile) {
                            e.next = 14;
                            break
                        }
                        return this.general_settings_form.getForm().findField("profile_name").hide(), this.general_settings_form.getForm().findField("profile_desc").hide(), this.general_settings_form.getForm().findField("backend").hide(), this.profile.profile_name_fixed = this.profile.profile_name, this.profile.profile_desc_fixed = this.profile.profile_desc, e.next = 10, SYNO.SDS.WebStation.Util.PackageInfo.GetBackendMap("php", this.profile.backend);
                    case 10:
                        this.profile.backend_fixed = e.sent.name, this.profile.open_basedir_default = this.profile.default_profile.open_basedir || "None", e.next = 18;
                        break;
                    case 14:
                        this.general_settings_form.getForm().findField("profile_name_fixed").hide(), this.general_settings_form.getForm().findField("profile_desc_fixed").hide(), this.general_settings_form.getForm().findField("backend_fixed").hide(), this.profile.open_basedir_default = "None";
                    case 18:
                        this.profile.custom_open_basedir ? this.profile.open_basedir_customize_radio = !0 : this.profile.open_basedir_default_radio = !0;
                    case 19:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return function() {
            return e.apply(this, arguments)
        }
    }(),
    processCoreSettingsRecord: function(e, t, i, a) {
        var n = "",
            o = !1;
        for (var r in a) a.hasOwnProperty(r) && (t && t.php_settings[r] ? (n = t.php_settings[r], o = !0) : i && i.php_settings[r] ? (n = i.php_settings[r], o = !1) : (n = a[r], o = !1), e.push([r, n, o]))
    },
    updateCoreSettingSimpleStore: function() {
        for (var e, t = [], i = this.general_settings_form.getForm().findField("backend").getValue(), a = 0; a < this.default_settings.default_settings.length; a++) this.default_settings.default_settings[a].backend === i && (e = this.default_settings.default_settings[a]);
        this.processCoreSettingsRecord(t, this.profile, this.profile.default_profile, e.core), this.processCoreSettingsRecord(t, this.profile, this.profile.default_profile, e.extensions), this.php_settings_store.loadData(t), this.applyCoreModifiedRecords(this.coreModifiedList)
    },
    applyCoreModifiedRecords: function(e) {
        if (void 0 !== e)
            for (var t in e) {
                var i = this.php_settings_store.findExact("name", t);
                if (void 0 !== i) {
                    var a = this.php_settings_store.getAt(i);
                    a.set("value", e[t]), a.set("is_custom", !0)
                }
            }
    },
    updateExtensionSimpleStore: function() {
        for (var e, t = this.general_settings_form.getForm().findField("backend").getValue(), i = 0; i < this.default_settings.extensions_list.length; i++) this.default_settings.extensions_list[i].backend === t && (e = this.default_settings.extensions_list[i].extensions);
        for (var a, n, o, r, s = {}, l = [], d = e.length, p = 0; p < d; p++) n = (a = e[p]).name, o = a.enable, r = a.description, l.push([o, n, r, !1]), s[n] = l[l.length - 1];
        if (void 0 !== this.profile) {
            for (var c = this.profile.extensions, h = 0; h < c.length; h++) {
                var u = c[h];
                void 0 !== s[u] && (s[u][0] = !0)
            }
            if (this.profile.default_profile) {
                var S = this.profile.default_profile.extensions;
                if (void 0 !== S)
                    for (var m = 0; m < S.length; m++) {
                        var _ = S[m];
                        void 0 !== s[_] && (s[_][0] = !0, s[_][3] = !0)
                    }
            }
        }
        this.extension_store.loadData(l)
    },
    createGeneralSettingBasicFieldSets: function() {
        var e = [],
            t = SYNO.SDS.WebStation.Util.PackageInfo._packageData.backendData.php,
            i = this.available_php_backend.map(function(e) {
                return [e, t.find(function(t) {
                    return t.id === e
                }).name]
            }),
            a = new Ext.data.SimpleStore({
                fields: ["value", "display"],
                data: i,
                listeners: {
                    update: {
                        scope: this,
                        fn: function(e, t, i, a) {}
                    }
                }
            });
        return e.push({
            xtype: "syno_textfield",
            name: "profile_name",
            width: 250,
            fieldLabel: _TT("SYNO.SDS.WebStation.Application", "php", "profile_name"),
            allowBlank: !1,
            emptyText: "Profile Name"
        }, {
            xtype: "syno_displayfield",
            name: "profile_name_fixed",
            width: 250,
            fieldLabel: _TT("SYNO.SDS.WebStation.Application", "php", "profile_name")
        }, {
            xtype: "syno_textfield",
            name: "profile_desc",
            width: 250,
            fieldLabel: _TT("SYNO.SDS.WebStation.Application", "php", "profile_desc"),
            allowBlank: !1,
            emptyText: "Profile Description"
        }, {
            xtype: "syno_displayfield",
            name: "profile_desc_fixed",
            width: 250,
            fieldLabel: _TT("SYNO.SDS.WebStation.Application", "php", "profile_desc")
        }, {
            xtype: "syno_combobox",
            name: "backend",
            id: this.comboId = Ext.id(),
            fieldLabel: _TT("SYNO.SDS.WebStation.Application", "php", "version"),
            valueField: "value",
            displayField: "display",
            width: 250,
            store: a,
            listeners: {
                select: {
                    scope: this,
                    fn: function() {
                        this.updateExtensionSimpleStore(), this.updateCoreSettingSimpleStore()
                    }
                }
            }
        }, {
            xtype: "syno_displayfield",
            name: "backend_fixed",
            width: 250,
            fieldLabel: _TT("SYNO.SDS.WebStation.Application", "php", "version")
        }, {
            xtype: "syno_checkbox",
            name: "enable_cache",
            boxLabel: _TT("SYNO.SDS.WebStation.Application", "php", "php_cache_enabled")
        }, {
            xtype: "syno_checkbox",
            name: "enable_xdebug",
            boxLabel: _TT("SYNO.SDS.WebStation.Application", "php", "php_xdebug_enabled")
        }, {
            xtype: "syno_checkbox",
            name: "display_errors",
            boxLabel: _TT("SYNO.SDS.WebStation.Application", "php", "php_display_errors")
        }, {
            xtype: "syno_displayfield",
            indent: 1,
            value: "open_basedir" + _T("common", "colon")
        }, {
            xtype: "syno_compositefield",
            name: "open_basedir_customize_field",
            indent: 1,
            hideLabel: !0,
            items: [{
                xtype: "syno_radio",
                boxLabel: _TT("SYNO.SDS.WebStation.Application", "common", "customize"),
                id: this.open_basedir_customize_radio = Ext.id(),
                name: "open_basedir_customize_radio",
                width: 200,
                handler: function(e, t) {
                    t && this.toggleUseCustomOpenBasedir(!0)
                },
                scope: this
            }, {
                xtype: "syno_textfield",
                id: this.open_basedir = Ext.id(),
                name: "open_basedir",
                width: 300
            }]
        }, {
            xtype: "syno_compositefield",
            name: "open_basedir_default_field",
            indent: 1,
            hideLabel: !0,
            items: [{
                xtype: "syno_radio",
                boxLabel: _T("common", "default"),
                id: this.open_basedir_default_radio = Ext.id(),
                name: "open_basedir_default_radio",
                width: 200,
                handler: function(e, t) {
                    t && this.toggleUseCustomOpenBasedir(!1)
                },
                scope: this
            }, {
                xtype: "syno_displayfield",
                id: this.open_basedir_default = Ext.id(),
                name: "open_basedir_default",
                style: {
                    wordBreak: "break-all"
                },
                selectable: !0
            }]
        }), {
            xtype: "syno_fieldset",
            labelSeparator: _T("common", "colon"),
            items: e
        }
    },
    createExtensionGrid: function(e) {
        return this.colIndexed = new SYNO.ux.EnableColumn({
            id: "enable",
            dataIndex: "enable",
            menuDisabled: !0,
            bindRowClick: !1,
            align: "center",
            width: 60,
            fixed: !0,
            isIgnore: function(e, t) {
                return !!t.data.default_enable
            },
            renderer: function(e, t, i) {
                var a = "gray" === e ? "grayed" : e ? "checked" : "unchecked",
                    n = "grayed" === a ? "mixed" : "checked" === a,
                    o = i ? i.id + "_" + this.dataIndex : Ext.id(),
                    r = _JSLIBSTR("uicommon", "enable_column_" + a),
                    s = a;
                return !0 === i.get("default_enable") && (r = _JSLIBSTR("uicommon", "enable_column_" + a) + " " + _JSLIBSTR("common", "disabled"), s = "disabled-" + a), (t = t || {}).cellAttr = 'aria-label="' + Ext.util.Format.stripTags(this.orgHeader) + " " + r + '" aria-checked="' + n + '" role="checkbox"', String.format('<div class="syno-ux-grid-enable-column-{0}" aria-label="' + Ext.util.Format.stripTags(this.orgHeader) + " " + r + '" id="{2}"></div>', s, n, o)
            }
        }), this.extension_store = new Ext.data.SimpleStore({
            fields: ["enable", "name", "description", "default_enable"],
            data: []
        }), Ext.apply({
            xtype: "syno_gridpanel",
            enableColumnHide: !1,
            cls: "without-dirty-red-grid",
            plugins: [this.colIndexed],
            colModel: new Ext.grid.ColumnModel([this.colIndexed, {
                header: _TT("SYNO.SDS.WebStation.Application", "php", "extension_name"),
                id: "name",
                dataIndex: "name",
                menuDisabled: !0,
                width: 90,
                fixed: !0,
                resizable: !0
            }, {
                header: _TT("SYNO.SDS.WebStation.Application", "php", "extension_desc"),
                id: "description",
                dataIndex: "description",
                menuDisabled: !0,
                width: 200,
                resizable: !0,
                renderer: function(e) {
                    return '<div ext:qtip="' + e + '">' + e + "</div>"
                }
            }]),
            store: this.extension_store,
            autoExpandColumn: "name",
            selModel: new Ext.grid.RowSelectionModel
        }, e)
    },
    createGeneralSettingForm: function(e) {
        var t = {
            title: "",
            trackResetOnLoad: !0,
            itemId: "php_general_settings",
            labelWidth: 275,
            items: [this.createGeneralSettingBasicFieldSets()]
        };
        return Ext.apply(t, e), new SYNO.ux.FormPanel(t)
    },
    createCoreSettingColumnModel: function() {
        return new Ext.grid.ColumnModel([{
            header: _TT("SYNO.SDS.WebStation.Application", "php", "extension_name"),
            sortable: !0,
            width: "15px",
            dataIndex: "name",
            align: "left"
        }, {
            header: _TT("SYNO.SDS.WebStation.Application", "php_advanced_setting", "value"),
            dataIndex: "value",
            editor: {
                xtype: "syno_textfield",
                allowBlank: !0
            },
            renderer: function(e) {
                return null === e ? '<span class="disable-font" style="font-style: italic;">no value</span>' : Ext.util.Format.htmlEncode(e)
            }
        }])
    },
    createCoreSettingSearchFilter: function(e) {
        return new SYNO.ux.TextFilter({
            iconStyle: "search",
            itemId: "search",
            emptyText: _TT("SYNO.SDS.WebStation.Application", "php_advanced_setting", "search"),
            store: e,
            localFilter: !0,
            localFilterField: ["name"],
            blOr: !0
        })
    },
    createCoreSettingSearchComboBox: function(e) {
        return this.coreComboBox ? this.coreComboBox : (this.coreComboBox = new SYNO.ux.ComboBox({
            name: "custom_selector",
            fieldLabel: "",
            displayField: "name",
            valueField: "value",
            store: this.custom_selector,
            value: "all",
            listeners: {
                scope: this,
                select: function(t, i, a, n) {
                    var o = i.get("value");
                    "all" === o && e.isFiltered() ? e.clearFilter() : "custom" === o && e.filter([{
                        property: "is_custom",
                        value: !0
                    }])
                }
            }
        }), this.coreComboBox)
    },
    resetFieldCoreSettingHandler: function() {
        var e = this,
            t = this.core_setting_column.getSelectionModel().getSelections();
        t.length <= 0 || (this.coreModifiedList = {}, this.php_settings_store.getModifiedRecords().forEach(function(e) {
            this.coreModifiedList[e.get("name")] = e.get("value")
        }, this), Ext.each(t, function(t) {
            void 0 !== e.profile.php_settings[t.get("name")] && delete e.profile.php_settings[t.get("name")], void 0 !== e.coreModifiedList[t.get("name")] && delete e.coreModifiedList[t.get("name")]
        }), this.updateView(), this.coreComboBox.setValue("all"))
    },
    resetAllCoreSettingHandler: function() {
        this.profile.php_settings = {}, this.coreModifiedList = {}, this.updateView(), this.coreComboBox.setValue("all")
    },
    createCoreSettingResetButton: function() {
        return new SYNO.ux.SplitButton({
            text: _TT("SYNO.SDS.WebStation.Application", "actions", "reset_selected"),
            itemId: "reset_core_setting_group",
            cls: "syno-webstation-php-core-reset-button",
            handler: this.resetFieldCoreSettingHandler,
            scope: this,
            menu: {
                items: [{
                    text: _TT("SYNO.SDS.WebStation.Application", "actions", "reset_selected"),
                    scope: this,
                    handler: this.resetFieldCoreSettingHandler
                }, {
                    text: _TT("SYNO.SDS.WebStation.Application", "actions", "reset_all"),
                    scope: this,
                    handler: this.resetAllCoreSettingHandler
                }]
            }
        })
    },
    createCoreSettingColumn: function(e) {
        this.php_settings_store = new Ext.data.SimpleStore({
            pruneModifiedRecords: !0,
            fields: ["name", {
                name: "value",
                type: "auto"
            }, "is_custom"],
            data: [],
            listeners: {
                scope: this,
                update: function(e, t, i) {
                    t.set("is_custom", !0)
                }
            }
        }), this.custom_selector = new Ext.data.SimpleStore({
            fields: ["name", "value"],
            data: [
                [_TT("SYNO.SDS.WebStation.Application", "common", "show_all"), "all"],
                [_TT("SYNO.SDS.WebStation.Application", "common", "customize"), "custom"]
            ]
        });
        var t = this.createCoreSettingColumnModel(),
            i = this.createCoreSettingSearchFilter(this.php_settings_store),
            a = this.createCoreSettingSearchComboBox(this.php_settings_store),
            n = this.createCoreSettingResetButton(),
            o = {
                cm: t,
                ds: this.php_settings_store,
                sm: this.coreSelModel = new Ext.grid.RowSelectionModel({
                    singleSelect: !1
                }),
                tbar: {
                    items: [a, n, "->", i]
                },
                enableHdMenu: !1,
                enableColumnMove: !1,
                clicksToEdit: 1,
                listeners: {
                    scope: this,
                    rowcontextmenu: this.onCoreRowContextMenu
                }
            };
        return Ext.apply(o, e), new SYNO.ux.EditorGridPanel(o)
    },
    createFpmSettingForm: function(e) {
        var t = new Ext.data.SimpleStore({
                fields: ["mode", "value"],
                data: [
                    [_TT("SYNO.SDS.WebStation.Application", "php_advanced_setting", "fpm_mode_static"), "static"],
                    [_TT("SYNO.SDS.WebStation.Application", "php_advanced_setting", "fpm_mode_dynamic"), "dynamic"],
                    [_TT("SYNO.SDS.WebStation.Application", "php_advanced_setting", "fpm_mode_ondemand"), "ondemand"]
                ]
            }),
            i = {
                title: "",
                trackResetOnLoad: !0,
                itemId: "php_fpm_settings",
                labelWidth: 275,
                labelSeparator: _T("common", "colon"),
                items: [{
                    xtype: "syno_combobox",
                    name: "mode",
                    fieldLabel: _TT("SYNO.SDS.WebStation.Application", "php_advanced_setting", "fpm_process_mode"),
                    displayField: "mode",
                    valueField: "value",
                    store: t
                }, {
                    xtype: "syno_numberfield",
                    name: "max_children",
                    maxlength: 64,
                    fieldLabel: _TT("SYNO.SDS.WebStation.Application", "php_advanced_setting", "fpm_max_children"),
                    allowBlank: !1,
                    minValue: 1,
                    validator: this.validateMaxChildren.bind(this),
                    validateOnBlur: !1
                }, {
                    xtype: "syno_numberfield",
                    name: "start_servers",
                    maxlength: 64,
                    fieldLabel: _TT("SYNO.SDS.WebStation.Application", "php_advanced_setting", "fpm_start_servers"),
                    allowBlank: !1,
                    minValue: 1,
                    validator: this.validateStartServers.bind(this)
                }, {
                    xtype: "syno_numberfield",
                    name: "min_spare_servers",
                    maxlength: 64,
                    fieldLabel: _TT("SYNO.SDS.WebStation.Application", "php_advanced_setting", "fpm_min_spare_servers"),
                    allowBlank: !1,
                    minValue: 1,
                    validator: this.validateMinSpareServers.bind(this)
                }, {
                    xtype: "syno_numberfield",
                    name: "max_spare_servers",
                    maxlength: 64,
                    fieldLabel: _TT("SYNO.SDS.WebStation.Application", "php_advanced_setting", "fpm_max_spare_servers"),
                    allowBlank: !1,
                    minValue: 1,
                    validator: this.validateMaxSpareServers.bind(this)
                }]
            };
        return Ext.apply(i, e), new SYNO.ux.FormPanel(i)
    },
    validateMaxChildren: function(e) {
        e = parseInt(e, 10);
        var t = this.fpm_setting_form.getForm().getFieldValues(!1);
        return "dynamic" !== t.mode || (t.min_spare_servers >= e ? _TT("SYNO.SDS.WebStation.Application", "error", "err_fpm_less_min_spare") : !(t.max_spare_servers >= e) || _TT("SYNO.SDS.WebStation.Application", "error", "err_fpm_less_max_spare"))
    },
    validateStartServers: function(e) {
        e = parseInt(e, 10);
        var t = this.fpm_setting_form.getForm().getFieldValues(!1);
        return "dynamic" !== t.mode || (t.min_spare_servers > e ? _TT("SYNO.SDS.WebStation.Application", "error", "err_fpm_less_min_spare") : !(t.max_spare_servers < e) || _TT("SYNO.SDS.WebStation.Application", "error", "err_fpm_larger_max_spare"))
    },
    validateMinSpareServers: function(e) {
        e = parseInt(e, 10);
        var t = this.fpm_setting_form.getForm().getFieldValues(!1);
        return "dynamic" !== t.mode || (t.start_servers < e ? _TT("SYNO.SDS.WebStation.Application", "error", "err_fpm_larger_start_servers") : !(t.max_children <= e) || _TT("SYNO.SDS.WebStation.Application", "error", "err_fpm_larger_max_children"))
    },
    validateMaxSpareServers: function(e) {
        e = parseInt(e, 10);
        var t = this.fpm_setting_form.getForm().getFieldValues(!1);
        return "dynamic" !== t.mode || (t.start_servers > e ? _TT("SYNO.SDS.WebStation.Application", "error", "err_fpm_less_start_servers") : !(t.max_children <= e) || _TT("SYNO.SDS.WebStation.Application", "error", "err_fpm_larger_max_children"))
    },
    getGeneralSettingValues: function() {
        var e = this.general_settings_form.getForm(),
            t = e.getFieldValues(!1);
        return {
            uuid: this.profile.uuid,
            profile_name: e.findField("profile_name").getValue(),
            profile_desc: e.findField("profile_desc").getValue(),
            backend: e.findField("backend").getValue(),
            custom_open_basedir: Ext.getCmp(this.open_basedir_customize_radio).getValue(),
            open_basedir: Ext.getCmp(this.open_basedir).getValue(),
            display_errors: t.display_errors,
            enable_cache: t.enable_cache,
            enable_xdebug: t.enable_xdebug
        }
    },
    getExtensionsValue: function() {
        var e = [];
        return this.extension_store.each(function(t) {
            var i = t.data.enable,
                a = t.data.default_enable;
            (t.data.enable && !a || i && a) && e.push(t.data.name)
        }), e
    },
    getCoreSettingContextActionGroup: function() {
        return this.coreContextMenu ? this.coreContextMenu : (this.coreContextMenu = new SYNO.ux.Utils.ActionGroup([new Ext.Action({
            text: _TT("SYNO.SDS.WebStation.Application", "actions", "reset_selected"),
            itemId: "reset_field",
            scope: this,
            handler: this.resetFieldCoreSettingHandler
        })]), this.coreContextMenu)
    },
    sendRequest: function() {
        var e = this.getGeneralSettingValues(),
            t = this.fpm_setting_form.getForm();
        e.fpm_settings = t.getFieldValues(!1);
        var i = this.profile.php_settings;
        this.php_settings_store.query("is_custom", !0).each(function(e) {
            i[e.get("name")] = e.get("value")
        }), e.php_settings = i, e.extensions = this.getExtensionsValue(), this.sendWebAPI({
            api: this.webapi.api,
            method: this.webapi.method,
            version: this.webapi.version,
            scope: this,
            params: {
                profile: e
            },
            callback: function(e, t) {
                this.clearStatusBusy(), this.fireEvent("close"), this.close()
            }
        })
    },
    onCoreRowContextMenu: function(e, t, i, a) {
        var n = new SYNO.ux.Menu({
                autoDestroy: !0,
                items: this.getCoreSettingContextActionGroup().getArray()
            }),
            o = this.core_setting_column.getSelectionModel();
        o.selectRow(t, o.isSelected(t)), n.showAt(i.getXY()), i.preventDefault()
    },
    onApply: function() {
        this.general_settings_form.getForm().isValid() && this.profile ? this.fpm_setting_form.getForm().isValid() && this.validateStartServers() && this.validateMaxChildren() ? (this.setStatusBusy(), this.sendRequest()) : this.setStatusError({
            text: _TT("SYNO.SDS.WebStation.Application", "error", "err_fpm_settings_invalid"),
            clear: !0
        }) : this.setStatusError({
            text: _T("common", "forminvalid"),
            clear: !0
        })
    },
    onCancel: function() {
        var e = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t, i, a, n = this;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        if (this.general_settings_form.getForm().isDirty() || this.fpm_setting_form.getForm().isDirty()) {
                            e.next = 2;
                            break
                        }
                        return e.abrupt("return", this.close());
                    case 2:
                        return t = this.findAppWindow(), i = function() {
                            return new Promise(function(e) {
                                t.getMsgBox().confirm(_TT("SYNO.SDS.WebStation.Application", "title", "vhost"), n.isEditProfile ? _TT("SYNO.SDS.WebStation.Application", "common", "confirm_edit_page") : _TT("SYNO.SDS.WebStation.Application", "common", "confirm_create_page"), e, t, {
                                    yes: _T("common", "save"),
                                    no: _T("common", "cancel"),
                                    leftCustom: _T("common", "dont_save")
                                })
                            })
                        }, e.next = 6, i();
                    case 6:
                        if ("yes" !== (a = e.sent)) {
                            e.next = 9;
                            break
                        }
                        return e.abrupt("return", this.onApply());
                    case 9:
                        if ("no" !== a) {
                            e.next = 11;
                            break
                        }
                        return e.abrupt("return");
                    case 11:
                        if ("leftCustom" !== a) {
                            e.next = 13;
                            break
                        }
                        return e.abrupt("return", this.close());
                    case 13:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return function() {
            return e.apply(this, arguments)
        }
    }(),
    toggleUseCustomOpenBasedir: function(e) {
        e ? (Ext.getCmp(this.open_basedir_customize_radio).setValue(!0), Ext.getCmp(this.open_basedir_default_radio).setValue(!1)) : (Ext.getCmp(this.open_basedir_customize_radio).setValue(!1), Ext.getCmp(this.open_basedir_default_radio).setValue(!0))
    }
}), Ext.ns("SYNO.SDS.WebStation.PHPProfileTab"), Ext.define("SYNO.SDS.WebStation.PHPProfileTab.Main", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t;
        this.module = e.module, this.owner = e.owner, t = this.fillConfig(e), this.callParent([t]), this.LoadPHPProfile(), this.mon(SYNO.SDS.StatusNotifier, "thirdpartychanged", this.onPkgChanged, this)
    },
    fillConfig: function(e) {
        this.EmptyPanel = new SYNO.SDS.WebStation.PHPProfileTab.Empty({
            module: e.module,
            owner: e.owner,
            itemId: "Empty"
        }), this.LoadPanel = new SYNO.SDS.WebStation.PHPProfileTab.Load({
            module: e.module,
            appWin: e.appWin,
            owner: e.owner,
            itemId: "Load"
        });
        var t = {
            title: "PHP",
            layout: "fit",
            style: "padding-top: 0px",
            items: [],
            listeners: {
                activate: this.LoadPHPProfile,
                resize: this.SetPanelSize
            }
        };
        return t.items = [this.EmptyPanel, this.LoadPanel], t
    },
    onPkgChanged: function(e) {
        "WebStation" !== e && this.LoadPHPProfile()
    },
    LoadPHPProfile: function() {
        this.sendWebAPI({
            api: "SYNO.WebStation.Status",
            method: "get",
            version: 1,
            scope: this,
            callback: function(e, t) {
                this.SetPanelSize(), null === t.available_php_backend ? (this.EmptyPanel.show(), this.LoadPanel.hide()) : (this.EmptyPanel.hide(), this.LoadPanel.show(), this.LoadPanel.loadServiceProfiles())
            }
        })
    },
    SetPanelSize: function(e, t, i) {
        this.LoadPanel.setSize(t, i), this.EmptyPanel.setSize(t, i)
    }
}), Ext.define("SYNO.SDS.WebStation.PHPProfileTab.Empty", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t;
        this.module = e.module, this.owner = e.owner, t = this.fillConfig(e), this.callParent([t])
    },
    fillConfig: function(e) {
        var t = {
            layout: {
                type: "vbox",
                align: "center",
                pack: "center"
            },
            items: []
        };
        return t.items.push({
            xtype: "label",
            name: "empty_icon",
            width: 120,
            height: 120,
            cls: "syno-empty-icon"
        }, {
            xtype: "label",
            name: "notice_php_no_backen",
            text: _TT("SYNO.SDS.WebStation.Application", "php", "php_no_backend"),
            margins: {
                top: 20,
                right: 0,
                bottom: 20,
                left: 0
            },
            style: {
                color: "rgba(50, 60, 70, 0.60)",
                "line-Height": "20px"
            }
        }), Ext.apply(t, e), t
    }
}), Ext.define("SYNO.SDS.WebStation.PHPProfileTab.Load", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(e) {
        this.module = e.module, this.appWin = e.appWin, this.owner = e.owner, this.store = new Ext.data.GroupingStore({
            reader: new Ext.data.JsonReader({
                fields: ["uuid", {
                    name: "enable",
                    convert: this.converterPHPEnable
                }, "profile_name", {
                    name: "backend",
                    convert: this.converterPHPBackend
                }, "profile_desc", {
                    name: "removable",
                    convert: this.converterRemovable
                }],
                root: "profiles",
                idProperty: "uuid",
                totalProperty: "total"
            }),
            proxy: new SYNO.API.Proxy({
                api: "SYNO.WebStation.PHP.Profile",
                version: 1,
                method: "list"
            }),
            groupField: "removable",
            appWindow: this.owner,
            autoDestroy: !0,
            listeners: {
                beforeload: {
                    scope: this,
                    fn: this.onStoreBeforeLoaded
                },
                load: {
                    scope: this,
                    fn: this.onStoreLoaded
                }
            }
        });
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        return Ext.apply({
            style: "padding-top: 0px",
            store: this.store,
            tbar: {
                xtype: "syno_toolbar",
                defaultType: "syno_button",
                items: this.getTbarItems().getArray()
            },
            bbar: new SYNO.ux.PagingToolbar({
                store: this.store,
                displayInfo: !0
            }),
            columns: [{
                dataIndex: "removable",
                hidden: !0,
                renderer: function(e) {
                    return !1 === e ? _TT("SYNO.SDS.WebStation.Application", "php", "header_group_default_profile") : _TT("SYNO.SDS.WebStation.Application", "php", "header_group_custom_profile")
                }
            }, {
                dataIndex: "uuid",
                header: _TT("SYNO.SDS.WebStation.Application", "common", "service"),
                align: "left",
                sortable: !0,
                scope: this,
                renderer: function(e, t) {
                    var i;
                    if (e && void 0 !== this.serviceIdMap[e] && void 0 !== this.serviceIdMap[e].display_name) {
                        var a = this.serviceIdMap[e].display_name_i18n,
                            n = this.serviceIdMap[e].display_name;
                        i = SYNO.SDS.WebStation.Util.geti18nString(a, n)
                    } else i = _TT("SYNO.SDS.WebStation.Application", "common", "user_defined");
                    return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(i) + '"', i
                }
            }, {
                dataIndex: "enable",
                header: _TT("SYNO.SDS.WebStation.Application", "common", "status"),
                align: "left",
                sortable: !0,
                renderer: function(e, t) {
                    var i, a;
                    return e ? (i = _TT("SYNO.SDS.WebStation.Application", "common", "status_available"), a = "green") : (i = _TT("SYNO.SDS.WebStation.Application", "common", "status_not_available"), a = "red"), t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(i) + '"', String.format('<font class="{0}-status">{1}</font>', a, i)
                }
            }, {
                dataIndex: "profile_name",
                header: _TT("SYNO.SDS.WebStation.Application", "php", "profile_name"),
                align: "left",
                sortable: !0,
                renderer: function(e, t) {
                    var i = Ext.util.Format.htmlEncode(e);
                    return t.attr = "ext:qtip=" + Ext.util.Format.htmlEncode(i), i
                }
            }, {
                dataIndex: "backend",
                header: _TT("SYNO.SDS.WebStation.Application", "php", "version"),
                align: "left",
                sortable: !0,
                renderer: function(e, t) {
                    return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(e) + '"', e
                }
            }, {
                dataIndex: "profile_desc",
                header: _TT("SYNO.SDS.WebStation.Application", "php", "profile_desc"),
                align: "left",
                sortable: !0,
                renderer: function(e, t) {
                    var i = Ext.util.Format.htmlEncode(e);
                    return t.attr = "ext:qtip=" + Ext.util.Format.htmlEncode(i), i
                }
            }],
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: !1,
                listeners: {
                    selectionchange: {
                        scope: this,
                        fn: this.onSelectionChange
                    }
                }
            }),
            view: new SYNO.ux.GroupingView({
                showGroupName: !1,
                enableGroupingMenu: !1,
                forceFit: !0
            }),
            enableHdMenu: !1,
            enableColumnMove: !1,
            enableColLock: !1,
            listeners: {
                scope: this,
                rowdblclick: this.onRowDblclick,
                rowcontextmenu: this.onRowContextMenu
            }
        }, e)
    },
    createHandler: function() {
        this.busy(), this.sendWebAPI({
            api: "SYNO.WebStation.PHP",
            method: "get",
            version: 1,
            scope: this,
            params: {},
            callback: function(e, t) {
                this.sendWebAPI({
                    api: "SYNO.WebStation.Status",
                    method: "get",
                    version: 1,
                    scope: this,
                    callback: function(e, i) {
                        var a = new SYNO.SDS.WebStation.Web.PHPAdvancedSetting({
                            owner: this.appWin,
                            module: this,
                            default_settings: t,
                            available_php_backend: i.available_php_backend,
                            title: _TT("SYNO.SDS.WebStation.Application", "php", "create_php_profile"),
                            isEditProfile: !1,
                            webapi: {
                                api: "SYNO.WebStation.PHP.Profile",
                                method: "add",
                                version: 1
                            },
                            listeners: {
                                close: this.webapiDone,
                                scope: this
                            }
                        });
                        a.setInitData(), a.show()
                    }
                })
            }
        })
    },
    editHandler: function() {
        var e = this.getSelectionModel().getSelections();
        if (1 === e.length) {
            this.busy();
            var t = {
                    api: "SYNO.WebStation.PHP",
                    method: "get",
                    version: 1
                },
                i = {
                    api: "SYNO.WebStation.Status",
                    method: "get",
                    version: 1
                },
                a = [t, i];
            this.appWin.sendWebAPI({
                compound: {
                    stopwhenerror: !0,
                    params: a
                },
                scope: this,
                callback: function(a, n) {
                    var o = new SYNO.SDS.WebStation.Web.PHPAdvancedSetting({
                        owner: this.appWin,
                        module: this,
                        default_settings: SYNO.SDS.WebStation.Util.getSuccessRespCompoundData(t, n),
                        available_php_backend: SYNO.SDS.WebStation.Util.getSuccessRespCompoundData(i, n).available_php_backend,
                        title: _TT("SYNO.SDS.WebStation.Application", "php", "edit_php_profile"),
                        isEditProfile: !0,
                        webapi: {
                            api: "SYNO.WebStation.PHP.Profile",
                            method: "update",
                            version: 1
                        },
                        listeners: {
                            close: this.webapiDone,
                            scope: this
                        }
                    });
                    o.setData(e[0].json), o.show()
                }
            })
        }
    },
    deleteHandler: function() {
        var e = this.getSelectionModel(),
            t = e.getSelections();
        t.length && !this.hasDefaultProfile(t) && this.owner.getMsgBox().confirmDelete(_TT("SYNO.SDS.WebStation.Application", "title", "vhost"), _T("common", "remove_cfrmrmv"), function(i) {
            if ("yes" === i) {
                this.busy();
                var a = [];
                1 === t.length && e.selectNext(), Ext.each(t, function(e) {
                    this.store.remove(e), a.push(e.json.uuid)
                }, this), this.sendWebAPI({
                    api: "SYNO.WebStation.PHP.Profile",
                    method: "delete",
                    version: 1,
                    params: {
                        uuids: a
                    },
                    scope: this,
                    callback: this.webapiDone
                })
            }
        }, this)
    },
    onStoreBeforeLoaded: function(e, t, i) {
        this.busy()
    },
    onStoreLoaded: function(e, t, i, a) {
        var n = this.getSelectionModel().getSelections().length,
            o = this.getTbarItems();
        0 === n && (o.disable("delete"), o.disable("edit")), this.unbusy()
    },
    onSelectionChange: function(e, t) {
        var i = this.selModel.getSelections(),
            a = i.length,
            n = this.getTbarItems(),
            o = this.getContextActionGroup();
        if (0 === a ? (n.disable("delete"), n.disable("edit"), o.disable("delete"), o.disable("edit")) : (n.enable("delete"), o.enable("delete"), 1 === a ? (n.enable("edit"), o.enable("edit")) : (n.disable("edit"), o.disable("edit"))), this.hasDefaultProfile(i)) return n.disable("delete"), void o.disable("delete")
    },
    onRowDblclick: function(e, t, i, a) {
        this.editHandler()
    },
    onRowContextMenu: function(e, t, i, a) {
        var n = new SYNO.ux.Menu({
                autoDestroy: !0,
                items: this.getContextActionGroup().getArray()
            }),
            o = this.getSelectionModel();
        o.selectRow(t, o.isSelected(t)), n.showAt(i.getXY()), i.preventDefault()
    },
    busy: function() {
        this.el.mask(_T("common", "loading"), "x-mask-loading")
    },
    unbusy: function() {
        this.el.unmask()
    },
    webapiDone: function(e, t, i) {
        this.unbusy(), this.loadServiceProfiles()
    },
    converterRemovable: function(e, t) {
        return !t.default_profile
    },
    converterPHPEnable: function(e, t) {
        return t.default_profile ? t.default_profile.enable : e
    },
    converterPHPBackend: function(e, t) {
        var i = t.default_profile ? t.default_profile.backend : e,
            a = SYNO.SDS.WebStation.Util.PackageInfo._packageData.backendData.php.find(function(e) {
                return e.id === i
            });
        return void 0 === a ? t.profile_desc.split(" ").slice(1, 3).join(" ") : a.name
    },
    getTbarItems: function() {
        return this.tbarItems ? this.tbarItems : (this.tbarItems = new SYNO.ux.Utils.ActionGroup([new Ext.Action({
            text: _T("common", "create"),
            itemId: "create",
            disabled: this._S("demo_mode"),
            scope: this,
            handler: this.createHandler
        }), new Ext.Action({
            text: _T("common", "alt_edit"),
            itemId: "edit",
            scope: this,
            handler: this.editHandler
        }), new Ext.Action({
            text: _T("common", "delete"),
            itemId: "delete",
            scope: this,
            handler: this.deleteHandler
        })]), this.tbarItems)
    },
    getContextActionGroup: function() {
        return this.contextMenu ? this.contextMenu : (this.contextMenu = new SYNO.ux.Utils.ActionGroup([new Ext.Action({
            text: _T("common", "alt_edit"),
            itemId: "edit",
            scope: this,
            handler: this.editHandler
        }), new Ext.Action({
            text: _T("common", "delete"),
            itemId: "delete",
            scope: this,
            handler: this.deleteHandler
        })]), this.contextMenu)
    },
    loadServiceProfiles: function() {
        this.busy(), this.sendWebAPI({
            api: "SYNO.WebStation.WebService.Service",
            method: "list",
            version: 1,
            scope: this,
            callback: function() {
                var e = _asyncToGenerator(regeneratorRuntime.mark(function e(t, i) {
                    var a = this;
                    return regeneratorRuntime.wrap(function(e) {
                        for (;;) switch (e.prev = e.next) {
                            case 0:
                                if (!t) {
                                    e.next = 6;
                                    break
                                }
                                return e.next = 3, SYNO.SDS.WebStation.Util.PackageInfo.Get();
                            case 3:
                                this.store.load(), this.serviceIdMap = {}, i.services && i.services.forEach(function(e) {
                                    a.serviceIdMap[e.id] = e
                                });
                            case 6:
                            case "end":
                                return e.stop()
                        }
                    }, e, this)
                }));
                return function(t, i) {
                    return e.apply(this, arguments)
                }
            }()
        })
    },
    hasDefaultProfile: function(e) {
        for (var t = e.length, i = 0; i < t; i++)
            if (!1 === e[i].get("removable")) return !0;
        return !1
    }
}), Ext.define("SYNO.SDS.WebStation.ScriptLanguageTab", {
    extend: "SYNO.SDS.Utils.TabPanel",
    constructor: function(e) {
        var t = Ext.apply({
            activeTab: 0,
            cls: "ws-script-main",
            items: [this.phpTab = new SYNO.SDS.WebStation.PHPProfileTab.Main({
                module: e,
                appWin: e.appWin,
                owner: e.owner
            })]
        }, e);
        this.callParent([t])
    }
}), Ext.define("SYNO.SDS.WebStation.Web.VHostEditor", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.module = e.module, this.owner = e.owner, this.store = e.store, this.webapi = e.webapi, this.uuid = "", this.panel = new SYNO.SDS.WebStation.Web.VHostPanel({
            module: this.module,
            owner: this
        }), this.callParent([Ext.apply({
            width: 650,
            autoHeight: !0,
            items: [this.panel],
            closeAction: "onCancel",
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: this.onCancel
            }, {
                text: _T("common", "save"),
                btnStyle: "blue",
                disabled: this._S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                scope: this,
                handler: this.onApply
            }]
        }, e)]), this.setStatusBusy()
    },
    sendRequest: function(e) {
        var t = this.panel.getData();
        t.apply_permission = e, this.sendWebAPI({
            api: this.webapi.api,
            method: this.webapi.method,
            version: this.webapi.version,
            params: {
                host: t
            },
            callback: function(e, t) {
                this.clearStatusBusy(), e ? (this.fireEvent("close"), this.close()) : this.onError(t.code, t.errors)
            },
            scope: this
        })
    },
    onForceAcl: function(e) {
        "yes" == e && this.panel.getForm().isValid() && this.validator() && (this.panel.getForm().isDirty() ? (this.setStatusBusy(), this.sendRequest(!0)) : this.close())
    },
    onApply: function() {
        this.panel.getForm().isValid() && this.validator() ? this.panel.getForm().isDirty() ? (this.setStatusBusy(), this.sendRequest(!1)) : this.close() : this.setStatusError({
            text: _T("error", "error_bad_field"),
            clear: !0
        })
    },
    onCancel: function() {
        var e = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t, i, a;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        if (this.panel.getForm().isDirty()) {
                            e.next = 2;
                            break
                        }
                        return e.abrupt("return", this.close());
                    case 2:
                        return t = this.findAppWindow(), i = function() {
                            return new Promise(function(e) {
                                t.getMsgBox().confirm(_TT("SYNO.SDS.WebStation.Application", "title", "vhost"), _TT("SYNO.SDS.WebStation.Application", "common", "confirm_edit_page"), e, t, {
                                    yes: _T("common", "save"),
                                    no: _T("common", "cancel"),
                                    leftCustom: _T("common", "dont_save")
                                })
                            })
                        }, e.next = 6, i();
                    case 6:
                        if ("yes" !== (a = e.sent)) {
                            e.next = 9;
                            break
                        }
                        return e.abrupt("return", this.onApply());
                    case 9:
                        if ("no" !== a) {
                            e.next = 11;
                            break
                        }
                        return e.abrupt("return");
                    case 11:
                        if ("leftCustom" !== a) {
                            e.next = 13;
                            break
                        }
                        return e.abrupt("return", this.close());
                    case 13:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return function() {
            return e.apply(this, arguments)
        }
    }(),
    handleConflictHost: function(e) {
        var t = this.panel.getForm(),
            i = !t.findField("fqdn").disabled,
            a = t.findField(i ? "name_http_port" : "port_http_port"),
            n = t.findField(i ? "name_https_port" : "port_https_port"),
            o = {
                text: _TT("SYNO.SDS.WebStation.Application", "error", i ? "err_host_duplicated" : "err_port_conflict"),
                clear: !0
            };
        i && t.findField("fqdn").markInvalid(o.text), this.setStatusError(o), [a, n].forEach(function(t) {
            !t.disabled && e.includes(parseInt(t.getValue(), 10)) && t.markInvalid(_TT("SYNO.SDS.WebStation.Application", "error", "err_port_conflict"))
        })
    },
    onError: function(e, t) {
        var i = this.panel.getForm(),
            a = SYNO.SDS.WebStation.Errors.GetMessage(e);
        switch (e) {
            case 1004:
                this.handleConflictHost(t.conflict_ports);
                break;
            case 1007:
                i.findField("fqdn").markInvalid(a), this.setStatusError({
                    text: a,
                    clear: !0
                });
                break;
            case 1009:
            case 1021:
                this.handleConflictHost(t.conflict_ports);
                break;
            case 1022:
                this.module.appWin.getMsgBox().confirm("ACL Error", a, this.onForceAcl, this);
                break;
            default:
                this.setStatusError({
                    text: a,
                    clear: !0
                })
        }
    },
    setData: function(e) {
        return this.panel.setData(e)
    },
    validator: function() {
        var e = this.panel.getForm().getValues();
        return ("name" !== e.based || e.name_port || e.name_http || e.name_https) && !("port" === e.based && !e.port_http && !e.port_https) || (this.setStatusError({
            text: _TT("SYNO.SDS.WebStation.Application", "error", "err_no_port_set"),
            clear: !0
        }), !1)
    }
}), Ext.define("SYNO.SDS.WebStation.Web.VHostPanel", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(e) {
        this.module = e.module, this.owner = e.owner;
        var t = Ext.apply({
            monitorValid: !0,
            autoFlexcroll: !0,
            height: 476,
            fieldWidth: 270,
            bodyStyle: "padding-right:0px; padding-left:0px;",
            labelSeparator: _T("common", "colon"),
            webapi: {
                api: "SYNO.WebStation.Status",
                methods: {
                    get: "get"
                },
                version: 1
            },
            items: [{
                xtype: "syno_radio",
                name: "based",
                boxLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "name_based"),
                checked: !0,
                inputValue: "name",
                id: this.name_based = Ext.id(),
                scope: this,
                handler: this.enableHandler
            }, {
                xtype: "syno_textfield",
                vtype: "FQDN",
                maxlength: 255,
                allowBlank: !1,
                indent: 1,
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "hostname"),
                name: "fqdn",
                validator: this.validateFQDN.createDelegate(this)
            }, {
                xtype: "syno_compositefield",
                indent: 1,
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "port"),
                items: [{
                    xtype: "syno_checkbox",
                    name: "name_port",
                    boxLabel: "80 / 443",
                    checked: !1,
                    inputValue: "default"
                }]
            }, {
                xtype: "syno_compositefield",
                indent: 1,
                items: [{
                    xtype: "syno_checkbox",
                    name: "name_http",
                    boxLabel: "HTTP",
                    width: 90,
                    inputValue: "http",
                    scope: this,
                    handler: this.enableHandler
                }, {
                    disabled: !0,
                    xtype: "syno_textfield",
                    vtype: "port",
                    allowBlank: !1,
                    name: "name_http_port",
                    width: 60,
                    maxlength: 5,
                    validator: function(e) {
                        return 80 != e
                    }
                }]
            }, {
                xtype: "syno_compositefield",
                indent: 1,
                items: [{
                    xtype: "syno_checkbox",
                    name: "name_https",
                    boxLabel: "HTTPS",
                    width: 90,
                    inputValue: "https",
                    scope: this,
                    handler: this.enableHandler
                }, {
                    disabled: !0,
                    xtype: "syno_textfield",
                    vtype: "port",
                    allowBlank: !1,
                    name: "name_https_port",
                    width: 60,
                    maxlength: 5,
                    validator: function(e) {
                        return 443 != e
                    }
                }]
            }, {
                xtype: "syno_radio",
                name: "based",
                indent: 0,
                boxLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "port_based"),
                inputValue: "port",
                scope: this,
                handler: this.enableHandler
            }, {
                xtype: "syno_compositefield",
                indent: 1,
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "port"),
                items: [{
                    disabled: !0,
                    xtype: "syno_checkbox",
                    name: "port_http",
                    width: 90,
                    boxLabel: "HTTP",
                    inputValue: "http",
                    scope: this,
                    handler: this.enableHandler
                }, {
                    disabled: !0,
                    xtype: "syno_textfield",
                    vtype: "port",
                    allowBlank: !1,
                    name: "port_http_port",
                    width: 60,
                    maxlength: 5
                }]
            }, {
                xtype: "syno_compositefield",
                indent: 1,
                items: [{
                    disabled: !0,
                    xtype: "syno_checkbox",
                    name: "port_https",
                    width: 90,
                    boxLabel: "HTTPS",
                    inputValue: "https",
                    scope: this,
                    handler: this.enableHandler
                }, {
                    disabled: !0,
                    xtype: "syno_textfield",
                    vtype: "port",
                    allowBlank: !1,
                    name: "port_https_port",
                    width: 60,
                    maxlength: 5
                }]
            }, {
                xtype: "syno_compositefield",
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "docroot"),
                items: [{
                    xtype: "syno_textfield",
                    allowBlank: !1,
                    readOnly: !0,
                    width: 270,
                    name: "root"
                }, {
                    xtype: "syno_button",
                    text: _TT("SYNO.SDS.WebStation.Application", "vhost", "choose_dir"),
                    width: 90,
                    scope: this,
                    handler: this.docrootSelect
                }]
            }, {
                xtype: "syno_compositefield",
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "https_settings"),
                items: [{
                    xtype: "syno_checkbox",
                    name: "hsts",
                    boxLabel: "HSTS"
                }]
            }, {
                xtype: "syno_combobox",
                name: "backend",
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "http_backend"),
                displayField: "backend_name",
                allowBlank: !1,
                valueField: "backend_id",
                store: new Ext.data.SimpleStore({
                    fields: ["backend_id", "backend_name"],
                    listeners: {
                        load: {
                            scope: this,
                            fn: this.onAvailableServerLoad
                        }
                    }
                })
            }, {
                xtype: "syno_combobox",
                name: "php_backend",
                fieldLabel: "PHP",
                displayField: "profile_name",
                allowBlank: !1,
                valueField: "uuid",
                store: new Ext.data.SimpleStore({
                    fields: ["uuid", "profile_name"],
                    listeners: {
                        load: {
                            scope: this,
                            fn: this.onAvailablePHPLoad
                        }
                    }
                }),
                tpl: '<tpl for="."><div ext:qtip="{profile_name}" class="x-combo-list-item">{profile_name}</div></tpl>'
            }, {
                xtype: "syno_combobox",
                name: "acl",
                fieldLabel: _T("app_port_alias", "desc_acl"),
                displayField: "name",
                valueField: "UUID",
                store: new SYNO.API.JsonStore({
                    appWindow: this.module.appWin,
                    defaultSortable: !0,
                    autoDestroy: !0,
                    autoLoad: !0,
                    root: "entries",
                    idProperty: "UUID",
                    fields: ["UUID", "name"],
                    api: "SYNO.Core.AppPortal.AccessControl",
                    version: 1,
                    method: "list",
                    listeners: {
                        load: {
                            scope: this,
                            fn: this.onAvailableAclLoad
                        }
                    }
                }),
                tpl: '<tpl for="."><div ext:qtip="{name}" class="x-combo-list-item">{name}</div></tpl>'
            }, {
                xtype: "syno_combobox",
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "error_page_profile"),
                name: "error_page",
                valueField: "id",
                displayField: "desc",
                store: new SYNO.API.JsonStore({
                    appWindow: this.module.appWin,
                    defaultSortable: !0,
                    autoDestroy: !0,
                    autoLoad: !0,
                    root: "profiles",
                    idProperty: "id",
                    fields: ["id", "desc"],
                    api: "SYNO.WebStation.ErrorPage",
                    version: 1,
                    method: "list",
                    listeners: {
                        scope: this,
                        load: this.onAvailableErrorPageLoaded
                    }
                }),
                tpl: '<tpl for="."><div ext:qtip="{desc}" class="x-combo-list-item">{desc}</div></tpl>'
            }]
        }, e);
        this.FQDNChecker = new SYNO.SDS.AdminCenter.Utils.Validator.FQDNConflictChecker, this.FQDNChecker.FindListFQDNPortPair(this.owner, "SYNO.WebStation.HTTP.VHost"), this.callParent([t]), this.loadForm(), this.doLayout(), this.mon(SYNO.SDS.StatusNotifier, "thirdpartychanged", this.onPkgChanged, this), this.mon(this, "afterlayout", this.addToolTip, this, {
            single: !0
        })
    },
    addToolTip: function() {
        [{
            field: "php_backend",
            msg: _TT("SYNO.SDS.WebStation.Application", "php", "no_php_profile_available")
        }, {
            field: "acl",
            msg: _TT("SYNO.SDS.WebStation.Application", "common", "no_acl_profile_available")
        }, {
            field: "error_page",
            msg: _TT("SYNO.SDS.WebStation.Application", "common", "tip_error_page_profile")
        }].forEach(function(e) {
            var t = this.getForm().findField(e.field);
            SYNO.ux.AddTip(t.getEl(), e.msg)
        }, this)
    },
    onPkgChanged: function(e, t) {
        "WebStation" !== e && this.loadForm()
    },
    processParams: function(e, t) {
        this.callParent(arguments);
        return t.push({
            api: "SYNO.WebStation.PHP.Profile",
            method: "list",
            version: 1
        }), t
    },
    processReturnData: function() {
        var e = _asyncToGenerator(regeneratorRuntime.mark(function e(t, i, a) {
            var n, o, r, s, l, d, p, c, h, u, S;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        if ("get" !== t) {
                            e.next = 21;
                            break
                        }
                        return n = {
                            api: "SYNO.WebStation.Status",
                            method: "get",
                            version: 1
                        }, this.getForm().setValues(this.vhost_data), o = SYNO.SDS.WebStation.Util.getSuccessRespCompoundData(n, i), r = {
                            api: "SYNO.WebStation.PHP.Profile",
                            method: "list",
                            version: 1
                        }, s = SYNO.SDS.WebStation.Util.getSuccessRespCompoundData(r, i).profiles, e.next = 8, SYNO.SDS.WebStation.Util.PackageInfo.Get();
                    case 8:
                        l = e.sent, d = o.available_server_backend.map(function(e) {
                            return [e, l.backendData.server.find(function(t) {
                                return t.id === e
                            }).name]
                        }), this.getForm().findField("backend").getStore().loadData(d), p = [
                            [null, _TT("SYNO.SDS.WebStation.Application", "default", "php_not_configured")]
                        ].concat(s.filter(function(e) {
                            return null === e.default_profile
                        }).map(function(e) {
                            return [e.uuid, "".concat(e.profile_name, " ( ").concat(l.backendData.php.find(function(t) {
                                return t.id === e.backend
                            }).name, " )")]
                        })), this.getForm().findField("php_backend").getStore().loadData(p), c = {
                            entries: [{
                                UUID: null,
                                name: _TT("SYNO.SDS.WebStation.Application", "default", "not_configured")
                            }]
                        }, (h = this.getForm().findField("acl").getStore()).each(function(e) {
                            c.entries.push({
                                UUID: e.get("UUID"),
                                name: e.get("name")
                            })
                        }, this), h.loadData(c), u = {
                            profiles: []
                        }, (S = this.getForm().findField("error_page").getStore()).each(function(e) {
                            u.profiles.push({
                                id: e.get("id"),
                                desc: e.get("desc")
                            })
                        }, this), S.loadData(u);
                    case 21:
                        this.owner.clearStatusBusy(), this.el.unmask();
                    case 23:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return function(t, i, a) {
            return e.apply(this, arguments)
        }
    }(),
    onAvailableServerLoad: function(e, t) {
        for (var i = this.getForm().findField("backend"), a = i.getValue(), n = 0; n < t.length; n++)
            if (t[n].get("backend_id") === a) return i.reset(), 0;
        i.clearValue(), i.validate()
    },
    onAvailablePHPLoad: function(e, t) {
        var i = this.getForm().findField("php_backend"),
            a = i.getValue();
        if ("nan" === a || "" === a || null === a) return i.setValue(null), 0;
        for (var n = 0; n < t.length; n++)
            if (t[n].get("uuid") === a) return i.reset(), 0;
        this.handlePHPNotAvaliable(i, a)
    },
    handlePHPNotAvaliable: function(e, t) {
        e.setValue(""), e.markInvalid(_TT("SYNO.SDS.WebStation.Application", "error", "err_backend_not_found"))
    },
    onAvailableAclLoad: function(e, t) {
        var i = this.getForm().findField("acl"),
            a = i.getValue();
        if ("nan" === a || "" === a || null === a) return i.setValue(null), 0;
        for (var n = 0; n < t.length; n++)
            if (t[n].get("UUID") === a) return i.reset(), 0;
        i.setValue(null)
    },
    onAvailableErrorPageLoaded: function(e, t) {
        var i = this.getForm().findField("error_page"),
            a = i.getValue();
        if ("nan" === a || "" === a || null === a) return i.setValue(null), 0;
        var n = t.find(function(e) {
            return "default" === e.id
        });
        void 0 !== n && (n.data.desc = _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "default_profile"));
        for (var o = 0; o < t.length; o++)
            if (t[o].get("id") === a) return i.reset(), 0;
        i.setValue("default")
    },
    docrootSelect: function() {
        new SYNO.SDS.Utils.FileChooser.Chooser({
            owner: this.owner,
            needrw: !1,
            usage: {
                type: "chooseDir"
            },
            title: _TT("SYNO.SDS.WebStation.Application", "vhost", "select_folder"),
            folderToolbar: !0,
            enumCluster: !1,
            enumC2Share: !0,
            listeners: {
                scope: this,
                choose: function(e, t, i) {
                    var a = t.path;
                    a && (a = a.replace(/^\/+/, "")) && (this.getForm().findField("root").setValue(a), e.close())
                }
            },
            treeFilter: function(e, t) {
                if (t) {
                    if ("remote" === t.mountType) return !1;
                    for (var i = ["/web_packages", "/home", "/homes"], a = t.spath, n = 0; n < i.length; n++)
                        if (!(a.length < i[n] || a.substr(0, i[n].length) !== i[n] || a.length !== i[n].length && "/" !== a[i[n].length])) return !1
                }
                return !0
            }
        }).show()
    },
    enableHandler: function() {
        var e = this.getForm(),
            t = function(t) {
                e.findField(t).enable()
            },
            i = function(t) {
                e.findField(t).disable()
            },
            a = ["fqdn", "name_port", "name_http", "name_https"],
            n = ["port_http", "port_https"];
        e.findField(this.name_based).getValue() ? (Ext.each(a, t), Ext.each(n, i)) : (Ext.each(n, t), Ext.each(a, i)), Ext.each(["name_http", "name_https", "port_http", "port_https"], function(t) {
            var i = e.findField(t);
            !i.disabled && i.getValue() ? e.findField(t + "_port").enable() : e.findField(t + "_port").disable()
        })
    },
    getData: function() {
        var e = this.getForm().getValues(),
            t = {
                port: {
                    http: [],
                    https: []
                },
                https: {},
                version: 2
            };
        return "name" === e.based ? (t.fqdn = e.fqdn, e.name_port && (t.port.http.push(80), t.port.https.push(443)), e.name_http && t.port.http.push(parseInt(e.name_http_port, 10)), e.name_https && t.port.https.push(parseInt(e.name_https_port, 10))) : (e.port_http && t.port.http.push(parseInt(e.port_http_port, 10)), e.port_https && t.port.https.push(parseInt(e.port_https_port, 10))), t.root = e.root, t.https.hsts = e.hsts, t.backend = e.backend, t.php = e.php_backend, t.acl = e.acl, t.error_page = e.error_page, t.enable = this.vhost_data.enable, this.uuid && (t.UUID = this.uuid), t
    },
    setData: function(e) {
        var t = {};
        if (e.fqdn) {
            t.based = "name", t.fqdn = e.fqdn, e.port.http || (e.port.http = []), e.port.https || (e.port.https = []), t.name_port = e.port.http.includes(80) && e.port.https.includes(443);
            var i = e.port.http.filter(function(e) {
                return 80 !== e
            });
            i.length && (t.name_http = !0, t.name_http_port = i[0]);
            var a = e.port.https.filter(function(e) {
                return 443 !== e
            });
            a.length && (t.name_https = !0, t.name_https_port = a[0])
        } else t.based = "port", e.port.http && 0 !== e.port.http.length && (t.port_http = !0, t.port_http_port = e.port.http[0]), e.port.https && 0 !== e.port.https.length && (t.port_https = !0, t.port_https_port = e.port.https[0]);
        t.root = e.root, t.hsts = e.https.hsts, t.backend = e.backend, t.php_backend = e.php, t.acl = e.acl, t.error_page = e.error_page, t.enable = e.enable, e.UUID && (this.uuid = e.UUID), this.vhost_data = t
    },
    validateFQDN: function(e) {
        var t, i = this.getForm().getValues();
        return "name" !== i.based || (i.name_port && (this.FQDNChecker.IsConflict(e, 80) || this.FQDNChecker.IsConflict(e, 443)) ? _T("app_port_alias", "err_fqdn_duplicated") : i.name_http && (t = parseInt(i.name_http_port, 10)) && this.FQDNChecker.IsConflict(e, t) ? _T("app_port_alias", "err_fqdn_duplicated") : !(i.name_https && (t = parseInt(i.name_https_port, 10)) && this.FQDNChecker.IsConflict(e, t)) || _T("app_port_alias", "err_fqdn_duplicated"))
    }
}), Ext.define("SYNO.SDS.WebStation.Web.ServerPortalEditor", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.module = e.module, this.owner = e.owner, this.store = e.store, this.webapi = e.webapi, this.uuid = "", this.preserve = e.preserve, this.panel = new SYNO.SDS.WebStation.Web.ServerPortalPanel({
            module: this.module,
            perserve: this.preserve,
            owner: this
        }), this.callParent([Ext.apply({
            width: 650,
            autoHeight: !0,
            items: [this.panel],
            closeAction: "onCancel",
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: this.onCancel
            }, {
                text: _T("common", "save"),
                btnStyle: "blue",
                disabled: this._S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                scope: this,
                handler: this.onApply
            }],
            listeners: {
                scope: this,
                show: this.onShow
            }
        }, e)])
    },
    sendRequest: function(e) {
        var t = this.panel.getData();
        this.sendWebAPI({
            api: this.webapi.api,
            method: this.webapi.method,
            version: this.webapi.version,
            params: {
                portal: t
            },
            callback: function(e, t) {
                this.clearStatusBusy(), e ? (this.fireEvent("close"), this.close()) : this.onError(t.code, t.errors)
            },
            scope: this
        })
    },
    onShow: function() {
        this.panel.loadStores()
    },
    onForceAcl: function(e) {
        "yes" == e && this.panel.getForm().isValid() && this.validator() && (this.panel.getForm().isDirty() ? (this.setStatusBusy(), this.sendRequest(!0)) : this.close())
    },
    onApply: function() {
        this.panel.getForm().isValid() && this.validator() ? this.panel.getForm().isDirty() ? (this.setStatusBusy(), this.sendRequest(!1)) : this.close() : this.setStatusError({
            text: _T("error", "error_bad_field"),
            clear: !0
        })
    },
    onCancel: function() {
        var e = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t, i, a, n = this;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        if (this.panel.getForm().isDirty()) {
                            e.next = 2;
                            break
                        }
                        return e.abrupt("return", this.close());
                    case 2:
                        return t = this.findAppWindow(), i = function() {
                            return new Promise(function(e) {
                                t.getMsgBox().confirm(_TT("SYNO.SDS.WebStation.Application", "title", "vhost"), n.panel.isEditPanel ? _TT("SYNO.SDS.WebStation.Application", "common", "confirm_edit_page") : _TT("SYNO.SDS.WebStation.Application", "common", "confirm_create_page"), e, t, {
                                    yes: _T("common", "save"),
                                    no: _T("common", "cancel"),
                                    leftCustom: _T("common", "dont_save")
                                })
                            })
                        }, e.next = 6, i();
                    case 6:
                        if ("yes" !== (a = e.sent)) {
                            e.next = 9;
                            break
                        }
                        return e.abrupt("return", this.onApply());
                    case 9:
                        if ("no" !== a) {
                            e.next = 11;
                            break
                        }
                        return e.abrupt("return");
                    case 11:
                        if ("leftCustom" !== a) {
                            e.next = 13;
                            break
                        }
                        return e.abrupt("return", this.close());
                    case 13:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return function() {
            return e.apply(this, arguments)
        }
    }(),
    handleConflictHost: function(e) {
        var t = this.panel.getForm(),
            i = !t.findField("fqdn").disabled,
            a = t.findField(i ? "name_http_port" : "port_http_port"),
            n = t.findField(i ? "name_https_port" : "port_https_port"),
            o = {
                text: _TT("SYNO.SDS.WebStation.Application", "error", i ? "err_host_duplicated" : "err_port_conflict"),
                clear: !0
            };
        i && t.findField("fqdn").markInvalid(o.text), this.setStatusError(o), [a, n].forEach(function(t) {
            !t.disabled && e.includes(parseInt(t.getValue(), 10)) && t.markInvalid(_TT("SYNO.SDS.WebStation.Application", "error", "err_port_conflict"))
        })
    },
    onError: function(e, t) {
        var i = this.panel.getForm(),
            a = SYNO.SDS.WebStation.Errors.GetMessage(e);
        switch (e) {
            case 1004:
                this.handleConflictHost(t.conflict_ports);
                break;
            case 1007:
                i.findField("fqdn").markInvalid(a), this.setStatusError({
                    text: a,
                    clear: !0
                });
                break;
            case 1009:
            case 1021:
                this.handleConflictHost(t.conflict_ports);
                break;
            case 1022:
                this.module.appWin.getMsgBox().confirm("ACL Error", a, this.onForceAcl, this);
                break;
            default:
                this.setStatusError({
                    text: a,
                    clear: !0
                })
        }
    },
    setData: function(e) {
        return this.panel.setData(e)
    },
    validator: function() {
        var e = this.panel.getForm().getValues();
        return ("name" !== e.based || e.name_port || e.name_http || e.name_https) && !("port" === e.based && !e.port_http && !e.port_https) || (this.setStatusError({
            text: _TT("SYNO.SDS.WebStation.Application", "error", "err_no_port_set"),
            clear: !0
        }), !1)
    }
}), Ext.define("SYNO.SDS.WebStation.Web.ServerPortalPanel", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(e) {
        this.module = e.module, this.owner = e.owner, this.preserve = e.preserve, this.dirty = !1;
        var t = Ext.apply({
            monitorValid: !0,
            autoFlexcroll: !0,
            height: 402,
            fieldWidth: 270,
            bodyStyle: "padding-right:0px; padding-left:0px;",
            labelSeparator: _T("common", "colon"),
            items: [{
                xtype: "syno_combobox",
                name: "service_id",
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "common", "service"),
                displayField: "service",
                valueField: "id",
                validator: this.validateService.createDelegate(this),
                allowBlank: !1,
                hidden: this.preserve,
                store: new SYNO.API.JsonStore({
                    appWindow: this.module.appWin,
                    defaultSortable: !0,
                    autoDestroy: !0,
                    autoLoad: !0,
                    root: "services",
                    idProperty: "id",
                    fields: ["id", {
                        name: "service",
                        convert: function(e, t) {
                            return SYNO.SDS.WebStation.Util.geti18nString(t.display_name_i18n, t.display_name)
                        }
                    }],
                    api: "SYNO.WebStation.WebService.Service",
                    version: 1,
                    method: "list",
                    listeners: {
                        scope: this,
                        load: this.onServiceStoreLoaded
                    }
                })
            }, {
                xtype: "syno_displayfield",
                name: "service_id_fix",
                width: 250,
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "common", "service"),
                allowBlank: !1,
                emptyText: "Service Name",
                hidden: !this.preserve
            }, {
                xtype: "syno_radio",
                name: "based",
                boxLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "name_based"),
                checked: !0,
                inputValue: "name",
                id: this.name_based = Ext.id(),
                scope: this,
                handler: this.enableHandler
            }, {
                xtype: "syno_textfield",
                vtype: "FQDN",
                maxlength: 255,
                allowBlank: !1,
                indent: 1,
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "hostname"),
                name: "fqdn",
                validator: this.validateFQDN.createDelegate(this)
            }, {
                xtype: "syno_compositefield",
                indent: 1,
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "port"),
                items: [{
                    xtype: "syno_checkbox",
                    name: "name_port",
                    boxLabel: "80 / 443",
                    checked: !0,
                    inputValue: "default"
                }]
            }, {
                xtype: "syno_compositefield",
                indent: 1,
                items: [{
                    xtype: "syno_checkbox",
                    name: "name_http",
                    boxLabel: "HTTP",
                    width: 90,
                    inputValue: "http",
                    scope: this,
                    handler: this.enableHandler
                }, {
                    disabled: !0,
                    xtype: "syno_textfield",
                    vtype: "port",
                    allowBlank: !1,
                    name: "name_http_port",
                    width: 60,
                    maxlength: 5,
                    validator: function(e) {
                        return 80 != e
                    }
                }]
            }, {
                xtype: "syno_compositefield",
                indent: 1,
                items: [{
                    xtype: "syno_checkbox",
                    name: "name_https",
                    boxLabel: "HTTPS",
                    width: 90,
                    inputValue: "https",
                    scope: this,
                    handler: this.enableHandler
                }, {
                    disabled: !0,
                    xtype: "syno_textfield",
                    vtype: "port",
                    allowBlank: !1,
                    name: "name_https_port",
                    width: 60,
                    maxlength: 5,
                    validator: function(e) {
                        return 443 != e
                    }
                }]
            }, {
                xtype: "syno_radio",
                name: "based",
                indent: 0,
                boxLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "port_based"),
                inputValue: "port",
                scope: this,
                handler: this.enableHandler
            }, {
                xtype: "syno_compositefield",
                indent: 1,
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "port"),
                items: [{
                    disabled: !0,
                    xtype: "syno_checkbox",
                    name: "port_http",
                    width: 90,
                    boxLabel: "HTTP",
                    inputValue: "http",
                    scope: this,
                    handler: this.enableHandler
                }, {
                    disabled: !0,
                    xtype: "syno_textfield",
                    vtype: "port",
                    allowBlank: !1,
                    name: "port_http_port",
                    width: 60,
                    maxlength: 5
                }]
            }, {
                xtype: "syno_compositefield",
                indent: 1,
                items: [{
                    disabled: !0,
                    xtype: "syno_checkbox",
                    name: "port_https",
                    width: 90,
                    boxLabel: "HTTPS",
                    inputValue: "https",
                    scope: this,
                    handler: this.enableHandler
                }, {
                    disabled: !0,
                    xtype: "syno_textfield",
                    vtype: "port",
                    allowBlank: !1,
                    name: "port_https_port",
                    width: 60,
                    maxlength: 5
                }]
            }, {
                xtype: "syno_compositefield",
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "https_settings"),
                items: [{
                    xtype: "syno_checkbox",
                    name: "hsts",
                    boxLabel: "HSTS"
                }]
            }, {
                xtype: "syno_combobox",
                name: "acl",
                fieldLabel: _T("app_port_alias", "desc_acl"),
                displayField: "name",
                valueField: "UUID",
                store: new SYNO.API.JsonStore({
                    appWindow: this.module.appWin,
                    defaultSortable: !0,
                    autoDestroy: !0,
                    autoLoad: !0,
                    root: "entries",
                    idProperty: "UUID",
                    fields: ["UUID", "name"],
                    api: "SYNO.Core.AppPortal.AccessControl",
                    version: 1,
                    method: "list",
                    listeners: {
                        scope: this,
                        load: this.onAvailableAclLoaded
                    }
                }),
                tpl: '<tpl for="."><div ext:qtip="{name}" class="x-combo-list-item">{name}</div></tpl>'
            }, {
                xtype: "syno_combobox",
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "error_page_profile"),
                name: "error_page",
                valueField: "id",
                displayField: "desc",
                store: new SYNO.API.JsonStore({
                    appWindow: this.module.appWin,
                    defaultSortable: !0,
                    autoDestroy: !0,
                    autoLoad: !0,
                    root: "profiles",
                    idProperty: "id",
                    fields: ["id", "desc"],
                    api: "SYNO.WebStation.ErrorPage",
                    version: 1,
                    method: "list",
                    listeners: {
                        scope: this,
                        load: this.onAvailableErrorPageLoaded
                    }
                }),
                tpl: '<tpl for="."><div ext:qtip="{desc}" class="x-combo-list-item">{desc}</div></tpl>'
            }]
        }, e);
        this.FQDNChecker = new SYNO.SDS.AdminCenter.Utils.Validator.FQDNConflictChecker, this.FQDNChecker.FindListFQDNPortPair(this, "SYNO.WebStation.HTTP.VHost"), this.callParent([t]), this.doLayout(), this.mon(this, "afterlayout", this.addToolTip, this, {
            single: !0
        })
    },
    addToolTip: function() {
        var e = this.getForm().findField("acl"),
            t = this.getForm().findField("error_page");
        SYNO.ux.AddTip(e.getEl(), _TT("SYNO.SDS.WebStation.Application", "common", "no_acl_profile_available")), SYNO.ux.AddTip(t.getEl(), _TT("SYNO.SDS.WebStation.Application", "common", "tip_error_page_profile"))
    },
    loadStores: function() {
        this.owner.setStatusBusy();
        var e = this.getForm().findField("service_id").getStore(),
            t = this.getForm().findField("acl").getStore(),
            i = this.getForm().findField("error_page").getStore();
        e.load(), t.load(), i.load()
    },
    storeLoaded: function(e) {
        "service" === e ? this.serviceLoaded = !0 : "acl" === e ? this.aclLoaded = !0 : "error_page" === e && (this.errorPageLoaded = !0), this.serviceLoaded && this.aclLoaded && this.errorPageLoaded && (this.dirty || this.flushDirtyState(), this.owner.clearStatusBusy())
    },
    onServiceStoreLoaded: function(e, t) {
        var i, a = {
                id: null,
                service: _TT("SYNO.SDS.WebStation.Application", "common", "status_not_available")
            },
            n = this.getForm().findField("service_id"),
            o = this.getForm().findField("service_id_fix"),
            r = n.getValue(),
            s = t.find(function(e) {
                return e.get("id") === r
            });
        if (0 === t.length) {
            var l = n.getStore();
            l.insert(0, new l.recordType(a)), i = a
        } else s ? i = {
            id: s.get("id"),
            service: s.get("service")
        } : (i = t[0], this.dirty = !0);
        n.setValue(i.id), o.setValue(i.service), this.storeLoaded("service")
    },
    onAvailableAclLoaded: function(e, t) {
        var i, a = {
                UUID: null,
                name: _TT("SYNO.SDS.WebStation.Application", "default", "not_configured")
            },
            n = this.getForm().findField("acl"),
            o = n.getStore();
        o.insert(0, new o.recordType(a));
        var r = n.getValue();
        t.some(function(e) {
            return e.get("UUID") === r
        }) ? i = r : (i = null, null !== r && (this.dirty = !0)), n.setValue(i), this.storeLoaded("acl")
    },
    onAvailableErrorPageLoaded: function(e, t) {
        var i, a = this.getForm().findField("error_page"),
            n = a.getValue(),
            o = t.find(function(e) {
                return "default" === e.id
            });
        void 0 !== o && (o.data.desc = _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "default_profile")), t.some(function(e) {
            return e.get("id") === n
        }) ? i = n : (i = "default", this.dirty = !0), a.setValue(i), this.storeLoaded("error_page")
    },
    enableHandler: function() {
        var e = this.getForm(),
            t = function(t) {
                e.findField(t).enable()
            },
            i = function(t) {
                e.findField(t).disable()
            },
            a = ["fqdn", "name_port", "name_http", "name_https"],
            n = ["port_http", "port_https"];
        e.findField(this.name_based).getValue() ? (Ext.each(a, t), Ext.each(n, i)) : (Ext.each(n, t), Ext.each(a, i)), Ext.each(["name_http", "name_https", "port_http", "port_https"], function(t) {
            var i = e.findField(t);
            !i.disabled && i.getValue() ? e.findField(t + "_port").enable() : e.findField(t + "_port").disable()
        })
    },
    getData: function() {
        var e = this.getForm().getValues(),
            t = {
                http_port: [],
                https_port: []
            };
        return t.service = e.service_id, "name" === e.based ? (t.fqdn = e.fqdn, e.name_port && (t.http_port.push(80), t.https_port.push(443)), e.name_http && t.http_port.push(parseInt(e.name_http_port, 10)), e.name_https && t.https_port.push(parseInt(e.name_https_port, 10))) : (e.port_http && t.http_port.push(parseInt(e.port_http_port, 10)), e.port_https && t.https_port.push(parseInt(e.port_https_port, 10))), t.hsts = e.hsts, t.acl = e.acl, t.error_page = e.error_page, this.uuid && (t.id = this.uuid), this.portal_data_raw ? (t.compatible_crt_service = this.portal_data_raw.compatible_crt_service, t.compatible_crt_subscriber = this.portal_data_raw.compatible_crt_subscriber, t.compatible_sc_section = this.portal_data_raw.compatible_sc_section, t.type = this.portal_data_raw.type, t.enable = this.portal_data_raw.enable) : t.type = "server", "alias" === t.type && (t.alias = this.portal_data_raw.alias), t
    },
    setData: function(e) {
        this.isEditPanel = !0;
        var t = {};
        if (t.service_id = e.service, e.fqdn) {
            t.based = "name", t.fqdn = e.fqdn, e.http_port || (e.http_port = []), e.https_port || (e.https_port = []);
            var i = e.http_port.indexOf(80),
                a = e.https_port.indexOf(443); - 1 !== i && -1 !== a ? (t.name_port = !0, e.http_port.splice(i, 1), e.https_port.splice(a, 1)) : t.name_port = !1, e.http_port.length && (t.name_http = !0, t.name_http_port = e.http_port[0]), e.https_port.length && (t.name_https = !0, t.name_https_port = e.https_port[0])
        } else t.based = "port", e.http_port && e.http_port.length && (t.port_http = !0, t.port_http_port = e.http_port[0]), e.https_port && e.https_port.length && (t.port_https = !0, t.port_https_port = e.https_port[0]);
        t.hsts = e.hsts, t.acl = e.acl, t.error_page = e.error_page, e.id && (this.uuid = e.id), this.portal_data_raw = e, this.portal_data = t, this.getForm().setValues(this.portal_data)
    },
    flushDirtyState: function() {
        this.getForm().items.items.forEach(function(e) {
            e.originalValue = e.getValue()
        })
    },
    validateService: function(e) {
        return e !== _TT("SYNO.SDS.WebStation.Application", "common", "status_not_available") && "" !== e || _TT("SYNO.SDS.WebStation.Application", "error", "bad_service")
    },
    validateFQDN: function(e) {
        var t, i = this.getForm().getValues();
        return "name" !== i.based || (i.name_port && (this.FQDNChecker.IsConflict(e, 80) || this.FQDNChecker.IsConflict(e, 443)) ? _T("app_port_alias", "err_fqdn_duplicated") : i.name_http && (t = parseInt(i.name_http_port, 10)) && this.FQDNChecker.IsConflict(e, t) ? _T("app_port_alias", "err_fqdn_duplicated") : !(i.name_https && (t = parseInt(i.name_https_port, 10)) && this.FQDNChecker.IsConflict(e, t)) || _T("app_port_alias", "err_fqdn_duplicated"))
    }
}), Ext.define("SYNO.SDS.WebStation.VHostTab", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(e) {
        this.module = e.module, this.appWin = e.appWin, this.owner = e.owner, this.store = new Ext.data.GroupingStore({
            reader: new Ext.data.JsonReader({
                fields: ["status", "service", "fqdn", "port", "protocol", "detail", "preserve"],
                idProperty: "id"
            }),
            groupField: "preserve",
            appWindow: this.owner,
            autoDestroy: !0,
            listeners: {
                beforeload: {
                    scope: this,
                    fn: this.onStoreBeforeLoaded
                },
                load: {
                    scope: this,
                    fn: this.onStoreLoaded
                }
            }
        });
        var t = this.fillConfig(e);
        this.callParent([t]), this.mon(SYNO.SDS.StatusNotifier, "thirdpartychanged", this.onPkgChanged, this)
    },
    fillConfig: function(e) {
        return Ext.apply({
            title: _TT("SYNO.SDS.WebStation.Application", "title", "vhost"),
            store: this.store,
            tbar: {
                xtype: "syno_toolbar",
                defaultType: "syno_button",
                items: this.getTBarItem()
            },
            columns: [{
                dataIndex: "preserve",
                hidden: !0,
                renderer: this.renderPreserve
            }, {
                dataIndex: "status",
                header: _TT("SYNO.SDS.WebStation.Application", "common", "status"),
                align: "left",
                sortable: !0,
                scope: this,
                renderer: this.renderStatus
            }, {
                dataIndex: "service",
                header: _TT("SYNO.SDS.WebStation.Application", "common", "service"),
                align: "left",
                sortable: !0,
                scope: this,
                renderer: this.renderService
            }, {
                dataIndex: "fqdn",
                header: _T("service", "service_host_name"),
                align: "left",
                sortable: !0,
                renderer: this.renderFqdn
            }, {
                dataIndex: "port",
                header: _T("service", "service_vhost_port"),
                align: "left",
                sortable: !0,
                scope: this,
                renderer: this.renderPort
            }, {
                dataIndex: "primary_link",
                header: _TT("SYNO.SDS.WebStation.Application", "common", "primary_link"),
                align: "left",
                scope: this,
                renderer: this.renderPrimaryLink
            }, {
                dataIndex: "detail",
                header: _TT("SYNO.SDS.WebStation.Application", "common", "details"),
                align: "left",
                sortable: !0,
                renderer: this.renderDetail
            }],
            selModel: this.selModel = new Ext.grid.RowSelectionModel({
                singleSelect: !1,
                listeners: {
                    selectionchange: {
                        scope: this,
                        fn: this.onSelectionChange
                    }
                }
            }),
            view: new SYNO.ux.GroupingView({
                showGroupName: !1,
                enableGroupingMenu: !1,
                forceFit: !0
            }),
            enableHdMenu: !1,
            enableColumnMove: !1,
            enableColLock: !1,
            listeners: {
                scope: this,
                rowdblclick: this.onRowDblclick,
                rowcontextmenu: this.onRowContextMenu,
                activate: this.onPageActivate
            }
        }, e)
    },
    createWizard: function() {
        new SYNO.SDS.WebStation.ServiceWizard({
            owner: this.appWin,
            listeners: {
                close: this.webapiDone,
                scope: this
            }
        }).show()
    },
    enableDisableHandler: function(e) {
        var t = this.getSelectionModel().getSelections(),
            i = [];
        this.busy(), Ext.each(t, function(t) {
            t.data.enable = e, "vhost" === t.data.$type ? (t.data.version = 2, i.push(this.pushUpdateRequest("SYNO.WebStation.HTTP.VHost", "host", t.data))) : "portal" === t.data.$type && i.push(this.pushUpdateRequest("SYNO.WebStation.WebService.Portal", "portal", t.data))
        }, this), this.appWin.sendWebAPI({
            compound: {
                stopwhenerror: !1,
                params: i
            },
            scope: this,
            callback: function(e, t) {
                this.webapiDone()
            }
        })
    },
    editHandler: function() {
        var e = this.getSelectionModel().getSelections();
        if (1 === e.length) {
            var t = e[0].data.$type;
            if ("vhost" === t) {
                var i = new SYNO.SDS.WebStation.Web.VHostEditor({
                    owner: this.appWin,
                    module: this,
                    title: _TT("SYNO.SDS.WebStation.Application", "vhost", "edit_vhost"),
                    webapi: {
                        api: "SYNO.WebStation.HTTP.VHost",
                        method: "update",
                        version: 1
                    },
                    listeners: {
                        close: this.webapiDone,
                        scope: this
                    }
                });
                i.setData(e[0].data), i.show()
            } else if ("portal" === t) {
                var a = new SYNO.SDS.WebStation.Web.ServerPortalEditor({
                    owner: this.appWin,
                    module: this,
                    title: _TT("SYNO.SDS.WebStation.Application", "portal", "edit_portal"),
                    webapi: {
                        api: "SYNO.WebStation.WebService.Portal",
                        method: "update",
                        version: 1
                    },
                    listeners: {
                        close: this.webapiDone,
                        scope: this
                    },
                    preserve: e[0].data.preserve
                });
                a.setData(e[0].data), a.show()
            }
        }
    },
    deleteHandler: function() {
        var e = this.getSelectionModel(),
            t = e.getSelections();
        if (t.length && !this.hasPreserved(t)) {
            var i = [],
                a = [];
            this.owner.getMsgBox().confirmDelete(_TT("SYNO.SDS.WebStation.Application", "title", "vhost"), _T("common", "remove_cfrmrmv"), function(n) {
                var o = this;
                "yes" === n && (this.busy(), 1 === t.length && e.selectNext(), Ext.each(t, function(e) {
                    "vhost" === e.data.$type ? i.push(e.data.UUID) : "portal" === e.data.$type && a.push(e.data.id), this.store.remove(e)
                }, this), this.sendDeleteWebAPI("SYNO.WebStation.HTTP.VHost", "delete", "uuids", i).then(function() {
                    return o.sendDeleteWebAPI("SYNO.WebStation.WebService.Portal", "remove", "ids", a)
                }).then(function() {
                    o.webapiDone()
                }).catch(function() {
                    o.webapiDone()
                }))
            }.bind(this))
        }
    },
    btnDisableHandler: function() {
        var e = this.selModel.getSelections(),
            t = e.length,
            i = this.getTBarItem(),
            a = this.getContextActionGroup();
        if (0 === t ? (i[1].disable(), i[2].disable(), a.disable("edit")) : (Ext.getCmp(this.deletePortalBtnId).enable(), a.enable("delete"), 1 === t ? (i[1].enable(), i[2].enable(), a.enable("edit")) : (i[1].disable(), i[2].enable(), a.disable("edit"))), this.hasPreserved(e)) return Ext.getCmp(this.deletePortalBtnId).disable(), void a.disable("delete")
    },
    sendDeleteWebAPI: function(e, t, i, a) {
        var n = this;
        return new Promise(function(o, r) {
            a.length > 0 ? n.sendWebAPI({
                api: e,
                method: t,
                version: 1,
                params: _defineProperty({}, i, a),
                scope: n,
                callback: function(e, t) {
                    e && o(t), r(t)
                }
            }) : o()
        })
    },
    pushUpdateRequest: function(e, t, i) {
        return {
            api: e,
            method: "update",
            version: 1,
            params: _defineProperty({}, t, i)
        }
    },
    renderPreserve: function(e) {
        return !0 === e ? _TT("SYNO.SDS.WebStation.Application", "portal", "header_group_preserve_portal") : _TT("SYNO.SDS.WebStation.Application", "portal", "header_group_non_preserve_portal")
    },
    renderStatus: function(e, t, i) {
        var a, n, o = Object.freeze({
                ENABLE: Symbol("enable"),
                SERVICE_DISABLE: Symbol("service_disable"),
                DISABLE: Symbol("disable"),
                ERROR: Symbol("error")
            }),
            r = o.DISABLE;
        return "vhost" === i.data.$type ? 999 !== i.data.error ? r = o.ERROR : i.data.enable && (r = o.ENABLE) : "portal" === i.data.$type && (r = this.checkPortalStatus(i.data, o)), r === o.ENABLE ? (a = _T("helpbrowser", "font_normal"), n = "green") : r === o.ERROR ? (a = _T("common", "status_abnormal"), n = "red") : r === o.SERVICE_DISABLE ? (a = _TT("SYNO.SDS.WebStation.Application", "common", "service_disable"), n = "red") : r === o.DISABLE && (a = _T("common", "disabled"), n = "syno-webstation-grey"), String.format('<font class="{0}-status">{1}</font>', n, a)
    },
    checkPortalStatus: function(e, t) {
        if (!e.enable) return t.DISABLE;
        var i = e.service,
            a = this.serviceIdMap[i];
        return a ? a.enable ? t.ENABLE : t.SERVICE_DISABLE : t.ERROR
    },
    renderService: function(e, t, i) {
        if ("vhost" === i.data.$type) return _TT("SYNO.SDS.WebStation.Application", "title", "vhost");
        if ("portal" === i.data.$type) {
            if (!i.data.service) return "";
            var a = i.data.service;
            if (!this.serviceIdMap[a]) {
                var n = _TT("SYNO.SDS.WebStation.Application", "common", "status_not_available");
                return String.format('<span class="syno-webstation-grey-status">{0}</span>', n)
            }
            var o = this.serviceIdMap[a].display_name_i18n,
                r = this.serviceIdMap[a].display_name;
            return SYNO.SDS.WebStation.Util.geti18nString(o, r)
        }
        return ""
    },
    renderFqdn: function(e) {
        return e || "*"
    },
    renderPort: function(e, t, i) {
        var a = [];
        return "vhost" === i.data.$type ? (Ext.each(i.data.port.http, function(e) {
            a.push(e)
        }, this), Ext.each(i.data.port.https, function(e) {
            a.push(e)
        }, this)) : "portal" === i.data.$type && (Ext.each(i.data.http_port, function(e) {
            a.push(e)
        }, this), Ext.each(i.data.https_port, function(e) {
            a.push(e)
        }, this)), a.join(" / ")
    },
    renderPrimaryLink: function(e, t, i) {
        var a = "vhost" === i.data.$type ? i.data.port.http : i.data.http_port,
            n = "vhost" === i.data.$type ? i.data.port.https : i.data.https_port,
            o = 0 != n.length ? this.checkStandardPort(n, "443") : this.checkStandardPort(a, "80"),
            r = 0 != n.length ? "https" : "http";
        return this.genPrimaryLink(r, i.get("fqdn"), o)
    },
    renderDetail: function(e, t, i) {
        return "vhost" === i.data.$type && i.data.root ? _TT("SYNO.SDS.WebStation.Application", "vhost", "docroot") + ": ".concat(i.data.root) : ""
    },
    onPkgChanged: function(e, t) {
        "WebStation" !== e && this.loadStore()
    },
    onPageActivate: function() {
        this.btnDisableHandler(), this.loadStore()
    },
    onStoreBeforeLoaded: function(e, t, i) {
        this.busy()
    },
    onStoreLoaded: function(e, t, i, a) {
        this.unbusy(), this.btnDisableHandler()
    },
    onSelectionChange: function(e, t) {
        this.btnDisableHandler()
    },
    onRowContextMenu: function(e, t, i, a) {
        var n = new SYNO.ux.Menu({
                autoDestroy: !0,
                items: this.getContextActionGroup().getArray()
            }),
            o = this.getSelectionModel();
        o.selectRow(t, o.isSelected(t)), n.showAt(i.getXY()), i.preventDefault()
    },
    onRowDblclick: function(e, t, i, a) {
        this.editHandler()
    },
    addVHostData: function(e) {
        if (Array.isArray(e)) {
            var t = !0,
                i = !1,
                a = void 0;
            try {
                for (var n, o = e[Symbol.iterator](); !(t = (n = o.next()).done); t = !0) {
                    var r = n.value,
                        s = Object.assign({}, r);
                    s.$type = "vhost", s.preserve = !1, this.store.add([new this.store.recordType(s)])
                }
            } catch (e) {
                i = !0, a = e
            } finally {
                try {
                    t || null == o.return || o.return()
                } finally {
                    if (i) throw a
                }
            }
        }
    },
    addPortalData: function(e) {
        if (Array.isArray(e)) {
            var t = !0,
                i = !1,
                a = void 0;
            try {
                for (var n, o = e[Symbol.iterator](); !(t = (n = o.next()).done); t = !0) {
                    var r = n.value;
                    if ("server" === r.type) {
                        var s = Object.assign({}, r);
                        s.$type = "portal", this.store.add([new this.store.recordType(s)])
                    }
                }
            } catch (e) {
                i = !0, a = e
            } finally {
                try {
                    t || null == o.return || o.return()
                } finally {
                    if (i) throw a
                }
            }
        }
    },
    loadStore: function() {
        var e = this;
        this.busy(), this.loadServices().then(function() {
            return e.loadProfiles()
        }).then(function() {
            e.store.groupBy("preserve", !0)
        }).catch(function(e) {
            SYNO.Debug(e)
        }), this.unbusy()
    },
    loadServices: function() {
        var e = this;
        return new Promise(function(t, i) {
            e.sendWebAPI({
                api: "SYNO.WebStation.WebService.Service",
                method: "list",
                version: 1,
                scope: e,
                callback: function(e, a) {
                    var n = this;
                    e ? (this.serviceIdMap = {}, a.services && a.services.forEach(function(e) {
                        n.serviceIdMap[e.id] = e
                    }), t()) : i()
                }
            })
        })
    },
    loadProfiles: function() {
        var e = this;
        return new Promise(function(t, i) {
            var a = [{
                api: "SYNO.WebStation.WebService.Portal",
                method: "list",
                version: 1
            }, {
                api: "SYNO.WebStation.HTTP.VHost",
                method: "list",
                version: 1
            }];
            e.appWin.sendWebAPI({
                compound: {
                    stopwhenerror: !0,
                    params: a
                },
                scope: e,
                callback: function(e, a) {
                    e ? (this.store.removeAll(), this.addPortalData(a.result[0].data.portals), this.addVHostData(a.result[1].data.hosts), t()) : i()
                }
            })
        })
    },
    busy: function() {
        this.el.mask(_T("common", "loading"), "x-mask-loading")
    },
    unbusy: function() {
        this.el.unmask()
    },
    webapiDone: function() {
        this.unbusy(), this.loadStore(), SYNO.SDS.reloadJSConfig()
    },
    getTBarItem: function() {
        return this.tbarItems ? this.tbarItems : (this.tbarItems = [new SYNO.ux.Button({
            text: _T("common", "create"),
            itemId: "create",
            disabled: this._S("demo_mode"),
            btnStyle: "blue",
            handler: this.createWizard,
            scope: this
        }), new Ext.Action({
            text: _T("common", "alt_edit"),
            itemId: "edit",
            scope: this,
            handler: this.editHandler
        }), new SYNO.ux.SplitButton({
            text: _T("common", "action"),
            itemId: "operation",
            disabled: this._S("demo_mode"),
            handler: function(e) {
                e.showMenu()
            },
            scope: this,
            menu: {
                items: [{
                    text: _TT("SYNO.SDS.WebStation.Application", "common", "enable"),
                    scope: this,
                    handler: this.enableDisableHandler.createDelegate(this, [!0])
                }, {
                    text: _TT("SYNO.SDS.WebStation.Application", "common", "disable"),
                    scope: this,
                    handler: this.enableDisableHandler.createDelegate(this, [!1])
                }, {
                    id: this.deletePortalBtnId = Ext.id(),
                    text: _T("common", "delete"),
                    scope: this,
                    handler: this.deleteHandler
                }]
            }
        })], this.tbarItems)
    },
    getContextActionGroup: function() {
        return this.contextMenu ? this.contextMenu : (this.contextMenu = new SYNO.ux.Utils.ActionGroup([new Ext.Action({
            text: _T("common", "alt_edit"),
            itemId: "edit",
            scope: this,
            handler: this.editHandler
        }), new Ext.Action({
            text: _TT("SYNO.SDS.WebStation.Application", "common", "enable"),
            itemId: "enable",
            scope: this,
            handler: this.enableDisableHandler.createDelegate(this, [!0])
        }), new Ext.Action({
            text: _TT("SYNO.SDS.WebStation.Application", "common", "disable"),
            itemId: "disable",
            scope: this,
            handler: this.enableDisableHandler.createDelegate(this, [!1])
        }), new Ext.Action({
            text: _T("common", "delete"),
            itemId: "delete",
            scope: this,
            handler: this.deleteHandler
        })]), this.contextMenu)
    },
    hasPreserved: function(e) {
        for (var t = e.length, i = 0; i < t; i++)
            if (!0 === e[i].get("preserve")) return !0;
        return !1
    },
    genPrimaryLink: function(e, t, i) {
        var a = "".concat(e, "://{hostname}:").concat(i);
        return a = null === t ? a.replace("{hostname}", window.location.hostname) : a.replace("{hostname}", t), '<a class="syno-webstation-management" href="{link}" target="_blank" ext:qtip="{link}" style="width:20px;float:left"></a>'.replace(/{link}/g, a)
    },
    checkStandardPort: function(e, t) {
        var i = e.find(function(e) {
            return e === t
        });
        return null == i ? e[0] : i
    }
}), Ext.define("SYNO.SDS.WebStation.Web.AliasPortalEditor", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.module = e.module, this.owner = e.owner, this.store = e.store, this.webapi = e.webapi, this.uuid = "", this.preserve = e.preserve, this.isEditPanel = e.isEditPanel, this.panel = new SYNO.SDS.WebStation.Web.AliasPortalPanel({
            module: this.module,
            preserve: this.preserve,
            owner: this
        }), this.callParent([Ext.apply({
            width: 520,
            autoHeight: !0,
            items: [this.panel],
            closeAction: "onCancel",
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: this.onCancel
            }, {
                text: this.isEditPanel ? _T("common", "save") : _T("common", "create"),
                btnStyle: "blue",
                disabled: this._S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                scope: this,
                handler: this.onApply
            }],
            listeners: {
                scope: this,
                show: this.onShow
            }
        }, e)])
    },
    sendRequest: function(e) {
        var t = this.panel.getData();
        this.sendWebAPI({
            api: this.webapi.api,
            method: this.webapi.method,
            version: this.webapi.version,
            params: {
                portal: t
            },
            callback: function(e, t) {
                this.clearStatusBusy(), e ? (this.fireEvent("close"), this.close()) : this.onError(t.code, t.errors)
            },
            scope: this
        })
    },
    onShow: function() {
        this.panel.loadStores()
    },
    onForceAcl: function(e) {
        "yes" == e && this.panel.getForm().isValid() && (this.panel.getForm().isDirty() ? (this.setStatusBusy(), this.sendRequest(!0)) : this.close())
    },
    onApply: function() {
        this.panel.getForm().isValid() ? this.panel.getForm().isDirty() ? (this.setStatusBusy(), this.sendRequest(!1)) : this.close() : this.setStatusError({
            text: _T("error", "error_bad_field"),
            clear: !0
        })
    },
    onCancel: function() {
        var e = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t, i, a, n = this;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        if (this.panel.getForm().isDirty()) {
                            e.next = 2;
                            break
                        }
                        return e.abrupt("return", this.close());
                    case 2:
                        return t = this.findAppWindow(), i = function() {
                            return new Promise(function(e) {
                                t.getMsgBox().confirm(_TT("SYNO.SDS.WebStation.Application", "title", "vhost"), n.panel.isEditPanel ? _TT("SYNO.SDS.WebStation.Application", "common", "confirm_edit_page") : _TT("SYNO.SDS.WebStation.Application", "common", "confirm_create_page"), e, t, {
                                    yes: _T("common", "save"),
                                    no: _T("common", "cancel"),
                                    leftCustom: _T("common", "dont_save")
                                })
                            })
                        }, e.next = 6, i();
                    case 6:
                        if ("yes" !== (a = e.sent)) {
                            e.next = 9;
                            break
                        }
                        return e.abrupt("return", this.onApply());
                    case 9:
                        if ("no" !== a) {
                            e.next = 11;
                            break
                        }
                        return e.abrupt("return");
                    case 11:
                        if ("leftCustom" !== a) {
                            e.next = 13;
                            break
                        }
                        return e.abrupt("return", this.close());
                    case 13:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return function() {
            return e.apply(this, arguments)
        }
    }(),
    onError: function(e, t) {
        var i = SYNO.SDS.WebStation.Errors.GetMessage(e);
        switch (e) {
            case 1022:
                this.module.appWin.getMsgBox().confirm("ACL Error", i, this.onForceAcl, this);
                break;
            case 1310:
                this.panel.getForm().findField("alias").markInvalid(i), this.setStatusError({
                    text: i,
                    clear: !0
                });
                break;
            default:
                this.setStatusError({
                    text: i,
                    clear: !0
                })
        }
    },
    setData: function(e) {
        return this.panel.setData(e)
    }
}), Ext.define("SYNO.SDS.WebStation.Web.AliasPortalPanel", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(e) {
        this.module = e.module, this.owner = e.owner, this.preserve = e.preserve, this.dirty = !1;
        var t = Ext.apply({
            monitorValid: !0,
            autoFlexcroll: !0,
            height: 150,
            fieldWidth: 270,
            bodyStyle: "padding-right:0px; padding-left:0px;",
            labelSeparator: _T("common", "colon"),
            items: [{
                xtype: "syno_combobox",
                name: "service_id",
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "common", "service"),
                displayField: "service",
                valueField: "id",
                validator: this.serviceValidator,
                allowBlank: !1,
                hidden: this.preserve,
                store: new SYNO.API.JsonStore({
                    appWindow: this.module.appWin,
                    defaultSortable: !0,
                    autoDestroy: !0,
                    autoLoad: !1,
                    root: "services",
                    idProperty: "id",
                    fields: ["id", {
                        name: "service",
                        convert: function(e, t) {
                            return SYNO.SDS.WebStation.Util.geti18nString(t.display_name_i18n, t.display_name)
                        }
                    }],
                    api: "SYNO.WebStation.WebService.Service",
                    version: 1,
                    method: "list",
                    listeners: {
                        scope: this,
                        load: this.onServiceLoad
                    }
                })
            }, {
                xtype: "syno_displayfield",
                name: "service_id_fix",
                width: 250,
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "common", "service"),
                allowBlank: !1,
                emptyText: "Service Name",
                hidden: !this.preserve
            }, {
                xtype: "syno_textfield",
                vtype: "aliasname",
                maxlength: 255,
                allowBlank: !1,
                fieldLabel: _T("app_port_alias", "desc_alias"),
                name: "alias"
            }, {
                xtype: "syno_combobox",
                name: "acl",
                fieldLabel: _T("app_port_alias", "desc_acl"),
                displayField: "name",
                valueField: "UUID",
                store: new SYNO.API.JsonStore({
                    appWindow: this.module.appWin,
                    defaultSortable: !0,
                    autoDestroy: !0,
                    autoLoad: !1,
                    root: "entries",
                    idProperty: "UUID",
                    fields: ["UUID", "name"],
                    api: "SYNO.Core.AppPortal.AccessControl",
                    version: 1,
                    method: "list",
                    listeners: {
                        scope: this,
                        load: this.onAvailableAclLoad
                    }
                }),
                tpl: '<tpl for="."><div ext:qtip="{name}" class="x-combo-list-item">{name}</div></tpl>'
            }, {
                xtype: "syno_combobox",
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "error_page_profile"),
                name: "error_page",
                valueField: "id",
                displayField: "desc",
                store: new SYNO.API.JsonStore({
                    appWindow: this.module.appWin,
                    defaultSortable: !0,
                    autoDestroy: !0,
                    autoLoad: !0,
                    root: "profiles",
                    idProperty: "id",
                    fields: ["id", "desc"],
                    api: "SYNO.WebStation.ErrorPage",
                    version: 1,
                    method: "list",
                    listeners: {
                        scope: this,
                        load: this.onAvailableErrorPageLoaded
                    }
                }),
                tpl: '<tpl for="."><div ext:qtip="{desc}" class="x-combo-list-item">{desc}</div></tpl>'
            }]
        }, e);
        this.callParent([t]), this.doLayout(), this.mon(this, "afterlayout", this.addToolTip, this, {
            single: !0
        })
    },
    addToolTip: function() {
        var e = this.getForm().findField("service_id"),
            t = this.getForm().findField("acl"),
            i = this.getForm().findField("error_page");
        SYNO.ux.AddTip(e.getEl(), _TT("SYNO.SDS.WebStation.Application", "common", "tip_service_no_available")), SYNO.ux.AddTip(t.getEl(), _TT("SYNO.SDS.WebStation.Application", "common", "no_acl_profile_available")), SYNO.ux.AddTip(i.getEl(), _TT("SYNO.SDS.WebStation.Application", "common", "tip_error_page_profile"))
    },
    loadStores: function() {
        this.setStatusBusy();
        var e = this.getForm().findField("service_id").getStore(),
            t = this.getForm().findField("acl").getStore();
        e.load(), t.load()
    },
    onServiceLoad: function(e, t) {
        var i, a = {
                id: null,
                service: _TT("SYNO.SDS.WebStation.Application", "common", "status_not_available")
            },
            n = this.getForm().findField("service_id"),
            o = this.getForm().findField("service_id_fix"),
            r = n.getValue(),
            s = t.find(function(e) {
                return e.get("id") === r
            });
        if (0 === t.length) {
            var l = n.getStore();
            l.insert(0, new l.recordType(a)), i = a
        } else s ? i = {
            id: s.get("id"),
            service: s.get("service")
        } : (i = t[0], this.dirty = !0);
        n.setValue(i.id), o.setValue(i.service), this.storeLoaded("service")
    },
    onAvailableAclLoad: function(e, t) {
        var i, a = {
                UUID: null,
                name: _TT("SYNO.SDS.WebStation.Application", "default", "not_configured")
            },
            n = this.getForm().findField("acl"),
            o = n.getStore();
        o.insert(0, new o.recordType(a));
        var r = n.getValue();
        t.some(function(e) {
            return e.get("UUID") === r
        }) ? i = r : (i = null, null !== r && (this.dirty = !0)), n.setValue(i), this.storeLoaded("acl")
    },
    onAvailableErrorPageLoaded: function(e, t) {
        var i, a = this.getForm().findField("error_page"),
            n = a.getValue(),
            o = t.find(function(e) {
                return "default" === e.id
            });
        void 0 !== o && (o.data.desc = _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "default_profile")), t.some(function(e) {
            return e.get("id") === n
        }) ? i = n : (i = "default", this.dirty = !0), a.setValue(i), this.storeLoaded("error_page")
    },
    setStatusBusy: function() {
        this.owner.setStatusBusy()
    },
    storeLoaded: function(e) {
        "service" === e ? this.serviceLoaded = !0 : "acl" === e ? this.aclLoaded = !0 : "error_page" === e && (this.errorPageLoaded = !0), this.serviceLoaded && this.aclLoaded && this.errorPageLoaded && (this.dirty || this.flushDirtyState(), this.owner.clearStatusBusy())
    },
    serviceValidator: function(e) {
        return e !== _TT("SYNO.SDS.WebStation.Application", "common", "status_not_available") && "" !== e || _TT("SYNO.SDS.WebStation.Application", "error", "bad_service")
    },
    getData: function() {
        var e = this.getForm().getValues(),
            t = {};
        return this.uuid && (t.id = this.uuid), t.service = e.service_id, t.alias = e.alias, t.acl = e.acl, t.error_page = e.error_page, t.type = "alias", this.portal_data ? t.enable = this.portal_data.enable : t.enable = !0, t
    },
    setData: function(e) {
        var t = {};
        e.id && (this.uuid = e.id), t.service_id = e.service, t.alias = e.alias, t.acl = e.acl, t.error_page = e.error_page, t.enable = e.enable, this.portal_data = t, this.getForm().setValues(this.portal_data)
    },
    flushDirtyState: function() {
        this.getForm().items.items.forEach(function(e) {
            e.originalValue = e.getValue()
        })
    }
}), Ext.define("SYNO.SDS.WebStation.Web.AliasTab", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(e) {
        this.module = e.module, this.appWin = e.appWin, this.owner = e.owner, this.PortalStatusCode = Object.freeze({
            ENABLE: Symbol("enable"),
            SERVICE_DISABLE: Symbol("service_disable"),
            DISABLE: Symbol("disable"),
            ERROR: Symbol("error")
        }), this.store = new Ext.data.GroupingStore({
            reader: new Ext.data.JsonReader({
                fields: ["status", "service", "alias", "detail", "preserve"],
                idProperty: "id"
            }),
            groupField: "preserve",
            appWindow: this.owner,
            autoDestroy: !0,
            listeners: {
                beforeload: {
                    scope: this,
                    fn: this.onStoreBeforeLoaded
                },
                load: {
                    scope: this,
                    fn: this.onStoreLoaded
                }
            }
        });
        var t = this.fillConfig(e);
        this.callParent([t]), this.mon(SYNO.SDS.StatusNotifier, "thirdpartychanged", this.onPkgChanged, this)
    },
    fillConfig: function(e) {
        return Ext.apply({
            title: _T("app_port_alias", "desc_alias"),
            store: this.store,
            tbar: {
                xtype: "syno_toolbar",
                defaultType: "syno_button",
                items: this.getTBarItem()
            },
            columns: [{
                dataIndex: "preserve",
                hidden: !0,
                renderer: this.renderPreserve
            }, {
                dataIndex: "status",
                header: _TT("SYNO.SDS.WebStation.Application", "common", "status"),
                align: "left",
                sortable: !0,
                scope: this,
                renderer: this.renderStatus
            }, {
                dataIndex: "service",
                header: _TT("SYNO.SDS.WebStation.Application", "common", "service"),
                align: "left",
                sortable: !0,
                scope: this,
                renderer: this.renderService
            }, {
                dataIndex: "alias",
                header: _T("app_port_alias", "desc_alias"),
                align: "left",
                sortable: !0
            }, {
                dataIndex: "primary_link",
                header: _TT("SYNO.SDS.WebStation.Application", "common", "primary_link"),
                align: "left",
                scope: this,
                renderer: this.renderPrimaryLink
            }, {
                dataIndex: "detail",
                header: _TT("SYNO.SDS.WebStation.Application", "common", "details"),
                align: "left",
                sortable: !0,
                renderer: this.renderDetail
            }],
            selModel: this.selModel = new Ext.grid.RowSelectionModel({
                singleSelect: !1,
                listeners: {
                    selectionchange: {
                        scope: this,
                        fn: this.onSelectionChange
                    }
                }
            }),
            view: new SYNO.ux.GroupingView({
                showGroupName: !1,
                enableGroupingMenu: !1,
                forceFit: !0
            }),
            enableHdMenu: !1,
            enableColumnMove: !1,
            enableColLock: !1,
            listeners: {
                scope: this,
                rowdblclick: this.onRowDblclick,
                rowcontextmenu: this.onRowContextMenu,
                activate: this.onPageActivate
            }
        }, e)
    },
    createPortalHandler: function() {
        new SYNO.SDS.WebStation.Web.AliasPortalEditor({
            owner: this.appWin,
            module: this,
            title: _TT("SYNO.SDS.WebStation.Application", "alias", "create_alias_portal"),
            webapi: {
                api: "SYNO.WebStation.WebService.Portal",
                method: "create",
                version: 1
            },
            listeners: {
                close: this.webapiDone,
                scope: this
            }
        }).show()
    },
    createUpdateRequest: function(e, t, i) {
        return {
            api: e,
            method: "update",
            version: 1,
            params: _defineProperty({}, t, i)
        }
    },
    enableDisableHandler: function(e) {
        var t = this.getSelectionModel().getSelections(),
            i = [];
        this.busy(), Ext.each(t, function(t) {
            t.data.enable = e, i.push(this.createUpdateRequest("SYNO.WebStation.WebService.Portal", "portal", t.data))
        }, this), this.appWin.sendWebAPI({
            compound: {
                stopwhenerror: !1,
                params: i
            },
            scope: this,
            callback: function(e, t) {
                this.webapiDone()
            }
        })
    },
    editHandler: function() {
        var e = this.getSelectionModel().getSelections();
        if (1 === e.length) {
            var t = new SYNO.SDS.WebStation.Web.AliasPortalEditor({
                owner: this.appWin,
                module: this,
                title: _TT("SYNO.SDS.WebStation.Application", "alias", "edit_alias_portal"),
                webapi: {
                    api: "SYNO.WebStation.WebService.Portal",
                    method: "update",
                    version: 1
                },
                preserve: e[0].data.preserve,
                listeners: {
                    close: this.webapiDone,
                    scope: this
                }
            });
            t.setData(e[0].data), t.show()
        }
    },
    deleteHandler: function() {
        var e = this.getSelectionModel(),
            t = e.getSelections();
        if (t.length && !this.hasPreserved(t)) {
            var i = [];
            this.owner.getMsgBox().confirmDelete(_TT("SYNO.SDS.WebStation.Application", "title", "vhost"), _T("common", "remove_cfrmrmv"), function(a) {
                "yes" === a && (this.busy(), 1 === t.length && e.selectNext(), Ext.each(t, function(e) {
                    i.push(e.data.id), this.store.remove(e)
                }, this), this.sendDeleteWebAPI(i))
            }.bind(this))
        }
    },
    sendDeleteWebAPI: function(e) {
        this.sendWebAPI({
            api: "SYNO.WebStation.WebService.Portal",
            method: "remove",
            version: 1,
            params: {
                ids: e
            },
            scope: this,
            callback: function(e, t) {
                this.webapiDone()
            }
        })
    },
    renderPreserve: function(e) {
        return !0 === e ? _TT("SYNO.SDS.WebStation.Application", "portal", "header_group_preserve_portal") : _TT("SYNO.SDS.WebStation.Application", "portal", "header_group_non_preserve_portal")
    },
    renderStatus: function(e, t, i) {
        var a, n, o = this.checkPortalStatus(i.data);
        return o === this.PortalStatusCode.ENABLE ? (a = _T("helpbrowser", "font_normal"), n = "green") : o === this.PortalStatusCode.DISABLE ? (a = _T("common", "disabled"), n = "syno-webstation-grey") : o === this.PortalStatusCode.SERVICE_DISABLE ? (a = _TT("SYNO.SDS.WebStation.Application", "common", "service_disable"), n = "red") : o === this.PortalStatusCode.ERROR && (a = _T("common", "status_abnormal"), n = "red"), String.format('<font class="{0}-status">{1}</font>', n, a)
    },
    renderService: function(e, t, i) {
        var a = i.data.service;
        if (!this.serviceIdMap[a]) {
            var n = _TT("SYNO.SDS.WebStation.Application", "common", "status_not_available");
            return String.format('<span class="syno-webstation-grey-status">{0}</span>', n)
        }
        var o = this.serviceIdMap[a].display_name_i18n,
            r = this.serviceIdMap[a].display_name;
        return SYNO.SDS.WebStation.Util.geti18nString(o, r)
    },
    renderDetail: function(e, t, i) {
        return "vhost" === i.data.$type && i.data.root ? _TT("SYNO.SDS.WebStation.Application", "vhost", "docroot") + ": ".concat(i.data.root) : ""
    },
    renderPrimaryLink: function(e, t, i) {
        return this.genPrimaryLink("https", i.get("alias"))
    },
    onPkgChanged: function(e, t) {
        "WebStation" !== e && this.loadStore()
    },
    onPageActivate: function() {
        this.btnDisableHandler(), this.loadStore()
    },
    onStoreBeforeLoaded: function(e, t, i) {
        this.busy()
    },
    onStoreLoaded: function(e, t, i, a) {
        this.unbusy(), this.btnDisableHandler()
    },
    onSelectionChange: function(e, t) {
        this.btnDisableHandler()
    },
    onRowContextMenu: function(e, t, i, a) {
        var n = new SYNO.ux.Menu({
                autoDestroy: !0,
                items: this.getContextActionGroup().getArray()
            }),
            o = this.getSelectionModel();
        o.selectRow(t, o.isSelected(t)), n.showAt(i.getXY()), i.preventDefault()
    },
    onRowDblclick: function(e, t, i, a) {
        this.editHandler()
    },
    btnDisableHandler: function() {
        var e = this.selModel.getSelections(),
            t = this.selModel.getSelections().length,
            i = this.getTBarItem(),
            a = this.getContextActionGroup();
        if (0 === t ? (i[1].disable(), i[2].disable(), a.disable("edit")) : (Ext.getCmp(this.deletePortalBtnId).enable(), a.enable("delete"), 1 === t ? (i[1].enable(), i[2].enable(), a.enable("edit")) : (i[1].disable(), i[2].enable(), a.disable("edit"))), this.hasPreserved(e)) return Ext.getCmp(this.deletePortalBtnId).disable(), void a.disable("delete")
    },
    addPortalData: function(e) {
        var t = !0,
            i = !1,
            a = void 0;
        try {
            for (var n, o = e[Symbol.iterator](); !(t = (n = o.next()).done); t = !0) {
                var r = n.value;
                if ("alias" === r.type) {
                    var s = Object.assign({}, r);
                    this.store.add([new this.store.recordType(s)])
                }
            }
        } catch (e) {
            i = !0, a = e
        } finally {
            try {
                t || null == o.return || o.return()
            } finally {
                if (i) throw a
            }
        }
    },
    loadStore: function() {
        var e = this;
        this.busy(), this.loadServices().then(function() {
            return e.loadPortals()
        }).then(function() {
            e.store.groupBy("preserve", !0)
        }).catch(function(e) {
            SYNO.Debug(e)
        }), this.unbusy()
    },
    loadServices: function() {
        var e = this;
        return new Promise(function(t, i) {
            e.sendWebAPI({
                api: "SYNO.WebStation.WebService.Service",
                method: "list",
                version: 1,
                scope: e,
                callback: function(e, a) {
                    var n = this;
                    e ? (this.serviceIdMap = {}, a.services && a.services.forEach(function(e) {
                        n.serviceIdMap[e.id] = e
                    }), t()) : i()
                }
            })
        })
    },
    loadPortals: function() {
        var e = this;
        return new Promise(function(t, i) {
            e.sendWebAPI({
                api: "SYNO.WebStation.WebService.Portal",
                method: "list",
                version: 1,
                scope: e,
                callback: function(e, a) {
                    e ? (this.store.removeAll(), this.addPortalData(a.portals), t()) : i()
                }
            })
        })
    },
    busy: function() {
        this.el.mask(_T("common", "loading"), "x-mask-loading")
    },
    unbusy: function() {
        this.el.unmask()
    },
    webapiDone: function() {
        this.unbusy(), this.loadStore(), SYNO.SDS.reloadJSConfig()
    },
    getTBarItem: function() {
        return this.tbarItems ? this.tbarItems : (this.tbarItems = [new Ext.Action({
            text: _T("common", "create"),
            itemId: "create",
            btnStyle: "blue",
            scope: this,
            handler: this.createPortalHandler
        }), new Ext.Action({
            text: _T("common", "alt_edit"),
            itemId: "edit",
            scope: this,
            handler: this.editHandler
        }), new SYNO.ux.SplitButton({
            text: _T("common", "action"),
            itemId: "operation",
            disabled: this._S("demo_mode"),
            handler: function(e) {
                e.showMenu()
            },
            scope: this,
            menu: {
                items: [{
                    text: _TT("SYNO.SDS.WebStation.Application", "common", "enable"),
                    scope: this,
                    handler: this.enableDisableHandler.createDelegate(this, [!0])
                }, {
                    text: _TT("SYNO.SDS.WebStation.Application", "common", "disable"),
                    scope: this,
                    handler: this.enableDisableHandler.createDelegate(this, [!1])
                }, {
                    id: this.deletePortalBtnId = Ext.id(),
                    text: _T("common", "delete"),
                    scope: this,
                    handler: this.deleteHandler
                }]
            }
        })], this.tbarItems)
    },
    getContextActionGroup: function() {
        return this.contextMenu ? this.contextMenu : (this.contextMenu = new SYNO.ux.Utils.ActionGroup([new Ext.Action({
            text: _T("common", "alt_edit"),
            itemId: "edit",
            scope: this,
            handler: this.editHandler
        }), new Ext.Action({
            text: _TT("SYNO.SDS.WebStation.Application", "common", "enable"),
            itemId: "enable",
            scope: this,
            handler: this.enableDisableHandler.createDelegate(this, [!0])
        }), new Ext.Action({
            text: _TT("SYNO.SDS.WebStation.Application", "common", "disable"),
            itemId: "disable",
            scope: this,
            handler: this.enableDisableHandler.createDelegate(this, [!1])
        }), new Ext.Action({
            text: _T("common", "delete"),
            itemId: "delete",
            scope: this,
            handler: this.deleteHandler
        })]), this.contextMenu)
    },
    checkPortalStatus: function(e) {
        if (!e.enable) return this.PortalStatusCode.DISABLE;
        var t = e.service,
            i = this.serviceIdMap[t];
        return i ? i.enable ? this.PortalStatusCode.ENABLE : this.PortalStatusCode.SERVICE_DISABLE : this.PortalStatusCode.ERROR
    },
    hasPreserved: function(e) {
        for (var t = e.length, i = 0; i < t; i++)
            if (!0 === e[i].get("preserve")) return !0;
        return !1
    },
    genPrimaryLink: function(e, t) {
        var i = "".concat(e, "://").concat(window.location.hostname, "/").concat(t);
        return '<a class="syno-webstation-management" href="{link}" target="_blank" ext:qtip="{link}" style="width:20px;float:left"></a>'.replaceAll(/{link}/g, i)
    }
}), Ext.define("SYNO.SDS.WebStation.WebServicePortalTab", {
    extend: "SYNO.SDS.Utils.TabPanel",
    constructor: function(e) {
        var t = Ext.apply({
            activeTab: 0,
            cls: "ws-wsportal-main",
            items: [this.vhostTab = new SYNO.SDS.WebStation.VHostTab({
                module: e,
                appWin: e.appWin,
                owner: e.owner
            }), this.aliasTab = new SYNO.SDS.WebStation.Web.AliasTab({
                module: e,
                appWin: e.appWin,
                owner: e.owner
            })]
        }, e);
        this.callParent([t])
    }
}), Ext.define("SYNO.SDS.WebStation.CustomErrorPage", {
    extend: "Ext.Container",
    constructor: function(e) {
        this.customErrorPage = this.createCustomErrorPage();
        var t = {
            layout: "fit",
            items: [this.customErrorPage]
        };
        this.callParent([Ext.apply(t, e)]), this.mon(SYNO.SDS.StatusNotifier, "thirdpartychanged", this.onPkgChanged, this)
    },
    createCustomErrorPage: function() {
        return new SYNO.SDS.VuePanel({
            vueClass: SYNO.SDS.WebStation.Vue.CustomErrorPage,
            mountId: "webstation-custom-error-page",
            owner: this
        })
    },
    onPkgChanged: function(e) {
        "WebStation" !== e && this.loadData()
    },
    loadData: function() {
        this.customErrorPage.components[0].$children[0].$refs.dataTable.refresh()
    }
}), Ext.define("SYNO.SDS.WebStation.Web.DefaultServerPortalEditor", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.module = e.module, this.owner = e.owner, this.store = e.store, this.webapi = e.webapi, this.uuid = "", this.preserve = e.preserve, this.panel = new SYNO.SDS.WebStation.Web.DefaultServerPortalPanel({
            module: this.module,
            perserve: this.preserve,
            owner: this
        }), this.callParent([Ext.apply({
            width: 650,
            autoHeight: !0,
            items: [this.panel],
            closeAction: "onCancel",
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: this.onCancel
            }, {
                text: _T("common", "save"),
                btnStyle: "blue",
                disabled: this._S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                scope: this,
                handler: this.onApply
            }],
            listeners: {
                scope: this,
                show: this.onShow
            }
        }, e)])
    },
    sendRequest: function(e) {
        var t = this.panel.getData();
        this.sendWebAPI({
            api: this.webapi.api,
            method: this.webapi.method,
            version: this.webapi.version,
            params: {
                portal: t
            },
            callback: function(e, t) {
                this.clearStatusBusy(), e ? (this.fireEvent("close"), this.close()) : this.onError(t.code, t.errors)
            },
            scope: this
        })
    },
    onForceAcl: function(e) {
        "yes" == e && this.panel.getForm().isValid() && this.validator() && (this.panel.getForm().isDirty() ? (this.setStatusBusy(), this.sendRequest(!0)) : this.close())
    },
    onApply: function() {
        this.panel.getForm().isValid() && this.validator() ? this.panel.getForm().isDirty() ? (this.setStatusBusy(), this.sendRequest(!1)) : this.close() : this.setStatusError({
            text: _T("error", "error_bad_field"),
            clear: !0
        })
    },
    onCancel: function() {
        var e = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t, i, a;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        if (this.panel.getForm().isDirty()) {
                            e.next = 2;
                            break
                        }
                        return e.abrupt("return", this.close());
                    case 2:
                        return t = this.findAppWindow(), i = function() {
                            return new Promise(function(e) {
                                t.getMsgBox().confirm(_TT("SYNO.SDS.WebStation.Application", "title", "vhost"), _TT("SYNO.SDS.WebStation.Application", "common", "confirm_edit_page"), e, t, {
                                    yes: _T("common", "save"),
                                    no: _T("common", "cancel"),
                                    leftCustom: _T("common", "dont_save")
                                })
                            })
                        }, e.next = 6, i();
                    case 6:
                        if ("yes" !== (a = e.sent)) {
                            e.next = 9;
                            break
                        }
                        return e.abrupt("return", this.onApply());
                    case 9:
                        if ("no" !== a) {
                            e.next = 11;
                            break
                        }
                        return e.abrupt("return");
                    case 11:
                        if ("leftCustom" !== a) {
                            e.next = 13;
                            break
                        }
                        return e.abrupt("return", this.close());
                    case 13:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return function() {
            return e.apply(this, arguments)
        }
    }(),
    handleConflictHost: function(e) {
        var t = this.panel.getForm(),
            i = !t.findField("fqdn").disabled,
            a = t.findField(i ? "name_http_port" : "port_http_port"),
            n = t.findField(i ? "name_https_port" : "port_https_port"),
            o = {
                text: _TT("SYNO.SDS.WebStation.Application", "error", i ? "err_host_duplicated" : "err_port_conflict"),
                clear: !0
            };
        i && t.findField("fqdn").markInvalid(o.text), this.setStatusError(o), [a, n].forEach(function(t) {
            !t.disabled && e.includes(parseInt(t.getValue(), 10)) && t.markInvalid(_TT("SYNO.SDS.WebStation.Application", "error", "err_port_conflict"))
        })
    },
    onError: function(e, t) {
        var i = this.panel.getForm(),
            a = SYNO.SDS.WebStation.Errors.GetMessage(e);
        switch (e) {
            case 1004:
                this.handleConflictHost(t.conflict_ports);
                break;
            case 1007:
                i.findField("fqdn").markInvalid(a), this.setStatusError({
                    text: a,
                    clear: !0
                });
                break;
            case 1009:
            case 1021:
                this.handleConflictHost(t.conflict_ports);
                break;
            case 1022:
                this.module.appWin.getMsgBox().confirm("ACL Error", a, this.onForceAcl, this);
                break;
            default:
                this.setStatusError({
                    text: a,
                    clear: !0
                })
        }
    },
    setData: function(e) {
        return this.panel.setData(e)
    },
    validator: function() {
        var e = this.panel.getForm().getValues();
        return ("name" !== e.based || e.name_port || e.name_http || e.name_https) && !("port" === e.based && !e.port_http && !e.port_https) || (this.setStatusError({
            text: _TT("SYNO.SDS.WebStation.Application", "error", "err_no_port_set"),
            clear: !0
        }), !1)
    }
}), Ext.define("SYNO.SDS.WebStation.Web.DefaultServerPortalPanel", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(e) {
        this.module = e.module, this.owner = e.owner, this.preserve = e.preserve;
        var t = Ext.apply({
            monitorValid: !0,
            autoFlexcroll: !0,
            height: 402,
            fieldWidth: 270,
            bodyStyle: "padding-right:0px; padding-left:0px;",
            labelSeparator: _T("common", "colon"),
            items: [{
                xtype: "syno_displayfield",
                name: "service_id_fix",
                width: 250,
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "common", "service"),
                allowBlank: !1,
                emptyText: "Service Name",
                hidden: !this.preserve
            }, {
                xtype: "syno_radio",
                name: "based",
                boxLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "name_based"),
                checked: !0,
                inputValue: "name",
                id: this.name_based = Ext.id(),
                scope: this,
                handler: this.enableHandler
            }, {
                xtype: "syno_textfield",
                vtype: "FQDN",
                maxlength: 255,
                allowBlank: !1,
                indent: 1,
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "hostname"),
                name: "fqdn",
                validator: this.validateFQDN.createDelegate(this)
            }, {
                xtype: "syno_compositefield",
                indent: 1,
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "port"),
                items: [{
                    xtype: "syno_checkbox",
                    name: "name_port",
                    boxLabel: "80 / 443",
                    checked: !0,
                    inputValue: "default"
                }]
            }, {
                xtype: "syno_compositefield",
                indent: 1,
                items: [{
                    xtype: "syno_checkbox",
                    name: "name_http",
                    boxLabel: "HTTP",
                    width: 90,
                    inputValue: "http",
                    scope: this,
                    handler: this.enableHandler
                }, {
                    disabled: !0,
                    xtype: "syno_textfield",
                    vtype: "port",
                    allowBlank: !1,
                    name: "name_http_port",
                    width: 60,
                    maxlength: 5,
                    validator: function(e) {
                        return 80 != e
                    }
                }]
            }, {
                xtype: "syno_compositefield",
                indent: 1,
                items: [{
                    xtype: "syno_checkbox",
                    name: "name_https",
                    boxLabel: "HTTPS",
                    width: 90,
                    inputValue: "https",
                    scope: this,
                    handler: this.enableHandler
                }, {
                    disabled: !0,
                    xtype: "syno_textfield",
                    vtype: "port",
                    allowBlank: !1,
                    name: "name_https_port",
                    width: 60,
                    maxlength: 5,
                    validator: function(e) {
                        return 443 != e
                    }
                }]
            }, {
                xtype: "syno_radio",
                name: "based",
                indent: 0,
                boxLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "port_based"),
                inputValue: "port",
                scope: this,
                handler: this.enableHandler
            }, {
                xtype: "syno_compositefield",
                indent: 1,
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "port"),
                items: [{
                    disabled: !0,
                    xtype: "syno_checkbox",
                    name: "port_http",
                    width: 90,
                    boxLabel: "HTTP",
                    inputValue: "http",
                    scope: this,
                    handler: this.enableHandler
                }, {
                    disabled: !0,
                    xtype: "syno_textfield",
                    vtype: "port",
                    allowBlank: !1,
                    name: "port_http_port",
                    width: 60,
                    maxlength: 5
                }]
            }, {
                xtype: "syno_compositefield",
                indent: 1,
                items: [{
                    disabled: !0,
                    xtype: "syno_checkbox",
                    name: "port_https",
                    width: 90,
                    boxLabel: "HTTPS",
                    inputValue: "https",
                    scope: this,
                    handler: this.enableHandler
                }, {
                    disabled: !0,
                    xtype: "syno_textfield",
                    vtype: "port",
                    allowBlank: !1,
                    name: "port_https_port",
                    width: 60,
                    maxlength: 5
                }]
            }, {
                xtype: "syno_compositefield",
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "https_settings"),
                items: [{
                    xtype: "syno_checkbox",
                    name: "hsts",
                    boxLabel: "HSTS"
                }]
            }]
        }, e);
        this.FQDNChecker = new SYNO.SDS.AdminCenter.Utils.Validator.FQDNConflictChecker, this.FQDNChecker.FindListFQDNPortPair(this, "SYNO.WebStation.HTTP.VHost"), this.callParent([t]), this.doLayout()
    },
    enableHandler: function() {
        var e = this.getForm(),
            t = function(t) {
                e.findField(t).enable()
            },
            i = function(t) {
                e.findField(t).disable()
            },
            a = ["fqdn", "name_port", "name_http", "name_https"],
            n = ["port_http", "port_https"];
        e.findField(this.name_based).getValue() ? (Ext.each(a, t), Ext.each(n, i)) : (Ext.each(n, t), Ext.each(a, i)), Ext.each(["name_http", "name_https", "port_http", "port_https"], function(t) {
            var i = e.findField(t);
            !i.disabled && i.getValue() ? e.findField(t + "_port").enable() : e.findField(t + "_port").disable()
        })
    },
    getData: function() {
        var e = this.getForm().getValues(),
            t = {
                http_port: [],
                https_port: []
            };
        return t.service = this.service_id, "name" === e.based ? (t.fqdn = e.fqdn, e.name_port && (t.http_port.push(80), t.https_port.push(443)), e.name_http && t.http_port.push(parseInt(e.name_http_port, 10)), e.name_https && t.https_port.push(parseInt(e.name_https_port, 10))) : (e.port_http && t.http_port.push(parseInt(e.port_http_port, 10)), e.port_https && t.https_port.push(parseInt(e.port_https_port, 10))), t.hsts = e.hsts, t.acl = this.acl, t.error_page = this.error_page, this.uuid && (t.id = this.uuid), this.portal_data_raw ? (t.compatible_crt_service = this.portal_data_raw.compatible_crt_service, t.compatible_crt_subscriber = this.portal_data_raw.compatible_crt_subscriber, t.compatible_sc_section = this.portal_data_raw.compatible_sc_section, t.type = this.portal_data_raw.type, t.enable = this.portal_data_raw.enable) : t.type = "server", "alias" === t.type && (t.alias = this.portal_data_raw.alias), t
    },
    setData: function(e) {
        var t = {};
        if (this.service_id = e.service, e.fqdn) {
            t.based = "name", t.fqdn = e.fqdn, e.http_port || (e.http_port = []), e.https_port || (e.https_port = []);
            var i = e.http_port.indexOf(80),
                a = e.https_port.indexOf(443); - 1 !== i && -1 !== a ? (t.name_port = !0, e.http_port.splice(i, 1), e.https_port.splice(a, 1)) : t.name_port = !1, e.http_port.length && (t.name_http = !0, t.name_http_port = e.http_port[0]), e.https_port.length && (t.name_https = !0, t.name_https_port = e.https_port[0])
        } else t.based = "port", e.http_port && e.http_port.length && (t.port_http = !0, t.port_http_port = e.http_port[0]), e.https_port && e.https_port.length && (t.port_https = !0, t.port_https_port = e.https_port[0]);
        t.hsts = e.hsts, this.acl = e.acl, this.error_page = e.error_page, e.id && (this.uuid = e.id), this.portal_data_raw = e, this.portal_data = t, this.getForm().setValues(this.portal_data)
    },
    validateService: function(e) {
        return e !== _TT("SYNO.SDS.WebStation.Application", "common", "status_not_available") && "" !== e || _TT("SYNO.SDS.WebStation.Application", "error", "bad_service")
    },
    validateFQDN: function(e) {
        var t, i = this.getForm().getValues();
        return "name" !== i.based || (i.name_port && (this.FQDNChecker.IsConflict(e, 80) || this.FQDNChecker.IsConflict(e, 443)) ? _T("app_port_alias", "err_fqdn_duplicated") : i.name_http && (t = parseInt(i.name_http_port, 10)) && this.FQDNChecker.IsConflict(e, t) ? _T("app_port_alias", "err_fqdn_duplicated") : !(i.name_https && (t = parseInt(i.name_https_port, 10)) && this.FQDNChecker.IsConflict(e, t)) || _T("app_port_alias", "err_fqdn_duplicated"))
    }
}), Ext.define("SYNO.SDS.WebStation.ServicePortalPage", {
    extend: "Ext.Container",
    constructor: function(e) {
        this.page = this.createPage();
        var t = {
            layout: "fit",
            items: [this.page]
        };
        this.callParent([Ext.apply(t, e)]), this.mon(SYNO.SDS.StatusNotifier, "thirdpartychanged", this.onPkgChanged, this)
    },
    createPage: function() {
        return new SYNO.SDS.VuePanel({
            vueClass: SYNO.SDS.WebStation.Vue.ServicePortalPage,
            mountId: "webstation-vue-service-portal-page",
            owner: this
        })
    },
    onPageActivate: function() {
        this.loadData()
    },
    onPkgChanged: function(e) {
        "WebStation" !== e && this.loadData()
    },
    loadData: function() {
        this.page.components[0].$children[0].loadData()
    }
}), Ext.define("SYNO.SDS.WebStation.Dialog.DefaultServer", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.module = e.module, this.owner = e.owner, this.panel = this.createPanel(e), this.callParent([Ext.apply({
            width: 650,
            autoHeight: !0,
            items: [this.panel],
            closeAction: "cancel",
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: function() {
                    return this.cancel()
                }
            }, {
                text: _T("common", "save"),
                btnStyle: "blue",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                scope: this,
                handler: function() {
                    return this.submit()
                }
            }]
        }, e)])
    },
    createPanel: function(e) {
        return new SYNO.SDS.WebStation.DefaultServer({
            module: e.module,
            owner: e.owner
        })
    },
    submit: function() {
        if (this.panel.getForm().isValid())
            if (this.panel.getForm().isDirty()) {
                this.el.mask(), this.setStatusBusy();
                var e = this.panel.getData();
                this.sendWebAPI({
                    api: "SYNO.WebStation.Default",
                    method: "set",
                    version: 1,
                    params: e,
                    callback: function(e, t) {
                        this.el.unmask(), this.clearStatusBusy(), e ? (this.fireEvent("close"), this.close()) : this.setStatusError({
                            text: _T("error", "error_bad_field")
                        })
                    },
                    scope: this
                })
            } else this.close();
        else this.setStatusError({
            text: _T("error", "error_bad_field")
        })
    },
    cancel: function() {
        var e = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t, i, a, n = this;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        if (this.panel.getForm().isDirty()) {
                            e.next = 2;
                            break
                        }
                        return e.abrupt("return", this.close());
                    case 2:
                        return t = this.findAppWindow(), i = function() {
                            return new Promise(function(e) {
                                t.getMsgBox().confirm(_TT("SYNO.SDS.WebStation.Application", "title", "vhost"), n.panel.isEditPanel ? _TT("SYNO.SDS.WebStation.Application", "common", "confirm_edit_page") : _TT("SYNO.SDS.WebStation.Application", "common", "confirm_create_page"), e, t, {
                                    yes: _T("common", "save"),
                                    no: _T("common", "cancel"),
                                    leftCustom: _T("common", "dont_save")
                                })
                            })
                        }, e.next = 6, i();
                    case 6:
                        if ("yes" !== (a = e.sent)) {
                            e.next = 9;
                            break
                        }
                        return e.abrupt("return", this.submit());
                    case 9:
                        if ("no" !== a) {
                            e.next = 11;
                            break
                        }
                        return e.abrupt("return");
                    case 11:
                        if ("leftCustom" !== a) {
                            e.next = 13;
                            break
                        }
                        return e.abrupt("return", this.close());
                    case 13:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return function() {
            return e.apply(this, arguments)
        }
    }()
}), Ext.define("SYNO.SDS.WebStation.DefaultServer", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(e) {
        this.appWin = e.owner, this.webapiDefault = {
            api: "SYNO.WebStation.Default",
            methods: {
                get: "get",
                set: "set"
            },
            version: 1
        }, this.webapiStatus = {
            api: "SYNO.WebStation.Status",
            methods: {
                get: "get"
            },
            version: 1
        }, this.webapiPHPProfile = {
            api: "SYNO.WebStation.PHP.Profile",
            methods: {
                get: "list"
            },
            version: 1
        }, this.webapiHomeService = {
            api: "SYNO.Core.Share",
            methods: {
                get: "get"
            },
            version: 1
        };
        var t = this.fillConfig(e);
        this.status_data = void 0, this.saveResolve = null, this.serverData = null, this.userdirServerData = null, this.phpData = null, this.callParent([t]), this.loadForm(), this.mon(this, "afterlayout", this.addToolTip, this, {
            single: !0
        }), this.mon(SYNO.SDS.StatusNotifier, "thirdpartychanged", this.loadForm, this), this.mon(SYNO.SDS.StatusNotifier, "sharefolderchanged", this.loadForm, this)
    },
    fillConfig: function(e) {
        var t = {
            autoScroll: !0,
            autoHeight: !0,
            webapi: this.webapiDefault,
            labelSeparator: _T("common", "colon"),
            items: [this.createItems()]
        };
        return Ext.apply(t, e), t
    },
    createItems: function() {
        var e = [];
        return e.push({
            xtype: "syno_combobox",
            name: "backend",
            fieldLabel: _TT("SYNO.SDS.WebStation.Application", "default", "http_backend"),
            valueField: "backend_id",
            displayField: "backend_name",
            store: new Ext.data.SimpleStore({
                fields: ["backend_id", "backend_name"],
                listeners: {
                    load: {
                        scope: this,
                        fn: this.onAvailableDefaultServerLoad
                    }
                }
            }),
            validator: this.validatorBackend.createDelegate(this),
            allowBlank: !1
        }), e.push({
            xtype: "syno_combobox",
            name: "php",
            fieldLabel: "PHP",
            valueField: "uuid",
            displayField: "profile_name",
            store: new Ext.data.SimpleStore({
                fields: ["uuid", "profile_name"],
                listeners: {
                    load: {
                        scope: this,
                        fn: this.onAvailableDefaultServerPHPLoad
                    }
                }
            }),
            validator: this.validatorPHP.createDelegate(this),
            allowBlank: !1,
            tpl: '<tpl for="."><div ext:qtip="{profile_name}" class="x-combo-list-item">{profile_name}</div></tpl>'
        }), e.push({
            xtype: "syno_checkbox",
            name: "userdir",
            boxLabel: _TT("SYNO.SDS.WebStation.Application", "default", "enable_userdir"),
            listeners: {
                check: {
                    scope: this,
                    fn: function(e, t) {
                        var i = !1;
                        t && (i = this.userHomeCheckHandler()), this.handleUserdirEnableStatus(i)
                    }
                },
                disable: {
                    scope: this,
                    fn: function(e) {
                        this.handleUserdirEnableStatus(!1)
                    }
                }
            }
        }, {
            xtype: "syno_displayfield",
            indent: 1,
            value: _TT("SYNO.SDS.WebStation.Application", "default", "enable_userdir_desc")
        }, {
            xtype: "syno_combobox",
            indent: 1,
            name: "userdir_backend",
            fieldLabel: _TT("SYNO.SDS.WebStation.Application", "default", "http_backend"),
            valueField: "backend_id",
            displayField: "backend_name",
            store: new Ext.data.SimpleStore({
                fields: ["backend_id", "backend_name"],
                listeners: {
                    load: {
                        scope: this,
                        fn: this.onAvailableUserdirServerLoad
                    }
                }
            }),
            validator: this.validatorBackend.createDelegate(this),
            allowBlank: !1
        }, {
            xtype: "syno_combobox",
            indent: 1,
            name: "userdir_php",
            fieldLabel: "PHP",
            valueField: "uuid",
            displayField: "profile_name",
            store: new Ext.data.SimpleStore({
                fields: ["uuid", "profile_name"],
                listeners: {
                    load: {
                        scope: this,
                        fn: this.onAvailableUserdirPHPLoad
                    }
                }
            }),
            validator: this.validatorPHP.createDelegate(this),
            allowBlank: !1,
            tpl: '<tpl for="."><div ext:qtip="{profile_name}" class="x-combo-list-item">{profile_name}</div></tpl>'
        }), e.push({
            xtype: "syno_displayfield",
            htmlEncode: !1,
            value: '<font class="note-font">' + _TT("SYNO.SDS.WebStation.Application", "common", "note_header") + "</font>" + _TT("SYNO.SDS.WebStation.Application", "php", "no_php_profile_available")
        }), e
    },
    addToolTip: function() {
        var e = this.getForm().findField("userdir");
        SYNO.ux.AddTip(e.getEl(), _TT("SYNO.SDS.WebStation.Application", "default", "install_apache_for_enable_userdir_tips"))
    },
    userHomeCheckHandler: function() {
        var e = this.status_data.home_share_status;
        return e === SYNO.SDS.WebStation.Util.HomeShareStatus.StatusNormal || (e === SYNO.SDS.WebStation.Util.HomeShareStatus.StatusNotEnable ? this.appWin.getMsgBox().confirm(_TT("SYNO.SDS.WebStation.Application", "default", "userdir"), _TT("SYNO.SDS.WebStation.Application", "default", "userdir_warning"), function(e) {
            "yes" === e && SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", Ext.apply({
                fn: "SYNO.SDS.AdminCenter.User.Main",
                userHomeDialog: !0
            }))
        }, this) : e === SYNO.SDS.WebStation.Util.HomeShareStatus.StatusIsEncrypted ? this.appWin.getMsgBox().confirm(_TT("SYNO.SDS.WebStation.Application", "default", "userdir"), _TT("SYNO.SDS.WebStation.Application", "default", "userdir_encrypt_warning"), function(e) {
            "yes" === e && SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", Ext.apply({
                fn: "SYNO.SDS.AdminCenter.Share.Main"
            }))
        }, this) : this.home_share_data.hasOwnProperty("is_cold_storage_share") && this.home_share_data.is_cold_storage_share && this.appWin.getMsgBox().alert(_TT("SYNO.SDS.WebStation.Application", "default", "userdir"), _TT("SYNO.SDS.WebStation.Application", "default", "userdir_pata_warning")), this.getForm().findField("userdir").reset(), !1)
    },
    processParams: function(e, t) {
        this.callParent(arguments);
        var i = {
            api: this.webapiStatus.api,
            method: this.webapiStatus.methods.get,
            version: this.webapiStatus.version
        };
        t.push(i);
        var a = {
            api: this.webapiPHPProfile.api,
            method: this.webapiPHPProfile.methods.get,
            version: this.webapiPHPProfile.version
        };
        t.push(a);
        var n = {
            api: this.webapiHomeService.api,
            method: this.webapiHomeService.methods.get,
            params: {
                additional: ["is_cold_storage_share"],
                name: "homes"
            },
            version: this.webapiHomeService.version
        };
        return t.push(n), t
    },
    handleUserdirEnableStatus: function(e) {
        ["userdir_backend", "userdir_php"].forEach(function(t) {
            var i = this.getForm().findField(t);
            i.disabled === e && i.setDisabled(!e)
        }, this)
    },
    processReturnData: function() {
        var e = _asyncToGenerator(regeneratorRuntime.mark(function e(t, i, a) {
            var n, o, r, s, l, d, p, c = this;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        if (this.appWin.clearStatusBusy(), this.el.unmask(), !i.has_fail) {
                            e.next = 8;
                            break
                        }
                        if (n = i.result.filter(function(e) {
                                return !e.success
                            }), 402 === n.find(function(e) {
                                return "SYNO.Core.Share" === e.api
                            }).error.code && !(n.length > 1)) {
                            e.next = 8;
                            break
                        }
                        return this.errorHandling(n[0].error.code), e.abrupt("return");
                    case 8:
                        return o = {
                            api: this.webapiStatus.api,
                            method: this.webapiStatus.methods.get,
                            version: this.webapiStatus.version
                        }, this.status_data = SYNO.SDS.WebStation.Util.getSuccessRespCompoundData(o, i), r = {
                            api: this.webapiHomeService.api,
                            method: this.webapiHomeService.methods.get,
                            version: this.webapiHomeService.version
                        }, this.home_share_data = SYNO.SDS.WebStation.Util.getSuccessRespCompoundData(r, i), s = {
                            api: this.webapiPHPProfile.api,
                            method: this.webapiPHPProfile.methods.get,
                            version: this.webapiPHPProfile.version
                        }, this.profile_list = SYNO.SDS.WebStation.Util.getSuccessRespCompoundData(s, i), l = this.getForm().findField("userdir"), this.getForm().loadRecords(i.result, a.compound), this.status_data.home_share_status === SYNO.SDS.WebStation.Util.HomeShareStatus.StatusBackendNotExist ? l.disable() : (l.enable(), this.handleUserdirEnableStatus(l.getValue())), e.next = 19, SYNO.SDS.WebStation.Util.PackageInfo.Get();
                    case 19:
                        d = e.sent, p = this.status_data.available_server_backend, this.serverData = p.map(function(e) {
                            return [e, d.backendData.server.find(function(t) {
                                return t.id === e
                            }).name]
                        }), this.userdirServerData = this.serverData.filter(function(e) {
                            return 0 !== e[0]
                        }), this.phpData = [
                            [null, _TT("SYNO.SDS.WebStation.Application", "default", "php_not_configured")]
                        ].concat(this.profile_list.profiles.filter(function(e) {
                            return null === e.default_profile
                        }).map(function(e) {
                            return [e.uuid, "".concat(e.profile_name, " ( ").concat(d.backendData.php.find(function(t) {
                                return t.id === e.backend
                            }).name, " )")]
                        })), [{
                            field: "backend",
                            data: this.serverData
                        }, {
                            field: "php",
                            data: this.phpData
                        }, {
                            field: "userdir_backend",
                            data: this.userdirServerData
                        }, {
                            field: "userdir_php",
                            data: this.phpData
                        }].forEach(function(e) {
                            c.getForm().findField(e.field).getStore().loadData(e.data)
                        });
                    case 25:
                    case "end":
                        return e.stop()
                }
            }, e, this)
        }));
        return function(t, i, a) {
            return e.apply(this, arguments)
        }
    }(),
    onPageActivate: function() {
        this.loadForm()
    },
    onAvailableDefaultServerLoad: function(e, t) {
        var i = this.getForm().findField("backend");
        this.onAvailableServerLoad(e, t, i)
    },
    onAvailableUserdirServerLoad: function(e, t) {
        var i = this.getForm().findField("userdir_backend");
        this.onAvailableServerLoad(e, t, i)
    },
    onAvailableServerLoad: function(e, t, i) {
        for (var a = i.getValue(), n = 0; n < t.length; n++)
            if (t[n].get("backend_id") === a) return i.reset(), 0;
        if (i.disabled) {
            var o = t.length ? t[0].get("backend_id") : "";
            i.setValue(o)
        } else i.clearValue();
        i.validate()
    },
    onApiSuccess: function() {
        this.callParent(arguments), this.saveResolve && (this.saveResolve(), this.saveResolve = null)
    },
    onAvailableDefaultServerPHPLoad: function(e, t) {
        var i = this.getForm().findField("php");
        this.onAvailablePHPLoad(e, t, i)
    },
    onAvailableUserdirPHPLoad: function(e, t) {
        var i = this.getForm().findField("userdir_php");
        this.onAvailablePHPLoad(e, t, i)
    },
    onAvailablePHPLoad: function(e, t, i) {
        var a = i.getValue();
        if ("nan" === a) return i.reset(), 0;
        for (var n = 0; n < t.length; n++)
            if (t[n].get("uuid") === a) return i.reset(), 0;
        i.clearValue(), i.validate()
    },
    validatorBackend: function(e) {
        return this.validatorComboBox(e, this.serverData)
    },
    validatorPHP: function(e) {
        return this.validatorComboBox(e, this.phpData)
    },
    validatorComboBox: function(e, t) {
        if (!t) return !0;
        var i = !1;
        return t.forEach(function(t) {
            t[1] === e && (i = !0)
        }, i), !!i || _TT("SYNO.SDS.WebStation.Application", "error", "err_backend_not_found")
    },
    errorHandling: function(e) {
        this.appWin.getMsgBox().alert(this.title, SYNO.API.getErrorString(e))
    },
    onPageConfirmLostChangeSave: function() {
        var e = this;
        return new Promise(function(t, i) {
            e.saveResolve = t, e.applyHandler()
        })
    },
    cancelHandler: function() {
        this.loadForm()
    },
    getData: function() {
        return this.getForm().getValues()
    }
}), 
/**
 * @class SYNO.SDS.WebStation
 * @extends SYNO.SDS.AppInstance
 * WebStation application instance class
 *
 */
Ext.ns("SYNO.SDS.WebStation"), Ext.define("SYNO.SDS.WebStation.Application", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.WebStation.Main"
}), Ext.define("SYNO.SDS.WebStation.WelcomePage", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = {
            width: 450,
            height: 245,
            title: _TT("SYNO.SDS.WebStation.Application", "welcomepage", "title"),
            closable: !0,
            items: [{
                xtype: "syno_formpanel",
                itemId: "WebStationWelcomePage",
                items: [{
                    xtype: "syno_displayfield",
                    hideLabel: !0,
                    value: _TT("SYNO.SDS.WebStation.Application", "welcomepage", "tips")
                }, {
                    name: "noAutoLaunch",
                    xtype: "syno_checkbox",
                    checked: SYNO.SDS.UserSettings.getProperty("SYNO.SDS.WebStation.Application", "nolaunch") || !1,
                    boxLabel: _TT("SYNO.SDS.WebStation.Application", "welcomepage", "no_tip_again")
                }]
            }],
            fbar: {
                toolbarCls: "x-panel-fbar x-statusbar",
                items: [{
                    xtype: "syno_button",
                    text: _T("common", "ok"),
                    btnStyle: "blue",
                    handler: this.saveSettings,
                    scope: this
                }]
            }
        };
        return Ext.apply(t, e), t
    },
    getSettingForm: function() {
        return this.getComponent("WebStationWelcomePage")
    },
    getNoLaunchField: function() {
        return this.getSettingForm().getForm().findField("noAutoLaunch")
    },
    saveSettings: function() {
        var e = this.getNoLaunchField().getValue();
        SYNO.SDS.UserSettings.setProperty("SYNO.SDS.WebStation.Application", "nolaunch", e), this.close()
    }
}), Ext.define("SYNO.SDS.WebStation.Main", {
    extend: "SYNO.SDS.PageListAppWindow",
    activePage: "SYNO.SDS.WebStation.Overview",
    width: 990,
    minWidth: 880,
    height: 580,
    minHeight: 580,
    constructor: function(e) {
        var t;
        this.ConstructGlobalData(), this.appInstance = e.appInstance, t = Ext.apply({
            width: this.width,
            height: this.height,
            listItems: [{
                text: _TT("SYNO.SDS.WebStation.Application", "common", "status"),
                fn: "SYNO.SDS.WebStation.Overview",
                iconCls: "syno-webstation-overview"
            }, {
                text: _TT("SYNO.SDS.WebStation.Application", "title", "web_service_portal"),
                fn: "SYNO.SDS.WebStation.ServicePortalPage",
                iconCls: "syno-webstation-vhost"
            }, {
                text: _TT("SYNO.SDS.WebStation.Application", "title", "script_lang_setting"),
                fn: "SYNO.SDS.WebStation.ScriptLanguageTab",
                iconCls: "syno-webstation-php"
            }, {
                text: _TT("SYNO.SDS.WebStation.Application", "custom_error_page", "custom_error_page"),
                fn: "SYNO.SDS.WebStation.CustomErrorPage",
                iconCls: "syno-webstation-custom-error-page"
            }]
        }, e), this.callParent([t]), this.mon(this, "show", this.showWelcome, this, {
            single: !0
        }), this.mon(SYNO.SDS.StatusNotifier, "thirdpartychanged", this.onPkgChanged, this)
    },
    onPkgChanged: function(e) {
        "WebStation" !== e && SYNO.SDS.WebStation.Util.PackageInfo.Update()
    },
    showWelcome: function() {
        (this.selectPage("SYNO.SDS.WebStation.Overview"), !0 !== SYNO.SDS.UserSettings.getProperty("SYNO.SDS.WebStation.Application", "nolaunch")) && new SYNO.SDS.WebStation.WelcomePage({
            owner: this
        }).show()
    },
    ConstructGlobalData: function() {
        SYNO.SDS.WebStation.Util.CreatePackageInfo()
    },
    onClose: function() {
        SYNO.SDS.WebStation.Util.DestructPackageInfo(), this.callParent()
    }
}), Ext.define("SYNO.SDS.WebStation.Web.AliasShortcutEditor", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.module = e.module, this.owner = e.owner, this.store = e.store, this.webapi = e.webapi, this.panel = new SYNO.SDS.WebStation.Web.AliasShortcutPanel({
            module: this.module,
            owner: this
        }), this.callParent([Ext.apply({
            width: 500,
            autoHeight: !0,
            items: [this.panel],
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: function() {
                    this.close()
                }
            }, {
                text: _T("common", "save"),
                btnStyle: "blue",
                disabled: this._S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                scope: this,
                handler: this.onApply
            }]
        }, e)])
    },
    sendRequest: function() {
        var e = this.panel.getData();
        this.sendWebAPI({
            api: this.webapi.api,
            method: this.webapi.method,
            version: this.webapi.version,
            params: {
                shortcut: e
            },
            callback: function(e, t) {
                this.clearStatusBusy(), e ? (this.fireEvent("close"), this.close()) : this.onError(t.code, t.errors)
            },
            scope: this
        })
    },
    onApply: function() {
        this.panel.getForm().isValid() && (this.panel.getForm().isDirty() ? (this.setStatusBusy(), this.sendRequest()) : this.close())
    },
    onError: function(e, t) {
        var i = SYNO.SDS.WebStation.Errors.GetMessage(e);
        switch (e) {
            case 1022:
                this.module.appWin.getMsgBox().confirm("ACL Error", i, this.onForceAcl, this);
                break;
            default:
                this.setStatusError({
                    text: i
                })
        }
    },
    setData: function(e, t) {
        return this.panel.setData(e, t)
    }
}), Ext.define("SYNO.SDS.WebStation.Web.AliasShortcutPanel", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(e) {
        this.module = e.module, this.owner = e.owner;
        var t = Ext.apply({
            monitorValid: !0,
            autoFlexcroll: !0,
            height: 260,
            fieldWidth: 270,
            bodyStyle: "padding-right:0px; padding-left:0px;",
            items: [{
                xtype: "syno_displayfield",
                value: _TT("SYNO.SDS.WebStation.Application", "shortcut", "prefer_link_desc")
            }, {
                xtype: "syno_textfield",
                maxlength: 255,
                allowBlank: !1,
                indent: 1,
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "shortcut", "title"),
                name: "title"
            }, {
                xtype: "syno_displayfield",
                value: _T("app_port_alias", "protocol"),
                indent: 1
            }, {
                xtype: "syno_radiogroup",
                value: "https",
                fieldLabel: _T("app_port_alias", "protocol"),
                items: [{
                    indent: 1,
                    name: "protocol",
                    inputValue: "http",
                    boxLabel: "HTTP"
                }, {
                    indent: 1,
                    name: "protocol",
                    inputValue: "https",
                    boxLabel: "HTTPS"
                }],
                listeners: {
                    scope: this,
                    change: this.genLink
                }
            }, {
                xtype: "syno_displayfield",
                id: this.linkField = Ext.id(),
                value: _TT("SYNO.SDS.WebStation.Application", "common", "link"),
                indent: 1
            }, {
                xtype: "syno_displayfield",
                value: _TT("SYNO.SDS.WebStation.Application", "shortcut", "setting_priority_desc"),
                indent: 1
            }]
        }, e);
        this.callParent([t]), this.doLayout()
    },
    genLink: function() {
        var e, t, i = "https" === this.getForm().getValues().protocol;
        t = SYNO.SDS.WebStation.Util.genAliasLink(i, this._data.alias), e = _TT("SYNO.SDS.WebStation.Application", "common", "link") + ": ".concat(t), Ext.getCmp(this.linkField).setValue(e)
    },
    getData: function() {
        var e = this.getForm().getValues(),
            t = {};
        return t.title = Ext.util.Format.htmlEncode(e.title), t.id = this._data.shortcutId, t.portal = this._data.portalId, t.prefer_https = "https" === e.protocol, t
    },
    setData: function(e, t) {
        this._data = {}, "create" === t ? this._data = this.setDataFromPortal(e) : "update" === t && (this._data = this.setDataFromShortcut(e)), this.genLink()
    },
    setDataFromPortal: function(e) {
        return {
            shortcutId: null,
            portalId: e.id,
            alias: e.alias
        }
    },
    setDataFromShortcut: function(e) {
        var t = {
                shortcutId: e.id,
                portalId: e.portal,
                alias: e.alias
            },
            i = this.getForm(),
            a = {
                title: Ext.util.Format.htmlDecode(e.title),
                protocol: e.prefer_https ? "https" : "http"
            };
        return i.setValues(a), t
    }
}), Ext.define("SYNO.SDS.WebStation.Web.VhostShortcutEditor", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.module = e.module, this.owner = e.owner, this.store = e.store, this.webapi = e.webapi, this.panel = new SYNO.SDS.WebStation.Web.VhostShortcutPanel({
            module: this.module,
            owner: this
        }), this.callParent([Ext.apply({
            width: 500,
            autoHeight: !0,
            items: [this.panel],
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: function() {
                    this.close()
                }
            }, {
                text: _T("common", "save"),
                btnStyle: "blue",
                disabled: this._S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                scope: this,
                handler: this.onApply
            }]
        }, e)])
    },
    sendRequest: function() {
        var e = this.panel.getData();
        this.sendWebAPI({
            api: this.webapi.api,
            method: this.webapi.method,
            version: this.webapi.version,
            params: {
                shortcut: e
            },
            callback: function(e, t) {
                this.clearStatusBusy(), e ? (this.fireEvent("close"), this.close()) : this.onError(t.code, t.errors)
            },
            scope: this
        })
    },
    onApply: function() {
        this.panel.getForm().isValid() && (this.panel.getForm().isDirty() ? (this.setStatusBusy(), this.sendRequest()) : this.close())
    },
    onError: function(e, t) {
        var i = SYNO.SDS.WebStation.Errors.GetMessage(e);
        switch (e) {
            case 1022:
                this.module.appWin.getMsgBox().confirm("ACL Error", i, this.onForceAcl, this);
                break;
            default:
                this.setStatusError({
                    text: i
                })
        }
    },
    setData: function(e, t) {
        return this.panel.setData(e, t)
    }
}), Ext.define("SYNO.SDS.WebStation.Web.VhostShortcutPanel", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(e) {
        this.module = e.module, this.owner = e.owner;
        var t = Ext.apply({
            monitorValid: !0,
            autoFlexcroll: !0,
            height: 400,
            fieldWidth: 270,
            bodyStyle: "padding-right:0px; padding-left:0px;",
            items: [{
                xtype: "syno_displayfield",
                value: _TT("SYNO.SDS.WebStation.Application", "shortcut", "prefer_link_desc")
            }, {
                xtype: "syno_textfield",
                maxlength: 255,
                allowBlank: !1,
                indent: 1,
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "shortcut", "title"),
                name: "title"
            }, {
                xtype: "syno_displayfield",
                value: _T("app_port_alias", "protocol"),
                indent: 1
            }, {
                xtype: "syno_radiogroup",
                value: "https",
                fieldLabel: _T("app_port_alias", "protocol"),
                items: [{
                    indent: 1,
                    name: "protocol",
                    inputValue: "http",
                    boxLabel: "HTTP"
                }, {
                    indent: 1,
                    name: "protocol",
                    inputValue: "https",
                    boxLabel: "HTTPS"
                }],
                listeners: {
                    scope: this,
                    change: this.genLink
                }
            }, {
                xtype: "syno_displayfield",
                value: _TT("SYNO.SDS.WebStation.Application", "vhost", "port"),
                indent: 1
            }, {
                xtype: "syno_radiogroup",
                value: "standard",
                fieldLabel: _TT("SYNO.SDS.WebStation.Application", "vhost", "port"),
                items: [{
                    indent: 1,
                    name: "port",
                    inputValue: "standard",
                    boxLabel: _TT("SYNO.SDS.WebStation.Application", "shortcut", "standard_port")
                }, {
                    indent: 1,
                    name: "port",
                    inputValue: "customize",
                    boxLabel: _TT("SYNO.SDS.WebStation.Application", "shortcut", "customize_port")
                }],
                listeners: {
                    scope: this,
                    change: this.genLink
                }
            }, {
                xtype: "syno_displayfield",
                id: this.linkField = Ext.id(),
                value: _TT("SYNO.SDS.WebStation.Application", "common", "link"),
                indent: 1
            }, {
                xtype: "syno_displayfield",
                value: _TT("SYNO.SDS.WebStation.Application", "shortcut", "setting_priority_desc"),
                indent: 1
            }]
        }, e);
        this.callParent([t]), this.doLayout()
    },
    genLink: function() {
        var e, t, i = this.getForm().getValues(),
            a = "https" === i.protocol,
            n = "standard" === i.port;
        t = SYNO.SDS.WebStation.Util.genVhostLink(a, n, this._data.fqdn, this._data.http_ports, this._data.https_ports), e = _TT("SYNO.SDS.WebStation.Application", "common", "link") + ": ".concat(t), Ext.getCmp(this.linkField).setValue(e)
    },
    getData: function() {
        var e = this.getForm().getValues(),
            t = {};
        return t.title = Ext.util.Format.htmlEncode(e.title), t.id = this._data.shortcutId, t.portal = this._data.portalId, t.prefer_standard_port = "standard" === e.port, t.prefer_https = "https" === e.protocol, t
    },
    setData: function(e, t) {
        this._data = {}, "create" === t ? this._data = this.setDataFromPortal(e) : "update" === t && (this._data = this.setDataFromShortcut(e)), this.genLink()
    },
    setDataFromPortal: function(e) {
        var t = {
            shortcutId: null,
            portalId: null,
            fqdn: e.fqdn,
            http_ports: [],
            https_ports: []
        };
        return "vhost" === e.$type ? (t.http_ports = e.port.http, t.https_ports = e.port.https, t.portalId = e.UUID) : "portal" === e.$type && (t.http_ports = e.http_port, t.https_ports = e.https_port, t.portalId = e.id), t
    },
    setDataFromShortcut: function(e) {
        var t = {
                shortcutId: e.id,
                portalId: e.portal,
                fqdn: e.fqdn,
                http_ports: e.http,
                https_ports: e.https
            },
            i = this.getForm(),
            a = {
                title: Ext.util.Format.htmlDecode(e.title),
                port: e.prefer_standard_port ? "standard" : "customize",
                protocol: e.prefer_https ? "https" : "http"
            };
        return i.setValues(a), t
    }
}), Ext.define("SYNO.SDS.WebStation.Web.ShortcutManager", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        this.module = e.module, this.owner = e.owner, this.panel = new SYNO.SDS.WebStation.Web.ShortcutGridPanel({
            module: this.module,
            appWin: this,
            owner: this.owner
        }), this.callParent([Ext.apply({
            title: _TT("SYNO.SDS.WebStation.Application", "shortcut", "shortcut_manager"),
            autoHeight: !0,
            width: 700,
            layout: "fit",
            items: [this.panel]
        }, e)])
    }
}), Ext.define("SYNO.SDS.WebStation.Web.ShortcutGridPanel", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(e) {
        this.module = e.module, this.appWin = e.appWin, this.owner = e.owner, this.store = new Ext.data.GroupingStore({
            reader: new Ext.data.JsonReader({
                fields: ["id", "title", "link", "type", "system"]
            }),
            idProperty: "id",
            groupField: "system",
            appWindow: this.owner,
            autoDestroy: !0
        });
        var t = this.fillConfig(e);
        this.callParent([t])
    },
    fillConfig: function(e) {
        return Ext.apply({
            title: _TT("SYNO.SDS.WebStation.Application", "title", "vhost"),
            tbar: {
                xtype: "syno_toolbar",
                defaultType: "syno_button",
                items: this.getTBarItem()
            },
            columns: [{
                dataIndex: "system",
                hidden: !0,
                renderer: this.renderRemovable
            }, {
                dataIndex: "title",
                header: _TT("SYNO.SDS.WebStation.Application", "shortcut", "title"),
                align: "left",
                sortable: !0,
                renderer: this.renderTitle
            }, {
                dataIndex: "link",
                header: _TT("SYNO.SDS.WebStation.Application", "common", "link"),
                align: "left",
                sortable: !1,
                scope: this,
                renderer: this.renderLink
            }, {
                dataIndex: "type",
                header: _TT("SYNO.SDS.WebStation.Application", "shortcut", "portal_type"),
                align: "left",
                sortable: !0,
                renderer: this.renderType
            }],
            selModel: this.selModel = new Ext.grid.RowSelectionModel({
                singleSelect: !1,
                listeners: {
                    selectionchange: {
                        scope: this,
                        fn: this.onSelectionChange
                    }
                }
            }),
            enableHdMenu: !1,
            enableColumnMove: !1,
            enableColLock: !1,
            autoHeight: !1,
            height: 400,
            view: new SYNO.ux.GroupingView({
                showGroupName: !1,
                enableGroupingMenu: !1
            }),
            listeners: {
                scope: this,
                rowdblclick: this.onRowDblclick,
                rowcontextmenu: this.onRowContextMenu,
                afterrender: this.onAfterrender
            }
        }, e)
    },
    editHandler: function() {
        var e = this.getSelectionModel().getSelections();
        if (1 === e.length && !this.isSystemShortcut(e)) {
            var t = {},
                i = {
                    owner: this.appWin,
                    module: this,
                    title: _TT("SYNO.SDS.WebStation.Application", "shortcut", "edit_shortcut"),
                    webapi: {
                        api: "SYNO.WebStation.Shortcut",
                        method: "update",
                        version: 1
                    },
                    listeners: {
                        close: this.webapiDone,
                        scope: this
                    }
                },
                a = e[0].data.type;
            "server" === a ? t = new SYNO.SDS.WebStation.Web.VhostShortcutEditor(i) : "alias" === a && (t = new SYNO.SDS.WebStation.Web.AliasShortcutEditor(i)), t.setData(e[0].data, "update"), t.show()
        }
    },
    deleteHandler: function() {
        var e = this.getSelectionModel(),
            t = e.getSelections();
        if (t.length && !this.isSystemShortcut(t)) {
            var i = [];
            this.owner.getMsgBox().confirmDelete(_TT("SYNO.SDS.WebStation.Application", "title", "vhost"), _T("common", "remove_cfrmrmv"), function(a) {
                var n = this;
                "yes" === a && (this.busy(), 1 === t.length && e.selectNext(), Ext.each(t, function(e) {
                    i.push(e.data.id), this.store.remove(e)
                }, this), this.sendDeleteWebAPI("SYNO.WebStation.Shortcut", "remove", "ids", i).then(function() {
                    n.webapiDone()
                }).catch(function() {
                    n.webapiDone()
                }))
            }.bind(this))
        }
    },
    btnDisableHandler: function() {
        var e = this.selModel.getSelections(),
            t = e.length,
            i = this.getTBarItem(),
            a = this.getContextActionGroup();
        if (this.isSystemShortcut(e)) return i[0].disable(), i[1].disable(), a.disable("edit"), void a.disable("delete");
        0 === t ? (i[0].disable(), i[1].disable()) : 1 === t ? (i[0].enable(), i[1].enable(), a.enable("edit"), a.enable("delete")) : (i[0].disable(), i[1].enable(), a.disable("edit"), a.enable("delete"))
    },
    sendDeleteWebAPI: function(e, t, i, a) {
        var n = this;
        return new Promise(function(o, r) {
            a.length > 0 ? n.sendWebAPI({
                api: e,
                method: t,
                version: 1,
                params: _defineProperty({}, i, a),
                scope: n,
                callback: function(e, t) {
                    e && o(t), r(t)
                }
            }) : o()
        })
    },
    renderTitle: function(e) {
        return e
    },
    renderRemovable: function(e) {
        return !0 === e ? _TT("SYNO.SDS.WebStation.Application", "shortcut", "header_group_not_editable") : _TT("SYNO.SDS.WebStation.Application", "shortcut", "header_group_editable")
    },
    renderLink: function(e, t, i) {
        var a = i.data,
            n = "";
        return "server" === a.type ? n = SYNO.SDS.WebStation.Util.genVhostLink(a.prefer_https, a.prefer_standard_port, a.fqdn, a.http, a.https) : "alias" === a.type && (n = SYNO.SDS.WebStation.Util.genAliasLink(a.prefer_https, a.alias)), '<a href="{url}" target="_blank">{url}</a>'.replace(/{url}/g, n)
    },
    renderType: function(e) {
        return "alias" === e ? _T("app_port_alias", "desc_alias") : "server" === e ? _TT("SYNO.SDS.WebStation.Application", "title", "vhost") : "-"
    },
    onAfterrender: function() {
        this.btnDisableHandler(), this.loadStore()
    },
    onSelectionChange: function(e, t) {
        this.btnDisableHandler()
    },
    onRowContextMenu: function(e, t, i, a) {
        var n = new SYNO.ux.Menu({
                autoDestroy: !0,
                items: this.getContextActionGroup().getArray()
            }),
            o = this.getSelectionModel();
        o.selectRow(t, o.isSelected(t)), n.showAt(i.getXY()), i.preventDefault()
    },
    onRowDblclick: function(e, t, i, a) {
        this.editHandler()
    },
    addShortcutData: function(e) {
        var t = !0,
            i = !1,
            a = void 0;
        try {
            for (var n, o = e[Symbol.iterator](); !(t = (n = o.next()).done); t = !0) {
                var r = n.value,
                    s = Object.assign({}, r);
                this.store.add([new this.store.recordType(s)])
            }
        } catch (e) {
            i = !0, a = e
        } finally {
            try {
                t || null == o.return || o.return()
            } finally {
                if (i) throw a
            }
        }
        this.store.groupBy("system", !0)
    },
    loadStore: function() {
        this.busy(), this.loadShortcuts()
    },
    loadShortcuts: function() {
        this.sendWebAPI({
            api: "SYNO.WebStation.Shortcut",
            method: "list",
            params: {
                all: !0
            },
            version: 1,
            scope: this,
            callback: function(e, t) {
                this.unbusy(), e && (this.store.removeAll(), this.addShortcutData(t.shortcuts))
            }
        })
    },
    busy: function() {
        this.el.mask(_T("common", "loading"), "x-mask-loading")
    },
    unbusy: function() {
        this.el.unmask()
    },
    webapiDone: function() {
        this.unbusy(), this.loadStore(), SYNO.SDS.reloadJSConfig()
    },
    getTBarItem: function() {
        return this.tbarItems ? this.tbarItems : (this.tbarItems = [new Ext.Action({
            text: _T("common", "alt_edit"),
            itemId: "edit",
            scope: this,
            handler: this.editHandler
        }), new Ext.Action({
            text: _T("common", "delete"),
            itemId: "delete",
            scope: this,
            handler: this.deleteHandler
        })], this.tbarItems)
    },
    getContextActionGroup: function() {
        return this.contextMenu ? this.contextMenu : (this.contextMenu = new SYNO.ux.Utils.ActionGroup([new Ext.Action({
            text: _T("common", "alt_edit"),
            itemId: "edit",
            scope: this,
            handler: this.editHandler
        }), new Ext.Action({
            text: _T("common", "delete"),
            itemId: "delete",
            scope: this,
            handler: this.deleteHandler
        })]), this.contextMenu)
    },
    isSystemShortcut: function(e) {
        for (var t = e.length, i = 0; i < t; i++)
            if (e[i].get("system")) return !0;
        return !1
    }
});
