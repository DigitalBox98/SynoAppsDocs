/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.Drive.PackageUtils.UploadWindow
 * @extends SYNO.SDS.ModalWindow
 * SynologyDrive modal window class
 *
 */
 
Ext.define("SYNO.SDS.Drive.PackageUtils.UploadWindow", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t = {
            width: e.width || this.getWidth(),
            height: e.height || this.getHeight(),
            cls: "syno-d-package-upload-window",
            resizable: !1,
            style: "border-radius:6px",
            baseCls: "syno-d-package-window",
            useStatusBar: !1,
            items: [this.getPanel(e)]
        };
        Ext.apply(t, e || {}), this.callParent([t]), this.mon(this, "afterlayout", this.onAfterLayout, this, {
            single: !0
        })
    },
    getPanel: function(e) {
        if (this.panel) return this.panel;
        var t = {
            itemId: "iframe_panel",
            items: [{
                width: e.width || this.getWidth(),
                height: e.height || this.getHeight(),
                border: !1,
                data: {},
                tpl: this.getIFrameTemplate(e),
                listeners: {
                    scope: this,
                    afterrender: {
                        single: !0,
                        fn: function() {
                            this.loadMask = new Ext.LoadMask(this.bwrap, null, !0), this.hidden || this.loadMask.show();
                            var e = Ext.get(this.iframeId);
                            Ext.EventManager.on(e, "error", function() {
                                this.loadMask.hide(), this.el.mask(_T("error", "error_error_system"))
                            }.bind(this))
                        }
                    }
                }
            }]
        };
        return this.panel = new SYNO.ux.Panel(t), this.panel
    },
    getHeight: function() {
        var e = .8 * Ext.getBody().getViewSize().height;
        return e > 680 ? e = 680 : e < 440 && (e = 440), e
    },
    getWidth: function() {
        var e = Math.floor(.75 * Ext.getBody().getViewSize().width);
        return e > 1120 ? e = 1120 : e < 680 && (e = 680), e
    },
    getIFrameTemplate: function(e) {
        if (this.iframeTpl) return this.iframeTpl;
        this.iframeId = Ext.id();
        var t = "",
            i = _S("standaloneAppName");
        if (i && "Office" === i.split(".")[2]) {
            t = "/";
            var a = window.location.pathname.split("/");
            a.length > 3 && (t = a.slice(0, a.length - 3).join("/") + "/")
        }
        if (t += "?launchApp=SYNO.SDS.Drive.Upload.IFrameApplication", e) {
            var s;
            for (var n in e) e.hasOwnProperty(n) && -1 === ["listeners", "hidden", "width", "height"].indexOf(n) && (s || (s = {}), s[n] = e[n]);
            s && (t = Ext.urlAppend(t, Ext.urlEncode({
                launchParam: Ext.urlEncode(s)
            }), !1))
        }
        SYNO.SDS.JSDebug && (t = Ext.urlAppend(t, Ext.urlEncode({
            jsDebug: SYNO.SDS.JSDebug
        }), !1));
        return this.iframeTpl = new Ext.XTemplate(String.format('<iframe id="{0}" src="{1}" frameborder="0" style="border: 0px none; width: 100%; height: 100%;"></iframe>', this.iframeId, t)), this.iframeTpl
    },
    onAfterLayout: function() {
        this.maskEl && this.maskEl.addClass("syno-d-package-upload-window-mask"), this.onAddMessageEvent()
    },
    onAddMessageEvent: function() {
        !Ext.isIE9m && window.addEventListener && (this.recvMessageFn = this.onRecvMessageCallback.createDelegate(this), window.addEventListener("message", this.recvMessageFn))
    },
    onRecvMessageCallback: function(e) {
        var t = window.location.protocol + "//" + window.location.host;
        if (e.origin === t && Ext.isObject(e.data)) switch (e.data.action) {
            case "apply":
                this.fireEvent("apply", e.data.result), this.onRemoveMessageEvent(), this[this.closeAction]();
                break;
            case "close":
                this.onRemoveMessageEvent(), this[this.closeAction]();
                break;
            case "afterlayout":
                this.loadMask.hide()
        }
    },
    onRemoveMessageEvent: function() {
        "close" === this.closeAction && !Ext.isIE9m && window.removeEventListener && window.removeEventListener("message", this.recvMessageFn)
    }
});
