/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.Office"), Ext.ns("SYNO.SDS.SheetStation"), SYNO.SDS.Office.beforeOpen = function(e) {
    var n, t = "SYNO.SDS.Drive.Application",
        S = Ext.urlDecode(window.location.search.substr(1));
    if (!SYNO.SDS.StatusNotifier.isAppEnabled(t)) return SYNO.SDS.StatusNotifier.fireEvent("logout"), window.alert(_JSLIBSTR("uicommon", "error_noprivilege")), SYNO.SDS.Utils.Logout.action(!0), !1;
    if (!S.launchApp) return SYNO.SDS.Session.standaloneAppName = t, SYNO.SDS.AppLaunch(t, e), !1;
    S.launchApp = t;
    var o = window.location.pathname;
    return o = o.substr(1, o.lastIndexOf("/")), n = Ext.urlAppend(window.location.protocol + "//" + window.location.host + "/" + o, Ext.urlEncode(S), !1), window.location.hash && (n += window.location.hash), window.location.href = n, !1
}, SYNO.SDS.Office.Application = Ext.extend(SYNO.SDS.AppInstance, {
    skipRecord: !0,
    setUserSettings: function() {},
    beforeOpen: SYNO.SDS.Office.beforeOpen
}), SYNO.SDS.Office.PublicApplication = Ext.extend(SYNO.SDS.AppInstance, {
    skipRecord: !0,
    setUserSettings: function() {},
    beforeOpen: SYNO.SDS.Office.beforeOpen
}), SYNO.SDS.SheetStation.Application = Ext.extend(SYNO.SDS.AppInstance, {
    skipRecord: !0,
    setUserSettings: function() {},
    beforeOpen: SYNO.SDS.Office.beforeOpen
});