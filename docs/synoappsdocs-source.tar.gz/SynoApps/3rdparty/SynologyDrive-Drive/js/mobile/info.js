! function() {
    _mr.getButtonsConfig = function() {
        var t = this.getState().btns;
        if (Array.isArray(t) && !(t.length < 1)) {
            var e = this.getState(),
                r = e.file_info,
                i = encodeURIComponent(r.name),
                n = [{
                    text: t[0],
                    href: this.getAppLink()
                }];
            return "dir" !== r.type && t.length >= 2 && n.push({
                text: t[1],
                href: this.getWebAPIURL({
                    api: "SYNO.SynologyDrive.Files",
                    method: "download",
                    version: 1,
                    params: {
                        files: ["id:" + r.file_id],
                        force_download: !0
                    }
                }, "/" + i)
            }), n
        }
    }, _mr.getIconSrc = function() {
        var t = this.getIconType(this.getState().file_info);
        if (t) {
            var e = window.devicePixelRatio > 1.5 ? 256 : 128;
            return this.getImagePath() + "/_Asset/FileType/" + e + "/" + t + ".png"
        }
        return this.constructor.prototype.getIconSrc.call(this)
    }, _mr.render = function() {
        _mr.constructor.prototype.render.call(this)
    }, _mr.render()
}();