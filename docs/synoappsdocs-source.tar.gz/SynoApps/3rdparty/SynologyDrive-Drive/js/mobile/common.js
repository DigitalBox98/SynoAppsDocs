! function() {
    function t() {
        var t = document.getElementById("syno-state").getAttribute("data-state"),
            e = null;
        try {
            e = JSON.parse(t)
        } catch (t) {}
        return e
    }

    function e() {
        return /iPhone|iPad|iPod/i.test(navigator.userAgent)
    }

    function n() {
        return /Android/i.test(navigator.userAgent)
    }

    function a(t, e) {
        var n = [];
        return Object.keys(t).forEach(function(e) {
            var a = t[e];
            null !== a && void 0 !== a && n.push(e + "=" + encodeURIComponent(a))
        }), n.join(e || "&")
    }

    function o() {
        this.state = t()
    }
    document.body.addEventListener("touchstart", function() {});
    var r = {
            acc: ["acc", "accdb", "accde", "accdr", "accdt", "ade", "adn", "adp", "mam", "maf", "maq", "mar", "mat", "mda", "mdb", "mde", "mdf", "mdn", "mdt", "mdw"],
            image: ["3fr", "arw", "bmp", "cr2", "crw", "dcr", "dng", "erf", "gif", "jpe", "jpeg", "jpg", "k25", "kdc", "mef", "mos", "mrw", "nef", "orf", "pef", "png", "ptx", "raf", "raw", "rw2", "sr2", "srf", "tif", "tiff", "x3f", "ufo", "ico", "heic", "heif"],
            audio: ["aac", "ac3", "aif", "ape", "cda", "dts", "flac", "m4a", "m4b", "mid", "mka", "mp2", "mp3", "mpc", "ogg", "pcm", "ra", "wav", "wma", "mp1", "mpa", "ram", "m4p", "aiff", "dsf", "dff", "m3u", "wpl"],
            video: ["3g2", "3gp", "ac3", "amr", "asf", "avi", "dat", "divx", "dvr-ms", "ifo", "m1v", "m2t", "m2ts", "m2v", "m4v", "mkv", "mov", "mpe", "mpeg", "mpeg1", "mpeg2", "mpeg4", "mpg", "mp4", "mts", "ogv", "qt", "rm", "rmvb", "tp", "trp", "ts", "vob", "webm", "wmv", "xvid", "vdr"],
            doc: ["doc", "docx", "rtf", "wri", "odt"],
            ppt: ["ppt", "pps", "ppsx", "pptx", "odp"],
            xls: ["xls", "xla", "xlam", "xlb", "xlc", "xld", "xlk", "xll", "xlm", "xlsb", "xlsm", "xlsx", "xlt", "xltm", "xlv", "xlw", "xltx", "ods", "ots", "csv"],
            ai: ["ai"],
            psd: ["psd"],
            fla: ["fla"],
            pdf: ["pdf"],
            swf: ["swf", "f4v", "flv"],
            idn: ["idn", "indd"],
            txt: ["diff", "erl", "json", "lst", "markdown", "md", "mdown", "mkdn", "out", "patch", "sml", "txt"],
            htm: ["htm", "html"],
            code: ["actproj", "ad", "akp", "applescript", "as", "asax", "asc", "ascx", "asm", "asmx", "asp", "aspx", "asr", "as3", "bat", "bkpi", "c", "cc", "cmake", "coffee", "cpp", "cs", "css", "cxx", "erb", "groovy", "gvy", "h", "haml", "hh", "hpp", "hxx", "java", "js", "jsx", "less", "m", "make", "mhtml", "ml", "mm", "php", "pl", "plist", "properties", "py", "rb", "sass", "scala", "scm", "script", "scss", "sh", "sql", "swift", "tsx", "vb", "vi", "vim", "xhtml", "xml", "xsd", "xsl", "yaml", "yml"],
            ttf: ["ttf", "otf", "ttc"],
            iso: ["iso", "bin", "daa", "img", "mds", "nrg"],
            zip: ["zip", "7z", "bz2", "gz", "rar", "tar", "tbz", "tgz", "txz"],
            exe: ["exe"],
            folder: ["folder", "dir"],
            synodoc: ["odoc"],
            synosheet: ["osheet"],
            synoslide: ["oslides"]
        },
        i = {};
    Object.keys(r).forEach(function(t) {
        for (var e = 0; e < r[t].length; e++) i[r[t][e]] = t
    }), Object.assign(o.prototype, {
        getIconType: function(t) {
            var e = t.type;
            if (i[e]) return i[e];
            var n = t.name,
                a = n.lastIndexOf(".");
            if (a > -1) {
                var o = n.substr(a + 1).toLowerCase();
                if (i[o]) return i[o]
            }
        },
        getState: function() {
            return this.state
        },
        render: function() {
            this.getIconImg().src = this.getIconSrc(), this._renderButtons(), this._normalizeURL()
        },
        getButtonsConfig: function() {
            return {}
        },
        getIconSrc: function() {
            var t = window.devicePixelRatio > 1.5 ? 256 : 128;
            return this.getImagePath() + "/_Favicon/SynologyDrive_" + t + ".png"
        },
        getAssetPath: function() {
            return this.getImagePath() + "/_Asset/" + (window.devicePixelRatio > 1.5 ? "2x" : "1x")
        },
        getImagePath: function() {
            return "webman/3rdparty/SynologyDrive-Drive/images"
        },
        _renderButtons: function() {
            var t = this.getButtonsConfig();
            if (Array.isArray(t)) {
                for (var e = document.createDocumentFragment(), n = 0; n < t.length; n++) {
                    var a = t[n],
                        o = document.createElement("a");
                    o.className = "syno-dm-btn", o.innerHTML = a.text, a.href && (o.href = a.href), a.handler && o.addEventListener("click", a.handler, !1), e.appendChild(o)
                }
                this.getActionContainer().appendChild(e)
            }
        },
        getAppLink: function() {
            var t = this.getState(),
                o = t.permanent_link,
                r = t.host_info,
                i = r.ds_id,
                s = location.host,
                c = r.https,
                d = r.account,
                m = "#";
            "anonymous" === d && (d = void 0);
            var p = location.hostname,
                l = location.hash.substr(1);
            [".quickconnect.to", ".quickconnect.cn"].forEach(function(t) {
                p.toLowerCase().substr(-1 * t.length) === t && (s = p.match(/^([^.]+)\./)[1])
            });
            var f, u = this.GetSharingToken();
            return e() ? (f = {
                scheme: "synodrive",
                permanent_link: o,
                ds_id: i,
                host: s,
                https: c,
                account: d,
                origin_uri: location.href
            }, u && (f.sharing_token = u), l.length > 0 && (f.hash = l), m = "https://driveupdate.synology.com?" + a(f)) : n() && (f = {
                "S.permanent_link": o,
                "S.ds_id": i,
                "S.host": s,
                "B.https": c,
                "S.account": d,
                "S.origin_uri": location.href
            }, u && (f["S.sharing_token"] = u), l.length > 0 && (f["S.hash"] = l), m = "intent://open/#Intent;scheme=synodrive;package=com.synology.dsdrive;" + a(f, ";") + ";end"), m
        },
        getWebAPIURL: function(t, e) {
            e = e || "";
            var n = [];
            ["api", "method", "version"].forEach(function(e) {
                t.hasOwnProperty(e) && n.push(e + "=" + t[e])
            });
            var o = this.getState().syno_token,
                r = this.GetSharingToken(),
                i = t.params;
            if (i) {
                for (var s in i) i.hasOwnProperty(s) && (i[s] = JSON.stringify(i[s]));
                var c = a(i);
                c && n.push(c)
            }
            return o && n.push("SynoToken=" + o), r && n.push("sharing_token=" + r), "webapi/entry.cgi/" + t.api + e + "?" + n.join("&")
        },
        requestWebAPI: function(t, e) {
            var n = new XMLHttpRequest;
            n.open("get", this.getWebAPIURL(t)), n.onreadystatechange = function() {
                if (4 === n.readyState) {
                    var t = null;
                    if (200 === n.status) try {
                        t = JSON.parse(n.response)
                    } catch (t) {}
                    e(t && !0 === t.success, t)
                }
            }, n.send(null)
        },
        parseQueryString: function() {
            for (var t = [], e = location.search.substr(1).split("&"), n = 0; n < e.length; n++) {
                var a = e[n].split("=");
                a[0] && (t[a[0]] = decodeURIComponent(a[1]))
            }
            return t
        },
        logout: function(t) {
            var e = window.location.pathname,
                n = /\/d\/f\/[A-Za-z0-9]+$/,
                a = /\/d\/s\/[A-Za-z0-9]+\/([^\/]+)$/,
                o = /\/oo\/r\/[A-Za-z0-9]+$/,
                r = /\/oo\/sharing\/[A-Za-z0-9]+$/,
                i = /\/oo\/t\/[A-Za-z0-9_.]+$/;
            n.test(e) ? e = e.replace(n, "") : a.test(e) ? e = e.replace(a, "") : o.test(e) ? e = e.replace(o, "") : r.test(e) ? e = e.replace(r, "") : i.test(e) && (e = e.replace(i, ""));
            var s = t ? "SYNO.SDS.Office.BasicInstance" : "SYNO.SDS.Drive.BasicInstance",
                c = e + "/?launchApp=" + s + "&launchParam=link%3D" + this.getState().permanent_link,
                d = e + "/webman/logout.cgi",
                m = new XMLHttpRequest;
            m.open("get", d), m.onreadystatechange = function() {
                4 === m.readyState && (window.location.href === c ? window.location.reload() : window.location.href = c)
            }, m.send(null)
        },
        GetSharingToken: function() {
            var t = this.getState().sharing_link;
            return t ? this.getCookie("drive-sharing-" + t) : ""
        },
        getCookie: function(t) {
            for (var e = t + "=", n = decodeURIComponent(document.cookie), a = n.split(";"), o = 0; o < a.length; o++) {
                for (var r = a[o];
                    " " == r.charAt(0);) r = r.substring(1);
                if (0 == r.indexOf(e)) return r.substring(e.length, r.length)
            }
            return ""
        },
        isOffice: function() {
            return "office" === this.parseQueryString().type
        },
        _normalizeURL: function() {
            if ("office" === this.parseQueryString().type) {
                var t = location.pathname + location.hash;
                history.replaceState("", document.title, t.replace("/d/f/", "/oo/r/"))
            }
        },
        getIconImg: function() {
            return document.querySelector(".syno-dm-icon>img")
        },
        getTitleElement: function() {
            return document.querySelector(".syno-dm-title")
        },
        getDescElement: function() {
            return document.querySelector(".syno-dm-desc")
        },
        getActionContainer: function() {
            return document.querySelector(".syno-dm-action")
        }
    }), window._mr = new o
}();