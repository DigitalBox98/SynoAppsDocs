/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function _classCallCheck2(t, e) {
    if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
}

function _defineProperties(t, e) {
    for (var i = 0; i < e.length; i++) {
        var s = e[i];
        s.enumerable = s.enumerable || !1, s.configurable = !0, "value" in s && (s.writable = !0), Object.defineProperty(t, s.key, s)
    }
}

function _createClass2(t, e, i) {
    return e && _defineProperties(t.prototype, e), i && _defineProperties(t, i), t
}

function _typeof(t) {
    return (_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
        return typeof t
    } : function(t) {
        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
    })(t)
}

function getModalWindow(t) {
    if (t) {
        if ("ModalWindow" === t.$options.name || "MessageBoxWindow" === t.$options.name || "WizardWindow" === t.$options.name) return t;
        for (var e = 0; e < t.$children.length; e++) {
            var i = getModalWindow(t.$children[e]);
            if (i) return i
        }
    }
}
var _S, _TT;
Ext.namespace("SYNO"), SYNO.Debug = function() {
    var t = Ext.urlDecode(location.search.substr(1)).jsDebug,
        e = window.console && window.console.log && !0,
        i = window.console || Ext.emptyFn,
        s = function(s) {
            var n = "error".split(",");
            s = s.split(",");
            var o = {};
            return Ext.each(s, function(s) {
                o[s] = function(s) {
                    return (t || -1 !== n.indexOf(s)) && e ? (Ext.isFunction(window.console[s]) ? window.console[s] : Ext.emptyFn).createDelegate(i) : Ext.emptyFn
                }(s)
            }), o
        }("debug,trace,log,info,warn,error,group,groupEnd,profile,profileEnd,table,time,timeEnd,timeStamp"),
        n = s.log;
    return Ext.apply(n, s), n
}(), SYNO.Assert = function(t, e) {
    if (!t) throw e
}, SYNO.SDS.UIFeatures = function() {
    var t, e = {
            previewBox: !Ext.isIE || Ext.isModernIE,
            expandMenuHideAll: !0,
            windowGhost: !Ext.isIE || Ext.isModernIE,
            disableWindowShadow: Ext.isIE && !Ext.isModernIE,
            exposeWindow: !Ext.isIE || Ext.isIE10p,
            msPointerEnabled: window.navigator.msPointerEnabled && window.navigator.msMaxTouchPoints > 0,
            isTouch: "ontouchstart" in window || window.navigator.msPointerEnabled && window.navigator.msMaxTouchPoints > 0,
            isRetina: (t = !1, window.devicePixelRatio >= 1.5 && (t = !0), window.matchMedia && window.matchMedia("(-webkit-min-device-pixel-ratio: 1.5),(min--moz-device-pixel-ratio: 1.5),(-o-min-device-pixel-ratio: 3/2),(min-resolution: 1.5dppx)").matches && (t = !0), t),
            isSupportFullScreen: document.fullscreenEnabled || document.webkitFullscreenEnabled || document.mozFullScreenEnabled || document.msFullscreenEnabled
        },
        i = Ext.urlDecode(location.search.substr(1));
    return Ext.iterate(i, function(t) {
        var s = i[t];
        Ext.isDefined(e[t]) && (e[t] = "false" !== s)
    }), {
        test: function(t) {
            return !!e[t]
        },
        listAll: function() {
            Ext.iterate(e, function(t) {
                String.format("{0}: {1}\n", t, e[t])
            })
        },
        isFullScreenMode: function() {
            return !!(document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement || document.msFullscreenElement)
        }
    }
}(), Ext.define("SYNO.SDS.UIFeatures.IconSizeManager", {
    statics: {
        PortalIcon: 64,
        GroupView: 24,
        Taskbar: 32,
        GroupViewHover: 48,
        Desktop: 64,
        ClassicalDesktop: 48,
        AppView: 72,
        AppViewClassic: 48,
        Header: 24,
        HeaderV4: 16,
        TreeIcon: 16,
        StandaloneHeader: 24,
        FavHeader: 16,
        FinderPreview: 128,
        isEnableHDPack: !1,
        cls: "synohdpack",
        debugCls: "synohdpackdebug",
        getAppPortalIconPath: function(t) {
            var e = this.getRetinaAndSynohdpackStatus(),
                i = e ? 256 : this.PortalIcon,
                s = e ? "2x" : "1x";
            return String.format(t, i, s)
        },
        getIconPath: function(t, e, i) {
            var s, n, o = this.getRetinaAndSynohdpackStatus(),
                r = function(t, e, i, s) {
                    return t.replace(e, "48" === e ? "128" : 2 * e)
                },
                a = function(t, e, i, s) {
                    return t.replace(e, "48" === e ? "128" : 2 * e)
                };
            if (0 === t.indexOf("webman/3rdparty/")) return String.format("webapi/entry.cgi?api=SYNO.Core.Synohdpack&version=1&method=getHDIcon&res={0}&retina={1}&path={2}", this.getRes(e), o, t);
            switch (n = -1 === t.indexOf("{1}") ? o ? (i = i || !1) || -1 !== t.indexOf("shortcut_icons") || -1 !== t.indexOf("webfm/images") ? t : 0 === t.indexOf("webman/") ? "/synohdpack/images/dsm/" + t.substr("webman/".length) : "/synohdpack/images/dsm/" + t : t : t.replace("{1}", o ? "2x" : "1x"), e) {
                case "Taskbar":
                    s = String.format(n, o ? 2 * this.Taskbar : this.Taskbar);
                    break;
                case "Desktop":
                    -1 != n.indexOf("files_ext_48") && "classical" != SYNO.SDS.UserSettings.getProperty("Desktop", "desktopStyle") && (n = n.replace("files_ext_48", "files_ext_64")), -1 != n.indexOf("files_ext_") ? (n = n.replace(/webfm\/images/, o ? "images/2x" : "images/1x"), s = o ? n.replace(/.*\/files_ext_(\d+)\/.*/, r) : n) : -1 != n.indexOf("shortcut_icons") ? (n = n.replace(/images\/shortcut_icons/, o ? "images/default/2x/shortcut_icons" : "images/default/1x/shortcut_icons"), s = o ? n.replace(/.*\/.*_(\d+)\.png$/, a) : n) : s = String.format(n, o ? 256 : this.Desktop);
                    break;
                case "ClassicalDesktop":
                    -1 != n.indexOf("files_ext_") ? (n = n.replace(/webfm\/images/, o ? "images/2x" : "images/1x"), s = o ? n.replace(/.*\/files_ext_(\d+)\/.*/, r) : n) : -1 != n.indexOf("shortcut_icons") ? (n = n.replace(/images\/shortcut_icons/, o ? "images/default/2x/shortcut_icons" : "images/default/1x/shortcut_icons"), s = o ? n.replace(/.*\/.*_(\d+)\.png$/, a) : n) : s = String.format(n, o ? 256 : this.ClassicalDesktop);
                    break;
                case "AppView":
                    s = String.format(n, o ? 256 : this.AppView);
                    break;
                case "AppViewClassic":
                    s = String.format(n, o ? 256 : this.AppViewClassic);
                    break;
                case "Header":
                    s = String.format(n, o ? 2 * this.Header : this.Header);
                    break;
                case "HeaderV4":
                    s = String.format(n, o ? 2 * this.HeaderV4 : this.HeaderV4);
                    break;
                case "StandaloneHeader":
                    s = String.format(n, o ? 2 * this.StandaloneHeader : this.StandaloneHeader);
                    break;
                case "FavHeader":
                    s = String.format(n, o ? 2 * this.FavHeader : this.FavHeader);
                    break;
                case "FileType":
                    s = o ? n.replace(/.*\/files_ext_(\d+)\/.*/, r) : n;
                    break;
                case "TreeIcon":
                    s = String.format(n, o ? 3 * this.TreeIcon : this.TreeIcon);
                    break;
                case "FinderPreview":
                    s = String.format(n, o ? 256 : 128);
                    break;
                default:
                    s = n
            }
            return -1 == s.indexOf(String.format("?v={0}", _S("fullversion"))) && ".png" === s.substr(s.length - 4) && (s += "?v=" + _S("fullversion")), s = encodeURI(s)
        },
        enableHDDisplay: function(t) {
            SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = t
        },
        getRetinaAndSynohdpackStatus: function() {
            return SYNO.SDS.UIFeatures.test("isRetina") && (this.isEnableHDPack || SYNO.SDS.Session.SynohdpackStatus || !1)
        },
        addHDClsAndCSS: function(t) {
            t && SYNO.SDS.UIFeatures.test("isRetina") && Ext.get(document.documentElement).addClass(this.cls)
        },
        enableRetinaDisplay: function() {
            Ext.get(document.documentElement).removeClass(this.debugCls), Ext.get(document.documentElement).addClass(this.cls), SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = !0
        },
        enableRetinaDebugMode: function() {
            Ext.get(document.documentElement).removeClass(this.cls), Ext.get(document.documentElement).addClass(this.debugCls), SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = !0
        },
        disableRetinaDisplay: function() {
            Ext.get(document.documentElement).removeClass(this.cls), Ext.get(document.documentElement).removeClass(this.debugCls), SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = !1
        },
        getRes: function(t) {
            switch (t) {
                case "Taskbar":
                    return this.Taskbar;
                case "Desktop":
                    return this.Desktop;
                case "ClassicalDesktop":
                    return this.ClassicalDesktop;
                case "AppView":
                    return "classical" === SYNO.SDS.UserSettings.getProperty("Desktop", "appMenuStyle") ? this.AppViewClassic : this.AppView;
                case "AppViewClassic":
                    return this.AppViewClassic;
                case "Header":
                    return this.Header;
                case "HeaderV4":
                    return this.HeaderV4;
                case "StandaloneHeader":
                    return this.StandaloneHeader;
                case "FileType":
                    return this.FileType;
                case "PortalIcon":
                    return this.PortalIcon;
                case "TreeIcon":
                    return this.TreeIcon;
                case "FavHeader":
                    return this.FavHeader;
                case "FinderPreview":
                    return this.FinderPreview;
                default:
                    return -1
            }
        }
    }
}), Ext.namespace("SYNO.SDS._StatusNotifier"), Ext.define("SYNO.SDS._StatusNotifier", {
    extend: "Ext.util.Observable",
    constructor: function() {
        this.addEvents("beforeunload"), this.callParent(arguments)
    },
    isAppEnabled: function(t) {
        return !0 === this.isSupportedApp(t) && (!!SYNO.SDS.StatusNotifier.isAppHasPrivilege(t) && (!!SYNO.SDS.StatusNotifier.isServiceEnabled(t) && !(SYNO.SDS.Packages.isPackage(t) && !SYNO.SDS.Packages.isEnable(t))))
    },
    isSupportedApp: function(t) {
        var e, i, s, n = SYNO.SDS.Config.FnMap[t],
            o = !0;
        return !(!n || !Ext.isDefined(n.config)) && ("app" === (e = n.config).type && Ext.isDefined(e.supportKey) ? !(this.isRunningRecoverySite() && !e.supportSdrRecoverySite) && (i = Ext.isArray(e.supportKey) ? e.supportKey : [e.supportKey], Ext.each(i, function(t) {
            s = Ext.isDefined(t.value) ? _D(t.key) === t.value : !Ext.isEmpty(_D(t.key)), o = Ext.isDefined(t.cond) && "or" === t.cond ? o || s : o && s
        }, this), o) : !(("app" === e.type || "url" === e.type || "standalone" === e.type || "legacy" === e.type) && this.isRunningRecoverySite() && !e.supportSdrRecoverySite))
    },
    isRunningRecoverySite: function(t) {
        return _S("systemdr_running") && ("recovery_site" === _S("systemdr_role") || SYNO.SDS.Utils.isInC2DSM())
    },
    isAppHasPrivilege: function(t) {
        var e, i = SYNO.SDS.Config.FnMap[t];
        return (!Ext.isDefined(SYNO.SDS.AppPrivilege[t]) || !0 === SYNO.SDS.AppPrivilege[t]) && (!!i && (!(!i.config.publicAccess || !this.isPublicAccess()) || (i.config.grantAppPrivilege ? SYNO.SDS.AppPrivilege["SYNO.ALLOW.ALL.APPLICATIONS"] || SYNO.SDS.AppPrivilege[i.config.grantAppPrivilege] : "all" === (e = i.config.grantPrivilege) || "false" === _S("domainUser") && "local" === e || "true" === _S("domainUser") && "domain" === e ? SYNO.SDS.AppPrivilege["SYNO.ALLOW.ALL.APPLICATIONS"] || SYNO.SDS.AppPrivilege[t] : (!0 === _S("is_admin") || !0 === i.config.allUsers) && !("local" === e && "true" === _S("domainUser") || "domain" === e && "false" === _S("domainUser")))))
    },
    isPublicAccess: function() {
        return !_S("isLogined")
    },
    isServiceEnabled: function(t) {
        return !Ext.isDefined(SYNO.SDS.ServiceStatus[t]) || !0 === SYNO.SDS.ServiceStatus[t]
    },
    setServiceDisabled: function(t, e, i) {
        !e != !!SYNO.SDS.ServiceStatus[t] && (SYNO.SDS.ServiceStatus[t] = !e, this.fireEvent("servicechanged", t, !e, i))
    },
    checkServiceBlocked: function(t) {
        this.fireEvent("checkserviceblocked", t, "checkserviceblocked")
    },
    setAppPrivilege: function(t, e) {
        !!e != !!SYNO.SDS.AppPrivilege[t] && (SYNO.SDS.AppPrivilege[t] = !!e, this.fireEvent("appprivilegechanged", t, !!e))
    }
}), SYNO.SDS.DateTimeUtils = function() {
    var t = ["Y-m-d", "Y/m/d", "Y.m.d", "d-m-Y", "d/m/Y", "d.m.Y", "m-d-Y", "m/d/Y", "m.d.Y"],
        e = ["YYYY-MM-dd", "YYYY/MM/dd", "YYYY.MM.dd", "dd-MM-YYYY", "dd/MM/YYYY", "dd.MM.YYYY", "MM-dd-YYYY", "MM/dd/YYYY", "MM.dd.YYYY"],
        i = ["h:i", "H:i"],
        s = [_T("common", "pref_time_format_12") || "12-hour", _T("common", "pref_time_format_24") || "24-hour"],
        n = [" a", ""],
        o = [0, 1].map(function(t) {
            return i[t] + n[t]
        }),
        r = t[0],
        a = o[1],
        l = {
            chs: t[0],
            cht: t[0],
            csy: t[4],
            dan: t[4],
            enu: t[7],
            fre: t[4],
            ger: t[5],
            hun: t[0],
            ita: t[4],
            jpn: t[0],
            krn: t[0],
            nld: t[3],
            nor: t[5],
            plk: t[5],
            ptb: t[4],
            ptg: t[4],
            rus: t[5],
            spn: t[4],
            sve: t[0],
            tha: t[4],
            trk: t[5]
        };
    return {
        SupportedDateFormats: t,
        SupportedTimeFormats: o,
        GetDateFormatByLang: function(t) {
            return l[t] || r
        },
        GetTimeFormatByLang: function(t) {
            return a
        },
        GetSystemDateFormat: function() {
            return _S("date_format") || r
        },
        GetSystemTimeFormat: function() {
            return _S("time_format") || a
        },
        CreateDateFormatArray: function(t) {
            var i = SYNO.SDS.DateTimeUtils.SupportedDateFormats.map(function(t, i) {
                    return [t, e[i]]
                }),
                s = SYNO.SDS.DateTimeUtils.GetSystemDateFormat();
            return t && Ext.each(i, function(t) {
                t[0] === s && (t[1] = t[1] + " (" + _T("common", "sys_default_setting") + ")")
            }), i
        },
        CreateDateFormatJsonOptions: function(t) {
            return SYNO.SDS.DateTimeUtils.CreateDateFormatArray(t).map(function(t) {
                return {
                    value: t[0],
                    display: t[1]
                }
            })
        },
        CreateDateFormatStore: function(t) {
            var e = SYNO.SDS.DateTimeUtils.CreateDateFormatArray(t);
            return new Ext.data.ArrayStore({
                fields: ["value", "display"],
                autoDestroy: !0,
                data: e
            })
        },
        CreateTimeFormatArray: function(t) {
            var e = SYNO.SDS.DateTimeUtils.SupportedTimeFormats.map(function(t, e) {
                    return [t, s[e]]
                }),
                i = SYNO.SDS.DateTimeUtils.GetSystemTimeFormat();
            return t && Ext.each(e, function(t) {
                t[0] === i && (t[1] = t[1] + " (" + _T("common", "sys_default_setting") + ")")
            }), e
        },
        CreateTimeFormatJsonOptions: function(t) {
            return SYNO.SDS.DateTimeUtils.CreateTimeFormatArray(t).map(function(t) {
                return {
                    value: t[0],
                    display: t[1]
                }
            })
        },
        CreateTimeFormatStore: function(t) {
            var e = SYNO.SDS.DateTimeUtils.CreateTimeFormatArray(t);
            return new Ext.data.ArrayStore({
                fields: ["value", "display"],
                autoDestroy: !0,
                data: e
            })
        },
        SetUserFormat: function(t, e) {
            "string" == typeof e && ("date" === t ? SYNO.SDS.UserSettings.setProperty("Personal", "dateFormat", e) : "time" === t && SYNO.SDS.UserSettings.setProperty("Personal", "timeFormat", e))
        },
        RemoveUserFormat: function(t) {
            "date" === t ? SYNO.SDS.UserSettings.removeProperty("Personal", "dateFormat") : "time" === t && SYNO.SDS.UserSettings.removeProperty("Personal", "timeFormat")
        },
        GetYearMonthFormat: function() {
            return {
                "Y-m-d": "Y-m",
                "Y/m/d": "Y/m",
                "Y.m.d": "Y.m",
                "d-m-Y": "m-Y",
                "d/m/Y": "m/Y",
                "d.m.Y": "m.Y",
                "m-d-Y": "m-Y",
                "m/d/Y": "m/Y",
                "m.d.Y": "m.Y"
            } [SYNO.SDS.DateTimeUtils.GetDateFormat()]
        },
        GetMonthDateFormat: function() {
            return {
                "Y-m-d": "m-d",
                "Y/m/d": "m/d",
                "Y.m.d": "m.d",
                "d-m-Y": "d-m",
                "d/m/Y": "d/m",
                "d.m.Y": "d.m",
                "m-d-Y": "m-d",
                "m/d/Y": "m/d",
                "m.d.Y": "m.d"
            } [SYNO.SDS.DateTimeUtils.GetDateFormat()]
        },
        GetDateRawFormat: function() {
            return SYNO.SDS.UserSettings.getProperty("Personal", "dateFormat") || "system"
        },
        GetTimeRawFormat: function() {
            return SYNO.SDS.UserSettings.getProperty("Personal", "timeFormat") || "system"
        },
        GetDateFormat: function() {
            var t = SYNO.SDS.UserSettings.getProperty("Personal", "dateFormat");
            return t = "system" === t ? SYNO.SDS.DateTimeUtils.GetSystemDateFormat() : t || SYNO.SDS.DateTimeUtils.GetSystemDateFormat()
        },
        GetTimeFormat: function() {
            var t = SYNO.SDS.UserSettings.getProperty("Personal", "timeFormat");
            return t = "system" === t ? SYNO.SDS.DateTimeUtils.GetSystemTimeFormat() : t || SYNO.SDS.DateTimeUtils.GetSystemTimeFormat()
        },
        GetTimePrefix: function() {
            return SYNO.SDS.DateTimeUtils.GetTimeFormat().indexOf(i[1]) > -1 ? i[1] : i[0]
        },
        GetTimePostfix: function() {
            return SYNO.SDS.DateTimeUtils.GetTimeFormat().indexOf(i[1]) > -1 ? n[1] : n[0]
        },
        GetDateTimeFormat: function() {
            return SYNO.SDS.DateTimeUtils.GetDateFormat() + " " + SYNO.SDS.DateTimeUtils.GetTimeFormat()
        },
        GetDateTimeSecFormat: function() {
            var t = SYNO.SDS.DateTimeUtils;
            return t.GetDateFormat() + " " + t.GetTimePrefix() + ":s" + t.GetTimePostfix()
        },
        GetTimeSecFormat: function() {
            var t = SYNO.SDS.DateTimeUtils;
            return t.GetTimePrefix() + ":s" + t.GetTimePostfix()
        },
        GetDateTimeSecMsFormat: function() {
            var t = SYNO.SDS.DateTimeUtils,
                e = t.GetTimePrefix(),
                i = t.GetTimePostfix();
            return t.GetDateFormat() + " " + e + ":s.u" + i
        },
        GetTimeSecMsFormat: function() {
            var t = SYNO.SDS.DateTimeUtils;
            return t.GetTimePrefix() + ":s.u" + t.GetTimePostfix()
        }
    }
}(), SYNO.SDS.DateTimeFormatter = function(t, e) {
    if (!t || "[object Date]" !== Object.prototype.toString.call(t)) return "";
    var i, s = e && e.type,
        n = SYNO.SDS.DateTimeUtils;
    return i = "date" === s ? n.GetDateFormat() : "yearmonth" === s ? n.GetYearMonthFormat() : "monthdate" === s ? n.GetMonthDateFormat() : "time" === s ? n.GetTimeFormat() : "timesec" === s ? n.GetTimeSecFormat() : "datetimesec" === s ? n.GetDateTimeSecFormat() : "datetimesecms" === s ? n.GetDateTimeSecMsFormat() : n.GetDateTimeFormat(), t.format(i)
}, Ext.namespace("SYNO.SDS._UserSettings"), SYNO.SDS._UserSettings = Ext.extend(Ext.Component, {
    data: null,
    ajaxTask: null,
    delayedTask: null,
    modified: null,
    webapi: {
        get: {
            api: "SYNO.Core.UserSettings",
            method: "get",
            version: 1
        },
        apply: {
            api: "SYNO.Core.UserSettings",
            method: "apply",
            version: 1
        }
    },
    constructor: function() {
        SYNO.SDS._UserSettings.superclass.constructor.apply(this, arguments), this.data = SYNO.SDS.initUserSettings || {}, this.delayedTask = new Ext.util.DelayedTask(this.save, this), SYNO.SDS.StatusNotifier && (this.mon(SYNO.SDS.StatusNotifier, "logout", this.syncSave, this), this.mon(SYNO.SDS.StatusNotifier, "halt", this.saveAndUnload, this), this.mon(SYNO.SDS.StatusNotifier, "redirect", this.saveAndUnload, this)), this.registerUnloadEvent()
    },
    getUnloadEventName: function() {
        var t = "onpagehide" in window;
        return "onbeforeunload" in window ? "beforeunload" : t ? "pagehide" : null
    },
    registerUnloadEvent: function() {
        var t = this.getUnloadEventName();
        t && Ext.EventManager.on(window, t, this.syncSave, this)
    },
    unregisterNotifierEvent: function() {
        SYNO.SDS.StatusNotifier && (this.mun(SYNO.SDS.StatusNotifier, "logout", this.syncSave, this), this.mun(SYNO.SDS.StatusNotifier, "halt", this.saveAndUnload, this), this.mun(SYNO.SDS.StatusNotifier, "redirect", this.saveAndUnload, this))
    },
    unregisterUnloadEvent: function() {
        var t = this.getUnloadEventName();
        t && Ext.EventManager.un(window, t, this.syncSave, this)
    },
    saveAndUnload: function() {
        this.syncSave(), this.unregisterUnloadEvent()
    },
    setLocalStorageByUser: function(t, e) {
        var i = this.getLocalStorageByUser(t) || {};
        i.key = e, localStorage.setItem(_S("user"), Ext.encode(i))
    },
    getLocalStorageByUser: function(t) {
        var e = Ext.decode(localStorage.getItem(_S("user")));
        return e ? e.key : null
    },
    setLocalStorage: function(t, e) {
        localStorage && localStorage.setItem(t, Ext.encode(e))
    },
    getLocalStorage: function(t) {
        return localStorage ? Ext.decode(localStorage.getItem(t)) : null
    },
    removeLocalStorage: function(t) {
        localStorage && localStorage.removeItem(t)
    },
    setLocalStorageRestoreParams: function() {
        if (this.modified.Desktop && this.modified.Desktop.restoreParams) {
            var t = {
                userName: _S("user"),
                restoreParams: this.modified.Desktop.restoreParams
            };
            this.setLocalStorage("restoreParams", t)
        }
    },
    getLocalStorageRestoreParams: function() {
        var t = this.getLocalStorage("restoreParams");
        return t && t.userName && t.userName === _S("user") ? t.restoreParams : null
    },
    removeLocalStorageRestoreParams: function() {
        var t = this.getLocalStorage("restoreParams");
        t && t.userName && t.userName === _S("user") && this.removeLocalStorage("restoreParams")
    },
    syncSave: function(t) {
        SYNO.Debug.warn("synchronous XMLHttpRequest on the main thread is deprecated, will called by asynchronous"), SYNO.SDS.StatusNotifier && SYNO.SDS.StatusNotifier.fireEvent("beforeUserSettingsUnload"), this.modified && !_S("demo_mode") && _S("isLogined") && (this.ajaxTask && this.ajaxTask.remove(), this.setLocalStorageRestoreParams(), this.sendWebAPI(Ext.apply({
            timeout: 10,
            params: {
                data: Ext.encode(this.modified)
            },
            callback: this.onSaveSuccess.createDelegate(this, [t])
        }, this.webapi.apply)))
    },
    load: function() {
        this.addWebAPITask(Ext.apply({
            single: !0,
            callback: this.onLoadSuccess.createDelegate(this)
        }, this.webapi.get)).start()
    },
    save: function() {
        this.modified && !_S("demo_mode") && _S("isLogined") && (this.ajaxTask && this.ajaxTask.remove(), this.ajaxTask = this.addWebAPITask(Ext.apply({
            single: !0,
            params: {
                data: Ext.encode(this.modified)
            },
            callback: this.onSaveSuccess.createDelegate(this)
        }, this.webapi.apply)).start())
    },
    onLoadSuccess: function(t, e, i, s) {
        t && (this.data = e)
    },
    onSaveSuccess: function(t) {
        var e;
        if (this.modified = null, Ext.isObject(t)) {
            e = t.scope || this;
            var i = t.callback;
            Ext.isFunction(i) && i.call(e)
        }
    },
    getProperty: function(t, e) {
        try {
            return this.data[t][e]
        } catch (t) {
            return null
        }
    },
    setProperty: function(t, e, i) {
        if (this.modified = this.modified || {}, null == i) return this.removeProperty(t, e);
        Ext.isObject(this.data[t]) || (this.data[t] = {}), this.data[t][e] = i, this.modified[t] = this.data[t], this.delayedTask.delay(50)
    },
    removeProperty: function(t, e) {
        this.data[t] && (this.modified = this.modified || {}, this.modified[t] = this.data[t], delete this.data[t][e], this.delayedTask.delay(50))
    }
}), SYNO.SDS.UserSettingsProvider = Ext.extend(Ext.state.Provider, {
    constructor: function() {
        SYNO.SDS.UserSettingsProvider.superclass.constructor.apply(this, arguments)
    },
    set: function(t, e) {
        null != e ? (SYNO.SDS.UserSettingsProvider.superclass.set.call(this, t, e), SYNO.SDS.UserSettings.setProperty("desktop", "stateProvider", this.state)) : this.clear(t)
    },
    clear: function(t) {
        SYNO.SDS.UserSettingsProvider.superclass.clear.call(this, t), SYNO.SDS.UserSettings.setProperty("desktop", "stateProvider", this.state)
    }
}), Ext.namespace("SYNO.SDS.TaskRunner"), SYNO.SDS._TaskMgr = function(t) {
    var e = t || 10,
        i = [],
        s = [],
        n = 0,
        o = !1,
        r = !1,
        a = function(t, e) {
            for (var i; 0 !== e;) i = t % e, t = e, e = i;
            return t
        },
        l = function() {
            var s = function() {
                var e, s, n = i[0].interval;
                for (e = 1; s = i[e]; e++) n = a(n, s.interval);
                return Math.max(n, t)
            }();
            return s !== e && (e = s, !0)
        },
        c = function() {
            o = !1, clearTimeout(n), n = 0
        },
        d = function(t) {
            s.push(t), t.onStop && t.onStop.apply(t.scope || t)
        },
        u = function t() {
            var o, a, u, h, p, S = !1,
                f = (new Date).getTime();
            for (o = 0; a = s[o]; o++) i.remove(a), S = !0;
            if (s = [], i.length) {
                for (o = 0; a = i[o]; ++o)
                    if (a = i[o], r && !0 !== a.preventHalt) d(a);
                    else {
                        if (h = f - a.taskRunTime, a.interval <= h) {
                            try {
                                p = a.run.apply(a.scope || a, a.args || [++a.taskRunCount])
                            } catch (t) {
                                if (!Ext.isIE && (SYNO.Debug.error("TaskRunner: task " + a.id + " exception: ", t), Ext.isDefined(SYNO.SDS.JSDebug))) throw a.taskRunTime = f, t
                            }
                            if (a.taskRunTime = f, u = a.interval, a.interval = a.adaptiveInterval(), u !== a.interval && (S = !0), !1 === p || a.taskRunCount === a.repeat) return void d(a)
                        }
                        a.duration && a.duration <= f - a.taskStartTime && d(a)
                    } S && l(), n = setTimeout(t, e)
            } else c()
        };
    this.start = function(t, e) {
        var s = (new Date).getTime();
        return i.push(t), t.taskStartTime = s, t.taskRunTime = !1 === e ? s : 0, t.taskRunCount = 0, o ? (l(), clearTimeout(n), setImmediate(u)) : o || (o = !0, l(), setImmediate(u)), t
    }, this.stop = function(t) {
        return d(t), t
    }, this.stopAll = function() {
        var t, e;
        for (c(), t = 0; e = i[t]; t++) e.onStop && e.onStop();
        i = [], s = []
    }, this.setHalt = function(t) {
        r = t
    }
}, SYNO.SDS.TaskMgr = new SYNO.SDS._TaskMgr(100), SYNO.SDS.TaskRunner = Ext.extend(Ext.util.Observable, {
    tasks: null,
    constructor: function() {
        SYNO.SDS.TaskRunner.superclass.constructor.apply(this, arguments), this.addEvents("add", "remove", "beforestart"), this.tasks = {}
    },
    destroy: function() {
        this.stopAll(), this.tasks = {}, this.isDestroyed = !0
    },
    start: function(t, e) {
        if (!this.isDestroyed) return t.running || (this.fireEvent("beforestart", t), SYNO.SDS.TaskMgr.start(t, e)), t.running = !0, t
    },
    stop: function(t) {
        return t.running && SYNO.SDS.TaskMgr.stop(t), t.running = !1, t
    },
    stopAll: function() {
        for (var t in this.tasks)
            if (this.tasks.hasOwnProperty(t)) {
                if (!this.tasks[t].running) continue;
                SYNO.SDS.TaskMgr.stop(this.tasks[t])
            }
    },
    addTask: function(t) {
        return t.id = t.id || Ext.id(), this.tasks[t.id] = t, this.fireEvent("add", t), t
    },
    createTask: function(t) {
        t.id = t.id || Ext.id();
        var e = this.tasks[t.id];
        return e ? e.apply(t) : (e = new SYNO.SDS.TaskRunner.Task(t, this), this.addTask(e)), e
    },
    createAjaxTask: function(t) {
        t.id = t.id || Ext.id();
        var e = this.tasks[t.id];
        return e ? e.apply(t) : (e = new SYNO.SDS.TaskRunner.AjaxTask(t, this), this.addTask(e)), e
    },
    createWebAPITask: function(t) {
        t.id = t.id || Ext.id();
        var e = this.tasks[t.id];
        return e ? e.apply(t) : (e = new SYNO.SDS.TaskRunner.WebAPITask(t, this), this.addTask(e)), e
    },
    removeTask: function(t) {
        var e = this.tasks[t];
        e && (this.fireEvent("remove", e), delete this.tasks[t])
    },
    getTask: function(t) {
        return this.tasks[t] || null
    }
}), SYNO.SDS.TaskRunner.Task = Ext.extend(Ext.util.Observable, {
    INTERVAL_DEFAULT: 6e4,
    INTERVAL_FALLBACK: 6e4,
    manager: null,
    running: !1,
    removed: !1,
    taskFirstRunTime: 0,
    constructor: function(t, e) {
        SYNO.SDS.TaskRunner.Task.superclass.constructor.apply(this, arguments), this.manager = e, this.apply(t)
    },
    apply: function(t) {
        this.applyInterval(t.interval), delete t.interval, this.applyConfig(t)
    },
    applyConfig: function(t) {
        Ext.apply(this, t)
    },
    applyInterval: function(t) {
        this.intervalData = t, Ext.isFunction(this.intervalData) || Ext.isArray(this.intervalData) || Ext.isNumber(this.intervalData) || (this.intervalData = this.INTERVAL_DEFAULT), this.interval = this.adaptiveInterval()
    },
    adaptiveInterval: function() {
        var t, e = 0,
            i = this.intervalData,
            s = null;
        if (this.taskFirstRunTime && (e = (new Date).getTime() - this.taskFirstRunTime), Ext.isNumber(i)) s = i;
        else if (Ext.isFunction(i)) s = i.call(this.scope || this, e);
        else if (Ext.isArray(i))
            for (t = 0; t < i.length && !(i[t].time > e); ++t) s = i[t].interval;
        return Ext.isNumber(s) || (SYNO.Debug.debug("TaskRunner: Task " + this.id + " interval fallback to " + this.INTERVAL_FALLBACK), s = this.INTERVAL_FALLBACK), s
    },
    start: function(t) {
        var e = (new Date).getTime();
        if (!this.removed) return this.taskFirstRunTime || (this.taskFirstRunTime = !1 === t ? e + this.interval : e), this.manager.start(this, t)
    },
    stop: function() {
        if (!this.removed) return this.manager.stop(this)
    },
    restart: function(t) {
        this.stop(), this.start(t)
    },
    remove: function() {
        this.stop(), this.manager.removeTask(this.id), this.removed = !0
    }
}), SYNO.SDS.TaskRunner.AjaxTask = Ext.extend(SYNO.SDS.TaskRunner.Task, {
    constructor: function(t, e) {
        this.reqId = null, this.reqConfig = null, this.cbHandler = null, this.autoJsonDecode = !1, this.single = !1, SYNO.SDS.TaskRunner.AjaxTask.superclass.constructor.call(this, t, e)
    },
    applyConfig: function(t) {
        Ext.apply(this, {
            run: this.run,
            scope: this
        }), this.autoJsonDecode = !0 === t.autoJsonDecode, this.single = !0 === t.single, this.preventHalt = !0 === t.preventHalt, this.cbHandler = {}, this.reqConfig = {}, Ext.copyTo(this.cbHandler, t, ["scope", "callback", "success", "failure"]), Ext.apply(this.reqConfig, t), Ext.apply(this.reqConfig, {
            success: null,
            failure: null,
            callback: this.onCallback,
            scope: this
        }), Ext.applyIf(this.reqConfig, {
            method: "GET"
        }), delete this.reqConfig.id, delete this.reqConfig.autoJsonDecode, delete this.reqConfig.single
    },
    stop: function() {
        this.reqId && (Ext.Ajax.abort(this.reqId), this.reqId = null), SYNO.SDS.TaskRunner.AjaxTask.superclass.stop.apply(this, arguments)
    },
    run: function() {
        this.reqConfig.url ? (SYNO.SDS.TaskRunner.AjaxTask.superclass.stop.call(this), this.reqId = Ext.Ajax.request(this.reqConfig)) : this.remove()
    },
    onCallback: function(t, e, i) {
        var s = i,
            n = Ext.apply({}, t);
        if (Ext.apply(n, {
                scope: this.cbHandler.scope,
                callback: this.cbHandler.callback,
                success: this.cbHandler.success,
                failure: this.cbHandler.failure
            }), e && this.autoJsonDecode) try {
            s = Ext.util.JSON.decode(i.responseText)
        } catch (t) {
            s = {
                success: !1
            }, e = !1
        }
        e && n.success ? n.success.call(n.scope, s, t) : !e && n.failure && n.failure.call(n.scope, s, t), n.callback && n.callback.call(n.scope, t, e, s), this.fireEvent("callback", t, e, s), e && this.single ? (this.reqId = null, this.remove()) : this.reqId && (this.reqId = null, this.start(!1))
    }
}), SYNO.SDS.TaskRunner.WebAPITask = Ext.extend(SYNO.SDS.TaskRunner.AjaxTask, {
    constructor: function(t, e) {
        SYNO.SDS.TaskRunner.WebAPITask.superclass.constructor.call(this, t, e)
    },
    applyConfig: function(t) {
        Ext.apply(this, {
            run: this.run,
            scope: this
        }), this.single = !0 === t.single, this.preventHalt = !0 === t.preventHalt, this.cbHandler = {}, this.reqConfig = {}, Ext.copyTo(this.cbHandler, t, ["callback", "scope"]), Ext.apply(this.reqConfig, t), Ext.apply(this.reqConfig, {
            callback: this.onCallback,
            scope: this
        }), delete this.reqConfig.id, delete this.reqConfig.single
    },
    run: function() {
        SYNO.SDS.TaskRunner.AjaxTask.superclass.stop.call(this), this.reqId = SYNO.API.Request(this.reqConfig)
    },
    onCallback: function(t, e, i, s) {
        var n = Ext.apply({}, s);
        Ext.apply(n, {
            scope: this.cbHandler.scope,
            callback: this.cbHandler.callback
        }), n.callback && n.callback.call(n.scope, t, e, i, n), this.fireEvent("callback", t, e, i, n), this.single ? (this.reqId = null, this.remove()) : this.reqId && (this.reqId = null, this.start(!1))
    }
}), Ext.namespace("SYNO.SDS._AppMgr"), SYNO.SDS._AppMgr = Ext.extend(Ext.util.Observable, {
    list: null,
    constructor: function() {
        SYNO.SDS._AppMgr.superclass.constructor.apply(this, arguments), this.list = {}, SYNO.SDS.StatusNotifier.on("beforeUserSettingsUnload", this.saveStates, this)
    },
    register: function(t) {
        this.list[t.id] = t
    },
    unregister: function(t) {
        delete this.list[t.id]
    },
    get: function(t) {
        return "object" == _typeof(t) ? t : this.list[t]
    },
    getBy: function(t, e) {
        var i = [];
        for (var s in this.list)
            if (this.list.hasOwnProperty(s)) {
                var n = this.list[s];
                !1 !== t.call(e || n, n) && i.push(n)
            } return i
    },
    getByAppName: function(t) {
        return this.getBy(function(e) {
            return t === e.jsConfig.jsID
        })
    },
    each: function(t, e) {
        for (var i in this.list)
            if (this.list[i] && "function" != typeof this.list[i] && !1 === t.call(e || this.list[i], this.list[i])) return
    },
    saveStates: function() {
        this.saveAppState(), this.saveWidgetState()
    },
    saveAppState: function() {
        if (SYNO.SDS.UserSettings.getProperty("Desktop", "rememberWindowState") && !_S("standalone")) {
            var t = [];
            this.each(function(e) {
                var i = e.jsConfig.jsID;
                "SYNO.SDS.DSMNotify.Application" !== i && "SYNO.SDS.App.FileTaskMonitor.Instance" !== i && !0 !== e.jsConfig.hidden && t.push({
                    className: i,
                    params: e.getStateParam()
                })
            }), t.length && SYNO.SDS.UserSettings.setProperty("Desktop", "restoreParams", t)
        }
    },
    saveWidgetState: function() {
        if (!_S("standalone")) {
            var t = [];
            this.each(function(e) {
                "SYNO.SDS._Widget.Instance" === e.jsConfig.jsID && (t = e.getStateParam()) && e.setUserSettings("restoreParams", t)
            })
        }
    }
}), Ext.namespace("SYNO.SDS._WindowMgr"), SYNO.SDS._WindowMgr = Ext.extend(Ext.util.Observable, {
    zseed: 9e3,
    list: null,
    accessList: null,
    minimizedWin: null,
    centeredWindowCount: 0,
    centerOffsets: [20, 20],
    front: null,
    offsetX: 10,
    offsetY: 10,
    exposeTransformDelayTime: 900,
    exposeRestoreDelayTime: 300,
    exposeIconHeight: 38,
    exposeIconShift: 38,
    constructor: function() {
        this.list = {}, this.accessList = [], this.minimizedWin = [], SYNO.SDS._WindowMgr.superclass.constructor.apply(this, arguments), Ext.EventManager.onWindowResize(this.onWindowResize, this)
    },
    onWindowResize: function() {
        SYNO.SDS.WindowMgr.allHided && SYNO.SDS.WindowMgr.toggleAllWin(), this.exposeMask && this.exposeWindow()
    },
    sortWindows: function(t, e) {
        var i = t.getTopWin ? t.getTopWin() : t,
            s = e.getTopWin ? e.getTopWin() : e,
            n = t.isModalized && t.isModalized() ? 1 : 0,
            o = e.isModalized && e.isModalized() ? 1 : 0,
            r = t.isAlwaysOnTop && t.isAlwaysOnTop() ? 1 : 0,
            a = e.isAlwaysOnTop && e.isAlwaysOnTop() ? 1 : 0,
            l = t.isAlwaysOnBottom && t.isAlwaysOnBottom() ? 1 : 0,
            c = e.isAlwaysOnBottom && e.isAlwaysOnBottom() ? 1 : 0;
        return l !== c ? c ? 1 : -1 : r !== a ? a ? -1 : 1 : i !== s ? i.getGroupWinAccessTime() < s.getGroupWinAccessTime() ? -1 : 1 : n && t.hasOwnerWin(e) ? 1 : o && e.hasOwnerWin(t) ? -1 : t.sinkable && t.hasOwnerWin(e) ? t._lastClick < e._lastClick ? -1 : 1 : e.sinkable && e.hasOwnerWin(t) ? t._lastClick < e._lastClick ? 1 : -1 : !t._lastAccess || t._lastAccess < e._lastAccess ? -1 : 1
    },
    orderWindows: function() {
        var t = this.accessList,
            e = t.length;
        if (e > 0) {
            t.sort(this.sortWindows);
            for (var i = t[0].manager.zseed, s = 0; s < e; s++) {
                var n = t[s];
                n && !n.hidden && n.setZIndex(i + 10 * s)
            }
        }
        var o = this.activateLast();
        SYNO.SDS.StatusNotifier.fireEvent("allwinordered", this.accessList, o)
    },
    centerWindow: function(t) {
        SYNO.SDS.Desktop && SYNO.SDS.Desktop.getEl() && (t._isVue ? t.alignCenterToElement(SYNO.SDS.Desktop.getEl().dom) : (t.alignTo(SYNO.SDS.Desktop.getEl(), "c-c", this.centerOffsets.map(function(t) {
            return t * this.centeredWindowCount
        })), this.centeredWindowCount++))
    },
    setActiveWin: function(t) {
        t !== this.front && (this.front && this.front.setActive(!1), this.front = t, t && (t._isVue || (Ext.each(t.modalWin || [], function(t) {
            t && t.hideForMinimize && (delete t.hideForMinimize, t.show())
        }), Ext.each(t.siblingWin || [], function(t) {
            t && t.hideForMinimize && (delete t.hideForMinimize, t.show())
        })), this.bringToFront(t), t.setActive(!0)))
    },
    activateLast: function() {
        for (var t, e = this.accessList.length - 1; e >= 0; --e)
            if (!(t = this.accessList[e]).hidden) {
                if (t.isSkipActive && t.isSkipActive()) continue;
                return this.setActiveWin(this.accessList[e]), this.accessList[e]
            } this.setActiveWin(null)
    },
    getMaximizeAppWindowCount: function(t) {
        return this.accessList.reduce(function(e, i) {
            return t && t.id && i.id && t.id === i.id ? e : (i._isVue || i instanceof SYNO.SDS.AppWindow) && i.isVisible() && !0 === i.maximized ? e + 1 : e
        }, 0)
    },
    register: function(t) {
        if (t.manager && t.manager.unregister(t), t.manager = this, this.list[t.id] = t, this.accessList.push(t), this.bindActivateLast = this.activateLast.bind(this), t.on ? t.on("hide", this.activateLast, this) : t._isVue && t.$on("hide", this.bindActivateLast), t.fromRestore || t.isModalized && t.isModalized() || this.cascadeOverlap(t), t.autoStart && t.maximized && t.appInstance) {
            var e = t.appInstance.getRestoreSizePos();
            Ext.isDefined(e.x) || Ext.isDefined(e.y) || Ext.isDefined(e.pageX) || Ext.isDefined(e.pageY) || this.cascadeOverlap(t)
        }
    },
    unregister: function(t) {
        delete t.manager, delete this.list[t.id], t.un ? t.un("hide", this.activateLast, this) : t._isVue && t.$off("hide", this.bindActivateLast), this.accessList.remove(t), this.minimizedWin.remove(t)
    },
    get: function(t) {
        return "object" == _typeof(t) ? t : this.list[t]
    },
    bringToFront: function(t) {
        if ((t = this.get(t))._lastClick = (new Date).getTime(), t === this.front) return SYNO.SDS.StatusNotifier.fireEvent("allwinordered", this.accessList, t), !1;
        do {
            if (t._lastAccess = (new Date).getTime(), t.isModalized && !t.isModalized()) break;
            t = t._isVue ? t.$options.owner : t.owner
        } while (t);
        return this.orderWindows(), !0
    },
    sendToBack: function(t) {
        return (t = this.get(t))._lastAccess = -(new Date).getTime(), this.orderWindows(), t
    },
    hideAll: function() {
        for (var t in this.list) this.list[t] && "function" != typeof this.list[t] && this.list[t].isVisible() && this.list[t].hide()
    },
    getActive: function() {
        return this.front
    },
    getActiveAppWindow: function() {
        var t = this.getActive();
        if (t instanceof SYNO.SDS.AppWindow) return t;
        for (; t && !t.appInstance;) t = t.owner;
        return t
    },
    getBy: function(t, e) {
        for (var i = [], s = this.accessList.length - 1; s >= 0; --s) {
            var n = this.accessList[s];
            !1 !== t.call(e || n, n) && i.push(n)
        }
        return i
    },
    each: function(t, e) {
        for (var i in this.list)
            if (this.list[i] && "function" != typeof this.list[i] && !1 === t.call(e || this.list[i], this.list[i])) return
    },
    cascadeOverlap: function(t) {
        var e;
        e = t.container ? t.container.getSize() : t.getSize();
        var i = this.offsetX + t.getWidth(),
            s = this.offsetY + t.getHeight();
        i > e.width && s > e.height ? this.offsetX = this.offsetY = 10 : i > e.width ? (10 == this.offsetX && (this.offsetY = 10), this.offsetX = 10) : s > e.height && (this.offsetX += 30, this.offsetY = 10), t.setPosition(this.offsetX, this.offsetY), this.offsetX += 30, this.offsetY += 30
    },
    toggleAllWin: function(t) {
        this.showAllButton = this.showAllButton || t, this.toggleAllWinMinimize()
    },
    setShowAllButtonDisabled: function(t) {
        this.showAllButton && this.showAllButton.setDisabled(t)
    },
    toggleAllWinMinimize: function() {
        this.setShowAllButtonDisabled(!0);
        var t = [],
            e = 0,
            i = function() {
                if (!(--e > 0)) {
                    var t = (new Date).getTime();
                    Ext.each(this.minimizedWin, function(e, i) {
                        e._lastAccess = t + i
                    }), this.orderWindows(), this.setShowAllButtonDisabled(!1)
                }
            };
        Ext.each(this.accessList, function(e) {
            e.isVisible() && (!1 === e.toggleMinimizable ? e.close() : t.push(e))
        }, this), t.length ? (Ext.invoke(t, "minimize"), this.minimizedWin = t, this.setShowAllButtonDisabled(!1)) : this.minimizedWin.length ? Ext.each(this.minimizedWin, function(t) {
            e++, t.show(void 0, i, this)
        }, this) : this.setShowAllButtonDisabled(!1)
    },
    restoreWin: function(t) {
        var e = function() {
            this.allToggleing--, this.allToggleing <= 0 && (this.allToggleing = 0, SYNO.SDS.StatusNotifier.fireEvent("allwinrestored"))
        };
        t.el.origXY && (Ext.isIE ? (t.el.setXY([t.el.origXY[0], t.el.origXY[1]]), delete t.el.origXY, this.allToggleing++, e.defer(50, this)) : (this.allToggleing++, t.el.shift({
            x: t.el.origXY[0],
            y: t.el.origXY[1],
            easing: "easeOutStrong",
            duration: this.animDuration,
            scope: this,
            callback: function() {
                t.el.origShadowDisabled || t.el.enableShadow(!0), t.unmask(), delete t.el.origXY, e.apply(this)
            }
        })), t.childWinMgr && t.childWinMgr.each(this.restoreWin, this))
    },
    exposeWindow: function() {
        if (SYNO.SDS.UIFeatures.test("exposeWindow"))
            if (this.exposeMask) this.restoreTransform();
            else if (SYNO.SDS.DesktopMgr.show(SYNO.SDS.Desktop), !this.isRestoreTransform) {
            if (SYNO.SDS.WindowMgr.allHided) return SYNO.SDS.WindowMgr.toggleAllWin(), void SYNO.SDS.StatusNotifier.on("allwinrestored", this.exposeWindow, this, {
                single: !0
            });
            this.shownAppWins = [];
            var t = SYNO.SDS.TaskButtons.getAllAppWins();
            if (0 !== t.length) {
                Ext.each(t, function(t) {
                    if (!t.isVisible()) {
                        if (this.isSkipExposeAppWindow(t)) return !0;
                        t.show(!1), this.shownAppWins.push(t)
                    }
                }, this), this.hiddenNonAppWins = [], Ext.each(this.accessList, function(t) {
                    t.isVisible() && !t.taskButton && (t.hide(!1), this.hiddenNonAppWins.push(t))
                }, this);
                var e = this.calWindowPosition(t),
                    i = e.xyValues;
                this.exposeMask = Ext.getBody().createChild({
                    tag: "div",
                    cls: "sds-expose-mask",
                    tabIndex: 0
                }), this.focusMask(), this.exposeMask.on("click", this.restoreTransform, this);
                var s = 0;
                Ext.each(t, function(t) {
                    t.isVisible() && (t.el._origPos = {
                        x: t.el.getLeft(!0),
                        y: t.el.getTop(!0)
                    }, t.el._toWin = i[s], this.transformWindow(t, e.noWin), s++)
                }, this), this.exposeMask.setStyle({
                    opacity: "0.6",
                    "z-index": 1e3
                }), SYNO.SDS.StatusNotifier.fireEvent("allwinexpose")
            }
        }
    },
    focusMask: function() {
        this.exposeMask.focus()
    },
    transformWindow: function(t, e) {
        if (!t) return !1;
        var i = t.el;
        i.disableShadow();
        var s = i._toWin;
        if (i._exposeMask = i.createChild({
                tag: "div",
                cls: "sds-expose-win-mask"
            }), t.focusEl.on("focus", this.focusMask, this), !0 === e) i.addClass("sds-expose-win-hidden");
        else {
            var n = i.getSize(),
                o = s.w / n.width;
            n.height * o > s.h && (o = s.h / n.height), o = Math.min(o, 1).toFixed(2);
            var r = s.x - i._origPos.x,
                a = s.y - i._origPos.y;
            i.addClass("sds-expose-win-transform"), i.setStyle("-webkit-transform", String.format("translate3d({1}px, {2}px, 0) scale3d({0}, {0}, 1)", o, r, a)), i.setStyle("-moz-transform", String.format("translate({1}px, {2}px) scale({0})", o, r, a)), i.setStyle("-o-transform", String.format("translate({1}px, {2}px) scale({0})", o, r, a)), i.setStyle("transform", String.format("translate({1}px, {2}px) scale({0})", o, r, a))
        }
        return t._deferTaskId = this.afterTransformWindow.defer(!0 === e ? 0 : this.exposeTransformDelayTime, this, [t, e]), t
    },
    afterTransformWindow: function(t, e) {
        if (!t) return !1;
        var i = t.el,
            s = i._toWin;
        if (Ext.isEmpty(i.dom)) return !1;
        var n = i._exposeMask;
        if (t.mon(n, "mousedown", function(t) {
                t.stopEvent()
            }, this), t.mon(n, "click", this.onWinMaskClick, this, {
                win: t
            }), t.mon(n, "mouseenter", function(t) {
                var e = t.getTarget();
                Ext.fly(e).addClass("sds-expose-win-over")
            }, this), t.mon(n, "mouseleave", function(t) {
                var e = t.getTarget();
                Ext.fly(e).removeClass("sds-expose-win-over")
            }, this), i.iconBadge = new SYNO.SDS.IconBadge, t.jsConfig && t.getTitle() && t.jsConfig.icon) {
            var o = t.jsConfig.jsBaseURL + "/" + (t.jsConfig.icon || t.jsConfig.icon_16);
            i.iconBadge.setIconText(SYNO.SDS.UIFeatures.IconSizeManager.getIconPath(o, "Header"), SYNO.SDS.UIString.GetLocalizedString(t.getTitle(), t.jsConfig.jsID))
        } else i.iconBadge.setIconText("", t.title || "");
        i.iconBadge.setXY(s.x, s.y - this.exposeIconHeight + this.exposeIconShift), t.mon(i.iconBadge.el, "click", this.onWinMaskClick, this, {
            win: t
        })
    },
    onWinMaskClick: function(t, e, i) {
        return this.restoreTransform(),
            function() {
                i.win.show()
            }.defer(this.exposeRestoreDelayTime, this), t.stopEvent(), !1
    },
    restoreTransform: function() {
        this.isRestoreTransform || (this.isRestoreTransform = !0, this.exposeMask && this.exposeMask.setStyle("opacity", "0"), Ext.each(this.accessList, function(t) {
            var e = t.el;
            if (t.focusEl.un("focus", this.focusMask, this), t._deferTaskId && (window.clearTimeout(t._deferTaskId), t._deferTask = null), e._origPos) {
                e.iconBadge && (e.iconBadge.el.hide(), e.iconBadge.el.remove(), e.iconBadge = null), e._exposeMask && (e._exposeMask.remove(), delete e._exposeMask, e._exposeMask = null), e.hasClass("sds-expose-win-hidden") ? e.removeClass("sds-expose-win-hidden") : (e.addClass("sds-expose-win-transform-restore"), e.setStyle("-webkit-transform", ""), e.setStyle("-moz-transform", ""), e.setStyle("-o-transform", ""), e.setStyle("transform", ""));
                (function() {
                    e.removeClass("sds-expose-win-transform"), e.removeClass("sds-expose-win-transform-restore"), e.enableShadow(!0)
                }).defer(this.exposeRestoreDelayTime, this)
            }
        }, this), Ext.each(this.hiddenNonAppWins, function(t) {
            t.isSkipUnexpose && t.isSkipUnexpose() || t.show(!1)
        }, this), Ext.each(this.shownAppWins, function(t) {
            t.hide(!1), t.minimize()
        }, this), function() {
            this.exposeMask && (this.exposeMask.un("click", this.restoreTransform, this), this.exposeMask.remove(), this.exposeMask = null), SYNO.SDS.StatusNotifier.fireEvent("allwinunexpose"), this.isRestoreTransform = !1
        }.defer(this.exposeRestoreDelayTime, this))
    },
    calWindowPosition: function(t) {
        var e = 0;
        Ext.each(t, function(t) {
            t.isVisible() && e++
        });
        var i = SYNO.SDS.Desktop.getEl().getSize(),
            s = i.width,
            n = i.height,
            o = 0,
            r = 0,
            a = this.exposeIconHeight,
            l = 1;
        e < 3 ? (o = 1 === e ? s - 100 : (s - 150) / 2, r = n - 100 - a) : (o = (s - 200) / 3, r = (n - 50 * ((l = Math.ceil(e / 3)) + 1) - l * a) / l), o = Math.round(o), r = Math.round(r);
        for (var c = {}, d = [], u = 0; u < e; ++u) {
            var h, p = u % 3 + 1,
                S = Math.max(Math.ceil((u + 1) / 3), 1),
                f = 0;
            f = e < 3 ? 50 + a : S * (50 + a) + (S - 1) * r, h = (p - 1) * o + 50 * p, d[u] = {
                x: h,
                y: f,
                w: o,
                h: r
            }
        }
        return c.xyValues = d, (o < 80 || r < 80 || e > 9) && (c.noWin = !0), c
    },
    isSkipExposeAppWindow: function(t) {
        return !(!t.isSkipExpose || !0 !== t.isSkipExpose()) || !!(SYNO.SDS.AudioStation && SYNO.SDS.AudioStation.MainWindow && t instanceof SYNO.SDS.AudioStation.MainWindow && !0 === t.gIsOnMiniPlayerMode)
    }
}), Ext.define("SYNO.SDS.TransitionEndHandler", {
    extend: "Ext.util.Observable",
    constructor: function(t) {
        this.el = t, t.on("transitionend", this.endTransition, this), this.callParent(arguments)
    },
    start: function() {
        this.startTime = new Date
    },
    endTransition: function() {
        this.fireEvent("aftertransition", this, new Date - this.startTime)
    }
}), Ext.define("SYNO.SDS._DeskTopManager", {
    extend: "Ext.util.Observable",
    list: null,
    front: null,
    desktopId: "sds-desktop",
    constructor: function() {
        this.list = {}, this.callParent()
    },
    register: function(t) {
        t.manager && t.manager.unregister(t), t.manager = this, this.list[t.id] = t, t.id !== this.desktopId && t !== this.desktopId || this.showDesktop()
    },
    unregister: function(t) {
        delete t.manager, delete this.list[t.id]
    },
    isDesktopOnTop: function() {
        return this.front === this.get(this.desktopId)
    },
    showDesktop: function() {
        var t = this.get(this.desktopId);
        this.bringToFront(t)
    },
    get: function(t) {
        return "object" == _typeof(t) ? t : this.list[t]
    },
    updateTransition: function(t, e) {
        e > 500 && (this.disableBlur = !0, this.transitionHandler.un("aftertransition", this.updateTransition, this))
    },
    bringToFront: function(t) {
        var e, i = this;
        return !((t = i.get(t)) === i.front || !t) && (e = t.doLayout, t.show(), i.front && i.front.id === i.desktopId ? i.front.addClass(i.backgroundTransparent ? "semi-transparent" : "sent-back") : i.front && i.front.hide(), i.front = t, e && t.doLayout(), !0)
    },
    hideAllExceptMe: function(t) {
        var e, i = this;
        for (var s in i.list) i.list.hasOwnProperty(s) && (e = i.list[s]) && e !== t && "function" != typeof i.list[s] && i.list[s].isVisible() && i.list[s].hide()
    },
    hideAll: function() {
        for (var t in this.list) this.list[t] && "function" != typeof this.list[t] && this.list[t].isVisible() && this.list[t].hide();
        this.front = null
    },
    getActive: function() {
        return this.front
    },
    each: function(t, e) {
        for (var i in this.list)
            if (this.list[i] && "function" != typeof this.list[i] && !1 === t.call(e || this.list[i], this.list[i])) return
    }
}), SYNO.SDS.DefineDesktopView = function(t, e) {
    Ext.define(t, {
        extend: e,
        animateShowHideCls: "sds-desktop-view-animate",
        showCls: "sds-desktop-view-show",
        constructor: function(t) {
            t = t || {}, t = Ext.apply(t, {
                tabIndex: -1,
                hideMode: "offsets",
                hidden: !0
            }), this.callParent([t]), this.initManager(t.manager || SYNO.SDS.DeskTopManager), t.taskBarConfig && this.initTaskbarButton(t.taskBarConfig), t.trayIconConfig && this.initTrayIconButton(t.trayIconConfig)
        },
        initManager: function(t) {
            this.manager = t, this.manager.register(this)
        },
        initTaskbarButton: function(t) {
            _S("standalone") || (t = t || {}, t = Ext.applyIf(t, {
                toggleHandler: this.onToggle.createDelegate(this)
            }), this.taskBarButton = SYNO.SDS.TaskBar.addDesktopViewButton(t))
        },
        initTrayIconButton: function(t) {
            _S("standalone") || (t = t || {}, t = Ext.applyIf(t, {
                toggleHandler: this.onToggle.createDelegate(this)
            }), this.taskBarButton = SYNO.SDS.TaskBar.addTrayIconViewButton(t))
        },
        toggleButton: function(t, e) {
            var i = this.taskBarButton;
            i && i.toggle(t, e)
        },
        onToggle: function(t, e) {
            this[e ? "activeView" : "showDesktop"]()
        },
        hide: function() {
            var t = this;
            t.transitionHandler.start(), t.removeClass(t.showCls), t.callParent(), t.toggleButton(!1, !0)
        },
        show: function() {
            this.transitionHandler.start(), this.addClass(this.showCls), this.callParent()
        },
        updateTransition: function(t, e) {
            e > 500 && (this.addClass("no-transition"), this.transitionHandler.un("aftertransition", this.updateTransition, this))
        },
        resetTransition: function() {
            this.disableBlur = !1, this.removeClass("no-transition")
        },
        activeView: function() {
            this.manager.bringToFront(this), this.focus()
        },
        showDesktop: function() {
            this.manager.showDesktop()
        },
        afterRender: function() {
            var t = this;
            t.callParent(), t.transitionHandler = t.transitionHandler || new SYNO.SDS.TransitionEndHandler(t.getEl()), t.transitionHandler.on("aftertransition", t.updateTransition, t), Ext.EventManager.onWindowResize(this.onWindowResize, this), t.animateShowHide && t.addClass(t.animateShowHideCls), t.el.on("mousedown", this.onClick, this), void 0 !== t.tabIndex && t.el.dom.setAttribute("tabIndex", t.tabIndex), t.keyNav = new Ext.KeyNav(t.el, {
                esc: this.onEnterEsc,
                scope: this
            })
        },
        onEnterEsc: function(t) {
            this.showDesktop()
        },
        onClick: function(t, e) {},
        resize: function(t, e) {},
        getViewSize: function() {
            return {
                viewH: Ext.lib.Dom.getViewHeight() - SYNO.SDS.TaskBar.getHeight(),
                viewW: Ext.lib.Dom.getViewWidth()
            }
        },
        onWindowResize: function() {
            var t = this.getViewSize();
            this.resize(t.viewW, t.viewH)
        },
        refresh: function() {},
        addInstruction: function() {
            var t = Ext.lib.Dom.getViewHeight() - SYNO.SDS.TaskBar.getHeight(),
                e = Ext.lib.Dom.getViewWidth();
            this.instruction = new Ext.Container({
                cls: "sds-app-widget-instruction",
                width: e,
                height: t,
                items: [{
                    xtype: "box",
                    cls: "message-container",
                    html: _T("desktop", "shortcut_zone_instruction")
                }, {
                    xtype: "box",
                    cls: "message-arrow"
                }],
                listeners: {
                    afterlayout: function() {
                        var t = this.el.child(".message-container"),
                            e = this.el.child(".message-arrow"),
                            i = .33 * this.getHeight();
                        t.alignTo(this.shortcutZoneLeft.el, "tl-tr", [-36, i]), e.alignTo(t, "r-l", [1, 5])
                    },
                    scope: this
                },
                resize: function() {
                    var t = Ext.lib.Dom.getViewHeight() - SYNO.SDS.TaskBar.getHeight(),
                        e = Ext.lib.Dom.getViewWidth();
                    this.setSize(e, t), this.doLayout()
                },
                showTip: function() {
                    this.addClass("show")
                }
            }), this.add(this.instruction), this.on("show", this.showInstruction, this)
        },
        showInstruction: function() {
            this.showTaskId = Ext.defer(function() {
                this.instruction && (this.shortcutZoneLeft.addClass("on-instruction"), this.shortcutZoneRight.addClass("on-instruction"), this.shortcutZoneBottom && this.shortcutZoneBottom.addClass("on-instruction"), this.instruction.showTip())
            }, 500, this)
        },
        removeInstruction: function() {
            clearTimeout(this.showTaskId), this.resetTransition(), this.instruction && (this.remove(this.instruction, !0), this.instruction = null, this.shortcutZoneLeft.removeClass("on-instruction"), this.shortcutZoneRight.removeClass("on-instruction"), this.shortcutZoneBottom && this.shortcutZoneBottom.removeClass("on-instruction"), this.un("show", this.showInstruction, this), this.un("beforehide", this.removeInstruction, this))
        },
        destroy: function() {
            var t = this;
            t.transitionHandler.un("aftertransition", t.updateTransition, t), t.transitionHandler = null, Ext.EventManager.removeResizeListener(t.onWindowResize, t), Ext.destroy(t.keyNav), t.keyNav = null, t.taskBarButton.getEl().remove(), t.callParent(arguments)
        }
    })
}, SYNO.SDS.DefineDesktopView("SYNO.SDS._DesktopView", "Ext.Container"), SYNO.SDS.DefineDesktopView("SYNO.SDS.Box_DesktopView", "Ext.BoxComponent"), Ext.namespace("SYNO.SDS"), Ext.define("SYNO.SDS.DesktopSetting", {
    statics: {}
}), SYNO.SDS.ShortcutUtil = {
    allowedCfgProperty: ["jsID", "className", "param", "title", "formatedTitle", "desc", "icon", "type", "url", "urlDefMode", "urlTag", "urlTarget", "launchParams", "subItems", "icon_16", "icon_32", "allowStandalone", "port", "protocol", "windowLaunchEncodeFn", "windowLaunchDecodeFn"],
    getCfgPropertis: function() {
        return this.allowedCfgProperty.join(",")
    }
}, SYNO.SDS._StandaloneDesktop = Ext.extend(Ext.BoxComponent, {
    constructor: function() {
        SYNO.SDS._StandaloneDesktop.superclass.constructor.call(this, {
            id: "sds-desktop",
            style: "background: transparent; top: 0px; background-size: 100% 100%;",
            renderTo: document.body
        }), this.onWindowResize(), Ext.EventManager.onWindowResize(this.onWindowResize, this)
    },
    onWindowResize: function() {
        this.el.setHeight(Ext.lib.Dom.getViewHeight());
        var t = this.el.getBox(),
            e = SYNO.SDS.DesktopSetting.miniWidth || 1e3,
            i = SYNO.SDS.DesktopSetting.miniHeight || 580,
            s = t.width <= e ? "auto" : "hidden",
            n = t.height <= i ? "auto" : "hidden";
        this.el.setStyle({
            "overflow-x": s,
            "overflow-y": n
        })
    }
}), Ext.define("SYNO.SDS._Desktop", {
    extend: "SYNO.SDS.Box_DesktopView",
    defShortCuts: SYNO.SDS.isNVR ? [{
        className: "SYNO.SDS.PkgManApp.Instance"
    }, {
        className: "SYNO.SDS.AdminCenter.Application"
    }, {
        className: "SYNO.SDS.App.FileStation3.Instance"
    }, {
        className: "SYNO.SDS.HelpBrowser.Application"
    }, {
        className: "SYNO.SDS.SurveillanceStation"
    }] : [{
        className: "SYNO.SDS.PkgManApp.Instance"
    }, {
        className: "SYNO.SDS.AdminCenter.Application"
    }, {
        className: "SYNO.SDS.App.FileStation3.Instance"
    }, {
        className: "SYNO.SDS.HelpBrowser.Application"
    }],
    DROP_ALLOWED_CLS: "x-dd-drop-ok-add",
    DROP_DENIED_CLS: "x-dd-drop-nodrop",
    REPOSITION_OK_CLS: "x-dd-reposition-ok",
    CURSOR_OVER_TYPE: {
        ABOVE_ICON: 0,
        OVER_ICON: 1,
        BELOW_ICON: 2
    },
    items: null,
    iconItems: null,
    updateTask: null,
    updateDelay: 200,
    ICON_WIDTH: 136,
    ICON_HEIGHT: 116,
    isBeta: !1,
    opacityHideCls: "sds-desktop-hide",
    isItemUpdated: !1,
    constructor: function() {
        var t = this;
        SYNO.SDS.DesktopSetting.miniWidth = 1e3, SYNO.SDS.DesktopSetting.miniHeight = 580, this.allowedCfgProperty = SYNO.SDS.ShortcutUtil.getCfgPropertis(), this.hotkeyPlugin = new SYNO.SDS.DesktopHotKeyPlugin({
            module: this
        }), SYNO.SDS._Desktop.superclass.constructor.call(this, {
            id: "sds-desktop",
            taskBarConfig: {
                handler: this.onShowAll.createDelegate(this),
                tooltip: _T("desktop", "show_desktop"),
                renderTo: "sds-taskbar-showall"
            },
            plugins: [this.hotkeyPlugin],
            hidden: !1,
            renderTo: document.body
        }), this.items = [], this.iconItems = [], this.updateTask = new Ext.util.DelayedTask(this.updateItems, this), this.shortcutPanel = new SYNO.SDS.DesktopShortcutPanel({
            renderTo: "sds-desktop",
            module: this
        }), this.mon(this.el, "scroll", function(t) {
            var e = this.el.getBox();
            return this.el.dom.scrollTop > 0 && e.height >= SYNO.SDS.DesktopSetting.miniHeight && (this.el.dom.scrollTop = -100), t.preventDefault(), !1
        }, this), this.mon(Ext.getBody(), "scroll", function(t, e, i) {
            return e.scrollTop > 0 && (e.scrollTop = 0), t.preventDefault(), !1
        }, this), this.el.dragZone = new Ext.dd.DragZone(this.el, {
            ddGroup: "SDSShortCut",
            proxy: new SYNO.ux.StatusProxy({
                baseCls: "sds-launch-icon-dragging-proxy"
            }),
            validateTarget: function(t, e, i) {
                var s = e.getTarget("li.launch-icon");
                return !!(SYNO.SDS.Desktop.el.id === e.getTarget().id || s && Ext.fly(s).findParentNode(".sds-desktop-shortcut")) || (!(!e.getTarget("#sds-sub-container") && !e.getTarget("#sds-sub-container-shim")) || (this.getProxy().setStatus(this.dropNotAllowed), !1))
            },
            getDragData: this.getDragData.createDelegate(this, [], !0),
            getRepairXY: function() {
                return this.dragData.repairXY
            },
            endDrag: function(t) {
                SYNO.SDS.Desktop.onEndDrag(this.dragData)
            },
            onStartDrag: function(e, i) {
                var s = Ext.get(this.dragData.sourceEl).getBox(),
                    n = SYNO.SDS.Desktop.getEl().getBox(),
                    o = Ext.get(this.dragData.sourceEl);
                o.setVisibilityMode(Ext.Element.VISIBILITY), t.isInSelectState() || o.hide(), this.getProxy().getEl().disableShadow(), this.dragData.sourceEl.initPos = [e - o.getLeft(), i - o.getTop() + 30], this.dragData.sourceEl.moving = !1, this.minX = n.x, this.minY = n.y, this.maxX = n.right - s.width, this.maxY = n.bottom - s.height, this.constrainX = !0, this.constrainY = !0;
                var r = Ext.get("sds-desktop").dom.getElementsByTagName("iframe");
                Ext.each(r, function(t) {
                    var e = document.createElement("div");
                    e.addClassName("sds-shim-for-iframe"), Ext.get(t.parentNode).appendChild(e)
                })
            }
        }), this.el.dropZone = new Ext.dd.DropZone(Ext.getBody(), {
            dropAllowed: "x-dd-drop-ok-add",
            ddGroup: "SDSShortCut",
            getTargetFromEvent: function(t) {
                var e = t.getTarget("li.launch-icon");
                return e && Ext.fly(e).findParentNode(".sds-desktop-shortcut") ? e : null
            },
            onNodeOver: this.onNodeOver.createDelegate(this, [], !0),
            onContainerOver: this.onContainerOver.createDelegate(this, [], !0),
            onContainerDrop: this.onNotifyDrop.createDelegate(this, [], !0),
            onNodeDrop: this.onNodeDrop.createDelegate(this, [], !0)
        }), this.el.dropZone.addToGroup("AppReorderAndShortCut"), this.el.dropZone.addToGroup("AppShortCut"), this.wallpaper = this.createWallpaper(), this.onWindowResize(), Ext.EventManager.onWindowResize(this.onWindowResize, this), this.loadShortcutItems(), this.mon(SYNO.SDS.StatusNotifier, "servicechanged", this.onServiceChanged, this), this.mon(SYNO.SDS.StatusNotifier, "appprivilegechanged", this.onServiceChanged, this), this.mon(SYNO.SDS.StatusNotifier, "urltagchanged", this.refresh, this), this.mon(SYNO.SDS.StatusNotifier, "thirdpartychanged", this.onThirdPartyChanged, this), _S("isMobile") && _S("is_admin") ? this.addMobileEditionButton() : t.isBeta && this.addBetaBugReportButton(), this.el.on("mousedown", this.onDesktopMouseDown, this)
    },
    onEndDrag: function(t) {
        var e = Ext.get(t._fromAppMenu ? t.desktopSrcEl : t.sourceEl),
            i = SYNO.SDS.Desktop;
        i.isInSelectState() && (Ext.removeNode(t.ddel), Ext.destroy(i.ddel)), e.show(), Ext.each(SYNO.SDS.Desktop.iconItems, function(t, e) {
            t && "SYNO.SDS.VirtualGroup" === t.className && t.validTempNode()
        });
        var s = Ext.get("sds-desktop").query(".sds-shim-for-iframe");
        Ext.each(s, function(t) {
            Ext.removeNode(t)
        }), this.el.focus()
    },
    setDesktopVisible: function(t) {
        Ext.get("sds-desktop").setVisibilityMode(Ext.Element.OFFSETS), this.bugReportButton && this.bugReportButton.setVisible(t)
    },
    hide: function() {
        this.setDesktopVisible(!1), this.addClass(this.opacityHideCls), this.removeClass(this.showCls), Ext.isIE && this.callParent()
    },
    show: function() {
        this.setDesktopVisible(!0), this.callParent(), this.removeClass(this.opacityHideCls), this.removeClass("semi-transparent"), this.removeClass("sent-back")
    },
    onShowAll: function() {
        this.showDesktop(), SYNO.SDS.WindowMgr.toggleAllWin(this.taskButton)
    },
    isInSelectState: function() {
        var t = !1;
        return Ext.each(this.iconItems, function(e) {
            t || e && e.isSelected() && (t = !0)
        }, this), t
    },
    getEvtXYWithScroll: function(t) {
        return [t.xy[0] + this.el.dom.scrollLeft, t.xy[1] + this.el.dom.scrollTop]
    },
    onDesktopMouseDown: function(t, e, i) {
        var s, n = this.el.getLeft(),
            o = this.getEvtXYWithScroll(t);
        o[0] > e.scrollWidth || o[1] > e.scrollHeight || t.target === this.el.dom && ((s = Ext.get(document.body)).on("mousemove", this.onDesktopMouseMove, this), s.on("mouseup", this.onDesktopMouseUp, this), s.on("mouseleave", this.onDesktopMouseLeave, this, {
            delay: 100
        }), this.el._beginDragPos = o, this._range && this._range.remove(), this._range = this.el.createChild({
            tag: "div",
            cls: "sds-desktop-select-range"
        }), this._range.setPosition = function(t, e, i) {
            this.setLeft(t[0] - n), this.setTop(t[1] - 32), this.setWidth(e), this.setHeight(i)
        }.createDelegate(this._range), this._range.setPosition(o, 0, 0))
    },
    onDesktopMouseMove: function(t) {
        if (this.el._beginDragPos && t) {
            var e = this.el._beginDragPos,
                i = this.getEvtXYWithScroll(t),
                s = i[0] - e[0],
                n = i[1] - e[1];
            i = [s > 0 ? e[0] : i[0], n > 0 ? e[1] : i[1]], s = Math.abs(s), n = Math.abs(n), this._range.setPosition(i, s, n), this.rangeDetectTask = new Ext.util.DelayedTask(this.detectOverlappedObjects, this), this.rangeDetectTask.delay(5)
        }
    },
    onDesktopMouseLeave: function(t) {
        this.cancelRangeDetectTask(), this.endRangeDetect()
    },
    onDesktopMouseUp: function(t) {
        this.cancelRangeDetectTask(), this.detectOverlappedObjects(), this.endRangeDetect()
    },
    cancelRangeDetectTask: function() {
        this.rangeDetectTask && (this.rangeDetectTask.cancel(), this.rangeDetectTask = null)
    },
    endRangeDetect: function() {
        var t = Ext.get(document.body);
        this._range && this._range.remove(), this._range = null, delete this.el._beginDragPos, t.un("mousemove", this.onDesktopMouseMove, this), t.un("mouseup", this.onDesktopMouseUp, this), t.un("mouseleave", this.onDesktopMouseLeave, this)
    },
    collisionDetect: function(t, e) {
        var i, s;
        if (t && e) return i = t.getRegion(), s = e.getRegion(), (i.left < s.right && i.right > s.right || i.left < s.left && i.right > s.left || i.left > s.left && i.right < s.right) && (i.top > s.top && i.bottom < s.bottom || i.top < s.bottom && i.bottom > s.bottom || i.bottom > s.top && i.top < s.top)
    },
    detectOverlappedObjects: function() {
        var t = 0;
        Ext.each(this.iconItems, function(e, i) {
            e.subItems || (this.collisionDetect(e.li_el, this._range) ? (this.selectItem(e, !0), t++) : this.selectItem(e, !1))
        }, this), 0 === t && Ext.destroy(this.ddel)
    },
    selectItem: function(t, e) {
        t && t.li_el && t.setSelected && (t.setSelected(e), e ? t.li_el.addClass("sds-desktop-icon-selected") : t.li_el.removeClass("sds-desktop-icon-selected"))
    },
    getCursorOverType: function(t, e) {
        var i;
        return t[0] - e[0], (i = t[1] - e[1]) <= 17 ? this.CURSOR_OVER_TYPE.ABOVE_ICON : i >= 80 ? this.CURSOR_OVER_TYPE.BELOW_ICON : this.CURSOR_OVER_TYPE.OVER_ICON
    },
    onContainerOver: function(t, e, i) {
        return i.ddText && t.getProxy().getGhost().update(i.ddText), e.getTarget("#sds-sub-container") ? this.REPOSITION_OK_CLS : e.getTarget("#sds-taskbar") ? this.DROP_DENIED_CLS : i._fromDesktop || i._fromAppMenu ? this.REPOSITION_OK_CLS : this.DROP_ALLOWED_CLS
    },
    onNodeOver: function(t, e, i, s) {
        return s._fromSubContainer || this.isSubContainerExist() ? this.onSubNodeOver(t, e, i, s) : s._fromDesktop || s._fromAppMenu ? this.onDesktopNodeOver(t, e, i, s) : this.DROP_ALLOWED_CLS
    },
    onSubNodeOver: function(t, e, i, s) {
        var n = i.xy,
            o = Ext.get(t).getXY(),
            r = [n[0] - o[0], n[1] - o[1]],
            a = null;
        this.appendSubItemMode ? a = this.getItemFromSubTempNode() : s._fromSubContainer ? a = this.getItemFromSubNode(s.sourceEl) : this._creatingVirtualGroup && (a = this.getItemFromSubTempNode());
        var l = this.getItemFromSubNode(t),
            c = this.iconItems[l[0]];
        return this.isVirtualGroup(c) ? (r[0] > 40 && l[1]++, c.rePosition(a[1], l[1]), this.REPOSITION_OK_CLS) : this.DROP_ALLOWED_CLS
    },
    onDesktopNodeOver: function(t, e, i, s) {
        var n, o, r, a, l, c = this.getItemFromNode(t);
        if (!((n = s._fromAppMenu ? this.getItemFromNode(s.desktopSrcEl) : this.getItemFromNode(s.sourceEl)) < 0 || c < 0)) return o = this.iconItems[n], r = this.iconItems[c], l = this.getCursorOverType(i.xy, Ext.get(t).getXY()), this.cancelDeferTask(), l === this.CURSOR_OVER_TYPE.OVER_ICON ? this.nodeOverToGrouping(t, n, c, o, r) : (l === this.CURSOR_OVER_TYPE.ABOVE_ICON ? (a = this.rePosition.defer(100, this, [n, c]), this.setDeferTaskId(a)) : (a = this.rePosition.defer(100, this, [n, c + 1]), this.setDeferTaskId(a)), this.REPOSITION_OK_CLS)
    },
    rePosition: function(t, e) {
        if (t !== e && !this.isInSelectState()) {
            var i = this.items[t],
                s = this.iconItems[t];
            this.items.splice(e, 0, i), this.iconItems.splice(e, 0, s), e < t && t++, this.items.splice(t, 1), this.iconItems.splice(t, 1), this.updateItemsSetting(), this.refresh()
        }
    },
    isVirtualGroup: function(t) {
        return !(!t || "SYNO.SDS.VirtualGroup" !== t.className)
    },
    nodeOverToGrouping: function(t, e, i, s, n) {
        var o, r = this.isVirtualGroup(s),
            a = this.isVirtualGroup(n);
        if (s && n) {
            if (s === n) return this.DROP_ALLOWED_CLS;
            if (this.isInSelectState()) return n.isSelected() ? void 0 : this.DROP_ALLOWED_CLS;
            if (t && a && !r) {
                var l = Ext.copyTo({}, s.managerItemConfig ? s.managerItemConfig : s, this.allowedCfgProperty);
                return o = this.deferTaskToShowFolder.defer(800, this, [i, l]), this.setDeferTaskId(o), this.DROP_ALLOWED_CLS
            }
            return !t || a || r ? void 0 : (o = this.deferCreateVirtualGroup.defer(800, this, [e, i, s, n]), this.setDeferTaskId(o), this.DROP_ALLOWED_CLS)
        }
    },
    deferCreateVirtualGroup: function(t, e, i, s) {
        var n, o;
        this.backupNode = {
            src: {
                index: t,
                item: this.items[t]
            },
            dst: {
                index: e,
                item: this.items[e]
            }
        }, this.setOldDstItem(s), s.li_el.hide(), n = this.createNewGroupIcon(e, s, !1), this._containerShown = !0, this._creatingVirtualGroup = !0, n.createSubContainer(), o = Ext.copyTo({}, i.managerItemConfig ? i.managerItemConfig : i, this.allowedCfgProperty), n.addSubItem(o), n.refresh()
    },
    getItemFromSubTempNode: function() {
        var t = [-1, -1];
        return Ext.each(this.iconItems, function(e, i) {
            if (t[1] >= 0) return !1;
            Ext.each(e.iconItems, function(e, s) {
                if (e) return e.li_el._temp ? (t[0] = i, t[1] = s, !1) : void 0
            })
        }), t
    },
    getItemFromSubNode: function(t) {
        var e = [-1, -1];
        return Ext.each(this.iconItems, function(i, s) {
            if (i) return !(e[1] >= 0) && void Ext.each(i.iconItems, function(i, n) {
                if (i && t === i.dragEl.dom) return e[0] = s, e[1] = n, !1
            })
        }), e
    },
    updateItemsSetting: function() {
        SYNO.SDS.UserSettings.setProperty("Desktop", "ShortcutItems", this.items)
    },
    deferTaskToShowFolder: function(t, e) {
        var i = this.iconItems[t];
        i && (i.createSubContainer(), e && (this.appendSubItemMode = !0, i.addSubItem(e), i.refresh()), this._containerShown = !0)
    },
    addMobileEditionButton: function() {
        this.bugReportButton = this.el.createChild({
            tag: "div",
            id: "sds-mobile-edition",
            title: _T("common", "mobile_edition")
        }), this.mon(Ext.fly("sds-mobile-edition"), "click", function() {
            window.location = "?forceDesktop=0"
        })
    },
    addBetaBugReportButton: function() {
        this.bugReportButton = this.el.createChild({
            tag: "div",
            id: "sds-bug-report-container",
            cn: [{
                tag: "div",
                id: "sds-bug-report",
                title: _T("pkgmgr", "report_desc")
            }]
        }), this.mon(Ext.fly("sds-bug-report"), "click", function() {
            _S("is_admin") ? SYNO.SDS.AppLaunch("SYNO.SDS.SupportForm.Application") : window.open("http://myds.synology.com/support/beta_dsm_form.php", "_blank")
        })
    },
    onWindowResize: function() {
        this.el.setHeight(Ext.lib.Dom.getViewHeight() - SYNO.SDS.TaskBar.getHeight()), this.el.setWidth(Ext.lib.Dom.getViewWidth());
        var t = this.el.getBox();
        this.el.setStyle({
            "overflow-x": t.width <= SYNO.SDS.DesktopSetting.miniWidth ? "auto" : "hidden",
            "overflow-y": t.height <= SYNO.SDS.DesktopSetting.miniHeight ? "auto" : "hidden"
        }), this.wallpaper.resize(), this.refresh(), this.fireEvent("desktopresize", this)
    },
    getDragData: function(t) {
        var e, i, s = this.getItemFromNode(t.getTarget("li.launch-icon"));
        if (s >= 0) {
            if (!(i = this.iconItems[s])) return;
            if (this.isInSelectState()) {
                if (i.isSelected()) return this.getDragDataInSelectState(s, t);
                this.deselectItems()
            }
            return (e = i.dragEl.dom.cloneNode(!0)).style.position = "", e.style.left = "", e.style.top = "", e.id = Ext.id(), {
                _fromDesktop: !0,
                ddel: e,
                sourceEl: i.dragEl.dom,
                repairXY: i.dragEl.getXY(),
                SDSShortCut: i.managerItemConfig
            }
        }
        var n = this.getItemFromSubNode(t.getTarget("li.launch-icon")),
            o = this.iconItems[n[0]];
        if (o && !(o && o.iconItems && o.iconItems.length <= 0) && (i = o.iconItems[n[1]])) return (e = i.dragEl.dom.cloneNode(!0)).style.position = "", e.style.left = "", e.style.top = "", e.id = Ext.id(), {
            _fromDesktop: !1,
            _fromSubContainer: !0,
            ddel: e,
            sourceEl: i.dragEl.dom,
            repairXY: i.dragEl.getXY(),
            SDSShortCut: i.managerItemConfig
        }
    },
    getDragDataInSelectState: function(t, e) {
        var i, s, n = [];
        if (i = Ext.getBody().createChild({
                tag: "div",
                cls: "sds-desktop-dd-ct"
            }), Ext.destroy(this.ddel), this.ddel = i, Ext.each(this.iconItems, function(t) {
                var e;
                t && t.isSelected() && ((e = t.dragEl.dom.cloneNode(!0)).id = Ext.id(), n.push(e), i.appendChild(e))
            }, this), s = this.iconItems[t]) return (i = i.dom.cloneNode(!0)).style.top = "0px", i.id = Ext.id(), {
            _fromDesktop: !0,
            ddel: i,
            sourceEl: s.dragEl.dom,
            repairXY: s.dragEl.getXY(),
            SDSShortCut: s.managerItemConfig
        }
    },
    onNodeDropToInsertToGroup: function(t, e, i) {
        var s = this.getItemFromNode(i._fromAppMenu ? i.desktopSrcEl : i.sourceEl);
        s >= 0 ? this.iconItems[s].remove() : SYNO.Debug("Failed to get src node when insert to group"), this.appendSubItemMode = !1
    },
    onNotifyDrop: function(t, e, i) {
        return !(!e.getTarget("#sds-sub-container") && "sds-sub-container-shim" !== e.target.id || (this._creatingVirtualGroup && (this.removeOldDstItem(), this.iconItems[this.backupNode.src.index].remove(), this.updateItemsSetting(), this.refresh(), this.backupNode = null, this._creatingVirtualGroup = !1), this.appendSubItemMode && this.onNodeDropToInsertToGroup(t, e, i), "sds-sub-container-shim" === e.target.id)) || this.onNodeDrop(null, t, e, i)
    },
    onNodeDropSelectedToInsertToGroup: function(t, e, i, s) {
        var n, o = this.getItemFromNode(t),
            r = [];
        if (!(o < 0) && (n = this.iconItems[o]) && !n.isSelected()) return this.isVirtualGroup(n) || (n = this.createNewGroupIcon(o, n, !0)), Ext.each(this.iconItems, function(t, e) {
            var i, s;
            t && t.isSelected() && (s = this.items[e], i = Ext.copyTo({}, s.managerItemConfig ? s.managerItemConfig : s, this.allowedCfgProperty), n.addSubItem(i, !0), r.push(t))
        }, this), Ext.each(r, function(t) {
            t.remove()
        }, this), n.blinkForAdd(), n.refreshElementIcons(), this.refresh(), !0
    },
    createNewGroupIcon: function(t, e, i) {
        var s, n;
        if (!(e < 0) && e) {
            s = {
                className: "SYNO.SDS.VirtualGroup",
                title: "New Group",
                subItems: [Ext.copyTo({}, e.managerItemConfig ? e.managerItemConfig : e, this.allowedCfgProperty)]
            }, n = this.iconItems[t], this.items[t] = s;
            var o = {
                    x: n.li_el.dom.style.left,
                    y: n.li_el.dom.style.top
                },
                r = new SYNO.SDS.LaunchItem(Ext.apply({}, {
                    manager: this,
                    removable: !0,
                    module: this,
                    index: t
                }, s), this.shortcutPanel.getEl());
            return r.li_el.setLeft(o.x), r.li_el.setTop(o.y), r.li_el.addClass.defer(500, r.li_el, ["transition-cls"]), this.iconItems[t] = r, r.managerItemConfig = this.items[t], !0 === i && n.remove(), r
        }
    },
    onNodeDrop: function(t, e, i, s) {
        var n, o, r, a = -1,
            l = s.SDSShortCut;
        if (this.isInSelectState()) return this.onNodeDropSelectedToInsertToGroup(t, e, i, s);
        if (!s._fromFile && (!l || !l.className) || t && t === s.sourceEl) return !1;
        if (t && (a = this.getItemFromNode(t)), this.cancelDeferTask(), s._fromSubContainer && "sds-sub-container-shim" === i.target.id) {
            var c = this.getItemFromSubNode(s.sourceEl),
                d = this.iconItems[c[0]].iconItems[c[1]];
            d && d.remove(), this.addLaunchItem(s.SDSShortCut, -1)
        } else {
            if (s._fromSubContainer && i.getTarget("#sds-sub-container")) {
                var u = this.getItemFromSubNode(t),
                    h = this.getItemFromSubNode(s.sourceEl),
                    p = this.iconItems[u[0]];
                return p.iconItems[u[1]].li_el.show(), p.iconItems[h[1]].li_el.show(), !0
            }
            if ((s._fromDesktop || s._fromAppMenu) && i.getTarget("#sds-sub-container")) return this.onNotifyDrop(e, i, s);
            if (s._fromFile) {
                var S = i.getTarget();
                S && Ext.fly(S).findParentNode("div.syno-sds-fs-win", Number.MAX_VALUE) || ((n = this.isNodeDropOnIcon(t, e, i, s)) ? this.isVirtualGroup(n) ? Ext.isArray(s.SDSShortCut) && (Ext.each(s.SDSShortCut, function(t) {
                    var e = Ext.copyTo({}, t.config, this.allowedCfgProperty);
                    n.addSubItem(e, !0)
                }, this), n.blinkForAdd(), n.refreshElementIcons()) : Ext.isArray(s.SDSShortCut) && (r = this.createNewGroupIcon(a, n, !0), Ext.each(s.SDSShortCut, function(t) {
                    var e = Ext.copyTo({}, t.config, this.allowedCfgProperty);
                    r.addSubItem(e, !0)
                }, this), r.blinkForAdd(), r.refreshElementIcons()) : this.addLaunchItems(l, a))
            } else if (s.SDSShortCut && (s._fromControlPanel || s._fromDesktop || s._fromAppMenu)) {
                var f;
                if (n = this.isNodeDropOnIcon(t, e, i, s), s._fromDesktop || s._fromAppMenu) {
                    var g = this.getItemFromNode(s._fromAppMenu ? s.desktopSrcEl : s.sourceEl);
                    f = this.iconItems[g]
                }
                n ? this.isVirtualGroup(f) || (this.isVirtualGroup(n) ? (o = Ext.copyTo({}, s.SDSShortCut, this.allowedCfgProperty), (n = this.iconItems[a]).addSubItem(o, !0), n.blinkForAdd(), n.refreshElementIcons(), (s._fromDesktop || s._fromAppMenu) && f && f.remove()) : f !== n && (o = Ext.copyTo({}, s.SDSShortCut, this.allowedCfgProperty), (r = this.createNewGroupIcon(a, n, !0)).addSubItem(o, !0), r.blinkForAdd(), r.refreshElementIcons(), (s._fromDesktop || s._fromAppMenu) && f && f.remove(), this.refresh())) : s._fromControlPanel && this.addLaunchItem(s.SDSShortCut, a)
            }
        }
        return !0
    },
    isNodeDropOnIcon: function(t, e, i, s) {
        var n, o = -1;
        return t && (o = this.getItemFromNode(t), n = this.getCursorOverType(i.xy, Ext.get(t).getXY())), o >= 0 && n === this.CURSOR_OVER_TYPE.OVER_ICON && this.iconItems[o]
    },
    getItemFromNode: function(t) {
        var e = -1;
        if (t) return Ext.each(this.iconItems, function(i, s) {
            if (i && t === i.dragEl.dom) return e = s, !1
        }), e
    },
    validateItems: function() {
        var t = [],
            e = [];
        Ext.each(this.items, function(e, i) {
            var s = e.className || e.jsID;
            if (!_S("ha_safemode") || -1 != s.search("SYNO.SDS.HA") || -1 != s.search("SYNO.SDS.SupportForm") || -1 != s.search("SYNO.SDS.App.FileStation3"))
                if (this.isVirtualGroup(e)) t.push(e);
                else if (!this.isHiddenControlPanelModule(s, e)) {
                var n = e.needHide;
                SYNO.SDS.Config.FnMap[s] ? e.needHide = !SYNO.SDS.StatusNotifier.isAppEnabled(s) : e.needHide = !0, !0 === n && !1 === e.needHide ? e.needUpdate = !0 : e.needUpdate = !1, t.push(e)
            }
        }, this), this.items = t, SYNO.SDS.UserSettings.setProperty("Desktop", "ShortcutItems", this.items), Ext.each(this.iconItems, function(t) {
            -1 === this.items.indexOf(t.managerItemConfig) && e.push(t)
        }, this), Ext.each(e, function(t) {
            t.remove()
        }, this), Ext.each(this.iconItems, function(t) {
            this.isVirtualGroup(t) && t.validateItems()
        }, this)
    },
    loadShortcutItems: function() {
        var t = SYNO.SDS.UserSettings.getProperty("Desktop", "ShortcutItems") || this.defShortCuts;
        t = this.removeDeprecatedShortcutItems(t), Ext.each(t, function(t) {
            this.addLaunchItem(t, -1, !0)
        }, this), this.updateTextColor()
    },
    onThirdPartyChanged: function(t, e, i) {
        if ("uninstall" === e) {
            var s = [],
                n = {};
            if (Array.isArray(i) && i.length > 0) {
                for (var o = 0; o < i.length; o++) {
                    n[i[o]] = !0
                }
                for (o = 0; o < this.items.length; o++) {
                    var r = this.items[o];
                    void 0 === n[r.className || r.jsID] && s.push(r)
                }
            }
            this.items = s, SYNO.SDS.UserSettings.setProperty("Desktop", "ShortcutItems", this.items)
        }
    },
    createWallpaper: function() {
        var t = new SYNO.SDS.DesktopStyleParser;
        return Ext.getBody().setStyle({
            backgroundImage: String.format('url("{0}")', t.getDefaultWallpaperPath()),
            backgroundColor: "transparent",
            backgroundPosition: "center center",
            backgroundRepeat: "no-repeat",
            backgroundSize: "cover"
        }), new SYNO.SDS.Background(Ext.apply(t.getWallpaperCfg({
            wallpaper_path: ""
        }), {
            renderTo: "sds-wallpaper"
        }))
    },
    setBackground: function(t) {
        var e = new SYNO.SDS.DesktopStyleParser;
        this.wallpaper.destroy(), this.wallpaper = new SYNO.SDS.Background(Ext.apply(e.getWallpaperCfg(t), {
            renderTo: "sds-wallpaper"
        }))
    },
    updateTextColor: function(t) {
        var e = Ext.apply({}, SYNO.SDS.UserSettings.getProperty("Desktop", "wallpaper") || {}),
            i = "#FFFFFF";
        t && Ext.apply(e, t, {
            customize_color: !1,
            customize_wallpaper: !1
        }), e.customize_color && (i = e.text_color || "#FFFFFF"), !Ext.isIE9p && Ext.isIE ? (Ext.util.CSS.updateRule("#sds-desktop li.launch-icon .text", "color", i), Ext.util.CSS.updateRule("#sds-desktop li.launch-icon .text a", "color", i)) : Ext.util.CSS.updateRule("#sds-desktop li.launch-icon .text, #sds-desktop li.launch-icon .text a", "color", i)
    },
    onServiceChanged: function(t, e) {
        for (var i = 0; i < this.iconItems.length; i++) this.iconItems[i].className === t && this.refresh()
    },
    addLaunchItemCfg: function(t, e, i) {
        var s = Ext.copyTo({}, t, this.allowedCfgProperty);
        Ext.isNumber(e) && e >= 0 ? this.items.splice(e, 0, s) : this.items.push(s), !0 !== i && SYNO.SDS.UserSettings.setProperty("Desktop", "ShortcutItems", this.items)
    },
    addLaunchItem: function(t, e, i) {
        this.addLaunchItemCfg(t, e, i), this.refresh()
    },
    addLaunchItems: function(t, e) {
        Ext.each(t, function(t) {
            this.addLaunchItemCfg(t.config, e || t.pos, t.skipRegister)
        }, this), this.refresh()
    },
    addHiddenLaunchItem: function(t, e) {
        var i = Ext.copyTo({}, t, this.allowedCfgProperty),
            s = this.items.push(i) - 1;
        return this.refresh(), this.updateItems(), this.iconItems[s].el.hide(), SYNO.SDS.UserSettings.setProperty("Desktop", "ShortcutItems", this.items), s
    },
    removeLaunchItem: function(t) {
        t.managerItemConfig && (this.iconItems.remove(t), this.items.remove(t.managerItemConfig), SYNO.SDS.UserSettings.setProperty("Desktop", "ShortcutItems", this.items), this.refresh())
    },
    showHideItems: function(t) {
        this.showIcon = t, Ext.each(this.iconItems, function(e, i) {
            !0 === t ? e.el.show() : e.el.hide()
        }, this)
    },
    refresh: function() {
        this.updateTask.delay(this.updateDelay)
    },
    updateItems: function() {
        var t, e, i = 0,
            s = 0,
            n = this.iconItems.length <= 0;
        this.validateItems(), t = this.shortcutPanel.getEl();
        var o = 0,
            r = this.ICON_WIDTH,
            a = this.ICON_HEIGHT;
        Ext.each(this.items, function(l) {
            var c = o * r,
                d = s * a,
                u = !1;
            n || (e = this.iconItems[i]) && e.managerItemConfig !== l && (e = null), l.needUpdate && (e = this.iconItems[i], e = null, this.iconItems.splice(i, 1)), !n && e && e.li_el || ((e = new SYNO.SDS.LaunchItem(Ext.apply({}, {
                manager: this,
                removable: !0,
                module: this,
                index: i
            }, l), t)).param && e.el.addClass("hide-overflow"), this.iconItems.splice(i, 0, e), e.managerItemConfig = l, u = !0), this.setShortcutVisible(e, l.needHide), l.needHide ? ++i : (d + a > Ext.get("sds-desktop").getHeight() && (c = ++o * r, d = (s = 0) * a), ++i, ++s, this.animShortcutNode(e.li_el, c, d, !u))
        }, this), this.el.getBox().width < this.getTotalIconWidth() && (this.el.setStyle({
            "overflow-x": "scroll"
        }), this.fireEvent("desktopresize", this)), this.isItemUpdated = !0, this.fireEvent("desktopupdated")
    },
    setShortcutVisible: function(t, e) {
        t.el.setVisible(!e);
        var i = t.el.dom.childNodes;
        Ext.each(i, function(t) {
            var i = t.id,
                s = document.getElementById(i);
            s && s.classList.contains("launch-icon") && (s.style.visibility = e ? "hidden" : "visible")
        })
    },
    animShortcutNode: function(t, e, i, s) {
        if (t && t.dom)
            if (Ext.isIE && !t.dom.moving) {
                var n = t.getLeft(),
                    o = t.getTop();
                if (n === e && o === i) return;
                s ? t.shift({
                    left: e,
                    top: i,
                    easing: "easeOut",
                    duration: .5
                }) : t.setLeftTop(e, i)
            } else t.dom.moving || (s || t.removeClass("transition-cls"), t.setStyle("left", e + "px"), t.setStyle("top", i + "px"), t.addClass.defer(100, t, ["transition-cls"]))
    },
    isHiddenControlPanelModule: function(t, e) {
        if ("SYNO.SDS.ControlPanel.Instance" === t) return !0;
        if (!e.param || !e.param.fn) return !1;
        var i = e.param.fn;
        return !(!Ext.isDefined(SYNO.SDS.AppPrivilege[i]) || !1 !== SYNO.SDS.AppPrivilege[i])
    },
    msgBox: null,
    getMsgBox: function() {
        return this.msgBox && !this.msgBox.isDestroyed || (this.msgBox = new SYNO.SDS.MessageBoxV5({
            modal: !0,
            draggable: !1,
            renderTo: document.body
        })), this.msgBox.getWrapper()
    },
    removeDeprecatedShortcutItems: function(t) {
        var e = [];
        return Ext.each(t, function(t) {
            (function(t) {
                if (t.className) {
                    for (var e = ["SYNO.SDS.LogViewer.Application", "SYNO.SDS.App.WelcomeApp.Instance", "SYNO.SDS.SystemInfoApp.Application", "SYNO.SDS.ControlPanel.Instance", "SYNO.SDS.Tutorial.Application"], i = 0; i < e.length; i++) {
                        if (e[i] == t.className) return !0;
                        if ("SYNO.SDS.VirtualGroup" == t.className)
                            for (var s = t.subItems, n = s.length - 1; n >= 0; n--) e[i] == s[n].className && t.subItems.splice(n, 1)
                    }
                    return !1
                }
            })(t) || function(t) {
                return !("SYNO.SDS.AdminCenter.Application" !== t.className || !t.param || !t.param.fn || -1 === ["SYNO.SDS.AdminCenter.WebServices.Main"].indexOf(t.param.fn))
            }(t) || e.push(t)
        }, this), e
    },
    isSubContainerExist: function() {
        return !!Ext.getDom("sds-sub-container")
    },
    setDeferTaskId: function(t) {
        this._deferTaskId = t
    },
    getDeferTaskId: function() {
        return this._deferTaskId
    },
    cancelDeferTask: function() {
        var t = this.getDeferTaskId();
        t > 0 && (window.clearTimeout(t), this.setDeferTaskId(0))
    },
    getSelectedItems: function() {
        var t = [];
        return Ext.each(this.iconItems, function(e) {
            e && e.isSelected() && t.push(e)
        }, this), t
    },
    removeSelectedItems: function() {
        Ext.each(this.getSelectedItems(), function(t) {
            t.setSelected(!1), t.remove()
        }, this)
    },
    deselectItems: function() {
        Ext.each(this.getSelectedItems(), function(t) {
            this.selectItem(t, !1)
        }, this)
    },
    setOldDstItem: function(t) {
        this._oldDstItem && this._oldDstItem.remove(), this._oldDstItem = t
    },
    removeOldDstItem: function(t) {
        this._oldDstItem && this._oldDstItem.remove(), this._oldDstItem = null
    },
    getTotalIconWidth: function() {
        var t = Ext.get("sds-desktop").getHeight(),
            e = Math.floor(t / this.ICON_HEIGHT);
        return 10 + this.ICON_WIDTH * Math.ceil(this.items.length / e)
    }
}), Ext.define("SYNO.SDS.Classical._Desktop", {
    extend: "SYNO.SDS._Desktop",
    ICON_HEIGHT: 100,
    getCursorOverType: function(t, e) {
        var i;
        return t[0] - e[0], (i = t[1] - e[1]) <= 17 ? this.CURSOR_OVER_TYPE.ABOVE_ICON : i >= 64 ? this.CURSOR_OVER_TYPE.BELOW_ICON : this.CURSOR_OVER_TYPE.OVER_ICON
    }
}), Ext.namespace("SYNO.SDS.QuickConnect"), Ext.define("SYNO.SDS.QuickConnect.Main", {
    extend: "Ext.Component",
    DOMAIN: "QuickConnect.to",
    DOMAIN_PATTERN: /^.+\.quickconnect\.[^.]+$/,
    construtor: function() {
        this.callParent([{
            hidden: !0
        }])
    },
    TYPES: {
        NORMAL: "NORMAL",
        DIRECT: "DIRECT",
        TUNNEL: "TUNNEL"
    },
    SUB_DOMAIN_MAPPING: {
        NORMAL: "",
        DIRECT: "/direct/",
        TUNNEL: "/tunnel/"
    },
    aliasToPortalUrl: function(t, e) {
        return void 0 !== e && "" !== e || (e = this.DOMAIN), this.generatePortalUrl(this.TYPES.NORMAL, t, e)
    },
    getPortalUrl: function(t, e, i) {
        if (void 0 === this.SUB_DOMAIN_MAPPING[t]) return !1;
        if ("function" != typeof e) return !1;
        if (void 0 === this.callback_queue) {
            this.callback_queue = [];
            var s = {
                api: "SYNO.Core.QuickConnect",
                method: "get",
                version: 1,
                scope: this,
                callback: this.processReturnData
            };
            this.sendWebAPI(s)
        }
        return this.callback_queue.push({
            callback: e,
            scope: i,
            type: t
        }), !0
    },
    isInTunnel: function() {
        return this.DOMAIN_PATTERN.test(window.location.hostname.toLowerCase())
    },
    processReturnData: function(t, e, i) {
        for (var s = t && void 0 !== e.server_alias && void 0 !== e.region && void 0 !== e.enabled && !0 === e.enabled, n = 0; n < this.callback_queue.length; ++n) {
            var o = "",
                r = this.callback_queue[n].callback,
                a = this.callback_queue[n].scope;
            if (s) {
                var l = this.callback_queue[n].type;
                o = this.generatePortalUrl(l, e.server_alias, e.domain, e.region)
            } else o = void 0 === e.error || void 0 === e.error.code ? "" : e.error.code;
            r.apply(a, [s, o])
        }
        delete this.callback_queue
    },
    generatePortalUrl: function(t, e, i, s) {
        var n = this.SUB_DOMAIN_MAPPING[t],
            o = t == this.TYPES.NORMAL,
            r = o ? "http" : "https";
        return i = i.replace(/quickconnect/i, "QuickConnect"), o ? r + "://" + i + "/" + e : r + "://" + e + "." + s + "." + i + n
    }
}), SYNO.SDS.QuickConnect.Utils = new SYNO.SDS.QuickConnect.Main, Ext.namespace("SYNO.SDS.AppInstance"), SYNO.SDS.AppInstance = Ext.extend(Ext.Component, {
    window: null,
    trayItem: null,
    instances: null,
    taskButton: null,
    blMainApp: !1,
    constructor: function(t) {
        _S("standalone") && (this.blMainApp = this.jsConfig.jsID === _S("standaloneAppName")), SYNO.SDS.AppInstance.superclass.constructor.apply(this, arguments), SYNO.SDS.AppMgr.register(this)
    },
    beforeDestroy: function() {
        !0 === this.fullsize && SYNO.SDS.StatusNotifier.fireEvent("fullsizeappdestroy"), SYNO.SDS.AppInstance.superclass.beforeDestroy.apply(this, arguments), this.onBeforeDestroy()
    },
    onBeforeDestroy: function() {
        this.instances = null, this.window = null, this.trayItem = null, this.appItem = null, this.taskButton = null, SYNO.SDS.AppMgr.unregister(this)
    },
    beforeOpen: Ext.emptyFn,
    initInstance: function(t) {
        var e;
        if (!this.window && this.appWindowName) {
            if (!0 === this.fullsize)
                if (!(!!this.shouldLaunch && this.shouldLaunch())) return void this.destroy();
            e = Ext.getClassByName(this.appWindowName), this.window = new e(Ext.apply({
                appInstance: this,
                fromRestore: t.fromRestore
            }, t.windowState || {})), this.addInstance(this.window), this.window.init(), this.window.open(t)
        }!this.trayItem && this.appTrayItemName && (e = Ext.getClassByName(this.appTrayItemName), this.trayItem = new e(Ext.apply({
            appInstance: this
        })), this.addInstance(this.trayItem), this.trayItem.open(t)), !this.appItem && this.appItemName && (e = Ext.getClassByName(this.appItemName), this.appItem = new e(Ext.apply({
            appInstance: this
        })), this.addInstance(this.appItem), this.appItem.open(t))
    },
    open: function(t) {
        if (!Ext.isObject(t) || !Ext.isNumber(t.cms_id) || 0 >= t.cms_id) return this.delayOpen(t);
        SYNO.API.Info.UpdateById({
            cms_id: t.cms_id,
            callback: this.delayOpen,
            args: arguments,
            scope: this
        }, !0)
    },
    delayOpen: function() {
        return this.opened ? this.onRequest.apply(this, arguments) : (this.opened = !0, this.onOpen.apply(this, arguments))
    },
    onOpen: function(t) {
        !1 !== this.beforeOpen(t) ? (this.initInstance(t), this.checkAlive()) : this.destroy()
    },
    onRequest: function(t) {
        this.window && this.window.open(t), this.trayItem && this.trayItem.open(t), this.appItem && this.appItem.open(t)
    },
    checkAlive: function() {
        this.destroying || this.instances && this.instances.length || this.destroy()
    },
    addInstance: function(t) {
        t.appInstance = this, this.instances = this.instances || [], this.instances.push(t), this.addManagedComponent(t)
    },
    removeInstance: function(t) {
        t.appInstance = null, this.instances = this.instances || [], this.instances.remove(t), this.removeManagedComponent(t), this.checkAlive()
    },
    shouldNotifyMsg: function(t, e) {
        return !0
    },
    getUserSettings: function(t) {
        return SYNO.SDS.UserSettings.getProperty(this.jsConfig.jsID, t)
    },
    setUserSettings: function(t, e) {
        return SYNO.SDS.UserSettings.setProperty(this.jsConfig.jsID, t, e)
    },
    getStateParam: function() {
        var t = {
            windowState: {}
        };
        return Ext.isEmpty(this.window) ? t : (Ext.apply(t, {
            windowState: this.window.getStateParam()
        }, this.window.openConfig), t)
    }
}), Ext.namespace("SYNO.SDS.BaseWindow"), Ext.define("SYNO.SDS.AbstractWindow", {
    extend: "Ext.Window",
    toolTarget: "toolCt",
    toolCtCls: "x-window-toolCt",
    toolTemplate: new Ext.XTemplate('<div class="x-tool x-tool-{id}" role="option" aria-label="{text}">&#160;</div>'),
    constructor: function(t) {
        var e = Ext.urlDecode(location.search.substr(1));
        this.enableAlertHeight = e.alertHeight;
        var i = SYNO.SDS.Desktop ? SYNO.SDS.Desktop.getEl() : Ext.getBody();
        t = Ext.apply({
            autoFitDesktopHeight: !1,
            maximizable: !0,
            minimizable: !0,
            closable: !0,
            width: 300,
            height: 300,
            constrain: !1,
            constrainHeader: !0,
            modal: !1,
            renderTo: i,
            manager: SYNO.SDS.WindowMgr
        }, t), SYNO.SDS.AbstractWindow.superclass.constructor.call(this, t), (this.constrain || this.constrainHeader) && this.resizer && (this.resizer.constrainTo = this.container), this.mon(this, "titlechange", this.onWindowTitleChanged, this)
    },
    initEvents: function() {
        if (SYNO.SDS.AbstractWindow.superclass.initEvents.apply(this, arguments), this.resizer) {
            var t = Ext.Resizable.positions;
            for (var e in t) this.resizer[t[e]] && this.mon(this.resizer[t[e]].el, "mousedown", this.toFront, this)
        }
        this.mon(this, "beforeclose", this.onClose, this), this.mon(this, "maximize", this.onMaximize, this), this.mon(this, "minimize", this.onMinimize, this), this.mon(this, "restore", this.onRestore, this), this.mon(this, "activate", this.onActivate, this), this.mon(this, "deactivate", this.onDeactivate, this), this.header && this.mon(this.header, "contextmenu", this.onHeaderContextMenu, this)
    },
    onClose: Ext.emptyFn,
    onMaximize: Ext.emptyFn,
    onMinimize: Ext.emptyFn,
    onRestore: Ext.emptyFn,
    onActivate: Ext.emptyFn,
    onDeactivate: Ext.emptyFn,
    onHeaderContextMenu: function(t) {
        t.preventDefault()
    },
    onShow: function() {
        this.removeClass("syno-window-hide"), delete this.hideForMinimize, this.enableAlertHeight && this.isVisible() && this.getHeight() > 580 && window.alert(String.format("Height: {0}px, Plz contact your PM to adjust UI.", this.getHeight())), this.autoFitDesktopHeight && this.adjustHeightByValue(SYNO.SDS.Desktop.getHeight())
    },
    adjustHeightByValue: function(t, e) {
        (this.isVisible() || Ext.isDefined(e)) && this.getHeight() > t && this.setHeight(t)
    },
    beforeDestroy: function() {
        this.onBeforeDestroy(), SYNO.SDS.AbstractWindow.superclass.beforeDestroy.apply(this, arguments)
    },
    setIcon: function(t) {
        this.header && this.header.setStyle("background-image", t ? "url(" + t + ")" : "")
    },
    onBeforeDestroy: function() {
        this.appInstance && this.appInstance.removeInstance(this)
    },
    open: function() {
        return this.opened ? this.onRequest.apply(this, arguments) : (this.opened = !0, this.onOpen.apply(this, arguments))
    },
    onOpen: function() {
        this.minimized ? this.el.hide() : this.show()
    },
    onRequest: function() {
        this.isVisible() ? this.toFront() : this.show()
    },
    onWindowTitleChanged: function(t, e) {
        this.rendered && this.focusEl instanceof Ext.Element && this.focusEl.set({
            "aria-label": Ext.util.Format.stripTags(e)
        })
    },
    getSizeAndPosition: function() {
        var t, e = {};
        return this.maximized || this.hidden ? (this.draggable && this.restorePos ? (e.x = this.restorePos[0], e.y = this.restorePos[1]) : (e.x = this.x, e.y = this.y), this.resizable && (this.restoreSize ? (e.width = this.restoreSize.width, e.height = this.restoreSize.height) : (e.width = this.width, e.height = this.height))) : (t = this.el.origXY || this.getPosition(!1), e.pageX = t[0], e.pageY = t[1], this.resizable && (e.width = this.getWidth(), e.height = this.getHeight())), e
    },
    setResizable: function(t) {
        this.el[t ? "removeClass" : "addClass"]("no-resize")
    },
    setTitle: function(t, e, i) {
        return this.titleEncoded = i, this.title = t, !1 !== i && (t = Ext.util.Format.htmlEncode(t)), this.header && this.headerAsText && this.header.child("span").update(t), e && this.setIconClass(e), this.fireEvent("titlechange", this, this.title), this
    },
    getStateParam: function() {
        var t = {};
        return (this.maximized || this.hidden) && (t.maximized = this.maximized, t.minimized = this.hidden), Ext.apply(t, this.getSizeAndPosition()), t
    },
    getToolSelectedEl: function() {
        var t = this.toolCt.dom.getAttribute("aria-activedescendant");
        return t ? Ext.get(t) : null
    },
    selectToolNext: function() {
        var t, e = this.getToolSelectedEl();
        if (!e) return this.toolCt.set({
            "aria-activedescendant": this.toolCt.first().id
        }), void this.toolCt.first().addClass("x-tool-selected");
        for (t = e.next(); t && !t.isVisible();) t = t.next();
        t && (e.removeClass("x-tool-selected"), this.toolCt.set({
            "aria-activedescendant": t.id
        }), t.addClass("x-tool-selected"))
    },
    selectToolPre: function() {
        var t, e = this.getToolSelectedEl();
        if (!e) return this.toolCt.set({
            "aria-activedescendant": this.toolCt.last().id
        }), void this.toolCt.last().addClass("x-tool-selected");
        for (t = e.prev(); t && !t.isVisible();) t = t.prev();
        t && (e.removeClass("x-tool-selected"), this.toolCt.set({
            "aria-activedescendant": t.id
        }), t.addClass("x-tool-selected"))
    },
    onToolCtKenEnter: function() {
        var t = this.getToolSelectedEl();
        t && t.handler.call(this)
    },
    addTool: function() {
        if (this.rendered && !this.toolCt && this.header && (this.elements += ",toolCt", this.toolCt = this.header.createChild({
                cls: "x-window-toolCt"
            }, this.header.first("." + this.headerTextCls, !0)), this.toolCt.setARIA({
                role: "listbox",
                label: _T("desktop", "window_toolbar_list"),
                activedescendant: "false"
            }), this.toolCt.addKeyListener(Ext.EventObject.LEFT, this.selectToolNext, this), this.toolCt.addKeyListener(Ext.EventObject.RIGHT, this.selectToolPre, this), this.toolCt.addKeyListener(Ext.EventObject.DOWN, this.selectToolNext, this), this.toolCt.addKeyListener(Ext.EventObject.UP, this.selectToolPre, this), this.toolCt.addKeyListener(Ext.EventObject.ENTER, this.onToolCtKenEnter, this)), this.callParent(arguments), this.rendered && this.header) {
            var t, e = arguments,
                i = e.length,
                s = this.tools;
            for (t = 0; t < i; t++) {
                var n = e[t];
                s[n.id].handler || (s[n.id].handler = n.handler)
            }
        }
    },
    createGhost: function(t, e, i) {
        var s = document.createElement("div");
        if (s.className = "x-panel-ghost " + (t || ""), this.header && s.appendChild((this.tl || this.el.dom.firstChild).cloneNode(!0)), Ext.fly(s.appendChild(document.createElement("ul"))).setHeight(this.bwrap.getHeight()), s.style.width = this.el.dom.offsetWidth + "px", i ? Ext.getDom(i).appendChild(s) : this.container.dom.appendChild(s), !1 !== e && !1 !== this.el.useShim) {
            var n = new Ext.Layer({
                shadow: !1,
                useDisplay: !0,
                constrain: !1
            }, s);
            return n.show(), n
        }
        return new Ext.Element(s)
    },
    initTools: function() {
        this.minimizable && this.addTool({
            id: "minimize",
            text: _T("desktop", "minimize"),
            handler: this.minimize.createDelegate(this, [])
        }), this.maximizable && (this.addTool({
            id: "maximize",
            text: _T("desktop", "maximize"),
            handler: this.maximize.createDelegate(this, [])
        }), this.addTool({
            id: "restore",
            text: _T("destop", "restore"),
            handler: this.restore.createDelegate(this, []),
            hidden: !0
        })), this.closable && this.addTool({
            id: "close",
            text: _T("common", "close"),
            handler: this[this.closeAction].createDelegate(this, [])
        })
    },
    openVueWindow: function(t, e) {
        var i, s, n;
        Ext.isString(t) ? i = Ext.getClassByName(t) : i = t;
        if (i._isVue) n = s = i, document.querySelector("#sds-desktop").appendChild(i.$el);
        else {
            var o = document.createElement("div");
            n = new i({
                propsData: e
            }), document.querySelector("#sds-desktop").appendChild(o), n.$mount(o), (s = getModalWindow(n)).owner = SYNO.SDS.WindowMgr
        }
        return s.setOwner(this), s.init(), this.modalWin.push(s), {
            window: s,
            component: n
        }
    }
}), SYNO.SDS.BaseWindow = Ext.extend(SYNO.SDS.AbstractWindow, {
    maskCnt: 0,
    maskTask: null,
    siblingWin: null,
    sinkModalWin: null,
    modalWin: null,
    msgBox: null,
    dsmStyle: "v5",
    owner: null,
    useDefualtKey: !0,
    onEsc: function() {
        !1 !== this.useDefualtKey && SYNO.SDS.BaseWindow.superclass.onEsc.apply(this, arguments)
    },
    constructor: function(t) {
        var e, i = !!t.owner;
        this.siblingWin = [], this.modalWin = [], this.sinkModalWin = [], this.updateDsmStyle(t), t.useStatusBar && (t = this.addStatusBar(t)), (e = Ext.urlDecode(location.search.substr(1))).dsmStyle && (this.dsmStyle = e.dsmStyle), t.cls = String.format("{0}{1}", t.cls ? t.cls : "", this.isV5Style() ? " sds-window-v5" : " sds-window"), this.isV5Style() && this.fillPadding(t), SYNO.SDS.BaseWindow.superclass.constructor.call(this, Ext.applyIf(t, {
            border: !0,
            plain: !1,
            shadow: !this.isV5Style() && !SYNO.SDS.UIFeatures.test("disableWindowShadow") && "frame",
            shadowOffset: 6,
            closeAction: "close"
        })), !i || t.owner instanceof SYNO.SDS.BaseWindow || SYNO.Debug.warn(String.format('WARNING! owner of window "{0}" is not BaseWindow', this.title || this.id)), this.isV5Style() && this.centerTitle(), this.mon(this, "hide", this.restoreWindowFocus, this)
    },
    findTopWin: function() {
        for (var t, e = !1, i = this; !1 === e;)
            if (Ext.isArray(i.modalWin) && i.modalWin.length > 0)
                for (t = i.modalWin.length - 1; t >= 0; t--) {
                    if (i.modalWin[t] && !(i.modalWin[t].hidden || i.modalWin[t].isDestroyed || i.modalWin[t].destroying)) {
                        i = i.modalWin[t];
                        break
                    }
                    0 === t && (e = !0)
                } else e = !0;
        return i
    },
    restoreWindowFocus: function() {
        !0 !== this.focusLeave && SYNO.SDS.FocusMgr && (SYNO.SDS.FocusMgr.focusActiveWindow(), this.focusLeave = !0)
    },
    focusLastWindowPt: function() {
        var t, e = this.findTopWin();
        if (t = e.focusStack) {
            var i, s, n = !1;
            for (i = t.length - 1; i >= 0 && !0 !== n; i--)(s = Ext.fly(t[i])) && s.dom && s.isVisible() && -1 !== s.dom.getAttribute("tabIndex") && (s.focus(), n = !0);
            n || (this.focusEl.focus(), s = this.focusEl), e.focusStack = [s.dom]
        } else e.focusEl.focus()
    },
    addFocusPt: function() {
        var t, e = document.activeElement;
        e && Ext.fly(e).up(".x-window") && ((t = this.findTopWin()).focusStack || (t.focusStack = []), t.focusStack.push(e))
    },
    updateDsmStyle: function(t) {
        Ext.isDefined(t) && (t.dsmStyle ? this.dsmStyle = t.dsmStyle : t.owner && this.setToOwnerDsmStyle(t.owner))
    },
    getDsmStyle: function() {
        return this.dsmStyle
    },
    isV5Style: function() {
        return "v5" === this.getDsmStyle()
    },
    setToOwnerDsmStyle: function(t) {
        Ext.isFunction(t.getDsmStyle) && (this.dsmStyle = t.getDsmStyle())
    },
    addStatusBar: function(t) {
        var e = {
            xtype: "statusbar",
            defaultText: "&nbsp;",
            statusAlign: "left",
            buttonAlign: "left",
            items: []
        };
        return this.isV5Style() && (e.defaults = {
            xtype: "syno_button",
            btnStyle: "grey"
        }), t.buttons && (e.items = e.items.concat(t.buttons), delete t.buttons), Ext.applyIf(t, {
            fbar: e
        }), t
    },
    createGhost: function(t, e, i) {
        if (this.isV5Style() && (t += " sds-window-v5"), SYNO.SDS.UIFeatures.test("windowGhost")) return SYNO.SDS.BaseWindow.superclass.createGhost.apply(this, arguments);
        var s = this.el.dom,
            n = document.createElement("div"),
            o = n.style;
        return n.className = "x-panel-ghost-simple", o.width = s.offsetWidth + "px", o.height = s.offsetHeight + "px", i ? Ext.getDom(i).appendChild(n) : this.container.dom.appendChild(n), new Ext.Element(n)
    },
    isModalized: function() {
        return !1
    },
    hasOwnerWin: function(t) {
        var e = this;
        do {
            if (t === e) return !0;
            e = e.owner
        } while (e);
        return !1
    },
    getTopWin: function() {
        for (var t = this; t.owner;) t = t.owner;
        return t
    },
    getGroupWinAccessTime: function() {
        var t = this._lastAccess || 0;
        return Ext.each(this.modalWin, function(e) {
            e && e._lastAccess && e._lastAccess > t && (t = e._lastAccess)
        }), Ext.each(this.siblingWin, function(e) {
            e && e._lastAccess && e._lastAccess > t && (t = e._lastAccess)
        }), t
    },
    getMsgBox: function(t) {
        if (!this.msgBox || this.msgBox.isDestroyed) {
            var e = t && t.owner || this;
            e = e.isDestroyed ? null : e, this.isV5Style() ? this.msgBox = new SYNO.SDS.MessageBoxV5({
                owner: e,
                preventDelay: t && t.preventDelay || !1,
                draggable: t && t.draggable || !1
            }) : this.msgBox = new SYNO.SDS.MessageBox({
                owner: e
            })
        }
        return this.msgBox.getWrapper(t)
    },
    getToastBox: function(t, e, i, s) {
        this.toastBox && !this.toastBox.isDestroyed && this.toastBox.destroy();
        var n = {
            text: t,
            closable: e,
            owner: this
        };
        return Ext.isObject(i) && (Ext.isString(i.text) && (n.actionText = i.text), Ext.isFunction(i.fn) && (n.actionHandler = i.fn), Ext.isObject(i.scope) && (n.actionHandlerScope = i.scope)), Ext.isObject(s) && (Ext.isNumber(s.delay) && (n.delay = s.delay), Ext.isNumber(s.offsetY) && (n.offsetY = s.offsetY), Ext.isNumber(s.offsetX) && (n.offsetX = s.offsetX), Ext.isDefined(s.alignEl) && (n.alignEl = s.alignEl), n.alignBottom = !0 === s.alignBottom), this.toastBox = new SYNO.SDS.ToastBox(n), this.toastBox
    },
    onBeforeDestroy: function() {
        function t(t) {
            t && t.destroy()
        }
        this.msgBox && this.msgBox.destroy(), this.toastBox && this.toastBox.destroy(), Ext.each(this.modalWin, t), Ext.each(this.siblingWin, t), delete this.msgBox, delete this.modalWin, delete this.siblingWin, delete this.maskTask, SYNO.SDS.BaseWindow.superclass.onBeforeDestroy.apply(this, arguments)
    },
    onMinimize: function() {
        function t(t) {
            t && (t.hideForMinimize = !0, t.minimize())
        }
        SYNO.SDS.BaseWindow.superclass.onMinimize.apply(this, arguments), Ext.each(this.modalWin, t), Ext.each(this.siblingWin, t)
    },
    applyToAllWindows: function(t) {
        Ext.each(this.modalWin, t), Ext.each(this.siblingWin, t)
    },
    addClassToAllWindows: function(t) {
        this.el.addClass(t), this.applyToAllWindows(function(e) {
            e.addClassToAllWindows(t)
        })
    },
    removeClassFromAllWindows: function(t) {
        this.el.removeClass(t), this.applyToAllWindows(function(e) {
            e.removeClassFromAllWindows(t)
        })
    },
    disableAllShadow: function() {
        this.el.disableShadow(), this.applyToAllWindows(function(t) {
            t.disableAllShadow()
        })
    },
    onClose: function() {
        var t;

        function e(t) {
            return !t || (t.close(), t.isDestroyed)
        }
        return Ext.each(this.modalWin, e), Ext.each(this.sinkModalWin, e), this.modalWin.length || Ext.each(this.siblingWin, e), (t = !this.modalWin.length && !this.siblingWin.length) && (t = !1 !== SYNO.SDS.BaseWindow.superclass.onClose.apply(this, arguments)), t
    },
    onActivate: function() {
        var t = this.getTopWin();
        t.taskButton && t.taskButton.setState("active"), this.el.replaceClass("deactive-win", "active-win"), SYNO.SDS.BaseWindow.superclass.onActivate.apply(this, arguments)
    },
    onDeactivate: function() {
        var t = this.getTopWin();
        t.taskButton && t.taskButton.setState("deactive"), this.el.replaceClass("active-win", "deactive-win"), SYNO.SDS.BaseWindow.superclass.onDeactivate.apply(this, arguments), this.el && this.el.enableShadow(!0)
    },
    blinkShadow: function(t) {
        if (this.isV5Style()) return this.blinkShadowV5(t);
        !this.shadow || t <= 0 || (this.el.disableShadow(), function() {
            this.el.enableShadow(!0), this.blinkShadow.createDelegate(this, [--t]).defer(100)
        }.createDelegate(this).defer(100))
    },
    blinkShadowV5: function(t) {
        !this.el || !this.el.isVisible() || t <= 0 || (this.el.addClass("sds-window-v5-no-shadow"), function() {
            this.el && this.el.isVisible() && (this.el.removeClass("sds-window-v5-no-shadow"), this.blinkShadowV5.createDelegate(this, [--t]).defer(100))
        }.createDelegate(this).defer(100))
    },
    synchronizedMask: function(t) {
        this.mask(t)
    },
    delayedMask: function(t, e) {
        e = Ext.isNumber(e) ? e : 200, this.maskTask || (this.maskTask = new Ext.util.DelayedTask(this.setMaskOpacity, this, [t])), this.mask(0), this.maskTask.delay(e)
    },
    setMaskOpacity: function(t) {
        if (this.el.dom) {
            var e = Ext.Element.data(this.el.dom, "mask");
            e && e.setOpacity(t)
        }
    },
    mask: function(t, e, i, s) {
        if (!this.isDestroyed)
            if (t = Ext.isNumber(t) ? t : 0, this.maskCnt++, this.maskCnt > 1) this.setMaskOpacity(t, s);
            else {
                var n = this.el.mask(e, i);
                n.addClass("sds-window-mask"), this.mon(n, "mousedown", this.blinkModalChild, this), this.setMaskOpacity(t, s)
            }
    },
    unmask: function() {
        if (!(this.isDestroyed || --this.maskCnt > 0)) {
            this.maskCnt = 0, this.maskTask && this.maskTask.cancel();
            var t = Ext.Element.data(this.el, "mask");
            this.mun(t, "mousedown", this.blinkModalChild, this), this.el.unmask()
        }
    },
    blinkModalChild: function() {
        if (SYNO.SDS.WindowMgr) {
            this.modalWin.sort(SYNO.SDS.WindowMgr.sortWindows);
            var t = this.modalWin[this.modalWin.length - 1];
            t ? t.blinkModalChild() : this.isModalized() && (this.toFront(), this.blinkShadow(3))
        }
    },
    clearStatus: function(t) {
        var e = this.getFooterToolbar();
        e && Ext.isFunction(e.clearStatus) && e.clearStatus(t)
    },
    clearStatusBusy: function(t) {
        this.unmask(), 0 === this.maskCnt && this.clearStatus(t)
    },
    setStatus: function(t) {
        t = t || {};
        var e = this.getFooterToolbar();
        e && Ext.isFunction(e.setStatus) && e.setStatus(t)
    },
    setStatusOK: function(t) {
        t = t || {}, Ext.applyIf(t, {
            text: _T("common", "setting_applied"),
            iconCls: this.isV5Style() ? "syno-ux-statusbar-success" : "x-status-valid",
            clear: !0
        }), this.setStatus(t)
    },
    setStatusError: function(t) {
        t = t || {}, Ext.applyIf(t, {
            text: _T("common", "error_system"),
            iconCls: this.isV5Style() ? "syno-ux-statusbar-error" : "x-status-error"
        }), this.setStatus(t)
    },
    setStatusBusy: function(t, e, i) {
        t = t || {}, Ext.applyIf(t, {
            text: _T("common", "loading"),
            iconCls: this.isV5Style() ? "syno-ux-statusbar-loading" : "x-status-busy"
        }), this.setStatus(t), this.maskForBusy(e, i)
    },
    maskForBusy: function(t, e) {
        t = Ext.isNumber(t) ? t : .4, (e = Ext.isNumber(e) ? e : 400) > 0 ? this.delayedMask(t, e) : this.synchronizedMask(t)
    },
    hide: function() {
        this.maximized || (this.restoreSize = this.getSize(), this.restorePos = this.getPosition(!0)), this.addClass("syno-window-hide"), SYNO.SDS.BaseWindow.superclass.hide.apply(this, arguments)
    },
    centerTitle: function() {
        var t, e = 0;
        this.tools && (Ext.each(["help", "minimize", "maximize", "close"], function(t) {
            this.tools[t] && (e += 32)
        }, this), this.header && (t = this.header.child(".x-window-header-text")) && t.setStyle("padding-left", e + "px"))
    },
    fillPadding: function(t) {
        var e;
        if (!(e = this.getFirstItem(t))) return t;
        this.isGridPanel(e) || this.isFormPanel(e) ? this.fillWindowPadding(t) : this.isTabPanel(e) && this.hasItems(e) && this.fillWindowPadding(t)
    },
    hasItems: function(t) {
        return !!Ext.isArray(t.items) || t.items instanceof Ext.util.MixedCollection
    },
    fillWindowPadding: function(t) {
        Ext.applyIf(t, {
            padding: "0 20px"
        })
    },
    getFirstItem: function(t) {
        var e;
        return Ext.isArray(t.items) && 1 === t.items.length ? e = t.items[0] : Ext.isObject(t.items) && (e = t.items), e
    },
    isTabPanel: function(t) {
        return this.isPanelOf(t, Ext.TabPanel, ["tabpanel", "syno_tabpanel"])
    },
    isFormPanel: function(t) {
        return this.isPanelOf(t, Ext.form.FormPanel, ["form", "syno_formpanel"])
    },
    isGridPanel: function(t) {
        return this.isPanelOf(t, Ext.grid.GridPanel, ["grid", "syno_gridpanel"])
    },
    isPanelOf: function(t, e, i) {
        var s, n, o;
        if (!t) return !1;
        if (t instanceof e) return !0;
        for (s = t.xtype, n = 0, o = i.length; n < o; n++)
            if (s === i[n]) return !0;
        return !1
    },
    destroy: function() {
        this.isDestroyed || !1 !== this.fireEvent("beforedestroy", this) && (this.destroying = !0, this.focusStack && (this.focusStack = null), this.restoreWindowFocus(), SYNO.SDS.BaseWindow.superclass.destroy.call(this))
    }
}), Ext.namespace("SYNO.SDS.Window"), SYNO.SDS.Window = Ext.extend(SYNO.SDS.BaseWindow, {
    constructor: function(t) {
        t = Ext.apply({
            minimizable: !1
        }, t), SYNO.SDS.Window.superclass.constructor.call(this, t), this.owner && Ext.isArray(this.owner.siblingWin) && this.owner.siblingWin.push(this)
    },
    onBeforeDestroy: function() {
        this.owner && Ext.isArray(this.owner.siblingWin) && this.owner.siblingWin.remove(this), SYNO.SDS.Window.superclass.onBeforeDestroy.apply(this, arguments)
    },
    onMinimize: function() {
        this.hide(), SYNO.SDS.Window.superclass.onMinimize.apply(this, arguments)
    },
    isAlwaysOnTop: function() {
        return _S("standalone")
    }
}), Ext.namespace("SYNO.SDS.ModalWindow"), SYNO.SDS.ModalWindow = Ext.extend(SYNO.SDS.BaseWindow, {
    ownerMasked: !1,
    constructor: function(t) {
        t = Ext.apply({
            useStatusBar: !0,
            closable: !0,
            maximizable: !1,
            minimizable: !1,
            modal: !t.owner
        }, t), SYNO.SDS.ModalWindow.superclass.constructor.call(this, t)
    },
    afterRender: function() {
        var t, e, i;
        t = SYNO.SDS.Desktop ? SYNO.SDS.Desktop.getEl().getHeight() : Ext.lib.Dom.getViewHeight(), SYNO.SDS.ModalWindow.superclass.afterRender.apply(this, arguments), this.alignTo(this.owner ? this.owner.el : document.body, "c-c"), e = this.el.getHeight(), this.el.getTop() + e > t && (i = t - e - 20, this.el.setTop.defer(100, this.el, [i > 0 ? i : 0])), "emphasized" === this.popupStyle && this.el.addClass("syno-em-window")
    },
    isModalized: function() {
        return !0
    },
    hideFromOwner: function() {
        if (this.owner) {
            var t = this.sinkable ? "sinkModalWin" : "modalWin";
            return Ext.isArray(this.owner[t]) && this.owner[t].remove(this), this.ownerMasked && (this.owner.unmask(!0), this.ownerMasked = !1), !0
        }
        return !1
    },
    afterShow: function() {
        SYNO.SDS.ModalWindow.superclass.afterShow.apply(this, arguments), this.owner && this.sinkable ? this.owner.sinkModalWin.push(this) : !this.ownerMasked && this.owner && (this.owner.modalWin.push(this), this.owner.mask(0, null, null, !0), this.ownerMasked = !0)
    },
    afterHide: function() {
        SYNO.SDS.ModalWindow.superclass.afterHide.apply(this, arguments), this.hideForMinimize || this.hideFromOwner()
    },
    onBeforeDestroy: function() {
        this.hideFromOwner() && (this.owner = null), SYNO.SDS.ModalWindow.superclass.onBeforeDestroy.apply(this, arguments)
    },
    onMinimize: function() {
        this.hide(), SYNO.SDS.ModalWindow.superclass.onMinimize.apply(this, arguments)
    },
    onWindowClose: function() {
        this.owner ? this.owner.focus() : Ext.get("sds-taskbar-startbutton").child("button").focus()
    }
}), Ext.define("SYNO.SDS.BackgroundTpl", {
    extend: "Ext.XTemplate",
    defaultConf: {
        type: "fill",
        imgSrc: Ext.BLANK_IMAGE_URL,
        imgW: 0,
        imgH: 0,
        bgColor: "#FFFFFF",
        winW: Ext.lib.Dom.getViewWidth(),
        winH: Ext.lib.Dom.getViewHeight(),
        cls: ""
    },
    constructor: function(t) {
        Ext.apply(this, this.defaultConf), Ext.apply(this, t), this.id || (this.id = Ext.id()), "fill" === this.type || "fit" === this.type ? this.useFitFillTpl() : "center" === this.type ? this.useCenterTpl() : "stretch" === this.type ? this.useStretchTpl() : "tile" === this.type ? this.useTileTpl() : SYNO.Debug.warn("No such background template")
    },
    useFitFillTpl: function() {
        SYNO.SDS.BackgroundTpl.superclass.constructor.call(this, '<div id="{id}" class="{cls}"; style="background-color: {bgColor}; width: {winW}px; height: {winH}px; visibility: visible;">', '<tpl if="(this.imgSizeSet)">', '<img id={imgId} style="position: absolute; visibility: visible; width: {bgW}px; height: {bgH}px; left: {left}px; top: {top}px;" src="{imgSrc}" draggable="false">', "</tpl>", '<tpl if="(!this.imgSizeSet)">', '<img id={imgId} style="position: absolute; visibility: visible;" src="{imgSrc}" draggable="false">', "</tpl>", "</div>")
    },
    useStretchTpl: function() {
        SYNO.SDS.BackgroundTpl.superclass.constructor.call(this, '<div id="{id}" class="{cls}"; style="background-color: {bgColor}; width: {winW}px; height: {winH}px; visibility: visible;">', '<img id={imgId} style="position: absolute; visibility: visible; width: 100%; height: 100%" src="{imgSrc}" draggable="false">', "</div>")
    },
    useCenterTpl: function() {
        SYNO.SDS.BackgroundTpl.superclass.constructor.call(this, '<div id="{id}" class="{cls}"; style="width: {winW}px; height: {winH}px; background-color: {bgColor}; background-image: url({imgSrc}); background-position: 50% 50%; background-repeat: no-repeat; visibility: visible;"></div>')
    },
    useTileTpl: function() {
        SYNO.SDS.BackgroundTpl.superclass.constructor.call(this, '<div id="{id}" class="{cls}"; style="width: {winW}px; height: {winH}px; background-color: {bgColor}; background-image: url({imgSrc}); background-repeat: repeat; visibility: visible;"></div>')
    },
    setImgSize: function(t, e) {
        this.imgW = t, this.imgH = e, this.imgSizeSet = !0
    },
    getFillConfig: function() {
        var t = this.winH,
            e = this.winW,
            i = this.imgW / this.imgH;
        return e > t * i ? this.fitByWidth(e, t, i) : this.fitByHeight(e, t, i)
    },
    getFitConfig: function() {
        var t = this.winH,
            e = this.winW,
            i = this.imgW / this.imgH;
        return e > t * i ? this.fitByHeight(e, t, i) : this.fitByWidth(e, t, i)
    },
    fitByWidth: function(t, e, i) {
        return {
            bgW: t,
            bgH: t / i,
            left: 0,
            top: (e - t / i) / 2
        }
    },
    fitByHeight: function(t, e, i) {
        return {
            bgW: e * i,
            bgH: e,
            left: (t - e * i) / 2,
            top: 0
        }
    },
    fill: function(t) {
        var e;
        switch (Ext.apply(this, t), this.type) {
            case "fill":
                e = this.getFillConfig();
                break;
            case "fit":
                e = this.getFitConfig()
        }
        return Ext.apply(this, e), this.applyTemplate(this)
    }
}), Ext.define("SYNO.SDS.Background", {
    extend: "Ext.Container",
    constructor: function(t) {
        Ext.apply(this, t), this.imgId = Ext.id(), this.backgroundTpl = new SYNO.SDS.BackgroundTpl({
            type: t.type,
            imgSrc: t.imgSrc,
            imgId: this.imgId,
            bgColor: t.bgColor
        }), this.bgWallpaper = new Ext.BoxComponent({
            html: this.backgroundTpl.fill({
                winW: Ext.lib.Dom.getViewWidth(),
                winH: Ext.lib.Dom.getViewHeight()
            })
        }), "fit" !== this.type && "fill" !== this.type || this.bgWallpaper.on("afterrender", this.updateImgSize, this, {
            single: !0
        });
        var e = {
            id: t.id,
            width: Ext.lib.Dom.getViewWidth(),
            height: Ext.lib.Dom.getViewHeight(),
            items: [this.bgWallpaper]
        };
        SYNO.SDS.Background.superclass.constructor.call(this, e), this.mon(this, "beforedestroy", function() {
            this.backgroundTpl = null
        }, this)
    },
    updateImgSize: function() {
        var t = Ext.fly(this.imgId);
        if (Ext.isIE || Ext.isModernIE) {
            var e = new Image;
            if (Ext.isIE8) {
                var i = new Date;
                t.dom.src += "&nocache=" + i.getTime()
            }
            e.src = t.dom.src, Ext.fly(e).on("load", this.onImgLoad, this)
        } else t.on("load", this.onImgLoad, this)
    },
    onImgLoad: function() {
        var t = Ext.fly(this.imgId);
        Ext.isEmpty(this.backgroundTpl) || (this.backgroundTpl.setImgSize(t.getWidth(), t.getHeight()), this.resize())
    },
    resize: function() {
        var t = Ext.lib.Dom.getViewWidth(),
            e = Ext.lib.Dom.getViewHeight();
        this.setSize(t, e), this.bgWallpaper.el.dom && (this.bgWallpaper.el.dom.innerHTML = this.backgroundTpl.fill({
            winW: t,
            winH: e
        })), this.doLayout()
    }
}), Ext.define("SYNO.SDS.LoginStyleParser", {
    extend: "Ext.util.Observable",
    constructor: function(t) {
        this.isPreview = t.isPreview, this.isBusiness = t.isBusiness, this.parseAppPortalName(), this.parseTpl(), this.callParent()
    },
    getParam: function(t) {
        var e;
        return this.isPreview && window.opener && window.opener.previewParam ? (e = window.opener.previewParam[t], Ext.isBoolean(e) || (e = Ext.util.Format.htmlEncode(e))) : e = _S(t), e
    },
    parseAppPortalName: function() {
        var t = _S("preview_appName") || _S("appName");
        this.appName = t ? t + "_" : ""
    },
    parseTpl: function() {
        var t = this.getParam("login_style");
        this.tpl = "dark" === t ? "dark" : "light"
    },
    getLoginConfig: function() {
        var t = {
            tplName: this.tpl,
            preview: this.isPreview
        };
        return Ext.apply(t, this.getTitleConf()), Ext.apply(t, this.getCustomizeLogoConf()), Ext.apply(t, this.getWelcomeMsgConf()), Ext.apply(t, this.getBkgConf()), Ext.apply(t, this.getVersionLogoConf()), Ext.apply(t, this.getFooterConf()), t
    },
    getBkgConf: function() {
        var t = this.getRawBkgConf(),
            e = t.background_enable,
            i = t.only_bgcolor;
        return e ? this.isPreview && this.getParam("new_background") ? t.background_path = this.getEncodedPathUrl(this.getParam("login_background_path")) : t.background_path = this.getBuiltInPath(t) : i ? t.background_path = Ext.BLANK_IMAGE_URL : t = this.getDefaultBkgConf(), t
    },
    getVersionLogoConf: function() {
        var t = this.getParam("login_version_logo");
        return {
            versionLogo: !Ext.isDefined(t) || t
        }
    },
    getRawBkgConf: function() {
        return {
            background_enable: this.getParam("login_background_enable"),
            background_hd_enable: _S("login_background_hd_enable"),
            background_pos: this.getParam("login_background_pos") || "fill",
            only_bgcolor: this.getParam("login_only_bgcolor"),
            background_color: this.getParam("login_background_color") || "#FFFFFF",
            ext: _S("login_background_ext"),
            idx: _S("login_background_seq"),
            background_width: _S("login_background_width"),
            background_height: _S("login_background_height")
        }
    },
    getDefaultBkgConf: function() {
        var t, e = this.isRetina(),
            i = String.format("webman/resources/images/default/{0}/default_login_background/", e ? "2x" : "1x"),
            s = {
                background_pos: "fill",
                background_path: i + "dsm6_02.jpg?v=" + _S("version"),
                background_color: "#505050"
            },
            n = {
                background_pos: "fill",
                background_path: i + "dsm6_01.jpg?v=" + _S("version"),
                background_color: "#4c8fbf"
            };
        if (t = "dark" === this.tpl ? s : n, SYNO.SDS.isCompatibleMode()) {
            var o = this.getPkgDefBgPath(!0);
            null !== o ? t.background_path = o : (i = "webman/resources/images/2x/default_login_background/", t.background_path = i + "dsm7_01.jpg?v=" + _S("version"))
        }
        return t
    },
    isRetina: function() {
        return SYNO.SDS.UIFeatures.IconSizeManager.getRetinaAndSynohdpackStatus()
    },
    isBuiltInBkg2X: function() {
        var t = "default" === this.getParam("login_background_type"),
            e = this.isRetina();
        return t && e
    },
    getEncodedPathUrl: function(t) {
        if (SYNO.SDS.isCompatibleMode() && this.isPreview && "pkgDefault" === this.getParam("login_background_type")) return t.replace("/usr/syno/synoman/", "");
        var e = new Date;
        return Ext.urlAppend("webapi/entry.cgi", Ext.urlEncode({
            api: "SYNO.Core.PersonalSettings",
            method: "wallpaper",
            version: 1,
            path: Ext.encode(SYNO.SDS.Utils.bin2hex(t)),
            preview: e.getTime()
        }))
    },
    getBuiltInPath: function(t) {
        var e = this.isBuiltInBkg2X();
        if (SYNO.SDS.isCompatibleMode()) {
            var i = this.getPkgDefBgPath(e);
            if (null !== i && 0 === t.idx) return i
        }
        return String.format("webman/{0}login_background{1}{2}?id={3}", this.appName, e ? "_hd" : "", t.ext, t.idx)
    },
    getTitleConf: function() {
        return {
            login_title: this.getParam("custom_login_title") || _S("hostname")
        }
    },
    getCustomizeLogoConf: function() {
        var t = {
            logo_enable: this.getParam("login_logo_enable")
        };
        return this.isPreview && t.logo_enable && this.getParam("new_logo") ? t.logo_path = this.getEncodedPathUrl(this.getParam("login_logo_path")) : t.logo_enable && (t.logo_path = "webman/" + this.appName + "login_logo" + _S("login_logo_ext") + "?id=" + _S("login_logo_seq")), t
    },
    getWelcomeMsgConf: function() {
        return {
            login_welcome_title: this.getParam("login_welcome_title") || "",
            login_welcome_msg: this.getParam("login_welcome_msg") || ""
        }
    },
    getFooterConf: function() {
        var t = this.getParam("login_footer_enable_html");
        return {
            login_footer_msg: this.getParam("login_footer_msg") || "",
            login_footer_enable_html: !!Ext.isDefined(t) && t
        }
    },
    getPkgDefBgPath: function(t) {
        return SYNO.SDS.Session && SYNO.SDS.Session.appLoginStyle && SYNO.SDS.Session.appLoginStyle.defaultLoginWallpaper && SYNO.SDS.Session.appLoginStyle.defaultLoginWallpaperThumbnail ? String.format(SYNO.SDS.Session.appLoginStyle.defaultLoginWallpaper, t ? "2x" : "1x") : null
    }
}), SYNO.SDS.LoginDialog = Ext.extend(Ext.Container, {
    tplConfig: null,
    constructor: function(t) {
        this.isAppPortal = !!_S("appIconPath");
        var e = [];
        t = t || {}, this.tplConfig = this.getTplConfig(t.preview), this.createBackground(), this.createWelcomeInfo(), this.createDialog(), this.createFooterInfo(), e.push(this.backgound), this.footer && e.push(this.footer), this.welcomeInfo && e.push(this.welcomeInfo), e.push(this.dialog), this.isAppPortal && (this.createAppIcon(), e.push(this.appIcon));
        var i = {
            id: "sds-login",
            cls: String.format("sds-login-{0} {1}", this.tplConfig.tplName, this.isAppPortal ? "app-portal" : ""),
            renderTo: document.body,
            items: e,
            listeners: {
                afterrender: {
                    fn: this.createOSLogo,
                    scope: this
                }
            }
        };
        SYNO.SDS.LoginDialog.superclass.constructor.call(this, Ext.apply(i, t)), Ext.EventManager.onWindowResize(this.onWindowResize, this), this.el.applyStyles("background-color: " + this.tplConfig.background_color), this.onWindowResize(), t.preview || Ext.getDom("login_username") && Ext.getDom("login_username").focus(), Ext.isSafari && Ext.defer(this.onWindowResize, 1e3, this)
    },
    createOSLogo: function() {
        if (this.tplConfig.versionLogo) {
            var t = "light" === this.tplConfig.tplName;
            this.osLogo = new SYNO.SDS.DSMLogo({
                id: "sds-login-logo",
                theme: t ? "light" : "dark",
                renderTo: Ext.get("sds-login")
            })
        }
    },
    createBackground: function() {
        this.backgound = SYNO.SDS.LoginUtils.createBackground(this.tplConfig, "sds-login-background")
    },
    createWelcomeInfo: function() {
        var t = "" !== this.tplConfig.login_welcome_title || "" !== this.tplConfig.login_welcome_msg,
            e = this.tplConfig.logo_enable;
        (t || e) && (this.welcomeInfo = new SYNO.SDS.WelcomeInfo({
            logo_enable: this.tplConfig.logo_enable,
            logo_path: this.tplConfig.logo_path,
            login_welcome_title: this.tplConfig.login_welcome_title,
            login_welcome_msg: this.tplConfig.login_welcome_msg
        }))
    },
    createFooterInfo: function() {
        if (Ext.isDefined(this.tplConfig.login_footer_msg) && "" !== this.tplConfig.login_footer_msg) {
            var t = this.tplConfig.login_footer_msg.replace(/&nbsp;/g, " ");
            !0 === this.tplConfig.login_footer_enable_html && (t = Ext.util.Format.htmlDecode(t));
            var e = new Ext.Container({
                id: "sds-login-footer-msg",
                html: t
            });
            this.footer = new Ext.Container({
                id: "sds-login-footer",
                autoHeight: !0,
                module: this,
                items: [e]
            })
        }
    },
    createDialog: function() {
        var t = new Ext.Container({
            id: "sds-login-dialog-title",
            html: this.tplConfig.login_title,
            autoEl: {
                "ext:qtip": this.tplConfig.login_title
            }
        });
        this.loginForm = this.newForm(), this.dialog = new Ext.Container({
            id: "sds-login-dialog",
            autoHeight: !0,
            module: this,
            items: [t, this.loginForm]
        })
    },
    createAppIcon: function() {
        this.appIcon = new Ext.Container({
            id: "sds-login-icon",
            autoEl: {
                tag: "img",
                src: SYNO.SDS.UIFeatures.IconSizeManager.getAppPortalIconPath(_S("appIconPath"))
            },
            style: String.format("width: {0}px", SYNO.SDS.UIFeatures.IconSizeManager.PortalIcon)
        })
    },
    newForm: function() {
        return new SYNO.SDS.LoginDialog.Form({
            module: this,
            tplConfig: this.tplConfig
        })
    },
    destroy: function() {
        Ext.EventManager.removeResizeListener(this.onWindowResize, this), SYNO.SDS.LoginDialog.superclass.destroy.apply(this, arguments)
    },
    onWindowResize: function() {
        var t = Ext.lib.Dom.getViewWidth(),
            e = Ext.lib.Dom.getViewHeight();
        t < 840 || e < 500 ? this.welcomeInfo && this.welcomeInfo.hide() : this.welcomeInfo && this.welcomeInfo.show(), this.doAlignDialog(), this.doAlignFooter(t), this.backgound.resize(), this.welcomeInfo && this.welcomeInfo.resize();
        var i = Ext.getCmp("sds-login-dialog-combobox");
        i && i.isExpanded() && i.list.alignTo(i.el, i.listAlign[0], i.listAlign[1]), this.updateDialogLayout()
    },
    updateDialogLayout: function() {
        this.doAlignAppIcon()
    },
    doAlignDialog: function() {
        var t = Ext.lib.Dom.getViewHeight() * (.45 - .5);
        Ext.fly("sds-login-dialog").alignTo(document.body, "c-c", [0, -30 + t]), Ext.defer(function() {
            Ext.fly("sds-login-dialog").alignTo(document.body, "c-c", [0, -30 + t])
        }, 500, this)
    },
    doAlignFooter: function(t) {
        if (this.footer) {
            var e = -24;
            this.tplConfig.versionLogo && t <= 864 && (e = -64), this.footer.el.alignTo(document.body, "b-b", [0, e])
        }
    },
    doAlignAppIcon: function() {
        var t = Ext.get("login-inner-panel");
        this.appIcon && t && this.appIcon.el.alignTo(Ext.get("login-inner-panel"), "br-br", [16, 16])
    },
    getTplConfig: function(t) {
        return new SYNO.SDS.LoginStyleParser({
            isPreview: !0 === t,
            isBusiness: SYNO.SDS.isBusinessModel
        }).getLoginConfig()
    }
}), SYNO.SDS.LoginDialog.Form = Ext.extend(SYNO.ux.FormPanel, {
    btnLogin: null,
    iframe: null,
    constructor: function(t) {
        Ext.fly("sds-login-dialog-form").dom.removeAttribute("style"), this.supportForgetPass = 1 === _S("login_enable_fp"), this.isAppPortal = !!_S("appIconPath"), this.isPreview = t.tplConfig.preview, this.createSSOcombobox(t.tplConfig.tplName), this.createInputFields(), this.createLoginBtn(), this.createLinks(), this.createStatus();
        var e = [this.userField, this.passField, this.otpField, this.rememberField, this.trustDeviceField, this.btnLogin, this.forgetPassUrl, this.lostPhoneUrl];
        (this.isSupportSSO() || this.isSupportOIDCSSO()) && e.unshift(this.ssoCombo), this.innerPanel = new SYNO.ux.Panel({
            id: "login-inner-panel",
            cls: "login-inner-panel",
            items: e
        });
        var i = {
            applyTo: "sds-login-dialog-form",
            cls: this.supportForgetPass ? "" : "extra-padding",
            hideMode: "display",
            standardSubmit: !0,
            url: "webman/login.cgi",
            method: "POST",
            width: 320,
            minHeight: 260,
            unstyled: !0,
            autoFlexcroll: !1,
            useGradient: !1,
            listeners: {
                afterlayout: {
                    scope: this,
                    fn: this.onAfterLayout
                },
                afterrender: {
                    scope: this,
                    fn: this.onAfterRender,
                    single: !0
                }
            },
            items: [this.innerPanel, this.statusField, {
                xtype: "hidden",
                name: "__cIpHeRtExT"
            }, {
                xtype: "hidden",
                name: "isIframeLogin",
                value: "yes"
            }, {
                xtype: "hidden",
                name: "enable_device_token"
            }]
        };
        SYNO.SDS.LoginDialog.Form.superclass.constructor.call(this, Ext.apply(i, t)), "no" !== _S("enable_syno_token") && (this.form.url = Ext.urlAppend(this.form.url, "enable_syno_token=" + _S("enable_syno_token")), this.form.el.dom.action = Ext.urlAppend(this.form.el.dom.action, "enable_syno_token=" + _S("enable_syno_token")))
    },
    getUser: function() {
        return this.userField.getValue()
    },
    getPass: function() {
        return this.passField.getValue()
    },
    validURL: function(t) {
        var e = t.replace(/https?:\/\/\[/i, "").replace(/\].*$/, "");
        return !1 !== /^(https?):\/\/(((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:)*@)?(((\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5])\.(\d|[1-9]\d|1\d\d|2[0-4]\d|25[0-5]))|((([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|\d|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.)+(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*([a-z]|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])))\.?)(:\d*)?)(\/((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)+(\/(([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)*)*)?)?(\?((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|[\uE000-\uF8FF]|\/|\?)*)?(\#((([a-z]|\d|-|\.|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])|(%[\da-f]{2})|[!\$&'\(\)\*\+,;=]|:|@)|\/|\?)*)?$/i.test(t) || !1 !== /((^https?):\/\/([a-z]|\d|-|_|~|[\u00A0-\uD7FF\uF900-\uFDCF\uFDF0-\uFFEF])*)(:\d+)?$/i.test(t) || !1 !== Ext.form.VTypes.v6ipVal.test(e) || Ext.form.VTypes.urlText
    },
    createInputFields: function() {
        this.userField = new SYNO.SDS.IconTextfield({
            el: "login_username",
            fieldLabel: _T("common", "username"),
            iconCls: "user-icon"
        }), this.passField = new SYNO.SDS.IconTextfield({
            el: "login_passwd",
            fieldLabel: _T("common", "password"),
            iconCls: "passwd-icon"
        }), this.otpField = new SYNO.SDS.IconTextfield({
            el: "login_otp",
            fieldLabel: _T("login", "enter_otp_desc"),
            iconCls: "otp-icon",
            emptyText: _T("login", "enter_otp_desc"),
            validator: function(t) {
                return !(!/^[0-9]{6}$/.exec(t) && !/^[0-9]{8}$/.exec(t))
            }
        }), this.rememberField = new SYNO.ux.Checkbox({
            id: "login_rememberme",
            name: "rememberme",
            width: 296,
            hideLabel: !0,
            boxLabel: _T("login", "rememberme"),
            disabled: !1
        }), this.trustDeviceField = new SYNO.ux.Checkbox({
            id: "login_trudtdevice",
            name: "trustdevice",
            width: 296,
            boxLabel: _T("login", "trustdevice"),
            disabled: !1
        })
    },
    createLinks: function() {
        this.lostPhoneUrl = new SYNO.ux.Button({
            id: "lost_phone",
            cls: "link",
            hidden: !0,
            text: _T("login", "otp_lost_phone_desc"),
            scope: this,
            handler: this.lostPhone
        }), this.forgetPassUrl = new SYNO.ux.Button({
            id: "forget_pass",
            cls: "link",
            hidden: 1 !== _S("login_enable_fp"),
            text: _T("login", "forget_pass_link"),
            scope: this,
            handler: this.onForgetPass
        })
    },
    createStatus: function() {
        this.statusField = new Ext.form.DisplayField({
            id: "sds-login-dialog-status",
            hideLabel: !0,
            hidden: !0,
            value: "",
            listeners: {
                afterrender: function() {
                    this.el.setARIA({
                        role: "log",
                        live: "assertive"
                    })
                },
                scope: this
            }
        })
    },
    createSSOcombobox: function(t) {
        var e = this.isSupportSSO(),
            i = this.isSupportOIDCSSO(),
            s = [
                ["local", _T("sso", "account_login")]
            ];
        e && s.push(["sso", _T("sso", "sso_login")]), i && s.push(["oidc_sso", _T("sso", _S("oidc_sso_profile") + "_sso_login")]), (e || i) && (this.ssoCombo = new SYNO.ux.ComboBox({
            xtype: "syno_combobox",
            width: 320,
            id: "sds-login-dialog-combobox",
            listClass: "sds-login-" + t + " syno-ux-combobox-list sds-login-dialog-combobox-list",
            triggerClass: "sds-login-dialog-combobox-trigger",
            listAlign: ["tl-bl?", [0, 6]],
            forceSelection: !0,
            typeAhead: !0,
            triggerAction: "all",
            lazyRender: !0,
            allowBlank: !1,
            displayField: "display",
            valueField: "value",
            value: "local",
            hidden: !0,
            tpl: '<tpl for="."><div ext:qtip="{display}" class="x-combo-list-item">{display}</div></tpl>',
            store: new Ext.data.ArrayStore({
                fields: ["value", "display"],
                data: s
            }),
            listeners: {
                scope: this,
                expand: function(t) {
                    t.list.setZIndex(19999)
                },
                select: function(t, e, i) {
                    this.onLoginTypeChange(e.get("value"))
                }
            }
        }))
    },
    createLoginBtn: function(t) {
        this.btnLogin = new SYNO.ux.Button({
            xtype: "syno_button",
            btnStyle: "blue",
            text: _T("common", "dsm_login"),
            id: "login-btn",
            width: 280,
            height: 40,
            scope: this,
            disabled: t,
            handler: this.onClickLogin
        })
    },
    onAfterLayout: function() {
        if (!this.initLayout) return SYNO.SDS.SSOUtils.init(Ext.emptyFn, this), void(this.initLayout = !0)
    },
    onAfterRender: function() {
        this.otpField.hide(), this.trustDeviceField.hide(), this.rememberField.setValue("1" === Ext.util.Cookies.get("stay_login")), this.form.el.dom.onsubmit = this.onSubmit.createDelegate(this), this.showLoginComboBox(), this.isPreview && this.setFormDisabled(!0)
    },
    onForgetPass: function() {
        var t = this.module;
        t.el.fadeOut({
            callback: function() {
                t.destroy(), (new SYNO.SDS.ForgotPassPage).el.fadeIn({
                    duration: 1
                })
            }
        })
    },
    setFormRemove: function() {
        this.userField.hide(), this.btnLogin.hide()
    },
    setFormDisabled: function(t, e) {
        this.userField.setDisabled(t), this.passField.setDisabled(t), this.rememberField.setDisabled(t), this.forgetPassUrl.setDisabled(t), this.btnLogin.setDisabled(t), this.trustDeviceField.setDisabled(t), e && (this.userField.setDisabled(!1), this.passField.setDisabled(!1))
    },
    initIFrameEvent: function() {
        var t = this;
        t.iframe || (t.iframe = Ext.get("login_iframe"), Ext.isIE ? t.iframe.dom.onreadystatechange = function() {
            "complete" !== this.readyState && "loaded" !== this.readyState || t.onCallback()
        } : t.iframe.dom.onload = function() {
            t.onCallback()
        })
    },
    onClickLogin: function() {
        if (!1 === this.onSSOLogin()) {
            Ext.getDom("login_submit").click();
            var t = this.ssoCombo;
            t && (t.isExpanded() && t.collapse(), t.setDisabled(!0))
        }
    },
    isSlowModel: function() {
        var t = _D("unique");
        return ["synology_armada370_216se", "synology_armada370_ds115j", "synology_armada370_rs214", "synology_armada370_414slim", "synology_armada370_214se", "synology_armada370_114", "synology_armada370_213j", "synology_88f6282_413j", "synology_88f6282_213", "synology_88f6282_213air", "synology_88f6282_rs812", "synology_88f6282_rs212", "synology_x86_712+", "synology_88f6282_212+", "synology_88f6282_212", "synology_88f6281_212j", "synology_88f6282_112+", "synology_88f6282_112", "synology_88f6281_112j", "synology_88f6282_411", "synology_88f6281_411j", "synology_88f6282_411slim", "synology_88f6282_211+", "synology_88f6282_211", "synology_88f6281_211j", "synology_88f6282_111"].indexOf(t) >= 0
    },
    onSubmit: function() {
        return this.blShowOTPField && !this.otpField.validate() ? (this.setMsg(_T("login", "otp_wrong_input_format")), !1) : (Ext.getDom("login_submit").focus(), this.setFormDisabled(!0), this.setMsg(_T("common", "msg_waiting")), this.isResponed = !1, this.isSlowModel() && window.setTimeout(function() {
            this.isResponed || this.setMsg(_T("login", "error_system_getting_ready"))
        }.bind(this), 2e4), SYNO.API.currentManager.requestAPI("SYNO.API.Encryption", "getinfo", 1, {
            format: "module"
        }, this.onEncryptParams, this), !1)
    },
    stdTimezone: function() {
        var t = (new Date).getFullYear(),
            e = new Date(t, 0, 1),
            i = new Date(t, 6, 1);
        return e.getTimezoneOffset() >= i.getTimezoneOffset() ? e.format("P") : i.format("P")
    },
    onEncryptParams: function(t, e, i) {
        var s, n = this.form.findField("__cIpHeRtExT"),
            o = this.form.findField("enable_device_token");
        t && (SYNO.Encryption.CipherKey = e.cipherkey, SYNO.Encryption.RSAModulus = e.public_key, SYNO.Encryption.CipherToken = e.ciphertoken, SYNO.Encryption.TimeBias = e.server_time - Math.floor(+new Date / 1e3));
        var r, a = "local";
        this.ssoCombo && (a = this.ssoCombo.getValue()), r = {
            username: this.getUser(),
            passwd: this.getPass(),
            logintype: a,
            OTPcode: this.otpField.getValue(),
            rememberme: this.rememberField.getValue() ? 1 : 0,
            timezone: this.stdTimezone()
        }, s = SYNO.Encryption.EncryptParam(r)[e.cipherkey] || "", n.setValue(s), o.setValue(this.trustDeviceField.getValue() ? "yes" : "no");
        var l = new Date;
        l.setDate(l.getDate() + 60), Ext.util.Cookies.set("stay_login", this.rememberField.getValue() ? 1 : 0, l);
        var c = "" === s;
        this.initIFrameEvent(), !c || navigator && !navigator.onLine || window.alert(_T("login", "error_key_invalid")), this.setFormDisabled(!0, c), this.form.el.dom.submit()
    },
    launchOTPwizard: function() {
        var t = new SYNO.SDS.LoginStyleParser({
                isPreview: !1,
                isBusiness: "business" === _S("theme_cls")
            }).getDefaultBkgConf().background_path,
            e = Ext.get("sds-login-background").dom.firstChild;
        e && (e.style.display = "none"), new SYNO.SDS.Background({
            id: "sds-steup-otp-background",
            renderTo: "sds-login-background",
            type: "fill",
            imgSrc: t,
            tplName: "tpl1"
        }), this.module.welcomeInfo && (this.module.welcomeInfo.destroy(), this.module.welcomeInfo = null);
        var i = Ext.get("sds-login-icon");
        i && i.hide(), Ext.get("sds-login-dialog").hide();
        var s = {
            module: this,
            username: this.getUser(),
            passwd: this.getPass(),
            isLDAP: this.isLDAP,
            modal: !1,
            draggable: !1,
            closable: !1,
            renderTo: "sds-login"
        };
        this.OTPwizard = new SYNO.SDS.EnforceOTPWizard(s), this.OTPwizard.onOpen()
    },
    onCallback: function() {
        var t, e, i = !1;
        this.isResponed = !0;
        try {
            e = Ext.fly(this.iframe.dom.contentWindow.document.body).first("#synology", !0);
            var s = Ext.util.Format.htmlDecode(e.innerHTML);
            if (!0 === (t = Ext.decode(s)).success && !0 === t.setup_otp) this.isLDAP = t.is_ldap, this.launchOTPwizard();
            else if (!0 === t.success) Ext.isEmpty(SYNO.SDS.Session) && (SYNO.SDS.Session = {}), Ext.isEmpty(t.SynoToken) || (SYNO.SDS.Session.SynoToken = encodeURIComponent(t.SynoToken)), i = !0, SYNO.SDS.initData(), this.setMsg(_T("common", "loading")), Ext.isIE ? this.iframe.dom.onreadystatechange = Ext.emptyFn : this.iframe.dom.onload = Ext.emptyFn, this.iframe.dom.src = "about:blank";
            else if (t.request_pwdchange)
                if (t.external_url) {
                    var n = Ext.urlAppend(t.external_url, Ext.urlEncode({
                        callback_url: window.location.href
                    }), !1);
                    window.location.href = n
                } else {
                    var o = this.module,
                        r = this.getUser(),
                        a = this.getPass(),
                        l = window.location.pathname,
                        c = "error_pwd_expired" === t.reason ? _T("passwd", "passwd_expired") : _T("passwd", "passwd_stronger");
                    o.el.fadeOut({
                        callback: function() {
                            o.destroy(), new SYNO.SDS.ChangeUserPassPage({
                                title: c,
                                username: r,
                                passwd: a,
                                path: l
                            }).el.fadeIn({
                                duration: 1
                            })
                        }
                    })
                }
            else if (!0 === t.request_otp) this.blShowOTPField = !0, this.clearMsg();
            else if (t.reason) {
                if ("error_otp_failed" === t.reason) this.blShowOTPField = !0;
                else {
                    this.passField.setValue(""), this.passField.focus("", 1);
                    var d = Ext.getCmp("sds-login-dialog-combobox");
                    d && d.setDisabled(!1)
                }
                this.setError(_T("login", t.reason))
            } else this.setError(_T("common", "error_system"))
        } catch (t) {
            _T("common", "error_system")
        }
        this.setFormDisabled(!1), this.blShowOTPField ? (this.showOTPField(), i || "error_otp_failed" !== t.reason || (this.otpField.setValue(""), this.otpField.focus("", 1))) : i || "error_otp_failed" == t.reason || Ext.getDom("login_passwd").focus(), this.isSupportSSO() && "login" === SYNOSSO.status && !i && SYNOSSO.logout(Ext.emptyFn)
    },
    showOTPField: function() {
        this.forgetPassUrl.hide(), this.userField.hide(), this.passField.hide(), this.otpField.show(), this.trustDeviceField.show(), this.rememberField.hide(), this.lostPhoneUrl.show(), this.otpField.focus(), this.hideLoginComboBox(), this.hideAppIcon()
    },
    hideAppIcon: function() {
        this.isAppPortal && (this.module.removeClass("app-portal"), this.module.appIcon.hide())
    },
    lostPhone: function() {
        this.sendWebAPI({
            api: "SYNO.Core.OTP.Mail",
            method: "send",
            version: 1,
            params: {
                username: this.getUser()
            },
            scope: this,
            callback: function(t, e, i) {
                var s = _T("login", "unknown_otp_err");
                t ? this.setMsg(_T("login", "otp_mail_success")) : e.errors && e.errors.err ? this.setError(_T("login", e.errors.err)) : this.setError(s)
            }
        })
    },
    setError: function(t) {
        this.statusField.addClass("error"), this.setStatus(t)
    },
    setMsg: function(t) {
        this.statusField.removeClass("error"), this.setStatus(t)
    },
    clearMsg: function() {
        this.statusField.setValue(""), this.statusField.removeClass("error"), this.statusField.hide()
    },
    setStatus: function(t) {
        this.statusField.setValue(t), this.statusField.show(), this.module.doAlignAppIcon()
    },
    isSupportSSO: function() {
        return SYNO.SDS.SSOUtils.isSupport()
    },
    isSupportOIDCSSO: function() {
        if (!(_S("oidc_sso_enable") && "https:" === location.protocol)) return !1;
        if (!_S("oidc_redirect_uri")) return !1;
        if (!this.validURL(_S("oidc_redirect_uri"))) return !1;
        var t = document.createElement("a");
        return t.href = _S("oidc_redirect_uri"), t.hostname === location.hostname
    },
    onLoginTypeChange: function(t) {
        var e = "local" === t,
            i = e && this.supportForgetPass;
        this.userField.setVisible(e), this.passField.setVisible(e), this.forgetPassUrl.setVisible(i), i ? this.el.removeClass("extra-padding") : this.el.addClass("extra-padding"), Ext.getCmp("login-btn").setText(e ? _T("common", "dsm_login") : _T("common", "alt_next")), Ext.util.Cookies.set("login_type", t), this.module.updateDialogLayout()
    },
    showLoginComboBox: function() {
        var t = this.isSupportSSO(),
            e = this.isSupportOIDCSSO();
        if (t || e) {
            var i = this.ssoCombo;
            if (!i.isVisible()) {
                var s = Ext.util.Cookies.get("login_type") || "local";
                !0 === _S("sso_default_login") && (s = "sso"), i.setVisible(!0), i.setValue(s), this.onLoginTypeChange(s)
            }
        }
    },
    hideLoginComboBox: function() {
        var t = this.isSupportSSO(),
            e = this.isSupportOIDCSSO();
        if (t || e) {
            var i = this.ssoCombo;
            i.isVisible() && "sso" !== i.getValue() && "azure_sso" !== i.getValue() && "websphere_sso" !== i.getValue() && i.setVisible(!1)
        }
    },
    onSSOLogin: function() {
        var t = this.isSupportSSO(),
            e = this.isSupportOIDCSSO();
        if (!(t || e)) return !1;
        if ("oidc_sso" === this.ssoCombo.getValue()) {
            if ("azure" === _S("oidc_sso_profile")) return SYNO.SDS.AzureSSOUtils.login(this.onOIDCSSOCallback, this), !0;
            if ("websphere" === _S("oidc_sso_profile")) return SYNO.SDS.WebSphereSSOUtils.login(this.onOIDCSSOCallback, this), !0
        }
        return "sso" === this.ssoCombo.getValue() && (SYNO.SDS.SSOUtils.login(this.onSSOCallback, this), !0)
    },
    onSSOCallback: function(t) {
        "login" === t.status && t.access_token && 40 === t.access_token.length && this.sendWebAPI({
            api: "SYNO.Core.Directory.SSO.utils",
            method: "exchange",
            version: 1,
            params: {
                token: t.access_token
            },
            scope: this,
            callback: this.onGotSSOUsername
        })
    },
    onOIDCSSOCallback: function(t, e) {
        var i = function(e) {
            if (window.removeEventListener("message", i), e.source.close(), e.data.success) SYNO.SDS.initData(), location.reload();
            else {
                var s = _T("login", e.data.reason) || _T("login", "error_cantlogin");
                t.setError(s)
            }
        }.createDelegate();
        i(e)
    },
    onGotSSOUsername: function(t, e, i, s) {
        if (t) {
            this.setMsg(_T("common", "msg_waiting"));
            var n = this.passField,
                o = this.userField;
            n.hide(), o.hide(), n.setValue("SYNOSSOLOGIN" + i.token), o.setValue(e.user.replace("\\\\", "\\")), Ext.getDom("login_submit").click();
            var r = Ext.getCmp("sds-login-dialog-combobox");
            r.isExpanded() && r.collapse(), r.setDisabled(!0)
        } else this.setError("SSO login fail")
    }
}), Ext.define("SYNO.SDS.IconTextfield", {
    extend: "Ext.Container",
    constructor: function(t) {
        this.icon = new Ext.BoxComponent({
            cls: "icon " + (t.iconCls ? t.iconCls : "")
        }), this.input = new Ext.form.TextField({
            cls: "textfield",
            el: t.el,
            inputType: t.inputType,
            fieldLabel: t.fieldLabel || null,
            emptyText: t.emptyText || null,
            validator: t.validator || null
        });
        var e = {
            width: t.width,
            cls: String.format("sds-icon-text-field {0}", t.cls || ""),
            items: [this.icon, this.input]
        };
        this.callParent([e])
    },
    getValue: function() {
        return this.input.getValue()
    },
    setValue: function(t) {
        this.input.setValue(t)
    },
    setDisabled: function(t) {
        this.input.setDisabled(t)
    },
    setEmptyText: function(t) {
        this.input.emptyText = t, this.input.applyEmptyText()
    },
    focus: function() {
        this.input.focus(arguments)
    },
    validate: function() {
        return this.input.validate()
    }
}), SYNO.SDS.LoginUtils = {
    createBackground: function(t, e) {
        return new SYNO.SDS.Background({
            id: e || Ext.id(),
            cls: "sds-login-background",
            type: t.background_pos,
            imgSrc: t.background_path,
            bgColor: t.background_color,
            tplName: t.tplName
        })
    }
}, Ext.namespace("SYNO.SDS"), SYNO.SDS.GetExternalIP = function() {
    _S("isLogined") && SYNO.API.Request({
        api: "SYNO.Core.Desktop.Initdata",
        method: "get",
        version: 1,
        params: {
            action: "external_ip"
        },
        callback: function(t, e, i, s) {
            t ? (SYNO.SDS.Session.external_ip = e.external_ip, SYNO.SDS.Session.ddns_hostname = e.ddns_hostname) : SYNO.Debug("SYNO.SDS.GetExternalIP fail", arguments)
        }
    })
}, SYNO.SDS.HTML5Utils = function() {
    var t = window.XMLHttpRequest ? new XMLHttpRequest : {};
    return {
        HTML5Progress: !!t.upload,
        HTML5SendBinary: !(!t.sendAsBinary && !t.upload),
        HTML5ReadBinary: !!(window.FileReader || window.File && window.File.prototype.getAsBinary),
        HTML5Slice: !(!window.File || !(window.File.prototype.slice || window.File.prototype.mozSlice || window.File.prototype.webkitSlice)),
        isSupportHTML5Upload: function() {
            return (Ext.isChrome || !Ext.isSafari4 && !Ext.isSafari5_0 && !(Ext.isWindows && Ext.isSafari) && !Ext.isGecko3 && !Ext.isOpera) && (!!window.FormData || SYNO.SDS.HTML5Utils.HTML5SendBinary && SYNO.SDS.HTML5Utils.HTML5ReadBinary && SYNO.SDS.HTML5Utils.HTML5Slice)
        },
        isDragFile: function(t) {
            try {
                if (Ext.isWebKit) return t.dataTransfer.types && -1 != t.dataTransfer.types.indexOf("Files");
                if (Ext.isGecko) return t.dataTransfer.types.contains && t.dataTransfer.types.contains("application/x-moz-file") || 0 <= t.dataTransfer.types.indexOf("application/x-moz-file");
                if (Ext.isIE10 || Ext.isModernIE) return t.dataTransfer.files && t.dataTransfer.types && t.dataTransfer.types.contains("Files")
            } catch (t) {
                SYNO.Debug.error("Error in isDragFile")
            }
            return !1
        }
    }
}(), SYNO.SDS.SSOUtils = function() {
    return {
        callbackFn: {
            fn: Ext.emptyFn,
            scope: this
        },
        setCallback: function(t, e) {
            this.callbackFn.fn = t, Ext.isDefined(e) && (this.callbackFn.scope = e)
        },
        isSupport: function() {
            return _S("sso_support") && _S("sso_server") && _S("sso_appid") && "SYNOSSO" in window && Ext.isFunction(SYNOSSO.init)
        },
        init: function(t, e) {
            if (this.isSupport()) {
                this.setCallback(t, e);
                try {
                    SYNOSSO.init({
                        oauthserver_url: _S("sso_server"),
                        app_id: _S("sso_appid"),
                        redirect_uri: document.URL,
                        callback: this.callback.createDelegate(this)
                    })
                } catch (t) {}
            }
        },
        callback: function(t) {
            SYNOSSO.status = t.status, this.callbackFn.fn.call(this.callbackFn.scope, t)
        },
        login: function(t, e) {
            this.setCallback(t, e), SYNOSSO.login()
        },
        logout: function(t, e) {
            e && t.createDelegate(e), "sso" === (Ext.util.Cookies.get("login_type") || "sso") && SYNOSSO.logout(t)
        }
    }
}(), SYNO.SDS.AzureSSOUtils = function() {
    var t = screen.width / 2 - 250,
        e = screen.height / 2 - 300,
        i = String.format("height={0},width={1},left={2},top={3}", 600, 500, t, e);
    return {
        login: function(t, e) {
            var s = function(i) {
                    t(e, i)
                }.createDelegate(this),
                n = _S("dsm_https_port"),
                o = Ext.urlEncode({
                    action: "signin",
                    method: "azure_oidc",
                    origin: location.origin
                }),
                r = "https://" + location.hostname + ":" + n + "/webman/index.cgi?" + o;
            window.addEventListener("message", s), window.open(r, "OIDC", i)
        },
        logout: function() {
            var t = "webman/logout.cgi?" + Ext.urlEncode({
                asso: "true"
            });
            window.open(t, "OIDC", i)
        }
    }
}(), SYNO.SDS.WebSphereSSOUtils = function() {
    var t = screen.width / 2 - 250,
        e = screen.height / 2 - 300,
        i = String.format("height={0},width={1},left={2},top={3}", 600, 500, t, e);
    return {
        login: function(t, e) {
            var s = function(i) {
                    t(e, i)
                }.createDelegate(this),
                n = _S("dsm_https_port"),
                o = Ext.urlEncode({
                    action: "signin",
                    method: "websphere_oidc",
                    origin: location.origin
                }),
                r = "https://" + location.hostname + ":" + n + "/webman/index.cgi?" + o;
            window.addEventListener("message", s), window.open(r, "OIDC", i)
        },
        logout: function() {
            var t = "webman/logout.cgi?" + Ext.urlEncode({
                webspheresso: "true"
            });
            window.open(t, "OIDC", i)
        }
    }
}(), Ext.define("SYNO.SDS.IEUpgradeAlert", {
    extend: "SYNO.SDS.Window",
    constructor: function() {
        var t = {
            cls: "ie-upgrade-alert",
            width: 450,
            height: 230,
            maximizable: !1,
            title: _D("manager"),
            items: [{
                xtype: "syno_formpanel",
                name: "ie_alert_form",
                items: [{
                    xtype: "syno_displayfield",
                    hideLabel: !0,
                    value: _T("desktop", "upgrade_ie_browser")
                }, {
                    name: "skip_alert",
                    xtype: "syno_checkbox",
                    checked: !1,
                    boxLabel: _T("common", "dont_alert_again")
                }]
            }],
            fbar: {
                toolbarCls: "x-panel-fbar x-statusbar",
                items: [{
                    xtype: "syno_button",
                    text: _T("common", "ok"),
                    btnStyle: "blue",
                    handler: function() {
                        var t = this.find("name", "skip_alert")[0],
                            e = new Date;
                        !0 === t.getValue() && Ext.util.Cookies.set("skip_upgrade_ie_alert", !0, e.add(Date.YEAR, 1)), this.close()
                    },
                    scope: this
                }]
            }
        };
        this.callParent([t])
    }
}), Ext.define("SYNO.SDS.InitUtils", {
    singleton: !0,
    checkTargetSelectable: function(t) {
        if (t.getTarget(".selectabletext")) return !0;
        if (t.getTarget("textarea")) return !0;
        var e = t.getTarget("input"),
            i = e && e.type ? e.type.toLowerCase() : "";
        return ("text" === i || "textarea" === i || "password" === i) && !e.readOnly
    },
    checkTargetTextFiledorTextArea: function(t) {
        var e = t.getTarget("input"),
            i = e && e.type ? e.type.toLowerCase() : "";
        return !!t.getTarget("textarea") || ("text" === i || "password" === i)
    },
    hideForms: function() {
        var t = Ext.get("sds-login-dialog-form"),
            e = Ext.get("sds-apply-preview-form");
        return t && t.setStyle("display", "none"), e && e.setStyle("display", "none"), this
    },
    removeForm: function() {
        var t = Ext.get("sds-login-dialog-form");
        return t && t.remove(), this
    },
    initQuickTips: function() {
        return Ext.QuickTips.init(), Ext.isIE9m && !Ext.isIE9 || Ext.QuickTips.getQuickTip().getEl().disableShadow(), this
    },
    initDragDrop: function() {
        return Ext.dd.DragDropMgr.stopPropagation = !1, Ext.dd.DragDropMgr.clickTimeThresh = -1, Ext.WindowMgr.zseed = 12e3, this
    },
    disableIESelect: function() {
        return Ext.isIE && Ext.getDoc().on("selectstart", function(t) {
            this.checkTargetSelectable(t) || t.stopEvent()
        }, this), this
    },
    disableSelectAllKeyboard: function() {
        return Ext.getDoc().on("keydown", function(t) {
            t.ctrlKey && t.A === t.getKey() && !this.checkTargetSelectable(t) && t.stopEvent();
            var e, i = SYNO.SDS.WindowMgr,
                s = i ? i.getActiveAppWindow() : null;
            s && (e = s.appInstance), e && e.jsConfig && !0 != !e.jsConfig.allowBackspace || t.BACKSPACE !== t.getKey() || this.checkTargetTextFiledorTextArea(t) || t.preventDefault(), Ext.isIE && t.ESC === t.getKey() && this.checkTargetTextFiledorTextArea(t) && t.preventDefault()
        }, this), this
    },
    disableRightClick: function() {
        return Ext.getBody().on("contextmenu", function(t) {
            this.checkTargetSelectable(t) || t.getTarget(".allowDefCtxMenu") || t.stopEvent()
        }, this), this
    },
    handleServerError: function() {
        return Ext.Ajax.on("requestcomplete", function(t, e, i) {
            try {
                SYNO.SDS.Utils.CheckServerError(e) && (t.purgeListeners(), delete i.success, delete i.failure, delete i.callback)
            } catch (t) {
                if (!Ext.isIE8) throw t
            }
        }), this
    },
    initHTML5Upload: function() {
        return SYNO.SDS.HTML5Utils.isSupportHTML5Upload() && Ext.getBody().on("dragover", function(t) {
            SYNO.SDS.HTML5Utils.isDragFile(t.browserEvent) && (t.preventDefault(), t.browserEvent.dataTransfer.dropEffect = "none")
        }), this
    },
    IEUpgradeAlert: function() {
        (Ext.isIE6 || Ext.isIE7 || Ext.isIE8 || Ext.isIE9) && (Ext.util.Cookies.get("skip_upgrade_ie_alert") || (new SYNO.SDS.IEUpgradeAlert).show());
        return this
    },
    defaultCSSSelectors: function() {
        _S("diskless") && Ext.getBody().addClass("syno-diskless"), Ext.isIE10Touch && Ext.getBody().addClass("syno-ie10-touch");
        var t = Ext.urlDecode(location.search.substr(1)).accessible;
        return Ext.isDefined(t) && Ext.getBody().addClass("accessible"), this
    },
    initAPIManagerPromise: function() {
        return SYNO.API.currentManager || (SYNO.API.currentManager = new SYNO.API.Manager), new Promise(function(t, e) {
            SYNO.API.currentManager.queryAPI("all", t)
        })
    },
    checkTokenLogin: function() {
        return Ext.isWindows && !1 === _S("isLogined") && !0 === _S("enable_http_negotiate") ? new Promise(function(t, e) {
            Ext.Ajax.request({
                url: "webman/login.cgi?negotiate=" + Math.floor(window.performance.now()),
                method: "Get",
                success: function(e, i) {
                    var s = Ext.decode(e.responseText);
                    !0 === s.success ? (Ext.isEmpty(s.SynoToken) || (SYNO.SDS.Session.SynoToken = encodeURIComponent(s.SynoToken)), t(!0)) : t(!1)
                },
                failure: function() {
                    e()
                },
                scope: this
            })
        }) : Promise.resolve(!1)
    },
    initHDPack: function() {
        return SYNO.SDS.UIFeatures.IconSizeManager.addHDClsAndCSS(_S("SynohdpackStatus")), this
    },
    initLoginDialog: function() {
        return void 0 !== SYNO.SDS.ForgotPass ? new SYNO.SDS.ChangePassPage({}) : _S("isLogined") ? _S("preview") ? (window.opener && window.opener.previewParam && window.opener.previewParam.preview_modified && new SYNO.SDS.LoginApplyPreviewForm({}), new SYNO.SDS.LoginDialog({
            preview: !0
        })) : "no" !== _S("enable_syno_token") ? SYNO.SDS.UpdateSynoToken(this.readyToInitData) : this.readyToInitData() : 0 < window.location.search.indexOf("SynoToken=") ? window.location.search = window.location.search.replace(/&SynoToken=.*/, "") : _S("public_access") ? this.readyToInitData() : (window.loginLang = _S("lang"), new SYNO.SDS.LoginDialog({})), this
    },
    readyToInitData: function() {
        return SYNO.SDS.initData(), this
    },
    fetchSYNODEFS: function() {
        return new Promise(function(t, e) {
            if (!0 === _S("isLogined")) t();
            else {
                var i = "webapi/entry.cgi?api=SYNO.Core.Desktop.Defs&version=1&method=getjs";
                i = Ext.urlAppend(i, ""), SYNO.SDS.JSLoader.requestJSFileByScript(i, t, e)
            }
        })
    }
}), Ext.namespace("SYNO.SDS"), _S = function(t) {
    return SYNO.SDS.Session[t]
}, _TT = function(t, e, i) {
    try {
        return SYNO.SDS.Strings[t][e][i]
    } catch (t) {
        return ""
    }
}, Ext.define("SYNO.SDS.DependencyProvider", {
    extend: "Ext.util.Observable",
    constructor: function(t) {
        Ext.apply(this, t), this.callParent(arguments)
    },
    resolve: function(t, e) {
        return this.fn ? this.fn.apply(t || window, e || []) : this.className
    }
}), Ext.define("SYNO.SDS._Injector", {
    extend: "Ext.util.Observable",
    constructor: function(t) {
        this.callParent(arguments), this.providers = {}, this.selector = t
    },
    getEnvironment: function() {
        return this.selector
    },
    register: function(t) {
        if (!(Ext.isEmpty(t) || Ext.isEmpty(t.cls) || Ext.isEmpty(t.realCls))) {
            var e = t.cls;
            if (this.selector === t.name) Ext.define(e, {
                extend: t.realCls
            });
            else {
                if (e === t.defaultCls) return;
                Ext.isEmpty(t.defaultCls) || Ext.define(e, {
                    extend: t.defaultCls
                })
            }
        }
    },
    configure: function(t) {
        var e, i, s;
        for (e in {}, t) t.hasOwnProperty(e) && (s = t[e], Ext.isString(s) ? i = new SYNO.SDS.DependencyProvider({
            identifier: e,
            className: s
        }) : Ext.isObject(s) && (i = new SYNO.SDS.DependencyProvider(Ext.apply({
            identifier: e
        }, s))), this.providers[e] = i)
    },
    resolve: function(t, e, i) {
        var s = this.providers[t];
        if (s) return s.resolve(e, i)
    }
}), Ext.define("SYNO.SDS.basic.Themer", {
    extend: "Ext.util.Observable",
    constructor: function() {
        this.callParent(arguments)
    },
    setTheme: function(t, e) {
        this.theme = t, this.themeCls = e, Ext.getBody().addClass(e)
    },
    getTheme: function() {
        return this.theme
    },
    getThemeCls: function() {
        return this.themeCls
    },
    getPath: function(t) {
        var e = arguments.length > 1;
        if (e || Ext.isArray(t)) {
            var i = [];
            return Ext.each(e ? arguments : t, function(t) {
                i.push(this.innerGetPath(t))
            }, this), i
        }
        return this.innerGetPath(t)
    },
    innerGetPath: function(t) {
        return SYNO.SDS.CompatibleMode && !0 === SYNO.SDS.CompatibleMode ? t.replace("default/", "") : t.replace("default/", this.themeCls + "/")
    }
}), Ext.define("SYNO.SDS.DSM.Themer", {
    extend: "SYNO.SDS.basic.Themer",
    statics: {
        BUSINESS: "business",
        DEFAULT: "default"
    },
    defaultThemeCls: "default",
    defaultThemeName: "dsm",
    constructor: function(t) {
        var e = this.defaultThemeCls;
        this.callParent(arguments), SYNO.SDS.DSM.Themer.BUSINESS === t.themeCls && (e = SYNO.SDS.DSM.Themer.BUSINESS), this.setTheme(this.defaultThemeName, e)
    }
}), Ext.define("SYNO.SDS.ESM.Themer", {
    extend: "SYNO.SDS.basic.Themer",
    defaultThemeCls: "business",
    defaultThemeName: "esm",
    constructor: function() {
        this.callParent(arguments), this.setTheme(this.defaultThemeName, this.defaultThemeCls)
    }
}), Ext.define("SYNO.SDS.interval.Task", {
    extend: "Ext.Component",
    constructor: function() {
        this.callParent(arguments), _S("isLogined") && this.getTimeout()
    },
    stopPollingTask: function() {
        this.pollTask && this.pollUnreg(this.pollTask)
    },
    startPollingTask: function() {
        var t = this,
            e = {
                interval: 60,
                webapi: {
                    api: "SYNO.Core.Desktop.Timeout",
                    version: 1,
                    method: "check"
                },
                scope: t,
                status_callback: t.handleResponese
            };
        t.stopPollingTask(), t.pollTask = t.pollReg(e), t.mon(SYNO.SDS.StatusNotifier, "halt", function() {
            this.pollUnreg(this.pollTask)
        }, t)
    },
    handleResponese: function(t, e, i, s) {},
    delayGetTimeOut: function() {
        this.getTimeout.defer(6e4, this)
    },
    getTimeout: function() {
        var t = {
            api: "SYNO.Core.Desktop.Timeout",
            method: "get",
            version: 1,
            params: {}
        };
        this.sendWebAPI({
            api: t.api,
            version: t.version,
            method: t.method,
            params: t.params,
            scope: this,
            callback: function(t, e, i, s) {
                t && Ext.isNumber(e.timeout) && e.timeout > 0 ? (this.intervalTime = e.timeout, this.startPollingTask()) : this.delayGetTimeOut()
            }
        })
    }
}), SYNO.SDS.iFrameAppToFront = function(t) {
    var e = SYNO.SDS.AppMgr.getByAppName(t);
    e.length && Ext.each(e, function(t) {
        if (t.window) return t.window.toFront(), !1
    })
}, SYNO.SDS.restoreLogoutTrigger = function() {
    SYNO.SDS.Utils.Logout.logoutTriggered = !1
}, SYNO.SDS.isCompatibleMode = function() {
    for (var t = document.getElementsByTagName("script"), e = 0; e < t.length; e++) {
        if (t[e].src.indexOf("compatible-6.x") >= 0) return !0
    }
    return !1
}, SYNO.SDS.onBasicBeforeUnload = function() {
    var t, e;
    if (Ext.isChrome && SYNO.SDS.DragToDesktop.destroy(), !_S("standalone") && (t = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.WelcomeApp.Instance")) && t[0] && !t[0].window.canReload()) return _T("welcome", "unload_hint");
    if (!_S("standalone") && (t = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.PkgManApp.Instance")) && t[0] && t[0].window.isUpdating()) return _T("pkgmgr", "close_updateall_confirm");
    if ((t = _S("standalone") ? SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileStation3.Instance") : SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.App.FileTaskMonitor.Instance")) && t[0]) {
        e = _S("standalone") ? t[0].window.panelObj.monitorPanel : t[0].window;
        var i = "",
            s = _S("standalone") ? _T("tree", "leaf_filebrowser") : _D("os_name") || "DSM";
        if (e.uploadGrid.isProcessing() ? i += String.format(_T("filebrowser", "upload_confirm_unload"), s) : e.localGrid.isProcessing() ? i += String.format(_T("filebrowser", "local_confirm_unload"), s) : e.downloadGrid.isProcessing() && (i += String.format(_T("filebrowser", "download_confirm_unload"), s)), "" !== i) return SYNO.SDS.restoreLogoutTrigger.defer(10), i
    }
}, SYNO.SDS.getMsgBeforeUnload = function() {
    var t = SYNO.SDS.onBasicBeforeUnload();
    return !1 === SYNO.SDS.StatusNotifier.fireEvent("beforeunload") ? (SYNO.SDS.restoreLogoutTrigger.defer(10), _T("desktop", "confirm_leave")) : t ? (SYNO.SDS.restoreLogoutTrigger.defer(10), t) : void 0
}, SYNO.SDS.onBeforeUnload = function() {
    var t = _S("standalone") ? SYNO.SDS.Config.FnMap[_S("standaloneAppName")] : null,
        e = t && t.config ? SYNO.SDS.Utils.GetLocalizedString(t.config.title, t.config.jsID) : _D("os_name") || "DSM";
    return SYNO.SDS.getMsgBeforeUnload() || (!1 === SYNO.SDS.UserSettings.getProperty("Desktop", "disableLogoutConfirm") ? String.format(_T("desktop", "confirm_unload"), e) : void 0)
}, SYNO.SDS.onBeforeUnloadForApplication = function() {
    return SYNO.SDS.getMsgBeforeUnload()
}, SYNO.SDS.initData = function(t) {
    var e, i = Ext.urlDecode(window.location.search.substr(1));
    if (Ext.isNumber(t) && t > 0) SYNO.SDS.initData.defer(t, this);
    else {
        SYNO.SDS.CompatibleMode = SYNO.SDS.isCompatibleMode(), SYNO.SDS.InitUtils.handleServerError();
        var s = i.launchApp;
        !s && SYNO.SDS.Session && (s = SYNO.SDS.Session.rewriteApp), e = i.jsDebug ? {
            action: "debug",
            launch_app: s
        } : {
            launch_app: s
        };
        SYNO.SDS.InitUtils.initAPIManagerPromise().then(function() {
            return SYNO.SDS.InitUtils.fetchSYNODEFS()
        }).then(function() {
            return Promise.all([new Promise(function(t, i) {
                return SYNO.API.Request({
                    api: "SYNO.Core.Desktop.Initdata",
                    method: "get",
                    params: e,
                    version: 1,
                    callback: function(e, s, n, o) {
                        e ? t(s) : i(e, s)
                    }
                })
            }), (SYNO.SDS.Packages = new SYNO.SDS._Packages, SYNO.SDS.Packages.getData())])
        }).then(function(t) {
            t = t[0];
            var e = 1;

            function s() {
                0 === (e -= 1) && (Ext.isDefined(window._loadSynoLang) && window._loadSynoLang(), t.Session.SynoToken = _S("SynoToken"), SYNO.SDS.Session = t.Session, SYNO.SDS.Config.JSConfig = t.JSConfig, SYNO.SDS.Strings = t.Strings, SYNO.SDS.initUserSettings = t.UserSettings, SYNO.SDS.initGroupSettings = t.GroupSettings, SYNO.SDS.UrlTag = t.UrlTag, SYNO.SDS.AppPrivilege = t.AppPrivilege, SYNO.SDS.ServiceStatus = t.ServiceStatus, SYNO.SDS.UIFeatures.IconSizeManager.enableHDDisplay(t.SynohdpackStatus || !0), SYNO.SDS.init(), window.loginLang && _S("lang") !== window.loginLang && (Ext.form.VTypes.reloadVtypeStr(), SYNO.API.AssignErrorStr(), SYNO.SDS.Utils.StorageUtils.UiRenderHelper = SYNO.SDS.Utils.StorageUtils.UiRenderHelperInitializer(), SYNO.SDS.Relay.GetRelaydStatusStr = SYNO.SDS.Relay.GenRelaydStatusStr()), SYNO.SDS.appendMissingCSSFiles(t.CSSFiles), SYNO.SDS.InitUtils.removeForm())
            }
            var n = Ext.get(document.documentElement);
            switch (t.Session.lang) {
                case "cht":
                    n.set({
                        lang: "zh-Hant"
                    }), Ext.getBody().addClass("syno-cjk");
                    break;
                case "chs":
                    n.set({
                        lang: "zh-Hans"
                    }), Ext.getBody().addClass("syno-cjk");
                    break;
                case "jpn":
                    n.set({
                        lang: "ja"
                    }), Ext.getBody().addClass("syno-cjk");
                    break;
                case "krn":
                    n.set({
                        lang: "ko"
                    }), Ext.getBody().addClass("syno-cjk")
            }
            var o = i.launchApp;
            !0 !== t.Session.is_admin || t.Session.rewriteApp || o ? window.loginLang && t.Session.lang !== window.loginLang ? SYNO.SDS.Utils.loadUIStrings(t.Session.lang, t.Session.fullversion, s) : s() : (e += 1, window.loginLang && t.Session.lang !== window.loginLang ? SYNO.SDS.Utils.loadUIStrings(t.Session.lang, t.Session.fullversion, s) : s(), SYNO.API.Request({
                api: "SYNO.Core.QuickStart.Info",
                method: "load_ds_info",
                version: 2,
                callback: function(e, i, n, o) {
                    if (!e) return t.Session.qckFailed = !0, void s();
                    Ext.isObject(i) && (Ext.copyTo(t.Session, i, ["welcome_hide", "admin_configured", "myds_unified", "found_myds_account", "udc_check_state", "udc_enabled"]), i.vol_path && (t.Session.vol_path = i.vol_path), t.Session.myds_region_api_base_url = i.myds_region_api_base_url), s()
                }
            }))
        }).catch(function(t) {
            SYNO.Debug("Failed to fetch DSM defs scripts", t), SYNO.SDS.initData(3e3)
        })
    }
}, SYNO.SDS.filterStandaloneCSSFiles = function(t) {
    if (!_S("standalone")) return t;
    var e, i, s, n, o = _S("standaloneAppName"),
        r = SYNO.SDS.Config.FnMap,
        a = [],
        l = function(e) {
            Ext.each(t, function(t) {
                if (t.indexOf(e) >= 0) return a.push(t), !1
            })
        };
    return (e = r[o] ? r[o].config : null) && (n = e.white_pkg_list) ? (Ext.each(n, function(t) {
        (i = r[t] ? r[t].config : null) && (s = i.jsBaseURL, l(s))
    }), l(e.jsBaseURL), a) : t
}, SYNO.SDS.appendMissingCSSFiles = function(t) {
    var e = -1,
        i = "";
    t = SYNO.SDS.filterStandaloneCSSFiles(t), Ext.each(t, function(t) {
        var s = !1,
            n = function(t) {
                var e = document.createElement("link");
                e.setAttribute("rel", "stylesheet"), e.setAttribute("type", "text/css"), e.setAttribute("href", t), document.getElementsByTagName("head")[0].appendChild(e)
            };
        if (0 !== t.indexOf("webman/3rdparty/")) return Ext.each(document.getElementsByTagName("style"), function(e) {
            if (e.innerHTML.indexOf(t) >= 0) return s = !0, !1
        }), void(s || (Ext.each(document.getElementsByTagName("style"), function(e) {
            var i = t.substr(0, t.indexOf("?v=")),
                s = new RegExp('@import url\\("' + i + '\\?v=[^"]+"\\);(\\n)?');
            e.innerHTML.indexOf(i) >= 0 && (e.innerHTML = e.innerHTML.replace(s, ""))
        }), n(t)));
        Ext.each(document.getElementsByTagName("link"), function(e) {
            if (0 < e.href.indexOf(t)) return s = !0, !1
        }), s || (! function(t) {
            Ext.each(document.getElementsByTagName("link"), function(s) {
                if (-1 !== (e = t.indexOf("?")) && (i = t.substring(0, e), 0 < s.href.indexOf(i))) return s.parentNode.removeChild(s), !1
            })
        }(t), n(t))
    })
}, SYNO.SDS.AutoLaunch = function() {
    var t = function(t, e) {
        var i, s = (SYNO.SDS.Config.FnMap[t] && SYNO.SDS.Config.FnMap[t].config ? SYNO.SDS.Config.FnMap[t].config : {}).canLaunch;
        if (Ext.isObject(s))
            for (i in s)
                if (!!_S(i) !== s[i]) return;
        0 === SYNO.SDS.AppMgr.getByAppName(t).length && SYNO.SDS.AppLaunch(t, {}, !1, e)
    };
    SYNO.SDS.Config.AutoLaunchFnList.each(function(e) {
        Ext.isObject(e) ? t(e.dependName, t.createDelegate(this, [e.appName])) : t(e)
    })
}, SYNO.SDS.reloadJSConfig = function(t) {
    if (Ext.isNumber(t) && t > 0) SYNO.SDS.reloadJSConfig.defer(t, this);
    else {
        var e = Ext.urlDecode(location.search.substr(1));
        SYNO.API.Request({
            api: "SYNO.Core.Desktop.Initdata",
            method: "get",
            version: 1,
            params: {
                action: "jsconfig",
                launch_app: e.launchApp
            },
            callback: function(t, e, i, s) {
                if (!t) return SYNO.Debug("SYNO.SDS.reloadJSConfig fail", arguments), void SYNO.SDS.reloadJSConfig(3e3);
                var n;
                SYNO.SDS.Config.JSConfig = e.JSConfig, SYNO.SDS.Strings = e.Strings, SYNO.SDS.ServiceStatus = e.ServiceStatus, SYNO.SDS.AppPrivilege = e.AppPrivilege, SYNO.SDS.UrlTag = e.UrlTag, SYNO.SDS.JSLoad.init(), SYNO.SDS.AppView.refresh(), SYNO.SDS.Desktop.refresh(), SYNO.SDS.appendMissingCSSFiles(e.CSSFiles), n = [], SYNO.SDS.AppMgr.each(function(t) {
                    var e = t.jsConfig.jsID;
                    Ext.isDefined(SYNO.SDS.Config.FnMap[e]) || n.push(t)
                }), Ext.invoke(n, "destroy"), SYNO.SDS.StatusNotifier && SYNO.SDS.StatusNotifier.fireEvent("jsconfigLoaded"), SYNO.SDS.AutoLaunch()
            }
        }), SYNO.API.currentManager || (SYNO.API.currentManager = new SYNO.API.Manager), SYNO.API.currentManager.queryAPI("all")
    }
}, SYNO.SDS.CheckAndNotifySecurityAdvisor = function() {
    SYNO.API.Request({
        api: "SYNO.Core.SecurityScan.Conf",
        method: "first_get",
        version: 1,
        callback: function(t, e) {
            if (!t || e.firstLogAnalyzer || e.firstScan) {
                var i = String.format(_T("desktop", "notify_security_advisor"), '<a data-syno-app="SYNO.SDS.SecurityScan.Instance">', "</a>");
                SYNO.SDS.SystemTray.notifyMsg(null, _T("helptoc", "securityscan"), i, 0, !1)
            }
        },
        scope: this
    })
}, SYNO.SDS.CheckAndNotifyPackageStarting = function() {
    SYNO.API.Request({
        api: "SYNO.Core.Package",
        method: "list",
        version: 2,
        params: {
            additional: ["status"]
        },
        callback: function(t, e) {
            var i = e.packages;
            if (t && void 0 !== i)
                for (var s = {
                        installing: !0,
                        starting: !0,
                        upgrading: !0,
                        repairing: !0
                    }, n = 0; n < i.length; n++) {
                    var o = i[n].additional;
                    if (void 0 !== o && void 0 !== o.status && !0 === s[o.status]) {
                        var r = _T("notification", "pkg_still_enabling_title"),
                            a = _T("notification", "pkg_still_enabling_info");
                        return void SYNO.SDS.SystemTray.notifyMsg(null, r, a, 0, !0)
                    }
                }
        }
    })
}, SYNO.SDS.autoStart = function() {
    var t = SYNO.SDS.UserSettings.getProperty("Desktop", "restoreParams") || [],
        e = SYNO.SDS.UserSettings.getLocalStorageRestoreParams();
    !Ext.isEmpty(e) && SYNO.SDS.UserSettings.getProperty("Desktop", "rememberWindowState") && (t = e), _S("is_admin") && (_S("welcome_hide") || (SYNO.SDS.CheckAndNotifySecurityAdvisor(), SYNO.API.Request({
        api: "SYNO.Core.QuickStart.Info",
        method: "hide_welcome",
        version: 1,
        callback: Ext.emptyFn
    })), !0 === SYNO.SDS.Session.admin_first_login_after_upgrade && (SYNO.SDS.CheckAndNotifyPackageStarting(), SYNO.SDS.CheckAndNotifySecurityAdvisor())), SYNO.SDS.AutoLaunch(), Ext.each(t, function(t) {
        SYNO.SDS.AppLaunch(t.className, Ext.apply({
            fromRestore: !0
        }, t.params), !0)
    }), SYNO.SDS.UserSettings.removeProperty("Desktop", "restoreParams"), SYNO.SDS.UserSettings.removeLocalStorageRestoreParams()
}, SYNO.SDS.CheckBadge = function() {
    ! function() {
        SYNO.API.Request({
            compound: {
                api: "SYNO.Entry.Request",
                version: 1,
                method: "request",
                stopwhenerror: !1,
                params: [{
                    api: "SYNO.Core.Upgrade.Server",
                    method: "check",
                    version: 1,
                    params: {
                        need_auto_smallupdate: !0
                    }
                }, {
                    api: "SYNO.Core.Package.Server",
                    method: "check",
                    version: 1
                }]
            },
            scope: this,
            callback: Ext.emptyFn
        })
    }()
}, SYNO.SDS.init = function() {
    var t, e, i = Ext.urlDecode(location.search.substr(1)),
        s = i.launchApp,
        n = i.launchParam,
        o = i.jsDebug,
        r = i.report,
        a = SYNO.SDS.Session.rewriteApp,
        l = Ext.id();
    if (Ext.isDefined(r)) window.location = Ext.urlAppend(r);
    else {
        Ext.isDefined(o) && (SYNO.SDS.JSDebug = o), SYNO.SDS.initFramework();
        var c = SYNO.SDS.Config.FnMap[s],
            d = !1;
        if (c && c.config) {
            var u = c.config;
            "standalone" !== u.type && !0 !== u.allowStandalone && "url" !== u.type && "legacy" !== u.type || (d = !0)
        }
        if (d) SYNO.SDS.StatusNotifier.isAppEnabled(s) ? SYNO.SDS.initStandaloneDesktop(s, n) : window.location = "/";
        else if (a) {
            if (!SYNO.SDS.StatusNotifier.isAppEnabled(a)) return SYNO.SDS.StatusNotifier.fireEvent("logout"), window.alert(_JSLIBSTR("uicommon", "error_noprivilege")), void SYNO.SDS.Utils.Logout.action(!0);
            SYNO.SDS.Session.rewrite_mode = !0, SYNO.SDS.initStandaloneDesktop(a, n)
        } else {
            if (!SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.Desktop")) return SYNO.SDS.StatusNotifier.fireEvent("logout"), window.alert(_JSLIBSTR("uicommon", "error_noprivilege")), void SYNO.SDS.Utils.Logout.action(!0);
            SYNO.SDS.initDesktop(s), SYNO.SDS.StatusNotifier.isAppEnabled(s) && SYNO.SDS.AppLaunch(s, n), window.Notification && SYNO.SDS.UserSettings.getProperty("Desktop", "enableDesktopNotification") && "default" === window.Notification.permission && (t = String.format('<span id={0} class="blue-status" style="cursor:pointer;">{1}</span>', l, _T("common", "here")), t = String.format(_T("common", "click_to_enable_notification"), t), e = SYNO.SDS.SystemTray.notifyMsg("", _T("common", "desktop"), t, 0, !1), Ext.get(l).on("click", function() {
                window.Notification.requestPermission(function(t) {
                    window.Notification.permission = t
                }), e.close()
            })), _S("is_admin") && SYNO.SDS.CheckBadge()
        }
        SYNO.SDS.GetExternalIP(), SYNO.SDS.initAccesibilityPlugin(), SYNO.SDS.HandleTimeoutTask = new SYNO.SDS.interval.Task
    }
}, SYNO.SDS.initAccesibilityPlugin = function() {
    var t = SYNO.SDS.UserSettings.getProperty("Desktop", "disableAccessibility") || !1;
    setARIAPluginsDisabled(t)
}, SYNO.SDS.initFramework = function() {
    var t = Ext.getCmp("sds-login");
    if (t && t.el.fadeOut({
            callback: function() {
                t.destroy()
            }
        }), SYNO.SDS.LaunchTime = (new Date).getTime(), SYNO.SDS.JSLoad.init(), SYNO.SDS.StatusNotifier = new SYNO.SDS._StatusNotifier({}), SYNO.SDS.UserSettings = new SYNO.SDS._UserSettings, SYNO.SDS.GroupSettings = new SYNO.SDS._GroupSettings, SYNO.SDS.WindowMgr = new SYNO.SDS._WindowMgr, SYNO.SDS.FocusMgr = new SYNO.SDS._FocusMgr, SYNO.SDS.AppMgr = new SYNO.SDS._AppMgr, SYNO.SDS.GestureMgr = new SYNO.SDS._GestureMgr, SYNO.SDS.Injector = new SYNO.SDS._Injector(SYNO.SDS.Environment.GetEnvironment()), SYNO.SDS.Injector.configure({
            getDesktopClass: {
                fn: function() {
                    var t = SYNO.SDS.UserSettings.getProperty("Desktop", "desktopStyle");
                    return "classical" === t || SYNO.SDS.Environment.GetEnvironment() === SYNO.SDS.Environment.ESM || "business" === _S("theme_cls") && Ext.isEmpty(t) ? "SYNO.SDS.Classical._Desktop" : "SYNO.SDS._Desktop"
                }
            },
            getLaunchItemClass: {
                fn: function() {
                    var t = SYNO.SDS.UserSettings.getProperty("Desktop", "desktopStyle");
                    return "classical" === t || SYNO.SDS.Environment.GetEnvironment() === SYNO.SDS.Environment.ESM || "business" === _S("theme_cls") && Ext.isEmpty(t) ? "SYNO.SDS.Classical._LaunchItem" : "SYNO.SDS._LaunchItem"
                }
            },
            getAppMenuClass: {
                fn: function() {
                    var t = SYNO.SDS.UserSettings.getProperty("Desktop", "appMenuStyle");
                    return "classical" === t || SYNO.SDS.Environment.GetEnvironment() === SYNO.SDS.Environment.ESM || "business" === _S("theme_cls") && Ext.isEmpty(t) ? "SYNO.SDS.Classic._AppView" : "SYNO.SDS._AppView"
                }
            }
        }), SYNO.SDS._ActiveDesktop = Ext.getClassByName(SYNO.SDS.Injector.resolve("getDesktopClass")), SYNO.SDS.LaunchItem = Ext.getClassByName(SYNO.SDS.Injector.resolve("getLaunchItemClass")), SYNO.SDS._ActiveMenu = Ext.getClassByName(SYNO.SDS.Injector.resolve("getAppMenuClass")), SYNO.SDS.Injector.register({
            name: SYNO.SDS.Environment.ESM,
            cls: "SYNO.SDS.Themer",
            realCls: "SYNO.SDS.DSM.Themer",
            defaultCls: "SYNO.SDS.DSM.Themer"
        }), SYNO.SDS.ThemeProvider = new SYNO.SDS.Themer({
            themeCls: _S("theme_cls")
        }), Ext.isDefined(SYNO.SDS.JSDebug) && (SYNO.Debug("JS Loading Caching Disabled. (append _dc to js link)"), "all" === SYNO.SDS.JSDebug)) {
        var e = SYNO.SDS.Config.FnMap;
        for (var i in SYNO.Debug("JS Dynamic Loading Disabled."), e) e.hasOwnProperty(i) && SYNO.SDS.JSLoad(i)
    }
}, SYNO.SDS.initStandaloneDesktop = function(t, e) {
    _S("isLogined") && (SYNO.SDS.BackgroundTaskMgr = new SYNO.SDS._BackgroundTaskMgr, SYNO.SDS.UploadTaskMgr = new SYNO.SDS._UploadBackgroundTaskMgr, SYNO.SDS.MailTaskMgr = new SYNO.SDS._MailBackgroundTaskMgr, SYNO.SDS.SystemTray = new SYNO.SDS._SystemTray), SYNO.SDS.Session.standalone = !0, SYNO.SDS.Session.standaloneAppName = t, SYNO.SDS.Desktop = new SYNO.SDS._StandaloneDesktop, SYNO.SDS.AppLaunch(t, e), window.onbeforeunload = SYNO.SDS.onBeforeUnload, SYNO.SDS.DestroyLoginInstance && SYNO.SDS.DestroyLoginInstance()
}, SYNO.SDS.HideDesktop = function() {
    SYNO.SDS.TaskBar.hide(), SYNO.SDS.Desktop.hide(), Ext.get("sds-taskbar-shadow").hide()
}, SYNO.SDS.ShowDesktop = function() {
    var t = Ext.fly("sds-wallpaper");
    t.dom && t.dom.src && Ext.fly("sds-wallpaper").show(), SYNO.SDS.Desktop.show(), SYNO.SDS.TaskBar.show(), Ext.get("sds-taskbar-shadow").show()
}, Ext.define("SYNO.SDS.LaunchFullSizeApps", {
    statics: {
        appList: ["SYNO.SDS.App.WelcomeApp.Instance", "SYNO.SDS.UDC.Instance", "SYNO.SDS.App.WelcomeTip.Instance"],
        index: 0,
        start: function() {
            if (this.index < this.appList.length) return SYNO.SDS.AppLaunch(this.appList[this.index], {}, !1), void this.index++;
            this.index === this.appList.length && (SYNO.SDS.ShowDesktop(), SYNO.SDS.autoStart())
        }
    }
}), SYNO.SDS.initDesktop = function(t) {
    var e = !t && !_S("qckFailed") && _S("is_admin");
    SYNO.SDS.BackgroundTaskMgr = new SYNO.SDS._BackgroundTaskMgr, SYNO.SDS.UploadTaskMgr = new SYNO.SDS._UploadBackgroundTaskMgr, SYNO.SDS.PackageTaskMgr = new SYNO.SDS._PackageBackgroundTaskMgr, SYNO.SDS.MailTaskMgr = new SYNO.SDS._MailBackgroundTaskMgr, SYNO.SDS.DeskTopManager = new SYNO.SDS._DeskTopManager, SYNO.SDS.TaskBar = new SYNO.SDS._TaskBar, SYNO.SDS.TaskButtons = Ext.getCmp("sds-taskbuttons-panel"), SYNO.SDS.SystemTray = Ext.getCmp("sds-tray-panel"), SYNO.SDS.Desktop = new SYNO.SDS._ActiveDesktop, SYNO.SDS.AppView = new SYNO.SDS._ActiveMenu, SYNO.SDS.System = new SYNO.SDS._System, !1 !== SYNO.SDS.Session.boot_done ? (e && (SYNO.SDS.LaunchFullSizeApps.start(), SYNO.SDS.HideDesktop()), SYNO.SDS.PreviewBox = new SYNO.SDS._PreviewBox, window.onbeforeunload = SYNO.SDS.onBeforeUnload, SYNO.SDS.StatusNotifier.on("thirdpartychanged", SYNO.SDS.reloadJSConfig), SYNO.SDS.StatusNotifier.on("halt", function() {
        var t = Ext.getClassByName("SYNO.API.Request.Polling.Instance");
        SYNO.SDS.TaskMgr.setHalt(!0), Ext.isObject(t) && Ext.isFunction(t.endPolling) && t.endPolling("halt")
    }), SYNO.SDS.StatusNotifier.on("resumehalt", function() {
        var t = Ext.getClassByName("SYNO.API.Request.Polling.Instance");
        SYNO.SDS.TaskMgr.setHalt(!1), Ext.isObject(t) && Ext.isFunction(t.beginPolling) && t.beginPolling("halt")
    }), e ? SYNO.SDS.StatusNotifier.on("fullsizeappdestroy", function() {
        SYNO.SDS.LaunchFullSizeApps.start()
    }) : SYNO.SDS.autoStart()) : SYNO.SDS.System.WaitForBootUp()
}, SYNO.SDS.DragToDesktop = function() {
    var t = !1,
        e = [".syno-sds-fs-win", ".welcomedragable-url"],
        i = function(t) {
            var i = !1;
            Ext.each(e, function(e) {
                if (t.within(t.getTarget(e))) return i = !0, !1
            }, this), i || t.preventDefault()
        },
        s = function(t) {
            t.preventDefault();
            var e = this.timeStamp || (this.timeStamp = t.browserEvent.timeStamp);
            Math.abs(t.browserEvent.timeStamp - e) < 100 || (this.timeStamp = t.browserEvent.timeStamp, this.handleMouseMove(t))
        },
        n = function(t) {
            this.handleMouseUp(t), t.stopPropagation(), t.preventDefault()
        },
        o = function(t) {
            this.dragCurrent && this.handleMouseUp.defer(150, this, [t])
        },
        r = function(t) {
            t.preventDefault()
        };
    return {
        init: function() {
            Ext.dd.DragDropMgr.preventDefault = !1, Ext.EventManager.on(document, "dragstart", i, this, !0), Ext.EventManager.on(document, "dragenter", r, Ext.dd.DragDropMgr, !0), Ext.EventManager.on(document, "dragover", s, Ext.dd.DragDropMgr, !0), Ext.EventManager.on(document, "drop", n, Ext.dd.DragDropMgr, {
                preventDefault: !0
            }), Ext.EventManager.on(document, "dragend", o, Ext.dd.DragDropMgr, !0), t = !0
        },
        destroy: function() {
            Ext.dd.DragDropMgr.preventDefault = !0, Ext.EventManager.un(document, "dragstart", i, this, !0), Ext.EventManager.un(document, "dragover", s, Ext.dd.DragDropMgr, !0), Ext.EventManager.un(document, "dragenter", r, Ext.dd.DragDropMgr, !0), Ext.EventManager.un(document, "drop", n, Ext.dd.DragDropMgr), Ext.EventManager.un(document, "dragend", o, Ext.dd.DragDropMgr), t = !1
        },
        isEnable: function() {
            return t
        }
    }
}(), Ext.namespace("SYNO.SDS.AppWindow"), Ext.define("SYNO.SDS.FullScreenToolbar", {
    extend: "Ext.Container",
    constructor: function(t) {
        t.appWin && t.appWin instanceof SYNO.SDS.AppWindow ? (this.offsetX = t && t.offset ? t.offset[0] : 0, this.offsetY = t && t.offset ? t.offset[1] : 0, this.callParent([this.fillConfig(t)])) : SYNO.Debug.error("Need to add appWin in config!")
    },
    fillConfig: function(t) {
        this.contentBox = new Ext.BoxComponent({
            cls: "syno-sds-fullscreen-toolbar-content-container"
        });
        var e = {
            hideMode: "offset",
            cls: "syno-sds-fullscreen-toolbar",
            renderTo: SYNO.SDS.Desktop.id,
            items: [this.contentBox]
        };
        return Ext.apply(e, t)
    },
    adjustPos: function() {
        var t = "tl",
            e = [_S("standalone") ? 10 : 0, _S("standalone") ? 10 : 0],
            i = this.appWin.fsHandler,
            s = this.el.parent();
        i ? (s = i.el, t = "br", e[0] -= this.el.getWidth()) : "b" === this.dir ? (t = "bl", e[1] -= _S("standalone") ? this.el.getHeight() + 10 : this.el.getHeight()) : "r" === this.dir && (t = "tr", e[0] -= _S("standalone") ? this.el.getWidth() + 10 : this.el.getWidth()), e[0] += this.offsetX, e[1] += this.offsetY, this.el.alignTo(s, t, e), this.el.applyStyles({
            zIndex: parseInt(this.appWin.el.getStyle("zIndex"), 10) + 1
        })
    },
    cancleHideTask: function() {
        this.hideTask || (this.hideTask = new Ext.util.DelayedTask(this.hide, this)), this.hideTask.delay(2e3)
    },
    show: function(t, e) {
        this.cancleHideTask(), this.adjustPos(), this.el.hasClass("dissolve-in") || (this.removeClass("dissolve-out"), this.addClass("dissolve-in"))
    },
    hide: function(t) {
        if (t) return Ext.each(this.contentBox.el.dom.childNodes, function(t) {
            var e = Ext.get(t);
            e.orgParent.appendChild(e)
        }), this.removeParentClsFromContentBox(), void this.callParent();
        this.el.hasClass("dissolve-in") && (this.removeClass("dissolve-in"), this.addClass("dissolve-out")), this.hideTask && (this.hideTask = null)
    },
    addParentClsToContentBox: function(t) {
        Ext.isArray(t) ? Ext.each(t, this.addParentClsToContentBox, this) : Ext.isString(t) && (this.contentBox.addClass(t), this.contentBox.addedCls || (this.contentBox.addedCls = []), this.contentBox.addedCls.push(t))
    },
    removeParentClsFromContentBox: function() {
        this.contentBox.addedCls && this.contentBox.addedCls.each(function(t) {
            this.contentBox.removeClass(t)
        }, this)
    },
    addElements: function(t) {
        Ext.isArray(t) ? Ext.each(t, this.addElements, this) : Ext.isObject(t) && t instanceof Ext.Element && (t.orgParent = t.parent(), this.contentBox.el.appendChild(t))
    }
}), Ext.define("SYNO.SDS.AppWindow", {
    extend: "SYNO.SDS.BaseWindow",
    initialized: !1,
    taskButton: null,
    ariaRole: "application",
    constructor: function(t) {
        var e;
        t = Ext.apply({}, t, {
            useStatusBar: Ext.isDefined(t.buttons),
            showHelp: !0,
            toggleFullScreen: !1
        }), t = Ext.apply(t, {
            title: null,
            iconCls: "x-panel-icon",
            openConfig: {
                dsm_version: _S("majorversion") + "." + _S("minorversion")
            }
        }), !_S("standalone") && t.appInstance && !0 !== t.fromRestore && !1 !== t.autoRestoreSizePos && Ext.apply(t, this.getRestoreSizePos(t)), t = this.adjustPageXY(t), !_S("standalone") && t.showHelp && (Ext.isArray(t.tools) || (t.tools = []), t.tools.push({
            id: "help",
            text: _T("common", "alt_help"),
            scope: this,
            handler: this.onClickHelp
        })), t.toggleFullScreen && SYNO.SDS.UIFeatures.test("isSupportFullScreen") && (this.isFullScreen = !1, Ext.isArray(t.tools) || (t.tools = []), t.tools.push({
            id: "fullscreen",
            text: _T("personal_settings", "menu_style_fullscreen"),
            scope: this,
            handler: this.onClickFullScrren
        })), e = !Ext.isDefined(t.maximizable) || t.maximizable;
        var i = !!t.appInstance && t.appInstance.blMainApp;
        if (_S("standalone")) {
            if (i) Ext.apply(t, {
                maximizable: !1,
                maximized: e,
                closable: !1,
                modal: !1
            }), t.cls = (t.cls || "") + (this.cls || "") + " sds-standalone-main-window", document.title = t.title || document.title;
            else if (Ext.apply(t, {
                    maximizable: !1,
                    maximized: !1,
                    closable: !0,
                    modal: !0
                }), e) {
                Ext.EventManager.onWindowResize(this.onModalWindowResize, this), Ext.apply(t, {
                    x: 10,
                    y: 10,
                    width: Ext.lib.Dom.getViewWidth() - 20,
                    height: Ext.lib.Dom.getViewHeight() - 20
                })
            }
            Ext.apply(t, {
                resizable: !1,
                draggable: !1,
                minimizable: !1
            })
        }
        if ((_S("isMobile") || Ext.isIE10Touch) && e && Ext.apply(t, {
                maximized: !0
            }), t = this.overwriteAppWinConfig(t), SYNO.SDS.AppWindow.superclass.constructor.call(this, t), t.maximized || (_S("standalone") && this.anchorTo(this.container, "c-c"), (_S("isMobile") || Ext.isIE10Touch) && this.anchorTo(this.container, "t-t")), this.mon(this, "move", this.saveRestoreData, this), this.mon(this, "resize", this.saveRestoreData, this), t.toggleFullScreen && this.bindFullScreenEvents(), _S("standalone") && i) {
            var s = this.getSmallIcon(!0);
            Ext.each([16, 32, 48, 64, 96], function(t) {
                s.indexOf("webman/3rdparty/") >= 0 ? SYNO.SDS.Utils.addFavIconLink(s.replace(/(res=)(\d)*/, "$1" + t), "image/png", t + "x" + t) : SYNO.SDS.Utils.addFavIconLink(s.replace(/_16/, "_" + t), "image/png", t + "x" + t)
            }), this.mon(this, "titlechange", function() {
                document.title = this.title || document.title
            }, this)
        }!0 === this.splitWindow && this.addClass("x-window-split")
    },
    bindFullScreenEvents: function() {
        document.fullscreenEnabled ? document.addEventListener("fullscreenchange", this.handleFSChange.createDelegate(this), !1) : document.webkitFullscreenEnabled ? document.addEventListener("webkitfullscreenchange", this.handleFSChange.createDelegate(this), !1) : document.mozFullScreenEnabled ? document.addEventListener("mozfullscreenchange", this.handleFSChange.createDelegate(this), !1) : document.msFullscreenEnabled && document.addEventListener("MSFullscreenChange", this.handleFSChange.createDelegate(this), !1)
    },
    isAlwaysOnTop: function() {
        if (!0 === this.toggleFullScreen && !0 === this.isFullScreen) return !0
    },
    handleFSChange: function() {
        if (this.isFullScreen) {
            if (SYNO.SDS.UIFeatures.isFullScreenMode()) {
                if (!1 === this.fireEvent("beforeenablefullscreen")) return;
                _S("standalone") || (SYNO.SDS.TaskBar.hide(), Ext.get("sds-taskbar-shadow").setStyle({
                    display: "none"
                }), SYNO.SDS.Desktop.el.setStyle({
                    top: "0px",
                    zIndex: 0,
                    height: window.screen.height + "px"
                }), this.lastStateMaximized = this.maximized, this.lastStateMaximized || this.toggleMaximize()), this.hideTools(), this.fireEvent("windowfullscreenenabled")
            } else {
                if (!1 === this.fireEvent("beforedisablefullscreen")) return;
                this.isFullScreen = !1, this.showTools(), _S("standalone") || (this.lastStateMaximized || this.toggleMaximize(), SYNO.SDS.Desktop.el.setStyle({
                    top: "39px",
                    zIndex: "",
                    height: Ext.getBody().getHeight() + "px"
                }), SYNO.SDS.TaskBar.show(), Ext.get("sds-taskbar-shadow").setStyle({
                    display: "block"
                })), this.fireEvent("windowfullscreendisabled")
            }
            SYNO.SDS.WindowMgr.orderWindows()
        }
    },
    showFSToolbar: function() {
        this.fsToolbar.show()
    },
    initFSToolbar: function(t, e, i, s, n) {
        e = e || "t", this.fsToolbar || (this.fsToolbar = new SYNO.SDS.FullScreenToolbar({
            appWin: this,
            dir: e,
            offset: n
        })), t && this.fsToolbar.addElements(t, i), i && this.fsToolbar.addParentClsToContentBox(i), !0 === s && this.fsToolbar.show(), this.el.on("mousemove", this.showFSToolbar, this), this.el.on("click", this.showFSToolbar, this)
    },
    destroyFSToolbar: function(t) {
        this.el.un("mousemove", this.showFSToolbar, this), this.el.un("click", this.showFSToolbar, this), this.fsToolbar && this.fsToolbar.hide(!t)
    },
    overwriteAppWinConfig: function(t) {
        return t
    },
    genIndPortHeader: function() {
        var t = this.el.createChild({
                tag: "div",
                cls: "sds-standalone-main-window-header"
            }, this.header.dom),
            e = !1 === this.showHelp,
            i = new Ext.Toolbar({
                renderTo: t,
                height: 30,
                toolbarCls: "sds-standalone-main-window-header-toolbar",
                items: [{
                    cls: "sds-standalone-welcome-text",
                    xtype: "syno_displayfield",
                    htmlEncode: !1,
                    tabIndex: -1,
                    hideLabel: !0,
                    value: _T("common", "welcome") + "&nbsp;<b>" + _S("user") + "</b>",
                    hidden: !_S("rewrite_mode")
                }, {
                    xtype: "syno_button",
                    cls: "sds-standalone-logout",
                    iconCls: "sds-standalone-logout-icon",
                    text: _T("common", "logout"),
                    scope: this,
                    hidden: !_S("rewrite_mode") || e,
                    handler: function() {
                        SYNO.SDS.StatusNotifier.fireEvent("logout"), window.onbeforeunload = SYNO.SDS.onBasicBeforeUnload;
                        try {
                            SYNO.SDS.Utils.Logout.action()
                        } catch (t) {}
                    }
                }, {
                    xtype: "syno_button",
                    cls: "sds-standalone-help",
                    iconCls: "sds-standalone-help-icon",
                    text: _T("common", "alt_help"),
                    hidden: e,
                    scope: this,
                    handler: this.onClickHelp
                }],
                listeners: {
                    scope: this,
                    single: !0,
                    buffer: 80,
                    afterlayout: function() {
                        var e = 0;
                        i.items.each(function(t) {
                            !0 !== t.hidden && (e += t.getOuterSize().width)
                        }), e += 2, t.setWidth(e)
                    }
                }
            })
    },
    afterRender: function() {
        var t;
        SYNO.SDS.AppWindow.superclass.afterRender.apply(this, arguments), _S("standalone") && (this.alignTo(document.body, "c-c"), "true" === _S("remove_banner") && this.appInstance && this.appInstance.blMainApp && (this.toggleMaximize(), this.header.setVisibilityMode(Ext.Element.DISPLAY), this.header.hide(), (t = this.el.first("div.x-window-tl")) && t.setStyle({
            "padding-top": "8px"
        }), this.toggleMaximize())), this.isStandaloneMainWindow() && (this.header.dom.innerHTML = '<div class="sds-standalone-main-window-header-text">' + this.header.dom.innerHTML + "</div>", "true" !== _S("remove_banner") && this.genIndPortHeader())
    },
    destroy: function() {
        _S("standalone") && Ext.EventManager.removeResizeListener(this.onModalWindowResize, this), this.aboutWindow && this.aboutWindow.destroy(), SYNO.SDS.AppWindow.superclass.destroy.apply(this, arguments)
    },
    onModalWindowResize: function() {
        this.setPosition(10, 10), this.setSize(Ext.lib.Dom.getViewWidth() - 20, Ext.lib.Dom.getViewHeight() - 20)
    },
    isStandaloneMainWindow: function() {
        return _S("standalone") && this.appInstance && this.appInstance.blMainApp
    },
    getSmallIcon: function(t) {
        var e, i = this.jsConfig.jsBaseURL + "/" + (this.jsConfig.icon || this.jsConfig.icon_16),
            s = this.isStandaloneMainWindow();
        return e = t ? "FavHeader" : s ? "StandaloneHeader" : this.isV5Style() ? "Header" : "HeaderV4", SYNO.SDS.UIFeatures.IconSizeManager.getIconPath(i, e)
    },
    init: function() {
        this.initialized || (!1 !== this.toggleMinimizable && this.setIcon(this.getSmallIcon()), _S("standalone") || !1 === this.toggleMinimizable || (this.taskButton = this.appInstance.taskButton || SYNO.SDS.TaskButtons.add(this.appInstance.jsConfig.jsID, this.jsConfig.jsID), this.taskButton.init(this), this.taskButton.setState("loading"), this.taskButton.setLoading(!1), this.addManagedComponent(this.taskButton)), this.setTitle(SYNO.SDS.Utils.GetLocalizedString(this.getTitle(), this.appInstance.jsConfig.jsID)), this.initialized = !0)
    },
    onBeforeDestroy: function() {
        SYNO.SDS.AppWindow.superclass.onBeforeDestroy.apply(this, arguments), this.taskButton = null
    },
    showAboutWindow: function(t) {
        t = t || {}, this.aboutWindow = Vue.extend({
            template: '<v-about-window :syno-id="synoId" :name="name" :custom-name="customName" :desc="desc" :icon="icon" :copyright-year="copyrightYear" :is-beta="isBeta" :swap-name-and-desc="swapNameAndDesc" :theme="theme" :class="customCls" />',
            props: ["synoId", "name", "customName", "desc", "icon", "copyrightYear", "isBeta", "swapNameAndDesc", "theme", "customCls"]
        });
        var e = this.getJsConfig();
        this.openVueWindow(this.aboutWindow, {
            synoId: t.synoId || e.jsID,
            name: SYNO.SDS.Utils.GetLocalizedString(this.getTitle(), e.jsID),
            customName: Array.isArray(e.customAboutTitle) ? [SYNO.SDS.Utils.GetLocalizedString(e.customAboutTitle[0], e.jsID), SYNO.SDS.Utils.GetLocalizedString(e.customAboutTitle[1], e.jsID)] : null,
            desc: t.desc || "",
            icon: SYNO.SDS.UIFeatures.IconSizeManager.getIconPath(e.jsBaseURL + "/" + (e.icon || e.icon_32), "desktop"),
            copyrightYear: e.buildTime ? e.buildTime.split("-")[0] : _S && _S("builddate") ? _S("builddate").split("/")[0] : "",
            isBeta: void 0 !== t.isBeta ? t.isBeta : this.isBeta || !1,
            swapNameAndDesc: t.swapNameAndDesc || !1,
            theme: t.theme || {},
            customCls: t.customCls || ""
        })
    },
    hideAboutWindow: function() {
        this.aboutWindow && this.aboutWindow.hide()
    },
    showTools: function() {
        var t, e = this.maximized;
        for (t in this.tools)
            if (this.tools.hasOwnProperty(t)) {
                if (!this.maximizable && "maximize" === t || !this.maximizable && "restore" === t || e && "maximize" === t || !e && "restore" === t) continue;
                "fullscreen" == t && this.tools[t].removeClass("collapse"), this.tools[t].show()
            }
    },
    hideTools: function() {
        var t;
        for (t in this.tools)
            if (this.tools.hasOwnProperty(t)) {
                if ("fullscreen" === t) {
                    this.tools[t].addClass("collapse");
                    continue
                }
                this.tools[t].hide()
            }
    },
    onClickFullScrren: function() {
        var t = SYNO.SDS.Desktop.el.dom;
        SYNO.SDS.UIFeatures.isFullScreenMode() ? document.exitFullscreen ? document.exitFullscreen() : document.msExitFullscreen ? document.msExitFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitExitFullscreen && document.webkitExitFullscreen() : (this.isFullScreen = !0, t.requestFullscreen ? t.requestFullscreen() : t.msRequestFullscreen ? t.msRequestFullscreen() : t.mozRequestFullScreen ? t.mozRequestFullScreen() : t.webkitRequestFullscreen && t.webkitRequestFullscreen())
    },
    onClickHelp: function() {
        var t = this.appInstance ? this.appInstance.jsConfig.jsID : this.jsConfig.jsID,
            e = this.getHelpParam();
        Ext.isString(e) && e.length && (t += ":" + e), _S("standalone") ? SYNO.SDS.WindowLaunch("SYNO.SDS.HelpBrowser.Application", {
            topic: t
        }) : SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
            topic: t
        }, !1)
    },
    getHelpParam: Ext.emptyFn,
    setTitle: function(t, e, i) {
        if (SYNO.SDS.AppWindow.superclass.setTitle.apply(this, arguments), this.taskButton) {
            var s = !1 !== i ? Ext.util.Format.htmlEncode(t) : t;
            this.taskButton.setTooltip(s)
        }
    },
    getTitle: function() {
        var t = this.getJsConfig();
        return this.title || t.title
    },
    getJsConfig: function() {
        return this.appInstance ? this.appInstance.jsConfig : this.jsConfig
    },
    updateTaskButton: function(t) {
        this.taskButton && this.taskButton.updateContextMenu(t)
    },
    restore: function() {
        !0 !== this.isFullScreen && SYNO.SDS.AppWindow.superclass.restore.call(this)
    },
    onHeaderContextMenu: function(t) {
        !0 !== this.isFullScreen && (SYNO.SDS.AppWindow.superclass.onHeaderContextMenu.apply(this, arguments), _S("standalone") || this.taskButton.getContextMenu(!1).showAt(t.getXY()))
    },
    onMaximize: function() {
        SYNO.SDS.AppWindow.superclass.onMaximize.apply(this, arguments), this.updateTaskButton("maximize")
    },
    onMinimize: function() {
        _S("standalone") || (this.minimizable ? this.hide(Ext.isIE9m && !Ext.isIE9 ? void 0 : this.taskButton.el) : this.el.frame(), SYNO.SDS.AppWindow.superclass.onMinimize.apply(this, arguments), this.updateTaskButton("minimize"))
    },
    onRestore: function() {
        SYNO.SDS.AppWindow.superclass.onRestore.apply(this, arguments), this.updateTaskButton("restore")
    },
    mask: function() {
        SYNO.SDS.AppWindow.superclass.mask.apply(this, arguments), this.updateTaskButton("mask")
    },
    unmask: function() {
        SYNO.SDS.AppWindow.superclass.unmask.apply(this, arguments), this.updateTaskButton("unmask")
    },
    saveRestoreData: function() {
        var t = Ext.apply(this.getSizeAndPosition(), {
            fromRestore: !0
        });
        this.appInstance.setUserSettings("restoreSizePos", t)
    },
    adjustPageXY: function(t) {
        return t ? (Ext.isDefined(t.pageX) && t.pageX < 0 && (t.pageX = 0), Ext.isDefined(t.pageY) && t.pageY < 0 && (t.pageY = 0), Ext.isDefined(t.x) && t.x < 0 && (t.x = 0), Ext.isDefined(t.y) && t.y < 0 && (t.y = 0), t) : {}
    },
    getRestoreSizePos: function(t) {
        var e = t.appInstance.getUserSettings("restoreSizePos") || {};
        return Ext.isDefined(t.minWidth) && Ext.isDefined(e.width) && e.width < t.minWidth && (e.width = t.width), Ext.isDefined(t.minHeight) && Ext.isDefined(e.height) && e.height < t.minHeight && (e.height = t.height), e
    },
    onOpen: function(t) {
        var e;
        if (this.initialized || this.init(), Ext.isObject(t)) {
            for (e in t) t.hasOwnProperty(e) && this.setOpenConfig(e, t[e]);
            t.title && this.setTitle(t.title), SYNO.API.Info.Update(this)
        }
        this.appInstance.skipRecord || this.recordAppOpened(), SYNO.SDS.AppWindow.superclass.onOpen.apply(this, arguments)
    },
    recordAppOpened: function() {
        var t = this.appInstance,
            e = t.appWindowName,
            i = t.jsConfig.jsID;
        e && _S("isLogined") && this.sendWebAPI({
            callback: function() {
                SYNO.SDS.StatusNotifier.fireEvent("apprecordupdated", i, e)
            }.bind(this),
            compound: {
                stopwhenerror: !1,
                params: [{
                    api: "SYNO.Core.DataCollect.Application",
                    version: 1,
                    method: "record",
                    params: {
                        app: e
                    }
                }, {
                    api: "SYNO.Core.AppNotify",
                    version: 1,
                    method: "view",
                    params: {
                        app: i
                    }
                }]
            }
        })
    },
    onShow: function() {
        SYNO.SDS.AppWindow.superclass.onShow.apply(this, arguments), this.updateTaskButton("restore")
    },
    checkModalOrMask: function() {
        return !!(this.modalWin && this.modalWin.length > 0 || this.maskCnt > 0) && (this.blinkModalChild(), !0)
    },
    setMaskMsgVisible: function(t) {
        if (this.el.isMasked()) {
            var e = Ext.Element.data(this.el, "maskMsg");
            e && e.dom && (e.setVisibilityMode(Ext.Element.VISIBILITY), e.setVisible(t))
        }
    },
    setMaskOpacity: function(t) {
        SYNO.SDS.AppWindow.superclass.setMaskOpacity.call(this, t), this.setMaskMsgVisible(0 !== t)
    },
    delayedMask: function(t, e, i, s) {
        e = e || 200, this.maskTask || (this.maskTask = new Ext.util.DelayedTask(this.setMaskOpacity, this, [t])), this.mask(0, i, s), this.setMaskMsgVisible(!1), this.maskTask.delay(e)
    },
    synchronizedMask: function(t, e, i) {
        this.mask(t, e, i), this.setMaskMsgVisible(0 !== t)
    },
    setStatusBusy: function(t, e, i) {
        t = t || {}, Ext.applyIf(t, {
            text: _T("common", "loading"),
            iconCls: "x-mask-loading"
        }), e = Ext.isNumber(e) ? e : .4, (i = Ext.isNumber(i) ? i : 400) > 0 ? this.delayedMask(e, i, t.text, t.iconCls) : this.synchronizedMask(e, t.text, t.iconCls), this.canClose = !1
    },
    clearStatusBusy: function(t) {
        this.unmask(), this.canClose = !0
    },
    onClose: function() {
        if (this.isStandaloneMainWindow() || !1 === this.canClose) return !1;
        this.callParent()
    },
    doConstrain: function() {
        var t, e, i;
        this.constrainHeader && (t = {
            left: -((e = this.getSize()).width - 100),
            right: -(e.width - 100),
            bottom: -(e.height - 25)
        }, (i = this.el.getConstrainToXY(this.container, !0, t)) && (i[0] < 0 && i[0] + e.width < this.container.getWidth() || this.setPosition(i[0], i[1])))
    },
    getOpenConfig: function(t) {
        if (Ext.isString(t) && !Ext.isEmpty(this.openConfig[t])) return this.openConfig[t]
    },
    setOpenConfig: function(t, e) {
        Ext.isString(t) && !Ext.isEmpty(t) && (this.openConfig[t] = e)
    },
    hasOpenConfig: function(t) {
        return !(!Ext.isString(t) || Ext.isEmpty(t)) && void 0 !== this.openConfig[t]
    }
}), Ext.namespace("SYNO.SDS.LegacyAppWindow"), SYNO.SDS.LegacyAppWindow = Ext.extend(SYNO.SDS.AppWindow, {
    iframeId: "",
    url: Ext.SSL_SECURE_URL,
    constructor: function(t) {
        this.iframeId = Ext.id(), SYNO.SDS.LegacyAppWindow.superclass.constructor.call(this, Ext.apply({
            width: this.jsConfig.width || 800,
            height: this.jsConfig.height || 600,
            html: String.format('<iframe id="{0}" src="{1}" frameborder="0" style="border: 0px none; width: 100%; height: 100%;"></iframe>', this.iframeId, Ext.SSL_SECURE_URL)
        }, t)), this.setURL(this.url)
    },
    onActivate: function() {
        SYNO.SDS.LegacyAppWindow.superclass.onActivate.apply(this, arguments), this.unmaskBody()
    },
    onDeactivate: function() {
        SYNO.SDS.LegacyAppWindow.superclass.onDeactivate.apply(this, arguments), this.maskBody()
    },
    setURL: function(t) {
        Ext.getDom(this.iframeId).src = t
    },
    getURL: function() {
        return Ext.getDom(this.iframeId).src
    },
    maskBody: function() {
        var t = this.body.mask();
        t.setOpacity(0), this.mon(t, "mousedown", this.toFront, this)
    },
    unmaskBody: function() {
        var t = Ext.Element.data(this.body, "mask");
        t && (this.mun(t, "mousedown", this.toFront, this), this.body.unmask())
    }
}), Ext.namespace("SYNO.SDS.Config"), Ext.namespace("SYNO.SDS.JSLoad"), Ext.define("SYNO.SDS.JSLoader", {
    singleton: !0,
    requestJSFileByScript: function(t, e, i) {
        var s = document.getElementsByTagName("head")[0],
            n = document.createElement("script"),
            o = t;
        o = Ext.urlAppend(o, "v=" + _S("fullversion")), Ext.isDefined(SYNO.SDS.JSDebug) && (o = Ext.urlAppend(o, "_dc=" + (new Date).getTime())), SYNO.Debug.debug("JSLoad requesting for  " + t + " by script tag"), n.type = "text/javascript", Ext.isIE ? (n.onready = e, n.onreadystatechange = function() {
            "complete" !== this.readyState && "loaded" !== this.readyState || this.onready()
        }) : n.onload = e, n.onerror = i, n.src = o, s.appendChild(n)
    },
    requestJSFileByAjax: function(t, e, i) {
        var s = SYNO.SDS.JSLoad.JSStatus[t];
        SYNO.Debug.debug("JSLoad requesting for  " + t + " by ajax"), Ext.Ajax.request({
            method: "GET",
            disableCaching: Ext.isDefined(SYNO.SDS.JSDebug),
            url: Ext.urlAppend(t, "v=" + (s.version || _S("fullversion"))),
            extraParams: {
                jsFile: t
            },
            scope: this,
            failure: function(t, s) {
                var n = s.extraParams.jsFile,
                    o = Math.round(5 + 5 * Math.random());
                SYNO.Debug.error(n + ": " + t.status + " " + t.statusText), SYNO.Debug.error("JSLoad request failed: " + n + ", retry after " + o + " seconds"), Ext.defer(this.requestJSFileByAjax, 1e3 * o, this, [n, e, i])
            },
            success: function(t, s) {
                try {
                    var n = s.extraParams.jsFile;
                    SYNO.Debug.debug("JSLoad request successed: " + n), window.execScript ? window.execScript(t.responseText, "JavaScript") : window.eval(t.responseText), e()
                } catch (t) {
                    return SYNO.Debug.error("JSLoad import " + n + " failed: ", t, t.stack), void i(t)
                }
            }
        })
    },
    JSLoadFn: function(t) {
        var e = SYNO.SDS.Config.FnMap[t];
        return e ? this.JSLoadFile(e.jsFile) : Promise.reject("No such app: " + t)
    },
    JSLoadFile: function(t) {
        if (!SYNO.SDS.Config.JSConfig[t]) return Promise.reject("No such file: " + t);
        if (this.isLoaded(t)) return Promise.resolve();
        var e = SYNO.SDS.JSLoad.JSStatus[t];
        if (e.promise) return e.promise;
        var i = this.getDepends(t);
        return e.loading ? (this.printLoopStat(t, i), Promise.reject("loop detected")) : (e.loading = !0, e.promise = Promise.all(i.map(this.JSLoadFile.bind(this))).then(this.loadJS.bind(this, t)).then(this.afterLoadJS.bind(this, t)), e.promise)
    },
    isLoaded: function(t) {
        var e, i = SYNO.SDS.Config.FnMap,
            s = SYNO.SDS.Config.JSConfig[t],
            n = SYNO.SDS.JSLoad.JSStatus[t];
        for (var o in s)
            if (!/\/\.url$/.exec(o) && i[o].config.version) {
                e = i[o].config.version, n.version != e && (n.loaded = !1, n.version = e);
                break
            } return n.loaded
    },
    getDepends: function(t) {
        var e = SYNO.SDS.Config.JSConfig[t],
            i = [],
            s = [];
        return Ext.iterate(e, function(t, e) {
            i = i.concat(e.depend || []), s = s.concat(t)
        }), i.filter(function(t) {
            return -1 === s.indexOf(t)
        }).map(function(e) {
            if (!SYNO.SDS.Config.FnMap[e]) throw "fn not exist: " + e + ", depend by: " + t;
            return SYNO.SDS.Config.FnMap[e].jsFile
        }).filter(function(t, e, i) {
            return i.indexOf(t) === e && !this.isLoaded(t)
        }.bind(this))
    },
    loadJS: function(t) {
        return this.isLoaded(t) ? Promise.resolve() : new Promise(function(e, i) {
            switch (SYNO.SDS.JSDebug) {
                case "script":
                case "all":
                    SYNO.SDS.JSLoader.requestJSFileByScript(t, e, i);
                    break;
                default:
                    SYNO.SDS.JSLoader.requestJSFileByAjax(t, e, i)
            }
        })
    },
    afterLoadJS: function(t) {
        var e = SYNO.SDS.Config.FnMap,
            i = SYNO.SDS.Config.JSConfig[t],
            s = SYNO.SDS.JSLoad.JSStatus[t];
        for (var n in s.loading = !1, s.promise = null, i)
            if (i.hasOwnProperty(n)) {
                if (!e[n] || "app" !== e[n].config.type && "lib" !== e[n].config.type && "widget" !== e[n].config.type && "standalone" !== e[n].config.type) continue;
                try {
                    Ext.getClassByName(n).prototype.jsConfig = e[n].config
                } catch (t) {
                    if (SYNO.Debug.error("JSLoad apply JSConfig to " + n + " failed: ", t), Ext.isDefined(SYNO.SDS.JSDebug)) throw t
                }
            } s.loaded = !0
    },
    printLoopStat: function(t, e) {
        SYNO.Debug.error("=== loop start ==="), SYNO.Debug.error(t, "depends on", e), Ext.each(e, function(t) {
            SYNO.Debug.error(t, "depends on", this.getDepends(t))
        }, this), SYNO.Debug.error("=== loop end ===")
    }
}), SYNO.SDS.JSLoad = function(t, e, i) {
    SYNO.SDS.JSLoader.JSLoadFn(t).then(function() {
        Ext.isFunction(e) && e.call(i)
    }, function(t) {
        SYNO.Debug.error(t, t.stack)
    })
}, SYNO.SDS.JSLoad.overrideConfig = function() {
    var t, e = SYNO.SDS.Config.FnMap,
        i = "../../resources/images/package/",
        s = {
            "SYNO.SDS._ThirdParty.Desktop.MailStation": {
                allUsers: !0,
                icon: i + "MailStation_{0}.png"
            },
            "SYNO.SDS._ThirdParty.Desktop.SqueezeCenter": {
                icon: i + "SqueezeboxServer_{0}.png"
            },
            "SYNO.SDS._ThirdParty.Desktop.Webalizer": {
                icon: i + "Webalizer_{0}.png"
            },
            "SYNO.SDS._ThirdParty.Desktop.phpMyAdmin": {
                icon: i + "phpMyAdmin_{0}.png"
            },
            "SYNO.SDS.PersonalPhotoStation": {
                title: "Photo Station - " + _S("user")
            }
        };
    for (t in Ext.isIE7 && Ext.apply(s, {
            "SYNO.SDS.DownloadStation.Application": {
                type: "standalone"
            },
            "SYNO.SDS.AudioStation.Application": {
                type: "standalone"
            }
        }), s) Ext.isObject(e[t]) && Ext.apply(e[t].config, s[t])
}, SYNO.SDS.JSLoad.init = function() {
    SYNO.SDS.Config.FnMap = {}, SYNO.SDS.Config.AutoLaunchFnList = [];
    var t = SYNO.SDS.Config.JSConfig,
        e = SYNO.SDS.Config.FnMap;

    function i(t, e) {
        "app" === e.type && !0 === e.autoLaunch && (e.dependApp ? SYNO.SDS.Config.AutoLaunchFnList.push({
            appName: t,
            dependName: e.dependApp
        }) : SYNO.SDS.Config.AutoLaunchFnList.push(t))
    }

    function s(t, i, n) {
        var o = e[i].config.depend;
        if (n.push(i), Ext.isArray(o)) {
            var r = o.indexOf(t);
            if (r >= 0) return SYNO.Debug.warn("Dependency loop detected: " + t + " <--\x3e " + i), void o.splice(r, 1);
            for (var a = 0; a < o.length; ++a) {
                var l = o[a];
                e[l] ? n.indexOf(l) < 0 && s(t, l, n) : (SYNO.Debug.warn("Dependency missing: " + i + " --\x3e " + l), o.splice(a, 1), --a)
            }
        }
    }
    e["SYNO.SDS.VirtualGroup"] = {
            config: {
                title: "Group Icon",
                jsBaseURL: "resources"
            }
        },
        function() {
            var n = [],
                o = function(t) {
                    Ext.isString(t.getIconFn) && n.push(t.getIconFn)
                };
            for (var r in t)
                if (t.hasOwnProperty(r)) {
                    for (var a in t[r])
                        if (t[r].hasOwnProperty(a)) {
                            if (Ext.isObject(e[a])) {
                                SYNO.Debug.warn(a + " Conflict!!! " + e[a].jsFile + ", " + r);
                                continue
                            }
                            e[a] = {
                                jsFile: r,
                                jsFileConfig: t[r],
                                config: t[r][a]
                            }, Ext.isArray(t[r][a].fb_extern) && Ext.each(t[r][a].fb_extern, o)
                        } if (Ext.isObject(SYNO.SDS.JSLoad.JSStatus[r])) {
                        var l = SYNO.SDS.JSLoad.JSStatus[r],
                            c = _S("fullversion");
                        for (var d in t[r]) t[r].hasOwnProperty(d) && !/\/\.url$/.exec(d) && e[d] && e[d].config.version && (c = e[d].config.version, l.version != c && (SYNO.SDS.JSLoad.JSStatus[r][d] = !1, l.loaded = !1))
                    } else SYNO.SDS.JSLoad.JSStatus[r] = {}, /\/\.url$/.exec(r) && (SYNO.SDS.JSLoad.JSStatus[r].loaded = !0)
                } if (!Ext.isEmpty(n) && e["SYNO.SDS.App.FileStation3.Instance"]) {
                var u = e["SYNO.SDS.App.FileStation3.Instance"].jsFileConfig["SYNO.SDS.App.FileStation3.Instance"];
                u.depend = u.depend.concat(n)
            }
            for (var h in SYNO.SDS.JSLoad.overrideConfig(), e)
                if (e.hasOwnProperty(h)) {
                    if ("standalone" === e[h].config.type || !0 === e[h].config.allowStandalone) {
                        var p = Ext.urlDecode(window.location.search.substr(1)) || {};
                        e[h].config.url = SYNO.SDS.WindowLauncher.Util.getStandaloneLaunchURL(h, p)
                    }
                    s(h, h, []), i(h, e[h].config)
                }
        }()
}, SYNO.SDS.JSLoad.RemoveJSSatusByAppName = function(t) {
    var e = SYNO.SDS.Config.FnMap[t],
        i = SYNO.SDS.Config.JSConfig;
    e && (SYNO.SDS.JSLoad.JSStatus[e.jsFile] = {}, i[e.jsFile] && (i[e.jsFile].isLoaded = !1))
}, SYNO.SDS.JSLoad.JSStatus = {}, Ext.namespace("SYNO.SDS.AppLaunch"), SYNO.SDS.WindowLaunch = function(t, e, i, s) {
    return new SYNO.SDS.WindowLauncher(SYNO.SDS.WindowLauncher.Util.parseOptions(t, e, i, s)).launch()
}, SYNO.SDS.WindowLaunchToWindow = function(t, e, i) {
    return new SYNO.SDS.WindowLauncher(SYNO.SDS.WindowLauncher.Util.parseOptions(t, e, !1)).launch(i)
}, Ext.define("SYNO.SDS.WindowLauncher", {
    extend: "Ext.util.Observable",
    validType: ["standalone", "url", "legacy"],
    constructor: function(t) {
        if (Ext.copyTo(this, t, ["className", "param", "url", "type", "isOpenNewWindow", "appConfig"]), !this.appConfig) {
            var e = SYNO.SDS.Config.FnMap[t.className];
            this.appConfig = e.config
        }
    },
    launch: function(t) {
        if (!this.isValidType()) return !1;
        if (this.isLaunchFromURL() && !this.checkLaunchFromURL()) return this.alterNotSupport(), !1;
        var e = this.getLaunchURL();
        return this.isOpenNewWindow ? this.openNewWindow(t, e) : (t || this.maskDesktop(), (t || window).location = e, t || window)
    },
    isValidType: function() {
        return -1 != this.validType.indexOf(this.type)
    },
    openNewWindow: function(t, e) {
        var i = this.appConfig,
            s = i.urlTarget ? i.urlTarget + (i.allowFixedURLTarget ? "" : SYNO.SDS.LaunchTime) : "_blank",
            n = i.windowParam || "";
        return (t || window).open(e, s, n)
    },
    isLaunchFromURL: function() {
        return "url" === this.type
    },
    checkLaunchFromURL: function() {
        return !(SYNO.SDS.QuickConnect.Utils.isInTunnel() && !SYNO.SDS.IsDSMPortalWhiteList(this.className))
    },
    getLaunchParam: function() {
        if (!this.param) return {};
        var t, e = Ext.urlEncode(this.param);
        return Ext.isEmpty(e) ? {} : (t = {
            launchParam: e
        }, this.param.ieMode && (t.ieMode = this.param.ieMode), t)
    },
    getLaunchURL: function() {
        var t, e;
        return t = this.getLaunchParam(), e = this.resolveRelativeURL(this.url), this.appendParam(e, t)
    },
    resolveRelativeURL: function(t) {
        var e = "http" !== t.substr(0, 4).toLowerCase(),
            i = this.appConfig;
        if (!e) return t;
        if (i.port || i.protocol) {
            var s = i.protocol || window.location.protocol,
                n = i.port || window.location.port || "";
            n && (n = ":" + n), SYNO.SDS.QuickConnect.Utils.isInTunnel() && (s = "https", n = ""), t = s + "://" + window.location.hostname + n + t
        }
        return t
    },
    appendParam: function(t, e) {
        var i, s, n = t.split("?");
        n.length > 2 && (n[1] = n.splice(1, n.length - 1).join("?")), i = n[1] ? Ext.urlDecode(n[1]) : {}, s = Ext.apply(i, e);
        var o = n[0],
            r = Ext.urlEncode(s);
        return t = Ext.urlAppend(o, r, !1)
    },
    alterNotSupport: function() {
        new SYNO.SDS.MessageBoxV5({
            modal: !0,
            draggable: !1,
            renderTo: document.body
        }).alert(_T("relayservice", "package_not_supported"), _T("relayservice", "package_not_supported"))
    },
    maskDesktop: function() {
        var t = SYNO.SDS.Desktop.getEl();
        t.addClass("sds-window-v5"), t.addClass("sds-standalone-desktop"), t.mask(_T("common", "loading"), "x-mask-loading x-standalone-loading")
    }
}), Ext.define("SYNO.SDS.WindowLauncher.Util", {
    statics: {
        getStandaloneLaunchURL: function(t, e) {
            var i = SYNO.SDS.Config.FnMap[t];
            if (i) return e = Ext.apply(e || {}, {
                launchApp: t
            }), Ext.urlAppend(window.location.protocol + "//" + window.location.host + window.location.pathname, Ext.urlEncode(e), !i.config.allowURLNoSynoToken)
        },
        parseOptions: function(t, e, i, s) {
            var n = SYNO.SDS.Config.FnMap[t];
            if (!n) return !1;
            var o = "";
            s && s.url ? o = s.url : n.config.url ? o = n.config.url : SYNO.SDS.UrlTag[n.config.urlTag] && (o = SYNO.SDS.UrlTag[n.config.urlTag], !0 === n.config.appendSynoTokenInUrlTag && (o = Ext.urlAppend(o)));
            var r = n.config.type;
            return n.config.allowStandalone && (r = "standalone"), !1 !== i && (i = !0), {
                className: t,
                param: e,
                url: o,
                type: r,
                isOpenNewWindow: i,
                appConfig: n.config
            }
        }
    }
}), SYNO.SDS.IsDSMPortalWhiteList = function(t) {
    return t in {
        "SYNO.SDS.PersonalPhotoStation": !0,
        "SYNO.SDS.PhotoStation": !0,
        "SYNO.SDS.SurveillanceStation": !0
    }
}, SYNO.SDS.IsHABlackList = function(t) {
    for (var e = ["SYNO.SDS.EzInternet.Instance"], i = 0; i < e.length; i++)
        if ("SYNO.SDS.EzInternet.Instance" === t) return !0;
    return !1
}, SYNO.SDS.AppLaunch = function(t, e, i, s, n) {
    var o, r = null,
        a = SYNO.SDS.Config.FnMap[t],
        l = null,
        c = t,
        d = function() {
            var i = 0,
                s = SYNO.SDS.AppMgr.getByAppName(t);
            return !0 === o.matchInstanceName ? s.each(function(t, s, n) {
                t.instanceName === e.instanceName && (l = t, i++)
            }) : i = s.length, i
        },
        u = function() {
            var t = o.loadingCnt || 0,
                e = d(),
                i = o.allowMultiInstance ? o.maxInstance || 0 : 1;
            return !i || i > t + e
        };
    if (a && a.config)
        if (o = a.config, _S("ha_running") && SYNO.SDS.IsHABlackList(t)) new SYNO.SDS.MessageBoxV5({
            modal: !0,
            draggable: !1,
            renderTo: document.body
        }).getWrapper().alert(_D("product"), _TT("SYNO.SDS.HA.Instance", "ui", "warning_forbidden_action"));
        else if (SYNO.SDS.Config.CheckCSPRefresh && -1 != SYNO.SDS.Config.CheckCSPRefresh.indexOf(t)) SYNO.SDS.Desktop.getMsgBox().confirm(_D("product"), _T("pkgmgr", "csp_need_refresh"), function(o) {
        if ("yes" !== o) {
            var r = SYNO.SDS.Config.CheckCSPRefresh.indexOf(t);
            SYNO.SDS.Config.CheckCSPRefresh.splice(r, 1), SYNO.SDS.AppLaunch(t, e, i, s, n)
        } else window.location.href = "/"
    }, this);
    else if (e && e.className && (c = e.className), SYNO.SDS.StatusNotifier.isAppEnabled(c))
        if ("url" === o.type || "standalone" === o.type && !_S("standalone") || "legacy" === o.type && "url" === o.urlDefMode) SYNO.SDS.WindowLaunch(t, e, !_S("rewriteApp") && "url" !== o.type);
        else if ("standalone" === o.type || "app" === o.type || "legacy" === o.type) {
        if (SYNO.SDS.WindowMgr.allHided) return SYNO.SDS.WindowMgr.toggleAllWin(), void SYNO.SDS.AppLaunch.defer(1e3, this, arguments);
        if (SYNO.SDS.WindowMgr.exposeMask) return SYNO.SDS.WindowMgr.exposeWindow(), void SYNO.SDS.AppLaunch.defer(1e3, this, arguments);
        if (e = e || {}, Ext.isString(e) && (e = Ext.urlDecode(e)), i = i && (o.allowMultiInstance || !1), !_S("standalone") && !0 !== o.hideTaskBtn && Ext.isDefined(o.appWindow) && (i && u() || !d() && !o.loadingCnt) && (r = SYNO.SDS.TaskButtons.add(t, o.appWindow)).setState("loading"), Ext.isNumber(o.loadingCnt) || (o.loadingCnt = 0), o.loadingCnt++, _S("standalone")) {
            var h = s,
                p = SYNO.SDS.Desktop.getEl(),
                S = SYNO.SDS.Config.FnMap[SYNO.SDS.Session.standaloneAppName].config,
                f = ["sds-window-v5", "sds-window-init-loading", "sds-standalone-desktop"];
            S && Ext.isString(S.desktopcls) && f.push(S.desktopcls), p.addClass(f), S && !0 !== S.preventDesktopMask && p.mask(_T("common", "loading"), "x-mask-loading x-standalone-loading"), s = function() {
                h && h.call(n || window)
            }
        }
        SYNO.SDS.JSLoad(t, function a() {
            if (_S("standalone")) {
                var c = SYNO.SDS.Desktop.getEl();
                c.unmask(), c.removeClass(["sds-window-v5", "sds-window-init-loading"])
            }
            var d, h, p, S;
            try {
                var f;
                if (SYNO.SDS.WindowMgr.allHided) return SYNO.SDS.WindowMgr.toggleAllWin(), void SYNO.SDS.StatusNotifier.on("allwinrestored", a, this, {
                    single: !0
                });
                o.loadingCnt--;
                try {
                    f = Ext.getClassByName(t)
                } catch (t) {}
                if (f || "legacy" !== o.type || (p = o.url, S = "".concat("Ext.namespace('{0}');", "{0} = Ext.extend(SYNO.SDS.AppInstance, {", "appWindowName: '{0}.MainWindow'", "});", "{0}.MainWindow = Ext.extend(SYNO.SDS.LegacyAppWindow, {", "constructor: function(config) {", "{0}.MainWindow.superclass.constructor.call(this, Ext.apply({", "url: '{1}'", "}, config));", "}", "});", "{0}.prototype.jsConfig = SYNO.SDS.Config.FnMap['{0}'].config;", "{0}.MainWindow.prototype.jsConfig = SYNO.SDS.Config.FnMap['{0}'].config;"), window.execScript ? window.execScript(String.format(S, t, p), "JavaScript") : window.eval(String.format(S, t, p)), f = Ext.getClassByName(t)), r || i && u() || (h = null, !(l ? (l.open(e), 1) : (h = SYNO.SDS.AppMgr.getByAppName(t)).length > 0 && (h[h.length - 1].open(e), 1)))) {
                    if (!(f.prototype instanceof SYNO.SDS.AppInstance)) return void SYNO.Debug.error(t + " is not extends from AppInstance.");
                    if (!1 === function(e, i) {
                            return !(!Ext.isObject(i) || !i.is_cms_open) || SYNO.SDS.StatusNotifier.isAppEnabled(t)
                        }(0, e)) return;
                    (d = new f(Ext.copyTo({
                        taskButton: r
                    }, e, "instanceName"))).open(e)
                }
            } catch (e) {
                if (SYNO.Debug.error(t + " launch failed: ", e, e.stack), Ext.isDefined(SYNO.SDS.JSDebug)) throw e;
                return
            }
            s && s.call(n || window, d)
        })
    } else SYNO.Debug.error(t + " is not app type.")
}, Ext.namespace("SYNO.SDS.Gesture"), SYNO.SDS.Gesture.EmptyGesture = Ext.extend(Ext.util.Observable, {
    onTouchStart: Ext.emptyFn,
    onTouchMove: Ext.emptyFn,
    onTouchEnd: Ext.emptyFn,
    onTouchCancel: Ext.emptyFn
}), SYNO.SDS.Gesture.BaseGesture = Ext.extend(SYNO.SDS.Gesture.EmptyGesture, {
    constructor: function() {
        SYNO.SDS.Gesture.BaseGesture.superclass.constructor.apply(this, arguments)
    },
    getBrowserEvent: function(t) {
        return t && t.browserEvent ? t.browserEvent : null
    },
    getFirstTouch: function(t) {
        var e, i = null;
        return (e = this.getBrowserEvent(t)) && e.touches && e.touches.length > 0 && (i = e.touches[0]), i
    },
    getFirstChangedTouch: function(t) {
        var e, i = null;
        return (e = this.getBrowserEvent(t)) && e.changedTouches && e.changedTouches.length > 0 && (i = e.changedTouches[0]), i
    },
    getChangedTouchCount: function(t) {
        var e;
        return (e = this.getBrowserEvent(t)) && e.changedTouches && Ext.isNumber(e.changedTouches.length) ? e.changedTouches.length : -1
    },
    getTouchCount: function(t) {
        var e;
        return (e = this.getBrowserEvent(t)) && e.touches && Ext.isNumber(e.touches.length) ? e.touches.length : -1
    }
}), SYNO.SDS.Gesture.Swipe = Ext.extend(SYNO.SDS.Gesture.BaseGesture, {
    config: {
        minDistance: 80,
        maxOffset: 100,
        maxDuration: 1e3
    },
    fireSwipe: function(t, e, i, s, n) {
        SYNO.SDS.GestureMgr.fireEvent("swipe", t, e, i, s, n)
    },
    getMinDistance: function() {
        return this.config.minDistance
    },
    getMaxOffset: function() {
        return this.config.maxOffset
    },
    getMaxDuration: function() {
        return this.config.maxDuration
    },
    setInitialXY: function(t) {
        var e, i, s;
        for (e = 0, i = t.changedTouches.length; e < i; e++) s = t.changedTouches[e], this.initialTouches[s.identifier] = {
            x: s.pageX,
            y: s.pageY
        }
    },
    getInitialXY: function(t) {
        var e = this.initialTouches[t.identifier];
        return {
            x: e.x,
            y: e.y
        }
    },
    onTouchStart: function(t, e, i) {
        var s = this.getBrowserEvent(t);
        this.startTime = s.timeStamp, this.isHorizontal = !0, this.isVertical = !0, this.initialTouches || (this.initialTouches = {}), this.setInitialXY(s), this.touchCount = this.getTouchCount(t)
    },
    onTouchMove: function(t, e, i) {
        return 3 === this.getTouchCount(t) && (t.preventDefault(), this.checkTouchMove(t, e, i))
    },
    checkTouchXY: function(t, e, i) {
        var s, n, o, r;
        if (s = t.pageX, n = t.pageY, o = Math.abs(s - e), r = Math.abs(n - i), this.isVertical && o > this.getMaxOffset() && (this.isVertical = !1), this.isHorizontal && r > this.getMaxOffset() && (this.isHorizontal = !1), !this.isHorizontal && !this.isVertical) return this.fail()
    },
    checkTouchMove: function(t, e, i) {
        var s, n, o, r, a;
        if ((r = this.getBrowserEvent(t)).timeStamp - this.startTime > this.getMaxDuration()) return this.fail();
        for (s = 0, a = r.changedTouches.length; s < a; s++)
            if (o = r.changedTouches[s], n = this.initialTouches[o.identifier]) {
                if (!1 === this.checkTouchXY(o, n.x, n.y)) return !1
            } else SYNO.Debug.error("Error: initial does not exist when handle touchmove, TouchEvent id:" + o.identifier)
    },
    onTouchEnd: function(t, e, i) {
        var s, n, o, r, a, l, c, d, u, h, p, S;
        if (0 !== this.getTouchCount(t)) return !1;
        if (3 !== this.touchCount) return !1;
        if (!(s = this.getFirstChangedTouch(t))) return !1;
        if (n = s.pageX, o = s.pageY, a = n - (r = this.getInitialXY(s)).x, l = o - r.y, c = Math.abs(a), d = Math.abs(l), u = this.getMinDistance(), h = t.browserEvent.timeStamp - this.startTime, this.isVertical && d < u && (this.isVertical = !1), this.isHorizontal && c < u && (this.isHorizontal = !1), this.isHorizontal) p = a < 0 ? "left" : "right", S = c;
        else {
            if (!this.isVertical) return this.fail();
            p = l < 0 ? "up" : "down", S = d
        }
        this.fireSwipe(t, s, p, S, h)
    },
    fail: function() {
        return !1
    }
}), SYNO.SDS.Gesture.LongPress = Ext.extend(SYNO.SDS.Gesture.BaseGesture, {
    config: {
        minDuration: 500
    },
    fireLongPress: function(t, e) {
        SYNO.SDS.GestureMgr.fireEvent("longpress", t, e)
    },
    getMinDuration: function() {
        return this.config.minDuration
    },
    onTouchStart: function(t, e, i) {
        var s = this;
        this.timer && this.removeTimer(), this.timer = setTimeout(function() {
            s.fireLongPress(t, e), this.timer = null
        }, this.getMinDuration())
    },
    onTouchMove: function() {
        return this.fail()
    },
    onTouchEnd: function(t, e, i) {
        return this.fail()
    },
    removeTimer: function() {
        clearTimeout(this.timer), this.timer = null
    },
    fail: function() {
        return this.removeTimer(), !1
    }
}), SYNO.SDS.Gesture.DoubleTap = Ext.extend(SYNO.SDS.Gesture.BaseGesture, {
    config: {
        maxDuration: 300,
        maxOffset: 50
    },
    singleTapTimer: null,
    fireSingleTap: function(t, e) {},
    fireDoubleTap: function(t, e) {
        t.preventDefault(), SYNO.SDS.GestureMgr.fireEvent("doubletap", t, e)
    },
    getMaxDuration: function() {
        return this.config.maxDuration
    },
    getMaxOffset: function() {
        return this.config.maxOffset
    },
    onTouchStart: function(t, e, i) {
        t && t.browserEvent && this.isInMaxDuration(t.browserEvent.timeStamp, this.lastTapTime) && t.preventDefault()
    },
    onTouchMove: function() {
        return this.fail()
    },
    onTouchEnd: function(t, e, i) {
        var s, n, o, r, a = this.lastTapTime,
            l = this.lastX,
            c = this.lastY;
        return this.getTouchCount(t) > 0 ? this.fail() : (t && t.browserEvent && (s = t.browserEvent.timeStamp), this.lastTapTime = s, !!(n = this.getFirstChangedTouch(t)) && (o = n.pageX, r = n.pageY, this.lastX = o, this.lastY = r, a && this.checkXY(l, c) && this.isInMaxDuration(s, a) ? (this.lastTapTime = 0, void this.fireDoubleTap(t, e)) : void 0))
    },
    checkXY: function(t, e) {
        var i = Math.abs(this.lastX - t),
            s = Math.abs(this.lastY - e),
            n = this.getMaxOffset();
        return i < n && s < n
    },
    isInMaxDuration: function(t, e) {
        return !(!t || !e) && t - e <= this.getMaxDuration()
    },
    fail: function() {
        return this.lastTapTime = 0, this.lastX = void 0, this.lastY = void 0, !1
    }
}), Ext.ns("SYNO.SDS.Gesture.MS"), SYNO.SDS.Gesture.MS.Swipe = Ext.extend(SYNO.SDS.Gesture.Swipe, {
    config: {
        minDistance: 80,
        maxOffset: 500,
        maxDuration: 1e3
    },
    constructor: function() {
        SYNO.SDS.Gesture.MS.Swipe.superclass.constructor.apply(this, arguments)
    },
    setInitialXY: function(t) {
        this.initialTouches[t.pointerId] = {
            x: t.pageX,
            y: t.pageY
        }
    },
    getTouchCount: function() {
        var t, e = 0;
        if (this.initialTouches)
            for (t in this.initialTouches) this.initialTouches.hasOwnProperty(t) && e++;
        return e
    },
    checkTouchXY: function(t, e, i) {
        var s, n, o, r;
        if (s = t.pageX, n = t.pageY, o = Math.abs(s - e), r = Math.abs(n - i), this.isVertical && o > this.getMaxOffset() && (this.isVertical = !1), this.isHorizontal && r > this.getMaxOffset() && (this.isHorizontal = !1), !this.isHorizontal && !this.isVertical) return this.fail()
    },
    checkTouchMove: function(t, e, i) {
        var s, n;
        if ((n = this.getBrowserEvent(t)).timeStamp - this.startTime > this.getMaxDuration()) return this.fail();
        for (s in this.initialTouches)
            if (this.initialTouches.hasOwnProperty(s)) {
                var o, r = this.initialTouches[s];
                if (n && n.touches && n.touches.length > 0 && (o = n.touches[0]), !r) {
                    SYNO.Debug.error("Error: initial does not exist when handle touchmove, TouchEvent id:" + o.identifier);
                    continue
                }
                if (!1 === this.checkTouchXY(n, r.x, r.y)) return !1
            }
    },
    onTouchStart: function(t, e, i) {
        var s = this.getBrowserEvent(t);
        this.startTime = s.timeStamp, this.isHorizontal = !0, this.isVertical = !0, this.initialTouches || (this.initialTouches = {}), this.setInitialXY(s), this.touchCount = this.getTouchCount()
    },
    onTouchMove: function(t, e, i) {
        return 3 === this.getTouchCount() && (t.preventDefault(), this.checkTouchMove(t, e, i))
    },
    onTouchEnd: function(t, e, i) {
        var s, n, o, r, a, l, c, d, u, h, p, S = this.getBrowserEvent(t);
        if (!this.initialTouches || !this.initialTouches[S.pointerId]) return !1;
        if (p = this.initialTouches[S.pointerId], delete this.initialTouches[S.pointerId], 0 !== this.getTouchCount()) return !1;
        if (3 !== this.touchCount) return !1;
        if (s = S.pageX, n = S.pageY, o = s - p.x, r = n - p.y, a = Math.abs(o), l = Math.abs(r), c = this.getMinDistance(), d = S.timeStamp - this.startTime, this.isVertical && l < c && (this.isVertical = !1), this.isHorizontal && a < c && (this.isHorizontal = !1), this.isHorizontal) u = o < 0 ? "left" : "right", h = a;
        else {
            if (!this.isVertical) return this.fail();
            u = r < 0 ? "up" : "down", h = l
        }
        this.fireSwipe(t, void 0, u, h, d)
    },
    onTouchCancel: function() {
        this.fail(), delete this.initialTouches
    }
}), SYNO.SDS.Gesture.EmptyGestureObject = new SYNO.SDS.Gesture.EmptyGesture, SYNO.SDS.Gesture.MS.EmptyGestureObject = SYNO.SDS.Gesture.EmptyGestureObject, SYNO.SDS.Gesture.GestureFactory = Ext.extend(Object, {
    create: function(t) {
        var e = SYNO.SDS.UIFeatures.test("msPointerEnabled"),
            i = "SYNO.SDS.Gesture." + (e ? "MS." : "");
        switch (t) {
            case "Swipe":
                if (e && (window.navigator.msMaxTouchPoints ? window.navigator.msMaxTouchPoints : 0) < 3) return SYNO.SDS.Gesture.MS.EmptyGestureObject;
                i += t;
                break;
            case "LongPress":
            case "DoubleTap":
                if (e) return SYNO.SDS.Gesture.MS.EmptyGestureObject;
                i += t;
                break;
            default:
                return e ? SYNO.SDS.Gesture.MS.EmptyGestureObject : SYNO.SDS.Gesture.EmptyGestureObject
        }
        return this.getGestureInstance(i)
    },
    getGestureInstance: function(t) {
        return new(Ext.getClassByName(t))
    }
}), Ext.namespace("SYNO.SDS._GestureMgr"), SYNO.SDS._GestureMgr = Ext.extend(Ext.util.Observable, {
    constructor: function() {
        SYNO.SDS._GestureMgr.superclass.constructor.apply(this, arguments), this.gestures = ["Swipe", "LongPress", "DoubleTap"], this.init()
    },
    init: function() {
        var t, e, i, s, n = SYNO.SDS.UIFeatures.test("msPointerEnabled");
        for (i = Ext.getDoc(), t = 0, e = this.gestures.length; t < e; t++) s = this.getGestureInstance(this.gestures[t]), Ext.EventManager.on(i, n ? "MSPointerCancel" : "touchcancel", s.onTouchCancel, s), Ext.EventManager.on(i, n ? "MSPointerDown" : "touchstart", s.onTouchStart, s), Ext.EventManager.on(i, n ? "MSPointerUp" : "touchend", s.onTouchEnd, s), Ext.EventManager.on(i, n ? "MSPointerMove" : "touchmove", s.onTouchMove, s);
        this.addGestureHandlers()
    },
    addGestureHandlers: function() {
        this.on("swipe", this.swipeHandler, this, {
            buffer: 10
        }), this.on("longpress", this.longPressHandler, this), this.on("doubletap", this.doubleTapHandler, this)
    },
    getGestureInstance: function(t) {
        return this.gestureFactory = this.gestureFactory || new SYNO.SDS.Gesture.GestureFactory, this.gestureFactory.create(t)
    },
    swipeHandler: function(t, e, i, s, n) {
        var o;
        "right" === i ? SYNO.SDS.TaskButtons.setRightWindowActive() : "left" === i ? SYNO.SDS.TaskButtons.setLeftWindowActive() : "up" === i && (o = SYNO.SDS.WindowMgr.getActiveAppWindow()) && o.minimize()
    },
    longPressHandler: function(t, e) {
        var i, s, n;
        for (s = 0, n = (i = this.findEventHandlers(e, "contextmenu")).length; s < n; s++) i[s](t.browserEvent)
    },
    doubleTapHandler: function(t, e) {
        var i, s, n;
        for (s = 0, n = (i = this.findEventHandlers(e, "dblclick")).length; s < n; s++) i[s](t.browserEvent)
    },
    findEventHandlers: function(t, e) {
        for (var i, s, n, o, r = Ext.get(t), a = []; r;) {
            if (i = Ext.EventManager.getListeners(r, e)) {
                for (s = 0, n = i.length; s < n; s++) o = i[s], a.push(o[1]);
                break
            }
            r = r.parent()
        }
        return a
    }
}), Ext.BLANK_IMAGE_URL = "scripts/ext-3/resources/images/default/s.gif", Ext.data.Connection.prototype.timeout = 12e4, Ext.form.BasicForm.prototype.timeout = 120, Ext.QuickTip.prototype.maxWidth = 500, Ext.override(Ext.QuickTip, {
    hide: function() {
        return this.getEl().animate({
            opacity: {
                from: 1,
                to: 0
            }
        }, .3, function() {
            delete this.activeTarget, Ext.QuickTip.superclass.hide.call(this), this.getEl().setOpacity(1)
        }.createDelegate(this))
    }
}), Ext.apply(SYNO.LayoutConfig.Defaults.combo, {
    getListParent: function() {
        return this.el.up(".sds-window")
    }
}), Ext.override(Ext.Element, {
    addClassOnHover: function(t) {
        var e = this;
        "ontouchstart" in window || window.navigator.msPointerEnabled && window.navigator.msMaxTouchPoints > 0 ? Ext.getDoc().on("click", function(i) {
            i.within(e) ? e.addClass(t) : e.removeClass(t)
        }, e) : e.addClassOnOver(t)
    }
}), Ext.override(Ext.Component, {
    getTaskRunner: function() {
        return this.taskRunner || (this.taskRunner = new SYNO.SDS.TaskRunner, this.addManagedComponent(this.taskRunner)), this.taskRunner
    },
    addTask: function(t) {
        return this.getTaskRunner().createTask(t)
    },
    addAjaxTask: function(t) {
        return this.getTaskRunner().createAjaxTask(t)
    },
    addWebAPITask: function(t) {
        return this.getTaskRunner().createWebAPITask(t)
    },
    getTask: function(t) {
        return this.taskRunner ? this.taskRunner.getTask(t) : null
    },
    removeTask: function(t) {
        var e = this.getTask(t);
        return e && e.remove(), e
    },
    addManagedComponent: function(t) {
        return this.components = this.components || [], this.components.push(t), t
    },
    removeManagedComponent: function(t) {
        return this.components = this.components || [], this.components.remove(t), t
    },
    beforeDestroy: function() {
        this.taskRunner = null, this.components = this.components || [];
        for (var t = 0; t < this.components.length; ++t) try {
            this.components[t].destroy()
        } catch (e) {
            if (Ext.isDefined(SYNO.SDS.JSDebug)) throw SYNO.Debug.error(this.id, "sub-components[" + t + "] destroy failed.", this.components[t]), e
        }
        delete this.components
    },
    findWindow: function() {
        var t = this;
        if (t instanceof SYNO.SDS.BaseWindow) return t;
        for (; Ext.isObject(t.ownerCt); t = t.ownerCt);
        return t instanceof SYNO.SDS.BaseWindow ? t : void 0
    },
    findAppWindow: function() {
        var t = this,
            e = Ext.getClassByName("SYNO.SDS.AppWindow");
        if (!Ext.isEmpty(e)) {
            if (t instanceof e) return t;
            if (t._appWindow instanceof e) return t._appWindow;
            for (; Ext.isObject(t.ownerCt); t = t.ownerCt);
            if (t instanceof e) return this._appWindow = t, t;
            if (Ext.isObject(t)) {
                for (; Ext.isObject(t.owner); t = t.owner);
                return t instanceof e ? (this._appWindow = t, t) : t.module && t.module.appWin && t.module.appWin instanceof e ? (this._appWindow = t.module.appWin, t.module.appWin) : void 0
            }
        }
    },
    getDsmVersion: function() {
        var t = this.findAppWindow();
        return t ? t.getOpenConfig("dsm_version") : null
    },
    getDsmHttpPort: function() {
        var t, e = this.findAppWindow();
        return e && e.hasOpenConfig("cms_ds_data") && (t = e.getOpenConfig("cms_ds_data").http_port), t
    },
    getDsmHost: function() {
        var t, e = this.findAppWindow();
        return e && e.hasOpenConfig("cms_ds_data") && (t = e.getOpenConfig("cms_ds_data").host), t
    },
    getBaseURL: function(t, e, i) {
        return t.appWindow = this.findAppWindow(), SYNO.API.GetBaseURL(t, e, i)
    },
    sendWebAPI: function(t) {
        return t.appWindow = this.findAppWindow(), SYNO.API.Request(t)
    },
    sendWebAPIPromise: function(t) {
        return new Promise(function(e, i) {
            t.callback = function(t, s, n, o) {
                t ? e(s) : i(s)
            }, this.sendWebAPI(t)
        }.bind(this))
    },
    pollReg: function(t) {
        return t.appWindow = this.findAppWindow(), SYNO.API.Request.Polling.Register(t)
    },
    pollUnreg: function(t) {
        return SYNO.API.Request.Polling.Unregister(t)
    },
    pollList: function(t) {
        return t.appWindow = this.findAppWindow(), SYNO.API.Request.Polling.List(t)
    },
    downloadWebAPI: function(t) {
        return t.appWindow = this.findAppWindow(), SYNO.SDS.Utils.IFrame.requestWebAPI(t)
    },
    IsAllowRelay: function() {
        var t = this.findAppWindow();
        return !!Ext.isObject(t) && (SYNO.SDS.Utils.IsAllowRelay && SYNO.SDS.Utils.IsAllowRelay(t))
    },
    _S: function(t) {
        var e = this.findAppWindow();
        return SYNO.API.Info.GetSession(e, t)
    },
    _D: function(t, e) {
        var i = this.findAppWindow();
        return SYNO.API.Info.GetDefine(i, t, e)
    },
    getKnownAPI: function(t) {
        var e = this.findAppWindow();
        return SYNO.API.Info.GetKnownAPI(e, t)
    },
    IsKnownAPI: function(t, e) {
        var i = SYNO.API.Info.GetKnownAPI(this.findAppWindow(), t);
        return !!Ext.isObject(i) && !(e < i.minVersion || i.maxVersion < e)
    }
}), Ext.override(Ext.grid.GridView, {
    onLayout: function() {
        var t = this.el.select(".x-grid3-scroller", this).elements[0];
        t.clientWidth === t.offsetWidth ? this.scrollOffset = 2 : this.scrollOffset = void 0, this.fitColumns(!1)
    }
}), Ext.override(Ext.data.Record, {
    set: function(t, e) {
        var i, s = Ext.isPrimitive(e) ? String : Ext.encode;
        if (s(this.data[t]) != s(e)) {
            if (this.dirty = !0, this.modified || (this.modified = {}), t in this.modified && this.modified[t] === e) {
                for (i in this.dirty = !1, delete this.modified[t], this.modified)
                    if (this.modified.hasOwnProperty(i)) {
                        this.dirty = !0;
                        break
                    }
            } else t in this.modified || (this.modified[t] = this.data[t]);
            this.data[t] = e, this.editing || this.afterEdit()
        }
    }
}), Ext.override(Ext.data.Store, {
    afterEdit: function(t) {
        var e = this.modified.indexOf(t);
        t.dirty && -1 == e ? this.modified.push(t) : t.dirty || -1 == e || this.modified.splice(e, 1), this.fireEvent("update", this, t, Ext.data.Record.EDIT)
    }
}), Ext.Element.addMethods(Ext.Fx), Ext.override(Ext.dd.DragSource, {
    validateTarget: function(t, e, i) {
        return !(i !== e.getTarget().id && !e.within(i)) || (this.getProxy().setStatus(this.dropNotAllowed), !1)
    },
    beforeDragEnter: function(t, e, i) {
        return this.validateTarget(t, e, i)
    },
    beforeDragOver: function(t, e, i) {
        var s = this.validateTarget(t, e, i);
        return this.proxy && this.proxy.setStatus(s ? this.dropAllowed : this.dropNotAllowed), s
    },
    beforeDragOut: function(t, e, i) {
        return this.validateTarget(t, e, i)
    },
    beforeDragDrop: function(t, e, i) {
        return !!this.validateTarget(t, e, i) || (this.onInvalidDrop(t, e, i), !1)
    }
}), Ext.override(Ext.form.CompositeField, {
    combineErrors: !1
}), Ext.isIE && (Ext.menu.BaseItem.prototype.clickHideDelay = -1), Ext.override(Ext.Window, {
    onRender: function(t, e) {
        Ext.Window.superclass.onRender.call(this, t, e), this.plain && this.el.addClass("x-window-plain"), this.focusEl = this.el.createChild({
            tag: "div",
            cls: "x-dlg-focus",
            tabIndex: "0",
            role: this.ariaRole || "dialog",
            "aria-label": this.title
        }, this.el.first()), this.focusEl.swallowEvent("click", !0), this.focusEl.addKeyListener(Ext.EventObject.TAB, this.onFirstTab, this), this.lastEl = this.el.createChild({
            tag: "div",
            cls: "x-dlg-focus",
            tabIndex: 0,
            role: "article",
            html: _T("desktop", "window_last_hint")
        }), this.lastEl.addKeyListener(Ext.EventObject.TAB, this.onLastTab, this), this.proxy = this.el.createProxy("x-window-proxy"), this.proxy.enableDisplayMode("block"), this.modal && (this.maskEl = this.container.createChild({
            cls: "ext-el-mask"
        }, this.el.dom), this.maskEl.enableDisplayMode("block"), this.maskEl.hide(), this.mon(this.maskEl, "click", this.focus, this)), this.maximizable && this.mon(this.header, "dblclick", this.toggleMaximize, this), this.frame && this.header && (this.tl = this.header.dom.parentNode.parentNode.parentNode)
    },
    onLastTab: function(t, e) {
        e.shiftKey || (e.preventDefault(), this.focusEl.focus())
    },
    onFirstTab: function(t, e) {
        if (e.shiftKey) e.preventDefault(), this.lastEl.focus();
        else if (Ext.isFunction(this.findTopWin)) {
            var i = this.findTopWin();
            i !== this && (e.preventDefault(), i.focus())
        }
    },
    beforeShow: function() {
        if (delete this.el.lastXY, delete this.el.lastLT, void 0 === this.x || void 0 === this.y) {
            var t = this.el.getAlignToXY(this.container, "c-c"),
                e = this.el.translatePoints(t[0], t[1]);
            this.x = void 0 === this.x ? e.left : this.x, this.y = void 0 === this.y ? e.top : this.y
        }
        this.el.setLeftTop(this.x, this.y), this.expandOnShow && this.expand(!1), this.modal && (Ext.getBody().addClass("x-body-masked"), this.maskEl.setSize(Ext.lib.Dom.getViewWidth(!0), Ext.lib.Dom.getViewHeight(!0)), this.maskEl.show())
    },
    onWindowResize: function() {
        this.maximized && this.fitContainer(), this.modal && (this.maskEl.setSize("100%", "100%"), this.maskEl.setSize(Ext.lib.Dom.getViewWidth(!0), Ext.lib.Dom.getViewHeight(!0))), this.doConstrain()
    },
    setZIndex: function(t) {
        this.modal && this.maskEl.setStyle("z-index", t), this.el.setZIndex(++t), t += 5, this.resizer && this.resizer.proxy.setStyle("z-index", ++t), this.lastZIndex = t
    },
    beforeDestroy: function() {
        this.rendered && (this.hide(), this.clearAnchor(), Ext.destroy(this.focusEl, this.resizer, this.dd, this.proxy, this.maskEl)), Ext.Window.superclass.beforeDestroy.call(this)
    },
    hide: function(t, e, i) {
        return this.hidden || !1 === this.fireEvent("beforehide", this) ? this : (e && this.on("hide", e, i, {
            single: !0
        }), this.hidden = !0, void 0 !== t && this.setAnimateTarget(t), this.modal && (this.maskEl.hide(), Ext.getBody().removeClass("x-body-masked")), this.animateTarget ? this.animHide() : (this.el.hide(), this.afterHide()), this)
    },
    getFrameHeight: function() {
        var t = this.el.getFrameWidth("tb") + this.bwrap.getFrameWidth("tb");
        return t += (this.tbar ? this.tbar.getHeight() : 0) + (this.bbar ? this.bbar.getHeight() : 0), this.frame ? t += (this.tl || this.el.dom.firstChild).offsetHeight + this.ft.dom.offsetHeight + this.mc.getFrameWidth("tb") : t += (this.header ? this.header.getHeight() : 0) + (this.footer ? this.footer.getHeight() : 0), t
    },
    toFront: function(t) {
        this.manager.bringToFront(this) && (this.focusLeave = !1, t && t.getTarget().focus ? (t.getTarget().focus(), document.activeElement !== t.getTarget() && this.focus()) : this.focus())
    }
}), Ext.override(Ext.grid.RowSelectionModel, {
    silentMode: !1,
    onRefresh: function() {
        var t, e, i = this.grid.store,
            s = this.getSelections(),
            n = 0,
            o = s.length;
        for (this.silent = this.silentMode && !0, this.clearSelections(!0); n < o; n++) e = s[n], -1 != (t = i.indexOfId(e.id)) && this.selectRow(t, !0);
        s.length != this.selections.getCount() && this.fireEvent("selectionchange", this), this.silent = !1
    }
}), Ext.override(Ext.grid.GridPanel, {
    getValues: function() {
        var t = [],
            e = this.getStore();
        return Ext.isObject(e) ? (e.each(function(e, i, s) {
            t.push(Ext.apply({}, e.data))
        }, this), t) : t
    },
    setValues: function(t) {
        var e = this.getStore(),
            i = [];
        if (!Ext.isObject(e) || !Ext.isArray(t)) return !1;
        e.removeAll(), t.each(function(t) {
            i.push(new Ext.data.Record(t))
        }, this), e.add(i)
    }
}), Ext.override(Ext.grid.GridView.ColumnDragZone, {
    getDragData: function(t) {
        var e = Ext.lib.Event.getTarget(t),
            i = this.view.findHeaderCell(e);
        return !!i && {
            ddel: Ext.fly(i).child("div.x-grid3-hd-inner", !0),
            header: i
        }
    }
}), Ext.override(Ext.grid.HeaderDropZone, {
    positionIndicator: function(t, e, i) {
        var s, n, o = Ext.lib.Event.getPageX(i),
            r = Ext.lib.Dom.getRegion(Ext.fly(e).child("div.x-grid3-hd-inner", !0)),
            a = r.top + this.proxyOffsets[1];
        return r.right - o <= (r.right - r.left) / 2 ? (s = r.right + this.view.borderWidth, n = "after") : (s = r.left, n = "before"), !this.grid.colModel.isFixed(this.view.getCellIndex(e)) && (s += this.proxyOffsets[0], this.proxyTop.setLeftTop(s, a), this.proxyTop.show(), this.bottomOffset || (this.bottomOffset = this.view.mainHd.getHeight()), this.proxyBottom.setLeftTop(s, a + this.proxyTop.dom.offsetHeight + this.bottomOffset), this.proxyBottom.show(), n)
    },
    onNodeDrop: function(t, e, i, s) {
        var n = s.header;
        if (n != t) {
            var o = this.grid.colModel,
                r = Ext.lib.Event.getPageX(i),
                a = Ext.lib.Dom.getRegion(Ext.fly(t).child("div.x-grid3-hd-inner", !0)),
                l = a.right - r <= (a.right - a.left) / 2 ? "after" : "before",
                c = this.view.getCellIndex(n),
                d = this.view.getCellIndex(t);
            return "after" == l && d++, c < d && d--, o.moveColumn(c, d), !0
        }
        return !1
    }
}), Ext.override(SYNO.ux.ModuleList, {
    getLocalizedString: function(t) {
        return SYNO.SDS.Utils.GetLocalizedString(t)
    }
}), Ext.override(SYNO.ux.FieldSet, {
    stateful: !0,
    stateEvents: ["expand", "collapse"],
    getState: function() {
        return {
            collapsed: this.collapsed
        }
    },
    saveState: function() {
        var t = this.getState();
        this.setUserCollapseState(t.collapsed)
    },
    getUserCollapseState: function() {
        var t = this.getStateId(),
            e = this.findAppWindow();
        if (e && e.appInstance && t) {
            var i = e.appInstance.getUserSettings("fieldset_collapse_status") || {};
            return Ext.isBoolean(i[t]) ? i[t] : this.collapsed
        }
        return this.collapsed
    },
    setUserCollapseState: function(t) {
        var e = this.getStateId(),
            i = this.findAppWindow();
        if (i && i.appInstance && e) {
            var s = i.appInstance.getUserSettings("fieldset_collapse_status") || {};
            s[e] = t, i.appInstance.setUserSettings("fieldset_collapse_status", s)
        }
    },
    updateUserCollapseState: function() {
        var t = {
            collapsed: this.getUserCollapseState()
        };
        this.applyState(t)
    }
});
var _urlAppend = Ext.urlAppend;
Ext.urlAppend = function(t, e, i) {
        var s = Ext.urlDecode(e);
        return (i = void 0 === i || i) && -1 === t.indexOf("SynoToken") && !Ext.isEmpty(_S("SynoToken")) && (s.SynoToken = decodeURIComponent(_S("SynoToken"))), _urlAppend(t, Ext.urlEncode(s))
    }, Ext.ns("SYNO.SDS"), SYNO.SDS.UpdateSynoToken = function(t) {
        Ext.Ajax.request({
            url: "webman/login.cgi",
            updateSynoToken: !0,
            callback: function(e, i, s) {
                var n = Ext.util.JSON.decode(s.responseText);
                i && !Ext.isEmpty(n.SynoToken) && (SYNO.SDS.Session.SynoToken = encodeURIComponent(n.SynoToken)), Ext.isFunction(t) && t(e, i, s)
            }
        })
    }, Ext.Ajax.on("beforerequest", function(t, e) {
        !0 !== e.updateSynoToken && Ext.isEmpty(e.skipSynoToken) && !Ext.isEmpty(_S("SynoToken")) && (Ext.isEmpty(e.headers) && (e.headers = {}), e.headers["X-SYNO-TOKEN"] = _S("SynoToken"))
    }), Ext.util.Observable.observeClass(Ext.form.BasicForm), Ext.form.BasicForm.on("beforeaction", function(t, e) {
        t.url && (t.url = Ext.urlAppend(t.url))
    }), Ext.util.Observable.observeClass(Ext.data.Connection), Ext.data.Connection.on("beforerequest", function(t, e) {
        Ext.isEmpty(e.skipSynoToken) && !Ext.isEmpty(_S("SynoToken")) && (Ext.isEmpty(e.headers) && (e.headers = {}), e.headers["X-SYNO-TOKEN"] = _S("SynoToken"))
    }), Ext.define("Ext.data.JsonP", {
        singleton: !0,
        requestCount: 0,
        requests: {},
        timeout: 3e4,
        disableCaching: !0,
        disableCachingParam: "_dc",
        callbackKey: "callback",
        request: function(t) {
            t = Ext.apply({}, t);
            var e, i, s = this,
                n = Ext.isDefined(t.disableCaching) ? t.disableCaching : s.disableCaching,
                o = t.disableCachingParam || s.disableCachingParam,
                r = ++s.requestCount,
                a = t.callbackName || "callback" + r,
                l = t.callbackKey || s.callbackKey,
                c = Ext.isDefined(t.timeout) ? t.timeout : s.timeout,
                d = Ext.apply({}, t.params),
                u = t.url;
            return n && !d[o] && (d[o] = (new Date).getTime()), t.params = d, d[l] = "Ext.data.JsonP." + a, i = t.iframeUrl ? s.createIframe(u, d, t) : s.createScript(u, d, t), s.requests[r] = e = {
                url: u,
                params: d,
                script: i,
                id: r,
                scope: t.scope,
                success: t.success,
                failure: t.failure,
                callback: t.callback,
                callbackKey: l,
                callbackName: a
            }, c > 0 && (e.timeout = setTimeout(Ext.createDelegate(s.handleTimeout, s, [e]), c)), s.setupErrorHandling(e), s[a] = Ext.createDelegate(s.handleResponse, s, [e], !0), s.loadScript(e), e
        },
        abort: function(t) {
            var e, i = this.requests;
            if (t) t.id || (t = i[t]), this.handleAbort(t);
            else
                for (e in i) i.hasOwnProperty(e) && this.abort(i[e])
        },
        setupErrorHandling: function(t) {
            t.script.onerror = Ext.createDelegate(this.handleError, this, [t])
        },
        handleAbort: function(t) {
            t.errorType = "abort", this.handleResponse(null, t)
        },
        handleError: function(t) {
            t.errorType = "error", this.handleResponse(null, t)
        },
        cleanupErrorHandling: function(t) {
            t.script.onerror = null
        },
        handleTimeout: function(t) {
            t.errorType = "timeout", this.handleResponse(null, t)
        },
        handleResponse: function(t, e) {
            var i = !0;
            e.timeout && clearTimeout(e.timeout), delete this[e.callbackName], delete this.requests[e.id], this.cleanupErrorHandling(e), Ext.fly(e.script).remove(), e.errorType ? (i = !1, Ext.callback(e.failure, e.scope, [e.errorType])) : Ext.callback(e.success, e.scope, [t]), Ext.callback(e.callback, e.scope, [i, t, e.errorType])
        },
        createScript: function(t, e, i) {
            var s = document.createElement("script");
            return s.setAttribute("src", Ext.urlAppend(t, Ext.urlEncode(e))), s.setAttribute("async", !0), s.setAttribute("type", "text/javascript"), s
        },
        createIframe: function(t, e, i) {
            var s, n = Ext.urlAppend(t, Ext.urlEncode(e), !1);
            if (void 0 !== i.iframeUrl) {
                var o = i.iframeUrl;
                return o += "&url=" + encodeURIComponent(n), o = Ext.urlAppend(o, "", !0), (s = document.createElement("iframe")).setAttribute("src", o), s.setAttribute("style", "visibility: hidden"), s
            }
            SYNO.Debug("no iframe url")
        },
        loadScript: function(t) {
            Ext.get(document.getElementsByTagName("head")[0]).appendChild(t.script)
        }
    }), Ext.override(SYNO.ux.Button, {
        getUXMenu: function(t) {
            if (!Ext.menu.MenuMgr.getMenuList) return Ext.menu.MenuMgr.get(t);
            var e = Ext.menu.MenuMgr.getMenuList();
            return "string" == typeof t ? e ? e[t] : null : t.events ? t : "number" == typeof t.length ? new SYNO.ux.Menu({
                items: t
            }) : Ext.create(t, "syno_menu")
        },
        initComponent: function() {
            this.menu && (Ext.isArray(this.menu) && (this.menu = {
                items: this.menu
            }), Ext.isObject(this.menu) && (this.menu.ownerCt = this), this.menu = this.getUXMenu(this.menu), this.menu.ownerCt = void 0), SYNO.ux.Button.superclass.initComponent.call(this)
        }
    }), Ext.override(SYNO.ux.ComboBox, {
        afterRender: function() {
            SYNO.ux.ComboBox.superclass.afterRender.call(this), this.mon(this, "expand", this.onListExpand, this)
        },
        onDestroy: function() {
            this.mun(this, "expand", this.onListExpand, this), SYNO.ux.ComboBox.superclass.onDestroy.call(this)
        },
        onListExpand: function() {
            if (SYNO.SDS.Desktop) {
                var t = SYNO.SDS.UIFeatures.isFullScreenMode(),
                    e = Ext.get(SYNO.SDS.Desktop.id);
                t && this.list.parent() === Ext.getBody() ? e.appendChild(this.list) : t || this.list.parent() !== e || Ext.getBody().appendChild(this.list)
            }
        }
    }), Ext.override(SYNO.ux.DateField, {
        constructor: function(t) {
            t = t || {}, Ext.applyIf(t, {
                format: SYNO.SDS.DateTimeUtils.GetDateFormat()
            }), Ext.form.DateField.superclass.constructor.call(this, t), this.addClass("syno-ux-datefield")
        },
        onDestroy: function() {
            this.menu && this.mun(this.menu, "show", this.onMenuShow, this), this.callParent(arguments)
        },
        onMenuShow: function() {
            if (SYNO.SDS.Desktop) {
                var t = SYNO.SDS.UIFeatures.isFullScreenMode(),
                    e = Ext.get(SYNO.SDS.Desktop.id),
                    i = this.menu.el;
                t && i.parent() === Ext.getBody() ? e.appendChild(i) : t || i.parent() !== e || Ext.getBody().appendChild(i)
            }
        }
    }), Ext.override(SYNO.ux.Menu, {
        onMenuShow: function() {
            if (SYNO.SDS.Desktop) {
                var t = SYNO.SDS.UIFeatures.isFullScreenMode(),
                    e = Ext.get(SYNO.SDS.Desktop.id);
                t && this.el.parent() === Ext.getBody() ? e.appendChild(this.el) : t || this.el.parent() !== e || Ext.getBody().appendChild(this.el), this.resetWidthForFlexcroll()
            }
        }
    }), Ext.override(SYNO.ux.DatePicker, {
        getWeekdayHeader: function(t) {
            var e = this.dayNames,
                i = "ger" === _S("lang") ? 2 : 1;
            return e[t].substr(0, i)
        }
    }), Ext.namespace("SYNO.API"), Ext.define("SYNO.API.QueryAPI", {
        singleton: !0,
        IsQuerying: !1,
        QueryAPIInfo: function() {
            var t = this;
            return t.IsQuerying && t.promise ? t.promise : (SYNO.API.currentManager || (SYNO.API.currentManager = new SYNO.API.Manager), t.promise = new Promise(function(e, i) {
                t.IsQuerying = !0, SYNO.API.currentManager.queryAPI("all", function(s) {
                    s ? e() : i(), t.IsQuerying = !1
                })
            }), t.promise)
        }
    }), SYNO.API.getErrorString = function(t) {
        var e, i = 100;
        return Ext.isNumber(t) ? i = t : Ext.isObject(t) && (e = SYNO.API.Util.GetFirstError(t), i = Ext.isNumber(e.code) ? e.code : 100), i <= 118 ? SYNO.API.Errors.common[i] : Ext.isString(SYNO.API.Errors.core[i]) ? SYNO.API.Errors.core[i] : _T("common", "error_system")
    }, SYNO.API.CheckSpecialError = function(t, e, i) {
        var s;
        return "SYNO.DSM.Share" === i.api && ("delete" === i.method && 404 === e.code ? s = _T("error", "delete_default_share") : "edit" === i.method && 406 === e.code && (s = _T("error", "share_mounted_rename"))), s
    }, SYNO.API.CheckResponse = function(t, e, i, s) {
        var n, o;
        if (t) return !0;
        if (Ext.isEmpty(e) || 0 === e.status) return !1;
        try {
            o = (n = Ext.isDefined(e.status) ? 0 : e.code || 100) < SYNO.API.Errors.minCustomeError ? SYNO.API.Errors.common[n] : SYNO.API.CheckSpecialError(t, e, i) || SYNO.API.Errors.core[n]
        } catch (t) {} finally {
            o || (n = 100, o = SYNO.API.Errors.common[n])
        }
        return s && Ext.isFunction(s.getResponseHeader) && !Ext.isEmpty(s.getResponseHeader("X-SYNO-SOURCE-ID")) || (105 === n || 107 === n ? SYNO.SDS.Utils.Logout.action(!0, o, !0, !0) : 106 === n && SYNO.SDS.Utils.Logout.action(!0, o, !0, !1)), o
    }, SYNO.API.CheckRelayResponse = function(t, e, i, s, n) {
        var o, r = !1,
            a = Ext.getClassByName("SYNO.SDS.AppWindow");
        if (Ext.isEmpty(e) || Ext.isObject(n) && 0 === n.status) return r;
        if (!SYNO.SDS.Utils.IsAllowRelay(s.appWindow) || Ext.isEmpty(a)) return r;
        if (!((o = s.appWindow.findAppWindow()) instanceof a) || Ext.isEmpty(o.appInstance)) return r;
        if (!Ext.isObject(s.params)) return r;
        if ("SYNO.API.Info" === s.params.api) r = !0;
        else if ('"SYNO.CMS.DS"' !== s.params.api || '"relay"' !== s.params.method) return r;
        return !0 === r || (Ext.isObject(n) && Ext.isEmpty(n.getResponseHeader("X-SYNO-SOURCE-ID")) ? !Ext.isNumber(e.code) || 414 !== e.code && 406 !== e.code && 401 !== e.code && 423 !== e.code ? Ext.isObject(n) && n.status >= 400 && n.status < 600 && (r = !0) : r = !0 : Ext.isObject(s.userInfo.params) && Ext.isArray(s.userInfo.params.compound) ? Ext.each(e.result, function(t) {
            if (Ext.isObject(t.error) && t.error.code >= 105 && t.error.code <= 107) return r = !0, !1
        }, this) : Ext.isNumber(e.code) ? e.code >= 105 && e.code <= 107 && (r = !0) : Ext.isObject(n) && n.status >= 400 && n.status < 600 && (r = !0)), !0 === r && o.getMsgBox().alert(_T("error", "error_error"), _T("cms", "relaunch_app"), function() {
            o.close()
        }), r
    }, SYNO.API.Manager = Ext.extend(Ext.util.Observable, {
        baseURL: "webapi",
        constructor: function() {
            SYNO.API.Manager.superclass.constructor.apply(this, arguments), this.jsDebug = Ext.urlDecode(location.search.substr(1)).jsDebug, this.knownAPI = {
                "SYNO.API.Info": {
                    path: "query.cgi",
                    minVersion: 1,
                    maxVersion: 1
                }
            }
        },
        queryAPI: function(t, e, i, s) {
            var n = [];
            Ext.isArray(t) || (t = [t]), Ext.each(t, function(t) {
                this.knownAPI.hasOwnProperty(t) || n.push(t)
            }, this), this.requestAjaxAPI("SYNO.API.Info", "query", 1, {
                async: !Ext.isBoolean(s) || s
            }, {
                query: n.join(",")
            }, Ext.createDelegate(this.onQueryAPI, this, [e, i], !0))
        },
        onQueryAPI: function(t, e, i, s, n, o) {
            t && (Ext.isObject(i) && "all" === i.query ? this.knownAPI = Ext.apply({}, e) : Ext.apply(this.knownAPI, e)), n && n.call(o, t, e, i, s)
        },
        getKnownAPI: function(t, e) {
            var i, s, n = this.knownAPI[t];
            return Ext.isDefined(this.jsDebug) && Ext.isObject(n) ? (i = n.path + "/", "SYNO.Entry.Request" === t && Ext.isObject(e) && Ext.isArray(e.compound) ? (s = [], Ext.each(e.compound, function(t) {
                Ext.isString(t.api) && s.push(t.api)
            }), i += s.join()) : i += t, Ext.apply({}, {
                path: i
            }, n)) : n
        },
        getBaseURL: function(t, e, i, s, n) {
            var o, r, a, l;
            if (Ext.isObject(t))
                if (s = e, n = i, (r = t).webapi && (r = r.webapi), Ext.isObject(r.compound)) {
                    if (!Ext.isArray(r.compound.params)) return void SYNO.Debug.error("params must be array", r.compound.params);
                    t = "SYNO.Entry.Request", e = "request", i = 1;
                    for (var c = r.compound.params || [], d = [], u = 0; u < c.length; u++) d.push(Ext.apply({
                        api: c[u].api,
                        method: c[u].method,
                        version: c[u].version
                    }, c[u].params));
                    a = {
                        stop_when_error: !!Ext.isBoolean(r.compound.stopwhenerror) && r.compound.stopwhenerror,
                        mode: Ext.isString(r.compound.mode) ? r.compound.mode : "sequential",
                        compound: d
                    }
                } else t = r.api, e = r.method, i = r.version, a = r.params;
            return (o = this.getKnownAPI(t, a)) ? (l = this.baseURL + "/" + o.path, Ext.isString(n) && !Ext.isEmpty(n) && (l += "/" + window.encodeURIComponent(n)), e && i ? (r = {
                api: t,
                method: e,
                version: i
            }, a && Ext.apply(r, "JSON" === o.requestFormat ? SYNO.API.EncodeParams(a) : a), Ext.urlAppend(l, Ext.urlEncode(r), s)) : l) : (SYNO.Debug.error("No Such API: " + t), void SYNO.API.QueryAPI.QueryAPIInfo())
        },
        requestAjaxAPI: function(t, e, i, s, n, o, r) {
            var a, l, c, d, u, h, p = SYNO.Util.copy(n),
                S = null;
            if (Ext.isObject(t) && ((l = t).webapi && (l = l.webapi), s = {}, Ext.apply(s, l), delete s.api, delete s.method, delete s.version, delete s.scope, delete s.callback, o = l.callback || t.callback, r = l.scope || t.scope, s.appWindow = t.appWindow, Ext.isObject(l.compound) ? d = l.compound : (t = l.api, e = l.method, i = l.version, p = l.params)), s && s.compound && (d = s.compound), d) {
                if (!Ext.isArray(d.params)) return void SYNO.Debug.error("params must be array", d.params);
                t = "SYNO.Entry.Request", e = "request", i = 1;
                for (var f = d.params || [], g = [], m = 0; m < f.length; m++) g.push(Ext.apply({
                    api: f[m].api,
                    method: f[m].method,
                    version: f[m].version
                }, f[m].params));
                p = {
                    stop_when_error: !!Ext.isBoolean(d.stopwhenerror) && d.stopwhenerror,
                    mode: Ext.isString(d.mode) ? d.mode : "sequential",
                    compound: g
                }
            }
            if (!(a = Ext.isObject(s.appWindow) && "SYNO.API.Info" !== t ? SYNO.API.Info.GetKnownAPI(s.appWindow, t, p) : this.getKnownAPI(t, p))) return h = Ext.isObject(s.appWindow) && s.appWindow.IsAllowRelay(), SYNO.Debug.error("No Such API: " + t), u = {
                error: {
                    code: 102
                }
            }, SYNO.API.QueryAPI.QueryAPIInfo(), h && SYNO.API.CheckRelayResponse(!1, u, p, s), void(Ext.isFunction(o) && o.call(r || window, !1, u, p, s));
            if ((i < a.minVersion || a.maxVersion < i) && SYNO.Debug.warn(String.format("WARN: API({0}) version ({1}) is higher then server ({2})", t, i, a.version)), Ext.isObject(p) || Ext.isEmpty(p)) {
                !Ext.isSecure && Ext.isArray(s.encryption) && (S = Ext.apply([], s.encryption)), delete s.encryption;
                var _, x = {
                        api: t,
                        method: e,
                        version: i
                    },
                    v = this.baseURL + "/" + a.path;
                if (s && s.url) {
                    var E = s.url;
                    (_ = Ext.urlDecode(E.substr(E.indexOf("?") + 1))) && _.api && _.method && _.version && (delete _.api, delete _.method, delete _.version, delete _.SynoToken, x = _, v = s.url)
                }
                return s && Ext.isElement(s.form) && /multipart\/form-data/i.test(s.form.enctype) ? (v = SYNO.API.GetBaseURL(x), x = {}) : Ext.isObject(s) && !0 === s.html5upload && (v = SYNO.API.GetBaseURL(Ext.apply({
                    params: p
                }, x)), x = {}, s.method = "POST"), c = Ext.apply(s || {}, {
                    url: v,
                    params: Ext.apply({}, x, "JSON" === a.requestFormat ? SYNO.API.EncodeParams(p) : p),
                    callback: this.onRequestAPI,
                    userInfo: {
                        params: p,
                        cb: o,
                        scope: r
                    }
                }), Ext.isEmpty(S) ? this.sendRequest(c) : this.requestAjaxAPI("SYNO.API.Encryption", "getinfo", 1, {
                    appWindow: c.appWindow || void 0,
                    reqObj: c,
                    reqEnc: S
                }, {
                    format: "module"
                }, this.onEncryptRequestAPI, this)
            }
            SYNO.Debug.error("params must be object, ", p)
        },
        onEncryptRequestAPI: function(t, e, i, s) {
            var n, o, r, a = s.reqObj,
                l = s.reqEnc,
                c = function(t) {
                    for (var e in t)
                        if (t.hasOwnProperty(e)) return !1;
                    return !0
                };
            if (!t) return Ext.Ajax.request(a);
            if (SYNO.Encryption.CipherKey = e.cipherkey, SYNO.Encryption.RSAModulus = e.public_key, SYNO.Encryption.CipherToken = e.ciphertoken, SYNO.Encryption.TimeBias = e.server_time - Math.floor(+new Date / 1e3), Ext.isEmpty(a.params.compound)) {
                for (n = SYNO.Encryption.EncryptParam(Ext.copyTo({}, a.params, l)), o = 0; o < l.length; o++) delete a.params[l[o]];
                return a.params = Ext.apply(a.params, n), this.sendRequest(a)
            }
            var d = Ext.apply({}, a.userInfo.params),
                u = this,
                h = 5;
            (Ext.isIE6 || Ext.isIE7 || Ext.isIE8) && (h = 1), o = 0;
            ! function t() {
                for (; o < d.compound.length; o++) {
                    var e, i = Ext.apply({}, d.compound[o], d.compound[o].params);
                    for (n = {}, e = SYNO.API.EncodeParams(Ext.copyTo({}, i, l)), c(e) || (n = SYNO.Encryption.EncryptParam(e)), r = 0; r < l.length; r++) delete i[l[r]];
                    if (d.compound[o] = Ext.apply(i, n), o + 1 === d.compound.length) return Ext.apply(a.params, SYNO.API.EncodeParams(d)), void u.sendRequest(a);
                    if (o % h == 0) return o++, void window.setTimeout(t, 80)
                }
            }()
        },
        sendRequest: function(t) {
            var e, i, s, n = t.appWindow,
                o = this.getKnownAPI("SYNO.CMS.DS");
            return Ext.isObject(n) && (n = n.findAppWindow()), !Ext.isEmpty(o) && SYNO.SDS.Utils.IsAllowRelay(n) && n.hasOpenConfig("cms_id") && (i = n.getOpenConfig("cms_timeout") || 120, s = {
                api: "SYNO.CMS.DS",
                version: 1,
                method: "relay",
                id: n.getOpenConfig("cms_id"),
                timeout: i
            }, Ext.isElement(t.form) && /multipart\/form-data/i.test(t.form.enctype) ? (e = Ext.urlDecode(t.url.substr(t.url.indexOf("?") + 1)), s.webapi = Ext.encode(Ext.copyTo({}, e, "api,version,method")), e.SynoToken && (s.SynoToken = e.SynoToken), t.url = this.baseURL + "/" + o.path + "?" + Ext.urlEncode(s)) : (t.url = this.baseURL + "/" + o.path, s.webapi = Ext.apply({
                api: t.params.api,
                version: t.params.version,
                method: t.params.method
            }, t.userInfo.params), t.params = SYNO.API.EncodeParams(s)), t.timeout = t.timeout || 1e3 * (i + 10)), Ext.Ajax.request(t)
        },
        requestAPI: function(t, e, i, s, n, o) {
            return this.requestAjaxAPI(t, e, i, {}, s, n, o)
        },
        onRequestAPI: function(t, e, i) {
            var s, n = !1,
                o = i;
            if (e) {
                try {
                    s = Ext.decode(i.responseText)
                } catch (t) {}
                Ext.isObject(s) && (s.success ? (n = !0, o = s.data) : (n = !1, o = s.error))
            }
            SYNO.API.CheckResponse(n, o, t.userInfo.params, i), SYNO.SDS.Utils.IsAllowRelay(t.appWindow) && SYNO.API.CheckRelayResponse(n, o, void 0, t, i) || t.userInfo.cb && t.userInfo.cb.call(t.userInfo.scope, n, o, t.userInfo.params, t)
        }
    }), SYNO.API.Store = Ext.extend(Ext.data.Store, {
        defaultParamNames: {
            start: "offset",
            limit: "limit",
            sort: "sort_by",
            dir: "sort_direction"
        },
        constructor: function(t) {
            if (t.api && t.method && t.version && !t.proxy) {
                if (!Ext.isObject(t.appWindow) && !1 !== t.appWindow) return SYNO.Debug.error("No appWindow!"), SYNO.Debug.debug("SYNO.API.Store and SYNO.API.JsonStore require appWindow in config."), SYNO.Debug.debug("appWindow can be found by Ext.Component.findAppWindow"), void SYNO.Debug.debug("ex: this.findAppWindow() or config.module.appWin.findAppWindow()");
                this.proxy = new SYNO.API.Proxy({
                    api: t.api,
                    method: t.method,
                    version: t.version,
                    appWindow: t.appWindow,
                    encryption: t.encryption
                })
            }
            SYNO.API.Store.superclass.constructor.apply(this, arguments)
        }
    }), Ext.define("SYNO.API.CompoundReader", {
        extend: "Ext.data.JsonReader",
        constructor: function() {
            this.callParent(arguments)
        },
        readRecords: function(t) {
            var e, i = [],
                s = this.meta.roots,
                n = {
                    success: !1,
                    records: [],
                    totalRecords: 0
                };
            if (this.compoundData = t, !Ext.isObject(t)) return n;
            if (Ext.each(t.result, function(t, o, r) {
                    Ext.isArray(s) && (this.getRoot = this.createAccessor(s[o])), !0 === t.success ? e = this.superclass().readRecords.call(this, t.data) : i.push({
                        response: t,
                        index: o,
                        total: r
                    }), Ext.isFunction(this.meta.onCompoundResponse) && (e = this.meta.onCompoundResponse(t, e)), n.records = n.records.concat(e.records), n.totalRecords += e.totalRecords
                }, this), n.success = !t.has_fail, !1 === n.success) throw i;
            return n
        }
    }), SYNO.API.CompoundStore = Ext.extend(SYNO.API.Store, {
        constructor: function(t) {
            Ext.apply(t, {
                api: "SYNO.Entry.Request",
                version: 1,
                method: "request"
            }), SYNO.API.JsonStore.superclass.constructor.call(this, Ext.apply(t, {
                reader: new SYNO.API.CompoundReader(t)
            }))
        }
    }), SYNO.API.JsonStore = Ext.extend(SYNO.API.Store, {
        constructor: function(t) {
            SYNO.API.JsonStore.superclass.constructor.call(this, Ext.apply(t, {
                reader: new Ext.data.JsonReader(t)
            }))
        }
    }), SYNO.API.Proxy = Ext.extend(Ext.util.Observable, {
        constructor: function(t) {
            t = t || {}, Ext.apply(this, t), this.addEvents("exception", "beforeload", "loadexception"), SYNO.API.Proxy.superclass.constructor.call(this);
            var e = Ext.data.Api.actions;
            for (var i in this.activeRequest = {}, e) e.hasOwnProperty(i) && (this.activeRequest[e[i]] = void 0)
        },
        request: function(t, e, i, s, n, o, r) {
            !1 !== this.fireEvent("beforeload", this, i) ? this.doRequest.apply(this, arguments) : n.call(o || this, null, r, !1)
        },
        doRequest: function(t, e, i, s, n, o, r) {
            if (s) {
                var a = {
                    appWindow: this.appWindow
                };
                !r.timeout && this.timeout && Ext.apply(a, {
                    timeout: this.timeout
                }), this.encryption && Ext.apply(a, {
                    encryption: this.encryption
                }), Ext.isObject(s.meta.compound) && Ext.isArray(s.meta.compound.params) && (a.compound = Ext.apply({}, s.meta.compound), Ext.isObject(i) && Ext.each(a.compound.params, function(t) {
                    t.params = Ext.apply(t.params || {}, i)
                }, this), i = {}), this.activeRequest[t] = SYNO.API.currentManager.requestAjaxAPI(this.api, this.method, this.version, a, i, Ext.createDelegate(this.onRequestAPI, this, [s, n, o, r, t], !0)), Ext.isEmpty(this.activeRequest[t]) && this.onRequestAPI(!1, void 0, i, r, s, n, o, r, t)
            }
        },
        onRequestAPI: function(t, e, i, s, n, o, r, a, l) {
            this.activeRequest[l] = void 0;
            var c = null,
                d = null;
            if (t) try {
                c = n.readRecords(e)
            } catch (t) {
                d = t, SYNO.Debug.error("Failed to read data, ", t)
            }!t || d ? (this.fireEvent("loadexception", this, a, e, d), this.fireEvent("exception", this, "response", Ext.data.Api.actions.read, a, e, d)) : this.fireEvent("load", this, e, a), o.call(r || this, c, a, t)
        }
    }), SYNO.API.TreeLoader = Ext.extend(Ext.tree.TreeLoader, {
        load: function(t, e, i) {
            if (this.clearOnLoad)
                for (; t.firstChild;) t.removeChild(t.firstChild);
            this.doPreload(t) ? this.runCallback(e, i || t, [t]) : (this.directFn || this.method && this.api || this.dataUrl || this.url) && this.requestData(t, e, i || t)
        },
        requestData: function(t, e, i) {
            !1 !== this.fireEvent("beforeload", this, t, e) ? this.method && this.api ? this.transId = this.doRequest.apply(this, arguments) : (this.dataUrl || this.url) && (this.transId = Ext.Ajax.request({
                method: this.requestMethod,
                url: this.dataUrl || this.url,
                success: this.handleResponse,
                failure: this.handleFailure,
                scope: this,
                argument: {
                    callback: e,
                    node: t,
                    scope: i
                },
                params: this.getParams(t)
            })) : this.runCallback(e, i || t, [])
        },
        doRequest: function(t, e, i) {
            var s = this.getParams(t);
            return SYNO.API.currentManager.requestAjaxAPI(this.api, this.method, this.version, {
                timeout: this.timeout,
                success: this.handleResponse,
                failure: this.handleFailure,
                encryption: this.encryption,
                scope: this,
                appWindow: this.appWindow || !1,
                argument: {
                    callback: e,
                    node: t,
                    scope: i
                }
            }, s, Ext.emptyFn)
        },
        processResponse: function(t, e, i, s) {
            var n = t.responseText;
            try {
                var o = t.responseData || Ext.decode(n);
                if (this.dataroot) {
                    Ext.isArray(this.dataroot) || (this.dataroot = this.dataroot.split(","));
                    var r = this.dataroot;
                    for (var a in r) r.hasOwnProperty(a) && (o = o[r[a]])
                }
                e.beginUpdate();
                for (var l = 0, c = o.length; l < c; l++) {
                    var d = this.createNode(o[l], e);
                    d && e.appendChild(d)
                }
                e.endUpdate(), this.runCallback(i, s || e, [e])
            } catch (e) {
                this.handleFailure(t)
            }
        }
    }), SYNO.API.Form = {}, SYNO.API.Form.Traverse = function(t, e) {
        if (t) {
            var i, s, n, o, r = t.elements || (document.forms[t] || Ext.getDom(t)).elements,
                a = !1;
            Ext.each(r, function(t) {
                i = t.name, s = t.type, (o = Ext.getCmp(t.id)) && (Ext.isEmpty(i) && Ext.isFunction(o.getName) && (i = o.getName()), !t.disabled && i && (/select-(one|multiple)/i.test(s) ? Ext.each(t.options, function(t) {
                    t.selected && (n = t.hasAttribute ? t.hasAttribute("value") : t.getAttributeNode("value").specified, e(o, i, n ? t.value : t.text, s))
                }) : /file|undefined|reset|button/i.test(s) || (/radio/i.test(s) || o instanceof SYNO.ux.Radio ? o.getValue() && e(o, i, o.getInputValue() || "", s) : /checkbox/i.test(s) || o instanceof SYNO.ux.Checkbox ? e(o, i, !!o.getValue()) : "submit" == s && a || (Ext.isFunction(o.getValue) ? e(o, i, o.getValue(), s) : e(o, i, t.value, s), a = /submit/i.test(s)))))
            })
        }
    }, SYNO.API.Form.Serialize = function(t, e) {
        var i = {};
        return i = SYNO.API.Form.Retrieve(t, !1, e), i = SYNO.API.DecodeFlatParams(i), i = SYNO.API.EncodeParams(i), Ext.urlEncode(i)
    }, SYNO.API.Form.Retrieve = function(t, e, i) {
        var s, n, o = {};
        return SYNO.API.Form.Traverse(t, function(t, e, r) {
            if (i) {
                if (s = SYNO.ux.Utils.getFormFieldApi(t), !SYNO.ux.Utils.checkApiObjValid(s)) return;
                n = "get" === i || "load" === i ? s.method || s.methods.get : s.method || s.methods.set, e = s.api + "|" + n + "|" + s.version + "|" + e
            }
            o[e] = r
        }), e && (o = SYNO.API.EncodeParams(o)), o
    }, SYNO.API.Form.Action = {}, SYNO.API.Form.Action.Load = Ext.extend(Ext.form.Action.Load, {
        run: function() {
            var t = this.options,
                e = Ext.urlDecode(this.getParams()),
                i = this.form.webapi || this.form,
                s = i.method || i.methods.get;
            SYNO.API.currentManager.requestAjaxAPI(i.api, s, i.version, Ext.apply(this.createCallback(t), {
                appWindow: this.form.appWindow,
                compound: t.compound,
                method: this.getMethod(),
                url: this.getUrl(!1),
                headers: this.options.headers,
                encryption: this.form.encryption
            }), e, t.callback, t.scope)
        }
    }), SYNO.API.Form.Action.Submit = Ext.extend(Ext.form.Action.Submit, {
        run: function() {
            var t = this.options;
            if (!1 === t.clientValidation || this.form.isValid()) {
                var e = Ext.urlDecode(this.getParams()),
                    i = Ext.isBoolean(t.fileUpload) ? t.fileUpload : this.form.fileUpload || this.form.el && this.form.el.dom && /multipart\/form-data/i.test(this.form.el.dom.getAttribute("enctype")),
                    s = this.form.el ? this.form.el.dom : void 0;
                if (i) {
                    this.form.items.each(function t(i) {
                        if (!i.disabled && "file" !== i.inputType) {
                            var s = i.getValue();
                            Ext.isBoolean(s) && (e[i.getName()] = s), i.isComposite && i.rendered && i.items.each(t)
                        }
                    })
                } else if (t.compound);
                else {
                    var n = SYNO.API.Form.Retrieve(s, !1, "submit");
                    for (var o in n) n.hasOwnProperty(o) && (e[o] = n[o]);
                    e = SYNO.API.DecodeFlatParams(e)
                }
                var r = this.form.webapi || this.form,
                    a = r.method || (r.methods ? r.methods.set : void 0);
                SYNO.API.currentManager.requestAjaxAPI(r.api, a, r.version, Ext.apply(this.createCallback(t), {
                    appWindow: this.form.appWindow,
                    compound: t.compound,
                    form: i ? s : void 0,
                    method: this.getMethod(),
                    headers: t.headers,
                    encryption: this.form.encryption
                }), e, t.callback, t.scope)
            } else !1 !== t.clientValidation && (this.failureType = Ext.form.Action.CLIENT_INVALID, this.form.afterAction(this, !1))
        }
    }), SYNO.API.Form.BasicForm = Ext.extend(Ext.form.BasicForm, {
        doAction: function(t, e) {
            return Ext.isString(t) && (t = "load" !== t ? new SYNO.API.Form.Action.Submit(this, e) : new SYNO.API.Form.Action.Load(this, e)), !1 !== this.fireEvent("beforeaction", this, t) && (this.beforeAction(t), t.run.defer(100, t)), this
        },
        submit: function(t) {
            if (this.standardSubmit) {
                var e = {};
                this.items.each(function t(i) {
                    if (!i.disabled && "file" !== i.inputType) {
                        var s = i.getValue();
                        Ext.isBoolean(s) && (e[i.getName()] = s), i.isComposite && i.rendered && i.items.each(t)
                    }
                });
                var i = this.webapi || this;
                return this.url = SYNO.API.GetBaseURL(Ext.apply(e, {
                    api: i.api,
                    method: i.method || i.methods.set,
                    version: i.version
                })), SYNO.API.Form.BasicForm.superclass.submit.call(this, t)
            }
            return this.doAction("submit", t), this
        },
        load: function(t) {
            return this.doAction("load", t), this
        },
        getValues: function(t, e) {
            return !0 === t ? SYNO.API.Form.Serialize(this.el.dom, e) : SYNO.API.Form.Retrieve(this.el.dom, !1, e)
        },
        loadRecords: function(t, e) {
            for (var i = 0; i < e.length && (t[i] && e[i]); i++) t[i].success && this.setFieldValues(t[i].data, e[i])
        },
        setFieldValues: function(t, e) {
            var i, s, n, o, r, a, l, c;
            if (c = function(t) {
                    this.trackResetOnLoad && (t.originalValue = t.getValue())
                }, Ext.isArray(t))
                for (r = 0, l = t.length; r < l; r++) {
                    var d = t[r];
                    for (o = this.findFields(d.id), a = 0; a < o.length; a++)
                        if (i = o[a]) {
                            if (!SYNO.ux.Utils.checkFieldApiConsistency(i, e, "get")) continue;
                            s = [i], ("radio" === i.inputType || i instanceof SYNO.ux.Radio) && (s = SYNO.ux.Utils.getRadioGroup(this, d.id)), i.setValue(d.value), Ext.each(s, c, this)
                        }
                } else
                    for (n in t)
                        if (!Ext.isFunction(t[r]))
                            for (o = this.findFields(n), r = 0; r < o.length; r++) i = o[r], SYNO.ux.Utils.checkFieldApiConsistency(i, e, "get") && (s = [i], ("radio" === i.inputType || i instanceof SYNO.ux.Radio) && (s = SYNO.ux.Utils.getRadioGroup(this, n)), i.setValue(t[n]), Ext.each(s, c, this));
            return this
        },
        findFields: function(t) {
            var e = [];
            return this.items.each(function i(s) {
                if (s.isFormField) {
                    if (s.dataIndex == t || s.id == t || s.getName() == t) return e.push(s), !0;
                    if (s.isComposite) return s.items.each(i);
                    if (s instanceof Ext.form.CheckboxGroup && s.rendered) return s.eachItem(i)
                }
            }), e
        }
    }), SYNO.API.Form.FormPanel = Ext.extend(Ext.form.FormPanel, {
        createForm: function() {
            var t = Ext.applyIf({
                appWindow: this,
                listeners: {}
            }, this.initialConfig);
            return new SYNO.API.Form.BasicForm(null, t)
        }
    }), SYNO.API.EncodeFlatParams = function(t) {
        var e = {};
        if (!t) return e;
        var i = function t(e, i, s) {
            for (var n in e)
                if (e.hasOwnProperty(n)) {
                    var o = e[n],
                        r = i ? i + "|" + n : n;
                    Ext.isFunction(o) || (Ext.isObject(o) ? t(e[n], r, s) : s[r] = o)
                }
        };
        if (!Ext.isArray(t)) return i(t, void 0, e), e;
        for (var s = 0; s < (void 0).length; s++)(void 0)[s].api && (void 0)[s].method ? i((void 0)[s], (void 0)[s].api + "|" + (void 0)[s].method, e) : i(t, void 0, e);
        return e
    }, SYNO.API.DecodeFlatParams = function(t) {
        var e = {},
            i = function t(e, i, s) {
                var n, o = e.indexOf("|");
                0 < o ? (n = e.substring(0, o), Ext.isObject(s[n]) || (s[n] = {}), t(e.substring(o + 1), i, s[n])) : s[e] = i
            };
        for (var s in t) Ext.isObject(t[s]) ? e[s] = t[s] : i(s, t[s], e);
        return e
    }, SYNO.API.EscapeStr = function(t) {
        return t ? t.replace(/[\\]/g, "\\\\").replace(/[,]/g, "\\,") : ""
    }, SYNO.API.EncodeParams = function(t) {
        var e = {};
        for (var i in t) t.hasOwnProperty(i) && (e[i] = Ext.encode(t[i]));
        return e
    }, SYNO.API.DecodeParams = function(t) {
        var e = {};
        for (var i in t)
            if (t.hasOwnProperty(i)) try {
                e[i] = Ext.decode(t[i])
            } catch (s) {
                e[i] = SYNO.Util.copy(t[i])
            }
        return e
    }, SYNO.API.Request = function(t) {
        return SYNO.API.currentManager.requestAjaxAPI(t)
    }, SYNO.API.RequestPromise = function(t) {
        return new Promise(function(e, i) {
            t.callback = function(t, s, n, o) {
                t ? e(s) : i(s)
            }, SYNO.API.Request(t)
        }.bind(this))
    }, SYNO.API.GetBaseURL = function(t, e, i) {
        var s = t.appWindow;
        return SYNO.ux.Utils.checkApiObjValid(t) && SYNO.SDS.Utils.IsAllowRelay(s) && s.hasOpenConfig("cms_id") ? SYNO.API.currentManager.getBaseURL({
            api: "SYNO.CMS.DS",
            version: 1,
            method: "relay",
            params: {
                id: s.getOpenConfig("cms_id"),
                timeout: s.getOpenConfig("cms_timeout") || 120,
                webapi: Ext.apply({
                    api: t.api,
                    version: t.version,
                    method: t.method
                }, t.params)
            }
        }, e, i) : SYNO.API.currentManager.getBaseURL(t, e, i)
    }, SYNO.API.EncodeURL = function(t) {
        return t = SYNO.API.EncodeParams(t), Ext.urlEncode.apply(this, arguments)
    }, SYNO.API.GetKnownAPI = function(t, e) {
        return SYNO.API.currentManager.getKnownAPI(t, e)
    }, SYNO.API.Util = {}, SYNO.API.Util.GetReqByAPI = function(t, e, i, s) {
        var n, o, r;
        if (Ext.isObject(t))
            if (n = t.compound, Ext.isObject(n)) {
                if (!Ext.isArray(n.params)) return;
                o = n.params;
                for (var a = 0; a < o.length; a++)
                    if (e === (r = o[a]).api && i === r.method) return s ? Ext.isObject(r.params) && Ext.isDefined(r.params[s]) ? r.params[s] : r[s] : r
            } else if (Ext.isObject(t.params)) return s ? t.params[s] : t.params
    }, SYNO.API.Util.GetReqByIndex = function(t, e, i) {
        var s, n;
        if (Ext.isObject(t)) {
            if (s = t.compound, Ext.isObject(s)) {
                if (!Ext.isArray(s.params)) return;
                if (n = s.params, !Ext.isObject(n[e])) return;
                return n = n[e], i ? Ext.isObject(n.params) && Ext.isDefined(n.params[i]) ? n.params[i] : n[i] : n
            }
            return Ext.isObject(t.params) ? i ? t.params[i] : t.params : void 0
        }
    }, SYNO.API.Util.GetValByAPI = function(t, e, i, s) {
        if (Ext.isObject(t)) {
            if (Ext.isArray(t.result)) {
                for (var n = t.result, o = 0; o < n.length; o++)
                    if (e === n[o].api && i === n[o].method) {
                        var r = n[o].data || n[o].error;
                        if (!r) return;
                        return s ? r[s] : r
                    } return
            }
            return s ? t[s] : t
        }
    }, SYNO.API.Util.GetValByIndex = function(t, e, i) {
        var s;
        if (Ext.isObject(t)) {
            if (s = t.result, Ext.isArray(s)) {
                if (!Ext.isObject(s[e])) return;
                var n = s[e].data || s[e].error;
                if (!n) return;
                return i ? n[i] : n
            }
            return i ? t[i] : t
        }
    }, SYNO.API.Util.GetFirstError = function(t) {
        var e;
        if (Ext.isObject(t)) {
            if (Ext.isBoolean(t.has_fail) && t.has_fail && Ext.isArray(t.result)) {
                e = t.result;
                for (var i = 0; i < e.length; i++)
                    if (Ext.isObject(e[i]) && !e[i].success) return e[i].error
            }
            return t
        }
    }, SYNO.API.Util.GetFirstErrorIndex = function(t) {
        var e;
        if (Ext.isObject(t)) {
            if (Ext.isBoolean(t.has_fail) && t.has_fail && Ext.isArray(t.result)) {
                e = t.result;
                for (var i = 0; i < e.length; i++)
                    if (Ext.isObject(e[i]) && !e[i].success) return i
            }
            return 0
        }
    }, SYNO.API.Request.Polling = Ext.extend(Ext.util.Observable, {
        api: "SYNO.Entry.Request.Polling",
        version: 1,
        local: "polling_local_instance",
        queue: null,
        pool: null,
        reg: null,
        pollingId: null,
        jsDebug: void 0,
        constructor: function() {
            SYNO.API.Request.Polling.superclass.constructor.apply(this, arguments), this.queue = {}, this.pool = {}, this.reg = {}, this.jsDebug = Ext.urlDecode(location.search.substr(1)).jsDebug
        },
        getInterval: function(t, e) {
            var i, s, n = 0;
            if (Ext.isNumber(t.firstRunTime) && (n = parseInt((new Date).getTime() / 1e3, 10) - t.firstRunTime), Ext.isNumber(e)) i = e;
            else if (Ext.isFunction(e)) i = e.call(t.scope || this, n);
            else if (Ext.isArray(e))
                for (s = 0; s < e.length && !(e[s].time > n); ++s) i = e[s].interval;
            return !!Ext.isNumber(i) && (i < 1 && (i = 1), i)
        },
        addToQueue: function(t, e) {
            var i, s = this.reg[t];
            return !Ext.isEmpty(s) && (i = this.getInterval(s, e), Ext.isNumber(i) ? (this.queue[t] = i, !0) : (SYNO.Debug.error("[Polling]Register " + t + " interval is invalid"), !1))
        },
        addToPool: function(t, e, i) {
            var s = this.getInstanceName(i);
            Ext.isEmpty(this.pool[s + t]) && (this.pool[s + t] = Ext.apply({
                register_id_list: [],
                auto_remove: !1,
                finish: !1
            }, e || {}))
        },
        addToRegister: function(t) {
            var e, i, s, n = Ext.id(void 0, "webapi_polling_register_id");
            if (!(Ext.isEmpty(t.task_id) && Ext.isEmpty(t.webapi) || !Ext.isFunction(t.status_callback)) && (Ext.isNumber(t.interval) || Ext.isFunction(t.interval) || Ext.isArray(t.interval))) {
                if (Ext.isEmpty(t.webapi)) {
                    if (e = this.getTask(t.task_id, t.appWindow), Ext.isEmpty(e)) return;
                    e.register_id_list = e.register_id_list.concat(n)
                }
                return i = parseInt((new Date).getTime() / 1e3, 10), s = t.immediate ? i : i + this.getInterval(t, t.interval), this.reg[n] = Ext.apply({
                    firstRunTime: s
                }, t), n
            }
        },
        getTask: function(t, e) {
            var i = this.getInstanceName(e);
            if (!Ext.isEmpty(t)) return this.pool[i + t]
        },
        updateTask: function(t, e, i) {
            var s = this.getTask(t, i) || {
                register_id_list: []
            };
            Ext.copyTo(s, e, "auto_remove,finish")
        },
        removeTask: function(t, e) {
            var i = this.getTask(t, e),
                s = this.getInstanceName(e);
            return !Ext.isEmpty(i) && (Ext.isEmpty(i.register_id_list) || !Ext.isArray(i.register_id_list) ? (delete this.pool[s + t], !0) : (Ext.each(i.register_id_list, function(t) {
                delete this.queue[t], delete this.reg[t]
            }, this), delete this.pool[s + t], !0))
        },
        removeRegister: function(t) {
            var e, i;
            if (Ext.isEmpty(t) || Ext.isEmpty(this.reg[t])) return SYNO.Debug.error("[Polling]No such register id"), !1;
            if (i = this.reg[t], Ext.isEmpty(i.webapi)) {
                if (e = this.getTask(i.task_id, i.appWindow), Ext.isEmpty(e)) return SYNO.Debug.error("[Polling]No such task"), !1;
                e.register_id_list.remove(t)
            }
            return i.status_callback = null, delete this.reg[t], !0
        },
        convertToTaskUser: function(t) {
            var e;
            return Ext.isEmpty(t) ? e = _S("user") : "admin" == t ? e = "@administrators" : "everyone" == t && (e = "@users"), e
        },
        notifyTaskStatus: function(t, e, i, s) {
            var n, o;
            n = this.getTask(t, s.app), Ext.isEmpty(n) || Ext.each(n.register_id_list, function(n) {
                if (o = this.reg[n], !Ext.isEmpty(o) && Ext.isFunction(o.status_callback)) try {
                    o.status_callback.call(o.scope || this, t, e, i, s)
                } catch (t) {
                    SYNO.Debug.error(t)
                }
            }, this)
        },
        notifyWebAPIStatus: function(t, e, i, s, n) {
            var o = this.reg[t];
            if (!Ext.isEmpty(o))
                if (Ext.isDefined(this.jsDebug)) o.status_callback.call(o.scope || this, e, i, s, n);
                else try {
                    o.status_callback.call(o.scope || this, e, i, s, n)
                } catch (t) {
                    SYNO.Debug.error(t)
                }
        },
        beginPolling: function(t) {
            var e, i, s, n, o = !1,
                r = {};
            for (i in "halt" === t && delete this.pollingHalt, this.queue)
                if (this.queue.hasOwnProperty(i)) {
                    if (e = this.reg[i], Ext.isEmpty(e)) {
                        delete this.queue[i];
                        continue
                    }
                    if (!0 === this.pollingHalt && !0 !== e.preventHalt) continue;
                    if (this.queue[i]--, this.queue[i] > 0) continue;
                    if (delete this.queue[i], !Ext.isFunction(e.status_callback)) continue;
                    if ((s = e.appWindow || !1) && !0 === s.isDestroyed && !0 !== s.keepPolling) {
                        this.removeRegister(i);
                        continue
                    }
                    if (n = this.getInstanceName(s), Ext.isEmpty(r[n]) && (r[n] = {
                            task_id_list: [],
                            webapi: [],
                            reg: [],
                            opts: [],
                            app: s
                        }), !Ext.isEmpty(e.webapi)) {
                        o = !0, r[n].webapi.push(e.webapi), r[n].reg.push(i), r[n].opts.push(e.webapi);
                        continue
                    }
                    if (Ext.isEmpty(this.getTask(e.task_id, e.appWindow))) continue;
                    o = !0, r[n].task_id_list.indexOf(e.task_id) < 0 && (r[n].task_id_list = r[n].task_id_list.concat(e.task_id))
                } if (this.endPolling(), !1 !== o)
                for (n in r) r.hasOwnProperty(n) && (Ext.isEmpty(r[n].task_id_list) || (r[n].webapi.push({
                    api: this.api,
                    version: this.version,
                    method: "status",
                    params: {
                        task_id_list: r[n].task_id_list
                    }
                }), r[n].reg.push("TASK"), r[n].opts.push({
                    app: r[n].app,
                    task_id_list: r[n].task_id_list
                })), this.reqId = SYNO.API.Request({
                    compound: {
                        stop_when_error: !1,
                        mode: "parallel",
                        params: r[n].webapi
                    },
                    appWindow: r[n].app,
                    callback: this.pollingCompoundCallack,
                    reg_ref: r[n].reg,
                    opts_ref: r[n].opts,
                    timeout: 6e6,
                    scope: this
                }));
            else this.pollingId = this.beginPolling.defer(1e3, this)
        },
        endPolling: function(t) {
            "halt" !== t ? (window.clearTimeout(this.pollingId), this.pollingId = null, Ext.isEmpty(this.reqId) || (Ext.Ajax.abort(this.reqId), delete this.reqId)) : this.pollingHalt = !0
        },
        collectToQueue: function(t, e) {
            var i, s, n, o, r = Ext.isArray(t) ? t : [],
                a = function(t) {
                    Ext.each(t, function(t, e) {
                        s = this.reg[t], !Ext.isEmpty(s) && Ext.isFunction(s.status_callback) && this.addToQueue(t, s.interval)
                    }, this)
                }; - 1 !== (o = r.indexOf("TASK")) && (i = e[o], r.splice(o, 1)), a.call(this, r), Ext.isObject(i) && Ext.isArray(i.task_id_list) && Ext.each(i.task_id_list, function(t) {
                n = this.getTask(t, i.app), Ext.isEmpty(n) || !0 !== n.finish && a.call(this, n.register_id_list)
            }, this), Ext.isEmpty(this.pollingId) && (this.pollingId = this.beginPolling.defer(1e3, this))
        },
        pollingCompoundCallack: function(t, e, i, s) {
            var n, o, r, a, l, c, d;
            if (this.reqId = null, n = t ? e.result : [], o = s.reg_ref, r = s.opts_ref, o.length === n.length) {
                for (this.endPolling(), l = 0; l < n.length; l++)
                    if ("TASK" === o[l]) this.pollingCallback(t, n[l].data, i.compound[l], r[l]);
                    else {
                        if (c = this.reg[o[l]], Ext.isEmpty(c)) continue;
                        if (!Ext.isFunction(c.status_callback)) {
                            this.removeRegister(o[l]);
                            continue
                        }
                        if ((d = c.appWindow || !1) && !0 === d.isDestroyed && !0 !== d.keepPolling) {
                            this.removeRegister(o[l]);
                            continue
                        }
                        a = n[l].success, this.notifyWebAPIStatus(o[l], a, a ? n[l].data : n[l].error, i.compound[l], r[l])
                    } this.collectToQueue(o, r)
            } else this.collectToQueue(o, r)
        },
        pollingCallback: function(t, e, i, s) {
            var n, o;
            if (t)
                for (o in e)
                    if (e.hasOwnProperty(o)) {
                        if (this.updateTask(o, e[o], s.app), n = this.getTask(o, s.app), Ext.isEmpty(n)) continue;
                        this.notifyTaskStatus(o, e[o], i, s), n.finish && n.auto_remove && this.removeTask(o, s.app)
                    }
        },
        list: function(t) {
            var e, i;
            i = Ext.apply({
                extra_group_tasks: [],
                task_id_prefix: "",
                callback: null
            }, t), Ext.isArray(i.extra_group_tasks) ? (i.extra_group_tasks = i.extra_group_tasks.concat("user"), e = Ext.copyTo({}, i, "extra_group_tasks,task_id_prefix"), Ext.isFunction(i.callback) ? (delete e.callback, delete e.scope, SYNO.API.Request({
                api: this.api,
                version: this.version,
                method: "list",
                params: e,
                appWindow: i.appWindow || !1,
                callback: i.callback,
                scope: i.scope || this
            })) : SYNO.Debug.error("[Polling]No required parameter: callback")) : SYNO.Debug.error("[Polling]Incorrect type parameter: extra_group_tasks")
        },
        register: function(t) {
            var e;
            if (Ext.isEmpty(t.task_id) && Ext.isEmpty(t.webapi) || !Ext.isFunction(t.status_callback)) SYNO.Debug.error("[Polling]register fail, no requried parameters");
            else {
                if (Ext.isNumber(t.interval) || Ext.isFunction(t.interval) || Ext.isArray(t.interval)) return Ext.isEmpty(t.task_id) || this.addToPool(t.task_id, {
                    task_id: t.task_id
                }, t.appWindow), e = this.addToRegister(t), !0 === t.immediate ? !0 === this.pollingHalt ? this.addToQueue(e, 0) : SYNO.API.Request(Ext.apply({
                    appWindow: t.appWindow,
                    callback: function(i, s, n, o) {
                        this.notifyWebAPIStatus(e, i, s, n, o), this.addToQueue(e, t.interval)
                    },
                    scope: this
                }, t.webapi)) : this.addToQueue(e, t.interval), e;
                SYNO.Debug.error("[Polling]register fail, interval is invalid")
            }
        },
        unregister: function(t) {
            return this.removeRegister(t)
        },
        getInstanceName: function(t) {
            var e = this.local;
            return Ext.isObject(t) && SYNO.SDS.Utils.IsAllowRelay(t) && t.hasOpenConfig("cms_id") && (e = "cms_ds_" + t.getOpenConfig("cms_id")), e
        }
    }), SYNO.API.Request.Polling.InitInstance = function(t) {
        return t || (t = {}), Ext.isEmpty(t._Instance) && (t._Instance = new SYNO.API.Request.Polling, t._Instance.beginPolling()), t._Instance
    }, SYNO.API.Request.Polling.Instance = SYNO.API.Request.Polling.InitInstance(SYNO.API.Request.Polling.Instance), SYNO.API.Request.Polling.List = function(t) {
        return SYNO.API.Request.Polling.Instance.list(t)
    }, SYNO.API.Request.Polling.Register = function(t) {
        return SYNO.API.Request.Polling.Instance.register(t)
    }, SYNO.API.Request.Polling.Unregister = function(t) {
        return SYNO.API.Request.Polling.Instance.unregister(t)
    }, Ext.define("SYNO.API.Info", {
        extend: "Ext.util.Observable",
        local: "info_local",
        constructor: function() {
            this.callParent(arguments), this._session = {}, this._define = {}, this._knownAPI = {}
        },
        check: function(t) {
            var e;
            if (!Ext.isObject(t)) throw "Error! appwindow is incorrect!";
            if (Ext.isFunction(t.findAppWindow) && (e = t.findAppWindow(), Ext.isObject(e) && Ext.isObject(e.openConfig) && Ext.isFunction(e.hasOpenConfig) && Ext.isFunction(e.getOpenConfig) && Ext.isFunction(e.setOpenConfig))) return e
        },
        getInstName: function(t) {
            var e = this.local,
                i = this.check(t);
            return Ext.isObject(i) && SYNO.SDS.Utils.IsAllowRelay(i) && i.hasOpenConfig("cms_id") && (e = "cms_ds_" + i.getOpenConfig("cms_id")), e
        },
        getInstNameById: function(t) {
            var e = this.local;
            return Ext.isNumber(t) && 0 <= t && (e = "cms_ds_" + t), e
        },
        checkInst: function(t, e, i, s, n) {
            return t !== this.local && (Ext.isObject(s) && Ext.isObject(i) ? (this.handleResponse(e, i, s, n), !1) : !(t in this._define && t in this._session && !0 !== i) || (this.handleResponse({
                cms_id: 0
            }, void 0, void 0, n), !1))
        },
        updateInstById: function(t, e, i) {
            var s, n, o;
            Ext.isObject(t) && (t = (n = t).cms_id, s = this.getInstNameById(n.cms_id), o = Ext.copyTo({}, n, "callback,args,scope")), !1 !== this.checkInst(s, {
                cms_id: t
            }, e, i, o) && (SYNO.API.Request({
                api: "SYNO.CMS.DS",
                version: 1,
                method: "relay",
                timeout: 3e4,
                params: {
                    id: t,
                    timeout: 30,
                    webapi: {
                        api: "SYNO.API.Info",
                        version: 1,
                        method: "query"
                    }
                },
                appOpt: o,
                cms_id: t,
                callback: function(t, e, i, n) {
                    this._knownAPI[s] = !0 !== t ? void 0 : e
                },
                scope: this
            }), SYNO.API.Request({
                api: "SYNO.CMS.DS",
                version: 1,
                method: "relay",
                timeout: 3e4,
                params: {
                    id: t,
                    timeout: 30,
                    webapi: {
                        api: "SYNO.Entry.Request",
                        version: 1,
                        method: "request",
                        compound: [{
                            api: "SYNO.Core.System",
                            version: 1,
                            method: "info",
                            type: "define"
                        }, {
                            api: "SYNO.Core.System",
                            version: 1,
                            method: "info",
                            type: "session"
                        }]
                    }
                },
                appOpt: o,
                cms_id: t,
                callback: this.onUpdateInst,
                scope: this
            }))
        },
        updateInst: function(t, e, i) {
            var s = this.check(t),
                n = this.getInstName(t);
            !1 !== this.checkInst(n, {
                appWindow: t
            }, e, i) && (s.sendWebAPI({
                api: "SYNO.API.Info",
                version: 1,
                method: "query",
                callback: function(t, e, i, s) {
                    this._knownAPI[n] = !0 !== t ? void 0 : e
                },
                scope: this
            }), this._knownAPI.hasOwnProperty(n) && Ext.isEmpty(this._knownAPI[n]) || s.sendWebAPI({
                compound: {
                    stopwhenerror: !1,
                    params: [{
                        api: "SYNO.Core.System",
                        version: 1,
                        method: "info",
                        params: {
                            type: "define"
                        }
                    }, {
                        api: "SYNO.Core.System",
                        version: 1,
                        method: "info",
                        params: {
                            type: "session"
                        }
                    }]
                },
                callback: this.onUpdateInst,
                scope: this
            }))
        },
        checkUpdateResponse: function(t, e, i, s) {
            var n;
            return n = Ext.isNumber(s.cms_id) ? this.getInstNameById(s.cms_id) : this.getInstName(s.appWindow), t ? n !== this.local && (2 !== e.result.length ? (SYNO.Debug.error("Incorrect response:" + Ext.encode(e.result)), !1) : !1 !== e.result[0].success && !1 !== e.result[1].success || (delete this._session[n], delete this._define[n], !1)) : (SYNO.Debug.error("Update session and define fail"), !1)
        },
        onUpdateInst: function(t, e, i, s) {
            this.checkUpdateResponse(t, e, i, s) ? this.handleResponse(s, e.result[0].data, e.result[1].data, s.appOpt) : this.handleResponse({
                cms_id: 0
            }, void 0, void 0, s.appOpt)
        },
        handleResponse: function(t, e, i, s) {
            var n;
            (n = Ext.isNumber(t.cms_id) ? this.getInstNameById(t.cms_id) : this.getInstName(t.appWindow)) !== this.local && (this._define[n] = Ext.apply({}, e), this._session[n] = Ext.apply({}, i)), Ext.isObject(s) && Ext.isFunction(s.callback) && (n in this._knownAPI ? s.callback.apply(s.scope || this, s.args) : s.callback.defer(1e3, s.scope || this, s.args))
        },
        removeById: function(t) {
            var e = this.getInstNameById(t);
            e !== this.local && (delete this._define[e], delete this._session[e], delete this._knownAPI[e])
        },
        getDefine: function(t, e, i) {
            var s = this.getInstName(t);
            return s === this.local ? _D(e, i) : Ext.isEmpty(this._session[s]) ? (this.updateInst(t), void SYNO.Debug.error("Please update first")) : e in this._define[s] ? this._define[s][e] : Ext.isString(i) ? i : ""
        },
        getSession: function(t, e) {
            var i = this.getInstName(t);
            if (i === this.local) return _S(e);
            switch (e) {
                case "lang":
                case "isMobile":
                case "demo_mode":
                case "SynoToken":
                    return _S(e);
                default:
                    return Ext.isEmpty(this._session[i]) ? (this.updateInst(t), void SYNO.Debug.error("[Info]Please update first")) : this._session[i][e]
            }
        },
        getKnownAPI: function(t, e, i) {
            var s = this.getInstName(t);
            return s === this.local ? SYNO.API.GetKnownAPI(e, i) : Ext.isEmpty(this._knownAPI[s]) || Ext.isEmpty(this._knownAPI[s][e]) ? (this.updateInst(t), void SYNO.Debug.warn("[Info]Please update first")) : this._knownAPI[s][e]
        }
    }), SYNO.API.Info.InitInstance = function(t) {
        return t || (t = {}), Ext.isEmpty(t._Instance) && (t._Instance = new SYNO.API.Info), t._Instance
    }, SYNO.API.Info.Instance = SYNO.API.Info.InitInstance(SYNO.API.Info.Instance), SYNO.API.Info.GetSession = function(t, e) {
        return SYNO.API.Info.Instance.getSession(t, e)
    }, SYNO.API.Info.GetDefine = function(t, e, i) {
        return SYNO.API.Info.Instance.getDefine(t, e, i)
    }, SYNO.API.Info.GetKnownAPI = function(t, e, i) {
        return SYNO.API.Info.Instance.getKnownAPI(t, e, i)
    }, SYNO.API.Info.Update = function(t, e, i) {
        return SYNO.API.Info.Instance.updateInst(t, e, i)
    }, SYNO.API.Info.UpdateById = function(t) {
        return SYNO.API.Info.Instance.updateInstById(t)
    }, SYNO.API.Info.RemoveById = function(t) {
        return SYNO.API.Info.Instance.removeById(t)
    }, Ext.namespace("SYNO.API"), SYNO.API.GetErrors = function() {
        var t = {
            minCustomeError: 400
        };
        return t.common = {
            0: _T("common", "commfail"),
            100: _T("common", "error_system"),
            101: "Bad Request",
            102: "No Such API",
            103: "No Such Method",
            104: "Not Supported Version",
            105: _T("error", "error_privilege_not_enough"),
            106: _T("error", "error_timeout"),
            107: _T("login", "error_interrupt"),
            108: _T("user", "user_file_upload_fail"),
            109: _T("error", "error_error_system"),
            110: _T("error", "error_error_system"),
            111: _T("error", "error_error_system"),
            112: "Stop Handling Compound Request",
            113: "Invalid Compound Request",
            114: _T("error", "error_invalid"),
            115: _T("error", "error_invalid"),
            116: _JSLIBSTR("uicommon", "error_demo"),
            117: _T("error", "error_error_system"),
            118: _T("error", "error_error_system"),
            122: _T("error", "error_privilege_not_enough"),
            123: _T("error", "error_privilege_not_enough"),
            124: _T("error", "error_privilege_not_enough"),
            125: _T("error", "error_timeout"),
            126: _T("error", "error_privilege_not_enough"),
            127: _T("error", "error_privilege_not_enough"),
            160: _T("error", "error_privilege_not_enough")
        }, t.core = {
            402: _T("share", "no_such_share"),
            403: _T("error", "error_invalid"),
            404: _T("error", "error_privilege_not_enough"),
            1101: _T("error", "error_subject"),
            1102: _T("firewall", "firewall_restore_failed"),
            1103: _T("firewall", "firewall_block_admin_client"),
            1104: _T("firewall", "firewall_rule_exceed_max_number"),
            1105: _T("firewall", "firewall_rule_disable_fail"),
            1198: _T("common", "version_not_support"),
            1201: _T("error", "error_subject"),
            1202: _T("firewall", "firewall_tc_ceil_exceed_system_upper_bound"),
            1203: _T("firewall", "firewall_tc_max_ceil_too_large"),
            1204: _T("firewall", "firewall_tc_restore_failed"),
            1301: _T("error", "error_subject"),
            1302: _T("firewall", "firewall_dos_restore_failed"),
            1402: _T("service", "service_ddns_domain_load_error"),
            1410: _T("service", "service_ddns_operation_fail"),
            1500: _T("common", "error_system"),
            1501: _T("common", "error_apply_occupied"),
            1502: _T("routerconf", "routerconf_external_ip_warning"),
            1503: _T("routerconf", "routerconf_require_gateway"),
            1504: _T("routerconf", "dns_setting_no_response"),
            1510: _T("routerconf", "routerconf_update_db_failed"),
            1521: _T("routerconf", "routerconf_exceed_singel_max_port"),
            1522: _T("routerconf", "routerconf_exceed_combo_max_port"),
            1523: _T("routerconf", "routerconf_exceed_singel_range_max_port"),
            1524: _T("routerconf", "routerconf_exceed_max_rule"),
            1525: _T("routerconf", "routerconf_port_conflict"),
            1526: _T("routerconf", "routerconf_add_port_failed"),
            1527: _T("routerconf", "routerconf_apply_failed"),
            1528: _T("routerconf", "protocol_on_router_not_enabled"),
            1530: _T("routerconf", "routerconf_syntax_version_error"),
            1600: _T("error", "error_error_system"),
            1601: _T("error", "error_error_system"),
            1602: _T("error", "error_error_system"),
            1701: _T("error", "error_port_conflict"),
            1702: _T("error", "error_file_exist"),
            1703: _T("error", "error_no_path"),
            1704: _T("error", "error_error_system"),
            1706: _T("error", "error_volume_ro"),
            1903: _T("error", "error_port_conflict"),
            1904: _T("error", "error_port_conflict"),
            1905: _T("ftp", "ftp_annoymous_root_share_invalid"),
            1951: _T("error", "error_port_conflict"),
            2001: _T("error", "error_error_system"),
            2002: _T("error", "error_error_system"),
            2101: _T("error", "error_error_system"),
            2102: _T("error", "error_error_system"),
            2201: _T("error", "error_error_system"),
            2202: _T("error", "error_error_system"),
            2301: _T("error", "error_invalid"),
            2303: _T("error", "error_port_conflict"),
            2331: _T("nfs", "nfs_key_wrong_format"),
            2332: _T("user", "user_file_upload_fail"),
            2371: _T("error", "error_mount_point_nfs"),
            2372: _T("error", "error_hfs_plus_mount_point_nfs"),
            2401: _T("error", "error_error_system"),
            2402: _T("error", "error_error_system"),
            2403: _T("error", "error_port_conflict"),
            2500: _T("error", "error_unknown_desc"),
            2502: _T("error", "error_invalid"),
            2503: _T("error", "error_error_system"),
            2504: _T("error", "error_error_system"),
            2505: _T("error", "error_error_system"),
            2601: _T("network", "domain_name_err"),
            2602: _T("network", "domain_dns_name_err"),
            2603: _T("network", "domain_kdc_ip_error"),
            2604: _T("network", "error_badgname"),
            2605: _T("network", "domain_unreachserver_err"),
            2606: _T("network", "domain_port_unreachable_err"),
            2607: _T("network", "domain_password_err"),
            2608: _T("network", "domain_acc_revoked_ads"),
            2609: _T("network", "domain_acc_revoked_rpc"),
            2610: _T("network", "domain_acc_err"),
            2611: _T("network", "domain_notadminuser"),
            2612: _T("network", "domain_change_passwd"),
            2613: _T("network", "domain_check_kdcip"),
            2614: _T("network", "domain_error_misc_rpc"),
            2615: _T("network", "domain_join_err"),
            2616: _T("directory_service", "warr_enable_samba"),
            2626: _T("directory_service", "warr_db_not_ready"),
            2628: _T("directory_service", "warr_synoad_exists"),
            2702: _T("network", "status_connected"),
            2703: _T("network", "status_disconnected"),
            2704: _T("common", "error_occupied"),
            2705: _T("common", "error_system"),
            2706: _T("ldap_error", "ldap_invalid_credentials"),
            2707: _T("ldap_error", "ldap_operations_error"),
            2708: _T("ldap_error", "ldap_server_not_support"),
            2709: _T("domain", "domain_ldap_conflict"),
            2710: _T("ldap_error", "ldap_operations_error"),
            2712: _T("ldap_error", "ldap_no_such_object"),
            2713: _T("ldap_error", "ldap_protocol_error"),
            2714: _T("ldap_error", "ldap_invalid_dn_syntax"),
            2715: _T("ldap_error", "ldap_insufficient_access"),
            2716: _T("ldap_error", "ldap_insufficient_access"),
            2717: _T("ldap_error", "ldap_timelimit_exceeded"),
            2718: _T("ldap_error", "ldap_inappropriate_auth"),
            2719: _T("ldap_error", "ldap_smb2_enable_warning"),
            2721: _T("ldap_error", "ldap_confidentiality_required"),
            2799: _T("common", "error_system"),
            2800: _T("error", "error_unknown_desc"),
            2801: _T("error", "error_unknown_desc"),
            2900: _T("error", "error_unknown_desc"),
            2901: _T("error", "error_unknown_desc"),
            2902: _T("relayservice", "relayservice_err_network"),
            2903: _T("relayservice", "error_alias_server_internal"),
            2904: _T("relayservice", "relayservice_err_alias_in_use"),
            2905: _T("pkgmgr", "myds_error_account"),
            2906: _T("relayservice", "error_alias_used_in_your_own"),
            3000: _T("error", "error_unknown_desc"),
            3001: _T("error", "error_unknown_desc"),
            3002: _T("relayservice", "relayservice_err_resolv"),
            3003: _T("relayservice", "myds_server_internal_error"),
            3004: _T("error", "error_auth"),
            3005: _T("relayservice", "relayservice_err_alias_in_use"),
            3006: _T("relayservice", "myds_exceed_max_register_error"),
            3009: _T("error", "error_unknown_desc"),
            3010: _T("myds", "already_logged_in"),
            3013: _T("myds", "error_migrate_authen"),
            3106: _T("user", "no_such_user"),
            3107: _T("user", "error_nameused"),
            3108: _T("user", "error_nameused"),
            3109: _T("user", "error_disable_admin"),
            3110: _T("user", "error_too_much_user"),
            3111: _T("user", "homes_not_found"),
            3112: _T("common", "error_apply_occupied"),
            3113: _T("common", "error_occupied"),
            3114: _T("user", "error_nameused"),
            3115: _T("user", "user_cntrmvdefuser"),
            3116: _T("user", "user_set_fail"),
            3117: _T("user", "user_quota_set_fail"),
            3118: _T("common", "error_no_enough_space"),
            3119: _T("user", "error_home_is_moving"),
            3121: _T("common", "err_pass"),
            3122: _T("login", "password_in_history"),
            3123: _T("login", "password_too_common"),
            3124: _T("common", "err_pass"),
            3130: _T("user", "invalid_syntax_enclosed_trailing"),
            3131: _T("user", "invalid_syntax_double_quote_in_middle"),
            3132: _T("user", "invalid_syntax_not_double_quote_ending"),
            3191: _T("user", "user_file_open_fail"),
            3192: _T("user", "user_file_empty"),
            3193: _T("user", "user_file_not_utf8"),
            3194: _T("user", "user_upload_no_volume"),
            3202: _T("common", "error_occupied"),
            3204: _T("group", "failed_load_group"),
            3205: _T("group", "failed_load_group"),
            3206: _T("group", "error_nameused"),
            3207: _T("group", "error_nameused"),
            3208: _T("group", "error_badname"),
            3209: _T("group", "error_toomanygr"),
            3210: _T("group", "error_rmmember"),
            3217: _T("group", "error_too_many_dir_admin"),
            3221: _T("share", "error_too_many_acl_rules") + "(" + _T("acl_editor", "acl_rules_reach_limit_report").replace(/.*\//, "").trim().replace("_maxCount_", "200") + ")",
            3299: _T("common", "error_system"),
            3301: _T("share", "share_already_exist"),
            3302: _T("share", "share_acl_volume_not_support"),
            3303: _T("share", "error_encrypt_reserve"),
            3304: _T("share", "error_volume_not_found"),
            3305: _T("share", "error_badname"),
            3308: _T("common", "err_pass"),
            3309: _T("share", "error_toomanysh"),
            3313: _T("share", "error_volume_not_found"),
            3314: _T("share", "error_volume_read_only"),
            3319: _T("share", "error_nameused"),
            3320: _T("share", "share_space_not_enough"),
            3321: _T("share", "error_too_many_acl_rules") + "(" + _T("acl_editor", "acl_rules_reach_limit_report").replace(/.*\//, "").trim().replace("_maxCount_", "200") + ")",
            3322: _T("share", "mount_point_not_empty"),
            3323: _T("error", "error_mount_point_change_vol"),
            3324: _T("error", "error_mount_point_rename"),
            3326: _T("share", "error_key_file"),
            3327: _T("share", "share_conflict_on_new_volume"),
            3328: _T("share", "get_lock_failed"),
            3329: _T("share", "error_toomanysnapshot"),
            3330: _T("share", "share_snapshot_busy"),
            3332: _T("backup", "is_backing_up_restoring"),
            3334: _T("share", "error_mount_point_restore"),
            3335: _T("share", "share_cannot_move_fstype_not_support"),
            3336: _T("share", "share_cannot_move_replica_busy"),
            3337: _T("snapmgr", "snap_system_preserved"),
            3338: _T("share", "error_mounted_encrypt_restore"),
            3340: _T("snapmgr", "snap_restore_share_conf_err"),
            3341: _T("snapmgr", "err_quota_is_not_enough"),
            3344: _T("keymanager", "error_invalid_passphrase"),
            3345: _T("keymanager", "error_used_keystore"),
            3400: _T("error", "error_error_system"),
            3401: _T("error", "error_error_system"),
            3402: _T("error", "error_error_system"),
            3403: _T("app_privilege", "error_no_such_user_or_group"),
            3500: _T("error", "error_invalid"),
            3501: _T("common", "error_badport"),
            3502: _T("error", "error_port_conflict"),
            3503: _T("error", "error_port_conflict"),
            3504: _T("error", "error_port_conflict"),
            3505: _T("app_port_alias", "err_fqdn_duplicated"),
            3510: _T("error", "error_invalid"),
            3511: _T("app_port_alias", "err_port_dup"),
            3550: _T("volume", "volume_no_volumes"),
            3551: _T("error", "error_no_shared_folder"),
            3552: String.format(_T("volume", "volume_crashed_service_disable"), _T("common", "web_station")),
            3553: _T("volume", "volume_expanding_waiting"),
            3554: _T("error", "error_port_conflict"),
            3555: _T("common", "error_badport"),
            3603: _T("volume", "volume_share_volumeno"),
            3604: _T("error", "error_space_not_enough"),
            3605: _T("usb", "usb_printer_driver_fail"),
            3606: _T("login", "error_cantlogin"),
            3607: _T("common", "error_badip"),
            3608: _T("usb", "net_prntr_ip_exist_error"),
            3609: _T("usb", "net_prntr_ip_exist_unknown"),
            3610: _T("common", "error_demo"),
            3611: _T("usb", "net_prntr_name_exist_error"),
            3700: _T("error", "error_invalid"),
            3701: _T("status", "status_not_available"),
            3702: _T("error", "error_invalid"),
            3710: _T("status", "status_not_available"),
            3711: _T("error", "error_invalid"),
            3712: _T("cms", "fan_mode_not_supported"),
            3720: _T("status", "status_not_available"),
            3721: _T("error", "error_invalid"),
            3730: _T("status", "status_not_available"),
            3731: _T("error", "error_invalid"),
            3740: _T("status", "status_not_available"),
            3741: _T("error", "error_invalid"),
            3750: _T("status", "status_not_available"),
            3751: _T("error", "error_invalid"),
            3760: _T("status", "status_not_available"),
            3761: _T("error", "error_invalid"),
            3800: _T("error", "error_invalid"),
            3801: _T("error", "error_invalid"),
            4000: _T("error", "error_invalid"),
            4001: _T("error", "error_error_system"),
            4002: _T("dsmoption", "error_format"),
            4003: _T("dsmoption", "error_size"),
            4100: _T("error", "error_invalid"),
            4101: _T("error", "error_invalid"),
            4102: _T("app_port_alias", "err_alias_refused"),
            4103: _T("app_port_alias", "err_alias_used"),
            4104: _T("app_port_alias", "err_port_used"),
            4105: _T("app_port_alias", "err_port_used"),
            4106: _T("app_port_alias", "err_port_used"),
            4107: _T("app_port_alias", "err_fqdn_duplicated"),
            4154: _T("app_port_alias", "err_fqdn_duplicated"),
            4155: _T("app_port_alias", "err_port_used"),
            4156: _T("app_port_alias", "err_invalid_backend_host"),
            4164: _T("app_port_alias", "err_invalid_header_name"),
            4165: _T("app_port_alias", "err_invalid_header_value"),
            4166: _T("app_port_alias", "err_header_name_duplicated"),
            4168: _T("app_port_alias", "err_proxy_timeout"),
            4169: _T("app_port_alias", "err_proxy_timeout"),
            4170: _T("app_port_alias", "err_proxy_timeout"),
            4300: _T("error", "error_error_system"),
            4301: _T("error", "error_error_system"),
            4302: _T("error", "error_error_system"),
            4303: _T("error", "error_invalid"),
            4304: _T("error", "error_error_system"),
            4305: _T("error", "error_error_system"),
            4306: _T("error", "error_error_system"),
            4307: _T("error", "error_error_system"),
            4308: _T("error", "error_error_system"),
            4309: _T("error", "error_invalid"),
            4310: _T("error", "error_error_system"),
            4311: _T("network", "interface_not_found"),
            4312: _T("tcpip", "tcpip_ip_used"),
            4313: _T("tcpip", "ipv6_ip_used"),
            4314: _T("tunnel", "tunnel_conn_fail"),
            4315: _T("tcpip", "ipv6_err_link_local"),
            4316: _T("network", "error_applying_network_setting"),
            4317: _T("common", "error_notmatch"),
            4319: _T("error", "error_error_system"),
            4320: _T("vpnc", "name_conflict"),
            4321: _T("service", "service_illegel_crt"),
            4322: _T("service", "service_illegel_key"),
            4323: _T("service", "service_ca_not_utf8"),
            4324: _T("service", "service_unknown_cipher"),
            4325: _T("vpnc", "l2tp_conflict"),
            4326: _T("vpnc", "vpns_conflict"),
            4327: _T("vpnc", "ovpnfile_invalid_format"),
            4340: _T("background_task", "task_processing"),
            4350: _T("tcpip", "ipv6_invalid_config"),
            4351: _T("tcpip", "ipv6_router_bad_lan_req"),
            4352: _T("tcpip", "ipv6_router_err_enable"),
            4353: _T("tcpip", "ipv6_router_err_disable"),
            4354: _T("tcpip", "ipv6_no_public_ip"),
            4370: _T("ovs", "ovs_not_support_bonding"),
            4371: _T("ovs", "ovs_not_support_vlan"),
            4372: _T("ovs", "ovs_not_support_bridge"),
            4373: _T("network", "linkaggr_mode_inconsistent_err"),
            4380: _T("router_networktools", "ping_target_invalid"),
            4381: _T("router_networktools", "ping_timeout"),
            4382: _T("router_networktools", "traceroute_target_invalid"),
            4500: _T("error", "error_error_system"),
            4501: _T("error", "error_error_system"),
            4502: _T("pkgmgr", "pkgmgr_space_not_ready"),
            4503: _T("error", "volume_creating"),
            4504: _T("pkgmgr", "error_sys_no_space"),
            4506: _T("pkgmgr", "noncancellable"),
            4520: _T("error", "error_space_not_enough"),
            4521: _T("pkgmgr", "pkgmgr_file_not_package"),
            4522: _T("pkgmgr", "broken_package"),
            4529: _T("pkgmgr", "pkgmgr_pkg_cannot_upgrade"),
            4530: _T("pkgmgr", "error_occupied"),
            4531: _T("pkgmgr", "pkgmgr_not_syno_publish"),
            4532: _T("pkgmgr", "pkgmgr_unknown_publisher"),
            4533: _T("pkgmgr", "pkgmgr_cert_expired"),
            4534: _T("pkgmgr", "pkgmgr_cert_revoked"),
            4535: _T("pkgmgr", "broken_package"),
            4540: _T("pkgmgr", "pkgmgr_file_install_failed"),
            4541: _T("pkgmgr", "upgrade_fail"),
            4542: _T("error", "error_error_system"),
            4543: _T("pkgmgr", "pkgmgr_file_not_package"),
            4544: _T("pkgmgr", "pkgmgr_pkg_install_already"),
            4545: _T("pkgmgr", "pkgmgr_pkg_not_available"),
            4548: _T("pkgmgr", "install_version_less_than_limit"),
            4549: _T("pkgmgr", "depend_cycle"),
            4570: _T("common", "error_invalid_serial"),
            4580: _T("pkgmgr", "pkgmgr_pkg_start_failed"),
            4581: _T("pkgmgr", "pkgmgr_pkg_stop_failed"),
            4590: _T("pkgmgr", "invalid_feed"),
            4591: _T("pkgmgr", "duplicate_feed"),
            4592: _T("pkgmgr", "duplicate_certificate"),
            4593: _T("pkgmgr", "duplicate_certificate_sys"),
            4594: _T("pkgmgr", "revoke_certificate"),
            4595: _T("service", "service_illegel_crt"),
            4600: _T("error", "error_error_system"),
            4601: _T("error", "error_error_system"),
            4602: _T("notification", "google_auth_failed"),
            4631: _T("error", "error_error_system"),
            4632: _T("error", "error_error_system"),
            4633: _T("error", "error_error_system"),
            4634: _T("error", "error_error_system"),
            4635: _T("error", "error_error_system"),
            4661: _T("pushservice", "error_update_ds_info"),
            4800: _T("error", "error_invalid"),
            4801: _T("error", "error_error_system"),
            4802: _T("error", "error_error_system"),
            4803: _T("error", "error_error_system"),
            4804: _T("error", "error_error_system"),
            4900: _T("error", "error_invalid"),
            4901: _T("error", "error_error_system"),
            4902: _T("user", "no_such_user"),
            4903: _T("report", "err_dest_share_not_exist"),
            4904: _T("error", "error_file_exist"),
            4905: _T("error", "error_space_not_enough"),
            5000: _T("error", "error_invalid"),
            5001: _T("error", "error_invalid"),
            5002: _T("error", "error_invalid"),
            5003: _T("error", "error_invalid"),
            5004: _T("error", "error_invalid"),
            5005: _T("syslog", "err_server_disconnected"),
            5006: _T("syslog", "service_ca_copy_failed"),
            5007: _T("syslog", "service_ca_copy_failed"),
            5008: _T("error", "error_invalid"),
            5009: _T("error", "error_port_conflict"),
            5010: _T("error", "error_invalid"),
            5011: _T("error", "error_invalid"),
            5012: _T("syslog", "err_name_conflict"),
            5100: _T("error", "error_invalid"),
            5101: _T("error", "error_invalid"),
            5102: _T("error", "error_invalid"),
            5103: _T("error", "error_invalid"),
            5104: _T("error", "error_invalid"),
            5105: _T("error", "error_invalid"),
            5106: _T("error", "error_invalid"),
            5202: _T("update", "error_apply_lock"),
            5203: _T("volume", "volume_busy_waiting"),
            5205: _T("update", "error_bad_dsm_version"),
            5206: _T("update", "update_notice"),
            5207: _T("update", "error_model"),
            5208: _T("update", "error_apply_lock"),
            5209: _T("update", "error_patch"),
            5211: _T("update", "upload_err_no_space"),
            5213: _T("pkgmgr", "error_occupied"),
            5214: _T("update", "check_new_dsm_err"),
            5215: _T("error", "error_space_not_enough"),
            5216: _T("error", "error_fs_ro"),
            5217: _T("error", "error_dest_no_path"),
            5219: _T("update", "autoupdate_cancel_failed_running"),
            5220: _T("update", "autoupdate_cancel_failed_no_task"),
            5221: _T("update", "autoupdate_cancel_failed"),
            5222: _T("update", "error_verify_patch"),
            5223: _T("update", "error_updater_prehook_failed"),
            5300: _T("error", "error_invalid"),
            5301: _T("user", "no_such_user"),
            5510: _T("service", "service_illegel_crt"),
            5511: _T("service", "service_illegel_key"),
            5512: _T("service", "service_illegal_inter_crt"),
            5513: _T("service", "service_unknown_cypher"),
            5514: _T("service", "service_key_not_match"),
            5515: _T("service", "service_ca_copy_failed"),
            5516: _T("service", "service_ca_not_utf8"),
            5517: _T("certificate", "inter_and_crt_verify_error"),
            5518: _T("certificate", "not_support_dsa"),
            5519: _T("service", "service_illegal_csr"),
            5520: _T("backup", "general_backup_destination_no_response"),
            5521: _T("certificate", "err_connection"),
            5522: _T("certificate", "err_server_not_match"),
            5523: _T("certificate", "err_too_many_reg"),
            5524: _T("certificate", "err_too_many_req"),
            5525: _T("certificate", "err_mail"),
            5526: _T("s2s", "err_invalid_param_value"),
            5527: _T("certificate", "not_support_ecc"),
            5600: _T("error", "error_no_path"),
            5601: _T("file", "error_bad_file_content"),
            5602: _T("error", "error_error_system"),
            5603: _T("texteditor", "LoadFileFail"),
            5604: _T("texteditor", "SaveFileFail"),
            5605: _T("error", "error_privilege_not_enough"),
            5606: _T("texteditor", "CodepageConvertFail"),
            5607: _T("texteditor", "AskForceSave"),
            5608: _T("error", "error_encryption_long_path"),
            5609: _T("error", "error_long_path"),
            5610: _T("error", "error_quota_not_enough"),
            5611: _T("error", "error_space_not_enough"),
            5612: _T("error", "error_io"),
            5613: _T("error", "error_privilege_not_enough"),
            5614: _T("error", "error_fs_ro"),
            5615: _T("error", "error_file_exist"),
            5616: _T("error", "error_no_path"),
            5617: _T("error", "error_dest_no_path"),
            5618: _T("error", "error_testjoin"),
            5619: _T("error", "error_reserved_name"),
            5620: _T("error", "error_fat_reserved_name"),
            5621: _T("texteditor", "exceed_load_max"),
            5703: _T("time", "ntp_service_disable_warning"),
            5800: _T("error", "error_invalid"),
            5801: _T("share", "no_such_share"),
            5901: _T("error", "error_subject"),
            5902: _T("firewall", "firewall_vpnpassthrough_restore_failed"),
            5903: _T("firewall", "firewall_vpnpassthrough_specific_platform"),
            6000: _T("error", "error_error_system"),
            6001: _T("error", "error_error_system"),
            6002: _T("error", "error_error_system"),
            6003: _T("error", "error_error_system"),
            6004: _T("common", "loadsetting_fail"),
            6005: _T("error", "error_subject"),
            6006: _T("error", "error_service_start_failed"),
            6007: _T("error", "error_service_stop_failed"),
            6008: _T("error", "error_service_start_failed"),
            6009: _T("firewall", "firewall_save_failed"),
            6010: _T("common", "error_badip"),
            6011: _T("common", "error_badip"),
            6012: _T("common", "error_badip"),
            6013: _T("share", "no_such_share"),
            6014: _T("cms", "cms_no_volumes"),
            6200: _T("error", "error_error_system"),
            6201: _T("error", "error_acl_volume_not_support"),
            6202: _T("error", "error_fat_privilege"),
            6203: _T("error", "error_remote_privilege"),
            6204: _T("error", "error_fs_ro"),
            6205: _T("error", "error_privilege_not_enough"),
            6206: _T("error", "error_no_path"),
            6207: _T("error", "error_no_path"),
            6208: _T("error", "error_testjoin"),
            6209: _T("error", "error_privilege_not_enough"),
            6210: _T("acl_editor", "admin_cannot_set_acl_perm"),
            6211: _T("acl_editor", "error_invalid_user_or_group"),
            6212: _T("error", "error_acl_mp_not_support"),
            6213: _T("acl_editor", "quota_exceeded"),
            6703: _T("error", "error_port_conflict"),
            6704: _T("error", "error_port_conflict"),
            6705: _T("user", "no_such_user"),
            6706: _T("user", "error_nameused"),
            6708: _T("share", "error_volume_not_found"),
            6709: _T("netbackup", "err_create_service_share"),
            7100: _T("connections", "error_disable_admin_name"),
            8000: _T("router_wireless", "wifi_daemon_not_ready"),
            8001: _T("network", "net_daemon_not_ready"),
            8002: _T("network", "usbmodem_daemon_not_ready"),
            8003: _T("wireless_ap", "ap_ssid_limit_alert"),
            8010: _T("router_topology", "get_topology_fail"),
            8011: _T("network", "net_get_fail"),
            8012: _T("network", "net_get_setting_fail"),
            8013: _T("router_wireless", "wifi_setting_get_fail"),
            8020: _T("router_topology", "set_topology_fail"),
            8021: _T("network", "net_set_fail"),
            8022: _T("network", "net_set_setting_fail"),
            8023: _T("router_wireless", "wifi_setting_set_fail"),
            8030: _T("network", "get_redirect_info_fail"),
            8031: _T("router_common", "dhcp_range_conflict_err"),
            8100: _T("router_wireless", "guest_network_get_count_down_fail"),
            8101: _T("router_wireless", "guest_network_set_count_down_fail"),
            8130: _T("pppoe", "pppoe_get_setting_fail"),
            8131: _T("pppoe", "pppoe_set_setting_fail"),
            8132: _T("pppoe", "pppoe_no_interface_available"),
            8133: _T("pppoe", "pppoe_service_start_fail"),
            8134: _T("pppoe", "pppoe_service_stop_fail"),
            8135: _T("pppoe", "pppoe_connection_failed"),
            8136: _T("pppoe", "pppoe_disconnect_fail"),
            8150: _T("wireless_ap", "country_code_get_fail"),
            8151: _T("wireless_ap", "country_code_set_fail"),
            8152: _T("wireless_ap", "country_code_read_list_fail"),
            8153: _T("wireless_ap", "country_code_region_not_support"),
            8170: _T("routerconf", "routerconf_exceed_max_rule"),
            8175: _T("smartwan", "sw_too_many_rules"),
            8180: _T("routerconf", "routerconf_exceed_max_rule"),
            8190: _T("router_parental", "err_device_reach_max"),
            8200: _T("router_parental", "err_domain_name_reach_max"),
            8230: _T("routerconf", "routerconf_exceed_max_reservation"),
            8231: _T("routerconf", "routerconf_exceed_max_reservation_v6")
        }, t
    }, SYNO.API.AssignErrorStr = function() {
        SYNO.API.Errors = SYNO.API.GetErrors()
    }, SYNO.API.AssignErrorStr(), SYNO.API.Erros = function() {
        if (Ext.isIE8) return SYNO.API.Errors;
        var t = {},
            e = function(e) {
                Object.defineProperty(t, e, {
                    get: function() {
                        return SYNO.Debug.warn("SYNO.API.Erros is deprecated (typo), please use SYNO.API.Errors instead."), SYNO.API.Errors[e]
                    },
                    configurable: !1
                })
            };
        for (var i in SYNO.API.Errors) SYNO.API.Errors.hasOwnProperty(i) && e(i);
        return t
    }(), Ext.namespace("SYNO.SDS.Utils"),
    function() {
        var t = "text-align: left;",
            e = "overflow: hidden;display: inline;" + t,
            i = "width: auto;margin-right: 5px;display: inline;" + t,
            s = e + "width: 0px; visibility: hidden;",
            n = function(t, e) {
                return void 0 === e ? String.format("margin-left: {0}px;", t) : String.format("width: {0}px; margin-left: {1}px", e - t, t)
            };
        Ext.apply(SYNO.SDS.Utils, {
            labelStyleL0: e + n(0, 167),
            labelStyleL1: e + n(Ext.isIE ? 19 : 17, 167),
            labelStyleL2: e + n(Ext.isIE ? 36 : 34, 167),
            labelStyleL0Auto: i,
            labelStyleL1Auto: i + n(Ext.isIE ? 19 : 17),
            labelStyleL2Auto: i + n(Ext.isIE ? 36 : 34),
            labelStyleL0Hidden: s + n(0),
            labelStyleL1Hidden: s + n(Ext.isIE ? 16 : 14)
        })
    }(), Ext.define("SYNO.SDS.Utils.MessageBox", {
        statics: {
            CreateMsgBox: function(t) {
                return t = t || {}, new SYNO.SDS.MessageBoxV5(Ext.applyIf(t, {
                    modal: !0,
                    preventDelay: !0,
                    draggable: !1,
                    renderTo: document.body
                })).getWrapper()
            }
        }
    }), String.prototype.hashCode = function() {
        var t, e = 0;
        if (0 === this.length) return e;
        for (t = 0; t < this.length; t++) e = (e << 5) - e + this.charCodeAt(t), e |= 0;
        return e
    }, SYNO.SDS.Utils.FieldFind = function(t, e) {
        var i = t.findField(e);
        return null === i && (i = Ext.getCmp(e)), i
    }, SYNO.SDS.Utils.DescribeGroup = function(t, e) {
        var i = function(t, e) {
                var i = t.getAriaEl().dom.getAttribute("aria-describedby") || "";
                i.replace(e.getAriaEl().id, ""), t.getAriaEl().setARIA({
                    describedby: i + " " + e.getAriaEl().id
                }), e.tabIndex = -1, e instanceof SYNO.ux.DisplayField && (e.customTabIdx = -1), e.getAriaEl().set({
                    tabIndex: -1
                })
            },
            s = function(t, e) {
                e.rendered ? i(t, e) : t.mon(e, "afterrender", i.createDelegate(t, [t, e]))
            };
        Ext.isArray(e) ? Ext.each(e, function(e) {
            SYNO.SDS.Utils.DescribeGroup(t, e)
        }) : t.rendered ? s(t, e) : t.mon(t, "afterrender", s.createDelegate(t, [t, e]))
    }, SYNO.SDS.Utils.EnableRadioGroup = Ext.extend(Object, {
        constructor: function(t, e, i) {
            this.form = t, this.members = i;
            for (var s = SYNO.SDS.Utils.getRadioGroup(t, e), n = 0; n < s.length; n++) {
                var o = s[n];
                o.el.dom.value in i && (o.mon(o, "check", this.onRadioCheck, this), o.mon(o, "enable", this.onRadioEnable, this, {
                    delay: 50
                }), o.mon(o, "disable", this.onRadioEnable, this, {
                    delay: 50
                }))
            }
        },
        onRadioEnable: function(t) {
            var e = t.getRawValue(),
                i = this.members[e],
                s = t.getValue() && !t.disabled;
            Ext.each(i, function(t) {
                var e = SYNO.SDS.Utils.FieldFind(this.form, t);
                e.setDisabled(!s), Ext.isFunction(e.clearInvalid) && e.clearInvalid()
            }, this)
        },
        onRadioCheck: function(t, e) {
            var i = t.getRawValue(),
                s = this.members[i];
            Ext.each(s, function(t) {
                var i = SYNO.SDS.Utils.FieldFind(this.form, t);
                i.setDisabled(!e), Ext.isFunction(i.clearInvalid) && i.clearInvalid()
            }, this)
        }
    }), SYNO.SDS.Utils.EnableCheckGroup = Ext.extend(Object, {
        constructor: function(t, e, i, s, n) {
            var o = SYNO.SDS.Utils.FieldFind(t, e);
            s = void 0 !== s ? s : [], n = Ext.isDefined(n) ? n : {}, this.enable_fields = i, this.disable_fields = s, this.config = n, this.form = t, o.mon(o, "check", this.checkHandler, this), o.mon(o, "enable", this.enableHandler, this, {
                delay: 50
            }), o.mon(o, "disable", this.enableHandler, this, {
                delay: 50
            }), this.checkHandler(o, o.getValue())
        },
        setFieldStatus: function(t, e, i, s) {
            var n, o;
            if ("radio" == e.inputType)
                for (n = SYNO.SDS.Utils.getRadioGroup(t, e.getName()), o = 0; o < n.length; o++) s ? i ? n[o].disable() : n[o].enable() : i ? n[o].enable() : n[o].disable(), Ext.isFunction(n[o].clearInvalid) && n[o].clearInvalid();
            else s ? i ? e.disable() : e.enable() : i ? e.enable() : e.disable(), Ext.isFunction(e.clearInvalid) && e.clearInvalid()
        },
        enableField: function(t, e, i) {
            this.setFieldStatus(t, e, i, !1)
        },
        IsNeedDisableGroup: function(t) {
            return !0 === this.config.disable_group && !0 === t
        },
        checkHandler: function(t, e) {
            var i, s, n = this.IsNeedDisableGroup(t.disabled);
            for (i = 0; i < this.enable_fields.length; i++) s = SYNO.SDS.Utils.FieldFind(this.form, this.enable_fields[i]), n ? this.enableField(this.form, s, !1) : this.setFieldStatus(this.form, s, e, !1);
            for (i = 0; i < this.disable_fields.length; i++) s = SYNO.SDS.Utils.FieldFind(this.form, this.disable_fields[i]), n ? this.enableField(this.form, s, !1) : this.setFieldStatus(this.form, s, e, !0)
        },
        enableHandler: function(t) {
            var e, i, s = !1 === t.disabled && !0 === t.getRealValue(),
                n = this.IsNeedDisableGroup(t.disabled);
            for (e = 0; e < this.enable_fields.length; e++) i = SYNO.SDS.Utils.FieldFind(this.form, this.enable_fields[e]), n ? this.enableField(this.form, i, !1) : this.setFieldStatus(this.form, i, s, !1);
            for (e = 0; e < this.disable_fields.length; e++) i = SYNO.SDS.Utils.FieldFind(this.form, this.disable_fields[e]), n ? this.enableField(this.form, i, !1) : this.setFieldStatus(this.form, i, s, !0)
        }
    }), SYNO.SDS.Utils.DisplayField = function(t, e, i) {
        var s = t.findField(e);
        if (s && s.getEl()) {
            var n = s.getEl().findParent("div[class~=x-form-item]", t.el, !0);
            if (n) {
                var o = n.isDisplayed();
                if (n.setDisplayed(i), !1 === o && !0 === i && "under" == s.msgTarget) {
                    var r = s.getEl().findParent(".x-form-element", 5, !0),
                        a = r.child("div[class~=x-form-invalid-msg]");
                    a && a.setWidth(r.getWidth(!0) - 20)
                }
            }
        }
    }, SYNO.SDS.Utils.getRadioGroup = function(t, e) {
        for (var i = [], s = t.el.query("input[name=" + e + "]"), n = 0; n < s.length; n++) i.push(Ext.getCmp(s[n].id));
        return i
    }, SYNO.SDS.Utils.SymbolMap = {
        "+": "plus",
        "<": "smaller",
        ">": "greater",
        ",": "comma",
        ":": "colon",
        ";": "semicolon",
        "-": "minus",
        "~": "tilt"
    }, SYNO.SDS.Utils.ConvertSingleSymbolToString = function(t, e, i) {
        var s = "\\" + e,
            n = i ? new RegExp(s, "g") : new RegExp(s);
        return t = t.replace(n, _T("common", SYNO.SDS.Utils.SymbolMap[e] + "_str"))
    }, SYNO.SDS.Utils.ConvertSymbolsToString = function(t) {
        var e, i, s = ["+", "<", ">", ",", ":", ";"];
        for (e = 0; e < s.length; e++) i = new RegExp("\\" + s[e], "g"), t = t.replace(i, _T("common", SYNO.SDS.Utils.SymbolMap[s[e]] + "_str"));
        return t
    }, SYNO.SDS.Utils.isBrowserReservedPort = function(t, e) {
        var i = [1, 7, 9, 11, 13, 15, 17, 19, 20, 21, 22, 23, 25, 37, 42, 43, 53, 77, 79, 87, 95, 101, 102, 103, 104, 109, 110, 111, 113, 115, 117, 119, 123, 135, 139, 143, 179, 389, 465, 512, 513, 514, 515, 526, 530, 531, 532, 540, 556, 563, 587, 601, 636, 993, 995, 2049, 3659, 4045, 6e3, 6665, 6666, 6667, 6668, 6669],
            s = 0;
        t > e && (s = t, t = e, e = s);
        for (var n = 0; n < i.length; n++)
            if (t <= i[n] && e >= i[n]) return !0;
        return !1
    }, SYNO.SDS.Utils.isReservedPort = function(t, e, i) {
        var s = [20, 21, 22, 23, 25, 69, 80, 110, 111, 137, 138, 139, 143, 161, 162, 199, 443, 445, 514, 515, 543, 548, 587, 631, 873, 892, 914, 915, 916, 993, 995, 2049, 3260, 3306, 3493, 4662, 4672, 5e3, 5001, 5005, 5006, 5335, 5432, 6281, 7e3, 7001, 9e3, 9002, 9900, 9901, 9997, 9998, 9999, 50001, 50002],
            n = [],
            o = [],
            r = 0;
        switch (e > i && (r = e, e = i, i = r), t) {
            case "ftp":
                o = [21];
                break;
            case "ssh":
                o = [22];
                break;
            case "http":
                o = [80];
                break;
            case "https":
                o = [443];
                break;
            case "www":
                o = [80, 443];
                break;
            case "webman":
            case "dsm":
                o = [5e3, 5001];
                break;
            case "cfs":
                o = [7e3, 7001];
                break;
            case "webdav":
                o = [5005, 5006];
                break;
            case "custsurveillance":
                o = [9900, 9901];
                break;
            case "emule":
                o = [4662, 4672];
                break;
            case "syslog":
                o = [514]
        }
        for (var a = 0; a < s.length; a++) {
            for (var l = !1, c = 0; c < o.length; c++)
                if (s[a] == o[c]) {
                    l = !0;
                    break
                } l || n.push(s[a])
        }
        for (a = 0; a < n.length; a++)
            if (e <= n[a] && i >= n[a]) return !0;
        if ("ftp" != t) {
            var d = parseInt(_D("ftp_pasv_def_min_port", "55536"), 10),
                u = parseInt(_D("ftp_pasv_def_max_port", "55663"), 10);
            if (e <= u && u <= i) return !0;
            if (d <= i && i <= u) return !0
        }
        if ("emule" != t) {
            if (e <= 4662 && 4662 <= i) return !0;
            if (e <= 4672 && 4672 <= i) return !0
        }
        if ("surveillance" != t) {
            if (e <= 55863 && 55863 <= i) return !0;
            if (55736 <= i && i <= 55863) return !0
        }
        if ("custsurveillance" != t) {
            if (e <= 9900 && 9900 <= i) return !0;
            if (e <= 9901 && 9901 <= i) return !0
        }
        if ("cfs" != t) {
            if (e <= 7e3 && 7e3 <= i) return !0;
            if (e <= 7001 && 7001 <= i) return !0
        }
        if ("webdav" != t) {
            if (e <= 5005 && 5005 <= i) return !0;
            if (e <= 5006 && 5006 <= i) return !0
        }
        return e <= 55910 && 55910 <= i || (55900 <= i && i <= 55910 || (e <= 3259 && 3259 <= i || 3240 <= i && i <= 3259))
    }, SYNO.SDS.Utils.getTimeZoneStore = function() {
        if (SYNO.SDS.Utils._timezoneStore) return SYNO.SDS.Utils._timezoneStore;
        var t = SYNO.SDS.Utils.getTimeZoneData(),
            e = [];
        Ext.each(t, function(t) {
            e.push([t.value, t.offset, t.display])
        });
        var i = new Ext.data.SimpleStore({
            id: 0,
            fields: ["value", "offset", "display"],
            data: e
        });
        return SYNO.SDS.Utils._timezoneStore = i, i
    }, SYNO.SDS.Utils.getTimeZoneData = function() {
        if (SYNO.SDS.Utils._timezoneData) return SYNO.SDS.Utils._timezoneData;

        function t(t) {
            var e = "",
                i = Math.floor(Math.abs(t));
            return i < 10 && (e += "0"), e + i.toString()
        }
        var e = [];
        return Ext.each([
            ["Midway", -660],
            ["Hawaii", -600],
            ["Alaska", -540],
            ["Pacific", -480],
            ["Arizona", -420],
            ["Chihuahua", -420],
            ["Mountain", -420],
            ["Central", -360],
            ["Guatemala", -360],
            ["MexicoCity", -360],
            ["Saskatchewan", -360],
            ["Bogota", -300],
            ["EastIndiana", -300],
            ["Eastern", -300],
            ["Atlantic", -240],
            ["Caracas", -240],
            ["La_Paz", -240],
            ["Manaus", -240],
            ["Santiago", -240],
            ["Newfoundland", -210],
            ["Brasilia", -180],
            ["BuenosAires", -180],
            ["Godthab", -180],
            ["Montevideo", -180],
            ["South_Georgia", -120],
            ["Azores", -60],
            ["CapeVerde", -60],
            ["Casablanc", 0],
            ["Dublin", 0],
            ["Monrovia", 0],
            ["Amsterdam", 60],
            ["Belgrade", 60],
            ["Brussels", 60],
            ["Sarajevo", 60],
            ["WAT", 60],
            ["Windhoek", 60],
            ["Amman", 120],
            ["Athens", 120],
            ["Beirut", 120],
            ["CAT", 120],
            ["EET", 120],
            ["Egypt", 120],
            ["Harare", 120],
            ["Helsinki", 120],
            ["Israel", 120],
            ["Baghdad", 180],
            ["Istanbul", 180],
            ["Kuwait", 180],
            ["Minsk", 180],
            ["Moscow", 180],
            ["Nairobi", 180],
            ["Tehran", 210],
            ["Baku", 240],
            ["Muscat", 240],
            ["Tbilisi", 240],
            ["Yerevan", 240],
            ["Kabul", 270],
            ["Ekaterinburg", 300],
            ["Karachi", 300],
            ["Calcutta", 330],
            ["Katmandu", 345],
            ["Almaty", 360],
            ["Dhaka", 360],
            ["Rangoon", 390],
            ["Jakarta", 420],
            ["Krasnoyarsk", 420],
            ["Novosibirsk", 420],
            ["Taipei", 480],
            ["Beijing", 480],
            ["Irkutsk", 480],
            ["Perth", 480],
            ["Singapore", 480],
            ["Ulaanbaatar", 480],
            ["Seoul", 540],
            ["Tokyo", 540],
            ["Yakutsk", 540],
            ["Adelaide", 570],
            ["Darwin", 570],
            ["Brisbane", 600],
            ["Guam", 600],
            ["Melbourne", 600],
            ["Tasmania", 600],
            ["Vladivostok", 600],
            ["Magadan", 660],
            ["Noumea", 660],
            ["Auckland", 720],
            ["Fiji", 720],
            ["Kamchatka", 720],
            ["Kwajalein", 720]
        ], function(i) {
            var s, n = i[1];
            s = 0 === n ? "(GMT+00:00)" : String.format("(GMT{0}{1}:{2})", n > 0 ? "+" : "-", t(n / 60), t(n % 60)), e.push({
                value: i[0],
                offset: i[1],
                display: _T("timezone", i[0]).replace(/\(GMT.{0,6}\)/g, s)
            })
        }), SYNO.SDS.Utils._timezoneData = e, e
    }, SYNO.SDS.Utils.createTimeItemStore = function(t) {
        var e = [],
            i = {
                hour: 24,
                min: 60,
                sec: 60
            };
        if (t in i) {
            for (var s = 0; s < i[t]; s++) e.push([s, String.leftPad(String(s), 2, "0")]);
            return new Ext.data.SimpleStore({
                id: 0,
                fields: ["value", "display"],
                data: e
            })
        }
        return null
    }, SYNO.SDS.Utils.GetLocalizedString = function(t, e) {
        if (!t) return "";
        var i, s, n, o, r = t.split(":", 3);
        return 2 < r.length ? (i = r[0], s = r[1], n = r[2], (o = _TT(i, s, n)) || _T(s, n) || t) : (s = r[0], n = r[1], e && (Ext.isArray(e) || (e = [e]), Ext.each(e, function(t) {
            if (o = _TT(t, s, n), !Ext.isEmpty(o)) return !1
        })), o || _T(s, n) || t)
    }, SYNO.SDS.Utils.CapacityRender = function(t, e) {
        var i = _T("common", "size_mb"),
            s = t;
        s < 0 && (s = 0), s >= 1024 && (s /= 1024, i = _T("common", "size_gb")), s >= 1024 && (s /= 1024, i = _T("common", "size_tb"));
        var n = e || 2;
        return s.toFixed(n) + " " + i
    }, Ext.override(Ext.form.Radio, {
        setValue: function(t) {
            if ("boolean" == typeof t) Ext.form.Radio.superclass.setValue.call(this, t);
            else if (this.rendered) {
                this.getCheckEl().select("input[name=" + this.el.dom.name + "]").each(function(e) {
                    var i = Ext.getCmp(e.dom.id);
                    i.setValue(t === e.dom.value), i.fireEvent("check", i, i.checked)
                }, this)
            }
            return this
        },
        onClick: function() {
            this.el.dom.checked != this.checked && this.setValue(this.el.dom.value)
        }
    }), SYNO.SDS.Utils.Checkbox = Ext.extend(Ext.form.Checkbox, {
        activeCls: "",
        isMouseOn: !1,
        boxEl: null,
        clsStates: {
            check: {
                normal: "check",
                active: "checkActive"
            },
            nocheck: {
                normal: "nocheck",
                active: "nocheckActive"
            }
        },
        initComponent: function() {
            SYNO.SDS.Utils.Checkbox.superclass.initComponent.apply(this, arguments)
        },
        initEvents: function() {
            SYNO.SDS.Utils.Checkbox.superclass.initEvents.call(this), this.boxEl = this.el.next(), this.mon(this, {
                scope: this,
                check: this.onChecked,
                focus: this.onFocus,
                blur: this.onBlur
            }), this.mon(this.container, {
                scope: this,
                mouseenter: this.mouseOn,
                mouseleave: this.mouseOut
            })
        },
        mouseOn: function() {
            this.isMouseOn = !0, this.updateStates(this.isMouseOn)
        },
        mouseOut: function() {
            this.isMouseOn = !1, this.updateStates(this.isMouseOn)
        },
        onBlur: function() {
            this.updateStates(!1)
        },
        onFocus: function() {
            this.updateStates(!0)
        },
        onChecked: function() {
            this.updateStates(this.isMouseOn)
        },
        updateStates: function(t) {
            if (this.boxEl) {
                var e = this.clsStates[this.getValue() ? "check" : "nocheck"][t ? "active" : "normal"];
                this.boxEl.removeClass(this.activeCls), this.boxEl.addClass(e), this.activeCls = e
            }
        }
    }), SYNO.SDS.Utils.SearchField = Ext.extend(SYNO.ux.FleXcroll.ComboBox, {
        constructor: function(t) {
            t.listeners = Ext.applyIf(t.listeners || {}, {
                render: {
                    fn: function(t) {
                        t.trigger.hide(), t.trigger.removeClass("syno-ux-combobox-trigger")
                    }
                }
            }), SYNO.SDS.Utils.SearchField.superclass.constructor.call(this, Ext.apply({
                title: _T("common", "search_results"),
                loadingText: _T("common", "searching"),
                emptyText: _T("user", "search_user"),
                queryParam: "query",
                queryDelay: 500,
                listEmptyText: _T("search", "no_search_result"),
                grow: !0,
                width: 200,
                listWidth: 360,
                maxHeight: 360,
                minChars: 1,
                autoSelect: !1,
                typeAhead: !1,
                editable: !0,
                mode: "remote",
                listAlign: ["tr-br?", [16, 0]],
                ctCls: "syno-textfilter",
                cls: "syno-textfilter-text",
                listClass: "sds-search-result",
                triggerConfig: {
                    tag: "button",
                    "aria-label": _T("common", "clear_input"),
                    cls: "x-form-trigger syno-textfilter-trigger"
                },
                store: new SYNO.API.JsonStore({
                    autoDestroy: !0,
                    appWindow: this.findAppWindow() || !1,
                    api: "SYNO.Core.UISearch",
                    method: "uisearch",
                    version: 1,
                    root: "items",
                    id: "_random",
                    fields: ["id", "title", "owner", "topic", "type", {
                        name: "desc",
                        convert: function(t, e) {
                            return String.format(t, _D("product"))
                        }
                    }],
                    baseParams: {
                        lang: _S("lang"),
                        type: t.type || "all"
                    }
                })
            }, t))
        },
        initEvents: function() {
            SYNO.SDS.Utils.SearchField.superclass.initEvents.apply(this, arguments), this.keyNav.disable(), this.mon(this.el, "click", this.onClick, this), this.mon(this.getStore(), "load", this.onStoreLoad, this), this.mon(this.el, "focus", this.setListAria, this, {
                single: !0
            }), this.enterNav = new Ext.KeyNav(this.el, {
                enter: this.focusResult,
                scope: this
            })
        },
        setListAria: function() {
            this.innerList.set({
                role: "listbox",
                tabindex: 0,
                "aria-label": _T("common", "search_results")
            }), this.setListKeyNav()
        },
        setListKeyNav: function() {
            this.listKeyNav = new Ext.KeyNav(this.innerList, {
                up: function(t) {
                    this.inKeyMode = !0, this.selectPrev()
                },
                down: function(t) {
                    this.isExpanded() ? (this.inKeyMode = !0, this.selectNext()) : this.onTriggerClick()
                },
                enter: function(t) {
                    this.onViewClick(!1)
                },
                esc: function(t) {
                    this.collapse(), this.getAriaEl().focus()
                },
                tab: function(t) {
                    this.collapse(), this.getAriaEl().focus()
                },
                scope: this,
                doRelay: function(t, e, i) {
                    if ("down" == i || this.scope.isExpanded()) {
                        var s = Ext.KeyNav.prototype.doRelay.apply(this, arguments);
                        return (Ext.isIE9 && Ext.isStrict || !Ext.isIE) && Ext.EventManager.useKeydown && this.scope.fireKey(t), s
                    }
                    return !0
                },
                forceKeyDown: !0,
                defaultEventAction: "stopEvent"
            })
        },
        focusResult: function() {
            0 === this.getStore().getCount() ? (this.innerList.set({
                tabindex: 0,
                "aria-label": _T("search", "no_search_result")
            }), this.innerList.dom.removeAttribute("role")) : this.innerList.set({
                role: "listbox",
                tabindex: 0,
                "aria-label": _T("common", "search_results")
            }), this.innerList.focus()
        },
        onClick: function() {
            this.getValue().length >= this.minChars && (this.hasFocus || (this.blur(), this.focus()), this.expand())
        },
        onStoreLoad: function(t) {
            t.filterBy(function(t) {
                var e = "";
                switch (t.get("type")) {
                    case "app":
                        if (e = SYNO.SDS.Utils.ParseSearchID(t.get("id")).className, SYNO.SDS.Utils.isHiddenControlPanelModule(t.get("id"))) return !1;
                        break;
                    case "help":
                        if (e = "SYNO.SDS.HelpBrowser.Application", SYNO.SDS.isNVR && t.get("id").indexOf("SYNO.SDS.Tutorial.Application") >= 0) return !1;
                        break;
                    default:
                        return !0
                }
                return SYNO.SDS.StatusNotifier.isAppEnabled(e)
            })
        },
        onSelect: function(t, e) {
            !1 !== this.fireEvent("beforeselect", this, t, e) && (this.collapse(), this.fireEvent("select", this, t, e))
        },
        select: function(t, e) {
            if (this.selectedIndex = t, this.view.select(t), !1 !== e) {
                var i = this.view.getNode(t);
                i && this.innerList.scrollChildIntoView(i, !1)
            }
            var s = this.view.getSelectedNodes()[0];
            this.innerList.set({
                "aria-activedescendant": s.id
            })
        },
        onViewOver: function(t, e) {
            if (!this.inKeyMode) {
                var i = this.view.findItemFromChild(e);
                if (i) {
                    var s = this.view.indexOf(i);
                    this.select(s, !1)
                } else this.view.clearSelections()
            }
        },
        onViewClick: function(t) {
            var e = this.view.getSelectedIndexes()[0],
                i = this.store.getAt(e);
            i && (this.onSelect(i, e), this.view.clearSelections()), !1 !== t && this.el.focus()
        },
        onKeyUp: function(t) {
            var e = t.getKey(),
                i = this.getValue();
            this.trigger.setVisible(!!i), i.length < this.minChars ? this.collapse() : i === this.lastQuery && t.ENTER === e ? this.expand() : !1 === this.editable || !0 === this.readOnly || t.ENTER !== e && t.BACKSPACE !== e && t.DELETE !== e && t.isSpecialKey() || (this.lastKey = e, this.dqTask.delay(this.queryDelay))
        },
        preFocus: function() {
            var t = this.el;
            this.emptyText && (t.dom.value === this.emptyText && this.el.hasClass(this.emptyClass) && this.setRawValue(""), t.removeClass(this.emptyClass)), this.selectOnFocus && t.dom.select()
        },
        initQuery: function() {
            this.view.clearSelections(), this.doQuery(this.getRawValue())
        },
        getRawValue: function() {
            var t = this.rendered ? this.el.getValue() : Ext.value(this.value, "");
            return t === this.emptyText && this.el.hasClass(this.emptyClass) && (t = ""), t
        },
        getValue: function() {
            if (!this.rendered) return this.value;
            var t = this.el.getValue();
            return (t === this.emptyText && this.el.hasClass(this.emptyClass) || void 0 === t) && (t = ""), t
        },
        onTriggerClick: function() {
            this.getValue() && (this.setValue(""), this.trigger.hide(), this.collapse()), this.focus(!1, 200)
        }
    }), SYNO.SDS.Utils.InnerGroupingView = Ext.extend(Ext.grid.GroupingView, {
        onLayout: function() {
            SYNO.SDS.Utils.InnerGroupingView.superclass.onLayout.call(this), Ext.grid.GroupingView.superclass.onLayout.call(this);
            var t = this.getGroups();
            t && Ext.each(t, function(t) {
                var e = Ext.get(t.id).child(".x-grid-group-hd");
                e && (e.on("mouseover", function() {
                    e.addClass("syno-ux-grid-group-hd-over")
                }), e.on("mouseout", function() {
                    e.removeClass("syno-ux-grid-group-hd-over")
                }), e.on("mousedown", function() {
                    e.addClass("syno-ux-grid-group-hd-click")
                }), e.on("mouseup", function() {
                    e.removeClass("syno-ux-grid-group-hd-click")
                }))
            })
        }
    }), SYNO.SDS.DefineGridView("SYNO.SDS.Utils.GroupingView", "SYNO.SDS.Utils.InnerGroupingView"), Ext.override(SYNO.SDS.Utils.GroupingView, {
        toggleGroup: function(t, e) {
            var i = this,
                s = Ext.get(t),
                n = Ext.util.Format.htmlEncode(s.id);
            if (e = Ext.isDefined(e) ? e : s.hasClass("x-grid-group-collapsed"), i.state[n] !== e) {
                !1 !== i.cancelEditOnToggle && i.grid.stopEditing(!0), i.state[n] = e;
                var o = s.child(".x-grid-group-body");
                o ? o[e ? "slideIn" : "slideOut"]("t", {
                    duration: .25,
                    block: !0,
                    scope: i,
                    callback: this.afterSlideEffect.createDelegate(this, [t, e])
                }) : (s[e ? "removeClass" : "addClass"]("x-grid-group-collapsed"), this.onLayout.call(this), this.updateScroller())
            }
        },
        afterSlideEffect: function(t, e) {
            var i = Ext.get(t),
                s = i.child(".x-grid-group-body");
            s.removeClass("x-grid3-row-over"), i[e ? "removeClass" : "addClass"]("x-grid-group-collapsed"), s[e ? "show" : "hide"]("display"), this.onLayout.call(this), this.updateScroller()
        }
    }), SYNO.SDS.Utils.StateGridPanel = Ext.extend(SYNO.ux.GridPanel, {
        constructor: function(t) {
            var e = {};
            if (t.stateId && (this.stateId = t.stateId, e = {
                    stateEvents: ["columnmove", "columnresize", "sortchange"],
                    stateful: !0,
                    saveState: function() {
                        var t = this.getState();
                        this.findAppWindow() && this.findAppWindow().appInstance && this.findAppWindow().appInstance.setUserSettings(this.stateId, t)
                    }.createDelegate(this)
                }), Ext.apply(e, t), SYNO.SDS.Utils.StateGridPanel.superclass.constructor.call(this, e), t.stateId) {
                var i = function(t) {
                    if (this.findAppWindow() && this.findAppWindow().appInstance) {
                        var e = this.findAppWindow().appInstance.getUserSettings(this.stateId);
                        if (e) try {
                            t.applyState(e)
                        } catch (t) {}
                    }
                };
                this.mon(this, "beforerender", i, this, this), this.mon(this, "reconfigure", i, this, this)
            }
        }
    }), SYNO.SDS.Utils.GridView = Ext.extend(Ext.grid.GridView, {
        onLayout: function() {}
    }), SYNO.SDS.Utils.ParseSearchID = function(t) {
        var e = t.split("?", 2),
            i = {
                className: "",
                params: {}
            };
        return i.className = e[0], 2 === e.length && (i.params = Ext.urlDecode(e[1])), i
    }, SYNO.SDS.Utils.isControlPanelModule = function(t, e) {
        return "SYNO.SDS.ControlPanel.Instance" === e && "SYNO.SDS.ControlPanel.Instance" !== t && !SYNO.SDS.Utils.isHiddenControlPanelModule(t)
    }, SYNO.SDS.Utils.isHiddenControlPanelModule = function(t) {
        var e = SYNO.SDS.Utils.ParseSearchID(t);
        return !!("SYNO.SDS.ControlPanel.Instance" === e.className && e.params && e.params.fn && Ext.isDefined(SYNO.SDS.AppPrivilege[e.params.fn]) && !1 === SYNO.SDS.AppPrivilege[e.params.fn])
    }, SYNO.SDS.Utils.GetAppIcon = function(t, e) {
        if (t in SYNO.SDS.Config.FnMap) {
            var i = SYNO.SDS.Config.FnMap[t].config;
            return SYNO.SDS.UIFeatures.IconSizeManager.getIconPath(i.jsBaseURL + "/" + i.icon, e)
        }
        return ""
    }, SYNO.SDS.Utils.GetAppTitle = function(t) {
        if (t in SYNO.SDS.Config.FnMap) {
            var e = SYNO.SDS.Config.FnMap[t].config;
            return SYNO.SDS.Utils.GetLocalizedString(e.title, t)
        }
        return ""
    }, SYNO.SDS.Utils.CheckWebapiError = function(t) {
        var e, i, s;
        try {
            if ((e = Ext.isDefined(t.responseText) ? Ext.decode(t.responseText) : t).success) return !1;
            i = e.error.code || 100, s = SYNO.API.Errors.common[i]
        } catch (t) {}
        return s || (i = 100, s = SYNO.API.Errors.common[i]), window.alert(s), i >= 105 && (window.onbeforeunload = null, window.location.href = "/"), !0
    }, Ext.define("SYNO.SDS.Utils.Logout", {
        statics: {
            logoutTriggered: !1,
            reserveQueryString: !1,
            action: function(t, e, i, s) {
                this.logoutTriggered || (!0 === i && (SYNO.SDS.Desktop && SYNO.SDS.Desktop.hide(), Ext.getBody().mask().addClass("desktop-timeout-mask")), this.logout(t, e, s))
            },
            showMessage: function(t) {
                return new Promise(function(e, i) {
                    Ext.isDefined(t) ? (Ext.getBody().unmask(), Ext.getClassByName("SYNO.SDS.StatusNotifier") && SYNO.SDS.StatusNotifier.fireEvent("halt"), SYNO.SDS.Utils.MessageBox.CreateMsgBox().alert("", t, e, this)) : e()
                })
            },
            logout: function(t, e, i) {
                var s = this,
                    n = function() {
                        !0 === t && (window.onbeforeunload = null), "azure_sso" === Ext.util.Cookies.get("login_type") && SYNO.SDS.AzureSSOUtils.logout(), Ext.isSafari && Ext.isMac ? s.redirect(i).defer(300, s) : s.redirect(i)
                    };
                s.logoutTriggered = !0, s.showMessage(e).then(n.bind(s), n.bind(s)).catch(n.bind(s))
            },
            setConfig: function(t) {
                Ext.apply(this, t)
            },
            redirect: function(t) {
                var e = function() {
                        if (this.reserveQueryString) window.location.reload(!0);
                        else {
                            var t = window.location.href;
                            window.location.href = window.location.pathname, t === window.location.href && window.setTimeout(function() {
                                window.location.reload(!0)
                            }, 100)
                        }
                    },
                    i = function() {
                        var t = new XMLHttpRequest;
                        t.onreadystatechange = function() {
                            4 === t.readyState && e()
                        }, t.open("GET", "webapi/entry.cgi?api=SYNO.API.Auth&version=7&method=logout", !0), t.send()
                    };
                if (!1 === t) {
                    var s = new XMLHttpRequest;
                    s.onreadystatechange = function() {
                        if (4 === s.readyState) {
                            if (200 === s.status)
                                if (!0 === JSON.parse(s.response).success) return void e();
                            i()
                        }
                    }, s.open("POST", "webman/login.cgi", !0), s.send()
                } else i()
            }
        }
    }), SYNO.SDS.Utils.CheckServerError = function(t) {
        var e, i, s, n;
        if (!t || !t.getResponseHeader) return !1;
        try {
            e = t.getResponseHeader("x-request-error") || t.getResponseHeader("X-Request-Error")
        } catch (i) {
            e = t.getResponseHeader["x-request-error"] || t.getResponseHeader["X-Request-Error"]
        }
        try {
            s = t.getResponseHeader("X-SYNO-SOURCE-ID")
        } catch (t) {
            s = void 0
        }
        if (n = !0, e && Ext.isEmpty(s)) {
            switch (e = Ext.util.Format.trim(e)) {
                case "timeout":
                    i = _JSLIBSTR("uicommon", "error_timeout"), n = !1;
                    break;
                case "unauth":
                    i = _JSLIBSTR("uicommon", "error_unauth"), n = !1;
                    break;
                case "noprivilege":
                    i = _JSLIBSTR("uicommon", "error_noprivilege");
                    break;
                case "relogin":
                    i = _JSLIBSTR("uicommon", "error_relogin");
                    break;
                case "errorip":
                    i = void 0;
                    break;
                default:
                    i = _JSLIBSTR("uicommon", "error_system")
            }
            return SYNO.SDS.Utils.Logout.action(!0, i, !0, n), !0
        }
        return !1
    }, SYNO.SDS.Utils.CheckServerErrorData = function(t) {
        var e, i, s = null;
        if (!Ext.isDefined(t)) return !1;
        if (e = t.section, i = t.key, "login" === e) switch (i) {
            case "error_timeout":
            case "error_noprivilege":
            case "error_interrupt":
                s = _JSLIBSTR("uicommon", i);
                break;
            default:
                s = _JSLIBSTR("uicommon", "error_system")
        } else "error" === e && "error_testjoin" === i && (s = _T("error", "error_testjoin"));
        return !!s && (alert(s), window.onbeforeunload = null, window.location.href = "/", !0)
    }, SYNO.SDS.Utils.AddTip = function(t, e, i) {
        var s = document.createElement("a"),
            n = document.createElement("img"),
            o = "vertical-align:bottom; position: relative;",
            r = Ext.getCmp(t.id),
            a = Ext.id(),
            l = SYNO.SDS.UIFeatures.test("isRetina") ? SYNO.SDS.ThemeProvider.getPath("synoSDSjslib/images/default/2x/components/icon_information_mini.png") : SYNO.SDS.ThemeProvider.getPath("synoSDSjslib/images/default/1x/components/icon_information_mini.png");
        if (n.setAttribute("src", l), n.setAttribute("width", "24px"), n.setAttribute("height", "24px"), n.setAttribute("draggable", "false"), r && r.defaultTriggerWidth && (o += " left:" + r.defaultTriggerWidth + "px;"), n.setAttribute("style", o), n.setAttribute("ext:qtip", e), !1 === i && n.setAttribute("ext:hide", !1), n.setAttribute("alt", e), n.setAttribute("id", a), s.appendChild(n), r instanceof SYNO.ux.DisplayField) t.appendChild(s);
        else if (r instanceof SYNO.ux.Button && Ext.getDom(t).nextSibling) {
            var c = t.dom.getAttribute("style") + " margin-right:0px !important;",
                d = Ext.getDom(t);
            d.setAttribute("style", c), s.setAttribute("style", "margin-right:6px !important;"), d.parentNode.insertBefore(s, d.nextSibling)
        } else r instanceof SYNO.ux.TextArea ? Ext.getDom(t).parentNode.parentNode.appendChild(s) : Ext.getDom(t).parentNode.appendChild(s);
        return r && r.el && r.el.set({
            "aria-describedby": r.el.dom.getAttribute("aria-describedby") + " " + a
        }), s
    }, SYNO.SDS.Utils.CheckStrongPassword = Ext.extend(Object, {
        passwordPolicy: null,
        isFakePasswd: function(t, e) {
            if ("12345678" === t && "87654321" === e) return !0
        },
        getForm: null,
        getUserAcc: null,
        getUserDesc: null,
        getPasswd: null,
        getPasswdConfirm: null,
        getStartValidate: null,
        initPasswordChecker: function(t) {
            Ext.each(["getForm", "getUserAcc", "getUserDesc", "getPasswd", "getPasswdConfirm", "getStartValidate"], function(e) {
                this[e] = t[e]
            }, this)
        },
        setValue: function(t, e) {
            this.getForm().findField(this[t]).setValue(e)
        },
        getInfo: function(t) {
            return Ext.isFunction(this[t]) ? this[t].call(this.scope || this) : Ext.isString(this[t]) ? Ext.isFunction(this.getForm) ? this.getForm().findField(this[t]).getValue() : this[t] : void 0
        },
        isStrongValidator: function() {
            var t = this.getInfo("getUserAcc"),
                e = this.getInfo("getUserDesc"),
                i = this.getInfo("getPasswd"),
                s = this.getInfo("getPasswdConfirm");
            return !1 === this.getStartValidate() || (!0 === this.isFakePasswd(i, s) || this.isPasswordValid(i, t, e))
        },
        isPasswordValid: function(t, e, i) {
            var s = !1,
                n = !1,
                o = {
                    mixed_case: !1,
                    included_special_char: !1,
                    included_numeric_char: !1,
                    exclude_username: !1,
                    min_length_enable: !1
                },
                r = [],
                a = 0,
                l = "",
                c = Ext.util.Format.lowercase(t),
                d = Ext.util.Format.lowercase(e),
                u = Ext.util.Format.lowercase(i);
            if ("admin" === d && t.length < 6) return String.format(_T("passwd", "min_length_default"), "admin", 6);
            if (!1 === this.passwordPolicy.strong_password_enable) return !0;
            for ("" !== d && -1 !== c.indexOf(d) || "" !== u && -1 !== c.indexOf(u) || (o.exclude_username = !0), a = 0; a < t.length; a++) l = t.charAt(a), -1 !== "abcdefghijklmnopqrstuvwxyz".indexOf(l) ? s = !0 : -1 !== "ABCDEFGHIJKLMNOPQRSTUVWXYZ".indexOf(l) ? n = !0 : -1 !== "~`!@#$%^&*()-_+={[}]|\\:;\"'<,>.?/ ".indexOf(l) ? o.included_special_char = !0 : -1 !== "1234567890".indexOf(l) && (o.included_numeric_char = !0);
            for (a in !0 === s && !0 === n && (o.mixed_case = !0), t.length >= this.passwordPolicy.min_length && (o.min_length_enable = !0), o) !0 === this.passwordPolicy[a] && !1 === o[a] && ("min_length_enable" === a ? r.push(_T("passwd", a) + " " + this.passwordPolicy.min_length) : r.push(_T("passwd", a)));
            return 0 === r.length || _T("passwd", "passwd_strength_warn") + r.join(", ") + _T("common", "period")
        }
    }), SYNO.SDS.Utils.ActionGroup = Ext.extend(Object, {
        constructor: function(t) {
            this.list = [], this.dict = {}, Ext.isObject(t) ? (this.dict = t, Ext.iterate(t, function(t, e, i) {
                this.list.push(e)
            }, this)) : Ext.isArray(t) ? (this.list = t, Ext.each(t, function(t, e, i) {
                this.dict[t.itemId] = t
            }, this)) : SYNO.Debug.error("wrong parameters for ActionGroup")
        },
        enableAll: function() {
            Ext.each(this.list, function(t, e, i) {
                t.enable()
            }, this)
        },
        disableAll: function() {
            Ext.each(this.list, function(t, e, i) {
                t.disable()
            }, this)
        },
        enable: function(t) {
            this.dict[t] && this.dict[t].enable()
        },
        disable: function(t) {
            this.dict[t] && this.dict[t].disable()
        },
        add: function(t) {
            t && t.itemId ? (this.dict[t.itemId] = t, this.list.push(t)) : SYNO.Debug.error("Invalid parameter for ActionGroup.add()")
        },
        get: function(t) {
            return this.dict[t]
        },
        getArray: function() {
            return this.list
        },
        showAll: function() {
            Ext.each(this.list, function(t, e, i) {
                t.show()
            }, this)
        },
        hideAll: function() {
            Ext.each(this.list, function(t, e, i) {
                t.hide()
            }, this)
        }
    }), SYNO.SDS.Utils.isValidExtension = function(t, e) {
        var i, s = t.toLowerCase();
        return !(!t.length || !e.length) && (-1 != (i = s.lastIndexOf(e)) && s.length == i + e.length)
    }, SYNO.SDS.Utils._Language = {
        ENU: "enu",
        FRE: "fre",
        GER: "ger",
        ITA: "ita",
        SPN: "spn",
        CHT: "cht",
        CHS: "chs",
        JPN: "jpn",
        KRN: "krn",
        THA: "tha",
        RUS: "rus",
        NLD: "nld",
        CSY: "csy",
        PLK: "plk",
        DAN: "dan",
        SVE: "sve",
        HUN: "hun",
        TRK: "trk",
        NOR: "nor",
        PTG: "ptg",
        PTB: "ptb"
    }, SYNO.SDS.Utils.Language = function() {
        var t, e = {},
            i = "",
            s = function(t, e, i) {
                Ext.isIE8 ? t[e] = i : Object.defineProperty(t, e, {
                    value: i,
                    enumerable: !0
                })
            };
        for (var n in t = {
                GetDefaultHelpLanguage: function() {
                    return SYNO.SDS.Utils._Language.ENU
                },
                GetSupportedLanguage: function() {
                    return e
                }
            }, SYNO.SDS.Utils._Language) SYNO.SDS.Utils._Language.hasOwnProperty(n) && (s(t, n, i = SYNO.SDS.Utils._Language[n]), s(e, i, _T("common", "language_" + i)));
        return t
    }(), SYNO.SDS.Utils.getHelpLanguage = function(t) {
        var e = [SYNO.SDS.Utils.Language.DAN, SYNO.SDS.Utils.Language.SVE, SYNO.SDS.Utils.Language.HUN, SYNO.SDS.Utils.Language.THA, SYNO.SDS.Utils.Language.TRK, SYNO.SDS.Utils.Language.NOR, SYNO.SDS.Utils.Language.PTG, SYNO.SDS.Utils.Language.PTB];
        return t = t || _S("lang"), -1 !== e.indexOf(t) ? SYNO.SDS.Utils.Language.GetDefaultHelpLanguage() : SYNO.SDS.Utils.Language.GetSupportedLanguage()[t] ? t : SYNO.SDS.Utils.Language.GetDefaultHelpLanguage()
    }, SYNO.SDS.Utils.getSupportedLanguage = function(t) {
        var e = SYNO.SDS.Utils.Language.GetSupportedLanguage(),
            i = [],
            s = 0;
        for (var n in e) e.hasOwnProperty(n) && (i[s++] = [n, e[n]]);
        return i = i.sort(function(t, e) {
            return t[1] > e[1] ? 1 : t[1] < e[1] ? -1 : 0
        }), t && i.unshift(["def", _T("common", "language_def")]), i
    }, SYNO.SDS.Utils.getSupportedLanguageCodepage = function(t) {
        var e = {
                enu: _T("common", "language_enu"),
                fre: _T("common", "language_fre"),
                ger: _T("common", "language_ger"),
                gre: _T("common", "language_gre"),
                heb: _T("common", "language_heb"),
                tha: _T("common", "language_tha"),
                ita: _T("common", "language_ita"),
                spn: _T("common", "language_spn"),
                cht: _T("common", "language_cht"),
                chs: _T("common", "language_chs"),
                jpn: _T("common", "language_jpn"),
                krn: _T("common", "language_krn"),
                ptb: _T("common", "language_ptb"),
                rus: _T("common", "language_rus"),
                dan: _T("common", "language_dan"),
                nor: _T("common", "language_nor"),
                sve: _T("common", "language_sve"),
                nld: _T("common", "language_nld"),
                plk: _T("common", "language_plk"),
                ptg: _T("common", "language_ptg"),
                hun: _T("common", "language_hun"),
                trk: _T("common", "language_trk"),
                csy: _T("common", "language_csy"),
                ara: _T("common", "language_ara")
            },
            i = [],
            s = 0;
        for (var n in e) e.hasOwnProperty(n) && (i[s++] = [n, e[n]]);
        return i = i.sort(function(t, e) {
            return t[1] > e[1] ? 1 : t[1] < e[1] ? -1 : 0
        }), t && i.unshift(["def", _T("common", "language_def")]), i
    }, SYNO.SDS.Utils.utfencode = function(t) {
        var e, i, s = "";
        for (t = t.replace(/\r\n/g, "\n"), e = 0; e < t.length; e++)(i = t.charCodeAt(e)) < 128 ? s += String.fromCharCode(i) : i > 127 && i < 2048 ? (s += String.fromCharCode(i >> 6 | 192), s += String.fromCharCode(63 & i | 128)) : (s += String.fromCharCode(i >> 12 | 224), s += String.fromCharCode(i >> 6 & 63 | 128), s += String.fromCharCode(63 & i | 128));
        return s
    }, SYNO.SDS.Utils.bin2hex = function(t) {
        var e, i, s = [];
        for (i = (t = SYNO.SDS.Utils.utfencode(t) + "").length, e = 0; e < i; e++) s[e] = t.charCodeAt(e).toString(16).replace(/^([\da-f])$/, "0$1");
        return s.join("")
    }, SYNO.SDS.Utils.loadUIStrings = function(t, e, i) {
        var s = ["webapi/entry.cgi?api=SYNO.Core.Desktop.JSUIString&version=1&method=getjs&lang=" + t, "webapi/entry.cgi?api=SYNO.Core.Desktop.UIString&version=1&method=getjs&lang=" + t],
            n = 0;

        function o(t) {
            ++n >= s.length && i()
        }

        function r() {
            "complete" !== this.readyState && "loaded" !== this.readyState || this.onready()
        }
        if ("def" !== t && t !== _S("sys_lang")) {
            var a = document.getElementsByTagName("head")[0];
            Ext.each(s, function(t) {
                var i = t;
                i = Ext.urlAppend(i, "v=" + e), Ext.isDefined(SYNO.SDS.JSDebug) && (i = Ext.urlAppend(i, "_dc=" + (new Date).getTime()));
                var s = document.createElement("script");
                s.type = "text/javascript", Ext.isIE ? (s.onready = o.createCallback(t), s.onreadystatechange = r) : s.onload = o.createCallback(t), s.src = i, a.appendChild(s)
            })
        } else i()
    }, SYNO.SDS.Utils.addFavIconLink = function(t, e, i) {
        var s, n = document.getElementsByTagName("link"),
            o = document.createElement("link");
        o.rel = "icon", o.href = t, o.setAttribute("sizes", i), e && (o.type = e);
        for (var r = document.head || document.getElementsByTagName("head")[0], a = n.length - 1; a >= 0; a--) n[a] && "icon" === n[a].getAttribute("rel") && ((s = n[a].getAttribute("sizes")) && i !== s || r.removeChild(n[a]));
        r.appendChild(o)
    }, SYNO.SDS.Utils.listAllowAltPortApp = function() {
        var t = SYNO.SDS.Config.FnMap,
            e = [];
        return Ext.iterate(t, function(t, i, s) {
            !i.config || "app" !== i.config.type && "url" !== i.config.type || !0 === i.config.allowAltPort && e.push(t)
        }), e
    }, SYNO.SDS.Utils.IconBadge = Ext.extend(Object, {
        constructor: function() {
            this.container = Ext.DomHelper.createDom({
                tag: "div",
                cls: "sds-expose-desc-ct"
            }), this.el = Ext.get(this.container), this.icon = Ext.DomHelper.createDom({
                tag: "img",
                cls: "sds-expose-desc-img",
                style: String.format("width: {0}px", SYNO.SDS.UIFeatures.IconSizeManager.Header)
            }), this.title = Ext.DomHelper.createDom({
                tag: "div",
                cls: "sds-expose-desc-text"
            }), this.el.appendChild(this.icon), this.el.appendChild(this.title), Ext.get(document.body).appendChild(this.container)
        },
        setIconText: function(t, e) {
            this.icon.src = t, this.title.innerHTML = e
        },
        setXY: function(t, e) {
            this.el.setLeft(t), this.el.setTop(e)
        }
    }), SYNO.SDS.Utils.isCJKLang = function() {
        switch (SYNO.SDS.Session.lang) {
            case "cht":
            case "chs":
            case "jpn":
            case "krn":
                return !0;
            default:
                return !1
        }
    }, SYNO.SDS.Utils.is3rdPartyApp = function(t) {
        var e = SYNO.SDS.Config.FnMap[t];
        return !e || 0 === e.jsFile.indexOf("webman/3rdparty/")
    }, SYNO.SDS.Utils.clone = function(t) {
        if (!t || "object" !== _typeof(t)) return t;
        if ("function" == typeof t.clone) return t.clone();
        var e, i, s = "[object Array]" === Object.prototype.toString.call(t) ? [] : {};
        for (e in t) t.hasOwnProperty(e) && ((i = t[e]) && "object" === _typeof(i) ? s[e] = SYNO.SDS.Utils.clone(i) : s[e] = i);
        return s
    }, SYNO.SDS.Utils.IsCJK = function(t) {
        if (!t) return !1;
        for (var e, i = function(t) {
                return /^[\u0800-\u4e00]/.test(t)
            }, s = function(t) {
                return /^[\u3130-\u318F]|^[\uAC00-\uD7AF]/.test(t)
            }, n = 0; n < t.length; n++)
            if (" " !== (e = t[n]) && (void 0 === e || !/^[\u4E00-\u9FA5]|^[\uFE30-\uFFA0]/.test(e) && !i(e) && !s(e))) return !1;
        return !0
    }, SYNO.SDS.Utils.SelectableCLS = "allowDefCtxMenu selectabletext", SYNO.SDS.Utils.AutoResizeComboBox = Ext.extend(Ext.form.ComboBox, {
        expand: function() {
            var t = this;
            SYNO.SDS.Utils.AutoResizeComboBox.superclass.expand.call(t), !0 === t.comboBoxGrow && t.autoResizeList(t.getWidth(), t.calcWidthFunc)
        },
        doResize: function(t) {
            Ext.isDefined(this.listWidth) || !0 !== this.comboBoxGrow || this.autoResizeList(t, this.calcWidthFunc)
        },
        autoResizeList: function(t, e) {
            var i = this,
                s = "",
                n = null,
                o = i.getStore();
            if (o) {
                o.each(function(t) {
                    s.length < t.data[i.displayField].length && (s = t.data[i.displayField], n = t)
                });
                var r = Ext.util.TextMetrics.createInstance(i.getEl()),
                    a = document.createElement("div");
                a.appendChild(document.createTextNode(s)), s = a.innerHTML, Ext.removeNode(a), a = null, s += "&#160;";
                var l = Math.min(i.comboBoxGrowMax || Number.MAX_VALUE, Math.max((e && n ? e(n, r.getWidth(s)) : r.getWidth(s)) + 10, t || 0));
                i.list.setWidth(l), i.innerList.setWidth(l - i.list.getFrameWidth("lr"))
            }
        }
    }), SYNO.SDS.Utils.IsAllowRelay = function(t) {
        var e, i, s;
        return !!Ext.isObject(t) && (e = Ext.getClassByName("SYNO.SDS.AdminCenter.MainWindow"), i = Ext.getClassByName("SYNO.SDS.ResourceMonitor.App"), !(!(!Ext.isEmpty(e) && t instanceof e || !Ext.isEmpty(i) && t instanceof i || !0 == (s = t, !!(!0 === s._relayObject && Ext.isFunction(s.findAppWindow) && Ext.isObject(s.openConfig) && Ext.isFunction(s.hasOpenConfig) && Ext.isFunction(s.getOpenConfig) && Ext.isFunction(s.setOpenConfig)))) || !t.hasOpenConfig("cms_id")))
    }, SYNO.SDS.Utils.IFrame = {
        createIFrame: function(t, e) {
            var i = SYNO.SDS.Utils.IFrame.createIFrame.iframeId || Ext.id(),
                s = t.getElementById(i),
                n = s || t.createElement("iframe");
            return SYNO.SDS.Utils.IFrame.createIFrame.iframeId = i, Ext.isChrome || n.setAttribute("src", ""), n.setAttribute("id", i), n.setAttribute("name", i), e && n.setAttribute("src", e), n.setAttribute("frameBorder", "0"), n.setAttribute("style", "border:0px none;width:0;height:0;position:absolute;top:-100000px"), s || t.body.appendChild(n), n
        },
        cleanIframe: function(t, e) {
            try {
                Ext.EventManager.removeAll(e), Ext.destroy(e), t.body.removeChild(e), e = void 0
            } catch (t) {}
        },
        getWebAPIResp: function(t) {
            var e;
            try {
                e = Ext.decode(t.contentDocument.body.firstChild.innerHTML), Ext.isEmpty(e.success) && (e = void 0)
            } catch (t) {
                e = void 0
            }
            return e
        },
        request: function(t, e, i, s, n, o) {
            var r, a, l = document,
                c = SYNO.SDS.Utils.IFrame.createIFrame(l, s ? Ext.SSL_SECURE_URL : o ? t : Ext.urlAppend(t)),
                d = Ext.isIE ? c.contentWindow.document : c.contentDocument || window.frames[c.id].document;
            if (n = Ext.isNumber(n) ? n : 12e4, r = setTimeout(function() {
                    Ext.isFunction(e) && e.call(i || this, "timeout", c), SYNO.SDS.Utils.IFrame.cleanIframe.defer(100, this, [l, c])
                }.createDelegate(this), n), s) {
                for (var u in (a = document.createElement("form")).setAttribute("name", "dlform"), a.setAttribute("action", o ? t : Ext.urlAppend(t)), a.setAttribute("method", "POST"), s)
                    if (s.hasOwnProperty(u)) {
                        var h = s[u];
                        a.appendChild(SYNO.SDS.Utils.IFrame.createHiddenInput(u, h))
                    } d.body.appendChild(a)
            }
            return Ext.EventManager.on(c, "load", function() {
                var t;
                Ext.isEmpty(r) || clearTimeout(r), Ext.isFunction(e) && (t = this.getWebAPIResp(c), Ext.isObject(t) ? e.call(i || this, "load", c, t.success, t.success ? t.data : t.error) : e.call(i || this, "load", c)), SYNO.SDS.Utils.IFrame.cleanIframe.defer(100, this, [l, c])
            }, this, {
                single: !0
            }), Ext.EventManager.on(c, "error", function() {
                Ext.isEmpty(r) || clearTimeout(r), Ext.isFunction(e) && e.call(i || this, "error", c), SYNO.SDS.Utils.IFrame.cleanIframe.defer(100, this, [l, c])
            }, this, {
                single: !0
            }), s && (a.submit(), Ext.removeNode(a)), c
        },
        requestWebAPI: function(t) {
            var e, i, s, n, o, r;
            if (Ext.isObject(t.webapi) && SYNO.ux.Utils.checkApiObjValid(t.webapi)) {
                if (n = t.webapi, s = Ext.isObject(t.appWindow) ? t.appWindow.findAppWindow() : t.appWindow, SYNO.SDS.Utils.IsAllowRelay(s) && s.hasOpenConfig("cms_id")) i = {
                    api: "SYNO.CMS.DS",
                    version: 1,
                    method: "relay"
                }, o = {
                    id: s.getOpenConfig("cms_id"),
                    timeout: s.getOpenConfig("cms_timeout") || 120,
                    webapi: Ext.apply({
                        api: n.api,
                        version: n.version,
                        method: n.method
                    }, n.params)
                }, r = n.encryption ? ["webapi"] : null;
                else {
                    if (!(!1 === s || s instanceof SYNO.SDS.AppWindow)) return SYNO.Debug.error("appWindow is invalid!"), SYNO.Debug.debug("appWindow can be found by Ext.Component.findAppWindow"), void SYNO.Debug.debug("ex: this.findAppWindow() or config.module.appWin.findAppWindow()");
                    i = {
                        api: n.api,
                        method: n.method,
                        version: n.version
                    }, o = n.params, r = n.encryption
                }
                return r ? (e = SYNO.API.currentManager.getBaseURL(i, !1, t.filename), o = this.encodeParams(i.api, o), this.sendEncrypedRequest({
                    reqObj: {
                        url: e,
                        params: o
                    },
                    reqEnc: r,
                    config: t
                })) : (i.params = o, e = SYNO.API.currentManager.getBaseURL(i, !1, t.filename), this.request(e, t.callback, t.scope, null, t.timeout, t.skipAppendSynoToken))
            }
            SYNO.Debug.error("webapi is invalid")
        },
        sendEncrypedRequest: function(t) {
            return SYNO.API.currentManager.requestAPI(Ext.apply({
                api: "SYNO.API.Encryption",
                method: "getinfo",
                version: 1,
                params: {
                    format: "module"
                },
                callback: this.onEncryptRequestAPI,
                scope: this
            }, t))
        },
        onEncryptRequestAPI: function(t, e, i, s) {
            var n, o, r = s.config,
                a = s.reqObj,
                l = s.reqEnc;
            if (t) {
                for (SYNO.Encryption.CipherKey = e.cipherkey, SYNO.Encryption.RSAModulus = e.public_key, SYNO.Encryption.CipherToken = e.ciphertoken, SYNO.Encryption.TimeBias = e.server_time - Math.floor(+new Date / 1e3), n = Ext.copyTo({}, a.params, l), n = SYNO.Encryption.EncryptParam(n), o = 0; o < l.length; o++) delete a.params[l[o]];
                a.params = Ext.apply(a.params, n)
            }
            return this.request(a.url, r.callback, r.scope, a.params, r.skipAppendSynoToken)
        },
        encodeParams: function(t, e) {
            return "JSON" === SYNO.API.GetKnownAPI(t, e).requestFormat ? SYNO.API.EncodeParams(e) : e
        },
        createHiddenInput: function(t, e) {
            var i = document.createElement("input");
            return i.setAttribute("type", "hidden"), i.setAttribute("name", t), i.setAttribute("value", e), i
        }
    }, Ext.define("SYNO.SDS.Utils.HiDPI", {
        statics: {
            getRatio: function(t) {
                var e = window.matchMedia && window.matchMedia("(-webkit-min-device-pixel-ratio: 1.5),(-moz-min-device-pixel-ratio: 1.5),(min-device-pixel-ratio: 1.5)").matches ? 1.5 : 1;
                return (window.devicePixelRatio || e) / (t.webkitBackingStorePixelRatio || t.mozBackingStorePixelRatio || t.msBackingStorePixelRatio || t.oBackingStorePixelRatio || t.backingStorePixelRatio || 1)
            }
        }
    }), SYNO.SDS.Utils.isBSTinEffect = function() {
        var t, e, i, s, n = new Date;
        for (t = 31; t > 0; t--)
            if (0 === (e = new Date(n.getFullYear(), 2, t)).getDay()) {
                i = e;
                break
            } for (t = 31; t > 0; t--)
            if (0 === (e = new Date(n.getFullYear(), 9, t)).getDay()) {
                s = e;
                break
            } return !(n < i || n > s)
    }, SYNO.SDS.Utils.isInVirtualDSM = function() {
        var t = _D("synobios");
        return !!t && ("kvmx64" === t.toLowerCase() || "nextkvmx64" === t.toLowerCase() || "kvmcloud" === t.toLowerCase())
    }, SYNO.SDS.Utils.isInC2DSM = function() {
        var t = _D("c2_dsm");
        return !!t && "yes" === t.toLowerCase()
    }, SYNO.SDS.Utils.IsJson = function(t) {
        return "" !== t && (t = (t = (t = t.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@")).replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+-]?\d+)?/g, "]")).replace(/(?:^|:|,)(?:\s*\[)+/g, ""), /^[\],:{}\s]*$/.test(t))
    }, SYNO.SDS.Utils.isInAliDSM = function() {
        var t = _D("ali_dsm");
        return !!t && "yes" === t.toLowerCase()
    }, SYNO.SDS.Utils.GetFeasibilityCheckMsg = function(t) {
        var e, i, s, n = "",
            o = t,
            r = [],
            a = !0;
        if (SYNO.SDS.Utils.IsJson(t)) {
            if ((e = Ext.util.JSON.decode(t)).task_i18n ? o = e.task_i18n : (o = e.task, a = !1), !o) return "";
            e.args && (r = e.args)
        }
        return n = a ? 1 === (i = o.split(":")).length ? o : 2 === i.length ? 0 === _T(i[0], i[1]).length ? _JSLIBSTR(i[0], i[1]) : _T(i[0], i[1]) : 3 === i.length ? _TT(i[0], i[1], i[2]) : o : o, Ext.isDefined(n) && 0 !== n.length || !Ext.isObject(e) || (n = e.task), 0 < r.length ? (r.unshift(n), s = String.format.apply(String, r)) : s = n, s
    }, SYNO.SDS.Utils.GetFeasibilityCheckMsgJoin = function(t, e) {
        var i = [];
        return e = e || "<br> ", Ext.each(t, function(t) {
            i.push(SYNO.SDS.Utils.GetFeasibilityCheckMsg(t))
        }, this), i.join(e)
    }, Ext.define("SYNO.SDS.Utils.StrongPassValidator", {
        extend: "Ext.util.Observable",
        constructor: function(t, e) {
            this.rules = Ext.apply({
                default_admin_min_length: !0
            }, t), this.username = e || ""
        },
        validate: function(t) {
            var e = this.getMatchError(t);
            return !(e.length > 0) || e[0]
        },
        getStrength: function(t) {
            var e = this.getMatchError(t);
            return Math.max(3 - e.length, 1)
        },
        getMatchError: function(t) {
            var e, i, s = /[a-z]/,
                n = /[A-Z]/,
                o = /[0-9]/,
                r = /[~`!@#$%^&*()\-_+={\[}\]|\\\/:;"'<,>\.\? ]/,
                a = [],
                l = this.rules,
                c = this.username.toLowerCase(),
                d = l.min_length;
            for (e in l)
                if (!0 === l[e]) {
                    switch (i = !1, e) {
                        case "exclude_username":
                            i = 0 === c.length || t.toLowerCase().indexOf(c) < 0;
                            break;
                        case "included_numeric_char":
                            i = o.test(t);
                            break;
                        case "included_special_char":
                            i = r.test(t);
                            break;
                        case "min_length_enable":
                            i = t.length >= d;
                            break;
                        case "mixed_case":
                            i = s.test(t) && n.test(t);
                            break;
                        case "default_admin_min_length":
                            i = "admin" != c || t.length >= 6;
                            break;
                        default:
                            i = !0
                    }
                    i || a.push(this.getErrMsg(e))
                } return a
        },
        getErrMsg: function(t) {
            switch (t) {
                case "min_length_enable":
                    return _T("passwd", t) + " " + this.rules.min_length;
                case "default_admin_min_length":
                    return String.format(_T("passwd", "min_length_default"), "admin", 6);
                default:
                    return _T("passwd", t)
            }
        }
    }), Ext.ns("SYNO.ux"), SYNO.SDS.Utils.FormPanel = Ext.extend(SYNO.ux.FormPanel, {
        module: null,
        constructor: function(t) {
            var e, i = [{
                xtype: "syno_button",
                btnStyle: "blue",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                text: _T("common", "commit"),
                scope: this,
                handler: this.applyHandler
            }, {
                xtype: "syno_button",
                btnStyle: "grey",
                text: _T("common", "reset"),
                scope: this,
                handler: this.cancelHandler
            }];
            if (SYNO.SDS.isCompatibleMode()) {
                var s = i[0],
                    n = i[1];
                i[1] = s, i[0] = n
            }
            e = Ext.apply({
                checkFormDirty: !0,
                trackResetOnLoad: !0,
                useStatusBar: t.useDefaultBtn || t.buttons,
                useDefaultBtn: !1,
                hideMode: "offsets",
                buttons: !0 === t.useDefaultBtn ? i : null
            }, t), e = this.addStatusBar(e), SYNO.SDS.Utils.FormPanel.superclass.constructor.call(this, e)
        },
        addStatusBar: function(t) {
            if (!t.useStatusBar) return t;
            var e = {
                xtype: "statusbar",
                defaultText: "&nbsp;",
                statusAlign: "left",
                buttonAlign: "left",
                items: []
            };
            return t.buttons && (e.items = e.items.concat(t.buttons), delete t.buttons), Ext.applyIf(t, {
                fbar: e
            }), t
        },
        onBeforeRequest: function(t) {
            return !0
        },
        onBeforeAction: function(t, e) {
            if ("get" === e) return !0;
            if (this.checkFormDirty && !this.isFormDirty()) {
                var i = _T("error", "nochange_subject");
                return this.setStatusError({
                    text: i,
                    clear: !0
                }), !1
            }
            return !!t.isValid() || (this.setStatusError({
                text: _T("common", "forminvalid"),
                clear: !0
            }), !1)
        },
        onApiSuccess: function(t, e, i) {
            "set" === t && (Ext.isBoolean(e.has_fail) && e.has_fail || this.setStatusOK()), this.processReturnData(t, e, i)
        },
        processReturnData: function(t, e, i) {
            var s = this.getForm();
            i && Ext.isArray(i.compound) && s.loadRecords(e.result, i.compound)
        },
        onApiFailure: function(t, e, i) {
            "get" === t ? this.reportLoadFail(this.getForm(), t) : "set" === t && this.reportFormSubmitFail(this.getForm(), t)
        },
        reportLoadFail: function(t, e) {},
        reportFormSubmitFail: function(t, e) {},
        applyHandler: function(t, e) {
            this.applyForm()
        },
        cancelHandler: function(t, e) {
            this.getForm().reset()
        },
        applyForm: function() {
            var t = this.getForm();
            if (!1 === this.onBeforeAction(t, "set")) return !1;
            var e = t.getValues(!1, "set"),
                i = this.constructApplyParams(e);
            i = i.concat(this.getApiArray("get")), i = this.processParams("set", i), this.sendAjaxRequest("set", i)
        },
        upload: function() {
            var t = this.getForm();
            if (!this.fileUpload || !1 === this.onBeforeAction(t, "set")) return !1;
            this.setStatusBusy({
                text: _T("common", "saving")
            }), this.getForm().submit({
                clientValidation: !1,
                scope: this,
                callback: function(t, e, i) {
                    this.clearStatusBusy(), t ? this.onApiSuccess("set", e, i) : this.onApiFailure("set", e, i)
                }
            })
        },
        processParams: function(t, e) {
            return e
        },
        loadForm: function(t) {
            var e;
            if (!1 === this.onBeforeAction(this.getForm(), "get")) return !1;
            e = this.getApiArray("get"), e = this.processParams("get", e), this.sendAjaxRequest("get", e)
        },
        getAjaxCfg: function(t) {
            return {}
        },
        getCompoundCfg: function(t) {
            return {}
        },
        sendAjaxRequest: function(t, e) {
            "get" === t ? this.setStatusBusy() : this.setStatusBusy({
                text: _T("common", "saving")
            });
            var i = this.getAjaxCfg(t),
                s = this.getCompoundCfg(t),
                n = Ext.apply({
                    fileUpload: !1,
                    clientValidation: !1,
                    compound: {
                        stopwhenerror: !1,
                        params: e
                    },
                    scope: this,
                    callback: function(e, i, s) {
                        this.clearStatusBusy(), e ? this.onApiSuccess(t, i, s) : this.onApiFailure(t, i, s)
                    }
                }, i);
            n.compound = Ext.apply(n.compound, s), this.getForm().submit(n)
        },
        onPageDeactivate: function() {
            return !this.checkFormDirty || !this.isFormDirty()
        },
        isFormDirty: function() {
            return this.getForm().isDirty()
        },
        getAbsoluteURL: function(t) {
            return this.module ? this.module.getAbsoluteURL(t) : t
        },
        createForm: function() {
            var t = Ext.applyIf({
                appWindow: this,
                listeners: {}
            }, this.initialConfig);
            return new SYNO.API.Form.BasicForm(null, t)
        },
        getApiArray: function(t) {
            var e = SYNO.ux.Utils.getApiArray(this, t, 0, 3);
            return e = SYNO.ux.Utils.uniqueApiArray(e)
        },
        constructApplyParams: function(t) {
            var e, i, s, n, o, r, a = {},
                l = [];
            for (i in t)
                if (t.hasOwnProperty(i)) {
                    if (4 != (e = i.split("|")).length) continue;
                    s = i.substr(0, i.lastIndexOf("|")), n = i.substr(i.lastIndexOf("|") + 1), o = t[i], a[s] || (a[s] = {}), a[s][n] = o
                } for (s in a)
                if (a.hasOwnProperty(s)) {
                    for (n in (r = {
                            api: (e = s.split("|"))[0],
                            method: e[1],
                            version: e[2]
                        }).params = SYNO.ux.Utils.getApiParams(r, this.getApiArray("set")), a[s]) a[s].hasOwnProperty(n) && (r.params[n] = a[s][n]);
                    l.push(r)
                } return l
        },
        clearStatus: function(t) {
            var e = this.getFooterToolbar();
            e && Ext.isFunction(e.clearStatus) && e.clearStatus(t)
        },
        clearStatusBusy: function(t) {
            this.clearStatus(t), this.unmaskAppWin()
        },
        setStatus: function(t) {
            t = t || {};
            var e = this.getFooterToolbar();
            e && Ext.isFunction(e.setStatus) && e.setStatus(t)
        },
        maskAppWin: function() {
            var t = this.findWindow();
            t && Ext.isDefined(t.maskForBusy) && t.maskForBusy()
        },
        unmaskAppWin: function() {
            var t = this.findWindow();
            t && Ext.isDefined(t.unmask) && t.unmask()
        },
        setStatusBusy: function(t) {
            t = t || {}, Ext.applyIf(t, {
                text: _T("common", "loading"),
                iconCls: "syno-ux-statusbar-loading"
            }), this.setStatus(t), this.maskAppWin()
        },
        setStatusOK: function(t) {
            t = t || {}, Ext.applyIf(t, {
                text: _T("common", "setting_applied"),
                iconCls: "syno-ux-statusbar-success",
                clear: !0
            }), this.setStatus(t)
        },
        setStatusError: function(t) {
            t = t || {}, Ext.applyIf(t, {
                text: _T("common", "error_system"),
                iconCls: "syno-ux-statusbar-error"
            }), this.setStatus(t)
        }
    }), Ext.namespace("SYNO.SDS.Relay"), SYNO.SDS.Relay.GenRelaydStatusStr = function() {
        var t = {
                err_unknown: _T("relayservice", "relayservice_err_unknown"),
                err_config: String.format(_T("relayservice", "relayservice_err_config"), "ERR_CONF"),
                err_register: String.format(_T("relayservice", "relayservice_err_register"), "ERR_REG"),
                err_network: _T("relayservice", "relayservice_err_network"),
                err_not_support: _T("relayservice", "relayservice_status_update_dsm"),
                err_resolv: _T("relayservice", "relayservice_err_resolv"),
                err_lock: String.format(_T("relayservice", "relayservice_err_lock"), "ERR_LOCK"),
                err_auth: _T("error", "error_auth"),
                err_server_limit: _T("relayservice", "relayservice_err_server_limit"),
                err_server_busy: String.format(_T("relayservice", "relayservice_err_server_busy"), "ERR_BUSY"),
                err_server_changed: String.format(_T("relayservice", "relayservice_err_register"), "ERR_REG"),
                success: void 0
            },
            e = {
                not_running: _T("relayservice", "relayservice_disconnected"),
                starting: _T("relayservice", "relayservice_starting"),
                login: Ext.copyTo({
                    success: _T("relayservice", "relayservice_login")
                }, t, "err_network,err_resolv,err_server_limit"),
                connected: Ext.copyTo({
                    success: _T("relayservice", "relayservice_connected")
                }, t, "err_network,err_resolv"),
                direct_connect: _T("relayservice", "relayservice_direct_connect"),
                logout: _T("relayservice", "relayservice_stop"),
                stoped: Ext.applyIf({
                    success: _T("relayservice", "relayservice_disconnected")
                }, t),
                "--": "--"
            };
        return function(i, s) {
            if (i in e) {
                if (Ext.isString(e[i])) return e[i];
                if (!Ext.isObject(e[i])) throw Error("unknown status config");
                return s in e[i] ? e[i][s] : e[i].success
            }
            return s in t ? e.stoped.success + "(" + t[s] + ")" : e.stoped.success
        }
    }, SYNO.SDS.Relay.GetRelaydStatusStr = SYNO.SDS.Relay.GenRelaydStatusStr(), Ext.namespace("SYNO.SDS.MessageBox"), SYNO.SDS.MessageBox = Ext.extend(SYNO.SDS.ModalWindow, {
        buttonNames: ["ok", "yes", "no", "cancel"],
        buttonWidth: 0,
        maxWidth: 600,
        minWidth: 300,
        minProgressWidth: 250,
        minPromptWidth: 250,
        emptyText: "&#160;",
        defaultTextHeight: 75,
        mbIconCls: "",
        fbButtons: null,
        opt: null,
        bodyEl: null,
        iconEl: null,
        msgEl: null,
        textboxEl: null,
        textareaEl: null,
        progressBar: null,
        activeTextEl: null,
        passwordEl: null,
        gridEl: null,
        constructor: function(t) {
            this.opt = {}, this.buttonText = Ext.MessageBox.buttonText, this.dsmStyle = t.dsmStyle, (t = t || {}).cls = t.cls ? t.cls + " x-window-dlg" : "x-window-dlg", SYNO.SDS.MessageBox.superclass.constructor.call(this, Ext.apply({
                resizable: !1,
                minimizable: !1,
                maximizable: !1,
                closable: !0,
                stateful: !1,
                buttonAlign: "center",
                width: 400,
                height: 100,
                footer: !0,
                fbar: new Ext.Toolbar({
                    items: this.getButtons(t),
                    enableOverflow: !1
                })
            }, t))
        },
        getButtons: function(t) {
            var e = [];
            return this.fbButtons = {}, SYNO.SDS.isCompatibleMode() && (this.buttonNames = ["no", "cancel", "ok", "yes"]), Ext.each(this.buttonNames, function(t) {
                e.push(this.fbButtons[t] = new Ext.Button({
                    hideModE: "offset",
                    text: this.buttonText[t],
                    handler: this.handleButton.createDelegate(this, [t])
                }))
            }, this), e
        },
        close: function() {
            !1 !== this.opt.canClose && (this.opt.buttons && this.opt.buttons.no && !this.opt.buttons.cancel ? this.handleButton("no", "close") : this.handleButton("cancel", "close"))
        },
        doClose: function() {
            if (this.activeGhost) {
                var t = Ext.dd.DragDropMgr;
                this.dd === t.dragCurrent && (t.dragCurrent = null, t.dragOvers = {}), this.unghost(!1, !1)
            }
            SYNO.SDS.MessageBox.superclass.doClose.apply(this, arguments)
        },
        onRender: function() {
            SYNO.SDS.MessageBox.superclass.onRender.apply(this, arguments);
            var t = Ext.id();
            this.bodyEl = this.body.createChild({
                html: '<div class="ext-mb-icon"></div><div class="ext-mb-content"><span class="ext-mb-text" id=' + t + '></span><br /><div class="ext-mb-fix-cursor"><input type="text" class="ext-mb-input" /><textarea class="ext-mb-textarea"></textarea></div></div><div class="ext-mb-grid"></div>'
            }), this.iconEl = Ext.get(this.bodyEl.dom.childNodes[0]), this.msgEl = Ext.get(this.bodyEl.dom.childNodes[1].childNodes[0]), this.textboxEl = Ext.get(this.bodyEl.dom.childNodes[1].childNodes[2].childNodes[0]), this.brEl = Ext.get(this.bodyEl.dom.childNodes[1].childNodes[1]), this.textareaEl = Ext.get(this.bodyEl.dom.childNodes[1].childNodes[2].childNodes[1]), this.wrapperEl = Ext.get(this.bodyEl.dom.childNodes[1].childNodes[2]), this.gridEl = Ext.get(this.bodyEl.dom.childNodes[2]), this.progressBar = new Ext.ProgressBar({
                renderTo: this.bodyEl
            }), this.focusEl.set({
                "aria-labelledby": this.msgEl.id
            }), this.focusEl.dom.removeAttribute("aria-label"), this.bodyEl.createChild({
                cls: "x-clear"
            }), this.textboxEl.enableDisplayMode(), this.textareaEl.enableDisplayMode(), this.gridEl.enableDisplayMode(), this.textboxEl.addKeyListener(Ext.EventObject.ENTER, this.handleButton.createDelegate(this, ["ok"])), this.textareaEl.addKeyListener(Ext.EventObject.ENTER, this.handleButton.createDelegate(this, ["ok"])), this.addManagedComponent(this.progressBar)
        },
        createPasswordEl: function() {
            this.passwordEl || (this.passwordEl = this.wrapperEl.createChild({
                tag: "input",
                type: "password",
                cls: "ext-mb-input"
            }), this.passwordEl.addKeyListener(Ext.EventObject.ENTER, this.handleButton.createDelegate(this, ["ok"])))
        },
        removePasswordEl: function() {
            this.passwordEl && (this.passwordEl.remove(), this.passwordEl = null)
        },
        showMsg: function(t) {
            if (this.opt = t, this.setTitle(t.title || this.emptyText), this.tools.close && this.tools.close.setDisplayed(!1 !== t.closable && !0 !== t.progress && !0 !== t.wait), this.gridEl.hide(), this.activeTextEl = this.textboxEl, t.prompt = t.prompt || !!t.multiline, t.prompt ? t.multiline ? (this.textboxEl.hide(), this.textareaEl.show(), this.textareaEl.setHeight(Ext.isNumber(t.multiline) ? t.multiline : this.defaultTextHeight), this.removePasswordEl()) : t.password ? (this.textboxEl.hide(), this.textareaEl.hide(), this.createPasswordEl(), this.activeTextEl = this.passwordEl) : (this.textboxEl.show(), this.textareaEl.hide(), this.removePasswordEl()) : (this.textboxEl.hide(), this.textareaEl.hide(), this.removePasswordEl()), this.activeTextEl.dom.value = t.value || "", this.setIconClass(Ext.isDefined(t.icon) ? t.icon : null), this.buttonWidth = this.updateButtons(t.buttons), this.progressBar.setVisible(!0 === t.progress || !0 === t.wait), this.updateProgress(0, t.progressText), this.updateText(t.msg), t.wait && this.progressBar.wait(t.waitConfig), t.cls && this.el.addClass(t.cls), t.progress ? this.progressBar.progressBar.set({
                    "aria-labelledby": this.msgEl.id
                }) : this.progressBar.progressBar.set({
                    tabIndex: "-1"
                }), !0 === t.wait && this.progressBar.wait(t.waitConfig), Ext.isArray(t.msgArray)) {
                var e = this.bodyEl.child("div.ext-mb-content"),
                    i = Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(t.msg));
                this.brEl.enableDisplayMode("DISPLAY"), this.brEl.hide(), this.msgEl.set({
                    "ext:qtip": i
                }), e.addClass("ext-mb-grid-desc"), this.gridEl.show(), this.createGridPanel(t.msgArray)
            }
            this.show(), this.owner && !this.owner.isVisible() && (this.hideForMinimize = !0, this.minimize())
        },
        createGridPanel: function(t) {
            var e = t.map(function(t) {
                return [t]
            });
            if (this.grid) this.grid.store.loadData(e);
            else {
                var i = new Ext.grid.ColumnModel({
                    columns: [{
                        dataIndex: "data",
                        renderer: function(t, e, i) {
                            var s = Ext.util.Format.htmlEncode(t);
                            return e.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(s) + '"', s
                        }
                    }]
                });
                this.grid = new SYNO.ux.GridPanel({
                    colModel: i,
                    store: new Ext.data.ArrayStore({
                        autoDestroy: !0,
                        fields: ["data"],
                        data: e
                    }),
                    viewConfig: {
                        rowOverCls: "",
                        selectedRowClass: ""
                    },
                    hideHeaders: !0,
                    enableHdMenu: !1,
                    height: 304,
                    autoHeight: !1,
                    renderTo: this.gridEl,
                    listeners: {
                        viewready: function(t) {
                            this.view.updateScroller()
                        }
                    }
                }), this.addManagedComponent(this.grid)
            }
        },
        focus: function() {
            var t = this.focusEl;
            this.fbButtons.yes && this.fbButtons.yes.isVisible() ? this.fbButtons.yes.focus() : (t = t || this.focusEl).focus.defer(10, t)
        },
        show: function() {
            this.alignTo(this.owner ? this.owner.el : document.body, "c-c"), SYNO.SDS.MessageBox.superclass.show.apply(this, arguments)
        },
        updateText: function(t) {
            this.opt.width || this.setSize(this.maxWidth, 100), this.msgEl.update(t || this.emptyText);
            var e, i = "" !== this.mbIconCls ? this.iconEl.getWidth() + this.iconEl.getMargins("lr") : 0,
                s = this.msgEl.getWidth() + this.msgEl.getMargins("lr"),
                n = this.getFrameWidth("lr"),
                o = this.body.getFrameWidth("lr");
            Ext.isIE && i > 0 && (i += 3), e = Math.max(Math.min(this.opt.width || i + s + n + o, this.opt.maxWidth || this.maxWidth), Math.max(this.opt.minWidth || this.minWidth, this.buttonWidth || 0)), e += 2 * (this.fbar.getBox().x - this.getBox().x), !0 === this.opt.prompt && this.activeTextEl.setWidth(e - i - n - o), !0 !== this.opt.progress && !0 !== this.opt.wait || this.progressBar.setSize(e - i - n - o), Ext.isIE && e == this.buttonWidth && (e += 4), this.setSize(e, "auto")
        },
        updateProgress: function(t, e, i) {
            return this.progressBar.updateProgress(t, e), i && this.updateText(i), this
        },
        updateButtons: function(t) {
            var e, i = 0;
            return t ? (Ext.iterate(this.fbButtons, function(s, n) {
                (e = t[s]) ? (n.show(), n.setText(Ext.isString(e) ? e : this.buttonText[s]), i += n.container.getWidth()) : n.hide()
            }, this), i) : (Ext.each(this.buttonNames, function(t) {
                this.fbButtons[t].hide()
            }, this), i)
        },
        handleButton: function(t, e) {
            this.fbButtons[t].blur(), this.preventDelay ? this.opt.fn.call(this.opt.scope || window, t, this.activeTextEl.dom.value, this.opt, e) : Ext.callback(this.opt.fn, this.opt.scope || window, [t, this.activeTextEl.dom.value, this.opt, e], 1), SYNO.SDS.MessageBox.superclass.close.call(this)
        },
        setIconClass: function(t) {
            if (t && "" !== t) return this.iconEl.removeClass("x-hidden"), this.bodyEl.addClass("x-dlg-icon"), this.iconEl.replaceClass(this.mbIconCls, t), void(this.mbIconCls = t);
            this.iconEl.addClass("x-hidden"), this.bodyEl.removeClass("x-dlg-icon"), this.iconEl.removeClass(this.mbIconCls), this.mbIconCls = ""
        },
        progress: function(t, e, i) {
            return this.showMsg({
                title: t,
                msg: e,
                buttons: !1,
                progress: !0,
                closable: !1,
                minWidth: this.minProgressWidth,
                progressText: i
            }), this
        },
        wait: function(t, e, i) {
            return this.showMsg({
                title: e,
                msg: t,
                buttons: !1,
                closable: !1,
                wait: !0,
                minWidth: this.minProgressWidth,
                waitConfig: i
            }), this
        },
        alert: function(t, e, i, s) {
            return this.showMsg({
                title: t,
                msg: e,
                buttons: Ext.MessageBox.OK,
                fn: i,
                scope: s,
                minWidth: this.minWidth
            }), this
        },
        showGridMsg: function(t, e, i, s, n, o) {
            return this.showMsg({
                title: t,
                msg: e,
                msgArray: i,
                buttons: o || Ext.MessageBox.YESNO,
                fn: s,
                scope: n,
                icon: Ext.MessageBox.QUESTION,
                maxWidth: 380,
                minWidth: this.minWidth
            }), this
        },
        confirm: function(t, e, i, s, n) {
            return this.showMsg({
                title: t,
                msg: e,
                buttons: n || Ext.MessageBox.YESNO,
                fn: i,
                scope: s,
                icon: Ext.MessageBox.QUESTION,
                minWidth: this.minWidth
            }), this
        },
        prompt: function(t, e, i, s, n, o, r) {
            return this.showMsg({
                title: t,
                msg: e,
                buttons: Ext.MessageBox.OKCANCEL,
                fn: i,
                minWidth: this.minPromptWidth,
                scope: s,
                prompt: !0,
                multiline: n,
                value: o,
                password: r
            }), this
        },
        getWrapper: function(t) {
            function e(t, e) {
                return function() {
                    return e.apply(t, arguments)
                }
            }
            return this.msgBoxWrapper || (this.msgBoxWrapper = {
                show: e(this, this.showMsg),
                hide: e(this, this.doClose),
                progress: e(this, this.progress),
                wait: e(this, this.wait),
                alert: e(this, this.alert),
                confirm: e(this, this.confirm),
                prompt: e(this, this.prompt),
                getDialog: function() {
                    return this
                }.createDelegate(this),
                isVisible: e(this, this.isVisible),
                setIcon: e(this, this.setIconClass),
                updateProgress: e(this, this.updateProgress),
                updateText: e(this, this.updateText)
            }), this.extra = {}, Ext.apply(this.extra, t || {}), this.msgBoxWrapper
        }
    }), Ext.define("SYNO.SDS.MessageBoxV5", {
        extend: "SYNO.SDS.MessageBox",
        ariaRole: "alertdialog",
        constructor: function(t) {
            this.callParent([Ext.apply(t, {
                dsmStyle: "v5",
                closable: !0,
                header: t.draggable || !1,
                draggable: t.draggable || !1,
                buttonAlign: "right",
                elements: "body",
                padding: t.draggable ? "0 20px" : "20px 20px 0 20px"
            })]), this.draggable && this.addClass("msgbox-draggable")
        },
        onRender: function() {
            this.callParent(arguments), this.progressStatus = this.bodyEl.createChild({
                tag: "span",
                cls: "syno-mb-progress-status"
            }, this.bodyEl.child(".x-clear")), this.progressBar.addClass("syno-mb-progress")
        },
        selectBtn: function(t, e, i) {
            for (var s = Ext.getCmp(Ext.get(t.target).up(".syno-ux-button").id)[i + "Sibling"](); s && s.hidden;) s = s[i + "Sibling"]();
            s && !s.hidden && s.focus()
        },
        getButtons: function(t) {
            var e = [];
            return this.fbButtons = {}, this.buttonNames = ["custom", "ok", "yes", "no", "cancel"], this.buttonText = Ext.MessageBox.buttonText, this.buttonText.custom = this.buttonText.no, SYNO.SDS.isCompatibleMode() && (this.buttonNames = ["custom", "no", "cancel", "ok", "yes"]), Ext.each(this.buttonNames, function(t) {
                e.push(this.fbButtons[t] = new SYNO.ux.Button({
                    hideModE: "offset",
                    btnStyle: this.getButtonStyle(t),
                    text: this.buttonText[t],
                    handler: this.handleButton.createDelegate(this, [t]),
                    msgWin: this,
                    transitionFocus: function() {
                        this.el.hasClass("focus-effect") ? this.el.removeClass("focus-effect") : this.el.addClass("focus-effect")
                    },
                    onBtnElFocus: function(t) {
                        this.focusTask = this.focusTask || this.addTask({
                            id: "focus_effect",
                            interval: 600,
                            run: this.transitionFocus,
                            scope: this
                        }), this.focusTask.start()
                    },
                    onBtnElBlur: function(t) {
                        this.focusTask.stop(), this.el.removeClass("focus-effect")
                    },
                    listeners: {
                        afterrender: function() {
                            this.hidden || (this.nav = new Ext.KeyNav(this.btnEl, {
                                left: this.msgWin.selectBtn.createDelegate(this.msgWin, ["previous"], !0),
                                right: this.msgWin.selectBtn.createDelegate(this.msgWin, ["next"], !0)
                            }), this.mon(this.btnEl, {
                                focus: this.onBtnElFocus,
                                blur: this.onBtnElBlur,
                                scope: this
                            }, this))
                        }
                    }
                }))
            }, this), e
        },
        getButtonStyle: function(t) {
            return "ok" == t || "yes" == t ? "blue" : "grey"
        },
        isModalized: function() {
            return !this.sinkable
        },
        getTopWin: function() {
            return this.sinkable ? this : this.callParent()
        },
        setButtonAlign: function() {
            var t = [];
            Ext.iterate(this.fbButtons, function(e, i) {
                i.hidden || t.push(i)
            }, this), 1 == t.length && t[0].el.center(this.footer)
        },
        isCustomBtnVisible: function() {
            return !this.fbButtons.custom.hidden
        },
        updateProgress: function(t, e, i, s) {
            return s = s || !1, this.progressBar.updateProgress(t, e), this.progressStatus.update(e), (i || e) && !0 !== s ? this.updateText(i) : i && this.msgEl.update(i), this
        },
        updateButtons: function(t) {
            var e, i, s, n = 0;
            return this.fbButtons.custom.removeClass("syno-mb-custom-btn"), t ? (Ext.iterate(this.fbButtons, function(o, r) {
                (e = t[o]) ? (r.show(), this.updateBtnByCfg(o, r, e), !this.extra || this.extra.btnStyle === r.btnStyle || "yes" !== o && "ok" !== o || !r.el || r.el.hasClass(s) || (i = String.format("syno-ux-button-{0}", r.btnStyle), s = String.format("syno-ux-button-{0}", this.extra.btnStyle || "blue"), r.removeClass(i), r.addClass(s)), n += r.container.getWidth()) : r.hide()
            }, this), this.isCustomBtnVisible() && (n += this.iconEl.getWidth() + this.iconEl.getMargins("lr"), this.fbButtons.custom.addClass("syno-mb-custom-btn")), n) : (Ext.each(this.buttonNames, function(t) {
                this.fbButtons[t].hide()
            }, this), n)
        },
        updateBtnByCfg: function(t, e, i) {
            var s = this.buttonText[t],
                n = "grey";
            e.el && (Ext.isString(i) ? s = i : Ext.isObject(i) && i.text && (s = i.text), e.setText(s), e.removeClass("syno-ux-button-blue"), e.removeClass("syno-ux-button-red"), e.removeClass("syno-ux-button-grey"), Ext.isObject(i) && i.btnStyle ? n = i.btnStyle : "yes" !== t && "ok" !== t || (n = "blue"), e.addClass("syno-ux-button-" + n))
        },
        updateText: function() {
            this.callParent(arguments), !0 === this.opt.progress && this.progressStatus.getWidth() > 0 && this.setSize(this.getSize().width + (this.progressStatus.getWidth() + 5), "auto"), this.setButtonAlign()
        },
        confirmDelete: function(t, e, i, s, n) {
            var o = {
                yes: {
                    text: _T("common", "delete"),
                    btnStyle: "red"
                },
                no: {
                    text: this.buttonText.no
                }
            };
            return this.showMsg({
                title: t,
                msg: e,
                buttons: n || o,
                fn: i,
                scope: s,
                icon: Ext.MessageBox.QUESTION,
                minWidth: this.minWidth
            }), this
        },
        getWrapper: function(t) {
            function e(t, e) {
                return function() {
                    return e.apply(t, arguments)
                }
            }
            return this.msgBoxWrapper || (this.msgBoxWrapper = {
                confirmGrid: e(this, this.showGridMsg),
                show: e(this, this.showMsg),
                hide: e(this, this.doClose),
                progress: e(this, this.progress),
                wait: e(this, this.wait),
                alert: e(this, this.alert),
                confirm: e(this, this.confirm),
                confirmDelete: e(this, this.confirmDelete),
                prompt: e(this, this.prompt),
                getDialog: function() {
                    return this
                }.createDelegate(this),
                isVisible: e(this, this.isVisible),
                setIcon: e(this, this.setIconClass),
                updateProgress: e(this, this.updateProgress),
                updateText: e(this, this.updateText)
            }), this.extra = {}, Ext.apply(this.extra, t || {}), this.extra && this.extra.sinkable && Ext.apply(this, {
                sinkable: !!this.extra.sinkable
            }), this.msgBoxWrapper
        }
    }), SYNO.SDS.MessageBoxV5.YESNOCANCEL = {
        custom: !0,
        yes: !0,
        cancel: !0
    }, Ext.namespace("SYNO.SDS.Wizard"), SYNO.SDS.Wizard.Step = Ext.extend(Ext.Panel, {
        getNext: function() {
            return this.nextId ? this.nextId : null
        },
        checkState: function() {
            this.owner.hasHistory() ? this.owner.getButton("back").show() : this.owner.getButton("back").hide(), null === this.nextId ? this.owner.getButton("next").setText(_T("common", "commit")) : this.owner.getButton("next").setText(_T("common", "next")), this.owner.getButton("back").enable(), _S("demo_mode") && this.disableNextInDemoMode ? (this.owner.getButton("next").disable(), this.owner.getButton("next").setTooltip(_JSLIBSTR("uicommon", "error_demo"))) : (this.owner.getButton("next").enable(), this.owner.getButton("next").setTooltip(""))
        }
    }), SYNO.SDS.Wizard.WelcomeStep = Ext.extend(SYNO.SDS.Wizard.Step, {
        constructor: function(t) {
            if (!Ext.isObject(t)) throw Error("invalid config of WelcomeStep");
            this.leftTextBox = new Ext.BoxComponent({
                html: ""
            });
            var e = {
                layout: "border",
                padding: 0,
                bwrapCfg: {
                    cls: "x-panel-bwrap sds-wizard-welcome-bwrap"
                },
                items: [{
                    xtype: "panel",
                    region: "west",
                    border: !1,
                    split: !1,
                    width: 140,
                    bodyCssClass: "welcome-image",
                    items: [this.leftTextBox]
                }, {
                    region: "center",
                    border: !1,
                    layout: "vbox",
                    itemId: "wizard_welcome_center",
                    layoutConfig: {
                        align: "stretch",
                        pack: "start"
                    },
                    items: [{
                        border: !1,
                        autoHeight: !0,
                        role: "article",
                        tabIndex: 0,
                        bodyCssClass: "welcome-headline"
                    }, {
                        border: !1,
                        flex: 1,
                        role: "article",
                        xtype: "syno_panel",
                        autoFlexcroll: !0,
                        tabIndex: 0,
                        bodyCssClass: "welcome-text"
                    }]
                }]
            };
            Ext.isObject(t.imageCls) ? Ext.apply(e.items[0], t.imageCls) : t.imageCls && (e.items[0].bodyCssClass = t.imageCls);
            var i = Ext.util.Format.htmlEncode(t.leftTitle),
                s = String.format('<p class="welcome-image-text">' + i + "</p>");
            Ext.isObject(t.leftTitle) ? Ext.apply(this.leftTextBox.html, s) : t.leftTitle && (this.leftTextBox.html = s), Ext.isObject(t.headline) ? Ext.apply(e.items[1].items[0], t.headline) : t.headline && (e.items[1].items[0].html = t.headline), Ext.isObject(t.description) ? Ext.apply(e.items[1].items[1], t.description) : t.description && (e.items[1].items[1].html = t.description), Ext.isDefined(t.headLineHeight) && (e.items[1].items[0].height = t.headLineHeight), delete t.imageCls, delete t.headline, delete t.description, Ext.apply(e, t), SYNO.SDS.Wizard.WelcomeStep.superclass.constructor.call(this, e)
        },
        getHeadLine: function() {
            return this.getComponent("wizard_welcome_center").items.items[0]
        },
        activate: function() {
            this.hideBanner()
        },
        deactivate: function() {
            this.showBanner()
        },
        hideBanner: function() {
            this.owner.banner && (this.owner.getComponent("banner").hide(), this.owner.doLayout())
        },
        showBanner: function() {
            this.owner.banner && (this.owner.getComponent("banner").show(), this.owner.doLayout())
        },
        listeners: {
            afterlayout: function(t) {
                var e = this.getHeight() - 24;
                this.leftTextBox.setWidth(e)
            }
        }
    }), SYNO.SDS.Wizard.SummaryStore = Ext.extend(Ext.data.JsonStore, {
        constructor: function() {
            SYNO.SDS.Wizard.SummaryStore.superclass.constructor.call(this, {
                autoDestroy: !0,
                root: "data",
                fields: ["key", "value"]
            })
        },
        append: function(t, e) {
            this.loadData({
                data: [{
                    key: t,
                    value: e
                }]
            }, !0)
        },
        appendSub: function(t, e) {
            this.append(String.format("&nbsp;&nbsp;&nbsp;&nbsp;{0}", t), e)
        },
        appendNoChange: function(t) {
            this.append(t, String.format("[{0}]", _T("tree", "nochangepage")))
        }
    }), SYNO.SDS.Wizard.SummaryStep = Ext.extend(SYNO.ux.GridPanel, {
        showCommitButton: !1,
        constructor: function(t) {
            var e = Ext.apply({
                headline: _T("ezinternet", "ezinternet_summary_title"),
                description: _T("wizcommon", "summary_descr"),
                viewConfig: {
                    forceFit: !1
                },
                columns: [{
                    width: 150,
                    header: _T("status", "header_item"),
                    dataIndex: "key",
                    renderer: this.fieldRenderer
                }, {
                    id: "value",
                    autoExpand: !0,
                    header: _T("status", "header_value"),
                    dataIndex: "value",
                    renderer: this.descRenderer,
                    scope: this
                }],
                enableHdMenu: !1,
                enableColumnMove: !1,
                autoExpandColumn: "value",
                store: new SYNO.SDS.Wizard.SummaryStore
            }, t);
            SYNO.SDS.Wizard.SummaryStep.superclass.constructor.call(this, e)
        },
        fieldRenderer: function(t, e) {
            return e.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(t) + '"', "<b>" + t + "</b>"
        },
        descRenderer: function(t, e, i, s, n, o) {
            var r = Ext.util.Format.htmlEncode(t);
            return e.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(r) + '"', r
        },
        activate: function() {
            var t = this.owner.stepStack,
                e = null;
            this.getStore().removeAll(!0);
            for (var i = 0; i < t.length; i++) e = this.owner.getStep(t[i]), Ext.isFunction(e.summary) && e.summary(this.getStore());
            this.getView().refresh()
        },
        checkState: function() {
            SYNO.SDS.Wizard.Step.prototype.checkState.apply(this, arguments), this.showCommitButton && this.owner.getButton("next").setText(_T("common", "commit"))
        }
    }), SYNO.SDS.Wizard.TaskStore = Ext.extend(Ext.data.JsonStore, {
        constructor: function(t) {
            SYNO.SDS.Wizard.TaskStore.superclass.constructor.call(this, Ext.apply({
                autoDestroy: !0,
                idProperty: "id",
                root: "data",
                fields: ["id", "text", "config", "option", "status"]
            }, t))
        },
        append: function(t, e, i, s) {
            var n = new this.recordType({
                status: "",
                id: t,
                text: e,
                config: i,
                option: s || {}
            }, t);
            return this.add(n), n.set("status", "queue"), n.setStatus = function(t) {
                n.set("status", t), n.store.commitChanges()
            }, n
        },
        get: function(t) {
            return Ext.isString(t) ? this.getById(t) : Ext.isNumber(t) ? this.getAt(t) : Ext.isObject(t) && t.store && this === t.store ? t : void 0
        }
    }), SYNO.SDS.Wizard.ApplyStep = Ext.extend(SYNO.ux.GridPanel, {
        currentTask: null,
        stopOnFail: !0,
        constructor: function(t) {
            SYNO.SDS.Wizard.ApplyStep.superclass.constructor.call(this, Ext.apply({
                headline: _T("ezinternet", "ezinternet_apply_title"),
                description: _T("ezinternet", "ezinternet_apply_desc"),
                cls: "without-dirty-red-grid",
                store: new SYNO.SDS.Wizard.TaskStore,
                viewConfig: {
                    forceFit: !1,
                    headersDisabled: !0
                },
                hideHeaders: !0,
                columns: [{
                    header: "",
                    align: "center",
                    width: 30,
                    dataIndex: "status",
                    renderer: this.renderStatus
                }, {
                    id: "text",
                    header: "Activity",
                    dataIndex: "text",
                    renderer: function(t) {
                        return t
                    }
                }],
                draggable: !1,
                enableColumnMove: !1,
                autoExpandColumn: "text"
            }, t))
        },
        renderStatus: function(t) {
            var e = {
                doing: '<div class="x-status-loading">&nbsp;</div>',
                done: '<div class="x-status-success">&nbsp;</div>',
                fail: '<div class="x-status-fail">&nbsp;</div>'
            };
            if (e[t]) return e[t]
        },
        checkState: function() {
            this.owner.hasHistory() ? this.owner.getButton("back").show() : this.owner.getButton("back").hide(), this.owner.getButton("cancel").hide(), null === this.nextId ? this.owner.getButton("next").setText(_T("common", "finish")) : this.owner.getButton("next").setText(_T("common", "next"))
        },
        activate: function() {
            var t = this,
                e = this.getStore(),
                i = this.owner.stepStack,
                s = null;
            this.owner.clearStatus(), e.removeAll(!0), Ext.each(i, function(i) {
                var n = this.owner.getStep(i);
                Ext.isFunction(n.appendTask) && (e.commitChanges(), n.appendTask(e), s = e.getModifiedRecords(), Ext.each(s, function(e) {
                    var s = e.get("option");
                    s && !s.backId && (s.backId = i), e.report = function(e) {
                        t.report(e)
                    }, e.doNextTask = function(e) {
                        t.doNextTask(e)
                    }
                }, this))
            }, this), e.commitChanges(), this.getView().refresh(), e.getCount() > 0 ? this.start() : this.finish.defer(300, this)
        },
        deactivate: function() {
            if (this.currentTask) return SYNO.Debug.error("task is running"), !1
        },
        report: function(t) {
            t && (t.success ? this.owner.setStatusOK(t) : this.owner.setStatusError(t))
        },
        start: function() {
            this.owner.getButton("back").disable(), this.owner.getButton("next").disable(), this.doTask(0)
        },
        finish: function() {
            !Ext.isString(this.getBack()) ? (this.owner.getButton("back").disable(), this.owner.getButton("back").hide(), this.report({
                success: !0
            })) : (this.owner.getButton("back").enable(), this.owner.getButton("next").setText(_T("common", "cancel"))), this.owner.getButton("next").enable(), this.currentTask = null
        },
        getBack: function() {
            var t = this.getStore(),
                e = null,
                i = 0;
            for (i = 0; i < t.getCount(); i++)
                if ("fail" === (e = t.getAt(i)).get("status")) return e.get("option").backId;
            return !1
        },
        doTask: function(t) {
            var e = {};
            (t = this.getStore().get(t)) && (t.setStatus("doing"), Ext.apply(e, t.get("config")), this.currentTask = t, this.compound = e.compound, this.sendWebAPI(Ext.apply(e, {
                callback: this.taskDone,
                scope: this
            })))
        },
        taskDone: function(t, e, i) {
            var s, n = this.currentTask.get("config");
            Ext.isFunction(n.callback) && (s = n.callback.call(n.scope || void 0, t, e, i)), !1 !== s && "doing" !== s && (!t || this.compound && e.has_fail ? this.doNextTask(!1) : this.doNextTask(t))
        },
        doNextTask: function(t) {
            var e = this.currentTask,
                i = this.getStore().indexOf(e);
            if (e.setStatus(t ? "done" : "fail"), !this.stopOnFail || t) {
                if (-1 === i) throw Error("can not found index of current task");
                i + 1 < this.getStore().getCount() ? this.doTask(i + 1) : this.finish()
            } else this.finish()
        }
    }), Ext.namespace("SYNO.SDS.Wizard"), SYNO.SDS.Wizard.AppWindow = Ext.extend(SYNO.SDS.AppWindow, {
        constructor: function(t) {
            this.updateDsmStyle(t), this.addClass("sds-wizard-window"), SYNO.SDS.Wizard.AppWindow.superclass.constructor.call(this, this.configWizard(t)), this.getActiveStep() instanceof SYNO.SDS.Wizard.WelcomeStep ? (this.footer.addClass("sds-wizard-footer-welcome"), this.footer.removeClass("sds-wizard-footer")) : (this.footer.removeClass("sds-wizard-footer-welcome"), this.footer.addClass("sds-wizard-footer")), this.stepStack = []
        },
        onOpen: function() {
            SYNO.SDS.Wizard.AppWindow.superclass.onOpen.apply(this, arguments);
            var t = this.getActiveStep();
            t && Ext.isFunction(t.activate) && !1 === t.activate() || this.syncView()
        },
        onClose: function() {
            var t = this.getActiveStep();
            return (!t || !Ext.isFunction(t.deactivate) || !1 !== t.deactivate("close")) && !1 !== SYNO.SDS.Wizard.AppWindow.superclass.onClose.apply(this, arguments)
        },
        configWizard: function(t) {
            var e = {
                buttonAlign: "left",
                footer: !0,
                useStatusBar: !1,
                closable: void 0 === t.closable || t.closable,
                layout: "border",
                defaults: Ext.apply(t.defaults || {}, {
                    owner: this
                }),
                items: [this.configSteps(t.steps)],
                buttons: this.configButtons(t.fbar)
            };
            if (delete t.steps, !1 !== t.banner) {
                var i = this.configBanner(t.banner);
                Ext.isDefined(t.bannerHeadLineHeight) && (i.items[0].height = t.bannerHeadLineHeight), Ext.isDefined(t.bannerDescHeight) && (i.items[1].height = t.bannerDescHeight), i.height = i.minSize = i.maxSize = i.items[0].height + i.items[1].height, e.items.splice(0, 0, i), e.banner = !0
            }
            return Ext.isDefined(t.activeStep) && (e.items[0].activeItem = t.activeStep, delete t.activeStep), Ext.applyIf(e, t), Ext.applyIf(e, {
                resizable: !1,
                maximizable: !1
            }), e
        },
        configBanner: function(t) {
            return Ext.apply({
                itemId: "banner",
                region: "north",
                height: 112,
                minSize: 112,
                maxSize: 112,
                split: !1,
                cls: "sds-wizard-banner-wrap",
                bodyCssClass: "sds-wizard-banner",
                layout: "anchor",
                items: [{
                    xtype: "box",
                    padding: "0px 0px 5px 20px",
                    height: 24,
                    autoHeight: !0,
                    itemId: "headline",
                    border: !1,
                    role: "article",
                    tabIndex: 0,
                    bodyCssClass: "wizard-headline",
                    html: ""
                }, {
                    xtype: "box",
                    padding: "5px 0px 0px 0px",
                    height: 18,
                    autoHeight: !0,
                    itemId: "description",
                    border: !1,
                    role: "article",
                    bodyCssClass: "wizard-description",
                    html: ""
                }]
            }, t)
        },
        setHeadline: function(t) {
            var e = this.getComponent("banner");
            if (e) {
                var i = Ext.util.Format.htmlEncode(t),
                    s = String.format('<div class = "wizard-headline"> {0} </div>', i),
                    n = e.getComponent("headline");
                n.update(s), n.el.set({
                    "aria-label": i
                })
            }
        },
        getHeadLine: function() {
            var t, e;
            return (t = this.getComponent("banner")) && (e = t.getComponent("headline")) ? e.el : null
        },
        setDescription: function(t) {
            var e, i = this.getComponent("banner");
            if (i) {
                var s = Ext.util.Format.htmlEncode(t),
                    n = String.format('<div class = "wizard-description"> {0} </div>', s);
                (e = i.getComponent("description")).update(n), e.el.set({
                    tabIndex: s.length > 0 ? 0 : -1,
                    "aria-label": s
                })
            }
        },
        configSteps: function(t) {
            Ext.isArray(t) && (t = {
                items: t
            });
            if (!t.items) throw Error("invalid config of wizard steps");
            var e = 0,
                i = Ext.applyIf({
                    itemId: "steps",
                    layout: "card",
                    region: "center",
                    border: !1,
                    activeItem: 0,
                    bodyCssClass: "sds-wizard-step",
                    defaults: function(e) {
                        var i = t.defaults;
                        return e.owner = this.owner, Ext.applyIf(e, {
                            border: !1,
                            bwrapCfg: {
                                cls: "x-panel-bwrap sds-wizard-step-bwrap"
                            }
                        }), Ext.isFunction(i) && (i = i.call(this, e)), i
                    }
                }, t);
            for (e = 0; e < i.items.length; e++) Ext.applyIf(i.items[e], {
                nextId: e + 1 < i.items.length ? e + 1 : null,
                getNext: SYNO.SDS.Wizard.Step.prototype.getNext,
                checkState: SYNO.SDS.Wizard.Step.prototype.checkState
            });
            return i
        },
        appendSteps: function(t) {
            var e, i, s, n = this.getComponent("steps"),
                o = [];
            for (Ext.isArray(t) || (t = [t]), s = n.items.length + t.length, e = 0, i = n.items.length; e < t.length; e++, i++) o.push(t[e].itemId || "append" + i), Ext.applyIf(t[e], {
                itemId: "append" + i,
                nextId: i + 1 < s ? "append" + (i + 1) : null,
                getNext: SYNO.SDS.Wizard.Step.prototype.getNext,
                checkState: SYNO.SDS.Wizard.Step.prototype.checkState
            }), n.add(t[e]);
            return n.doLayout(), o
        },
        getStep: function(t) {
            return this.getComponent("steps").getComponent(t)
        },
        getActiveStep: function() {
            var t = this.getComponent("steps");
            if (t) return t.layout.activeItem
        },
        setActiveStep: function(t) {
            var e;
            if (!this.getStep(t)) throw Error("step is not exist, id: " + t);
            return this.getComponent("steps").layout.setActiveItem(t), this.getActiveStep() instanceof SYNO.SDS.Wizard.WelcomeStep ? (this.footer.addClass("sds-wizard-footer-welcome"), this.footer.removeClass("sds-wizard-footer"), this.getActiveStep().getHeadLine().focus()) : (this.footer.removeClass("sds-wizard-footer-welcome"), this.footer.addClass("sds-wizard-footer"), (e = this.getHeadLine()) && e.focus()), !0
        },
        configButtons: function(t) {
            return t || [{
                xtype: "syno_button",
                btnStyle: "grey",
                itemId: "back",
                text: _T("common", "back"),
                handler: function() {
                    Ext.isFunction(this.getActiveStep().getBack) ? this.goBack(this.getActiveStep().getBack()) : this.goBack()
                },
                scope: this
            }, "->", {
                xtype: "syno_button",
                btnStyle: "grey",
                itemId: "cancel",
                text: _T("common", "cancel"),
                handler: this.close,
                scope: this
            }, {
                xtype: "syno_button",
                itemId: "next",
                text: _T("common", "next"),
                btnStyle: "blue",
                handler: function() {
                    this.goNext(this.getActiveStep().getNext())
                },
                scope: this
            }]
        },
        getButton: function(t) {
            return this.getFooterToolbar().getComponent(t)
        },
        goNext: function(t, e) {
            var i, s = null;
            return !1 !== t && (null === t ? (this.close(), !0) : (i = (s = this.getActiveStep()).getItemId(), (!Ext.isFunction(s.deactivate) || !1 !== s.deactivate("next")) && (!1 !== this.setActiveStep(t) && (!1 !== e && this.stepStack.push(i), s = this.getActiveStep(), (!Ext.isFunction(s.activate) || !1 !== s.activate()) && (this.syncView(), !0)))))
        },
        goBack: function(t) {
            var e, i = null;
            if (!1 === t || !this.hasHistory()) return !1;
            if (Ext.isDefined(t) && !this.inHistory(t)) return !1;
            if (i = this.getActiveStep(), Ext.isFunction(i.deactivate) && !1 === i.deactivate("back")) return !1;
            if (e = this.stepStack.pop(), Ext.isDefined(t) || (t = e), !1 === this.setActiveStep(t)) return this.stepStack.push(e), !1;
            for (; e !== t;) e = this.stepStack.pop();
            return i = this.getActiveStep(), (!Ext.isFunction(i.activate) || !1 !== i.activate()) && (this.syncView(), !0)
        },
        inHistory: function(t) {
            for (var e = this.stepStack.length - 1; e >= 0; e--)
                if (this.stepStack[e] === t) return !0;
            return !1
        },
        hasHistory: function() {
            return this.stepStack.length > 0
        },
        syncView: function() {
            var t = this.getActiveStep();
            t && (Ext.isFunction(t.checkState) && t.checkState(), this.banner && (this.setHeadline(t.headline || ""), this.setDescription(t.description || "")))
        }
    }), SYNO.SDS.Wizard.ModalWindow = Ext.extend(SYNO.SDS.ModalWindow, {
        constructor: function(t) {
            this.updateDsmStyle(t), SYNO.SDS.Wizard.ModalWindow.superclass.constructor.call(this, this.configWizard(t)), this.stepStack = [], this.addClass("sds-wizard-window"), this.getActiveStep() instanceof SYNO.SDS.Wizard.WelcomeStep ? (this.footer.addClass("sds-wizard-footer-welcome"), this.footer.removeClass("sds-wizard-footer")) : (this.footer.removeClass("sds-wizard-footer-welcome"), this.footer.addClass("sds-wizard-footer"))
        },
        onOpen: function() {
            SYNO.SDS.Wizard.ModalWindow.superclass.onOpen.apply(this, arguments);
            var t = this.getActiveStep();
            t && Ext.isFunction(t.activate) && !1 === t.activate() || this.syncView()
        },
        onClose: function() {
            var t = this.getActiveStep();
            return !(!t || !Ext.isFunction(t.deactivate) || !1 !== t.deactivate("close")) || !1 !== SYNO.SDS.Wizard.ModalWindow.superclass.onClose.apply(this, arguments)
        },
        setMaskMsgVisible: function(t) {
            if (this.el.isMasked()) {
                var e = Ext.Element.data(this.el, "maskMsg");
                e && e.dom && (e.setVisibilityMode(Ext.Element.VISIBILITY), e.setVisible(t))
            }
        },
        setMaskOpacity: function(t) {
            SYNO.SDS.AppWindow.superclass.setMaskOpacity.call(this, t), this.setMaskMsgVisible(0 !== t)
        },
        delayedMask: function(t, e, i, s) {
            e = e || 200, this.maskTask || (this.maskTask = new Ext.util.DelayedTask(this.setMaskOpacity, this, [t])), this.mask(0, i, s), this.setMaskMsgVisible(!1), this.maskTask.delay(e)
        },
        synchronizedMask: function(t, e, i) {
            this.mask(t, e, i), this.setMaskMsgVisible(0 !== t)
        },
        setStatusBusy: function(t, e, i) {
            t = t || {}, Ext.applyIf(t, {
                text: _T("common", "loading"),
                iconCls: "x-mask-loading"
            }), e = Ext.isNumber(e) ? e : .4, (i = Ext.isNumber(i) ? i : 400) > 0 ? this.delayedMask(e, i, t.text, t.iconCls) : this.synchronizedMask(e, t.text, t.iconCls)
        },
        setStatusError: function(t) {
            t = t || {}, Ext.applyIf(t, {
                text: _T("common", "error_system")
            }), this.getMsgBox().alert(_T("error", "error_error"), t.text)
        },
        configWizard: SYNO.SDS.Wizard.AppWindow.prototype.configWizard,
        configBanner: SYNO.SDS.Wizard.AppWindow.prototype.configBanner,
        setHeadline: SYNO.SDS.Wizard.AppWindow.prototype.setHeadline,
        setDescription: SYNO.SDS.Wizard.AppWindow.prototype.setDescription,
        configSteps: SYNO.SDS.Wizard.AppWindow.prototype.configSteps,
        appendSteps: SYNO.SDS.Wizard.AppWindow.prototype.appendSteps,
        getStep: SYNO.SDS.Wizard.AppWindow.prototype.getStep,
        getActiveStep: SYNO.SDS.Wizard.AppWindow.prototype.getActiveStep,
        setActiveStep: SYNO.SDS.Wizard.AppWindow.prototype.setActiveStep,
        configButtons: SYNO.SDS.Wizard.AppWindow.prototype.configButtons,
        getButton: SYNO.SDS.Wizard.AppWindow.prototype.getButton,
        goNext: SYNO.SDS.Wizard.AppWindow.prototype.goNext,
        goBack: SYNO.SDS.Wizard.AppWindow.prototype.goBack,
        inHistory: SYNO.SDS.Wizard.AppWindow.prototype.inHistory,
        hasHistory: SYNO.SDS.Wizard.AppWindow.prototype.hasHistory,
        syncView: SYNO.SDS.Wizard.AppWindow.prototype.syncView,
        getHeadLine: SYNO.SDS.Wizard.AppWindow.prototype.getHeadLine
    }), Ext.define("SYNO.SDS._FocusMgr", {
        extend: "Ext.util.Observable",
        constructor: function() {
            Ext.isIE ? document.onfocusin = this.onFocusChange : document.addEventListener("focus", this.onFocusChange, !0), this.callParent(arguments)
        },
        onFocusChange: function() {
            var t = SYNO.SDS.WindowMgr.getActiveAppWindow();
            t && t.addFocusPt()
        },
        focusActiveWindow: function() {
            var t = SYNO.SDS.WindowMgr.getActiveAppWindow();
            t && t.focusLastWindowPt()
        }
    }), Ext.define("SYNO.SDS.About.Window", {
        extend: "SYNO.SDS.ModalWindow",
        constructor: function(t) {
            var e = {
                title: _T("personal_settings", "about"),
                cls: "sds-user-about-window x-window-dlg",
                closable: !1,
                useStatusBar: !1,
                maximizable: !1,
                minimizable: !1,
                resizable: !1,
                header: !1,
                width: 480,
                draggable: !1,
                height: 240,
                elements: "body",
                renderTo: Ext.getBody(),
                padding: "20px 20px 0px 20px",
                items: this.configureItems(),
                footerStyle: "padding: 0 0 20px 0",
                modal: !1,
                ownerMasked: !0,
                fbar: {
                    buttonAlign: "center",
                    items: new SYNO.ux.Button({
                        text: _T("common", "ok"),
                        handler: this.close,
                        scope: this
                    })
                },
                listeners: {
                    show: {
                        fn: this.onAfterShow,
                        scope: this
                    },
                    beforeclose: {
                        fn: this.onBeforeClose,
                        scope: this
                    }
                }
            };
            Ext.apply(e, t), this.callParent([e]), Ext.EventManager.onWindowResize(this.onBrowserWinResize, this)
        },
        onAfterShow: function() {
            SYNO.SDS.Desktop.el.setStyle("zIndex", 0), Ext.getBody().mask().addClass("sds-user-about-mask")
        },
        onBrowserWinResize: function() {
            this.center()
        },
        onBeforeClose: function() {
            Ext.EventManager.removeResizeListener(this.onBrowserWinResize, this), Ext.getBody().unmask(), SYNO.SDS.Desktop.el.setStyle("zIndex", "")
        },
        configureItems: function() {
            return [{
                xtype: "box",
                tabIndex: 0,
                role: "article",
                cls: "sds-user-about-desc",
                html: _T("personal_settings", "about_desc")
            }, {
                xtype: "box",
                cls: "sds-user-about-terms-and-cond",
                html: _T("personal_settings", "terms_and_conditions")
            }]
        }
    }), Ext.define("SYNO.SDS._System", {
        extend: "Ext.Component",
        isDifferentNode: !1,
        nodeData: {},
        Reboot: function() {
            SYNO.SDS.System.RebootWithMsg()
        },
        RebootWithNode: function(t) {
            this.nodeData = t, this.isDifferentNode = t && t.isDifferentNode;
            var e = "ha" == this.nodeData.node ? this.nodeData.msg.reboot.ha : "active" == this.nodeData.node ? this.nodeData.msg.reboot.active : this.nodeData.msg.reboot.passive;
            SYNO.SDS.System.RebootMsgBox(e)
        },
        RebootWithMsg: function(t) {
            var e = SYNO.SDS.System;
            "yes" !== _D("support_dual_head", "no") ? _S("ha_running") && !0 !== _S("ha_running_xa") ? e._launchHA() : _S("ha_running_xa") ? SYNO.SDS.RebootPowerOff.HAShow(this, "reboot", function(t) {
                var e = {
                    isDifferentNode: !1,
                    node: "ha",
                    type: "reboot",
                    msg: t.msg,
                    can_switchover: t.can_switchover
                };
                SYNO.SDS.System.RebootWithNode(e)
            }) : SYNO.SDS.System.RebootMsgBox(t) : e._launchAHA()
        },
        RebootMsgBox: function(t) {
            var e = SYNO.SDS.System;
            SYNO.SDS.Desktop.hide(), e.getMsgBox().confirm(_D("product"), t || _JSLIBSTR("uicommon", "reboot_warn"), function(t) {
                "yes" === t ? e._rebootSystem(!1) : "no" === t && SYNO.SDS.Desktop.show()
            }, e)
        },
        PowerOff: function() {
            SYNO.SDS.System.PowerOffWithMsg()
        },
        PowerOffWithNode: function(t) {
            this.nodeData = t, this.isDifferentNode = t && t.isDifferentNode;
            var e = "ha" === this.nodeData.node ? this.nodeData.msg.shutdown.ha : "active" == this.nodeData.node ? this.nodeData.msg.shutdown.active : this.nodeData.msg.shutdown.passive;
            SYNO.SDS.System.PowerOffMsgBox(e)
        },
        PowerOffWithMsg: function(t) {
            var e = SYNO.SDS.System;
            "yes" !== _D("support_dual_head", "no") ? _S("ha_running") && !0 !== _S("ha_running_xa") ? e._launchHA() : _S("ha_running_xa") ? SYNO.SDS.RebootPowerOff.HAShow(this, "reboot", function(t) {
                var e = {
                    isDifferentNode: !1,
                    node: "ha",
                    type: "poweroff",
                    msg: t.msg,
                    can_switchover: t.can_switchover
                };
                SYNO.SDS.System.PowerWithNode(e)
            }) : SYNO.SDS.System.PowerOffMsgBox(t) : e._launchAHA()
        },
        PowerOffMsgBox: function(t) {
            var e = SYNO.SDS.System;
            SYNO.SDS.Desktop.hide(), e.getMsgBox().confirm(_D("product"), t || _JSLIBSTR("uicommon", "shutdown_warn"), function(t) {
                "yes" === t ? e._shutdownSystem(!1) : "no" === t && SYNO.SDS.Desktop.show()
            }, e)
        },
        WaitForBootUp: function() {
            SYNO.SDS.Desktop.hide(), SYNO.SDS.System._rebootSystem(!1, !1, !0)
        },
        Logout: function() {
            SYNO.SDS.StatusNotifier.fireEvent("logout"), window.onbeforeunload = SYNO.SDS.onBasicBeforeUnload;
            try {
                SYNO.SDS.Utils.Logout.action()
            } catch (t) {}
        },
        About: function() {
            (new SYNO.SDS.About.Window).show()
        },
        _launchHA: function() {
            SYNO.SDS.System.getMsgBox().confirm(_D("product"), _TT("SYNO.SDS.HA.Instance", "ui", "warning_forbid_power_option"), function(t) {
                "yes" === t && SYNO.SDS.AppLaunch("SYNO.SDS.HA.Instance")
            })
        },
        _launchAHA: function() {
            SYNO.SDS.System.getMsgBox().confirm(_D("product"), _TT("SYNO.SDS.AHA.Instance", "uicommon", "warning_forbid_power_option"), function(t) {
                "yes" === t && SYNO.SDS.AppLaunch("SYNO.SDS.AHA.Instance")
            })
        },
        _waitHAStatus: function() {
            var t = this,
                e = t.addTask({
                    interval: 5e3,
                    run: function() {
                        t.sendWebAPI({
                            api: "SYNO.SHA.Panel.Overview",
                            version: 1,
                            method: "load",
                            scope: this,
                            callback: function(i, s, n) {
                                i && s ? !0 !== s.ha.passive_is_rebooting_triggered_by_webapi && !0 !== s.ha.passive_is_shutting_down_triggered_by_webapi && "desc_passive_offline" !== s.ha.description[0] || (t.getMsgBox().hide(), SYNO.SDS.Desktop.show(), e.stop()) : e.stop()
                            }
                        })
                    }
                }).start()
        },
        _rebootSystem: function(t, e, i) {
            var s, n = !0 === i ? _T("login", "error_system_getting_ready") : _JSLIBSTR("uicommon", "system_reboot").replace(/_DISKSTATION_/g, _D("product"));
            this.isDifferentNode ? n = _TT("SYNO.SDS.HA.Instance", "ui", "rebooting_" + this.nodeData.node) : _S("ha_running_xa") && "active" === this.nodeData.node && this.nodeData.can_switchover && "poweroff" === this.nodeData.type && (n = this.nodeData.msg.shutting_down.active), this.getMsgBox().show({
                wait: !0,
                closable: !1,
                maxWidth: 300,
                title: _D("product"),
                msg: n
            }), s = !1 === t && !1 === e ? "skip_cmd" : "reboot", _S("ha_running_xa") && "poweroff" === this.nodeData.type && "active" === this.nodeData.node && this.nodeData.can_switchover && (s = "shutdown"), this._haltSystem(s, t, function() {
                var t, e = 0,
                    i = 2;
                this.isDifferentNode ? this._waitHAStatus() : ("skip_cmd" === s && (e = 2), _S("ha_running_xa") && (i = 1), t = this.addAjaxTask({
                    preventHalt: !0,
                    interval: 5e3,
                    autoJsonDecode: !0,
                    url: "webman/pingpong.cgi",
                    startTime: (new Date).getTime(),
                    timeLimit: 6e5,
                    scope: this,
                    success: function(s, n) {
                        e < i ? e = 0 : s && s.boot_done && (t.stop(), window.location.href = "/")
                    },
                    failure: function(t, i) {
                        var s = (new Date).getTime();
                        !i.timeoutNotified && s - i.startTime > i.timeLimit && (this.getMsgBox().show({
                            closable: !1,
                            maxWidth: 300,
                            title: _D("product"),
                            msg: _JSLIBSTR("uicommon", "system_reboot_timeout").replace(/_DISKSTATION_/g, _D("product"))
                        }), i.timeoutNotified = !0), e++
                    }
                }).start())
            }, this)
        },
        _shutdownSystem: function(t) {
            if (!this.isDifferentNode) {
                if (_S("ha_running_xa") && "active" === this.nodeData.node && this.nodeData.can_switchover) return this._rebootSystem(t);
                this.getMsgBox().show({
                    closable: !1,
                    maxWidth: 300,
                    title: _D("product"),
                    msg: _JSLIBSTR("uicommon", "system_poweroff").replace(/_DISKSTATION_/g, _D("product"))
                })
            }
            this._haltSystem("shutdown", t, function() {
                if (this.isDifferentNode) return this.getMsgBox().show({
                    wait: !0,
                    closable: !1,
                    maxWidth: 300,
                    title: _D("product"),
                    msg: _TT("SYNO.SDS.HA.Instance", "ui", "shutting_down_" + this.nodeData.node + "_desc")
                }), void this._waitHAStatus()
            }, this)
        },
        _confirmCache: function() {
            if (!1 !== SYNO.SDS.UserSettings.getProperty("Personal", "cacheShutdownQuery")) {
                var t, e, i = Ext.id();
                this.getMsgBox().hide(), e = '&nbsp<a class="link-font" id="' + i + '" href="#">' + _T("volume", "storage_manager") + " </a>", (t = new SYNO.SDS.CacheConfirmMessage({
                    modal: !0,
                    draggable: !1,
                    renderTo: document.body,
                    scope: this
                })).showMsg({
                    title: _D("product"),
                    msg: String.format(_T("volume", "cache_shutdown_warn"), e) + "</br>",
                    buttons: {
                        ok: _T("volume", "cache_shutdown"),
                        cancel: !0
                    },
                    icon: Ext.MessageBox.WARNING,
                    fn: function(e) {
                        "ok" === e ? (t.checkbox.checked && SYNO.SDS.UserSettings.setProperty("Personal", "cacheShutdownQuery", !1), this._shutdownSystem(!0)) : SYNO.SDS.Desktop.show()
                    },
                    closable: !1,
                    minWidth: 250,
                    scope: this
                }), this.mon(Ext.fly(i), "click", function() {
                    SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance", Ext.apply({}, {
                        fn: "SYNO.SDS.StorageManager.SsdCache.Main"
                    })), t.close(), SYNO.SDS.Desktop.show()
                }, this, {
                    single: !0
                })
            } else this._shutdownSystem(!0)
        },
        _haltSystem: function(t, e, i, s) {
            if ("skip_cmd" !== (t = t || "reboot")) {
                var n = "SYNO.Core.System",
                    o = t,
                    r = {
                        force: !!e,
                        local: !0,
                        cache_check_shutdown: "shutdown" === t
                    };
                _S("ha_running_xa") && (n = "SYNO.SHA.Panel.Action", o = "active" === this.nodeData.node ? t + "_active" : "ha" === this.nodeData.node ? t + "_ha" : t + "_passive", r.mode = o), SYNO.API.Request({
                    api: n,
                    method: o,
                    version: 1,
                    relay_node: this.nodeData.node,
                    params: r,
                    callback: function(e, n) {
                        var o = "reboot" === t ? _T("system", "running_tasks_confirm_reboot") : _T("system", "running_tasks_confirm_shutdown");
                        if (_S("ha_running_xa") && e && !1 === n.success) {
                            var r = SYNO.SDS.HA.GenErrMsg(n.errinfo, this);
                            this.getMsgBox().alert(_D("product"), r, function(t) {
                                SYNO.SDS.Desktop.show()
                            }, this)
                        } else {
                            var a = n.errors;
                            if (!1 === e && a.blockingTasks) {
                                var l = this.getTasks(a.blockingTasks);
                                this.getMsgBox().alert(_D("product"), _T("system", "running_tasks_warning") + "<br><br>" + l + "<br><br>" + _T("system", "try_later_warning"), function(t) {
                                    SYNO.SDS.Desktop.show()
                                }, this)
                            } else {
                                if (!1 === e && a.runningTasks) {
                                    var c, d = a.runningTasks,
                                        u = 0 <= d.indexOf("volume:cache_shutdown_warn");
                                    return d.remove("volume:cache_shutdown_warn"), void(0 < d.length ? (c = this.getTasks(d), this.getMsgBox().confirm(_D("product"), o + "<br><br>" + c, function(e) {
                                        "yes" === e ? "shutdown" === t ? u ? this._confirmCache() : this._shutdownSystem(!0) : this._rebootSystem(!0) : "no" === e && SYNO.SDS.Desktop.show()
                                    }, this)) : "shutdown" === t ? this._confirmCache() : this._rebootSystem(!0))
                                }
                                this._beforeHaltSystem(i, s)
                            }
                        }
                    },
                    scope: this
                })
            } else this._beforeHaltSystem(i, s)
        },
        CountCharInStr: function(t, e) {
            var i = 0,
                s = 0;
            for (s = 0; s < t.length; ++s) e == t[s] && i++;
            return i
        },
        getTasks: function(t) {
            var e, i, s = [];
            return Ext.each(t, function(t) {
                if (-1 === t.indexOf(":")) s.push(t);
                else {
                    if (e = t.split(":"), 1 === this.CountCharInStr(t, ":")) i = 0 === _T(e[0], e[1]).length ? _JSLIBSTR(e[0], e[1]) : _T(e[0], e[1]);
                    else {
                        if (2 !== this.CountCharInStr(t, ":")) return !0;
                        i = _TT(e[0], e[1], e[2])
                    }
                    s.push(i)
                }
            }, this), s.join("<br> ")
        },
        getMsgBox: function(t) {
            var e = SYNO.SDS.System;
            return e.msgBox && !e.msgBox.isDestroyed || (e.msgBox = new SYNO.SDS.MessageBoxV5({
                modal: !0,
                draggable: !1,
                renderTo: document.body
            })), e.msgBox.getWrapper()
        },
        _beforeHaltSystem: function(t, e) {
            this.isDifferentNode || (SYNO.SDS.StatusNotifier.fireEvent("halt"), window.onbeforeunload = null), t && t.apply(e)
        }
    }), Ext.define("SYNO.SDS.CacheConfirmMessage", {
        extend: "SYNO.SDS.MessageBoxV5",
        checkbox: null,
        onRender: function() {
            this.callParent(arguments), this.checkbox = new SYNO.ux.Checkbox({
                xtype: "syno_checkbox",
                htmlEncode: !1,
                boxLabel: _T("volume", "cache_shutdown_remind"),
                renderTo: this.bodyEl,
                wrapCls: "syno-ux-form-check-wrap cache-confirm-checkbox",
                scope: this
            }), this.addManagedComponent(this.checkbox)
        }
    }), Ext.define("SYNO.SDS.AboutWindow", {
        extend: "SYNO.SDS.ModalWindow",
        isBeta: !1,
        constructor: function(t) {
            var e, i, s, n, o;
            if (!t || !t.owner) throw "No Owner!";
            e = t.owner.appInstance.jsConfig, n = t.owner.isBeta || this.isBeta, o = e.buildTime ? Date.parseDate(e.buildTime, "Y-m-d") : Date.parseDate(_S("builddate"), "Y/m/d"), s = n ? String.format('<span class="pkg-name" style="color: {0}">{1}</span>', t.pkgColor, SYNO.SDS.Utils.GetLocalizedString(e.title, e.jsID)) + '<span class="beta-icon"></span>' : String.format('<span class="pkg-name" style="color: {0}">{1}</span>', t.pkgColor, SYNO.SDS.Utils.GetLocalizedString(e.title, e.jsID)), i = {
                cls: "about-window",
                layout: "border",
                closable: !0,
                resizable: !1,
                draggable: !1,
                width: 450,
                height: 190,
                header: !1,
                useStatusBar: !1,
                closeAction: "hide",
                items: [{
                    xtype: "box",
                    region: "west",
                    width: 144,
                    cls: "about-west",
                    html: String.format('<img alt="" src="{0}" width="96" height="96">', e.jsBaseURL + "/" + String.format(e.icon, 256, SYNO.SDS.UIFeatures.test("isRetina") ? "2x" : "1x"))
                }, {
                    xtype: "container",
                    region: "center",
                    items: [{
                        xtype: "box",
                        cls: "about-syno",
                        html: Ext.isEmpty(t.aboutHeader) ? "Synology" : t.aboutHeader
                    }, {
                        xtype: "box",
                        cls: "about-pkgname",
                        html: s
                    }, {
                        xtype: "box",
                        cls: "about-version",
                        html: String.format("<b>{0}: </b>{1}", _T("nfs", "nfs_key_version"), e.version)
                    }, {
                        xtype: "box",
                        cls: "about-ip",
                        html: String.format("<b>{0}: </b>{1}", _T("common", "osname"), _S("productversion") + "-" + _S("version"))
                    }]
                }],
                bbar: [{
                    xtype: "box",
                    cls: "about-copyright",
                    width: 402,
                    html: String.format(_T("copyright", "copyright"), o.getUTCFullYear())
                }]
            }, Ext.apply(i, t), this.callParent([i])
        }
    }), Ext.define("SYNO.SDS.ToastBox", {
        extend: "Ext.BoxComponent",
        actionTextEl: null,
        alignEl: null,
        closeBtnEl: null,
        closable: "",
        actionHandler: Ext.emptyFn,
        actionHandlerScope: null,
        delay: 3e3,
        offsetY: 0,
        offsetX: 0,
        constructor: function(t) {
            t.owner || SYNO.Debug("owner required"), !0 === t.alignBottom ? this.offsetY = 0 : this.offsetY = 36;
            var e = '<div class="content">{0}{1}{2}</div>',
                i = "",
                s = "",
                n = "";
            !0 === t.closable && (n = '<div id={0} class="close-btn" role="button" aria-label="{1}" tabIndex="0"></div>', n = String.format(n, this.closeBtnId = Ext.id(), _T("common", "close"))), Ext.isString(t.text) && (i = '<span id={0} class="text">{1} </span>', i = String.format(i, this.textId = Ext.id(), t.text)), Ext.isString(t.actionText) && (s = '<span id={0} class="action-text" role="button" aria-label="{1}" tabIndex="0">{1}</span>', s = String.format(s, this.actionTextId = Ext.id(), t.actionText));
            var o = {
                cls: "syno-sds-toast-box",
                html: e = String.format(e, i, s, n),
                renderTo: t.owner.id,
                listeners: {
                    afterrender: {
                        fn: this.defineToastBoxBehavior,
                        scope: this,
                        single: !0
                    },
                    beforedestroy: {
                        fn: this.unbindEvents,
                        scope: this
                    }
                }
            };
            Ext.apply(o, t), this.callParent([o])
        },
        defineToastBoxBehavior: function() {
            this.alignBox(), Ext.isNumber(this.delay) && -1 !== this.delay && this.destroyBox.defer(this.delay, this), this.bindEvents()
        },
        alignBox: function() {
            var t = "t-t";
            this.alignBottom && (t = "b-b"), this.getEl().alignTo(this.alignEl || this.owner.getEl(), t, [this.offsetX, this.offsetY])
        },
        bindEvents: function() {
            this.closeBtnEl = Ext.get(this.closeBtnId), this.closeBtnEl && (this.closeBtnEl.on("click", this.destroyBox, this), this.closeBtnEl.addKeyListener(Ext.EventObject.ENTER, this.destroyBox, this), this.closeBtnEl.addKeyListener(Ext.EventObject.SPACE, this.destroyBox, this)), this.actionTextEl = Ext.get(this.actionTextId), this.actionTextEl && (this.actionTextEl.on("click", this.actionHandler.createSequence(this.destroyBox, this), this.actionHandlerScope || this), this.actionTextEl.addKeyListener(Ext.EventObject.ENTER, this.actionHandler.createSequence(this.destroyBox, this), this.actionHandlerScope || this), this.actionTextEl.addKeyListener(Ext.EventObject.SPACE, this.actionHandler.createSequence(this.destroyBox, this), this.actionHandlerScope || this))
        },
        unbindEvents: function() {
            this.closeBtnEl && this.closeBtnEl.un("click", this.destroyBox, this), this.actionTextEl && this.actionTextEl.un("click", this.actionHandler.createSequence(this.destroyBox), this.actionHandlerScope || this)
        },
        destroyBox: function() {
            this.destroy()
        }
    }),
    /*!
     * clipboard.js v1.5.5
     * https://zenorocha.github.io/clipboard.js
     *
     * Licensed MIT © Zeno Rocha
     */
    Ext.isIE8 || function(t) {
        if ("object" === ("undefined" == typeof exports ? "undefined" : _typeof(exports)) && "undefined" != typeof module) module.exports = t();
        else if ("function" == typeof define && define.amd) define([], t);
        else {
            ("undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : this).Clipboard = t()
        }
    }(function() {
        return function t(e, i, s) {
            function n(r, a) {
                if (!i[r]) {
                    if (!e[r]) {
                        var l = "function" == typeof require && require;
                        if (!a && l) return l(r, !0);
                        if (o) return o(r, !0);
                        var c = new Error("Cannot find module '" + r + "'");
                        throw c.code = "MODULE_NOT_FOUND", c
                    }
                    var d = i[r] = {
                        exports: {}
                    };
                    e[r][0].call(d.exports, function(t) {
                        var i = e[r][1][t];
                        return n(i || t)
                    }, d, d.exports, t, e, i, s)
                }
                return i[r].exports
            }
            for (var o = "function" == typeof require && require, r = 0; r < s.length; r++) n(s[r]);
            return n
        }({
            1: [function(t, e, i) {
                var s = t("matches-selector");
                e.exports = function(t, e, i) {
                    for (var n = i ? t : t.parentNode; n && n !== document;) {
                        if (s(n, e)) return n;
                        n = n.parentNode
                    }
                }
            }, {
                "matches-selector": 2
            }],
            2: [function(t, e, i) {
                var s = Element.prototype,
                    n = s.matchesSelector || s.webkitMatchesSelector || s.mozMatchesSelector || s.msMatchesSelector || s.oMatchesSelector;
                e.exports = function(t, e) {
                    if (n) return n.call(t, e);
                    for (var i = t.parentNode.querySelectorAll(e), s = 0; s < i.length; ++s)
                        if (i[s] == t) return !0;
                    return !1
                }
            }, {}],
            3: [function(t, e, i) {
                var s = t("closest");
                e.exports = function(t, e, i, n) {
                    var o = function(t, e, i, n) {
                        return function(i) {
                            i.delegateTarget = s(i.target, e, !0), i.delegateTarget && n.call(t, i)
                        }
                    }.apply(this, arguments);
                    return t.addEventListener(i, o), {
                        destroy: function() {
                            t.removeEventListener(i, o)
                        }
                    }
                }
            }, {
                closest: 1
            }],
            4: [function(t, e, i) {
                i.node = function(t) {
                    return void 0 !== t && t instanceof HTMLElement && 1 === t.nodeType
                }, i.nodeList = function(t) {
                    var e = Object.prototype.toString.call(t);
                    return void 0 !== t && ("[object NodeList]" === e || "[object HTMLCollection]" === e) && "length" in t && (0 === t.length || i.node(t[0]))
                }, i.string = function(t) {
                    return "string" == typeof t || t instanceof String
                }, i.function = function(t) {
                    return "[object Function]" === Object.prototype.toString.call(t)
                }
            }, {}],
            5: [function(t, e, i) {
                var s = t("./is"),
                    n = t("delegate");
                e.exports = function(t, e, i) {
                    if (!t && !e && !i) throw new Error("Missing required arguments");
                    if (!s.string(e)) throw new TypeError("Second argument must be a String");
                    if (!s.function(i)) throw new TypeError("Third argument must be a Function");
                    if (s.node(t)) return function(t, e, i) {
                        return t.addEventListener(e, i), {
                            destroy: function() {
                                t.removeEventListener(e, i)
                            }
                        }
                    }(t, e, i);
                    if (s.nodeList(t)) return function(t, e, i) {
                        return Array.prototype.forEach.call(t, function(t) {
                            t.addEventListener(e, i)
                        }), {
                            destroy: function() {
                                Array.prototype.forEach.call(t, function(t) {
                                    t.removeEventListener(e, i)
                                })
                            }
                        }
                    }(t, e, i);
                    if (s.string(t)) return function(t, e, i) {
                        return n(document.body, t, e, i)
                    }(t, e, i);
                    throw new TypeError("First argument must be a String, HTMLElement, HTMLCollection, or NodeList")
                }
            }, {
                "./is": 4,
                delegate: 3
            }],
            6: [function(t, e, i) {
                e.exports = function(t) {
                    var e;
                    if ("INPUT" === t.nodeName || "TEXTAREA" === t.nodeName) t.focus(), t.setSelectionRange(0, t.value.length), e = t.value;
                    else {
                        t.hasAttribute("contenteditable") && t.focus();
                        var i = window.getSelection(),
                            s = document.createRange();
                        s.selectNodeContents(t), i.removeAllRanges(), i.addRange(s), e = i.toString()
                    }
                    return e
                }
            }, {}],
            7: [function(t, e, i) {
                function s() {}
                s.prototype = {
                    on: function(t, e, i) {
                        var s = this.e || (this.e = {});
                        return (s[t] || (s[t] = [])).push({
                            fn: e,
                            ctx: i
                        }), this
                    },
                    once: function(t, e, i) {
                        var s = this;

                        function n() {
                            s.off(t, n), e.apply(i, arguments)
                        }
                        return n._ = e, this.on(t, n, i)
                    },
                    emit: function(t) {
                        for (var e = [].slice.call(arguments, 1), i = ((this.e || (this.e = {}))[t] || []).slice(), s = 0, n = i.length; s < n; s++) i[s].fn.apply(i[s].ctx, e);
                        return this
                    },
                    off: function(t, e) {
                        var i = this.e || (this.e = {}),
                            s = i[t],
                            n = [];
                        if (s && e)
                            for (var o = 0, r = s.length; o < r; o++) s[o].fn !== e && s[o].fn._ !== e && n.push(s[o]);
                        return n.length ? i[t] = n : delete i[t], this
                    }
                }, e.exports = s
            }, {}],
            8: [function(t, e, i) {
                "use strict";
                i.__esModule = !0;
                var s = function() {
                    function t(t, e) {
                        for (var i = 0; i < e.length; i++) {
                            var s = e[i];
                            s.enumerable = s.enumerable || !1, s.configurable = !0, "value" in s && (s.writable = !0), Object.defineProperty(t, s.key, s)
                        }
                    }
                    return function(e, i, s) {
                        return i && t(e.prototype, i), s && t(e, s), e
                    }
                }();
                var n, o = t("select"),
                    r = (n = o) && n.__esModule ? n : {
                        default: n
                    },
                    a = function() {
                        function t(e) {
                            ! function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, t), this.resolveOptions(e), this.initSelection()
                        }
                        return t.prototype.resolveOptions = function() {
                            var t = arguments.length <= 0 || void 0 === arguments[0] ? {} : arguments[0];
                            this.action = t.action, this.emitter = t.emitter, this.target = t.target, this.text = t.text, this.trigger = t.trigger, this.selectedText = ""
                        }, t.prototype.initSelection = function() {
                            if (this.text && this.target) throw new Error('Multiple attributes declared, use either "target" or "text"');
                            if (this.text) this.selectFake();
                            else {
                                if (!this.target) throw new Error('Missing required attributes, use either "target" or "text"');
                                this.selectTarget()
                            }
                        }, t.prototype.selectFake = function() {
                            var t = this;
                            this.removeFake(), this.fakeHandler = document.body.addEventListener("click", function() {
                                return t.removeFake()
                            }), this.fakeElem = document.createElement("textarea"), this.fakeElem.style.position = "absolute", this.fakeElem.style.left = "-9999px", this.fakeElem.style.top = (window.pageYOffset || document.documentElement.scrollTop) + "px", this.fakeElem.setAttribute("readonly", ""), this.fakeElem.value = this.text, document.body.appendChild(this.fakeElem), this.selectedText = r.default(this.fakeElem), this.copyText()
                        }, t.prototype.removeFake = function() {
                            this.fakeHandler && (document.body.removeEventListener("click"), this.fakeHandler = null), this.fakeElem && (document.body.removeChild(this.fakeElem), this.fakeElem = null)
                        }, t.prototype.selectTarget = function() {
                            this.selectedText = r.default(this.target), this.copyText()
                        }, t.prototype.copyText = function() {
                            var t = void 0;
                            try {
                                t = document.execCommand(this.action)
                            } catch (e) {
                                t = !1
                            }
                            this.handleResult(t)
                        }, t.prototype.handleResult = function(t) {
                            t ? this.emitter.emit("success", {
                                action: this.action,
                                text: this.selectedText,
                                trigger: this.trigger,
                                clearSelection: this.clearSelection.bind(this)
                            }) : this.emitter.emit("error", {
                                action: this.action,
                                trigger: this.trigger,
                                clearSelection: this.clearSelection.bind(this)
                            })
                        }, t.prototype.clearSelection = function() {
                            this.target && this.target.blur(), window.getSelection().removeAllRanges()
                        }, t.prototype.destroy = function() {
                            this.removeFake()
                        }, s(t, [{
                            key: "action",
                            set: function() {
                                var t = arguments.length <= 0 || void 0 === arguments[0] ? "copy" : arguments[0];
                                if (this._action = t, "copy" !== this._action && "cut" !== this._action) throw new Error('Invalid "action" value, use either "copy" or "cut"')
                            },
                            get: function() {
                                return this._action
                            }
                        }, {
                            key: "target",
                            set: function(t) {
                                if (void 0 !== t) {
                                    if (!t || "object" !== _typeof(t) || 1 !== t.nodeType) throw new Error('Invalid "target" value, use a valid Element');
                                    this._target = t
                                }
                            },
                            get: function() {
                                return this._target
                            }
                        }]), t
                    }();
                i.default = a, e.exports = i.default
            }, {
                select: 6
            }],
            9: [function(t, e, i) {
                "use strict";

                function s(t) {
                    return t && t.__esModule ? t : {
                        default: t
                    }
                }
                i.__esModule = !0;
                var n = s(t("./clipboard-action")),
                    o = s(t("tiny-emitter")),
                    r = s(t("good-listener")),
                    a = function(t) {
                        function e(i, s) {
                            ! function(t, e) {
                                if (!(t instanceof e)) throw new TypeError("Cannot call a class as a function")
                            }(this, e), t.call(this), this.resolveOptions(s), this.listenClick(i)
                        }
                        return function(t, e) {
                            if ("function" != typeof e && null !== e) throw new TypeError("Super expression must either be null or a function, not " + _typeof(e));
                            t.prototype = Object.create(e && e.prototype, {
                                constructor: {
                                    value: t,
                                    enumerable: !1,
                                    writable: !0,
                                    configurable: !0
                                }
                            }), e && (Object.setPrototypeOf ? Object.setPrototypeOf(t, e) : t.__proto__ = e)
                        }(e, t), e.prototype.resolveOptions = function() {
                            var t = arguments.length <= 0 || void 0 === arguments[0] ? {} : arguments[0];
                            this.action = "function" == typeof t.action ? t.action : this.defaultAction, this.target = "function" == typeof t.target ? t.target : this.defaultTarget, this.text = "function" == typeof t.text ? t.text : this.defaultText
                        }, e.prototype.listenClick = function(t) {
                            var e = this;
                            this.listener = r.default(t, "click", function(t) {
                                return e.onClick(t)
                            })
                        }, e.prototype.onClick = function(t) {
                            var e = t.delegateTarget || t.currentTarget;
                            this.clipboardAction && (this.clipboardAction = null), this.clipboardAction = new n.default({
                                action: this.action(e),
                                target: this.target(e),
                                text: this.text(e),
                                trigger: e,
                                emitter: this
                            })
                        }, e.prototype.defaultAction = function(t) {
                            return l("action", t)
                        }, e.prototype.defaultTarget = function(t) {
                            var e = l("target", t);
                            if (e) return document.querySelector(e)
                        }, e.prototype.defaultText = function(t) {
                            return l("text", t)
                        }, e.prototype.destroy = function() {
                            this.listener.destroy(), this.clipboardAction && (this.clipboardAction.destroy(), this.clipboardAction = null)
                        }, e
                    }(o.default);

                function l(t, e) {
                    var i = "data-clipboard-" + t;
                    if (e.hasAttribute(i)) return e.getAttribute(i)
                }
                i.default = a, e.exports = i.default
            }, {
                "./clipboard-action": 8,
                "good-listener": 5,
                "tiny-emitter": 7
            }]
        }, {}, [9])(9)
    }), Ext.define("SYNO.SDS.ClipBoardUtil", {
        extend: "Ext.util.Observable",
        fixedText: !1,
        inputText: "",
        clipAction: "copy",
        constructor: function(t) {
            Ext.apply(this, t), this.handlerId && (this.fixedText || this.clipTarget || this.getTargetFn) || SYNO.Debug("Wrong Inupt"), this.callParent(arguments), this.initEvents(), this.initClipBoard()
        },
        setClipText: function(t) {
            var e = Ext.get(this.handlerId);
            this.inputText = t, e && e.set({
                "data-clipboard-text": this.inputText
            })
        },
        initEvents: function() {
            this.addEvents("clipsucceed", "clipfailed")
        },
        initClipBoard: function() {
            if (!Ext.isIE8) {
                var t, e, i = this,
                    s = Ext.get(i.handlerId),
                    n = {},
                    o = {};
                s ? (i.fixedText ? n["data-clipboard-text"] = i.inputText : (Ext.isString(i.clipTarget) ? i.clipTarget = Ext.getDom(i.clipTarget) : i.clipTarget instanceof Ext.Element ? i.clipTarget = i.clipTarget.dom : i.clipTarget instanceof Ext.Component && (i.clipTarget = i.clipTarget.getEl().dom), i.clipTarget instanceof HTMLElement && (n["data-clipboard-target"] = "#" + i.clipTarget.id), "copy" !== i.clipAction && (n["data-clipboard-action"] = "cut")), Ext.each(["text", "target"], function(t) {
                    e = t.charAt(0).toUpperCase() + t.slice(1), i["get" + e + "Fn"] && (o[t] = i["get" + e + "Fn"].createDelegate(i["get" + e + "Scope"] || window))
                }), s.set(n), (t = new Clipboard("#" + s.id, o)).on("success", function(t) {
                    i.fireEvent("clipsucceed", t)
                }), t.on("error", function(t) {
                    i.fireEvent("clipfailed", t)
                }), this.clipBoard = t) : SYNO.Debug("Cannot Find Handler Element")
            }
        },
        destroy: function() {
            this.clipBoard && (this.clipBoard.destroy(), this.clipBoard = null)
        }
    }), Ext.define("SYNO.SDS.Utils.ClipBoardButton", {
        extend: "SYNO.ux.Button",
        constructor: function(t) {
            if (t.clipCfg) {
                this.addEvents("clipsucceed", "clipfailed");
                var e = {
                    tooltip: t.clipCfg && "cut" === t.clipCfg.clipAction ? _T("filebrowser", "filetable_cut") : _T("filebrowser", "filetable_copy")
                };
                this.callParent([Ext.apply(e, t)])
            } else SYNO.Debug("clipCfg is needed")
        },
        afterRender: function() {
            this.callParent(arguments);
            var t = this.clipCfg || {},
                e = new SYNO.SDS.ClipBoardUtil(Ext.apply(t, {
                    handlerId: this.btnEl.id
                }));
            this.relayEvents(e, ["clipsucceed", "clipfailed"]), this.mon(this, "clipfailed", this.onClipFailed, this), this.clipboardUtil = e
        },
        onClipFailed: function(t) {
            this.appWin && this.appWin.getMsgBox().alert(_T("error", "error_error"), _T("error", "clip_failed"))
        },
        onClick: function(t) {
            (t && this.disabled || Ext.isIE8) && t.stopEvent(), Ext.isIE8 && this.fireEvent("clipfailed"), this.callParent(arguments)
        },
        destroy: function() {
            this.clipboardUtil && (this.clipboardUtil.destroy(), this.clipboardUtil = null), this.callParent(arguments)
        }
    }), Ext.define("SYNO.SDS.Utils.ClipBoardComposite", {
        extend: "SYNO.ux.CompositeField",
        BTN_CUT_CLASS: "clipboard-btn-cut",
        BTN_COPY_CLASS: "clipboard-btn-copy",
        disableWhenEmpty: !0,
        constructor: function(t) {
            this.initFields(t), this.addEvents("clipsucceed", "clipfailed"), this.callParent(arguments)
        },
        initFields: function(t) {
            var e, i = this;
            return t.textFieldCfg = t.textFieldCfg || {}, t.btnCfg = t.btnCfg || {}, i.textFieldId = Ext.id(), t.textFieldCfg.id = i.textFieldId, i.textField = new SYNO.ux.TextField(Ext.apply(t.textFieldCfg, {
                enableKeyEvents: !0,
                setValue: function(t) {
                    SYNO.ux.TextField.superclass.setValue.call(i.textField, t), i.updateBtnStatus()
                }
            })), e = t.disableWhenEmpty ? !t.textFieldCfg.value : !(!t.btnCfg || !Ext.isDefined(t.btnCfg.disabled)) && t.btnCfg.disabled, t.btnCfg.clipCfg = t.btnCfg.clipCfg || {}, t.btnCfg.clipCfg.clipTarget = i.textFieldId, i.btn = new SYNO.SDS.Utils.ClipBoardButton(Ext.apply(t.btnCfg, {
                disabled: e
            })), t.btnCfg.clipCfg.clipAction && "cut" === t.btnCfg.clipCfg.clipAction ? i.btn.addClass(i.BTN_CUT_CLASS) : i.btn.addClass(i.BTN_COPY_CLASS), t.items ? Ext.isArray(t.items) || (t.items = [t.items]) : t.items = [], t.items.push(i.textField), t.items.push(i.btn), delete t.textFieldCfg, delete t.btnCfg, t
        },
        enable: function() {
            this.textField.enable(), this.btn.enable()
        },
        disable: function() {
            this.textField.disable(), this.btn.disable()
        },
        afterRender: function() {
            this.callParent(arguments), this.relayEvents(this.btn, ["clipsucceed", "clipfailed"]), this.mon(this, "clipfailed", this.onClipFailed, this), this.mon(this, "clipsucceed", this.updateBtnStatus, this), this.mon(this.textField, "keyup", this.updateBtnStatus, this, {
                buffer: 200
            })
        },
        onClipFailed: function(t) {
            this.appWin && this.appWin.getMsgBox().alert(_T("error", "error_error"), _T("error", "clip_failed"))
        },
        updateBtnStatus: function() {
            this.disableWhenEmpty && this.btn.setDisabled(Ext.isEmpty(this.textField.getValue()))
        }
    }), Ext.ns("SYNO.SDS.Utils.DataView"), SYNO.SDS.Utils.DataView.FlexcrollDataView = Ext.extend(Ext.DataView, {
        scrollCls: " ux-scroll",
        overScrollCls: " ux-scroll-over",
        autoFlexcroll: !0,
        trackResetOnLoad: !0,
        initComponent: function() {
            var t = this;
            SYNO.SDS.Utils.DataView.FlexcrollDataView.superclass.initComponent.call(t), t.addEvents("refresh", "updateScrollbar"), t.mon(t, "beforerender", function() {
                t.cls = t.cls ? t.cls + t.scrollCls : t.scrollCls, t.overCls = t.overCls ? t.overCls + t.overScrollCls : t.overScrollCls
            }, t)
        },
        onStoreException: function() {
            this.el.unmask()
        },
        onStoreLoad: function() {
            this.updateScrollbar(this.trackResetOnLoad), this.fireEvent("afterUpdateScrollbar", this)
        },
        onStoreClear: function() {
            this.updateScrollbar(this.trackResetOnLoad)
        },
        bindStore: function(t, e) {
            var i = this;
            SYNO.SDS.Utils.DataView.FlexcrollDataView.superclass.bindStore.apply(i, arguments), !e && this.store && (t !== this.store && this.store.autoDestroy ? this.store.destroy() : (i.mun(t, "loadexception", i.onStoreException, i), i.mun(t, "load", i.onStoreLoad, i), i.mun(t, "clear", i.onStoreClear, i), i.mun(t, "datachanged", i.updateScrollbar, i), i.mun(t, "update", i.updateScrollbar, i)), t || (this.store = null)), t && (t = Ext.StoreMgr.lookup(t), i.mon(t, "loadexception", i.onStoreException, i), i.mon(t, "load", i.onStoreLoad, i), i.mon(t, "clear", i.onStoreClear, i), i.mon(t, "datachanged", i.updateScrollbar, i), i.mon(t, "update", i.updateScrollbar, i))
        },
        afterRender: function() {
            var t = this;
            SYNO.SDS.Utils.DataView.FlexcrollDataView.superclass.afterRender.call(t), t.mon(t, "resize", t.updateScrollbar, t), t.mon(t, "afterrender", t.updateScrollbar, t), t.mon(t, "afterlayout", t.updateScrollbar, t), t.mon(t, "updateScrollbar", t.onUpdateScrollbar, t, {
                buffer: 100
            }), t.updateScrollbar()
        },
        getTemplateTarget: function() {
            var t = this;
            if (t.el.dom) return t.scrollBar = t.scrollBar || t.el.createChild({
                tag: "div",
                style: "display:inline-block;width:100%;"
            }), t.scrollBar
        },
        updateScrollbar: function(t) {
            (t = !!Ext.isBoolean(t) && t) ? this.onUpdateScrollbar(t): this.fireEvent("updateScrollbar", t)
        },
        onUpdateScrollbar: function(t) {
            var e = this;
            if (e.isVisible()) {
                var i = e.el.dom;
                i && i.fleXcroll ? (t && i.fleXcroll.setScrollPos(!1, 0), i.fleXcroll.updateScrollBars(), t || i.fleXcroll.setScrollPos(0, 0, !0)) : i && (fleXenv.fleXcrollMain(i, this.disableTextSelect), i.onfleXcroll = function() {
                    this.fireEvent("flexcroll", this, this.getFleXcrollInfo(e.el.dom))
                }.createDelegate(this), i.fleXcroll && this.fireEvent("flexcrollInitDone")), i = null
            }
        },
        refresh: function() {
            SYNO.SDS.Utils.DataView.FlexcrollDataView.superclass.refresh.call(this), this.fireEvent("refresh")
        },
        onDestroy: function() {
            this.scrollBar && (Ext.destroy(this.scrollBar), delete this.scrollBar), SYNO.SDS.Utils.DataView.FlexcrollDataView.superclass.onDestroy.apply(this, arguments)
        }
    }), SYNO.SDS.Utils.DataView.SquenceStrategy = function() {
        this.isDestroyed || 0 !== this.all.getCount() && this.all.each(function(t) {
            this.updateItem(t)
        }, this)
    }, SYNO.SDS.Utils.DataView.BinarySearchStrategy = function() {
        var t = this,
            e = null,
            i = -1,
            s = -1,
            n = -1,
            o = 0;
        if (!t.isDestroyed && 0 !== t.all.getCount())
            if (-1 === (i = (e = t.all.first()) && !0 === t.isIntens(e, t.getEl()) ? 0 : (e = t.all.last()) && !0 === t.isIntens(e, t.getEl()) ? t.all.getCount() - 1 : function() {
                    for (var e = null, i = 0, s = 0, n = t.all.getCount() - 1, o = -1; s <= n;) {
                        if (o = Math.floor((s + n) / 2), e = t.all.item(o), i = t.isIntens(e, t.getEl()), e && !0 === i) return o;
                        !1 === i ? s = o + 1 : i < 0 && (n = o - 1)
                    }
                    return -1
                }())) t.all.each(function(t) {
                this.onUnLoadItem(t)
            }, t);
            else {
                for (o = i; o < t.all.getCount(); o++) {
                    if (!0 !== t.isIntens(t.all.item(o), t.getEl())) {
                        n = o;
                        break
                    }
                    t.onLoadItem(e)
                }
                for (o = i - 1; o >= 0; o--) {
                    if (!0 !== t.isIntens(t.all.item(o), t.getEl())) {
                        s = o;
                        break
                    }
                    t.onLoadItem(e)
                }
                if (-1 !== s)
                    for (o = s; o >= 0; o--) t.onUnLoadItem(e);
                if (-1 !== n)
                    for (o = n; o < t.all.getCount(); o++) t.onUnLoadItem(e)
            }
    }, SYNO.SDS.Utils.DataView.ConstantSearchStrategy = function() {
        var t = this,
            e = null,
            i = -1,
            s = -1,
            n = -1,
            o = 0;
        if (!t.isDestroyed && 0 !== t.all.getCount())
            if (-1 === (i = (e = t.all.first()) && !0 === t.isIntens(e, t.getEl()) ? 0 : (e = t.all.last()) && !0 === t.isIntens(e, t.getEl()) ? t.all.getCount() - 1 : function(e) {
                    var i = e.getSize(),
                        s = e.getMargins(),
                        n = t.el.dom.fleXdata ? t.el.dom.fleXdata.scrollPosition[1][0] : 0;
                    return Math.floor(n / (i.height + s.top + s.bottom)) * Math.floor(t.el.getWidth() / (i.width + s.right + s.left))
                }(t.all.first()))) t.all.each(function(t) {
                this.onUnLoadItem(t)
            }, t);
            else {
                for (o = i; o < t.all.getCount(); o++) {
                    if (!0 !== t.isIntens(t.all.item(o), t.getEl())) {
                        n = o;
                        break
                    }
                    t.onLoadItem(e)
                }
                for (o = i - 1; o >= 0; o--) {
                    if (!0 !== t.isIntens(t.all.item(o), t.getEl())) {
                        s = o;
                        break
                    }
                    t.onLoadItem(e)
                }
                if (-1 !== s)
                    for (o = s; o >= 0; o--) t.onUnLoadItem(t.all.item(o));
                if (-1 !== n)
                    for (o = n; o < t.all.getCount(); o++) t.onUnLoadItem(t.all.item(o))
            }
    }, SYNO.SDS.Utils.DataView.LazyDataView = Ext.extend(SYNO.SDS.Utils.DataView.FlexcrollDataView, {
        delay: 600,
        widthThreshold: 0,
        heightThreshold: 0,
        autoHeightThreshold: !0,
        constructor: function(t) {
            this.itemCls = t.itemCls || void 0, this.searchStrategy = this.searchStrategy || SYNO.SDS.Utils.DataView.SquenceStrategy.createDelegate(this), this.addPlugins(SYNO.ux.DataViewARIA, t), SYNO.SDS.Utils.DataView.LazyDataView.superclass.constructor.apply(this, [t]), this.last = !1
        },
        initKeyNav: function() {
            new Ext.KeyNav(this.el, {
                down: function(t) {
                    this.onKeyDown(t)
                },
                up: function(t) {
                    this.onKeyUp(t)
                },
                left: function(t) {
                    this.onKeyLeft(t)
                },
                right: function(t) {
                    this.onKeyRight(t)
                },
                esc: function(t) {
                    this.onKeyEsc(t)
                },
                scope: this
            })
        },
        focusNode: function(t) {
            var e = this.getNode(t);
            this.autoFlexcroll && this.fleXcrollTo(e)
        },
        getFirstSelItemIdx: function() {
            return this.getSelectedIndexes()[0]
        },
        getLastSelItemIdx: function() {
            return this.getSelectedIndexes()[this.getSelectedIndexes().length - 1]
        },
        getThumbnailRowNum: function(t) {
            var e = t.getTemplateTarget(),
                i = t.selected.elements[0].getStyles(),
                s = parseInt(i.width, 10) + parseInt(i.marginLeft, 10) + parseInt(i.marginRight, 10);
            return Math.floor(e.getWidth() / s)
        },
        isNeedToShift: function() {
            return !!this.selected.elements[0]
        },
        selectItem: function(t, e) {
            e ? this.select(t, !0, !0) : this.select(t), this.focusNode(t)
        },
        selectPreItem: function() {
            var t, e = this.getFirstSelItemIdx();
            t = 0 === e ? 0 : e - 1, this.selectItem(t)
        },
        selectNextItem: function() {
            var t, e = this.getFirstSelItemIdx(),
                i = this.store.getCount() - 1;
            t = e == i ? i : e + 1, this.selectItem(t)
        },
        selectPreRowItem: function(t) {
            var e, i = this.getFirstSelItemIdx();
            i < t ? this.selectItem(i) : (e = i - t, this.selectItem(e))
        },
        selectNextRowItem: function(t) {
            var e, i = this.getFirstSelItemIdx();
            (e = i + t) > this.store.getCount() - 1 ? this.selectItem(i) : this.selectItem(e)
        },
        selectPreItemIn: function() {
            var t, e = this.last;
            t = 0 === this.getLastSelItemIdx() ? 0 : this.getLastSelItemIdx() - 1, this.selectRange(e, t), this.last = e
        },
        selectNextItemIn: function() {
            var t, e = this.last,
                i = this.store.getCount() - 1;
            t = this.getLastSelItemIdx() + 1 > i ? i : this.getLastSelItemIdx() + 1, this.selectRange(e, t), this.last = e
        },
        selectPreRowItemIn: function(t) {
            var e, i = this.last;
            e = this.getLastSelItemIdx() < t ? 0 : this.getLastSelItemIdx() - t, this.selectRange(i, e), this.last = i
        },
        selectNextRowItemIn: function(t) {
            var e, i = this.last,
                s = this.store.getCount() - 1;
            e = this.getLastSelItemIdx() + t > s ? s : this.getLastSelItemIdx() + t, this.selectRange(i, e), this.last = i
        },
        onKeyEsc: function(t) {
            this.clearAllSelections()
        },
        onKeyUp: function(t) {
            if (!0 === this.isNeedToShift()) {
                var e = this.getThumbnailRowNum(this);
                t.shiftKey ? this.selectPreRowItemIn(e) : this.selectPreRowItem(e)
            } else this.selectItem(0)
        },
        onKeyDown: function(t) {
            if (!0 === this.isNeedToShift()) {
                var e = this.getThumbnailRowNum(this);
                t.shiftKey ? this.selectNextRowItemIn(e) : this.selectNextRowItem(e)
            } else this.selectItem(0)
        },
        onKeyRight: function(t) {
            if (!0 === this.isNeedToShift()) {
                t.shiftKey ? this.selectNextItemIn() : this.selectNextItem()
            } else this.selectItem(0)
        },
        onKeyLeft: function(t) {
            if (!0 === this.isNeedToShift()) {
                t.shiftKey ? this.selectPreItemIn() : this.selectPreItem()
            } else this.selectItem(0)
        },
        setSearchStategy: function(t) {
            this.searchStrategy = t
        },
        onLoadItem: function(t) {},
        onUnLoadItem: function(t) {},
        belowthefold: function(t, e, i) {
            return (i || e.getY()) + e.dom.scrollTop + e.getHeight() - (t.getY() - this.heightThreshold)
        },
        rightoffold: function(t, e, i) {
            return (i || e.getX()) + e.dom.scrollLeft + e.getWidth() - (t.getX() - this.widthThreshold)
        },
        abovethetop: function(t, e, i) {
            return (i || e.getY()) + e.dom.scrollTop >= t.getY() + this.heightThreshold + t.getHeight()
        },
        leftofbegin: function(t, e, i) {
            return (i || e.getX()) + e.dom.scrollLeft >= t.getX() + this.widthThreshold + t.getWidth()
        },
        isIntens: function(t, e) {
            var i = this,
                s = 0,
                n = 0,
                o = e.getX(),
                r = e.getY();
            return !!i.isVisible() && (!!t && (!i.abovethetop(t, e, r) && !i.leftofbegin(t, e, o) && ((n = i.belowthefold(t, e, r)) >= 0 && (s = i.rightoffold(t, e, o)) >= 0 || s + n)))
        },
        fitWidth: function() {
            var t, e, i, s, n = this,
                o = n.getTemplateTarget(),
                r = n.all.item(0),
                a = !0;
            if (Ext.isObject(r) && n.itemCls && (Ext.util.CSS.getRule(n.itemCls) && (n.marginLeft = n.marginLeft || r.getMargins("l") || 0, n.marginRight = n.marginRight || r.getMargins("r") || 0, s = n.marginLeft + n.marginRight, Ext.isNumber(s) && (i = r.getWidth() + s, 0 !== (e = Math.floor(o.getWidth() / i)))))) return t = Math.floor(o.getWidth() % i), r.getMargins("l") !== Math.floor(n.marginLeft + t / 2 / e) && (a = (a = a && Ext.util.CSS.updateRule(n.itemCls, "margin-left", Math.floor(n.marginLeft + t / 2 / e) + "px")) && Ext.util.CSS.updateRule(n.itemCls, "margin-right", Math.floor(n.marginRight + t / 2 / e) + "px")), a
        },
        updateScrollbar: function(t) {
            (t = !!Ext.isBoolean(t) && t) ? this.onUpdateScrollbar(t): this.fireEvent("updateScrollbar", t)
        },
        onUpdateScrollbar: function(t) {
            var e = this;
            if (e.isVisible()) {
                var i = e.el.dom;
                i && i.fleXcroll ? (t && i.fleXcroll.setScrollPos(!1, 0), i.fleXcroll.updateScrollBars(), t || i.fleXcroll.setScrollPos(0, 0, !0)) : i && (fleXenv.fleXcrollMain(i, this.disableTextSelect), i.onfleXcroll = function() {
                    e.isVisible() && e.onUpdateView && e.onUpdateView(), this.fireEvent("flexcroll", this, this.getFleXcrollInfo(e.el.dom))
                }.createDelegate(this), i.fleXcroll && this.fireEvent("flexcrollInitDone")), i = null
            }
        },
        afterRender: function() {
            var t = this;
            SYNO.SDS.Utils.DataView.LazyDataView.superclass.afterRender.call(t), t.mon(t, {
                resize: t.onResize,
                scope: t
            }), t.initKeyNav(), this.updateHeightThreshold()
        },
        onUserResize: function() {
            this.updateScrollbar(), this.updateHeightThreshold(), this.fitWidth.createSequence(function() {
                this.updateScrollbar.defer(300, this)
            }, this).defer(330, this)
        },
        onResize: function() {
            this.resizeTask || (this.resizeTask = new Ext.util.DelayedTask(this.onUserResize, this)), this.resizeTask.delay(350)
        },
        updateHeightThreshold: function() {
            !this.autoHeightThreshold || Ext.isIE && !Ext.isModernIE || (this.heightThreshold = this.getEl().getHeight())
        },
        onUpdateView: function() {
            this.delay ? (this.renderTask || (this.renderTask = new Ext.util.DelayedTask(this.searchStrategy, this)), this.renderTask.delay(this.delay)) : this.searchStrategy()
        },
        updateItem: function(t) {
            t.isVisible() && !0 === this.isIntens(t, this.getEl()) ? this.onLoadItem(t) : this.onUnLoadItem(t)
        },
        lazyLoadItem: function(t) {
            this.updateItem(Ext.fly(t))
        },
        onBeforeLoad: function() {
            this.loadingText && (this.clearSelections(!1, !0), this.getEl().mask(this.loadingText, "x-mask-loading"), this.all.clear())
        },
        refresh: function() {
            this.loadingText && this.getEl().unmask(), SYNO.SDS.Utils.DataView.LazyDataView.superclass.refresh.call(this), this.onUpdateView()
        },
        removeTask: function(t) {
            var e = this[t];
            e && e.cancel && (e.cancel(), this[t] = null)
        },
        destroy: function() {
            this.removeTask("renderTask"), this.removeTask("resizeTask"), SYNO.SDS.Utils.DataView.LazyDataView.superclass.destroy.call(this)
        }
    }), Ext.define("SYNO.SDS.Utils.PercentageBar", {
        extend: "Ext.XTemplate",
        defaultConf: {
            barWidth: 150,
            barHeight: 16,
            value: 0,
            showValueText: !0,
            fixed: !0,
            fixedBarTpl: ['<div class="{cls} syno-percentage-cmp">', '<div class="percentage-cmp-hbar-background" style="width:{barWidth}px; height:{barHeight}px;">', '<div class="percentage-cmp-hbar-fill" style="width:{fillW}px; height:{barHeight}px;" ></div>', "</div>", '<tpl if="(this.showValueText)">', '<div class="percentage-cmp-value" style="line-height: {barHeight}px;"> {value} %</div>', "</tpl>", "</div>"],
            flexBarTpl: ['<div class="{cls} syno-percentage-cmp">', '<tpl if="(this.showExtraText)">', '<div class="percentage-cmp-value extra-info" style="line-height: {barHeight}px;"> {extraInfo}</div>', "</tpl>", '<tpl if="(this.showValueText)">', '<div class="percentage-cmp-value" style="line-height: {barHeight}px;"> {value} %</div>', "</tpl>", '<div class="percentage-cmp-hbar-background" style="height:{barHeight}px;">', '<div class="percentage-cmp-hbar-fill" style="width:{fillW}%; height:{barHeight}px;" ></div>', "</div>", "</div>"]
        },
        constructor: function(t) {
            Ext.apply(this, this.defaultConf), Ext.apply(this, t), this.fixed ? SYNO.SDS.Utils.PercentageBar.superclass.constructor.apply(this, this.fixedBarTpl) : SYNO.SDS.Utils.PercentageBar.superclass.constructor.apply(this, this.flexBarTpl)
        },
        fill: function(t, e, i) {
            var s, n = this.fixed ? t * (this.barWidth / 100) : t;
            return i = i || 100 === t, s = {
                barHeight: this.barHeight,
                barWidth: this.barWidth,
                fillW: n,
                extraInfo: e,
                value: t,
                cls: this.cls + (i ? " no-animation" : "")
            }, this.applyTemplate(s)
        }
    }), Ext.define("SYNO.SDS.Utils.ProgressBar", {
        extend: "SYNO.SDS.Utils.PercentageBar",
        constructor: function(t) {
            this.callParent(arguments), this.cls = this.cls ? this.cls : "sds-ux-progressbar"
        }
    }), Ext.namespace("SYNO.SDS");
var pkgStatus = {
        start: ["running"],
        error: ["broken", "broken_by_other", "version_limit", "license_error", "stopped_by_dep_limit", "start_failed"],
        doing: ["installing", "upgrading", "starting", "repairing", "stopping", "uninstalling"],
        stop: ["stop", "stopped"]
    },
    tipStatus = {
        repair: _T("pkg_detail_status", "repairing"),
        install: _T("pkg_detail_status", "installing"),
        start: _T("pkg_detail_status", "starting"),
        stop: _T("pkg_detail_status", "stopping"),
        uninstall: _T("pkg_detail_status", "uninstalling"),
        upgrade: _T("pkg_detail_status", "upgrading"),
        installing: _T("pkg_detail_status", "installing"),
        upgrading: _T("pkg_detail_status", "upgrading"),
        starting: _T("pkg_detail_status", "starting"),
        repairing: _T("pkg_detail_status", "repairing"),
        stopping: _T("pkg_detail_status", "stopping"),
        uninstalling: _T("pkg_detail_status", "uninstalling"),
        error: _T("error", "error_error"),
        broken: _T("pkgmgr", "pkgmgr_pkg_broken"),
        broken_by_other: _T("pkgmgr", "pkgmgr_pkg_broken"),
        license_error: _T("pkgmgr", "pkgmgr_pkg_broken"),
        version_limit: _T("pkgmgr", "status_version_limit"),
        start_failed: _T("pkgmgr", "pkgmgr_pkg_stopped"),
        stopped_by_dep_limit: _T("pkgmgr", "stopped_by_dep_limit")
    },
    pkgSocketStatus = {
        start: {
            condition: function(t) {
                return ("start" === t.action || "upgrade" === t.action || "restart" === t.action) && !0 === t.finished && !0 === t.success
            }
        },
        error: {
            condition: function(t) {
                return !0 === t.finished && !1 === t.success
            }
        },
        doing: {
            condition: function(t) {
                return !1 === t.finished
            }
        },
        stop: {
            condition: function(t) {
                return "stop" === t.action && !0 === t.finished && !0 === t.success
            }
        },
        install: {
            condition: function(t) {
                return "install" === t.action && !0 === t.finished && !0 === t.success
            }
        },
        uninstall: {
            condition: function(t) {
                return "uninstall" === t.action && !0 === t.finished && !0 === t.success
            }
        }
    },
    PKG_ALL = "_all";
SYNO.SDS._Packages = function() {
    function t() {
        _classCallCheck2(this, t), this._packages = Object.create(null), this._mapPackages = new Map, this._onChangeCallbacks = [], this._onAllPackagesChange = [], this.anonymous = !1
    }
    return _createClass2(t, [{
        key: "getAllPackages",
        value: function() {
            return Object.assign({}, this._packages)
        }
    }, {
        key: "registerSocketPackageStatus",
        value: function() {
            var t = this;
            SYNO.SDS.SocketInst.registerSDKEvent("package_status_changed", function(e) {
                try {
                    t._onPackageStatusChange.apply(t, [e])
                } catch (t) {
                    SYNO.Debug.error(t, e)
                }
            }), SYNO.SDS.SocketInst.registerSDKEvent("package_progress_changed", function() {
                t.getData()
            })
        }
    }, {
        key: "_notifyAllPackagesChanged",
        value: function() {
            var t = !0,
                e = !1,
                i = void 0;
            try {
                for (var s, n = this._onAllPackagesChange[Symbol.iterator](); !(t = (s = n.next()).done); t = !0) {
                    var o = s.value,
                        r = o.callback,
                        a = o.context;
                    r.apply(a || this)
                }
            } catch (t) {
                e = !0, i = t
            } finally {
                try {
                    t || null == n.return || n.return()
                } finally {
                    if (e) throw i
                }
            }
        }
    }, {
        key: "_notifyPackageStatusChange",
        value: function(t, e) {
            var i = !0,
                s = !1,
                n = void 0;
            try {
                for (var o, r = this._onChangeCallbacks[Symbol.iterator](); !(i = (o = r.next()).done); i = !0) {
                    var a = o.value,
                        l = a.callback,
                        c = a.context,
                        d = a.pkgId;
                    d !== PKG_ALL && d !== t.package || l.apply(c || this, [e, t])
                }
            } catch (t) {
                s = !0, n = t
            } finally {
                try {
                    i || null == r.return || r.return()
                } finally {
                    if (s) throw n
                }
            }
        }
    }, {
        key: "_onPackageStatusChange",
        value: function(t) {
            var e = this.transformPkgStatus(t);
            if (e) {
                var i = this.getInfo(t.package, "pkgId");
                if (i && 0 !== i.length) {
                    var s = !0,
                        n = !1,
                        o = void 0;
                    try {
                        for (var r, a = i[Symbol.iterator](); !(s = (r = a.next()).done); s = !0) {
                            var l = r.value;
                            l._socketAction = t.action, l.status = e, delete l._pkgStatus
                        }
                    } catch (t) {
                        n = !0, o = t
                    } finally {
                        try {
                            s || null == a.return || a.return()
                        } finally {
                            if (n) throw o
                        }
                    }
                    this._notifyPackageStatusChange(t, e)
                }
            }
        }
    }, {
        key: "transformPkgStatus",
        value: function(t) {
            return "socket" === (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "socket") ? Object.entries(pkgSocketStatus).reduce(function(e, i) {
                var s = i[0],
                    n = i[1];
                return n.condition && !0 === n.condition.apply(n, [t]) ? s : e
            }, null) : this._mappingPkgStatus(t.status)
        }
    }, {
        key: "getPackageTip",
        value: function(t) {
            var e = this.getInfo(t, "pkgId");
            if (e && 0 !== e.length) {
                var i = e[0];
                return "doing" === i.status ? tipStatus[i._socketAction] || tipStatus[i._pkgStatus] || _T("pkg_detail_status", "waiting") : "error" === i.status ? tipStatus[i._pkgStatus] || tipStatus.error : void 0
            }
        }
    }, {
        key: "shouldLaunchPkgCenter",
        value: function(t) {
            return "doing" === t || "stop" === t || "error" === t
        }
    }, {
        key: "clear",
        value: function() {
            this._packages = Object.create(null), this._mapPackages = new Map
        }
    }, {
        key: "insert",
        value: function(t, e) {
            (this._packages[t] = e, this._mapPackages.has(e.pkgId)) ? this._mapPackages.get(e.pkgId).push(e): this._mapPackages.set(e.pkgId, [e])
        }
    }, {
        key: "isPackage",
        value: function(t) {
            return !!this._packages[t]
        }
    }, {
        key: "isStop",
        value: function(t) {
            var e = this._packages[t];
            return !!e && "stop" === e.status
        }
    }, {
        key: "isStart",
        value: function(t) {
            var e = this._packages[t];
            return !!e && "start" === e.status
        }
    }, {
        key: "getInfo",
        value: function(t) {
            var e = "appId" === (arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "appId") ? this._packages[t] : this._mapPackages.get(t);
            return e || null
        }
    }, {
        key: "isAnonymous",
        value: function() {
            return this.anonymous
        }
    }, {
        key: "getData",
        value: function() {
            var t = this;
            return _S("public_access") ? (this.anonymous = !0, Promise.resolve()) : SYNO.API.RequestPromise({
                api: "SYNO.Core.Package",
                method: "list",
                version: 2,
                params: {
                    additional: ["status", "dsm_apps"]
                }
            }).then(function(e) {
                return t.clear(), t.processPackagesResponse(e.packages), t._notifyAllPackagesChanged(), t._packages
            }).catch(function(t) {
                SYNO.Debug.error(t)
            })
        }
    }, {
        key: "getPackage",
        value: function(t) {
            var e = this;
            return SYNO.API.RequestPromise({
                api: "SYNO.Core.Package",
                method: "get",
                version: 1,
                params: {
                    id: t,
                    additional: ["status", "dsm_apps"]
                }
            }).then(function(t) {
                e.processPackageResponse(t)
            }).catch(function(t) {
                SYNO.Debug.error(t)
            })
        }
    }, {
        key: "processPackageResponse",
        value: function(t) {
            var e = t.additional.dsm_apps.split(" "),
                i = !0,
                s = !1,
                n = void 0;
            try {
                for (var o, r = e[Symbol.iterator](); !(i = (o = r.next()).done); i = !0) {
                    var a = o.value,
                        l = t.additional.status;
                    this.insert(a, {
                        id: a,
                        pkgId: t.id,
                        name: t.name,
                        _pkgStatus: l,
                        version: t.version,
                        status: this.transformPkgStatus({
                            status: l
                        }, "webapi")
                    })
                }
            } catch (t) {
                s = !0, n = t
            } finally {
                try {
                    i || null == r.return || r.return()
                } finally {
                    if (s) throw n
                }
            }
        }
    }, {
        key: "processPackagesResponse",
        value: function(t) {
            var e = !0,
                i = !1,
                s = void 0;
            try {
                for (var n, o = t[Symbol.iterator](); !(e = (n = o.next()).done); e = !0) {
                    var r = n.value;
                    this.processPackageResponse(r)
                }
            } catch (t) {
                i = !0, s = t
            } finally {
                try {
                    e || null == o.return || o.return()
                } finally {
                    if (i) throw s
                }
            }
        }
    }, {
        key: "_mappingPkgStatus",
        value: function(t) {
            return Object.entries(pkgStatus).reduce(function(e, i) {
                var s = i[0];
                return i[1].includes(t) ? s : e
            }, null)
        }
    }, {
        key: "registerAllPackagesChange",
        value: function(t, e) {
            this._onAllPackagesChange.push({
                callback: t,
                context: e || this
            })
        }
    }, {
        key: "registerPackageStatusChange",
        value: function(t, e) {
            var i = arguments.length > 2 && void 0 !== arguments[2] ? arguments[2] : PKG_ALL;
            this._onChangeCallbacks.push({
                callback: t,
                context: e || this,
                pkgId: i
            })
        }
    }, {
        key: "unregisterPackageStatusChange",
        value: function(t, e) {
            this._onChangeCallbacks = this._onChangeCallbacks.filter(function(i) {
                var s = i.callback,
                    n = i.context;
                return s !== t || n !== e
            })
        }
    }, {
        key: "unregisterAllPackagesChange",
        value: function(t, e) {
            this._onAllPackagesChange = this._onAllPackagesChange.filter(function(i) {
                var s = i.callback,
                    n = i.context;
                return s !== t || n !== e
            })
        }
    }, {
        key: "isEnable",
        value: function(t) {
            return !!this.isAnonymous() || this.isStart(t)
        }
    }, {
        key: "getJsId",
        value: function(t) {
            var e = this.getInfo(t, "pkgId");
            return e && e.length > 0 ? e[0].id : null
        }
    }]), t
}();