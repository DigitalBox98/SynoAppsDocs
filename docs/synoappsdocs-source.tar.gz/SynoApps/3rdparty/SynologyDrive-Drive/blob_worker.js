/* Copyright (c) 2020 Synology Inc. All rights reserved. */

onmessage = function(e) {
    var a = e.data.requestId,
        r = e.data.graduallyConcat;
    try {
        var s = [],
            t = new FileReaderSync;
        if (r)
            for (var d = 0, l = e.data.blobArray.length; d < l;) {
                var o = e.data.blobArray.slice(d, d + 1e3),
                    u = new Blob(o),
                    c = t.readAsArrayBuffer(u);
                s.push(c), d += 1e3
            } else s = e.data.blobArray;
        var b = new Blob(s),
            f = t.readAsArrayBuffer(b);
        postMessage({
            requestId: a,
            success: !0,
            buffer: f
        }, [f])
    } catch (e) {
        postMessage({
            requestId: a,
            success: !1
        })
    }
};