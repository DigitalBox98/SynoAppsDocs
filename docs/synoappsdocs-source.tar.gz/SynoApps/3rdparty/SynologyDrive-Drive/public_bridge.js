/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.Drive.BridgeApplication
 * @extends SYNO.SDS.AppInstance
 * SynologyDrive bridge application class
 *
 */
Ext.define("SYNO.SDS.Drive.BridgeApplication", {
    extend: SYNO.SDS.AppInstance,
    beforeOpen: function(o) {
        switch (o.action) {
            case "logout":
                this.logout(o.callback)
        }
        return !1
    },
    logout: function(o) {
        o && (SYNO.SDS.Utils.Logout.redirect = function() {
            window.location = o
        }), SYNO.SDS.Utils.Logout.logout(!0)
    }
});
