/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.AudioStation.Slider.Main
 * @extends Ext.slider.SingleSlider
 * AudioStation slider class
 *
 */
Ext.define("SYNO.SDS.AudioStation.Slider.Main", {
    extend: "Ext.slider.SingleSlider",
    constructor: function(t) {
        this.audioAppMain = t.audioAppMain, this.callParent(arguments)
    },
    isDragging: function() {
        return !(!this.thumbs || this.thumbs.length < 1) && this.thumbs[0].dragging
    },
    promoteThumb: function(t) {}
}), Ext.define("SYNO.SDS.AudioStation.Slider.PositionSlider", {
    extend: "SYNO.SDS.AudioStation.Slider.Main",
    positionMax: 1e4,
    constructor: function(t) {
        var e = this.fillConfig(t);
        this.callParent([e]), this.clickRange = [0, 22]
    },
    fillConfig: function(t) {
        var e = {
            cls: "syno-as-slider syno-as-position-slider",
            width: 360,
            minValue: 0,
            maxValue: this.positionMax,
            disabled: !0,
            scope: this,
            listeners: {
                change: this.onPositionChange,
                changecomplete: this.onPositionChangeComplete,
                afterrender: this.onPositionSliderRender
            }
        };
        return Ext.apply(e, t), e
    },
    updatePosition: function(t) {
        var e = this.getDuration();
        e > 0 && !this.isDragging() && this.setValue(this.positionMax * t / e)
    },
    getDuration: function() {
        return this.audioAppMain.playerPanel.Ctrl.getDurationValue()
    },
    onPositionChange: function(t, e, i) {
        var n = t.getEl().child(".syno-as-slider-progress"),
            a = t.getEl().child(".x-slider-inner").getWidth(),
            o = 0;
        0 !== e && (o = e * a / this.positionMax + 3), n.dom.style.width = o + "px"
    },
    onPositionChangeComplete: function(t, e) {
        var i = this.audioAppMain.playerPanel.Ctrl.getDurationValue();
        i > 0 && (e = i * e / this.positionMax), this.audioAppMain.audioPlayer.doSetPosition(e)
    },
    onPositionSliderRender: function(t) {
        var e = t.getEl().child(".x-slider-inner"),
            i = t.getEl().child(".x-slider-thumb");
        e.createChild({
            tag: "div",
            cls: "syno-as-slider-progress"
        }, i), e.createChild({
            tag: "div",
            cls: "syno-as-slider-bg"
        }, i), t.halfThumb = 15, i.dom.style.left = "-15px"
    },
    setPositionSlideThumbVisible: function(t) {
        var e = this.getEl().child(".x-slider-thumb");
        e && (t && this.audioAppMain.playerPanel.Ctrl.getPlayingStatus() ? e.addClass("syno-as-slider-thumb-visible") : e.removeClass("syno-as-slider-thumb-visible"))
    }
}), Ext.define("SYNO.SDS.AudioStation.Slider.VolumeSlider", {
    extend: "SYNO.SDS.AudioStation.Slider.Main",
    constructor: function(t) {
        var e = this.fillConfig(t);
        this.callParent([e])
    },
    fillConfig: function(t) {
        var e = {
            cls: "syno-as-slider syno-as-volume-slider",
            minValue: 0,
            maxValue: 100,
            delayPollingModifyFlag: 0,
            volumeAllCurrent: -1,
            volumeSavedList: {},
            scope: this,
            listeners: {
                change: this.onVolumeChange,
                changecomplete: this.onVolumeChangeComplete,
                afterrender: this.onVolumeSliderRender
            }
        };
        return Ext.apply(e, t), e
    },
    onVolumeChange: function(t, e, i) {
        var n = t.getEl().child(".syno-as-slider-progress"),
            a = t.getEl().child(".x-slider-inner").getWidth(),
            o = 0;
        0 !== e && (o = e * a / 100 + 1), n.dom.style.width = o + "px", this.audioAppMain.audioPlayer.doFastSetVolume(e, i.dragging)
    },
    onVolumeChangeComplete: function(t, e, i) {
        var n;
        "__SYNO_WEB_PLAYER__" !== this.audioAppMain.gCurrentSelectPlayer && (t.delayPollingModifyFlag = 2), "__SYNO_Multiple_AirPlay__" === this.audioAppMain.gCurrentSelectPlayer ? Ext.Ajax.request({
            url: SYNO.SDS.AudioStation.Utils.getWebAPIURL("remote_player.cgi"),
            params: SYNO.SDS.AudioStation.Utils.getWebAPIParams({
                api: "SYNO.AudioStation.RemotePlayer",
                method: "getstatus",
                id: this.audioAppMain.gCurrentSelectPlayer,
                additional: "subplayer_volume"
            }),
            method: "GET",
            scope: this,
            callback: function(i, a, o) {
                var s, l, r, d, u = [],
                    g = [],
                    c = {},
                    h = [],
                    S = this.audioAppMain.PlayerStore;
                if (a && o.responseText && (s = Ext.util.JSON.decode(o.responseText)) && (!s.error || !s.error.code || "AUDIO_ERR_DEVICE_NOT_EXISTS" !== this.audioAppMain._getUtils().getErrCodeMapping(s.error.code))) {
                    if (l = s.data, 0 === e) {
                        t.volumeAllCurrent = s.data.volume;
                        for (r in l.subplayer_volume) l.subplayer_volume.hasOwnProperty(r) && (t.volumeSavedList[r] = l.subplayer_volume[r])
                    }
                    if (0 === s.data.volume)
                        if (-1 === t.volumeAllCurrent) {
                            n = e / 50, c = l.subplayer_volume;
                            for (r in l.subplayer_volume) l.subplayer_volume.hasOwnProperty(r) && h.push(S.getById(r).get("name"));
                            h.sort();
                            for (r in l.subplayer_volume)
                                if (l.subplayer_volume.hasOwnProperty(r) && h[0] === S.getById(r).get("name")) {
                                    d = r;
                                    break
                                } c[d] = 50
                        } else n = e / t.volumeAllCurrent, c = t.volumeSavedList, t.volumeAllCurrent = -1, t.volumeSavedList = {};
                    else n = e / s.data.volume, c = l.subplayer_volume;
                    for (r in l.subplayer_volume) l.subplayer_volume.hasOwnProperty(r) && (u.push(r), g.push(Math.round(c[r] * n)));
                    this.audioAppMain.audioPlayer.doSetMultipleVolumes(u.join(), g.join())
                }
            }
        }) : this.audioAppMain.audioPlayer.doSetVolume(e)
    },
    onVolumeSliderRender: function(t) {
        var e = t.getEl().child(".x-slider-inner"),
            i = t.getEl().child(".x-slider-thumb");
        e.createChild({
            tag: "div",
            cls: "syno-as-slider-progress"
        }, i), e.createChild({
            tag: "div",
            cls: "syno-as-slider-bg"
        }, i), t.halfThumb = 6
    }
}), Ext.define("SYNO.SDS.AudioStation.Slider.MultipleVolumeSlider", {
    extend: "SYNO.SDS.AudioStation.Slider.VolumeSlider",
    onVolumeChange: function(t, e, i) {
        var n, a, o, s = t.getEl().child(".syno-as-slider-progress"),
            l = t.getEl().child(".x-slider-inner").getWidth(),
            r = 0;
        if (0 !== e && (r = e * l / 100 + 1), s.dom.style.width = r + "px", "" === this.owner.firstSlider && (this.owner.firstSlider = t.UDN), this.owner.volumeAllSlider === t) {
            if (this.owner.firstSlider === t.UDN) {
                if (0 === this.owner.volumeAllCurrent)
                    for (this.owner.volumeAllCurrent = 50, n = 0; n < this.owner.volumeSliderList.length; n++)
                        if (this.owner.checkboxList[n].checked) {
                            this.owner.volumeSavedList[n] = 50;
                            break
                        } for (a = e / this.owner.volumeAllCurrent, n = 0; n < this.owner.volumeSliderList.length; n++) this.owner.volumeSliderList[n].disabled || this.owner.volumeSliderList[n].setValue(this.owner.volumeSavedList[n] * a)
            }
        } else if (this.owner.firstSlider === t.UDN) {
            if (this.owner.keepCurrentFlag) {
                for (n = 0; n < this.owner.volumeSliderList.length; n++) this.owner.volumeCurrentList[n] = this.owner.volumeSliderList[n].getValue();
                this.owner.keepCurrentFlag = !1
            }
            for (n = 0; n < this.owner.volumeSliderList.length; n++)
                if (t.UDN === this.owner.volumeSliderList[n].UDN) {
                    this.owner.volumeCurrentList[n] = t.getValue();
                    break
                } o = Math.max.apply(Math, this.owner.volumeCurrentList), this.owner.volumeAllSlider.setValue(o)
        }
    },
    onVolumeChangeComplete: function(t, e, i) {
        var n;
        if (this.owner.firstSlider = "", this.owner.delayPollingModifyFlag = 2, this.owner.volumeAllSlider === t) 0 === t.getValue() ? this.owner.keepCurrentFlag = !0 : this.owner.keepCurrentFlag = !1;
        else if (0 === t.getValue()) {
            for (n = 0; n < this.owner.volumeSliderList.length && (this.owner.volumeSliderList[n].disabled || 0 === this.owner.volumeSliderList[n].getValue()); n++);
            n === this.owner.volumeSliderList.length && (this.owner.keepCurrentFlag = !0)
        }
        if (!this.owner.keepCurrentFlag)
            for (this.owner.volumeAllCurrent = this.owner.volumeAllSlider.getValue(), n = 0; n < this.owner.volumeSliderList.length; n++) this.owner.volumeSliderList[n].disabled || (this.owner.volumeCurrentList[n] = this.owner.volumeSliderList[n].getValue(), this.owner.volumeSavedList[n] = this.owner.volumeSliderList[n].getValue());
        this.owner.setAllVolumes()
    },
    onVolumeSliderRender: function(t) {
        var e = t.getEl().child(".x-slider-inner"),
            i = t.getEl().child(".x-slider-thumb");
        e.createChild({
            tag: "div",
            cls: "syno-as-slider-progress"
        }, i), e.createChild({
            tag: "div",
            cls: "syno-as-slider-bg"
        }, i), t.halfThumb = 7
    }
}), Ext.define("SYNO.SDS.AudioStation.Slider.MiniVolumeSlider", {
    extend: "SYNO.SDS.AudioStation.Slider.VolumeSlider",
    constructor: function(t) {
        var e = {
            cls: "syno-as-mini-volume-slider",
            vertical: !0
        };
        Ext.apply(e, t), this.callParent([e])
    },
    onVolumeSliderRender: function() {
        this.volumeBg = Ext.DomHelper.insertBefore(this.thumbs[0].el, {
            tag: "div",
            cls: "syno-as-slider-bg"
        }, !0), this.volumeStrip = Ext.DomHelper.insertBefore(this.thumbs[0].el, {
            tag: "div",
            cls: "syno-as-slider-progress"
        }, !0), this.volumeStrip.setHeight(0), this.halfThumb = 7
    },
    onVolumeChange: function(t, e, i) {
        var n = 0;
        0 !== e && (n = 82 * e / 100 - 2), this.volumeStrip.setHeight(n), this.audioAppMain.audioPlayer.doFastSetVolume(e, i.dragging)
    }
}), Ext.define("SYNO.SDS.AudioStation.Slider.VerticalVolumeSlider", {
    extend: "SYNO.SDS.AudioStation.Slider.VolumeSlider",
    constructor: function(t) {
        var e = {
            cls: "syno-as-vertical-volume-slider",
            vertical: !0
        };
        Ext.apply(e, t), this.callParent([e])
    },
    onVolumeChange: function(t, e, i) {
        this.updateProgress(t, e), this.audioAppMain.audioPlayer.doFastSetVolume(e, i.dragging)
    },
    onVolumeSliderRender: function(t) {
        var e = t.getEl().child(".x-slider-inner"),
            i = t.getEl().child(".x-slider-thumb");
        e.createChild({
            tag: "div",
            cls: "syno-as-slider-progress"
        }, i), e.createChild({
            tag: "div",
            cls: "syno-as-slider-bg"
        }, i);
        var n = this.getValue();
        this.updateProgress(t, n)
    },
    updateProgress: function(t, e) {
        var i = t.getEl().child(".syno-as-slider-progress"),
            n = t.getEl().child(".x-slider-inner").getHeight(),
            a = 0;
        0 !== e && (a = e * n / 100 + 1), i.dom.style.height = a + "px"
    }
}), Ext.namespace("SYNO.SDS.AudioStation"), SYNO.SDS.AudioStation.WebPlayer = function(t) {
    var e, i, n = null,
        a = [],
        o = 0,
        s = 0,
        l = -1,
        r = 0,
        d = !1,
        u = !1,
        g = !1,
        c = !1,
        h = !1,
        S = !1,
        p = -1,
        y = 50,
        m = null,
        f = !1,
        P = !1,
        v = 1,
        A = t._getUtils().isMobileDevice(),
        _ = !1,
        M = "syno_audio",
        b = M,
        C = "syno_audio2",
        O = 0,
        N = 0,
        D = 0,
        w = new Ext.util.DelayedTask,
        E = "",
        x = !0;
    ! function() {
        soundManager ? (c = !0, Ext.isFunction(t.delayPlayFn) && (t.delayPlayFn(), t.delayPlayFn = null)) : (soundManager = new SoundManager, soundManager.setup({
            url: t.baseURL + "/SoundManager2/",
            debugMode: !1,
            waitForWindowLoad: !0,
            useHighPerformance: !0,
            flashVersion: 9,
            flashLoadTimeout: 3e4,
            preferFlash: !1,
            useHTML5Audio: !0,
            html5PollingInterval: 20,
            onready: function(e) {
                c = !0, e.success && (SYNO.SDS.AudioStation.Utils.createStreamingModeSupportList(), SYNO.SDS.AudioStation.Utils.streamSupportObj = SYNO.SDS.AudioStation.Utils.getStreamingSupportFormat(), t.playingStore.load(), Ext.isFunction(t.delayPlayFn) && (t.delayPlayFn(), t.delayPlayFn = null))
            },
            ontimeout: function(t) {
                c = !0
            }
        }), soundManager.beginDelayedInit());
        var e = 50;
        t.isPublicSharing() || (e = t._getWindow().appInstance.getUserSettings("StreamingVolume")), null !== e && e >= 0 && e <= 100 && (y = e), t.lyricsMgr || (t.lyricsMgr = new SYNO.SDS.AudioStation.Lyrics.Mgr)
    }();
    var I = function(t) {
            return !!n && (n.getTotalCount() !== a.length && (g ? L() : R()), !(t < 0 || a.length <= t))
        },
        Y = function(t) {
            var e;
            if (!I(t)) return !1;
            if (s = t, wt(t), g) {
                for (e in a)
                    if (t === a[e]) {
                        o = parseInt(e, 10);
                        break
                    }
            } else o = t;
            return !0
        },
        R = function() {
            var t, e = n.getTotalCount();
            for (a = [], t = 0; t < e; t++) a[t] = t;
            o = s
        },
        L = function() {
            R(), a.sort(function() {
                return .5 - Math.random()
            }), o = 0, s != a[o] && T(s, o), d && Y(s)
        },
        T = function(t, e) {
            var i;
            if (!(t >= a.length || e >= a.length)) {
                for (i = 0; i < a.length; i++)
                    if (t == a[i]) {
                        a[i] = a[e];
                        break
                    } a[e] = t
            }
        },
        U = function(t) {
            var e = t.data.id;
            return !(!SYNO.SDS.AudioStation.Utils.isLocalMusic(t) || !isNaN(e.substr(e.lastIndexOf("_") + 1)))
        },
        V = function() {
            return I(o) ? (s = a[o], wt(s), s) : null
        },
        k = function(t) {
            return !t && d ? V() : u ? (I(o + 1) ? o++ : o = 0, V()) : I(o + 1) ? (o++, V()) : null
        },
        B = function(t) {
            return d ? t : u ? I(t + 1) ? t + 1 : 0 : I(t + 1) ? t + 1 : null
        },
        W = function(t) {
            return isNaN(t) ? null : a[t]
        },
        H = function(t) {
            var e, i;
            return isNaN(t) ? null : (i = n.baseParams.offset, (e = t - i) < 0 ? null : n.getAt(e) || null)
        },
        F = function() {
            var t, e;
            return isNaN(V()) ? null : (e = n.baseParams.offset, (t = s - e) < 0 ? null : n.getAt(t) || null)
        },
        Q = function() {
            var e, i, s;
            if (!d) {
                if (e = o + 1, !I(e)) {
                    if (!u) return;
                    e = 0
                }
                i = a[e], s = n.getAt(i), s && SYNO.SDS.AudioStation.Utils.isLocalMusic(s) && t.lyricsMgr.getLyrics(s)
            }
        },
        G = function() {
            return u ? (I(o - 1) ? o-- : o = n.getTotalCount() - 1, V()) : I(o - 1) ? (o--, V()) : null
        },
        q = function() {
            return O
        },
        j = function() {
            return N
        },
        z = function(t) {
            O = t, N = 1e3 * (t - r)
        },
        X = function() {
            return D
        },
        K = function(t) {
            D = t
        },
        J = function() {
            var t, e = soundManager.getSoundById(b);
            return e ? (t = Math.floor(e.position / 1e3), h ? t + r : t) : 0
        },
        Z = function() {
            var e;
            "__SYNO_WEB_PLAYER__" === t.gCurrentSelectPlayer && J() !== X() && (e = t.playerPanel.Ctrl, K(J()), e.updatePositionDuration(X(), q()))
        },
        $ = function() {
            var e, i;
            "__SYNO_WEB_PLAYER__" === t.gCurrentSelectPlayer && (i = soundManager.getSoundById(b), i && (y = i.volume), e = t.playerPanel.Ctrl, e.updateVolume(y), t.isPublicSharing() || t._getWindow().appInstance.setUserSettings("StreamingVolume", y))
        },
        tt = function() {
            t.playerPanel.Ctrl.updateRepeatShuffle({
                all: u,
                one: d,
                shuffle: g
            })
        },
        et = function() {
            if (t.stopGetRadioSongInfoPollTask(), "__SYNO_WEB_PLAYER__" === t.gCurrentSelectPlayer) {
                var e = t.playerPanel.Ctrl;
                e.setPlayingStatus(!1), e.setBtnPause(!1), e.setRecordPause(!1), e.clearPlayingStatus(), e.clearLyricsPanel(), e.setLyricsDisabled(!0)
            }
        },
        it = function() {
            var e, i, a, o = null,
                s = SYNO.SDS.AudioStation.Utils;
            if ("__SYNO_WEB_PLAYER__" === t.gCurrentSelectPlayer) {
                if (!(o = soundManager.getSoundById(b))) return et(), $(), void tt();
                if (e = V(), !isNaN(e))
                    if (i = F()) {
                        a = t.playerPanel.Ctrl;
                        var l = i.data.title;
                        "" === l && (l = i.data.path.split("/").pop()), a.updateTitleArtist(l, i.data.artist, i.data.album), a.updateSongRating(i.data.id, i.data.type, i.data.song_rating), $(), i.data.duration ? z(i.data.duration) : (z(0), t.startGetRadioSongInfoPollTask()), Z(), tt(), a.updateCover(s.getTrackCover(i.data, "playing")), a.setPlayingStatus(!0), a.setBtnPause(!o.paused), a.setRecordPause(o.paused), a.setLyricsDisabled(!1), t.playerPanel.refreshLyrics(i), t.highlightPlayingIndex(e)
                    } else {
                        if (t.isPlayingPage(e, n)) return;
                        n.on("load", it, this, {
                            single: !0
                        }), t.checkPlayingPage(e, n)
                    }
            }
        },
        nt = function(t, e) {
            var i, n, a, l;
            if (S) return yt(), !1;
            if (!t) {
                if (!(i = F()) || !i.data) return yt(), !1;
                if (!i.data.support || U(i)) {
                    if (void 0 === e) return yt(), !1;
                    i = ft(s, e)
                }
                if (!i || !i.data || !i.data.path) return yt(), !1
            }
            if (a = o, a = B(a), e && 1 < e)
                for (l = 1; l < e; l++) a = B(a);
            return p = W(a), n = H(p), n && n.data ? n.data.support && !U(n) || (n = mt(p)) : S = !0, vt(i, n), n && n.data && n.data.path || (S = !0), x = !1, !0
        },
        at = function(t, e) {
            var i = t ? p : k(e);
            return t || yt(!1, !0), Ext.isNumber(i) ? (Pt(i, t, 1), !0) : (yt(), !1)
        },
        ot = function() {
            var t = G();
            return yt(!1, !0), null !== t ? (Pt(t, !1, -1), !0) : (yt(), !1)
        },
        st = function(e, i) {
            var n = SYNO.SDS.AudioStation.Utils,
                a = e.get("path"),
                o = n.getFileExtensionName(a);
            if (0 === e.get("id").indexOf("music_")) {
                var s = n.getStreamingPlayTypeByRecord(e),
                    l = [];
                switch (SYNO.SDS.AudioStation.SessionData.sid && l.push("sid=" + SYNO.SDS.AudioStation.SessionData.sid), Ext.isNumber(i) || (i = 0), l = l.concat(["api=SYNO.AudioStation.Stream", "version=" + n.webAPIVersion["SYNO.AudioStation.Stream"]]), s) {
                    case "direct":
                        l = l.concat(["method=stream", "id=" + e.get("id")]);
                        break;
                    case "mp3":
                        o = "mp3", l = l.concat(["method=transcode", "id=" + e.get("id"), "format=mp3", "position=" + i]);
                        break;
                    case "wav":
                        o = "wav", l = l.concat(["method=transcode", "id=" + e.get("id"), "format=wav", "position=" + i]);
                        break;
                    default:
                        return null
                }
                t.isPublicSharing() && (l = l.concat(["sharing_id=" + SYNO.SDS.AudioStation.SessionData.SharingId])), l.push("_dc=" + (new Date).getTime()), a = String.format("{0}/0.{1}?{2}", n.getWebAPIURL("stream.cgi"), o, l.join("&")), a = Ext.urlAppend(a)
            } else a = {
                id: e.data.id,
                uri: a
            };
            return a
        },
        lt = function(t) {
            return !!(t.match(/\/webapi\/AudioStation\/stream\.cgi\//) && t.match("method=transcode") || t.match(/\/webapi\/AudioStation\/proxy.cgi\//) && !t.match(/\/webapi\/AudioStation\/proxy.cgi\/0\.raw\?api/) && !t.match(/\/webapi\/AudioStation\/proxy.cgi\/.+format=raw/))
        },
        rt = function(t) {
            return !!t.match("api=SYNO.AudioStation.Stream")
        },
        dt = function(t) {
            r = 0, h = !(!soundManager.getSoundById(C) || !lt(soundManager.getSoundById(C).url)), M === t ? f = !1 : P = !1, soundManager.getSoundById(C) ? soundManager.getSoundById(C).paused ? (soundManager.setPosition(C, 0), soundManager.setVolume(C, soundManager.getSoundById(b).volume), soundManager.getSoundById(C).togglePause()) : (soundManager.setPosition(C, 0), soundManager.setVolume(C, soundManager.getSoundById(b).volume)) : at()
        },
        ut = function() {
            var t, e = M === this.id ? f : P;
            et(), e && dt(this.id), t = b, b = C, C = t, at(!0)
        },
        gt = function() {
            2 === this.readyState ? b === this.id ? at() : (v = v > p - s ? v + 1 : p - s + 1, nt(!0, v)) : C === this.id && (v = 1, soundManager.getSoundById(C).togglePause())
        },
        ct = function() {
            "__SYNO_WEB_PLAYER__" === t.gCurrentSelectPlayer && (t.playerPanel.Ctrl.setBtnPause(soundManager.getSoundById(b) && !soundManager.getSoundById(b).paused), t.playerPanel.Ctrl.setRecordPause(soundManager.getSoundById(b) && soundManager.getSoundById(b).paused))
        },
        ht = function() {
            var e;
            M === this.id ? f = !0 : P = !0, t.isInLyricsMode() || (e = t.audioWebPlayer.getCurrentRecord(), SYNO.SDS.AudioStation.Utils.isLocalMusic(e) && w.delay(500, function() {
                t.lyricsMgr.getLyrics(e)
            }, this)), i = !1
        },
        St = function() {
            var e = M === this.id ? f : P,
                n = 1e3 > j() - this.position && this.duration ? this.duration : j();
            b === this.id && "__SYNO_WEB_PLAYER__" === t.gCurrentSelectPlayer && (0 < n && 100 > n - this.position && e && dt(this.id), Z(), t.playerPanel.Ctrl.setBtnPause(soundManager.getSoundById(b) && !soundManager.getSoundById(b).paused), t.playerPanel.Ctrl.setRecordPause(soundManager.getSoundById(b) && soundManager.getSoundById(b).paused), !i && this.position / 1e3 > 10 && (i = !0, Q()))
        },
        pt = function(t, e, n) {
            i = !1;
            var a = null,
                o = null;
            return t ? a = soundManager.createSound({
                id: b,
                url: t,
                volume: y,
                bufferTime: 3,
                onfinish: ut,
                onload: gt,
                onpause: ct,
                onplay: ht,
                whileplaying: St
            }) : soundManager.destroySound(C), e ? o = soundManager.createSound({
                id: C,
                url: e,
                volume: 0,
                bufferTime: 3,
                onfinish: ut,
                onload: gt,
                onpause: ct,
                onplay: ht,
                whileplaying: St
            }) : soundManager.destroySound(C), it(), o || a
        },
        yt = function(i, a) {
            soundManager.destroySound(b), soundManager.destroySound(C), clearTimeout(e), m && (Ext.Ajax.abort(m), m = null), i || (r = 0, S = !1, z(0), et()), !a && t.isInLyricsMode() && t.playerPanel.btnLyrics.toggle(), 0 === n.getTotalCount() && (x = !0)
        },
        mt = function(t) {
            for (var e, i = B(o), n = null; null === n;) {
                if (i = B(i), null === (e = W(i))) return null;
                if (e === t) return null;
                if (!(n = H(e))) return null;
                n.data && n.data.support && !U(n) || (n = null)
            }
            return p = e, n
        },
        ft = function(t, e) {
            for (var i = null, n = null; null === n;) {
                if (null === (i = -1 === e ? G() : k(!0))) return null;
                if (i === t) return null;
                if (!Y(i)) return null;
                if (!(n = F())) return null;
                n.data && n.data.support && !U(n) || (n = null)
            }
            return n
        },
        Pt = function(e, i, a) {
            if (!Y(e)) return yt(), !1;
            if (nt(i, a));
            else {
                if (t.isPlayingPage(s, n)) return yt(), !1;
                n.on("load", function() {
                    Pt(s, i, a)
                }, this, {
                    single: !0,
                    delay: 100
                }), t.checkPlayingPage(s, n)
            }
        },
        vt = function(e, i, n) {
            var a, o, s = SYNO.SDS.AudioStation.Utils;
            return m && (Ext.Ajax.abort(m), m = null), soundManager.supported() ? (e && (a = st(e, n)), i && i.data && i.data.path && (o = st(i, 0)), a || o || !e && !i ? void(Ext.isObject(a) ? (Mt(a, n, !0), t.playerPanel.Ctrl.updateCover(s.getTrackCover(e.data, "playing")), t.playerPanel.Ctrl.updateTitleArtist(e.data.title, e.data.artist, e.data.album), t.playerPanel.Ctrl.setBtnPause(!0), t.playerPanel.Ctrl.setRecordPause(!1)) : Ext.isObject(o) ? (a && _t(a, null, n), 0 < i.get("duration") ? Mt(o, 0, !1) : _t(null, null, 0)) : A || o && lt(o) || Ext.isSafari ? _t(a, null, n) : _t(a, o, n)) : null) : null
        },
        At = function() {
            var t = soundManager.getSoundById(b);
            t && !t.position && at()
        },
        _t = function(t, i, n) {
            if (pt(t, i)) {
                if (t) {
                    h = !(!soundManager.getSoundById(b) || !lt(soundManager.getSoundById(b).url));
                    var a = soundManager.play(b);
                    a instanceof Promise && a.catch(function(t) {
                        "NotAllowedError" === t.name && yt()
                    }), rt(t) || (clearTimeout(e), e = setTimeout(function() {
                        At()
                    }, 6e4))
                }
                if (i) {
                    var o = soundManager.play(C);
                    o instanceof Promise && o.catch(function(t) {
                        "NotAllowedError" === t.name && yt()
                    })
                }
            }
        },
        Mt = function(e, i, n) {
            if (!e || !e.id) return void(n && at());
            i = i || 0, m = Ext.Ajax.request({
                url: t._getUtils().getWebAPIURL("proxy.cgi"),
                params: t._getUtils().getWebAPIParams({
                    api: "SYNO.AudioStation.Proxy",
                    method: "getstreamid",
                    id: e.id
                }),
                method: "POST",
                callback: function(e, a, o) {
                    var s, l, r, d, u = SYNO.SDS.AudioStation.SessionData.settings.transcode_to_mp3,
                        g = "raw";
                    if (!a || !o || !o.responseText) return m = null, void(n && at());
                    if (!(s = Ext.decode(o.responseText)) || !s.data || !s.data.stream_id) return m = null, void(n && at());
                    if (d = s.data.format, "mp3" !== s.data.format && "flv" !== s.data.format || Ext.isSafari) {
                        if (u) g = "mp3";
                        else if (g = "flv", !soundManager.canPlayURL(".flv")) return void yt();
                        d = g
                    }
                    E = s.data.stream_id, l = "{0}/0.{8}?api={1}&version={2}&method={3}&stream_id={4}&format={5}&position={6}&_dc={7}", r = Ext.urlAppend(String.format(l, t._getUtils().getWebAPIURL("proxy.cgi"), "SYNO.AudioStation.Proxy", t._getUtils().webAPIVersion["SYNO.AudioStation.Proxy"], "stream", encodeURIComponent(decodeURIComponent(s.data.stream_id)), g, i, (new Date).getTime(), d)), t.isPublicSharing() && (r = Ext.urlAppend(r, "sharing_id=" + SYNO.SDS.AudioStation.SessionData.SharingId)), m = null, n ? (_t(r, null, i), Ct()) : lt(r) ? _t(null, null, i) : _t(null, r, 0)
                },
                scope: this
            })
        },
        bt = function(t) {
            if (void 0 !== t && -2 !== t) return -1 === t ? (a = [], o = 0, s = 0, l = -1, void yt()) : void Y(t)
        },
        Ct = function() {
            (soundManager.getSoundById(b) || soundManager.getSoundById(C)) && (S = !1, nt(!0))
        },
        Ot = function(e) {
            var i = location.pathname.split("/", 2)[1];
            if (!i) return null;
            Ext.Ajax.request({
                url: "/" + i + "/" + t.baseURL + "/webUI/audio_playing.cgi",
                params: {
                    action: "setcurrent",
                    target: "stream",
                    current: 0 > e ? 0 : e
                },
                method: "POST",
                callback: function(e, i, n) {
                    i || t._getWindow().getMsgBox().alert(this.title, _AST("common", "error_system"))
                },
                scope: this
            })
        },
        Nt = function() {
            var t, e;
            if (g && 0 !== a.length && !Dt()) {
                var i = n.getTotalCount() - a.length;
                for (t = 0; t < n.getTotalCount(); t++)
                    if (a[t] >= s + 1) a[t] += i;
                    else if (a[t] === s) {
                    for (e = 0; e < i; e++) a.splice(o + 1 + e, 0, s + 1 + e);
                    t += i
                }
            } else g ? L() : R();
            Dt() && Y(l + 1)
        },
        Dt = function() {
            return !soundManager.getSoundById(b)
        },
        wt = function(t) {
            Dt() || (l = t)
        };
    return {
        setStreamStore: function(t) {
            n = t
        },
        createStreamStore: function(e, i) {
            SYNO.SDS.AudioStation.Utils.isStreamStoreCopy = !0, n = t.createPlayingStore(i), n.load()
        },
        play: function() {
            var t = soundManager.getSoundById(b);
            t ? t.togglePause() : (g && L(), yt(!1, !0), nt(!1))
        },
        stop: function() {
            yt()
        },
        next: function() {
            return at(!1, !0)
        },
        prev: function() {
            return ot()
        },
        jump: function(t) {
            return g && (Y(t), L()), yt(!1, !0), Pt(t, !1)
        },
        setPosition: function(t) {
            t >= 0 && (h ? (r = t, yt(!0, !0), vt(F(), H(W(B(o))), t)) : soundManager.setPosition(b, 1e3 * t))
        },
        setVol: function(t) {
            y = t, soundManager.setVolume(b, t), $()
        },
        setNoRepeat: function() {
            d = !1, u = !1, Ct()
        },
        setRepeatOne: function() {
            d = !0, u = !1, Ct()
        },
        setRepeatAll: function() {
            d = !1, u = !0, Ct()
        },
        setShuffle: function(t) {
            t !== g && (g ? (g = !1, R()) : (g = !0, L()), Ct())
        },
        updateSongInfo: function() {
            it()
        },
        updatePlaylist: function(t) {
            bt(t)
        },
        updatePreload: function() {
            Ct()
        },
        getCurrentIndex: function() {
            return Dt() ? -1 : s
        },
        getCurrentRecord: function() {
            return F()
        },
        addIndex: function(t) {
            Y(s + t), Dt() && (l += t)
        },
        isReady: function() {
            return c
        },
        destroy: function() {
            soundManager && Ext.isFunction(soundManager.destroySound) && soundManager.destroySound(b)
        },
        setCurrent: function(t) {
            Ot(t)
        },
        getRadioStreamId: function() {
            return E
        },
        setKeepShuffleOrder: function(t) {
            _ = t
        },
        getKeepShuffleOrder: function() {
            return _
        },
        addToNext: function() {
            Nt()
        },
        getLastPlayIndex: function() {
            return x ? -1 : l
        },
        getPlayIndex: function() {
            return s
        },
        setPlaylistInit: function(t) {
            x = t, Y(0), l = -1
        },
        hasAddToNext: function() {
            return l !== s
        },
        isStop: function() {
            return Dt()
        }
    }
}, Ext.namespace("SYNO.SDS.AudioStation"), SYNO.SDS.AudioStation.Player = function(t, e) {
    var i = {},
        n = function(t) {
            switch (t.action) {
                case "prev":
                    e.prev();
                    break;
                case "next":
                    e.next();
                    break;
                case "play":
                case "pause":
                    void 0 !== t.value ? e.jump(t.value) : e.play();
                    break;
                case "stop":
                    e.stop();
                    break;
                case "seek":
                    void 0 !== t.value && e.setPosition(t.value);
                    break;
                case "set_volume":
                    void 0 !== t.value && e.setVol(t.value);
                    break;
                case "set_repeat":
                    if (void 0 !== t.value) switch (t.value) {
                        case SYNO.SDS.AudioStation.PlsPlayMode.NONE:
                            e.setNoRepeat();
                            break;
                        case SYNO.SDS.AudioStation.PlsPlayMode.REPEAT_ONE:
                            e.setRepeatOne();
                            break;
                        case SYNO.SDS.AudioStation.PlsPlayMode.REPEAT_ALL:
                            e.setRepeatAll()
                    }
                    break;
                case "set_shuffle":
                    void 0 !== t.value && e.setShuffle(t.value)
            }
        },
        a = function(e, i) {
            e && ("__SYNO_WEB_PLAYER__" === t.gCurrentSelectPlayer ? n(e) : (t.playerPanel.Ctrl.setUpdateDelay(1), Ext.Ajax.request({
                url: t._getUtils().getWebAPIURL("remote_player.cgi"),
                params: Ext.apply(t._getUtils().getWebAPIParams({
                    api: "SYNO.AudioStation.RemotePlayer",
                    method: "control",
                    id: t.gCurrentSelectPlayer
                }), e),
                callback: i || o,
                scope: this
            })))
        },
        o = function(t, e, i) {
            if (!e) return void SYNO.SDS.AudioStation.Window.getMsgBox().alert(_AST("playlist", "playlist"), _AST("common", "error_system"));
            var n = Ext.util.JSON.decode(i.responseText);
            return n.success ? void 0 : void(n.error && n.error.code ? SYNO.SDS.AudioStation.Window.getMsgBox().alert(_AST("playlist", "playlist"), this._getUtils().getErrMsgString(this._getUtils().getErrCodeMapping(n.error.code))) : SYNO.SDS.AudioStation.Window.getMsgBox().alert(_AST("playlist", "playlist"), _AST("common", "error_system")))
        },
        s = function() {
            return t.gCurrentSelectPlayer
        },
        l = function(t, e) {
            var n;
            n = s(), i[n] || (i[n] = {}), i[n].isMute = t, i[n].volume = e
        },
        r = function() {
            var t = s();
            return i[t]
        },
        d = function() {
            var e = r(),
                i = t.playerPanel.Ctrl;
            e && i.setMute(e.isMute)
        },
        u = function() {
            var e = t.playerPanel.Ctrl,
                i = e.getCurrentVolume();
            "__SYNO_Multiple_AirPlay__" === s() ? 0 !== t.playerPanel.volumeSlider.getValue() && (t.playerPanel.volumeSlider.setValue(0), t.playerPanel.volumeSlider.fireEvent("changecomplete", t.playerPanel.volumeSlider, 0)) : a({
                action: "set_volume",
                value: 0
            }), e.setMute(!0), l(!0, i)
        },
        g = function() {
            var e, i = t.playerPanel.Ctrl,
                n = 50;
            e = r(), e && (n = e.volume, e.isMute = !1), "__SYNO_Multiple_AirPlay__" === s() ? 0 !== t.playerPanel.volumeSlider.getValue() || t.multiAirPlayDialog && t.multiAirPlayDialog.isVisible() || (t.playerPanel.volumeSlider.setValue(t.playerPanel.volumeSlider.volumeAllCurrent), t.playerPanel.volumeSlider.fireEvent("changecomplete", t.playerPanel.volumeSlider, t.playerPanel.volumeSlider.volumeAllCurrent)) : a({
                action: "set_volume",
                value: Math.round(n)
            }), i.setMute(!1)
        },
        c = function(e) {
            t.playerPanel.Ctrl.getMute() && e > 0 && g(), a({
                action: "set_volume",
                value: Math.round(e)
            })
        },
        h = function(e, i) {
            t.playerPanel.Ctrl.getMute() && Math.max.apply(Math, i.split(",")) > 0 && g(), a({
                action: "set_volume",
                subplayer_id: e,
                value: i
            })
        };
    return {
        doPrevious: function(t, e) {
            a({
                action: "prev"
            })
        },
        doPlay: function(e, i) {
            if (t.playerPanel.Ctrl.toggleBtnPause(), t.playerPanel.Ctrl.getPlayingStatus()) a({
                action: t.playerPanel.Ctrl.getPauseStatus() ? "play" : "pause"
            });
            else {
                if (null === t.getPlayingPanel()) return void a({
                    action: "play"
                });
                var n = t.getSelectionRecords()[0];
                if (n) {
                    var o = n.index + t.playingStore.baseParams.offset;
                    a({
                        action: "play",
                        value: o
                    })
                } else a({
                    action: "play"
                })
            }
        },
        doNext: function(t, e) {
            a({
                action: "next"
            })
        },
        doStop: function(t, e) {
            a({
                action: "stop"
            })
        },
        doJump: function(t) {
            a({
                action: "play",
                value: t
            })
        },
        doSetPosition: function(t) {
            a({
                action: "seek",
                value: t
            })
        },
        doSetVolume: function(t) {
            c(t)
        },
        doSetMultipleVolumes: function(t, e) {
            h(t, e)
        },
        doFastSetVolume: function(e, i) {
            if ("__SYNO_WEB_PLAYER__" === t.gCurrentSelectPlayer) {
                if (0 === e && !i) return;
                a({
                    action: "set_volume",
                    value: Math.round(e)
                })
            }
        },
        doSetMute: function(t) {
            t ? u() : g()
        },
        updateMuteState: function() {
            d()
        },
        doSetMode: function(t) {
            a({
                action: "set_repeat",
                value: t
            })
        },
        doSetShuffle: function(t) {
            a({
                action: "set_shuffle",
                value: t
            })
        }
    }
}, Ext.define("SYNO.AudioStation.PlayerPanel.Button", {
    extend: "SYNO.ux.Button",
    constructor: function(t) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.call(this, t);
        var e = {
            handler: this.clickHandler
        };
        this.callParent([Ext.apply(e, t)])
    },
    clickHandler: Ext.emptyFn
}), Ext.define("SYNO.AudioStation.PlayerPanel.MenuButton", {
    extend: "SYNO.AudioStation.PlayerPanel.Button",
    constructor: function(t) {
        var e = {
            cls: "syno-as-menu-btn",
            menu: this.createMenu(),
            menuAlign: "br-tr"
        };
        this.callParent([Ext.apply(e, t)])
    },
    createMenu: Ext.emptyFn
}), Ext.define("SYNO.AudioStation.PlayerPanel.ToggleButton", {
    extend: "SYNO.AudioStation.PlayerPanel.Button",
    constructor: function(t) {
        var e = {
            cls: "syno-as-toggle-btn"
        };
        this.callParent([Ext.apply(e, t)])
    },
    clickHandler: function(t, e) {
        this.disabled || this.toggle()
    },
    toggleHandler: Ext.emptyFn
}), Ext.define("SYNO.AudioStation.PlayerPanel.PlayButton", {
    extend: "SYNO.AudioStation.PlayerPanel.Button",
    constructor: function(t) {
        this.audioMain = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main");
        var e = {
            tooltip: _AST("player", "play_btn_title")
        };
        this.callParent([Ext.apply(e, t)])
    },
    clickHandler: function(t, e) {
        this.audioMain.audioPlayer.doPlay()
    }
}), Ext.define("SYNO.AudioStation.PlayerPanel.PrevButton", {
    extend: "SYNO.AudioStation.PlayerPanel.Button",
    constructor: function(t) {
        this.audioMain = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main");
        var e = {
            tooltip: _AST("player", "previous_btn_title")
        };
        this.callParent([Ext.apply(e, t)])
    },
    clickHandler: function(t, e) {
        this.audioMain.audioPlayer.doPrevious()
    }
}), Ext.define("SYNO.AudioStation.PlayerPanel.NextButton", {
    extend: "SYNO.AudioStation.PlayerPanel.Button",
    constructor: function(t) {
        this.audioMain = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main");
        var e = {
            tooltip: _AST("player", "next_btn_title")
        };
        this.callParent([Ext.apply(e, t)]), this.callParent([t])
    },
    clickHandler: function(t, e) {
        this.audioMain.audioPlayer.doNext()
    }
}), Ext.define("SYNO.AudioStation.PlayerPanel.StopButton", {
    extend: "SYNO.AudioStation.PlayerPanel.Button",
    constructor: function(t) {
        this.audioMain = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main");
        var e = {
            tooltip: _AST("player", "stop_btn_title")
        };
        this.callParent([Ext.apply(e, t)])
    },
    clickHandler: function(t, e) {
        this.audioMain.audioPlayer.doStop()
    }
}), Ext.define("SYNO.AudioStation.PlayerPanel.DeviceSelectButton", {
    extend: "SYNO.AudioStation.PlayerPanel.MenuButton",
    constructor: function(t) {
        this.audioMain = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main"), this.module = t.module;
        var e = {
            disabled: !0,
            listeners: {
                scope: this,
                afterrender: this.loadStore
            }
        };
        this.callParent([Ext.apply(e, t)]), this.addClass("btn-device-stream"), this.createStore()
    },
    clickHandler: function() {
        this.audioMain.PlayerStore.load({
            callback: this.updateMenu,
            scope: this
        })
    },
    createStore: function() {
        var t = new Ext.data.JsonReader({
            root: "data.players",
            totalProperty: "total",
            id: "id"
        }, ["device_count", "id", "name", "password_protected", "support_seek", "support_set_volume", "type"]);
        this.audioMain.PlayerStore = new Ext.data.Store({
            proxy: new Ext.data.HttpProxy({
                url: this._getUtils().getWebAPIURL("remote_player.cgi"),
                method: "POST"
            }),
            reader: t,
            remoteSort: !1,
            baseParams: this._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.RemotePlayer",
                method: "list",
                type: "all",
                additional: "subplayer_list"
            }),
            pruneModifiedRecords: !1,
            listeners: {
                scope: this,
                single: !0,
                load: function(t, e, i) {
                    var n = this._getWindow().appInstance.getUserSettings("CurrentSelectPlayer");
                    if (!n || "__SYNO_WEB_PLAYER__" === n || "__SYNO_Multiple_AirPlay__" === n && 0 === t.getById(n).json.additional.subplayer_list.length) "__SYNO_WEB_PLAYER__" == this.audioMain.gCurrentSelectPlayer && (this.audioMain.gCurrentSelectPlayer = void 0), this.audioMain.updatePlayingModeInfo.call(this.audioMain, "stream", null), this.updateBtnClass("stream", _AST("player", "to_my_computer"));
                    else {
                        var a = t.getById(n);
                        this.audioMain.updatePlayingModeInfo.call(this.audioMain, "renderer", a), a && this.updateBtnClass(a.get("type"), a.get("name"))
                    }
                    this.updateMenu()
                }
            }
        })
    },
    createMenu: function() {
        return this.PlayingDeviceMenu ? this.PlayingDeviceMenu : (this.PlayingDeviceMenu = new SYNO.ux.Menu({
            itemId: "playingDeviceMenu",
            cls: "syno-ux-check-menu",
            autoScroll: !0,
            maxHeight: 850,
            items: [],
            listeners: {
                scope: this
            }
        }), this.PlayingDeviceMenu)
    },
    loadStore: function() {
        this.audioMain.PlayerStore.load()
    },
    updateMenu: function() {
        this.PlayingDeviceMenu.removeAll();
        var t = this.audioMain.gCurrentSelectPlayer,
            e = new Ext.menu.CheckItem({
                text: _AST("player", "to_my_computer"),
                checked: "__SYNO_WEB_PLAYER__" === t,
                group: "players",
                handler: this.onPlayingModeSelected.createDelegate(this, ["stream"]),
                listeners: {
                    render: function() {
                        this.getEl().dom.qtip = _AST("player", "to_my_computer")
                    }
                }
            });
        this.PlayingDeviceMenu.addItem(e), this.audioMain.PlayerStore.data.each(function(i) {
            var n, a, o, s = i.get("id");
            "__SYNO_Multiple_AirPlay__" === s ? (a = _AST("player", "to_multiple_airplay"), o = a) : (n = i.get("name"), o = Ext.util.Format.htmlEncode(n), a = Ext.util.Format.ellipsis(n, 40, !1));
            var l, r, d = function() {
                    this.getEl().dom.qtip = o
                },
                u = "";
            l = this.onPlayingModeSelected.createDelegate(this, ["renderer", i]), r = s === t, u = !0 === i.get("password_protected") ? "syno-as-player-passwd" : "", e = new Ext.menu.CheckItem({
                text: a,
                checked: r,
                group: "players",
                cls: u,
                handler: l,
                listeners: {
                    render: d
                }
            }), this.PlayingDeviceMenu.addItem(e)
        }, this), this.setDisabled(!1), this.PlayingDeviceMenu.hidden || this.PlayingDeviceMenu.showAt([this.getEl().getX() - this.PlayingDeviceMenu.getWidth() + 32, this.getEl().getY() - this.PlayingDeviceMenu.getHeight()]), "__SYNO_WEB_PLAYER__" === t || this.audioMain.getCurrentRendererRecord() || this.audioMain.switchToStreamingMode()
    },
    updateBtnClass: function(t, e) {
        this.removeClass(["btn-device-stream", "btn-device-airplay", "btn-device-upnp"]), this.addClass("btn-device-" + t), this.setTooltip(e)
    },
    onPlayingModeSelected: function(t, e) {
        "stream" === t ? this.updateBtnClass(t, _AST("player", "to_my_computer")) : this.updateBtnClass(e.get("type"), e.get("name")), this.audioMain.onPlayingModeSelected.call(this.audioMain, t, e)
    }
}), Ext.define("SYNO.AudioStation.PlayerPanel.VolumeButton", {
    extend: "SYNO.AudioStation.PlayerPanel.MenuButton",
    constructor: function(t) {
        this.audioMain = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main"), this.module = t.module;
        var e = {
            tooltip: _AST("player", "volume_btn_title"),
            menuAlign: "b-t"
        };
        this.callParent([Ext.apply(e, t)])
    },
    onClick: function(t) {
        t && t.preventDefault(), 0 !== t.button || this.disabled || this.handler && this.handler.call(this, this, t)
    },
    clickHandler: function(t, e) {
        this.audioMain.playerPanel.Ctrl.getMute() ? this.audioMain.audioPlayer.doSetMute(!1) : this.audioMain.audioPlayer.doSetMute(!0)
    },
    createMenu: function() {
        return this.volumeSlider = new SYNO.SDS.AudioStation.Slider.VerticalVolumeSlider({
            height: 134,
            width: 22,
            audioAppMain: this.audioMain
        }), this.volumePanel = new SYNO.ux.Panel({
            cls: "syno-as-vertical-volume-panel",
            height: 144,
            width: 22,
            items: [this.volumeSlider]
        }), this.volumeMenu = new SYNO.ux.Menu({
            cls: "syno-as-vertical-volume-menu",
            height: 172,
            width: 52,
            items: [this.volumePanel],
            listeners: {
                scope: this,
                beforeshow: function() {
                    var t = this.audioMain.playerPanel.Ctrl;
                    t.updateVolume(t.getCurrentVolume())
                }
            }
        }), this.volumeMenu
    },
    setMute: function(t) {
        t ? (this.addClass("muted"), this.hideMenu()) : (this.removeClass("muted"), this.getEl().hasClass("x-btn-over") && this.showMenu())
    },
    onMouseOver: function(t) {
        this.disabled || this.showMenu(), this.callParent(arguments)
    }
}), Ext.define("SYNO.AudioStation.PlayerPanel.SwitchMiniButton", {
    extend: "SYNO.AudioStation.PlayerPanel.Button",
    constructor: function(t) {
        this.audioMain = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main"), this.module = t.module;
        var e = {
            tooltip: _AST("player", "switch_to_mini_player")
        };
        this.callParent([Ext.apply(e, t)])
    },
    clickHandler: function(t, e) {
        this.module.switchToMiniPlayer.call(this.module)
    }
}), Ext.define("SYNO.AudioStation.PlayerPanel.ShuffleButton", {
    extend: "SYNO.AudioStation.PlayerPanel.ToggleButton",
    constructor: function(t) {
        this.audioMain = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main"), this.module = t.module;
        var e = {
            tooltip: _AST("player", "shuffle_btn_title")
        };
        this.callParent([Ext.apply(e, t)])
    },
    toggleHandler: function(t, e, i) {
        this.audioMain.audioPlayer.doSetShuffle(e)
    }
}), Ext.define("SYNO.AudioStation.PlayerPanel.RepeatButton", {
    extend: "SYNO.AudioStation.PlayerPanel.Button",
    constructor: function(t) {
        this.audioMain = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main"), this.module = t.module;
        var e = {
            tooltip: _AST("player", "repeat_mode_set"),
            repeatState: SYNO.SDS.AudioStation.PlsPlayMode.NONE
        };
        this.callParent([Ext.apply(e, t)])
    },
    clickHandler: function(t, e) {
        switch (this.repeatState) {
            case SYNO.SDS.AudioStation.PlsPlayMode.NONE:
                this.setRepeatState(SYNO.SDS.AudioStation.PlsPlayMode.REPEAT_ALL);
                break;
            case SYNO.SDS.AudioStation.PlsPlayMode.REPEAT_ONE:
                this.setRepeatState(SYNO.SDS.AudioStation.PlsPlayMode.NONE);
                break;
            case SYNO.SDS.AudioStation.PlsPlayMode.REPEAT_ALL:
                this.setRepeatState(SYNO.SDS.AudioStation.PlsPlayMode.REPEAT_ONE)
        }
        this.audioMain.audioPlayer.doSetMode(this.repeatState)
    },
    setRepeatState: function(t) {
        switch (this.removeClass(["btn_mode_repeat_one", "btn_mode_repeat_all"]), t) {
            case SYNO.SDS.AudioStation.PlsPlayMode.NONE:
                this.repeatState = SYNO.SDS.AudioStation.PlsPlayMode.NONE;
                break;
            case SYNO.SDS.AudioStation.PlsPlayMode.REPEAT_ONE:
                this.repeatState = SYNO.SDS.AudioStation.PlsPlayMode.REPEAT_ONE, this.addClass("btn_mode_repeat_one");
                break;
            case SYNO.SDS.AudioStation.PlsPlayMode.REPEAT_ALL:
                this.repeatState = SYNO.SDS.AudioStation.PlsPlayMode.REPEAT_ALL, this.addClass("btn_mode_repeat_all")
        }
    }
}), Ext.define("SYNO.AudioStation.PlayerPanel.LyricsButton", {
    extend: "SYNO.AudioStation.PlayerPanel.ToggleButton",
    constructor: function(t) {
        this.audioMain = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main"), this.module = t.module;
        var e = {
            tooltip: _AST("common", "lyrics")
        };
        this.callParent([Ext.apply(e, t)])
    },
    toggleHandler: function(t, e, i) {
        this.module.setLyricsPanelDisplay.call(this.module, e)
    }
}), Ext.define("SYNO.AudioStation.PlayerPanel.PlayingQueueButton", {
    extend: "SYNO.AudioStation.PlayerPanel.ToggleButton",
    constructor: function(t) {
        this.audioMain = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main"), this.module = t.module;
        var e = {
            tooltip: _AST("common", "playing_queue")
        };
        this.callParent([Ext.apply(e, t)])
    },
    toggleHandler: function(t, e, i) {
        this.module.setPlayingQueueDisplay.call(this.module, e)
    }
}), Ext.define("SYNO.AudioStation.PlayerPanel.EQButton", {
    extend: "SYNO.AudioStation.PlayerPanel.ToggleButton",
    constructor: function(t) {
        this.audioMain = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main"), this.module = t.module;
        var e = {
            tooltip: _AST("eq", "eq_name")
        };
        this.callParent([Ext.apply(e, t)])
    },
    clickHandler: function() {
        this.disabled || this.module.showEQDialog.call(this.module)
    }
}), Ext.namespace("SYNO.SDS.AudioStation"), SYNO.SDS.AudioStation.PlsPlayMode = {
    NONE: "none",
    NORMAL: "normal",
    REPEAT_ONE: "one",
    REPEAT_ALL: "all"
}, SYNO.SDS.AudioStation.PlayerState = {
    NONE: 0,
    STOPPED: 1,
    PLAYING: 2,
    PAUSED: 3,
    TRANSITIONING: 4,
    WAITING: 5,
    NO_MEDIA: 6
}, Ext.define("SYNO.SDS.AudioStation.PlayerPanel", {
    extend: "SYNO.ux.Panel",
    isFromBrowseToLyrics: !0,
    NORMAL_HEIGHT: 74,
    MOBILE_HEIGHT: 102,
    constructor: function(t) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.call(this, t), SYNO.SDS.AudioStation.Window.addPanelScope("SYNO.SDS.AudioStation.PlayerPanel", this);
        var e = this.fillConfig(t);
        this.callParent([e]), this.initPlayerPanel(), this.createCtrlObj()
    },
    fillConfig: function(t) {
        this.isMobileStyle = this._getWindow().isMobile;
        var e = Ext.apply({
            xtype: "syno_panel",
            html: this.isMobileStyle ? this.getMobileHtml() : this.getHtml(t.audioAppMain.isPublicSharing()),
            border: !1,
            height: this.isMobileStyle ? this.MOBILE_HEIGHT : this.NORMAL_HEIGHT,
            bodyCssClass: "syno-as-panel-body",
            listeners: {
                buffer: 100,
                afterrender: this.onPanelAfterRender.createDelegate(this),
                resize: this.onPanelResize.createDelegate(this)
            }
        });
        return Ext.apply(e, t), e
    },
    onPanelAfterRender: function(t, e) {
        this.renderPositionSlider(), this._getUtils().isIosDevice() && this.audioAppMain.isWebPlayer() && this.Ctrl.setSetVolumeAbility(!1), this.btnPrev.render(this.getEl().child(".player-prev")), this.btnPlay.render(this.getEl().child(".player-play")), this.btnNext.render(this.getEl().child(".player-next")), this.btnStop.render(this.getEl().child(".player-stop")), this.btnShuffle.render(this.getEl().child(".player-shuffle")), this.btnRepeat.render(this.getEl().child(".player-repeat")), this.renderLyricsBtn(), this.isMobileStyle ? this.getVolumeSlider().render(this.getEl().child(".volume-slider")) : (this.btnVolume.render(this.getEl().child(".player-volume")), this.setSongInfoVisible(!1), this.audioAppMain.isPublicSharing() || (this.btnQueue.render(this.getEl().child(".player-queue")), this.btnDevice.render(this.getEl().child(".player-device")), this.btnMini.render(this.getEl().child(".player-mini")))), this.addVolumeIconEvent()
    },
    renderPositionSlider: function() {
        this.isMobileStyle ? this.getPositionSlider().render(this.audioAppMain.coverPanel.getInfoElement("syno-as-mobile-slider")) : (this.getPositionSlider().render(this.getEl().child(".syno-as-player-slider")), this._getUtils().isMobileDevice() ? this.positionSlider.setPositionSlideThumbVisible(!0) : (this.getEl().on("mouseover", function() {
            this.positionSlider.setPositionSlideThumbVisible(!0)
        }, this), this.getEl().on("mouseleave", function() {
            this.positionSlider.setPositionSlideThumbVisible(!1)
        }, this)))
    },
    renderLyricsBtn: function() {
        this.isMobileStyle ? this.btnLyrics.render(this._getWindow().getTool("syno_as_lyrics")) : this.btnLyrics.render(this.getEl().child(".player-lyrics"))
    },
    onPanelResize: function() {
        this.isMobileStyle || this.getPositionSlider().setWidth(this.getWidth() + 14)
    },
    initPlayerPanel: function() {
        this.btnPrev = new SYNO.AudioStation.PlayerPanel.PrevButton({
            module: this
        }), this.btnPlay = new SYNO.AudioStation.PlayerPanel.PlayButton({
            module: this
        }), this.btnNext = new SYNO.AudioStation.PlayerPanel.NextButton({
            module: this
        }), this.btnStop = new SYNO.AudioStation.PlayerPanel.StopButton({
            module: this
        }), this.isMobileStyle || (this.btnVolume = new SYNO.AudioStation.PlayerPanel.VolumeButton({
            module: this
        }), this.btnDevice = new SYNO.AudioStation.PlayerPanel.DeviceSelectButton({
            module: this
        })), this.btnMini = new SYNO.AudioStation.PlayerPanel.SwitchMiniButton({
            hidden: _S("standalone") || this.audioAppMain.isPublicSharing(),
            module: this
        }), this.btnShuffle = new SYNO.AudioStation.PlayerPanel.ShuffleButton({
            module: this
        }), this.btnRepeat = new SYNO.AudioStation.PlayerPanel.RepeatButton({
            module: this
        }), this.btnLyrics = new SYNO.AudioStation.PlayerPanel.LyricsButton({
            disabled: !0,
            module: this
        }), this.btnQueue = new SYNO.AudioStation.PlayerPanel.PlayingQueueButton({
            module: this
        })
    },
    addVolumeIconEvent: function() {
        this.isMobileStyle ? (this.volumeBtn = this.getEl().child(".volume-icon"), this.volumeBtn && (this._getUtils().isIosDevice() && this.audioAppMain.isWebPlayer() && this.setMuteBtnDisabled(!0), this.volumeBtn.on("click", function(t, e, i) {
            this.onVolumeIconClick()
        }, this))) : this._getUtils().isIosDevice() && this.audioAppMain.isWebPlayer() && this.setMuteBtnDisabled(!0)
    },
    setMuteBtnDisabled: function(t) {
        this.isMobileStyle ? this.volumeBtn[t ? "addClass" : "removeClass"]("volume-disabled") : this.btnVolume.setDisabled(t)
    },
    onVolumeIconClick: function() {
        this.volumeBtn.hasClass("volume-disabled") || (this.Ctrl.getMute() ? this.audioAppMain.audioPlayer.doSetMute(!1) : this.audioAppMain.audioPlayer.doSetMute(!0))
    },
    setLyricsPanelDisplay: function(t) {
        t && this.btnQueue.toggle(!1);
        var e = this.isMobileStyle ? "mobileDisplayLyricsPanel" : "displayLyricsPanel";
        this.audioAppMain[e](t)
    },
    setPlayingQueueDisplay: function(t) {
        t && this.btnLyrics.toggle(!1), this.audioAppMain.gIsOnLargePlayingQueue = t, this.audioAppMain.mainCardPanel.getLayout().setActiveItem(t ? "LargePlayingQueue" : "browse"), !t && this._getUtils().isInPlaylist() && this.audioAppMain.cardPanel.getLayout().activeItem.fireEvent("activate"),
            function() {
                this.audioAppMain.focusHighlightRow(this.audioAppMain.getCurrentPlayingIndex())
            }.createDelegate(this).defer(100)
    },
    clearLyricsBtnState: function() {
        this.btnLyrics.toggle(!1)
    },
    refreshLyrics: function(t) {
        return this.audioAppMain.gIsOnMiniPlayerMode && this.audioAppMain.miniPlayer && this.audioAppMain.miniPlayer.isInLyricsMode() ? void this.audioAppMain.miniPlayer.lyricsPanel.setLyrics(t) : this.audioAppMain.gIsOnLargePlayingQueue && this.audioAppMain.largePlayingQueuePanel.isInLyricsMode() ? void this.audioAppMain.largePlayingQueuePanel.lyricsPanel.setLyrics(t) : void(this.audioAppMain.isPublicSharing() && this.isMobileStyle && this.audioAppMain.lyricsPanel.setLyrics(t))
    },
    switchToMiniPlayer: function() {
        var t, e = this._getWindow().getBox();
        this.audioAppMain.gIsOnMiniPlayerMode = !0, this._getWindow().hide(), this.audioAppMain.miniPlayer ? this.audioAppMain.miniPlayer.isVisible() || (this.audioAppMain.miniPlayer.resetInfo(), this.audioAppMain.playerPanel.refreshLyrics(this.audioAppMain.getCurrentPlayingRecord()), this.audioAppMain.miniPlayer.show()) : (t = {
            cls: "syno-as-mini-player-window",
            audioAppWindow: this._getWindow(),
            audioAppMain: this.audioAppMain,
            normalPlayerBox: e,
            header: !1,
            owner: this._getWindow()
        }, Ext.apply(t, this.audioAppMain.miniPlayerSizePosition), this.audioAppMain.miniPlayer = new SYNO.SDS.AudioStation.MiniPlayer(t), this.audioAppMain.miniPlayer.open()), this._getWindow().taskButton && (this._getWindow().taskButton.contextMenu.defaultActions.maximize.setHidden(!0), this._getWindow().taskButton.contextMenu.defaultActions.minimize.setHidden(!0), this._getWindow().taskButton.contextMenu.defaultActions.restore.setHidden(!0))
    },
    setSongInfoVisible: function(t) {
        var e = this.getPlayerElement("syno-as-player-song-info");
        e && !this.audioAppMain.isPublicSharing() && e.setVisible(t)
    },
    getPlayerElement: function(t) {
        return this.getEl().child("." + t)
    },
    getPositionSlider: function() {
        return this.positionSlider ? this.positionSlider : (this.positionSlider = new SYNO.SDS.AudioStation.Slider.PositionSlider({
            width: 216,
            clickRange: [0, 6],
            audioAppMain: this.audioAppMain
        }), this.positionSlider)
    },
    getPositionTextEl: function() {
        return this.isMobileStyle ? this.audioAppMain.coverPanel.getInfoElement("info-position") : this.getPlayerElement("info-position")
    },
    getDurationTextEl: function() {
        return this.isMobileStyle ? this.audioAppMain.coverPanel.getInfoElement("info-duration") : this.getPlayerElement("info-duration")
    },
    getVolumeSlider: function() {
        if (this.volumeSlider) return this.volumeSlider;
        if (this.isMobileStyle) {
            this.volumeSlider = new SYNO.SDS.AudioStation.Slider.VolumeSlider({
                width: 216,
                clickRange: [0, 6],
                disabled: SYNO.SDS.AudioStation.Utils.isIosDevice() && this.audioAppMain.isWebPlayer(),
                audioAppMain: this.audioAppMain
            })
        } else this.volumeSlider = this.btnVolume.volumeSlider;
        return this.volumeSlider
    },
    getHtml: function(t) {
        var e = ['<div class="syno-as-player-position-block">', '<div class="info-position"></div>', "<div>/</div>", '<div class="info-duration"></div>', "</div>"].join(""),
            i = ['<div class="syno-as-player-div">', '<div class="syno-as-player-slider">', "</div>", '<div class="syno-as-control">', '<div class="syno-as-control-left">', '<div class="player-prev"></div>', '<div class="player-play"></div>', '<div class="player-next"></div>', '<div class="player-stop"></div>', "</div>", '<div class="syno-as-control-right">', '<div class="player_btns">', '<div class="player-panel-section">', '<div class="player-btn player-queue"></div>', '<div class="player-btn player-lyrics"></div>', "</div>", '<div class="player-panel-section">', '<div class="player-btn player-volume"></div>', '<div class="player-btn player-repeat"></div>', '<div class="player-btn player-shuffle"></div>', '<div class="player-btn player-eq"></div>', "</div>", '<div class="player-panel-section">', '<div class="player-btn player-device"></div>', '<div class="player-btn player-mini"></div>', "</div>", "</div>", "</div>", t ? ['<div class="syno-as-public-share-info">', e, "</div>"].join("") : "", '<div class="syno-as-info">', '<div class="syno-as-player-thumb">', '<img class="player-info-thumb" src="{0}" qtip="">', "</div>", '<div class="syno-as-player-song-info">', '<div class="info-title"></div>', '<div class="info-album-artist"></div>', t ? "" : e, "</div>", "</div>", "</div>", "</div>"].join("");
        return i = String.format(i, Ext.BLANK_IMAGE_URL)
    },
    getMobileHtml: function() {
        var t = ['<div class="syno-as-player-div">', '<div class="syno-as-control">', '<div class="syno-as-control-btns">', '<div class="player-shuffle"></div>', '<div class="player-prev"></div>', '<div class="player-play"></div>', '<div class="player-next"></div>', '<div class="player-stop"></div>', '<div class="player-repeat"></div>', "</div>", '<div class="player_volume">', '<div class="volume-icon"></div>', '<div class="volume-slider"></div>', "</div>", "</div>", "</div>"].join("");
        return t = String.format(t, Ext.BLANK_IMAGE_URL)
    },
    createCtrlObj: function() {
        var t = this;
        this.Ctrl = function(e) {
            var i, n, a, o, s, l, r, d, u = {
                    title: "",
                    artist: "",
                    album: "",
                    cover: "",
                    volume: 50
                },
                g = {},
                c = {},
                h = t.getVolumeSlider(),
                S = t.getPositionSlider(),
                p = -1,
                y = -1,
                m = null,
                f = null,
                P = null,
                v = 0,
                A = 0,
                _ = 0,
                M = !1,
                b = !0,
                C = !0,
                O = !0,
                N = !1,
                D = 0,
                w = function(t) {
                    var e = {};
                    return e.widthAvailable = t.dom.offsetWidth, e.widthElem = t.dom.firstChild.offsetWidth, e.widthDiff = e.widthElem - e.widthAvailable, e
                },
                E = function(t) {
                    if (t.delay > 0) return void t.delay--;
                    1 === t.direction ? t.left > 0 ? (t.direction = -1, t.delay = 50) : (t.left += t.direction, t.elem.setLeft(t.left + "px")) : t.left < -t.diff - 10 ? (t.direction = 1, t.delay = 50) : (t.left += t.direction, t.elem.setLeft(t.left + "px"))
                },
                x = function(t, i) {
                    var n, a = Ext.util.Format.htmlEncode(i);
                    c[t.id] && c[t.id].stop(), t.update("<span>" + a + "</span>"), t.dom.qtip = a;
                    var o = w(t);
                    o.widthDiff > 0 && (n = ["<div", ' style="', "position: relative;", "width: " + o.widthElem + "px;", "", '"', ">", a, "</div>"], t.update(n.join("")), g[t.id] = {
                        elem: t.first(),
                        left: 0,
                        direction: -1,
                        width: o.widthElem,
                        diff: o.widthDiff,
                        delay: 50
                    }, c[t.id] = e.addTask({
                        run: E,
                        interval: 100,
                        args: [g[t.id]]
                    }), c[t.id].start())
                },
                I = function(i, n) {
                    var a = t.getPlayerElement("info-title");
                    e.gIsOnMiniPlayerMode && (a = e.miniPlayer.getInfoElement("mini-title")), (n || i !== u.title) && (a && x(a, i), u.title = i, e.isPublicSharing() || e._getWindow().onUpdateTitle(i), (e.gIsMobileStyle || e.gIsOnLargePlayingQueue) && x(e.getLargeCoverPanel().getInfoElement("lpq-title-text"), i))
                },
                Y = function() {
                    return u.title
                },
                R = function(t, i) {
                    var n = null;
                    (e.gIsMobileStyle || e.gIsOnLargePlayingQueue) && (n = e.getLargeCoverPanel().getInfoElement("lpq-artist-text")), n && (i || u.artist !== t) && (u.artist = t, x(n, t))
                },
                L = function() {
                    return u.artist
                },
                T = function(t, i) {
                    var n = null;
                    (n = e.gIsOnMiniPlayerMode ? e.miniPlayer.getInfoElement("mini-album") : e.getLargeCoverPanel().getInfoElement("lpq-album-text")) && (i || t !== u.album) && (u.album = t, x(n, t))
                },
                U = function(n, a, o) {
                    if (i || (i = t.getPlayerElement("info-album-artist")), (o || n !== u.album || a !== u.artist) && ((e.gIsMobileStyle || e.gIsOnLargePlayingQueue || e.gIsOnMiniPlayerMode) && (T(n, o), R(a, o)), !e.gIsOnMiniPlayerMode)) {
                        u.album = n, u.artist = a;
                        var s = n;
                        n && a ? s = n + " - " + a : a && (s = a), i && x(i, s)
                    }
                },
                V = function(t, i, n) {
                    if (!e.isPublicSharing() && "file" === i) {
                        var a = e.largePlayingQueuePanel.getInfoElement(SYNO.SDS.AudioStation.Utils.getRatingClass("song_container"));
                        e.largePlayingQueuePanel.setStarEl(n), SYNO.SDS.AudioStation.Utils.applySongRatingAndDisplay(a, n), SYNO.SDS.AudioStation.Utils.showOnlySongRatingOn(a)
                    }
                },
                k = function() {
                    return u.album
                },
                B = function(t) {
                    return !(!t.thumbs || t.thumbs.length < 1) && t.thumbs[0].dragging
                },
                W = function(i, n) {
                    var r, u, g;
                    if (a || (a = t.getPositionTextEl()), e.gIsOnMiniPlayerMode && !o && (o = e.miniPlayer.getInfoElement("info-position")), s || (s = t.getDurationTextEl()), e.gIsOnMiniPlayerMode && !l && (l = e.miniPlayer.getInfoElement("info-duration")), e.gIsOnMiniPlayerMode && !d && (d = e.miniPlayer.positionSlider), e.gIsOnMiniPlayerMode ? (r = o, u = l, g = d) : (r = a, u = s, g = S), r) {
                        if (A = i || 0, !n) return g.disable(), g.setValue(0), v = 0, r.dom.innerHTML = i ? SYNO.SDS.AudioStation.Utils.timeRenderer(i) : "--:--", u.dom.innerHTML = "--:--", void(u.qtip = "");
                        v = n, u.dom.innerHTML = SYNO.SDS.AudioStation.Utils.timeRenderer(n), u.qtip = SYNO.SDS.AudioStation.Utils.timeRenderer(n), r.dom.innerHTML = i ? SYNO.SDS.AudioStation.Utils.timeRenderer(i) : "0:00", C ? g.enable() : g.disable(), g.updatePosition(i)
                    }
                },
                H = function() {
                    return e.gIsOnMiniPlayerMode && !r && (r = e.miniPlayer.volumeSlider), e.gIsOnMiniPlayerMode ? r : h
                },
                F = function(t) {
                    var i = H();
                    if (O) i.enable();
                    else if (i.disable(), SYNO.SDS.AudioStation.Utils.isIosDevice() && e.isWebPlayer()) return;
                    if (u.volume = t, !B(i)) {
                        if (0 < i.delayPollingModifyFlag) return void i.delayPollingModifyFlag--;
                        i.setValue(t)
                    }
                },
                Q = function(t) {
                    var i, n = e.multiAirPlayDialog;
                    if (t && n && n.isVisible() && !e.passwordDialog && !n.stopSetSubVolumeFlag && !n.volumeAllSlider.thumbs[0].dragging) {
                        for (i = 0; i < n.volumeSliderList.length; i++)
                            if (n.volumeSliderList[i].thumbs[0].dragging) return;
                        if (0 < n.delayPollingModifyFlag) return void n.delayPollingModifyFlag--;
                        n.setSelectedAirPlay(t), n.firstSlider = ""
                    }
                },
                G = function() {
                    return u.volume
                },
                q = function(i, n) {
                    var a = H(),
                        o = t.isMobileStyle,
                        s = e.gIsOnMiniPlayerMode ? e.miniPlayer.volumeBtn : o ? t.volumeBtn : t.btnVolume;
                    s && (o || e.gIsOnMiniPlayerMode ? (s.removeClass("volume-mute"), i && (s.addClass("volume-mute"), a.setValue(0))) : s.setMute(i), N = i)
                },
                j = function() {
                    return N
                },
                z = function(e) {
                    t.btnRepeat.setRepeatState(e)
                },
                X = function(e) {
                    t.btnShuffle.toggle(e, !0)
                },
                K = function(i) {
                    i && e.gIsOnLargePlayingQueue && e.largePlayingQueuePanel.isInLyricsMode() || t.btnLyrics.setDisabled(i)
                },
                J = function() {
                    e.miniPlayer && e.miniPlayer.lyricsPanel && e.miniPlayer.lyricsPanel.clearLyrics(), e.largePlayingQueuePanel && e.largePlayingQueuePanel.lyricsPanel && e.largePlayingQueuePanel.lyricsPanel.clearLyrics()
                },
                Z = function(t) {
                    C = t
                },
                $ = function(t) {
                    O = t
                },
                tt = function(i) {
                    var n, a, o;
                    e.gIsOnMiniPlayerMode ? (i && (o = -1 !== i.indexOf("view=playing") ? i.replace("view=playing", "view=mini") : i.replace("audio_album_music_s.png", "_mini_player/audio_album_music_mini.png")), a = e.miniPlayer.getInfoElement("player-info-thumb"), n = 76) : e.gIsMobileStyle ? (i && (o = -1 !== i.indexOf("view=playing") ? i.replace("view=playing", "view=large") : i.replace("audio_album_music_s.png", "audio_default_music_album.png")), a = e.coverPanel.getInfoElement("lpq-thumb-img"), n = 240) : (o = i, a = t.getPlayerElement("player-info-thumb"), n = 48), a && (u.cover = i, et(a, o, n), e.gIsOnLargePlayingQueue && (i && (o = -1 !== i.indexOf("view=playing") ? i.replace("view=playing", "view=large") : i.replace("audio_album_music_s.png", "audio_default_music_album.png")), et(e.largePlayingQueuePanel.getInfoElement("lpq-thumb-img"), o, 320)))
                },
                et = function(t, e, i) {
                    if (t) {
                        var n = new Image,
                            a = e;
                        a || (a = Ext.BLANK_IMAGE_URL), -1 !== a.search(/icon_radio_96.png/) && (a = 320 == i ? SYNO.SDS.AudioStation.Utils.getImageByDisplay("audio_default_radio.png") : 76 == i ? SYNO.SDS.AudioStation.Utils.getImageByDisplay("_mini_player/audio_album_radio_mini.png") : SYNO.SDS.AudioStation.Utils.getImageByDisplay("audio_album_radio_s.png")), n.onload = it.createDelegate(this, [t, n, a, i]), n.onerror = nt.createDelegate(this, [t, n, a, i]), n.src = Ext.urlAppend(a)
                    }
                },
                it = function(t, e, i, n) {
                    SYNO.SDS.AudioStation.Utils.setImgFitCenterStyle(t, e, n), i === Ext.BLANK_IMAGE_URL ? t.parent().removeClass("syno-as-cover-hide-bg") : t.parent().addClass("syno-as-cover-hide-bg"), t.dom.src = e.src
                },
                nt = function(t, e, i, n) {
                    SYNO.SDS.AudioStation.Utils.resetImgSize(t, n), SYNO.SDS.AudioStation.Utils.setImgFitCenterStyle(t, e, n), i === Ext.BLANK_IMAGE_URL ? t.parent().removeClass("syno-as-cover-hide-bg") : t.parent().addClass("syno-as-cover-hide-bg"), t.dom.src = 320 === n ? SYNO.SDS.AudioStation.Utils.getImageByDisplay("audio_default_music_album.png") : 76 === n ? SYNO.SDS.AudioStation.Utils.getImageByDisplay("_mini_player/audio_album_music_mini.png") : SYNO.SDS.AudioStation.Utils.getImageByDisplay("audio_album_music_s.png")
                },
                at = function() {
                    return u.cover
                },
                ot = function(i, a) {
                    var o, s = null;
                    (a || M !== i) && (e.gIsOnMiniPlayerMode && !n && (n = e.miniPlayer.btnPlay), o = e.gIsOnMiniPlayerMode ? n : t.btnPlay, i ? (M = !0, o.addClass("player-btn-pause")) : (M = !1, o.removeClass("player-btn-pause")), (s = e.getCurrentPlayingRecord()) && s.commit())
                },
                st = function(t) {
                    var i = e.getCurrentPlayingRecord();
                    i && i.get("isNowPaused") !== t && (i.set("isNowPaused", t), i.commit())
                },
                lt = function() {
                    return M
                },
                rt = function() {
                    return b
                },
                dt = function(t) {
                    b = t
                },
                ut = function() {
                    I("", !1), U("", "", !1), e.initStarEl(), t.setSongInfoVisible(!1), W(0, 0), tt(null), ot(!1, !1), e.gIsOnMiniPlayerMode && T("", !0), p = -1, m = null, f = null, P = null, e.highlightPlayingIndex(-1), e.isPublicSharing() || e._getWindow().onUpdateTitle(null), _ = 0
                },
                gt = function() {
                    z(SYNO.SDS.AudioStation.PlsPlayMode.NONE), X(!1), F(0), Z(!0), $(!0), q(!1)
                },
                ct = function() {
                    b = !1, ut(), gt()
                },
                ht = function(i) {
                    var n = SYNO.SDS.AudioStation.Utils;
                    tt(n.getTrackCover(i.song, "playing")), U(i.song.additional.song_tag.album, i.song.additional.song_tag.artist, !1), t.refreshLyrics(e.getCurrentPlayingRecord()), St() && "" !== St().data.song_rating && V(i.song.id, i.song.type, St().data.song_rating)
                },
                St = function() {
                    return e.playingStore.getAt(p)
                },
                pt = function() {
                    return p
                },
                yt = function() {
                    return y
                };
            return {
                updateByJson: function(i) {
                    var n;
                    if (i) {
                        switch (D < i.playlist_timestamp && (SYNO.SDS.AudioStation.Utils.isPlayingStoreLoading || e.playingStore.reload(), D = i.playlist_timestamp), _ <= 0 && (X(i.play_mode.shuffle), z(i.play_mode.repeat)), i.state) {
                            case "playing":
                                _ <= 0 && (b = !0, ot(!0, !1), st(!1), K(!1));
                                break;
                            case "pause":
                                _ <= 0 && (b = !0, ot(!1, !1), st(!0), K(!1));
                                break;
                            default:
                                return b = !1, ut(), e.isInLyricsMode() && e.playerPanel.btnLyrics.toggle(), st(!1), F(i.volume), Q(i.subplayer_volume), K(!0), void(y !== i.stop_index && (y = i.stop_index))
                        }
                        t.setSongInfoVisible(!0), "" === i.song.title ? (n = i.song.path.lastIndexOf("/"), I(-1 === n ? i.song.path : i.song.path.substring(n + 1), !1)) : I(i.song.title, !1), _ <= 0 ? (W(i.position, i.song.additional.song_audio.duration), F(i.volume), Q(i.subplayer_volume), _ = 0) : _ -= 1, y !== i.stop_index && (y = i.stop_index), i.index === p && i.song.path === m && i.song.additional.song_tag.album === f && i.song.additional.song_tag.artist === P || (p = i.index, m = i.song.path, f = i.song.additional.song_tag.album, P = i.song.additional.song_tag.artist, e.isPlayingPage(p) ? (e.highlightPlayingIndex(p), ht(i)) : (e.playingStore.on("load", function(t, n, a) {
                            e.highlightPlayingIndex(p), ht(i)
                        }, e, {
                            single: !0
                        }), e.checkPlayingPage(p)))
                    }
                },
                updateVolume: function(t) {
                    F(t)
                },
                getCurrentVolume: function() {
                    return G()
                },
                setMute: function(t) {
                    q(t)
                },
                getMute: function() {
                    return j()
                },
                updatePositionDuration: function(t, e) {
                    W(t, e)
                },
                updateSongRating: function(t, e, i) {
                    V(0, e, i)
                },
                updateTitleArtist: function(e, i, n) {
                    t.setSongInfoVisible(!0), I(e, !1), U(n, i, !1), p = -1, m = null, f = null, P = null
                },
                updateTitle: function(t, e) {
                    I(t, e)
                },
                getCurrentTitle: function() {
                    return Y()
                },
                updateArtist: function(t, e) {
                    R(t, e)
                },
                getCurrentArtist: function() {
                    return L()
                },
                updateAlbumArtist: function(t, e, i) {
                    U(t, e, i)
                },
                updateAlbum: function(t, e) {
                    T(t, e)
                },
                getCurrentAlbum: function() {
                    return k()
                },
                updateRepeatShuffle: function(t) {
                    t && (t.all || t.one ? t.all ? z(SYNO.SDS.AudioStation.PlsPlayMode.REPEAT_ALL) : t.one && z(SYNO.SDS.AudioStation.PlsPlayMode.REPEAT_ONE) : z(SYNO.SDS.AudioStation.PlsPlayMode.NONE), X(t.shuffle))
                },
                updateCover: function(t) {
                    tt(t)
                },
                getCurrentCover: function() {
                    return at()
                },
                clearPanel: function() {
                    ct()
                },
                clearPlayingStatus: function() {
                    ut()
                },
                setBtnPause: function(t, e) {
                    ot(t, e)
                },
                setRecordPause: function(t) {
                    st(t)
                },
                getPauseStatus: function() {
                    return lt()
                },
                getPlayingStatus: function() {
                    return rt()
                },
                setPlayingStatus: function(t) {
                    return dt(t)
                },
                getDurationValue: function() {
                    return v
                },
                getPositionValue: function() {
                    return A
                },
                setUpdateDelay: function(t) {
                    _ = t
                },
                setSeekAbility: function(t) {
                    Z(t)
                },
                setSetVolumeAbility: function(t) {
                    $(t)
                },
                unsetMiniPlayerVariables: function() {
                    e.miniPlayer = void 0, n = void 0, o = void 0, l = void 0, r = void 0, d = void 0
                },
                setLyricsDisabled: function(t) {
                    K(t)
                },
                clearLyricsPanel: function(t) {
                    J()
                },
                getCurrentDaemonRecord: function() {
                    return St()
                },
                toggleBtnPause: function() {
                    ot(!lt())
                },
                getCurrentDaemonPlayingIndex: function() {
                    return pt()
                },
                getLastDaemonPlayIndex: function() {
                    return yt()
                }
            }
        }(this.audioAppMain)
    }
}), Ext.define("SYNO.SDS.AudioStation.Lyrics.Mgr", {
    extend: "Ext.util.Observable",
    MAX_POOL_SIZE: 5,
    constructor: function(t) {
        this.pool = [], SYNO.SDS.AudioStation.Utils._initWinWrappers.call(this, t), this.callParent([t]), this.audioMain = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main")
    },
    getLyrics: function(t, e, i) {
        var n, a = {},
            o = this._getUtils().isVirtualMusic(t) ? t.get("path") + "_" + t.get("track") : t.get("path");
        if ("http" !== o.substr(0, 4).toLowerCase()) {
            if (!1 !== (n = this.getPoolLyrics(o))) return void this.returnLyrics(o, n, e, i);
            this.requestLyricsId && e && (Ext.Ajax.abort(this.requestLyricsId), this.searchLyricsId && Ext.Ajax.abort(this.searchLyricsId)), a = this._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.Lyrics",
                method: "getlyrics",
                id: t.get("id")
            }), this.audioMain.isPublicSharing() && (a.sharing_id = SYNO.SDS.AudioStation.SessionData.SharingId), this.requestLyricsId = Ext.Ajax.request({
                url: this._getUtils().getWebAPIURL("lyrics.cgi"),
                method: "POST",
                params: a,
                callback: function(n, a, s) {
                    if (a) {
                        var l = Ext.decode(s.responseText);
                        return void(l && SYNO.SDS.AudioStation.Utils.testProperty(l, "data.lyrics") && !Ext.isEmpty(l.data.lyrics) ? this.returnLyrics(o, l.data.lyrics, e, i) : this.searchLyrics(t, t.get("title"), t.get("artist"), e, i))
                    }
                    this.returnLyrics(o, "", e, i)
                },
                scope: this
            })
        }
    },
    searchLyrics: function(t, e, i, n, a) {
        var o = this._getUtils().isVirtualMusic(t) ? t.get("path") + "_" + t.get("track") : t.get("path"),
            s = this._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.LyricsSearch",
                method: "searchlyrics",
                title: e,
                artist: i,
                limit: 1,
                additional: "full_lyrics"
            });
        this.audioMain.isPublicSharing() && (s.sharing_id = SYNO.SDS.AudioStation.SessionData.SharingId, s.song_id = t.get("id")), this.searchLyricsId = Ext.Ajax.request({
            url: this._getUtils().getWebAPIURL("lyrics_search.cgi"),
            params: s,
            method: "POST",
            callback: function(t, e, i) {
                var s = SYNO.SDS.AudioStation.Utils;
                if (e && i.responseText) {
                    var l = Ext.decode(i.responseText);
                    if (l && s.testProperty(l, "data.lyrics") && 0 < l.data.lyrics.length && !Ext.isEmpty(l.data.lyrics[0])) return void this.returnLyrics(o, l.data.lyrics[0].additional.full_lyrics, n, a)
                }
                this.returnLyrics(o, "", n, a)
            },
            scope: this
        })
    },
    returnLyrics: function(t, e, i, n) {
        !1 === this.getPoolLyrics(t) && this.addLyricsToPool({
            path: t,
            lyrics: e
        }), i && i.call(n, t, e), this.requestLyricsId = "", this.searchLyricsId = ""
    },
    addLyricsToPool: function(t) {
        this.pool.length >= this.MAX_POOL_SIZE && this.pool.shift(), this.pool.push(t)
    },
    getPoolLyrics: function(t) {
        var e;
        for (e = 0; e < this.pool.length; e++)
            if (this.pool[e].path == t) return this.pool[e].lyrics;
        return !1
    },
    clearLyrics: function(t) {
        var e, i = -1;
        if (t) {
            for (e = 0; e < this.pool.length; e++)
                if (this.pool[e].path == t) {
                    i = e;
                    break
                } - 1 != i && this.pool.splice(i, 1)
        }
    }
}), Ext.define("SYNO.SDS.AudioStation.LyricsPanel", {
    extend: "SYNO.ux.Panel",
    outputSyncLyrics: [],
    outputUnsyncLyrics: [],
    hasSyncLyrics: !1,
    updateTask: null,
    updateTaskEnabled: !0,
    updateTaskDelay: 0,
    panelMiddlePos: null,
    timeOffset: 0,
    requestLyricsId: null,
    autoFlexcroll: !0,
    constructor: function(t) {
        this.openContainer = t.openContainer, SYNO.SDS.AudioStation.Utils._initWinWrappers.call(this, t);
        var e = this.fillConfig(t);
        this.callParent([e]), this.audioMain = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main"), this.audioMain.lyricsMgr || (this.audioMain.lyricsMgr = new SYNO.SDS.AudioStation.Lyrics.Mgr)
    },
    fillConfig: function(t) {
        var e = {
            cls: "syno-audio-scroll",
            overCls: "syno-audio-scroll-over",
            layout: "form",
            listeners: {
                scope: this,
                buffer: 100,
                afterrender: function(t) {
                    t.getEl().on("mousewheel", function() {
                        this.updateTaskDelay = 4
                    }, this), t.getEl().on("mousedown", function() {
                        this.updateTaskEnabled = !1
                    }, this), t.getEl().on("mouseup", function() {
                        this.updateTaskEnabled || (this.updateTaskEnabled = !0, this.updateTaskDelay = 4)
                    }, this), t.getEl().on("mouseleave", function() {
                        this.updateTaskEnabled || (this.updateTaskEnabled = !0, this.updateTaskDelay = 4)
                    }, this)
                },
                deactivate: function() {
                    var t = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").playerPanel.Ctrl;
                    this.showCenterMsg(!1), t.getPlayingStatus() || t.setLyricsDisabled(!0)
                },
                afterlayout: function() {
                    this.panelMiddlePos = Math.floor(this.getHeight() / 2, 10)
                }
            }
        };
        return Ext.apply(e, t), SYNO.LayoutConfig.fill(e), e
    },
    clearLyrics: function(t) {
        this.updateTaskDelay = 0, this.hasSyncLyrics = !1, this.timeOffset = 0, this.getUpdateLyricsTask().stop(), this.refreshLyricsItems(t ? [] : void 0), this.lyrics = "", this.songPath = ""
    },
    setLyrics: function(t) {
        this.showCenterMsg(!1);
        var e = this._getUtils().isVirtualMusic(t) ? t.get("path") + "_" + t.get("track") : t.get("path");
        return e && "http" !== e.substr(0, 4).toLowerCase() ? e == this.songPath ? void(this.lyrics || this.showCenterMsg(!0, _AST("editor", "no_lyrics"))) : (this.clearLyrics(!0), this.showCenterMsg(!0, _AST("common", "searching"), !0), void this.audioMain.lyricsMgr.getLyrics(t, this.afterGetLyricsFromDS, this)) : void this.refreshLyricsItems()
    },
    afterGetLyricsFromDS: function(t, e) {
        this.showCenterMsg(!1), this.lyrics = e, this.songPath = t, e ? this.foundLyrics(e) : this.refreshLyricsItems()
    },
    foundLyrics: function(t) {
        this.prepareLyrics(t), this.hasSyncLyrics ? this.refreshLyricsItems(this.outputSyncLyrics) : this.refreshLyricsItems(this.outputUnsyncLyrics), this.getUpdateLyricsTask().start()
    },
    prepareLyrics: function(t) {
        var e = 0,
            i = "";
        for (t = Ext.util.Format.htmlEncode(t), i = t.replace(/\r\n/g, "\r").replace(/\n/g, "\r").split("\r"), this.outputSyncLyrics = [], this.outputUnsyncLyrics = []; e < i.length;) this.getTags(i[e]) && (this.hasSyncLyrics = !0), this.outputUnsyncLyrics.push([i[e++]]);
        this.hasSyncLyrics && this.sortTags()
    },
    getTags: function(t) {
        var e, i, n, a = [],
            o = [],
            s = 0;
        if ("" === t) return !1;
        for (;;) {
            if (e = t.indexOf("[", s), i = t.indexOf("]", s), -1 === e || -1 === i) break;
            i < e ? s = e : (s = i + 1, o = t.substr(e + 1, i - e - 1).toLowerCase().match(/^offset:([\+-])?(\d+)$/), null === o ? null !== (o = t.substr(e + 1, i - e - 1).match(/^(\d+:)?(\d+):(\d{1,2})(\.(\d+))?$/)) && a.push(+(60 * (parseInt(o[2], 10) || 0) + (parseInt(o[3], 10) || 0) + (o[4] || 0)) - this.timeOffset) : (this.timeOffset = parseInt(o[2], 10) / 1e3 || 0, "-" === o[1] && (this.timeOffset *= -1)))
        }
        return a.length > 0 && (n = t.substr(s), Ext.each(a, function(t) {
            this.outputSyncLyrics.push([n, t])
        }, this), !0)
    },
    sortTags: function() {
        Ext.isArray(this.outputSyncLyrics) && 0 !== this.outputSyncLyrics.length && this.outputSyncLyrics.sort(function(t, e) {
            return t[1] - e[1]
        })
    },
    refreshLyricsItems: function(t) {
        var e;
        if (this.removeAll(), void 0 === t) this.showCenterMsg(!0, _AST("editor", "no_lyrics"));
        else if (Ext.isArray(t))
            for (this.showCenterMsg(!1), e = 0; e < t.length; e++) this.add({
                xtype: "displayfield",
                hideLabel: !0,
                cls: "syno-audio-lyrics-line",
                value: t[e][0],
                time: t[e][1] || 0
            });
        this.updateFleXcroll(!0), this.doLayout()
    },
    getUpdateLyricsTask: function() {
        return this.updateTask = this.updateTask || this.addTask({
            id: "task_update_lyrics",
            interval: 500,
            run: this.updateLyricsTask,
            scope: this
        }), this.updateTask
    },
    updateLyricsTask: function() {
        var t, e, i, n, a, o, s = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").playerPanel.Ctrl,
            l = this.getLayoutTarget ? this.getLayoutTarget() : this.getScrollTarget();
        if (!s.getPlayingStatus()) return void this.clearLyrics();
        if (this.hasSyncLyrics) {
            this.updateTaskDelay = --this.updateTaskDelay > 0 ? this.updateTaskDelay : 0, t = s.getPositionValue();
            for (var r = 0; r < this.items.items.length; r++) t >= this.items.items[r].time - .25 && (r + 1 === this.items.items.length || t < this.items.items[r + 1].time - .25) ? (e = this.items.items[r].getPosition()[1] - this.items.items[0].getPosition()[1], i = this.items.items[r].getPosition()[1] - this.getPosition()[1], this.items.items[r].addClass("syno-audio-lyrics-line-highlight"), n = this.items.items[r].getHeight() / 2, this.updateTaskEnabled && 0 === this.updateTaskDelay && (0 > i || this.panelMiddlePos < i + n) && (a = e - this.panelMiddlePos + n, l.dom.fleXcroll && (o = l.dom.fleXdata.scrollPosition[1][1], a > o && (a = o),
                l.dom.fleXcroll.setScrollPos(!1, a > 0 ? a : 0)))) : this.items.items[r].removeClass("syno-audio-lyrics-line-highlight")
        }
    },
    showCenterMsg: function(t, e, i) {
        var n, a;
        this.openContainer.el && (t && this.audioMain.isInLyricsMode() ? (n = this.openContainer.el.mask(e), a = Ext.fly(n.dom.parentNode).first("div.ext-el-mask-msg"), a && !i && a.addClass("syno-as-info-mask"), this.openContainer.on("resize", this.onContainerResize, this)) : (this.openContainer.el.unmask(), this.openContainer.un("resize", this.onContainerResize, this)))
    },
    onContainerResize: function() {
        var t = this.openContainer.el.first("div.ext-el-mask-msg");
        t && t.center(this.openContainer.el)
    }
}), Ext.define("SYNO.SDS.AudioStation.FleXcrollBufferView", {
    extend: "SYNO.ux.FleXcroll.grid.BufferView",
    forceFit: !0,
    onLoad: function() {
        this.callParent(arguments), this.fireEvent("afterGridViewOnLoad", this)
    }
}), Ext.define("SYNO.SDS.AudioStation.MimiPlayerListView", {
    extend: "SYNO.SDS.AudioStation.FleXcrollBufferView",
    onLayout: function(t, e) {
        var i = this,
            n = i.scroller.dom;
        i.autoFlexcroll && (i.scrollOffset = 0, this.fitColumns(!1), i.updateScrollbar(n))
    }
}), Ext.define("SYNO.SDS.AudioStation.ListViewGrid", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(t) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.call(this, t), this.baseURL = SYNO.SDS.AudioStation.Window.baseURL, this.lastRowSelected = [];
        var e = this.fillConfig(t);
        this.callParent([e])
    },
    fillConfig: function(t) {
        this.paging = new SYNO.ux.PagingToolbar({
            cls: "syno-as-paging-toolbar",
            store: this.getStore(),
            pageSize: this._getWindow().gridPagingSize,
            displayInfo: !0,
            hidden: !0
        });
        var e = Ext.apply({
            style: "padding-top:8px;",
            cls: "syno-as-grid syno-as-list-grid",
            itemId: "grid_listView",
            border: !1,
            store: this.getStore(),
            plugins: [SYNO.SDS.AudioStation.FocusGridPlugin],
            enableDragDrop: !0,
            ddText: _AST("playlist", "ddtext_song_selected"),
            ddGroup: "PlayingQueueDD",
            stateEvents: ["columnmove", "columnresize", "sortchange"],
            saveState: this.saveColumnSetting,
            autoExpandColumn: "title",
            minColumnWidth: 30,
            columns: this.getColumnModel(),
            selModel: new Ext.grid.RowSelectionModel({
                single: !0
            }),
            keys: this._getUtils().getHotKeyMap(this, this.hotKeyHandler),
            bbar: this.paging,
            getView: function() {
                return this.view || (this.view = new SYNO.SDS.AudioStation.FleXcrollBufferView({
                    forceFit: !0,
                    scrollDelay: !1,
                    rowHeight: 28,
                    borderHeight: 1,
                    cacheSize: 50,
                    rowSelectorDepth: 12,
                    listeners: {
                        scope: this,
                        afterGridViewOnLoad: this.afterGridViewOnLoad
                    }
                })), this.view
            },
            listeners: {
                activate: this.onActivate,
                deactivate: this.onDeactivate,
                rowcontextmenu: this.onShowItemMenu,
                afterrender: this.onGridAfterRender,
                destroy: this.onGridDestroy,
                rowdblclick: this.onRowDbClick,
                mouseover: {
                    fn: this.onGridMouseOver,
                    buffer: 100,
                    scope: this
                },
                mouseout: this.onGridMouseOut,
                rowclick: this.onGridRowClick
            }
        });
        return Ext.apply(e, t), e
    },
    getColumnModel: function() {
        return this.colModel ? this.colModel : (this.mediaServerCM = [{
            header: _AST("music", "header_title"),
            id: "title",
            align: "left",
            dataIndex: "title",
            sortable: !1,
            autoExpand: !0,
            renderer: this.titleRender.createDelegate(this)
        }], this.basicCM = [{
            header: _AST("music", "header_title"),
            id: "title",
            align: "left",
            dataIndex: "name",
            sortable: !1,
            autoExpand: !0,
            renderer: this.titleRender.createDelegate(this)
        }, {
            header: _AST("music", "header_avg_rating"),
            dataIndex: "avg_rating",
            sortable: !1,
            renderer: this.avgRatingRender.createDelegate(this)
        }], this.playlistCM = [{
            header: _AST("music", "header_title"),
            id: "title",
            align: "left",
            dataIndex: "name",
            width: 150,
            sortable: !1,
            autoExpand: !0,
            renderer: this.titleRender.createDelegate(this)
        }, {
            header: _AST("radio", "radio_type"),
            id: "type",
            align: "left",
            dataIndex: "type",
            width: 50,
            sortable: !1,
            renderer: this.playlistTypeRender.createDelegate(this)
        }, {
            header: _AST("playlist", "playlist_folder"),
            id: "folder",
            align: "left",
            dataIndex: "path",
            width: 50,
            sortable: !1,
            renderer: this.playlistFolderRender.createDelegate(this)
        }], this.radioStationCM = this.getRadioStationCM(), this.albumCM = this.getAlbumCM(), this.musicSongCM = this.getMusicSongCM(!0), this.mediaServerSongCM = this.getMusicSongCM(!1), this.searchAllSongCM = this.getSearchAllSongCM(), this.colModel = new Ext.grid.ColumnModel({
            columns: this.basicCM
        }), this.colModel)
    },
    getStore: function() {
        return this.info && this._getUtils()._PlayingQueue_ID === this.info.type ? this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").playingStore : this._getUtils().isInSearchAllCate() ? this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").searchAllSongStore : this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").dataStore
    },
    onGridAfterRender: function(t) {
        this.PlayingDropTarget || (this.PlayingDropTarget = new SYNO.SDS.AudioStation.PlayingQueueDropTarget(t, this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main"), {
            ddGroup: "PlayingQueueDD"
        }))
    },
    onGridDestroy: function(t) {
        this.PlayingDropTarget && this.PlayingDropTarget.removeFromGroup(this.ddGroup)
    },
    afterGridViewOnLoad: function() {
        this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").highlightPlayingIndex(), this._getUtils().isInSearchAllCate() && this.module.setMoreButtonDisplay.call(this.module, "song", this.store.totalLength > 10)
    },
    saveColumnSetting: function() {
        if ("" !== this.configName && this.isActive) {
            var t = this.getState();
            if (this._getUtils().isDisableSortPage()) {
                var e = this._getWindow().appInstance.getUserSettings(this.configName),
                    i = Ext.apply({}, t);
                e && e.sort && (i.sort = e.sort), t = i
            }
            this._getWindow().appInstance.setUserSettings(this.configName, t)
        }
    },
    restoreColumnSetting: function() {
        if ("" !== this.configName) {
            var t = this._getWindow().appInstance.getUserSettings(this.configName),
                e = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main");
            if (t) {
                if (this._getUtils().isDisableSortPage()) {
                    var i = Ext.apply({}, t);
                    delete i.sort, t = i
                } else t.sort || (t.sort = {
                    field: e.metadataMapping[this.info.params.api].field,
                    direction: "ASC"
                });
                this.adjustColumnWidth(t)
            } else t = this._getUtils().isDisableSortPage() ? {} : {
                sort: {
                    field: e.metadataMapping[this.info.params.api].field,
                    direction: "ASC"
                }
            };
            this.applyState(t), this.getView().updateHeaders(), this._getUtils().isPlayingQueue() && this.syncSize()
        }
    },
    adjustColumnWidth: function(t) {
        var e, i = t.columns,
            n = this.getInnerWidth(),
            a = 0;
        for (e = 0; e < i.length; e++) !0 !== i[e].hidden && (a += i[e].width);
        for (e = 0; e < i.length; e++) !0 !== i[e].hidden && (i[e].width = Math.floor(i[e].width * n / a))
    },
    onActivate: function() {
        this.getAlbumPanel().setVisible(!1), this.info = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo(), this.updateColumnModel(), this.updateColumnSortable(), SYNO.SDS.AudioStation.Utils._PlayingQueue_ID === this.info.type && (this.getView().emptyText = ""), this.paging.bindStore(this.getStore()), this.reconfigure(this.getStore(), this.colModel), this._getUtils()._PlayingQueue_ID === this.info.type && this.setPagingToolbarVisible(!1), this._getWindow().getPanelScope("SYNO.SDS.AudioStation.CardPanel").doLayout(), this.restoreColumnSetting(), this.isActive = !0
    },
    onDeactivate: function() {
        this.isActive = !1
    },
    focusItem: function(t) {
        var e = this.getView(),
            i = Ext.min([t * e.rowHeight, e.getContentwrapper().getHeight() - e.scroller.getHeight()]);
        e.scroller.dom.fleXcroll.setScrollPos(0, i), this.getSelectionModel().selectRow(t)
    },
    setPagingToolbarVisible: function(t) {
        t !== this.paging.isVisible() && (this.paging.setVisible(t), this.doLayout())
    },
    showEmptyMsg: function(t, e) {
        if (this.el) {
            var i, n;
            t ? (i = this.el.mask(e), (n = Ext.fly(i.dom.parentNode).first("div.ext-el-mask-msg")) && n.addClass("syno-as-info-mask")) : this.el.unmask()
        }
    },
    onGridRowClick: function(t, e, i) {
        var n, a = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main");
        if (void 0 !== this.dataType && this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").clearSelections(t, !0), i && e && !i.hasModifier() && t.getSelectionModel().selectRow(e), SYNO.SDS.AudioStation.Utils.isWindowsTablet() && (n = t.getStore().getAt(e), this._getUtils().isTrack(n) || (this.info.focusIdx = e, a.gotoNext(n))), this.isSupportRatingEvent() && (this.handleSongRatingSelected(), this.handleSongRatingClick(e, i), this._getUtils().isInAlbum())) {
            var o = this._getUtils().calculateAvgRating(this.getStore().data.items),
                s = this.getAlbumPanel().getComponent("avgRatingDiv").getEl();
            this._getUtils().applyAvgRatingAndDisplay(s, o)
        }
    },
    onRowDbClick: function(t, e, i) {
        var n = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main"),
            a = t.getStore().getAt(e);
        if (a) return this._getUtils()._PlayingQueue_ID === this.info.type ? void(n.gUpdatingPlayingQueue || a.get("support") && n.audioPlayer.doJump(e + n.playingStore.baseParams.offset)) : void(this._getUtils().isTrack(a) ? n.addQueue(a) : (this.info.focusIdx = e, n.gotoNext(a)))
    },
    updateColumnModel: function() {
        return this.configName = "", this._getUtils()._PlayingQueue_ID === this.info.type ? (this.colModel.setConfig(this.musicSongCM), void(this.configName = "PlayingQueueColumnSetting")) : this._getUtils()._Playlist_ID === this.info.type ? void("list" === this.info.params.method ? (this.colModel.setConfig(this.playlistCM), this.configName = "PlaylistColumnSetting") : "getinfo" === this.info.params.method && (this.colModel.setConfig(this.musicSongCM), this.configName = "MusicColumnSetting")) : this._getUtils()._MediaServer_ID === this.info.type ? void(2 > this.info.index ? (this.colModel.setConfig(this.mediaServerCM), this.configName = "MediaServerColumnSetting") : (this.colModel.setConfig(this.mediaServerSongCM), this.configName = "MusicColumnSetting")) : this._getUtils()._Radio_ID === this.info.type ? (this.colModel.setConfig(this.radioStationCM), void(this.configName = "RadioColumnSetting")) : "SYNO.AudioStation.Album" === this.info.params.api ? (this.colModel.setConfig(this.albumCM), void(this.configName = "AlbumColumnSetting")) : "SYNO.AudioStation.Song" === this.info.params.api || "SYNO.AudioStation.Folder" === this.info.params.api ? (this.colModel.setConfig(this.musicSongCM), void(this.configName = "MusicColumnSetting")) : this._getUtils().isInSearchAllCate() ? (this.colModel.setConfig(this.searchAllSongCM), void(this.configName = "SearchAllColumnSetting")) : ((this._getUtils().isInArtistList() || this._getUtils().isInComposerList() || this._getUtils().isInGenreList()) && (this.configName = "BasicColumnSetting"), void this.colModel.setConfig(this.basicCM))
    },
    updateColumnSortable: function() {
        var t, e = this.getStore();
        if (this._getUtils().isDisableSortPage()) {
            for (t = 0; t < this.colModel.config.length; t++) this.colModel.config[t].sortable = !1;
            e.setDefaultSort("", "")
        } else
            for (t = 0; t < this.colModel.config.length; t++) this.colModel.config[t].sortable = !0;
        this.getView().updateHeaders()
    },
    onShowItemMenu: function(t, e, i) {
        var n = t.getSelectionModel();
        n.isSelected(e) || n.selectRow(e), 1 === n.getSelections().length && this.handleSongRatingSelected(), void 0 !== this.dataType && this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").clearSelections(t, !0), this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").onShowItemMenu(t, i)
    },
    getAlbumPanel: function() {
        return this._getWindow().getPanelScope("SYNO.SDS.AudioStation.CardPanel").albumView
    },
    showAlbumView: function(t) {
        var e = t[0];
        if (e) {
            var i = this.getAlbumPanel(),
                n = i.getComponent("albumCoverDiv").getEl().child(".syno-as-album-view-img"),
                a = null,
                o = e.get("album") ? e.get("album") : _AST("common", "unknown_music_album"),
                s = e.get("album_artist"),
                l = Ext.util.Format.htmlEncode(o),
                r = Ext.util.Format.htmlEncode(s),
                d = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
            a = new Image, a.onload = this.onAlbumImgLoad.createDelegate(this, [n, a]), a.onerror = this.onAlbumImgError.createDelegate(this, [n, a]);
            var u = Ext.urlAppend(SYNO.SDS.AudioStation.Utils.getWebAPIURL("cover.cgi"), String.format(this._getUtils().getCgiImgMapping("SYNO.AudioStation.Album"), this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").gIsRetina, "album", encodeURIComponent(o), encodeURIComponent(s)));
            void 0 !== d.params.artist && (u += "&artist_name=" + encodeURIComponent(d.params.artist)), void 0 !== d.params.composer && (u += "&composer_name=" + encodeURIComponent(d.params.composer)), void 0 !== d.params.genre ? u += "&genre_name=" + encodeURIComponent(d.params.genre) : void 0 !== d.params.genre_filter && (u += "&genre_filter=" + encodeURIComponent(d.params.genre_filter)), a.src = u, n.hide(), this._getUtils().resetImgSize(n, 210), i.getComponent("title").getEl().update(l), i.getComponent("artist").getEl().update(r);
            var g = this._getUtils().calculateAvgRating(t),
                c = i.getComponent("avgRatingDiv").getEl();
            this._getUtils().applyAvgRatingAndDisplay(c, g), i.setVisible(!0), this.paging.setVisible(!1), this._getWindow().getPanelScope("SYNO.SDS.AudioStation.CardPanel").doLayout()
        }
    },
    onAlbumImgError: function(t, e) {
        this._getUtils().setImgFitCenterStyle(t, e, 210), t.dom.src = SYNO.SDS.AudioStation.Utils.getImageByDisplay("audio_default_music_album_m.png"), t.show()
    },
    onAlbumImgLoad: function(t, e) {
        this._getUtils().setImgFitCenterStyle(t, e, 210), t.dom.src = e.src, t.show()
    },
    titleRender: function(t, e, i, n, a, o) {
        var s, l, r = i.get("path"),
            d = -1 !== i.get("id").indexOf("/"),
            u = this.getIconClass(i),
            g = "";
        return l = this._getUtils().getRenderedTitle(t, i.id), !l && r && (l = Ext.util.Format.htmlEncode(r.split("/").pop())), s = Ext.util.Format.htmlEncode(l), this._getUtils().isPlayingQueue() && (d && "file" === i.get("type") ? s = '<font color="red">X</font> ' + s : !1 === i.get("support") && (s = '<font color="red">!</font> ' + s)), this._getUtils().isInPlaylistLayer2() && d && "file" === i.get("type") && (s = '<font color="red">X</font> ' + s), this._getUtils().isInAllPlaylist() && (g = this.getStatusHtml(i.get("sharing_status"))), String.format('<div class="grid-img {0}">{1}</div>{2}', u, s || "&nbsp;", g)
    },
    getStatusHtml: function(t) {
        var e = '<div class="syno-as-sharing-st {0}"></div>';
        return "valid" == t ? String.format(e, "st-valid") : "invalid" == t || "expired" == t ? String.format(e, "st-invalid") : ""
    },
    playlistTypeRender: function(t, e, i, n, a, o) {
        return this._getUtils().isSmartItem(i.get("id")) ? this._getUtils().isSharedItem(i.get("id")) ? _AST("playlist", "shared_smart_playlist_v2") : _AST("playlist", "personal_smart_playlist") : this._getUtils().isSharedItem(i.get("id")) ? _AST("playlist", "shared_playlist_v2") : _AST("playlist", "personal_playlist")
    },
    playlistFolderRender: function(t, e, i, n, a, o) {
        if (i.get("path")) return e.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(i.get("path")) + '"', i.get("path").substr(i.get("path").lastIndexOf("/") + 1)
    },
    getIconClass: function(t) {
        if (!this.info) return "";
        var e = t.get("library");
        if (this._getUtils()._PlayingQueue_ID === this.info.type) return this._getUtils().getPlayingQueueIconClass(t);
        if (this._getUtils()._Library_ID === this.info.type || this._getUtils()._SearchResults_ID === this.info.type || this._getUtils().isInHomepage()) return this.getLibraryIcon(t);
        if (this._getUtils()._MediaServer_ID === this.info.type) return this.getMediaServerIcon(t);
        if (this._getUtils()._Radio_ID === this.info.type) return this.getRadioIcon(t);
        if (this._getUtils()._Playlist_ID === this.info.type) {
            if (this._getUtils().isPredefinedPls(t.get("id"))) return "playlist_predefined";
            if ("personal" === e) return "playlist_personal";
            if ("shared" === e) return "playlist_share"
        }
        return "music_track"
    },
    getLibraryIcon: function(t) {
        return "folder" === t.get("type") ? "music_folder" : "SYNO.AudioStation.Album" === this.info.params.api ? "music_album" : "SYNO.AudioStation.Artist" === this.info.params.api ? "music_artist" : "SYNO.AudioStation.Composer" === this.info.params.api ? "music_composer" : "SYNO.AudioStation.Genre" === this.info.params.api ? "music_genre" : "music_track"
    },
    getRadioIcon: function(t) {
        return "station" === t.get("type") ? "music_radio_station" : "music_radio_category"
    },
    getMediaServerIcon: function(t) {
        return void 0 === this.info.params.id ? "media_server_root" : "object.container.playlistContainer" === t.get("class") ? "playlist_share" : "object.container.album.musicAlbum" === t.get("class") ? "music_album" : "object.container.person.musicArtist" === t.get("class") ? "music_artist" : "object.container.person.musicComposer" === t.get("class") ? "music_composer" : "object.container.genre.musicGenre" === t.get("class") ? "music_genre" : "object.item.audioItem.musicTrack" === t.get("class") ? "music_track" : "media_server_category"
    },
    SongValueRenderer: function(t, e, i, n, a, o) {
        return t || ""
    },
    albumYearRenderer: function(t, e, i, n, a, o) {
        return i.get("year") ? i.get("year") : ""
    },
    avgRatingRender: function(t, e, i, n, a, o) {
        var s = i.data.avg_rating;
        if (!(isNaN(s) || 1 > s)) {
            var l = Ext.id(),
                r = Math.ceil(s) - 1,
                d = '<div class="{0} {1}"></div>',
                u = "",
                g = "",
                c = 0;
            for (c = 0; c < r; c++) g = String.format(d, SYNO.SDS.AudioStation.Utils.getRatingClass("star"), SYNO.SDS.AudioStation.Utils.getRatingClass("avg_on")), u += g;
            for (g = String.format(d, SYNO.SDS.AudioStation.Utils.getRatingClass("star"), SYNO.SDS.AudioStation.Utils.isInt(s) ? SYNO.SDS.AudioStation.Utils.getRatingClass("avg_on") : SYNO.SDS.AudioStation.Utils.getRatingClass("avg_on_half")), u += g, c = s; c < 5; c++) g = String.format(d, SYNO.SDS.AudioStation.Utils.getRatingClass("star"), ""), u += g;
            var h = String.format('<input type="hidden" name="starValue" value="{0}">', s);
            return String.format('<div class="{3}" lockHover="true" id="{0}">{1}{2}</div>', l, u, h, SYNO.SDS.AudioStation.Utils.getRatingClass("avg_container"))
        }
    },
    songRatingRender: function(t, e, i, n, a, o) {
        if ("file" === i.data.type && SYNO.SDS.AudioStation.Utils.isSongExistent(i)) {
            var s = i.data.song_rating;
            s = !s || isNaN(s) ? 0 : s;
            var l = Ext.id(),
                r = '<div class="{0} {1}" star="{2}"></div>',
                d = "",
                u = "",
                g = 0;
            for (g = 0; g < s; g++) u = String.format(r, SYNO.SDS.AudioStation.Utils.getRatingClass("star"), SYNO.SDS.AudioStation.Utils.getRatingClass("on"), g + 1), d += u;
            var c = this.getSelectionModel().isSelected(n);
            for (c && this.lastRowSelected.push(l), g = s; g < 5; g++) u = String.format(r, SYNO.SDS.AudioStation.Utils.getRatingClass("star"), c ? SYNO.SDS.AudioStation.Utils.getRatingClass("mouseover") : "", g + 1), d += u;
            var h = String.format('<input type="hidden" name="starValue" value="{0}">', s);
            return String.format('<div class="{4} {5}" lockHover="{3}" id="{0}">{1}{2}</div>', l, d, h, c ? "true" : "false", SYNO.SDS.AudioStation.Utils.getRatingClass("song_container"), SYNO.SDS.AudioStation.Utils.getRatingClass("cursor_style"))
        }
    },
    handleSongRatingSelected: function() {
        var t, e = 0;
        for (e = 0; e < this.lastRowSelected.length; e++)(t = Ext.get(this.lastRowSelected[e])) && (t.set({
            lockHover: "false"
        }), SYNO.SDS.AudioStation.Utils.showOnlySongRatingOn(t));
        this.lastRowSelected = [];
        var i, n, a = 0,
            o = this.getSelectionModel().getSelections();
        for (e = 0; e < o.length; e++) a = this.store.indexOf(o[e]), i = this.getView().getRow(a), (t = Ext.get(i).select("." + SYNO.SDS.AudioStation.Utils.getRatingClass("song_container")).first()) && (SYNO.SDS.AudioStation.Utils.showEmptySongRating(t), t.set({
            lockHover: "true"
        }), n = t.getAttribute("id"), this.lastRowSelected.push(n))
    },
    handleSongRatingClick: function(t, e) {
        var i = e.getTarget("." + SYNO.SDS.AudioStation.Utils.getRatingClass("star"));
        if (i) {
            var n = Ext.get(i).getAttribute("star"),
                a = this.store.getAt(t).get("id"),
                o = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main");
            o.onSetSongRating(n, [a]);
            this.getStore().getAt(t).set("song_rating", parseInt(n, 10)), this.getStore().commitChanges();
            var s = e.getTarget("." + SYNO.SDS.AudioStation.Utils.getRatingClass("song_container")),
                l = Ext.get(s);
            SYNO.SDS.AudioStation.Utils.applySongRatingAndDisplay(l, n), o.updateSongRatingInPlayingStore(a, n);
            var r = o.getNowPlayingId();
            if (-1 !== r && a === r) {
                var d = o.largePlayingQueuePanel.getInfoElement(SYNO.SDS.AudioStation.Utils.getRatingClass("song_container"));
                SYNO.SDS.AudioStation.Utils.applySongRatingAndDisplay(d, n), SYNO.SDS.AudioStation.Utils.showOnlySongRatingOn(d)
            }
        }
    },
    getListViewSongRatingContainerEl: function(t) {
        var e, i = !1,
            n = null;
        if (this.store.each(function(n) {
                if (t === n.get("id")) return e = this.store.indexOf(n), i = !0, !1
            }, this), !i) return n;
        var a = this.getView().getRow(e);
        return n = Ext.get(a).child("." + SYNO.SDS.AudioStation.Utils.getRatingClass("song_container"))
    },
    isSupportRatingEvent: function() {
        return this._getUtils()._MediaServer_ID !== this.info.type && this._getUtils()._Radio_ID !== this.info.type && ("MusicColumnSetting" === this.configName || "PlayingQueueColumnSetting" === this.configName)
    },
    onGridMouseOut: function(t) {
        if (this.isSupportRatingEvent()) {
            var e = t.getTarget("." + SYNO.SDS.AudioStation.Utils.getRatingClass("song_container"));
            e && SYNO.SDS.AudioStation.Utils.showOnlySongRatingOn(Ext.get(e))
        }
    },
    onGridMouseOver: function(t) {
        if (this.isSupportRatingEvent()) {
            var e = t.getTarget("." + SYNO.SDS.AudioStation.Utils.getRatingClass("song_container"));
            e && SYNO.SDS.AudioStation.Utils.showEmptySongRating(Ext.get(e))
        }
    },
    getMusicSongCM: function(t) {
        var e = [{
            header: _AST("music", "header_title"),
            id: "title",
            align: "left",
            dataIndex: "title",
            sortable: !0,
            width: 150,
            renderer: this.titleRender.createDelegate(this)
        }, {
            dataIndex: "album",
            header: _AST("music", "header_album"),
            renderer: Ext.util.Format.htmlEncode,
            sortable: !0,
            width: 50
        }, {
            dataIndex: "artist",
            header: _AST("music", "header_artist"),
            renderer: Ext.util.Format.htmlEncode,
            sortable: !0,
            width: 50
        }, {
            dataIndex: "album_artist",
            header: _AST("music", "header_album_artist"),
            renderer: Ext.util.Format.htmlEncode,
            sortable: !0,
            hidden: !0,
            width: 50
        }, {
            dataIndex: "composer",
            header: _AST("music", "header_composer"),
            renderer: Ext.util.Format.htmlEncode,
            hidden: !0,
            sortable: !0,
            width: 50
        }, {
            dataIndex: "genre",
            header: _AST("music", "header_genre"),
            renderer: Ext.util.Format.htmlEncode,
            hidden: !0,
            sortable: !0,
            width: 50
        }, {
            dataIndex: "duration",
            header: _AST("music", "header_duration"),
            renderer: this._getUtils().timeRenderer,
            sortable: !0,
            width: 50
        }, {
            dataIndex: "year",
            header: _AST("music", "header_year"),
            renderer: this.SongValueRenderer,
            sortable: !0,
            hidden: !0,
            width: 50
        }, {
            dataIndex: "disc",
            header: _AST("music", "header_disc"),
            renderer: this.SongValueRenderer,
            sortable: !0,
            hidden: !0,
            width: 50
        }, {
            dataIndex: "track",
            header: _AST("music", "header_track"),
            renderer: this.SongValueRenderer,
            sortable: !0,
            width: 50
        }];
        if (t) {
            var i = {
                header: _AST("music", "header_rating"),
                dataIndex: "song_rating",
                width: 150,
                sortable: !0,
                renderer: this.songRatingRender.createDelegate(this)
            };
            e.push(i)
        }
        return e
    },
    getRadioStationCM: function() {
        return [{
            header: _AST("radio", "radio_name"),
            align: "left",
            dataIndex: "title",
            autoExpand: !0,
            width: 120,
            renderer: this.titleRender.createDelegate(this)
        }, {
            header: _AST("radio", "radio_desc"),
            align: "left",
            dataIndex: "desc",
            width: 30,
            sortable: !1,
            renderer: Ext.util.Format.htmlEncode
        }]
    },
    getAlbumCM: function() {
        return [{
            header: _AST("music", "header_title"),
            id: "title",
            align: "left",
            dataIndex: "name",
            sortable: !0,
            width: 150,
            renderer: this.titleRender.createDelegate(this)
        }, {
            dataIndex: "display_artist",
            header: _AST("music", "header_artist"),
            renderer: Ext.util.Format.htmlEncode,
            sortable: !0,
            width: 100
        }, {
            header: _AST("music", "header_year"),
            dataIndex: "year",
            sortable: !0,
            width: 50,
            renderer: this.albumYearRenderer.createDelegate(this)
        }, {
            header: _AST("music", "header_avg_rating"),
            dataIndex: "avg_rating",
            sortable: !0,
            width: 100,
            renderer: this.avgRatingRender.createDelegate(this)
        }]
    },
    getSearchAllSongCM: function() {
        return [{
            header: _AST("music", "header_title"),
            id: "title",
            align: "left",
            dataIndex: "title",
            sortable: !1,
            width: 150,
            renderer: this.titleRender.createDelegate(this)
        }, {
            dataIndex: "album",
            header: _AST("music", "header_album"),
            renderer: Ext.util.Format.htmlEncode,
            sortable: !1,
            width: 50
        }, {
            dataIndex: "artist",
            header: _AST("music", "header_artist"),
            renderer: Ext.util.Format.htmlEncode,
            sortable: !1,
            width: 50
        }]
    },
    hotKeyHandler: function(t) {
        var e, i = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main");
        "c_a" === t ? this.onSelectAllRowAction() : "delete" === t && (this._getUtils().isInRadioUserDefined() || this._getUtils().isInRadioFavorite() ? i.onInetRadioDeleteRec() : this._getUtils().isInPlaylist() ? i.onPlaylistDeleteRec() : this._getUtils().isPlayingQueue() && (e = i.getSelectionRecords(), SYNO.SDS.AudioStation.DelayedTaskQueue.addTask(e[0].get("id"), e, i.removeSelectFromPlayingQueue, i)))
    },
    onSelectAllRowAction: function() {
        Ext.isMac && !this.cmdKeyDown || (this.getSelectionModel().selectAll(), this.isSupportRatingEvent() && this.handleSongRatingSelected())
    }
}), SYNO.SDS.AudioStation.MiniPlayerMode = {
    NORMAL: 0,
    PLAYING_QUEUE: 1,
    LYRICS: 2
}, Ext.define("SYNO.SDS.AudioStation.MiniPlayer", {
    extend: "SYNO.SDS.Window",
    miniPlayerPanel: void 0,
    audioAppWindow: void 0,
    btnPlay: void 0,
    btnDisplayMode: void 0,
    volumeSlider: void 0,
    positionSlider: void 0,
    currentMode: SYNO.SDS.AudioStation.MiniPlayerMode.NORMAL,
    playerNormalHeight: 119,
    playerDisplayHeight: 419,
    constructor: function(t) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.call(this, t), SYNO.SDS.AudioStation.Window.addPanelScope("SYNO.SDS.AudioStation.MiniPlayer", this), this.audioAppWindow = t.audioAppWindow, this.audioAppMain = t.audioAppMain, this.miniPlayerPanel = this.initMiniPlayerPanel(), this.callParent([Ext.apply({
            width: 360,
            height: this.playerNormalHeight,
            layout: "fit",
            resizable: !1,
            fbar: [],
            items: [this.miniPlayerPanel]
        }, t)]), t.fromRestore || this.setPosition(t.normalPlayerBox.x + t.normalPlayerBox.width - 360, t.normalPlayerBox.y - 30), this.setHeight(this.playerNormalHeight)
    },
    initDraggable: function() {
        this.dd = new SYNO.SDS.AudioStation.Utils_.Window.DD(this, this.allowDragDivId)
    },
    initMiniPlayerPanel: function() {
        this.allowDragDivId = Ext.id();
        var t = ['<div id="syno_as_mini_control_div" class="syno-as-mini-control-div">', '<div id="{0}" class="mini-drag-area">', '<div class="mini-thumb-div">', '<img class="player-info-thumb" src="{1}" qtip="">', "</div>", '<div class="mini-info-div">', '<div class="mini-title">title</div>', '<div class="mini-album">album artist</div>', "</div>", '<div class="mini-duration">', '<span class="info-position">--:--</span>&nbsp;/&nbsp;', '<span class="info-duration">--:--</span>', "</div>", '<div class="mini-control-btns">', '<div class="mini-btn mini-volume"></div>', '<div class="mini-btn mini-prev"></div>', '<div class="mini-btn mini-play"></div>', '<div class="mini-btn mini-next"></div>', '<div class="mini-btn mini-stop"></div>', "</div>", '<div class="mini-btn mini-display-mode"></div>', '<div class="mini-btn mini-back-to-normal"></div>', "</div>", '<div class="mini_position_div"></div>', "</div>"].join("");
        t = String.format(t, this.allowDragDivId, Ext.BLANK_IMAGE_URL), this.infoPanel = new SYNO.ux.Panel({
            html: t,
            cls: "syno-as-mini-info-panel",
            border: !1,
            region: "north",
            height: 100,
            bodyCssClass: "syno-as-mini-panel-body"
        }), this.songPanel = new SYNO.SDS.AudioStation.PlayingQueueGrid({
            itemId: "miniPlayerQueue"
        }), this.bottomCardPanel = new SYNO.ux.Panel({
            cls: "syno-as-mini-song-panel",
            layout: "card",
            border: !1,
            region: "center",
            height: 300,
            hidden: !0,
            bodyCssClass: "syno-as-mini-panel-body",
            items: [this.songPanel]
        }), this.lyricsPanel = new SYNO.SDS.AudioStation.LyricsPanel({
            itemId: "miniPlayerLyrics",
            cls: "syno-as-mini-lyrics-panel",
            openContainer: this.bottomCardPanel
        }), this.bottomCardPanel.add(this.lyricsPanel), this.bottomCardPanel.doLayout();
        var e = new SYNO.ux.Panel({
            layout: "border",
            border: !1,
            bodyCssClass: "syno-as-mini-panel-body",
            items: [this.infoPanel, this.bottomCardPanel],
            listeners: {
                buffer: 100,
                afterrender: this.onPanelAfterRender.createDelegate(this)
            }
        });
        return this.positionSlider = new SYNO.SDS.AudioStation.Slider.PositionSlider({
            width: 374,
            clickRange: [0, 16],
            audioAppMain: this.audioAppMain
        }), this.btnPrev = new Ext.Toolbar.Button({
            handler: this.audioAppMain.audioPlayer.doPrevious
        }), this.btnPlay = new Ext.Toolbar.Button({
            handler: this.audioAppMain.audioPlayer.doPlay
        }), this.btnNext = new Ext.Toolbar.Button({
            handler: this.audioAppMain.audioPlayer.doNext
        }), this.btnStop = new Ext.Toolbar.Button({
            handler: this.audioAppMain.audioPlayer.doStop
        }), this.volumeBtn = new Ext.Toolbar.Button({
            scope: this,
            handler: this.onVolumeBtnClick
        }), this.btnDisplayMode = new Ext.Toolbar.Button({
            tooltip: _AST("player", "mini_display_queue"),
            displayState: SYNO.SDS.AudioStation.MiniPlayerMode.NORMAL,
            setState: function(t) {
                switch (this.removeClass(["btn_mode_display_normal", "btn_mode_display_queue", "btn_mode_display_lyrics"]), t) {
                    case SYNO.SDS.AudioStation.MiniPlayerMode.NORMAL:
                        this.displayState = SYNO.SDS.AudioStation.MiniPlayerMode.NORMAL, this.addClass("btn_mode_display_normal"), this.setTooltip(_AST("player", "mini_display_queue"));
                        break;
                    case SYNO.SDS.AudioStation.MiniPlayerMode.PLAYING_QUEUE:
                        this.displayState = SYNO.SDS.AudioStation.MiniPlayerMode.PLAYING_QUEUE, this.addClass("btn_mode_display_queue"), this.setTooltip(_AST("player", "mini_display_lyrics"));
                        break;
                    case SYNO.SDS.AudioStation.MiniPlayerMode.LYRICS:
                        this.displayState = SYNO.SDS.AudioStation.MiniPlayerMode.LYRICS, this.addClass("btn_mode_display_lyrics"), this.setTooltip(_AST("player", "mini_display_mini"))
                }
            },
            handler: this.switchMode,
            scope: this
        }), this.btnBackToNormal = new Ext.Toolbar.Button({
            tooltip: _AST("player", "switch_to_normal_player"),
            handler: this.backToNormalPlayer,
            scope: this
        }), e
    },
    onPanelAfterRender: function() {
        this.positionSlider.render(this.getPlayerControlElement("mini_position_div")), this.btnPrev.render(this.getPlayerControlElement("mini-prev")), this.btnPlay.render(this.getPlayerControlElement("mini-play")), this.btnNext.render(this.getPlayerControlElement("mini-next")), this.btnStop.render(this.getPlayerControlElement("mini-stop")), this.btnDisplayMode.render(this.getPlayerControlElement("mini-display-mode")), this.btnBackToNormal.render(this.getPlayerControlElement("mini-back-to-normal")), this.volumeBtn.render(this.getPlayerControlElement("mini-volume")), this.createVolumeSliderMenu(this.volumeBtn), this.resetInfo(), this.infoPanel.getEl().on("mouseover", function() {
            this.positionSlider.setPositionSlideThumbVisible(!0)
        }, this), this.infoPanel.getEl().on("mouseleave", function() {
            this.positionSlider.setPositionSlideThumbVisible(!1)
        }, this)
    },
    onVolumeBtnClick: function() {
        this.audioAppMain.playerPanel.Ctrl.getMute() ? this.audioAppMain.audioPlayer.doSetMute(!1) : this.audioAppMain.audioPlayer.doSetMute(!0)
    },
    backToNormalPlayer: function() {
        var t = this.audioAppMain.playerPanel.Ctrl.getCurrentTitle(),
            e = this.audioAppMain.playerPanel.Ctrl.getCurrentAlbum(),
            i = this.audioAppMain.playerPanel.Ctrl.getCurrentArtist(),
            n = this.audioAppMain.playerPanel.Ctrl.getCurrentCover(),
            a = this.audioAppMain.playerPanel.Ctrl.getCurrentVolume(),
            o = this.audioAppMain.playerPanel.Ctrl.getPauseStatus(),
            s = this.audioAppMain.playerPanel.Ctrl.getPositionValue(),
            l = this.audioAppMain.playerPanel.Ctrl.getDurationValue(),
            r = this.audioAppMain.playerPanel.Ctrl.getMute();
        this.audioAppMain.gIsOnMiniPlayerMode = !1, this.audioAppMain.taskButton && (this.audioAppMain.taskButton.contextMenu.defaultActions.maximize.setHidden(!1), this.audioAppMain.taskButton.contextMenu.defaultActions.minimize.setHidden(!1), this.audioAppMain.taskButton.contextMenu.defaultActions.restore.setHidden(!1)), this.audioAppMain.playerPanel.Ctrl.updateTitle(t, !0), this.audioAppMain.playerPanel.Ctrl.updateAlbumArtist(e, i, !0), this.audioAppMain.playerPanel.Ctrl.updateVolume(a), this.audioAppMain.playerPanel.Ctrl.updateCover(n), this.audioAppMain.playerPanel.Ctrl.setBtnPause(o, !0), this.audioAppMain.playerPanel.Ctrl.setRecordPause(!o), this.audioAppMain.playerPanel.Ctrl.updatePositionDuration(s, l), this.audioAppMain.miniPlayerSizePosition = this.getSizeAndPosition(), this.audioAppMain.miniPlayerSizePosition.fromRestore = !0, r ? this.audioAppMain.playerPanel.Ctrl.setMute(!0) : this.audioAppMain.playerPanel.Ctrl.setMute(!1, a), this.hide();
        var d = this.audioAppMain.getCurrentPlayingRecord();
        this.audioAppMain.playerPanel.refreshLyrics(d), this.audioAppWindow.show(), this.audioAppMain.gIsOnLargePlayingQueue && (this.audioAppMain.getPlayingPanel().getView().updateScroller(), this.audioAppMain.highlightPlayingIndex())
    },
    resetInfo: function() {
        var t = this.audioAppMain.playerPanel.Ctrl.getCurrentTitle(),
            e = this.audioAppMain.playerPanel.Ctrl.getCurrentAlbum(),
            i = this.audioAppMain.playerPanel.Ctrl.getCurrentVolume(),
            n = this.audioAppMain.playerPanel.Ctrl.getPauseStatus(),
            a = this.audioAppMain.playerPanel.Ctrl.getPositionValue(),
            o = this.audioAppMain.playerPanel.Ctrl.getDurationValue(),
            s = this.audioAppMain.playerPanel.Ctrl.getCurrentCover(),
            l = this.audioAppMain.playerPanel.Ctrl.getMute();
        this.audioAppMain.playerPanel.Ctrl.updateTitle(t, !0), this.audioAppMain.playerPanel.Ctrl.updateAlbum(e, !0), this.audioAppMain.playerPanel.Ctrl.setBtnPause(n, !0), this.audioAppMain.playerPanel.Ctrl.setRecordPause(!n), this.audioAppMain.playerPanel.Ctrl.updatePositionDuration(a, o), this.audioAppMain.playerPanel.Ctrl.updateCover(s), l ? this.audioAppMain.playerPanel.Ctrl.setMute(!0) : this.audioAppMain.playerPanel.Ctrl.setMute(!1, i)
    },
    getPlayerControlElement: function(t) {
        return Ext.get("syno_as_mini_control_div").child("." + t)
    },
    getInfoElement: function(t) {
        return Ext.get("syno_as_mini_control_div").child("." + t)
    },
    ghost: function(t) {
        var e = t ? t + " syno-as-miniplayer-ghost" : "syno-as-miniplayer-ghost",
            i = this.createGhost(e),
            n = this.getBox(!0);
        return i.setLeftTop(n.x, n.y), i.setWidth(n.width), this.el.hide(), this.activeGhost = i, i
    },
    switchMode: function(t, e) {
        switch (t.displayState) {
            case SYNO.SDS.AudioStation.MiniPlayerMode.NORMAL:
                t.setState(SYNO.SDS.AudioStation.MiniPlayerMode.PLAYING_QUEUE), this.setCenterPanelVisible(!0), this.bottomCardPanel.getLayout().setActiveItem("miniPlayerQueue");
                break;
            case SYNO.SDS.AudioStation.MiniPlayerMode.PLAYING_QUEUE:
                var i = this.audioAppMain.getCurrentPlayingRecord();
                t.setState(SYNO.SDS.AudioStation.MiniPlayerMode.LYRICS), this.bottomCardPanel.getLayout().setActiveItem("miniPlayerLyrics"), this.audioAppMain.playerPanel.refreshLyrics(i);
                break;
            case SYNO.SDS.AudioStation.MiniPlayerMode.LYRICS:
                t.setState(SYNO.SDS.AudioStation.MiniPlayerMode.NORMAL), this.setCenterPanelVisible(!1)
        }
    },
    setCenterPanelVisible: function(t) {
        t ? (this.setHeight(this.playerDisplayHeight), this.bottomCardPanel.show(), this.addClass("syno-as-mini-expand")) : (this.setHeight(this.playerNormalHeight), this.bottomCardPanel.hide(), this.removeClass("syno-as-mini-expand"))
    },
    isInLyricsMode: function() {
        return SYNO.SDS.AudioStation.MiniPlayerMode.LYRICS === this.btnDisplayMode.displayState
    },
    createVolumeSliderMenu: function() {
        this.volumeSlider = new SYNO.SDS.AudioStation.Slider.MiniVolumeSlider({
            height: 86,
            audioAppMain: this.audioAppMain
        }), this.volumePanel = new SYNO.ux.Panel({
            cls: "syno-as-volume-panel",
            items: [this.volumeSlider]
        }), this.volumeMenu = new SYNO.ux.Menu({
            cls: "syno-as-volume-menu",
            defaultOffsets: [0, -8],
            items: [this.volumePanel],
            listeners: {
                scope: this,
                beforeshow: function() {
                    var t = this.audioAppMain.playerPanel.Ctrl;
                    t.updateVolume(t.getCurrentVolume())
                }
            }
        }), this.volumeBtn.on("mouseover", function() {
            this.volumeMenu.show(this.volumeBtn.getId(), "b-t")
        }, this)
    }
}), Ext.define("SYNO.SDS.AudioStation.PlayingQueueGrid", {
    extend: "SYNO.ux.GridPanel",
    isForPublicSharing: !1,
    constructor: function(t) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.call(this, t), this.baseURL = SYNO.SDS.AudioStation.Window.baseURL, this.isForLargeView = t.isForLargeView;
        var e = this.fillConfig(t);
        this.callParent([e])
    },
    fillConfig: function(t) {
        this.isForPublicSharing = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").isPublicSharing(), this.paging = new SYNO.ux.PagingToolbar({
            cls: "syno-as-paging-toolbar",
            store: this.getStore(),
            pageSize: this._getWindow().gridPagingSize,
            displayInfo: !0
        });
        var e = Ext.apply({
            cls: "syno-as-grid syno-as-list-grid",
            itemId: "grid_listView",
            border: !1,
            store: this.getStore(),
            hideHeaders: !0,
            enableDragDrop: !this.isForPublicSharing,
            ddText: _AST("playlist", "ddtext_song_selected"),
            ddGroup: "MiniPlayingQueueDD",
            autoExpandColumn: "title",
            columns: this.getColumnModel(),
            selModel: new Ext.grid.RowSelectionModel({
                single: !0
            }),
            plugins: [SYNO.SDS.AudioStation.FocusGridPlugin],
            keys: this._getUtils().getHotKeyMap(this, this.hotKeyHandler),
            view: this.getView(t),
            listeners: {
                rowdblclick: this.onRowDbClick,
                rowclick: this.onGridRowClick,
                rowcontextmenu: this.onShowItemMenu,
                afterrender: this.onGridAfterRender,
                destroy: this.onGridDestroy,
                activate: this.onGridActivate
            }
        });
        return Ext.apply(e, t), e
    },
    getColumnModel: function() {
        return this.colModel ? this.colModel : (this.colModel = new Ext.grid.ColumnModel({
            columns: this.isForLargeView ? this.getLargeSongCM() : this.getMusicSongCM()
        }), this.colModel)
    },
    getStore: function() {
        return this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").playingStore
    },
    getView: function(t) {
        var e = this.isForLargeView ? SYNO.SDS.AudioStation.FleXcrollBufferView : SYNO.SDS.AudioStation.MimiPlayerListView;
        return this.view || (this.view = new e({
            rowSelectorDepth: 12,
            rowHeight: this.isForLargeView ? t.customGridHeight : 26,
            listeners: {
                scope: this,
                afterGridViewOnLoad: this.afterGridViewOnLoad
            }
        })), this.view
    },
    onGridActivate: function() {
        var t = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main"),
            e = this;
        (function() {
            e.view.updateScroller(), t.focusHighlightRow()
        }).defer(100)
    },
    onGridAfterRender: function(t) {
        this.PlayingDropTarget || (this.PlayingDropTarget = new SYNO.SDS.AudioStation.PlayingQueueDropTarget(t, this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main"), {
            ddGroup: "MiniPlayingQueueDD"
        }))
    },
    onGridDestroy: function() {
        this.PlayingDropTarget && this.PlayingDropTarget.removeFromGroup(this.ddGroup)
    },
    afterGridViewOnLoad: function() {
        this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").highlightPlayingIndex()
    },
    onRowDbClick: function(t, e, i) {
        var n = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main"),
            a = t.getStore().getAt(e);
        a && (n.gUpdatingPlayingQueue || a.get("support") && n.audioPlayer.doJump(e + n.playingStore.baseParams.offset))
    },
    onGridRowClick: function(t, e, i) {
        i && e && !i.hasModifier() && t.getSelectionModel().selectRow(e)
    },
    showEmptyMsg: function(t, e) {
        if (this.el) {
            var i, n;
            t ? (i = this.el.mask(e), (n = Ext.fly(i.dom.parentNode).first("div.ext-el-mask-msg")) && n.addClass("syno-as-info-mask")) : this.el.unmask()
        }
    },
    onShowItemMenu: function(t, e, i) {
        if (!this.isForPublicSharing) {
            var n = t.getSelectionModel();
            n.isSelected(e) || n.selectRow(e), this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").onShowItemMenu(t, i)
        }
    },
    titleRender: function(t, e, i, n, a, o) {
        var s = i.get("path"),
            l = -1 !== i.get("id").indexOf("/"),
            r = Ext.util.Format.htmlEncode(t.trim()),
            d = this._getUtils().getPlayingQueueIconClass(i);
        return !t.trim() && s && (r = Ext.util.Format.htmlEncode(s.split("/").pop())), r ? l && "file" === i.get("type") ? String.format('<div class="{0}">{1} {2}</div>', d, '<font color="red">X</font>', r) : String.format('<div class="{0}">{1} {2}</div>', d, !1 === i.get("support") ? '<font color="red">!</font>' : "", r) : String.format("")
    },
    largeTitleRender: function(t, e, i, n, a, o) {
        var s = i.get("path"),
            l = -1 !== i.get("id").indexOf("/"),
            r = Ext.util.Format.htmlEncode(t.trim());
        !t.trim() && s && (r = Ext.util.Format.htmlEncode(s.split("/").pop()));
        var d = new Ext.Template('<table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0" class="{cls} syno-as-lpq-info x-table-layout"><tbody><tr><td class="x-table-layout-cell syno-as-data-cell syno-as-data-title" valign="top"><div><span>{is_support}{title}</span></div></td></tr><tr><td class="x-table-layout-cell syno-as-data-cell syno-as-data-album" valign="top" rowspan="4"><div><span>{album}</span></div></td></tr></tbody></table>');
        return d.compile(), d.apply({
            cls: this._getUtils().getPlayingQueueIconClass(i),
            is_support: l && "file" === i.get("type") ? '<font color="red">X</font> ' : i.data.support ? "" : '<font color="red">!</font> ',
            title: r,
            album: Ext.util.Format.htmlEncode(i.data.album)
        })
    },
    getIconClass: function(t) {
        return t.get("isNowPlaying") ? "music_isNowPlaying" : "music_track"
    },
    getMusicSongCM: function() {
        return [{
            header: _AST("music", "header_title"),
            id: "title",
            align: "left",
            dataIndex: "title",
            sortable: !0,
            width: 250,
            renderer: this.titleRender.createDelegate(this)
        }, {
            dataIndex: "duration",
            header: _AST("music", "header_duration"),
            align: "left",
            renderer: this._getUtils().timeRenderer,
            sortable: !0,
            width: 55
        }]
    },
    getLargeSongCM: function() {
        return [{
            header: _AST("music", "header_title"),
            id: "title",
            align: "left",
            dataIndex: "title",
            width: 250,
            renderer: this.largeTitleRender.createDelegate(this)
        }, {
            dataIndex: "artist",
            header: _AST("music", "header_artist"),
            align: "center",
            renderer: Ext.util.Format.htmlEncode,
            width: 100
        }, {
            dataIndex: "duration",
            header: _AST("music", "header_duration"),
            align: "center",
            renderer: this._getUtils().timeRenderer,
            width: 50
        }]
    },
    hotKeyHandler: function(t) {
        var e, i = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main");
        "c_a" === t ? this.onSelectAllRowAction() : "delete" === t && (e = i.getSelectionRecords(), SYNO.SDS.AudioStation.DelayedTaskQueue.addTask(e[0].get("id"), e, i.removeSelectFromPlayingQueue, i))
    },
    onSelectAllRowAction: function() {
        Ext.isMac && !this.cmdKeyDown || this.getSelectionModel().selectAll()
    }
}), Ext.define("SYNO.SDS.AudioStation.Base_Main", {
    extend: "SYNO.ux.Panel",
    gCurrentSelectPlayer: "__SYNO_WEB_PLAYER__",
    gCurrentSelectPlayerType: "web",
    gIsRetina: !1,
    gIsOnMiniPlayerMode: !1,
    gIsMobileStyle: !1,
    delayPlayFn: null,
    constructor: function(t) {
        this.callParent(arguments)
    },
    isPublicSharing: function() {
        return !1
    },
    isPlayingPage: function(t, e) {
        return e = e || this.playingStore, !(t < e.baseParams.offset || e.baseParams.offset + e.baseParams.limit <= t)
    },
    isWebPlayer: function() {
        return "__SYNO_WEB_PLAYER__" === this.gCurrentSelectPlayer
    },
    highlightPlayingIndex: function(t, e) {
        e = e || this.playingStore;
        var i;
        if (Ext.isDefined(t) || (t = this.getCurrentPlayingIndex()), i = e.find("isNowPlaying", !0), -1 !== i && e.getAt(i).set("isNowPlaying", !1), this.isPlayingPage(t, e)) {
            var n = t - e.baseParams.offset,
                a = e.getAt(n);
            a && (a.set("isNowPlaying", !0), e.commitChanges()), this.focusHighlightRow(n)
        }
    },
    focusHighlightRow: function(t) {
        var e, i = this.getPlayingPanel(),
            n = t;
        i && (0 !== this.playingStore.getCount() || this.isPublicSharing() ? i.showEmptyMsg(!1) : i.showEmptyMsg(!0, _AST("common", "warning_playing_queue_no_music")), Ext.isDefined(t) || (t = this.getCurrentPlayingIndex()), 0 > t || i.getView().getRow(t) && (e = parseInt(i.getHeight() / i.view.rowHeight / 2, 10), n = t + e >= this.playingStore.getCount() - 1 ? this.playingStore.getCount() - 1 : t + e, i.getView().focusRow(n)))
    },
    displayLyricsPanel: function(t) {
        var e;
        t ? (this.isFromBrowseToLyrics = !this.gIsOnLargePlayingQueue, (e = this.getCurrentPlayingRecord()) && (this.gIsOnLargePlayingQueue = !0, this.mainCardPanel && this.mainCardPanel.getLayout().setActiveItem("LargePlayingQueue"), this.largePlayingQueuePanel.displayLyrics(!0), this.playerPanel.refreshLyrics(e))) : (this.largePlayingQueuePanel.displayLyrics(!1), this.isFromBrowseToLyrics && (this.mainCardPanel && this.mainCardPanel.getLayout().setActiveItem("browse"), this.gIsOnLargePlayingQueue = !1)), this.updateMainToolbar()
    },
    mobileDisplayLyricsPanel: function(t) {
        var e = this.getCurrentPlayingRecord(),
            i = this.getComponent("mobile_info").getComponent("center_card");
        i && e && (t ? (i.getLayout().setActiveItem("lyrics"), this.playerPanel.refreshLyrics(e)) : i.getLayout().setActiveItem("cover"))
    },
    updateMainToolbar: function() {},
    isInLyricsMode: function() {
        if (this.gIsOnMiniPlayerMode && this.miniPlayer) return this.miniPlayer.isInLyricsMode();
        if (this.gIsOnLargePlayingQueue) return this.largePlayingQueuePanel.isInLyricsMode();
        if (this.gIsMobileStyle) {
            return "lyrics" === this.getComponent("mobile_info").getComponent("center_card").layout.activeItem.itemId
        }
        return !1
    },
    initStarEl: function() {
        this.isPublicSharing() || this.largePlayingQueuePanel.initStarEl()
    },
    getPlayingPanel: function() {
        var t;
        return this.gIsOnLargePlayingQueue ? this.largePlayingQueuePanel.songPanel : this.gIsOnMiniPlayerMode ? this.miniPlayer.songPanel : (t = this._getWindow().pathMgr.getHistoryInfo(), this._getUtils()._PlayingQueue_ID !== t.type ? null : this.cardPanel.listViewGrid)
    },
    getLargeCoverPanel: function() {
        return this.gIsOnLargePlayingQueue ? this.largePlayingQueuePanel.coverPanel : this.gIsMobileStyle ? this.coverPanel : null
    },
    getCurrentPlayingRecord: function() {
        return "__SYNO_WEB_PLAYER__" === this.gCurrentSelectPlayer ? this.audioWebPlayer.getCurrentRecord() : this.playerPanel.Ctrl.getCurrentDaemonRecord()
    },
    getCurrentPlayingIndex: function() {
        return "__SYNO_WEB_PLAYER__" === this.gCurrentSelectPlayer ? this.audioWebPlayer.getCurrentIndex() : this.playerPanel.Ctrl.getCurrentDaemonPlayingIndex()
    },
    getRecentPlayIndex: function() {
        return "__SYNO_WEB_PLAYER__" === this.gCurrentSelectPlayer ? this.audioWebPlayer.getLastPlayIndex() : this.playerPanel.Ctrl.getLastDaemonPlayIndex()
    },
    getSelectionRecords: function(t) {
        var e, i, n, a, o = [];
        for (this.gIsOnMiniPlayerMode ? o = this.miniPlayer.songPanel.getSelectionModel().getSelections() : this.gIsOnLargePlayingQueue && !this.largePlayingQueuePanel.isInLyricsMode() ? o = this.largePlayingQueuePanel.songPanel.getSelectionModel().getSelections() : this.gIsMobileStyle ? (i = this.getLayout().activeItem, "mobile_song" === i.itemId && (o = this.getComponent("mobile_song").getSelectionModel().getSelections())) : (i = this.cardPanel.getLayout().activeItem, "listViewPanel" === i.itemId ? o = this.cardPanel.listViewGrid.getSelectionModel().getSelections() : "thumbViewPanel" === i.itemId ? o = this.cardPanel.thumbView.dataView.getSelectedRecords() : "searchAllPanel" === i.itemId ? (a = void 0 !== t && void 0 !== t.dataType ? t.dataType : this.getSearchAllPanelSelection(), o = "artist" === a ? this.cardPanel.searchAllView.artistDataView.getSelectedRecords() : "album" === a ? this.cardPanel.searchAllView.albumDataView.getSelectedRecords() : this.cardPanel.searchAllView.songListView.getSelectionModel().getSelections()) : "homepagePanel" === i.itemId ? (o = this.cardPanel.homepageView.pinDataView.getSelectedRecords(), 0 === o.length && (o = this.cardPanel.homepageView.defaultGenreDataView.getSelectedRecords())) : "pinViewPanel" === i.itemId && (o = this.cardPanel.allPinView.getSelectedRecords())), this.isPublicSharing() || this._getUtils().isPlayingQueue() || this.gIsOnLargePlayingQueue || this.gIsOnMiniPlayerMode ? n = this.playingStore : this._getUtils().isInSearchAllCate() ? (a = void 0 !== t && void 0 !== t.dataType ? t.dataType : this.getSearchAllPanelSelection(), n = "artist" === a ? this.searchAllArtistStore : "album" === a ? this.searchAllAlbumStore : this.searchAllSongStore) : n = this._getUtils().isAtHomepage() || this._getUtils().isAtPinList() ? this.pinStore : this.dataStore, e = 0; e < o.length; e++) o[e].index = n.indexOf(o[e]);
        return o.sort(function(t, e) {
            return t.index - e.index
        }), o
    },
    DeleteRadioTmpFile: function() {
        var t = this._getUtils().getWebAPIParams({
            api: "SYNO.AudioStation.Proxy",
            method: "deletesonginfo",
            stream_id: this.audioWebPlayer.getRadioStreamId()
        });
        Ext.Ajax.request({
            url: this._getUtils().getWebAPIURL("proxy.cgi"),
            params: t,
            callback: this.playerPanel.Ctrl.updateTitleArtist("", "", "")
        })
    },
    stopGetRadioSongInfoPollTask: function() {
        this.RadioSongInfoPollTask && (this.RadioSongInfoPollTask.stop(), delete this.RadioSongInfoPollTask, this.DeleteRadioTmpFile())
    },
    startGetRadioSongInfoPollTask: function() {
        this.RadioSongInfoPollTask || (this.RadioSongInfoPollTask = this.addTask({
            run: function() {
                if ("__SYNO_WEB_PLAYER__" !== this.gCurrentSelectPlayer) return void this.stopGetRadioSongInfoPollTask();
                var t = this._getUtils().getWebAPIParams({
                    api: "SYNO.AudioStation.Proxy",
                    method: "getsonginfo",
                    stream_id: this.audioWebPlayer.getRadioStreamId()
                });
                Ext.Ajax.request({
                    url: this._getUtils().getWebAPIURL("proxy.cgi"),
                    method: "GET",
                    params: t,
                    scope: this,
                    callback: function(t, e, i) {
                        var n;
                        if ("__SYNO_WEB_PLAYER__" !== this.gCurrentSelectPlayer) return void this.stopGetRadioSongInfoPollTask();
                        e && i.responseText && (n = Ext.util.JSON.decode(i.responseText)) && "" !== n.data.title && this.playerPanel.Ctrl.updateAlbumArtist(n.data.title, "")
                    }
                })
            },
            scope: this,
            interval: 3e3
        }), this.RadioSongInfoPollTask.start())
    }
}), Ext.define("SYNO.SDS.AudioStation.CoverPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(t) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.call(this, t);
        var e = this.fillConfig(t);
        this.callParent([e])
    },
    fillConfig: function(t) {
        var e = {
            html: this.getCoverHtml(),
            listeners: {
                scope: this,
                afterrender: this.onCoverPanelAfterRender,
                resize: {
                    buffer: 100,
                    fn: this.onCoverPanelResize
                }
            }
        };
        return Ext.apply(e, t), e
    },
    onCoverPanelAfterRender: function() {
        var t = this.getEl().child(".syno-song-rating-container");
        t.on("mouseover", function() {
            SYNO.SDS.AudioStation.Utils.showEmptySongRating(t)
        }, this), t.on("mouseout", function() {
            SYNO.SDS.AudioStation.Utils.showOnlySongRatingOn(t)
        }, this), t.on("click", this.songRatingClick, this)
    },
    onCoverPanelResize: function(t, e, i, n, a) {
        if (this._getWindow().isMobile) {
            var o, s, l = this.getInfoElement("syno-as-mobile-position"),
                r = this.getInfoElement("syno-as-mobile-slider"),
                d = this.getInfoElement("info-position"),
                u = this.getInfoElement("info-duration"),
                g = this.getInfoElement("lpq-info-div"),
                c = this.getInfoElement("lpq-thumb-div");
            o = (this.getHeight() - c.getHeight()) / 3 * 2, o < 30 && (o = 30), l.setHeight(o), r.center(l), s = (this.getWidth() - r.getWidth()) / 2, d.setWidth(s), u.setWidth(s), d.alignTo(r, "tl", [0 - s, 0]), u.alignTo(r, "tr"), g.appendTo(c)
        }
    },
    resetInfo: function() {
        var t = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.PlayerPanel").Ctrl,
            e = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main"),
            i = e.getCurrentPlayingRecord();
        t.updateTitle(t.getCurrentTitle(), !0), t.updateAlbumArtist(t.getCurrentAlbum(), t.getCurrentArtist(), !0), t.updateCover(t.getCurrentCover()), i && t.getPlayingStatus() ? t.updateSongRating(i.data.id, i.data.type, i.data.song_rating) : e.initStarEl()
    },
    getCoverHtml: function() {
        var t = ['<div class="syno-as-mobile-position">', '<span class="info-position">--:--</span>', '<div class="syno-as-mobile-slider"></div>', '<span class="info-duration">--:--</span>', "</div>", '<div class="syno-as-lpq-info-div">', '<div class="lpq-thumb-wrap">', '<div class="lpq-thumb-div">', '<img class="lpq-thumb-img" src="{0}" qtip="">', '<div class="mobile-info-bg"></div>', "</div>", "</div>", '<div class="lpq-info-div">', "{1}", '<div class="lpq-title"><div id="' + Ext.id() + '" class="lpq-title-text"></div></div>', '<div class="lpq-album"><div id="' + Ext.id() + '" class="lpq-album-text"></div></div>', '<div class="lpq-artist"><div id="' + Ext.id() + '" class="lpq-artist-text"></div></div>', "</div>", "</div>"].join("");
        return t = String.format(t, Ext.BLANK_IMAGE_URL, SYNO.SDS.AudioStation.Utils.getStarHtml("song_container"))
    },
    songRatingClick: function(t, e, i) {
        var n = Ext.get(t.getTarget("." + SYNO.SDS.AudioStation.Utils.getRatingClass("song_container")));
        if (n && "true" !== n.getAttribute("lockClick")) {
            var a = t.getTarget("." + SYNO.SDS.AudioStation.Utils.getRatingClass("star"));
            if (a) {
                var o = Ext.get(a),
                    s = o.getAttribute("star"),
                    l = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main"),
                    r = l.getNowPlayingId();
                if (-1 !== r) {
                    l.onSetSongRating(s, [r]), l.updateSongRatingInPlayingStore(r, s), SYNO.SDS.AudioStation.Utils.applySongRatingAndDisplay(n, s), l.updateSongRatingInDataStore(r, s);
                    var d = l.cardPanel.listViewGrid,
                        u = d.getListViewSongRatingContainerEl(r);
                    u && (SYNO.SDS.AudioStation.Utils.applySongRatingAndDisplay(u, s), SYNO.SDS.AudioStation.Utils.showOnlySongRatingOn(u))
                }
            }
        }
    },
    getInfoElement: function(t) {
        return this.getEl() ? this.getEl().child("." + t) : null
    }
}), Ext.define("SYNO.SDS.AudioStation.PlayingQueueView", {
    extend: "SYNO.ux.Panel",
    constructor: function(t) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.call(this, t), SYNO.SDS.AudioStation.Window.addPanelScope("SYNO.SDS.AudioStation.PlayingQueueView", this), this.baseURL = SYNO.SDS.AudioStation.Window.baseURL;
        var e = this.fillConfig(t);
        this.callParent([e])
    },
    fillConfig: function(t) {
        var e = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main");
        this.coverPanel = new SYNO.SDS.AudioStation.CoverPanel({
            padding: "12px 30px 0 60px",
            itemId: "coverPanel",
            region: "west",
            width: 410
        }), this.songPanel = new SYNO.SDS.AudioStation.PlayingQueueGrid({
            itemId: "playingQueue",
            region: "center",
            isForLargeView: !0,
            customGridHeight: 56
        }), this.cardPanel = new SYNO.ux.Panel({
            layout: "card",
            cls: "syno-as-lpq-card-panel",
            padding: "12px 8px 0 0",
            border: !1,
            region: "center",
            bodyCssClass: "syno-as-mini-panel-body",
            activeItem: 0,
            items: [this.songPanel]
        }), this.lyricsPanel = new SYNO.SDS.AudioStation.LyricsPanel({
            itemId: "lyrics",
            cls: "syno-as-mini-lyrics-panel",
            padding: "10px",
            openContainer: this.cardPanel
        }), this.cardPanel.add(this.lyricsPanel), this.cardPanel.doLayout();
        var i = {
            xtype: "syno_panel",
            border: !1,
            cls: "syno-as-lpq-main-panel",
            layout: "border",
            region: "east",
            items: [this.coverPanel, this.cardPanel],
            listeners: {
                scope: this,
                deactivate: this.onDeactivate,
                activate: this.onActivate
            }
        };
        if (!e.isPublicSharing()) {
            var n = ["->"];
            n.push.apply(n, e.getActions(!0)), Ext.apply(i, {
                tbar: {
                    xtype: "syno_toolbar",
                    cls: "syno-as-toolbar",
                    items: n
                }
            })
        }
        return Ext.apply(i, t), i
    },
    onActivate: function() {
        this.coverPanel.resetInfo(), this.songPanel.onGridActivate()
    },
    onDeactivate: function() {
        var t = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").playerPanel.Ctrl;
        t.getPlayingStatus() || t.setLyricsDisabled(!0)
    },
    displayLyrics: function(t) {
        t ? this.cardPanel.getLayout().setActiveItem("lyrics") : (this.cardPanel.getLayout().setActiveItem("playingQueue"), this.songPanel.getView().layout())
    },
    isInLyricsMode: function() {
        return "lyrics" === this.cardPanel.layout.activeItem.itemId
    },
    initStarEl: function() {
        var t = this.getInfoElement(SYNO.SDS.AudioStation.Utils.getRatingClass("song_container"));
        if (t) {
            t.removeClass([SYNO.SDS.AudioStation.Utils.getRatingClass("cursor_style")]), t.set({
                lockHover: !0
            }), t.set({
                lockClick: !0
            });
            t.child("input[type=hidden]").set({
                value: "0"
            });
            for (var e = t.select("." + SYNO.SDS.AudioStation.Utils.getRatingClass("star")), i = 0; i < 5; i++) e.item(i).removeClass([SYNO.SDS.AudioStation.Utils.getRatingClass("mouseover"), SYNO.SDS.AudioStation.Utils.getRatingClass("on")])
        }
    },
    setStarEl: function(t) {
        var e = this.getInfoElement(SYNO.SDS.AudioStation.Utils.getRatingClass("song_container"));
        if (e) {
            e.addClass(SYNO.SDS.AudioStation.Utils.getRatingClass("cursor_style")), e.set({
                lockHover: !1
            }), e.set({
                lockClick: !1
            });
            e.child("input[type=hidden]").set({
                value: t
            })
        }
    },
    getInfoElement: function(t) {
        return this.coverPanel.getEl() ? this.coverPanel.getInfoElement(t) : null
    }
});
