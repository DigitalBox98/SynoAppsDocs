/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.namespace("SYNO.SDS.AudioStation.Utils");

function _AST(b, a) {
    if ("undefined" !== typeof SYNO_SDS_AudioStation_Strings) {
        return SYNO_SDS_AudioStation_Strings[b][a]
    } else {
        return _TT("SYNO.SDS.AudioStation.Application", b, a)
    }
}
SYNO.SDS.AudioStation.Define = {
    MAX_SONG_LIMIT: 8192
};
SYNO.SDS.AudioStation.PreDefinedGenre = ["Blues", "Classic Rock", "Country", "Dance", "Disco", "Funk", "Grunge", "Hip-Hop", "Jazz", "Metal", "New Age", "Oldies", "Other", "Pop", "R&B", "Rap", "Reggae", "Rock", "Techno", "Industrial", "Alternative", "Ska", "Death Metal", "Pranks", "Soundtrack", "Euro-Techno", "Ambient", "Trip-Hop", "Vocal", "Jazz+Funk", "Fusion", "Trance", "Classical", "Instrumental", "Acid", "House", "Game", "Sound Clip", "Gospel", "Noise", "AlternRock", "Bass", "Soul", "Punk", "Space", "Meditative", "Instrumental Pop", "Instrumental Rock", "Ethnic", "Gothic", "Darkwave", "Techno-Industrial", "Electronic", "Pop-Folk", "Eurodance", "Dream", "Southern Rock", "Comedy", "Cult", "Gangsta", "Top 40", "Christian Rap", "Pop/Funk", "Jungle", "Native American", "Cabaret", "New Wave", "Psychadelic", "Rave", "Showtunes", "Trailer", "Lo-Fi", "Tribal", "Acid Punk", "Acid Jazz", "Polka", "Retro", "Musical", "Rock & Roll", "Hard Rock", "Folk", "Folk-Rock", "National Folk", "Swing", "Fast Fusion", "Bebob", "Latin", "Revival", "Celtic", "Bluegrass", "Avantgarde", "Gothic Rock", "Progressive Rock", "Psychedelic Rock", "Symphonic Rock", "Slow Rock", "Big Band", "Chorus", "Easy Listening", "Acoustic", "Humour", "Speech", "Chanson", "Opera", "Chamber Music", "Sonata", "Symphony", "Booty Bass", "Primus", "Porn Groove", "Satire", "Slow Jam", "Club", "Tango", "Samba", "Folklore", "Ballad", "Power Ballad", "Rhythmic Soul", "Freestyle", "Duet", "Punk Rock", "Drum Solo", "A capella", "Euro-House", "Dance Hall", "EDM", "World", "Spiritual"].sort();
SYNO.SDS.AudioStation.Utils = {
    init: function(c, b) {
        var a = SYNO.SDS.AudioStation.Utils;
        a._SearchResults_ID = "search_results";
        a._Homepage_ID = "homepage";
        a._MediaServer_ID = "media_server";
        a._Library_ID = "library";
        a._AllMusic_ID = "all_music";
        a._ByFolder_ID = "by_folder";
        a._ByAlbum_ID = "by_album";
        a._ByArtist_ID = "by_artist";
        a._ByComposer_ID = "by_composer";
        a._ByGenre_ID = "by_genre";
        a._Playlist_ID = "playlist";
        a._Random100_ID = "random_100";
        a._RecentlyAdded_ID = "recently_added";
        a._SharedSongs_ID = "playlist_personal_normal/__SYNO_AUDIO_SHARED_SONGS__";
        a._Radio_ID = "radio";
        a._ShoutCast_ID = "SHOUTcast";
        a._Userdefined_ID = "UserDefined";
        a._MyFavorite_ID = "Favorite";
        a._PlayingQueue_ID = "playing_queue";
        a.SEC_LIST = [a._SearchResults_ID, a._Homepage_ID, a._MediaServer_ID, a._AllMusic_ID, a._ByFolder_ID, a._ByAlbum_ID, a._ByArtist_ID, a._ByComposer_ID, a._ByGenre_ID, a._Playlist_ID, a._Random100_ID, a._RecentlyAdded_ID, a._SharedSongs_ID, a._ShoutCast_ID, a._Userdefined_ID, a._MyFavorite_ID];
        this.coverTimeStamp = new Date().getTime();
        this.webAPIVersion = this.createWebAPIVersionMapping();
        this.imgMapping = this.createImgMapping();
        this.isStreamStoreCopy = false;
        this.isPlayingStoreLoading = false;
        a.SEC_CFG = {};
        a.SEC_CFG[a._SearchResults_ID] = [{
            type: a._SearchResults_ID,
            text: _AST("common", "search_result"),
            layoutCfg: "searchAllPanel",
            params: this.getWebAPIParams({
                api: "SYNO.AudioStation.Search",
                method: "list"
            }),
            container_type: a._SearchResults_ID
        }, {
            type: a._SearchResults_ID,
            text: "",
            layoutCfg: "listViewPanel",
            params: {}
        }];
        a.SEC_CFG[a._Homepage_ID] = [{
            type: a._Homepage_ID,
            text: _AST("common", "homepage"),
            layoutCfg: "homepagePanel",
            params: this.getWebAPIParams({
                api: "SYNO.AudioStation.Pin",
                method: "list"
            }),
            container_type: a._Homepage_ID
        }, {
            type: a._Homepage_ID,
            text: "",
            layoutCfg: "listViewPanel",
            params: {}
        }, {
            type: a._Homepage_ID,
            text: _AST("common", "my_pins"),
            layoutCfg: "pinViewPanel",
            params: this.getWebAPIParams({
                api: "SYNO.AudioStation.Pin",
                method: "list"
            }),
            container_type: "my_pins"
        }];
        a.SEC_CFG[a._MediaServer_ID] = [{
            type: a._MediaServer_ID,
            text: _AST("common", "player_source_dms"),
            layoutCfg: "listViewPanel",
            params: this.getWebAPIParams({
                api: "SYNO.AudioStation.MediaServer",
                method: "list"
            }),
            container_type: a._MediaServer_ID
        }];
        a.SEC_CFG[a._AllMusic_ID] = [{
            type: a._Library_ID,
            text: _AST("common", "class_music_allmusic"),
            layoutCfg: "listViewPanel",
            params: this.getWebAPIParams({
                api: "SYNO.AudioStation.Song",
                method: "list"
            }),
            container_type: a._AllMusic_ID
        }];
        a.SEC_CFG[a._ByFolder_ID] = [{
            type: a._Library_ID,
            text: _AST("common", "class_music_userfile"),
            layoutCfg: "listViewPanel",
            params: this.getWebAPIParams({
                api: "SYNO.AudioStation.Folder",
                method: "list"
            }),
            container_type: a._ByFolder_ID
        }];
        a.SEC_CFG[a._ByAlbum_ID] = [{
            type: a._Library_ID,
            text: _AST("common", "class_music_album"),
            layoutCfg: "listViewPanel",
            params: this.getWebAPIParams({
                api: "SYNO.AudioStation.Album",
                method: "list"
            }),
            container_type: a._ByAlbum_ID
        }];
        a.SEC_CFG[a._ByArtist_ID] = [{
            type: a._Library_ID,
            text: _AST("common", "class_music_artist"),
            layoutCfg: "listViewPanel",
            params: this.getWebAPIParams({
                api: "SYNO.AudioStation.Artist",
                method: "list"
            }),
            container_type: a._ByArtist_ID
        }];
        a.SEC_CFG[a._ByComposer_ID] = [{
            type: a._Library_ID,
            text: _AST("common", "class_music_composer"),
            layoutCfg: "listViewPanel",
            params: this.getWebAPIParams({
                api: "SYNO.AudioStation.Composer",
                method: "list"
            }),
            container_type: a._ByComposer_ID
        }];
        a.SEC_CFG[a._ByGenre_ID] = [{
            type: a._Library_ID,
            text: _AST("common", "class_music_genre"),
            layoutCfg: "listViewPanel",
            params: this.getWebAPIParams({
                api: "SYNO.AudioStation.Genre",
                method: "list"
            }),
            container_type: a._ByGenre_ID
        }];
        a.SEC_CFG[a._Playlist_ID] = [{
            type: a._Playlist_ID,
            text: _AST("playlist", "playlist"),
            layoutCfg: "listViewPanel",
            params: this.getWebAPIParams({
                api: "SYNO.AudioStation.Playlist",
                method: "list"
            }),
            container_type: "playlist_list"
        }];
        a.SEC_CFG[a._Random100_ID] = [{
            type: a._Library_ID,
            text: _AST("common", "random_playlist"),
            layoutCfg: "listViewPanel",
            params: this.getWebAPIParams({
                api: "SYNO.AudioStation.Song",
                method: "list"
            }),
            container_type: a._Random100_ID
        }];
        a.SEC_CFG[a._RecentlyAdded_ID] = [{
            type: a._Library_ID,
            text: _AST("common", "class_music_latestalbum"),
            layoutCfg: "listViewPanel",
            params: this.getWebAPIParams({
                api: "SYNO.AudioStation.Album",
                method: "list"
            }),
            container_type: a._RecentlyAdded_ID
        }];
        a.SEC_CFG[a._SharedSongs_ID] = [{
            type: a._Playlist_ID,
            text: _AST("playlist", "shared_songs_playlist"),
            layoutCfg: "listViewPanel",
            params: this.getWebAPIParams({
                api: "SYNO.AudioStation.Playlist",
                method: "list"
            }),
            container_type: a._Playlist_ID
        }];
        a.SEC_CFG[a._ShoutCast_ID] = [{
            type: a._Radio_ID,
            text: _AST("player", "player_source_shoutcast"),
            layoutCfg: "listViewPanel",
            params: this.getWebAPIParams({
                api: "SYNO.AudioStation.Radio",
                method: "list"
            }),
            container_type: a._Radio_ID
        }];
        a.SEC_CFG[a._Userdefined_ID] = [{
            type: a._Radio_ID,
            text: _AST("player", "player_source_userdefined"),
            layoutCfg: "listViewPanel",
            params: this.getWebAPIParams({
                api: "SYNO.AudioStation.Radio",
                method: "list"
            }),
            container_type: a._Radio_ID
        }];
        a.SEC_CFG[a._MyFavorite_ID] = [{
            type: a._Radio_ID,
            text: _AST("player", "def_radio_station"),
            layoutCfg: "listViewPanel",
            params: this.getWebAPIParams({
                api: "SYNO.AudioStation.Radio",
                method: "list"
            }),
            container_type: a._Radio_ID
        }];
        if (c) {
            c.call(b)
        }
    },
    createImgMapping: function() {
        var a = {
            personal: "icon_personal_playlist_96.png",
            shared: "icon_playlist_96.png",
            predefined: "icon_share_individually_96.png",
            random_playlist: "icon_shuffle_96.png",
            class_music_latestalbum: "icon_recently_added_96.png",
            station: "icon_radio_96.png",
            container: "icon_folder_96.png",
            folder: "icon_media_server_96.png",
            "object.container": "icon_folder_96.png",
            "object.container.storageFolder": "icon_folder_96.png",
            "object.container.playlistContainer": "icon_playlist_96.png",
            "object.container.person.musicArtist": "icon_artist_96.png",
            "object.container.person.musicComposer": "icon_composer_96.png",
            "object.container.genre.musicGenre": "icon_genre_96.png",
            "object.container.album.musicAlbum": "icon_album_96.png",
            "object.item.audioItem.musicTrack": "audio_default_songs.png",
            "SYNO.AudioStation.Song": "audio_default_songs.png",
            "SYNO.AudioStation.Folder": "icon_folder_96.png",
            "SYNO.AudioStation.Album": "icon_album_96.png",
            "SYNO.AudioStation.Artist": "icon_artist_96.png",
            "SYNO.AudioStation.Composer": "icon_composer_96.png",
            "SYNO.AudioStation.Genre": "icon_genre_96.png",
            "SYNO.AudioStation.MediaServer": "audio_default_songs.png",
            "SYNO.AudioStation.Search": "audio_default_songs.png",
            "SYNO.AudioStation.Playlist": "audio_default_songs.png"
        };
        return a
    },
    getCgiImgMapping: function(a) {
        var b = "api=SYNO.AudioStation.Cover&output_default=true&is_hr={0}&version=" + this.webAPIVersion["SYNO.AudioStation.Cover"] + "&library=" + SYNO.SDS.AudioStation.Window.getBrowseLibraryType() + "&_dc=" + this.coverTimeStamp;
        switch (a) {
            case "album":
            case "SYNO.AudioStation.Album":
                return b + "&method=getcover&view={1}&album_name={2}&album_artist_name={3}";
            case "artist":
            case "SYNO.AudioStation.Artist":
                return b + "&method=getcover&view={1}&artist_name={2}";
            case "composer":
            case "SYNO.AudioStation.Composer":
                return b + "&method=getcover&view={1}&composer_name={2}";
            case "genre":
            case "SYNO.AudioStation.Genre":
                return b + "&method=getcover&view={1}&genre_name={2}";
            case "default_genre":
                return b + "&method=getcover&view={1}&default_genre_name={2}";
            case "folder":
                return b + "&method=getfoldercover&view={1}&id={2}";
            case "file":
                return b + "&method=getsongcover&view={1}&id={2}";
            default:
                return this.getImageByDisplay(this.imgMapping["SYNO.AudioStation.Song"])
        }
    },
    createWebAPIVersionMapping: function() {
        var a = {
            "SYNO.AudioStation.Album": 3,
            "SYNO.AudioStation.Artist": 4,
            "SYNO.AudioStation.Composer": 2,
            "SYNO.AudioStation.Cover": 3,
            "SYNO.AudioStation.Download": 1,
            "SYNO.AudioStation.Folder": 2,
            "SYNO.AudioStation.Genre": 3,
            "SYNO.AudioStation.Info": 4,
            "SYNO.AudioStation.Lyrics": 2,
            "SYNO.AudioStation.LyricsSearch": 2,
            "SYNO.AudioStation.MediaServer": 1,
            "SYNO.AudioStation.Playlist": 3,
            "SYNO.AudioStation.Proxy": 1,
            "SYNO.AudioStation.Radio": 2,
            "SYNO.AudioStation.RemotePlayer": 3,
            "SYNO.AudioStation.RemotePlayerStatus": 1,
            "SYNO.AudioStation.Search": 1,
            "SYNO.AudioStation.Song": 3,
            "SYNO.AudioStation.Stream": 2,
            "SYNO.AudioStation.WebPlayer": 1,
            "SYNO.AudioStation.Pin": 1
        };
        return a
    },
    getErrCodeMapping: function(a, b, c) {
        switch (a) {
            case 0:
                return "AUDIO_ERR_NONE";
            case 101:
                if (("SYNO.AudioStation.Playlist" === b && "create" === c) || ("SYNO.AudioStation.Playlist" === b && "rename" === c)) {
                    return "AUDIO_ERR_INVALID_PLAYLIST_NAME"
                }
                return "AUDIO_ERR_COMMON_ERR";
            case 403:
                return "AUDIO_ERR_LIST_RADIO_FAIL";
            case 405:
                if ("SYNO.AudioStation.Playlist" === b && "copytolibrary" === c) {
                    return "AUDIO_ERR_FILE_OVERWRITE"
                } else {
                    if ("SYNO.AudioStation.RemotePlayer" === b && "setpassword" === c) {
                        return "AUDIO_ERR_INVALID_PASSWORD"
                    }
                }
                return "AUDIO_ERR_COMMON_ERR";
            case 406:
                return "AUDIO_ERR_FILE_EXISTS";
            case 409:
                return "AUDIO_ERR_TOO_MANY_SONGS";
            case 410:
                return "AUDIO_ERR_SHARED_PLAYLIST_CONTAINS_SONG_RATING";
            case 411:
            case 1201:
                return "AUDIO_ERR_DUPLICATE_SONGS";
            case 407:
            case 412:
            case 1202:
                return "AUDIO_ERR_PLAYLIST_NOT_EXISTS";
            case 500:
                return "AUDIO_ERR_DEVICE_NOT_EXISTS";
            case 501:
                return "AUDIO_ERR_INVALID_PASSWORD";
            case 502:
                return "AUDIO_ERR_DEVICE_BUSY";
            case 620:
                return "AUDIO_ERR_FAILED_TO_CONNECT_PORTAL_SERVER";
            case 1006:
                return "AUDIO_ERR_PIN_EXIST";
            case 1007:
                return "AUDIO_ERR_PIN_NOT_EXIST";
            case 1010:
            case 1011:
                return "AUDIO_ERR_PIN_TARGET_NOT_EXIST";
            default:
                return "AUDIO_ERR_COMMON_ERR"
        }
    },
    getErrMsgStringFromResponse: function(b, a) {
        var c = {};
        if (b.status === 200 && b.responseText) {
            c = Ext.util.JSON.decode(b.responseText);
            if (c && c.error && c.error.code) {
                return this.getErrMsgString(this.getErrCodeMapping(c.error.code))
            }
        }
        return a ? a : _AST("common", "error_system")
    },
    getErrMsgString: function(a) {
        switch (a) {
            case "AUDIOAPI_ERR_LIST_RADIO_FAIL":
                return _AST("radio", "err_radio_get");
            case "AUDIO_ERR_FILE_OVERWRITE":
                return _AST("playlist", "playlist_name_overwrite");
            case "AUDIO_ERR_FILE_EXISTS":
                return _AST("playlist", "playlist_name_exist");
            case "AUDIO_ERR_TOO_MANY_SONGS":
                return _AST("player", "error_too_many_songs");
            case "AUDIO_ERR_INVALID_PASSWORD":
                return _AST("airplay", "error_airplay_password_incorrect");
            case "AUDIO_ERR_INVALID_PLAYLIST_NAME":
                return _AST("playlist", "error_reserved_name");
            case "AUDIO_ERR_DEVICE_BUSY":
                return _AST("airplay", "error_airplay_busy");
            case "AUDIO_ERR_SHARED_PLAYLIST_CONTAINS_SONG_RATING":
                return _AST("playlist", "error_copy_contains_rating_rule");
            case "AUDIO_ERR_DUPLICATE_SONGS":
                return _AST("playlist", "duplicate_songs");
            case "AUDIO_ERR_FAILED_TO_CONNECT_PORTAL_SERVER":
                return _AST("setting", "error_alexa_connect_portal_server");
            case "AUDIO_ERR_DEVICE_NOT_EXISTS":
                return _AST("player", "error_device_not_found");
            case "AUDIO_ERR_PLAYLIST_NOT_EXISTS":
                return String.format("<b>{0}</b><br>{1}", String.format(_AST("common", "error_dose_not_exist"), _AST("playlist", "playlist")), _AST("common", "error_dsm_may_be_reindexing"));
            default:
                return _T("common", "error_system")
        }
    },
    processAlbumArtUrl: function(b, d) {
        var g = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo(),
            f = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main");
        if ("pin" === d) {
            var e = b.type;
            var a = b.criteria;
            if ("folder" === e) {
                return Ext.urlAppend(this.getWebAPIURL("cover.cgi"), String.format(this.getCgiImgMapping(e), f.gIsRetina, "default", a.folder))
            } else {
                if ("artist" === e) {
                    return Ext.urlAppend(this.getWebAPIURL("cover.cgi"), String.format(this.getCgiImgMapping(e), f.gIsRetina, "default", encodeURIComponent(a.artist)))
                } else {
                    if ("composer" === e) {
                        return Ext.urlAppend(this.getWebAPIURL("cover.cgi"), String.format(this.getCgiImgMapping(e), f.gIsRetina, "default", encodeURIComponent(a.composer)))
                    } else {
                        if ("album" === e) {
                            return Ext.urlAppend(this.getWebAPIURL("cover.cgi"), String.format(this.getCgiImgMapping(e), f.gIsRetina, "default", encodeURIComponent(a.album), encodeURIComponent(a.album_artist)))
                        } else {
                            if ("genre" === e) {
                                return Ext.urlAppend(this.getWebAPIURL("cover.cgi"), String.format(this.getCgiImgMapping(e), f.gIsRetina, "default", encodeURIComponent(a.genre)))
                            } else {
                                if ("playlist" === e) {
                                    if (this.isPredefinedPls(a.playlist)) {
                                        return this.getImageByDisplay(this.imgMapping.predefined)
                                    } else {
                                        if (this.isSharedItem(a.playlist)) {
                                            return this.getImageByDisplay(this.imgMapping[this.getSharedPlsLib()])
                                        } else {
                                            if (this.isPersonalItem(a.playlist)) {
                                                return this.getImageByDisplay(this.imgMapping[this.getPersonalPlsLib()])
                                            }
                                        }
                                    }
                                } else {
                                    if ("random_100" === e) {
                                        return this.getImageByDisplay(this.imgMapping.random_playlist)
                                    } else {
                                        if ("recently_added" === e) {
                                            return this.getImageByDisplay(this.imgMapping.class_music_latestalbum)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if ("default_genre" === d) {
                return Ext.urlAppend(this.getWebAPIURL("cover.cgi"), String.format(this.getCgiImgMapping("default_genre"), f.gIsRetina, "default", encodeURIComponent(b.name)))
            } else {
                if (this._Library_ID === g.type || this._SearchResults_ID === g.type || this._Homepage_ID === g.type) {
                    if (b.type) {
                        return Ext.urlAppend(this.getWebAPIURL("cover.cgi"), String.format(this.getCgiImgMapping(b.type), f.gIsRetina, "default", b.id))
                    } else {
                        if (d) {
                            return Ext.urlAppend(this.getWebAPIURL("cover.cgi"), String.format(this.getCgiImgMapping(d), f.gIsRetina, "default", encodeURIComponent(b.name), encodeURIComponent(b.album_artist)))
                        } else {
                            if (this.getCgiImgMapping(g.params.api)) {
                                var c;
                                if (b.id === "AllMusic") {
                                    return this.getImageByDisplay(this.imgMapping[g.params.api])
                                }
                                c = Ext.urlAppend(this.getWebAPIURL("cover.cgi"), String.format(this.getCgiImgMapping(g.params.api), f.gIsRetina, "default", encodeURIComponent(b.name), encodeURIComponent(b.album_artist)));
                                if (g.params.api !== "SYNO.AudioStation.Genre") {
                                    if (g.params.genre !== null && "undefined" !== typeof(g.params.genre)) {
                                        c += "&genre_name=" + encodeURIComponent(g.params.genre)
                                    } else {
                                        if (g.params.genre_filter !== null && "undefined" !== typeof(g.params.genre_filter)) {
                                            c += "&genre_filter=" + encodeURIComponent(g.params.genre_filter)
                                        }
                                    }
                                }
                                return c
                            }
                        }
                    }
                } else {
                    if (this._Playlist_ID === g.type) {
                        if (this.isPredefinedPls(b.id)) {
                            return this.getImageByDisplay(this.imgMapping.predefined)
                        } else {
                            if (b.library) {
                                return this.getImageByDisplay(this.imgMapping[b.library])
                            } else {
                                return this.getTrackCover(b, "default")
                            }
                        }
                    } else {
                        if (this._Radio_ID === g.type) {
                            if (this.imgMapping[b.id]) {
                                return this.getImageByDisplay(this.imgMapping[b.id])
                            } else {
                                return this.getImageByDisplay(this.imgMapping[b.type])
                            }
                        } else {
                            if (this._MediaServer_ID === g.type) {
                                if (!b["class"]) {
                                    return this.getImageByDisplay(this.imgMapping[b.type])
                                } else {
                                    return (b.cover) ? Ext.urlAppend(this.getWebAPIURL("proxy.cgi"), String.format("api=SYNO.AudioStation.Proxy&chktype=false&method={0}&version={1}&url={2}", "stream", this.webAPIVersion["SYNO.AudioStation.Proxy"], encodeURIComponent(b.cover))) : this.getImageByDisplay(this.imgMapping[b["class"]])
                                }
                            } else {
                                return this.getTrackCover(b, "default")
                            }
                        }
                    }
                }
            }
        }
    },
    getTrackCover: function(b, a) {
        var e = b.id,
            d, c = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main");
        if (0 === e.indexOf("music_")) {
            return Ext.urlAppend(this.getWebAPIURL("cover.cgi"), String.format(this.getCgiImgMapping(b.type), c.gIsRetina, a, b.id))
        } else {
            if (0 === e.indexOf("remote_")) {
                d = Ext.util.JSON.decode(e.substring(e.indexOf("_") + 1, e.lastIndexOf(" "))).cover;
                if (d && (0 === d.indexOf("http://") || 0 === d.indexOf("https://"))) {
                    return Ext.urlAppend(this.getWebAPIURL("proxy.cgi"), String.format("api=SYNO.AudioStation.Proxy&chktype=false&method={0}&version={1}&url={2}", "stream", this.webAPIVersion["SYNO.AudioStation.Proxy"], encodeURIComponent(d)))
                } else {
                    if ("default" === a) {
                        return this.getImageByDisplay("audio_default_songs.png")
                    } else {
                        if ("playing" == a) {
                            return this.getImageByDisplay("audio_album_music_s.png")
                        } else {
                            return this.getImageByDisplay("audio_default_songs.png")
                        }
                    }
                }
            } else {
                return ("default" === a) ? this.getImageByDisplay("audio_default_songs.png") : this.getImageByDisplay("audio_album_music_s.png")
            }
        }
    },
    getImageByDisplay: function(c, a) {
        var b = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main");
        if (!a) {
            a = b.baseURL
        }
        var d = b.gIsRetina ? a + "/images/2x/" : a + "/images/1x/";
        return d + c
    },
    isMobileStyle: function() {
        var a = navigator.userAgent,
            b = /webOS|iPhone|iPod|BlackBerry|Opera Mini|IEMobile|windows phone os 7|windows phone 8/i;
        if (b.test(a)) {
            return true
        } else {
            if (/Android/i.test(a) && /mobile/i.test(a)) {
                return true
            }
        }
        return false
    },
    isMobileDevice: function() {
        return (/Android|webOS|iPhone|iPad|iPod|BlackBerry|Opera Mini|IEMobile|windows phone os 7|windows phone 8/i.test(navigator.userAgent))
    },
    isIosDevice: function() {
        return (/(iPhone|iPod|iPad)/i.test(navigator.userAgent))
    },
    isSupportHtml5AutoPlay: function() {
        if (this.isIosDevice() || (this.isMobileDevice() && !!window.chrome)) {
            return false
        }
        return true
    },
    isInLibrary: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (a.type === this._Library_ID || a.type === this._SearchResults_ID) {
            return true
        }
        return false
    },
    isInLibraryFolder: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if ("SYNO.AudioStation.Folder" === a.params.api) {
            return true
        }
        return false
    },
    isInLibrarySearch: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if ("SYNO.AudioStation.Song" === a.params.api && "search" === a.params.method) {
            return true
        }
        return false
    },
    isInAllMusic: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if ("SYNO.AudioStation.Song" === a.params.api && "list" === a.params.method && undefined === a.params.album && undefined === a.params.artist && undefined === a.params.composer && undefined === a.params.genre && undefined === a.params.sort_by) {
            return true
        }
        return false
    },
    isInRandom100: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if ("SYNO.AudioStation.Song" === a.params.api && "random" === a.params.sort_by) {
            return true
        }
        return false
    },
    isInLatestAlbum: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if ("SYNO.AudioStation.Album" === a.params.api && "time" === a.params.sort_by) {
            return true
        }
        return false
    },
    isInAlbum: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (a.params.api === "SYNO.AudioStation.Song" && (undefined !== a.params.album && undefined !== a.params.album_artist)) {
            return true
        }
        return false
    },
    isInArtistList: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (a.params.api === "SYNO.AudioStation.Artist") {
            return true
        }
        return false
    },
    isInGenreArtistList: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (((1 == a.index && !this.isInSearchAllDetail()) || this.isInHomepage()) && a.params.api === "SYNO.AudioStation.Artist") {
            return true
        }
        return false
    },
    isInComposerList: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (a.params.api === "SYNO.AudioStation.Composer") {
            return true
        }
        return false
    },
    isInGenreList: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (a.params.api === "SYNO.AudioStation.Genre") {
            return true
        }
        return false
    },
    isInRating: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (2 == a.index && a.params.api === "SYNO.AudioStation.Song" && (Ext.isDefined(a.params.song_rating_meq) || Ext.isDefined(a.params.song_rating_leq))) {
            return true
        }
        return false
    },
    isInCateAllMusic: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (1 < a.index && a.params.api === "SYNO.AudioStation.Song" && undefined === a.params.album) {
            return true
        }
        return false
    },
    isInCateAlbumLayer: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (((1 === a.index && a.params.api === "SYNO.AudioStation.Album") && !this.isInSearchAllDetail()) || (2 === a.index && a.params.api === "SYNO.AudioStation.Album") || (this.isInHomepage() && a.params.api === "SYNO.AudioStation.Album" && a.params.sort_by !== "time")) {
            return true
        }
        return false
    },
    isInSearchAllDetail: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (undefined === a.params.artist && undefined === a.params.album_artist && undefined === a.params.composer && undefined === a.params.genre) {
            return true
        }
        return false
    },
    isInAlbumLayer: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (a.params.api === "SYNO.AudioStation.Album") {
            return true
        }
        return false
    },
    isInPlaylist: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (a.type === this._Playlist_ID) {
            return true
        }
        return false
    },
    isInAllPlaylist: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (0 === a.index && a.params.api === "SYNO.AudioStation.Playlist" && a.params.method === "list") {
            return true
        }
        return false
    },
    isInPlaylistLayer2: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (a.type === this._Playlist_ID && a.params.api === "SYNO.AudioStation.Playlist" && a.params.method === "getinfo") {
            return true
        }
        return false
    },
    isInPredefinedPlaylist: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (2 > a.index && a.type === this._Playlist_ID && this.isPredefinedPls(a.params.id)) {
            return true
        }
        return false
    },
    isInPublicSharingPlaylist: function() {
        var b = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main").dataStore,
            a;
        if (this.testProperty(b, "reader.jsonData.data.playlists")) {
            a = b.reader.jsonData.data.playlists[0];
            if (a && "valid" == a.sharing_status) {
                return true
            }
        }
        return false
    },
    isInSearchAllCate: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if ("SYNO.AudioStation.Search" === a.params.api) {
            return true
        }
        return false
    },
    isAtHomepage: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (0 === a.index && a.type === this._Homepage_ID) {
            return true
        }
        return false
    },
    isInHomepage: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (a.type === this._Homepage_ID) {
            return true
        }
        return false
    },
    isAtPinList: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (1 === a.index && "SYNO.AudioStation.Pin" === a.params.api && a.type === this._Homepage_ID) {
            return true
        }
        return false
    },
    isInHomepagePlaylist: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if ("SYNO.AudioStation.Playlist" === a.params.api && "getinfo" === a.params.method && a.type === this._Homepage_ID) {
            return true
        }
        return false
    },
    isDefaultGenreRecord: function(a) {
        if (a.store && "list_default_genre" === a.store.baseParams.method) {
            return true
        }
        return false
    },
    getSmartPlsType: function() {
        return "smart"
    },
    getNormalPlsType: function() {
        return "normal"
    },
    getPersonalPlsLib: function() {
        return "personal"
    },
    getSharedPlsLib: function() {
        return "shared"
    },
    checkPlaylistEditable: function(a) {
        if (this.isSmartItem(a)) {
            return false
        }
        if (this.isPersonalItem(a) || SYNO.SDS.AudioStation.SessionData.privilege.playlist_edit) {
            return true
        }
        return false
    },
    isSharedItem: function(a) {
        if (-1 !== a.substr(0, a.indexOf("/")).search(this.getSharedPlsLib())) {
            return true
        }
        return false
    },
    isPersonalItem: function(a) {
        if (-1 !== a.substr(0, a.indexOf("/")).search(this.getPersonalPlsLib())) {
            return true
        }
        return false
    },
    isNormalItem: function(a) {
        if (-1 !== a.substr(0, a.indexOf("/")).search(this.getNormalPlsType())) {
            return true
        }
        return false
    },
    isSmartItem: function(a) {
        if (-1 !== a.substr(0, a.indexOf("/")).search(this.getSmartPlsType())) {
            return true
        }
        return false
    },
    isPredefinedPls: function(a) {
        if ("playlist_personal_normal/__SYNO_AUDIO_SHARED_SONGS__" === a) {
            return true
        }
        return false
    },
    isContainPersonalItem: function(b) {
        var a;
        var c;
        for (c = 0; c < b.length; c++) {
            a = b[c];
            if (!a) {
                continue
            }
            if (this.isPersonalItem(a.get("id"))) {
                return true
            }
        }
        return false
    },
    isContainSharedItem: function(b) {
        var a;
        var c;
        for (c = 0; c < b.length; c++) {
            a = b[c];
            if (!a) {
                continue
            }
            if (this.isSharedItem(a.get("id"))) {
                return true
            }
        }
        return false
    },
    isContainSmartItem: function(b) {
        var a;
        var c;
        for (c = 0; c < b.length; c++) {
            a = b[c];
            if (!a) {
                continue
            }
            if (this.isSmartItem(a.get("id"))) {
                return true
            }
        }
        return false
    },
    isContainNormalItem: function(b) {
        var a;
        var c;
        for (c = 0; c < b.length; c++) {
            a = b[c];
            if (!a) {
                continue
            }
            if (this.isNormalItem(a.get("id"))) {
                return true
            }
        }
        return false
    },
    isContainPredefinedItem: function(b) {
        var a;
        var c;
        for (c = 0; c < b.length; c++) {
            a = b[c];
            if (!a) {
                continue
            }
            if (this.isPredefinedPls(a.get("id"))) {
                return true
            }
        }
        return false
    },
    isInRadio: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (this._Radio_ID === a.type) {
            return true
        }
        return false
    },
    isInetRadioItem: function(b) {
        var a = b.substr(0, 6);
        if ("radio_" === a) {
            return true
        }
        return false
    },
    isInRadioLeaf: function() {
        if (this.isInRadio() && !this.isInShoutCastCate()) {
            return true
        }
        return false
    },
    isInShoutCast: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (a.params.container && "SHOUTcast" === a.params.container.substr(0, 9)) {
            return true
        }
        return false
    },
    isInShoutCastCate: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if ("SHOUTcast" === a.params.container) {
            return true
        }
        return false
    },
    isInShoutCastSearch: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (this._Radio_ID === a.type && "search" === a.params.method) {
            return true
        }
        return false
    },
    isInRadioUserDefined: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if ("UserDefined" === a.params.container) {
            return true
        }
        return false
    },
    isInRadioFavorite: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if ("Favorite" === a.params.container) {
            return true
        }
        return false
    },
    getRadioTitleByContainer: function(a) {
        return ("UserDefined" === a) ? _AST("player", "player_source_userdefined") : _AST("player", "def_radio_station")
    },
    isMediaServerRoot: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (0 === a.index && a.type === this._MediaServer_ID) {
            return true
        }
        return false
    },
    isInMediaserver: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if ("SYNO.AudioStation.MediaServer" === a.params.api) {
            return true
        }
        return false
    },
    isPlayingQueue: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (this._PlayingQueue_ID === a.type) {
            return true
        }
        return false
    },
    getUpdatedIndex: function(c, f, e, a, g) {
        var b = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main").playingStore,
            d = -2;
        if (a <= f && (undefined === g || g >= f)) {
            d = b.indexOf(e)
        }
        return d
    },
    rearrangeStore: function(d, a, b) {
        var e = (50 < d.length) ? true : false,
            c;
        a.suspendEvents(!e);
        if (d.length === a.getTotalCount()) {
            a.removeAll()
        } else {
            for (c = 0; c < d.length; c++) {
                a.remove(d[c])
            }
        }
        a.insert(b, d);
        a.resumeEvents();
        SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main").selectRecords(d);
        return e
    },
    updateSongsInStore: function(c, b) {
        var a, d = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main"),
            e;
        if (Ext.isString(c.params.songs)) {
            a = c.params.songs.replace(/{[^{}]+}/g, "").match(/,/g)
        }
        if ((0 !== c.params.limit) && null !== a && undefined !== a && (c.params.limit - 1 === a.length)) {
            e = d.getPlayingPanel() || d.listViewPanel;
            if (!e) {
                return
            }
            e.updateScrollbar(false, b);
            e.getView().refresh()
        } else {
            b.reload()
        }
    },
    isTrack: function(a) {
        if ("station" === a.get("type") || "file" === a.get("type") || "remote" === a.get("type")) {
            return true
        }
        return false
    },
    isLocalMusic: function(a) {
        var c = a.get("path"),
            b = a.get("url");
        if ("http" === c.substr(0, 4).toLowerCase() || (b && "http" === b.substr(0, 4).toLowerCase())) {
            return false
        }
        return true
    },
    isVirtualMusic: function(a) {
        var b = a.get("id");
        if (0 === b.indexOf("music_v_") || 0 === b.indexOf("music_p_v_")) {
            return true
        }
        return false
    },
    parseVirtualPath: function(c) {
        var b, a;
        if ("http" === c.substr(0, 4).toLowerCase()) {
            return false
        }
        b = c.lastIndexOf(".");
        if (-1 == b) {
            return false
        }
        a = c.indexOf("_", b);
        if (-1 == a) {
            return false
        }
        return {
            path: c.substring(0, a),
            track: c.substring(a + 1)
        }
    },
    isTagEditableMusic: function(a) {
        var c;
        var b;
        if (this.isVirtualMusic(a)) {
            return false
        }
        if (this.isLocalMusic(a)) {
            c = a.get("path");
            b = this.getFileExtensionName(c);
            if (0 <= this.TAG_EDITABLE_TYPE_LIST.indexOf(b.toLowerCase())) {
                return true
            }
        }
        return false
    },
    isSongExistent: function(a) {
        if ("file" !== a.get("type")) {
            return true
        }
        if (!this.isInPlaylistLayer2() && !this.isPlayingQueue()) {
            return true
        }
        var b = a.get("id").substr(a.get("id").lastIndexOf("_") + 1);
        if ("0" === b || isNaN(b)) {
            return false
        }
        return true
    },
    isExternalPath: function(a) {
        if (a.indexOf("/volumeUSB") === 0 || a.indexOf("/volumeSATA") === 0) {
            return true
        } else {
            return false
        }
    },
    POWER_DECODE_LIST: ["dsf", "dff"],
    TRANSCODE_TYPE_LIST: ["mp1", "mp2", "mp3", "mpa", "m4a", "m4b", "m4p", "aac", "ogg", "wav", "flac", "ape", "aiff", "aif", "wma", "dsf", "dff"],
    TAG_EDITABLE_TYPE_LIST: ["mp3", "ogg", "m4a", "m4p", "flac", "aiff", "aif", "m4b"],
    streamingModeSupportList: {
        init: false
    },
    getStreamingPlayTypeByRecord: function(b) {
        var a = SYNO.SDS.AudioStation.Utils,
            e, d, c;
        e = b.get("path");
        d = a.getFileExtensionName(e);
        c = a.getStreamingPlayTypeByExt(d);
        if (a.isALAC(b)) {
            c = a.getStreamingPlayTypeByExt("m4a_alac")
        }
        if (a.isVirtualMusic(b) && "wav" === d.toLowerCase()) {
            c = "wav"
        }
        if (Ext.isGecko && b.get("container") === "wav" && b.get("codec") !== "pcm_s16le") {
            c = a.getStreamingPlayTypeByExt("force_transcode")
        }
        return c
    },
    createFieldConvertFunc: function(c, b, a) {
        return function(e, f) {
            var d;
            if (f[c]) {
                return f[c]
            }
            if (f.additional && f.additional[b] && f.additional[b][a]) {
                d = f.additional;
                if (d[b] && d[b][a]) {
                    return d[b][a]
                }
            }
            if (f.additional && f.additional.songs && f.additional.songs.additional) {
                d = f.additional.songs.additional;
                if (d[b] && d[b][a]) {
                    return d[b][a]
                }
            }
            return ""
        }
    },
    getStreamingPlayTypeByExt: function(a) {
        if (!SYNO.SDS.AudioStation.Utils.streamingModeSupportList.init) {
            SYNO.SDS.AudioStation.Utils.createStreamingModeSupportList()
        }
        return SYNO.SDS.AudioStation.Utils.streamingModeSupportList[a.toLowerCase()]
    },
    getAirplayNotSupportFormat: function() {
        var a = [];
        var b = this.canDSDDecode();
        if (!b) {
            Ext.each(SYNO.SDS.AudioStation.Utils.POWER_DECODE_LIST, function(c) {
                a.push(c)
            })
        }
        return {
            list: a
        }
    },
    getStreamingSupportFormat: function() {
        var b = [],
            a = false,
            c = SYNO.SDS.AudioStation.Utils.streamingModeSupportList;
        if (!c.init) {
            SYNO.SDS.AudioStation.Utils.createStreamingModeSupportList()
        }
        Ext.each(SYNO.SDS.AudioStation.Utils.TRANSCODE_TYPE_LIST, function(d) {
            if (c[d]) {
                b.push(d)
            }
        });
        if (c.m4a_alac) {
            a = true
        }
        return {
            list: b,
            m4a_alac: a
        }
    },
    updateSupportField: function(c) {
        var b = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main"),
            a;
        c = c.toLowerCase();
        a = c.substr(c.lastIndexOf(".") + 1);
        if (!this.airplayNotSupportObj) {
            this.airplayNotSupportObj = this.getAirplayNotSupportFormat()
        }
        if (0 === c.indexOf("http://") || 0 === c.indexOf("https://")) {
            return true
        }
        if (this.isStreamStoreCopy || "web" === b.gCurrentSelectPlayerType) {
            if (!this.streamSupportObj || -1 === this.streamSupportObj.list.indexOf(a)) {
                return false
            }
        } else {
            if ("airplay" === b.gCurrentSelectPlayerType) {
                if (-1 !== this.airplayNotSupportObj.list.indexOf(a)) {
                    return false
                }
            }
        }
        return true
    },
    canDSDDecode: function() {
        return SYNO.SDS.AudioStation.SessionData.dsd_decode_capability
    },
    createStreamingModeSupportList: function() {
        var e = SYNO.SDS.AudioStation.Utils.streamingModeSupportList;
        e.init = true;
        var d = SYNO.SDS.AudioStation.SessionData.settings.transcode_to_mp3;
        var c = this.canDSDDecode();
        var b = soundManager.canPlayURL(".wav");
        var a = soundManager.canPlayURL(".mp3");
        Ext.each(SYNO.SDS.AudioStation.Utils.TRANSCODE_TYPE_LIST, function(g) {
            var f = soundManager.canPlayURL("." + g);
            if (f) {
                e[g] = "direct"
            } else {
                if ("dsf" === g || "dff" === g) {
                    if (c) {
                        if (d && a) {
                            e[g] = "mp3"
                        } else {
                            if (b) {
                                e[g] = "wav"
                            } else {
                                e[g] = false
                            }
                        }
                    } else {
                        e[g] = false
                    }
                } else {
                    if (d && a) {
                        e[g] = "mp3"
                    } else {
                        if (b) {
                            e[g] = "wav"
                        } else {
                            e[g] = false
                        }
                    }
                }
            }
        });
        if (d && a) {
            e.m4a_alac = "mp3";
            e.force_transcode = "mp3"
        } else {
            if (b) {
                e.m4a_alac = "wav";
                e.force_transcode = "wav"
            } else {
                e.m4a_alac = false;
                e.force_transcode = false
            }
        }
    },
    getFileExtensionName: function(d) {
        var c = /.*\.(.+)$/;
        var b = d.match(c);
        var a = "";
        if (b && b.length === 2) {
            a = b[1]
        }
        return a
    },
    isLossless: function(a) {
        var c = a.get("bitrate");
        var b = SYNO.SDS.AudioStation.Utils.getFileExtensionName(a.get("path")).toLowerCase();
        if ("m4a" === b && c > 320000) {
            return true
        } else {
            if (c > 512000) {
                return true
            }
        }
        return false
    },
    isALAC: function(b) {
        var a = SYNO.SDS.AudioStation.Utils;
        var d = b.get("path");
        var c = a.getFileExtensionName(d);
        if (b.get("container") === "mp4" && b.get("codec") === "alac") {
            return true
        }
        if (c.toLowerCase() === "m4a" && a.isLossless(b)) {
            return true
        }
        return false
    },
    isPrivateNetworkIp: function(a) {
        var e = /http:\/\/([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})\.([0-9]{1,3})/i;
        var d, b;
        if (typeof(a) !== "string") {
            return false
        }
        var c = a.match(e);
        if (!c || (5 !== c.length)) {
            return false
        }
        d = parseInt(c[1], 10);
        b = parseInt(c[2], 10);
        if (192 === d && 168 === b) {
            return true
        }
        if (10 === d) {
            return true
        }
        if (172 === d && (16 <= b && b <= 31)) {
            return true
        }
        return false
    },
    setImgSquareCenterStyle: function(f, d, g) {
        var c = d.width,
            a = d.height;
        var e, b;
        f.dom.style.marginTop = "";
        f.dom.style.marginLeft = "";
        if (a > c) {
            e = g / c * a;
            f.setWidth(g);
            f.setHeight(e);
            f.dom.style.marginTop = (g - e) / 2 + "px"
        } else {
            b = g * c / a;
            f.setWidth(b);
            f.setHeight(g);
            f.dom.style.marginLeft = (g - b) / 2 + "px"
        }
    },
    setImgFitCenterStyle: function(f, d, g) {
        var c = d.width,
            a = d.height;
        var b, e;
        f.dom.style.marginTop = "";
        f.dom.style.marginLeft = "";
        if (a > c) {
            b = g * c / a;
            f.setWidth(b);
            f.setHeight(g);
            f.dom.style.marginLeft = (g - b) / 2 + "px"
        } else {
            e = g / c * a;
            f.setWidth(g);
            f.setHeight(e);
            f.dom.style.marginTop = (g - e) / 2 + "px"
        }
    },
    resetImgSize: function(a, b) {
        a.dom.style.marginTop = "";
        a.dom.style.marginLeft = "";
        a.setWidth(b);
        a.setHeight(b);
        a.dom.src = Ext.BLANK_IMAGE_URL
    },
    getPlayingQueueIconClass: function(b) {
        var a = "music_track";
        if (b.get("isNowPlaying")) {
            return b.get("isNowPaused") ? "music_isNowPaused" : "music_isNowPlaying"
        }
        return a
    },
    getRenderedTitle: function(a, b) {
        if (this.isInArtistList() && "" === a) {
            if ("AllMusic" === b) {
                a = _AST("common", "class_music_allalbum")
            } else {
                a = _AST("common", "unknown_music_artist")
            }
        } else {
            if (this.isInComposerList() && "" === a) {
                a = _AST("common", "unknown_music_composer")
            } else {
                if (this.isInGenreList() && "" === a) {
                    a = _AST("common", "unknown_music_genre")
                } else {
                    if (this.isInCateAlbumLayer() && "" === a) {
                        a = _AST("common", "class_music_allmusic")
                    }
                }
            }
        }
        return a.trim()
    },
    timeRenderer: function(c) {
        var b;
        if (isNaN(c) || "" === c) {
            return ""
        }
        if (0 === c) {
            return _AST("player", "unknown_duration")
        }
        var a = {
            hour: Math.floor(c / 3600),
            minute: Math.floor((c % 3600) / 60),
            second: Math.floor(c % 60)
        };
        if (c >= 3600) {
            b = ([a.hour, String.leftPad(a.minute, 2, "0"), String.leftPad(a.second, 2, "0")]).join(":")
        } else {
            if (c < 60) {
                b = "0:" + String.leftPad(a.second, 2, "0")
            } else {
                b = a.minute + ":" + String.leftPad(a.second, 2, "0")
            }
        }
        return b
    },
    getAlbumJsonObj: function(b, h, c, a, e, g, f, d) {
        var i = {
            type: "album",
            sort_by: f,
            sort_direction: d
        };
        if (null !== b) {
            i.album = b;
            i.album_artist = h
        }
        if (null !== c) {
            i.artist = c
        }
        if (null !== a) {
            i.composer = a
        }
        if (null !== e && "undefined" !== typeof(e)) {
            i.genre = e
        } else {
            if (null !== g && "undefined" !== typeof(g)) {
                i.genre_filter = g
            }
        }
        return i
    },
    getInfoJsonObj: function(c, f, a, e, b, d) {
        var g = {
            type: c,
            sort_by: b,
            sort_direction: d
        };
        if (null !== f) {
            if ("artist" === c) {
                g.artist = f
            } else {
                if ("composer" === c) {
                    g.composer = f
                } else {
                    if ("genre" === c) {
                        g.genre = f
                    }
                }
            }
        }
        if ("genre" !== c) {
            if (null !== a && "undefined" !== typeof(a)) {
                g.genre = a
            } else {
                if (null !== e && "undefined" !== typeof(e)) {
                    g.genre_filter = e
                }
            }
        }
        return g
    },
    getRatingJsonObj: function(c, e, a, b) {
        var d = {
            type: "rating",
            song_rating_meq: c,
            song_rating_leq: e,
            sort_by: a,
            sort_direction: b
        };
        return d
    },
    getFolderJsonObj: function(e, a, b, c) {
        var d = {
            type: "folder",
            id: e,
            recursive: a,
            sort_by: b,
            sort_direction: c
        };
        return d
    },
    getPlaylistJsonObj: function(b) {
        var a = {
            type: "playlist",
            id: b
        };
        return a
    },
    getSearchJsonObj: function(d, a, b, c) {
        var e = {
            type: "search",
            sort_by: b,
            sort_direction: c
        };
        if ("all" === d) {
            e.album = a;
            e.artist = a;
            e.composer = a;
            e.genre = a;
            e.title = a
        } else {
            e[d] = a
        }
        return e
    },
    getContainerJsonList: function(c, h) {
        var b = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        var f = b.params.api;
        var g = [],
            e, j, l;
        for (e = 0; e < c.length; e++) {
            if (!c[e]) {
                continue
            }
            var k = "AllMusic" === c[e].get("id");
            if ("SYNO.AudioStation.Album" === f) {
                l = this.getSortInfo("MusicColumnSetting");
                j = this.getAlbumJsonObj(("AllMusic" === c[e].get("id")) ? null : c[e].get("name"), c[e].get("album_artist"), b.params.artist, b.params.composer, b.params.genre, b.params.genre_filter, l.field, l.direction)
            } else {
                if ("SYNO.AudioStation.Artist" === f) {
                    l = this.getSortInfo("AlbumColumnSetting");
                    j = this.getInfoJsonObj("artist", k ? null : c[e].get("name"), b.params.genre, b.params.genre_filter, l.field, l.direction)
                } else {
                    if ("SYNO.AudioStation.Composer" === f) {
                        l = this.getSortInfo("AlbumColumnSetting");
                        j = this.getInfoJsonObj("composer", c[e].get("name"), null, null, l.field, l.direction)
                    } else {
                        if ("SYNO.AudioStation.Genre" === f) {
                            l = this.getSortInfo("AlbumColumnSetting");
                            j = this.getInfoJsonObj("genre", c[e].get("name"), null, null, l.field, l.direction)
                        } else {
                            if ("SYNO.AudioStation.Folder" === f) {
                                l = this.getSortInfo("MusicColumnSetting");
                                j = this.getFolderJsonObj(c[e].get("id"), true, l.field, l.direction)
                            } else {
                                if ("SYNO.AudioStation.Playlist" === f) {
                                    j = this.getPlaylistJsonObj(c[e].get("id"))
                                } else {
                                    if ("SYNO.AudioStation.Search" === f) {
                                        if ("artist" === h.storeType) {
                                            l = this.getSortInfo("AlbumColumnSetting");
                                            j = this.getInfoJsonObj("artist", c[e].get("name"), null, null, l.field, l.direction)
                                        } else {
                                            l = this.getSortInfo("MusicColumnSetting");
                                            j = this.getAlbumJsonObj(c[e].get("name"), c[e].get("album_artist"), b.params.artist, b.params.composer, b.params.genre, null, l.field, l.direction)
                                        }
                                    } else {
                                        if ("SYNO.AudioStation.Pin" === f) {
                                            var d = c[e].get("type");
                                            var a = c[e].get("criteria");
                                            if ("folder" === d) {
                                                l = this.getSortInfo("MusicColumnSetting", c[e]);
                                                j = this.getFolderJsonObj(a.folder, true, l.field, l.direction)
                                            } else {
                                                if ("artist" === d || "composer" === d || "genre" === d) {
                                                    l = this.getSortInfo("AlbumColumnSetting", c[e]);
                                                    j = this.getInfoJsonObj(d, a[d], b.params.genre, null, l.field, l.direction)
                                                } else {
                                                    if ("album" === d) {
                                                        l = this.getSortInfo("MusicColumnSetting", c[e]);
                                                        j = this.getAlbumJsonObj(a.album, a.album_artist, a.artist, a.composer, a.genre, null, l.field, l.direction)
                                                    } else {
                                                        if ("playlist" === d) {
                                                            j = this.getPlaylistJsonObj(a.playlist)
                                                        } else {
                                                            if ("random_100" === d) {
                                                                j = {
                                                                    type: "random_100"
                                                                }
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
            g.push(j)
        }
        return g
    },
    getSongIdList: function(b) {
        var a = "",
            c;
        for (c = 0; c < b.length; c++) {
            if (!b[c]) {
                continue
            }
            a += (b[c].get("id").replace(/\,/g, "\\,") + ",")
        }
        a = a.substr(0, a.length - 1);
        return a
    },
    getPinCriteriaDescription: function(b) {
        var e = b.type;
        var a = b.criteria;
        var d = "";
        if ("folder" === e) {
            d = _AST("playlist", "playlist_folder") + _AST("common", "colon") + " " + Ext.util.Format.htmlEncode(a.path)
        } else {
            if ("playlist" === e) {
                if ("playlist_personal_normal/__SYNO_AUDIO_SHARED_SONGS__" === a.playlist) {
                    d = _AST("playlist", "personal_playlist") + _AST("common", "colon") + " " + _AST("playlist", "shared_songs_playlist")
                } else {
                    if (0 === a.playlist.indexOf("playlist_personal_smart")) {
                        d = _AST("playlist", "personal_smart_playlist") + _AST("common", "colon") + " " + Ext.util.Format.htmlEncode(a.playlist.substring(a.playlist.indexOf("/") + 1))
                    } else {
                        if (0 === a.playlist.indexOf("playlist_shared_smart")) {
                            d = _AST("playlist", "shared_smart_playlist_v2") + _AST("common", "colon") + " " + Ext.util.Format.htmlEncode(a.playlist.substring(a.playlist.indexOf("/") + 1))
                        } else {
                            if (a.path) {
                                d = _AST("playlist", "playlist_folder") + _AST("common", "colon") + " " + Ext.util.Format.htmlEncode(a.path)
                            } else {
                                d = _AST("playlist", "personal_playlist") + _AST("common", "colon") + " " + Ext.util.Format.htmlEncode(a.name)
                            }
                        }
                    }
                }
            } else {
                if ("random_100" === e) {
                    d = _AST("common", "random_playlist")
                } else {
                    if ("recently_added" === e) {
                        d = _AST("common", "class_music_latestalbum")
                    } else {
                        for (var c in a) {
                            if (a.hasOwnProperty(c)) {
                                if ("genre_filter" === c) {
                                    d += _AST("common", "default_genre")
                                } else {
                                    d += _AST("music", "header_" + c)
                                }
                                d += _AST("common", "colon") + " ";
                                if (("genre" === c || "artist" === c || "composer" === c) && "" === a[c]) {
                                    d += _AST("common", "unknown_music_" + c)
                                } else {
                                    d += Ext.util.Format.htmlEncode(a[c])
                                }
                                d += "<br>"
                            }
                        }
                        d = d.substr(0, d.length - 4)
                    }
                }
            }
        }
        return d
    },
    escapeComma: function(a) {
        return a.replace(/\,/g, "\\,")
    },
    sepSongsAndContainers: function(a) {
        var c = {},
            b;
        c.songs = [];
        c.containers = [];
        for (b = 0; b < a.length; b++) {
            if (!a[b]) {
                continue
            }
            if (this.isTrack(a[b])) {
                c.songs.push(a[b])
            } else {
                c.containers.push(a[b])
            }
        }
        return c
    },
    isDisableSortPage: function() {
        if (this.isPlayingQueue() || this.isInPlaylistLayer2() || this.isInAllPlaylist() || this.isInRadio() || this.isInMediaserver() || this.isInRandom100() || this.isInLatestAlbum()) {
            return true
        }
        return false
    },
    getSortInfo: function(g, a) {
        var c = SYNO.SDS.AudioStation.Window.appInstance.getUserSettings(g),
            f = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo(),
            e = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main");
        if ("" === g || !c || !c.sort) {
            var d;
            if ("SYNO.AudioStation.Pin" !== f.params.api) {
                d = e.metadataMapping[f.params.api].field
            } else {
                var b = a ? a.get("type") : "";
                if ("folder" === b) {
                    d = "title"
                } else {
                    d = "name"
                }
            }
            c = {
                sort: {
                    field: d,
                    direction: "ASC"
                }
            }
        }
        return c.sort
    },
    calculateAvgRating: function(a) {
        var b = 0,
            d = 0,
            c = 0;
        Ext.each(a, function(e) {
            b += e.get("song_rating");
            if (0 !== e.get("song_rating")) {
                c++
            }
        });
        if (0 === c) {
            d = 0
        } else {
            d = b / c;
            d = Math.round(d * 2) / 2
        }
        return d
    },
    isInt: function(a) {
        return (0 === (a % 1))
    },
    getRatingClass: function(a) {
        if ("on" === a) {
            return "syno-song-rating-on"
        } else {
            if ("star" === a) {
                return "syno-rating-star"
            } else {
                if ("mouseover" === a) {
                    return "syno-song-rating-mouseover"
                } else {
                    if ("avg_on" === a) {
                        return "syno-avg-rating-on"
                    } else {
                        if ("avg_on_half" === a) {
                            return "syno-avg-half-rating-on"
                        } else {
                            if ("song_container" === a) {
                                return "syno-song-rating-container"
                            } else {
                                if ("avg_container" === a) {
                                    return "syno-avg-rating-container"
                                } else {
                                    if ("cursor_style" === a) {
                                        return "syno-song-rating-cursor-style"
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return null
    },
    getStarHtml: function(h) {
        if ("song_container" !== h && "avg_container" !== h) {
            return
        }
        var e = '<div class="{3}" lockHover="true" lockClick="true" id="{0}">{1}{2}</div>';
        var d = Ext.id();
        var g = '<div class="{0}" star="{1}"></div>';
        var b = "",
            a = "",
            f = 0;
        for (f = 0; f < 5; f++) {
            a = String.format(g, SYNO.SDS.AudioStation.Utils.getRatingClass("star"), f + 1);
            b += a
        }
        var j = '<input type="hidden" name="starValue" value="{0}">';
        var k = String.format(j, 0);
        var c = String.format(e, d, b, k, SYNO.SDS.AudioStation.Utils.getRatingClass(h));
        return c
    },
    applyAvgRatingAndDisplay: function(c, e) {
        if (!c) {
            return
        }
        var d = c.select("input[type=hidden]").first();
        d.set({
            value: e
        });
        var f = Math.ceil(e) - 1;
        var a = c.select("." + SYNO.SDS.AudioStation.Utils.getRatingClass("star"));
        var b = 0;
        for (b = 0; b < 5; b++) {
            a.item(b).removeClass([SYNO.SDS.AudioStation.Utils.getRatingClass("avg_on"), SYNO.SDS.AudioStation.Utils.getRatingClass("avg_on_half")])
        }
        if (0 > f) {
            return
        }
        for (b = 0; b < f; b++) {
            a.item(b).addClass(SYNO.SDS.AudioStation.Utils.getRatingClass("avg_on"))
        }
        if (this.isInt(e)) {
            a.item(f).addClass(SYNO.SDS.AudioStation.Utils.getRatingClass("avg_on"))
        } else {
            a.item(f).addClass(SYNO.SDS.AudioStation.Utils.getRatingClass("avg_on_half"))
        }
    },
    applySongRatingAndDisplay: function(c, e) {
        if (!c) {
            return
        }
        var d = c.select("input[type=hidden]").first();
        d.set({
            value: e
        });
        var a = c.select("." + SYNO.SDS.AudioStation.Utils.getRatingClass("star"));
        var b = 0;
        for (b = 0; b < 5; b++) {
            a.item(b).removeClass([SYNO.SDS.AudioStation.Utils.getRatingClass("mouseover"), SYNO.SDS.AudioStation.Utils.getRatingClass("on")])
        }
        for (b = 0; b < e; b++) {
            a.item(b).addClass(SYNO.SDS.AudioStation.Utils.getRatingClass("on"))
        }
        for (b = e; b < 5; b++) {
            a.item(b).addClass(SYNO.SDS.AudioStation.Utils.getRatingClass("mouseover"))
        }
    },
    showOnlySongRatingOn: function(c) {
        if (!c || ("true" === c.getAttribute("lockHover"))) {
            return
        }
        var d = c.select("input[type=hidden]");
        var e = d.first().getAttribute("value");
        var a = c.select("." + SYNO.SDS.AudioStation.Utils.getRatingClass("star"));
        var b = 0;
        e = (!e || isNaN(e)) ? 0 : e;
        for (b = 0; b < e; b++) {
            a.item(b).addClass(SYNO.SDS.AudioStation.Utils.getRatingClass("on"))
        }
        for (b = e; b < 5; b++) {
            a.item(b).removeClass([SYNO.SDS.AudioStation.Utils.getRatingClass("mouseover"), SYNO.SDS.AudioStation.Utils.getRatingClass("on")])
        }
    },
    showEmptySongRating: function(c) {
        if (!c || ("true" === c.getAttribute("lockHover"))) {
            return
        }
        var d = c.select("input[type=hidden]");
        var e = d.first().getAttribute("value");
        var a = c.select("." + SYNO.SDS.AudioStation.Utils.getRatingClass("star"));
        e = (!e || isNaN(e)) ? 0 : e;
        for (var b = e; b < 5; b++) {
            a.item(b).addClass(SYNO.SDS.AudioStation.Utils.getRatingClass("mouseover"))
        }
    },
    GetDownloadIframe: function(a) {
        var b = Ext.fly("download_iframe");
        if (b) {
            b.removeAllListeners();
            b = b.dom;
            try {
                var d = Ext.isIE || Ext.isModernIE ? b.contentWindow.document : (b.contentDocument || window.frames[b.id].document);
                d.open();
                d.close()
            } catch (c) {
                a.getMsgBox().alert(_AST("playlist", "playlist"), _AST("common", "error_system"));
                Ext.destroy(Ext.get("download_iframe"));
                return null
            }
        } else {
            b = Ext.DomHelper.append(document.body, {
                tag: "iframe",
                id: "download_iframe",
                frameBorder: 0,
                width: 0,
                height: 0,
                css: "display:none;visibility:hidden;height:1px;"
            });
            b.src = Ext.SSL_SECURE_URL
        }
        return b
    },
    replaceDLNameSpecChars: function(a) {
        var b = Ext.isWindows ? (/[\/\\\:\?\><\*\"\|]/g) : (/[\/\\\:]/g);
        return a.replace(b, "-")
    },
    getWebAPIURL: function(a) {
        var b = window.location.pathname.replace(/[^\\\/]*$/, "");
        if (SYNO.SDS.AudioStation.SessionData && Ext.isDefined(SYNO.SDS.AudioStation.SessionData.SharingId) && "cover.cgi" === a) {
            return String.format("{0}webapi/AudioStation/{1}?sharing_id={2}", b, a, SYNO.SDS.AudioStation.SessionData.SharingId)
        }
        return String.format("{0}webapi/AudioStation/{1}", b, a)
    },
    getPlayerCGI: function() {
        if ("__SYNO_WEB_PLAYER__" === SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main").gCurrentSelectPlayer) {
            return this.getWebAPIURL("web_player.cgi")
        }
        return this.getWebAPIURL("remote_player.cgi")
    },
    getPlayerAPI: function() {
        if ("__SYNO_WEB_PLAYER__" === SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main").gCurrentSelectPlayer) {
            return "SYNO.AudioStation.WebPlayer"
        }
        return "SYNO.AudioStation.RemotePlayer"
    },
    getWebAPIParams: function(b) {
        var a;
        b.version = this.webAPIVersion[b.api];
        if (SYNO.SDS.AudioStation.Window) {
            a = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main");
            if (a && a.isPublicSharing()) {
                b.sharing_id = SYNO.SDS.AudioStation.SessionData.SharingId
            }
        }
        return b
    },
    _initWinWrappers: function(a) {
        this._getWindow = function() {
            return SYNO.SDS.AudioStation.Window
        };
        this._getUtils = function() {
            return SYNO.SDS.AudioStation.Utils
        };
        this.baseURL = SYNO.SDS.AudioStation.Window.baseURL
    },
    launchFileStation: function(a) {
        SYNO.SDS.AppLaunch("SYNO.SDS.App.FileStation3.Instance", {
            openfile: a
        })
    },
    getHotKeyMap: function(a, b) {
        if (Ext.isMac) {
            var c = SYNO.SDS.AudioStation.Utils.getCmdCode();
            return [{
                key: c,
                fn: function() {
                    a.cmdKeyDown = true
                },
                scope: a
            }, {
                key: Ext.EventObject.DELETE,
                fn: function() {
                    b.apply(a, ["delete"])
                },
                scope: this
            }, {
                key: Ext.EventObject.A,
                fn: function() {
                    b.apply(a, ["c_a"])
                },
                stopEvent: true,
                scope: a
            }]
        } else {
            return [{
                key: Ext.EventObject.DELETE,
                fn: function() {
                    b.apply(a, ["delete"])
                },
                scope: this
            }, {
                key: Ext.EventObject.A,
                ctrl: true,
                fn: function() {
                    b.apply(a, ["c_a"])
                },
                scope: a
            }]
        }
    },
    getCmdCode: function() {
        var a = 224;
        if (Ext.isWebKit) {
            a = [91, 93]
        } else {
            if (Ext.isOpera) {
                a = 17
            }
        }
        return a
    },
    isPersonalLibraryEnabled: function() {
        if (_S("authType") !== "local" && _S("version") < "3154") {
            return false
        }
        return (SYNO.SDS.AudioStation.SessionData.is_manager || SYNO.SDS.AudioStation.SessionData.enable_personal_library)
    },
    isWindowsTablet: function() {
        var a = navigator.userAgent;
        if (/Windows NT 6.2/i.test(a) && /Touch/i.test(a)) {
            return true
        }
        return false
    },
    testProperty: function(f, d) {
        var e = d.split(".");
        for (var c = 0, a = e.length; c < a; c++) {
            var b = e[c];
            if (f && Ext.isDefined(f[b])) {
                f = f[b]
            } else {
                return false
            }
        }
        return true
    },
    lengthGetInBytes: function(b) {
        var c = 0;
        if (!b || b.length === 0) {
            return 0
        }
        for (var a = 0; a < b.length; a++) {
            if ((b.charCodeAt(a) >= 0) && (b.charCodeAt(a) <= 127)) {
                c += 1
            } else {
                if ((b.charCodeAt(a) >= 128) && (b.charCodeAt(a) <= 2047)) {
                    c += 2
                } else {
                    if ((b.charCodeAt(a) >= 2048) && (b.charCodeAt(a) <= 65535)) {
                        c += 3
                    } else {
                        if ((b.charCodeAt(a) >= 65536) && (b.charCodeAt(a) <= 131071)) {
                            c += 4
                        } else {
                            if ((b.charCodeAt(a) >= 2097152) && (b.charCodeAt(a) <= 67108863)) {
                                c += 5
                            } else {
                                if ((b.charCodeAt(a) >= 67108864) && (b.charCodeAt(a) <= 2147483647)) {
                                    c += 6
                                }
                            }
                        }
                    }
                }
            }
        }
        return c
    },
    sortByFrequency: function(f) {
        var d = {},
            e = [],
            c, b;
        for (b = 0; b < f.length; b++) {
            c = f[b];
            if (c in d) {
                d[c]++
            } else {
                d[c] = 1
            }
        }
        for (c in d) {
            if (d.hasOwnProperty(c)) {
                e.push([c])
            }
        }

        function a(h, g) {
            return d[g] - d[h]
        }
        return e.sort(a)
    },
    filterObjectByKey: function(b, d) {
        var a = {};
        for (var c in b) {
            if (d.indexOf(c) > -1) {
                a[c] = b[c]
            }
        }
        return a
    },
    isValidExtension: function(d, b) {
        var a = 0;
        var c = d.toLowerCase();
        if (!d.length || !b.length) {
            return false
        }
        a = c.lastIndexOf(b);
        if (-1 == a) {
            return false
        }
        if (c.length != (a + b.length)) {
            return false
        }
        return true
    }
};
SYNO.SDS.AudioStation.DelayedTaskItem = function(a, e, d, c, b) {
    this.ID = e;
    this.Data = d;
    this.Task = a;
    this.Func = c;
    this.Scope = b
};
SYNO.SDS.AudioStation.DelayedTaskItem.prototype = {
    ID: null,
    Data: null,
    Task: null,
    Func: null,
    Scope: null,
    delay: function(a) {
        if (this.Task) {
            this.Task.delay(a)
        }
    },
    getID: function() {
        return this.ID
    },
    getData: function() {
        return this.Data
    },
    setData: function(a) {
        this.Data = a
    },
    getScope: function() {
        return this.Scope
    }
};
Ext.namespace("SYNO.SDS.AudioStation.DelayedTaskQueue");
SYNO.SDS.AudioStation.DelayedTaskQueue = {
    delayTime: 1000,
    tasks: [],
    addTask: function(e, d, g, f, c) {
        var b;
        if ("undefined" === typeof(e) || "undefined" === typeof(d) || "undefined" === typeof(g)) {
            return false
        }
        if ("undefined" === typeof(c)) {
            c = this.delayTime
        }
        var a = this.getTaskByID(e);
        if (null === a) {
            b = new Ext.util.DelayedTask(function() {
                this.SendTask(e)
            }, this);
            a = new SYNO.SDS.AudioStation.DelayedTaskItem(b, e, d, g, f)
        } else {
            a.setData(d)
        }
        a.delay(c);
        var h = this.getEmptyIndex();
        this.tasks[h] = a
    },
    getTaskByID: function(b) {
        if (0 === this.tasks.length) {
            return null
        }
        for (var a = 0; a < this.tasks.length; a++) {
            if (this.tasks[a] && this.tasks[a].getID() === b) {
                return this.tasks[a]
            }
        }
        return null
    },
    setTaskDone: function(b) {
        if (0 === this.tasks.length) {
            return false
        }
        for (var a = 0; a < this.tasks.length; a++) {
            if (this.tasks[a] && this.tasks[a].getID() === b) {
                delete this.tasks[a];
                this.tasks[a] = null
            }
        }
        return true
    },
    getEmptyIndex: function() {
        var a;
        if (0 === this.tasks.length) {
            return 0
        }
        for (a = 0; a < this.tasks.length; a++) {
            if (null === this.tasks[a]) {
                break
            }
        }
        return a
    },
    SendTask: function(b) {
        var a = this.getTaskByID(b);
        if (null !== a && null !== a.Func) {
            a.Func.call(a.getScope(), a.getData())
        }
        this.setTaskDone(b)
    }
};
Ext.define("SYNO.SDS.AudioStation.CustomMessageBox", {
    extend: "SYNO.SDS.MessageBoxV5",
    onRender: function() {
        this.callParent(arguments);
        this.addClass("syno-as-dialog syno-as-dialog-small")
    }
});
Ext.define("SYNO.SDS.AudioStation.Utils_.Window.DD", {
    extend: "Ext.Window.DD",
    constructor: function(b, a) {
        this.callParent([b]);
        this.setHandleElId(a)
    }
});
/**
 * @class SYNO.SDS.AudioStation.PlayingQueueDropTarget
 * @extends Ext.dd.DropTarget
 * AudioStation playing queue class
 *
 */
Ext.define("SYNO.SDS.AudioStation.PlayingQueueDropTarget", {
    extend: "Ext.dd.DropTarget",
    ddTarget: null,
    audioAppMain: null,
    copy: false,
    constructor: function(a, c, b) {
        this.ddTarget = a;
        this.audioAppMain = c;
        this.callParent([a.container, b])
    },
    notifyDrop: function(p, n, s) {
        var d = -1,
            g = this.ddTarget,
            c = this.audioAppMain.playingStore,
            l, f, o, h, b, t, k, q = [],
            j = 0,
            m = new Date().getTime(),
            a = this.audioAppMain.getCurrentPlayingIndex(),
            r = this.audioAppMain.getCurrentPlayingRecord();
        if (m < this.dropTargetLastTime + 500) {
            return false
        } else {
            this.dropTargetLastTime = m
        }
        o = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (!this.checkAllowDrop()) {
            p.endDrag();
            return false
        }
        c = (!this.audioAppMain.gIsOnLargePlayingQueue && !this.audioAppMain.gIsOnMiniPlayerMode && SYNO.SDS.AudioStation.Utils.isInPlaylistLayer2()) ? this.audioAppMain.dataStore : this.audioAppMain.playingStore;
        d = g.view.findRowIndex(n.getTarget());
        if (false === d) {
            p.endDrag();
            return false
        }
        f = s.selections;
        if (f) {
            for (l = 0; l < f.length; l++) {
                f[l].index = c.indexOf(f[l])
            }
            f.sort(function(i, e) {
                return i.index - e.index
            })
        }
        b = (f[0].index > d) ? d : f[0].index;
        t = (f[f.length - 1].index < d) ? d : f[f.length - 1].index;
        for (l = 0; l < f.length; l++) {
            if (f[l].index <= d) {
                j++
            }
        }
        if (d !== b) {
            if (d === t) {
                d = d - f.length + 1
            } else {
                d = d - j + 1
            }
        }
        h = SYNO.SDS.AudioStation.Utils.rearrangeStore(f, c, d);
        if (!this.audioAppMain.gIsOnLargePlayingQueue && !this.audioAppMain.gIsOnMiniPlayerMode && SYNO.SDS.AudioStation.Utils.isInPlaylistLayer2()) {
            this.audioAppMain.onPlaylistUpdateRec(b, t, h)
        } else {
            q = SYNO.SDS.AudioStation.Utils.getSongIdList(c.getRange(b, t));
            k = SYNO.SDS.AudioStation.Utils.getUpdatedIndex(q, a, r, b, t);
            this.audioAppMain.onPlayingQueueCommit("updateplaylist", false, q, null, b, t - b + 1, k, h)
        }
        p.endDrag();
        return true
    },
    notifyOver: function(a, c, b) {
        if (this.checkAllowDrop()) {
            return this.dropAllowed
        }
        return this.dropNotAllowed
    },
    checkAllowDrop: function() {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (SYNO.SDS.AudioStation.Utils._PlayingQueue_ID === a.type || this.audioAppMain.gIsOnLargePlayingQueue || this.audioAppMain.gIsOnMiniPlayerMode || (SYNO.SDS.AudioStation.Utils.isInPlaylistLayer2() && SYNO.SDS.AudioStation.Utils.checkPlaylistEditable(a.params.id))) {
            return true
        }
        return false
    }
});
Ext.define("SYNO.SDS.AudioStation.ListPanelDropTarget", {
    extend: "Ext.dd.DropTarget",
    ddTarget: null,
    audioAppMain: null,
    copy: false,
    constructor: function(a, c, b) {
        this.ddTarget = a;
        this.audioAppMain = c;
        this.callParent([a.getEl(), b])
    },
    notifyDrop: function(a, h, f) {
        var i, d, c, g;
        i = this.getOverNodeId(h);
        if (!i || false === this.checkAllowDrop(i, f)) {
            a.endDrag();
            return false
        }
        if (i === SYNO.SDS.AudioStation.Utils._Playlist_ID) {
            this.audioAppMain.showSelectPlaylistDialog(f.selections)
        } else {
            if (i === SYNO.SDS.AudioStation.Utils._PlayingQueue_ID) {
                g = SYNO.SDS.AudioStation.Utils.sepSongsAndContainers(f.selections);
                d = SYNO.SDS.AudioStation.Utils.getSongIdList(g.songs);
                if (SYNO.SDS.AudioStation.Utils.isInSearchAllCate()) {
                    var b = this.audioAppMain.getSearchAllPanelSelection();
                    if ("artist" === b) {
                        c = SYNO.SDS.AudioStation.Utils.getContainerJsonList(g.containers, this.audioAppMain.searchAllArtistStore)
                    } else {
                        if ("album" === b) {
                            c = SYNO.SDS.AudioStation.Utils.getContainerJsonList(g.containers, this.audioAppMain.searchAllAlbumStore)
                        }
                    }
                } else {
                    c = SYNO.SDS.AudioStation.Utils.getContainerJsonList(g.containers, this.audioAppMain.dataStore)
                }
                this.audioAppMain.onPlayingQueueCommit("updateplaylist", false, d, c, -1, 0)
            } else {
                a.endDrag();
                return false
            }
        }
        a.endDrag();
        return true
    },
    notifyOver: function(a, c, b) {
        var d;
        d = this.getOverNodeId(c);
        if (d && this.checkAllowDrop(d, b)) {
            return this.dropAllowed
        }
        return this.dropNotAllowed
    },
    checkAllowDrop: function(d, c) {
        var a = c.selections,
            b;
        if (d === SYNO.SDS.AudioStation.Utils._Playlist_ID) {
            for (b = 0; b < a.length; b++) {
                if (!a[b]) {
                    continue
                }
                if (!SYNO.SDS.AudioStation.Utils.isTrack(a[b])) {
                    return false
                }
            }
            return true
        } else {
            if (d === SYNO.SDS.AudioStation.Utils._PlayingQueue_ID) {
                if (SYNO.SDS.AudioStation.Utils.isPlayingQueue()) {
                    return true
                }
                if (SYNO.SDS.AudioStation.Utils.isInShoutCastCate()) {
                    return false
                }
                if (SYNO.SDS.AudioStation.Utils.isInMediaserver()) {
                    for (b = 0; b < a.length; b++) {
                        if (!a[b]) {
                            continue
                        }
                        if ("remote" !== a[b].get("type")) {
                            return false
                        }
                    }
                }
                return true
            }
        }
        return false
    },
    getOverNodeId: function(c) {
        var a, b, d;
        a = Ext.fly(c.getTarget()).parent("li");
        if (a) {
            b = a.child("div")
        }
        if (b) {
            d = b.getAttribute("ext:tree-node-id")
        }
        return d
    }
});
Ext.define("SYNO.SDS.AudioStation.FocusGridPlugin", {
    extend: "Ext.Component",
    init: function(a) {
        a.mon(a, "click", function(b) {
            if (document.activeElement.id === this.getView().focusEl.id) {
                return
            }
            if (Ext.isGecko) {
                this.getView().focusEl.focus()
            } else {
                this.getView().focusEl.focus.defer(1, this.getView().focusEl)
            }
        }, a);
        a.on("afterrender", function(b) {
            this.getEl().on("keyup", function(d) {
                var c = SYNO.SDS.AudioStation.Utils.getCmdCode();
                if (Ext.isArray(c)) {
                    this.cmdKeyDown = this.cmdKeyDown && (c.indexOf(d.getKey()) === -1)
                } else {
                    this.cmdKeyDown = this.cmdKeyDown && (c !== d.getKey())
                }
            }, this)
        }, a)
    }
});
SYNO.SDS.AudioStation.FocusGridPluginInstance = new SYNO.SDS.AudioStation.FocusGridPlugin();
Ext.preg("audiofocusgridplugin", SYNO.SDS.AudioStation.FocusGridPlugin);
Ext.define("SYNO.SDS.AudioStation.FocusComponentPlugin", {
    extend: "Ext.Component",
    init: function(a) {
        a.mon(a, "afterrender", function(b) {
            this.getEl().on("click", function(d) {
                var c = this.getEl().tabindex;
                if (!c) {
                    this.getEl().set({
                        tabindex: -1
                    })
                }
                if (Ext.isGecko) {
                    this.getEl().focus()
                } else {
                    this.getEl().focus.defer(1, this.getEl())
                }
            }, this);
            this.getEl().on("keyup", function(d) {
                var c = SYNO.SDS.AudioStation.Utils.getCmdCode();
                if (Ext.isArray(c)) {
                    this.cmdKeyDown = this.cmdKeyDown && (c.indexOf(d.getKey()) === -1)
                } else {
                    this.cmdKeyDown = this.cmdKeyDown && (c !== d.getKey())
                }
            }, this)
        }, a)
    }
});
SYNO.SDS.AudioStation.FocusComponentPluginInstance = new SYNO.SDS.AudioStation.FocusComponentPlugin();
Ext.preg("audiofocuscomponentplugin", SYNO.SDS.AudioStation.FocusComponentPlugin);
Ext.define("SYNO.SDS.AudioStation.DataViewDragZone", {
    extend: "Ext.dd.DragZone",
    constructor: function(a, b) {
        this.callParent([a.getEl(), b]);
        this.dataview = a
    },
    getDragData: function(g) {
        var b = this.dataview;
        var c = g.getTarget(b.itemSelector, 10);
        if (!c) {
            return false
        }
        var i = b.indexOf(c);
        if (-1 !== i && !b.isSelected(i) && !g.hasModifier()) {
            b.select(i, false)
        }
        var d = this.dataview.getSelectedRecords();
        var h = document.createElement("div");
        var a = document.createElement("div");
        a.innerHTML = String.format(_AST("playlist", "ddtext_song_selected"), d.length);
        h.appendChild(a);
        var f = {
            from: b,
            ddel: h,
            selections: d
        };
        return f
    }
});
SYNO.SDS.AudioStation.Utils.Base64 = {
    _keyStr: "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789-_=",
    encode: function(c) {
        var a = "";
        var k, h, f, j, g, e, d;
        var b = 0;
        c = SYNO.SDS.AudioStation.Utils.Base64._utf8_encode(c);
        while (b < c.length) {
            k = c.charCodeAt(b++);
            h = c.charCodeAt(b++);
            f = c.charCodeAt(b++);
            j = k >> 2;
            g = ((k & 3) << 4) | (h >> 4);
            e = ((h & 15) << 2) | (f >> 6);
            d = f & 63;
            if (isNaN(h)) {
                e = d = 64
            } else {
                if (isNaN(f)) {
                    d = 64
                }
            }
            a = a + this._keyStr.charAt(j) + this._keyStr.charAt(g) + this._keyStr.charAt(e) + this._keyStr.charAt(d)
        }
        return a
    },
    decode: function(c) {
        var a = "";
        var k, h, f;
        var j, g, e, d;
        var b = 0;
        c = c.replace(/[^A-Za-z0-9\-\_\=]/g, "");
        while (b < c.length) {
            j = this._keyStr.indexOf(c.charAt(b++));
            g = this._keyStr.indexOf(c.charAt(b++));
            e = this._keyStr.indexOf(c.charAt(b++));
            d = this._keyStr.indexOf(c.charAt(b++));
            k = (j << 2) | (g >> 4);
            h = ((g & 15) << 4) | (e >> 2);
            f = ((e & 3) << 6) | d;
            a = a + String.fromCharCode(k);
            if (e != 64) {
                a = a + String.fromCharCode(h)
            }
            if (d != 64) {
                a = a + String.fromCharCode(f)
            }
        }
        a = SYNO.SDS.AudioStation.Utils.Base64._utf8_decode(a);
        return a
    },
    _utf8_encode: function(b) {
        b = b.replace(/\r\n/g, "\n");
        var a = "";
        for (var e = 0; e < b.length; e++) {
            var d = b.charCodeAt(e);
            if (d < 128) {
                a += String.fromCharCode(d)
            } else {
                if ((d > 127) && (d < 2048)) {
                    a += String.fromCharCode((d >> 6) | 192);
                    a += String.fromCharCode((d & 63) | 128)
                } else {
                    a += String.fromCharCode((d >> 12) | 224);
                    a += String.fromCharCode(((d >> 6) & 63) | 128);
                    a += String.fromCharCode((d & 63) | 128)
                }
            }
        }
        return a
    },
    _utf8_decode: function(a) {
        var d = "";
        var f = 0;
        var g = 0,
            e = 0,
            b = 0;
        while (f < a.length) {
            g = a.charCodeAt(f);
            if (g < 128) {
                d += String.fromCharCode(g);
                f++
            } else {
                if ((g > 191) && (g < 224)) {
                    e = a.charCodeAt(f + 1);
                    d += String.fromCharCode(((g & 31) << 6) | (e & 63));
                    f += 2
                } else {
                    e = a.charCodeAt(f + 1);
                    b = a.charCodeAt(f + 2);
                    d += String.fromCharCode(((g & 15) << 12) | ((e & 63) << 6) | (b & 63));
                    f += 3
                }
            }
        }
        return d
    }
};
