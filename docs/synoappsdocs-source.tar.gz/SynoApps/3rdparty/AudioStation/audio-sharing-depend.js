/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function _defineProperty(t, e, i) {
    return e in t ? Object.defineProperty(t, e, {
        value: i,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : t[e] = i, t
}

function _typeof(t) {
    return (_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(t) {
        return typeof t
    } : function(t) {
        return t && "function" == typeof Symbol && t.constructor === Symbol && t !== Symbol.prototype ? "symbol" : typeof t
    })(t)
}

function getModalWindow(t) {
    if (t) {
        if ("ModalWindow" === t.$options.name || "MessageBoxWindow" === t.$options.name || "WizardWindow" === t.$options.name) return t;
        var e = !0,
            i = !1,
            s = void 0;
        try {
            for (var n, o = t.$children[Symbol.iterator](); !(e = (n = o.next()).done); e = !0) {
                var a = n.value,
                    r = getModalWindow(a);
                if (r) return r
            }
        } catch (t) {
            i = !0, s = t
        } finally {
            try {
                e || null == o.return || o.return()
            } finally {
                if (i) throw s
            }
        }
    }
}

function inJsdom() {
    return navigator.userAgent.includes("Node.js") || navigator.userAgent.includes("jsdom")
}
Ext.BLANK_IMAGE_URL = "scripts/ext-3/resources/images/default/s.gif", Ext.data.Connection.prototype.timeout = 12e4, Ext.form.BasicForm.prototype.timeout = 120, Ext.QuickTip.prototype.maxWidth = 500, Ext.override(Ext.QuickTip, {
    hide: function() {
        var t = function() {
            delete this.activeTarget, Ext.QuickTip.superclass.hide.call(this), this.getEl().setOpacity(1)
        };
        return this.getEl().animate({
            opacity: {
                from: 1,
                to: 0
            }
        }, .3, t.createDelegate(this))
    }
}), Ext.override(Ext.Element, {
    addClassOnHover: function(t) {
        var e = this;
        "ontouchstart" in window || window.navigator.msPointerEnabled && window.navigator.msMaxTouchPoints > 0 ? Ext.getDoc().on("click", function(i) {
            i.within(e) ? e.addClass(t) : e.removeClass(t)
        }, e) : e.addClassOnOver(t)
    }
}), Ext.override(Ext.Component, {
    labelSeparator: _T("common", "colon"),
    getTaskRunner: function() {
        return this.taskRunner || (this.taskRunner = new SYNO.SDS.TaskRunner, this.addManagedComponent(this.taskRunner)), this.taskRunner
    },
    addTask: function(t) {
        return this.getTaskRunner().createTask(t)
    },
    addAjaxTask: function(t) {
        return this.getTaskRunner().createAjaxTask(t)
    },
    addWebAPITask: function(t) {
        return this.getTaskRunner().createWebAPITask(t)
    },
    getTask: function(t) {
        return this.taskRunner ? this.taskRunner.getTask(t) : null
    },
    removeTask: function(t) {
        var e = this.getTask(t);
        return e && e.remove(), e
    },
    addManagedComponent: function(t) {
        return this.components = this.components || [], this.components.push(t), t
    },
    removeManagedComponent: function(t) {
        return this.components = this.components || [], this.components.remove(t), t
    },
    beforeDestroy: function() {
        this.taskRunner = null, this.components = this.components || [];
        for (var t = 0; t < this.components.length; ++t) try {
            this.components[t] instanceof Vue ? this.components[t].$destroy() : this.components[t].destroy()
        } catch (e) {
            if (Ext.isDefined(SYNO.SDS.JSDebug)) throw SYNO.Debug.error(this.id, "sub-components[" + t + "] destroy failed.", this.components[t]), e
        }
        delete this.components
    },
    findWindow: function() {
        var t = this;
        if (t instanceof SYNO.SDS.BaseWindow) return t;
        for (; Ext.isObject(t.ownerCt); t = t.ownerCt);
        return t instanceof SYNO.SDS.BaseWindow ? t : void 0
    },
    findAppWindow: function() {
        var t = function(t) {
                return t && t._isVue && "AppWindow" === t.$options.name
            },
            e = this,
            i = Ext.getClassByName("SYNO.SDS.AppWindow");
        if (!Ext.isEmpty(i)) {
            if (e instanceof i || t(e)) return e;
            if (e._appWindow instanceof i || t(e._appWindow)) return e._appWindow;
            for (; Ext.isObject(e.ownerCt); e = e.ownerCt);
            if (e instanceof i || t(e._appWindow)) return this._appWindow = e, e;
            if (Ext.isObject(e)) {
                for (; Ext.isObject(e.owner || e.$options && e.$options.owner); e = e._isVue ? e.$options.owner : e.owner);
                return e instanceof i || t(e) ? (this._appWindow = e, e) : e.module && e.module.appWin && e.module.appWin instanceof i ? (this._appWindow = e.module.appWin, e.module.appWin) : void 0
            }
        }
    },
    getDsmVersion: function() {
        var t = this.findAppWindow();
        return t ? t.getOpenConfig("dsm_version") : null
    },
    getDsmHttpPort: function() {
        var t, e = this.findAppWindow();
        return e && e.hasOpenConfig("cms_ds_data") && (t = e.getOpenConfig("cms_ds_data").http_port), t
    },
    getDsmHost: function() {
        var t, e = this.findAppWindow();
        return e && e.hasOpenConfig("cms_ds_data") && (t = e.getOpenConfig("cms_ds_data").host), t
    },
    getBaseURL: function(t, e, i) {
        return t.appWindow = this.findAppWindow(), SYNO.API.GetBaseURL(t, e, i)
    },
    sendWebAPI: function(t) {
        return t.appWindow = this.findAppWindow(), SYNO.API.Request(t)
    },
    sendWebAPIPromise: function(t) {
        return new Promise(function(e, i) {
            t.callback = function(t, s, n, o) {
                t ? e(s) : i(s)
            }, this.sendWebAPI(t)
        }.bind(this))
    },
    pollReg: function(t) {
        return t.appWindow = this.findAppWindow(), SYNO.API.Request.Polling.Register(t)
    },
    pollUnreg: function(t) {
        return SYNO.API.Request.Polling.Unregister(t)
    },
    pollList: function(t) {
        return t.appWindow = this.findAppWindow(), SYNO.API.Request.Polling.List(t)
    },
    downloadWebAPI: function(t) {
        return t.appWindow = this.findAppWindow(), SYNO.SDS.Utils.IFrame.requestWebAPI(t)
    },
    IsAllowRelay: function() {
        var t = this.findAppWindow();
        return !!Ext.isObject(t) && (SYNO.SDS.Utils.CMS.IsAllowRelay && SYNO.SDS.Utils.CMS.IsAllowRelay(t))
    },
    _S: function(t) {
        var e = this.findAppWindow();
        return SYNO.API.Info.GetSession(e, t)
    },
    _D: function(t, e) {
        var i = this.findAppWindow();
        return SYNO.API.Info.GetDefine(i, t, e)
    },
    getKnownAPI: function(t) {
        var e = this.findAppWindow();
        return SYNO.API.Info.GetKnownAPI(e, t)
    },
    IsKnownAPI: function(t, e) {
        var i = SYNO.API.Info.GetKnownAPI(this.findAppWindow(), t);
        return !!Ext.isObject(i) && !(e < i.minVersion || i.maxVersion < e)
    }
}), Ext.override(Ext.grid.GridView, {
    onLayout: function() {
        var t = this.el.select(".x-grid3-scroller", this),
            e = t.elements[0];
        e.clientWidth === e.offsetWidth ? this.scrollOffset = 2 : this.scrollOffset = void 0, this.fitColumns(!1)
    }
}), Ext.override(Ext.data.Record, {
    set: function(t, e) {
        var i, s = Ext.isPrimitive(e) ? String : Ext.encode;
        if (s(this.data[t]) != s(e)) {
            if (this.dirty = !0, this.modified || (this.modified = {}), t in this.modified && this.modified[t] === e) {
                this.dirty = !1, delete this.modified[t];
                for (i in this.modified)
                    if (this.modified.hasOwnProperty(i)) {
                        this.dirty = !0;
                        break
                    }
            } else t in this.modified || (this.modified[t] = this.data[t]);
            this.data[t] = e, this.editing || this.afterEdit()
        }
    }
}), Ext.override(Ext.data.Store, {
    afterEdit: function(t) {
        var e = this.modified.indexOf(t);
        t.dirty && -1 == e ? this.modified.push(t) : t.dirty || -1 == e || this.modified.splice(e, 1), this.fireEvent("update", this, t, Ext.data.Record.EDIT)
    }
}), Ext.Element.addMethods(Ext.Fx), Ext.override(Ext.dd.DragSource, {
    validateTarget: function(t, e, i) {
        return !(i !== e.getTarget().id && !e.within(i)) || (this.getProxy().setStatus(this.dropNotAllowed), !1)
    },
    beforeDragEnter: function(t, e, i) {
        return this.validateTarget(t, e, i)
    },
    beforeDragOver: function(t, e, i) {
        var s = this.validateTarget(t, e, i);
        return this.proxy && this.proxy.setStatus(s ? this.dropAllowed : this.dropNotAllowed), s
    },
    beforeDragOut: function(t, e, i) {
        return this.validateTarget(t, e, i)
    },
    beforeDragDrop: function(t, e, i) {
        return !!this.validateTarget(t, e, i) || (this.onInvalidDrop(t, e, i), !1)
    }
}), Ext.override(Ext.form.CompositeField, {
    combineErrors: !1
}), Ext.isIE && (Ext.menu.BaseItem.prototype.clickHideDelay = -1), Ext.override(Ext.Window, {
    onRender: function(t, e) {
        Ext.Window.superclass.onRender.call(this, t, e), this.plain && this.el.addClass("x-window-plain"), this.focusEl = this.el.createChild({
            tag: "div",
            cls: "x-dlg-focus",
            tabIndex: "0",
            role: this.ariaRole || "dialog",
            "aria-label": this.title
        }, this.el.first()), this.focusEl.swallowEvent("click", !0), this.focusEl.addKeyListener(Ext.EventObject.TAB, this.onFirstTab, this), this.lastEl = this.el.createChild({
            tag: "div",
            cls: "x-dlg-focus",
            tabIndex: 0,
            role: "article",
            html: _T("desktop", "window_last_hint")
        }), this.lastEl.addKeyListener(Ext.EventObject.TAB, this.onLastTab, this), this.proxy = this.el.createProxy("x-window-proxy"), this.proxy.enableDisplayMode("block"), this.modal && (this.maskEl = this.container.createChild({
            cls: "ext-el-mask"
        }, this.el.dom), this.maskEl.enableDisplayMode("block"), this.maskEl.hide(), this.mon(this.maskEl, "click", this.focus, this)), this.maximizable && this.mon(this.header, "dblclick", this.toggleMaximize, this), this.frame && this.header && (this.tl = this.header.dom.parentNode.parentNode.parentNode)
    },
    onLastTab: function(t, e) {
        e.shiftKey || (e.preventDefault(), this.focusEl.focus())
    },
    onFirstTab: function(t, e) {
        if (e.shiftKey) e.preventDefault(), this.lastEl.focus();
        else if (Ext.isFunction(this.findTopWin)) {
            var i = this.findTopWin();
            i !== this && (e.preventDefault(), i.focus())
        }
    },
    beforeShow: function() {
        if (delete this.el.lastXY, delete this.el.lastLT, void 0 === this.x || void 0 === this.y) {
            var t = this.el.getAlignToXY(this.container, "c-c"),
                e = this.el.translatePoints(t[0], t[1]);
            this.x = void 0 === this.x ? e.left : this.x, this.y = void 0 === this.y ? e.top : this.y
        }
        this.el.setLeftTop(this.x, this.y), this.expandOnShow && this.expand(!1), this.modal && (Ext.getBody().addClass("x-body-masked"), this.maskEl.setSize(Ext.lib.Dom.getViewWidth(!0), Ext.lib.Dom.getViewHeight(!0)), this.maskEl.show())
    },
    onWindowResize: function() {
        this.maximized && this.fitContainer(), this.modal && (this.maskEl.setSize("100%", "100%"), this.maskEl.setSize(Ext.lib.Dom.getViewWidth(!0), Ext.lib.Dom.getViewHeight(!0))), this.doConstrain()
    },
    setZIndex: function(t) {
        this.modal && this.maskEl.setStyle("z-index", t), this.el.setZIndex(++t), t += 5, this.resizer && this.resizer.proxy.setStyle("z-index", ++t), this.lastZIndex = t
    },
    beforeDestroy: function() {
        this.rendered && (this.hide(), this.clearAnchor(), Ext.destroy(this.focusEl, this.resizer, this.dd, this.proxy, this.maskEl)), Ext.Window.superclass.beforeDestroy.call(this)
    },
    hide: function(t, e, i) {
        return this.hidden || !1 === this.fireEvent("beforehide", this) ? this : (e && this.on("hide", e, i, {
            single: !0
        }), this.hidden = !0, void 0 !== t && this.setAnimateTarget(t), this.modal && (this.maskEl.hide(), Ext.getBody().removeClass("x-body-masked")), this.animateTarget ? this.animHide() : (this.el.hide(), this.afterHide()), this)
    },
    getFrameHeight: function() {
        var t = this.el.getFrameWidth("tb") + this.bwrap.getFrameWidth("tb");
        return t += (this.tbar ? this.tbar.getHeight() : 0) + (this.bbar ? this.bbar.getHeight() : 0), this.frame ? t += (this.tl || this.el.dom.firstChild).offsetHeight + this.ft.dom.offsetHeight + this.mc.getFrameWidth("tb") : t += (this.header ? this.header.getHeight() : 0) + (this.footer ? this.footer.getHeight() : 0), t
    },
    toFront: function(t) {
        this.manager.bringToFront(this) && (this.focusLeave = !1, t && t.getTarget().focus ? (t.getTarget().focus(), document.activeElement !== t.getTarget() && this.focus()) : this.focus())
    }
}), Ext.override(Ext.grid.RowSelectionModel, {
    silentMode: !1,
    onRefresh: function() {
        var t, e, i = this.grid.store,
            s = this.getSelections(),
            n = 0,
            o = s.length;
        for (this.silent = this.silentMode && !0, this.clearSelections(!0); n < o; n++) e = s[n], -1 != (t = i.indexOfId(e.id)) && this.selectRow(t, !0);
        s.length != this.selections.getCount() && this.fireEvent("selectionchange", this), this.silent = !1
    }
}), Ext.override(Ext.grid.GridPanel, {
    getValues: function() {
        var t = [],
            e = this.getStore();
        return Ext.isObject(e) ? (e.each(function(e, i, s) {
            t.push(Ext.apply({}, e.data))
        }, this), t) : t
    },
    setValues: function(t) {
        var e = this.getStore(),
            i = [];
        if (!Ext.isObject(e) || !Ext.isArray(t)) return !1;
        e.removeAll(), Ext.each(t, function(t) {
            i.push(new Ext.data.Record(t))
        }, this), e.add(i)
    }
}), Ext.override(Ext.grid.GridView.ColumnDragZone, {
    getDragData: function(t) {
        var e = Ext.lib.Event.getTarget(t),
            i = this.view.findHeaderCell(e);
        return !!i && {
            ddel: Ext.fly(i).child("div.x-grid3-hd-inner", !0),
            header: i
        }
    }
}), Ext.override(Ext.grid.HeaderDropZone, {
    positionIndicator: function(t, e, i) {
        var s, n, o = Ext.lib.Event.getPageX(i),
            a = Ext.lib.Dom.getRegion(Ext.fly(e).child("div.x-grid3-hd-inner", !0)),
            r = a.top + this.proxyOffsets[1];
        return a.right - o <= (a.right - a.left) / 2 ? (s = a.right + this.view.borderWidth, n = "after") : (s = a.left, n = "before"), !this.grid.colModel.isFixed(this.view.getCellIndex(e)) && (s += this.proxyOffsets[0], this.proxyTop.setLeftTop(s, r), this.proxyTop.show(), this.bottomOffset || (this.bottomOffset = this.view.mainHd.getHeight()), this.proxyBottom.setLeftTop(s, r + this.proxyTop.dom.offsetHeight + this.bottomOffset), this.proxyBottom.show(), n)
    },
    onNodeDrop: function(t, e, i, s) {
        var n = s.header;
        if (n != t) {
            var o = this.grid.colModel,
                a = Ext.lib.Event.getPageX(i),
                r = Ext.lib.Dom.getRegion(Ext.fly(t).child("div.x-grid3-hd-inner", !0)),
                l = r.right - a <= (r.right - r.left) / 2 ? "after" : "before",
                h = this.view.getCellIndex(n),
                d = this.view.getCellIndex(t);
            return "after" == l && d++, h < d && d--, o.moveColumn(h, d), !0
        }
        return !1
    }
}), Ext.override(SYNO.ux.ModuleList, {
    getLocalizedString: function(t) {
        return SYNO.SDS.UIString.GetLocalizedString(t)
    }
}), Ext.override(SYNO.ux.FieldSet, {
    stateful: !0,
    stateEvents: ["expand", "collapse"],
    getState: function() {
        return {
            collapsed: this.collapsed
        }
    },
    saveState: function() {
        var t = this.getState();
        this.setUserCollapseState(t.collapsed)
    },
    getUserCollapseState: function() {
        var t = this.getStateId(),
            e = this.findAppWindow();
        if (e && e.appInstance && t) {
            var i = e.appInstance.getUserSettings("fieldset_collapse_status") || {};
            return Ext.isBoolean(i[t]) ? i[t] : this.collapsed
        }
        return this.collapsed
    },
    setUserCollapseState: function(t) {
        var e = this.getStateId(),
            i = this.findAppWindow();
        if (i && i.appInstance && e) {
            var s = i.appInstance.getUserSettings("fieldset_collapse_status") || {};
            s[e] = t, i.appInstance.setUserSettings("fieldset_collapse_status", s)
        }
    },
    updateUserCollapseState: function() {
        var t = this.getUserCollapseState(),
            e = {
                collapsed: t
            };
        this.applyState(e)
    }
});
var _urlAppend = Ext.urlAppend;
Ext.urlAppend = function(t, e, i) {
    var s = Ext.urlDecode(e);
    return i = void 0 === i || i, i && -1 === t.indexOf("SynoToken") && !Ext.isEmpty(_S("SynoToken")) && (s.SynoToken = decodeURIComponent(_S("SynoToken"))), _urlAppend(t, Ext.urlEncode(s))
}, Ext.ns("SYNO.SDS"), Ext.Ajax.on("beforerequest", function(t, e) {
    !0 !== e.updateSynoToken && Ext.isEmpty(e.skipSynoToken) && !Ext.isEmpty(_S("SynoToken")) && (Ext.isEmpty(e.headers) && (e.headers = {}), void 0 === e.headers["X-SYNO-TOKEN"] && (e.headers["X-SYNO-TOKEN"] = _S("SynoToken")))
}), Ext.util.Observable.observeClass(Ext.form.BasicForm), Ext.form.BasicForm.on("beforeaction", function(t, e) {
    t.url && (t.url = Ext.urlAppend(t.url))
}), Ext.util.Observable.observeClass(Ext.data.Connection), Ext.data.Connection.on("beforerequest", function(t, e) {
    Ext.isEmpty(e.skipSynoToken) && !Ext.isEmpty(_S("SynoToken")) && (Ext.isEmpty(e.headers) && (e.headers = {}), e.headers["X-SYNO-TOKEN"] = _S("SynoToken"))
}), Ext.define("Ext.data.JsonP", {
    singleton: !0,
    requestCount: 0,
    requests: {},
    timeout: 3e4,
    disableCaching: !0,
    disableCachingParam: "_dc",
    callbackKey: "callback",
    request: function(t) {
        t = Ext.apply({}, t);
        var e, i, s = this,
            n = Ext.isDefined(t.disableCaching) ? t.disableCaching : s.disableCaching,
            o = t.disableCachingParam || s.disableCachingParam,
            a = ++s.requestCount,
            r = t.callbackName || "callback" + a,
            l = t.callbackKey || s.callbackKey,
            h = Ext.isDefined(t.timeout) ? t.timeout : s.timeout,
            d = Ext.apply({}, t.params),
            c = t.url;
        return n && !d[o] && (d[o] = (new Date).getTime()), t.params = d, d[l] = "Ext.data.JsonP." + r, i = t.iframeUrl ? s.createIframe(c, d, t) : s.createScript(c, d, t), s.requests[a] = e = {
            url: c,
            params: d,
            script: i,
            id: a,
            scope: t.scope,
            success: t.success,
            failure: t.failure,
            callback: t.callback,
            callbackKey: l,
            callbackName: r
        }, h > 0 && (e.timeout = setTimeout(Ext.createDelegate(s.handleTimeout, s, [e]), h)), s.setupErrorHandling(e), s[r] = Ext.createDelegate(s.handleResponse, s, [e], !0), s.loadScript(e), e
    },
    abort: function(t) {
        var e, i = this,
            s = i.requests;
        if (t) t.id || (t = s[t]), i.handleAbort(t);
        else
            for (e in s) s.hasOwnProperty(e) && i.abort(s[e])
    },
    setupErrorHandling: function(t) {
        t.script.onerror = Ext.createDelegate(this.handleError, this, [t])
    },
    handleAbort: function(t) {
        t.errorType = "abort", this.handleResponse(null, t)
    },
    handleError: function(t) {
        t.errorType = "error", this.handleResponse(null, t)
    },
    cleanupErrorHandling: function(t) {
        t.script.onerror = null
    },
    handleTimeout: function(t) {
        t.errorType = "timeout", this.handleResponse(null, t)
    },
    handleResponse: function(t, e) {
        var i = !0;
        e.timeout && clearTimeout(e.timeout), delete this[e.callbackName], delete this.requests[e.id], this.cleanupErrorHandling(e), Ext.fly(e.script).remove(), e.errorType ? (i = !1, Ext.callback(e.failure, e.scope, [e.errorType])) : Ext.callback(e.success, e.scope, [t]), Ext.callback(e.callback, e.scope, [i, t, e.errorType])
    },
    createScript: function(t, e, i) {
        var s = document.createElement("script");
        return s.setAttribute("src", Ext.urlAppend(t, Ext.urlEncode(e))), s.setAttribute("async", !0), s.setAttribute("type", "text/javascript"), s
    },
    createIframe: function(t, e, i) {
        var s, n = Ext.urlAppend(t, Ext.urlEncode(e), !1);
        if (void 0 === i.iframeUrl) return void SYNO.Debug("no iframe url");
        var o = i.iframeUrl;
        return o += "&url=" + encodeURIComponent(n), o = Ext.urlAppend(o, "", !0), s = document.createElement("iframe"), s.setAttribute("src", o), s.setAttribute("style", "visibility: hidden"), s
    },
    loadScript: function(t) {
        Ext.get(document.getElementsByTagName("head")[0]).appendChild(t.script)
    }
}), Ext.override(SYNO.ux.Button, {
    getUXMenu: function(t) {
        if (!Ext.menu.MenuMgr.getMenuList) return Ext.menu.MenuMgr.get(t);
        var e = Ext.menu.MenuMgr.getMenuList();
        return "string" == typeof t ? e ? e[t] : null : t.events ? t : "number" == typeof t.length ? new SYNO.ux.Menu({
            items: t
        }) : Ext.create(t, "syno_menu")
    },
    initComponent: function() {
        this.menu && (Ext.isArray(this.menu) && (this.menu = {
            items: this.menu
        }), Ext.isObject(this.menu) && (this.menu.ownerCt = this), this.menu = this.getUXMenu(this.menu), this.menu.ownerCt = void 0), SYNO.ux.Button.superclass.initComponent.call(this)
    }
}), Ext.override(SYNO.ux.ComboBox, {
    afterRender: function() {
        SYNO.ux.ComboBox.superclass.afterRender.call(this), this.mon(this, "expand", this.onListExpand, this)
    },
    onDestroy: function() {
        this.mun(this, "expand", this.onListExpand, this), SYNO.ux.ComboBox.superclass.onDestroy.call(this)
    },
    onListExpand: function() {
        if (SYNO.SDS.Desktop) {
            var t = SYNO.SDS.UIFeatures.isFullScreenMode(),
                e = SYNO.SDS.Desktop.getEl();
            t && this.list.parent() === Ext.getBody() ? e.appendChild(this.list) : t || this.list.parent() !== e || Ext.getBody().appendChild(this.list)
        }
    }
}), Ext.override(SYNO.ux.DateField, {
    onDestroy: function() {
        this.menu && this.mun(this.menu, "show", this.onMenuShow, this), this.callParent(arguments)
    },
    onMenuShow: function() {
        if (SYNO.SDS.Desktop) {
            var t = SYNO.SDS.UIFeatures.isFullScreenMode(),
                e = SYNO.SDS.Desktop.getEl(),
                i = this.menu.el;
            t && i.parent() === Ext.getBody() ? e.appendChild(i) : t || i.parent() !== e || Ext.getBody().appendChild(i)
        }
    }
}), Ext.override(SYNO.ux.DateTimeField, {
    initComponent: function() {
        Ext.ux.form.DateTimeField.superclass.initComponent.call(this);
        var t = this.initialConfig,
            e = SYNO.SDS.DateTimeUtils;
        this.dateFormat = void 0 === t.dateFormat ? e.GetDateFormat() : t.dateFormat, this.timeFormat = void 0 === t.timeFormat ? e.GetTimeFormat() : t.timeFormat, this.format = this.isAllDay ? this.dateFormat : this.dateFormat + " " + this.timeFormat, this.afterMethod("afterRender", function() {
            this.getEl().applyStyles("top:0")
        })
    }
}), Ext.override(SYNO.ux.Menu, {
    onMenuShow: function() {
        if (SYNO.SDS.Desktop) {
            var t = SYNO.SDS.UIFeatures.isFullScreenMode(),
                e = SYNO.SDS.Desktop.getEl();
            t && this.el.parent() === Ext.getBody() ? e.appendChild(this.el) : t || this.el.parent() !== e || Ext.getBody().appendChild(this.el), this.resetWidthForFlexcroll()
        }
    }
}), Ext.override(SYNO.ux.DatePicker, {
    getWeekdayHeader: function(t) {
        var e = this.dayNames,
            i = "ger" === _S("lang") ? 2 : 1;
        return e[t].substr(0, i)
    }
}), Ext.override(Ext.form.Radio, {
    setValue: function(t) {
        if ("boolean" == typeof t) Ext.form.Radio.superclass.setValue.call(this, t);
        else if (this.rendered) {
            var e = this.getCheckEl().select("input[name=" + this.el.dom.name + "]");
            e.each(function(e) {
                var i = Ext.getCmp(e.dom.id);
                i.setValue(t === e.dom.value), i.fireEvent("check", i, i.checked)
            }, this)
        }
        return this
    },
    onClick: function() {
        this.el.dom.checked != this.checked && this.setValue(this.el.dom.value)
    }
}), Ext.namespace("SYNO.SDS.BaseWindow"), Ext.define("SYNO.SDS.AbstractWindow", {
    extend: "Ext.Window",
    closeDisabled: !1,
    toolTarget: "toolCt",
    toolCtCls: "x-window-toolCt",
    toolTemplate: new Ext.XTemplate('<div class="x-tool x-tool-{id}" role="option" aria-label="{text}">&#160;</div>'),
    realHeight: void 0,
    realWidth: void 0,
    constructor: function(t) {
        var e = Ext.urlDecode(location.search.substr(1));
        this.enableAlertHeight = e.alertHeight;
        var i = SYNO.SDS.Desktop ? SYNO.SDS.Desktop.getEl() : Ext.getBody();
        t = Ext.apply({
            autoFitDesktopHeight: !1,
            maximizable: !0,
            minimizable: !0,
            closable: !0,
            width: 300,
            height: 300,
            constrain: !1,
            constrainHeader: !0,
            modal: !1,
            renderTo: i,
            manager: SYNO.SDS.WindowMgr
        }, t), SYNO.SDS.AbstractWindow.superclass.constructor.call(this, t), (this.constrain || this.constrainHeader) && this.resizer && (this.resizer.constrainTo = this.container), this.mon(this, "titlechange", this.onWindowTitleChanged, this)
    },
    initEvents: function() {
        if (SYNO.SDS.AbstractWindow.superclass.initEvents.apply(this, arguments), this.resizer) {
            var t = Ext.Resizable.positions;
            for (var e in t) this.resizer[t[e]] && this.mon(this.resizer[t[e]].el, "mousedown", this.toFront, this)
        }
        this.mon(this, "beforeclose", this._onClose, this), this.mon(this, "beforemaximize", this._onBeforeMaximize, this), this.mon(this, "maximize", this._onMaximize, this), this.mon(this, "minimize", this._onMinimize, this), this.mon(this, "restore", this._onRestore, this), this.mon(this, "activate", this._onActivate, this), this.mon(this, "deactivate", this._onDeactivate, this), this.header && this.mon(this.header, "contextmenu", this.onHeaderContextMenu, this)
    },
    _onClose: function() {
        return !this.closeDisabled && this.onClose.apply(this, arguments)
    },
    _onMaximize: function() {
        return this.onMaximize.apply(this, arguments)
    },
    _onBeforeMaximize: function() {
        return this.onBeforeMaximize.apply(this, arguments)
    },
    _onMinimize: function() {
        return this.onMinimize.apply(this, arguments)
    },
    _onRestore: function() {
        return this.onRestore.apply(this, arguments)
    },
    _onActivate: function() {
        return this.onActivate.apply(this, arguments)
    },
    _onDeactivate: function() {
        return this.onDeactivate.apply(this, arguments)
    },
    _onDragWindow: function(t) {
        SYNO.SDS.TaskBar
    },
    _endDragWindow: function(t, e) {
        SYNO.SDS.TaskBar && SYNO.SDS.TaskBar.toggleCollideOverlay(!1)
    },
    onClose: Ext.emptyFn,
    onMaximize: Ext.emptyFn,
    onBeforeMaximize: Ext.emptyFn,
    onMinimize: Ext.emptyFn,
    onRestore: Ext.emptyFn,
    onActivate: Ext.emptyFn,
    onDeactivate: Ext.emptyFn,
    onHeaderContextMenu: function(t) {
        t.preventDefault()
    },
    onShow: function() {
        this.removeClass("syno-window-hide"), delete this.hideForMinimize, this.enableAlertHeight && this.isVisible() && this.getHeight() > 580 && window.alert(String.format("Height: {0}px, Plz contact your PM to adjust UI.", this.getHeight())), this.tryConstrainHeight()
    },
    doConstrain: function() {
        var t, e;
        this.constrainHeader && (t = this.getSize(), e = this.el.getConstrainToXY(this.container, !0, void 0), e && (e[0] + t.width > this.container.getWidth() && (e[0] = this.container.getWidth() - t.width), this.setPosition(e[0], e[1])), this.tryConstrainHeight())
    },
    tryConstrainHeight: function() {
        if (this.realHeight = this.getHeight(), this.realWidth = this.getWidth(), !0 !== this.isWizard) {
            var t = Ext.getBody().getHeight();
            t < this.minHeight && (t = this.minHeight), this.constrainHeight(t)
        }
    },
    constrainHeight: function(t, e) {
        (this.isVisible() || Ext.isDefined(e)) && this.realHeight > t && (this.setHeight(t), this.heightConstrained = !0)
    },
    disableCloseButton: function() {
        var t = this.toolCt.child(".x-tool.x-tool-close");
        this.closeDisabled = !0, t && t.addClass("disabled")
    },
    enableCloseButton: function() {
        var t = this.toolCt.child(".x-tool.x-tool-close");
        this.closeDisabled = !1, t && t.removeClass("disabled")
    },
    _onCloseAction: function() {
        if (this.closeDisabled) return !1;
        this[this.closeAction].apply(this, arguments)
    },
    beforeDestroy: function() {
        this.onBeforeDestroy(), SYNO.SDS.AbstractWindow.superclass.beforeDestroy.apply(this, arguments)
    },
    setIcon: function(t) {
        this.header && this.header.setStyle("background-image", t ? "url(" + t + ")" : "")
    },
    onBeforeDestroy: function() {
        this.appInstance && this.appInstance.removeInstance(this)
    },
    open: function() {
        return this.opened ? this.onRequest.apply(this, arguments) : (this.opened = !0, this.onOpen.apply(this, arguments))
    },
    onOpen: function() {
        this.minimized ? this.el.hide() : this.show()
    },
    onRequest: function() {
        if (!this.isVisible()) return void this.show();
        this.toFront()
    },
    onWindowTitleChanged: function(t, e) {
        this.rendered && this.focusEl instanceof Ext.Element && this.focusEl.set({
            "aria-label": Ext.util.Format.stripTags(e)
        })
    },
    getSizeAndPosition: function() {
        var t, e = {};
        return this.maximized || this.hidden ? (this.draggable && this.restorePos ? (e.x = this.restorePos[0], e.y = this.restorePos[1]) : (e.x = this.x, e.y = this.y), this.resizable && (this.restoreSize ? (e.width = this.restoreSize.width, e.height = this.restoreSize.height) : (e.width = this.width, e.height = this.height))) : (t = this.el.origXY || this.getPosition(!1), e.pageX = t[0], e.pageY = t[1], this.resizable && (e.width = this.getWidth(), e.height = this.getHeight())), e
    },
    setResizable: function(t) {
        this.el[t ? "removeClass" : "addClass"]("no-resize")
    },
    getConstrainSize: function() {
        var t = this.getSize();
        return t.width < this.minWidth && (t.width = this.minWidth), t.height < this.minHeight && (t.height = this.minHeight), t
    },
    maximize: function() {
        return this.maximized || (this.fireEvent("beforemaximize", this), this.expand(!1), this.restoreSize = this.getConstrainSize(), this.restorePos = this.getPosition(!0), this.maximizable && (this.tools.maximize.hide(), this.tools.restore.show()), this.maximized = !0, this.el.disableShadow(), this.dd && this.dd.lock(), this.collapsible && this.tools.toggle.hide(), this.el.addClass("x-window-maximized"), this.container.addClass("x-window-maximized-ct"), SYNO.SDS.TaskBar && this.setPosition(0, this.isFullScreen ? 0 : SYNO.SDS.TaskBar.height()), this.fitContainer(), this.fireEvent("maximize", this)), this
    },
    fitContainer: function() {
        var t = this.container.getViewSize(!1);
        SYNO.SDS.TaskBar && !this.isFullScreen ? this.setSize(t.width, t.height - SYNO.SDS.TaskBar.height()) : this.setSize(t.width, t.height)
    },
    setTitle: function(t, e, i) {
        return this.titleEncoded = i, this.title = t, !1 !== i && (t = Ext.util.Format.htmlEncode(t)), this.header && this.headerAsText && this.header.child("span").update(t), e && this.setIconClass(e), this.fireEvent("titlechange", this, this.title), this
    },
    getStateParam: function() {
        var t = {};
        return (this.maximized || this.hidden) && (t.maximized = this.maximized, t.minimized = this.hidden), t
    },
    getToolSelectedEl: function() {
        var t = this.toolCt.dom.getAttribute("aria-activedescendant");
        return t ? Ext.get(t) : null
    },
    selectToolNext: function() {
        var t, e = this.getToolSelectedEl();
        if (!e) return this.toolCt.set({
            "aria-activedescendant": this.toolCt.first().id
        }), void this.toolCt.first().addClass("x-tool-selected");
        for (t = e.next(); t && !t.isVisible();) t = t.next();
        t && (e.removeClass("x-tool-selected"), this.toolCt.set({
            "aria-activedescendant": t.id
        }), t.addClass("x-tool-selected"))
    },
    selectToolPre: function() {
        var t, e = this.getToolSelectedEl();
        if (!e) return this.toolCt.set({
            "aria-activedescendant": this.toolCt.last().id
        }), void this.toolCt.last().addClass("x-tool-selected");
        for (t = e.prev(); t && !t.isVisible();) t = t.prev();
        t && (e.removeClass("x-tool-selected"), this.toolCt.set({
            "aria-activedescendant": t.id
        }), t.addClass("x-tool-selected"))
    },
    onToolCtKenEnter: function() {
        var t = this.getToolSelectedEl();
        t && t.handler.call(this)
    },
    addTool: function() {
        if (this.rendered && !this.toolCt && this.header && (this.elements += ",toolCt", this.toolCt = this.header.createChild({
                cls: "x-window-toolCt"
            }, this.header.first("." + this.headerTextCls, !0)), this.toolCt.setARIA({
                role: "listbox",
                label: _T("desktop", "window_toolbar_list"),
                activedescendant: "false"
            }), this.toolCt.addKeyListener(Ext.EventObject.LEFT, this.selectToolNext, this), this.toolCt.addKeyListener(Ext.EventObject.RIGHT, this.selectToolPre, this), this.toolCt.addKeyListener(Ext.EventObject.DOWN, this.selectToolNext, this), this.toolCt.addKeyListener(Ext.EventObject.UP, this.selectToolPre, this), this.toolCt.addKeyListener(Ext.EventObject.ENTER, this.onToolCtKenEnter, this)), this.callParent(arguments), this.rendered && this.header) {
            var t, e = arguments,
                i = e.length,
                s = this.tools;
            for (t = 0; t < i; t++) {
                var n = e[t];
                s[n.id].handler || (s[n.id].handler = n.handler)
            }
        }
    },
    createGhost: function(t, e, i) {
        var s = document.createElement("div");
        if (s.className = "x-panel-ghost " + (t || ""), this.header && s.appendChild((this.tl || this.el.dom.firstChild).cloneNode(!0)), Ext.fly(s.appendChild(document.createElement("ul"))).setHeight(this.bwrap.getHeight()), s.style.width = this.el.dom.offsetWidth + "px", i ? Ext.getDom(i).appendChild(s) : this.container.dom.appendChild(s), !1 !== e && !1 !== this.el.useShim) {
            var n = new Ext.Layer({
                shadow: !1,
                useDisplay: !0,
                constrain: !1
            }, s);
            return n.show(), n
        }
        return new Ext.Element(s)
    },
    initTools: function() {
        this.minimizable && this.addTool({
            id: "minimize",
            text: _T("desktop", "minimize"),
            handler: this.minimize.createDelegate(this, [])
        }), this.maximizable && (this.addTool({
            id: "maximize",
            text: _T("desktop", "maximize"),
            handler: this.maximize.createDelegate(this, [])
        }), this.addTool({
            id: "restore",
            text: _T("destop", "restore"),
            handler: this.restore.createDelegate(this, []),
            hidden: !0
        })), this.closable && this.addTool({
            id: "close",
            text: _T("common", "close"),
            handler: this._onCloseAction.createDelegate(this, [])
        })
    },
    openVueWindow: function(t, e) {
        var i, s, n;
        if (Ext.isString(t)) {
            i = Ext.getClassByName(t)
        } else i = t;
        if (i._isVue) n = s = i, document.querySelector("#sds-desktop").appendChild(i.$el);
        else {
            var o = document.createElement("div");
            n = new i({
                propsData: e
            }), SYNO.SDS.Desktop && n && SYNO.SDS.Desktop.appendChild(n), document.querySelector("#sds-desktop").appendChild(o), n.$mount(o), s = getModalWindow(n)
        }
        return s.setOwner(this), s.init(), this.modalWin.push(s), {
            window: s,
            component: n
        }
    }
}), SYNO.SDS.BaseWindow = Ext.extend(SYNO.SDS.AbstractWindow, {
    maskCnt: 0,
    maskTask: null,
    siblingWin: null,
    sinkModalWin: null,
    modalWin: null,
    msgBox: null,
    dsmStyle: "v5",
    owner: null,
    useDefualtKey: !0,
    onEsc: function() {
        !1 !== this.useDefualtKey && SYNO.SDS.BaseWindow.superclass.onEsc.apply(this, arguments)
    },
    constructor: function(t) {
        var e, i = !!t.owner;
        this.siblingWin = [], this.modalWin = [], this.sinkModalWin = [], this.updateDsmStyle(t), t.useStatusBar && (t = this.addStatusBar(t)), e = Ext.urlDecode(location.search.substr(1)), e.dsmStyle && (this.dsmStyle = e.dsmStyle), t.cls = String.format("{0}{1}", t.cls ? t.cls : "", this.isV5Style() ? " sds-window-v5" : " sds-window"), this.fillPadding(t), SYNO.SDS.BaseWindow.superclass.constructor.call(this, Ext.applyIf(t, {
            border: !0,
            plain: !1,
            shadow: !this.isV5Style() && !SYNO.SDS.UIFeatures.test("disableWindowShadow") && "frame",
            shadowOffset: 6,
            closeAction: "close"
        })), !i || t.owner instanceof SYNO.SDS.BaseWindow || t.owner._isVue || SYNO.Debug.warn(String.format('WARNING! owner of window "{0}" is not BaseWindow', this.title || this.id)), this.mon(this, "hide", this.restoreWindowFocus, this)
    },
    findTopWin: function() {
        for (var t, e = !1, i = this; !1 === e;)
            if (Ext.isArray(i.modalWin) && i.modalWin.length > 0)
                for (t = i.modalWin.length - 1; t >= 0; t--) {
                    if (i.modalWin[t] && !(i.modalWin[t].hidden || i.modalWin[t].isDestroyed || i.modalWin[t].destroying)) {
                        i = i.modalWin[t];
                        break
                    }
                    0 === t && (e = !0)
                } else e = !0;
        return i
    },
    restoreWindowFocus: function() {
        !0 !== this.focusLeave && SYNO.SDS.FocusMgr && (SYNO.SDS.FocusMgr.focusActiveWindow(), this.focusLeave = !0)
    },
    focusLastWindowPt: function() {
        var t, e = this.findTopWin();
        if (!(t = e.focusStack)) return void e.focusEl.focus();
        var i, s, n = !1;
        for (i = t.length - 1; i >= 0 && !0 !== n; i--)(s = Ext.fly(t[i])) && s.dom && s.isVisible() && -1 !== s.dom.getAttribute("tabIndex") && (s.focus(), n = !0);
        n || (this.focusEl.focus(), s = this.focusEl), e.focusStack = [s.dom]
    },
    addFocusPt: function() {
        var t, e = document.activeElement;
        e && Ext.fly(e).up(".x-window") && (t = this.findTopWin(), t.focusStack || (t.focusStack = []), t.focusStack.push(e))
    },
    updateDsmStyle: function(t) {
        Ext.isDefined(t) && (t.dsmStyle ? this.dsmStyle = t.dsmStyle : t.owner && this.setToOwnerDsmStyle(t.owner))
    },
    getDsmStyle: function() {
        return this.dsmStyle
    },
    isV5Style: function() {
        return "v5" === this.getDsmStyle()
    },
    setToOwnerDsmStyle: function(t) {
        Ext.isFunction(t.getDsmStyle) && (this.dsmStyle = t.getDsmStyle())
    },
    addStatusBar: function(t) {
        var e = {
            xtype: "statusbar",
            defaultText: "&nbsp;",
            statusAlign: "left",
            buttonAlign: "left",
            items: []
        };
        return this.isV5Style() && (e.defaults = {
            xtype: "syno_button",
            btnStyle: "grey"
        }), t.buttons && (e.items = e.items.concat(t.buttons), delete t.buttons), Ext.applyIf(t, {
            fbar: e
        }), t
    },
    createGhost: function(t, e, i) {
        if (this.isV5Style() && (t += " sds-window-v5"), SYNO.SDS.UIFeatures.test("windowGhost")) return SYNO.SDS.BaseWindow.superclass.createGhost.apply(this, arguments);
        var s = this.el.dom,
            n = document.createElement("div"),
            o = n.style;
        return n.className = "x-panel-ghost-simple", o.width = s.offsetWidth + "px", o.height = s.offsetHeight + "px", i ? Ext.getDom(i).appendChild(n) : this.container.dom.appendChild(n), new Ext.Element(n)
    },
    isModalized: function() {
        return !1
    },
    hasOwnerWin: function(t) {
        var e = this;
        do {
            if (t === e) return !0;
            e = e._isVue ? e.$options.owner : e.owner
        } while (e);
        return !1
    },
    getTopWin: function() {
        for (var t = this, e = this; t;) e = t, t = t._isVue ? t.$options.owner : t.owner;
        return e
    },
    getGroupWinAccessTime: function() {
        var t = this._lastAccess || 0;
        return Ext.each(this.modalWin, function(e) {
            e && e._lastAccess && e._lastAccess > t && (t = e._lastAccess)
        }), Ext.each(this.siblingWin, function(e) {
            e && e._lastAccess && e._lastAccess > t && (t = e._lastAccess)
        }), t
    },
    getMsgBox: function(t) {
        if (!this.msgBox || this.msgBox.isDestroyed) {
            var e = t && t.owner || this;
            e = e.isDestroyed ? null : e, this.isV5Style() ? this.msgBox = new SYNO.SDS.MessageBoxV5({
                owner: e,
                preventDelay: !!t && (t.preventDelay || !1),
                draggable: !!t && (t.draggable || !1)
            }) : this.msgBox = new SYNO.SDS.MessageBox({
                owner: e
            })
        }
        return this.msgBox.getWrapper(t)
    },
    confirmLeave: function(t) {
        var e = {
            yes: {
                text: _T("common", "leave")
            },
            cancel: !0
        };
        this.getMsgBox().confirm("", _T("common", "confirm_lostchange"), t, this, e)
    },
    confirmLostChangePromise: function(t, e, i, s, n) {
        var o, a = {};
        if (Ext.isFunction(t)) o = t;
        else {
            if (!Ext.isObject(t)) return void SYNO.Debug.error("func should be object(for promise) or function(for callback)");
            a = t
        }
        var r = a.save,
            l = a.dontSave,
            h = a.cancel,
            d = a.confirmText;
        i = i || Ext.emptyFn, s = s || Ext.emptyFn, n = n || Ext.emptyFn, this.getMsgBox().confirm("", d || _T("common", "confirm_lostchange_without_save"), o || function(t) {
            Ext.isFunction(i) && i.apply(e, []), "yes" === t ? this.confirmLostChangeCallback(r, s, e) : "cancel" === t ? this.confirmLostChangeCallback(h, n, e) : "leftCustom" === t && this.confirmLostChangeCallback(l, s, e)
        }.bind(this), this, {
            yes: _T("common", "save"),
            cancel: !0,
            leftCustom: {
                text: _T("common", "dont_save"),
                extraStyle: "syno-ux-button-dontsave"
            }
        })
    },
    confirmLostChangeCallback: function(t, e, i) {
        if (!Ext.isFunction(t)) return void SYNO.Debug.error("Callback should be callable");
        var s = t.apply(i, []);
        s && s.then && Ext.isFunction(s.then) || (s = Promise.resolve()), s.then(function(t) {
            Ext.isFunction(e) && e.apply(i, [])
        }.bind(i)).catch(function(t) {}.bind(i))
    },
    getToastBox: function(t, e, i, s) {
        this.toastBox && !this.toastBox.isDestroyed && this.toastBox.destroy();
        var n = {
            text: t,
            closable: e,
            owner: this
        };
        return Ext.isObject(i) && (Ext.isString(i.text) && (n.actionText = i.text), Ext.isFunction(i.fn) && (n.actionHandler = i.fn), Ext.isObject(i.scope) && (n.actionHandlerScope = i.scope)), Ext.isObject(s) && (Ext.isNumber(s.delay) && (n.delay = s.delay), Ext.isNumber(s.offsetY) && (n.offsetY = s.offsetY), Ext.isNumber(s.offsetX) && (n.offsetX = s.offsetX), Ext.isDefined(s.alignEl) && (n.alignEl = s.alignEl), n.alignBottom = !0 === s.alignBottom), this.toastBox = new SYNO.SDS.ToastBox(n), this.toastBox
    },
    onBeforeDestroy: function() {
        function t(t) {
            t && t.destroy()
        }
        this.msgBox && this.msgBox.destroy(), this.toastBox && this.toastBox.destroy(), Ext.each(this.modalWin, t), Ext.each(this.siblingWin, t), delete this.msgBox, delete this.modalWin, delete this.siblingWin, delete this.maskTask, SYNO.SDS.BaseWindow.superclass.onBeforeDestroy.apply(this, arguments)
    },
    onMinimize: function() {
        function t(t) {
            t && (t.hideForMinimize = !0, t.minimize())
        }
        SYNO.SDS.BaseWindow.superclass.onMinimize.apply(this, arguments), Ext.each(this.modalWin, t), Ext.each(this.siblingWin, t)
    },
    applyToAllWindows: function(t) {
        Ext.each(this.modalWin, t), Ext.each(this.siblingWin, t)
    },
    addClassToAllWindows: function(t) {
        function e(e) {
            e.addClassToAllWindows(t)
        }
        this.el.addClass(t), this.applyToAllWindows(e)
    },
    removeClassFromAllWindows: function(t) {
        function e(e) {
            e.removeClassFromAllWindows(t)
        }
        this.el.removeClass(t), this.applyToAllWindows(e)
    },
    disableAllShadow: function() {
        function t(t) {
            t.disableAllShadow()
        }
        this.el.disableShadow(), this.applyToAllWindows(t)
    },
    onClose: function() {
        function t(t) {
            return !t || (t.close(), t.isDestroyed)
        }
        var e;
        return Ext.each(this.modalWin, t), Ext.each(this.sinkModalWin, t), this.modalWin.length || Ext.each(this.siblingWin, t), e = !this.modalWin.length && !this.siblingWin.length, e && (e = !1 !== SYNO.SDS.BaseWindow.superclass.onClose.apply(this, arguments)), e
    },
    onActivate: function() {
        var t = this.getTopWin();
        t.taskButton && t.taskButton.setState("active"), this.el.replaceClass("deactive-win", "active-win"), SYNO.SDS.BaseWindow.superclass.onActivate.apply(this, arguments)
    },
    onDeactivate: function() {
        var t = this.getTopWin();
        t.taskButton && t.taskButton.setState("deactive"), this.el.replaceClass("active-win", "deactive-win"), SYNO.SDS.BaseWindow.superclass.onDeactivate.apply(this, arguments), this.el && this.el.enableShadow(!0)
    },
    blinkShadow: function(t) {
        if (this.isV5Style()) return this.blinkShadowV5(t);
        !this.shadow || t <= 0 || (this.el.disableShadow(), function() {
            this.el.enableShadow(!0), this.blinkShadow.createDelegate(this, [--t]).defer(100)
        }.createDelegate(this).defer(100))
    },
    blinkShadowV5: function(t) {
        !this.el || !this.el.isVisible() || t <= 0 || (this.el.addClass("sds-window-v5-no-shadow"), function() {
            this.el && this.el.isVisible() && (this.el.removeClass("sds-window-v5-no-shadow"), this.blinkShadowV5.createDelegate(this, [--t]).defer(100))
        }.createDelegate(this).defer(100))
    },
    synchronizedMask: function(t) {
        this.mask(t)
    },
    delayedMask: function(t, e) {
        e = Ext.isNumber(e) ? e : 200, this.maskTask || (this.maskTask = new Ext.util.DelayedTask(this.setMaskOpacity, this, [t])), this.mask(0), this.maskTask.delay(e)
    },
    setMaskOpacity: function(t) {
        if (this.el.dom) {
            var e = Ext.Element.data(this.el.dom, "mask");
            e && e.setOpacity(t)
        }
    },
    mask: function(t, e, i, s) {
        if (!this.isDestroyed) {
            if (t = Ext.isNumber(t) ? t : 0, ++this.maskCnt > 1) return void this.setMaskOpacity(t, s);
            var n = this.el.mask(e, i);
            n.addClass("sds-window-mask"), this.mon(n, "mousedown", this.blinkModalChild, this), this.setMaskOpacity(t, s)
        }
    },
    unmask: function() {
        if (!(this.isDestroyed || --this.maskCnt > 0)) {
            this.maskCnt = 0, this.maskTask && this.maskTask.cancel();
            var t = Ext.Element.data(this.el, "mask");
            this.mun(t, "mousedown", this.blinkModalChild, this), this.el.unmask()
        }
    },
    blinkModalChild: function() {
        if (SYNO.SDS.WindowMgr) {
            this.modalWin.sort(SYNO.SDS.WindowMgr.sortWindows);
            var t = this.modalWin[this.modalWin.length - 1];
            if (!t) return void(this.isModalized() && (this.toFront(), this.blinkShadow(3)));
            t.blinkModalChild()
        }
    },
    clearStatus: function(t) {
        var e = this.getFooterToolbar();
        e && Ext.isFunction(e.clearStatus) && e.clearStatus(t)
    },
    clearStatusBusy: function(t) {
        this.unmask(), 0 === this.maskCnt && this.clearStatus(t)
    },
    setStatus: function(t) {
        t = t || {};
        var e = this.getFooterToolbar();
        e && Ext.isFunction(e.setStatus) && e.setStatus(t)
    },
    setStatusOK: function(t) {
        t = t || {}, Ext.applyIf(t, {
            text: _T("common", "setting_applied"),
            iconCls: this.isV5Style() ? "syno-ux-statusbar-success" : "x-status-valid",
            clear: !0
        }), this.setStatus(t)
    },
    setStatusError: function(t) {
        t = t || {}, Ext.applyIf(t, {
            text: _T("common", "error_system"),
            iconCls: this.isV5Style() ? "syno-ux-statusbar-error" : "x-status-error"
        }), this.setStatus(t)
    },
    setStatusBusy: function(t, e, i) {
        t = t || {}, Ext.applyIf(t, {
            text: _T("common", "loading"),
            iconCls: this.isV5Style() ? "syno-ux-statusbar-loading" : "x-status-busy"
        }), this.setStatus(t), this.maskForBusy(e, i)
    },
    maskForBusy: function(t, e) {
        t = Ext.isNumber(t) ? t : .4, e = Ext.isNumber(e) ? e : 400, e > 0 ? this.delayedMask(t, e) : this.synchronizedMask(t)
    },
    hide: function() {
        this.maximized || (this.restoreSize = this.getSize(), this.restorePos = this.getPosition(!0)), this.addClass("syno-window-hide"), SYNO.SDS.BaseWindow.superclass.hide.apply(this, arguments)
    },
    centerTitle: function() {
        var t, e = 0,
            i = ["help", "minimize", "maximize", "close"];
        this.tools && (Ext.each(i, function(t) {
            this.tools[t] && (e += 32)
        }, this), this.header && (t = this.header.child(".x-window-header-text")) && t.setStyle("padding-left", e + "px"))
    },
    fillPadding: function(t) {
        var e;
        return e = this.getFirstItem(t), e ? this.isGridPanel(e) || this.isFormPanel(e) ? void this.fillWindowPadding(t) : this.isTabPanel(e) && this.hasItems(e) ? void this.fillWindowPadding(t) : void 0 : t
    },
    hasItems: function(t) {
        return !!Ext.isArray(t.items) || t.items instanceof Ext.util.MixedCollection
    },
    fillWindowPadding: function(t) {
        Ext.applyIf(t, {
            padding: "16px 16px 0 16px"
        })
    },
    getFirstItem: function(t) {
        var e;
        return Ext.isArray(t.items) && 1 === t.items.length ? e = t.items[0] : Ext.isObject(t.items) && (e = t.items), e
    },
    isTabPanel: function(t) {
        return this.isPanelOf(t, Ext.TabPanel, ["tabpanel", "syno_tabpanel"])
    },
    isFormPanel: function(t) {
        return this.isPanelOf(t, Ext.form.FormPanel, ["form", "syno_formpanel"])
    },
    isGridPanel: function(t) {
        return this.isPanelOf(t, Ext.grid.GridPanel, ["grid", "syno_gridpanel"])
    },
    isPanelOf: function(t, e, i) {
        var s, n, o;
        if (!t) return !1;
        if (t instanceof e) return !0;
        for (s = t.xtype, n = 0, o = i.length; n < o; n++)
            if (s === i[n]) return !0;
        return !1
    },
    destroy: function() {
        this.isDestroyed || !1 !== this.fireEvent("beforedestroy", this) && (this.destroying = !0, this.focusStack && (this.focusStack = null), this.restoreWindowFocus(), SYNO.SDS.BaseWindow.superclass.destroy.call(this))
    }
}), Ext.namespace("SYNO.SDS.Window"), SYNO.SDS.Window = Ext.extend(SYNO.SDS.BaseWindow, {
    constructor: function(t) {
        t = Ext.apply({
            minimizable: !1
        }, t), SYNO.SDS.Window.superclass.constructor.call(this, t), this.owner && Ext.isArray(this.owner.siblingWin) && this.owner.siblingWin.push(this)
    },
    onBeforeDestroy: function() {
        this.owner && Ext.isArray(this.owner.siblingWin) && this.owner.siblingWin.remove(this), SYNO.SDS.Window.superclass.onBeforeDestroy.apply(this, arguments)
    },
    onMinimize: function() {
        this.hide(), SYNO.SDS.Window.superclass.onMinimize.apply(this, arguments)
    },
    isAlwaysOnTop: function() {
        return _S("standalone")
    }
}), Ext.namespace("SYNO.SDS.ModalWindow"), Ext.define("SYNO.SDS.ModalWindow", {
    extend: "SYNO.SDS.BaseWindow",
    ownerMasked: !1,
    constructor: function(t) {
        t = Ext.apply({
            useStatusBar: !0,
            closable: !0,
            maximizable: !1,
            minimizable: !1,
            modal: !t.owner
        }, t), this.callParent([t])
    },
    afterRender: function() {
        if (this.callParent(arguments), !this.heightConstrained) {
            var t = this.owner ? this.owner.el : document.body;
            this.owner && this.owner._isVue || this.alignTo(t, "c-c")
        }
        "emphasized" === this.popupStyle && this.el.addClass("syno-em-window")
    },
    isModalized: function() {
        return !0
    },
    hideFromOwner: function() {
        if (this.owner) {
            var t = this.sinkable ? "sinkModalWin" : "modalWin";
            return Ext.isArray(this.owner[t]) && this.owner[t].remove(this), this.ownerMasked && (this.owner.unmask(!0), this.ownerMasked = !1), !0
        }
        return !1
    },
    afterShow: function() {
        this.callParent(arguments), this.owner && this.owner._isVue || (this.owner && this.sinkable ? this.owner.sinkModalWin.push(this) : !this.ownerMasked && this.owner && (this.owner.modalWin.push(this), this.owner.mask(0, null, null, !0), this.ownerMasked = !0))
    },
    afterHide: function() {
        SYNO.SDS.ModalWindow.superclass.afterHide.apply(this, arguments), this.owner && this.owner._isVue || this.hideForMinimize || this.hideFromOwner()
    },
    onBeforeDestroy: function() {
        this.owner && this.owner._isVue || this.hideFromOwner() && (this.owner = null), SYNO.SDS.ModalWindow.superclass.onBeforeDestroy.apply(this, arguments)
    },
    onMinimize: function() {
        this.hide(), SYNO.SDS.ModalWindow.superclass.onMinimize.apply(this, arguments)
    },
    onWindowClose: function() {
        this.owner ? this.owner.focus() : Ext.get("sds-taskbar-startbutton").child("button").focus()
    },
    fillWindowPadding: function(t) {
        Ext.applyIf(t, {
            padding: "16px 20px 0 20px"
        })
    }
}), Ext.define("SYNO.SDS.MessageBoxV5", {
    extend: "SYNO.SDS.ModalWindow",
    ariaRole: "alertdialog",
    maxWidth: 600,
    minWidth: 420,
    minProgressWidth: 250,
    minPromptWidth: 250,
    emptyText: "&#160;",
    defaultTextHeight: 75,
    mbIconCls: "",
    fbButtons: null,
    opt: null,
    bodyEl: null,
    msgEl: null,
    progressBar: null,
    gridEl: null,
    constructor: function(t) {
        this.opt = {}, this.buttonNames = ["custom", "cancel", "no", "ok", "yes"], this.leftButtonNames = ["leftCustom"], this.buttonText = Ext.MessageBox.buttonText, t = t || {}, t.cls = t.cls ? t.cls + " x-window-dlg" : "x-window-dlg", t.fbar = t.fbar || this.getButtons(t), this.callParent([Ext.apply(t, {
            closable: !0,
            stateful: !1,
            resizable: !1,
            minimizable: !1,
            maximizable: !1,
            header: t.draggable || !1,
            draggable: t.draggable || !1,
            buttonAlign: "left",
            elements: "body",
            padding: "24px 30px 0 30px"
        })]), this.draggable && this.addClass("msgbox-draggable")
    },
    onRender: function() {
        this.callParent(arguments);
        var t = Ext.id();
        this.bodyEl = this.body.createChild({
            html: '<div class="ext-mb-content"><div class="ext-mb-title"></div><span class="ext-mb-text" id=' + t + '></span><br class="ext-mb-br"/><div class="ext-mb-fix-cursor"></div></div><div class="ext-mb-grid"></div>'
        }), this.titleEl = this.bodyEl.child(".ext-mb-title"), this.msgEl = this.bodyEl.child(".ext-mb-text"), this.brEl = this.bodyEl.child(".ext-mb-br"), this.wrapperEl = this.bodyEl.child(".ext-mb-fix-cursor"), this.gridEl = this.bodyEl.child(".ext-mb-grid"), this.progressBar = new Ext.ProgressBar({
            renderTo: this.bodyEl
        }), this.focusEl.set({
            "aria-labelledby": this.msgEl.id
        }), this.focusEl.dom.removeAttribute("aria-label"), this.bodyEl.createChild({
            cls: "x-clear"
        }), this.titleEl.enableDisplayMode(), this.gridEl.enableDisplayMode(), this.addManagedComponent(this.progressBar), this.progressStatus = this.bodyEl.createChild({
            tag: "span",
            cls: "syno-mb-progress-status"
        }, this.bodyEl.child(".x-clear")), this.progressBar.addClass("syno-mb-progress")
    },
    handleButton: function(t, e) {
        this.fbButtons[t].blur();
        var i = this.activeTextField ? this.activeTextField.getValue() : "";
        this.preventDelay ? this.opt.fn.call(this.opt.scope || window, t, i, this.opt, e) : Ext.callback(this.opt.fn, this.opt.scope || window, [t, i, this.opt, e], 1), SYNO.SDS.MessageBoxV5.superclass.close.call(this)
    },
    setIconClass: function(t) {
        if (t && "" !== t) return this.bodyEl.addClass("x-dlg-icon"), this.addClass(t), void(this.mbIconCls = t);
        this.bodyEl.removeClass("x-dlg-icon"), this.mbIconCls = ""
    },
    createTextField: function() {
        this.textbox || (this.textbox = new SYNO.ux.TextField({
            renderTo: this.wrapperEl
        }), this.textbox.el.addKeyListener(Ext.EventObject.ENTER, this.handleButton.createDelegate(this, ["ok"])))
    },
    createTextArea: function() {
        this.textarea || (this.textarea = new SYNO.ux.TextArea({
            renderTo: this.wrapperEl
        }), this.textarea.el.addKeyListener(Ext.EventObject.ENTER, this.handleButton.createDelegate(this, ["ok"])))
    },
    createPasswordField: function() {
        this.passwordField || (this.passwordField = new SYNO.ux.TextField({
            renderTo: this.wrapperEl,
            type: "password"
        }), this.passwordField.el.addKeyListener(Ext.EventObject.ENTER, this.handleButton.createDelegate(this, ["ok"])))
    },
    removeTextArea: function() {
        this.textarea && (this.textarea.destroy(), this.textarea = null)
    },
    removeTextfield: function() {
        this.textbox && (this.textbox.destroy(), this.textbox = null)
    },
    removePassword: function() {
        this.passwordField && (this.passwordField.destroy(), this.passwordField = null)
    },
    setTitle: function(t, e) {
        !0 === e ? (this.titleEl.update(t), this.titleEl.show()) : (this.titleEl.hide(), SYNO.SDS.MessageBoxV5.superclass.setTitle.apply(this, [t]))
    },
    showMsg: function(t) {
        if (this.opt = t, this.setTitle(t.title || this.emptyText, this.opt.useMessageTitle), this.tools.close && this.tools.close.setDisplayed(!1 !== t.closable && !0 !== t.progress && !0 !== t.wait), this.gridEl.hide(), this.activeTextField = null, t.prompt = t.prompt || !!t.multiline, t.prompt ? (t.multiline ? (this.createTextArea(), this.activeTextField = this.textarea, this.textarea.setHeight(Ext.isNumber(t.multiline) ? t.multiline : this.defaultTextHeight), this.removeTextfield(), this.removePassword()) : t.password ? (this.createPasswordField(), this.activeTextField = this.passwordField, this.removeTextfield(), this.removeTextArea()) : (this.createTextField(), this.activeTextField = this.textbox, this.removeTextArea(), this.removePassword()), this.activeTextField.setValue(t.value || "")) : (this.removeTextfield(), this.removeTextArea(), this.removePassword()), this.setIconClass(Ext.isDefined(t.icon) ? t.icon : null), this.buttonWidth = this.updateButtons(t.buttons), this.progressBar.setVisible(!0 === t.progress || !0 === t.wait), this.updateProgress(0, t.progressText), this.updateText(t.msg), t.wait && this.progressBar.wait(t.waitConfig), t.cls && this.el.addClass(t.cls), t.progress ? this.progressBar.progressBar.set({
                "aria-labelledby": this.msgEl.id
            }) : this.progressBar.progressBar.set({
                tabIndex: "-1"
            }), !0 === t.wait && this.progressBar.wait(t.waitConfig), Ext.isArray(t.msgArray)) {
            var e = this.bodyEl.child("div.ext-mb-content"),
                i = Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(t.msg));
            this.brEl.enableDisplayMode("DISPLAY"), this.brEl.hide(), this.msgEl.set({
                "ext:qtip": i
            }), e.addClass("ext-mb-grid-desc"), this.gridEl.show(), this.createGridPanel(t.msgArray)
        }
        t.hideBrElement && (this.brEl.enableDisplayMode("DISPLAY"), this.brEl.hide()), this.show(), this.owner && !this.owner.isVisible() && (this.hideForMinimize = !0, this.minimize())
    },
    createGridPanel: function(t) {
        var e = t.map(function(t) {
            return [t]
        });
        if (this.grid) return void this.grid.store.loadData(e);
        var i = new Ext.grid.ColumnModel({
            columns: [{
                dataIndex: "data",
                renderer: function(t, e, i) {
                    var s = Ext.util.Format.htmlEncode(t);
                    return e.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(s) + '"', s
                }
            }]
        });
        this.grid = new SYNO.ux.GridPanel({
            colModel: i,
            store: new Ext.data.ArrayStore({
                autoDestroy: !0,
                fields: ["data"],
                data: e
            }),
            viewConfig: {
                rowOverCls: "",
                selectedRowClass: ""
            },
            hideHeaders: !0,
            enableHdMenu: !1,
            height: 304,
            autoHeight: !1,
            renderTo: this.gridEl,
            listeners: {
                viewready: function(t) {
                    this.view.updateScroller()
                }
            }
        }), this.addManagedComponent(this.grid)
    },
    selectBtn: function(t, e, i) {
        var s = Object.values(this.fbButtons).filter(function(t) {
            return !t.hidden
        });
        if (0 !== s.length) {
            var n = "previous" === i ? -1 : "next" === i && 1 || 0,
                o = Ext.getCmp(Ext.get(t.target).up(".syno-ux-button").id),
                a = s.findIndex(function(t) {
                    return t === o
                });
            s[Math.min(Math.max(0, a + n), s.length - 1)].focus()
        }
    },
    close: function() {
        !1 !== this.opt.canClose && (this.opt.buttons && this.opt.buttons.no && !this.opt.buttons.cancel ? this.handleButton("no", "close") : this.handleButton("cancel", "close"))
    },
    doClose: function() {
        if (this.activeGhost) {
            var t = Ext.dd.DragDropMgr;
            this.dd === t.dragCurrent && (t.dragCurrent = null, t.dragOvers = {}), this.unghost(!1, !1)
        }
        this.removePassword(), this.removeTextArea(), this.removeTextfield(), this.callParent(arguments)
    },
    genButtonConfig: function(t) {
        return {
            btnStyle: this.getButtonStyle(t),
            text: this.buttonText[t],
            handler: this.handleButton.createDelegate(this, [t]),
            msgWin: this,
            transitionFocus: function() {
                this.el.hasClass("focus-effect") ? this.el.removeClass("focus-effect") : this.el.addClass("focus-effect")
            },
            onBtnElFocus: function(t) {
                this.focusTask = this.focusTask || this.addTask({
                    id: "focus_effect",
                    interval: 600,
                    run: this.transitionFocus,
                    scope: this
                }), this.focusTask.start()
            },
            onBtnElBlur: function(t) {
                this.focusTask.stop(), this.el.removeClass("focus-effect")
            },
            listeners: {
                afterrender: function() {
                    this.hidden || (this.nav = new Ext.KeyNav(this.btnEl, {
                        left: this.msgWin.selectBtn.createDelegate(this.msgWin, ["previous"], !0),
                        right: this.msgWin.selectBtn.createDelegate(this.msgWin, ["next"], !0)
                    }), this.mon(this.btnEl, {
                        focus: this.onBtnElFocus,
                        blur: this.onBtnElBlur,
                        scope: this
                    }, this))
                }
            }
        }
    },
    getButtons: function(t) {
        var e = [],
            i = this;
        return this.fbButtons = {}, this.buttonText.custom = this.buttonText.no, Ext.each(this.leftButtonNames, function(t) {
            e.push(i.fbButtons[t] = new SYNO.ux.Button(i.genButtonConfig(t), this))
        }), e.push("->"), Ext.each(this.buttonNames, function(t) {
            e.push(i.fbButtons[t] = new SYNO.ux.Button(i.genButtonConfig(t), this))
        }), e
    },
    setButtonsCls: function(t) {
        for (var e in this.fbButtons) {
            this.fbButtons[e].addClass(t)
        }
    },
    getButtonStyle: function(t) {
        return "ok" == t || "yes" == t ? "blue" : "grey"
    },
    isModalized: function() {
        return !this.sinkable
    },
    getTopWin: function() {
        return this.sinkable ? this : this.callParent()
    },
    isCustomBtnVisible: function() {
        return !this.fbButtons.custom.hidden
    },
    updateProgress: function(t, e, i, s) {
        return s = s || !1, this.progressStatus.update(e), (i || e) && !0 !== s ? this.updateText(i) : i && this.msgEl.update(i), this.progressBar.updateProgress(t, e), this
    },
    updateButtons: function(t) {
        var e, i, s, n = 0;
        return this.fbButtons.custom.removeClass("syno-mb-custom-btn"), t ? (Ext.iterate(this.fbButtons, function(o, a) {
            e = t[o], e ? (a.show(), this.updateBtnByCfg(o, a, e), !this.extra || this.extra.btnStyle === a.btnStyle || "yes" !== o && "ok" !== o || !a.el || a.el.hasClass(s) || (i = String.format("syno-ux-button-{0}", a.btnStyle), s = String.format("syno-ux-button-{0}", this.extra.btnStyle || "blue"), a.removeClass(i), a.addClass(s)), n += a.container.getWidth()) : a.hide()
        }, this), this.isCustomBtnVisible() && this.fbButtons.custom.addClass("syno-mb-custom-btn"), n) : (Ext.each(this.buttonNames, function(t) {
            this.fbButtons[t].hide()
        }, this), Ext.each(this.leftButtonNames, function(t) {
            this.fbButtons[t].hide()
        }, this), n)
    },
    updateBtnByCfg: function(t, e, i) {
        var s = this.buttonText[t],
            n = "grey";
        e.el && (Ext.isString(i) ? s = i : Ext.isObject(i) && i.text && (s = i.text), e.setText(s), e.removeClass("syno-ux-button-blue"), e.removeClass("syno-ux-button-red"), e.removeClass("syno-ux-button-grey"), Ext.isObject(i) && i.btnStyle ? n = i.btnStyle : "yes" !== t && "ok" !== t || (n = "blue"), e.addClass("syno-ux-button-" + n), Ext.isObject(i) && i.extraStyle && e.addClass(i.extraStyle))
    },
    updateText: function(t) {
        this.opt.width || this.setSize(this.maxWidth, 100), this.msgEl.update(t || this.emptyText);
        var e, i = this.msgEl.getWidth() + this.msgEl.getMargins("lr"),
            s = this.getFrameWidth("lr"),
            n = this.body.getFrameWidth("lr");
        e = Math.max(Math.min(this.opt.width || i + s + n, this.opt.maxWidth || this.maxWidth), Math.max(this.opt.minWidth || this.minWidth, this.buttonWidth || 0)), e += 2 * (this.fbar.getBox().x - this.getBox().x), !0 === this.opt.prompt && this.activeTextField.setWidth(e - s - n), Ext.isIE && e == this.buttonWidth && (e += 4), this.setSize(e, "auto")
    },
    confirmDelete: function(t, e, i, s, n, o) {
        var a = {
            yes: {
                text: _T("common", "delete"),
                btnStyle: "red"
            },
            cancel: {
                text: this.buttonText.cancel
            }
        };
        return this.showMsg(Object.assign({
            title: t,
            msg: e,
            buttons: n || a,
            fn: i,
            icon: "confirm-delete-icon",
            scope: s,
            minWidth: this.minWidth
        }, o)), this
    },
    focus: function() {
        var t = this.focusEl;
        if (this.fbButtons.yes && this.fbButtons.yes.isVisible()) return void this.fbButtons.yes.focus();
        t = t || this.focusEl, t.focus.defer(10, t)
    },
    progress: function(t, e, i, s) {
        return this.showMsg(Object.assign({
            title: t,
            msg: e,
            buttons: !1,
            progress: !0,
            closable: !1,
            minWidth: this.minProgressWidth,
            progressText: i
        }, s)), this
    },
    wait: function(t, e, i, s) {
        return this.showMsg(Object.assign({
            title: e,
            msg: t,
            buttons: !1,
            closable: !1,
            wait: !0,
            minWidth: this.minProgressWidth,
            waitConfig: i
        }, s)), this
    },
    alert: function(t, e, i, s, n) {
        return this.showMsg(Object.assign({
            title: t,
            msg: e,
            buttons: Ext.MessageBox.OK,
            fn: i,
            scope: s,
            minWidth: this.minWidth
        }, n)), this
    },
    showGridMsg: function(t, e, i, s, n, o, a) {
        return this.showMsg(Object.assign({
            title: t,
            msg: e,
            msgArray: i,
            buttons: o || Ext.MessageBox.YESNO,
            fn: s,
            scope: n,
            maxWidth: 380,
            minWidth: this.minWidth
        }, a)), this
    },
    confirm: function(t, e, i, s, n, o) {
        return this.showMsg(Object.assign({
            title: t,
            msg: e,
            buttons: n || Ext.MessageBox.YESNO,
            fn: i,
            scope: s,
            minWidth: this.minWidth
        }, o)), this
    },
    prompt: function(t, e, i, s, n, o, a, r) {
        return this.showMsg(Object.assign({
            title: t,
            msg: e,
            buttons: Ext.MessageBox.OKCANCEL,
            fn: i,
            minWidth: this.minPromptWidth,
            scope: s,
            prompt: !0,
            multiline: n,
            value: o,
            password: a
        }, r)), this
    },
    show: function() {
        this.alignTo(this.owner ? this.owner.el : document.body, "c-c"), this.callParent(arguments)
    },
    getWrapper: function(t) {
        function e(t, e) {
            return function() {
                return e.apply(t, arguments)
            }
        }
        return this.msgBoxWrapper || (this.msgBoxWrapper = {
            confirmGrid: e(this, this.showGridMsg),
            show: e(this, this.showMsg),
            hide: e(this, this.doClose),
            progress: e(this, this.progress),
            wait: e(this, this.wait),
            alert: e(this, this.alert),
            confirm: e(this, this.confirm),
            confirmDelete: e(this, this.confirmDelete),
            prompt: e(this, this.prompt),
            getDialog: function() {
                return this
            }.createDelegate(this),
            isVisible: e(this, this.isVisible),
            setIcon: e(this, this.setIconClass),
            updateProgress: e(this, this.updateProgress),
            updateText: e(this, this.updateText)
        }), this.extra = {}, Ext.apply(this.extra, t || {}), this.extra && this.extra.sinkable && Ext.apply(this, {
            sinkable: !!this.extra.sinkable
        }), this.msgBoxWrapper
    }
}), SYNO.SDS.MessageBoxV5.YESNOCANCEL = {
    custom: !0,
    yes: !0,
    cancel: !0
}, SYNO.SDS.MessageBox = SYNO.SDS.MessageBoxV5, Ext.namespace("SYNO.SDS"), Ext.namespace("SYNO.SDS.Utils"), SYNO.SDS.emptyFn = function() {}, SYNO.SDS.isFunction = function(t) {
    return "[object Function]" === Object.prototype.toString.apply(t)
}, SYNO.SDS.isDefined = function(t) {
    return void 0 !== t
}, SYNO.SDS.GetBody = function() {
    return document.body || document.documentElement
}, SYNO.SDS.Utils.UserAgent = function() {
    var t = navigator.userAgent.toLowerCase(),
        e = function(e) {
            return e.test(t)
        },
        i = {};
    return i.isEdge = e(/edge/), i.isOpera = e(/opera/), i.isChrome = !i.isEdge && e(/\bchrome\b/), i.isWebKit = !i.isEdge && e(/webkit/), i.isSafari = !(i.isChrome || i.isEdge) && e(/safari/), i.isSafari2 = i.isSafari && e(/applewebkit\/4/), i.isSafari3 = i.isSafari && e(/version\/3/), i.isSafari4 = i.isSafari && e(/version\/4/), i.isSafari5 = i.isSafari && e(/version\/5/), i.isSafari5_0 = i.isSafari && e(/version\/5.0/), i.isGecko = !(i.isWebKit || i.isIE11 || i.isEdge) && e(/gecko/), i.isGecko2 = i.isGecko && e(/rv:1\.8/), i.isGecko3 = i.isGecko && e(/rv:1\.9/), i.isIE = !i.isOpera && e(/msie/), i.isTrident7 = e(/trident\/7/), i.isIE11 = i.isTrident7, i.isIE12 = e(/edge\/(\d+)./), i.isIE10 = i.isIE && (e(/msie 10/) || e(/trident\/6/)), i.isTrident6 = i.isIE && e(/trident\/6/), i.isIE10Touch = i.isTrident6 && e(/touch;/), i.isIE9 = i.isIE && e(/trident\/5/), i.isIE8 = i.isIE && !i.isIE9 && !i.isIE10 && !i.isIE11 && e(/trident/), i.isIE7 = i.isIE && !i.isIE8 && !i.isIE9 && !i.isIE10 && !i.isIE11 && e(/msie 7/), i.isIE6 = i.isIE && !i.isIE7 && !i.isIE8 && !i.isIE9 && !i.isIE10 && !i.isIE11 && e(/msie 6/), i.isModernIE = i.isIE12 || i.isIE11 || i.isIE && !i.isIE6 && !i.isIE7 && !i.isIE8, i.isIE9m = i.isIE && (i.isIE6 || i.isIE7 || i.isIE8 || i.isIE9), i.isBorderBox = i.isIE9m && !i.isStrict, i.isWindows = e(/windows|win32/), i.isMac = e(/macintosh|mac os x/), i.isAir = e(/adobeair/), i.isLinux = e(/linux/), i
}(), SYNO.SDS.Utils.GetURLParam = function(t, e) {
    var i, s, n = t.split("&"),
        o = decodeURIComponent,
        a = {};
    return n.forEach(function(t) {
        t = t.split("="), i = o(t[0]), s = o(t[1]), a[i] = e || !a[i] ? s : [].concat(a[i]).concat(s)
    }), a
}, Ext.define("SYNO.SDS.IEUpgradeAlert", {
    extend: "SYNO.SDS.Window",
    constructor: function() {
        var t = {
            cls: "ie-upgrade-alert",
            width: 450,
            height: 230,
            maximizable: !1,
            title: _D("manager"),
            items: [{
                xtype: "syno_formpanel",
                name: "ie_alert_form",
                items: [{
                    xtype: "syno_displayfield",
                    hideLabel: !0,
                    value: _T("desktop", "upgrade_ie_browser")
                }, {
                    name: "skip_alert",
                    xtype: "syno_checkbox",
                    checked: !1,
                    boxLabel: _T("common", "dont_alert_again")
                }]
            }],
            fbar: {
                toolbarCls: "x-panel-fbar x-statusbar",
                items: [{
                    xtype: "syno_button",
                    text: _T("common", "ok"),
                    btnStyle: "blue",
                    handler: function() {
                        var t = this.find("name", "skip_alert")[0],
                            e = new Date;
                        !0 === t.getValue() && Ext.util.Cookies.set("skip_upgrade_ie_alert", !0, e.add(Date.YEAR, 1)), this.close()
                    },
                    scope: this
                }]
            }
        };
        this.callParent([t])
    }
}), SYNO.SDS.HTML5Utils = function() {
    var t = window.XMLHttpRequest ? new XMLHttpRequest : {},
        e = SYNO.SDS.Utils.UserAgent;
    return {
        HTML5Progress: !!t.upload,
        HTML5SendBinary: !(!t.sendAsBinary && !t.upload),
        HTML5ReadBinary: !!(window.FileReader || window.File && window.File.prototype.getAsBinary),
        HTML5Slice: !(!window.File || !(window.File.prototype.slice || window.File.prototype.mozSlice || window.File.prototype.webkitSlice)),
        isSupportHTML5Upload: function() {
            return (e.isChrome || !e.isSafari4 && !e.isSafari5_0 && !(e.isWindows && e.isSafari) && !e.isGecko3 && !e.isOpera) && (!!window.FormData || SYNO.SDS.HTML5Utils.HTML5SendBinary && SYNO.SDS.HTML5Utils.HTML5ReadBinary && SYNO.SDS.HTML5Utils.HTML5Slice)
        },
        isDragFile: function(t) {
            try {
                if (e.isWebKit) {
                    return t.dataTransfer.types && -1 != t.dataTransfer.types.indexOf("Files")
                }
                if (e.isGecko) return t.dataTransfer.types.contains && t.dataTransfer.types.contains("application/x-moz-file") || 0 <= t.dataTransfer.types.indexOf("application/x-moz-file");
                if (e.isIE10 || e.isModernIE) return t.dataTransfer.files && t.dataTransfer.types && t.dataTransfer.types.contains("Files")
            } catch (t) {
                SYNO.Debug.log("Error in isDragFile")
            }
            return !1
        }
    }
}(), SYNO.SDS.UpdateSynoToken = function(t) {
    Ext.Ajax.request({
        url: "webapi/entry.cgi?api=SYNO.API.Auth&version=6&method=token",
        updateSynoToken: !0,
        callback: function(e, i, s) {
            var n = Ext.util.JSON.decode(s.responseText);
            i && n.data && !Ext.isEmpty(n.data.synotoken) && (SYNO.SDS.Session.SynoToken = encodeURIComponent(n.data.synotoken), synowebapi && synowebapi.env.setSynoToken(SYNO.SDS.Session.SynoToken)), Ext.isFunction(t) && t(e, i)
        }
    })
}, SYNO.SDS.UIFeatures = function() {
    var t, e, i = SYNO.SDS.Utils.UserAgent,
        s = {
            previewBox: !i.isIE || i.isModernIE,
            expandMenuHideAll: !0,
            windowGhost: !i.isIE || i.isModernIE,
            disableWindowShadow: i.isIE && !i.isModernIE,
            exposeWindow: !i.isIE || i.isIE10p,
            msPointerEnabled: window.navigator.msPointerEnabled && window.navigator.msMaxTouchPoints > 0,
            isTouch: "ontouchstart" in window || window.navigator.msPointerEnabled && window.navigator.msMaxTouchPoints > 0,
            isRetina: function() {
                var t = !1;
                return window.devicePixelRatio >= 1.5 && (t = !0), window.matchMedia && window.matchMedia("(-webkit-min-device-pixel-ratio: 1.5),(min--moz-device-pixel-ratio: 1.5),(-o-min-device-pixel-ratio: 3/2),(min-resolution: 1.5dppx)").matches && (t = !0), t
            }(),
            isSupportFullScreen: document.fullscreenEnabled || document.webkitFullscreenEnabled || document.mozFullScreenEnabled || document.msFullscreenEnabled
        },
        n = SYNO.SDS.Utils.GetURLParam(location.search.substr(1));
    for (t in n) n.hasOwnProperty(t) && (e = n[t], void 0 !== s[t] && (s[t] = "false" !== e));
    return {
        test: function(t) {
            return !!s[t]
        },
        listAll: function() {
            var t, e = "== Feature List ==\n";
            for (t in s) s.hasOwnProperty(t) && (e += String.format("{0}: {1}\n", t, s[t]));
            return e
        },
        isFullScreenMode: function() {
            return !!(document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement || document.msFullscreenElement)
        }
    }
}(), SYNO.SDS.UIFeatures.IconSizeManager = {
    PortalIcon: 64,
    GroupView: 24,
    Taskbar: 24,
    WidgetHeader: 32,
    GroupViewHover: 48,
    Desktop: 64,
    ClassicalDesktop: 48,
    AppView: 72,
    AppViewClassic: 48,
    Header: 24,
    HeaderV4: 16,
    TreeIcon: 16,
    StandaloneHeader: 24,
    FavHeader: 16,
    FinderPreview: 128,
    isEnableHDPack: !1,
    cls: "synohdpack",
    debugCls: "synohdpackdebug",
    getAppPortalIconPath: function(t) {
        var e = this.isRetinaMode(),
            i = e ? 256 : this.PortalIcon,
            s = e ? "2x" : "1x";
        return String.format(t, i, s)
    },
    getIconPath: function(t, e, i) {
        var s, n, o = this.isRetinaMode(),
            a = function(t, e, i, s) {
                return t.replace(e, "48" === e ? "128" : 2 * e)
            },
            r = function(t, e, i, s) {
                return t.replace(e, "48" === e ? "128" : 2 * e)
            };
        if (0 === t.indexOf("webman/3rdparty/")) {
            o = "FavHeader" !== e && o;
            return String.format("webapi/entry.cgi?api=SYNO.Core.Synohdpack&version=1&method=getHDIcon&res={0}&retina={1}&path={2}", this.getRes(e), o, t)
        }
        switch (-1 === t.indexOf("{1}") ? o ? (i = i || !1, n = i || -1 !== t.indexOf("shortcut_icons") || -1 !== t.indexOf("webfm/images") ? t : 0 === t.indexOf("webman/") ? "/synohdpack/images/dsm/" + t.substr("webman/".length) : "/synohdpack/images/dsm/" + t) : n = t : n = t.replace("{1}", o ? "2x" : "1x"), e) {
            case "Taskbar":
                s = String.format(n, o ? 2 * this.Taskbar : this.Taskbar);
                break;
            case "Desktop":
                -1 != n.indexOf("files_ext_48") && "classical" != SYNO.SDS.UserSettings.getProperty("Desktop", "desktopStyle") && (n = n.replace("files_ext_48", "files_ext_64")), -1 != n.indexOf("files_ext_") ? (n = n.replace(/webfm\/images/, o ? "images/2x" : "images/1x"), s = o ? n.replace(/.*\/files_ext_(\d+)\/.*/, a) : n) : -1 != n.indexOf("shortcut_icons") ? (n = n.replace(/images\/default\/.+\/shortcut_icons/, o ? "images/2x/shortcut_icons" : "images/1x/shortcut_icons"), s = o ? n.replace(/.*\/.*_(\d+)\.png$/, r) : n) : s = String.format(n, o ? 256 : this.Desktop);
                break;
            case "ClassicalDesktop":
                -1 != n.indexOf("files_ext_") ? (n = n.replace(/webfm\/images/, o ? "images/2x" : "images/1x"), s = o ? n.replace(/.*\/files_ext_(\d+)\/.*/, a) : n) : -1 != n.indexOf("shortcut_icons") ? (n = n.replace(/images\/default\/.+\/shortcut_icons/, o ? "images/2x/shortcut_icons" : "images/1x/shortcut_icons"), s = o ? n.replace(/.*\/.*_(\d+)\.png$/, r) : n) : s = String.format(n, o ? 256 : this.ClassicalDesktop);
                break;
            case "AppView":
                s = String.format(n, o ? 256 : this.AppView);
                break;
            case "AppViewClassic":
                s = String.format(n, o ? 256 : this.AppViewClassic);
                break;
            case "Header":
                s = String.format(n, o ? 2 * this.Header : this.Header);
                break;
            case "HeaderV4":
                s = String.format(n, o ? 2 * this.HeaderV4 : this.HeaderV4);
                break;
            case "StandaloneHeader":
                s = String.format(n, o ? 2 * this.StandaloneHeader : this.StandaloneHeader);
                break;
            case "FavHeader":
                s = String.format(n, o ? 2 * this.FavHeader : this.FavHeader);
                break;
            case "FileType":
                s = o ? n.replace(/.*\/files_ext_(\d+)\/.*/, a) : n;
                break;
            case "TreeIcon":
                s = String.format(n, o ? 3 * this.TreeIcon : this.TreeIcon);
                break;
            case "FinderPreview":
                s = String.format(n, o ? 256 : 128);
                break;
            case "WidgetHeader":
                s = String.format(n, o ? 2 * this.WidgetHeader : this.WidgetHeader);
                break;
            default:
                s = n
        }
        return -1 == s.indexOf(String.format("?v={0}", _S("fullversion"))) && ".png" === s.substr(s.length - 4) && (s += "?v=" + _S("fullversion")), s = encodeURI(s)
    },
    enableHDDisplay: function(t) {
        SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = t
    },
    isRetinaMode: function() {
        return SYNO.SDS.UIFeatures.test("isRetina") && this.isEnableHDPack
    },
    getRetinaAndSynohdpackStatus: function() {
        return SYNO.Debug("SYNO.SDS.UIFeatures.IconSizeManager.getRetinaAndSynohdpackStatus() was renamed, please call SYNO.SDS.UIFeatures.IconSizeManager.isRetinaMode() instead."), this.isRetinaMode()
    },
    addHDClsAndCSS: function() {
        var t = !1;
        SYNO.SDS.UIFeatures.test("isRetina") && (document.documentElement.classList.add(this.cls), t = !0), SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = t
    },
    enableRetinaDisplay: function() {
        document.documentElement.classList.remove(this.debugCls), document.documentElement.classList.add(this.cls), SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = !0
    },
    enableRetinaDebugMode: function() {
        document.documentElement.classList.remove(this.cls), document.documentElement.classList.add(this.debugCls), SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = !0
    },
    disableRetinaDisplay: function() {
        document.documentElement.classList.remove(this.cls), document.documentElement.classList.remove(this.debugCls), SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = !1
    },
    getRes: function(t) {
        return this[t] ? this[t] : -1
    }
}, SYNO.SDS.HandShake = function() {
    var t = void 0,
        e = void 0;
    return {
        get: function() {
            return e
        },
        Init: function(t) {
            SYNO.SDS.HandShake._noise = t, SYNO.SDS.HandShake._hhid = sodium.randombytes_random() % 65536, Ext.Ajax.on("beforerequest", function(t, e) {
                if (SYNO.SDS.HandShake.IsSupport()) return !0 === SYNO.SDS.Session.updateSession ? (SYNO.SDS.Session.DelayAjax.push(e), !1) : void(e && e.params && e.params.api && "SYNO.Entry.Request" !== e.params.api && (Ext.isEmpty(e.headers) && (e.headers = {}), e.headers["X-SYNO-HASH"] || (e.headers["X-SYNO-HASH"] = SYNO.SDS.HandShake.Encrypt(""), e.headers["X-SYNO-HHID"] = SYNO.SDS.HandShake._hhid)))
            })
        },
        GetLoginParams: function(e) {
            var i = {
                api: "SYNO.API.Auth",
                version: 6,
                method: "login",
                session: "webui",
                hhid: SYNO.SDS.HandShake._hhid,
                enable_syno_token: _S("enable_syno_token")
            };
            return i = Object.assign(i, e), i = Object.assign(i, Ext.urlDecode(window.location.search.split("?")[1])), SYNO.SDS.HandShake.IsSupport() && (t = SYNO.SDS.HandShake.GetInstance("Noise_IK_25519_ChaChaPoly_BLAKE2b"), t ? (i.ik_message = SYNO.SDS.HandShake.Write(t), i.version = 7) : SYNO.SDS.HandShake.UnSupport()), i
        },
        GetLoginSynoToken: function(e) {
            var i = null,
                s = Ext.urlDecode(window.location.search.split("?")[1]),
                n = s.state;
            if (e.data.code && e.data.code.length > 0) {
                if (window.opener && "" === e.data.redirect_uri) return e.data.rs = Ext.util.Cookies.get("_SSID"), window.opener.postMessage(e.data, s.opener), void window.close();
                if ("" === e.data.redirect_uri) return void window.location.replace("/error");
                var o = e.data.redirect_uri + "?code=" + e.data.code;
                return o += "&rs=" + Ext.util.Cookies.get("_SSID"), n && (o += "&state=" + n), void window.location.replace(o)
            }
            if (!0 === e.success) {
                var a = localStorage.getItem("choseAuthType");
                a && (localStorage.setItem(e.data.account + ".AuthType", a), localStorage.removeItem("choseAuthType"))
            }
            return e.data && e.data.synotoken && (i = e.data.synotoken, SYNO.SDS.HandShake.IsSupport() && (t && e.data.ik_message ? (SYNO.SDS.HandShake.Read(t, e.data.ik_message), SYNO.SDS.CrossPortStorage.SetItem("currentLoginUser", e.data.account), t = void 0) : SYNO.SDS.HandShake.UnSupport())), i
        },
        GetHeaderError: function(t) {
            if (t && t.getResponseHeader) try {
                return t.getResponseHeader("x-request-error") || t.getResponseHeader("X-Request-Error")
            } catch (e) {
                return t.getResponseHeader["x-request-error"] || t.getResponseHeader["X-Request-Error"]
            }
        },
        CheckServerError: function(t) {
            if (SYNO.SDS.HandShake.IsSupport() && "unauth" === this.GetHeaderError(t)) return !1
        },
        CheckAPIResponse: function(t, e) {
            if (SYNO.SDS.HandShake.IsSupport() && "unauth" === this.GetHeaderError(e)) return Ext.isEmpty(SYNO.SDS.Session.DelayAjax) && (SYNO.SDS.Session.DelayAjax = []), SYNO.SDS.Session.DelayAjax.push(t), !0 === SYNO.SDS.Session.updateSession ? (SYNO.SDS.Session.DelayAjax.push(t), !1) : (SYNO.SDS.Session.updateSession = !0, SYNO.SDS.HandShake.TryResumeSession().then(function(t) {
                SYNO.SDS.Session.updateSession = !1, t ? SYNO.SDS.Session.DelayAjax.forEach(function(t) {
                    t.headers["X-SYNO-HASH"] && (t.headers["X-SYNO-HASH"] = SYNO.SDS.HandShake.Encrypt("")), Ext.Ajax.request(t)
                }) : SYNO.SDS.Utils.Logout.action(!0, SYNO.API.Errors.common[106], !0, !1), SYNO.SDS.Session.DelayAjax = void 0
            }), !1)
        },
        GetInstance: function(t) {
            var e = SYNO.SDS.HandShake._noise,
                i = Ext.util.Cookies.get("_SSID");
            if (i) {
                var s = SYNO.SDS.CrossPortStorage.GetItem("_HSID");
                if (!s) {
                    if ("Noise_IK_25519_ChaChaPoly_BLAKE2b" !== t) return;
                    s = sodium.to_base64(e.CreateKeyPair(e.constants.NOISE_DH_CURVE25519)[0]), SYNO.SDS.CrossPortStorage.PromoteLocal(), SYNO.SDS.CrossPortStorage.SetItem("_HSID", s)
                }
                var n = e.constants.NOISE_ROLE_INITIATOR,
                    o = e.HandshakeState(t, n),
                    a = sodium.from_base64(s),
                    r = sodium.from_base64(i);
                return o.Initialize(null, a, r, null), o
            }
        },
        Write: function(t) {
            var e = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
            return sodium.to_base64(t.WriteMessage(e))
        },
        Read: function(t, i) {
            t.ReadMessage(sodium.from_base64(i), !0), e = t.Split(), e[0].n = 0, e[1].n = 0
        },
        Encrypt: function() {
            arguments.length > 0 && void 0 !== arguments[0] && arguments[0], arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
            return e ? sodium.to_base64(e[0].EncryptWithAd(new Uint8Array, new Uint8Array)) + "." + sodium.to_base64("" + e[0].n++) : ""
        },
        IsSupport: function() {
            return ("http:" !== window.location.protocol || !0 !== _S("is_secure")) && void 0 !== SYNO.SDS.HandShake._noise
        },
        UnSupport: function() {
            SYNO.SDS.HandShake._noise = void 0
        },
        TryResumeSession: function() {
            return new Promise(function(t, e) {
                var i = SYNO.SDS.HandShake.GetInstance("Noise_KK_25519_ChaChaPoly_BLAKE2b");
                if (!i) return t(!1);
                var s = SYNO.SDS.CrossPortStorage.GetItem("currentLoginUser");
                if (!s) return t(!1);
                synowebapi.request({
                    url: "webapi/entry.cgi?api=SYNO.API.Auth",
                    requestFormat: "raw",
                    responseFormat: "raw",
                    method: "POST",
                    params: {
                        api: "SYNO.API.Auth",
                        version: 7,
                        method: "resume",
                        kk_message: SYNO.SDS.HandShake.Write(i),
                        hhid: SYNO.SDS.HandShake._hhid,
                        account: s
                    },
                    callback: function(e, s) {
                        if (!s.data || !s.data.kk_message) return t(!1);
                        SYNO.SDS.HandShake.Read(i, s.data.kk_message), SYNO.SDS.Session.isLogined = !0, t(!0)
                    }
                })
            })
        }
    }
}(), Ext.namespace("SYNO.SDS.Gesture"), SYNO.SDS.Gesture.EmptyGesture = Ext.extend(Ext.util.Observable, {
    onTouchStart: Ext.emptyFn,
    onTouchMove: Ext.emptyFn,
    onTouchEnd: Ext.emptyFn,
    onTouchCancel: Ext.emptyFn
}), SYNO.SDS.Gesture.BaseGesture = Ext.extend(SYNO.SDS.Gesture.EmptyGesture, {
    constructor: function() {
        SYNO.SDS.Gesture.BaseGesture.superclass.constructor.apply(this, arguments)
    },
    getBrowserEvent: function(t) {
        return t && t.browserEvent ? t.browserEvent : null
    },
    getFirstTouch: function(t) {
        var e, i = null;
        return e = this.getBrowserEvent(t), e && e.touches && e.touches.length > 0 && (i = e.touches[0]), i
    },
    getFirstChangedTouch: function(t) {
        var e, i = null;
        return e = this.getBrowserEvent(t), e && e.changedTouches && e.changedTouches.length > 0 && (i = e.changedTouches[0]), i
    },
    getChangedTouchCount: function(t) {
        var e;
        return e = this.getBrowserEvent(t), e && e.changedTouches && Ext.isNumber(e.changedTouches.length) ? e.changedTouches.length : -1
    },
    getTouchCount: function(t) {
        var e;
        return e = this.getBrowserEvent(t), e && e.touches && Ext.isNumber(e.touches.length) ? e.touches.length : -1
    }
}), SYNO.SDS.Gesture.Swipe = Ext.extend(SYNO.SDS.Gesture.BaseGesture, {
    config: {
        minDistance: 80,
        maxOffset: 100,
        maxDuration: 1e3
    },
    fireSwipe: function(t, e, i, s, n) {
        SYNO.SDS.GestureMgr.fireEvent("swipe", t, e, i, s, n)
    },
    getMinDistance: function() {
        return this.config.minDistance
    },
    getMaxOffset: function() {
        return this.config.maxOffset
    },
    getMaxDuration: function() {
        return this.config.maxDuration
    },
    setInitialXY: function(t) {
        var e, i, s;
        for (e = 0, i = t.changedTouches.length; e < i; e++) s = t.changedTouches[e], this.initialTouches[s.identifier] = {
            x: s.pageX,
            y: s.pageY
        }
    },
    getInitialXY: function(t) {
        var e = this.initialTouches[t.identifier];
        return {
            x: e.x,
            y: e.y
        }
    },
    onTouchStart: function(t, e, i) {
        var s = this.getBrowserEvent(t);
        this.startTime = s.timeStamp, this.isHorizontal = !0, this.isVertical = !0, this.initialTouches || (this.initialTouches = {}), this.setInitialXY(s), this.touchCount = this.getTouchCount(t)
    },
    onTouchMove: function(t, e, i) {
        return 3 === this.getTouchCount(t) && (t.preventDefault(), this.checkTouchMove(t, e, i))
    },
    checkTouchXY: function(t, e, i) {
        var s, n, o, a;
        if (s = t.pageX, n = t.pageY, o = Math.abs(s - e), a = Math.abs(n - i), this.isVertical && o > this.getMaxOffset() && (this.isVertical = !1), this.isHorizontal && a > this.getMaxOffset() && (this.isHorizontal = !1), !this.isHorizontal && !this.isVertical) return this.fail()
    },
    checkTouchMove: function(t, e, i) {
        var s, n, o, a, r;
        if (a = this.getBrowserEvent(t), a.timeStamp - this.startTime > this.getMaxDuration()) return this.fail();
        for (s = 0, r = a.changedTouches.length; s < r; s++)
            if (o = a.changedTouches[s], n = this.initialTouches[o.identifier]) {
                if (!1 === this.checkTouchXY(o, n.x, n.y)) return !1
            } else SYNO.Debug.error("Error: initial does not exist when handle touchmove, TouchEvent id:" + o.identifier)
    },
    onTouchEnd: function(t, e, i) {
        var s, n, o, a, r, l, h, d, c, u, f, p;
        if (0 !== this.getTouchCount(t)) return !1;
        if (3 !== this.touchCount) return !1;
        if (!(s = this.getFirstChangedTouch(t))) return !1;
        if (n = s.pageX, o = s.pageY, a = this.getInitialXY(s), r = n - a.x, l = o - a.y, h = Math.abs(r), d = Math.abs(l), c = this.getMinDistance(), u = t.browserEvent.timeStamp - this.startTime, this.isVertical && d < c && (this.isVertical = !1), this.isHorizontal && h < c && (this.isHorizontal = !1), this.isHorizontal) f = r < 0 ? "left" : "right", p = h;
        else {
            if (!this.isVertical) return this.fail();
            f = l < 0 ? "up" : "down", p = d
        }
        this.fireSwipe(t, s, f, p, u)
    },
    fail: function() {
        return !1
    }
}), SYNO.SDS.Gesture.LongPress = Ext.extend(SYNO.SDS.Gesture.BaseGesture, {
    config: {
        minDuration: 500
    },
    fireLongPress: function(t, e) {
        SYNO.SDS.GestureMgr.fireEvent("longpress", t, e)
    },
    getMinDuration: function() {
        return this.config.minDuration
    },
    onTouchStart: function(t, e, i) {
        var s = this;
        this.timer && this.removeTimer(), this.timer = setTimeout(function() {
            s.fireLongPress(t, e), this.timer = null
        }, this.getMinDuration())
    },
    onTouchMove: function() {
        return this.fail()
    },
    onTouchEnd: function(t, e, i) {
        return this.fail()
    },
    removeTimer: function() {
        clearTimeout(this.timer), this.timer = null
    },
    fail: function() {
        return this.removeTimer(), !1
    }
}), SYNO.SDS.Gesture.DoubleTap = Ext.extend(SYNO.SDS.Gesture.BaseGesture, {
    config: {
        maxDuration: 300,
        maxOffset: 50
    },
    singleTapTimer: null,
    fireSingleTap: function(t, e) {},
    fireDoubleTap: function(t, e) {
        t.preventDefault(), SYNO.SDS.GestureMgr.fireEvent("doubletap", t, e)
    },
    getMaxDuration: function() {
        return this.config.maxDuration
    },
    getMaxOffset: function() {
        return this.config.maxOffset
    },
    onTouchStart: function(t, e, i) {
        t && t.browserEvent && this.isInMaxDuration(t.browserEvent.timeStamp, this.lastTapTime) && t.preventDefault()
    },
    onTouchMove: function() {
        return this.fail()
    },
    onTouchEnd: function(t, e, i) {
        var s, n, o, a, r = this.lastTapTime,
            l = this.lastX,
            h = this.lastY;
        return this.getTouchCount(t) > 0 ? this.fail() : (t && t.browserEvent && (s = t.browserEvent.timeStamp), this.lastTapTime = s, !!(n = this.getFirstChangedTouch(t)) && (o = n.pageX, a = n.pageY, this.lastX = o, this.lastY = a, r && this.checkXY(l, h) && this.isInMaxDuration(s, r) ? (this.lastTapTime = 0, void this.fireDoubleTap(t, e)) : void 0))
    },
    checkXY: function(t, e) {
        var i = Math.abs(this.lastX - t),
            s = Math.abs(this.lastY - e),
            n = this.getMaxOffset();
        return i < n && s < n
    },
    isInMaxDuration: function(t, e) {
        return !(!t || !e) && t - e <= this.getMaxDuration()
    },
    fail: function() {
        return this.lastTapTime = 0, this.lastX = void 0, this.lastY = void 0, !1
    }
}), Ext.ns("SYNO.SDS.Gesture.MS"), SYNO.SDS.Gesture.MS.Swipe = Ext.extend(SYNO.SDS.Gesture.Swipe, {
    config: {
        minDistance: 80,
        maxOffset: 500,
        maxDuration: 1e3
    },
    constructor: function() {
        var t = this;
        SYNO.SDS.Gesture.MS.Swipe.superclass.constructor.apply(t, arguments)
    },
    setInitialXY: function(t) {
        this.initialTouches[t.pointerId] = {
            x: t.pageX,
            y: t.pageY
        }
    },
    getTouchCount: function() {
        var t, e = 0;
        if (this.initialTouches)
            for (t in this.initialTouches) this.initialTouches.hasOwnProperty(t) && e++;
        return e
    },
    checkTouchXY: function(t, e, i) {
        var s, n, o, a;
        if (s = t.pageX, n = t.pageY, o = Math.abs(s - e), a = Math.abs(n - i), this.isVertical && o > this.getMaxOffset() && (this.isVertical = !1), this.isHorizontal && a > this.getMaxOffset() && (this.isHorizontal = !1), !this.isHorizontal && !this.isVertical) return this.fail()
    },
    checkTouchMove: function(t, e, i) {
        var s, n;
        if (n = this.getBrowserEvent(t), n.timeStamp - this.startTime > this.getMaxDuration()) return this.fail();
        for (s in this.initialTouches)
            if (this.initialTouches.hasOwnProperty(s)) {
                var o, a = this.initialTouches[s];
                if (n && n.touches && n.touches.length > 0 && (o = n.touches[0]), !a) {
                    SYNO.Debug.error("Error: initial does not exist when handle touchmove, TouchEvent id:" + o.identifier);
                    continue
                }
                if (!1 === this.checkTouchXY(n, a.x, a.y)) return !1
            }
    },
    onTouchStart: function(t, e, i) {
        var s = this.getBrowserEvent(t);
        this.startTime = s.timeStamp, this.isHorizontal = !0, this.isVertical = !0, this.initialTouches || (this.initialTouches = {}), this.setInitialXY(s), this.touchCount = this.getTouchCount()
    },
    onTouchMove: function(t, e, i) {
        return 3 === this.getTouchCount() && (t.preventDefault(), this.checkTouchMove(t, e, i))
    },
    onTouchEnd: function(t, e, i) {
        var s, n, o, a, r, l, h, d, c, u, f, p = this.getBrowserEvent(t);
        if (!this.initialTouches || !this.initialTouches[p.pointerId]) return !1;
        if (f = this.initialTouches[p.pointerId], delete this.initialTouches[p.pointerId], 0 !== this.getTouchCount()) return !1;
        if (3 !== this.touchCount) return !1;
        if (s = p.pageX, n = p.pageY, o = s - f.x, a = n - f.y, r = Math.abs(o), l = Math.abs(a), h = this.getMinDistance(), d = p.timeStamp - this.startTime, this.isVertical && l < h && (this.isVertical = !1), this.isHorizontal && r < h && (this.isHorizontal = !1), this.isHorizontal) c = o < 0 ? "left" : "right", u = r;
        else {
            if (!this.isVertical) return this.fail();
            c = a < 0 ? "up" : "down", u = l
        }
        this.fireSwipe(t, void 0, c, u, d)
    },
    onTouchCancel: function() {
        this.fail(), delete this.initialTouches
    }
}), SYNO.SDS.Gesture.EmptyGestureObject = new SYNO.SDS.Gesture.EmptyGesture, SYNO.SDS.Gesture.MS.EmptyGestureObject = SYNO.SDS.Gesture.EmptyGestureObject, SYNO.SDS.Gesture.GestureFactory = Ext.extend(Object, {
    create: function(t) {
        var e = SYNO.SDS.UIFeatures.test("msPointerEnabled"),
            i = "SYNO.SDS.Gesture." + (e ? "MS." : "");
        switch (t) {
            case "Swipe":
                if (e && (window.navigator.msMaxTouchPoints ? window.navigator.msMaxTouchPoints : 0) < 3) return SYNO.SDS.Gesture.MS.EmptyGestureObject;
                i += t;
                break;
            case "LongPress":
            case "DoubleTap":
                if (e) return SYNO.SDS.Gesture.MS.EmptyGestureObject;
                i += t;
                break;
            default:
                return e ? SYNO.SDS.Gesture.MS.EmptyGestureObject : SYNO.SDS.Gesture.EmptyGestureObject
        }
        return this.getGestureInstance(i)
    },
    getGestureInstance: function(t) {
        return new(Ext.getClassByName(t))
    }
}), Ext.namespace("SYNO.SDS._GestureMgr"), SYNO.SDS._GestureMgr = Ext.extend(Ext.util.Observable, {
    constructor: function() {
        SYNO.SDS._GestureMgr.superclass.constructor.apply(this, arguments), this.gestures = ["Swipe", "LongPress", "DoubleTap"], this.init()
    },
    init: function() {
        var t, e, i, s, n = SYNO.SDS.UIFeatures.test("msPointerEnabled");
        for (i = Ext.getDoc(), t = 0, e = this.gestures.length; t < e; t++) s = this.getGestureInstance(this.gestures[t]), Ext.EventManager.on(i, n ? "MSPointerCancel" : "touchcancel", s.onTouchCancel, s), Ext.EventManager.on(i, n ? "MSPointerDown" : "touchstart", s.onTouchStart, s), Ext.EventManager.on(i, n ? "MSPointerUp" : "touchend", s.onTouchEnd, s), Ext.EventManager.on(i, n ? "MSPointerMove" : "touchmove", s.onTouchMove, s);
        this.addGestureHandlers()
    },
    addGestureHandlers: function() {
        this.on("swipe", this.swipeHandler, this, {
            buffer: 10
        }), this.on("longpress", this.longPressHandler, this), this.on("doubletap", this.doubleTapHandler, this)
    },
    getGestureInstance: function(t) {
        return this.gestureFactory = this.gestureFactory || new SYNO.SDS.Gesture.GestureFactory, this.gestureFactory.create(t)
    },
    swipeHandler: function(t, e, i, s, n) {
        var o;
        "right" === i ? SYNO.SDS.TaskButtons.setRightWindowActive() : "left" === i ? SYNO.SDS.TaskButtons.setLeftWindowActive() : "up" === i && (o = SYNO.SDS.WindowMgr.getActiveAppWindow()) && o.minimize()
    },
    longPressHandler: function(t, e) {
        var i, s, n;
        for (i = this.findEventHandlers(e, "contextmenu"), s = 0, n = i.length; s < n; s++) i[s](t.browserEvent)
    },
    doubleTapHandler: function(t, e) {
        var i, s, n;
        for (i = this.findEventHandlers(e, "dblclick"), s = 0, n = i.length; s < n; s++) i[s](t.browserEvent)
    },
    findEventHandlers: function(t, e) {
        for (var i, s, n, o, a = Ext.get(t), r = []; a;) {
            i = Ext.EventManager.getListeners(a, e); {
                if (i) {
                    for (s = 0, n = i.length; s < n; s++) o = i[s], r.push(o[1]);
                    break
                }
                a = a.parent()
            }
        }
        return r
    }
}), Ext.namespace("SYNO.SDS.AppWindow"), Ext.define("SYNO.SDS.FullScreenToolbar", {
    extend: "Ext.Container",
    constructor: function(t) {
        if (!(t.appWin && t.appWin instanceof SYNO.SDS.AppWindow)) return void SYNO.Debug.error("Need to add appWin in config!");
        this.offsetX = t && t.offset ? t.offset[0] : 0, this.offsetY = t && t.offset ? t.offset[1] : 0, this.callParent([this.fillConfig(t)])
    },
    fillConfig: function(t) {
        this.contentBox = new Ext.BoxComponent({
            cls: "syno-sds-fullscreen-toolbar-content-container"
        });
        var e = {
            hideMode: "offset",
            cls: "syno-sds-fullscreen-toolbar",
            renderTo: SYNO.SDS.Desktop.getEl(),
            items: [this.contentBox]
        };
        return Ext.apply(e, t)
    },
    adjustPos: function() {
        var t = "tl",
            e = [_S("standalone") ? 10 : 0, _S("standalone") ? 10 : 0],
            i = this.appWin.fsHandler,
            s = this.el.parent();
        i ? (s = i.el, t = "br", e[0] -= this.el.getWidth()) : "b" === this.dir ? (t = "bl", e[1] -= _S("standalone") ? this.el.getHeight() + 10 : this.el.getHeight()) : "r" === this.dir && (t = "tr", e[0] -= _S("standalone") ? this.el.getWidth() + 10 : this.el.getWidth()), e[0] += this.offsetX, e[1] += this.offsetY, this.el.alignTo(s, t, e), this.el.applyStyles({
            zIndex: parseInt(this.appWin.el.getStyle("zIndex"), 10) + 1
        })
    },
    cancleHideTask: function() {
        this.hideTask || (this.hideTask = new Ext.util.DelayedTask(this.hide, this)), this.hideTask.delay(2e3)
    },
    show: function(t, e) {
        this.cancleHideTask(), this.adjustPos(), this.el.hasClass("dissolve-in") || (this.removeClass("dissolve-out"), this.addClass("dissolve-in"))
    },
    hide: function(t) {
        if (t) return Ext.each(this.contentBox.el.dom.childNodes, function(t) {
            var e = Ext.get(t);
            e.orgParent.appendChild(e)
        }), this.removeParentClsFromContentBox(), void this.callParent();
        this.el.hasClass("dissolve-in") && (this.removeClass("dissolve-in"), this.addClass("dissolve-out")), this.hideTask && (this.hideTask = null)
    },
    addParentClsToContentBox: function(t) {
        Ext.isArray(t) ? Ext.each(t, this.addParentClsToContentBox, this) : Ext.isString(t) && (this.contentBox.addClass(t), this.contentBox.addedCls || (this.contentBox.addedCls = []), this.contentBox.addedCls.push(t))
    },
    removeParentClsFromContentBox: function() {
        this.contentBox.addedCls && this.contentBox.addedCls.each(function(t) {
            this.contentBox.removeClass(t)
        }, this)
    },
    addElements: function(t) {
        Ext.isArray(t) ? Ext.each(t, this.addElements, this) : Ext.isObject(t) && t instanceof Ext.Element && (t.orgParent = t.parent(), this.contentBox.el.appendChild(t))
    }
}), Ext.define("SYNO.SDS.AppWindow", {
    extend: "SYNO.SDS.BaseWindow",
    moveDirty: !1,
    resizeDirty: !1,
    autoCenter: !0,
    initialized: !1,
    taskButton: null,
    ariaRole: "application",
    constructor: function(t) {
        var e;
        t = Ext.apply({}, t, {
            useStatusBar: Ext.isDefined(t.buttons),
            showHelp: !0,
            toggleGrayOverlay: !0,
            toggleFullScreen: !1,
            autoCenter: !0
        }), t = Ext.apply(t, {
            title: null,
            iconCls: "x-panel-icon",
            openConfig: {
                dsm_version: _S("majorversion") + "." + _S("minorversion")
            }
        }), !_S("standalone") && t.appInstance && (!0 === t.autoStart || !0 !== t.fromRestore && !1 !== t.autoRestoreSizePos) && Ext.apply(t, this.getRestoreSizePos(t)), !_S("standalone") && t.showHelp && (Ext.isArray(t.tools) || (t.tools = []), t.tools.push({
            id: "help",
            text: _T("common", "alt_help"),
            scope: this,
            handler: this.onClickHelp
        })), t.toggleFullScreen && SYNO.SDS.UIFeatures.test("isSupportFullScreen") && (this.isFullScreen = !1, Ext.isArray(t.tools) || (t.tools = []), t.tools.push({
            id: "fullscreen",
            text: _T("personal_settings", "menu_style_fullscreen"),
            scope: this,
            handler: this.onClickFullScrren
        })), e = !Ext.isDefined(t.maximizable) || t.maximizable;
        var i = !!t.appInstance && t.appInstance.blMainApp;
        if (_S("standalone")) {
            if (i) Ext.apply(t, {
                maximizable: !1,
                maximized: e,
                closable: !1,
                modal: !1
            }), t.cls = (t.cls || "") + (this.cls || "") + " sds-standalone-main-window", "true" === _S("remove_banner") && (t.cls += " sds-standalone-main-window--no-banner"), document.title = t.title || document.title;
            else if (Ext.apply(t, {
                    maximizable: !1,
                    maximized: !1,
                    closable: !0,
                    modal: !0
                }), e) {
                Ext.EventManager.onWindowResize(this.onModalWindowResize, this), Ext.apply(t, {
                    x: 10,
                    y: 10,
                    width: Ext.lib.Dom.getViewWidth() - 20,
                    height: Ext.lib.Dom.getViewHeight() - 20
                })
            }
            Ext.apply(t, {
                resizable: !1,
                draggable: !1,
                minimizable: !1
            })
        }
        if ((_S("isMobile") || Ext.isIE10Touch) && e && Ext.apply(t, {
                maximized: !0
            }), t = this.overwriteAppWinConfig(t), SYNO.SDS.AppWindow.superclass.constructor.call(this, t), t.maximized ? SYNO.SDS.StatusNotifier.fireEvent("windowMaximize") : (_S("standalone") && this.anchorTo(this.container, "c-c"), (_S("isMobile") || Ext.isIE10Touch) && this.anchorTo(this.container, "t-t")), this.mon(this, "move", this.onWindowMove, this), this.resizer && this.mon(this.resizer, "resize", this.onHandlerResize, this), t.toggleFullScreen && this.bindFullScreenEvents(), _S("standalone") && i) {
            var s, n = this.getSmallIcon(!0);
            s = SYNO.SDS.UIFeatures.test("isRetina") ? [32, 64, 256] : [16, 32, 128], Ext.each(s, function(t) {
                n.indexOf("webman/3rdparty/") >= 0 ? SYNO.SDS.Utils.addFavIconLink(n.replace(/(res=)(\d)*/, "$1" + t), "image/png", t + "x" + t) : SYNO.SDS.Utils.addFavIconLink(n.replace(/(_16|_32)/, "_" + t), "image/png", t + "x" + t)
            }), this.mon(this, "titlechange", function() {
                document.title = this.title || document.title
            }, this)
        }!0 === this.splitWindow && this.addClass("x-window-split")
    },
    getTrait: function() {
        return this.jsConfig && this.jsConfig.jsID ? this.jsConfig.jsID : this.callParent()
    },
    _onBeforeMaximize: function() {
        return SYNO.SDS.StatusNotifier.fireEvent("windowBeforeMaximize", this), this.callParent()
    },
    _onMinimize: function() {
        return SYNO.SDS.StatusNotifier.fireEvent("windowMinimize", this), this.callParent()
    },
    _onActivate: function() {
        return SYNO.SDS.StatusNotifier.fireEvent("windowActivate", this), this.callParent()
    },
    _onRestore: function() {
        return SYNO.SDS.StatusNotifier.fireEvent("windowRestore", this), this.callParent()
    },
    _onClose: function() {
        return SYNO.SDS.StatusNotifier.fireEvent("windowClose", this), this.callParent()
    },
    bindFullScreenEvents: function() {
        document.fullscreenEnabled ? document.addEventListener("fullscreenchange", this.handleFSChange.createDelegate(this), !1) : document.webkitFullscreenEnabled ? document.addEventListener("webkitfullscreenchange", this.handleFSChange.createDelegate(this), !1) : document.mozFullScreenEnabled ? document.addEventListener("mozfullscreenchange", this.handleFSChange.createDelegate(this), !1) : document.msFullscreenEnabled && document.addEventListener("MSFullscreenChange", this.handleFSChange.createDelegate(this), !1)
    },
    isAlwaysOnTop: function() {
        if (!0 === this.toggleFullScreen && !0 === this.isFullScreen) return !0
    },
    handleFSChange: function() {
        if (this.isFullScreen) {
            if (SYNO.SDS.UIFeatures.isFullScreenMode()) {
                if (!1 === this.fireEvent("beforeenablefullscreen")) return;
                _S("standalone") || (SYNO.SDS.TaskBar.hide(), SYNO.SDS.Desktop.getEl().setStyle({
                    top: "0px",
                    zIndex: 0,
                    height: window.screen.height + "px"
                }), this.lastStateMaximized = this.maximized, this.lastStateMaximized ? (this.setPosition(0, 0), this.fitContainer()) : this.toggleMaximize()), this.hideTools(), this.fireEvent("windowfullscreenenabled")
            } else {
                if (!1 === this.fireEvent("beforedisablefullscreen")) return;
                this.isFullScreen = !1, this.showTools(), _S("standalone") || (this.lastStateMaximized ? (SYNO.SDS.TaskBar && this.setPosition(0, SYNO.SDS.TaskBar.height()), this.fitContainer()) : this.toggleMaximize(), SYNO.SDS.Desktop.getEl().setStyle({
                    zIndex: "",
                    height: Ext.getBody().getHeight() + "px"
                }), SYNO.SDS.TaskBar.show()), this.fireEvent("windowfullscreendisabled")
            }
            SYNO.SDS.WindowMgr.orderWindows()
        }
    },
    showFSToolbar: function() {
        this.fsToolbar.show()
    },
    initFSToolbar: function(t, e, i, s, n) {
        e = e || "t", this.fsToolbar || (this.fsToolbar = new SYNO.SDS.FullScreenToolbar({
            appWin: this,
            dir: e,
            offset: n
        })), t && this.fsToolbar.addElements(t, i), i && this.fsToolbar.addParentClsToContentBox(i), !0 === s && this.fsToolbar.show(), this.el.on("mousemove", this.showFSToolbar, this), this.el.on("click", this.showFSToolbar, this)
    },
    destroyFSToolbar: function(t) {
        this.el.un("mousemove", this.showFSToolbar, this), this.el.un("click", this.showFSToolbar, this), this.fsToolbar && this.fsToolbar.hide(!t)
    },
    overwriteAppWinConfig: function(t) {
        return t
    },
    genIndPortHeader: function() {
        var t = this.el.createChild({
                tag: "div",
                cls: "sds-standalone-main-window-header"
            }, this.header.dom),
            e = !1 === this.showHelp;
        new Ext.Toolbar({
            renderTo: t,
            toolbarCls: "sds-standalone-main-window-header__toolbar",
            buttonAlign: "right",
            items: [{
                xtype: "syno_button",
                cls: "sds-standalone-main-window-header__toolbar__btn",
                text: _S("user"),
                scope: this,
                menu: new SYNO.ux.Menu({
                    cls: "sds-standalone-main-window-header__toolbar__menu",
                    items: [{
                        cls: "sds-standalone-logout",
                        iconCls: "sds-standalone-logout-icon",
                        text: _T("common", "logout"),
                        scope: this,
                        hidden: !_S("rewrite_mode") || e,
                        handler: function() {
                            SYNO.SDS.StatusNotifier.fireEvent("logout"), window.onbeforeunload = SYNO.SDS.onBasicBeforeUnload;
                            try {
                                SYNO.SDS.Utils.Logout.action()
                            } catch (t) {}
                        }
                    }, {
                        cls: "sds-standalone-help",
                        iconCls: "sds-standalone-help-icon",
                        text: _T("common", "alt_help"),
                        hidden: e,
                        scope: this,
                        handler: this.onClickHelp
                    }]
                })
            }],
            listeners: {
                scope: this,
                single: !0,
                buffer: 80
            }
        })
    },
    afterRender: function() {
        SYNO.SDS.AppWindow.superclass.afterRender.apply(this, arguments), _S("standalone") && this.alignTo(document.body, "c-c"), this.isStandaloneMainWindow() && (this.header.dom.innerHTML = '<div class="sds-standalone-main-window-header-text">' + this.header.dom.innerHTML + "</div>", "true" !== _S("remove_banner") && this.genIndPortHeader()), !0 === this.maximized && 0 == this.minimized && SYNO.SDS.StatusNotifier && SYNO.SDS.StatusNotifier.fireEvent("windowMaximize", this), !1 === this.autoCenter || _S("standalone") || this.centerItIfOutOfBound()
    },
    destroy: function() {
        _S("standalone") && Ext.EventManager.removeResizeListener(this.onModalWindowResize, this), this.aboutWindow && this.aboutWindow.destroy(), SYNO.SDS.AppWindow.superclass.destroy.apply(this, arguments)
    },
    onModalWindowResize: function() {
        this.setPosition(10, 10), this.setSize(Ext.lib.Dom.getViewWidth() - 20, Ext.lib.Dom.getViewHeight() - 20)
    },
    isStandaloneMainWindow: function() {
        return _S("standalone") && this.appInstance && this.appInstance.blMainApp
    },
    getSmallIcon: function(t) {
        var e, i = this.jsConfig.jsBaseURL + "/" + (this.jsConfig.icon || this.jsConfig.icon_16),
            s = this.isStandaloneMainWindow();
        return e = t ? "FavHeader" : s ? "StandaloneHeader" : this.isV5Style() ? "Header" : "HeaderV4", SYNO.SDS.UIFeatures.IconSizeManager.getIconPath(i, e)
    },
    init: function() {
        this.initialized || (!1 !== this.toggleMinimizable && this.setIcon(this.getSmallIcon()), _S("standalone") || !1 === this.toggleMinimizable || (this.taskButton = this.appInstance.taskButton || SYNO.SDS.TaskButtons.add(this.appInstance.jsConfig.jsID, this.jsConfig.jsID), this.taskButton.init(this), this.taskButton.setState("deactive"), this.addManagedComponent(this.taskButton)), this.setTitle(SYNO.SDS.UIString.GetLocalizedString(this.getTitle(), this.appInstance.jsConfig.jsID)), this.initialized = !0)
    },
    onBeforeDestroy: function() {
        SYNO.SDS.AppWindow.superclass.onBeforeDestroy.apply(this, arguments), this.taskButton = null
    },
    showAboutWindow: function() {
        var t = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
        this.aboutWindow || (this.aboutWindow = Vue.extend({
            template: '<v-about-window :syno-id="synoId" :name="name" :custom-name="customName" :desc="desc" :icon="icon" :copyright-year="copyrightYear" :is-beta="isBeta" :swap-name-and-desc="swapNameAndDesc" :theme="theme" :class="customCls" />',
            props: ["synoId", "name", "customName", "desc", "icon", "copyrightYear", "isBeta", "swapNameAndDesc", "theme", "customCls"]
        }));
        var e = this.getJsConfig();
        this.openVueWindow(this.aboutWindow, {
            synoId: t.synoId || e.jsID,
            name: SYNO.SDS.UIString.GetLocalizedString(this.getTitle(), e.jsID),
            customName: Array.isArray(e.customAboutTitle) ? [SYNO.SDS.UIString.GetLocalizedString(e.customAboutTitle[0], e.jsID), SYNO.SDS.UIString.GetLocalizedString(e.customAboutTitle[1], e.jsID)] : null,
            desc: t.desc || "",
            icon: SYNO.SDS.UIFeatures.IconSizeManager.getIconPath(e.jsBaseURL + "/" + (e.icon || e.icon_32), "desktop"),
            copyrightYear: e.buildTime ? e.buildTime.split("-")[0] : _S && _S("builddate") ? _S("builddate").split("/")[0] : "",
            isBeta: void 0 !== t.isBeta ? t.isBeta : this.isBeta || !1,
            swapNameAndDesc: t.swapNameAndDesc || !1,
            theme: t.theme || {},
            customCls: t.customCls || ""
        })
    },
    hideAboutWindow: function() {
        this.aboutWindow && this.aboutWindow.hide()
    },
    showTools: function() {
        var t, e = this.maximized;
        for (t in this.tools)
            if (this.tools.hasOwnProperty(t)) {
                if (!this.maximizable && "maximize" === t || !this.maximizable && "restore" === t || e && "maximize" === t || !e && "restore" === t) continue;
                "fullscreen" == t && this.tools[t].removeClass("collapse"), this.tools[t].show()
            }
    },
    hideTools: function() {
        var t;
        for (t in this.tools)
            if (this.tools.hasOwnProperty(t)) {
                if ("fullscreen" === t) {
                    this.tools[t].addClass("collapse");
                    continue
                }
                this.tools[t].hide()
            }
    },
    onClickFullScrren: function() {
        var t = SYNO.SDS.Desktop.getEl().dom;
        SYNO.SDS.UIFeatures.isFullScreenMode() ? document.exitFullscreen ? document.exitFullscreen() : document.msExitFullscreen ? document.msExitFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitExitFullscreen && document.webkitExitFullscreen() : (this.isFullScreen = !0, t.requestFullscreen ? t.requestFullscreen() : t.msRequestFullscreen ? t.msRequestFullscreen() : t.mozRequestFullScreen ? t.mozRequestFullScreen() : t.webkitRequestFullscreen && t.webkitRequestFullscreen())
    },
    onClickHelp: function() {
        var t = this.appInstance ? this.appInstance.jsConfig.jsID : this.jsConfig.jsID,
            e = this.getHelpParam();
        Ext.isString(e) && e.length && (t += ":" + e), _S("standalone") ? SYNO.SDS.WindowLaunch("SYNO.SDS.HelpBrowser.Application", {
            topic: t
        }) : SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
            topic: t
        }, !1)
    },
    getHelpParam: Ext.emptyFn,
    setTitle: function(t, e, i) {
        if (SYNO.SDS.AppWindow.superclass.setTitle.apply(this, arguments), this.taskButton) {
            var s = !1 !== i ? Ext.util.Format.htmlEncode(t) : t;
            this.taskButton.setTooltip(s)
        }
    },
    getTitle: function() {
        var t = this.getJsConfig();
        return this.title || t.title
    },
    getJsConfig: function() {
        return this.appInstance ? this.appInstance.jsConfig : this.jsConfig
    },
    updateTaskButton: function(t) {
        this.taskButton && this.taskButton.updateContextMenu(t)
    },
    restore: function() {
        !0 !== this.isFullScreen && SYNO.SDS.AppWindow.superclass.restore.call(this)
    },
    onHeaderContextMenu: function(t) {
        !0 !== this.isFullScreen && (SYNO.SDS.AppWindow.superclass.onHeaderContextMenu.apply(this, arguments), _S("standalone") || this.taskButton.getContextMenu(!1).showAt(t.getXY()))
    },
    onMaximize: function() {
        SYNO.SDS.AppWindow.superclass.onMaximize.apply(this, arguments), this.updateTaskButton("maximize"), this.saveRestoreData()
    },
    onMinimize: function() {
        _S("standalone") || (this.minimizable ? this.hide() : this.el.frame(), SYNO.SDS.AppWindow.superclass.onMinimize.apply(this, arguments), this.updateTaskButton("minimize"))
    },
    onRestore: function() {
        SYNO.SDS.AppWindow.superclass.onRestore.apply(this, arguments), this.updateTaskButton("restore"), this.saveRestoreData()
    },
    mask: function() {
        SYNO.SDS.AppWindow.superclass.mask.apply(this, arguments), this.updateTaskButton("mask")
    },
    unmask: function() {
        SYNO.SDS.AppWindow.superclass.unmask.apply(this, arguments), this.updateTaskButton("unmask")
    },
    onWindowMove: function() {
        this.moveDirty = !0, this.saveRestoreData()
    },
    onHandlerResize: function() {
        this.resizeDirty = !0, this.saveRestoreData()
    },
    saveRestoreData: function() {
        var t = this.appInstance.getUserSettings("restoreSizePos"),
            e = Ext.apply(this.getSizeAndPosition(), {
                fromRestore: !0,
                maximized: this.maximized
            });
        t && (this.moveDirty ? this.moveDirty = !1 : (t.pageX && (e.pageX = t.pageX), t.pageY && (e.pageY = t.pageY)), this.resizeDirty ? this.resizeDirty = !1 : (t.width && (e.width = t.width), t.height && (e.height = t.height))), this.appInstance.setUserSettings("restoreSizePos", e)
    },
    adjustPageXY: function(t) {
        return t ? (Ext.isDefined(t.pageX) && t.pageX < 0 && (t.pageX = 0), Ext.isDefined(t.pageY) && t.pageY < 0 && (t.pageY = 0), Ext.isDefined(t.x) && t.x < 0 && (t.x = 0), Ext.isDefined(t.y) && t.y < 0 && (t.y = 0), t) : {}
    },
    isOutOfBound: function() {
        var t = Ext.lib.Dom.getViewWidth(!0),
            e = Ext.lib.Dom.getViewHeight(!0);
        if (Ext.isDefined(this.pageX) && (this.pageX < 0 || this.pageX + this.width > t)) return !0;
        var i = SYNO.SDS.TaskBar ? SYNO.SDS.TaskBar.height() : 0;
        return !(!Ext.isDefined(this.pageY) || !(this.pageY < i || this.pageY + this.height > e))
    },
    centerItIfOutOfBound: function() {
        this.isOutOfBound() && (SYNO.SDS.WindowMgr.centerWindow(this, {
            withOffset: this.autoStart
        }), this.moveDirty = !0)
    },
    getRestoreSizePos: function(t) {
        var e = t.appInstance.getUserSettings("restoreSizePos") || {};
        return Ext.isDefined(t.minWidth) && Ext.isDefined(e.width) && e.width < t.minWidth && (Ext.isDefined(t.width) ? e.width = t.width : e.width = t.minWidth), Ext.isDefined(t.minHeight) && Ext.isDefined(e.height) && e.height < t.minHeight && (Ext.isDefined(t.height) ? e.height = t.height : e.height = t.minHeight), Ext.isDefined(e.maximized) || (e.maximized = t.defaultMaximized), t.maximized && (e.maximized = t.maximized), e
    },
    onOpen: function(t) {
        var e;
        if (this.initialized || this.init(), Ext.isObject(t)) {
            for (e in t) t.hasOwnProperty(e) && this.setOpenConfig(e, t[e]);
            t.title && this.setTitle(t.title), SYNO.API.Info.Update(this)
        }
        this.appInstance.skipRecord || this.recordAppOpened(), SYNO.SDS.AppWindow.superclass.onOpen.apply(this, arguments)
    },
    recordAppOpened: function() {
        var t = this.appInstance,
            e = t.appWindowName,
            i = t.jsConfig.jsID;
        e && _S("isLogined") && this.sendWebAPI({
            callback: function() {
                SYNO.SDS.StatusNotifier.fireEvent("apprecordupdated", i, e)
            }.bind(this),
            compound: {
                stopwhenerror: !1,
                params: [{
                    api: "SYNO.Core.DataCollect.Application",
                    version: 1,
                    method: "record",
                    params: {
                        app: e
                    }
                }, {
                    api: "SYNO.Core.AppNotify",
                    version: 1,
                    method: "view",
                    params: {
                        app: i
                    }
                }]
            }
        })
    },
    onShow: function() {
        SYNO.SDS.AppWindow.superclass.onShow.apply(this, arguments), this.updateTaskButton("restore")
    },
    checkModalOrMask: function() {
        return !!(this.modalWin && this.modalWin.length > 0 || this.maskCnt > 0) && (this.blinkModalChild(), !0)
    },
    setMaskMsgVisible: function(t) {
        if (this.el.isMasked()) {
            var e = Ext.Element.data(this.el, "maskMsg");
            e && e.dom && (e.setVisibilityMode(Ext.Element.VISIBILITY), e.setVisible(t))
        }
    },
    setMaskOpacity: function(t) {
        SYNO.SDS.AppWindow.superclass.setMaskOpacity.call(this, t), this.setMaskMsgVisible(0 !== t)
    },
    delayedMask: function(t, e, i, s) {
        e = e || 200, this.maskTask || (this.maskTask = new Ext.util.DelayedTask(this.setMaskOpacity, this, [t])), this.mask(0, i, s), this.setMaskMsgVisible(!1), this.maskTask.delay(e)
    },
    synchronizedMask: function(t, e, i) {
        this.mask(t, e, i), this.setMaskMsgVisible(0 !== t)
    },
    setStatusBusy: function(t, e, i) {
        t = t || {}, Ext.applyIf(t, {
            text: _T("common", "loading"),
            iconCls: "x-mask-loading"
        }), e = Ext.isNumber(e) ? e : .4, i = Ext.isNumber(i) ? i : 400, i > 0 ? this.delayedMask(e, i, t.text, t.iconCls) : this.synchronizedMask(e, t.text, t.iconCls), this.canClose = !1
    },
    clearStatusBusy: function(t) {
        this.unmask(), this.canClose = !0
    },
    onClose: function() {
        if (this.isStandaloneMainWindow() || !1 === this.canClose) return !1;
        this.saveRestoreData(), this.callParent()
    },
    getOpenConfig: function(t) {
        if (Ext.isString(t) && !Ext.isEmpty(this.openConfig[t])) return this.openConfig[t]
    },
    setOpenConfig: function(t, e) {
        Ext.isString(t) && !Ext.isEmpty(t) && (this.openConfig[t] = e)
    },
    hasOpenConfig: function(t) {
        return !(!Ext.isString(t) || Ext.isEmpty(t)) && void 0 !== this.openConfig[t]
    }
}), Ext.namespace("SYNO.SDS.TaskRunner"), SYNO.SDS._TaskMgr = function(t) {
    var e = t || 10,
        i = [],
        s = [],
        n = 0,
        o = !1,
        a = !1,
        r = function(t, e) {
            for (var i; 0 !== e;) i = t % e, t = e, e = i;
            return t
        },
        l = function() {
            var e, s, n = i[0].interval;
            for (e = 1; s = i[e]; e++) n = r(n, s.interval);
            return Math.max(n, t)
        },
        h = function() {
            var t = l();
            return t !== e && (e = t, !0)
        },
        d = function() {
            o = !1, clearTimeout(n), n = 0
        },
        c = function() {
            o || (o = !0, h(), setImmediate(p))
        },
        u = function(t) {
            s.push(t), t.onStop && t.onStop.apply(t.scope || t)
        },
        f = function(t) {
            t.processing = !0, Promise.resolve(t.run.apply(t.scope || t, t.args || [++t.taskRunCount])).then(function(e) {
                !1 === e && u(t), t.processing = !1
            })
        },
        p = function t() {
            var o, r, l, c, p = !1,
                S = (new Date).getTime();
            for (o = 0; r = s[o]; o++) i.remove(r), p = !0;
            if (s = [], !i.length) return void d();
            for (o = 0; r = i[o]; ++o)
                if (r = i[o], !a || !0 === r.preventHalt) {
                    if (c = S - r.taskRunTime, r.interval <= c) {
                        if (!1 === r.processing) try {
                            f(r)
                        } catch (t) {
                            if (!Ext.isIE && (SYNO.Debug.error("TaskRunner: task " + r.id + " exception: ", t), Ext.isDefined(SYNO.SDS.JSDebug))) throw r.taskRunTime = S, t
                        }
                        if (r.taskRunTime = S, l = r.interval, r.interval = r.adaptiveInterval(), l !== r.interval && (p = !0), r.taskRunCount === r.repeat) return void u(r)
                    }
                    r.duration && r.duration <= S - r.taskStartTime && u(r)
                } p && h(), n = setTimeout(t, e)
        };
    this.start = function(t, e) {
        var s = (new Date).getTime();
        return i.push(t), t.taskStartTime = s, t.taskRunTime = !1 === e ? s : 0, t.taskRunCount = 0, o ? (h(), clearTimeout(n), setImmediate(p)) : c(), t
    }, this.stop = function(t) {
        return u(t), t
    }, this.stopAll = function() {
        var t, e;
        for (d(), t = 0; e = i[t]; t++) e.onStop && e.onStop();
        i = [], s = []
    }, this.setHalt = function(t) {
        a = t
    }
}, SYNO.SDS.TaskMgr = new SYNO.SDS._TaskMgr(100), SYNO.SDS.TaskRunner = Ext.extend(Ext.util.Observable, {
    tasks: null,
    constructor: function() {
        SYNO.SDS.TaskRunner.superclass.constructor.apply(this, arguments), this.addEvents("add", "remove", "beforestart"), this.tasks = {}
    },
    destroy: function() {
        this.stopAll(), this.tasks = {}, this.isDestroyed = !0
    },
    start: function(t, e) {
        if (!this.isDestroyed) return t.running || (this.fireEvent("beforestart", t), SYNO.SDS.TaskMgr.start(t, e)), t.running = !0, t
    },
    stop: function(t) {
        return t.running && SYNO.SDS.TaskMgr.stop(t), t.running = !1, t
    },
    stopAll: function() {
        for (var t in this.tasks)
            if (this.tasks.hasOwnProperty(t)) {
                if (!this.tasks[t].running) continue;
                SYNO.SDS.TaskMgr.stop(this.tasks[t])
            }
    },
    addTask: function(t) {
        return t.id = t.id || Ext.id(), this.tasks[t.id] = t, this.fireEvent("add", t), t
    },
    createTask: function(t) {
        t.id = t.id || Ext.id();
        var e = this.tasks[t.id];
        return e ? e.apply(t) : (e = new SYNO.SDS.TaskRunner.Task(t, this), this.addTask(e)), e
    },
    createAjaxTask: function(t) {
        t.id = t.id || Ext.id();
        var e = this.tasks[t.id];
        return e ? e.apply(t) : (e = new SYNO.SDS.TaskRunner.AjaxTask(t, this), this.addTask(e)), e
    },
    createWebAPITask: function(t) {
        t.id = t.id || Ext.id();
        var e = this.tasks[t.id];
        return e ? e.apply(t) : (e = new SYNO.SDS.TaskRunner.WebAPITask(t, this), this.addTask(e)), e
    },
    removeTask: function(t) {
        var e = this.tasks[t];
        e && (this.fireEvent("remove", e), delete this.tasks[t])
    },
    getTask: function(t) {
        return this.tasks[t] || null
    }
});
var LOW_LEVEL_RUNNER_INTERVAL_PENALTY = 2;
SYNO.SDS.TaskRunner.Task = Ext.extend(Ext.util.Observable, {
    INTERVAL_DEFAULT: 6e4,
    INTERVAL_FALLBACK: 6e4,
    manager: null,
    running: !1,
    processing: !1,
    removed: !1,
    taskFirstRunTime: 0,
    constructor: function(t, e) {
        SYNO.SDS.TaskRunner.Task.superclass.constructor.apply(this, arguments), this.manager = e, this.apply(t)
    },
    apply: function(t) {
        this.applyInterval(t.interval), delete t.interval, this.applyConfig(t)
    },
    applyConfig: function(t) {
        Ext.apply(this, t)
    },
    applyInterval: function(t) {
        this.intervalData = t, Ext.isFunction(this.intervalData) || Ext.isArray(this.intervalData) || Ext.isNumber(this.intervalData) || (this.intervalData = this.INTERVAL_DEFAULT), this.interval = this.adaptiveInterval()
    },
    adaptiveInterval: function() {
        var t, e = 0,
            i = this.intervalData,
            s = null;
        if (this.taskFirstRunTime && (e = (new Date).getTime() - this.taskFirstRunTime), Ext.isNumber(i)) s = i;
        else if (Ext.isFunction(i)) s = i.call(this.scope || this, e);
        else if (Ext.isArray(i))
            for (t = 0; t < i.length && !(i[t].time > e); ++t) s = i[t].interval;
        return Ext.isNumber(s) || (SYNO.Debug.debug("TaskRunner: Task " + this.id + " interval fallback to " + this.INTERVAL_FALLBACK), s = this.INTERVAL_FALLBACK), SYNO.SDS.Utils.isLowLevelModel() && (s *= LOW_LEVEL_RUNNER_INTERVAL_PENALTY), s
    },
    start: function(t) {
        var e = (new Date).getTime();
        if (!this.removed) return this.taskFirstRunTime || (this.taskFirstRunTime = !1 === t ? e + this.interval : e), this.manager.start(this, t)
    },
    stop: function() {
        if (!this.removed) return this.manager.stop(this)
    },
    restart: function(t) {
        this.stop(), this.start(t)
    },
    remove: function() {
        this.stop(), this.manager.removeTask(this.id), this.removed = !0
    }
}), SYNO.SDS.TaskRunner.AjaxTask = Ext.extend(SYNO.SDS.TaskRunner.Task, {
    constructor: function(t, e) {
        this.reqId = null, this.reqConfig = null, this.cbHandler = null, this.autoJsonDecode = !1, this.single = !1, SYNO.SDS.TaskRunner.AjaxTask.superclass.constructor.call(this, t, e)
    },
    applyConfig: function(t) {
        Ext.apply(this, {
            run: this.run,
            scope: this
        }), this.autoJsonDecode = !0 === t.autoJsonDecode, this.single = !0 === t.single, this.preventHalt = !0 === t.preventHalt, this.cbHandler = {}, this.reqConfig = {}, Ext.copyTo(this.cbHandler, t, ["scope", "callback", "success", "failure"]), Ext.apply(this.reqConfig, t), Ext.apply(this.reqConfig, {
            success: null,
            failure: null,
            callback: this.onCallback,
            scope: this
        }), Ext.applyIf(this.reqConfig, {
            method: "GET"
        }), delete this.reqConfig.id, delete this.reqConfig.autoJsonDecode, delete this.reqConfig.single
    },
    stop: function() {
        this.reqId && (Ext.Ajax.abort(this.reqId), this.reqId = null), SYNO.SDS.TaskRunner.AjaxTask.superclass.stop.apply(this, arguments)
    },
    run: function() {
        if (!this.reqConfig.url) return void this.remove();
        SYNO.SDS.TaskRunner.AjaxTask.superclass.stop.call(this), this.reqId = Ext.Ajax.request(this.reqConfig)
    },
    onCallback: function(t, e, i) {
        var s = i,
            n = Ext.apply({}, t);
        if (Ext.apply(n, {
                scope: this.cbHandler.scope,
                callback: this.cbHandler.callback,
                success: this.cbHandler.success,
                failure: this.cbHandler.failure
            }), e && this.autoJsonDecode) try {
            s = Ext.util.JSON.decode(i.responseText)
        } catch (t) {
            s = {
                success: !1
            }, e = !1
        }
        e && n.success ? n.success.call(n.scope, s, t) : !e && n.failure && n.failure.call(n.scope, s, t), n.callback && n.callback.call(n.scope, t, e, s), this.fireEvent("callback", t, e, s), e && this.single ? (this.reqId = null, this.remove()) : this.reqId && (this.reqId = null, this.start(!1))
    }
}), SYNO.SDS.TaskRunner.WebAPITask = Ext.extend(SYNO.SDS.TaskRunner.AjaxTask, {
    constructor: function(t, e) {
        SYNO.SDS.TaskRunner.WebAPITask.superclass.constructor.call(this, t, e)
    },
    applyConfig: function(t) {
        Ext.apply(this, {
            run: this.run,
            scope: this
        }), this.single = !0 === t.single, this.preventHalt = !0 === t.preventHalt, this.cbHandler = {}, this.reqConfig = {}, Ext.copyTo(this.cbHandler, t, ["callback", "scope"]), Ext.apply(this.reqConfig, t), Ext.apply(this.reqConfig, {
            callback: this.onCallback,
            scope: this
        }), delete this.reqConfig.id, delete this.reqConfig.single
    },
    run: function() {
        SYNO.SDS.TaskRunner.AjaxTask.superclass.stop.call(this), this.reqId = SYNO.API.Request(this.reqConfig)
    },
    onCallback: function(t, e, i, s) {
        var n = Ext.apply({}, s);
        Ext.apply(n, {
            scope: this.cbHandler.scope,
            callback: this.cbHandler.callback
        }), n.callback && n.callback.call(n.scope, t, e, i, n), this.fireEvent("callback", t, e, i, n), this.single ? (this.reqId = null, this.remove()) : this.reqId && (this.reqId = null, this.start(!1))
    }
}), inJsdom() ? window.SYNO = {
    SDS: {
        Utils: {}
    }
} : Ext.namespace("SYNO.SDS.Utils"), window._D = window._D || function() {}, window._S = window._S || function() {}, String.prototype.hashCode = function() {
    var t, e, i = 0;
    if (0 === this.length) return i;
    for (t = 0; t < this.length; t++) e = this.charCodeAt(t), i = (i << 5) - i + e, i |= 0;
    return i
}, SYNO.SDS.Utils.addFavIconLink = function(t, e, i) {
    var s, n = document.getElementsByTagName("link"),
        o = document.createElement("link");
    o.rel = "icon", o.href = t, o.setAttribute("sizes", i), e && (o.type = e);
    for (var a = document.head || document.getElementsByTagName("head")[0], r = n.length - 1; r >= 0; r--) n[r] && "icon" === n[r].getAttribute("rel") && ((s = n[r].getAttribute("sizes")) && i !== s || a.removeChild(n[r]));
    a.appendChild(o)
}, SYNO.SDS.Utils.clone = function(t) {
    if (!t || "object" !== _typeof(t)) return t;
    if ("function" == typeof t.clone) return t.clone();
    var e, i, s = "[object Array]" === Object.prototype.toString.call(t) ? [] : {};
    for (e in t) t.hasOwnProperty(e) && (i = t[e], i && "object" === _typeof(i) ? s[e] = SYNO.SDS.Utils.clone(i) : s[e] = i);
    return s
}, SYNO.SDS.Utils.mergeDeep = function(t) {
    for (var e, i = arguments.length, s = new Array(i > 1 ? i - 1 : 0), n = 1; n < i; n++) s[n - 1] = arguments[n];
    if (!s.length) return t;
    var o = s.shift();
    if (Ext.isObject(t) && Ext.isObject(o))
        for (var a in o) Ext.isObject(o[a]) ? (t[a] || Object.assign(t, _defineProperty({}, a, {})), SYNO.SDS.Utils.mergeDeep(t[a], o[a])) : Object.assign(t, _defineProperty({}, a, o[a]));
    return (e = SYNO.SDS.Utils).mergeDeep.apply(e, [t].concat(s))
}, SYNO.SDS.Utils.nextElementSibling = function(t, e) {
    var i = t.nextElementSibling;
    if (!e) return i;
    for (; i;) {
        if (i.matches(e)) return i;
        i = i.nextElementSibling
    }
    return null
}, SYNO.SDS.Utils.SelectableCLS = "allowDefCtxMenu selectabletext", SYNO.SDS.Utils.IsJson = function(t) {
    return "" !== t && (t = t.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@"), t = t.replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+-]?\d+)?/g, "]"), t = t.replace(/(?:^|:|,)(?:\s*\[)+/g, ""), /^[\],:{}\s]*$/.test(t))
};
var isLowLevelModel;
SYNO.SDS.Utils.isLowLevelModel = function() {
        if (Ext.isDefined(isLowLevelModel)) return isLowLevelModel;
        var t = _D("upnpmodelname");
        return isLowLevelModel = /(j|slim|se)$/.test(t) && t.indexOf("620slim") < 0
    }, inJsdom() && (module.exports = SYNO.SDS.Utils),
    function(t, e) {
        "use strict";

        function i(t) {
            return l[r] = s.apply(e, t), r++
        }

        function s(t) {
            var i = [].slice.call(arguments, 1);
            return function() {
                "function" == typeof t ? t.apply(e, i) : new Function("" + t)()
            }
        }

        function n(t) {
            if (h) setTimeout(s(n, t), 0);
            else {
                var e = l[t];
                if (e) {
                    h = !0;
                    try {
                        e()
                    } finally {
                        o(t), h = !1
                    }
                }
            }
        }

        function o(t) {
            delete l[t]
        }
        if (!t.setImmediate) {
            var a, r = 1,
                l = {},
                h = !1,
                d = t.document,
                c = Object.getPrototypeOf && Object.getPrototypeOf(t);
            c = c && c.setTimeout ? c : t, "[object process]" === {}.toString.call(t.process) ? function() {
                a = function() {
                    var t = i(arguments);
                    return process.nextTick(s(n, t)), t
                }
            }() : function() {
                if (t.postMessage && !t.importScripts) {
                    var e = !0,
                        i = t.onmessage;
                    return t.onmessage = function() {
                        e = !1
                    }, t.postMessage("", "*"), t.onmessage = i, e
                }
            }() ? function() {
                var e = "setImmediate$" + Math.random() + "$",
                    s = function(i) {
                        i.source === t && "string" == typeof i.data && 0 === i.data.indexOf(e) && n(+i.data.slice(e.length))
                    };
                t.addEventListener ? t.addEventListener("message", s, !1) : t.attachEvent("onmessage", s), a = function() {
                    var s = i(arguments);
                    return t.postMessage(e + s, "*"), s
                }
            }() : t.MessageChannel ? function() {
                var t = new MessageChannel;
                t.port1.onmessage = function(t) {
                    n(t.data)
                }, a = function() {
                    var e = i(arguments);
                    return t.port2.postMessage(e), e
                }
            }() : d && "onreadystatechange" in d.createElement("script") ? function() {
                var t = d.documentElement;
                a = function() {
                    var e = i(arguments),
                        s = d.createElement("script");
                    return s.onreadystatechange = function() {
                        n(e), s.onreadystatechange = null, t.removeChild(s), s = null
                    }, t.appendChild(s), e
                }
            }() : function() {
                a = function() {
                    var t = i(arguments);
                    return setTimeout(s(n, t), 0), t
                }
            }(), c.setImmediate = a, c.clearImmediate = o
        }
    }(new Function("return this")());