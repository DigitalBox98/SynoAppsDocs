/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.define("SYNO.SDS.AudioStation.SearchField.Main", {
    extend: "SYNO.ux.SearchField",
    constructor: function(a) {
        this.audioMain = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main");
        var b = {
            width: 212,
            listeners: {
                scope: this,
                keydown: this.onSearchFieldKeyDown
            }
        };
        Ext.apply(b, a);
        this.callParent([b]);
        this.isSearchTriggerDisable = false;
        if (!this.audioMain.searchFieldMgr) {
            this.audioMain.searchFieldMgr = new SYNO.SDS.AudioStation.SearchField.Mgr()
        }
        this.audioMain.searchFieldMgr.addComponent(this)
    },
    getMenu: function() {
        return this.audioMain.getSearchCateMenu()
    },
    onTriggerClick: function() {
        this.callParent(arguments);
        this.audioMain.clearSearchResult()
    },
    onSearchTriggerClick: function(a) {
        if (this.isSearchTriggerDisable) {
            return
        }
        this.callParent(arguments)
    },
    onSearchFieldKeyDown: function(b, c) {
        if (Ext.EventObject.ENTER !== c.getKey()) {
            return
        }
        var a = b.getValue().trim();
        if ("" === a) {
            return
        }
        this.startSearch(a)
    },
    startSearch: function(b) {
        var a = this.audioMain;
        if (a._getUtils().isInShoutCast() || a._getUtils().isInShoutCastSearch()) {
            if (b.length <= 2) {
                a._getWindow().getMsgBox().alert(_AST("common", "search_shoutcast"), _AST("common", "search_inet_radio_invalid"));
                return
            }
            a.searchShoutCast(b)
        } else {
            if (a._getUtils().isInAllPlaylist() || a._getUtils().isInPlaylistLayer2()) {
                a.searchPlaylist(b)
            } else {
                a.searchLibrary(b)
            }
        }
    }
});
Ext.define("SYNO.SDS.AudioStation.SearchField.Mgr", {
    extend: Object,
    constructor: function() {
        this.items = []
    },
    addComponent: function(a) {
        this.items.push(a);
        a.on("destroy", this.removeComponent, this)
    },
    removeComponent: function(a) {
        this.items.remove(a)
    },
    setEmptyText: function(c) {
        var b, a;
        for (b = 0, a = this.items.length; b < a; b++) {
            this.items[b].emptyText = c
        }
    },
    setValue: function(c) {
        var b, a;
        for (b = 0, a = this.items.length; b < a; b++) {
            this.items[b].setValue(c)
        }
    },
    resetSearch: function() {
        var b, a;
        for (b = 0, a = this.items.length; b < a; b++) {
            this.resetOneSearch(this.items[b])
        }
    },
    resetOneSearch: function(a) {
        a.reset();
        a.blur();
        a.trigger.hide()
    },
    setCateBtnDisable: function(b) {
        var c, a;
        for (c = 0, a = this.items.length; c < a; c++) {
            this.items[c].searchtrigger.removeClass("syno-as-search-btn-disabled");
            this.items[c].isSearchTriggerDisable = false;
            if (b) {
                this.items[c].searchtrigger.addClass("syno-as-search-btn-disabled");
                this.items[c].isSearchTriggerDisable = true
            }
        }
    },
    setTriggerVisible: function(b) {
        var c, a;
        for (c = 0, a = this.items.length; c < a; c++) {
            this.items[c].trigger.setVisible(b)
        }
    },
    checkMenuItem: function(c) {
        var b, a;
        for (b = 0, a = this.items.length; b < a; b++) {
            this.items[b].getMenu().items.get(c).setChecked(true)
        }
    }
});
Ext.define("SYNO.SDS.AudioStation.ListPanel", {
    extend: "SYNO.ux.ModuleList",
    constructor: function(a) {
        this.callParent([this.fillConfig(a)]);
        this.audioMain = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main");
        SYNO.SDS.AudioStation.Utils._initWinWrappers.call(this, a);
        SYNO.SDS.AudioStation.Window.addPanelScope("SYNO.SDS.AudioStation.ListPanel", this);
        this.mon(this.getSelectionModel(), "selectionchange", this.onListSelect, this)
    },
    fillConfig: function(a) {
        var b = {
            cls: "syno-as-list",
            listItems: this.getListItems(),
            listeners: {
                scope: this,
                click: this.onListClick,
                beforeclick: this.onBeforeListClick,
                afterlayout: {
                    buffer: 80,
                    single: true,
                    fn: function(c, d) {
                        this.setMediaServerVisible(!SYNO.SDS.AudioStation.SessionData.settings.disable_upnp && SYNO.SDS.AudioStation.SessionData.privilege.upnp_browse);
                        if (!this.listDropTarget) {
                            this.listDropTarget = new SYNO.SDS.AudioStation.ListPanelDropTarget(c, this.audioMain, {
                                ddGroup: "PlayingQueueDD"
                            })
                        }
                        this.selectModule(SYNO.SDS.AudioStation.Utils._Homepage_ID);
                        this.onListClick(this.getNodeById(SYNO.SDS.AudioStation.Utils._Homepage_ID))
                    }
                },
                destroy: function(c) {
                    if (this.listDropTarget) {
                        this.listDropTarget.removeFromGroup("PlayingQueueDD")
                    }
                }
            }
        };
        Ext.apply(b, a);
        return b
    },
    addToolbar: function(a) {
        var b = {
            tbar: {
                height: 28,
                style: {
                    marginBottom: "12px"
                },
                items: [this.searchField = new SYNO.SDS.AudioStation.SearchField.Main()]
            }
        };
        Ext.apply(a, b)
    },
    onListSelect: function(a, b) {},
    onListClick: function(b, a) {
        var e, d, c;
        c = this._getWindow().getPathMgr().getHistoryInfo(b.id);
        if (SYNO.SDS.AudioStation.Utils._Homepage_ID !== b.id && 0 === c.index) {
            e = new Ext.data.Record({
                id: b.id,
                title: b.text
            });
            if (SYNO.SDS.AudioStation.Utils._Radio_ID === c.type && SYNO.SDS.AudioStation.Utils._Radio_ID !== b.id) {
                e.set("type", "container")
            }
            this._getWindow().getPathMgr().onSetGotoCfg(b.id);
            d = this.audioMain.prepareGotoNextParam(e);
            this._getWindow().getPathMgr().objHistory[b.id][0] = Ext.apply(SYNO.Util.copy(this._getUtils().SEC_CFG[b.id][0]), SYNO.Util.copy({
                index: 0,
                params: SYNO.Util.copy(d || {})
            } || {}))
        }
        SYNO.SDS.AudioStation.Window.getPathMgr().onGotoPanel(b.id)
    },
    onBeforeListClick: function(e, c) {
        var a = e.attributes.cls ? e.attributes.cls : "",
            b = e.attributes.iconCls ? e.attributes.iconCls : "",
            d = e.attributes.text ? e.attributes.text : "",
            f = c.getTarget();
        if (-1 !== a.indexOf("syno-as-list-title-with-button") && Ext.fly(f).hasClass("x-tree-node-anchor")) {
            if (_AST("common", "class_music_title_playlist") === d) {
                this.getPlaylistMenu();
                this.playlistMenu.shadow = false;
                this.playlistMenu.showAt([Ext.fly(f).getX() + 180, Ext.fly(f).getY() + 32])
            } else {
                this.getRadioMenu();
                this.radioMenu.shadow = false;
                this.radioMenu.showAt([Ext.fly(f).getX() + 180, Ext.fly(f).getY() + 32])
            }
        }
        if ("syno-as-list-shoutcast" === b) {
            this.getEl().child(".syno-as-list-shoutcast-leaf").setOpacity(1)
        } else {
            if ("syno-as-list-shoutcast-leaf" !== a && -1 === a.indexOf("syno-as-list-title")) {
                this.getEl().child(".syno-as-list-shoutcast-leaf").setOpacity(0)
            }
        }
    },
    clearSelectedItems: function() {
        this.getSelectionModel().clearSelections()
    },
    selectItemById: function(a) {
        this.suspendEvents();
        this.selectModule(a);
        this.resumeEvents()
    },
    setMediaServerVisible: function(a) {
        this.setModuleVisible(SYNO.SDS.AudioStation.Utils._MediaServer_ID, a);
        if (!a && this._getUtils().isInMediaserver()) {
            SYNO.SDS.AudioStation.Window.getPathMgr().gotoHomePage()
        }
    },
    getPlaylistMenu: function() {
        if (!this.playlistMenu) {
            this.playlistMenu = new SYNO.ux.Menu({
                enableScrolling: false,
                defaults: {
                    scope: this.audioMain
                },
                items: [{
                    text: _AST("playlist", "playlist"),
                    handler: this.audioMain.onPlaylistNew.createDelegate(this.audioMain, [])
                }, {
                    text: _AST("common", "class_smart_playlist"),
                    handler: this.audioMain.onSmartPlaylistNew
                }]
            })
        }
        return this.playlistMenu
    },
    getRadioMenu: function() {
        if (!this.radioMenu) {
            this.radioMenu = new SYNO.ux.Menu({
                enableScrolling: false,
                defaults: {
                    scope: this.audioMain
                },
                items: [{
                    text: _AST("player", "player_source_userdefined"),
                    handler: this.audioMain.onInetRadioEditRec.createDelegate(this.audioMain, ["UserDefined"])
                }, {
                    text: _AST("player", "def_radio_station"),
                    handler: this.audioMain.onInetRadioEditRec.createDelegate(this.audioMain, ["Favorite"])
                }]
            })
        }
        return this.radioMenu
    },
    getListItems: function() {
        return [{
            text: _AST("common", "homepage"),
            iconCls: "syno-as-list-homepage",
            fn: SYNO.SDS.AudioStation.Utils._Homepage_ID
        }, {
            text: _AST("common", "player_source_dms"),
            iconCls: "syno-as-list-mediaserver",
            fn: SYNO.SDS.AudioStation.Utils._MediaServer_ID
        }, {
            text: _AST("common", "class_music_title_mymusic"),
            cls: "syno-as-list-title",
            iconCls: "syno-as-list-no-icon",
            disabled: true
        }, {
            text: _AST("common", "class_music_allmusic"),
            iconCls: "syno-as-list-allmusic",
            fn: SYNO.SDS.AudioStation.Utils._AllMusic_ID
        }, {
            text: _AST("common", "class_music_userfile"),
            iconCls: "syno-as-list-userfile",
            fn: SYNO.SDS.AudioStation.Utils._ByFolder_ID
        }, {
            text: _AST("common", "class_music_album"),
            iconCls: "syno-as-list-album",
            fn: SYNO.SDS.AudioStation.Utils._ByAlbum_ID
        }, {
            text: _AST("common", "class_music_artist"),
            iconCls: "syno-as-list-artist",
            fn: SYNO.SDS.AudioStation.Utils._ByArtist_ID
        }, {
            text: _AST("common", "class_music_composer"),
            iconCls: "syno-as-list-composer",
            fn: SYNO.SDS.AudioStation.Utils._ByComposer_ID
        }, {
            text: _AST("common", "class_music_genre"),
            iconCls: "syno-as-list-genre",
            fn: SYNO.SDS.AudioStation.Utils._ByGenre_ID
        }, {
            text: _AST("common", "class_music_title_playlist"),
            cls: "syno-as-list-title syno-as-list-title-with-button",
            iconCls: "syno-as-list-no-icon",
            disabled: true
        }, {
            text: _AST("common", "class_music_allplaylist"),
            iconCls: "syno-as-list-allplaylist",
            fn: SYNO.SDS.AudioStation.Utils._Playlist_ID
        }, {
            text: _AST("common", "random_playlist"),
            iconCls: "syno-as-list-random100",
            fn: SYNO.SDS.AudioStation.Utils._Random100_ID
        }, {
            text: _AST("common", "class_music_latestalbum"),
            iconCls: "syno-as-list-latestalbum",
            fn: SYNO.SDS.AudioStation.Utils._RecentlyAdded_ID
        }, {
            text: _AST("playlist", "shared_songs_playlist"),
            iconCls: "syno-as-list-sharedsongs",
            fn: SYNO.SDS.AudioStation.Utils._SharedSongs_ID
        }, {
            text: _AST("radio", "title_radio"),
            cls: "syno-as-list-title syno-as-list-title-with-button",
            iconCls: "syno-as-list-no-icon",
            disabled: true,
            fn: SYNO.SDS.AudioStation.Utils._Radio_ID
        }, {
            text: _AST("player", "player_source_shoutcast"),
            iconCls: "syno-as-list-shoutcast",
            fn: SYNO.SDS.AudioStation.Utils._ShoutCast_ID
        }, {
            text: _AST("player", "player_source_userdefined"),
            iconCls: "syno-as-list-userdefined",
            fn: SYNO.SDS.AudioStation.Utils._Userdefined_ID
        }, {
            text: _AST("player", "def_radio_station"),
            iconCls: "syno-as-list-myfavorite",
            fn: SYNO.SDS.AudioStation.Utils._MyFavorite_ID
        }, {
            cls: "syno-as-list-shoutcast-leaf",
            iconCls: "syno-as-list-no-icon",
            disabled: true
        }]
    }
});
Ext.ns("SYNO.SDS.AudioStation");
Ext.define("SYNO.SDS.AudioStation.PathBar.Main", {
    extend: "Ext.util.Observable",
    constructor: function(a) {
        SYNO.SDS.AudioStation.Window.addPanelScope("SYNO.SDS.AudioStation.PathBar.Main", this);
        this.init();
        this.callParent(arguments)
    },
    init: function() {
        this.tbPanel = new SYNO.SDS.AudioStation.PathButtonsPanel({
            cls: "syno-as-ux-pathtoolbar"
        });
        return this
    },
    addPathButton: function(f, e, c, g, b, d, a) {
        return this.tbPanel.addButton(f, e, c, g, b, d, a)
    },
    updatePathButton: function(e, d, c, f, b, a) {
        return this.tbPanel.updateButton(e, d, c, f, b, a)
    },
    addPathButtons: function(c) {
        var b = (this.tbPanel.items.length < c.length) ? c.length : this.tbPanel.items.length;
        var d = c.length - 1;
        for (var a = 0; a < b; a++) {
            if (a < this.tbPanel.items.length && a < c.length) {
                this.updatePathButton(a, c[a].text, c[a].tooltip, c[a].callback, c[a].scope, a === d)
            } else {
                if (a < c.length) {
                    this.addPathButton(this.tbPanel.items.length, c[a].text, c[a].tooltip, c[a].callback, c[a].scope, a === 0, a === d)
                } else {
                    this.removePathButtons(a, b);
                    break
                }
            }
        }
        this.tbPanel.setActiveButton(this.tbPanel.items[this.tbPanel.items.length - 1])
    },
    removePathButtons: function(b, a) {
        this.tbPanel.removeButtons(b, a)
    },
    setWidth: function(a) {
        this.tbPanel.setWidth(a)
    },
    getPanel: function() {
        return this.tbPanel
    }
});
Ext.define("SYNO.SDS.AudioStation.PathButtonsPanel", {
    extend: "Ext.BoxComponent",
    activeButton: null,
    enableScroll: true,
    scrollIncrement: 0,
    scrollRepeatInterval: 400,
    scrollDuration: 0.35,
    animScroll: true,
    buttonWidthSet: false,
    allowDomMove: false,
    onRender: function() {
        this.callParent(arguments);
        this.mon(this, "resize", this.delegateUpdates);
        this.items = [];
        var a = Ext.get(this.el);
        this.stripWrap = a.createChild({
            cls: "ux-pathbuttons-strip-wrap",
            cn: {
                tag: "ul",
                cls: "ux-pathbuttons-strip"
            }
        });
        this.stripSpacer = a.createChild({
            cls: "ux-pathbuttons-strip-spacer"
        });
        this.strip = new Ext.Element(this.stripWrap.dom.firstChild);
        this.edge = this.strip.createChild({
            tag: "li",
            cls: "ux-pathbuttons-edge"
        });
        this.strip.createChild({
            cls: "x-clear"
        });
        this.addEvents("updatepath")
    },
    addButton: function(c, f, i, e, h, b, g) {
        var d = this.strip.createChild({
            tag: "li"
        }, this.edge);
        var a = new SYNO.SDS.AudioStation.PathBar.PathButton(this, d, c, f, i, e, h, b, g);
        this.items.push(a);
        if (!this.buttonWidthSet) {
            this.lastButtonWidth = a.container.getWidth()
        }
        this.addManagedComponent(a);
        return a
    },
    updateButton: function(f, e, d, g, c, b) {
        var a = this.items[f];
        a.updateButton(e, d, g, c, b)
    },
    removeButtons: function(f, e) {
        var a;
        var c;
        for (var b = f; b < e; b++) {
            c = this.items[b];
            a = document.getElementById(c.container.id);
            this.removeManagedComponent(c);
            c.purgeListeners();
            c.destroy();
            a.parentNode.removeChild(a)
        }
        var d = [];
        for (b = 0; b < f; b++) {
            d.push(this.items[b])
        }
        this.items = d;
        this.delegateUpdates()
    },
    setActiveButton: function(a) {
        this.activeButton = a;
        this.delegateUpdates()
    },
    delegateUpdates: function() {
        if (this.enableScroll && this.rendered) {
            this.onAutoScroll()
        }
    },
    onAutoScroll: function() {
        var e = this.items.length;
        var c = this.el.dom.clientWidth;
        var d = this.stripWrap;
        var b = d.dom.offsetWidth;
        var f = this.getScrollPos();
        var a = this.edge.getOffsetsTo(this.stripWrap)[0] + f;
        if (!this.enableScroll || e < 1 || b < 20) {
            return
        }
        d.setWidth(c);
        if (a <= c) {
            d.dom.scrollLeft = 0;
            if (this.scrolling) {
                this.scrolling = false;
                this.el.removeClass("x-pathbuttons-scrolling");
                this.scrollLeft.hide();
                this.scrollRight.hide()
            }
        } else {
            if (!this.scrolling) {
                this.el.addClass("x-pathbuttons-scrolling")
            }
            c -= d.getMargins("lr");
            d.setWidth(c > 20 ? c : 20);
            if (!this.scrolling) {
                if (!this.scrollLeft) {
                    this.createScrollers()
                } else {
                    this.scrollLeft.show();
                    this.scrollRight.show()
                }
            }
            this.scrolling = true;
            if (f > (a - c)) {
                d.dom.scrollLeft = a - c
            } else {
                this.scrollToButton(this.activeButton, false)
            }
            this.updateScrollButtons()
        }
    },
    createScrollers: function() {
        var c = this.el.dom.offsetHeight;
        var a = this.el.insertFirst({
            cls: "ux-pathbuttons-scroller-left"
        });
        a.setHeight(c);
        a.addClassOnOver("ux-pathbuttons-scroller-left-over");
        this.leftRepeater = new Ext.util.ClickRepeater(a, {
            interval: this.scrollRepeatInterval,
            handler: this.onScrollLeft,
            scope: this
        });
        this.scrollLeft = a;
        var b = this.el.insertFirst({
            cls: "ux-pathbuttons-scroller-right"
        });
        b.setHeight(c);
        b.addClassOnOver("ux-pathbuttons-scroller-right-over");
        this.rightRepeater = new Ext.util.ClickRepeater(b, {
            interval: this.scrollRepeatInterval,
            handler: this.onScrollRight,
            scope: this
        });
        this.scrollRight = b
    },
    getScrollWidth: function() {
        return this.edge.getOffsetsTo(this.stripWrap)[0] + this.getScrollPos()
    },
    getScrollPos: function() {
        return parseInt(this.stripWrap.dom.scrollLeft, 10) || 0
    },
    getScrollArea: function() {
        return parseInt(this.stripWrap.dom.clientWidth, 10) || 0
    },
    getScrollAnim: function() {
        return {
            duration: this.scrollDuration,
            callback: this.updateScrollButtons,
            scope: this
        }
    },
    getScrollIncrement: function() {
        return (this.scrollIncrement || this.lastButtonWidth + 2)
    },
    scrollToButton: function(e, a) {
        if (!e.el.dom) {
            return
        }
        e = e.el.dom.parentNode;
        if (!e) {
            return
        }
        var c = e;
        var g = this.getScrollPos(),
            d = this.getScrollArea();
        var f = Ext.fly(c).getOffsetsTo(this.stripWrap)[0] + g;
        var b = f + c.offsetWidth;
        if (f < g) {
            this.scrollTo(f, a)
        } else {
            if (b > (g + d)) {
                this.scrollTo(b - d, a)
            }
        }
    },
    scrollTo: function(b, a) {
        this.stripWrap.scrollTo("left", b, a ? this.getScrollAnim() : false);
        if (!a) {
            this.updateScrollButtons()
        }
    },
    onScrollRight: function() {
        var a = this.getScrollWidth() - this.getScrollArea();
        var c = this.getScrollPos();
        var b = Math.min(a, c + this.getScrollIncrement());
        if (b != c) {
            this.scrollTo(b, this.animScroll)
        }
    },
    onScrollLeft: function() {
        var b = this.getScrollPos();
        var a = Math.max(0, b - this.getScrollIncrement());
        if (a != b) {
            this.scrollTo(a, this.animScroll)
        }
    },
    updateScrollButtons: function() {
        var a = this.getScrollPos();
        this.scrollLeft[a === 0 ? "addClass" : "removeClass"]("ux-pathbuttons-scroller-left-disabled");
        this.scrollRight[a + 2 > (this.getScrollWidth() - this.getScrollArea()) ? "addClass" : "removeClass"]("ux-pathbuttons-scroller-right-disabled")
    }
});
Ext.define("SYNO.SDS.AudioStation.PathBar.PathButton", {
    extend: "Ext.Button",
    firstBtnCls: "x-first-btn",
    lastBtnCls: "x-last-btn",
    constructor: function(a, b, g, j, m, i, l, e, h) {
        var d = e ? this.firstBtnCls : "";
        var k = h ? this.lastBtnCls : "";
        var f = Ext.isFunction(i) ? i : Ext.emptyFn;
        var c = {
            text: j,
            itemId: g,
            renderTo: b,
            tooltip: m,
            clickEvent: "mousedown",
            listeners: {
                click: {
                    fn: f,
                    scope: l || this
                }
            },
            template: new Ext.Template('<table cellspacing="0" class="x-btn ' + d + " " + k + ' {3}"><tbody><tr>', '<td class="ux-pathbutton-left"></td>', '<td class="ux-pathbutton-center"><em class="{5}" unselectable="on">', '<button class="x-btn-text {2}" type="{1}">{0}</button>', "</em></td>", '<td class="ux-pathbutton-right"></td>', "</tr></tbody></table>")
        };
        this.callParent([c])
    },
    updateButton: function(e, d, f, c, b) {
        var a = Ext.isFunction(f) ? f : Ext.emptyFn;
        this.purgeListeners();
        this.mon(this, "click", a, c || this);
        this.setText(e);
        this.setTooltip(d);
        if (b) {
            this.addClass(this.lastBtnCls)
        } else {
            this.removeClass(this.lastBtnCls)
        }
    }
});
Ext.define("SYNO.SDS.AudioStation.ImageLoadManager", {
    extend: "Ext.util.Observable",
    MAX_CONCURRENT: 3,
    running: 0,
    jobs: null,
    preemptJobs: null,
    delegate: null,
    loadingClass: "thumb-loading",
    statics: {
        instance: null,
        get: function() {
            if (!Ext.isObject(SYNO.SDS.AudioStation.ImageLoadManager.instance)) {
                SYNO.SDS.AudioStation.ImageLoadManager.instance = new SYNO.SDS.AudioStation.ImageLoadManager()
            }
            return SYNO.SDS.AudioStation.ImageLoadManager.instance
        }
    },
    constructor: function(a) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.apply(this, arguments);
        this.callParent(arguments);
        this.jobs = [];
        this.preemptJobs = [];
        this.delayedPreemptJob = new Ext.util.DelayedTask(this.preemptJob, this);
        this.running = 0
    },
    clear: function() {
        this.jobs = [];
        this.preemptJobs = []
    },
    appendJob: function(a) {
        if (-1 !== this.jobs.indexOf(a)) {
            return
        }
        this.jobs.push(a);
        this.dispatch()
    },
    insertJob: function(a) {
        this.preemptJobs.push(a);
        this.delayedPreemptJob.delay(100)
    },
    preemptJob: function() {
        var a;
        Ext.each(this.preemptJobs, function(b) {
            for (a = 0; a < this.jobs.length; a++) {
                if (b.select("img").elements[0].getAttribute("id") && this.jobs[a].select("img").elements[0].getAttribute("id") === b.select("img").elements[0].getAttribute("id")) {
                    this.jobs.splice(a, 1)
                }
            }
        }, this);
        this.jobs.unshift.apply(this.jobs, this.preemptJobs);
        this.preemptJobs = [];
        this.dispatch()
    },
    dispatch: function() {
        while (this.MAX_CONCURRENT > this.running) {
            var a = this.jobs.shift();
            if (!a) {
                break
            }
            this.running++;
            this.setImgURL(a)
        }
    },
    setImgURL: function(d) {
        var c = d.select("img"),
            a = c.elements[0];
        if (c.elements.length < 1 || a.src) {
            if (this.running > 0) {
                this.running--
            }
            this.dispatch.defer(5, this);
            return
        }
        var b = document.createElement("img");
        Ext.fly(b).on({
            load: this.onImageLoad.createDelegate(this, [d, b]),
            error: this.onImageError.createDelegate(this, [d, b])
        });
        b.src = a.getAttribute("thumbnails")
    },
    finalizedImageLoad: function(b, a) {
        if (this.running > 0) {
            this.running--
        }
        a = null;
        this.dispatch.defer(5, this)
    },
    onImageLoad: function(c, b) {
        var a = c.select("img").elements[0];
        this.finalizedImageLoad(c, b);
        if (!c.hasClass(this.loadingClass)) {
            return
        }
        c.removeClass(this.loadingClass);
        if (!a) {
            return
        }
        a.src = a.getAttribute("thumbnails");
        Ext.fly(a).addClass("fadein syno-as-arkwork-nomal-image")
    },
    onImageError: function(c, b) {
        var a = c.select("img").elements[0];
        this.finalizedImageLoad(c, b);
        if (!c.hasClass(this.loadingClass)) {
            return
        }
        var d = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (-1 !== a.getAttribute("thumbnails").search(/getsongcover/)) {
            a.src = this._getUtils().getImageByDisplay("audio_default_songs.png")
        } else {
            if (this._getUtils().isInSearchAllCate()) {
                if (-1 !== a.src.indexOf("artist_name")) {
                    a.src = this._getUtils().getImageByDisplay(this._getUtils().imgMapping["SYNO.AudioStation.Artist"])
                } else {
                    a.src = this._getUtils().getImageByDisplay(this._getUtils().imgMapping["SYNO.AudioStation.Album"])
                }
            } else {
                if (this._getUtils().imgMapping[d.params.api]) {
                    a.src = this._getUtils().getImageByDisplay(this._getUtils().imgMapping[d.params.api])
                }
            }
        }
    }
});
Ext.ns("SYNO.SDS.AudioStation");
Ext.define("SYNO.SDS.AudioStation.ThumbView", {
    extend: "SYNO.ux.Panel",
    constructor: function(a) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.call(this, a);
        SYNO.SDS.AudioStation.Window.addPanelScope("SYNO.SDS.AudioStation.ThumbView", this);
        this.baseURL = SYNO.SDS.AudioStation.Window.baseURL;
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        this.dataView = new SYNO.SDS.AudioStation.ThumbDataView({
            module: this
        });
        this.paging = new SYNO.ux.PagingToolbar({
            displayInfo: true,
            cls: "syno-as-paging-toolbar",
            store: this.dataView.getStore(),
            pageSize: this._getWindow().gridPagingSize,
            listeners: {
                scope: this,
                change: this.onPageChange
            }
        });
        var b = {
            boxMinHeight: 1,
            boxMinWidth: 1,
            border: false,
            layout: "fit",
            bodyStyle: "overflow: visible;",
            keys: this._getUtils().getHotKeyMap(this, this.hotKeyHandler),
            items: [this.dataView],
            bbar: this.paging,
            listeners: {
                activate: this.onActivate,
                deactivate: this.onDeactivate,
                afterrender: {
                    scope: this,
                    single: true,
                    buffer: 80,
                    fn: this.setPagetoolBarVisible.createDelegate(this, [false])
                }
            }
        };
        Ext.apply(b, a);
        return b
    },
    setPagetoolBarVisible: function(a) {
        if (a === this.paging.isVisible()) {
            return
        }
        this.paging.setVisible(a);
        this.doLayout()
    },
    onActivate: function() {
        this.dataView.onActivate()
    },
    onDeactivate: function() {
        this.dataView.onDeactivate()
    },
    onPageChange: function(b, a) {
        SYNO.SDS.AudioStation.ImageLoadManager.get().clear()
    },
    hotKeyHandler: function(a) {
        var b = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main");
        if ("c_a" === a) {
            if (Ext.isMac && !this.cmdKeyDown) {
                return
            }
            this.dataView.selectAll()
        } else {
            if ("delete" === a) {
                if (this._getUtils().isInRadioUserDefined() || this._getUtils().isInRadioFavorite()) {
                    b.onInetRadioDeleteRec()
                } else {
                    if (this._getUtils().isInPlaylist()) {
                        b.onPlaylistDeleteRec()
                    }
                }
            }
        }
    }
});
Ext.define("SYNO.SDS.AudioStation.ThumbDataView", {
    extend: "SYNO.SDS.Utils.DataView.LazyDataView",
    constructor: function(a) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.apply(this, arguments);
        var b = this.fillConfig(a);
        this.callParent([b]);
        this.bindStore(null);
        this.loader = new SYNO.SDS.AudioStation.ImageLoadManager.get();
        this.mon(this._getWindow(), "close", this.loader.clear, this.loader)
    },
    fillConfig: function(a) {
        var b = {
            tpl: this.getTpl(),
            itemId: "dataview",
            multiSelect: true,
            cls: "syno-as-thumb-dataview",
            overClass: "x-view-over",
            itemSelector: "div.thumb-wrap",
            ddGroup: "PlayingQueueDD",
            store: this.getStore(),
            deferEmptyText: false,
            plugins: [SYNO.SDS.AudioStation.FocusComponentPluginInstance],
            listeners: {
                scope: this,
                dblclick: this.onNodeDbClick,
                click: this.onNodeClick,
                activate: this.onActivate,
                deactivate: this.onDeactivate,
                contextmenu: this.onShowItemMenu,
                mouseenter: this.onNodeMouseEnter,
                mouseleave: this.onNodeMouseLeave,
                beforeselect: this.beforeNodeSelect
            },
            collectData: function(d, h, g) {
                var f = [],
                    e = 0,
                    c = (undefined !== g && g < d.length) ? g : d.length;
                for (; e < c; e++) {
                    f[f.length] = this.prepareData(d[e].data, h + e, d[e])
                }
                return f
            }
        };
        Ext.apply(b, a);
        return b
    },
    getImageItems: function(a, b) {
        Ext.each(a, function(f, c, e) {
            var d = Ext.fly(f).select(".thumb");
            if (0 < d.elements.length && d.item(0).hasClass("thumb-loading")) {
                b(d.item(0))
            }
        })
    },
    preloadItems: function() {
        var a = this.getNodes();
        this.getImageItems(a, this.loader.appendJob.createDelegate(this.loader))
    },
    onViewResize: function() {
        this.refreshView(true)
    },
    refreshView: function(f) {
        var b, a;
        if (undefined !== this.dataType) {
            var c = this.getTemplateTarget();
            this.clearSelections(false, true);
            b = this.getThumbnailRange();
            a = this.getStore().getRange();
            var e = false;
            if (a.length < 1) {
                if (!this.deferEmptyText || this.hasSkippedEmptyText) {
                    c.update(this.emptyText)
                }
                this.all.clear()
            } else {
                var d = this.collectData(a, 0, b);
                if (!f || d.length !== this.lastRenderCount) {
                    this.lastRenderCount = d.length;
                    this.tpl.overwrite(c, this.collectData(a, 0, b));
                    this.all.fill(Ext.query(this.itemSelector, c.dom));
                    this.updateIndexes(0);
                    this.preloadItems()
                }
                if (this.store.getTotalCount() > d.length) {
                    e = true
                }
            }
            this.module.setMoreButtonDisplay.call(this.module, this.dataType, e);
            this.hasSkippedEmptyText = true;
            this.updateScrollbar()
        } else {
            if (!f) {
                this.preloadItems()
            }
            this.updateScrollbar()
        }
    },
    updateSortInfo: function() {
        var b = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo().params.api;
        var a;
        if (this._getUtils().isDisableSortPage()) {
            return
        }
        if (b === "SYNO.AudioStation.Folder" || b === "SYNO.AudioStation.Song") {
            a = this.getSortInfo("MusicColumnSetting")
        } else {
            if (b === "SYNO.AudioStation.Album") {
                a = this.getSortInfo("AlbumColumnSetting")
            } else {
                if (b === "SYNO.AudioStation.Artist" || b === "SYNO.AudioStation.Composer" || b === "SYNO.AudioStation.Genre") {
                    a = this.getSortInfo("BasicColumnSetting")
                }
            }
        }
        if (a) {
            this.store[this.store.remoteSort ? "setDefaultSort" : "sort"](a.field, a.direction)
        }
    },
    getSortInfo: function(b) {
        var a = SYNO.SDS.AudioStation.Window.appInstance.getUserSettings(b);
        return ("" === b || !a || !a.sort) ? null : a.sort
    },
    onNodeDbClick: function(b, c, d, a) {
        var f = b.getStore().getAt(c),
            e = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (!f) {
            return false
        }
        if (this._getUtils().isTrack(f)) {
            this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").addQueue(f)
        } else {
            e.focusIdx = c;
            this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").gotoNext(f, this.dataType)
        }
    },
    onNodeClick: function(b, c, d, a) {
        if (undefined !== this.dataType) {
            this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").clearSelections(b, true)
        }
        if (!SYNO.SDS.AudioStation.Utils.isWindowsTablet()) {
            return
        }
        var f, e;
        f = b.getStore().getAt(c);
        e = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if (f && !this._getUtils().isTrack(f)) {
            e.focusIdx = c;
            this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").gotoNext(f)
        }
    },
    onShowItemMenu: function(b, a, c, d) {
        if (!b.isSelected(a)) {
            b.select(a, false)
        }
        if (undefined !== this.dataType) {
            this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").clearSelections(b, true)
        }
        this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").onShowItemMenu(b, d)
    },
    getTemplateTarget: function() {
        var a = this;
        a.scrollBar = a.scrollBar || a.el.createChild({
            tag: "div",
            style: "display:inline-block;width:100%;"
        });
        return a.scrollBar
    },
    onActivate: function() {
        if (this.store !== this.getStore()) {
            this.bindStore(this.getStore())
        }
        this.updateSortInfo();
        if (0 < this.store.getCount()) {
            this.preloadItems()
        }
        this.on("render", this.onViewRender, this, {
            buffer: 80
        });
        this.on("resize", this.onViewResize, this, {
            buffer: 80
        });
        this.store.on("load", this.onStoreLoad, this)
    },
    onDeactivate: function() {
        this.store.un("load", this.onStoreLoad, this);
        this.un("resize", this.onViewResize, this);
        this.un("render", this.onViewRender, this);
        this.bindStore(null)
    },
    onStoreLoad: function() {
        this.refreshView()
    },
    getStore: function() {
        if (this.dataType === "artist") {
            return this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").searchAllArtistStore
        } else {
            if (this.dataType === "album") {
                return this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").searchAllAlbumStore
            }
        }
        return this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").dataStore
    },
    onLoadItem: function(a) {
        this.getImageItems([a], this.loader.insertJob.createDelegate(this.loader))
    },
    selectAll: function() {
        var b = this.getStore().getCount(),
            a;
        for (a = 0; a < b; a++) {
            this.select(a, true, true)
        }
    },
    onNodeMouseEnter: function(a, b, d, f) {
        var g = a.getStore().getAt(b),
            c = Ext.fly(d).child(".syno-as-thumb-play");
        if (!g || !c) {
            return
        }
        if (this.checkPlayable(g)) {
            c.removeAllListeners();
            c.on("click", this.onNodePlayIconClick.createDelegate(this, [g]), this);
            c.addClass("syno-as-show-play-icon")
        }
    },
    onNodeMouseLeave: function(a, b, d, f) {
        var c = Ext.fly(d).child(".syno-as-thumb-play");
        if (c) {
            c.removeClass("syno-as-show-play-icon")
        }
    },
    onNodePlayIconClick: function(c) {
        var b = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main"),
            a;
        if ("artist" === this.dataType) {
            a = SYNO.SDS.AudioStation.Utils.getContainerJsonList([c], b.searchAllArtistStore)
        } else {
            if ("album" === this.dataType) {
                a = SYNO.SDS.AudioStation.Utils.getContainerJsonList([c], b.searchAllAlbumStore)
            } else {
                a = SYNO.SDS.AudioStation.Utils.getContainerJsonList([c], b.dataStore)
            }
        }
        b.onPlayingQueueCommit("updateplaylist", true, null, a, 0, b.playingStore.getTotalCount())
    },
    onViewRender: function(a) {
        a.dragZone = new SYNO.SDS.AudioStation.DataViewDragZone(a, {
            ddGroup: a.ddGroup
        }, this)
    },
    checkPlayable: function(b) {
        var a = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        if ("file" === b.get("type")) {
            return false
        }
        if (this._getUtils().isAtHomepage() && !this._getUtils().isDefaultGenreRecord(b)) {
            if ("recently_added" !== b.get("type")) {
                return true
            }
        } else {
            if ("SYNO.AudioStation.Album" === a.params.api || "SYNO.AudioStation.Artist" === a.params.api || "SYNO.AudioStation.Composer" === a.params.api || "SYNO.AudioStation.Folder" === a.params.api || "SYNO.AudioStation.Genre" === a.params.api || "SYNO.AudioStation.Search" === a.params.api) {
                return true
            } else {
                if (this._getUtils().isAtPinList()) {
                    if ("recently_added" !== b.get("type")) {
                        return true
                    }
                }
            }
        }
        return false
    },
    getTpl: function() {
        var a = new Ext.XTemplate('<tpl for=".">', '<div class="thumb-wrap">', '<div class="thumb thumb-loading" >', '<img thumbnails="{[this.getImageURL(values)]}">', '<div class="syno-as-thumb-sharing-status {[this.getSharingStatusCls(values)]}"></div>', '<div class="syno-as-thumb-play"></div>', "</div>", '<span class="thumb-title">{[this.getTitle(values)]}</span>', '<span class="thumb-artist">{[this.getArtist(values)]}</span>', "</div>", "</tpl>", '<div class="x-clear"></div>', {
            getTitle: function(b) {
                var c = b.title || b.name;
                c = SYNO.SDS.AudioStation.Utils.getRenderedTitle(c, b.id);
                return Ext.util.Format.htmlEncode(c)
            },
            getImageURL: this.processImgUrl.createDelegate(this, [], true),
            getArtist: function(b) {
                if (b.album_artist) {
                    return Ext.util.Format.htmlEncode(b.album_artist)
                } else {
                    if (b.artist) {
                        return Ext.util.Format.htmlEncode(b.artist)
                    } else {
                        return ""
                    }
                }
            },
            getSharingStatusCls: function(b) {
                if ("valid" == b.sharing_status) {
                    return "st-valid"
                } else {
                    if ("invalid" == b.sharing_status || "expired" == b.sharing_status) {
                        return "st-invalid"
                    }
                }
                return ""
            }
        });
        return a
    },
    processImgUrl: function(a) {
        return SYNO.SDS.AudioStation.Utils.processAlbumArtUrl(a, this.dataType)
    },
    getThumbnailRange: function() {
        var a = this,
            c, d, b;
        if (a.all.elements[0]) {
            b = Ext.get(a.all.elements[0]);
            c = b.getWidth() + b.getMargins().right;
            d = Math.floor(a.getWidth() / c)
        }
        return d
    },
    beforeNodeSelect: function() {}
});
Ext.define("SYNO.SDS.AudioStation.SearchAllView", {
    extend: "SYNO.ux.Panel",
    constructor: function(a) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.call(this.cfg);
        SYNO.SDS.AudioStation.Window.addPanelScope("SYNO.SDS.AudioStation.SearchAllView", this);
        this.audioMain = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main");
        this.baseURL = SYNO.SDS.AudioStation.Window.baseURL;
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        this.artistTitlePanel = new SYNO.ux.Panel({
            itemId: "artistTitle",
            region: "north",
            layout: "border",
            height: 38,
            items: [{
                itemId: "byArtistDiv",
                xtype: "container",
                region: "center",
                html: "<div>" + _AST("common", "class_music_artist") + "</div>",
                cls: "syno-search-all-container syno-search-all-by-artist"
            }, {
                xtype: "container",
                region: "east",
                layout: "border",
                itemId: "btnShowmoreWrap",
                width: 34,
                items: [{
                    itemId: "artistMoreBtn",
                    xtype: "syno_button",
                    region: "center",
                    margins: {
                        top: 2,
                        bottom: 2,
                        right: 10
                    },
                    cls: "syno-search-all-more-btn",
                    hidden: true,
                    scope: this,
                    handler: this.onMoreBtnClick
                }]
            }]
        });
        this.artistDataView = new SYNO.SDS.AudioStation.ThumbDataView({
            itemId: "artistDataView",
            dataType: "artist",
            module: this,
            region: "center"
        });
        this.artistPanel = new SYNO.ux.Panel({
            itemId: "artistPanel",
            layout: "border",
            cls: "syno-search-all-panel",
            items: [this.artistTitlePanel, this.artistDataView]
        });
        this.albumTitlePanel = new SYNO.ux.Panel({
            itemId: "albumTitle",
            region: "north",
            layout: "border",
            height: 38,
            items: [{
                itemId: "byAlbumDiv",
                xtype: "container",
                region: "center",
                html: "<div>" + _AST("common", "class_music_album") + "</div>",
                cls: "syno-search-all-container syno-search-all-by-album"
            }, {
                xtype: "container",
                region: "east",
                layout: "border",
                itemId: "btnShowmoreWrap",
                width: 34,
                items: [{
                    itemId: "albumMoreBtn",
                    xtype: "syno_button",
                    region: "center",
                    margins: {
                        top: 2,
                        bottom: 2,
                        right: 10
                    },
                    cls: "syno-search-all-more-btn",
                    hidden: true,
                    scope: this,
                    handler: this.onMoreBtnClick
                }]
            }]
        });
        this.albumDataView = new SYNO.SDS.AudioStation.ThumbDataView({
            itemId: "albumDataView",
            dataType: "album",
            module: this,
            region: "center"
        });
        this.albumPanel = new SYNO.ux.Panel({
            itemId: "albumPanel",
            layout: "border",
            cls: "syno-search-all-panel",
            items: [this.albumTitlePanel, this.albumDataView]
        });
        this.songTitlePanel = new SYNO.ux.Panel({
            itemId: "songTitle",
            region: "north",
            layout: "border",
            height: 38,
            items: [{
                itemId: "bySongDiv",
                xtype: "container",
                region: "center",
                html: "<div>" + _AST("common", "class_music_song") + "</div>",
                cls: "syno-search-all-container syno-search-all-by-song"
            }, {
                xtype: "container",
                region: "east",
                layout: "border",
                itemId: "btnShowmoreWrap",
                width: 34,
                items: [{
                    itemId: "songMoreBtn",
                    xtype: "syno_button",
                    region: "center",
                    margins: {
                        top: 2,
                        bottom: 2,
                        right: 10
                    },
                    cls: "syno-search-all-more-btn",
                    hidden: true,
                    scope: this,
                    handler: this.onMoreBtnClick
                }]
            }]
        });
        this.songListView = new SYNO.SDS.AudioStation.ListViewGrid({
            itemId: "songListView",
            dataType: "song",
            module: this,
            region: "center"
        });
        this.songPanel = new SYNO.ux.Panel({
            itemId: "songPanel",
            padding: "3px 0 24px 0",
            layout: "border",
            height: 376,
            cls: "syno-search-all-panel",
            items: [this.songTitlePanel, this.songListView]
        });
        var b = {
            xtype: "syno_panel",
            itemId: "searchAllView",
            style: "margin-top: 3px;",
            autoFlexcroll: true,
            items: [this.artistPanel, this.albumPanel, this.songPanel],
            plugins: [SYNO.SDS.AudioStation.FocusComponentPluginInstance],
            layout: {
                type: "vbox",
                align: "stretch",
                pack: "start"
            },
            listeners: {
                activate: this.onActivate,
                deactivate: this.onDeactivate
            }
        };
        Ext.apply(b, a);
        return b
    },
    onActivate: function() {
        this.artistDataView.onActivate();
        this.albumDataView.onActivate();
        this.songListView.onActivate()
    },
    onDeactivate: function() {
        this.artistDataView.onDeactivate();
        this.albumDataView.onDeactivate()
    },
    onMoreBtnClick: function(a, d) {
        var g = a.itemId;
        var c = SYNO.SDS.AudioStation.Window.pathMgr.getHistoryInfo();
        var b = c.params.keyword;
        var f = {};
        if ("artistMoreBtn" === g) {
            f.api = "SYNO.AudioStation.Artist";
            f.text = _AST("common", "class_music_artist");
            f.method = "list";
            f.library = SYNO.SDS.AudioStation.Window.getBrowseLibraryType();
            f.filter = b
        } else {
            if ("albumMoreBtn" === g) {
                f.api = "SYNO.AudioStation.Album";
                f.text = _AST("common", "class_music_album");
                f.method = "list";
                f.library = SYNO.SDS.AudioStation.Window.getBrowseLibraryType();
                f.filter = b
            } else {
                f.api = "SYNO.AudioStation.Song";
                f.method = "search";
                f.additional = "song_tag,song_audio,song_rating";
                f.text = _AST("common", "class_music_allmusic");
                f.library = SYNO.SDS.AudioStation.Window.getBrowseLibraryType();
                f.title = b
            }
        }
        f.version = SYNO.SDS.AudioStation.Utils.webAPIVersion[f.api];
        f.keyword = b;
        SYNO.SDS.AudioStation.Window.pathMgr.gotoDetailSearchCate(f)
    },
    setMoreButtonDisplay: function(b, c) {
        var a;
        switch (b) {
            case "artist":
                a = this.artistTitlePanel;
                break;
            case "album":
                a = this.albumTitlePanel;
                break;
            case "song":
                a = this.songTitlePanel;
                break
        }
        a.getComponent("btnShowmoreWrap").getComponent(b + "MoreBtn").setVisible(c)
    }
});
Ext.define("SYNO.SDS.AudioStation.CardPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(b) {
        SYNO.SDS.AudioStation.Window.addPanelScope("SYNO.SDS.AudioStation.CardPanel", this);
        var d = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main");
        this.pathBar = new SYNO.SDS.AudioStation.PathBar.Main({
            scope: this
        });
        var e = [this.pathBar.getPanel(), "->"];
        e.push.apply(e, d.getActions());
        var a = new SYNO.ux.Toolbar({
            cls: "syno-as-toolbar syno-as-path-bar",
            itemId: "topToolbar",
            enableOverflow: false,
            items: e,
            listeners: {
                buffer: 100,
                show: this.resizePathbar,
                resize: this.resizePathbar,
                scope: this,
                render: {
                    single: true,
                    buffer: 80,
                    scope: this,
                    fn: function() {}
                }
            }
        });
        this.listViewGrid = new SYNO.SDS.AudioStation.ListViewGrid({
            region: "center"
        });
        this.thumbView = new SYNO.SDS.AudioStation.ThumbView({
            itemId: "thumbViewPanel"
        });
        this.albumView = new SYNO.ux.Panel({
            itemId: "albumCoverPanel",
            region: "west",
            width: 218,
            padding: "8px 0 0 0",
            cls: "syno-as-album-view",
            hidden: true,
            items: [{
                itemId: "albumCoverDiv",
                xtype: "container",
                cls: "syno-as-album-view-cover",
                items: [{
                    xtype: "box",
                    autoEl: {
                        cls: "syno-as-album-view-img",
                        tag: "img"
                    }
                }]
            }, {
                itemId: "title",
                xtype: "container",
                cls: "syno-as-album-view-album"
            }, {
                itemId: "artist",
                xtype: "container",
                cls: "syno-as-album-view-artist"
            }, {
                itemId: "avgRatingDiv",
                xtype: "container",
                html: SYNO.SDS.AudioStation.Utils.getStarHtml("avg_container")
            }]
        });
        this.listView = new SYNO.ux.Panel({
            itemId: "listViewPanel",
            border: false,
            layout: "border",
            monitorResize: true,
            items: [this.albumView, this.listViewGrid]
        });
        this.searchAllView = new SYNO.SDS.AudioStation.SearchAllView({
            itemId: "searchAllPanel"
        });
        this.homepageView = new SYNO.SDS.AudioStation.HomepageView({
            itemId: "homepagePanel"
        });
        this.allPinView = new SYNO.SDS.AudioStation.PinThumbDataView({
            itemId: "pinViewPanel"
        });
        var c = {
            xtype: "syno_panel",
            style: "padding-left:16px;padding-right:16px;padding-top:16px;",
            layout: "card",
            tbar: a,
            items: [this.homepageView, this.listView, this.thumbView, this.searchAllView, this.allPinView],
            border: false,
            cls: "syno-as-card"
        };
        Ext.apply(c, b);
        this.callParent([c]);
        this.listViewGrid.relayEvents(this.listView, ["activate", "deactivate"])
    },
    resizePathbar: function() {
        var b = 0;
        var c = this.getTopToolbar();
        if (!c.rendered) {
            return
        }
        c.items.each(function(f) {
            if (true !== f.hidden) {
                try {
                    b += f.getOuterSize().width
                } catch (g) {}
            }
        });
        b -= this.pathBar.tbPanel.getWidth();
        var a = c.getWidth() - c.getResizeEl().getPadding("lr") - 2;
        var d = a - b;
        if (d > 0) {
            this.pathBar.setWidth(d)
        }
    }
});
Ext.define("SYNO.SDS.AudioStation.EnableColumn", {
    extend: "SYNO.ux.EnableColumn",
    constructor: function() {
        this.callParent(arguments)
    },
    isIgnore: function(b, a) {
        if (Ext.isEmpty(this.ignoreKey)) {
            return this.callParent(arguments)
        }
        return (true === a.get(this.ignoreKey))
    },
    renderer: function(g, e, a, f, c, b) {
        var d = this.scope;
        if (d.ignoreKey && a.get(d.ignoreKey) === true) {
            return this.callParent(["gray", e, a, f, c, b])
        } else {
            return this.callParent(arguments)
        }
    }
});
Ext.define("SYNO.SDS.AudioStation.UserGrid", {
    extend: "SYNO.ux.GridPanel",
    baseURL: undefined,
    ownerDialog: undefined,
    constructor: function(b, a) {
        this.baseURL = b.baseURL;
        this.ownerDialog = b.ownerDialog;
        this.dataStore = this.createStore();
        this.audioAppWindow = a;
        var c = this.fillConfig(b);
        this.callParent([c])
    },
    fillConfig: function(b) {
        var f = new SYNO.ux.PagingToolbar({
            cls: "syno-as-paging-toolbar",
            pageSize: 50,
            store: this.dataStore,
            displayInfo: true
        });
        var h = new SYNO.SDS.AudioStation.EnableColumn({
            header: _AST("common", "right_upnp_mode"),
            id: "usb",
            dataIndex: "usb",
            ignoreKey: "isAdminGroup"
        });
        var g = new SYNO.SDS.AudioStation.EnableColumn({
            header: _AST("common", "right_upnp_browsing"),
            id: "upnp",
            dataIndex: "upnp",
            ignoreKey: "isAdminGroup"
        });
        var e = new SYNO.SDS.AudioStation.EnableColumn({
            header: _AST("user", "user_column_playlist"),
            id: "playlist",
            dataIndex: "playlist",
            ignoreKey: "isAdminGroup"
        });
        var d = new SYNO.SDS.AudioStation.EnableColumn({
            header: _AST("user", "user_column_edit_song"),
            id: "editsong",
            dataIndex: "editsong",
            ignoreKey: "isAdminGroup"
        });
        var a = new SYNO.SDS.AudioStation.EnableColumn({
            header: _AST("sharing", "public_sharing"),
            id: "sharing",
            dataIndex: "sharing",
            ignoreKey: "isAdminGroup"
        });
        var c = {
            title: _AST("user", "user_title"),
            store: this.dataStore,
            loadMask: true,
            cls: "syno-as-setting-grid syno-audio-scroll",
            overCls: "syno-audio-scroll-over",
            stripeRows: true,
            enableHdMenu: false,
            enableColumnMove: false,
            selModel: new Ext.grid.RowSelectionModel(),
            bbar: f,
            viewConfig: {
                autoFill: true,
                forceFit: true
            },
            columns: [{
                header: _AST("user", "user_column_name"),
                id: "name",
                dataIndex: "name",
                sortable: false
            }, h, g, e, d, a],
            plugins: [h, g, e, d, a]
        };
        Ext.apply(c, b);
        return c
    },
    createStore: function() {
        var a = new Ext.data.JsonReader({
            root: "items",
            totalProperty: "total",
            id: "id"
        }, ["name", "usb", "upnp", "playlist", "editsong", "sharing", "isAdminGroup"]);
        var b = new Ext.data.Store({
            proxy: new Ext.data.HttpProxy({
                url: this.baseURL + "/webUI/audio_userman.cgi",
                method: "POST"
            }),
            reader: a,
            remoteSort: false,
            baseParams: {
                action: "enum",
                start: 0,
                limit: 50
            },
            pruneModifiedRecords: true
        });
        b.on("beforeload", function(d, e) {
            var c = d.getModifiedRecords();
            if (c.length) {
                this.ownerDialog.getMsgBox().confirm(this.title, _AST("user", "user_save_chg_before_reload"), function(f) {
                    if ("yes" === f) {
                        this.saveUserSetting(e)
                    } else {
                        d.rejectChanges();
                        d.load(e)
                    }
                }, this);
                return false
            }
            return true
        }, this);
        return b
    },
    getModifiedUserSetting: function() {
        var b = this.dataStore.getModifiedRecords();
        var a = ["usb", "upnp", "playlist", "editsong", "sharing"];
        var c = {};
        if (b.length === 0) {
            return null
        }
        Ext.each(b, function(e) {
            var d = {};
            Ext.each(a, function(f) {
                d[f] = e.get(f)
            });
            c[e.get("name")] = d
        });
        return c
    },
    saveUserSetting: function(a) {
        var b = this.getModifiedUserSetting();
        if (!b) {
            return
        }
        Ext.Ajax.request({
            url: this.baseURL + "/webUI/audio_userman.cgi",
            params: {
                items: Ext.encode(b),
                action: "apply"
            },
            method: "POST",
            callback: function(d, e, c) {
                if (e) {
                    this.dataStore.commitChanges();
                    this.dataStore.load(a)
                } else {
                    this.ownerDialog.getMsgBox().alert(_AST("user", "user_title"), _AST("user", "error_apply"))
                }
            },
            scope: this
        })
    }
});
Ext.define("SYNO.SDS.AudioStation.LyricsPlugInPanel", {
    extend: "SYNO.ux.DDGridPanel",
    baseURL: undefined,
    owner: undefined,
    dataStore: undefined,
    constructor: function(a) {
        this.baseURL = a.baseURL;
        this.dataStore = this.createStore();
        this.owner = a.owner;
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        var c = new SYNO.ux.EnableColumn({
            header: _AST("common", "enabled"),
            dataIndex: "enable",
            width: 50
        });
        var b = {
            title: _AST("setting", "lyrics_plugin_title"),
            itemId: "lyricsPlugInPanel",
            cls: "syno-as-setting-grid",
            stripeRows: true,
            enableDragDrop: true,
            viewConfig: {
                autoFill: true,
                forceFit: true,
                ddGroup: "LyricsPluginDD"
            },
            tbar: {
                xtype: "syno_toolbar",
                items: [{
                    text: _AST("common", "btn_add"),
                    handler: this.uploadPlugInHandler,
                    disabled: _S("demo_mode"),
                    tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                    scope: this
                }, {
                    text: _AST("common", "btn_delete"),
                    itemId: "deleteButton",
                    handler: this.deletePlugInHandler,
                    disabled: true,
                    tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                    scope: this
                }]
            },
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: true,
                listeners: {
                    selectionchange: {
                        fn: function() {
                            var d = this.getSelectionModel();
                            if (!d.hasSelection() || _S("demo_mode")) {
                                this.getTopToolbar().getComponent("deleteButton").setDisabled(true)
                            } else {
                                this.getTopToolbar().getComponent("deleteButton").setDisabled(false)
                            }
                        },
                        scope: this
                    }
                }
            }),
            colModel: new Ext.grid.ColumnModel({
                columns: [c, {
                    header: _AST("common", "name"),
                    dataIndex: "displayname",
                    renderer: function(g, e, f) {
                        var d = Ext.util.Format.htmlEncode(g);
                        return d
                    }
                }, {
                    header: _AST("common", "literal_description"),
                    dataIndex: "description",
                    renderer: function(g, e, f) {
                        var d = Ext.util.Format.htmlEncode(g);
                        e.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(d) + '"';
                        return d
                    }
                }, {
                    header: _AST("common", "version"),
                    dataIndex: "version",
                    width: 60,
                    renderer: function(g, e, f) {
                        var d = Ext.util.Format.htmlEncode(g);
                        return d
                    }
                }]
            }),
            store: this.dataStore,
            plugins: [c],
            enableHdMenu: false
        };
        Ext.apply(b, a);
        SYNO.LayoutConfig.fill(b);
        return b
    },
    createStore: function() {
        var a = new Ext.data.JsonReader({
            root: "plugins"
        }, ["name", "enable", "displayname", "version", "description"]);
        var b = new Ext.data.Store({
            proxy: new Ext.data.HttpProxy({
                url: this.baseURL + "/webUI/audio_search_lyrics.cgi",
                method: "POST"
            }),
            reader: a,
            remoteSort: false,
            baseParams: {
                action: "getLyricsPlugInInfo"
            },
            pruneModifiedRecords: true
        });
        return b
    },
    uploadPlugInHandler: function() {
        var a = new SYNO.SDS.AudioStation.AddLyricsPlugInDialog({
            owner: this.owner,
            baseURL: this.baseURL,
            dataStore: this.dataStore
        });
        a.show()
    },
    deletePlugInHandler: function() {
        var a = this.getSelectionModel();
        var c = [];
        var b = [];
        if (!a.hasSelection()) {
            return
        }
        this.owner.getMsgBox().confirmDelete(_AST("setting", "lyrics_plugin_delete"), _AST("setting", "lyrics_plugin_confirm_delete"), function(e) {
            if ("no" === e) {
                return
            }
            for (var d = 0; d < this.dataStore.getCount(); d++) {
                if (a.isSelected(d)) {
                    var f = this.dataStore.getAt(d);
                    c.push(f.data.name);
                    b.push(f)
                }
            }
            Ext.Ajax.request({
                url: this.baseURL + "/webUI/audio_search_lyrics.cgi",
                params: {
                    action: "deletePlugIn",
                    deletelist: Ext.encode(c)
                },
                method: "POST",
                callback: function(j, k, g) {
                    if (k) {
                        for (var h = 0; h < b.length; h++) {
                            this.dataStore.remove(b[h])
                        }
                    }
                },
                scope: this
            })
        }, this)
    },
    getModifiedPlugInInfo: function() {
        var a = [];
        this.dataStore.each(function(b) {
            a.push({
                name: b.data.name,
                enable: b.data.enable
            })
        }, this);
        return a
    }
});
Ext.define("SYNO.SDS.AudioStation.AddLyricsPlugInDialog", {
    extend: "SYNO.SDS.ModalWindow",
    baseURL: undefined,
    owner: undefined,
    dataStore: undefined,
    constructor: function(a) {
        this.baseURL = a.baseURL;
        this.owner = a.owner;
        this.dataStore = a.dataStore;
        var b = this.fillConfig(a);
        this.callParent([b]);
        this.defineBehaviors()
    },
    fillConfig: function(a) {
        var b = {
            cls: "syno-as-dialog",
            width: 550,
            height: 200,
            shadow: true,
            resizable: false,
            collapsible: false,
            autoScroll: false,
            constrainHeader: true,
            plain: true,
            monitorResize: true,
            title: _AST("setting", "lyrics_plugin_add"),
            layout: "fit",
            items: [this.initFormConfig()],
            buttons: [{
                text: _AST("common", "btn_cancel"),
                handler: this.onCloseHandler,
                scope: this
            }, {
                text: _AST("common", "btn_add"),
                btnStyle: "blue",
                handler: this.onSubmit,
                scope: this
            }]
        };
        Ext.apply(b, a);
        SYNO.LayoutConfig.fill(b);
        return b
    },
    initFormConfig: function() {
        var a = {
            xtype: "syno_formpanel",
            fileUpload: true,
            itemId: "formpanel",
            labelAlign: "left",
            trackResetOnLoad: true,
            waitMsgTarget: true,
            url: this.baseURL + "/webUI/audio_search_lyrics.cgi",
            border: false,
            labelWidth: 161,
            items: [{
                xtype: "syno_filebutton",
                itemId: "singleselectfield",
                fieldLabel: _AST("setting", "open_file"),
                buttonMargin: 6,
                hideMode: "display",
                name: "plugin",
                listeners: {
                    render: {
                        fn: function(b) {
                            b.getEl().dom.accept = ".aum"
                        },
                        single: true
                    }
                }
            }, {
                xtype: "syno_displayfield",
                cls: "syno-as-lyrics-add-text",
                value: Ext.util.Format.htmlEncode("( eg. search.aum)"),
                listeners: {
                    scope: this,
                    single: true,
                    afterrender: function(b) {
                        SYNO.SDS.Utils.AddTip(b.getEl(), _AST("setting", "show_lyric_legal_issue"))
                    }
                }
            }],
            listeners: {
                scope: this,
                actioncomplete: this.onActionComplete,
                actionfailed: this.onActionFailed
            }
        };
        return a
    },
    defineBehaviors: function() {
        this.form = this.get("formpanel").form
    },
    onCloseHandler: function() {
        this.close()
    },
    onSubmit: function() {
        var a = this.form.findField("plugin").getValue();
        if (a === "") {
            this.getMsgBox().alert(_T("error", "error_error"), _AST("setting", "error_lyrics_empty_input_file"));
            return
        } else {
            if (!SYNO.SDS.AudioStation.Utils.isValidExtension(a, ".aum")) {
                this.getMsgBox().alert(_T("error", "error_error"), _AST("setting", "error_lyrics_wrong_file_format"));
                return
            }
        }
        this.form.doAction("submit", {
            waitMsg: _AST("common", "saving")
        })
    },
    onBeforeAction: function() {},
    onActionComplete: function(b, a) {
        if (!a || a.type !== "submit") {
            return
        }
        if (!a.result || a.result.errno) {
            this.getMsgBox().alert(_T("error", "error_error"), _AST("common", "error_common"));
            return
        }
        if (!a.result.update) {
            var c = new Ext.data.Record(a.result.pluginInfo);
            this.dataStore.add(c)
        } else {
            this.owner.getMsgBox().confirm(_AST("setting", "lyrics_plugin_title"), _AST("setting", "lyrics_plugin_confirm_override"), function(d) {
                if ("yes" === d) {
                    a.result.doupdate = true
                } else {
                    a.result.doupdate = false
                }
                this.doUpdateRequest(a.result)
            }, this)
        }
        this.onCloseHandler()
    },
    doUpdateRequest: function(a) {
        Ext.Ajax.request({
            url: this.baseURL + "/webUI/audio_search_lyrics.cgi",
            params: {
                action: "afterUpload",
                doupdate: a.doupdate,
                tmpname: a.tmpname
            },
            callback: function(e, g, b) {
                var d = Ext.decode(b.responseText);
                var f = new Ext.data.Record(d.pluginInfo);
                var c = this.dataStore.find("name", f.data.name);
                if (!g) {
                    this.getMsgBox().alert(_T("error", "error_error"), _AST("common", "error_common"));
                    return
                }
                if (!a.doupdate) {
                    return
                }
                if (-1 === c) {
                    this.dataStore.add(f)
                } else {
                    this.dataStore.removeAt(c);
                    this.dataStore.insert(c, f)
                }
            },
            method: "POST",
            scope: this
        })
    },
    onActionFailed: function(c, b) {
        var d;
        if (b.failureType == Ext.form.Action.CLIENT_INVALID) {
            d = _AST("common", "forminvalid")
        } else {
            if (b.failureType == Ext.form.Action.CONNECT_FAILURE) {
                d = _AST("common", "error_connect_fail")
            } else {
                if (typeof b.result.errno == "object") {
                    var a = b.result.errno;
                    d = _AST(a.section, a.key)
                } else {
                    if (b.failureType == Ext.form.Action.SERVER_INVALID) {
                        d = _AST("common", "error_connect_fail")
                    } else {
                        d = _AST("common", "error_common")
                    }
                }
            }
        }
        this.getMsgBox().alert(_T("error", "error_error"), d)
    }
});
Ext.define("SYNO.SDS.AudioStation.ImportItunesXMLDialog", {
    extend: "SYNO.SDS.ModalWindow",
    baseURL: undefined,
    owner: undefined,
    constructor: function(a) {
        this.baseURL = a.baseURL;
        this.owner = a.owner;
        var b = this.fillConfig(a);
        this.closeHandler = false;
        this.importHandler = false;
        this.callParent([b]);
        this.fileForm = this.get("fileFormpanel").form
    },
    fillConfig: function(a) {
        var b = {
            cls: "syno-as-dialog",
            width: 550,
            height: 240,
            padding: "16px 16px 0px 16px",
            shadow: true,
            resizable: false,
            collapsible: false,
            autoScroll: false,
            constrainHeader: true,
            plain: true,
            monitorResize: true,
            title: _AST("setting", "itunes_import_song_rating"),
            layout: {
                type: "vbox",
                align: "stretch",
                pack: "start"
            },
            items: [this.initFileFormConfig(), this.initOptionFormConfig()],
            buttons: [{
                text: _AST("common", "btn_cancel"),
                handler: this.onCloseHandler,
                scope: this
            }, {
                text: _AST("setting", "itunes_import"),
                btnStyle: "blue",
                id: this.importButtonId = Ext.id(),
                handler: this.onImportHandler,
                scope: this
            }]
        };
        Ext.apply(b, a);
        SYNO.LayoutConfig.fill(b);
        return b
    },
    initOptionFormConfig: function() {
        var a = {
            xtype: "syno_formpanel",
            fileUpload: false,
            itemId: "optionFormPanel",
            labelAlign: "left",
            border: false,
            labelWidth: 161,
            items: [{
                xtype: "syno_checkbox",
                boxLabel: _AST("setting", "itunes_overwrite_song_rating"),
                id: this.iTunesOverwrite = Ext.id()
            }]
        };
        return a
    },
    initFileFormConfig: function() {
        var a = {
            xtype: "syno_formpanel",
            fileUpload: true,
            itemId: "fileFormpanel",
            labelAlign: "left",
            trackResetOnLoad: true,
            waitMsgTarget: true,
            url: this.baseURL + "/webUI/audio_itunes_import.cgi",
            border: false,
            labelWidth: 161,
            items: [{
                xtype: "syno_filebutton",
                itemId: "singleselectfield",
                fieldLabel: _AST("setting", "open_file"),
                hideMode: "display",
                name: "iTunesXML",
                listeners: {
                    render: {
                        fn: function(b) {
                            b.getEl().dom.accept = ".xml"
                        },
                        single: true
                    }
                }
            }, {
                xtype: "syno_displayfield",
                itemCls: "syno-as-itunes-import-song-rating",
                value: Ext.util.Format.htmlEncode("( eg. iTunes.xml)")
            }],
            listeners: {
                scope: this,
                actioncomplete: this.onActionComplete,
                actionfailed: this.onActionFailed
            }
        };
        return a
    },
    onBeforeAction: function() {},
    deleteUploadPath: function() {
        Ext.Ajax.request({
            url: this.baseURL + "/webUI/audio_itunes_import.cgi",
            method: "POST",
            scope: this,
            params: {
                action: "delete_upload_file"
            },
            callback: function(b, c, a) {}
        })
    },
    onActionComplete: function(b, a) {
        if (this.closeHandler) {
            this.deleteUploadPath();
            this.close();
            return
        }
        this.importHandler = false;
        if (!a || "submit" !== a.type) {
            return
        }
        if (!a.result || a.result.errno) {
            this.getMsgBox().alert(_T("error", "error_error"), _AST("common", "error_common"));
            return
        }
        if ("format error" === a.result.errMsg) {
            this.setConfigDisabled(false);
            this.getMsgBox().alert(_T("error", "error_error"), _AST("setting", "itunes_database_format_error"));
            return
        }
        this.owner.optionPanel.setProgressSet(-1);
        this.importItunesRequest(a.result);
        this.close()
    },
    importItunesRequest: function(a) {
        Ext.Ajax.request({
            url: this.baseURL + "/webUI/audio_itunes_import.cgi",
            method: "POST",
            scope: this,
            params: {
                action: "import_itunes_song_rating",
                uploadPath: a.uploadPath,
                overwrite: Ext.getCmp(this.iTunesOverwrite).getValue()
            },
            callback: function(d, e, b) {
                var c = Ext.decode(b.responseText);
                if (!e) {
                    this.getMsgBox().alert(_T("error", "error_error"), _AST("common", "error_common"));
                    return
                }
                if (!c.success) {
                    this.getMsgBox().alert(_T("error", "error_error"), _AST("setting", "itunes_import_song_rating_error"));
                    return
                }
            }
        })
    },
    onActionFailed: function(c, b) {
        this.setConfigDisabled(false);
        this.importHandler = false;
        var d;
        if (b.failureType == Ext.form.Action.CLIENT_INVALID) {
            d = _AST("common", "forminvalid")
        } else {
            if (b.failureType == Ext.form.Action.CONNECT_FAILURE) {
                d = _AST("common", "error_connect_fail")
            } else {
                if (typeof b.result.errno == "object") {
                    var a = b.result.errno;
                    d = _AST(a.section, a.key)
                } else {
                    if (b.failureType == Ext.form.Action.SERVER_INVALID) {
                        d = _AST("common", "error_connect_fail")
                    } else {
                        d = _AST("common", "error_common")
                    }
                }
            }
        }
        this.getMsgBox().alert(_T("error", "error_error"), d)
    },
    onImportHandler: function() {
        this.setConfigDisabled(true);
        var a = this.fileForm.findField("iTunesXML").getValue();
        if ("" === a) {
            this.setConfigDisabled(false);
            this.getMsgBox().alert(_T("error", "error_error"), _AST("setting", "error_lyrics_empty_input_file"));
            return
        } else {
            if (!SYNO.SDS.AudioStation.Utils.isValidExtension(a, ".xml")) {
                this.setConfigDisabled(false);
                this.getMsgBox().alert(_T("error", "error_error"), _AST("setting", "error_lyrics_wrong_file_format"));
                return
            }
        }
        this.fileForm.doAction("submit", {
            waitMsg: _AST("common", "saving")
        });
        this.importHandler = true
    },
    setConfigDisabled: function(a) {
        Ext.getCmp(this.importButtonId).setDisabled(a);
        Ext.getCmp(this.iTunesOverwrite).setDisabled(a)
    },
    onCloseHandler: function() {
        if (!this.importHandler) {
            this.close();
            return
        }
        this.closeHandler = true;
        this.setStatusBusy({
            text: _AST("common", "btn_cancel") + "..."
        })
    }
});
Ext.define("SYNO.SDS.AudioStation.OptionPanel", {
    extend: "SYNO.ux.FormPanel",
    baseURL: undefined,
    onwer: undefined,
    constructor: function(a) {
        var b = this.fillConfig(a);
        this.baseURL = a.baseURL;
        this.owner = a.owner;
        this.callParent([b])
    },
    fillConfig: function(a) {
        var b = {
            title: _AST("common", "options"),
            header: false,
            border: false,
            itemId: "option",
            style: "padding-top: 12px;",
            bodyStyle: "padding-top: 0px;",
            trackResetOnLoad: true,
            listeners: {
                activate: {
                    scope: this,
                    fn: this.onActivate
                },
                deactivate: {
                    scope: this,
                    fn: this.onDeactivate
                }
            },
            items: []
        };
        b.items.push(this.importSongRatingField());
        if (SYNO.SDS.AudioStation.SessionData.support_virtual_library) {
            b.items.push(this.cueSheetField())
        }
        Ext.apply(b, a);
        return b
    },
    importSongRatingField: function() {
        var a = {
            xtype: "syno_fieldset",
            collapsible: true,
            title: _AST("setting", "itunes_import_song_rating_title"),
            items: [{
                xtype: "syno_displayfield",
                value: _AST("setting", "itunes_import_song_rating_desc")
            }, {
                xtype: "syno_compositefield",
                hideLabel: true,
                indent: 1,
                cls: "syno-as-progress-bar",
                items: [{
                    xtype: "syno_button",
                    disabled: _S("demo_mode"),
                    text: _AST("setting", "itunes_import_song_rating"),
                    id: this.iTunesBtnId = Ext.id(),
                    handler: this.importItunesXML,
                    scope: this
                }, {
                    xtype: "progress",
                    id: this.iTunesProgressId = Ext.id(),
                    name: "itunes_progress_bar",
                    renderTo: Ext.getBody(),
                    width: 200
                }, {
                    xtype: "syno_displayfield",
                    name: "itunes_percent",
                    id: this.iTunesPercentId = Ext.id()
                }]
            }]
        };
        return a
    },
    importItunesXML: function() {
        var a = new SYNO.SDS.AudioStation.ImportItunesXMLDialog({
            baseURL: this.baseURL,
            owner: this.owner
        });
        a.show()
    },
    cueSheetField: function() {
        var a = {
            xtype: "syno_fieldset",
            collapsible: true,
            title: _AST("setting", "cue_sheet_title"),
            items: [{
                xtype: "syno_checkbox",
                itemId: "audio_show_virtual_library",
                name: "audio_show_virtual_library",
                boxLabel: _AST("setting", "show_virtual_library")
            }]
        };
        return a
    },
    onActivate: function() {
        Ext.getCmp(this.iTunesProgressId).hide();
        Ext.getCmp(this.iTunesPercentId).hide();
        if (undefined === this.pollingTask && !_S("demo_mode")) {
            this.pollingTask = this.addAjaxTask({
                id: "iTunesPollingTask",
                interval: 1000,
                autoJsonDecode: true,
                url: this.baseURL + "/webUI/audio_itunes_import.cgi",
                params: {
                    action: "load_itunes_progress"
                },
                success: function(a, b) {
                    this.setProgressSet(a.progress)
                },
                scope: this
            });
            this.pollingTask.start(true)
        }
    },
    onDeactivate: function() {
        if (undefined !== this.pollingTask) {
            this.pollingTask.remove();
            this.pollingTask = undefined
        }
    },
    setProgressSet: function(a) {
        if ((0 <= a && 1 > a) || (-1 == a)) {
            Ext.getCmp(this.iTunesBtnId).setDisabled(true);
            Ext.getCmp(this.iTunesProgressId).show();
            Ext.getCmp(this.iTunesPercentId).show();
            if (-1 == a) {
                Ext.getCmp(this.iTunesProgressId).updateProgress(0);
                Ext.getCmp(this.iTunesPercentId).setValue(_AST("setting", "init_status") + "...")
            } else {
                Ext.getCmp(this.iTunesProgressId).updateProgress(a);
                Ext.getCmp(this.iTunesPercentId).setValue(Math.ceil(a * 100) + "%")
            }
        } else {
            Ext.getCmp(this.iTunesBtnId).setDisabled(false);
            Ext.getCmp(this.iTunesProgressId).hide();
            Ext.getCmp(this.iTunesPercentId).hide()
        }
    },
});
Ext.define("SYNO.SDS.AudioStation.AdvancePanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(a) {
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        var b = {
            title: _AST("setting", "advanced_title"),
            itemId: "advance",
            trackResetOnLoad: true,
            style: "padding-top: 12px;",
            bodyStyle: "padding-top: 0px;",
            items: [],
            listeners: {
                afterlayout: {
                    single: true,
                    scope: this,
                    fn: this.onAfterLayout
                }
            }
        };
        b.items.push(this.generalField());
        b.items.push(this.dlnaField());
        Ext.apply(b, a);
        return b
    },
    onAfterLayout: function() {
        var a = this.getForm();
        var b;
        b = new SYNO.ux.Utils.EnableCheckGroup(a, "enable_amazon_alexa", ["amazon_alexa_hostname"])
    },
    generalField: function() {
        var a = {
            xtype: "syno_fieldset",
            collapsible: true,
            title: _AST("setting", "advanced_general"),
            labelWidth: 250,
            items: [{
                xtype: "syno_checkbox",
                itemId: "audio_enable_download",
                name: "audio_enable_download",
                boxLabel: _AST("setting", "enable_download")
            }, {
                xtype: "syno_checkbox",
                itemId: "enable_amazon_alexa",
                name: "enable_amazon_alexa",
                hidden: true,
                boxLabel: _AST("setting", "enable_amazon_alexa")
            }, {
                xtype: "syno_displayfield",
                itemId: "enable_amazon_alexa_alert",
                name: "enable_amazon_alexa_alert",
                indent: 1,
                htmlEncode: false,
                hidden: true,
                value: String.format('<span style="color:red ">{0}: {1}</span>', _T("common", "note"), _AST("setting", "enable_amazon_alexa_alert"))
            }, {
                xtype: "syno_displayfield",
                itemId: "amazon_alexa_hostname_note",
                name: "amazon_alexa_hostname_note",
                indent: 1,
                hidden: true,
                htmlEncode: false,
                value: String.format('<span class="syno-ux-note">{0}: </span>{1}', _T("common", "note"), _AST("setting", "amazon_alexa_hostname_note"))
            }, {
                xtype: "syno_combobox",
                name: "amazon_alexa_hostname",
                indent: 1,
                hidden: true,
                fieldLabel: _AST("setting", "amazon_alexa_hostname"),
                emptyText: "audiostation.synology.com:5001",
                store: new Ext.data.JsonStore({
                    autoDestroy: true,
                    id: "value",
                    fields: ["value"]
                }),
                valueField: "value",
                displayField: "value",
                editable: true,
                width: 300,
                validator: function(c) {
                    var b = new RegExp("(([a-z\\d]([a-z\\d-]*[a-z\\d])*)\\.)+[a-z]{2,}(\\:\\d+)?$", "i");
                    return b.test(c)
                }
            }, {
                xtype: "syno_checkbox",
                itemId: "enable_diagnosis",
                name: "enable_diagnosis",
                boxLabel: _AST("setting", "enable_diagnosis")
            }, {
                xtype: "syno_compositefield",
                hideLabel: true,
                indent: 1,
                items: [{
                    xtype: "syno_button",
                    disabled: _S("demo_mode"),
                    tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                    text: _AST("setting", "download_diagnosis"),
                    handler: this.downloadLog,
                    scope: this
                }, {
                    xtype: "syno_button",
                    disabled: _S("demo_mode"),
                    tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                    text: _AST("setting", "clear_diagnosis"),
                    handler: this.clearLog,
                    scope: this
                }, {
                    xtype: "syno_displayfield",
                    value: ""
                }]
            }]
        };
        return a
    },
    dlnaField: function() {
        var a = {
            xtype: "syno_fieldset",
            collapsible: true,
            title: _AST("setting", "advanced_dlna"),
            labelWidth: 275,
            items: [{
                xtype: "syno_checkbox",
                itemId: "audio_disable_upnp",
                name: "audio_disable_upnp",
                boxLabel: _AST("setting", "disable_upnp")
            }, {
                xtype: "syno_checkbox",
                boxLabel: _AST("setting", "enable_audio_transcoding"),
                name: "enable_audio_transcoding",
                scope: this,
                handler: this.transcodingClickHandler
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                value: _AST("setting", "service_desc_audio_transcoder")
            }, {
                xtype: "syno_compositefield",
                name: "grptranscoding",
                indent: 1,
                hideLabel: true,
                width: 400,
                items: [{
                    xtype: "syno_checkbox",
                    htmlEncode: false,
                    boxLabel: String.format('<span ext:qtip="*.flac *.ape">FLAC/APE</span>'),
                    width: 100,
                    name: "flactranscoding",
                    disabled: true,
                    scope: this,
                    handler: this.transcodingClickHandler
                }, {
                    xtype: "syno_checkbox",
                    htmlEncode: false,
                    boxLabel: String.format('<span ext:qtip="*.aac *.m4a *.m4b">ALAC/AAC</span>'),
                    width: 100,
                    name: "aactranscoding",
                    disabled: true,
                    scope: this,
                    handler: this.transcodingClickHandler
                }, {
                    xtype: "syno_checkbox",
                    htmlEncode: false,
                    boxLabel: String.format('<span ext:qtip="*.ogg">OGG</span>'),
                    width: 60,
                    name: "oggtranscoding",
                    disabled: true,
                    scope: this,
                    handler: this.transcodingClickHandler
                }, {
                    xtype: "syno_checkbox",
                    htmlEncode: false,
                    boxLabel: String.format('<span ext:qtip="*.aiff *.aif">AIFF</span>'),
                    name: "aifftranscoding",
                    disabled: true,
                    scope: this,
                    handler: this.transcodingClickHandler
                }]
            }, {
                xtype: "syno_checkbox",
                indent: 1,
                boxLabel: _AST("setting", "downsampling_for_audio_transcoding"),
                name: "downsample_audio_transcoding",
                disabled: true,
                scope: this,
                handler: this.transcodingClickHandler
            }, {
                xtype: "syno_combobox",
                name: "network_interface",
                fieldLabel: _AST("setting", "network_interface"),
                editable: false,
                store: [
                    [0, 0]
                ]
            }]
        };
        return a
    },
    transcodingClickHandler: function(d, c) {
        var b = this.getForm();
        var e = b.findField("grptranscoding");
        var a = false;
        if (this.inTranscodingClickHandler || !e.rendered) {
            return
        }
        this.inTranscodingClickHandler = true;
        if (d.name === "enable_audio_transcoding") {
            e.items.each(function(f) {
                f.setValue(c);
                f.setDisabled(!c)
            }, this);
            b.findField("downsample_audio_transcoding").setDisabled(!c);
            if (!c) {
                b.findField("downsample_audio_transcoding").setValue(false)
            }
        } else {
            e.items.each(function(f) {
                if (f.getValue()) {
                    a = true;
                    return false
                }
            }, this);
            b.findField("enable_audio_transcoding").setValue(a);
            b.findField("downsample_audio_transcoding").setDisabled(!a);
            if (!a) {
                b.findField("downsample_audio_transcoding").setValue(false);
                this.disableAudioTranscodingSetting()
            }
        }
        this.inTranscodingClickHandler = false
    },
    downloadLog: function() {
        var a = Ext.urlAppend(String.format("{0}/webUI/audio_userman.cgi?action=download_log", this.ownerCt.ownerCt.owner.baseURL));
        var b = document.getElementById("syno-download-frame");
        if (!b) {
            b = Ext.DomHelper.append(document.body, {
                tag: "iframe",
                id: "syno-download-frame",
                frameBorder: 0,
                width: 0,
                height: 0,
                css: "display: none; visibility: hidden; height: 1px",
                src: a
            })
        } else {
            b.src = a
        }
    },
    clearLog: function() {
        var a = this.ownerCt.ownerCt;
        a.getMsgBox().confirm(_AST("setting", "clear_log_confirm_title"), _AST("setting", "clear_log_confirm_text"), function(b) {
            if ("yes" === b) {
                a.setStatusBusy({
                    text: _T("common", "msg_waiting")
                });
                Ext.Ajax.request({
                    url: this.ownerCt.ownerCt.owner.baseURL + "/webUI/audio_userman.cgi",
                    params: {
                        action: "clear_log"
                    },
                    callback: function(d, e, c) {
                        a.clearStatusBusy();
                        if (e) {
                            a.setStatusOK({
                                text: _AST("setting", "clear_log_done")
                            })
                        } else {
                            a.setStatusError()
                        }
                    }
                })
            }
        }, this)
    },
    disableAmazonAlexaSetting: function() {
        var a = this.getForm();
        a.findField("enable_amazon_alexa").disable();
        a.findField("enable_amazon_alexa").show();
        a.findField("enable_amazon_alexa_alert").show();
        a.findField("amazon_alexa_hostname_note").hide();
        a.findField("amazon_alexa_hostname").hide()
    },
    hideAmazonAlexaSetting: function() {
        var a = this.getForm();
        a.findField("enable_amazon_alexa").hide();
        a.findField("enable_amazon_alexa_alert").hide();
        a.findField("amazon_alexa_hostname_note").hide();
        a.findField("amazon_alexa_hostname").hide()
    },
    enableAmazonAlexaSetting: function() {
        var a = this.getForm();
        a.findField("enable_amazon_alexa").enable();
        a.findField("enable_amazon_alexa").show();
        a.findField("enable_amazon_alexa_alert").hide();
        a.findField("amazon_alexa_hostname_note").show();
        a.findField("amazon_alexa_hostname").show()
    },
    isValid: function() {
        return this.getForm().findField("amazon_alexa_hostname").isValid()
    },
    markInvalid: function() {
        this.getForm().findField("amazon_alexa_hostname").markInvalid()
    },
    disableAudioTranscodingSetting: function() {
        var a = this.getForm();
        var b = a.findField("grptranscoding");
        a.findField("downsample_audio_transcoding").disable();
        b.items.each(function(c) {
            c.disable()
        }, this)
    },
    enableAudioTranscodingSetting: function() {
        var a = this.getForm();
        var b = a.findField("grptranscoding");
        a.findField("downsample_audio_transcoding").enable();
        b.items.each(function(c) {
            c.enable()
        }, this)
    }
});
Ext.define("SYNO.SDS.AudioStation.PersonalLibraryPanel", {
    extend: "SYNO.ux.FormPanel",
    reindexBtnId: null,
    reindexMsgId: null,
    constructor: function(a) {
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        var b = [];
        var c = {
            title: _AST("setting", "personal_library_title"),
            trackResetOnLoad: true,
            listeners: {
                afterlayout: {
                    single: true,
                    scope: this,
                    fn: this.onAfterLayout
                },
                activate: {
                    scope: this,
                    fn: this.onActivate
                },
                deactivate: {
                    scope: this,
                    fn: this.onDeactivate
                }
            }
        };
        var d = (SYNO.SDS.isNSM) ? _AST("setting", "desc_enable_user_home_for_router") : _AST("setting", "desc_enable_user_home");
        if (SYNO.SDS.AudioStation.SessionData.is_manager) {
            b.push({
                xtype: "syno_displayfield",
                value: _AST("setting", "enable_personal_library_desc")
            }, {
                xtype: "syno_displayfield",
                htmlEncode: false,
                value: '<span class="note-font">' + _AST("common", "note") + ": </span>" + d
            }, {
                xtype: "syno_checkbox",
                itemId: "enable_personal_library",
                name: "enable_personal_library",
                boxLabel: _AST("setting", "enable_personal_library"),
                disabled: true,
                scope: this,
                handler: this.setReindexBtnEnable
            }, {
                xtype: "syno_displayfield",
                itemId: "user_home_in_peta_volume_alert",
                name: "user_home_in_peta_volume_alert",
                indent: 1,
                htmlEncode: false,
                hidden: true,
                style: "padding: 0px;",
                value: String.format('<font class="red-status">{0}</font>', _AST("setting", "user_home_in_peta_volume_alert"))
            }, {
                xtype: "syno_displayfield",
                value: ""
            })
        }
        b.push({
            xtype: "syno_displayfield",
            value: _AST("setting", "browse_personal_library_desc")
        }, {
            xtype: "syno_radio",
            itemId: "browse_personal_library_all",
            name: "browse_personal_library",
            inputValue: "all",
            boxLabel: _AST("setting", "browse_personal_library_all"),
            scope: this,
            handler: this.setReindexBtnEnable
        }, {
            xtype: "syno_radio",
            itemId: "browse_personal_library_personal",
            name: "browse_personal_library",
            inputValue: "personal",
            boxLabel: _AST("setting", "browse_personal_library_personal"),
            scope: this,
            handler: this.setReindexBtnEnable
        }, {
            xtype: "syno_displayfield",
            value: ""
        }, {
            xtype: "syno_compositefield",
            hideLabel: true,
            items: [{
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : _AST("setting", "reindex_tip"),
                xtype: "syno_button",
                id: this.reindexBtnId = Ext.id(),
                text: _T("mediaservice", "btn_reindex_media_data"),
                scope: this,
                handler: this.onClickReindexBtn
            }, {
                xtype: "syno_displayfield",
                cls: "syno-audio-desc-reindex",
                id: this.reindexMsgId = Ext.id(),
                htmlEncode: false,
                value: "<span class='blue-status'>" + _T("mediaservice", "media_data_reindexing") + "</span>"
            }]
        });
        c.items = b;
        Ext.apply(c, a);
        return c
    },
    onAfterLayout: function() {
        var a;
        this.checkEnablePersonalLibrary = this.getComponent("enable_personal_library");
        if (this.checkEnablePersonalLibrary) {
            a = new SYNO.ux.Utils.EnableCheckGroup(this.getForm(), "enable_personal_library", ["browse_personal_library"])
        }
        this.browseRadioAll = this.getComponent("browse_personal_library_all");
        this.browseRadioPersonal = this.getComponent("browse_personal_library_personal")
    },
    onActivate: function() {
        if (undefined === this.pollingTask) {
            this.pollingTask = this.addAjaxTask({
                id: "paudioPollingTask",
                interval: 5000,
                autoJsonDecode: true,
                url: this.ownerCt.ownerCt.owner.baseURL + "/webUI/audio_userman.cgi",
                params: {
                    action: "load_reindex"
                },
                success: function(a, b) {
                    Ext.getCmp(this.reindexMsgId).setVisible(!!a.reindexing);
                    this.setReindexBtnEnable()
                },
                scope: this
            });
            this.pollingTask.start(true)
        }
    },
    onDeactivate: function() {
        if (undefined !== this.pollingTask) {
            this.pollingTask.remove();
            this.pollingTask = undefined
        }
    },
    onClickReindexBtn: function() {
        Ext.getCmp(this.reindexMsgId).setVisible(true);
        Ext.getCmp(this.reindexBtnId).setDisabled(true);
        Ext.Ajax.request({
            url: this.ownerCt.ownerCt.owner.baseURL + "/webUI/audio_userman.cgi",
            params: {
                action: "do_reindex"
            }
        })
    },
    clearRadioDirty: function() {
        this.browseRadioAll.originalValue = this.browseRadioAll.getValue();
        this.browseRadioPersonal.originalValue = this.browseRadioPersonal.getValue()
    },
    setReindexBtnEnable: function() {
        var a = Ext.getCmp(this.reindexMsgId).isVisible();
        Ext.getCmp(this.reindexBtnId).setDisabled(_S("demo_mode") || this.browseRadioAll.disabled || a)
    }
});
Ext.define("SYNO.SDS.AudioStation.SettingDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(b, a) {
        var c = [];
        this.audioAppWindow = a;
        if (SYNO.SDS.AudioStation.SessionData.is_manager) {
            this.userGrid = new SYNO.SDS.AudioStation.UserGrid({
                baseURL: b.owner.baseURL,
                ownerDialog: this
            }, this.audioAppWindow);
            this.advancePanel = new SYNO.SDS.AudioStation.AdvancePanel();
            this.lyricsPlugInPanel = new SYNO.SDS.AudioStation.LyricsPlugInPanel({
                baseURL: b.owner.baseURL,
                owner: this
            })
        }
        this.optionPanel = new SYNO.SDS.AudioStation.OptionPanel({
            baseURL: b.owner.baseURL,
            owner: this
        });
        if (SYNO.SDS.AudioStation.Utils.isPersonalLibraryEnabled()) {
            this.personalPanel = new SYNO.SDS.AudioStation.PersonalLibraryPanel()
        }
        if (this.userGrid) {
            c.push(this.userGrid)
        }
        if (this.lyricsPlugInPanel) {
            c.push(this.lyricsPlugInPanel)
        }
        if (this.optionPanel) {
            c.push(this.optionPanel)
        }
        if (this.personalPanel) {
            c.push(this.personalPanel)
        }
        if (this.advancePanel) {
            c.push(this.advancePanel)
        }
        this.tabPanel = new SYNO.ux.TabPanel({
            deferredRender: false,
            bodyStyle: "padding-top: 0px;",
            activeTab: 0,
            plain: true,
            items: c
        });
        this.callParent([this.fillConfig(b)])
    },
    fillConfig: function(a) {
        var b = {
            title: _AST("user", "user_setting"),
            layout: "fit",
            cls: "syno-as-dialog",
            width: 750,
            height: SYNO.SDS.AudioStation.SessionData.is_manager ? 500 : 330,
            minWidth: 650,
            minHeight: SYNO.SDS.AudioStation.SessionData.is_manager ? 500 : 330,
            closeAction: "hide",
            constrain: true,
            items: this.tabPanel,
            buttons: [{
                text: _AST("common", "btn_cancel"),
                scope: this,
                handler: this.onCancel
            }, {
                text: _AST("common", "btn_ok"),
                btnStyle: "blue",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                scope: this,
                handler: function() {
                    if (this.isAnyDirty()) {
                        this.saveAll()
                    } else {
                        this.hide()
                    }
                }
            }],
            listeners: {
                scope: this,
                hide: this.onDialogHide,
                show: this.onDialogShow
            }
        };
        Ext.apply(b, a);
        return b
    },
    onCancel: function() {
        if (this.isAnyDirty()) {
            this.confirmLostChangePromise({
                save: function() {
                    this.saveAll()
                },
                cancel: Ext.emptyFn,
                dontSave: function() {
                    this.hide()
                }
            }, this)
        } else {
            this.hide()
        }
    },
    saveAll: function() {
        var f, c, a, b;
        if (this.userGrid) {
            f = this.userGrid.getModifiedUserSetting()
        }
        if (this.advancePanel) {
            if (!this.advancePanel.isValid()) {
                this.advancePanel.markInvalid();
                return
            }
            c = this.advancePanel.getForm().getValues()
        }
        if (this.optionPanel) {
            a = this.optionPanel.getForm().getValues()
        }
        if (this.personalPanel) {
            b = this.personalPanel.getForm().getValues()
        }
        var e = Ext.apply({
            action: (this.userGrid && this.advancePanel) ? "apply_all" : "apply_preference"
        }, a);
        e = Ext.apply(e, c);
        if (f) {
            e.items = Ext.encode(f)
        }
        if (b) {
            e = Ext.apply(e, b)
        }
        var d;
        if (this.lyricsPlugInPanel) {
            d = this.lyricsPlugInPanel.getModifiedPlugInInfo()
        }
        this.setStatusBusy({
            text: _AST("common", "applying")
        });
        Ext.Ajax.request({
            url: this.owner.baseURL + "/webUI/audio_userman.cgi",
            params: e,
            method: "POST",
            callback: function(i, j, h) {
                var g = Ext.isEmpty(h.responseText) ? {} : JSON.parse(h.responseText);
                if (!j) {
                    this.clearStatusBusy();
                    this.getMsgBox().alert(this.title, _AST("user", "error_apply"))
                } else {
                    if (true !== g.success && g.error && g.error.code) {
                        this.clearStatusBusy();
                        this.getMsgBox().alert(this.title, this.owner.mainpanel._getUtils().getErrMsgString(this.owner.mainpanel._getUtils().getErrCodeMapping(g.error.code)))
                    } else {
                        if (this.advancePanel) {
                            this.notifyAdvanceSetting()
                        }
                        this.notifyCueSheetSetting();
                        if (this.personalPanel) {
                            this.notifyPersonalLibrarySetting()
                        }
                        if (this.lyricsPlugInPanel) {
                            Ext.Ajax.request({
                                url: this.owner.baseURL + "/webUI/audio_search_lyrics.cgi",
                                params: {
                                    action: "modifyPlugInInfo",
                                    modifiedpluginlist: Ext.encode(d)
                                },
                                method: "POST",
                                callback: function(l, m, k) {
                                    this.clearStatusBusy();
                                    this.rejectAll();
                                    this.hide()
                                },
                                scope: this
                            })
                        } else {
                            this.clearStatusBusy();
                            this.rejectAll();
                            this.hide()
                        }
                    }
                }
            },
            scope: this
        })
    },
    rejectAll: function() {
        if (this.userGrid) {
            this.userGrid.getStore().rejectChanges()
        }
        if (this.advancePanel) {
            this.advancePanel.getForm().reset()
        }
        if (this.optionPanel) {
            this.optionPanel.getForm().reset()
        }
        if (this.personalPanel) {
            this.personalPanel.getForm().reset()
        }
        if (this.lyricsPlugInPanel) {
            this.lyricsPlugInPanel.getStore().rejectChanges()
        }
    },
    isAnyDirty: function() {
        if (this.userGrid && (this.userGrid.getStore().getModifiedRecords().length > 0)) {
            return true
        }
        if (this.advancePanel && (this.advancePanel.getForm().isDirty())) {
            return true
        }
        if (this.optionPanel) {
            if (this.optionPanel.getForm().findField("itunes_percent").isDirty()) {
                this.optionPanel.getForm().findField("itunes_percent").reset()
            }
            if (this.optionPanel.getForm().isDirty()) {
                return true
            }
        }
        if (this.personalPanel && this.personalPanel.getForm().isDirty()) {
            return true
        }
        if (this.lyricsPlugInPanel && (this.lyricsPlugInPanel.getStore().getModifiedRecords().length > 0)) {
            return true
        }
        return false
    },
    notifyCueSheetSetting: function() {
        var c = this.optionPanel.getForm();
        var d = c.findField("audio_show_virtual_library");
        var a = SYNO.SDS.AudioStation.SessionData.settings.audio_show_virtual_library;
        if (!d) {
            return
        }
        var b = d.getValue();
        SYNO.SDS.AudioStation.SessionData.settings.audio_show_virtual_library = b;
        if (a !== b) {
            this.audioAppWindow.pathMgr.onSetGotoCfg(SYNO.SDS.AudioStation.Utils._Playlist_ID, 0);
            this.audioAppWindow.pathMgr.gotoHomePage()
        }
    },
    notifyAdvanceSetting: function() {
        var a = this.advancePanel.getForm();
        var c = a.findField("audio_enable_download").getValue();
        var b = a.findField("audio_disable_upnp").getValue();
        SYNO.SDS.AudioStation.SessionData.settings.enable_download = c;
        SYNO.SDS.AudioStation.SessionData.settings.disable_upnp = b;
        this.audioAppWindow.getPanelScope("SYNO.SDS.AudioStation.Main").listPanel.setMediaServerVisible(!SYNO.SDS.AudioStation.SessionData.settings.disable_upnp)
    },
    notifyPersonalLibrarySetting: function() {
        var c = this.personalPanel.getForm().findField("enable_personal_library");
        var d = this.personalPanel.getForm().findField("browse_personal_library");
        var b = SYNO.SDS.AudioStation.SessionData.enable_personal_library;
        var a = SYNO.SDS.AudioStation.SessionData.browse_personal_library;
        if (c) {
            SYNO.SDS.AudioStation.SessionData.enable_personal_library = c.getValue()
        }
        SYNO.SDS.AudioStation.SessionData.browse_personal_library = SYNO.SDS.AudioStation.SessionData.enable_personal_library ? d.getGroupValue() : "all";
        if (b !== SYNO.SDS.AudioStation.SessionData.enable_personal_library || a !== SYNO.SDS.AudioStation.SessionData.browse_personal_library) {
            this.audioAppWindow.pathMgr.onSetGotoCfg(SYNO.SDS.AudioStation.Utils._Playlist_ID, 0);
            this.audioAppWindow.pathMgr.gotoHomePage();
            this.audioAppWindow.mainpanel.playlistStore.reload()
        }
    },
    onDialogHide: function() {
        if (this.personalPanel) {
            this.personalPanel.onDeactivate()
        }
        if (this.optionPanel) {
            this.optionPanel.onDeactivate()
        }
    },
    onDialogShow: function() {
        if ("option" == this.tabPanel.getActiveTab().getItemId()) {
            this.optionPanel.onActivate()
        }
        if (this.lyricsPlugInPanel) {
            this.lyricsPlugInPanel.getStore().load()
        }
        Ext.Ajax.request({
            url: this.owner.baseURL + "/webUI/audio_userman.cgi",
            params: {
                action: (this.userGrid && this.advancePanel) ? "load_all" : "load_preference"
            },
            method: "POST",
            callback: function(c, d, a) {
                if (d) {
                    var b = Ext.decode(a.responseText);
                    if (this.userGrid) {
                        this.userGrid.getStore().loadData(b)
                    }
                    if (this.advancePanel) {
                        this.advancePanel.getForm().setValues(b);
                        this.displaySet(b)
                    }
                    if (this.optionPanel) {
                        this.optionPanel.getForm().setValues(b)
                    }
                    if (this.personalPanel) {
                        if (this.personalPanel.checkEnablePersonalLibrary) {
                            this.personalPanel.checkEnablePersonalLibrary.setDisabled(!b.enable_user_home);
                            if (b.is_user_home_in_peta_volume) {
                                this.personalPanel.getForm().findField("user_home_in_peta_volume_alert").show()
                            } else {
                                this.personalPanel.getForm().findField("user_home_in_peta_volume_alert").hide()
                            }
                        }
                        this.personalPanel.getForm().setValues(b);
                        this.personalPanel.clearRadioDirty()
                    }
                } else {
                    this.getMsgBox().alert(this.title, _AST("common", "error_system"))
                }
            },
            scope: this
        })
    },
    displaySet: function(b) {
        var c = this.advancePanel.getForm();
        var d = [];
        var a = c.findField("network_interface");
        if (!b.network) {
            SYNO.ux.Utils.displayFormField(c, "network_interface", false)
        } else {
            b.network.sort(function(f, e) {
                if (f.value > e.value) {
                    return 1
                } else {
                    return -1
                }
            });
            Ext.each(b.network, function(g, e, f) {
                d.push([g.value, g.display])
            }, this);
            a.getStore().loadData(d);
            a.setValue(b.network_interface);
            SYNO.ux.Utils.displayFormField(c, "network_interface", true)
        }
        if (b.network_total === 1) {
            SYNO.ux.Utils.displayFormField(c, "network_interface", false)
        }
        if (false === b.is_support_amazon_alexa) {
            this.advancePanel.hideAmazonAlexaSetting()
        } else {
            if (true === b.is_oauth_service_active) {
                this.advancePanel.enableAmazonAlexaSetting();
                SYNO.API.Request({
                    compound: {
                        stopwhenerror: true,
                        params: [{
                            api: "SYNO.Core.Certificate.CRT",
                            method: "list",
                            version: "1"
                        }, {
                            api: "SYNO.Core.Web.DSM",
                            method: "get",
                            version: "2"
                        }]
                    },
                    callback: this.onListDomainInfo,
                    scope: this.advancePanel
                })
            } else {
                this.advancePanel.disableAmazonAlexaSetting()
            }
        }
        if (false === b.enable_audio_transcoding) {
            this.advancePanel.disableAudioTranscodingSetting()
        } else {
            this.advancePanel.enableAudioTranscodingSetting()
        }
    },
    onListDomainInfo: function(h, b, c, j) {
        var g = this.getForm().findField("amazon_alexa_hostname");
        var i = g.getValue();
        var e = Ext.isEmpty(i);
        if (!h) {
            g.getStore().loadData(e ? [] : [{
                value: i
            }]);
            g.setValue(i);
            return
        }
        var d = b.result[0].data.certificates;
        var a = b.result[1].data.https_port;
        var f = d.filter(function(k) {
            return -1 === k.subject.common_name.indexOf("*")
        }).map(function(k) {
            return {
                value: k.subject.common_name + ":" + a
            }
        });
        g.getStore().loadData(e ? f : [{
            value: i
        }].concat(f));
        g.setValue(!e ? i : !Ext.isEmpty(f) ? f[0].value : "")
    }
});
Ext.define("SYNO.SDS.AudioStation.MultiAirPlayDialog", {
    extend: "SYNO.SDS.ModalWindow",
    delayPollingModifyFlag: 0,
    keepCurrentFlag: false,
    stopSetSubVolumeFlag: false,
    firstSlider: "",
    checkboxList: [],
    volumeAllSlider: null,
    volumeAllCurrent: 0,
    volumeSliderList: [],
    volumeSavedList: [],
    volumeCurrentList: [],
    activeAirplayNum: 0,
    constructor: function(a) {
        this.owner = a.owner;
        this.store = a.store;
        this.baseURL = this.owner.baseURL;
        this.delayPollingModifyFlag = 0;
        this.keepCurrentFlag = false;
        this.firstSlider = "";
        this.checkboxList = [];
        this.volumeSliderList = [];
        this.volumeSavedList = [];
        this.volumeCurrentList = [];
        this.checkboxPanel = this.createPanel();
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        var b = {
            owner: this.owner,
            layout: "fit",
            cls: "syno-as-dialog",
            border: false,
            resizable: false,
            width: 435,
            height: 290,
            items: this.checkboxPanel,
            buttons: [{
                text: _AST("common", "btn_close"),
                scope: this,
                handler: this.closeCheckRedirect
            }]
        };
        Ext.apply(b, a);
        return b
    },
    createPanel: function() {
        var d = [],
            c;
        var e = this.store.getCount();
        this.store.sort("name");
        d.push(this.createAllCompositeField());
        d.push(new Ext.Container({
            cls: "syno-as-multi-airplay-all-line"
        }));
        for (c = 0; c < e; c++) {
            var h = this.store.getAt(c);
            var f = h.get("password_protected");
            var b = h.get("name");
            var g = {
                UDN: h.get("id")
            };
            d.push(this.createDeviceCompositeField(f, b, g));
            d.push(new Ext.Container({
                cls: "syno-as-multi-airplay-device-line"
            }))
        }
        var a = {
            autoFlexcroll: true,
            border: false,
            items: d,
            listeners: {
                afterRender: {
                    fn: this.loadSelectedAirPlay,
                    scope: this
                }
            }
        };
        return new Ext.form.FormPanel(a)
    },
    createAllCompositeField: function() {
        var b = new Ext.form.Label({
            text: "All",
            cls: "syno-as-multi-aiplay-text",
            listeners: {
                afterrender: function(d) {
                    var e = b.container.dom.clientWidth;
                    var c = b.el.dom.offsetWidth;
                    a.setPosition(e - c - a.width - 8, 0)
                },
                scope: this
            }
        });
        var a = new SYNO.SDS.AudioStation.Slider.MultipleVolumeSlider({
            width: 148,
            clickRange: [0, 6],
            UDN: "__SYNO_Multiple_AirPlay__",
            audioAppMain: this.owner.mainpanel,
            owner: this,
            scope: this
        });
        this.volumeAllSlider = a;
        return new Ext.Container({
            autoEl: "div",
            layout: "column",
            items: [b, a]
        })
    },
    createDeviceCompositeField: function(c, d, f) {
        var e = new SYNO.ux.Checkbox({
            fieldLabel: "",
            boxLabel: d,
            UDN: f.UDN,
            checked: false,
            width: 200,
            listeners: {
                afterrender: function(i) {
                    var j = e.container.dom.clientWidth;
                    var h = 200 + e.boxlabelEl.dom.offsetLeft;
                    var g = b.hidden ? 0 : 30;
                    a.setPosition(j - h - g - a.width - 8, 0);
                    i.positionEl.dom.qtip = Ext.util.Format.htmlEncode(d)
                },
                check: {
                    fn: c ? this.testCheckedAirplay : this.setMultipleAirplay,
                    scope: this
                },
                scope: this,
                single: true
            }
        });
        var b = new SYNO.ux.Button({
            ctCls: "syno-audio-password-btn-ct",
            iconCls: "syno-as-password-btn",
            tooltip: _AST("setting", "renderer_password_title"),
            hidden: !c,
            scope: this,
            handler: this.passwordHandler.createDelegate(this, [e, false])
        });
        var a = new SYNO.SDS.AudioStation.Slider.MultipleVolumeSlider({
            width: 148,
            clickRange: [0, 6],
            UDN: f.UDN,
            audioAppMain: this.owner.mainpanel,
            owner: this,
            scope: this
        });
        this.checkboxList.push(e);
        this.volumeSliderList.push(a);
        return new Ext.Container({
            autoEl: "div",
            layout: "column",
            cls: "syno-audio-ellipsis-text",
            items: [e, b, a]
        })
    },
    testCheckedAirplay: function(c, b) {
        var a = this.owner.mainpanel.PlayerStore;
        this.stopSetSubVolumeFlag = true;
        if (b) {
            this.owner.mainpanel.testAirPlayPassword(a.getById(c.UDN), this.setMultipleAirplay.createDelegate(this, [c, b]))
        } else {
            this.setMultipleAirplay(c, b)
        }
    },
    setMultipleAirplay: function(d, c) {
        var a, b = [];
        this.stopSetSubVolumeFlag = true;
        for (a = 0; a < this.volumeSliderList.length; a++) {
            if (this.volumeSliderList[a].UDN === d.UDN) {
                if ((c && !this.volumeSliderList[a].disabled) || (!c && this.volumeSliderList[a].disabled)) {
                    return
                }
            }
        }
        this.delayPollingModifyFlag = 2;
        for (a = 0; a < this.checkboxList.length; a++) {
            if (this.checkboxList[a].checked) {
                b.push(this.checkboxList[a].UDN)
            }
        }
        this.setStatusBusy({
            text: _T("common", "msg_waiting")
        });
        Ext.Ajax.request({
            url: SYNO.SDS.AudioStation.Utils.getWebAPIURL("remote_player.cgi"),
            params: SYNO.SDS.AudioStation.Utils.getWebAPIParams({
                api: "SYNO.AudioStation.RemotePlayer",
                method: "setmultiple",
                id: this.owner.mainpanel.gCurrentSelectPlayer,
                subplayer_id: b.join()
            }),
            method: "GET",
            scope: this,
            callback: function(f, h, e) {
                var g;
                this.clearStatusBusy();
                if (!h || !e.responseText) {
                    this.getMsgBox().alert(this.title, _AST("common", "error_system"));
                    return
                }
                g = Ext.util.JSON.decode(e.responseText);
                if (!g) {
                    this.getMsgBox().alert(this.title, _AST("common", "error_system"));
                    return
                } else {
                    if (g.error && g.error.code && "AUDIO_ERR_DEVICE_NOT_EXISTS" === this.owner.mainpanel._getUtils().getErrCodeMapping(g.error.code)) {
                        this.redirectToStreamMode()
                    }
                }
                this.modifySelectedAirPlay(g.data.subplayer_volume, d, c);
                this.stopSetSubVolumeFlag = false
            }
        })
    },
    loadSelectedAirPlay: function() {
        this.setStatusBusy({
            text: _T("common", "msg_waiting")
        });
        Ext.Ajax.request({
            url: SYNO.SDS.AudioStation.Utils.getWebAPIURL("remote_player.cgi"),
            params: SYNO.SDS.AudioStation.Utils.getWebAPIParams({
                api: "SYNO.AudioStation.RemotePlayer",
                method: "getstatus",
                id: this.owner.mainpanel.gCurrentSelectPlayer,
                additional: "subplayer_volume"
            }),
            method: "GET",
            scope: this,
            callback: function(c, g, a) {
                var e, f, b, d;
                this.clearStatusBusy();
                if (!g || !a.responseText) {
                    this.getMsgBox().alert(this.title, _AST("common", "error_system"));
                    return
                }
                e = Ext.util.JSON.decode(a.responseText);
                if (!e) {
                    this.getMsgBox().alert(this.title, _AST("common", "error_system"));
                    return
                } else {
                    if (e.error && e.error.code && "AUDIO_ERR_DEVICE_NOT_EXISTS" === this.owner.mainpanel._getUtils().getErrCodeMapping(e.error.code)) {
                        this.redirectToStreamMode()
                    }
                }
                f = this.owner.mainpanel.playerPanel.volumeSlider;
                if (-1 !== f.volumeAllCurrent) {
                    this.keepCurrentFlag = true;
                    this.volumeAllCurrent = f.volumeAllCurrent;
                    for (d = 0; d < this.checkboxList.length; d++) {
                        b = this.checkboxList[d].UDN;
                        if (undefined !== f.volumeSavedList[b]) {
                            this.volumeSavedList[d] = f.volumeSavedList[b]
                        }
                    }
                    f.volumeAllCurrent = -1;
                    f.volumeSavedList = {}
                }
                this.setSelectedAirPlay(e.data.subplayer_volume);
                this.firstSlider = ""
            }
        })
    },
    modifySelectedAirPlay: function(c, f, d) {
        var b, a;
        var e = this.keepCurrentFlag;
        for (b = 0; b < this.volumeSliderList.length; b++) {
            if (this.volumeSliderList[b].UDN === f.UDN) {
                if (d) {
                    this.volumeSliderList[b].setDisabled(false);
                    this.volumeSliderList[b].setValue(c[f.UDN]);
                    this.activeAirplayNum++;
                    this.volumeCurrentList[b] = c[f.UDN];
                    this.volumeSavedList[b] = c[f.UDN];
                    if (e) {
                        this.volumeSliderList[b].fireEvent("changecomplete", this.volumeSliderList[b], c[f.UDN])
                    }
                } else {
                    this.volumeSliderList[b].setDisabled(true);
                    this.volumeSliderList[b].setValue(0);
                    this.activeAirplayNum--;
                    this.volumeCurrentList[b] = 0;
                    this.volumeSavedList[b] = 0
                }
                break
            }
        }
        a = Math.max.apply(Math, this.volumeCurrentList);
        this.volumeAllSlider.setValue(a);
        if (!this.keepCurrentFlag) {
            this.volumeAllCurrent = a
        }
        if (0 === this.activeAirplayNum) {
            this.volumeAllSlider.setDisabled(true)
        } else {
            this.volumeAllSlider.setDisabled(false)
        }
    },
    setSelectedAirPlay: function(d) {
        var b, c, a;
        this.activeAirplayNum = 0;
        for (c = 0; c < this.checkboxList.length; c++) {
            b = this.checkboxList[c].UDN;
            if (d && undefined !== d[b]) {
                this.checkboxList[c].suspendEvents(false);
                this.checkboxList[c].setValue(true);
                this.checkboxList[c].resumeEvents();
                this.volumeSliderList[c].setDisabled(false);
                this.volumeSliderList[c].setValue(d[b]);
                this.activeAirplayNum++;
                this.volumeCurrentList[c] = d[b];
                if (!this.keepCurrentFlag) {
                    this.volumeSavedList[c] = d[b]
                }
            } else {
                this.checkboxList[c].suspendEvents(false);
                this.checkboxList[c].setValue(false);
                this.checkboxList[c].resumeEvents();
                this.volumeSliderList[c].setDisabled(true);
                this.volumeSliderList[c].setValue(0);
                this.volumeCurrentList[c] = 0;
                this.volumeSavedList[c] = 0
            }
        }
        a = Math.max.apply(Math, this.volumeCurrentList);
        this.volumeAllSlider.setValue(a);
        if (!this.keepCurrentFlag) {
            this.volumeAllCurrent = a
        }
        if (0 === this.activeAirplayNum) {
            this.volumeAllSlider.setDisabled(true)
        } else {
            this.volumeAllSlider.setDisabled(false)
        }
    },
    setAllVolumes: function() {
        var b = [],
            c = [],
            a;
        if (!this.playingStore) {
            this.playingStore = this.owner.mainpanel.playingStore
        }
        this.owner.mainpanel.playerPanel.Ctrl.setUpdateDelay(1);
        for (a = 0; a < this.volumeSliderList.length; a++) {
            if (!this.volumeSliderList[a].disabled) {
                if (isNaN(this.volumeSliderList[a].getValue())) {
                    return
                }
                b.push(this.volumeSliderList[a].UDN);
                c.push(Math.round(this.volumeSliderList[a].getValue()))
            }
        }
        this.owner.mainpanel.audioPlayer.doSetMultipleVolumes(b.join(), c.join())
    },
    closeCheckRedirect: function() {
        var c = this.owner.mainpanel.playerPanel.volumeSlider,
            a, b;
        if (this.checkboxSelectNone()) {
            this.redirectToStreamMode()
        }
        c.volumeAllCurrent = this.volumeAllCurrent;
        c.volumeSavedList = {};
        for (a = 0; a < this.checkboxList.length; a++) {
            b = this.checkboxList[a].UDN;
            c.volumeSavedList[b] = this.volumeSavedList[a]
        }
        this.close()
    },
    passwordHandler: function(c, a) {
        var b = new SYNO.SDS.AudioStation.PasswordDialog({
            owner: this,
            name: c.boxLabel,
            UDN: c.UDN,
            autoPop: !!a
        });
        b.show()
    },
    redirectToStreamMode: function() {
        this.owner.getPanelScope("SYNO.SDS.AudioStation.Main").updatePlayingModeInfo("stream", null)
    },
    checkboxSelectNone: function() {
        var a = true;
        for (var b = 0; b < this.checkboxList.length; ++b) {
            if (this.checkboxList[b].checked) {
                a = false;
                break
            }
        }
        return a
    }
});
Ext.define("SYNO.SDS.AudioStation.PasswordDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.call(this, a);
        this.deviceName = a.name;
        this.deviceUDN = a.UDN;
        this.callback = a.callback;
        this.owner = a.owner;
        this.autoPop = a.autoPop;
        this.formPanel = this.createPanel();
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function() {
        var a = {
            owner: this.owner,
            layout: "fit",
            cls: "syno-as-dialog",
            border: false,
            resizable: false,
            title: _AST("setting", "renderer_password_title"),
            width: 450,
            height: 200,
            items: this.createPanel(),
            buttons: [{
                text: _AST("common", "btn_cancel"),
                scope: this,
                handler: this.cancelHandler
            }, {
                text: _AST("common", "btn_ok"),
                btnStyle: "blue",
                scope: this,
                handler: this.okHandler
            }],
            listeners: {
                scope: this,
                afterrender: this.onAfterRender
            }
        };
        return a
    },
    createPanel: function() {
        var a = {
            border: false,
            items: [{
                xtype: "syno_displayfield",
                value: String.format(_AST("setting", "renderer_password_desc"), this.getDeviceName())
            }, {
                xtype: "syno_textfield",
                textType: "password",
                name: "password",
                fieldLabel: _AST("common", "password"),
                labelWidth: 120,
                width: 200,
                maxlength: 50
            }]
        };
        SYNO.LayoutConfig.fill(a);
        return new SYNO.ux.FormPanel(a)
    },
    getDeviceName: function() {
        return Ext.util.Format.ellipsis(this.deviceName, 50, false)
    },
    getPasswordField: function() {
        return this.get(0).getForm().findField("password")
    },
    onAfterRender: function(a) {
        this.focusInputField()
    },
    focusInputField: function() {
        var a = this.getPasswordField();
        a.focus(false, 300)
    },
    okHandler: function() {
        var b = this.getPasswordField();
        var a = b.getValue();
        if (a) {
            this.applyPassword(a)
        } else {
            this.cancelHandler()
        }
    },
    applyPassword: function(b) {
        var a = this.addAjaxTask({
            id: "syno_audio_password_save_task",
            autoJsonDecode: true,
            single: true,
            method: "POST",
            url: this._getUtils().getWebAPIURL("remote_player.cgi"),
            params: this._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.RemotePlayer",
                method: "setpassword",
                id: this.deviceUDN,
                password: b
            }),
            scope: this,
            success: function(d, e) {
                var c, f;
                this.clearStatusBusy();
                if (d.success) {
                    if (this.callback) {
                        this.callback.call()
                    }
                    this.close()
                } else {
                    if (d.error && d.error.code) {
                        c = this._getUtils().getErrCodeMapping(d.error.code, e.params.api, e.params.method);
                        if ("AUDIO_ERR_DEVICE_BUSY" === c) {
                            f = String.format(this._getUtils().getErrMsgString(c), this.getDeviceName())
                        } else {
                            f = this._getUtils().getErrMsgString(c)
                        }
                    } else {
                        f = _AST("common", "error_system")
                    }
                    this.getMsgBox().alert(this.title, f, function() {
                        this.focusInputField()
                    }, this)
                }
            },
            failure: function(c, d) {
                this.clearStatusBusy();
                this.getMsgBox().alert(this.title, _AST("common", "error_system"))
            }
        });
        this.setStatusBusy({
            text: _T("common", "msg_waiting")
        });
        a.start()
    },
    cancelHandler: function() {
        var c = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main"),
            b, a;
        if (this.autoPop) {
            if ("__SYNO_Multiple_AirPlay__" !== c.gCurrentSelectPlayer) {
                c.switchToStreamingMode()
            } else {
                for (b = 0; b < c.multiAirPlayDialog.checkboxList.length; b++) {
                    a = c.multiAirPlayDialog.checkboxList[b].UDN;
                    if (this.deviceUDN === a) {
                        c.multiAirPlayDialog.checkboxList[b].setValue(false);
                        break
                    }
                }
            }
        }
        this.close()
    }
});
Ext.define("SYNO.SDS.AudioStation.PlaylistSelectDialog", {
    extend: "SYNO.SDS.ModalWindow",
    arrPersonalPls: [],
    arrSharePls: [],
    constructor: function(a) {
        this.owner = a.owner;
        this.data = a.data;
        this.audioAppMain = a.audioAppMain;
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        var b = {
            owner: this.owner,
            layout: "fit",
            cls: "syno-as-dialog",
            border: false,
            resizable: false,
            title: _AST("playlist", "playlist"),
            width: 380,
            height: 260,
            items: this.formPanel = this.createPanel(),
            buttons: [{
                text: _AST("common", "btn_cancel"),
                scope: this,
                handler: this.cancelHandler
            }, {
                text: _AST("common", "btn_ok"),
                btnStyle: "blue",
                scope: this,
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                handler: this.okHandler
            }],
            listeners: {
                scope: this,
                afterrender: this.onAfterRender
            }
        };
        return b
    },
    createPanel: function() {
        this.curStore = new Ext.data.Store({
            recordType: this.audioAppMain.playlistStore.recordType
        });
        var b = new Ext.XTemplate('<tpl for="."><div class="x-combo-list-item">{name:htmlEncode}</div></tpl>');
        var a = {
            border: false,
            items: [{
                xtype: "syno_radio",
                itemId: "radio_personal_pls",
                name: "redio_pls_type",
                inputValue: "personal",
                boxLabel: _AST("playlist", "personal_playlist"),
                scope: this,
                handler: this.onPlsRadioChange,
                hidden: !SYNO.SDS.AudioStation.SessionData.privilege.playlist_edit
            }, {
                xtype: "syno_radio",
                itemId: "radio_share_pls",
                name: "redio_pls_type",
                inputValue: "shared",
                boxLabel: _AST("playlist", "shared_playlist_v2"),
                scope: this,
                handler: this.onPlsRadioChange,
                hidden: !SYNO.SDS.AudioStation.SessionData.privilege.playlist_edit
            }, {
                xtype: "syno_displayfield",
                value: ""
            }, {
                xtype: "syno_displayfield",
                value: _AST("playlist", "enter_playlist_name")
            }, {
                xtype: "syno_combobox",
                name: "pls_name",
                id: this.plsComboId = Ext.id(),
                store: this.curStore,
                hideLabel: true,
                tpl: b,
                editable: true,
                displayField: "name",
                allowBlank: false,
                validator: this.validatePlsName,
                width: 340
            }]
        };
        return new Ext.form.FormPanel(a)
    },
    validatePlsName: function(a) {
        a.trim();
        if (Ext.isEmpty(a)) {
            return _AST("playlist", "playlist_name_empty")
        } else {
            if (250 < SYNO.SDS.AudioStation.Utils.lengthGetInBytes(a)) {
                return _AST("playlist", "playlist_name_too_long")
            } else {
                return true
            }
        }
    },
    onAfterRender: function(a) {
        Ext.getCmp(this.plsComboId).focus(false, 300);
        this.prepareStoreData();
        this.formPanel.form.findField("redio_pls_type").setValue("personal")
    },
    prepareStoreData: function() {
        this.arrPersonalPls = [];
        this.arrSharePls = [];
        this.audioAppMain.playlistStore.each(function(a) {
            if (!this.audioAppMain._getUtils().isSmartItem(a.get("id"))) {
                if (this.audioAppMain._getUtils().isPersonalItem(a.get("id"))) {
                    this.arrPersonalPls.push(a.copy())
                } else {
                    this.arrSharePls.push(a.copy())
                }
            }
        }, this)
    },
    onPlsRadioChange: function(a, b) {
        if (!b) {
            return
        }
        this.curStore.removeAll();
        if ("personal" === a.inputValue) {
            this.curStore.add(this.arrPersonalPls)
        } else {
            this.curStore.add(this.arrSharePls)
        }
    },
    okHandler: function() {
        var d = /(^(\._)|[\/\\\:\*\?"><\|])/,
            b = this.formPanel.form.findField("redio_pls_type").getGroupValue(),
            f = Ext.getCmp(this.plsComboId).getValue().trim(),
            a = this.curStore.find("name", f),
            c = SYNO.SDS.AudioStation.Utils.getSongIdList(this.data),
            e, g;
        if (Ext.isEmpty(f)) {
            return
        }
        if (f.match(d)) {
            this.getMsgBox().alert(_AST("playlist", "playlist"), _AST("playlist", "error_reserved_name"));
            return
        }
        this.setStatusBusy();
        if (!SYNO.SDS.AudioStation.SessionData.privilege.playlist_edit) {
            b = "personal"
        }
        if (-1 === a) {
            this.audioAppMain.onPlaylistRequest(this.audioAppMain._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.Playlist",
                method: "create",
                name: f,
                songs: c,
                library: b
            }), this.plsRequestDone.createDelegate(this));
            this.clearStatusBusy();
            return
        }
        e = this.curStore.getAt(a);
        g = (e) ? e.get("id") : -1;
        if (-1 === g) {
            this.getMsgBox().alert(this.title, _AST("common", "error_system"))
        } else {
            this.audioAppMain.onPlaylistRequest(this.audioAppMain._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.Playlist",
                method: "updatesongs",
                offset: -1,
                limit: 0,
                id: g,
                songs: c
            }), this.plsRequestDone.createDelegate(this))
        }
    },
    plsRequestDone: function(b, c, a) {
        this.clearStatusBusy();
        this.audioAppMain.onPlaylistRequestDone.call(this.audioAppMain, b, c, a);
        this.close()
    },
    cancelHandler: function() {
        this.close()
    }
});
Ext.define("SYNO.SDS.AudioStation.PlaylistDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        var b;
        this.option = a.option;
        this.isEditing = !Ext.isEmpty(this.option.id);
        this.oriName = this.option.name;
        this.plsId = this.option.id;
        this.isPublicSharing = !!this.option.isPublicSharing;
        b = this.fillConfig(a);
        this.callParent([b]);
        this.sharingOpt = {
            enable_sharing: false,
            date_available: "0",
            date_expired: "0"
        }
    },
    fillConfig: function(a) {
        var b = {
            title: _AST("playlist", "playlist"),
            layout: "form",
            width: 580,
            height: this.isPublicSharing ? 370 : 200,
            padding: "16px 16px 0px 16px",
            cls: "syno-as-dialog",
            closeAction: "hide",
            constrain: true,
            resizable: false,
            items: [{
                xtype: "syno_displayfield",
                itemId: "desc",
                value: _AST("sharing", "public_sharing_desc")
            }, {
                xtype: "syno_textfield",
                itemId: "text",
                fieldLabel: _AST("playlist", "playlist_name"),
                labelWidth: 250,
                validator: this.validatePlsName,
                width: 290
            }, {
                xtype: "syno_checkbox",
                itemId: "checkbox",
                disabled: !SYNO.SDS.AudioStation.SessionData.privilege.playlist_edit,
                boxLabel: _AST("playlist", "add_as_shared_playlist_v2")
            }, {
                xtype: "syno_checkbox",
                itemId: "period_checkbox",
                boxLabel: _AST("sharing", "customize_duration"),
                hidden: !this.isPublicSharing || !SYNO.SDS.AudioStation.SessionData.privilege.sharing,
                listeners: {
                    scope: this,
                    check: function(c, d) {
                        this.availDate.setDisabled(!d);
                        this.expDate.setDisabled(!d)
                    }
                }
            }, {
                xtype: "syno_compositefield",
                itemId: "period_composite",
                hidden: !this.isPublicSharing || !SYNO.SDS.AudioStation.SessionData.privilege.sharing,
                hideLabel: true,
                indent: 1,
                items: [{
                    xtype: "syno_datetimefield",
                    itemId: "availDate",
                    value: new Date().format("Y-m-d"),
                    showToday: false,
                    markToday: false,
                    editable: false,
                    disabled: true,
                    width: 150
                }, {
                    xtype: "syno_displayfield",
                    value: " - "
                }, {
                    xtype: "syno_datetimefield",
                    itemId: "expDate",
                    value: new Date().format("Y-m-d"),
                    showToday: false,
                    markToday: false,
                    editable: false,
                    disabled: true,
                    width: 150,
                    validator: this.validateExpDate.createDelegate(this)
                }]
            }],
            buttons: [{
                text: _AST("common", "btn_cancel"),
                scope: this,
                handler: this.handleCancel
            }, {
                text: _AST("common", "btn_ok"),
                btnStyle: "blue",
                scope: this,
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                handler: this.handleApply
            }],
            keys: [{
                key: Ext.EventObject.ENTER,
                scope: this,
                fn: this.handleApply
            }, {
                key: Ext.EventObject.ESC,
                scope: this,
                fn: this.handleCancel
            }],
            listeners: {
                afterRender: {
                    fn: this.afterDlgRender,
                    scope: this
                },
                show: {
                    fn: this.getDSInfo,
                    scope: this
                }
            }
        };
        Ext.apply(b, a);
        return b
    },
    afterDlgRender: function() {
        this.sharingDesc = this.getComponent("desc");
        this.textValue = this.getComponent("text");
        this.checkbox = this.getComponent("checkbox");
        this.periodCheckbox = this.getComponent("period_checkbox");
        this.availDate = this.getComponent("period_composite").items.get(0);
        this.expDate = this.getComponent("period_composite").items.get(2);
        this.setOpt(this.option)
    },
    validatePlsName: function(a) {
        if (250 < SYNO.SDS.AudioStation.Utils.lengthGetInBytes(a)) {
            return _AST("playlist", "playlist_name_too_long")
        } else {
            return true
        }
    },
    validateExpDate: function() {
        var b = this.availDate.getValue(),
            a = this.expDate.getValue();
        if (b > a) {
            return _AST("sharing", "exp_before_avail")
        } else {
            return true
        }
    },
    setOpt: function(a) {
        this.textValue.setValue(this.oriName);
        this.checkbox.setValue(a.isShared || SYNO.SDS.AudioStation.Utils.isSharedItem(a.id));
        if (this.isEditing || this.isPublicSharing) {
            this.checkbox.hide()
        } else {
            this.checkbox.show()
        }
        if (!this.isPublicSharing) {
            this.sharingDesc.hide();
            this.setTitle(_AST("playlist", "playlist"))
        } else {
            this.sharingDesc.show();
            this.setTitle(_AST("sharing", "share_to_public"))
        }
    },
    getDSInfo: function() {
        if (!this.isPublicSharing) {
            return
        }
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.DSM.Info",
            method: "GetInfo",
            version: 1,
            callback: function(e, c, d) {
                var b = new Date(),
                    a;
                this.clearStatusBusy();
                if (e && c.time) {
                    b = new Date(Date.parse(c.time))
                }
                a = b.format("Y-m-d");
                this.availDate.setMinValue(a);
                this.expDate.setMinValue(a);
                this.availDate.setValue(a);
                this.expDate.setValue(b.add(Date.DAY, 7))
            },
            scope: this
        })
    },
    handleApply: function() {
        var a = /(^(\._)|[\/\\\:\*\?"><\|])/;
        if (_S("demo_mode")) {
            return
        }
        if (Ext.isEmpty(this.textValue.getValue().trim())) {
            this.textValue.markInvalid(_AST("playlist", "playlist_name_empty"));
            return
        }
        if (!this.textValue.isValid() || !this.expDate.isValid()) {
            return
        }
        if (this.textValue.getValue().trim().match(a)) {
            this.getMsgBox().alert(_AST("playlist", "playlist"), _AST("playlist", "error_reserved_name"));
            return
        }
        this.sharingOpt.enable_sharing = this.isPublicSharing;
        if (this.periodCheckbox.getValue()) {
            this.sharingOpt.date_available = this.availDate.getValue().format("Y-m-d");
            this.sharingOpt.date_expired = this.expDate.getValue().format("Y-m-d")
        } else {
            this.sharingOpt.date_available = "0";
            this.sharingOpt.date_expired = "0"
        }
        this.sharingOpt.isNeedUpdate = this.sharingOpt.enable_sharing;
        Ext.callback(this.callback, this.callbackScope, [this.textValue.getValue(), this.checkbox.getValue(), this.sharingOpt], 1);
        this.close()
    },
    handleCancel: function() {
        this.close()
    }
});
Ext.define("SYNO.SDS.AudioStation.SharingLinkDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.call(this, a);
        var b = this.fillConfig(a);
        this.callParent([b]);
        this.dateInfo = {
            date_available: "0",
            date_expired: "0"
        }
    },
    fillConfig: function(a) {
        var b = {
            layout: "form",
            width: 560,
            height: this.calHeight(a),
            padding: "16px 16px 0px 16px",
            cls: "syno-as-dialog",
            constrain: true,
            resizable: false,
            items: [{
                xtype: "syno_checkbox",
                itemId: "sharing_checkbox",
                boxLabel: _AST("sharing", "share_to_public"),
                hidden: Ext.isDefined(a.url) || a.isJustGetUrl,
                listeners: {
                    scope: this,
                    check: function(c, d) {
                        this.linkText.setDisabled(!d);
                        this.openLinkBtn.setDisabled(!d);
                        this.dateBtn.setDisabled(!d);
                        if (!this.loadComplete) {
                            return
                        }
                        if (this.isSingleSong) {
                            this.setSongSharingData()
                        } else {
                            this.setPlaylistData()
                        }
                    }
                }
            }, {
                xtype: "syno_textfield",
                itemId: "link_text",
                hideLabel: true,
                readOnly: true,
                disabled: true,
                selectOnFocus: true,
                cls: "selectabletext",
                width: 510
            }, {
                xtype: "syno_button",
                itemId: "customize_date_btn",
                hidden: a.isSingleSong || Ext.isDefined(a.url),
                text: _AST("sharing", "customize_duration"),
                scope: this,
                disabled: true,
                handler: this.handleCustomizeDate
            }],
            buttons: [{
                text: _AST("sharing", "open_link"),
                scope: this,
                id: this.linkBtnId = Ext.id(),
                disabled: true,
                handler: this.handleOpenLink
            }, {
                text: _AST("common", "done"),
                btnStyle: "blue",
                scope: this,
                handler: this.handleCancel
            }],
            keys: [{
                key: Ext.EventObject.ESC,
                scope: this,
                fn: this.handleCancel
            }],
            listeners: {
                afterRender: {
                    fn: this.afterDlgRender,
                    scope: this
                }
            }
        };
        Ext.apply(b, a);
        return b
    },
    calHeight: function(a) {
        if (Ext.isDefined(a.url) || a.isJustGetUrl) {
            return 160
        }
        if (this.isSingleSong) {
            return 150
        }
        return 230
    },
    afterDlgRender: function() {
        this.linkText = this.getComponent("link_text");
        this.openLinkBtn = Ext.getCmp(this.linkBtnId);
        this.sharingCheckbox = this.getComponent("sharing_checkbox");
        this.dateBtn = this.getComponent("customize_date_btn");
        if (this.url) {
            this.linkText.setDisabled(false);
            this.linkText.setValue(this.url);
            this.linkText.focus(true, 300);
            this.openLinkBtn.setDisabled(false)
        } else {
            if (this.isSingleSong) {
                this.loadSongSharing()
            } else {
                this.loadPlaylistData()
            }
        }
    },
    loadPlaylistData: function() {
        this.setStatusBusy();
        this.loadComplete = false;
        var a = {
            id: this.plsId,
            additional: "sharing_info"
        };
        this.sendWebAPI({
            api: "SYNO.AudioStation.Playlist",
            method: "getinfo",
            version: SYNO.SDS.AudioStation.Utils.webAPIVersion["SYNO.AudioStation.Playlist"],
            params: a,
            scope: this,
            callback: function(f, c, e) {
                this.clearStatusBusy();
                if (f && c.playlists && c.playlists.length > 0) {
                    var d = c.playlists[0].additional.sharing_info,
                        b = d.url;
                    if ("none" !== d.status) {
                        this.sharingCheckbox.setValue(true);
                        this.linkText.setValue(b);
                        this.linkText.focus(true);
                        this.openLinkBtn.setDisabled(false);
                        this.dateBtn.setDisabled(false)
                    }
                    this.dateInfo = {
                        date_available: d.date_available,
                        date_expired: d.date_expired
                    }
                } else {
                    if (c && c.error && c.error.code) {
                        this.getMsgBox().alert(this.title, this._getUtils().getErrMsgString(this._getUtils().getErrCodeMapping(c.error.code)))
                    } else {
                        this.getMsgBox().alert(this.title, _AST("common", "error_system"))
                    }
                }
                this.loadComplete = true
            }
        })
    },
    setPlaylistData: function() {
        this.setStatusBusy();
        var a = {
            id: this.plsId,
            enable_sharing: this.sharingCheckbox.getValue(),
            date_available: this.dateInfo.date_available,
            date_expired: this.dateInfo.date_expired
        };
        this.sendWebAPI({
            api: "SYNO.AudioStation.Playlist",
            method: "editsharing",
            version: SYNO.SDS.AudioStation.Utils.webAPIVersion["SYNO.AudioStation.Playlist"],
            params: a,
            scope: this,
            callback: function(d, b, c) {
                this.clearStatusBusy();
                if (d && b.sharing_info) {
                    this.linkText.setValue(b.sharing_info.url);
                    this.linkText.focus(true);
                    if (this._getUtils().isInAllPlaylist()) {
                        this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").dataStore.reload()
                    }
                } else {
                    this.getMsgBox().alert(this.title, _AST("common", "error_system"))
                }
            }
        })
    },
    loadSongSharing: function() {
        this.setStatusBusy();
        this.loadComplete = false;
        var a = {
            id: this.songId
        };
        this.sendWebAPI({
            api: "SYNO.AudioStation.Song",
            method: "getsharing",
            version: SYNO.SDS.AudioStation.Utils.webAPIVersion["SYNO.AudioStation.Song"],
            params: a,
            scope: this,
            callback: function(f, d, e) {
                this.clearStatusBusy();
                if (f) {
                    var c = d.enable_sharing,
                        b = d.url;
                    if (c) {
                        this.sharingCheckbox.setValue(c)
                    }
                    this.linkText.setValue(b);
                    this.linkText.focus(c)
                } else {
                    this.getMsgBox().alert(this.title, _AST("common", "error_system"))
                }
                this.loadComplete = true
            }
        })
    },
    setSongSharingData: function() {
        this.setStatusBusy();
        var a = {
            id: this.songId,
            enable_sharing: this.sharingCheckbox.getValue()
        };
        this.sendWebAPI({
            api: "SYNO.AudioStation.Song",
            method: "setsharing",
            version: SYNO.SDS.AudioStation.Utils.webAPIVersion["SYNO.AudioStation.Song"],
            params: a,
            scope: this,
            callback: function(d, b, c) {
                this.clearStatusBusy();
                if (d) {
                    this.linkText.focus(this.sharingCheckbox.getValue());
                    if (SYNO.SDS.AudioStation.Utils.isInPredefinedPlaylist()) {
                        this.owner.getPanelScope("SYNO.SDS.AudioStation.Main").dataStore.reload()
                    }
                } else {
                    this.getMsgBox().alert(this.title, _AST("common", "error_system"))
                }
            }
        })
    },
    handleCustomizeDate: function() {
        var a = new SYNO.SDS.AudioStation.SharingPeriodDialog({
            owner: this
        });
        a.show()
    },
    handleOpenLink: function() {
        window.open(this.linkText.getValue())
    },
    handleCancel: function() {
        this.close()
    }
});
Ext.define("SYNO.SDS.AudioStation.SharingPeriodDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        var b = this.fillConfig(a);
        this.callParent([b]);
        this.dateInfo = this.owner.dateInfo
    },
    fillConfig: function(a) {
        var b = {
            title: _AST("sharing", "customize_duration"),
            layout: "form",
            width: 420,
            height: 170,
            padding: "0 20px",
            cls: "syno-as-dialog",
            constrain: true,
            resizable: false,
            items: [{
                xtype: "syno_checkbox",
                itemId: "checkbox",
                boxLabel: _AST("sharing", "customize_duration"),
                listeners: {
                    scope: this,
                    check: function(c, d) {
                        this.availDate.setDisabled(!d);
                        this.expDate.setDisabled(!d)
                    }
                }
            }, {
                xtype: "syno_compositefield",
                itemId: "period_composite",
                hideLabel: true,
                items: [{
                    xtype: "syno_datetimefield",
                    itemId: "availDate",
                    value: new Date().format("Y-m-d"),
                    showToday: false,
                    markToday: false,
                    editable: false,
                    disabled: true,
                    width: 150
                }, {
                    xtype: "syno_displayfield",
                    value: " - "
                }, {
                    xtype: "syno_datetimefield",
                    itemId: "expDate",
                    value: new Date().format("Y-m-d"),
                    showToday: false,
                    markToday: false,
                    editable: false,
                    disabled: true,
                    width: 150,
                    validator: this.validateExpDate.createDelegate(this)
                }]
            }],
            buttons: [{
                text: _AST("common", "btn_cancel"),
                scope: this,
                handler: this.handleCancel
            }, {
                text: _AST("common", "btn_ok"),
                btnStyle: "blue",
                scope: this,
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                handler: this.handleApply
            }],
            keys: [{
                key: Ext.EventObject.ENTER,
                scope: this,
                fn: this.handleApply
            }, {
                key: Ext.EventObject.ESC,
                scope: this,
                fn: this.handleCancel
            }],
            listeners: {
                afterRender: {
                    fn: this.afterDlgRender,
                    scope: this
                }
            }
        };
        Ext.apply(b, a);
        return b
    },
    validateExpDate: function() {
        var b = this.availDate.getValue(),
            a = this.expDate.getValue();
        if (b > a) {
            return _AST("sharing", "exp_before_avail")
        } else {
            return true
        }
    },
    afterDlgRender: function() {
        this.enablePeriod = this.getComponent("checkbox");
        this.availDate = this.getComponent("period_composite").items.get(0);
        this.expDate = this.getComponent("period_composite").items.get(2);
        this.getDSInfo()
    },
    getDSInfo: function() {
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.DSM.Info",
            method: "GetInfo",
            version: 1,
            callback: function(e, c, d) {
                var b = new Date(),
                    a;
                this.clearStatusBusy();
                if (e && c.time) {
                    b = new Date(Date.parse(c.time))
                }
                a = b.format("Y-m-d");
                this.availDate.setMinValue(a);
                this.expDate.setMinValue(a);
                if ("0" !== this.dateInfo.date_available || "0" !== this.dateInfo.date_expired) {
                    this.enablePeriod.setValue(true);
                    if (this.dateInfo.date_available < a) {
                        this.availDate.setMinValue(this.dateInfo.date_available)
                    }
                    this.availDate.setValue(this.dateInfo.date_available);
                    this.expDate.setValue(this.dateInfo.date_expired)
                } else {
                    this.enablePeriod.setValue(false);
                    this.availDate.setValue(a);
                    this.expDate.setValue(b.add(Date.DAY, 7))
                }
            },
            scope: this
        })
    },
    handleApply: function() {
        if (_S("demo_mode")) {
            return
        }
        if (!this.expDate.isValid()) {
            return
        }
        if (this.enablePeriod.getValue()) {
            this.dateInfo.date_available = this.availDate.getValue().format("Y-m-d");
            this.dateInfo.date_expired = this.expDate.getValue().format("Y-m-d")
        } else {
            this.dateInfo.date_available = "0";
            this.dateInfo.date_expired = "0"
        }
        this.owner.setPlaylistData();
        this.close()
    },
    handleCancel: function() {
        this.close()
    }
});
Ext.define("SYNO.SDS.AudioStation.SmartPlaylist.RuleDialog", {
    extend: "SYNO.SDS.ModalWindow",
    dsConditionList: undefined,
    opList: null,
    opStore: undefined,
    PeriodList: null,
    PeriodStore: undefined,
    lstConjRule: null,
    oldConjRuleVal: 0,
    ruleArray: {
        total: 0,
        items: []
    },
    plsName: undefined,
    oldName: "",
    actionType: null,
    bliTunesRun: true,
    blIsPersonalSmartPlaylist: false,
    blRequestFromAudioStaion: false,
    blShowConfirmDialog: true,
    TagSelect: undefined,
    OpSelect: undefined,
    DateSelect: undefined,
    ValueText: undefined,
    oldCount: 1,
    cgiHandler: undefined,
    Rule: undefined,
    DiscardChanges: function() {
        this.close()
    },
    SavePLS: function() {
        var b = this.plsName.getValue(),
            e = this.lstConjRule.getValue(),
            a = this.addAsShare.getValue();
        var d = {};
        var c = this.rulePanel.items.getCount();
        if (b.length === 0) {
            this.setStatusError({
                text: _ITUNESSTR("itunes", "itunes_empty_pls"),
                clear: true
            });
            return
        }
        if (!this.plsName.isValid()) {
            return
        }
        if (b == this.oldName && e == this.oldConjRuleVal && c == this.oldCount && !this.isRulesChange() && !(this.blRequestFromAudioStaion && this.blIsPersonalSmartPlaylist !== a)) {
            this.setStatusError({
                text: _T("error", "nochange_subject"),
                clear: true
            });
            return
        }
        if (false === this.getRules()) {
            return false
        }
        if (this.blRequestFromAudioStaion) {
            d = this.getSaveRuleParamsForAudioStation();
            if (a && this.isRuleContainsSongRating(d.rules_json)) {
                this.getMsgBox().alert(this.title, _AST("playlist", "error_create_contains_rating_rule"));
                return
            }
        }
        if (this.bliTunesRun) {
            this.getMsgBox().confirm(_ITUNESSTR("itunes", "itunes_smart_playlist"), _ITUNESSTR("itunes", "itunes_warn"), function(f) {
                if (f == "yes") {
                    this.savePLSRequest(d)
                }
            }, this)
        } else {
            this.savePLSRequest(d)
        }
    },
    onBeforeclose: function() {
        if (this.blShowConfirmDialog) {
            var a = this.rulePanel.items.getCount() - 1;
            var c = this.plsName.getValue();
            var b = this.lstConjRule.getValue();
            if (this.oldName == c && b == this.oldConjRuleVal && a == this.oldCount && !this.isRulesChange()) {
                return true
            }
            this.confirmLostChangePromise({
                save: function() {
                    this.blShowConfirmDialog = false;
                    this.SavePLS()
                },
                cancel: Ext.emptyFn,
                dontSave: function() {
                    this.blShowConfirmDialog = false;
                    this.close()
                }
            }, this);
            return false
        }
        return true
    },
    isRuleContainsSongRating: function(b) {
        var c = Ext.util.JSON.decode(b);
        for (var a = 0; a < c.length; a++) {
            if (c[a].hasOwnProperty("tag") && (this.ns.ITUNES_TAG_SONG_RATING == c[a].tag)) {
                return true
            }
        }
        return false
    },
    isActionNew: function() {
        return this.actionType === "new"
    },
    isActionEdit: function() {
        return this.actionType === "edit"
    },
    getSaveRuleParamsForAudioStation: function() {
        var e = {},
            d = this.getRules(),
            b = this.plsName.getValue(),
            c = this.lstConjRule.getValue(),
            a = this.addAsShare.getValue();
        e.api = "SYNO.AudioStation.Playlist";
        e.version = 2;
        e.library = a ? "shared" : "personal";
        e.conj_rule = ("all" === c) ? "and" : "or";
        e.rules_json = Ext.util.JSON.encode(d);
        if (this.isActionNew()) {
            e.method = "createsmart";
            e.name = b
        } else {
            if (this.isActionEdit()) {
                e.method = "updatesmart";
                e.id = this.plsId;
                e.new_name = b
            }
        }
        return e
    },
    isRulesChange: function() {
        var b = this.getNumberOfRules(),
            a;
        for (a = 0; a < b; a++) {
            if (this.rulePanel.items.itemAt(a).getForm().isDirty()) {
                return true
            }
        }
        return false
    },
    UpdateComboBox: function(c, b, a) {
        if (c == "tag") {
            this.opList.length = 0;
            switch (b) {
                case this.ns.ITUNES_TAG_DATE_ADDED:
                    this.opList.push([this.ns.ITUNES_OP_BEFORE, _ITUNESSTR("itunes", "itunes_before")]);
                    this.opList.push([this.ns.ITUNES_OP_AFTER, _ITUNESSTR("itunes", "itunes_after")]);
                    this.opList.push([this.ns.ITUNES_OP_LAST, _ITUNESSTR("itunes", "itunes_last")]);
                    this.opList.push([this.ns.ITUNES_OP_NOT_LAST, _ITUNESSTR("itunes", "itunes_not_last")]);
                    break;
                case this.ns.ITUNES_TAG_YEAR:
                case this.ns.ITUNES_TAG_BITRATE:
                case this.ns.ITUNES_TAG_SONG_RATING:
                    this.opList.push([this.ns.ITUNES_OP_EQUAL, _ITUNESSTR("itunes", "itunes_is")]);
                    this.opList.push([this.ns.ITUNES_OP_NOT_EQUAL, _ITUNESSTR("itunes", "itunes_is_not")]);
                    this.opList.push([this.ns.ITUNES_OP_GREATER, _ITUNESSTR("itunes", "itunes_greater")]);
                    this.opList.push([this.ns.ITUNES_OP_LESS, _ITUNESSTR("itunes", "itunes_less")]);
                    break;
                case this.ns.ITUNES_TAG_ARTIST:
                case this.ns.ITUNES_TAG_ALBUM:
                case this.ns.ITUNES_TAG_ALBUM_ARTIST:
                case this.ns.ITUNES_TAG_COMPOSER:
                case this.ns.ITUNES_TAG_GENRE:
                case this.ns.ITUNES_TAG_PATH:
                    this.opList.push([this.ns.ITUNES_OP_IS, _ITUNESSTR("itunes", "itunes_is")]);
                    this.opList.push([this.ns.ITUNES_OP_NOT_IS, _ITUNESSTR("itunes", "itunes_is_not")]);
                    this.opList.push([this.ns.ITUNES_OP_INCLUDES, _ITUNESSTR("itunes", "itunes_contains")]);
                    this.opList.push([this.ns.ITUNES_OP_NOT_INCLUDES, _ITUNESSTR("itunes", "itunes_not_contains")]);
                    break;
                default:
                    this.opList.push([""])
            }
            a.findField("op").store.loadData(this.opList)
        } else {
            if (c == "op") {
                this.PeriodList.length = 0;
                if (b == this.ns.ITUNES_OP_LAST || b == this.ns.ITUNES_OP_NOT_LAST) {
                    this.PeriodList.push([this.ns.ITUNES_INTERVAL_DAYS, _ITUNESSTR("itunes", "itunes_days")]);
                    this.PeriodList.push([this.ns.ITUNES_INTERVAL_WEEKS, _ITUNESSTR("itunes", "itunes_weeks")]);
                    this.PeriodList.push([this.ns.ITUNES_INTERVAL_MONTHS, _ITUNESSTR("itunes", "itunes_months")])
                } else {
                    this.PeriodList.push([""])
                }
                a.findField("interval").store.loadData(this.PeriodList)
            }
        }
    },
    addRuleRow: function(b) {
        var c = new Ext.form.FormPanel(this.getRuleRowConfig());
        var a = this.rulePanel.items.indexOfKey("add");
        this.rulePanel.insert(a, c);
        this.rulePanel.doLayout();
        if (!b) {
            b = new this.Rule({
                tag: 1,
                op: this.ns.ITUNES_OP_IS,
                tagval: "",
                interval: this.ns.ITUNES_SPACE_SELECT
            })
        }
        this.initRowValue(c.getForm(), b);
        this.updateRuleBtnStatus();
        (function() {
            this.panelWrap.fleXcrollTo(c.getEl())
        }.createDelegate(this)).defer(200)
    },
    initRowValue: function(b, c) {
        var a = {
            data: {
                value: ""
            }
        };
        if (this.blRequestFromAudioStaion && (this.ns.ITUNES_TAG_SONG_RATING == c.data.tag)) {
            c.data.tagval_song_rating = c.data.tagval
        } else {
            if (c.data.op == this.ns.ITUNES_OP_BEFORE || c.data.op == this.ns.ITUNES_OP_AFTER) {
                c.data.tagval_date_added = c.data.tagval
            }
        }
        b.loadRecord(c);
        a.data.value = c.data.tag;
        this.onTagSelect(b.findField("tag"), a);
        a.data.value = c.data.op;
        this.onOpSelect(b.findField("op"), a);
        b.loadRecord(c)
    },
    getRuleRowConfig: function() {
        var d;
        var e = [{
            xtype: "syno_combobox",
            name: "tag",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: this.tagStore,
            displayField: "display",
            valueField: "value",
            typeAhead: true,
            triggerAction: "all",
            mode: "local",
            width: 150,
            listeners: {
                select: {
                    scope: this,
                    fn: this.onTagSelect
                }
            }
        }, {
            xtype: "syno_combobox",
            name: "op",
            forceSelection: true,
            editable: false,
            allowBlank: false,
            store: new Ext.data.SimpleStore({
                id: "value",
                fields: ["value", "display"],
                data: this.opList
            }),
            displayField: "display",
            valueField: "value",
            typeAhead: true,
            triggerAction: "all",
            mode: "local",
            width: 150,
            listeners: {
                select: {
                    scope: this,
                    fn: this.onOpSelect
                }
            }
        }, {
            xtype: "syno_textfield",
            name: "tagval",
            maskRe: /^[^\-\s]/,
            enableKeyEvents: true,
            width: 150,
            listeners: {
                focus: {
                    scope: this,
                    fn: this.onValuetextFocus
                },
                blur: {
                    scope: this,
                    fn: function(g) {
                        g.getEl().dom.setAttribute("maxLength", this.ns.MAX_PATH_LENGTH);
                        this.validateedit(g, true)
                    }
                },
                keyup: {
                    scope: this,
                    fn: function() {
                        this.updateAddRuleBtnStatus()
                    }
                }
            }
        }, {
            xtype: "syno_combobox",
            name: "interval",
            editable: false,
            allowBlank: true,
            store: new Ext.data.SimpleStore({
                id: "value",
                fields: ["value", "display"],
                data: this.PeriodList
            }),
            displayField: "display",
            valueField: "value",
            typeAhead: true,
            triggerAction: "all",
            width: 100,
            mode: "local",
            hidden: true
        }];
        if (this.blRequestFromAudioStaion) {
            var a = {
                xtype: "syno_combobox",
                name: "tagval_song_rating",
                editable: false,
                allowBlank: false,
                width: 150,
                store: new Ext.data.SimpleStore({
                    id: "value",
                    fields: ["value", "display"],
                    data: this.songRatingList
                }),
                displayField: "display",
                valueField: "value",
                hidden: true
            };
            e.push(a)
        }
        var b = {
            xtype: "syno_datetimefield",
            name: "tagval_date_added",
            value: new Date().format("Y-m-d"),
            showToday: false,
            markToday: false,
            editable: false,
            width: 150
        };
        e.push(b);
        var f = {
            xtype: "syno_button",
            itemId: "delete",
            cls: "syno-as-rule-del-btn",
            btnStyle: "grey",
            name: "delete",
            tooltip: _ITUNESSTR("itunes", "itunes_del_rule"),
            scope: this,
            handler: this.onbtnDelRuleClk
        };
        e.push(f);
        var c = {
            cls: "syno-as-smart-rule-row-panel",
            border: false,
            height: 34,
            trackResetOnLoad: true,
            id: d = Ext.id(),
            items: [{
                xtype: "compositefield",
                hideLabel: true,
                defaults: {
                    rulePanelId: d
                },
                items: e
            }]
        };
        return c
    },
    initRuleRow: function() {
        this.tagStore = new Ext.data.SimpleStore({
            id: "value",
            fields: ["value", "display"],
            data: [
                [this.ns.ITUNES_TAG_ARTIST, _ITUNESSTR("itunes", "itunes_artist")],
                [this.ns.ITUNES_TAG_ALBUM, _ITUNESSTR("itunes", "itunes_album")],
                [this.ns.ITUNES_TAG_ALBUM_ARTIST, _ITUNESSTR("itunes", "itunes_album_artist")],
                [this.ns.ITUNES_TAG_COMPOSER, _ITUNESSTR("itunes", "itunes_composer")],
                [this.ns.ITUNES_TAG_GENRE, _ITUNESSTR("itunes", "itunes_genre")],
                [this.ns.ITUNES_TAG_PATH, _ITUNESSTR("itunes", "itunes_path")],
                [this.ns.ITUNES_TAG_YEAR, _ITUNESSTR("itunes", "itunes_year")],
                [this.ns.ITUNES_TAG_BITRATE, _ITUNESSTR("itunes", "itunes_bitrate")],
                [this.ns.ITUNES_TAG_DATE_ADDED, _ITUNESSTR("itunes", "itunes_date_added")]
            ]
        });
        if (this.blRequestFromAudioStaion) {
            var c = Ext.data.Record.create([{
                name: "value"
            }, {
                name: "display"
            }]);
            var a = new c({
                value: this.ns.ITUNES_TAG_SONG_RATING,
                display: _AST("music", "header_rating")
            });
            this.tagStore.add(a);
            this.songRatingList = [
                [this.ns.TAG_VAL_SONG_RATING_NOT_RATING, _AST("common", "no_rating")],
                [this.ns.TAG_VAL_SONG_RATING_1_STAR, _AST("common", "one_star")],
                [this.ns.TAG_VAL_SONG_RATING_2_STAR, _AST("common", "two_star")],
                [this.ns.TAG_VAL_SONG_RATING_3_STAR, _AST("common", "three_star")],
                [this.ns.TAG_VAL_SONG_RATING_4_STAR, _AST("common", "four_star")],
                [this.ns.TAG_VAL_SONG_RATING_5_STAR, _AST("common", "five_star")]
            ]
        }
        this.opList = [
            [this.ns.ITUNES_OP_IS, _ITUNESSTR("itunes", "itunes_is")],
            [this.ns.ITUNES_OP_NOT_IS, _ITUNESSTR("itunes", "itunes_is_not")],
            [this.ns.ITUNES_OP_INCLUDES, _ITUNESSTR("itunes", "itunes_contains")],
            [this.ns.ITUNES_OP_NOT_INCLUDES, _ITUNESSTR("itunes", "itunes_not_contains")]
        ];
        this.PeriodList = [];
        var b = Ext.data.Record.create([{
            name: "tag"
        }, {
            name: "op"
        }, {
            name: "tagval",
            type: "string"
        }, {
            name: "interval"
        }]);
        this.Rule = b
    },
    onbtnNewRuleClk: function() {
        this.addRuleRow()
    },
    updateAddRuleBtnStatus: function() {
        var b, d, a, c = this.getNumberOfRules();
        for (b = 0; b < c; b++) {
            d = this.rulePanel.items.itemAt(b).getForm();
            a = d.findField("tag").getValue();
            if (this.blRequestFromAudioStaion && this.ns.ITUNES_TAG_SONG_RATING === a) {
                continue
            } else {
                if (false === this.validateedit(d.findField("tagval"), false)) {
                    this.setRuleBtnAddDisable(true);
                    return
                }
            }
        }
        if (c < this.ns.ITUNES_PL_RULE_COUNT_MAX) {
            this.setRuleBtnAddDisable(false)
        } else {
            this.setRuleBtnAddDisable(true)
        }
    },
    updateRuleBtnStatus: function() {
        var a = this.getNumberOfRules();
        this.setRuleBtnDelDisable(1 === a);
        this.updateAddRuleBtnStatus()
    },
    setRuleBtnDelDisable: function(a) {
        var b = Ext.get(this.rulePanel.items.itemAt(0).id).child(".syno-as-rule-del-btn").id;
        if (a) {
            Ext.getCmp(b).disable()
        } else {
            Ext.getCmp(b).enable()
        }
    },
    setRuleBtnAddDisable: function(a) {
        var b = this.rulePanel.items.itemAt(this.getNumberOfRules()).id;
        if (a) {
            Ext.getCmp(b).disable()
        } else {
            Ext.getCmp(b).enable()
        }
    },
    onValuetextFocus: function(c) {
        var b = Ext.getCmp(c.rulePanelId).getForm(),
            a = b.findField("tag").getValue();
        switch (a) {
            case this.ns.ITUNES_TAG_ARTIST:
                c.getEl().dom.setAttribute("maxLength", this.ns.MAX_ARTIST_LENGTH);
                c.maskRe = /[^"\}]/;
                break;
            case this.ns.ITUNES_TAG_ALBUM:
                c.getEl().dom.setAttribute("maxLength", this.ns.MAX_ALBUM_LENGTH);
                c.maskRe = /[^"\}]/;
                break;
            case this.ns.ITUNES_TAG_ALBUM_ARTIST:
                c.getEl().dom.setAttribute("maxLength", this.ns.MAX_ALBUM_ARTIST_LENGTH);
                c.maskRe = /[^"\}]/;
                break;
            case this.ns.ITUNES_TAG_COMPOSER:
                c.getEl().dom.setAttribute("maxLength", this.ns.MAX_COMPOSER_LENGTH);
                c.maskRe = /[^"\}]/;
                break;
            case this.ns.ITUNES_TAG_GENRE:
                c.getEl().dom.setAttribute("maxLength", this.ns.MAX_GENRE_LENGTH);
                c.maskRe = /[^"\}]/;
                break;
            case this.ns.ITUNES_TAG_PATH:
                c.getEl().dom.setAttribute("maxLength", this.ns.MAX_PATH_LENGTH);
                c.maskRe = /[^"\}]/;
                break;
            case this.ns.ITUNES_TAG_YEAR:
                c.getEl().dom.setAttribute("maxLength", this.ns.MAX_YEAR_LENGTH);
                c.maskRe = /[0-9]/;
                break;
            case this.ns.ITUNES_TAG_BITRATE:
                c.getEl().dom.setAttribute("maxLength", this.ns.MAX_BITRATE_LENGTH);
                c.maskRe = /[0-9]/
        }
    },
    onbtnDelRuleClk: function(a, c) {
        var d = Ext.getCmp(a.rulePanelId);
        this.rulePanel.remove(d);
        this.rulePanel.doLayout();
        this.updateRuleBtnStatus()
    },
    onOpSelect: function(d, e, b) {
        var c = Ext.getCmp(d.rulePanelId).getForm(),
            a = c.findField("tag").getValue(),
            f = e.data.value;
        this.UpdateComboBox("op", f, c);
        if (a == this.ns.ITUNES_TAG_DATE_ADDED) {
            if (f == this.ns.ITUNES_OP_BEFORE || f == this.ns.ITUNES_OP_AFTER) {
                c.findField("tagval_date_added").show();
                c.findField("interval").setValue(this.ns.ITUNES_SPACE_SELECT);
                c.findField("interval").hide();
                c.findField("tagval").hide()
            } else {
                c.findField("tagval").setValue("0");
                c.findField("tagval").show();
                c.findField("interval").setValue(this.ns.ITUNES_INTERVAL_DAYS);
                c.findField("interval").show();
                c.findField("tagval_date_added").hide()
            }
        }
        this.rulePanel.doLayout()
    },
    onTagSelect: function(e, f, b) {
        var a = f.data.value;
        var d = Ext.getCmp(e.rulePanelId).getForm();
        var c = new Date();
        this.UpdateComboBox("tag", a, d);
        if (this.blRequestFromAudioStaion) {
            d.findField("tagval").show();
            d.findField("tagval_song_rating").hide()
        }
        d.findField("tagval_date_added").hide();
        switch (a) {
            case this.ns.ITUNES_TAG_DATE_ADDED:
                d.findField("op").setValue(this.ns.ITUNES_OP_BEFORE);
                d.findField("tagval").hide();
                d.findField("tagval_date_added").show();
                break;
            case this.ns.ITUNES_TAG_YEAR:
                d.findField("op").setValue(this.ns.ITUNES_OP_EQUAL);
                d.findField("tagval").setValue(c.format("Y").toString());
                break;
            case this.ns.ITUNES_TAG_BITRATE:
                d.findField("op").setValue(this.ns.ITUNES_OP_EQUAL);
                d.findField("tagval").setValue("128");
                break;
            case this.ns.ITUNES_TAG_SONG_RATING:
                if (this.blRequestFromAudioStaion) {
                    d.findField("tagval").hide();
                    d.findField("tagval_song_rating").show();
                    d.findField("op").setValue(this.ns.ITUNES_OP_EQUAL);
                    d.findField("tagval_song_rating").setValue(this.ns.TAG_VAL_SONG_RATING_5_STAR)
                }
                break;
            default:
                d.findField("op").setValue(this.ns.ITUNES_OP_IS)
        }
        d.findField("interval").setValue(this.ns.ITUNES_SPACE_SELECT);
        d.findField("interval").hide();
        this.rulePanel.doLayout();
        this.updateAddRuleBtnStatus()
    },
    validateedit: function(f, e) {
        var c = 0;
        var g = "";
        var d = Ext.getCmp(f.rulePanelId).getForm(),
            a = d.findField("tag").getValue(),
            h = d.findField("op").getValue(),
            b = f.getValue();
        if (this.ns.ITUNES_TAG_SONG_RATING == a || this.ns.ITUNES_TAG_DATE_ADDED == a) {
            return
        }
        if (b.trim().length === 0) {
            this.buttons[0].disable();
            g = String.format(_ITUNESSTR("itunes", "itunes_empty_value"), this.ns.tagRender(a));
            if (e) {
                this.setStatusError({
                    text: g,
                    clear: true
                })
            }
            this.buttons[0].enable();
            return false
        }
        switch (a) {
            case this.ns.ITUNES_TAG_ARTIST:
                c = this.ns.MAX_ARTIST_LENGTH;
                break;
            case this.ns.ITUNES_TAG_ALBUM:
                c = this.ns.MAX_ALBUM_LENGTH;
                break;
            case this.ns.ITUNES_TAG_ALBUM_ARTIST:
                c = this.ns.MAX_ALBUM_ARTIST_LENGTH;
                break;
            case this.ns.ITUNES_TAG_COMPOSER:
                c = this.ns.MAX_COMPOSER_LENGTH;
                break;
            case this.ns.ITUNES_TAG_GENRE:
                c = this.ns.MAX_GENRE_LENGTH;
                break;
            case this.ns.ITUNES_TAG_PATH:
                c = this.ns.MAX_PATH_LENGTH;
                break;
            case this.ns.ITUNES_TAG_YEAR:
                c = this.ns.MAX_YEAR_LENGTH;
                break;
            case this.ns.ITUNES_TAG_BITRATE:
                c = this.ns.MAX_BITRATE_LENGTH;
                break;
            case this.ns.ITUNES_TAG_DATE_ADDED:
                c = this.ns.MAX_DATE_ADDED_LENGTH
        }
        g += this.ValidateTagVal(a, h, b, c);
        if (g.length > 0) {
            this.buttons[0].disable();
            if (e) {
                this.setStatusError({
                    text: g,
                    clear: true
                })
            }
            this.buttons[0].enable();
            return false
        }
    },
    onplsNameChange: function(c, b, a) {
        var d = this.ns.ValidatePLSName(b);
        if (d.length > 0) {
            this.buttons[0].disable();
            this.setStatusError({
                text: d,
                clear: true
            });
            this.buttons[0].enable();
            this.plsName.setValue(a);
            this.plsName.focus()
        }
        this.plsName.setValue(b.trim())
    },
    ValidateTagVal: function(a, f, e, b) {
        var c = [34, 125];
        var d = "";
        if (a == this.ns.ITUNES_TAG_YEAR || a == this.ns.ITUNES_TAG_BITRATE || a == this.ns.ITUNES_TAG_DATE_ADDED) {
            return d
        }
        if (!e || e.length === 0) {
            d = String.format(_ITUNESSTR("itunes", "itunes_empty_value"), this.ns.tagRender(a));
            return d
        }
        if (!this.ns.IsValidStr(e, c)) {
            d = String.format(_ITUNESSTR("itunes", "itunes_symbol_warn"), this.ns.tagRender(a), ' " } ')
        }
        if (b < this.ns.StrLenGet(e)) {
            if (d.length > 0) {
                d += "<br>"
            }
            d += "[" + this.ns.tagRender(a) + "]" + _ITUNESSTR("itunes", "itunes_length_warn")
        }
        return d
    },
    getSaveRuleResponse: function(b, a) {
        var d = {},
            c;
        if (this.blRequestFromAudioStaion) {
            d.success = (true === a.success) ? true : false;
            if (true === d.success) {
                d.plsId = a.data.id
            }
        } else {
            if ("success" === a.result) {
                c = Ext.util.JSON.decode(b.params);
                d.success = true;
                d.plsId = "playlist_" + ((c.isPersonal) ? "personal" : "shared") + "_smart/" + c.plsname
            } else {
                if ("error_system" === a.result) {
                    d.success = false
                }
            }
        }
        return d
    },
    savePLSRequest: function(a) {
        if (this.blRequestFromAudioStaion) {
            this.savePlaylistForAudioStation(a)
        } else {
            if (this.isActionEdit()) {
                this.sendSmartPlaylistSet()
            } else {
                if (this.isActionNew()) {
                    this.sendSmartPlaylistCreate()
                }
            }
        }
    },
    getRules: function() {
        var b, g, a, f, e, c, d = [];
        c = this.getNumberOfRules();
        for (b = 0; b < c; b++) {
            g = this.rulePanel.items.itemAt(b).getForm();
            a = g.findField("tag").getValue();
            f = g.findField("op").getValue();
            if (f == this.ns.ITUNES_OP_BEFORE || f == this.ns.ITUNES_OP_AFTER) {
                e = g.findField("tagval_date_added").getValue().format("Y-m-d")
            } else {
                if (this.blRequestFromAudioStaion && this.ns.ITUNES_TAG_SONG_RATING === a) {
                    e = g.findField("tagval_song_rating").getValue()
                } else {
                    e = g.findField("tagval").getValue()
                }
            }
            if (false === this.validateedit(g.findField("tagval"), true)) {
                return false
            }
            d.push({
                tag: a,
                op: f,
                tagval: e,
                interval: g.findField("interval").getValue()
            })
        }
        return d
    },
    sendSmartPlaylistCreate: function() {
        this.setStatusBusy({
            text: _T("common", "msg_waiting")
        });
        this.sendWebAPI({
            api: "SYNO.SmartPlaylist",
            method: "create",
            params: {
                name: this.plsName.getValue(),
                match: this.lstConjRule.getValue(),
                rules: this.getRules()
            },
            version: 1,
            scope: this,
            callback: this.callbackSmartPlaylistCreate
        })
    },
    callbackSmartPlaylistCreate: function(c, b, a) {
        this.callbackSmartPlaylistCreateOrSet(c, b, a)
    },
    sendSmartPlaylistSet: function() {
        this.setStatusBusy({
            text: _T("common", "msg_waiting")
        });
        this.sendWebAPI({
            api: "SYNO.SmartPlaylist",
            method: "set",
            params: {
                name: this.oldName,
                new_name: this.plsName.getValue(),
                match: this.lstConjRule.getValue(),
                rules: this.getRules()
            },
            version: 1,
            scope: this,
            callback: this.callbackSmartPlaylistSet
        })
    },
    callbackSmartPlaylistSet: function(c, b, a) {
        this.callbackSmartPlaylistCreateOrSet(c, b, a)
    },
    callbackSmartPlaylistCreateOrSet: function(d, c, b) {
        var a = _T("common", "error_system");
        this.clearStatusBusy();
        if (d) {
            if (Ext.isFunction(this.owner.afterSaveSmartPlaylist)) {
                this.owner.afterSaveSmartPlaylist()
            }
            this.blShowConfirmDialog = false;
            this.close()
        } else {
            if (c && c.code == 400) {
                a = _ITUNESSTR("itunes", "itunes_pl_name_used")
            }
            this.setStatusError({
                text: a,
                clear: true
            })
        }
    },
    savePlaylistForAudioStation: function(a) {
        this.setStatusBusy({
            text: _T("common", "msg_waiting")
        });
        Ext.Ajax.request({
            url: this.cgiHandler,
            params: a,
            method: "POST",
            callback: function(d, e, c) {
                this.clearStatusBusy();
                if (e && c.responseText !== null) {
                    var b = Ext.util.JSON.decode(c.responseText),
                        f = this.getSaveRuleResponse(d, b);
                    if (true === f.success) {
                        if (this.blRequestFromAudioStaion && Ext.isFunction(this.owner.mainpanel.afterSaveSmartPlaylist)) {
                            this.owner.mainpanel.afterSaveSmartPlaylist(d)
                        }
                        this.blShowConfirmDialog = false;
                        this.close()
                    } else {
                        if (false === f.success) {
                            if (this.blRequestFromAudioStaion && "AUDIO_ERR_FILE_EXISTS" === this.owner.mainpanel._getUtils().getErrCodeMapping(b.error.code)) {
                                this.setStatusError({
                                    text: _ITUNESSTR("itunes", "itunes_pl_name_used"),
                                    clear: true
                                })
                            }
                        } else {
                            this.setStatusError({
                                text: _ITUNESSTR("itunes", b.result),
                                clear: true
                            })
                        }
                    }
                } else {
                    this.setStatusError({
                        text: _ITUNESSTR("itunes", "itunes_unknown_error"),
                        clear: true
                    })
                }
            },
            scope: this
        }, this)
    },
    load: function(c, b, a, d, e) {
        if (b == "edit") {
            this.oldName = c;
            this.plsId = "playlist_" + ((e) ? "personal" : "shared") + "_smart/" + c
        } else {
            this.oldName = "";
            this.plsId = "";
            this.lstConjRule.setValue("any");
            this.oldConjRuleVal = "any"
        }
        this.bliTunesRun = d;
        this.blIsPersonalSmartPlaylist = Ext.isDefined(e) ? e : false;
        this.actionType = b;
        this.library = a;
        this.plsName.setValue(c);
        if (this.blRequestFromAudioStaion) {
            this.addAsShare.setValue(!this.blIsPersonalSmartPlaylist)
        }
        this.show()
    },
    setInitialRules: function(a, b) {
        this.lstConjRule.setValue(a);
        this.oldConjRuleVal = a;
        this.oldCount = b.length;
        Ext.each(b, function(c) {
            var d = new this.Rule(c);
            this.addRuleRow(d)
        }, this)
    },
    onSmartPLSShow: function() {
        if (this.isActionNew()) {
            this.addRuleRow();
            (function() {
                this.plsName.focus()
            }).defer(100, this);
            return
        }
        this.setStatusBusy({
            text: _T("common", "msg_waiting")
        });
        if (this.blRequestFromAudioStaion) {
            this.loadRulesFromAudioStation()
        } else {
            this.sendSmartPlaylistGet()
        }
    },
    sendSmartPlaylistGet: function() {
        this.sendWebAPI({
            api: "SYNO.SmartPlaylist",
            method: "get",
            params: {
                name: this.plsName.getValue()
            },
            version: 1,
            scope: this,
            callback: this.callbackSmartPlaylistGet
        })
    },
    callbackSmartPlaylistGet: function(e, c, b) {
        var a, d;
        this.clearStatusBusy();
        if (e) {
            a = c.match;
            d = c.rules;
            if (a && d) {
                this.setInitialRules(a, d);
                return
            }
        }
        this.setStatusError({
            text: _T("common", "error_system"),
            clear: true
        })
    },
    loadRulesFromAudioStation: function() {
        Ext.Ajax.request({
            url: this.cgiHandler,
            params: this.getLoadRuleParamsForAudioStation(),
            method: "POST",
            callback: function(c, e, a) {
                this.clearStatusBusy();
                if (e && a.responseText !== null) {
                    var d = Ext.util.JSON.decode(a.responseText);
                    var b = this.getLoadRuleConjAndOps(d);
                    if (b.conjunction && b.ops) {
                        this.setInitialRules(b.conjunction, b.ops)
                    } else {
                        this.setStatusError({
                            text: _T("common", "error_system"),
                            clear: true
                        })
                    }
                } else {
                    this.setStatusError({
                        text: _ITUNESSTR("itunes", "itunes_unknown_error"),
                        clear: true
                    })
                }
            },
            scope: this
        })
    },
    getLoadRuleConjAndOps: function(b) {
        var a = {};
        if (this.blRequestFromAudioStaion) {
            if (b && b.data && b.data.playlists && b.data.playlists[0].additional) {
                a.conjunction = ("and" === b.data.playlists[0].additional.rules_conjunction) ? "all" : "any";
                a.ops = b.data.playlists[0].additional.rules
            }
        }
        return a
    },
    getLoadRuleParamsForAudioStation: function() {
        return {
            api: "SYNO.AudioStation.Playlist",
            version: 2,
            method: "getinfo",
            id: this.plsId,
            library: this.library,
            additional: "rules"
        }
    },
    getNumberOfRules: function() {
        return this.rulePanel.items.getCount() - 1
    },
    constructor: function(a) {
        this.ns = SYNO.SDS.AudioStation.SmartPlaylist.Utils;
        this.owner = a.owner;
        this.blRequestFromAudioStaion = Ext.isDefined(a.isFromAudioStation) ? a.isFromAudioStation : false;
        if (a.cgiUrl) {
            this.cgiHandler = a.cgiUrl
        } else {
            this.cgiHandler = this.jsConfig.jsBaseURL + "/smartplaylist.cgi"
        }
        this.initRuleRow();
        var b = this.fillConfig(a);
        this.callParent([b]);
        this.panelWrap = this.getComponent("syno_as_smart_wrap");
        this.infoPanel = this.panelWrap.getComponent("smart_info_panel");
        this.rulePanel = this.panelWrap.getComponent("smart_rule_panel");
        this.plsName = this.infoPanel.getForm().findField("plsname");
        this.addAsShare = this.infoPanel.getForm().findField("addAsSharePls");
        this.lstConjRule = Ext.getCmp(this.lstConjRuleId)
    },
    fillConfig: function(b) {
        var a = {
            xtype: "syno_formpanel",
            itemId: "smart_info_panel",
            border: false,
            labelWidth: 206,
            padding: "0",
            autoFlexcroll: false,
            useGradient: false,
            items: [{
                xtype: "syno_textfield",
                fieldLabel: _ITUNESSTR("itunes", "itunes_playlist_name"),
                itemId: "plsname",
                name: "plsname",
                style: {
                    paddingLeft: "8px"
                },
                id: this.plsnameId = Ext.id(),
                width: 300,
                validator: function(f) {
                    if (0 === f.length) {
                        return true
                    }
                    var e = SYNO.SDS.AudioStation.SmartPlaylist.Utils.ValidatePLSName(f);
                    if (0 < e.length) {
                        return e
                    }
                    return true
                },
                listeners: {
                    scope: this,
                    change: this.onplsNameChange
                }
            }, {
                xtype: "syno_checkbox",
                name: "addAsSharePls",
                boxLabel: this.blRequestFromAudioStaion ? _AST("playlist", "add_as_shared_playlist_v2") : "",
                checked: false,
                style: "padding: 0 0 0 8px;",
                disabled: this.blRequestFromAudioStaion && !SYNO.SDS.AudioStation.SessionData.privilege.playlist_edit,
                hidden: !this.blRequestFromAudioStaion
            }, {
                xtype: "syno_fieldset",
                padding: 0,
                title: typeof _IT === "function" ? _IT("app", "rules") : _ITUNESSTR("itunes", "itunes_rules"),
                bwrapCfg: {
                    cls: "x-fieldset-bwrap",
                    style: "padding-bottom: 0px"
                },
                items: {
                    xtype: "compositefield",
                    hideLabel: true,
                    items: [{
                        xtype: "syno_combobox",
                        itemId: "lstConjRule",
                        id: this.lstConjRuleId = Ext.id(),
                        hiddenName: "conjunction",
                        hideLabel: true,
                        editable: false,
                        width: 150,
                        allowBlank: false,
                        triggerAction: "all",
                        mode: "local",
                        store: [
                            ["all", _ITUNESSTR("itunes", "itunes_all")],
                            ["any", _ITUNESSTR("itunes", "itunes_any")]
                        ]
                    }, {
                        xtype: "syno_displayfield",
                        value: _ITUNESSTR("itunes", "itunes_match")
                    }]
                },
                listeners: {
                    afterrender: function(e) {
                        e.el.setStyle({
                            margin: 0
                        })
                    }
                }
            }]
        };
        var d = {
            xtype: "syno_panel",
            itemId: "smart_rule_panel",
            cls: "syno-as-smart-rule-panel",
            border: false,
            padding: "0 0 0 8px",
            items: [{
                xtype: "syno_button",
                itemId: "add",
                cls: "syno-ux-button",
                style: "margin-bottom: 8px;",
                name: "add",
                text: _ITUNESSTR("itunes", "itunes_new_rule_title"),
                scope: this,
                handler: this.onbtnNewRuleClk
            }],
            listeners: {
                scope: this,
                buffer: 100,
                afterlayout: function() {
                    this.panelWrap.updateScroller()
                }
            }
        };
        var c = {
            title: _ITUNESSTR("itunes", "itunes_smart_playlist"),
            width: 670,
            height: 446,
            minWidth: 670,
            minHeight: 446,
            layout: "fit",
            cls: "syno-as-smart-pls-win",
            items: [{
                xtype: "syno_panel",
                padding: "16px 30px 0px 22px",
                itemId: "syno_as_smart_wrap",
                autoFlexcroll: true,
                updateFormForScrollbar: true,
                items: [a, d]
            }],
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: this.DiscardChanges
            }, {
                text: _T("common", "apply"),
                btnStyle: "blue",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                scope: this,
                handler: this.SavePLS
            }],
            listeners: {
                show: {
                    scope: this,
                    fn: this.onSmartPLSShow
                },
                beforeclose: {
                    scope: this,
                    fn: this.onBeforeclose
                }
            }
        };
        Ext.apply(c, b);
        return c
    }
});
Ext.define("SYNO.SDS.AudioStation.HomepageView", {
    extend: "SYNO.ux.Panel",
    constructor: function(a) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.apply(this, arguments);
        SYNO.SDS.AudioStation.Window.addPanelScope("SYNO.SDS.AudioStation.HomepageView", this);
        this.audioMain = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main");
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        this.pinTitlePanel = new SYNO.ux.Panel({
            itemId: "pinTitle",
            layout: "border",
            height: 40,
            items: [{
                itemId: "myPinDiv",
                xtype: "container",
                region: "center",
                html: "<div>" + _AST("common", "my_pins") + "</div>",
                cls: "syno-as-home-section-title icon-type-pin"
            }, {
                xtype: "container",
                itemId: "btnShowmoreWrap",
                region: "east",
                layout: "border",
                width: 34,
                items: [{
                    xtype: "syno_button",
                    itemId: "btnShowmore",
                    region: "center",
                    height: 24,
                    margins: {
                        top: 2,
                        bottom: 2,
                        right: 10
                    },
                    tooltip: _AST("common", "show_more"),
                    cls: "syno-as-home-showmore",
                    hidden: true,
                    handler: this.showAllPins,
                    scope: this
                }]
            }]
        });
        this.pinDataView = new SYNO.SDS.AudioStation.PinThumbDataView({
            itemId: "pinThumbView",
            autoScroll: false,
            module: this
        });
        this.defaultGenreTitlePanel = new SYNO.ux.Panel({
            itemId: "defaultGenreTitle",
            layout: "border",
            height: 40,
            items: [{
                itemId: "defaultGenreDiv",
                xtype: "container",
                region: "center",
                html: "<div>" + _AST("common", "default_genre") + "</div>",
                cls: "syno-as-home-section-title icon-type-genre"
            }]
        });
        this.defaultGenreDataView = new SYNO.SDS.AudioStation.DefaultGenreDataView({
            itemId: "defaultThumbView",
            autoScroll: false,
            module: this
        });
        var b = {
            xtype: "syno_panel",
            itemId: "homepagePanel",
            autoFlexcroll: true,
            border: false,
            items: [this.pinTitlePanel, this.pinDataView, this.defaultGenreTitlePanel, this.defaultGenreDataView],
            layout: {
                type: "vbox",
                align: "stretch",
                pack: "start"
            },
            listeners: {
                scope: this,
                activate: this.onActivate,
                deactivate: this.onDeactivate
            }
        };
        Ext.apply(b, a);
        return b
    },
    showAllPins: function() {
        var a = {
            id: "AllPin",
            name: _AST("common", "my_pins")
        };
        var c = new this.audioMain.pinStore.recordType(a, a.id);
        var b = this.audioMain.prepareGotoNextParam(c);
        this._getWindow().getPathMgr().onGotoNext(_AST("common", "my_pins"), b, 2)
    },
    onActivate: function() {
        this.pinDataView.onActivate();
        this.defaultGenreDataView.onActivate();
        this.defaultGenreDataView.refreshView()
    },
    onDeactivate: function() {
        this.pinDataView.onDeactivate();
        this.defaultGenreDataView.onDeactivate()
    },
    setMoreButtonDisplay: function(a) {
        this.pinTitlePanel.getComponent("btnShowmoreWrap").getComponent("btnShowmore").setVisible(a)
    }
});
Ext.define("SYNO.SDS.AudioStation.PinThumbDataView", {
    extend: "SYNO.SDS.AudioStation.ThumbDataView",
    constructor: function(a) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.apply(this, arguments);
        var b = this.fillConfig(a);
        this.callParent([b]);
        this.oriHeight = 0;
        this.getStore().on("remove", function() {
            this.refreshView.defer(100, this)
        }, this, {
            buffer: 100
        })
    },
    getStore: function() {
        return this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main").pinStore
    },
    getTpl: function() {
        var a = new Ext.XTemplate('<tpl for=".">', '<div class="thumb-wrap">', '<div class="thumb thumb-loading" >', '<img thumbnails="{[this.getImageURL(values)]}">', '<div class="syno-as-thumb-sharing-status {[this.getSharingStatusCls(values)]}"></div>', '<div class="syno-as-thumb-pin-type-wrap"><div class="syno-as-thumb-pin-type {[this.getPinTypeClass(values)]}"></div></div>', '<div class="syno-as-thumb-play"></div>', "</div>", '<span class="thumb-title" ext:qtip="{[this.getTooltip(values)]}">{[this.getTitle(values)]}</span>', '<span class="thumb-artist">{[this.getArtist(values)]}</span>', "</div>", "</tpl>", '<div class="x-clear"></div>', {
            getTitle: function(b) {
                var c = b.title || b.name;
                c = SYNO.SDS.AudioStation.Utils.getRenderedTitle(c, b.id);
                return Ext.util.Format.htmlEncode(c)
            },
            getImageURL: this.processImgUrl.createDelegate(this, [], true),
            getArtist: function(b) {
                if ("album" !== b.type) {
                    return ""
                }
                if (b.album_artist) {
                    return Ext.util.Format.htmlEncode(b.album_artist)
                } else {
                    if (b.artist) {
                        return Ext.util.Format.htmlEncode(b.artist)
                    } else {
                        return ""
                    }
                }
            },
            getSharingStatusCls: function(b) {
                if ("valid" == b.sharing_status) {
                    return "st-valid"
                } else {
                    if ("invalid" == b.sharing_status || "expired" == b.sharing_status) {
                        return "st-invalid"
                    }
                }
                return ""
            },
            getTooltip: function(b) {
                return SYNO.SDS.AudioStation.Utils.getPinCriteriaDescription(b)
            },
            getPinTypeClass: function(b) {
                return "pin-type-" + b.type
            }
        });
        return a
    },
    processImgUrl: function(a) {
        return SYNO.SDS.AudioStation.Utils.processAlbumArtUrl(a, "pin")
    },
    onViewResize: function(a, f, d, c, e, b) {
        if (d !== this.oriHeight && this.itemId === "pinThumbView") {
            this.oriHeight = d;
            this.module.doLayout()
        }
        this.refreshView(true)
    },
    refreshView: function(g) {
        var c, b;
        var d = this.getTemplateTarget();
        b = this.getStore().getRange();
        if (this.itemId === "pinThumbView") {
            this.clearSelections(false, true);
            c = this.getThumbnailRange();
            var a = b.length > c ? 2 : 1;
            var f = false;
            if (b.length < 1) {
                if (this.hasSkippedEmptyText) {
                    d.update('<div class="syno-as-homepage-pin-empty">' + _AST("common", "no_pin") + "</div>");
                    this.setHeight(120);
                    this.all.clear()
                }
                this.hasSkippedEmptyText = true
            } else {
                var e = this.collectData(b, 0, c * a);
                if (!g || e.length !== this.lastRenderCount) {
                    this.lastRenderCount = e.length;
                    this.tpl.overwrite(d, e);
                    this.all.fill(Ext.query(this.itemSelector, d.dom));
                    this.updateIndexes(0);
                    this.preloadItems()
                }
                if (b.length > e.length) {
                    f = true
                }
                this.setHeight(200 * a)
            }
            this.updateScrollbar();
            this.module.setMoreButtonDisplay.call(this.module, f)
        } else {
            if (b.length < 1) {
                if (this.hasSkippedEmptyText) {
                    d.update('<div class="syno-as-homepage-pin-empty">' + _AST("common", "no_pin") + "</div>")
                }
                this.hasSkippedEmptyText = true
            }
            this.updateScrollbar();
            if (!g) {
                this.preloadItems()
            }
        }
    },
    beforeNodeSelect: function(a, d, c, b) {
        if ("pinThumbView" === this.itemId) {
            this.module.defaultGenreDataView.clearSelections()
        }
    }
});
Ext.define("SYNO.SDS.AudioStation.PinEditDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        var b;
        this.option = a.option;
        this.oriName = this.option.name;
        this.pinId = this.option.id;
        this.description = this.option.description;
        b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        var b = {
            title: _AST("common", "my_pins"),
            layout: "form",
            width: 560,
            height: 200,
            padding: "16px 20px 0",
            cls: "syno-as-dialog",
            constrain: true,
            resizable: false,
            items: [{
                xtype: "syno_textfield",
                itemId: "text",
                fieldLabel: _AST("common", "pin_name"),
                validator: this.validateName,
                width: 350
            }, {
                xtype: "syno_displayfield",
                itemId: "desc",
                htmlEncode: false,
                style: "overflow:hidden; text-overflow: ellipsis; white-space: nowrap;",
                fieldLabel: _AST("common", "literal_description")
            }],
            buttons: [{
                text: _AST("common", "btn_cancel"),
                scope: this,
                handler: this.handleCancel
            }, {
                text: _AST("common", "btn_ok"),
                btnStyle: "blue",
                scope: this,
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                handler: this.handleApply
            }],
            keys: [{
                key: Ext.EventObject.ENTER,
                scope: this,
                fn: this.handleApply
            }, {
                key: Ext.EventObject.ESC,
                scope: this,
                fn: this.handleCancel
            }],
            listeners: {
                afterRender: {
                    fn: this.afterDlgRender,
                    scope: this
                }
            }
        };
        Ext.apply(b, a);
        return b
    },
    afterDlgRender: function() {
        this.textValue = this.getComponent("text");
        this.textValue.setValue(this.oriName);
        this.textDescription = this.getComponent("desc");
        this.textDescription.setValue(this.description)
    },
    validateName: function(a) {
        if (250 < SYNO.SDS.AudioStation.Utils.lengthGetInBytes(a)) {
            return _AST("common", "pin_name_too_long")
        } else {
            return true
        }
    },
    handleApply: function() {
        if (_S("demo_mode")) {
            return
        }
        if (Ext.isEmpty(this.textValue.getValue().trim())) {
            this.textValue.markInvalid(_AST("common", "pin_name_empty"));
            return
        }
        if (!this.textValue.isValid()) {
            return
        }
        SYNO.API.Request({
            api: "SYNO.AudioStation.Pin",
            method: "rename",
            version: "1",
            params: {
                id: this.pinId,
                name: this.textValue.getValue()
            },
            callback: this.callback,
            scope: this.callbackScope
        });
        this.close()
    },
    handleCancel: function() {
        this.close()
    }
});
Ext.define("SYNO.SDS.AudioStation.PinReorderDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        var b;
        b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        var b = {
            width: 625,
            height: 580,
            constrain: true,
            resizable: false,
            title: _AST("common", "my_pins"),
            cls: "syno-as-dialog",
            layout: "fit",
            items: [this.getGridPanel({
                owner: this
            })],
            buttons: [{
                text: _AST("common", "btn_ok"),
                btnStyle: "blue",
                scope: this,
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                handler: this.handleApply
            }, {
                text: _AST("common", "btn_cancel"),
                scope: this,
                handler: this.handleCancel
            }]
        };
        Ext.apply(b, a);
        return b
    },
    getGridPanel: function(a) {
        this.grid = new SYNO.SDS.AudioStation.PinReorderGrid(a);
        return this.grid
    },
    handleApply: function() {
        if (this.grid.isDataDirty()) {
            var a = this.grid.getApplyData();
            SYNO.API.Request({
                api: "SYNO.AudioStation.Pin",
                method: "reorder",
                version: "1",
                params: {
                    items: a,
                    offset: 0,
                    limit: -1
                },
                callback: this.callback,
                scope: this.callbackScope
            })
        }
        this.close()
    },
    handleCancel: function() {
        this.close()
    }
});
Ext.define("SYNO.SDS.AudioStation.PinReorderGrid", {
    extend: "SYNO.ux.DDGridPanel",
    constructor: function(a) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.apply(this, arguments);
        this.audioMain = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main");
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        this.createActions();
        this.ctxMenu = new SYNO.ux.Menu({
            items: [this.getAction("up"), this.getAction("down")]
        });
        var b = {
            viewConfig: {
                ddGroup: "PinReorderGridDD",
                forceFit: false
            },
            cm: this.getCM(),
            sm: this.getSM(),
            store: this.getDS(a),
            enableDragDrop: true,
            enableColumnMove: false,
            autoFlexScroll: true,
            autoExpandColumn: this.nameID,
            listeners: {
                viewready: this.onGridViewReady,
                rowclick: this.onGridRowClick,
                rowcontextmenu: this.onRowCtxMenu,
                columnresize: this.onColumnResize,
                containercontextmenu: this.showCtxMenu,
                afterDrop: this.onRowDrop
            }
        };
        return Ext.apply(b, a)
    },
    getDS: function(a) {
        var b = new SYNO.API.JsonStore({
            api: "SYNO.AudioStation.Pin",
            method: "list",
            version: 1,
            appWindow: SYNO.SDS.AudioStation.Window,
            autoLoad: true,
            baseParams: {
                offset: 0,
                limit: -1
            },
            root: "items",
            totalProperty: "total",
            fields: SYNO.SDS.AudioStation.Window.gFields,
            listeners: {
                beforeload: function() {
                    this.owner.setStatusBusy()
                },
                load: function() {
                    this.owner.clearStatusBusy();
                    this.isDirty = false
                },
                exception: function() {
                    this.owner.clearStatusBusy()
                },
                scope: this
            }
        });
        return b
    },
    getCM: function() {
        var a = new Ext.grid.ColumnModel([{
            header: _AST("playlist", "header_type"),
            id: this.typeID = Ext.id(),
            dataIndex: "type",
            editable: false,
            sortable: false,
            menuDisabled: true,
            renderer: this.renderer
        }, {
            header: _AST("common", "name"),
            id: this.nameID = Ext.id(),
            dataIndex: "name",
            editable: false,
            sortable: false,
            menuDisabled: true,
            renderer: this.renderer
        }]);
        return a
    },
    getSM: function() {
        return new Ext.grid.RowSelectionModel()
    },
    renderer: function(e, b, a, f, c) {
        if (0 === c) {
            if ("folder" === e) {
                return _AST("common", "type_folder")
            } else {
                if ("playlist" === e) {
                    return _AST("common", "class_music_playlist")
                } else {
                    if ("random_100" === e) {
                        return _AST("common", "random_playlist")
                    } else {
                        if ("recently_added" === e) {
                            return _AST("common", "class_music_latestalbum")
                        } else {
                            return _AST("music", "header_" + e)
                        }
                    }
                }
            }
        } else {
            var d = SYNO.SDS.AudioStation.Utils.getPinCriteriaDescription(a.data);
            return String.format('<div ext:qtip="{0}">{1}</div>', d, Ext.util.Format.htmlEncode(e))
        }
    },
    onGridViewReady: function() {
        this.view.updateScroller()
    },
    onGridRowClick: function(a, c, b) {
        if (b && c && !b.hasModifier()) {
            a.getSelectionModel().selectRow(c)
        }
    },
    onColumnResize: function() {
        this.getView().fitColumns()
    },
    actions: null,
    createActions: function() {
        var a = function(f, e, d, c, b) {
            return new Ext.Action(Ext.apply({
                text: f,
                itemId: e,
                handler: d,
                scope: c
            }, b))
        };
        this.actions = {
            up: a(_T("common", "up"), "up", this.onClickUP, this),
            down: a(_T("common", "down"), "down", this.onClickDown, this)
        }
    },
    onClickUP: function() {
        this.moveSelectedRow(true)
    },
    onClickDown: function() {
        this.moveSelectedRow(false)
    },
    onRowCtxMenu: function(b, c, a) {
        a.preventDefault();
        var d = b.getSelectionModel();
        if (!d.isSelected(c)) {
            d.selectRow(c)
        }
        this.showCtxMenu(b, a)
    },
    onRowDrop: function() {
        this.isDirty = true
    },
    showCtxMenu: function(b, a) {
        this.ctxMenu.showAt(a.getXY())
    },
    getAction: function(a) {
        var b = this.actions[a];
        return b
    },
    moveSelectedRow: function(f) {
        var c = this.getStore(),
            h = this.getSelectionModel(),
            e = h.getSelections(),
            a = c.getCount(),
            b = -1,
            d, g;
        if (Ext.isEmpty(e)) {
            return
        }
        if (f) {
            b = c.indexOf(e.first()) - 1;
            if (b <= 0) {
                b = 0
            }
        } else {
            b = c.indexOf(e.last()) + 1;
            if (b >= (a - 1)) {
                b = a - 1
            }
        }
        c.suspendEvents();
        for (d = 0; d < e.length; d++) {
            c.remove(e[d]);
            if (0 === d) {
                g = b
            } else {
                g = this.store.indexOf(e[d - 1]) + 1
            }
            c.insert(g, e[d]);
            this.isDirty = true
        }
        c.resumeEvents();
        this.view.refresh();
        this.view.focusEl.focus()
    },
    isDataDirty: function() {
        return this.isDirty
    },
    getApplyData: function() {
        var b = [];
        var a = this.getStore();
        a.each(function(c) {
            b.push(c.data.id)
        }, this);
        return b
    }
});
Ext.define("SYNO.SDS.AudioStation.DefaultGenreDataView", {
    extend: "SYNO.SDS.AudioStation.ThumbDataView",
    constructor: function(a) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.apply(this, arguments);
        var b = this.fillConfig(a);
        Ext.apply(b, {
            multiSelect: false,
            singleSelect: true
        });
        this.callParent([b]);
        this.oriHeight = 0
    },
    getStore: function() {
        if (!this.defaultGenreStore) {
            this.defaultGenreStore = this.createStore()
        }
        return this.defaultGenreStore
    },
    createStore: function() {
        var a = new Ext.data.Store({
            paramNames: {
                start: "offset",
                limit: "limit"
            },
            autoLoad: true,
            method: "POST",
            baseParams: this._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.Genre",
                method: "list_default_genre"
            }),
            proxy: new Ext.data.HttpProxy({
                url: this._getUtils().getWebAPIURL("genre.cgi"),
                listeners: {
                    scope: this,
                    beforeload: function(b, c) {
                        var d = b.activeRequest.read;
                        if (d) {
                            Ext.Ajax.abort(d);
                            SYNO.SDS.AudioStation.Window.clearStatusBusy()
                        }
                    }
                }
            }),
            reader: new Ext.data.JsonReader({
                root: "data.default_genres",
                totalProperty: "data.total",
                fields: SYNO.SDS.AudioStation.Window.gFields
            })
        });
        return a
    },
    processImgUrl: function(a) {
        return SYNO.SDS.AudioStation.Utils.processAlbumArtUrl(a, "default_genre")
    },
    onViewResize: function(a, e, c, b, d) {
        if (c !== this.oriHeight) {
            this.oriHeight = c;
            this.module.doLayout()
        }
        this.refreshView(true)
    },
    refreshView: function(c) {
        var b;
        this.clearSelections(false, true);
        b = this.getThumbnailRange();
        var a = 200 * Math.ceil(this.getStore().getTotalCount() / b);
        this.setHeight(a);
        this.preloadItems();
        this.updateScrollbar()
    },
    beforeNodeSelect: function(a, d, c, b) {
        this.module.pinDataView.clearSelections()
    }
});
Ext.define("SYNO.SDS.AudioStation.SearchConditionDialog", {
    extend: "SYNO.SDS.ModalWindow",
    comboWidth: 230,
    constructor: function(a) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.apply(this, arguments);
        this.owner = a.owner;
        this.data = a.data;
        this.selectedAlbum = a.selectedAlbum;
        this.selectedArtist = a.selectedArtist;
        this.selectedRecords = a.selectedRecords;
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        var b = {
            owner: this.owner,
            layout: "fit",
            cls: "syno-as-dialog",
            border: false,
            resizable: false,
            title: _AST("common", "search_by"),
            width: 375,
            height: 200,
            items: this.formPanel = this.createPanel(),
            buttons: [{
                text: _AST("common", "btn_cancel"),
                scope: this,
                handler: this.cancelHandler
            }, {
                text: _AST("common", "btn_next"),
                btnStyle: "blue",
                scope: this,
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                handler: this.nextHandler
            }],
            listeners: {
                scope: this,
                afterrender: this.onAfterRender
            }
        };
        return b
    },
    createPanel: function() {
        var a = {
            labelWidth: 90,
            defaultType: "syno_textfield",
            trackResetOnLoad: true,
            itemId: "searchConditionAlbumArtist",
            items: [{
                xtype: "syno_combobox",
                id: this.searchConditionAlbumComboId = Ext.id(),
                width: this.comboWidth,
                name: "album",
                editable: true,
                triggerAction: "all",
                mode: "local",
                displayField: "value",
                valueField: "value",
                hideTrigger: true,
                store: new Ext.data.ArrayStore({
                    fields: ["value"]
                }),
                fieldLabel: _AST("music", "header_album")
            }, {
                xtype: "syno_combobox",
                id: this.searchConditionArtistComboId = Ext.id(),
                width: this.comboWidth,
                name: "artist",
                editable: true,
                triggerAction: "all",
                mode: "local",
                displayField: "value",
                valueField: "value",
                hideTrigger: true,
                store: new Ext.data.ArrayStore({
                    fields: ["value"]
                }),
                fieldLabel: _AST("music", "header_artist")
            }]
        };
        return new SYNO.ux.FormPanel(a)
    },
    onAfterRender: function(a) {
        var b;
        b = Ext.getCmp(this.searchConditionAlbumComboId);
        b.setHideTrigger(false);
        b.getStore().loadData(this.selectedAlbum);
        b.setValue(this.selectedAlbum[0]);
        b = Ext.getCmp(this.searchConditionArtistComboId);
        b.setHideTrigger(false);
        b.getStore().loadData(this.selectedArtist);
        b.setValue(this.selectedArtist[0])
    },
    getResultAlbums: function(a) {
        var c = [],
            b;
        for (b = 0; b < a.length; b++) {
            c.push([(b + 1) + ". " + a[b].album_artist + " - " + a[b].album + " (" + a[b].year + ")"])
        }
        return c
    },
    onListReleasesDone: function(e, c, d, b) {
        var a;
        if (!e) {
            this.clearStatusBusy();
            this._getWindow().getMsgBox().alert(this.title, _AST("common", "error_system"));
            return
        } else {
            if (!c || !c.items || c.items.length === 0) {
                this.clearStatusBusy();
                this._getWindow().getMsgBox().alert(this.title, _AST("common", "error_no_result"));
                return
            }
        }
        a = new SYNO.SDS.AudioStation.SearchResultDialog({
            resultAlbums: this.getResultAlbums(c.items),
            resultAlbumData: c.items,
            selectedRecords: this.selectedRecords,
            owner: this._getWindow()
        });
        a.open();
        this.clearStatusBusy();
        this.hide()
    },
    nextHandler: function() {
        this.setStatusBusy({
            text: _T("common", "msg_waiting")
        });
        SYNO.API.Request({
            api: "SYNO.AudioStation.Tag",
            method: "list",
            version: "1",
            params: {
                album: Ext.getCmp(this.searchConditionAlbumComboId).getValue().toString(),
                album_artist: Ext.getCmp(this.searchConditionArtistComboId).getValue().toString()
            },
            callback: this.onListReleasesDone,
            scope: this
        })
    },
    cancelHandler: function() {
        this.close()
    }
});
Ext.define("SYNO.SDS.AudioStation.Webapi.Base.Main", {
    apiName: null,
    successCallback: Ext.emptyFn,
    failureCallback: Ext.emptyFn,
    setSuccessCallback: function(a) {
        this.successCallback = a
    },
    setFailureCallback: function(a) {
        this.failureCallback = a
    },
    send: function(c, a, b) {
        SYNO.API.Request({
            api: this.apiName,
            method: c,
            version: a,
            params: b,
            callback: this.sendCallback.createDelegate(this),
            scope: this
        })
    },
    sendCallback: function(c, b, a) {
        SYNO.SDS.AudioStation.Window.clearStatusBusy();
        if (!c) {
            if (Ext.isFunction(this.failureCallback)) {
                this.failureCallback(b.code, b, a)
            }
            return
        }
        if (Ext.isFunction(this.successCallback)) {
            this.successCallback(b)
        }
    }
});
Ext.define("SYNO.SDS.AudioStation.Webapi.Browse.Playlist", {
    extend: "SYNO.SDS.AudioStation.Webapi.Base.Main",
    apiName: "SYNO.AudioStation.Browse.Playlist",
    addTrack: function(a, b, d) {
        var c = {
            id: a
        };
        Ext.apply(c, b);
        if (Ext.isBoolean(d)) {
            c.skip_duplicated = d
        }
        this.send("add_track", "1", c)
    }
});
Ext.define("SYNO.SDS.AudioStation.Main", {
    extend: "SYNO.SDS.AudioStation.Base_Main",
    gCurrentSelectPlayer: "__SYNO_WEB_PLAYER__",
    gIsRetina: false,
    gIsOnMiniPlayerMode: false,
    gIsOnLargePlayingQueue: false,
    miniPlayerSizePosition: null,
    delayPlayFn: null,
    gSearchCate: "all",
    gHasReloadPlaylist: false,
    constructor: function(a) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.call(this, a);
        SYNO.SDS.AudioStation.Window.addPanelScope("SYNO.SDS.AudioStation.Main", this);
        this.dataStore = this.createDataStore();
        this.pinStore = this.createPinStore();
        this.playingStore = this.createPlayingStore();
        this.searchAllStore = this.createSearchAllStore();
        this.searchAllArtistStore = this.createSearchAllArtistStore();
        this.searchAllAlbumStore = this.createSearchAllAlbumStore();
        this.searchAllSongStore = this.createSearchAllSongStore();
        this.addManagedComponent(this.dataStore);
        this.metadataMapping = this.createMetadataMapping();
        this.paramsMapping = this.createParamsMapping();
        this.gIsRetina = SYNO.SDS.UIFeatures.test("isRetina");
        this.firstSongIdx = 0;
        this.checkedRatingFilter = [];
        this.defaultPinItems = [this._getUtils()._Random100_ID, this._getUtils()._RecentlyAdded_ID, this._getUtils()._SharedSongs_ID];
        this.audioWebPlayer = SYNO.SDS.AudioStation.WebPlayer(this);
        this.addManagedComponent(this.audioWebPlayer);
        this.audioPlayer = SYNO.SDS.AudioStation.Player(this, this.audioWebPlayer);
        this.audioWebPlayer.setStreamStore(this.playingStore);
        var b = this.fillConfig(a);
        this.callParent([b]);
        this.updateMainToolbar();
        this.getItemMenu()
    },
    fillConfig: function(a) {
        this.createToolbarAction();
        this.listPanel = new SYNO.SDS.AudioStation.ListPanel({
            itemId: "listPanel",
            region: "west",
            style: "padding-top:16px;",
            width: 240
        });
        this.cardPanel = new SYNO.SDS.AudioStation.CardPanel({
            itemId: "cardPanel",
            region: "center"
        });
        this.browsePanel = {
            xtype: "syno_panel",
            itemId: "browse",
            border: false,
            layout: "border",
            cls: "syno-as-browse-panel",
            bodyCssClass: "syno-as-panel-body",
            monitorResize: true,
            items: [this.listPanel, this.cardPanel],
            listeners: {
                scope: this,
                activate: function() {
                    if (this._getUtils().isPlayingQueue()) {
                        this.cardPanel.listViewGrid.view.scrollToTop()
                    }
                }
            }
        };
        this.largePlayingQueuePanel = new SYNO.SDS.AudioStation.PlayingQueueView({
            itemId: "LargePlayingQueue"
        });
        this.mainCardPanel = new SYNO.ux.Panel({
            itemId: "mainCardPanel",
            cls: "syno-as-main-panel",
            bodyCssClass: "syno-as-panel-body",
            region: "center",
            border: false,
            layout: "card",
            activeItem: 0,
            items: [this.browsePanel, this.largePlayingQueuePanel]
        });
        this.playerPanel = new SYNO.SDS.AudioStation.PlayerPanel({
            itemId: "player",
            region: "south",
            height: 74,
            audioAppMain: this,
            cls: "syno-as-player-panel"
        });
        var b = {
            xtype: "syno_panel",
            border: false,
            layout: "border",
            cls: "syno-as-panel",
            bodyCssClass: "syno-as-panel-body",
            width: 800,
            height: 400,
            monitorResize: true,
            items: [this.playerPanel, this.mainCardPanel]
        };
        Ext.apply(b, a);
        return b
    },
    createToolbarAction: function() {
        this.ratingFilterBtn = new SYNO.ux.Button({
            cls: "syno-as-filter-btn",
            itemId: "btnRatingFilter",
            menu: this.createRatingFilterMenu(),
            scope: this
        });
        this.actionAction = new Ext.Action({
            xtype: "syno_button",
            text: _AST("common", "btn_start"),
            itemId: "btn_action",
            cls: "syno-ux-button-dropdown",
            getMenuClass: function() {
                return "x-btn-arrow"
            },
            handler: function(a, c) {
                this.onShowItemMenu(a, c)
            },
            scope: this
        });
        this.listViewAction = new Ext.Action({
            itemId: "switchListMode",
            ctCls: "syno-as-listMode",
            toggleGroup: "switchMode",
            enableToggle: true,
            allowDepress: false,
            tooltip: _AST("common", "mode_list"),
            handler: this.onModeItemClick,
            scope: this
        });
        this.thumbViewAction = new Ext.Action({
            itemId: "switchThumbMode",
            ctCls: "syno-as-thumbMode",
            toggleGroup: "switchMode",
            enableToggle: true,
            allowDepress: false,
            tooltip: _AST("common", "mode_icon"),
            handler: this.onModeItemClick,
            scope: this
        });
        this.settingsBtn = new SYNO.ux.Button({
            text: _AST("user", "user_setting"),
            handler: function(a, c) {
                this.onSettingClick()
            },
            scope: this
        })
    },
    toggleAction: function(c, b, a) {
        c.each(function(e, d) {
            e.toggle(b, a)
        }, this)
    },
    getModeAction: function(a) {
        if ("switchListMode" === a) {
            return this.listViewAction
        }
        if ("switchThumbMode" === a) {
            return this.thumbViewAction
        }
        return false
    },
    getActions: function(a) {
        if (a) {
            return [this.actionAction]
        }
        return [this.ratingFilterBtn, this.actionAction, this.settingsBtn, this.listViewAction, this.thumbViewAction]
    },
    onPlayingModeSelected: function(b, a) {
        if ("stream" !== b && (soundManager.getSoundById("syno_audio") || soundManager.getSoundById("syno_audio2"))) {
            this.audioWebPlayer.createStreamStore(this.playingStore, this.handlePlayingModeSelectedAction.createDelegate(this, [b, a]))
        } else {
            this.handlePlayingModeSelectedAction(b, a)
        }
    },
    handlePlayingModeSelectedAction: function(b, a) {
        this.updatePlayingModeInfo(b, a);
        if ("renderer" == b) {
            if ("__SYNO_Multiple_AirPlay__" === a.get("id")) {
                this.showMultiAirPlayDialog(a.get("id"))
            }
            if ("airplay" === a.get("type") && true === a.get("password_protected")) {
                this.testAirPlayPassword(a)
            }
        }
    },
    updatePlayingModeInfo: function(b, a) {
        var c = "",
            d;
        d = this.gCurrentSelectPlayer;
        switch (b) {
            case "stream":
                this.gCurrentSelectPlayer = "__SYNO_WEB_PLAYER__";
                this.gCurrentSelectPlayerType = "web";
                if (this._getUtils().isIosDevice()) {
                    this.playerPanel.setMuteBtnDisabled(true);
                    this.playerPanel.Ctrl.setSetVolumeAbility(false)
                }
                break;
            case "renderer":
                if (!a) {
                    this.switchToStreamingMode();
                    return
                }
                c = Ext.util.Format.ellipsis(a.get("name"), 20, false);
                if ("__SYNO_Multiple_AirPlay__" === a.get("id")) {
                    c = _AST("player", "to_multiple_airplay")
                }
                this.gCurrentSelectPlayer = a.get("id");
                this.gCurrentSelectPlayerType = a.get("type");
                this.playerPanel.Ctrl.setSeekAbility(a.get("support_seek"));
                this.playerPanel.Ctrl.setSetVolumeAbility(a.get("support_set_volume"));
                break
        }
        if (this.gCurrentSelectPlayer !== d) {
            this.playerPanel.Ctrl.clearPanel();
            this.playerPanel.setMuteBtnDisabled(false);
            if ("__SYNO_WEB_PLAYER__" === this.gCurrentSelectPlayer) {
                if (this.PollingTask) {
                    this.PollingTask.stop();
                    delete this.PollingTask
                }
                this.playingStore.on("load", this.updateWebPlayerStatus, this, {
                    single: true
                })
            } else {
                if (this.PollingTask) {
                    this.PollingTask.stop();
                    delete this.PollingTask
                }
                this.playingStore.on("load", this.startPollingTask, this, {
                    single: true
                })
            }
            this.audioPlayer.updateMuteState();
            this.playingStore.baseParams.id = this.gCurrentSelectPlayer;
            this.playingStore.removeAll();
            this.changePlayingStoreMetadata();
            this.playingStore.load();
            this._getWindow().appInstance.setUserSettings("CurrentSelectPlayer", this.gCurrentSelectPlayer)
        }
    },
    updateWebPlayerStatus: function() {
        this.audioWebPlayer.setStreamStore(this.playingStore);
        this.audioWebPlayer.updatePlaylist(this.getCurrentPlayingIndex());
        this.audioWebPlayer.updateSongInfo()
    },
    getCurrentRendererRecord: function() {
        var a = null;
        a = this.PlayerStore.getAt(this.PlayerStore.find("id", this.gCurrentSelectPlayer));
        return a
    },
    switchToStreamingMode: function() {
        this.playingStore.removeAll();
        this.playerPanel.btnDevice.updateBtnClass("stream", _AST("player", "to_my_computer"));
        this.onPlayingModeSelected("stream");
        if (this.PollingTask) {
            this.PollingTask.stop();
            delete this.PollingTask
        }
    },
    showPasswordDialog: function(b, a, c) {
        this.passwordDialog = new SYNO.SDS.AudioStation.PasswordDialog({
            owner: this._getWindow(),
            name: b.get("name"),
            UDN: b.get("id"),
            callback: c,
            autoPop: !!a
        });
        this.passwordDialog.show()
    },
    showMultiAirPlayDialog: function(c) {
        var b = this.PlayerStore.data.items,
            f = this.getCurrentRendererRecord(),
            e, g = [],
            d;
        if (!f) {
            return
        }
        e = "airplay";
        for (d = 0; d < b.length; d++) {
            if (e === b[d].json.type && c !== b[d].json.id) {
                g.push(b[d].json)
            }
        }
        var a = new Ext.data.JsonStore({
            autoDestroy: true,
            storeId: "Multiple Airplay Devices List",
            data: g,
            idProperty: "id",
            fields: ["name", "id", "password_protected"]
        });
        this.multiAirPlayDialog = new SYNO.SDS.AudioStation.MultiAirPlayDialog({
            owner: this._getWindow(),
            title: _AST("player", "select_airplay_devices"),
            udn: c,
            store: a
        });
        this.multiAirPlayDialog.show()
    },
    cancelInactiveAirplayer: function(b) {
        var a;
        for (a = 0; a < this.multiAirPlayDialog.checkboxList.length; a++) {
            if (b.params.id === this.multiAirPlayDialog.checkboxList[a].UDN) {
                this.multiAirPlayDialog.checkboxList[a].setValue(false);
                break
            }
        }
    },
    testAirPlayPassword: function(b, c) {
        var a = this.addAjaxTask({
            autoJsonDecode: true,
            single: true,
            method: "POST",
            url: this._getUtils().getWebAPIURL("remote_player.cgi"),
            params: this._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.RemotePlayer",
                method: "testpassword",
                id: c ? b.get("id") : this.gCurrentSelectPlayer
            }),
            scope: this,
            success: function(d, e) {
                if (d.success) {
                    if ("__SYNO_Multiple_AirPlay__" === this.gCurrentSelectPlayer) {
                        c.call()
                    }
                } else {
                    if (d.error && d.error.code && "AUDIO_ERR_INVALID_PASSWORD" === this._getUtils().getErrCodeMapping(d.error.code)) {
                        if ("__SYNO_Multiple_AirPlay__" === this.gCurrentSelectPlayer) {
                            this.showPasswordDialog(b, true, c)
                        } else {
                            this.showPasswordDialog(b, true)
                        }
                    } else {
                        if ("__SYNO_Multiple_AirPlay__" === this.gCurrentSelectPlayer) {
                            this.cancelInactiveAirplayer(e)
                        } else {
                            this.switchToStreamingMode()
                        }
                    }
                }
                if (this.multiAirPlayDialog) {
                    this.multiAirPlayDialog.stopSetSubVolumeFlag = false
                }
            },
            failure: function(d, e) {
                this._getWindow().getMsgBox().alert(this.title, _AST("common", "error_system"));
                if (this.multiAirPlayDialog) {
                    this.multiAirPlayDialog.stopSetSubVolumeFlag = false
                }
                if ("__SYNO_Multiple_AirPlay__" === this.gCurrentSelectPlayer) {
                    this.cancelInactiveAirplayer(e)
                }
            }
        });
        a.start()
    },
    searchLibrary: function(a) {
        var b = {};
        if ("all" !== this.gSearchCate && "title" !== this.gSearchCate) {
            b = this._getWindow().pathMgr.getMusicSearchCateParam(this.gSearchCate);
            b.filter = a
        } else {
            if ("title" == this.gSearchCate) {
                b.api = "SYNO.AudioStation.Song";
                b.method = "search";
                b.library = this._getWindow().getBrowseLibraryType();
                b.additional = "song_tag,song_audio,song_rating";
                b.text = _AST("common", "class_music_allmusic");
                b.title = a
            } else {
                b.api = "SYNO.AudioStation.Search";
                b.method = "list";
                b.library = this._getWindow().getBrowseLibraryType();
                b.additional = "song_tag,song_audio,song_rating";
                b.text = _AST("common", "search_result");
                b.limit = 10
            }
        }
        b.version = this._getUtils().webAPIVersion[b.api];
        b.keyword = a;
        this._getWindow().pathMgr.gotoSearchCate(b)
    },
    searchShoutCast: function(a) {
        var d, b = this._getWindow().pathMgr.getHistoryInfo(),
            c = this._getUtils()._ShoutCast_ID;
        if (!a) {
            return
        }
        if (this._getUtils().isInShoutCast()) {
            d = this._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.Radio",
                method: "search",
                keyword: a,
                offset: b.params.offset,
                text: _AST("common", "btn_search")
            });
            this._getWindow().getPathMgr().onSetGotoCfg(c, 1);
            this._getWindow().getPathMgr().objHistory[c][1] = Ext.apply(SYNO.Util.copy(this._getUtils().SEC_CFG[c][0]), SYNO.Util.copy({
                index: 1,
                params: SYNO.Util.copy(d || {})
            } || {}));
            SYNO.SDS.AudioStation.Window.getPathMgr().onGotoPanel(c)
        } else {
            b.params.keyword = a;
            this.loadCurrentStore()
        }
    },
    searchPlaylist: function(b) {
        var d = this._getUtils()._Playlist_ID,
            a = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.ListPanel"),
            c = this._getWindow().pathMgr.getHistoryInfo(d);
        if (this._getUtils().isInAllPlaylist()) {
            c.params.keyword = b
        } else {
            a.selectItemById(d);
            this._getWindow().pathMgr.objHistory[d][0].params.keyword = b
        }
        c.params.start = 0;
        this._getWindow().pathMgr.onSetGotoCfg(d, 0);
        this._getWindow().pathMgr.onGotoPanel(d)
    },
    showPlaylistSearchResult: function(a, b) {
        var c;
        this.playlistStore.filter("name", a, true, false);
        this.dataStore.removeAll();
        this.dataStore.totalLength = this.playlistStore.getRange().length;
        c = this.playlistStore.getRange(b.params.start, b.params.start + b.params.limit - 1);
        this.dataStore.add(c);
        this.dataStore.fireEvent("load", this.dataStore, c, b)
    },
    clearSearchResult: function(b) {
        var a = this._getWindow().pathMgr.getHistoryInfo();
        this.searchFieldMgr.resetSearch();
        if (!Ext.isDefined(a.params.keyword)) {
            return
        }
        if ("SYNO.AudioStation.Song" === a.params.api) {
            a.params = this._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.Song",
                method: "list",
                additional: "song_tag,song_audio,song_rating"
            })
        } else {
            if ("SYNO.AudioStation.Search" === a.params.api) {
                return
            } else {
                if (this._getUtils().isInShoutCastSearch()) {
                    this._getWindow().pathMgr.onGotoPanel(this._getUtils()._ShoutCast_ID, 0)
                } else {
                    a.params.filter = "";
                    delete a.params.keyword
                }
            }
        }
        this.loadCurrentStore()
    },
    getSearchCateMenu: function(a) {
        if (!this.searchCateMenu) {
            this.searchCateMenu = new SYNO.ux.Menu({
                cls: "syno-ux-check-menu",
                enableScrolling: false,
                defaults: {
                    checked: false,
                    group: "searchCate",
                    scope: this
                },
                items: [{
                    text: _AST("music", "music_search_category_all"),
                    checked: true,
                    itemId: "cate_all",
                    xtype: "menucheckitem",
                    checkHandler: this.setSearchCategory.createDelegate(this, ["all"])
                }, {
                    text: _AST("music", "header_artist"),
                    itemId: "cate_artist",
                    xtype: "menucheckitem",
                    checkHandler: this.setSearchCategory.createDelegate(this, ["artist"])
                }, {
                    text: _AST("music", "header_album"),
                    itemId: "cate_album",
                    xtype: "menucheckitem",
                    checkHandler: this.setSearchCategory.createDelegate(this, ["album"])
                }, {
                    text: _AST("music", "header_composer"),
                    itemId: "cate_composer",
                    xtype: "menucheckitem",
                    checkHandler: this.setSearchCategory.createDelegate(this, ["composer"])
                }, {
                    text: _AST("music", "header_genre"),
                    itemId: "cate_genre",
                    xtype: "menucheckitem",
                    checkHandler: this.setSearchCategory.createDelegate(this, ["genre"])
                }, {
                    text: _AST("music", "header_title"),
                    itemId: "cate_title",
                    xtype: "menucheckitem",
                    checkHandler: this.setSearchCategory.createDelegate(this, ["title"])
                }]
            });
            this.searchCateMenu.shadow = false
        }
        return this.searchCateMenu
    },
    setSearchCategory: function(a) {
        if (a === this.gSearchCate) {
            return
        }
        this.gSearchCate = a
    },
    onSettingClick: function(a) {
        if (!this.winPrivilege) {
            this.winPrivilege = new SYNO.SDS.AudioStation.SettingDialog({
                owner: this._getWindow()
            }, this._getWindow())
        }
        this.winPrivilege.activeTab = a ? a : 0;
        this.winPrivilege.open()
    },
    onModeItemClick: function(b, c) {
        var d = b.itemId,
            a = this._getWindow().pathMgr.getHistoryInfo().layoutCfg;
        if ("switchListMode" === d) {
            this._getWindow().appInstance.setUserSettings("ActivedViewPanel", "switchListMode");
            this.mainCardPanel.getLayout().setActiveItem("browse");
            this.cardPanel.getLayout().setActiveItem(a);
            this.toggleAction(this.listViewAction, true)
        } else {
            if ("switchThumbMode" === d) {
                this._getWindow().appInstance.setUserSettings("ActivedViewPanel", "switchThumbMode");
                this.mainCardPanel.getLayout().setActiveItem("browse");
                if (this._getUtils().isInSearchAllCate() || this._getUtils().isAtHomepage() || this._getUtils().isAtPinList()) {
                    this.cardPanel.getLayout().setActiveItem(a)
                } else {
                    this.cardPanel.getLayout().setActiveItem("thumbViewPanel")
                }
                this.toggleAction(this.thumbViewAction, true)
            }
        }
    },
    createPlayingStore: function(b) {
        var a = new Ext.data.Store({
            paramNames: {
                start: "offset",
                limit: "limit",
                sort: "sort_by",
                dir: "sort_direction"
            },
            method: "POST",
            baseParams: this._getUtils().getWebAPIParams({
                api: this._getUtils().getPlayerAPI(),
                method: "getplaylist",
                id: this.gCurrentSelectPlayer,
                additional: "song_tag,song_audio,song_rating",
                offset: 0,
                limit: SYNO.SDS.AudioStation.Define.MAX_SONG_LIMIT
            }),
            remoteSort: true,
            proxy: new Ext.data.HttpProxy({
                url: this._getUtils().getPlayerCGI(),
                listeners: {
                    scope: this,
                    beforeload: function(c, d) {
                        var e = c.activeRequest.read;
                        if (e) {
                            Ext.Ajax.abort(e);
                            SYNO.SDS.AudioStation.Window.clearStatusBusy()
                        }
                    }
                }
            }),
            reader: new Ext.data.JsonReader({
                id: "itemId",
                root: "data.songs",
                totalProperty: "data.total",
                fields: SYNO.SDS.AudioStation.Window.gFields
            }),
            listeners: {
                scope: this,
                beforeload: function() {
                    this.cardPanel.listViewGrid.showEmptyMsg(false);
                    SYNO.SDS.AudioStation.Window.setStatusBusy()
                },
                load: this.onAfterLoadPlayingStore.createDelegate(this, [b], true),
                exception: function() {
                    SYNO.SDS.AudioStation.Window.clearStatusBusy()
                }
            }
        });
        return a
    },
    onAfterLoadPlayingStore: function(b, a, c, e) {
        var d = this.getPlayingPanel();
        this._getUtils().isPlayingStoreLoading = false;
        if (this._getUtils().isStreamStoreCopy) {
            this._getUtils().isStreamStoreCopy = false
        }
        if (b && 0 === b.getCount()) {
            if (d) {
                d.showEmptyMsg(true, _AST("common", "warning_playing_queue_no_music"))
            }
            this.playerPanel.btnMini.disable()
        } else {
            if (d) {
                d.showEmptyMsg(false)
            }
            this.playerPanel.btnMini.enable()
        }
        SYNO.SDS.AudioStation.Window.clearStatusBusy();
        if ("__SYNO_WEB_PLAYER__" === this.gCurrentSelectPlayer) {
            if (this.audioWebPlayer.getKeepShuffleOrder()) {
                this.audioWebPlayer.addToNext();
                this.audioWebPlayer.setKeepShuffleOrder(false)
            }
            this.audioWebPlayer.updatePreload()
        }
        if (e) {
            e.call()
        }
    },
    createSearchAllStore: function() {
        var a = new Ext.data.Store({
            paramNames: {
                start: "offset",
                limit: "limit",
                sort: "sort_by",
                dir: "sort_direction"
            },
            sortInfo: {
                field: "title",
                direction: "ASC"
            },
            remoteSort: true,
            method: "POST",
            baseParams: {},
            proxy: new Ext.data.HttpProxy({
                url: this._getUtils().getWebAPIURL("search.cgi"),
                listeners: {
                    scope: this,
                    beforeload: function(b, c) {
                        var d = b.activeRequest.read;
                        if (d) {
                            Ext.Ajax.abort(d);
                            SYNO.SDS.AudioStation.Window.clearStatusBusy()
                        }
                    }
                }
            }),
            reader: new Ext.data.JsonReader({
                id: "itemId",
                root: "data",
                fields: SYNO.SDS.AudioStation.Window.gFields
            }),
            listeners: {
                scope: this,
                beforeload: this.onBeforeLoadStore,
                load: this.onAfterLoadStore,
                exception: this.onExceptionLoadStore
            }
        });
        return a
    },
    createSearchAllArtistStore: function() {
        var a = new Ext.data.Store({
            sortInfo: {
                field: "title",
                direction: "ASC"
            },
            proxy: new Ext.data.MemoryProxy(),
            reader: new Ext.data.JsonReader({
                id: "itemId",
                root: "data.artists",
                totalProperty: "data.artistTotal",
                fields: SYNO.SDS.AudioStation.Window.gFields
            }),
            storeType: "artist"
        });
        return a
    },
    createSearchAllAlbumStore: function() {
        var a = new Ext.data.Store({
            sortInfo: {
                field: "title",
                direction: "ASC"
            },
            proxy: new Ext.data.MemoryProxy(),
            reader: new Ext.data.JsonReader({
                id: "itemId",
                root: "data.albums",
                totalProperty: "data.albumTotal",
                fields: SYNO.SDS.AudioStation.Window.gFields
            }),
            storeType: "album"
        });
        return a
    },
    createSearchAllSongStore: function() {
        var a = new Ext.data.Store({
            sortInfo: {
                field: "title",
                direction: "ASC"
            },
            proxy: new Ext.data.MemoryProxy(),
            reader: new Ext.data.JsonReader({
                id: "itemId",
                root: "data.songs",
                totalProperty: "data.songTotal",
                fields: SYNO.SDS.AudioStation.Window.gFields
            }),
            storeType: "song"
        });
        return a
    },
    createDataStore: function() {
        var a = new Ext.data.Store({
            paramNames: {
                start: "offset",
                limit: "limit",
                sort: "sort_by",
                dir: "sort_direction"
            },
            sortInfo: {
                field: "title",
                direction: "ASC"
            },
            remoteSort: true,
            method: "POST",
            baseParams: {},
            proxy: new Ext.data.HttpProxy({
                url: this._getUtils().getWebAPIURL("song.cgi"),
                listeners: {
                    scope: this,
                    beforeload: function(b, c) {
                        var d = b.activeRequest.read;
                        if (d) {
                            Ext.Ajax.abort(d);
                            SYNO.SDS.AudioStation.Window.clearStatusBusy()
                        }
                    },
                    load: this.onDataProxyLoad
                }
            }),
            reader: new Ext.data.JsonReader({
                id: "itemId",
                root: "items",
                totalProperty: "total",
                fields: SYNO.SDS.AudioStation.Window.gFields
            }),
            listeners: {
                scope: this,
                beforeload: this.onBeforeLoadStore,
                load: this.onAfterLoadStore,
                exception: this.onExceptionLoadStore
            }
        });
        return a
    },
    createPinStore: function() {
        var a = new SYNO.API.JsonStore({
            api: "SYNO.AudioStation.Pin",
            method: "list",
            version: 1,
            appWindow: SYNO.SDS.AudioStation.Window,
            autoLoad: false,
            baseParams: {
                offset: 0,
                limit: -1
            },
            root: "items",
            totalProperty: "total",
            fields: SYNO.SDS.AudioStation.Window.gFields,
            listeners: {
                exception: this.onExceptionLoadStore,
                load: this.onAfterLoadPinStore,
                scope: this
            }
        });
        return a
    },
    onAfterLoadPinStore: function(c, b, d) {
        var e = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.ListPanel"),
            a = SYNO.SDS.AudioStation.Utils;
        Ext.each(b, function(f) {
            if ("playlist" !== f.get("type") || !f.get("criteria").playlist) {
                return true
            }
            var g = f.get("criteria").playlist;
            if (-1 !== this.defaultPinItems.indexOf(g)) {
                return true
            }
            if (e.getNodeById(g)) {
                return true
            }
            e.getRootNode().insertBefore({
                text: f.get("name"),
                iconCls: "syno-as-list-allplaylist",
                fn: g
            }, e.getNodeById(a._Radio_ID));
            a.SEC_LIST.push(g);
            a.SEC_CFG[g] = [{
                type: a._Playlist_ID,
                text: f.get("name"),
                layoutCfg: "listViewPanel",
                params: a.getWebAPIParams({
                    api: "SYNO.AudioStation.Playlist",
                    method: "getinfo"
                }),
                container_type: "playlist"
            }];
            if (g === this._getWindow().getPathMgr().getCurId()) {
                e.selectItemById(g)
            } else {
                this._getWindow().getPathMgr().clearHistory(g);
                this._getWindow().getPathMgr().pushHistory(g, {
                    index: 0
                }, 0)
            }
        }, this);
        e.doLayout()
    },
    onBeforeLoadStore: function(a, b) {
        var c = this._getWindow().pathMgr.getHistoryInfo();
        if ((this._getUtils().isInAllPlaylist() || this._getUtils().isInPlaylistLayer2()) && (Ext.isDefined(c.params.keyword) && "" !== c.params.keyword)) {
            b.params.keyword = c.params.keyword;
            this.showPlaylistSearchResult(b.params.keyword, b);
            return false
        }
        if (c.params.keyword && "" !== c.params.keyword) {
            this.cardPanel.listViewGrid.getView().emptyText = _AST("common", "searching");
            this._getWindow().getPanelScope("SYNO.SDS.AudioStation.ThumbView").dataView.emptyText = '<div style="padding:10px;color:gray;">' + _AST("common", "searching") + "</div>"
        } else {
            this.cardPanel.listViewGrid.getView().emptyText = "";
            this._getWindow().getPanelScope("SYNO.SDS.AudioStation.ThumbView").dataView.emptyText = ""
        }
        this.cardPanel.listViewGrid.showEmptyMsg(false);
        SYNO.SDS.AudioStation.Window.setStatusBusy();
        if (!this._getUtils().isInPlaylistLayer2()) {
            this.dataStore.removeAll()
        }
        this.changeMetadata()
    },
    onDataProxyLoad: function(c, e, b) {
        var d = this._getWindow().pathMgr.getHistoryInfo();
        if (d.params.keyword && "" !== d.params.keyword) {
            this.cardPanel.listViewGrid.getView().emptyText = _AST("common", "no_search_result");
            this._getWindow().getPanelScope("SYNO.SDS.AudioStation.ThumbView").dataView.emptyText = '<div style="padding:10px;color:gray;">' + _AST("common", "no_search_result") + "</div>"
        } else {
            if (this._getUtils().isInRating()) {
                this.cardPanel.listViewGrid.getView().emptyText = _AST("common", "no_rating_music_remind");
                this._getWindow().getPanelScope("SYNO.SDS.AudioStation.ThumbView").dataView.emptyText = '<div style="padding:10px;color:gray;">' + _AST("common", "no_rating_music_remind") + "</div>"
            } else {
                if (this._getUtils().isInHomepage()) {
                    var a = _AST("common", "no_music_remind");
                    if (d.params.genre_filter) {
                        a = _AST("common", "empty_default_genre")
                    } else {
                        if ("SYNO.AudioStation.Playlist" === d.params.api) {
                            a = _AST("sharing", "empty_msg")
                        }
                    }
                    this.cardPanel.listViewGrid.getView().emptyText = a;
                    this._getWindow().getPanelScope("SYNO.SDS.AudioStation.ThumbView").dataView.emptyText = '<div style="padding:10px;color:gray;">' + a + "</div>"
                } else {
                    if (this._getUtils().isInLibrary()) {
                        this.cardPanel.listViewGrid.getView().emptyText = _AST("common", "no_music_remind");
                        this._getWindow().getPanelScope("SYNO.SDS.AudioStation.ThumbView").dataView.emptyText = '<div style="padding:10px;color:gray;">' + _AST("common", "no_music_remind") + "</div>"
                    } else {
                        if (this._getUtils().isInPlaylistLayer2()) {
                            this.cardPanel.listViewGrid.getView().emptyText = _AST("sharing", "empty_msg");
                            this._getWindow().getPanelScope("SYNO.SDS.AudioStation.ThumbView").dataView.emptyText = '<div style="padding:10px;color:gray;">' + _AST("sharing", "empty_msg") + "</div>"
                        }
                    }
                }
            }
        }
    },
    onAfterLoadStore: function(c, b, d) {
        var h = (d) ? d.params : c.lastOptions.params,
            f = this._getWindow().pathMgr.getHistoryInfo(),
            e = this.cardPanel.listViewGrid;
        Ext.apply(f.params, (h) ? {
            offset: h.offset || 0,
            limit: h.limit
        } : {});
        if (this._getUtils().isInRandom100() || this._getUtils().isInLatestAlbum()) {
            this.setPagetoolBarVisible(false)
        } else {
            if (c.getTotalCount() > this._getWindow().gridPagingSize) {
                this.setPagetoolBarVisible(true)
            } else {
                this.setPagetoolBarVisible(false)
            }
        }
        if (b.length > 0 && (this._getUtils().isInCateAlbumLayer() || this._getUtils().isInGenreArtistList())) {
            var a;
            if (undefined !== f.params.artist) {
                a = {
                    id: "AllMusic",
                    name: "",
                    artist: f.params.artist,
                    title: "",
                    album: "",
                    album_artist: "",
                    composer: null,
                    genre: null,
                    duration: "",
                    year: "",
                    disc: "",
                    track: "",
                    path: ""
                }
            } else {
                if (undefined !== f.params.composer) {
                    a = {
                        id: "AllMusic",
                        name: "",
                        artist: null,
                        title: "",
                        album: "",
                        album_artist: "",
                        composer: f.params.composer,
                        genre: null,
                        duration: "",
                        year: "",
                        disc: "",
                        track: "",
                        path: ""
                    }
                } else {
                    a = {
                        id: "AllMusic",
                        name: "",
                        artist: null,
                        title: "",
                        album: "",
                        album_artist: "",
                        composer: null,
                        genre: f.params.genre,
                        duration: "",
                        year: "",
                        disc: "",
                        track: "",
                        path: ""
                    }
                }
            }
            var g = new c.recordType(a, a.id);
            c.insert(0, g)
        }
        if (this._getUtils().isInAlbum()) {
            e.showAlbumView(b)
        }
        if (this._getUtils().isInSearchAllCate()) {
            this.dispatchSearchAllResult(c)
        }
        if (0 === f.index && this._getUtils().isInLibraryFolder() || this._getUtils().isInAllPlaylist()) {
            this.replaceTitle(c)
        }
        if (Ext.isDefined(f.focusIdx)) {
            (function() {
                this.focusLastSelectedItem(f.focusIdx)
            }.createDelegate(this)).defer(150)
        }
        SYNO.SDS.AudioStation.Window.clearStatusBusy()
    },
    replaceTitle: function(a) {
        a.findBy(function(e, f) {
            var b = ("dir_p_" === e.get("id").substr(0, 6)) ? true : false,
                c = e.get("path"),
                d = e.get("title");
            if (b && "/homes" === c.substr(0, 6) && "music" === d && 4 === c.split("/").length) {
                d += " (home)";
                e.set("title", d);
                e.commit()
            }
            if ("__SYNO_AUDIO_SHARED_SONGS__" == e.get("name")) {
                e.set("name", _AST("playlist", "shared_songs_playlist"));
                e.commit()
            }
        }, this)
    },
    focusLastSelectedItem: function(a) {
        var b = this.cardPanel.layout.activeItem;
        if (this.gIsOnMiniPlayerMode || this.gIsOnLargePlayingQueue) {
            return
        }
        if ("listViewPanel" === b.itemId) {
            this.cardPanel.listViewGrid.focusItem(a)
        } else {
            if ("thumbViewPanel" === b.itemId) {
                this._getWindow().getPanelScope("SYNO.SDS.AudioStation.ThumbView").dataView.focusNode(a)
            }
        }
    },
    onExceptionLoadStore: function(e, f, b, i, c) {
        var a = this._getWindow().pathMgr.getHistoryInfo();
        var g = _AST("common", "error_system");
        var d = false;
        if ("SYNO.AudioStation.Playlist" === i.params.api) {
            if (0 === a.index || this._getUtils().isInHomepage()) {
                g = _AST("common", "invalid_pin")
            }
        } else {
            if ("SYNO.AudioStation.Folder" === i.params.api) {
                var h = this._getWindow().pathMgr.getPrevHistoryInfo();
                if (null !== h && "SYNO.AudioStation.Pin" === h.params.api) {
                    g = _AST("common", "invalid_pin")
                } else {
                    g = String.format(_AST("common", "error_dose_not_exist"), _AST("common", "type_folder")) + " " + _AST("common", "error_dsm_may_be_reindexing");
                    d = true
                }
            }
        }
        this._getWindow().getMsgBox().alert(_AST("common", "class_audio_station"), this._getUtils().getErrMsgStringFromResponse(c, g));
        if (d) {
            SYNO.SDS.AudioStation.Window.getPathMgr().onGotoPanel("by_folder", 0)
        }
        SYNO.SDS.AudioStation.Window.clearStatusBusy()
    },
    updateMainToolbar: function() {
        var b = SYNO.SDS.AudioStation.Window.getActiveViewMode(),
            a = null;
        this.listViewAction.enable();
        this.thumbViewAction.enable();
        if (this._getUtils().isAtHomepage() || this._getUtils().isAtPinList() || this._getUtils().isInSearchAllCate()) {
            this.listViewAction.disable();
            this.toggleAction(this.thumbViewAction, true)
        } else {
            if (this._getUtils().isInAlbum() || this._getUtils()._PlayingQueue_ID === this._getWindow().pathMgr.curID) {
                this.thumbViewAction.disable();
                this.toggleAction(this.listViewAction, true)
            } else {
                a = this.getModeAction(b);
                this.thumbViewAction.enable();
                if (!a) {
                    this.toggleAction(this.listViewAction, true)
                } else {
                    this.toggleAction(a, true)
                }
            }
        }
        if (this.isDisableAction()) {
            this.actionAction.disable()
        } else {
            this.actionAction.enable()
        }
        if (this._getUtils().isInAllMusic()) {
            this.ratingFilterBtn.show();
            this.cardPanel.resizePathbar.call(this.cardPanel)
        } else {
            this.ratingFilterBtn.hide();
            this.cardPanel.resizePathbar.call(this.cardPanel)
        }
    },
    setPagetoolBarVisible: function(c) {
        var a = this.cardPanel.listViewGrid,
            b = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.ThumbView");
        a.setPagingToolbarVisible(c);
        b.setPagetoolBarVisible(c)
    },
    isDisableAction: function() {
        if (this.gIsOnLargePlayingQueue && this.largePlayingQueuePanel.isInLyricsMode()) {
            return true
        }
        if (!this.gIsOnLargePlayingQueue && !this.gIsOnMiniPlayerMode && (this._getUtils().isMediaServerRoot() || this._getUtils().isInShoutCastCate())) {
            return true
        }
        return false
    },
    loadPinStore: function() {
        this.pinStore.removeAll();
        this.pinStore.load()
    },
    loadCurrentStore: function() {
        var b = this._getWindow().pathMgr.getHistoryInfo();
        this.cardPanel.listViewGrid.getView().emptyText = "";
        this._getWindow().getPanelScope("SYNO.SDS.AudioStation.ThumbView").dataView.emptyText = "";
        if (this._getUtils()._PlayingQueue_ID === this._getWindow().pathMgr.curID) {
            this.playingStore.load()
        } else {
            this.dataStore.removeAll();
            this.changeMetadata();
            this.dataStore.baseParams = SYNO.Util.copy(b.params);
            if (b.params.sort_by) {
                delete this.dataStore.sortInfo
            }
            var a = this._getUtils().isInAlbum() ? 100000 : this._getWindow().gridPagingSize;
            var c = {
                limit: a
            };
            if (this._getUtils().isInAllMusic() && 0 < this.checkedRatingFilter.length) {
                c.rating_filter = this.checkedRatingFilter.join(",")
            }
            this.dataStore.load({
                params: Ext.apply(c, b.params || {})
            })
        }
    },
    loadSearchAllStore: function() {
        var a = this._getWindow().pathMgr.getHistoryInfo();
        this.setSearchAllViewEmptyText(_AST("common", "searching"));
        this.searchAllStore.removeAll();
        this.searchAllArtistStore.removeAll();
        this.searchAllAlbumStore.removeAll();
        this.searchAllSongStore.removeAll();
        this.searchAllStore.reader.meta.root = "data.artists";
        this.searchAllStore.reader.meta.totalProperty = "data.artistTotal";
        this.searchAllStore.sortInfo.field = "title";
        delete this.searchAllStore.reader.ef;
        this.searchAllStore.reader.buildExtractors();
        this.searchAllStore.load({
            params: Ext.apply({
                limit: this._getWindow().gridPagingSize
            }, a.params || {})
        })
    },
    dispatchSearchAllResult: function(a) {
        this.setSearchAllViewEmptyText(_AST("common", "no_search_result"));
        this.searchAllArtistStore.loadData(a.reader.jsonData);
        this.searchAllAlbumStore.loadData(a.reader.jsonData);
        this.searchAllSongStore.loadData(a.reader.jsonData)
    },
    setSearchAllViewEmptyText: function(a) {
        this._getWindow().getPanelScope("SYNO.SDS.AudioStation.SearchAllView").artistDataView.emptyText = '<div style="padding:10px;color:gray;">' + a + "</div>";
        this._getWindow().getPanelScope("SYNO.SDS.AudioStation.SearchAllView").albumDataView.emptyText = '<div style="padding:10px;color:gray;">' + a + "</div>";
        this._getWindow().getPanelScope("SYNO.SDS.AudioStation.SearchAllView").songListView.getView().emptyText = a
    },
    createMetadataMapping: function() {
        var a = {
            "SYNO.AudioStation.Song": {
                root: "data.songs",
                url: this._getUtils().getWebAPIURL("song.cgi"),
                field: "title"
            },
            "SYNO.AudioStation.Folder": {
                root: "data.items",
                url: this._getUtils().getWebAPIURL("folder.cgi"),
                field: "title"
            },
            "SYNO.AudioStation.Album": {
                root: "data.albums",
                url: this._getUtils().getWebAPIURL("album.cgi"),
                field: "name"
            },
            "SYNO.AudioStation.Artist": {
                root: "data.artists",
                url: this._getUtils().getWebAPIURL("artist.cgi"),
                field: "name"
            },
            "SYNO.AudioStation.Composer": {
                root: "data.composers",
                url: this._getUtils().getWebAPIURL("composer.cgi"),
                field: "name"
            },
            "SYNO.AudioStation.Genre": {
                root: "data.genres",
                url: this._getUtils().getWebAPIURL("genre.cgi"),
                field: "name"
            },
            "SYNO.AudioStation.Playlist": {
                root: "data.playlists",
                url: this._getUtils().getWebAPIURL("playlist.cgi")
            },
            "SYNO.AudioStation.Radio": {
                root: "data.radios",
                url: this._getUtils().getWebAPIURL("radio.cgi")
            },
            "SYNO.AudioStation.MediaServer": {
                root: "data.list",
                url: this._getUtils().getWebAPIURL("media_server.cgi")
            },
            "SYNO.AudioStation.Search": {
                root: "data",
                url: this._getUtils().getWebAPIURL("search.cgi"),
                field: "title"
            }
        };
        return a
    },
    changePlayingStoreMetadata: function() {
        this.playingStore.proxy.setUrl(this._getUtils().getPlayerCGI(), true);
        this.playingStore.baseParams.api = this._getUtils().getPlayerAPI();
        this.playingStore.baseParams.version = this._getUtils().webAPIVersion[this._getUtils().getPlayerAPI()];
        delete this.playingStore.reader.ef;
        this.playingStore.reader.buildExtractors()
    },
    changeMetadata: function() {
        var a = this._getWindow().pathMgr.getHistoryInfo();
        if ((this._getUtils()._Playlist_ID === a.type && "getinfo" === a.params.method) || this._getUtils().isInHomepagePlaylist()) {
            this.dataStore.proxy.setUrl(this._getUtils().getWebAPIURL("playlist.cgi"));
            this.dataStore.reader.meta.root = "data.playlists[0].additional.songs";
            this.dataStore.reader.meta.totalProperty = "data.playlists[0].additional.songs_total"
        } else {
            this.dataStore.proxy.setUrl(this.metadataMapping[a.params.api].url);
            this.dataStore.reader.meta.root = this.metadataMapping[a.params.api].root;
            this.dataStore.reader.meta.totalProperty = "data.total";
            if (this.dataStore.sortInfo && !this._getUtils().isDisableSortPage() && ("title" === this.dataStore.sortInfo.field || "name" === this.dataStore.sortInfo.field)) {
                this.dataStore.sortInfo.field = this.metadataMapping[a.params.api].field
            }
        }
        delete this.dataStore.reader.ef;
        this.dataStore.reader.buildExtractors()
    },
    addQueue: function(b) {
        var f, e = [],
            c, d, a = this._getUtils().getSortInfo("MusicColumnSetting", b),
            g = this._getWindow().pathMgr.getHistoryInfo();
        this.gPlaySelectID = true;
        if (this._getUtils().isInRandom100()) {
            f = this._getUtils().getSongIdList(this.dataStore.getRange());
            this.onPlayingQueueCommit("updateplaylist", true, f, null, 0, this.playingStore.getTotalCount())
        } else {
            if (this._getUtils().isInLibraryFolder()) {
                e.push(this._getUtils().getFolderJsonObj(this.dataStore.reader.jsonData.data.id, false, a.field, a.direction));
                this.firstSongIdx = this.dataStore.reader.jsonData.data.folder_total;
                this.onPlayingQueueCommit("updateplaylist", true, null, e, 0, this.playingStore.getTotalCount())
            } else {
                if (this._getUtils().isInPlaylistLayer2() || this._getUtils().isInHomepagePlaylist()) {
                    e.push(this._getUtils().getPlaylistJsonObj(g.params.id));
                    this.onPlayingQueueCommit("updateplaylist", true, null, e, 0, this.playingStore.getTotalCount())
                } else {
                    if (this._getUtils().isInAlbum()) {
                        e.push(this._getUtils().getAlbumJsonObj(g.params.album, g.params.album_artist, g.params.artist, g.params.composer, g.params.genre, g.params.genre_filter, a.field, a.direction));
                        this.onPlayingQueueCommit("updateplaylist", true, null, e, 0, this.playingStore.getTotalCount())
                    } else {
                        if (this._getUtils().isInRating()) {
                            e.push(this._getUtils().getRatingJsonObj(g.params.song_rating_meq, g.params.song_rating_leq, a.field, a.direction));
                            this.onPlayingQueueCommit("updateplaylist", true, null, e, 0, this.playingStore.getTotalCount())
                        } else {
                            if (this._getUtils().isInCateAllMusic()) {
                                if (this._getUtils().isInSearchAllDetail()) {
                                    f = this._getUtils().getSongIdList([b]);
                                    this.gPlaySelectID = false;
                                    this.onPlayingQueueCommit("updateplaylist", true, f, null, -1, 0)
                                } else {
                                    c = (undefined !== g.params.artist) ? "artist" : ((undefined !== g.params.composer) ? "composer" : "genre");
                                    d = g.params[c];
                                    e.push(this._getUtils().getInfoJsonObj(c, d, g.params.genre, g.params.genre_filter, a.field, a.direction));
                                    this.onPlayingQueueCommit("updateplaylist", true, null, e, 0, this.playingStore.getTotalCount())
                                }
                            } else {
                                if (this._getUtils().isInLibrarySearch()) {
                                    e.push(this._getUtils().getSearchJsonObj(this.gSearchCate, g.params.keyword, a.field, a.direction));
                                    this.onPlayingQueueCommit("updateplaylist", true, null, e, 0, this.playingStore.getTotalCount())
                                } else {
                                    f = this._getUtils().getSongIdList([b]);
                                    this.gPlaySelectID = false;
                                    this.onPlayingQueueCommit("updateplaylist", true, f, null, -1, 0)
                                }
                            }
                        }
                    }
                }
            }
        }
    },
    gotoNext: function(f, b) {
        var c = this._getWindow().pathMgr.getHistoryInfo(),
            e, a = 0;
        var d = {};
        var g;
        d = this.prepareGotoNextParam(f, b);
        if (this._getUtils()._Homepage_ID === c.type || this._getUtils()._SearchResults_ID === c.type) {
            a = 1
        }
        e = this.findText(f, c);
        g = this.findContainerType(f, c);
        this._getWindow().getPathMgr().onGotoNext(e, d, a, g)
    },
    findText: function(b, a) {
        if ("AllMusic" === b.get("id")) {
            if ("SYNO.AudioStation.Artist" === a.params.api) {
                return _AST("common", "class_music_allalbum")
            } else {
                return _AST("common", "class_music_allmusic")
            }
        } else {
            if ("SYNO.AudioStation.Artist" === a.params.api && "" === b.get("name")) {
                return _AST("common", "unknown_music_artist")
            } else {
                if ("SYNO.AudioStation.Composer" === a.params.api && "" === b.get("name")) {
                    return _AST("common", "unknown_music_composer")
                } else {
                    if ("SYNO.AudioStation.Genre" === a.params.api && "" === b.get("name")) {
                        return _AST("common", "unknown_music_genre")
                    } else {
                        return b.get("title") || b.get("name")
                    }
                }
            }
        }
    },
    findContainerType: function(b, a) {
        if (this._getUtils().isDefaultGenreRecord(b)) {
            return "default_genre"
        } else {
            if (this._getUtils().isAtHomepage() || this._getUtils().isAtPinList()) {
                return b.get("type")
            } else {
                if (this._getUtils().isInRadio()) {
                    return "radio"
                } else {
                    if (this._getUtils().isInMediaserver()) {
                        return "media_server"
                    } else {
                        if (this._getUtils().isInAllPlaylist()) {
                            return "playlist"
                        } else {
                            if (this._getUtils().isInSearchAllCate()) {
                                return b.store.storeType
                            } else {
                                switch (a.params.api) {
                                    case "SYNO.AudioStation.Album":
                                        return "album";
                                    case "SYNO.AudioStation.Folder":
                                        return "folder";
                                    case "SYNO.AudioStation.Artist":
                                        return "artist";
                                    case "SYNO.AudioStation.Composer":
                                        return "composer";
                                    case "SYNO.AudioStation.Genre":
                                        return "genre"
                                }
                            }
                        }
                    }
                }
            }
        }
        return ""
    },
    createParamsMapping: function() {
        var a = {
            all_music: {
                api: "SYNO.AudioStation.Song",
                additional: "song_tag,song_audio,song_rating"
            },
            by_folder: {
                api: "SYNO.AudioStation.Folder",
                additional: "song_tag,song_audio,song_rating"
            },
            by_album: {
                api: "SYNO.AudioStation.Album",
                additional: "avg_rating"
            },
            by_artist: {
                api: "SYNO.AudioStation.Artist",
                additional: "avg_rating"
            },
            by_composer: {
                api: "SYNO.AudioStation.Composer",
                additional: "avg_rating"
            },
            by_genre: {
                api: "SYNO.AudioStation.Genre",
                additional: "avg_rating"
            },
            random_100: {
                api: "SYNO.AudioStation.Song",
                additional: "song_tag,song_audio,song_rating",
                sort_by: "random",
                limit: 100
            },
            recently_added: {
                api: "SYNO.AudioStation.Album",
                sort_by: "time",
                sort_direction: "desc",
                additional: "avg_rating",
                limit: 50
            }
        };
        return a
    },
    getSongRatingRange: function(b, a) {
        if (null === a) {
            return
        }
        a.song_rating_meq = 0;
        a.song_rating_leq = 5;
        if (_AST("common", "no_rating") === b) {
            a.song_rating_meq = 0;
            a.song_rating_leq = 0
        } else {
            if (_AST("common", "equal_more_than_one_star") === b) {
                a.song_rating_meq = 1;
                a.song_rating_leq = 5
            } else {
                if (_AST("common", "equal_more_than_two_star") === b) {
                    a.song_rating_meq = 2;
                    a.song_rating_leq = 5
                } else {
                    if (_AST("common", "equal_more_than_three_star") === b) {
                        a.song_rating_meq = 3;
                        a.song_rating_leq = 5
                    } else {
                        if (_AST("common", "equal_more_than_four_star") === b) {
                            a.song_rating_meq = 4;
                            a.song_rating_leq = 5
                        } else {
                            if (_AST("common", "five_star") === b) {
                                a.song_rating_meq = 5;
                                a.song_rating_leq = 5
                            }
                        }
                    }
                }
            }
        }
    },
    prepareGotoNextParam: function(g, b) {
        var e = this._getWindow().pathMgr.getHistoryInfo(),
            f = {};
        var h = this._getUtils().isDefaultGenreRecord(g);
        if (this._getUtils()._Library_ID === e.type || this._getUtils()._SearchResults_ID === e.type) {
            if ("folder" === g.get("type")) {
                f = {
                    api: "SYNO.AudioStation.Folder",
                    id: g.get("id"),
                    additional: "song_tag,song_audio,song_rating"
                }
            } else {
                if (undefined !== this.paramsMapping[g.get("id")]) {
                    f = this.paramsMapping[g.get("id")]
                } else {
                    if (0 === e.index) {
                        if ("SYNO.AudioStation.Album" === e.params.api) {
                            f = {
                                api: "SYNO.AudioStation.Song",
                                album: g.get("name"),
                                album_artist: g.get("album_artist"),
                                additional: "song_tag,song_audio,song_rating"
                            }
                        } else {
                            if ("SYNO.AudioStation.Artist" === e.params.api) {
                                f = {
                                    api: "SYNO.AudioStation.Album",
                                    artist: g.get("name"),
                                    additional: "avg_rating"
                                }
                            } else {
                                if ("SYNO.AudioStation.Composer" === e.params.api) {
                                    f = {
                                        api: "SYNO.AudioStation.Album",
                                        composer: g.get("name"),
                                        additional: "avg_rating"
                                    }
                                } else {
                                    if ("SYNO.AudioStation.Genre" === e.params.api) {
                                        f = {
                                            api: "SYNO.AudioStation.Artist",
                                            genre: g.get("name"),
                                            additional: "avg_rating"
                                        }
                                    } else {
                                        if (_AST("common", "class_music_rating") === e.text) {
                                            var d = {};
                                            this.getSongRatingRange(g.get("title"), d);
                                            f = {
                                                api: "SYNO.AudioStation.Song",
                                                song_rating_meq: d.song_rating_meq,
                                                song_rating_leq: d.song_rating_leq,
                                                additional: "song_tag,song_audio,song_rating"
                                            }
                                        } else {
                                            if ("SYNO.AudioStation.Search" === e.params.api) {
                                                if ("artist" === b) {
                                                    f = {
                                                        api: "SYNO.AudioStation.Album",
                                                        artist: g.get("name"),
                                                        additional: "avg_rating"
                                                    }
                                                } else {
                                                    if ("album" === b) {
                                                        f = {
                                                            api: "SYNO.AudioStation.Song",
                                                            album: g.get("name"),
                                                            album_artist: g.get("album_artist"),
                                                            additional: "song_tag,song_audio,song_rating"
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        if ("SYNO.AudioStation.Album" === e.params.api) {
                            f = {
                                api: "SYNO.AudioStation.Song",
                                additional: "song_tag,song_audio,song_rating"
                            };
                            if (undefined !== e.params.artist) {
                                f.artist = e.params.artist
                            }
                            if (undefined !== e.params.composer) {
                                f.composer = e.params.composer
                            }
                            if (undefined !== e.params.genre) {
                                f.genre = e.params.genre
                            }
                            if (0 !== e.focusIdx || (undefined === e.params.artist && undefined === e.params.composer && undefined === e.params.genre)) {
                                f.album = g.get("name");
                                f.album_artist = g.get("album_artist")
                            }
                        } else {
                            if ("SYNO.AudioStation.Artist" === e.params.api) {
                                f = {
                                    api: "SYNO.AudioStation.Album",
                                    additional: "avg_rating"
                                };
                                if ("AllMusic" !== g.get("id")) {
                                    f.artist = g.get("name")
                                }
                                if (undefined !== e.params.genre) {
                                    f.genre = e.params.genre
                                }
                            }
                        }
                    }
                }
            }
        } else {
            if (this._getUtils()._Playlist_ID === e.type) {
                if (this._getUtils()._Playlist_ID === g.get("id")) {
                    f = {
                        api: "SYNO.AudioStation.Playlist",
                        method: "list"
                    }
                } else {
                    f = {
                        api: "SYNO.AudioStation.Playlist",
                        method: "getinfo",
                        id: g.get("id"),
                        additional: "songs_song_tag,songs_song_audio,songs_song_rating,sharing_info"
                    }
                }
            } else {
                if (this._getUtils()._Radio_ID === e.type) {
                    f.api = "SYNO.AudioStation.Radio";
                    if ("container" === g.get("type")) {
                        f.container = g.get("id")
                    }
                } else {
                    if (this._getUtils()._MediaServer_ID === e.type) {
                        f = {
                            api: "SYNO.AudioStation.MediaServer",
                            additional: "song_tag,song_audio"
                        };
                        if ("folder" === g.get("type")) {
                            f.id = g.get("id")
                        }
                    } else {
                        if (this._getUtils().isInHomepage() && "SYNO.AudioStation.Pin" !== e.params.api) {
                            if ("folder" === g.get("type")) {
                                f = {
                                    api: "SYNO.AudioStation.Folder",
                                    id: g.get("id"),
                                    additional: "song_tag,song_audio,song_rating"
                                }
                            } else {
                                if ("SYNO.AudioStation.Album" === e.params.api) {
                                    f = {
                                        api: "SYNO.AudioStation.Song",
                                        additional: "song_tag,song_audio,song_rating"
                                    };
                                    if ("AllMusic" !== g.get("id")) {
                                        f.album = g.get("name");
                                        f.album_artist = g.get("album_artist")
                                    }
                                } else {
                                    if ("SYNO.AudioStation.Artist" === e.params.api) {
                                        f = {
                                            api: "SYNO.AudioStation.Album",
                                            additional: "avg_rating"
                                        };
                                        if ("AllMusic" !== g.get("id")) {
                                            f.artist = g.get("name")
                                        }
                                    } else {
                                        if ("SYNO.AudioStation.Composer" === e.params.api) {
                                            f = {
                                                api: "SYNO.AudioStation.Album",
                                                composer: g.get("name"),
                                                additional: "avg_rating"
                                            }
                                        } else {
                                            if ("SYNO.AudioStation.Genre" === e.params.api) {
                                                f = {
                                                    api: "SYNO.AudioStation.Artist",
                                                    genre: g.get("name"),
                                                    additional: "avg_rating"
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                            if (undefined !== e.params.artist) {
                                f.artist = e.params.artist
                            }
                            if (undefined !== e.params.composer) {
                                f.composer = e.params.composer
                            }
                            if (undefined !== e.params.genre) {
                                f.genre = e.params.genre
                            }
                            if (undefined !== e.params.genre_filter) {
                                f.genre_filter = e.params.genre_filter
                            }
                        } else {
                            if ((this._getUtils().isAtHomepage() || this._getUtils().isAtPinList()) && !h) {
                                var c = g.get("type");
                                var a = g.get("criteria");
                                if ("folder" === c) {
                                    f = {
                                        api: "SYNO.AudioStation.Folder",
                                        id: a.folder,
                                        additional: "song_tag,song_audio,song_rating"
                                    }
                                } else {
                                    if ("artist" === c || "composer" === c) {
                                        f = {
                                            api: "SYNO.AudioStation.Album",
                                            additional: "avg_rating"
                                        };
                                        Ext.apply(f, a)
                                    } else {
                                        if ("album" === c) {
                                            f = {
                                                api: "SYNO.AudioStation.Song",
                                                additional: "song_tag,song_audio,song_rating"
                                            };
                                            Ext.apply(f, a)
                                        } else {
                                            if ("genre" === c) {
                                                f = {
                                                    api: "SYNO.AudioStation.Artist",
                                                    additional: "avg_rating"
                                                };
                                                Ext.apply(f, a)
                                            } else {
                                                if ("playlist" === c) {
                                                    f = {
                                                        api: "SYNO.AudioStation.Playlist",
                                                        method: "getinfo",
                                                        id: a.playlist,
                                                        additional: "songs_song_tag,songs_song_audio,songs_song_rating,sharing_info"
                                                    }
                                                } else {
                                                    if ("random_100" === c) {
                                                        f = {
                                                            api: "SYNO.AudioStation.Song",
                                                            additional: "song_tag,song_audio,song_rating",
                                                            sort_by: "random",
                                                            limit: 100
                                                        }
                                                    } else {
                                                        if ("recently_added" === c) {
                                                            f = {
                                                                api: "SYNO.AudioStation.Album",
                                                                additional: "avg_rating",
                                                                sort_by: "time",
                                                                sort_direction: "desc",
                                                                limit: 50
                                                            }
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                if ("AllPin" === g.get("id")) {
                                    f = e.params
                                }
                            } else {
                                if (h) {
                                    f = {
                                        api: "SYNO.AudioStation.Artist",
                                        genre_filter: g.get("name"),
                                        additional: "avg_rating"
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        f = Ext.apply({
            method: "list",
            library: this._getWindow().getBrowseLibraryType()
        }, this._getUtils().getWebAPIParams(f));
        return f
    },
    onOpenContainingFolder: function(a) {
        var b = a.data.path;
        this._getUtils().launchFileStation(b)
    },
    onShowSongInfoEditor: function(d, b) {
        var e = [],
            c;
        Ext.each(d, function(f) {
            var g = f.data.path;
            e.push(g)
        });
        c = {
            selectRecord: d,
            editable: SYNO.SDS.AudioStation.SessionData.privilege.tag_edit,
            store: b,
            audioAppMain: this
        };
        var a = new SYNO.SDS.MusicTagEditor.ModalWindow({
            title: _AST("common", "song_information"),
            audioPaths: e,
            audioConfig: c,
            owner: this.getCurrentWindow()
        });
        a.open()
    },
    onShowSearchOnlineEditor: function(c) {
        var b = [],
            a = [];
        Ext.each(c, function(d) {
            b.push(d.data.album);
            a.push(d.data.artist)
        });
        b = this._getUtils().sortByFrequency(b);
        a = this._getUtils().sortByFrequency(a);
        this.searchConditionEdit = new SYNO.SDS.AudioStation.SearchConditionDialog({
            title: _AST("common", "search_info_online"),
            selectedAlbum: b,
            selectedArtist: a,
            selectedRecords: c,
            owner: this._getWindow()
        });
        this.searchConditionEdit.open()
    },
    onRegenRandom100: function() {
        delete this.dataStore.sortInfo;
        this.dataStore.reload()
    },
    onDownloadRequest: function(b) {
        var a = (b.filename) ? SYNO.SDS.AudioStation.Utils.replaceDLNameSpecChars(b.filename) : "audio.zip";
        var e = '<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"></head><body><form accept-charset="utf-8" name="dlform" action="{dlUrl}" method="POST"><input type="hidden" name="api" value="SYNO.AudioStation.Download" /><input type="hidden" name="version" value="' + this._getUtils().webAPIVersion["SYNO.AudioStation.Download"] + '"/><input type="hidden" name="method" value="download" />';
        if (b.id) {
            e += '<input type="hidden" name="id" value="' + b.id + '" />'
        }
        if (b.songs) {
            e += '<input type="hidden" name="songs" value="' + b.songs + '" />'
        }
        if (b.playlists_json) {
            e += '<input type="hidden" name="playlists_json" value="" />'
        }
        e += '<input type="hidden" name="library" value="' + this._getWindow().getBrowseLibraryType() + '" />';
        e += '<input type="hidden" name="filename" value="" />';
        e += "</form></body></html>";
        var g = new Ext.Template(e);
        g.compile();
        var c = Ext.urlAppend(String.format("{0}/{1}", this._getUtils().getWebAPIURL("download.cgi"), encodeURIComponent(a)));
        var i = g.applyTemplate({
            dlUrl: c
        });
        if (Ext.fly("download_iframe")) {
            Ext.destroy(Ext.fly("download_iframe"))
        }
        var f = SYNO.SDS.AudioStation.Utils.GetDownloadIframe(this._getWindow());
        if (!f) {
            return
        }
        var h = Ext.isIE || Ext.isModernIE ? f.contentWindow.document : (f.contentDocument || window.frames[f.id].document);
        h.open("text/html");
        h.write(i);
        h.close();
        Ext.EventManager.on(f, "load", function d() {
            var k = Ext.isIE || Ext.isModernIE ? f.contentWindow.document : (f.contentDocument || window.frames[f.id].document);
            Ext.EventManager.removeListener(f, "load", d, this);
            try {
                if (k && k.body) {
                    var j = Ext.decode(k.body.innerHTML);
                    if (SYNO.webfm.utils.checkIfNeedRedirect(j.errno.section, j.errno.key, true) || this.owner.getMsgBox().alert(_AST("common", "class_audio_station"), _AST(j.errno.section, j.errno.key))) {
                        return true
                    }
                }
            } catch (l) {}
            return false
        }, this);
        if (h.dlform.playlists_json) {
            h.dlform.playlists_json.value = Ext.util.JSON.encode(b.playlists_json)
        }
        h.dlform.submit()
    },
    onGetSharingLink: function(c, d, b) {
        var a = new SYNO.SDS.AudioStation.SharingLinkDialog({
            owner: this._getWindow(),
            plsId: d,
            url: b,
            title: String.format(_AST("sharing", "link_to"), c)
        });
        a.show()
    },
    onGetSharingLinkInPlaylist: function(b) {
        var a = this.dataStore.reader.jsonData.data.playlists[0],
            c = a.additional.sharing_info.url;
        if (b.length < 1) {
            this.onGetSharingLink(a.name, a.id, c)
        } else {
            var d = SYNO.SDS.AudioStation.Utils.Base64.encode(this._getUtils().isVirtualMusic(b[0]) ? b[0].get("path") + "_" + b[0].get("track") : b[0].get("path"));
            c = c + "#!" + d;
            this.onGetSharingLink(a.name, a.id, c)
        }
    },
    getAlbumPublicSharingRules: function(d) {
        var a = {},
            e = this._getWindow().pathMgr.getHistoryInfo(),
            c = d.get("name"),
            b = d.get("album_artist");
        a.conjRule = "and";
        a.rules = [];
        if (c) {
            a.rules.push({
                tag: 2,
                op: 1,
                tagval: c,
                interval: 0
            });
            a.rules.push({
                tag: 11,
                op: 1,
                tagval: b,
                interval: 0
            })
        }
        if (typeof e.params.artist === "string") {
            a.rules.push({
                tag: 1,
                op: 1,
                tagval: e.params.artist,
                interval: 0
            })
        }
        if (typeof e.params.composer === "string") {
            a.rules.push({
                tag: 12,
                op: 1,
                tagval: e.params.composer,
                interval: 0
            })
        }
        if (typeof e.params.genre === "string") {
            a.rules.push({
                tag: 3,
                op: 1,
                tagval: e.params.genre,
                interval: 0
            })
        }
        return a
    },
    onSmartPlaylistNew: function() {
        this.ManageSmartPlaylistRule("", "new", this._getWindow().getBrowseLibraryType(), true, false)
    },
    ManageSmartPlaylistRule: function(c, e, d, g, f, b) {
        var a = new SYNO.SDS.AudioStation.SmartPlaylist.RuleDialog({
            owner: this._getWindow(),
            cgiUrl: this._getUtils().getWebAPIURL("playlist.cgi"),
            isFromAudioStation: true
        });
        a.load(c, e, d, false, g, f);
        if (b) {
            a.setInitialRules(b.conjRule, b.rules)
        }
    },
    afterSaveSmartPlaylist: function(a) {
        var b = a.params;
        if ("createsmart" === b.method || "updatesmart" === b.method) {
            if (this._getUtils().isInAllPlaylist()) {
                this.dataStore.reload()
            }
            this.playlistStore.reload()
        }
    },
    afterTagEditorApply: function(l) {
        var e = false,
            d, a, b, k, h, f, g = this.getCurrentPlayingIndex(),
            c = this.getCurrentPlayingRecord(),
            j = true;
        if ((l.length < 50 && this._getUtils().isInAllMusic()) || this._getUtils().isInRandom100() || this._getUtils().isPlayingQueue() || this._getUtils().isInSearchAllCate()) {
            j = false
        }
        Ext.each(l, function(i) {
            if (!this._getUtils().isPlayingQueue()) {
                if (this._getUtils().isInSearchAllCate()) {
                    this.updateStore(i, this.searchAllSongStore)
                } else {
                    if (!j) {
                        this.updateStore(i, this.dataStore)
                    }
                }
            }
            if (-1 != this.playingStore.find("path", i.path)) {
                e = true
            }
            if (this.lyricsMgr) {
                this.lyricsMgr.clearLyrics(i.path)
            }
        }, this);
        if (e) {
            d = this.getSelectionRecords();
            if (!this._getUtils().isPlayingQueue()) {
                b = d.length;
                k = 0;
                for (f = 0; f < d.length; f++) {
                    d[f].index = this.playingStore.find("id", d[f].get("id"));
                    if (-1 !== d[f].index) {
                        if (d[f].index < b) {
                            b = d[f].index
                        }
                        if (d[f].index > k) {
                            k = d[f].index
                        }
                    }
                }
            } else {
                b = d[0].index;
                k = d[d.length - 1].index
            }
            a = this._getUtils().getSongIdList(this.playingStore.getRange(b, k));
            h = this._getUtils().getUpdatedIndex(a, g, c, b, k);
            this.onPlayingQueueCommit("updateplaylist", false, a, null, b, k - b + 1, h, true)
        }
        if (j) {
            this.dataStore.reload()
        }
    },
    updateStore: function(d, c) {
        var f, b, a = false,
            e = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.ThumbView");
        b = c.find("path", d.path);
        if (-1 !== b) {
            a = true;
            f = c.getAt(b);
            f.set("title", d.title);
            f.set("artist", d.artist);
            f.set("album", d.album);
            f.set("album_artist", d.album_artist);
            f.set("composer", d.composer);
            f.set("disc", d.disc);
            f.set("genre", d.genre);
            f.set("track", d.track);
            f.set("year", d.year);
            Ext.copyTo(f.json, f.data, "title,artist,album,album_artist,composer,disc,genre,track,year");
            if (d.type) {
                this._getUtils().coverTimeStamp = new Date().getTime()
            }
            c.commitChanges();
            if ("thumbViewPanel" == this.cardPanel.layout.activeItem.itemId) {
                e.dataView.refresh()
            }
        }
        return a
    },
    onPlaylistMoveRec: function(f) {
        var d = this.getSelectionRecords();
        var a = ("move_up" === f) ? d[0].index - 1 : d[0].index;
        var e = ("move_down" === f) ? d[d.length - 1].index + 1 : d[d.length - 1].index;
        var b = ("move_up" === f) ? a : e - d.length + 1;
        var c;
        c = this._getUtils().rearrangeStore(d, this.dataStore, b);
        this.onPlaylistUpdateRec(a, e, c)
    },
    onPlaylistUpdateRec: function(a, f, d) {
        var e = [];
        var c;
        e = SYNO.SDS.AudioStation.Utils.getSongIdList(this.dataStore.getRange(a, f));
        c = this.dataStore.baseParams.id;
        var b = this._getUtils().getWebAPIParams({
            api: "SYNO.AudioStation.Playlist",
            method: "updatesongs",
            offset: a,
            limit: f - a + 1,
            id: c,
            songs: e,
            force_reload: d
        });
        SYNO.SDS.AudioStation.DelayedTaskQueue.addTask(c, b, this.onPlaylistRequest, this)
    },
    onPlaylistDeleteRec: function() {
        var c = this._getWindow().pathMgr.getHistoryInfo();
        var b, l;
        var a = this.getSelectionRecords();
        var d = null;
        var j, k, f;
        var e;
        var h = false;
        var g = false;
        if (0 >= a.length) {
            return
        }
        if (this._getUtils().isInAllPlaylist()) {
            j = "";
            g = this._getUtils().isContainSharedItem(a);
            if (g && !SYNO.SDS.AudioStation.SessionData.privilege.playlist_edit) {
                return
            }
            for (f = 0; f < a.length; f++) {
                d = a[f];
                if (!d) {
                    continue
                }
                k = this._getUtils().escapeComma(d.get("id"));
                if (!h) {
                    if (SYNO.SDS.AudioStation.Utils.isSmartItem(k)) {
                        h = true
                    }
                }
                if (j.length) {
                    j += ("," + k)
                } else {
                    j += k
                }
            }
            e = this._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.Playlist",
                method: "delete"
            });
            if (j.length) {
                Ext.apply(e, {
                    id: j
                })
            }
            this._getWindow().getMsgBox().confirmDelete(_AST("playlist", "playlist"), _AST("playlist", "playlist_confirm_delete"), function(i) {
                if ("yes" === i) {
                    SYNO.SDS.AudioStation.DelayedTaskQueue.addTask(a[0].get("id"), e, this.onPlaylistRequest, this)
                }
            }, this)
        } else {
            d = [];
            if (!this._getUtils().checkPlaylistEditable(this.dataStore.baseParams.id)) {
                return
            }
            b = a[0].index;
            l = a[a.length - 1].index;
            for (f = b; f < l + 1; f++) {
                if (!this.IsRecordSelected(f)) {
                    d.push(this.dataStore.data.items[f])
                }
            }
            j = SYNO.SDS.AudioStation.Utils.getSongIdList(d);
            e = this._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.Playlist",
                method: "updatesongs",
                offset: c.params.offset + b,
                limit: l - b + 1,
                id: this.dataStore.baseParams.id,
                songs: j
            });
            SYNO.SDS.AudioStation.DelayedTaskQueue.addTask(a[0].get("id"), e, this.onPlaylistRequest, this)
        }
    },
    onPlaylistEdit: function(b) {
        var a = {
            id: b.get("id"),
            name: b.get("name")
        };
        this.promptPlaylistDialog(a, function(e, c, d) {
            if (e !== b.get("name")) {
                this.onPlaylistRequest(this._getUtils().getWebAPIParams({
                    api: "SYNO.AudioStation.Playlist",
                    method: "rename",
                    id: b.get("id"),
                    new_name: e
                }))
            }
            if (d.isNeedUpdate) {
                this.updatePlaylistSharing(b.get("id"), b.get("name"), d)
            }
        }, this)
    },
    onSmartPlaylistEdit: function(c) {
        var b = SYNO.SDS.AudioStation.Utils.isPersonalItem(c.get("id")),
            a = "none" !== c.json.sharing_status;
        this.ManageSmartPlaylistRule(c.get("name"), "edit", this._getWindow().getBrowseLibraryType(), b, a)
    },
    onPublicSharing: function(a, b) {
        var c, d;
        if (a && 1 == a.length && this._getUtils().isTrack(a[0])) {
            d = a[0];
            c = new SYNO.SDS.AudioStation.SharingLinkDialog({
                owner: this._getWindow(),
                songId: d.get("id"),
                isSingleSong: true,
                isJustGetUrl: b,
                title: b ? String.format(_AST("sharing", "link_to"), a[0].get("title")) : _AST("sharing", "share_to_public")
            });
            c.show()
        } else {
            this.onPlaylistNew(a, false, true)
        }
    },
    onPlaylistNew: function(a, e, d) {
        var b = "",
            g, f;
        var c = {
            id: "",
            name: "",
            isShared: !!e,
            isPublicSharing: !!d
        };
        if (a && 0 < a.length) {
            if (this._getUtils().isTrack(a[0])) {
                g = SYNO.SDS.AudioStation.Utils.getSongIdList(a)
            } else {
                f = this.getAlbumPublicSharingRules(a[0])
            }
            if (d) {
                b = (g) ? _AST("playlist", "untitled_playlist") : a[0].get("name");
                c.name = this.getDefaultSharingName(b)
            }
        }
        this.promptPlaylistDialog(c, function(l, h, i) {
            var k = this._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.Playlist",
                method: (f) ? "createsmart" : "create",
                name: l,
                library: (h) ? "shared" : "personal"
            });
            if (g) {
                k.songs = g
            }
            if (f) {
                k.conj_rule = f.conjRule;
                k.rules_json = Ext.util.JSON.encode(f.rules)
            }
            if (i.enable_sharing) {
                var j = function(n, p, m) {
                    var o = Ext.util.JSON.decode(m.responseText);
                    SYNO.SDS.AudioStation.Window.clearStatusBusy();
                    if (p && o.success) {
                        this.updatePlaylistSharing(o.data.id, l, i)
                    }
                };
                this.onPlaylistRequest(k, j)
            } else {
                this.onPlaylistRequest(k)
            }
        }, this)
    },
    updatePlaylistSharing: function(c, a, b) {
        this.onPlaylistRequest(this._getUtils().getWebAPIParams({
            api: "SYNO.AudioStation.Playlist",
            method: "editsharing",
            id: c,
            enable_sharing: b.enable_sharing,
            date_available: b.date_available,
            date_expired: b.date_expired
        }), this.onPlaylistRequestDone.createDelegate(this, [a], true))
    },
    getDefaultSharingName: function(b) {
        var c = false,
            a = 1,
            d = b;
        while (!c) {
            if (-1 == this.playlistStore.find("name", d)) {
                c = true
            } else {
                d = b + " (" + a + ")";
                a++
            }
        }
        return d
    },
    promptPlaylistDialog: function(a, c) {
        var b;
        b = new SYNO.SDS.AudioStation.PlaylistDialog({
            owner: this._getWindow(),
            option: a,
            callback: c,
            callbackScope: this
        });
        b.show()
    },
    onPlaylistRequest: function(b, a) {
        this.gHasReloadPlaylist = false;
        this.onPlaylistRequestWithoutSetReloadFlag({
            param: b,
            callbackFunction: a
        })
    },
    onPlaylistRequestWithoutSetReloadFlag: function(a, b) {
        SYNO.SDS.AudioStation.Window.setStatusBusy();
        Ext.Ajax.request({
            url: this._getUtils().getWebAPIURL("playlist.cgi"),
            params: Ext.isString(b) && !Ext.isEmpty(b) ? Ext.apply({}, {
                id: b
            }, a.param) : a.param,
            callback: a.callbackFunction || this.onPlaylistRequestDone,
            scope: this
        })
    },
    onDuplicatedTracksError: function(b, a) {
        this._getWindow().getMsgBox().confirm(_AST("playlist", "playlist"), this._getUtils().getErrMsgString("AUDIO_ERR_DUPLICATE_SONGS"), function(c) {
            if ("ok" === c) {
                b()
            } else {
                if ("yes" === c) {
                    a()
                }
            }
        }, this, {
            ok: _AST("common", "add_all"),
            yes: _AST("common", "skip_duplicate"),
            cancel: _AST("common", "btn_cancel")
        })
    },
    reloadPlaylistAndRetry: function(a, d, c) {
        var b = this.playlistStore.getById(a);
        if (!b) {
            c();
            return
        }
        this.gHasReloadPlaylist = true;
        this.playlistStore.reload({
            callback: function() {
                var e = this.playlistStore.findBy(function(f, g) {
                    return f.get("library") === b.get("library") && f.get("type") === b.get("type") && f.get("name") === b.get("name")
                });
                if (e === -1) {
                    c();
                    return
                }
                d(this.playlistStore.getAt(e).get("id"))
            },
            scope: this
        })
    },
    onPlaylistRequestDone: function(d, f, c, e) {
        SYNO.SDS.AudioStation.Window.clearStatusBusy();
        if (!f) {
            this._getWindow().getMsgBox().alert(_AST("playlist", "playlist"), _AST("common", "error_system"));
            return
        }
        var b = Ext.util.JSON.decode(c.responseText);
        if (!b.success) {
            if (b.error && b.error.code) {
                var a = this._getUtils().getErrCodeMapping(b.error.code, d.params.api, d.params.method);
                if ("AUDIO_ERR_FILE_OVERWRITE" === a) {
                    this._getWindow().getMsgBox().confirm(_AST("playlist", "playlist"), this._getUtils().getErrMsgString(a), function(g) {
                        if ("yes" === g) {
                            d.params.overwrite = "true";
                            if ("copytolibrary" == d.params.method && SYNO.SDS.AudioStation.Utils.isSmartItem(d.params.id) && SYNO.SDS.AudioStation.Utils.isPersonalItem(d.params.id)) {
                                this.setStatusBusy({
                                    text: _T("common", "msg_waiting")
                                })
                            }
                            this.onPlaylistRequest(d.params)
                        }
                    }, this)
                } else {
                    if ("AUDIO_ERR_DUPLICATE_SONGS" === a) {
                        this.onDuplicatedTracksError(this.onPlaylistRequest.bind(this, Ext.apply({}, {
                            skip_duplicate: false
                        }, d.params)), this.onPlaylistRequest.bind(this, Ext.apply({}, {
                            skip_duplicate: true
                        }, d.params)))
                    } else {
                        if ("AUDIO_ERR_PLAYLIST_NOT_EXISTS" === a && "updatesongs" === d.params.method && !this.gHasReloadPlaylist) {
                            this.reloadPlaylistAndRetry(d.params.id, this.onPlaylistRequestWithoutSetReloadFlag.bind(this, {
                                param: d.params,
                                callbackFunction: this.onPlaylistRequestDone.bind(this)
                            }), this._getWindow().getMsgBox().alert.bind(this, _AST("playlist", "playlist"), this._getUtils().getErrMsgString(a)))
                        } else {
                            if ("AUDIO_ERR_PLAYLIST_NOT_EXISTS" === a) {
                                this._getWindow().getMsgBox().alert(_AST("playlist", "playlist"), this._getUtils().getErrMsgString(a));
                                if (this._getUtils().isInAllPlaylist()) {
                                    this.dataStore.reload()
                                }
                                this.playlistStore.reload()
                            } else {
                                this._getWindow().getMsgBox().alert(_AST("playlist", "playlist"), this._getUtils().getErrMsgString(a))
                            }
                        }
                    }
                }
            } else {
                this._getWindow().getMsgBox().alert(_AST("playlist", "playlist"), _AST("common", "error_system"))
            }
            return
        }
        if (("create" === d.params.method) || ("saveplaying" === d.params.method) || ("savesearch" === d.params.method) || "editsharing" === d.params.method) {
            if (this._getUtils().isInAllPlaylist()) {
                this.dataStore.reload()
            }
            this.playlistStore.reload();
            if ("editsharing" === d.params.method) {
                if (d.params.enable_sharing && this._getUtils().testProperty(b, "data.sharing_info.url")) {
                    this.onGetSharingLink(e, d.params.id, b.data.sharing_info.url)
                }
            }
        } else {
            if ("delete" === d.params.method || "rename" === d.params.method || "copytolibrary" === d.params.method) {
                this.saveCurrentFoucusIndex();
                this.dataStore.reload();
                this.playlistStore.reload();
                if ("delete" === d.params.method) {
                    this.focusLastSelectedItem(--this._getWindow().pathMgr.getHistoryInfo().focusIdx)
                } else {
                    this.focusLastSelectedItem(this._getWindow().pathMgr.getHistoryInfo().focusIdx)
                }
            } else {
                if ("removemissing" === d.params.method) {
                    this.dataStore.reload()
                } else {
                    if ("updatesongs" === d.params.method && this._getUtils().isInPlaylistLayer2()) {
                        if (d.params.force_reload) {
                            this.dataStore.reload()
                        } else {
                            this._getUtils().updateSongsInStore(d, this.dataStore)
                        }
                    }
                }
            }
        }
    },
    showSelectPlaylistDialog: function(b) {
        var a = new SYNO.SDS.AudioStation.PlaylistSelectDialog({
            owner: this._getWindow(),
            audioAppMain: this,
            data: b
        });
        a.show()
    },
    onInetRadioEditRec: function(a, g) {
        var b;
        var k;
        var f;
        var i = this._getUtils().getRadioTitleByContainer(a);
        var d = this._getWindow().pathMgr.getHistoryInfo();
        if (!g) {
            this.clearSelections()
        }
        var e = function(l) {
            f = b.getForm().findField("txtInetDest").getValue();
            k = (l.getSelectionRecords()[0]) ? {
                method: "updateradios",
                offset: d.params.offset + l.dataStore.indexOf(l.getSelectionRecords()[0]),
                limit: 1,
                radios_json: String.format('[{"title":"{0}","desc":"{1}","url":"{2}"}]', b.getForm().findField("txtInetName").getValue().replace(/\"/g, '\\"'), b.getForm().findField("txtInetDesc").getValue().replace(/\"/g, '\\"'), b.getForm().findField("txtInetURL").getValue().replace(/\"/g, '\\"'))
            } : {
                method: "add",
                title: b.getForm().findField("txtInetName").getValue(),
                desc: b.getForm().findField("txtInetDesc").getValue(),
                url: b.getForm().findField("txtInetURL").getValue()
            };
            k = Ext.apply(k, l._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.Radio",
                container: f
            }));
            l.onInetRadioRequest(k);
            b.getForm().reset();
            l.winInetRadioEdit.hide()
        };
        var c = function(l, m) {
            if (_S("demo_mode")) {
                return
            }
            if (!b.getForm().isValid()) {
                return
            } else {
                if (!b.getForm().isDirty()) {
                    this.winInetRadioEdit.hide()
                } else {
                    e(this)
                }
            }
        };
        var j = function(l, m) {
            this.winInetRadioEdit.hide()
        };
        var h = function() {
            if (b.getForm().isDirty()) {
                this.winInetRadioEdit.confirmLostChangePromise({
                    save: function() {
                        if (!b.getForm().isValid()) {
                            return
                        } else {
                            e(this)
                        }
                    },
                    cancel: Ext.emptyFn,
                    dontSave: function() {
                        b.getForm().reset();
                        this.winInetRadioEdit.hide()
                    }
                }, this);
                return false
            }
            return true
        };
        if (!Ext.form.VTypes.inetradiourl) {
            Ext.apply(Ext.form.VTypes, {
                inetradiourl: function(l) {
                    return /^\s*http[s]?:\/\/\S+\s*$/.test(l) || (/^mms:\/\//.test(l) && 6 < l.trim().length)
                },
                inetradiourlText: Ext.form.VTypes.urlText
            })
        }
        if (!this.winInetRadioEdit) {
            b = new SYNO.ux.FormPanel({
                labelWidth: 90,
                defaultType: "syno_textfield",
                trackResetOnLoad: true,
                itemId: "formInetEdit",
                items: [{
                    fieldLabel: _AST("radio", "radio_name"),
                    allowBlank: false,
                    name: "txtInetName",
                    width: 230,
                    value: (g) ? g.get("title") : ""
                }, {
                    fieldLabel: _AST("radio", "radio_desc"),
                    name: "txtInetDesc",
                    width: 230,
                    value: (g) ? g.get("desc") : ""
                }, {
                    fieldLabel: _AST("radio", "radio_url"),
                    allowBlank: false,
                    name: "txtInetURL",
                    width: 230,
                    vtype: "inetradiourl",
                    value: (g) ? g.get("url") : ""
                }, {
                    name: "txtInetDest",
                    xtype: "hidden",
                    value: a
                }]
            });
            this.winInetRadioEdit = new SYNO.SDS.ModalWindow({
                title: i,
                layout: "fit",
                width: 375,
                height: 240,
                owner: this._getWindow(),
                cls: "syno-as-dialog",
                closeAction: "hide",
                constrain: true,
                resizable: false,
                defaultType: "textfield",
                items: [b],
                buttons: [{
                    text: _AST("common", "btn_cancel"),
                    scope: this,
                    handler: j
                }, {
                    text: _AST("common", "btn_ok"),
                    scope: this,
                    btnStyle: "blue",
                    disabled: _S("demo_mode"),
                    tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                    handler: c
                }],
                keys: [{
                    key: Ext.EventObject.ENTER,
                    scope: this,
                    fn: c
                }, {
                    key: Ext.EventObject.ESC,
                    scope: this,
                    fn: j
                }],
                listeners: {
                    scope: this,
                    beforehide: h
                }
            })
        }
        if (g) {
            b = this.winInetRadioEdit.getComponent("formInetEdit");
            b.getForm().setValues([{
                id: "txtInetName",
                value: g.get("title")
            }, {
                id: "txtInetDesc",
                value: g.get("desc")
            }, {
                id: "txtInetURL",
                value: g.get("url")
            }, {
                id: "txtInetDest",
                value: a
            }])
        } else {
            b = this.winInetRadioEdit.getComponent("formInetEdit");
            b.getForm().setValues([{
                id: "txtInetName",
                value: ""
            }, {
                id: "txtInetDesc",
                value: ""
            }, {
                id: "txtInetURL",
                value: ""
            }, {
                id: "txtInetDest",
                value: a
            }])
        }
        this.winInetRadioEdit.setTitle(i);
        this.winInetRadioEdit.open();
        b.getForm().clearInvalid()
    },
    onInetRadioDeleteRec: function() {
        var e = this._getWindow().pathMgr.getHistoryInfo();
        var g = this.getSelectionRecords();
        var a, d, c = "[",
            b, f;
        if (0 >= g.length) {
            return
        }
        a = g[0].index;
        d = g[g.length - 1].index;
        for (b = a; b < d + 1; b++) {
            if (!this.IsRecordSelected(b)) {
                c += String.format('{"title":"{0}","desc":"{1}","url":"{2}"},', this.dataStore.getAt(b).get("title").replace(/\"/g, '\\"'), this.dataStore.getAt(b).get("desc").replace(/\"/g, '\\"'), this.dataStore.getAt(b).get("url").replace(/\"/g, '\\"'))
            }
        }
        c = ("[" === c) ? "[]" : (c.substr(0, c.length - 1) + "]");
        this._getWindow().getMsgBox().confirmDelete(_AST("radio", "radio"), _AST("radio", "confrm_del_radio"), function(h) {
            if ("yes" === h) {
                f = this._getUtils().getWebAPIParams({
                    api: "SYNO.AudioStation.Radio",
                    method: "updateradios",
                    container: e.params.container,
                    offset: e.params.offset + a,
                    limit: d - a + 1,
                    radios_json: c
                });
                SYNO.SDS.AudioStation.DelayedTaskQueue.addTask(g[0].get("id"), f, this.onInetRadioRequest, this)
            }
        }, this)
    },
    onInetRadioRequest: function(b, a) {
        Ext.Ajax.request({
            url: this._getUtils().getWebAPIURL("radio.cgi"),
            params: b,
            callback: (a) ? a : this.onInetRadioRequestDone,
            scope: this
        })
    },
    onInetRadioRequestDone: function(d, h, c) {
        if (!h) {
            this._getWindow().getMsgBox().alert(_AST("playlist", "playlist"), _AST("common", "error_system"));
            return
        }
        var a = Ext.util.JSON.decode(c.responseText);
        var e = this._getWindow().pathMgr.getHistoryInfo().params;
        var b = this._getWindow().gridPagingSize;
        var f = d.params;
        var g = 0;
        if (!a.success) {
            if (a.error && a.error.code) {
                this._getWindow().getMsgBox().alert(_AST("playlist", "playlist"), this._getUtils().getErrMsgString(this._getUtils().getErrCodeMapping(a.error.code)))
            } else {
                this._getWindow().getMsgBox().alert(_AST("playlist", "playlist"), _AST("common", "error_system"))
            }
            return
        }
        this.dataStore.proxy.setUrl(this._getUtils().getWebAPIURL("radio.cgi"));
        delete this.dataStore.reader.ef;
        this.dataStore.reader.buildExtractors();
        if ("add" === f.method) {
            if ("SYNO.AudioStation.Radio" === e.api && f.container === e.container) {
                g = parseInt(this.dataStore.totalLength / b, 10) * b
            }
            this._getWindow().pathMgr.gotoCreatedInetRadio(f.container, g)
        } else {
            if (f.limit === this.dataStore.getCount() && "[]" === f.radios_json && 0 !== e.offset) {
                this._getWindow().pathMgr.gotoCreatedInetRadio(f.container, e.offset - b)
            } else {
                if ("updateradios" !== f.method || -1 !== f.offset) {
                    this.dataStore.reload()
                }
            }
        }
    },
    startPollingTask: function() {
        if (!this.PollingTask) {
            var a = this._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.RemotePlayerStatus",
                method: "getstatus",
                id: this.gCurrentSelectPlayer,
                additional: "song_tag,song_audio,subplayer_volume"
            });
            this.PollingTask = this.addTask({
                scope: this,
                run: function() {
                    Ext.Ajax.request({
                        url: this._getUtils().getWebAPIURL("remote_player_status.cgi"),
                        params: a,
                        method: "GET",
                        scope: this,
                        callback: function(c, e, b) {
                            var d;
                            if (!e || !b.responseText || this.gCurrentSelectPlayer !== a.id) {
                                return
                            }
                            d = Ext.util.JSON.decode(b.responseText);
                            if (!d) {
                                return
                            } else {
                                if (d.error && d.error.code && "AUDIO_ERR_DEVICE_NOT_EXISTS" === this._getUtils().getErrCodeMapping(d.error.code)) {
                                    this.switchToStreamingMode();
                                    this._getWindow().getMsgBox().alert(_AST("player", "player"), this._getUtils().getErrMsgString("AUDIO_ERR_DEVICE_NOT_EXISTS"));
                                    return
                                }
                            }
                            this.playerPanel.Ctrl.updateByJson(d.data)
                        }
                    })
                },
                interval: 1000
            });
            this.PollingTask.start()
        }
    },
    onShowItemMenu: function(b, c) {
        var d, a = this.getSelectionRecords(b);
        if (this.isDisableAction()) {
            return
        }
        if (this._getUtils().isPlayingQueue() || (this.gIsOnMiniPlayerMode && this.miniPlayer) || (this.gIsOnLargePlayingQueue && !this.largePlayingQueuePanel.isInLyricsMode())) {
            d = this.getPlayingQueueMenu();
            this.updatePlayingQueueMenu(a)
        } else {
            if (this._getUtils().isInAllPlaylist()) {
                d = this.getPlaylistMenu();
                this.updatePlaylistMenu(a)
            } else {
                d = this.getItemMenu();
                this.updateItemMenu(a, ("btn_action" === b.itemId))
            }
        }
        d.cls = d.cls ? d.cls + " syno-ux-button-menu" : "syno-ux-button-menu";
        d.shadow = false;
        if ("btn_action" === b.itemId) {
            b.menu = d;
            b.showMenu()
        } else {
            d.showAt(c.getXY())
        }
    },
    updatePlayingQueueMenu: function() {
        var c = this.getSelectionRecords(),
            e = true,
            a = true;
        var d;
        if (SYNO.SDS.AudioStation.SessionData.settings.enable_download) {
            this.nowPlayingMenu.getComponent("download_selected").show();
            this.nowPlayingMenu.getComponent("download_playing").show()
        } else {
            this.nowPlayingMenu.getComponent("download_selected").hide();
            this.nowPlayingMenu.getComponent("download_playing").hide()
        }
        if (c.length) {
            this.nowPlayingMenu.getComponent("remove_select").enable();
            for (d = 0; d < c.length; d++) {
                if (c[d].get("path").substr(0, 4) == "http") {
                    e = false;
                    break
                }
            }
            if (e) {
                this.nowPlayingMenu.getComponent("download_selected").enable()
            } else {
                this.nowPlayingMenu.getComponent("download_selected").disable()
            }
        } else {
            this.nowPlayingMenu.getComponent("remove_select").disable();
            this.nowPlayingMenu.getComponent("download_selected").disable()
        }
        this.nowPlayingMenu.getComponent("playing_saveas").hide();
        if (this.playingStore.getCount()) {
            this.nowPlayingMenu.getComponent("playing_saveas").show();
            this.nowPlayingMenu.getComponent("play").enable();
            this.nowPlayingMenu.getComponent("playing_saveas").enable();
            this.nowPlayingMenu.getComponent("remove_all").enable();
            this.nowPlayingMenu.getComponent("download_playing").enable()
        } else {
            this.nowPlayingMenu.getComponent("play").disable();
            this.nowPlayingMenu.getComponent("playing_saveas").disable();
            this.nowPlayingMenu.getComponent("remove_all").disable();
            this.nowPlayingMenu.getComponent("download_playing").disable()
        }
        var b = false;
        for (d = 0; d < c.length; d++) {
            if ("file" !== c[d].get("type") || !SYNO.SDS.AudioStation.Utils.isSongExistent(c[d])) {
                b = true;
                break
            }
        }
        this.nowPlayingMenu.getComponent("playing_apply_song_rating").enable();
        if (b || 0 === c.length) {
            this.nowPlayingMenu.getComponent("playing_apply_song_rating").disable()
        } else {
            this.clearSongRatingMenuItemChecked();
            if (1 === c.length) {
                this.checkSongRatingMenuItem(c[0].get("song_rating"))
            }
        }
        for (d = 0; d < c.length && a; d++) {
            var f = false;
            if (0 === c[d].get("id").indexOf("music_p_")) {
                f = true
            }
            if (!f) {
                a = false
            }
        }
        if (c.length && (1 == c.length || a || SYNO.SDS.AudioStation.SessionData.privilege.tag_edit)) {
            this.nowPlayingMenu.getComponent("playing_songinfo").enable();
            if (1 < c.length) {
                for (d = 0; d < c.length; d++) {
                    if (!SYNO.SDS.AudioStation.Utils.isTagEditableMusic(c[d])) {
                        this.nowPlayingMenu.getComponent("playing_songinfo").disable();
                        break
                    }
                }
            }
        } else {
            this.nowPlayingMenu.getComponent("playing_songinfo").disable()
        }
        if (c.length && (a || SYNO.SDS.AudioStation.SessionData.privilege.tag_edit)) {
            this.nowPlayingMenu.getComponent("playing_search_info_online").enable();
            for (d = 0; d < c.length; d++) {
                if (!SYNO.SDS.AudioStation.Utils.isTagEditableMusic(c[d])) {
                    this.nowPlayingMenu.getComponent("playing_search_info_online").disable();
                    break
                }
                if (!SYNO.SDS.AudioStation.Utils.isSongExistent(c[d])) {
                    this.nowPlayingMenu.getComponent("playing_search_info_online").disable();
                    break
                }
            }
        } else {
            this.nowPlayingMenu.getComponent("playing_search_info_online").disable()
        }
        if (c.length && !this.IsRecordSelected(this.playingStore.getCount() - 1)) {
            this.nowPlayingMenu.getComponent("playing_movedown").enable()
        } else {
            this.nowPlayingMenu.getComponent("playing_movedown").disable()
        }
        if (c.length && !this.IsRecordSelected(0)) {
            this.nowPlayingMenu.getComponent("playing_moveup").enable()
        } else {
            this.nowPlayingMenu.getComponent("playing_moveup").disable()
        }
        if (!_S("standalone") && SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.App.FileStation3.Instance")) {
            this.nowPlayingMenu.getComponent("playing_open_folder").show()
        } else {
            this.nowPlayingMenu.getComponent("playing_open_folder").hide()
        }
        if (1 === c.length && SYNO.SDS.AudioStation.Utils.isLocalMusic(c[0])) {
            this.nowPlayingMenu.getComponent("playing_open_folder").enable()
        } else {
            this.nowPlayingMenu.getComponent("playing_open_folder").disable()
        }
    },
    updatePlaylistMenu: function(a) {
        var c = this._getUtils().isContainSharedItem(a),
            f = SYNO.SDS.AudioStation.Utils.isContainNormalItem(a),
            j = SYNO.SDS.AudioStation.Utils.isContainSmartItem(a),
            h = SYNO.SDS.AudioStation.Utils.isContainPredefinedItem(a),
            d = SYNO.SDS.AudioStation.Utils.isContainPersonalItem(a),
            e = false,
            g = false;
        this.plMenu.getComponent("pl_play_this").disable();
        this.plMenu.getComponent("pl_add_to_queue").disable();
        this.plMenu.getComponent("pl_add_to_next").disable();
        if (a.length) {
            this.plMenu.getComponent("pl_play_this").enable();
            this.plMenu.getComponent("pl_add_to_queue").enable();
            this.plMenu.getComponent("pl_add_to_next").enable()
        }
        if (a.length && this._getUtils().isInAllPlaylist()) {
            g = true;
            e = true;
            for (var b = 0; b < a.length; b++) {
                if (null === this.getPinDataFromRecord(a[b])) {
                    g = false;
                    break
                }
            }
        }
        this.plMenu.getComponent("pl_copy_to_shared").hide();
        this.plMenu.getComponent("pl_copy_to_personal").hide();
        if (!h && (!c || SYNO.SDS.AudioStation.SessionData.privilege.playlist_edit)) {
            if (!f) {
                this.plMenu.getComponent("pl_edit").show();
                if (1 === a.length) {
                    this.plMenu.getComponent("pl_edit").enable()
                } else {
                    this.plMenu.getComponent("pl_edit").disable()
                }
            } else {
                this.plMenu.getComponent("pl_edit").hide()
            }
            if (!j) {
                this.plMenu.getComponent("pl_rename").show();
                if (1 === a.length && !_S("demo_mode")) {
                    this.plMenu.getComponent("pl_rename").enable()
                } else {
                    this.plMenu.getComponent("pl_rename").disable()
                }
            } else {
                this.plMenu.getComponent("pl_rename").hide()
            }
            this.plMenu.getComponent("pl_delete").show();
            if (a.length && !_S("demo_mode")) {
                this.plMenu.getComponent("pl_delete").enable()
            } else {
                this.plMenu.getComponent("pl_delete").disable()
            }
            if (!c && SYNO.SDS.AudioStation.SessionData.privilege.playlist_edit) {
                this.plMenu.getComponent("pl_copy_to_shared").show()
            }
            if (!d) {
                this.plMenu.getComponent("pl_copy_to_personal").show()
            }
        } else {
            this.plMenu.getComponent("pl_delete").hide();
            this.plMenu.getComponent("pl_rename").hide();
            this.plMenu.getComponent("pl_edit").hide()
        }
        this.plMenu.getComponent("pl_copy_to_shared").disable();
        this.plMenu.getComponent("pl_copy_to_personal").disable();
        if (1 === a.length) {
            if (SYNO.SDS.AudioStation.SessionData.privilege.playlist_edit) {
                this.plMenu.getComponent("pl_copy_to_shared").enable()
            }
            this.plMenu.getComponent("pl_copy_to_personal").enable()
        }
        this.plMenu.getComponent("pl_download_playlist").disable();
        if (SYNO.SDS.AudioStation.SessionData.settings.enable_download) {
            this.plMenu.getComponent("pl_download_playlist").show();
            if (1 === a.length) {
                this.checkPLEmpty(a[0])
            }
        } else {
            this.plMenu.getComponent("pl_download_playlist").hide()
        }
        this.plMenu.getComponent("pl_public_share").hide();
        if (1 === a.length && !h) {
            if (SYNO.SDS.AudioStation.SessionData.privilege.sharing) {
                this.plMenu.getComponent("pl_public_share").show()
            }
        }
        this.plMenu.getComponent("pin_selected_item").hide();
        this.plMenu.getComponent("unpin_selected_item").hide();
        this.plMenu.getComponent("pin_selected_item").disable();
        this.plMenu.getComponent("unpin_selected_item").disable();
        if (e) {
            this.plMenu.getComponent("pin_selected_item").enable();
            this.plMenu.getComponent("unpin_selected_item").enable()
        }
        if (g) {
            this.plMenu.getComponent("unpin_selected_item").show()
        } else {
            this.plMenu.getComponent("pin_selected_item").show()
        }
    },
    updateItemMenu: function(F, B) {
        var n = SYNO.SDS.AudioStation.Utils.isInLibrarySearch(),
            y = SYNO.SDS.AudioStation.Utils.isInLibraryFolder(),
            a = SYNO.SDS.AudioStation.Utils.isInAlbum(),
            M = SYNO.SDS.AudioStation.Utils.isInMediaserver(),
            C = SYNO.SDS.AudioStation.Utils.isInPlaylistLayer2() || SYNO.SDS.AudioStation.Utils.isInHomepagePlaylist(),
            H = SYNO.SDS.AudioStation.Utils.isInAllPlaylist(),
            v = SYNO.SDS.AudioStation.Utils.isInCateAllMusic(),
            L = SYNO.SDS.AudioStation.Utils.isInRadioLeaf(),
            h = SYNO.SDS.AudioStation.Utils.isInRadioUserDefined(),
            k = SYNO.SDS.AudioStation.Utils.isInRadioFavorite(),
            p = SYNO.SDS.AudioStation.Utils.isInRandom100(),
            r = SYNO.SDS.AudioStation.Utils.isInSearchAllCate(),
            o = this._getUtils().isInPredefinedPlaylist(),
            w = SYNO.SDS.AudioStation.Utils.isInHomepage(),
            m = SYNO.SDS.AudioStation.Utils.isAtHomepage(),
            u = SYNO.SDS.AudioStation.Utils.isAtPinList(),
            t = SYNO.SDS.AudioStation.Utils.isInLibrary(),
            l = SYNO.SDS.AudioStation.Utils.isInAllMusic(),
            e = true,
            A = true,
            K = true,
            J = this._getWindow().pathMgr.getHistoryInfo(),
            j = true,
            D = false,
            f = false,
            z = false,
            G = false,
            g = false,
            x = false,
            c = false,
            d;
        var I;
        for (I = 0; I < F.length; I++) {
            if (!this._getUtils().isTrack(F[I])) {
                e = false
            }
            if (0 !== F[I].get("id").indexOf("music_p_")) {
                K = false
            }
            if (!this._getUtils().isLocalMusic(F[I])) {
                A = false
            }
            if (!e && !K && !A) {
                break
            }
            if (this._getUtils().isDefaultGenreRecord(F[I])) {
                c = true
            }
        }
        var b = ["album", "artist", "composer", "genre", "folder", "playlist", "random_100", "recently_added"];
        if (0 <= b.indexOf(J.container_type) && B) {
            g = true;
            if (null !== this.getPinDataFromInfo()) {
                x = true
            }
        }
        G = (t || w || H || r) && !a && !p && !l && !v;
        if (G && F.length > 0 && !c && !e) {
            if (m || u) {
                D = true;
                f = true;
                for (I = 0; I < F.length; I++) {
                    if ("recently_added" === F[I].get("type")) {
                        z = true;
                        break
                    }
                }
            } else {
                if (w || t || r) {
                    if (this._getUtils().isInAlbumLayer() || this._getUtils().isInArtistList() || this._getUtils().isInComposerList() || this._getUtils().isInGenreList() || r) {
                        D = true;
                        f = true;
                        for (I = 0; I < F.length; I++) {
                            if (null === this.getPinDataFromRecord(F[I])) {
                                f = false;
                                break
                            }
                        }
                    } else {
                        if (y) {
                            D = true;
                            f = true;
                            for (I = 0; I < F.length; I++) {
                                if ("folder" !== F[I].data.type) {
                                    D = false
                                }
                                if (null === this.getPinDataFromRecord(F[I])) {
                                    f = false
                                }
                            }
                        }
                    }
                }
            }
        }
        if (n) {
            this.itemMenu.getComponent("save_search").show();
            if (this.dataStore.getCount()) {
                this.itemMenu.getComponent("save_search").enable()
            } else {
                this.itemMenu.getComponent("save_search").disable()
            }
        } else {
            this.itemMenu.getComponent("save_search").hide()
        }
        if (p) {
            this.itemMenu.getComponent("random100_randomize").show()
        } else {
            this.itemMenu.getComponent("random100_randomize").hide()
        }
        if (B && (p || C)) {
            this.itemMenu.getComponent("play_this_list").show();
            this.itemMenu.getComponent("add_list_to_queue").show();
            this.itemMenu.getComponent("add_list_to_next").show();
            this.itemMenu.getComponent("item_sep_after_add_list_to_next").show();
            if (SYNO.SDS.AudioStation.SessionData.settings.enable_download) {
                if (!p) {
                    this.itemMenu.getComponent("download_playlist").disable();
                    Ext.Ajax.request({
                        url: this._getUtils().getWebAPIURL("playlist.cgi"),
                        params: this._getUtils().getWebAPIParams({
                            api: "SYNO.AudioStation.Playlist",
                            method: "getinfo",
                            id: J.params.id,
                            additional: "songs"
                        }),
                        callback: this.onCheckPLEmptyDone.createDelegate(this, [true], true),
                        scope: this
                    })
                }
                this.itemMenu.getComponent("download_playlist").show()
            } else {
                this.itemMenu.getComponent("download_playlist").hide()
            }
        } else {
            this.itemMenu.getComponent("play_this_list").hide();
            this.itemMenu.getComponent("add_list_to_queue").hide();
            this.itemMenu.getComponent("add_list_to_next").hide();
            this.itemMenu.getComponent("item_sep_after_add_list_to_next").hide();
            this.itemMenu.getComponent("download_playlist").hide()
        }
        this.itemMenu.getComponent("save_personal_playlist").hide();
        this.itemMenu.getComponent("save_shared_playlist").hide();
        this.itemMenu.getComponent("public_share").hide();
        var s = SYNO.SDS.AudioStation.SessionData.privilege.playlist_edit && "all" === SYNO.SDS.AudioStation.SessionData.browse_personal_library;
        if (a || v || p || this._getUtils().isInAllMusic() || y || (this._getUtils().isInRadio() && !this._getUtils().isInShoutCastCate()) || M || C || n || (r && "song" === this.getSearchAllPanelSelection())) {
            this.itemMenu.getComponent("save_personal_playlist").show();
            if (s) {
                this.itemMenu.getComponent("save_shared_playlist").show()
            }
            if (!M && !this._getUtils().isInRadio() && !this._getUtils().isInPredefinedPlaylist() && SYNO.SDS.AudioStation.SessionData.privilege.sharing) {
                this.itemMenu.getComponent("public_share").show()
            }
        }
        if (F.length && e) {
            this.itemMenu.getComponent("save_personal_playlist").enable();
            this.itemMenu.getComponent("save_shared_playlist").enable();
            this.itemMenu.getComponent("public_share").enable()
        } else {
            this.itemMenu.getComponent("save_personal_playlist").disable();
            this.itemMenu.getComponent("save_shared_playlist").disable();
            this.itemMenu.getComponent("public_share").disable()
        }
        if (1 == F.length && !A) {
            this.itemMenu.getComponent("public_share").disable()
        }
        this.itemMenu.getComponent("save_to_personal_playlist_by_condition").hide();
        this.itemMenu.getComponent("save_to_shared_playlist_by_condition").hide();
        if (this._getUtils().isInAlbumLayer() || this._getUtils().isInArtistList() || this._getUtils().isInComposerList() || this._getUtils().isInGenreList() || (r && "song" !== this.getSearchAllPanelSelection())) {
            this.itemMenu.getComponent("save_to_personal_playlist_by_condition").show();
            if (s) {
                this.itemMenu.getComponent("save_to_shared_playlist_by_condition").show()
            }
        }
        if (1 === F.length) {
            this.itemMenu.getComponent("save_to_personal_playlist_by_condition").enable();
            this.itemMenu.getComponent("save_to_shared_playlist_by_condition").enable()
        } else {
            this.itemMenu.getComponent("save_to_personal_playlist_by_condition").disable();
            this.itemMenu.getComponent("save_to_shared_playlist_by_condition").disable()
        }
        if ((1 === F.length && this._getUtils().isInAlbumLayer()) || (r && "album" === this.getSearchAllPanelSelection())) {
            if (SYNO.SDS.AudioStation.SessionData.privilege.sharing) {
                this.itemMenu.getComponent("public_share").show();
                this.itemMenu.getComponent("public_share").enable()
            } else {
                this.itemMenu.getComponent("public_share").disable()
            }
        }
        this.itemMenu.getComponent("get_sharing_link").hide();
        if (SYNO.SDS.AudioStation.SessionData.privilege.sharing && C) {
            this.itemMenu.getComponent("get_sharing_link").show();
            if (this._getUtils().isInPublicSharingPlaylist()) {
                this.itemMenu.getComponent("get_sharing_link").enable()
            } else {
                this.itemMenu.getComponent("get_sharing_link").disable()
            }
        }
        this.itemMenu.getComponent("get_song_sharing_link").hide();
        this.itemMenu.getComponent("stop_sharing").hide();
        this.itemMenu.getComponent("get_song_sharing_link").disable();
        this.itemMenu.getComponent("stop_sharing").disable();
        if (this._getUtils().isInPredefinedPlaylist()) {
            this.itemMenu.getComponent("get_sharing_link").hide();
            this.itemMenu.getComponent("get_song_sharing_link").show();
            this.itemMenu.getComponent("stop_sharing").show();
            if (1 == F.length) {
                this.itemMenu.getComponent("get_song_sharing_link").enable()
            }
            if (1 <= F.length) {
                this.itemMenu.getComponent("stop_sharing").enable()
            }
        }
        this.itemMenu.getComponent("item_sep_1").hide();
        if (n || this._getUtils().isInPlaylistLayer2()) {
            this.itemMenu.getComponent("item_sep_1").show()
        }
        if (L || k || h) {
            this.itemMenu.getComponent("add_to_next").hide()
        } else {
            this.itemMenu.getComponent("add_to_next").show()
        }
        if (F.length) {
            if ((this._getUtils()._MediaServer_ID === J.type && !e) || z || c) {
                this.itemMenu.getComponent("play_this").disable();
                this.itemMenu.getComponent("add_to_queue").disable();
                this.itemMenu.getComponent("add_to_next").disable()
            } else {
                this.itemMenu.getComponent("play_this").enable();
                this.itemMenu.getComponent("add_to_queue").enable();
                this.itemMenu.getComponent("add_to_next").enable()
            }
        } else {
            this.itemMenu.getComponent("play_this").disable();
            this.itemMenu.getComponent("add_to_queue").disable();
            this.itemMenu.getComponent("add_to_next").disable()
        }
        this.itemMenu.getComponent("add_to_radio_favorite").hide();
        if (L && !k) {
            this.itemMenu.getComponent("add_to_radio_favorite").show();
            if (F.length > 0) {
                this.itemMenu.getComponent("add_to_radio_favorite").enable()
            } else {
                this.itemMenu.getComponent("add_to_radio_favorite").disable()
            }
        }
        if (SYNO.SDS.AudioStation.SessionData.settings.enable_download) {
            this.itemMenu.getComponent("download_selected").show()
        } else {
            this.itemMenu.getComponent("download_selected").hide()
        }
        if (F.length) {
            for (I = 0; I < F.length && j; I++) {
                j = (this._getUtils().isTrack(F[I]) && this._getUtils().isLocalMusic(F[I]))
            }
            if (e && j) {
                this.itemMenu.getComponent("download_selected").enable()
            } else {
                this.itemMenu.getComponent("download_selected").disable()
            }
        } else {
            this.itemMenu.getComponent("download_selected").disable()
        }
        if ((a || v || p || this._getUtils().isInAllMusic() || y || n || C)) {
            this.itemMenu.getComponent("apply_song_rating").show();
            var E = false;
            for (I = 0; I < F.length; I++) {
                if ("file" !== F[I].get("type") || !SYNO.SDS.AudioStation.Utils.isSongExistent(F[I])) {
                    E = true;
                    break
                }
            }
            this.itemMenu.getComponent("apply_song_rating").enable();
            if (E || 0 === F.length) {
                this.itemMenu.getComponent("apply_song_rating").disable()
            } else {
                this.clearSongRatingMenuItemChecked();
                if (1 === F.length) {
                    this.checkSongRatingMenuItem(F[0].get("song_rating"))
                }
            }
        } else {
            this.itemMenu.getComponent("apply_song_rating").hide()
        }
        if (a || v || p || this._getUtils().isInAllMusic() || y || M || C || n || (r && "song" === this.getSearchAllPanelSelection())) {
            this.itemMenu.getComponent("song_info").show();
            this.itemMenu.getComponent("search_info_online").show();
            this.itemMenu.getComponent("item_sep_after_add_to_next").show()
        } else {
            this.itemMenu.getComponent("song_info").hide();
            this.itemMenu.getComponent("search_info_online").hide();
            this.itemMenu.getComponent("item_sep_after_add_to_next").hide()
        }
        if (0 < F.length && e && (1 === F.length || K || SYNO.SDS.AudioStation.SessionData.privilege.tag_edit)) {
            this.itemMenu.getComponent("song_info").enable();
            if (1 < F.length) {
                for (I = 0; I < F.length; I++) {
                    if (!SYNO.SDS.AudioStation.Utils.isTagEditableMusic(F[I])) {
                        this.itemMenu.getComponent("song_info").disable();
                        break
                    }
                }
            }
        } else {
            this.itemMenu.getComponent("song_info").disable()
        }
        if (0 < F.length && e && (K || SYNO.SDS.AudioStation.SessionData.privilege.tag_edit)) {
            this.itemMenu.getComponent("search_info_online").enable();
            for (I = 0; I < F.length; I++) {
                if (!SYNO.SDS.AudioStation.Utils.isTagEditableMusic(F[I])) {
                    this.itemMenu.getComponent("search_info_online").disable();
                    break
                }
                if (!SYNO.SDS.AudioStation.Utils.isSongExistent(F[I])) {
                    this.itemMenu.getComponent("search_info_online").disable();
                    break
                }
            }
        } else {
            this.itemMenu.getComponent("search_info_online").disable()
        }
        d = this.itemMenu.getComponent("remove_from_playlist");
        d.hide();
        if (C && this._getUtils().checkPlaylistEditable(J.params.id)) {
            d.show();
            if (F.length) {
                d.enable()
            } else {
                d.disable()
            }
        } else {
            d.hide()
        }
        if (this._getUtils().isInPredefinedPlaylist()) {
            d.hide()
        }
        d = this.itemMenu.getComponent("delete_radio");
        d.hide();
        if (h || k) {
            d.show();
            if (F.length > 0) {
                d.enable()
            } else {
                d.disable()
            }
        } else {
            d.hide()
        }
        this.itemMenu.getComponent("edit").hide();
        if (h || k) {
            this.itemMenu.getComponent("edit").show();
            if (1 === F.length) {
                this.itemMenu.getComponent("edit").enable()
            } else {
                this.itemMenu.getComponent("edit").disable()
            }
        } else {
            this.itemMenu.getComponent("edit").hide()
        }
        if (C && this._getUtils().checkPlaylistEditable(J.params.id)) {
            this.itemMenu.getComponent("remove_missing").show();
            if (this.dataStore.getCount()) {
                this.itemMenu.getComponent("remove_missing").enable()
            } else {
                this.itemMenu.getComponent("remove_missing").disable()
            }
        } else {
            this.itemMenu.getComponent("remove_missing").hide()
        }
        if (!_S("standalone") && SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.App.FileStation3.Instance")) {
            if (a || v || p || this._getUtils().isInAllMusic() || y || C || n || (r && "song" === this.getSearchAllPanelSelection())) {
                this.itemMenu.getComponent("open_folder").show()
            } else {
                this.itemMenu.getComponent("open_folder").hide()
            }
            if (1 == F.length && e && SYNO.SDS.AudioStation.Utils.isLocalMusic(F[0])) {
                this.itemMenu.getComponent("open_folder").enable()
            } else {
                this.itemMenu.getComponent("open_folder").disable()
            }
        } else {
            this.itemMenu.getComponent("open_folder").hide()
        }
        if (C && !o && this._getUtils().checkPlaylistEditable(J.params.id)) {
            this.itemMenu.getComponent("move_down").show();
            this.itemMenu.getComponent("move_up").show();
            if (F.length && !this.IsRecordSelected(this.dataStore.getCount() - 1)) {
                this.itemMenu.getComponent("move_down").enable()
            } else {
                this.itemMenu.getComponent("move_down").disable()
            }
            if (F.length && !this.IsRecordSelected(0)) {
                this.itemMenu.getComponent("move_up").enable()
            } else {
                this.itemMenu.getComponent("move_up").disable()
            }
        } else {
            this.itemMenu.getComponent("move_down").hide();
            this.itemMenu.getComponent("move_up").hide()
        }
        this.itemMenu.getComponent("pin_selected_item").hide();
        this.itemMenu.getComponent("unpin_selected_item").hide();
        this.itemMenu.getComponent("pin_selected_item").disable();
        this.itemMenu.getComponent("unpin_selected_item").disable();
        if (G) {
            if (D) {
                this.itemMenu.getComponent("pin_selected_item").enable();
                this.itemMenu.getComponent("unpin_selected_item").enable()
            }
            if (f) {
                this.itemMenu.getComponent("unpin_selected_item").show()
            } else {
                this.itemMenu.getComponent("pin_selected_item").show()
            }
        }
        this.itemMenu.getComponent("pin_container").hide();
        this.itemMenu.getComponent("unpin_container").hide();
        if (g) {
            var q = J.text;
            if (x) {
                q = String.format(_AST("common", "unpin_some_item"), q);
                this.itemMenu.getComponent("unpin_container").setText(q);
                this.itemMenu.getComponent("unpin_container").show()
            } else {
                q = String.format(_AST("common", "pin_some_item"), q);
                this.itemMenu.getComponent("pin_container").setText(q);
                this.itemMenu.getComponent("pin_container").show()
            }
        }
        this.itemMenu.getComponent("renamepin").hide();
        if (m || u) {
            this.itemMenu.getComponent("renamepin").show();
            if (1 !== F.length || c) {
                this.itemMenu.getComponent("renamepin").disable()
            } else {
                this.itemMenu.getComponent("renamepin").enable()
            }
        }
        this.itemMenu.getComponent("reorderpin").hide();
        this.itemMenu.getComponent("reorderpin").disable();
        if (m || u) {
            this.itemMenu.getComponent("reorderpin").show()
        }
        if (F.length > 0 && !c) {
            this.itemMenu.getComponent("reorderpin").enable()
        }
    },
    checkSongRatingMenuItem: function(a) {
        var b = {
            0: "unrating",
            1: "one_star",
            2: "two_star",
            3: "three_star",
            4: "four_star",
            5: "five_star"
        };
        this.itemMenu.getComponent("apply_song_rating").menu.getComponent(b[a]).setChecked(true)
    },
    clearSongRatingMenuItemChecked: function() {
        this.itemMenu.getComponent("apply_song_rating").menu.items.each(function(a) {
            if (a.itemId) {
                Ext.getCmp(a.id).setChecked(false)
            }
        })
    },
    checkPLEmpty: function(a) {
        Ext.Ajax.request({
            url: this._getUtils().getWebAPIURL("playlist.cgi"),
            params: this._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.Playlist",
                method: "getinfo",
                id: a.get("id"),
                additional: "songs"
            }),
            callback: this.onCheckPLEmptyDone,
            scope: this
        })
    },
    onCheckPLEmptyDone: function(c, d, b, e) {
        if (d && b.responseText) {
            var a = Ext.util.JSON.decode(b.responseText);
            if (a && a.data && a.data.playlists && a.data.playlists[0].additional && a.data.playlists[0].additional.songs) {
                if (e) {
                    this.itemMenu.getComponent("download_playlist").enable()
                } else {
                    this.plMenu.getComponent("pl_download_playlist").enable()
                }
            }
        }
    },
    saveSearchToPlaylist: function() {
        var a = {
            id: "",
            name: "",
            isShared: false,
            isPublicSharing: false
        };
        this.promptPlaylistDialog(a, function(f, c) {
            var d = this._getWindow().pathMgr.getHistoryInfo(),
                b = this._getUtils().getSortInfo("MusicColumnSetting");
            var e = this._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.Playlist",
                method: "savesearch",
                name: f,
                library: (c) ? "shared" : "personal",
                conditions_json: Ext.util.JSON.encode([this._getUtils().getSearchJsonObj(this.gSearchCate, d.params.keyword, b.field, b.direction)])
            });
            this.onPlaylistRequest(e)
        }, this)
    },
    onSetSongRating: function(b, a) {
        SYNO.SDS.AudioStation.Window.setStatusBusy();
        Ext.Ajax.request({
            scope: this,
            method: "POST",
            url: this._getUtils().getWebAPIURL("song.cgi"),
            params: this._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.Song",
                method: "setrating",
                id: a.join(","),
                rating: b
            }),
            callback: function(d, e, c) {
                if (!e) {
                    this._getWindow().getMsgBox().alert(_AST("common", "class_audio_station"), _AST("common", "error_system"))
                }
                SYNO.SDS.AudioStation.Window.clearStatusBusy()
            }
        })
    },
    onMenuApplySongRating: function(o, l) {
        var m = 0;
        switch (o.itemId) {
            case "unrating":
                m = 0;
                break;
            case "one_star":
                m = 1;
                break;
            case "two_star":
                m = 2;
                break;
            case "three_star":
                m = 3;
                break;
            case "four_star":
                m = 4;
                break;
            case "five_star":
                m = 5;
                break
        }
        var f = this.getSelectionRecords();
        var n, h, g;
        var j, d, q;
        var c = [];
        g = this.cardPanel.listViewGrid;
        for (var k = 0; k < f.length; k++) {
            var p = f[k].get("id");
            c.push(p);
            this.updateSongRatingInDataStore(p, m);
            if (this.gIsOnLargePlayingQueue) {
                j = g.getListViewSongRatingContainerEl(p);
                SYNO.SDS.AudioStation.Utils.applySongRatingAndDisplay(j, m);
                SYNO.SDS.AudioStation.Utils.showOnlySongRatingOn(j)
            } else {
                if (g.rendered && "thumbViewPanel" !== this.cardPanel.layout.activeItem.itemId) {
                    n = g.store.indexOf(f[k]);
                    h = g.getView().getRow(n);
                    j = Ext.get(h).select("." + SYNO.SDS.AudioStation.Utils.getRatingClass("song_container")).first();
                    SYNO.SDS.AudioStation.Utils.applySongRatingAndDisplay(j, m)
                }
            }
            this.updateSongRatingInPlayingStore(p, m);
            q = this.getNowPlayingId();
            if (-1 !== q && p === q) {
                d = this.largePlayingQueuePanel.getInfoElement(SYNO.SDS.AudioStation.Utils.getRatingClass("song_container"));
                SYNO.SDS.AudioStation.Utils.applySongRatingAndDisplay(d, m);
                SYNO.SDS.AudioStation.Utils.showOnlySongRatingOn(d)
            }
        }
        if (SYNO.SDS.AudioStation.Utils.isInAlbum()) {
            var a = SYNO.SDS.AudioStation.Utils.calculateAvgRating(this.dataStore.data.items);
            var r = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.CardPanel").albumView.getComponent("avgRatingDiv").getEl();
            SYNO.SDS.AudioStation.Utils.applyAvgRatingAndDisplay(r, a)
        }
        this.onSetSongRating(m, c)
    },
    onItemMenuClick: function(o, m) {
        var g = this.getSelectionRecords(),
            a = [],
            d = [],
            j, k, l = null,
            q = this.dataStore.baseParams,
            c = this._getWindow().pathMgr.getHistoryInfo(),
            f = this._getUtils().isInRandom100(),
            h = this.getRecentPlayIndex(),
            p;
        switch (o.itemId) {
            case "pl_play_this":
            case "play_this":
                j = this._getUtils().sepSongsAndContainers(g);
                a = this._getUtils().getSongIdList(j.songs);
                if (this._getUtils().isInSearchAllCate()) {
                    p = this.getSearchAllPanelSelection();
                    if ("artist" === p) {
                        d = this._getUtils().getContainerJsonList(j.containers, this.searchAllArtistStore)
                    } else {
                        if ("album" === p) {
                            d = this._getUtils().getContainerJsonList(j.containers, this.searchAllAlbumStore)
                        }
                    }
                } else {
                    d = this._getUtils().getContainerJsonList(j.containers, this.dataStore)
                }
                this.onPlayingQueueCommit("updateplaylist", true, a, d, 0, this.playingStore.getTotalCount());
                break;
            case "play_this_list":
                if (f) {
                    a = this._getUtils().getSongIdList(this.dataStore.getRange())
                } else {
                    d.push(this._getUtils().getPlaylistJsonObj(c.params.id))
                }
                this.onPlayingQueueCommit("updateplaylist", true, a, d, 0, this.playingStore.getTotalCount());
                break;
            case "add_list_to_queue":
            case "add_list_to_next":
                if (f) {
                    a = this._getUtils().getSongIdList(this.dataStore.getRange())
                } else {
                    d.push(this._getUtils().getPlaylistJsonObj(c.params.id))
                }
                if ("add_list_to_next" === o.itemId) {
                    this.onPlayingQueueCommit("updateplaylist", false, a, d, h + 1, 0, undefined, undefined, true)
                } else {
                    this.onPlayingQueueCommit("updateplaylist", false, a, d, -1, 0)
                }
                break;
            case "save_search":
                this.saveSearchToPlaylist();
                break;
            case "remove_missing":
                this.onPlaylistRequest(this._getUtils().getWebAPIParams({
                    api: "SYNO.AudioStation.Playlist",
                    method: "removemissing",
                    id: c.params.id
                }));
                break;
            case "download_playlist":
                if (f) {
                    a = this._getUtils().getSongIdList(this.dataStore.getRange())
                } else {
                    d.push(this._getUtils().getPlaylistJsonObj(c.params.id))
                }
                this.onDownloadRequest({
                    songs: a,
                    playlists_json: d,
                    filename: c.text + ".zip"
                });
                break;
            case "random100_randomize":
                this.onRegenRandom100();
                break;
            case "get_sharing_link":
                this.onGetSharingLinkInPlaylist(g);
                break;
            case "reorderpin":
                this.onReorderPinItem();
                break;
            case "pin_container":
                this.onPinContainer();
                break;
            case "unpin_container":
                this.onUnpinContainer();
                break
        }
        if (0 === g.length) {
            return
        }
        l = g[0];
        switch (o.itemId) {
            case "pl_add_to_queue":
            case "pl_add_to_next":
            case "add_to_queue":
            case "add_to_next":
                j = this._getUtils().sepSongsAndContainers(g);
                a = this._getUtils().getSongIdList(j.songs);
                if (this._getUtils().isInSearchAllCate()) {
                    p = this.getSearchAllPanelSelection();
                    if ("artist" === p) {
                        d = this._getUtils().getContainerJsonList(j.containers, this.searchAllArtistStore)
                    } else {
                        if ("album" === p) {
                            d = this._getUtils().getContainerJsonList(j.containers, this.searchAllAlbumStore)
                        }
                    }
                } else {
                    if (this._getUtils().isAtHomepage() || this._getUtils().isAtPinList()) {
                        d = this._getUtils().getContainerJsonList(j.containers, this.pinStore)
                    } else {
                        d = this._getUtils().getContainerJsonList(j.containers, this.dataStore)
                    }
                }
                if ("pl_add_to_next" === o.itemId || "add_to_next" === o.itemId) {
                    this.onPlayingQueueCommit("updateplaylist", false, a, d, h + 1, 0, undefined, undefined, true)
                } else {
                    this.onPlayingQueueCommit("updateplaylist", false, a, d, -1, 0)
                }
                break;
            case "add_to_radio_favorite":
                var r = "[";
                for (k = 0; k < g.length; k++) {
                    r += String.format('{"title":"{0}","desc":"{1}","url":"{2}"},', g[k].get("title").replace(/\"/g, '\\"'), g[k].get("desc").replace(/\"/g, '\\"'), g[k].get("url").replace(/\"/g, '\\"'))
                }
                r = r.substr(0, r.length - 1) + "]";
                this.onInetRadioRequest(this._getUtils().getWebAPIParams({
                    api: "SYNO.AudioStation.Radio",
                    method: "updateradios",
                    container: "Favorite",
                    offset: -1,
                    limit: 0,
                    radios_json: r
                }));
                break;
            case "stop_sharing":
                this.onPlaylistDeleteRec(true);
                break;
            case "pl_delete":
            case "remove_from_playlist":
                this.onPlaylistDeleteRec();
                break;
            case "delete_radio":
                this.onInetRadioDeleteRec();
                break;
            case "edit":
                this.onInetRadioEditRec(q.container, l);
                break;
            case "get_song_sharing_link":
                this.onPublicSharing(g, true);
                break;
            case "public_share":
                this.onPublicSharing(g);
                break;
            case "pl_public_share":
                this.onGetSharingLink(l.get("name"), l.get("id"));
                break;
            case "pl_rename":
                this.onPlaylistEdit(l);
                break;
            case "pl_edit":
                this.onSmartPlaylistEdit(l);
                break;
            case "pl_copy_to_personal":
            case "pl_copy_to_shared":
                this.onPlaylistRequest(this._getUtils().getWebAPIParams({
                    api: "SYNO.AudioStation.Playlist",
                    method: "copytolibrary",
                    id: l.get("id"),
                    library: ("pl_copy_to_shared" === o.itemId) ? "shared" : "personal"
                }));
                break;
            case "song_info":
                if (this._getUtils().isInSearchAllCate()) {
                    this.onShowSongInfoEditor(g, this.searchAllSongStore)
                } else {
                    this.onShowSongInfoEditor(g, this.dataStore)
                }
                break;
            case "search_info_online":
                this.onShowSearchOnlineEditor(g);
                break;
            case "download_selected":
                a = SYNO.SDS.AudioStation.Utils.getSongIdList(g);
                var n;
                if (1 === g.length) {
                    n = g[0].get("path");
                    n = n.substr(n.lastIndexOf("/") + 1)
                } else {
                    n = this._getWindow().pathMgr.getHistoryInfo().text + ".zip"
                }
                this.onDownloadRequest({
                    songs: a,
                    filename: n
                });
                break;
            case "pl_download_playlist":
                d.push(this._getUtils().getPlaylistJsonObj(l.get("id")));
                this.onDownloadRequest({
                    playlists_json: d,
                    filename: l.get("name") + ".zip"
                });
                break;
            case "open_folder":
                this.onOpenContainingFolder(l);
                break;
            case "move_up":
            case "move_down":
                this.onPlaylistMoveRec(o.itemId);
                break;
            case "pin_selected_item":
                this.onPinItems(g);
                break;
            case "unpin_selected_item":
                this.onUnpinItems(g);
                break;
            case "renamepin":
                this.onEditPinItem(g[0]);
                break
        }
    },
    getNowPlayingId: function() {
        var b = -1;
        var a = this.playingStore.find("isNowPlaying", true);
        if (-1 !== a) {
            b = this.playingStore.getAt(a).get("id")
        }
        return b
    },
    updateSongRatingInDataStore: function(b, a) {
        this.dataStore.each(function(c) {
            if (b == c.get("id")) {
                c.data.song_rating = a;
                return false
            }
        }, this)
    },
    updateSongRatingInPlayingStore: function(b, a) {
        this.playingStore.each(function(c) {
            if (b === c.get("id")) {
                c.data.song_rating = a;
                return false
            }
        }, this)
    },
    onPlayingQueueCommit: function(a, c, b, d, g, f, i, j, h) {
        this.gUpdatingPlayingQueue = true;
        var e = this._getUtils().getWebAPIParams({
            api: this._getUtils().getPlayerAPI(),
            method: a,
            library: this._getWindow().getBrowseLibraryType(),
            id: this.gCurrentSelectPlayer,
            offset: g,
            limit: f,
            play: c
        });
        if ("updateplaylist" === a) {
            h = h === true;
            e.keep_shuffle_order = h
        }
        if (undefined !== i) {
            e.updated_index = i
        }
        if (b) {
            e.songs = b
        }
        if (d) {
            e.containers_json = Ext.util.JSON.encode(d)
        }
        if (undefined !== j) {
            e.force_reload = j
        }
        SYNO.SDS.AudioStation.DelayedTaskQueue.addTask(this.gCurrentSelectPlayer, e, this.onPlayingRequest, this, 1)
    },
    onPlayingRequest: function(b, a) {
        SYNO.SDS.AudioStation.Window.setStatusBusy();
        if (this.gIsOnMiniPlayerMode) {
            this.miniPlayer.setStatusBusy()
        }
        if ("__SYNO_WEB_PLAYER__" === this.gCurrentSelectPlayer) {
            this.audioWebPlayer.updatePlaylist(b.updated_index)
        }
        this._getUtils().isPlayingStoreLoading = true;
        Ext.Ajax.request({
            url: SYNO.SDS.AudioStation.Utils.getPlayerCGI(),
            params: b,
            callback: (a) ? a : this.onPlayingRequestDone,
            scope: this
        })
    },
    onPlayingRequestDone: function(e, h, d) {
        var c = null,
            g = _AST("common", "error_system"),
            f = this._getWindow().pathMgr.getHistoryInfo();
        SYNO.SDS.AudioStation.Window.clearStatusBusy();
        if (this.gIsOnMiniPlayerMode) {
            this.miniPlayer.clearStatusBusy()
        }
        this.gUpdatingPlayingQueue = false;
        if (!h) {
            this._getWindow().getMsgBox().alert(_AST("playlist", "playlist"), _AST("common", "error_system"));
            return
        }
        var b = Ext.util.JSON.decode(d.responseText);
        if (!b.success) {
            if (b.error && b.error.code) {
                var a = this._getUtils().getErrCodeMapping(b.error.code);
                g = this._getUtils().getErrMsgString(a);
                if ("AUDIO_ERR_TOO_MANY_SONGS" === a) {
                    g = String.format(g, SYNO.SDS.AudioStation.Define.MAX_SONG_LIMIT)
                }
                if ("AUDIO_ERR_DEVICE_NOT_EXISTS" === a) {
                    this.switchToStreamingMode()
                }
            }
            this._getWindow().getMsgBox().alert(_AST("playlist", "playlist"), g);
            if (-1 === g.indexOf(SYNO.SDS.AudioStation.Define.MAX_SONG_LIMIT)) {
                return
            }
        }
        if ("updateplaylist" === e.params.method && !e.params.force_reload && !e.params.play) {
            this._getUtils().updateSongsInStore(e, this.playingStore);
            if ("__SYNO_WEB_PLAYER__" === this.gCurrentSelectPlayer) {
                this.audioWebPlayer.setKeepShuffleOrder(e.params.keep_shuffle_order);
                this.audioWebPlayer.updatePreload()
            }
        } else {
            this.playingStore.reload()
        }
        if (e.params.play) {
            this.playingStore.on("load", function() {
                if (-1 === e.params.offset) {
                    this.audioPlayer.doJump(this.playingStore.getTotalCount() - 1)
                } else {
                    c = this.getSelectionRecords();
                    if (c.length && this.gPlaySelectID) {
                        this.gPlaySelectID = false;
                        this.audioPlayer.doJump(c[0].index - this.firstSongIdx + f.params.offset);
                        this.firstSongIdx = 0
                    } else {
                        this.audioPlayer.doJump(0)
                    }
                }
            }, this, {
                single: true
            })
        }
    },
    removeSelectFromPlayingQueue: function(d) {
        var f, a, e, b, k, j, h = this.getCurrentPlayingIndex(),
            c = this.getCurrentPlayingRecord(),
            g = this.audioWebPlayer.hasAddToNext() ? this.audioWebPlayer.getPlayIndex() : this.getRecentPlayIndex();
        this.playingStore.suspendEvents();
        for (f = 0; f < d.length; f++) {
            this.playingStore.remove(d[f])
        }
        this.playingStore.resumeEvents();
        b = d[0].index;
        k = d[d.length - 1].index - d.length;
        a = (k < b) ? "" : SYNO.SDS.AudioStation.Utils.getSongIdList(this.playingStore.getRange(b, k));
        e = d[d.length - 1].index - d[0].index + 1;
        j = this._getUtils().getUpdatedIndex(a, h, c, b);
        if ("__SYNO_WEB_PLAYER__" === this.gCurrentSelectPlayer && this.audioWebPlayer.isStop()) {
            if (b <= g && b + e > g) {
                this.audioWebPlayer.setPlaylistInit(true)
            } else {
                if (b < g && b + e <= g) {
                    this.audioWebPlayer.addIndex(-e)
                }
            }
        }
        this.onPlayingQueueCommit("updateplaylist", false, a, null, b, e, j)
    },
    onPlayingMenuClick: function(q, l) {
        var h, c, k = 0,
            g = this.getSelectionRecords(),
            p = this.playingStore.getCount(),
            j = null;
        if (this.gIsOnMiniPlayerMode) {
            j = this.miniPlayer.songPanel.getSelectionModel()
        } else {
            if (this.gIsOnLargePlayingQueue && !this.largePlayingQueuePanel.isInLyricsMode()) {
                j = this.largePlayingQueuePanel.songPanel.getSelectionModel()
            } else {
                j = this.cardPanel.listViewGrid.getSelectionModel()
            }
        }
        switch (q.itemId) {
            case "play":
                for (h = 0; h < p; h++) {
                    if (j.isSelected(h)) {
                        k = h;
                        break
                    }
                }
                k += this.playingStore.baseParams.offset;
                this.audioPlayer.doJump(k);
                break;
            case "remove_all":
                if ("__SYNO_WEB_PLAYER__" === this.gCurrentSelectPlayer) {
                    this.audioWebPlayer.setPlaylistInit(true)
                }
                this.onPlayingRequest(this._getUtils().getWebAPIParams({
                    api: this._getUtils().getPlayerAPI(),
                    method: "updateplaylist",
                    id: this.gCurrentSelectPlayer,
                    offset: 0,
                    limit: this.playingStore.getTotalCount(),
                    songs: "",
                    updated_index: -1
                }));
                break;
            case "playing_saveas":
                var a = {
                    id: "",
                    name: "",
                    isShared: false,
                    isPublicSharing: false
                };
                this.promptPlaylistDialog(a, function(i, b) {
                    c = SYNO.SDS.AudioStation.Utils.getSongIdList(g);
                    var e = this._getUtils().getWebAPIParams({
                        api: "SYNO.AudioStation.Playlist",
                        method: "saveplaying",
                        name: i,
                        library: (b) ? "shared" : "personal",
                        id: this.gCurrentSelectPlayer
                    });
                    this.onPlaylistRequest(e)
                }, this);
                break;
            case "download_playing":
                this.onDownloadRequest({
                    id: this.gCurrentSelectPlayer
                });
                break
        }
        if (!g.length) {
            return
        }
        switch (q.itemId) {
            case "playing_songinfo":
                this.onShowSongInfoEditor(g, this.playingStore);
                break;
            case "playing_search_info_online":
                this.onShowSearchOnlineEditor(g);
                break;
            case "download_selected":
                c = SYNO.SDS.AudioStation.Utils.getSongIdList(g);
                var o;
                if (1 === g.length) {
                    o = g[0].get("path");
                    o = o.substr(o.lastIndexOf("/") + 1)
                } else {
                    o = "audio.zip"
                }
                this.onDownloadRequest({
                    songs: c,
                    filename: o
                });
                break;
            case "remove_select":
                this.removeSelectFromPlayingQueue(g);
                break;
            case "playing_open_folder":
                this.onOpenContainingFolder(g[0]);
                break;
            case "playing_moveup":
            case "playing_movedown":
                var d = ("playing_moveup" === q.itemId) ? g[0].index - 1 : g[0].index,
                    s = ("playing_movedown" === q.itemId) ? g[g.length - 1].index + 1 : g[g.length - 1].index,
                    n = this.getCurrentPlayingIndex(),
                    f = this.getCurrentPlayingRecord(),
                    m, r;
                k = ("playing_moveup" === q.itemId) ? d : s - g.length + 1;
                r = this._getUtils().rearrangeStore(g, this.playingStore, k);
                c = this._getUtils().getSongIdList(this.playingStore.getRange(d, s));
                m = this._getUtils().getUpdatedIndex(c, n, f, d, s);
                this.onPlayingQueueCommit("updateplaylist", false, c, null, d, s - d + 1, m, r);
                break
        }
    },
    getSongRatingItemMenu: function() {
        if (this.songRatingMenu) {
            return this.songRatingMenu
        }
        this.songRatingMenu = new SYNO.ux.Menu({
            defaults: {
                scope: this,
                handler: this.onMenuApplySongRating
            },
            items: [{
                xtype: "menucheckitem",
                itemId: "unrating",
                text: _AST("common", "no_rating")
            }, "-", {
                xtype: "menucheckitem",
                itemId: "one_star",
                text: _AST("common", "one_star")
            }, {
                xtype: "menucheckitem",
                itemId: "two_star",
                text: _AST("common", "two_star")
            }, {
                xtype: "menucheckitem",
                itemId: "three_star",
                text: _AST("common", "three_star")
            }, {
                xtype: "menucheckitem",
                itemId: "four_star",
                text: _AST("common", "four_star")
            }, {
                xtype: "menucheckitem",
                itemId: "five_star",
                text: _AST("common", "five_star")
            }]
        });
        return this.songRatingMenu
    },
    getItemMenu: function() {
        if (this.itemMenu) {
            return this.itemMenu
        }
        this.itemMenu = new SYNO.ux.Menu({
            enableScrolling: false,
            cls: "syno-as-action-menu",
            defaults: {
                scope: this,
                handler: this.onItemMenuClick
            },
            items: [{
                itemId: "get_sharing_link",
                text: _AST("sharing", "get_sharing_link")
            }, {
                itemId: "get_song_sharing_link",
                text: _AST("sharing", "get_song_sharing_link")
            }, {
                itemId: "stop_sharing",
                text: _AST("sharing", "stop_sharing")
            }, {
                itemId: "save_search",
                text: _AST("playlist", "btn_save_search")
            }, {
                itemId: "random100_randomize",
                text: _AST("common", "btn_randomize_100")
            }, {
                itemId: "play_this_list",
                text: _AST("playlist", "btn_play_this_list")
            }, {
                itemId: "add_list_to_queue",
                text: _AST("playlist", "btn_append_this_list")
            }, {
                itemId: "add_list_to_next",
                text: _AST("playlist", "btn_insert_this_list")
            }, {
                xtype: "menuseparator",
                itemId: "item_sep_after_add_list_to_next"
            }, {
                itemId: "remove_missing",
                text: _AST("playlist", "btn_remove_missing")
            }, {
                xtype: "menuseparator",
                itemId: "item_sep_1"
            }, {
                itemId: "play_this",
                text: _AST("playlist", "btn_play_this")
            }, {
                itemId: "add_to_queue",
                text: _AST("playlist", "btn_append_selections")
            }, {
                itemId: "add_to_next",
                text: _AST("playlist", "btn_insert_selections")
            }, {
                xtype: "menuseparator",
                itemId: "item_sep_after_add_to_next"
            }, {
                itemId: "song_info",
                text: _AST("common", "song_information")
            }, {
                itemId: "search_info_online",
                text: _AST("common", "search_info_online")
            }, {
                itemId: "open_folder",
                text: _T("fbbrower", "open_folder")
            }, {
                itemId: "apply_song_rating",
                text: _AST("music", "header_rating"),
                hideOnClick: false,
                menu: this.getSongRatingItemMenu()
            }, {
                itemId: "delete_radio",
                text: _AST("common", "btn_delete")
            }, {
                itemId: "remove_from_playlist",
                text: _AST("playlist", "remove_action")
            }, {
                itemId: "edit",
                text: _AST("common", "btn_edit")
            }, {
                xtype: "menuseparator",
                itemId: "item_sep_2"
            }, {
                itemId: "add_to_radio_favorite",
                text: _AST("radio", "add_favorite")
            }, {
                itemId: "save_personal_playlist",
                text: _AST("playlist", "save_to_personal"),
                hideOnClick: false,
                menu: this.personalPLMenu = new SYNO.ux.Menu({
                    cls: "syno-as-save-pls-menu",
                    items: []
                })
            }, {
                itemId: "save_shared_playlist",
                text: _AST("playlist", "save_to_shared_v2"),
                hideOnClick: false,
                menu: this.sharePLMenu = new SYNO.ux.Menu({
                    cls: "syno-as-save-pls-menu",
                    items: []
                })
            }, {
                itemId: "save_to_personal_playlist_by_condition",
                text: _AST("playlist", "save_to_personal"),
                hideOnClick: false,
                menu: this.personalPlaylistByConditionMenu = new SYNO.ux.Menu({
                    cls: "syno-as-save-pls-menu",
                    items: []
                })
            }, {
                itemId: "save_to_shared_playlist_by_condition",
                text: _AST("playlist", "save_to_shared_v2"),
                hideOnClick: false,
                menu: this.sharedPlaylistByConditionMenu = new SYNO.ux.Menu({
                    cls: "syno-as-save-pls-menu",
                    items: []
                })
            }, {
                itemId: "download_playlist",
                text: _AST("playlist", "download_this_playlist")
            }, {
                itemId: "download_selected",
                text: _AST("playlist", "download_selected_songs")
            }, {
                itemId: "public_share",
                text: _AST("sharing", "share_to_public")
            }, {
                itemId: "move_up",
                text: _AST("playlist", "moveup")
            }, {
                itemId: "move_down",
                text: _AST("playlist", "movedown")
            }, {
                itemId: "pin_selected_item",
                text: _AST("common", "pin_selected_item")
            }, {
                itemId: "unpin_selected_item",
                text: _AST("common", "unpin_selected_item")
            }, {
                itemId: "pin_container",
                text: _AST("common", "pin")
            }, {
                itemId: "unpin_container",
                text: _AST("common", "unpin")
            }, {
                itemId: "renamepin",
                text: _AST("playlist", "renamepls")
            }, {
                itemId: "reorderpin",
                text: _AST("common", "reorder")
            }]
        });
        this.playlistStore = new Ext.data.Store({
            remoteSort: false,
            method: "POST",
            baseParams: this._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.Playlist",
                method: "list",
                library: "all",
                limit: 100000
            }),
            proxy: new Ext.data.HttpProxy({
                url: this._getUtils().getWebAPIURL("playlist.cgi")
            }),
            reader: new Ext.data.JsonReader({
                id: "id",
                root: "data.playlists",
                totalProperty: "data.total",
                fields: SYNO.SDS.AudioStation.Window.gFields
            }),
            listeners: {
                scope: this,
                load: this.onAfterLoadPlaylistStore
            }
        });
        this.playlistStore.load();
        return this.itemMenu
    },
    onAfterLoadPlaylistStore: function(b, a, c) {
        var d = this._getWindow().pathMgr.getHistoryInfo();
        b.removeAt(b.find("name", "__SYNO_AUDIO_SHARED_SONGS__"));
        if (d.params.keyword && this._getUtils().isInAllPlaylist()) {
            this.searchPlaylist(d.params.keyword)
        }
        this.resetSavePLSubmenu()
    },
    resetSavePLSubmenu: function() {
        var c, a, b = true,
            d = true;
        this.personalPLMenu.removeAll();
        this.personalPlaylistByConditionMenu.removeAll();
        this.sharePLMenu.removeAll();
        this.sharedPlaylistByConditionMenu.removeAll();
        this.personalPLMenu.addItem(new Ext.menu.Item({
            text: _AST("playlist", "newplaylist"),
            handler: this.onCreateAndSavePlaylist,
            scope: this,
            itemId: "new_personal"
        }));
        this.personalPlaylistByConditionMenu.addItem(new Ext.menu.Item({
            text: _AST("playlist", "newplaylist"),
            handler: this.onCreateAndSavePlaylistByCondition,
            scope: this,
            itemId: "new_personal_by_condition"
        }));
        this.sharePLMenu.addItem(new Ext.menu.Item({
            text: _AST("playlist", "newplaylist"),
            handler: this.onCreateAndSavePlaylist,
            scope: this,
            itemId: "new_shared"
        }));
        this.sharedPlaylistByConditionMenu.addItem(new Ext.menu.Item({
            text: _AST("playlist", "newplaylist"),
            handler: this.onCreateAndSavePlaylistByCondition,
            scope: this,
            itemId: "new_shared_by_condition"
        }));
        this.playlistStore.each(function(e) {
            if (SYNO.SDS.AudioStation.Utils.isSmartItem(e.get("id"))) {
                return true
            }
            c = new Ext.menu.Item({
                text: e.get("name"),
                handler: this.onSavePlaylist,
                scope: this,
                itemId: e.get("id")
            });
            a = new Ext.menu.Item({
                text: e.get("name"),
                handler: this.onSavePlaylistByCondition,
                scope: this,
                itemId: e.get("id")
            });
            if (this._getUtils().isPersonalItem(e.get("id"))) {
                if (b) {
                    this.personalPLMenu.addSeparator();
                    this.personalPlaylistByConditionMenu.addSeparator();
                    b = false
                }
                this.personalPLMenu.addItem(c);
                this.personalPlaylistByConditionMenu.addItem(a)
            } else {
                if (d) {
                    this.sharePLMenu.addSeparator();
                    this.sharedPlaylistByConditionMenu.addSeparator();
                    d = false
                }
                this.sharePLMenu.addItem(c);
                this.sharedPlaylistByConditionMenu.addItem(a)
            }
        }, this)
    },
    onCreateAndSavePlaylist: function(c, a) {
        var b = this.getSelectionRecords();
        this.onPlaylistNew(b, "new_shared" === c.itemId, false)
    },
    onCreateAndSavePlaylistByCondition: function(b) {
        var a = {
            id: "",
            name: "",
            isShared: "new_shared_by_condition" === b.itemId,
            isPublicSharing: false
        };
        this.promptPlaylistDialog(a, function(e, c) {
            var d = this._getUtils().getWebAPIParams({
                api: "SYNO.AudioStation.Playlist",
                method: "create",
                name: e,
                library: (c) ? "shared" : "personal"
            });
            this.onPlaylistRequest(d, function(g, h, f) {
                this.onPlaylistRequestDone(g, h, f);
                if (h && Ext.util.JSON.decode(f.responseText).success) {
                    this.addTrackToPlaylistByCondition(Ext.util.JSON.decode(f.responseText).data.id, this.getSelectionCondition())
                }
            })
        }, this)
    },
    onSavePlaylist: function(d, a) {
        var c = this.getSelectionRecords(),
            b = SYNO.SDS.AudioStation.Utils.getSongIdList(c);
        this.onPlaylistRequest(this._getUtils().getWebAPIParams({
            api: "SYNO.AudioStation.Playlist",
            method: "updatesongs",
            offset: -1,
            limit: 0,
            id: d.itemId,
            songs: b
        }))
    },
    getSelectionCondition: function() {
        var a = this.getSelectionRecords()[0];
        this._getWindow().pathMgr.getHistoryInfo().focusIdx = a.index;
        var b = this.prepareGotoNextParam(a, a.store.storeType);
        return this._getUtils().filterObjectByKey(b, ["album", "album_artist", "artist", "composer", "genre"])
    },
    onSavePlaylistByCondition: function(a) {
        this.addTrackToPlaylistByCondition(a.itemId, this.getSelectionCondition())
    },
    addTrackToPlaylistByCondition: function(a, b, c) {
        this.gHasReloadPlaylist = false;
        this.addTrackToPlaylistByConditionWithoutSetReloadFlag({
            conditions: b,
            skip_duplicated: c
        }, a)
    },
    addTrackToPlaylistByConditionWithoutSetReloadFlag: function(b, c) {
        var a = new SYNO.SDS.AudioStation.Webapi.Browse.Playlist();
        a.setFailureCallback(this.onAddTrackToPlaylistByConditionError.bind(this));
        a.addTrack(c, b.conditions, b.skip_duplicated)
    },
    onAddTrackToPlaylistByConditionError: function(a, b, e) {
        var d = this._getUtils().getErrCodeMapping(a);
        var c = e.id;
        delete e.id;
        delete e.skip_duplicated;
        if ("AUDIO_ERR_DUPLICATE_SONGS" === d) {
            this.onDuplicatedTracksError(this.addTrackToPlaylistByCondition.bind(this, c, e, false), this.addTrackToPlaylistByCondition.bind(this, c, e, true))
        } else {
            if ("AUDIO_ERR_PLAYLIST_NOT_EXISTS" === d && !this.gHasReloadPlaylist) {
                this.reloadPlaylistAndRetry(c, this.addTrackToPlaylistByConditionWithoutSetReloadFlag.bind(this, {
                    conditions: e
                }), this._getWindow().getMsgBox().alert.bind(this, _AST("playlist", "playlist"), this._getUtils().getErrMsgString(d)))
            } else {
                this._getWindow().getMsgBox().alert(_AST("playlist", "playlist"), this._getUtils().getErrMsgString(d))
            }
        }
    },
    getPlaylistMenu: function() {
        if (this.plMenu) {
            return this.plMenu
        }
        this.plMenu = new SYNO.ux.Menu({
            enableScrolling: false,
            cls: "syno-as-action-menu",
            defaults: {
                scope: this,
                handler: this.onItemMenuClick
            },
            items: [{
                itemId: "pl_play_this",
                text: _AST("playlist", "btn_play_this")
            }, {
                itemId: "pl_add_to_queue",
                text: _AST("playlist", "btn_append_this")
            }, {
                itemId: "pl_add_to_next",
                text: _AST("playlist", "btn_insert_this")
            }, {
                xtype: "menuseparator",
                itemId: "item_sep_after_pl_add_to_next"
            }, {
                itemId: "pl_public_share",
                text: _AST("sharing", "share_to_public")
            }, {
                itemId: "pl_delete",
                text: _AST("common", "btn_delete")
            }, {
                itemId: "pl_rename",
                text: _AST("playlist", "renamepls")
            }, {
                itemId: "pl_edit",
                text: _AST("common", "btn_edit")
            }, {
                itemId: "pl_download_playlist",
                text: _AST("playlist", "download_this_playlist")
            }, {
                itemId: "pl_copy_to_personal",
                text: _AST("playlist", "copy_to_personal")
            }, {
                itemId: "pl_copy_to_shared",
                text: _AST("playlist", "copy_to_shared_v2")
            }, {
                itemId: "pin_selected_item",
                text: _AST("common", "pin_selected_item")
            }, {
                itemId: "unpin_selected_item",
                text: _AST("common", "unpin_selected_item")
            }]
        });
        return this.plMenu
    },
    getPlayingQueueMenu: function() {
        if (this.nowPlayingMenu) {
            return this.nowPlayingMenu
        }
        this.nowPlayingMenu = new SYNO.ux.Menu({
            enableScrolling: false,
            cls: "syno-as-action-menu",
            defaults: {
                scope: this,
                handler: this.onPlayingMenuClick
            },
            items: [{
                itemId: "play",
                text: _AST("player", "play_btn_title")
            }, {
                itemId: "playing_saveas",
                text: _AST("player", "saveas_btn_title")
            }, {
                itemId: "save_personal_playlist",
                text: _AST("playlist", "save_to_personal"),
                hideOnClick: false,
                menu: this.personalPLMenu
            }, {
                itemId: "save_shared_playlist",
                text: _AST("playlist", "save_to_shared_v2"),
                hideOnClick: false,
                menu: this.sharePLMenu
            }, {
                itemId: "remove_select",
                text: _AST("player", "remove_btn_title")
            }, {
                itemId: "remove_all",
                text: _AST("player", "removeall_btn_title")
            }, "-", {
                itemId: "download_playing",
                text: _AST("playlist", "download_this_playlist")
            }, {
                itemId: "download_selected",
                text: _AST("playlist", "download_selected_songs")
            }, {
                itemId: "playing_songinfo",
                text: _AST("common", "song_information")
            }, {
                itemId: "playing_search_info_online",
                text: _AST("common", "search_info_online")
            }, {
                itemId: "playing_open_folder",
                text: _T("fbbrower", "open_folder")
            }, {
                itemId: "playing_apply_song_rating",
                text: _AST("music", "header_rating"),
                hideOnClick: false,
                menu: this.getSongRatingItemMenu()
            }, "-", {
                itemId: "playing_moveup",
                text: _AST("playlist", "moveup")
            }, {
                itemId: "playing_movedown",
                text: _AST("playlist", "movedown")
            }]
        });
        return this.nowPlayingMenu
    },
    IsRecordSelected: function(a) {
        var b = this.cardPanel.layout.activeItem;
        if (this.gIsOnMiniPlayerMode) {
            return this.miniPlayer.songPanel.getSelectionModel().isSelected(a)
        } else {
            if (this.gIsOnLargePlayingQueue) {
                return this.largePlayingQueuePanel.songPanel.getSelectionModel().isSelected(a)
            } else {
                if ("listViewPanel" === b.itemId) {
                    return this.cardPanel.listViewGrid.getSelectionModel().isSelected(a)
                } else {
                    if ("thumbViewPanel" === b.itemId) {
                        return this.cardPanel.thumbView.dataView.isSelected(a)
                    }
                }
            }
        }
    },
    clearSelections: function(a, b) {
        var c = this.cardPanel.layout.activeItem;
        if (this.gIsOnMiniPlayerMode) {
            this.miniPlayer.songPanel.getSelectionModel().clearSelections()
        } else {
            if (this.gIsOnLargePlayingQueue && !this.largePlayingQueuePanel.isInLyricsMode()) {
                this.largePlayingQueuePanel.songPanel.getSelectionModel().clearSelections()
            } else {
                if ("listViewPanel" === c.itemId) {
                    this.cardPanel.listViewGrid.getSelectionModel().clearSelections()
                } else {
                    if ("thumbViewPanel" === c.itemId) {
                        this.cardPanel.thumbView.dataView.clearSelections()
                    } else {
                        if ("searchAllPanel" === c.itemId) {
                            if (b) {
                                if ("artist" === a.dataType) {
                                    this.cardPanel.searchAllView.albumDataView.clearSelections();
                                    this.cardPanel.searchAllView.songListView.getSelectionModel().clearSelections()
                                } else {
                                    if ("album" === a.dataType) {
                                        this.cardPanel.searchAllView.artistDataView.clearSelections();
                                        this.cardPanel.searchAllView.songListView.getSelectionModel().clearSelections()
                                    } else {
                                        this.cardPanel.searchAllView.artistDataView.clearSelections();
                                        this.cardPanel.searchAllView.albumDataView.clearSelections()
                                    }
                                }
                            } else {
                                this.cardPanel.searchAllView.artistDataView.clearSelections();
                                this.cardPanel.searchAllView.albumDataView.clearSelections();
                                this.cardPanel.searchAllView.songListView.getSelectionModel().clearSelections()
                            }
                        }
                    }
                }
            }
        }
        return
    },
    selectRecords: function(b) {
        var c = this.cardPanel.layout.activeItem;
        var a;
        if (this.gIsOnMiniPlayerMode) {
            a = this.miniPlayer.songPanel.getSelectionModel().selectRecords(b)
        } else {
            if (this.gIsOnLargePlayingQueue && !this.largePlayingQueuePanel.isInLyricsMode()) {
                a = this.largePlayingQueuePanel.songPanel.getSelectionModel().selectRecords(b)
            } else {
                if ("listViewPanel" === c.itemId) {
                    a = this.cardPanel.listViewGrid.getSelectionModel().selectRecords(b)
                } else {
                    if ("thumbViewPanel" === c.itemId) {
                        a = this.cardPanel.thumbView.dataView.select(b)
                    }
                }
            }
        }
    },
    getSearchAllPanelSelection: function() {
        var a;
        if (this.cardPanel.searchAllView.artistDataView.getSelectionCount() > 0) {
            a = "artist"
        } else {
            if (this.cardPanel.searchAllView.albumDataView.getSelectionCount() > 0) {
                a = "album"
            } else {
                if (this.cardPanel.searchAllView.songListView.getSelectionModel().getSelections().length > 0) {
                    a = "song"
                }
            }
        }
        return a
    },
    getCurrentWindow: function() {
        if (this.gIsOnMiniPlayerMode) {
            return this.miniPlayer
        } else {
            return this._getWindow()
        }
    },
    getPinDataFromRecord: function(a) {
        var b = this.getPinArgumentsFromRecord(a);
        return this.getPinFromStore(b)
    },
    getPinDataFromInfo: function() {
        var a = this.getPinArgumentsFromInfo();
        return this.getPinFromStore(a)
    },
    getPinFromStore: function(b) {
        var c = this.pinStore.getRange();
        for (var a = 0; a < c.length; a++) {
            var d = c[a].data.criteria;
            delete d.path;
            delete d.type;
            delete d.library;
            delete d.name;
            if (b.type === c[a].data.type && SYNO.ux.Utils.checkObjectConsistency(b.criteria, d)) {
                return c[a].data
            }
        }
        return null
    },
    getPinArgumentsFromRecord: function(a) {
        var c = "";
        var e = {};
        var b = "";
        var d = this._getWindow().pathMgr.getHistoryInfo();
        if (undefined !== d.params.artist) {
            e.artist = d.params.artist
        }
        if (undefined !== d.params.genre) {
            e.genre = d.params.genre
        }
        if (undefined !== d.params.genre_filter) {
            e.genre_filter = d.params.genre_filter
        }
        if (undefined !== d.params.composer) {
            e.composer = d.params.composer
        }
        if (this._getUtils().isInLibraryFolder()) {
            c = "folder";
            e.folder = a.get("id");
            b = a.get("title")
        } else {
            if (this._getUtils().isInAlbumLayer() || (this._getUtils().isInSearchAllCate() && a.store.storeType === "album")) {
                c = "album";
                if ("AllMusic" !== a.get("id")) {
                    e.album = a.get("name");
                    e.album_artist = a.get("album_artist")
                }
                b = a.get("name")
            } else {
                if (this._getUtils().isInArtistList() || (this._getUtils().isInSearchAllCate() && a.store.storeType === "artist")) {
                    c = "artist";
                    if ("AllMusic" !== a.get("id")) {
                        e.artist = a.get("name")
                    }
                    b = a.get("name");
                    if ("" === b) {
                        b = _AST("common", "unknown_music_artist")
                    }
                } else {
                    if (this._getUtils().isInComposerList()) {
                        c = "composer";
                        e.composer = a.get("name");
                        b = a.get("name");
                        if ("" === b) {
                            b = _AST("common", "unknown_music_composer")
                        }
                    } else {
                        if (this._getUtils().isInGenreList()) {
                            c = "genre";
                            e.genre = a.get("name");
                            b = a.get("name");
                            if ("" === b) {
                                b = _AST("common", "unknown_music_genre")
                            }
                        } else {
                            if (this._getUtils().isInAllPlaylist()) {
                                c = "playlist";
                                e.playlist = a.get("id");
                                b = a.get("name")
                            }
                        }
                    }
                }
            }
        }
        if ("AllMusic" === a.get("id")) {
            if (this._getUtils().isInArtistList()) {
                b = _AST("common", "class_music_allalbum")
            } else {
                b = _AST("common", "class_music_allmusic")
            }
        }
        return {
            type: c,
            criteria: e,
            name: b
        }
    },
    getPinArgumentsFromInfo: function() {
        var b = "";
        var d = {};
        var a = "";
        var c = this._getWindow().pathMgr.getHistoryInfo();
        a = c.text;
        if ("playlist" === c.container_type) {
            b = "playlist";
            d.playlist = c.params.id
        } else {
            if ("folder" === c.container_type) {
                b = "folder";
                d.folder = c.params.id
            } else {
                if (SYNO.SDS.AudioStation.Utils._Random100_ID === c.container_type) {
                    b = "random_100"
                } else {
                    if (SYNO.SDS.AudioStation.Utils._RecentlyAdded_ID === c.container_type) {
                        b = "recently_added"
                    } else {
                        if (undefined !== c.params.artist) {
                            d.artist = c.params.artist
                        }
                        if (undefined !== c.params.genre) {
                            d.genre = c.params.genre
                        }
                        if (undefined !== c.params.genre_filter) {
                            d.genre_filter = c.params.genre_filter
                        }
                        if (undefined !== c.params.composer) {
                            d.composer = c.params.composer
                        }
                        if (undefined !== c.params.album) {
                            d.album = c.params.album
                        }
                        if (undefined !== c.params.album_artist) {
                            d.album_artist = c.params.album_artist
                        }
                        b = c.container_type
                    }
                }
            }
        }
        return {
            type: b,
            criteria: d,
            name: a
        }
    },
    onPinItems: function(b) {
        var a = [];
        for (var c = 0; c < b.length; c++) {
            a.push(this.getPinArgumentsFromRecord(b[c]))
        }
        this.sendPinRequest(a)
    },
    onPinContainer: function() {
        var a = [];
        a.push(this.getPinArgumentsFromInfo());
        this.sendPinRequest(a)
    },
    sendPinRequest: function(a) {
        SYNO.API.Request({
            api: "SYNO.AudioStation.Pin",
            method: "pin",
            version: "1",
            params: {
                items: a
            },
            callback: this.onPinItemsDone,
            scope: this
        })
    },
    onUnpinItems: function(a) {
        var c = [];
        for (var b = 0; b < a.length; b++) {
            if (this._getUtils().isAtHomepage() || this._getUtils().isAtPinList()) {
                c.push(a[b].id)
            } else {
                var d = this.getPinDataFromRecord(a[b]);
                if (null !== d) {
                    c.push(d.id)
                }
            }
        }
        this.sendUnpinRequest(c)
    },
    onUnpinContainer: function() {
        var a = [];
        var b = this.getPinDataFromInfo();
        if (null !== b) {
            a.push(b.id)
        }
        this.sendUnpinRequest(a)
    },
    sendUnpinRequest: function(a) {
        SYNO.API.Request({
            api: "SYNO.AudioStation.Pin",
            method: "unpin",
            version: "1",
            params: {
                items: a
            },
            callback: this.onUnpinItemsDone,
            scope: this
        })
    },
    onPinItemsDone: function(h, f, g, e) {
        if (!h) {
            var d = true;
            var c = false;
            for (var b = 0; b < f.errors.length; b++) {
                var a = this._getUtils().getErrCodeMapping(f.errors[b]);
                if ("AUDIO_ERR_NONE" !== a) {
                    if ("AUDIO_ERR_PIN_EXIST" !== a) {
                        d = false
                    }
                    if ("AUDIO_ERR_PIN_TARGET_NOT_EXIST" === a) {
                        c = true
                    }
                }
            }
            if (!d) {
                if (c) {
                    this._getWindow().getMsgBox().alert(this.title, _AST("common", "invalid_pin"))
                } else {
                    this._getWindow().getMsgBox().alert(this.title, _AST("common", "error_system"))
                }
            }
            return
        }
        this.pinStore.loadData(f, true)
    },
    onUnpinItemsDone: function(k, f, b, a) {
        var d, e, j;
        var c = [];
        var h = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.ListPanel");
        if (!k) {
            var g = true;
            for (d = 0; d < f.errors.length; d++) {
                j = this._getUtils().getErrCodeMapping(f.errors[d].error);
                if ("AUDIO_ERR_PIN_NOT_EXIST" === j) {
                    e = this.pinStore.getById(f.errors[d].id);
                    if (e) {
                        c.push(e)
                    }
                } else {
                    g = false
                }
            }
            if (!g) {
                this._getWindow().getMsgBox().alert(this.title, _AST("common", "error_system"))
            }
        } else {
            for (d = 0; d < f.items.length; d++) {
                e = this.pinStore.getById(f.items[d]);
                if (e) {
                    c.push(e)
                }
            }
            for (d = 0; d < f.errors.length; d++) {
                j = this._getUtils().getErrCodeMapping(f.errors[d].error);
                if ("AUDIO_ERR_PIN_NOT_EXIST" === j) {
                    e = this.pinStore.getById(f.errors[d].id);
                    if (e) {
                        c.push(e)
                    }
                }
            }
        }
        Ext.each(c, function(i) {
            var l = i.get("criteria").playlist;
            if ("playlist" !== i.get("type") || !l) {
                return true
            }
            if (-1 !== this.defaultPinItems.indexOf(l)) {
                return true
            }
            h.getNodeById(l).remove();
            delete this._getUtils().SEC_CFG[l];
            for (d = 0; d < this._getUtils().SEC_LIST.length; d++) {
                if (l === this._getUtils().SEC_LIST[d]) {
                    this._getUtils().SEC_LIST.splice(d, 1);
                    break
                }
            }
        }, this);
        h.doLayout();
        this.pinStore.remove(c)
    },
    onEditPinItem: function(a) {
        var b = {
            id: a.get("id"),
            name: a.get("name"),
            description: this._getUtils().getPinCriteriaDescription(a.data)
        };
        var c = new SYNO.SDS.AudioStation.PinEditDialog({
            owner: this._getWindow(),
            option: b,
            callback: this.onEditPinItemDone,
            callbackScope: this
        });
        c.show()
    },
    onEditPinItemDone: function(h, e, f, d) {
        if (!h) {
            var b = this._getUtils().getErrCodeMapping(e.code);
            if ("AUDIO_ERR_PIN_NOT_EXIST" === b) {
                this._getWindow().getMsgBox().alert(this.title, _AST("common", "pin_not_exist"))
            } else {
                this._getWindow().getMsgBox().alert(this.title, _AST("common", "error_system"))
            }
            return
        }
        var a = this.pinStore.getById(f.id);
        a.set("name", f.name);
        a.commit();
        if ("playlist" === a.get("type") && a.get("criteria").playlist) {
            var c = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.ListPanel"),
                g = a.get("criteria").playlist;
            if (-1 === this.defaultPinItems.indexOf(g)) {
                c.getNodeById(g).setText(f.name);
                this._getUtils().SEC_CFG[g][0].text = f.name
            }
        }
    },
    onReorderPinItem: function() {
        var a = new SYNO.SDS.AudioStation.PinReorderDialog({
            owner: this._getWindow(),
            callback: this.onReorderPinItemDone,
            callbackScope: this
        });
        a.show()
    },
    onReorderPinItemDone: function(d, b, c, a) {
        this.pinStore.reload()
    },
    createRatingFilterMenu: function() {
        var b = ["no_rating", "one_star", "two_star", "three_star", "four_star", "five_star"];
        this.ratingFilterMenu = new Ext.menu.Menu({
            xtype: "syno_menu",
            itemId: "menuRatingFilter",
            cls: "syno-ux-button-menu",
            hideOnClick: false,
            items: []
        });
        for (var a = 0; a < b.length; a++) {
            this.ratingFilterMenu.add({
                xtype: "menucheckitem",
                itemId: b[a],
                text: _AST("common", b[a]),
                hideOnClick: false,
                data: a,
                listeners: {
                    checkchange: this.onRatingFilterChange,
                    scope: this
                },
                scope: this
            })
        }
        return this.ratingFilterMenu
    },
    onRatingFilterChange: function(c, b) {
        var a = this.checkedRatingFilter;
        var d = {
            limit: this._getWindow().gridPagingSize
        };
        if (b) {
            a.push(c.data)
        } else {
            a.remove(c.data)
        }
        this.dataStore.removeAll();
        if (0 < a.length) {
            d.rating_filter = a.join(",");
            this.ratingFilterBtn.addClass("syno-as-rating-filter-on")
        } else {
            this.ratingFilterBtn.removeClass("syno-as-rating-filter-on")
        }
        this.dataStore.reload({
            params: d
        })
    },
    saveCurrentFoucusIndex: function() {
        var a = this.getSelectionRecords()[0];
        this._getWindow().pathMgr.getHistoryInfo().focusIdx = a.index
    }
});
Ext.ns("SYNO.SDS.AudioStation");
Ext.define("SYNO.SDS.AudioStation.HistoryMgr", {
    extend: "Ext.util.Observable",
    constructor: function(a) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.call(this, a);
        SYNO.SDS.AudioStation.Window.addPanelScope("SYNO.SDS.AudioStation.HistoryMgr", this);
        this.callParent([a]);
        this._init()
    },
    _init: function() {
        var a = SYNO.SDS.AudioStation.Utils;
        this.objHistory = {};
        Ext.each(a.SEC_LIST, function(b) {
            this.pushHistory(b, {
                index: 0
            }, 0)
        }, this)
    },
    pushHistory: function(a, d, b) {
        if (!this.objHistory[a]) {
            this.objHistory[a] = []
        }
        var c = this._getUtils().SEC_CFG[a];
        if (!c) {
            return false
        }
        if (!Ext.isDefined(b)) {
            b = 0
        }
        if (!c[b]) {
            return false
        }
        this.objHistory[a].push(Ext.apply(SYNO.Util.copy(c[b]), SYNO.Util.copy(d || {})));
        return true
    },
    clearHistory: function(a) {
        this.objHistory[a] = []
    },
    getCurHistoryLength: function(a) {
        return (!this.objHistory[a]) ? 0 : this.objHistory[a].length
    },
    getCardPanel: function() {
        return this._getWindow().getPanelScope("SYNO.SDS.AudioStation.CardPanel")
    },
    getCurId: function() {
        return this.curID || this._getUtils().SEC_LIST[0]
    },
    getHistoryInfo: function(b, a) {
        if (!Ext.isDefined(b)) {
            b = this.getCurId()
        }
        if (!Ext.isDefined(a)) {
            a = this.objHistory[b].length - 1
        }
        return this.objHistory[b][a]
    },
    getPrevHistoryInfo: function(b) {
        if (!Ext.isDefined(b)) {
            b = this.getCurId()
        }
        if (this.objHistory[b].length < 2) {
            return null
        }
        var a = this.objHistory[b].length - 2;
        return this.getHistoryInfo(b, a)
    },
    onSetGotoCfg: function(c, b) {
        this.oldID = this.curID || c;
        this.curID = c;
        if (Ext.isDefined(b)) {
            var a = [];
            Ext.each(this.objHistory[c], function(d) {
                if (d.index > b) {
                    return false
                }
                a.push(d);
                if (d.index === b) {
                    return false
                }
            });
            this.objHistory[c] = SYNO.Util.copy(a)
        }
    },
    setMainItem: function(f) {
        var c = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main"),
            a = this.objHistory[f][this.objHistory[f].length - 1].layoutCfg,
            d = this.getCardPanel().layout.activeItem,
            e = (d) ? d.itemId : "",
            b = this._getWindow().getActiveViewMode();
        if ("switchThumbMode" === b && !this._getUtils().isInAlbum() && this._getUtils()._PlayingQueue_ID !== this.curID && !this._getUtils().isAtHomepage() && !this._getUtils().isAtPinList()) {
            a = "thumbViewPanel"
        }
        if (SYNO.SDS.AudioStation.Utils.isInSearchAllCate()) {
            a = "searchAllPanel"
        }
        if (SYNO.SDS.AudioStation.Utils.isAtHomepage()) {
            a = "homepagePanel"
        }
        c.mainCardPanel.getLayout().setActiveItem("browse");
        if (e !== a) {
            this.getCardPanel().layout.setActiveItem(a)
        } else {
            this.getCardPanel().getComponent(a).fireEvent("activate")
        }
    },
    updatePathHistoryBar: function() {
        var b = 0,
            a = 0;
        var e = this.objHistory[this.curID];
        var c = [];
        if (0 === e.length) {
            return
        }
        var d = this.getHistoryInfo(this.curID, 0);
        c[a++] = {
            text: Ext.util.Format.htmlEncode(d.text),
            tooltip: Ext.util.Format.htmlEncode(d.text),
            callback: this.onClickHomeBtn.createDelegate(this)
        };
        for (b = 1; b < e.length; b++) {
            d = this.getHistoryInfo(this.curID, b);
            var f = d.text;
            if (d.params && d.params.text) {
                f = d.params.text
            }
            c[a++] = {
                text: Ext.util.Format.htmlEncode(Ext.util.Format.ellipsis(f, 100)),
                tooltip: Ext.util.Format.htmlEncode(f),
                callback: this.onClickBtn.createDelegate(this, [this.curID, d])
            }
        }
        this._getWindow().getPanelScope("SYNO.SDS.AudioStation.PathBar.Main").addPathButtons(c)
    },
    onClickBtn: function(b, a) {
        this.onGotoPanel(b, a.index)
    },
    onClickHomeBtn: function() {
        if (this.objHistory[this.curID].length <= 1) {
            return
        }
        this.onGotoPanel(this.curID, 0)
    },
    onGotoPanel: function(c, a) {
        var b = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main");
        SYNO.SDS.AudioStation.ImageLoadManager.get().clear();
        if (b.gIsOnLargePlayingQueue && b.largePlayingQueuePanel.isInLyricsMode()) {
            b.playerPanel.btnLyrics.toggle()
        }
        b.gIsOnLargePlayingQueue = false;
        this.onSetGotoCfg(c, a);
        this.setMainItem(c);
        if (SYNO.SDS.AudioStation.Utils.isInSearchAllCate()) {
            b.loadSearchAllStore()
        } else {
            if (SYNO.SDS.AudioStation.Utils.isAtHomepage() || this._getUtils().isAtPinList()) {
                b.loadPinStore()
            } else {
                b.loadCurrentStore()
            }
        }
        this.updatePathHistoryBar();
        this.updateSearchCateState();
        b.updateMainToolbar()
    },
    onGotoNext: function(c, b, a, e) {
        var d = this.curID;
        if (this.pushHistory(d, {
                text: c,
                index: this.objHistory[this.curID].length,
                params: SYNO.Util.copy(b || {}),
                container_type: e
            }, a)) {
            this.onGotoPanel(d)
        }
    },
    gotoCreatedInetRadio: function(b, f) {
        var e = ("UserDefined" === b) ? _AST("player", "player_source_userdefined") : _AST("player", "def_radio_station"),
            d = ("UserDefined" === b) ? this._getUtils()._Userdefined_ID : this._getUtils()._MyFavorite_ID,
            a = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.ListPanel");
        var c = this._getUtils().getWebAPIParams({
            api: "SYNO.AudioStation.Radio",
            method: "list",
            container: b,
            offset: f,
            library: this._getWindow().getBrowseLibraryType(),
            text: e
        });
        this.onSetGotoCfg(d, 0);
        a.selectItemById(d);
        this._getWindow().getPathMgr().objHistory[d][0] = Ext.apply(SYNO.Util.copy(this._getUtils().SEC_CFG[d][0]), SYNO.Util.copy({
            index: 0,
            params: SYNO.Util.copy(c || {})
        } || {}));
        SYNO.SDS.AudioStation.Window.getPathMgr().onGotoPanel(d)
    },
    gotoHomePage: function() {
        var b = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.ListPanel"),
            a = this._getUtils()._Homepage_ID;
        b.selectItemById(a);
        this.onGotoPanel(a, 0)
    },
    getMusicSearchCateParam: function(a) {
        var b = {};
        switch (a) {
            case "artist":
                b.api = "SYNO.AudioStation.Artist";
                b.text = _AST("common", "class_music_artist");
                break;
            case "album":
                b.api = "SYNO.AudioStation.Album";
                b.text = _AST("common", "class_music_album");
                break;
            case "composer":
                b.api = "SYNO.AudioStation.Composer";
                b.text = _AST("common", "class_music_composer");
                break;
            case "genre":
                b.api = "SYNO.AudioStation.Genre";
                b.text = _AST("common", "class_music_genre");
                break
        }
        b.method = "list";
        b.library = this._getWindow().getBrowseLibraryType();
        return b
    },
    gotoSearchCate: function(c) {
        var a = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.ListPanel"),
            b;
        delete c.text;
        if ("SYNO.AudioStation.Search" === c.api) {
            b = this._getUtils()._SearchResults_ID;
            a.clearSelectedItems()
        } else {
            if ("SYNO.AudioStation.Song" === c.api) {
                b = this._getUtils()._AllMusic_ID
            } else {
                if ("SYNO.AudioStation.Artist" === c.api) {
                    b = this._getUtils()._ByArtist_ID
                } else {
                    if ("SYNO.AudioStation.Album" === c.api) {
                        b = this._getUtils()._ByAlbum_ID
                    } else {
                        if ("SYNO.AudioStation.Composer" === c.api) {
                            b = this._getUtils()._ByComposer_ID
                        } else {
                            if ("SYNO.AudioStation.Genre" === c.api) {
                                b = this._getUtils()._ByGenre_ID
                            }
                        }
                    }
                }
            }
            a.selectItemById(b)
        }
        this._getWindow().getPathMgr().onSetGotoCfg(b, 0);
        this._getWindow().getPathMgr().objHistory[b][0] = Ext.apply(SYNO.Util.copy(this._getUtils().SEC_CFG[b][0]), SYNO.Util.copy({
            index: 0,
            params: SYNO.Util.copy(c || {})
        } || {}));
        SYNO.SDS.AudioStation.Window.getPathMgr().onGotoPanel(b)
    },
    gotoDetailSearchCate: function(b) {
        var a = this._getUtils()._SearchResults_ID;
        this._getWindow().getPathMgr().objHistory[a][1] = Ext.apply(SYNO.Util.copy(this._getUtils().SEC_CFG[a][1]), SYNO.Util.copy({
            index: 1,
            params: SYNO.Util.copy(b || {})
        } || {}));
        SYNO.SDS.AudioStation.Window.getPathMgr().onGotoPanel(a)
    },
    updateSearchCateState: function() {
        var b = this._getWindow().getPanelScope("SYNO.SDS.AudioStation.Main"),
            a = this.getHistoryInfo(),
            c = "cate_all";
        if (this._getUtils().isInShoutCast() || this._getUtils().isInShoutCastSearch()) {
            b.searchFieldMgr.setEmptyText(_AST("common", "search_shoutcast"));
            b.searchFieldMgr.resetSearch();
            b.searchFieldMgr.setCateBtnDisable(true)
        } else {
            if (this._getUtils().isInAllPlaylist() || this._getUtils().isInPlaylistLayer2()) {
                b.searchFieldMgr.setEmptyText(_AST("common", "search_playlist"));
                b.searchFieldMgr.resetSearch();
                b.searchFieldMgr.setCateBtnDisable(true)
            } else {
                if ("SYNO.AudioStation.Artist" === a.params.api) {
                    c = "cate_artist"
                } else {
                    if ("SYNO.AudioStation.Album" === a.params.api) {
                        c = "cate_album"
                    } else {
                        if ("SYNO.AudioStation.Composer" === a.params.api) {
                            c = "cate_composer"
                        } else {
                            if ("SYNO.AudioStation.Genre" === a.params.api) {
                                c = "cate_genre"
                            } else {
                                if ("search" === a.params.method && a.params.album !== a.params.title) {
                                    c = "cate_title"
                                }
                            }
                        }
                    }
                }
                b.searchFieldMgr.checkMenuItem(c);
                b.searchFieldMgr.setEmptyText(_AST("common", "btn_search"));
                b.searchFieldMgr.resetSearch();
                b.searchFieldMgr.setCateBtnDisable(false)
            }
        }
        if (a.params.keyword && "" !== a.params.keyword) {
            b.searchFieldMgr.setValue(a.params.keyword);
            b.searchFieldMgr.setTriggerVisible(true)
        }
    }
});
/**
 * @class SYNO.SDS.AudioStation.Application
 * @extends SYNO.SDS.AppInstance
 * AudioStation application class
 *
 */
Ext.define("SYNO.SDS.AudioStation.Application", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.AudioStation.AppWindow",
    constructor: function() {
        this.callParent(arguments)
    }
});
Ext.define("SYNO.SDS.AudioStation.AppWindow", {
    extend: "SYNO.SDS.AppWindow",
    gFields: [{
        name: "album",
        convert: function(a, b) {
            return b.album ? b.album : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.song_tag.album") ? b.additional.song_tag.album : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.songs.additional.song_tag.album") ? b.additional.songs.additional.song_tag.album : ""))
        }
    }, {
        name: "artist",
        convert: function(a, b) {
            return b.artist ? b.artist : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.song_tag.artist") ? b.additional.song_tag.artist : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.songs.additional.song_tag.artist") ? b.additional.songs.additional.song_tag.artist : (b.criteria && b.criteria.artist ? b.criteria.artist : "")))
        }
    }, {
        name: "album_artist",
        convert: function(a, b) {
            return b.album_artist ? b.album_artist : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.song_tag.album_artist") ? b.additional.song_tag.album_artist : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.songs.additional.song_tag.album_artist") ? b.additional.songs.additional.song_tag.album_artist : (b.criteria && b.criteria.album_artist ? b.criteria.album_artist : "")))
        }
    }, {
        name: "composer",
        convert: function(a, b) {
            return b.composer ? b.composer : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.song_tag.composer") ? b.additional.song_tag.composer : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.songs.additional.song_tag.composer") ? b.additional.songs.additional.song_tag.composer : ""))
        }
    }, {
        name: "genre",
        convert: function(a, b) {
            return b.genre ? b.genre : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.song_tag.genre") ? b.additional.song_tag.genre : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.songs.additional.song_tag.genre") ? b.additional.songs.additional.song_tag.genre : ""))
        }
    }, {
        name: "year",
        convert: function(a, b) {
            return b.year ? b.year : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.song_tag.year") ? b.additional.song_tag.year : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.songs.additional.song_tag.year") ? b.additional.songs.additional.song_tag.year : ""))
        }
    }, {
        name: "disc",
        convert: function(a, b) {
            return b.disc ? b.disc : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.song_tag.disc") ? b.additional.song_tag.disc : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.songs.additional.song_tag.disc") ? b.additional.songs.additional.song_tag.disc : ""))
        }
    }, {
        name: "track",
        convert: function(a, b) {
            return b.track ? b.track : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.song_tag.track") ? b.additional.song_tag.track : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.songs.additional.song_tag.track") ? b.additional.songs.additional.song_tag.track : ""))
        }
    }, {
        name: "comment",
        convert: function(a, b) {
            return b.comment ? b.comment : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.song_tag.comment") ? b.additional.song_tag.comment : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.songs.additional.song_tag.comment") ? b.additional.songs.additional.song_tag.comment : ""))
        }
    }, {
        name: "duration",
        convert: function(a, b) {
            return b.duration ? b.duration : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.song_audio.duration") ? b.additional.song_audio.duration : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.songs.additional.song_audio.duration") ? b.additional.songs.additional.song_audio.duration : ""))
        }
    }, {
        name: "bitrate",
        convert: function(a, b) {
            return b.bitrate ? b.bitrate : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.song_audio.bitrate") ? b.additional.song_audio.bitrate : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.songs.additional.song_audio.bitrate") ? b.additional.songs.additional.song_audio.bitrate : ""))
        }
    }, {
        name: "channels",
        convert: function(a, b) {
            return b.channels ? b.channels : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.song_audio.channel") ? b.additional.song_audio.channel : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.songs.additional.song_audio.channel") ? b.additional.songs.additional.song_audio.channel : ""))
        }
    }, {
        name: "size",
        convert: function(a, b) {
            return b.size ? b.size : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.song_audio.filesize") ? b.additional.song_audio.filesize : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.songs.additional.song_audio.filesize") ? b.additional.songs.additional.song_audio.filesize : ""))
        }
    }, {
        name: "sample",
        convert: function(a, b) {
            return b.sample ? b.sample : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.song_audio.frequency") ? b.additional.song_audio.frequency : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.songs.additional.song_audio.frequency") ? b.additional.songs.additional.song_audio.frequency : ""))
        }
    }, {
        name: "codec",
        convert: SYNO.SDS.AudioStation.Utils.createFieldConvertFunc("codec", "song_audio", "codec")
    }, {
        name: "container",
        convert: SYNO.SDS.AudioStation.Utils.createFieldConvertFunc("container", "song_audio", "container")
    }, {
        name: "support",
        convert: function(a, b) {
            return b.path ? SYNO.SDS.AudioStation.Utils.updateSupportField(b.path) : true
        }
    }, {
        name: "song_rating",
        convert: function(a, b) {
            return b.rating ? b.rating : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.song_rating.rating") ? b.additional.song_rating.rating : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.songs.additional.song_rating.rating") ? b.additional.songs.additional.song_rating.rating : ""))
        }
    }, {
        name: "avg_rating",
        convert: function(a, b) {
            return b.rating ? b.rating : (SYNO.SDS.AudioStation.Utils.testProperty(b, "additional.avg_rating.rating") ? b.additional.avg_rating.rating : 0)
        }
    }, "id", "path", "title", "name", "type", "library", "display_artist", "desc", "class", "cover", "isNowPlaying", "url", "sharing_status", "criteria"],
    gridPagingSize: 1000,
    constructor: function(a) {
        this.panelList = {};
        SYNO.SDS.AudioStation.Window = this;
        this.baseURL = this.jsConfig.jsBaseURL;
        var b = this.fillConfig(a);
        this.callParent([b]);
        this.setStatusBusy({
            text: _T("common", "loading")
        });
        SYNO.SDS.AudioStation.Utils.init(this.appInit, this)
    },
    fillConfig: function(a) {
        var b = {
            layout: "fit",
            cls: "syno-as-win",
            width: 980,
            height: 600,
            minWidth: 800,
            minHeight: 480,
            html: "",
            listeners: {
                scope: this,
                beforeshow: function() {
                    if (this.mainpanel && this.mainpanel.gIsOnMiniPlayerMode && this.mainpanel.miniPlayer) {
                        this.mainpanel.miniPlayer.show();
                        return false
                    }
                }
            }
        };
        Ext.apply(b, a);
        return b
    },
    appInit: function() {
        Ext.Ajax.request({
            url: SYNO.SDS.AudioStation.Utils.getWebAPIURL("info.cgi"),
            params: SYNO.SDS.AudioStation.Utils.getWebAPIParams({
                api: "SYNO.AudioStation.Info",
                method: "getinfo"
            }),
            callback: function(b, c, a) {
                if (c && a.responseText) {
                    SYNO.SDS.AudioStation.SessionData = Ext.util.JSON.decode(a.responseText).data;
                    if (soundManager) {
                        soundManager.setup({
                            preferFlash: false
                        })
                    }
                    if (SYNO.SDS.AudioStation.SessionData.has_music_share === false) {
                        this.getMsgBox().alert(_AST("common", "warning_no_music_share"), _AST("common", "warning_no_music_share_msg"))
                    }
                    this.delayConstructor()
                }
            },
            scope: this
        })
    },
    delayConstructor: function() {
        if (this.isDestroyed) {
            return
        }
        if (!this.rendered) {
            this.delayConstructor.defer(10, this, arguments);
            return
        }
        this.getPathMgr();
        var a = [];
        a.push(this.mainpanel = new SYNO.SDS.AudioStation.Main({
            header: false,
            itemId: "main"
        }));
        this.removeAll();
        this.add(a);
        this.doLayout();
        this.clearStatusBusy()
    },
    getPathMgr: function() {
        if (this.pathMgr) {
            return this.pathMgr
        }
        return (this.pathMgr = new SYNO.SDS.AudioStation.HistoryMgr())
    },
    addPanelScope: function(b, a) {
        this.panelList[b] = a
    },
    getPanelScope: function(a) {
        if (a in this.panelList) {
            return this.panelList[a]
        }
        return null
    },
    getActiveViewMode: function() {
        return this.appInstance.getUserSettings("ActivedViewPanel") || "switchListMode"
    },
    getBrowseLibraryType: function() {
        return SYNO.SDS.AudioStation.SessionData.enable_personal_library ? SYNO.SDS.AudioStation.SessionData.browse_personal_library : "shared"
    },
    onUpdateTitle: function(a) {
        var c = _AST("common", "class_audio_station");
        var b;
        if (a && "" !== a) {
            b = a + " - " + c
        } else {
            b = c
        }
        this.setTitle(b)
    },
    afterTagEditorApply: function(a) {
        this.mainpanel.afterTagEditorApply(a)
    },
    onOpen: function() {
        this.callParent(arguments)
    },
    setMaskOpacity: function(a) {
        if (this.modalWin.length) {
            a = 0
        }
        this.callParent(arguments);
        this.setMaskMsgVisible(a !== 0)
    }
});
Ext.define("SYNO.SDS.AudioStation.AlbumInfoEditorPanel", {
    extend: "SYNO.ux.Panel",
    albumCoverURL: undefined,
    predefinedGenreList: SYNO.SDS.AudioStation.PreDefinedGenre,
    comboWidth: 350,
    shortComboWidth: 123,
    constructor: function(a) {
        this.resultAlbumData = a.resultAlbumData;
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        var b = {
            region: "west",
            cls: "syno-as-songcover-left",
            border: false,
            items: [{
                xtype: "container",
                cls: "thumb-wrap",
                width: 230,
                items: [{
                    xtype: "container",
                    cls: "thumb",
                    items: [{
                        xtype: "container",
                        cls: "songcover-thumb-div",
                        overCls: "songcover-thumb-div-over",
                        items: [{
                            id: "album_cover",
                            xtype: "box",
                            autoEl: {
                                tag: "img"
                            }
                        }]
                    }, {
                        id: "bt_checkbox",
                        xtype: "container",
                        cls: "syno-as-thumb-bt",
                        items: [{
                            xtype: "box",
                            autoEl: {
                                tag: "img"
                            }
                        }]
                    }]
                }]
            }]
        };
        var d = new SYNO.ux.FormPanel({
            itemId: "albumInfo",
            region: "center",
            cls: "syno-as-songcover-right",
            border: false,
            labelWidth: 100,
            items: [{
                xtype: "syno_combobox",
                id: this.albumComboId = Ext.id(),
                width: this.comboWidth,
                name: "album",
                editable: true,
                triggerAction: "all",
                mode: "local",
                allowBlank: false,
                displayField: "display",
                valueField: "value",
                hideTrigger: true,
                validator: function(e) {
                    return !Ext.isEmpty(e.trim())
                },
                store: new Ext.data.ArrayStore({
                    fields: ["value", "display"]
                }),
                fieldLabel: _AST("music", "header_album")
            }, {
                xtype: "syno_combobox",
                id: this.albumArtistComboId = Ext.id(),
                width: this.comboWidth,
                name: "album_artist",
                editable: true,
                triggerAction: "all",
                mode: "local",
                displayField: "display",
                valueField: "value",
                hideTrigger: true,
                store: new Ext.data.ArrayStore({
                    fields: ["value", "display"]
                }),
                fieldLabel: _AST("music", "header_album_artist")
            }, {
                xtype: "syno_combobox",
                id: this.genreComboId = Ext.id(),
                width: this.shortComboWidth,
                name: "genre",
                editable: true,
                triggerAction: "all",
                mode: "local",
                displayField: "display",
                valueField: "value",
                hideTrigger: true,
                store: new Ext.data.ArrayStore({
                    fields: ["value", "display"]
                }),
                fieldLabel: _AST("music", "header_genre")
            }, {
                xtype: "syno_combobox",
                id: this.yearComboId = Ext.id(),
                width: this.shortComboWidth,
                name: "year",
                editable: true,
                triggerAction: "all",
                mode: "local",
                displayField: "display",
                valueField: "value",
                hideTrigger: true,
                store: new Ext.data.ArrayStore({
                    fields: ["value", "display"]
                }),
                fieldLabel: _AST("music", "header_year")
            }]
        });
        var c = {
            title: _AST("music", "header_album"),
            border: false,
            layout: "border",
            items: [b, d],
            listeners: {
                scope: this,
                buffer: 100,
                single: true,
                afterrender: this.onAfterRender
            }
        };
        Ext.apply(c, a);
        return c
    },
    onAfterRender: function() {
        this.initAlbumThumb();
        this.showAudioInfo(this.resultAlbumData[0]);
        this.setAlbumThumb(this.resultAlbumData[0])
    },
    showAudioInfo: function(c) {
        var a, b = [
            ["album", this.albumComboId, "string"],
            ["album_artist", this.albumArtistComboId, "string"],
            ["genre", this.genreComboId, "string"],
            ["year", this.yearComboId, "int"]
        ];
        for (a = 0; a < b.length; a++) {
            this.setupTagComboBox(b[a][0], b[a][1], b[a][2], c)
        }
    },
    setupTagComboBox: function(d, b, f, h) {
        var c, a = [],
            g, e;
        if (("string" == f && "" !== h[d]) || ("int" == f && 0 !== h[d])) {
            a.push([h[d], h[d]])
        }
        g = Ext.getCmp(b);
        e = (1 == a.length) ? a[0][0] : "";
        g.setValue(e);
        if (this.genreComboId == b) {
            for (c = 0; c < this.predefinedGenreList.length; c++) {
                a.push([this.predefinedGenreList[c], this.predefinedGenreList[c]])
            }
            g.setHideTrigger(false)
        }
        g.getStore().loadData(a);
        g.setValue(e)
    },
    onImageError: function(a) {
        Ext.fly(a).dom.src = SYNO.SDS.AudioStation.Utils.getImageByDisplay("audio_default_songs.png")
    },
    initAlbumThumb: function() {
        Ext.fly("album_cover").on("error", function a() {
            this.onImageError("album_cover");
            Ext.fly("album_cover").removeListener("error", a)
        }, this);
        Ext.fly("bt_checkbox").on("click", function b() {
            if (Ext.fly("bt_checkbox").hasClass("syno-as-thumb-bt-unchecked")) {
                Ext.fly("bt_checkbox").removeClass("syno-as-thumb-bt-unchecked")
            } else {
                Ext.fly("bt_checkbox").addClass("syno-as-thumb-bt-unchecked")
            }
        }, this)
    },
    setAlbumThumb: function(a) {
        Ext.fly("album_cover").dom.src = SYNO.SDS.AudioStation.Utils.getTrackCover({
            id: 'remote_{"cover":"' + a.cover + '"} '
        });
        this.albumCoverURL = a.cover
    }
});
Ext.define("SYNO.SDS.AudioStation.MenuCheckItem", {
    extend: "Ext.menu.CheckItem",
    xtype: "syno_as_menucheckitem",
    constructor: function(a) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.apply(this, arguments);
        this.visibleCols = a.visibleCols;
        this.callParent([a]);
        this.itemTpl = this.getTpl()
    },
    getTpl: function() {
        var d = "",
            b, c, a, e;
        d += '<a class="x-menu-list-item" hidefocus="true" unselectable="on">';
        d += '<div class="{cls} x-unselectable">';
        for (b = 0; b < this.visibleCols.length; b++) {
            d += "<span ";
            c = this.visibleCols[b].width - 8;
            d += ('style="width:' + c + 'px;"');
            d += 'class="{textColor} x-menu-item-text syno-as-search-result-menu-item"';
            a = this.visibleCols[b].dataIndex;
            e = Ext.util.Format.htmlEncode(this.data.json[a]);
            if (undefined !== e) {
                if ("duration" === a) {
                    e = this._getUtils().timeRenderer(e)
                }
                d += ('ext:qtip="' + e + '">');
                d += e
            } else {
                d += ">"
            }
            d += "</span>"
        }
        d += "</div>";
        d += "</a>";
        return new Ext.XTemplate(d)
    },
    getTemplateArgs: function() {
        return {
            cls: this.itemCls + (this.menu ? " x-menu-item-arrow" : "") + (this.cls ? " " + this.cls : ""),
            textColor: this.textColor || ""
        }
    }
});
Ext.define("SYNO.SDS.AudioStation.LocalTrackInfoPanel", {
    extend: "SYNO.ux.GridPanel",
    dataStore: undefined,
    constructor: function(a) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.apply(this, arguments);
        this.selectedRecords = a.selectedRecords;
        this.dataStore = this.createStore();
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        var b = {
            itemId: "localTrackInfoPanel",
            cls: "syno-as-setting-grid syno-as-search-result-local-grid",
            region: "west",
            width: 300,
            stripeRows: true,
            viewConfig: {
                autoFill: true,
                forceFit: true
            },
            colModel: new Ext.grid.ColumnModel({
                defaults: {
                    sortable: false
                },
                columns: [{
                    header: _AST("music", "header_track"),
                    dataIndex: "track",
                    renderer: this.tooltipRenderer,
                    hidden: true,
                    width: 50
                }, {
                    header: _AST("music", "header_title"),
                    dataIndex: "title",
                    renderer: this.titleRender.createDelegate(this),
                    width: 150
                }, {
                    header: _AST("music", "header_duration"),
                    dataIndex: "duration",
                    renderer: function(h, f, c, e, g, d) {
                        return this.tooltipRenderer(this._getUtils().timeRenderer(h))
                    },
                    width: 50,
                    scope: this
                }, {
                    header: _AST("music", "header_artist"),
                    dataIndex: "artist",
                    renderer: this.tooltipRenderer,
                    hidden: true,
                    width: 50
                }, {
                    header: _AST("music", "header_composer"),
                    dataIndex: "composer",
                    renderer: this.tooltipRenderer,
                    hidden: true,
                    width: 50
                }, {
                    header: _AST("music", "header_disc"),
                    dataIndex: "disc",
                    renderer: this.tooltipRenderer,
                    hidden: true,
                    width: 50
                }]
            }),
            store: this.dataStore,
            plugins: [SYNO.SDS.AudioStation.FocusGridPlugin]
        };
        Ext.apply(b, a);
        SYNO.LayoutConfig.fill(b);
        return b
    },
    createStore: function() {
        var a = new Ext.data.JsonStore({
            fields: SYNO.SDS.AudioStation.Window.gFields,
            autoDestroy: true
        });
        a.loadData(this.selectedRecords.map(function(b) {
            return b.json
        }));
        return a
    },
    titleRender: function(h, d, a, c, f, b) {
        var e = a.get("path"),
            g;
        g = h.trim();
        if (!g && e) {
            g = e.split("/").pop()
        }
        return this.tooltipRenderer(g)
    },
    tooltipRenderer: function(f, d, a, c, e, b) {
        if (f) {
            f = Ext.util.Format.htmlEncode(f);
            return String.format('<div ext:qtip="{0}">{0}</div>', f, f)
        }
        return ""
    }
});
Ext.define("SYNO.SDS.AudioStation.OnlineTrackInfoPanel", {
    extend: "SYNO.ux.GridPanel",
    dataStore: undefined,
    constructor: function(a) {
        SYNO.SDS.AudioStation.Utils._initWinWrappers.apply(this, arguments);
        this.resultAlbumData = a.resultAlbumData;
        this.selectedRecords = a.selectedRecords;
        this.launchWindow = a.launchWindow;
        this.dataStore = this.createStore();
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        var b = {
            itemId: "onlineTrackInfoPanel",
            cls: "syno-as-setting-grid syno-as-search-result-online-grid",
            region: "center",
            stripeRows: true,
            viewConfig: {
                autoFill: true,
                forceFit: true
            },
            colModel: new Ext.grid.ColumnModel({
                defaults: {
                    sortable: false
                },
                columns: [{
                    header: _AST("music", "header_track"),
                    dataIndex: "track",
                    name: "track",
                    renderer: this.tooltipRenderer,
                    width: 50
                }, {
                    header: _AST("music", "header_title"),
                    dataIndex: "title",
                    name: "title",
                    renderer: this.tooltipRenderer,
                    width: 150
                }, {
                    header: _AST("music", "header_duration"),
                    dataIndex: "duration",
                    name: "duration",
                    renderer: function(h, f, c, e, g, d) {
                        return this.tooltipRenderer(this._getUtils().timeRenderer(h))
                    },
                    width: 50,
                    scope: this
                }, {
                    header: _AST("music", "header_artist"),
                    dataIndex: "artist",
                    name: "artist",
                    renderer: this.tooltipRenderer,
                    hidden: true,
                    width: 50
                }, {
                    header: _AST("music", "header_composer"),
                    dataIndex: "composer",
                    renderer: this.tooltipRenderer,
                    hidden: true,
                    width: 50
                }, {
                    header: _AST("music", "header_disc"),
                    dataIndex: "disc",
                    name: "disc",
                    renderer: this.tooltipRenderer,
                    hidden: true,
                    width: 50
                }]
            }),
            store: this.dataStore,
            plugins: [SYNO.SDS.AudioStation.FocusGridPlugin],
            listeners: {
                cellclick: this.onGridCellClick
            }
        };
        Ext.apply(b, a);
        SYNO.LayoutConfig.fill(b);
        return b
    },
    onGridCellClick: function(b, i, c, g) {
        var h, f, d, a;
        this.checkedRow = i;
        f = Ext.fly(this.getView().getCell(i, 0)).getXY();
        d = this.getView().getGridInnerWidth() + 3;
        a = Ext.fly(this.getView().getCell(i, 0)).getHeight();
        h = this.getItemMenu(d);
        h.shadow = false;
        h.showAt([f[0] - 1, f[1] + a])
    },
    getItemMenu: function(c) {
        var b = [],
            d = [];
        d = this.getColumnModel().getColumnsBy(function(e) {
            return !e.hidden
        });
        b.push({
            xtype: "syno_as_menucheckitem",
            data: {
                json: {
                    track: "--",
                    title: _AST("common", "tag_not_apply")
                }
            },
            visibleCols: d
        });
        b.push({
            xtype: "menuseparator"
        });
        Ext.each(this.oriData, function(e) {
            b.push({
                xtype: "syno_as_menucheckitem",
                data: e,
                visibleCols: d,
                textColor: !Ext.isEmpty(e.id) ? "x-menu-item-blue-text" : ""
            })
        }, this);
        var a = new SYNO.ux.Menu({
            width: c,
            maxHeight: 500,
            cls: "syno-ux-button-menu syno-as-search-result-menu",
            items: b,
            defaults: {
                scope: this,
                xtype: "syno_as_menucheckitem",
                floating: true
            },
            listeners: {
                scope: this,
                click: this.onItemMenuClick
            }
        });
        return a
    },
    onItemMenuClick: function(f, c, d) {
        var b, a;
        b = this.dataStore.getAt(this.checkedRow);
        b.set("track", c.data.json.track ? c.data.json.track : "");
        b.set("title", c.data.json.title ? c.data.json.title : "");
        b.set("duration", c.data.json.duration ? c.data.json.duration : "");
        b.set("artist", c.data.json.artist ? c.data.json.artist : "");
        b.set("composer", c.data.json.composer ? c.data.json.composer : "");
        b.set("disc", c.data.json.disc ? c.data.json.disc : "");
        b.commit();
        Ext.each(this.oriData, function(e) {
            if (0 <= (a = e.id.indexOf(b.id))) {
                e.id.splice(a, 1)
            }
        }, this);
        a = f.items.indexOf(c);
        if (1 < a) {
            this.oriData[f.items.indexOf(c) - 2].id.push(b.id)
        }
    },
    createStore: function() {
        var b = this.resultAlbumData[0].release_url.split("/");
        var a = new SYNO.API.JsonStore({
            api: "SYNO.AudioStation.Tag",
            method: "getinfo",
            version: 1,
            appWindow: SYNO.SDS.AudioStation.Window,
            autoLoad: true,
            baseParams: {
                type: b[b.length - 2],
                id: parseInt(b[b.length - 1], 10)
            },
            root: "items",
            totalProperty: "total",
            fields: SYNO.SDS.AudioStation.Window.gFields,
            listeners: {
                exception: this.launchWindow.clearStatusBusy,
                load: this.adjustDataStore,
                scope: this
            }
        });
        return a
    },
    adjustDataStore: function(h, a, m) {
        var c, b, d, g, e, f = h.data.items,
            k = [],
            l = Ext.getCmp(this.launchWindow.albumInfoPanel.albumArtistComboId).getValue();
        if (f.length < this.selectedRecords.length) {
            for (c = f.length; c < this.selectedRecords.length; c++) {
                k.push(new Ext.data.Record({}))
            }
            h.add(k);
            for (c = 0; c < k.length; c++) {
                f[f.length - 1 - c].json = {}
            }
        }
        Ext.each(f, function(i) {
            if (undefined === i.json.artist) {
                i.json.artist = l;
                i.data.artist = l
            }
        }, this);
        this.oriData = f.map(function(i) {
            return {
                data: i.data,
                id: [],
                json: i.json
            }
        });
        for (c = 0; c < this.selectedRecords.length; c++) {
            d = this.selectedRecords[c].data;
            e = h.getAt(c);
            if (0 > (b = this.findSameTrack(d, f))) {
                e.set("track", "--");
                e.set("title", _AST("common", "tag_not_apply"));
                e.set("duration", "");
                e.set("artist", "");
                e.set("composer", "");
                e.set("disc", "")
            } else {
                g = f[b].json;
                e.set("track", g.track ? g.track : "");
                e.set("title", g.title ? g.title : "");
                e.set("duration", g.duration ? g.duration : "");
                e.set("artist", g.artist ? g.artist : "");
                e.set("composer", g.composer ? g.composer : "");
                e.set("disc", g.disc ? g.disc : "");
                this.oriData[b].id.push(e.id)
            }
            e.commit()
        }
        if (this.selectedRecords.length < f.length) {
            h.remove(h.getRange(this.selectedRecords.length))
        }
        this.launchWindow.clearStatusBusy()
    },
    findSameTrack: function(f, h) {
        var k = [],
            m, g, a, l, b, n = 0,
            d = -1,
            e, c;
        for (e = 0; e < h.length; e++) {
            m = h[e].json;
            g = f.duration - m.duration;
            if (m.duration) {
                if (5 >= Math.abs(g)) {
                    k.push(e)
                }
            } else {
                if (f.track && m.track) {
                    if (f.track === m.track) {
                        k.push(e)
                    }
                } else {
                    k.push(e)
                }
            }
        }
        if (Ext.isEmpty(k)) {
            return -1
        }
        for (e = 0; e < k.length; e++) {
            b = 0;
            m = h[k[e]].json;
            if (!m.title) {
                continue
            }
            if (m.title.length < f.title.length) {
                a = m.title.toLowerCase();
                l = f.title.toLowerCase()
            } else {
                a = f.title.toLowerCase();
                l = m.title.toLowerCase()
            }
            for (c = 0; c < a.length; c++) {
                if (-1 !== l.indexOf(a[c])) {
                    b++
                }
            }
            if (n < b) {
                n = b;
                if (0.65 < b / a.length) {
                    d = k[e]
                }
            }
        }
        return d
    },
    tooltipRenderer: function(f, d, a, c, e, b) {
        if (f) {
            f = Ext.util.Format.htmlEncode(f);
            return String.format('<div ext:qtip="{0}">{0}</div>', f, f)
        }
        return ""
    }
});
Ext.define("SYNO.SDS.AudioStation.TrackInfoEditorPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(a) {
        this.resultAlbumData = a.resultAlbumData;
        this.selectedRecords = a.selectedRecords;
        this.launchWindow = a.launchWindow;
        var b = this.fillConfig(a);
        this.callParent([b])
    },
    fillConfig: function(a) {
        this.localTrackInfoPanel = new SYNO.SDS.AudioStation.LocalTrackInfoPanel({
            selectedRecords: this.selectedRecords
        });
        this.onlineTrackInfoPanel = new SYNO.SDS.AudioStation.OnlineTrackInfoPanel({
            resultAlbumData: this.resultAlbumData,
            selectedRecords: this.selectedRecords,
            launchWindow: this.launchWindow
        });
        var b = {
            title: _AST("music", "header_track"),
            border: false,
            layout: "border",
            items: [this.localTrackInfoPanel, this.onlineTrackInfoPanel],
            listeners: {
                scope: this,
                buffer: 100,
                single: true
            }
        };
        Ext.apply(b, a);
        return b
    }
});
Ext.define("SYNO.SDS.AudioStation.SearchResultDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        var b = [];
        SYNO.SDS.AudioStation.Utils._initWinWrappers.apply(this, arguments);
        this.audioMain = SYNO.SDS.AudioStation.Window.getPanelScope("SYNO.SDS.AudioStation.Main");
        this.resultAlbums = a.resultAlbums;
        this.resultAlbumData = a.resultAlbumData;
        this.selectedRecords = a.selectedRecords;
        this.owner = a.owner;
        this.albumInfoPanel = new SYNO.SDS.AudioStation.AlbumInfoEditorPanel({
            resultAlbumData: this.resultAlbumData
        });
        this.trackInfoPanel = new SYNO.SDS.AudioStation.TrackInfoEditorPanel({
            resultAlbumData: this.resultAlbumData,
            selectedRecords: this.selectedRecords,
            launchWindow: this
        });
        b.push(this.albumInfoPanel);
        b.push(this.trackInfoPanel);
        this.tabPanel = new SYNO.ux.TabPanel({
            deferredRender: false,
            activeTab: 0,
            plain: true,
            items: b
        });
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(a) {
        var b = {
            title: _AST("common", "search_result"),
            layout: "fit",
            cls: "syno-as-dialog",
            width: 750,
            height: 500,
            minWidth: 650,
            minHeight: 500,
            closeAction: "hide",
            constrain: true,
            items: this.tabPanel,
            buttonAlign: "left",
            tbar: new SYNO.ux.Toolbar({
                cls: "syno-as-toolbar syno-as-search-result-toolbar",
                items: [{
                    xtype: "syno_combobox",
                    id: this.resultAlbumsComboId = Ext.id(),
                    width: 710,
                    name: "resultAlbums",
                    editable: false,
                    triggerAction: "all",
                    mode: "local",
                    allowBlank: false,
                    displayField: "value",
                    valueField: "value",
                    hideTrigger: true,
                    validator: function(c) {
                        return !Ext.isEmpty(c.trim())
                    },
                    store: new Ext.data.ArrayStore({
                        fields: ["value"]
                    }),
                    listeners: {
                        scope: this,
                        select: this.onComboBoxSel
                    }
                }]
            }),
            fbar: new SYNO.ux.Toolbar({
                cls: "x-statusbar",
                items: [{
                    xtype: "tbspacer",
                    width: 10
                }, {
                    xtype: "syno_button",
                    text: _AST("common", "btn_back"),
                    scope: this,
                    handler: function() {
                        this.audioMain.searchConditionEdit.show();
                        this.close()
                    }
                }, "->", {
                    xtype: "syno_button",
                    text: _AST("common", "btn_cancel"),
                    scope: this,
                    handler: function() {
                        this.close()
                    }
                }, {
                    xtype: "syno_button",
                    text: _AST("common", "btn_update"),
                    btnStyle: "blue",
                    disabled: _S("demo_mode"),
                    tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                    scope: this,
                    handler: function() {
                        this.updateAll()
                    }
                }]
            }),
            listeners: {
                scope: this,
                afterrender: this.onAfterRender
            }
        };
        Ext.apply(b, a);
        return b
    },
    onAfterRender: function(a) {
        var b;
        this.setStatusBusy({
            text: _T("common", "loading")
        });
        b = Ext.getCmp(this.resultAlbumsComboId);
        b.setHideTrigger(false);
        b.getStore().loadData(this.resultAlbums);
        b.setValue(this.resultAlbums[0])
    },
    onComboBoxSel: function(d, a, c) {
        var b = this.resultAlbumData[c].release_url.split("/");
        this.setStatusBusy({
            text: _T("common", "loading")
        });
        this.albumInfoPanel.showAudioInfo(this.resultAlbumData[c]);
        this.albumInfoPanel.setAlbumThumb(this.resultAlbumData[c]);
        this.trackInfoPanel.onlineTrackInfoPanel.dataStore.baseParams = {
            type: b[b.length - 2],
            id: parseInt(b[b.length - 1], 10)
        };
        this.trackInfoPanel.onlineTrackInfoPanel.dataStore.reload()
    },
    updateAll: function() {
        var k, b, d = [],
            e, l = ["title", "path", "album", "album_artist", "artist", "composer", "genre", "year", "disc", "track", "comment"],
            c = Ext.getCmp(this.albumInfoPanel.albumComboId).getValue(),
            j = Ext.getCmp(this.albumInfoPanel.albumArtistComboId).getValue(),
            f = Ext.getCmp(this.albumInfoPanel.genreComboId).getValue(),
            g = Ext.getCmp(this.albumInfoPanel.yearComboId).getValue(),
            h = "original_image",
            a = "";
        k = this.selectedRecords.map(function(i) {
            return SYNO.Util.copy(i.data)
        });
        b = this.trackInfoPanel.onlineTrackInfoPanel.getStore().getRange().map(function(i) {
            return i.data
        });
        for (e = 0; e < b.length; e++) {
            if (_AST("common", "tag_not_apply") === b[e].title && "--" === b[e].track) {
                k.splice(e, 1);
                b.splice(e, 1);
                e--
            }
        }
        if (Ext.isEmpty(k)) {
            this.close();
            return
        }
        Ext.each(k, function(m) {
            for (var i in m) {
                if (m.hasOwnProperty(i)) {
                    if (-1 === l.indexOf(i)) {
                        delete m[i]
                    }
                }
            }
        }, this);
        Ext.each(b, function(m) {
            for (var i in m) {
                if (m.hasOwnProperty(i)) {
                    if (-1 === l.indexOf(i)) {
                        delete m[i]
                    } else {
                        if (Ext.isArray(m[i])) {
                            m[i] = m[i].join(";")
                        }
                    }
                }
            }
            m.album = c;
            m.album_artist = j;
            m.genre = f.join(";");
            m.year = g
        }, this);
        if (!Ext.fly("bt_checkbox").hasClass("syno-as-thumb-bt-unchecked")) {
            a = this.albumInfoPanel.albumCoverURL;
            h = ("" !== a) ? "image_from_URL" : "no_image"
        }
        for (e = 0; e < b.length; e++) {
            Ext.apply(b[e], {
                audioInfos: [k[e]],
                coverType: h,
                coverPath: a
            });
            d.push(b[e])
        }
        this.setStatusBusy({
            text: _AST("common", "applying")
        });
        Ext.Ajax.request({
            url: this.owner.jsConfig.jsBaseURL + "/tagEditorUI/tag_editor.cgi",
            params: {
                action: "apply",
                data: Ext.encode(d)
            },
            method: "POST",
            callback: this.afterUpdateTags,
            scope: this
        })
    },
    afterUpdateTags: function(d, f, c) {
        this.clearStatusBusy();
        var e = "";
        if (f && c.responseText !== null) {
            var b = Ext.util.JSON.decode(c.responseText);
            if (b.success) {
                this.audioMain.afterTagEditorApply(b.files);
                if (0 !== b.write_fail_files.length) {
                    if (1 < b.files.length) {
                        e = String.format(_AST("editor", "error_write_fail"), b.write_fail_files.length)
                    } else {
                        var a = b.write_fail_files[0].error_reason;
                        if (a == "error_noprivilege") {
                            e = _T("error", "error_privilege_not_enough")
                        } else {
                            if (a == "error_fs_ro") {
                                e = _T("error", "error_fs_ro")
                            } else {
                                if (a == "error_file_not_exist") {
                                    e = _AST("editor", "error_file_not_exist")
                                } else {
                                    e = _AST("common", "error_system")
                                }
                            }
                        }
                    }
                } else {
                    this.close();
                    return
                }
            } else {
                if (b.error_msg == "upload_err_quota") {
                    e = _AST("common", "upload_err_quota")
                } else {
                    e = _AST("common", "error_system")
                }
            }
        } else {
            e = _AST("common", "error_system")
        }
        if (e) {
            this.getMsgBox().alert(this.title, e)
        }
    }
});
Ext.namespace("SYNO.SDS.AudioStation.SmartPlaylist.Utils");

function _ITUNESSTR(b, a) {
    if ("function" === typeof _AST && _AST("itunes", "itunes_after")) {
        return _AST(b, a)
    }
    if ("function" === typeof _IT && _IT("itunes", "itunes_after")) {
        return _IT(b, a)
    }
    return _T(b, a)
}
Ext.apply(SYNO.SDS.AudioStation.SmartPlaylist.Utils, {
    MAX_PLYLST_LENGTH: 250,
    MAX_ARTIST_LENGTH: 255,
    MAX_ALBUM_LENGTH: 254,
    MAX_ALBUM_ARTIST_LENGTH: 254,
    MAX_COMPOSER_LENGTH: 254,
    MAX_GENRE_LENGTH: 127,
    MAX_PATH_LENGTH: 1024,
    MAX_YEAR_LENGTH: 4,
    MAX_BITRATE_LENGTH: 4,
    MAX_DATE_ADDED_LENGTH: 10,
    ITUNES_MATCH_TYPE_AND: 1,
    ITUNES_MATCH_TYPE_OR: 2,
    ITUNES_TAG_ARTIST: 1,
    ITUNES_TAG_ALBUM: 2,
    ITUNES_TAG_GENRE: 3,
    ITUNES_TAG_PATH: 4,
    ITUNES_TAG_YEAR: 7,
    ITUNES_TAG_BITRATE: 9,
    ITUNES_TAG_DATE_ADDED: 10,
    ITUNES_TAG_ALBUM_ARTIST: 11,
    ITUNES_TAG_COMPOSER: 12,
    ITUNES_TAG_SONG_RATING: 13,
    TAG_VAL_SONG_RATING_NOT_RATING: "0",
    TAG_VAL_SONG_RATING_1_STAR: "1",
    TAG_VAL_SONG_RATING_2_STAR: "2",
    TAG_VAL_SONG_RATING_3_STAR: "3",
    TAG_VAL_SONG_RATING_4_STAR: "4",
    TAG_VAL_SONG_RATING_5_STAR: "5",
    ITUNES_OP_IS: 1,
    ITUNES_OP_NOT_IS: 2,
    ITUNES_OP_INCLUDES: 4,
    ITUNES_OP_NOT_INCLUDES: 8,
    ITUNES_OP_BEFORE: 16,
    ITUNES_OP_AFTER: 32,
    ITUNES_OP_EQUAL: 64,
    ITUNES_OP_NOT_EQUAL: 128,
    ITUNES_OP_GREATER: 256,
    ITUNES_OP_LESS: 512,
    ITUNES_OP_LAST: 1024,
    ITUNES_OP_NOT_LAST: 2048,
    ITUNES_SPACE_SELECT: 0,
    ITUNES_INTERVAL_DAYS: 1,
    ITUNES_INTERVAL_WEEKS: 2,
    ITUNES_INTERVAL_MONTHS: 4,
    ITUNES_PL_RULE_COUNT_MAX: 20,
    StrLenGet: function(b) {
        var c = 0;
        if (!b || b.length === 0) {
            return 0
        }
        for (var a = 0; a < b.length; a++) {
            if ((b.charCodeAt(a) >= 0) && (b.charCodeAt(a) <= 127)) {
                c += 1
            } else {
                if ((b.charCodeAt(a) >= 128) && (b.charCodeAt(a) <= 2047)) {
                    c += 2
                } else {
                    if ((b.charCodeAt(a) >= 2048) && (b.charCodeAt(a) <= 65535)) {
                        c += 3
                    } else {
                        if ((b.charCodeAt(a) >= 65536) && (b.charCodeAt(a) <= 131071)) {
                            c += 4
                        } else {
                            if ((b.charCodeAt(a) >= 2097152) && (b.charCodeAt(a) <= 67108863)) {
                                c += 5
                            } else {
                                if ((b.charCodeAt(a) >= 67108864) && (b.charCodeAt(a) <= 2147483647)) {
                                    c += 6
                                }
                            }
                        }
                    }
                }
            }
        }
        return c
    },
    IsValidStr: function(d, b) {
        if (!d || d.length === 0) {
            return true
        }
        for (var c = 0; c < d.length; c++) {
            for (var a = 0; a < b.length; a++) {
                if (d.charCodeAt(c) == b[a]) {
                    return false
                }
            }
        }
        return true
    },
    ValidatePLSName: function(c) {
        var a = [34, 92];
        var b = "";
        if (!c || c.trim().length === 0) {
            return _ITUNESSTR("itunes", "itunes_empty_pls")
        }
        if (!SYNO.SDS.AudioStation.SmartPlaylist.Utils.IsValidStr(c, a)) {
            b += String.format(_ITUNESSTR("itunes", "itunes_symbol_warn"), _ITUNESSTR("itunes", "itunes_playlist_name"), ' " \\ ')
        }
        if (SYNO.SDS.AudioStation.SmartPlaylist.Utils.MAX_PLYLST_LENGTH < SYNO.SDS.AudioStation.SmartPlaylist.Utils.StrLenGet(c)) {
            if (b.length > 0) {
                b += "<br>"
            }
            b += "[" + _ITUNESSTR("itunes", "itunes_playlist_name") + "] " + _ITUNESSTR("itunes", "itunes_length_warn")
        }
        return b
    },
    IsDate: function(c) {
        var d = 0;
        var a = 0;
        var b = /(\d{4})\-(\d{2})\-(\d{2})/;
        if (!c || c.length != 10 || !c.match(b)) {
            return false
        }
        d = parseInt(c.substring(5, 7), 10);
        a = parseInt(c.substring(8, 10), 10);
        if (d > 13) {
            return false
        }
        if (a > 31) {
            return false
        }
        return true
    },
    tagRender: function(a) {
        switch (a) {
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_TAG_ARTIST:
                return _ITUNESSTR("itunes", "itunes_artist");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_TAG_ALBUM:
                return _ITUNESSTR("itunes", "itunes_album");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_TAG_ALBUM_ARTIST:
                return _ITUNESSTR("itunes", "itunes_album_artist");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_TAG_COMPOSER:
                return _ITUNESSTR("itunes", "itunes_composer");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_TAG_GENRE:
                return _ITUNESSTR("itunes", "itunes_genre");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_TAG_PATH:
                return _ITUNESSTR("itunes", "itunes_path");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_TAG_YEAR:
                return _ITUNESSTR("itunes", "itunes_year");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_TAG_BITRATE:
                return _ITUNESSTR("itunes", "itunes_bitrate");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_TAG_DATE_ADDED:
                return _ITUNESSTR("itunes", "itunes_date_added");
            default:
                return a
        }
    },
    opRender: function(a) {
        switch (a) {
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_OP_IS:
                return _ITUNESSTR("itunes", "itunes_is");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_OP_NOT_IS:
                return _ITUNESSTR("itunes", "itunes_is_not");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_OP_INCLUDES:
                return _ITUNESSTR("itunes", "itunes_contains");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_OP_NOT_INCLUDES:
                return _ITUNESSTR("itunes", "itunes_not_contains");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_OP_BEFORE:
                return _ITUNESSTR("itunes", "itunes_before");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_OP_AFTER:
                return _ITUNESSTR("itunes", "itunes_after");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_OP_EQUAL:
                return _ITUNESSTR("itunes", "itunes_is");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_OP_NOT_EQUAL:
                return _ITUNESSTR("itunes", "itunes_is_not");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_OP_GREATER:
                return _ITUNESSTR("itunes", "itunes_greater");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_OP_LESS:
                return _ITUNESSTR("itunes", "itunes_less");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_OP_LAST:
                return _ITUNESSTR("itunes", "itunes_last");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_OP_NOT_LAST:
                return _ITUNESSTR("itunes", "itunes_not_last");
            default:
                return a
        }
    },
    intervalRender: function(a) {
        switch (a) {
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_SPACE_SELECT:
                return "";
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_INTERVAL_DAYS:
                return _ITUNESSTR("itunes", "itunes_days");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_INTERVAL_WEEKS:
                return _ITUNESSTR("itunes", "itunes_weeks");
            case SYNO.SDS.AudioStation.SmartPlaylist.Utils.ITUNES_INTERVAL_MONTHS:
                return _ITUNESSTR("itunes", "itunes_months");
            default:
                return a
        }
    },
    escapeComma: function(a) {
        return a.replace(/\,/g, "\\,")
    }
});
