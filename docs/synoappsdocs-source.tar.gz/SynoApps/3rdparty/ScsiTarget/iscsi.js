/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function asyncGeneratorStep(e, t, i, n, s, a, o) {
    try {
        var r = e[a](o),
            l = r.value
    } catch (e) {
        return void i(e)
    }
    r.done ? t(l) : Promise.resolve(l).then(n, s)
}

function _asyncToGenerator(e) {
    return function() {
        var t = this,
            i = arguments;
        return new Promise(function(n, s) {
            function a(e) {
                asyncGeneratorStep(r, n, s, a, o, "next", e)
            }

            function o(e) {
                asyncGeneratorStep(r, n, s, a, o, "throw", e)
            }
            var r = e.apply(t, i);
            a(void 0)
        })
    }
}

function _toConsumableArray(e) {
    return _arrayWithoutHoles(e) || _iterableToArray(e) || _nonIterableSpread()
}

function _nonIterableSpread() {
    throw new TypeError("Invalid attempt to spread non-iterable instance")
}

function _iterableToArray(e) {
    if (Symbol.iterator in Object(e) || "[object Arguments]" === Object.prototype.toString.call(e)) return Array.from(e)
}

function _arrayWithoutHoles(e) {
    if (Array.isArray(e)) {
        for (var t = 0, i = new Array(e.length); t < e.length; t++) i[t] = e[t];
        return i
    }
}
Ext.ns("SYNO.SDS.iSCSI.Utils"), SYNO.SDS.iSCSI.Utils = function() {
    var e = SYNO.SDS.Utils.StorageUtils.UiRenderHelper;
    return {
        SpaceIDParser: function(e) {
            return e ? SYNO.SDS.Utils.StorageUtils.SpaceIDParser(e) : ""
        },
        TargetStatusRender: e.TargetStatusRender,
        SizeRender: e.SizeRender,
        LunStatusRender: e.LunStatusRender,
        PercentRender: e.PercentRender,
        StatusNameRender: function(t) {
            var i = SYNO.SDS.iSCSI.LUN.Status[t];
            return void 0 !== i ? String.format('<span class="{0}">{1}</span>', i.color, i.text) : e.StatusNameRender(t)
        },
        RootPathParser: function(e) {
            var t = "";
            return 0 === e.search("/volume") && (t = e.replace("/volume", "volume_")), this.SpaceIDParser(t)
        },
        SetActionLunParentStatus: function(e) {
            var t = function(e, t) {
                var i;
                return Ext.each(e, function(e) {
                    if (t === e.iscsi_lun.lid) return i = e, !1
                }), i
            };
            Ext.each(e, function(i) {
                var n;
                "cloning" === i.status && (n = t(e, i.iscsi_lun.parent.plid), Ext.isDefined(n) && !n.is_actioning && (n.status = "using", n.is_actioning = !0))
            })
        },
        LunParentRender: function(e, t) {
            var i, n, s, a;
            return !(!Ext.isObject(t.parent) || t.lid === t.parent.plid) && (i = e.getMatched(function() {
                if (this.get("iscsi_lun").lid === t.parent.plid) return !0
            }), 0 !== i.length && (n = i[0].get("iscsi_lun"), s = n.name, 0 === t.parent.psid ? s : (Ext.each(n.snapshots, function(e) {
                if (t.parent.psid === e.sid) return a = e.name, !1
            }), a ? s + " / " + a : s)))
        },
        SupportSnapshot: function() {
            return "yes" === _D("support_vaai", "no")
        },
        renderPermission: function(e) {
            var t = {
                rw: SYNO.SDS.iSCSI.Utils.T("share", "share_permission_writable"),
                r: SYNO.SDS.iSCSI.Utils.T("share", "share_permission_readonly"),
                "-": SYNO.SDS.iSCSI.Utils.T("share", "share_permission_none")
            };
            return e in t ? t[e] : e
        },
        renderIQN: function(e, t) {
            var i = SYNO.SDS.iSCSI.TARGET.DefaultIQN === e ? SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_masking_default") : e;
            return t && (t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(i) + '"'), i
        },
        stringNaturalSort: function(e, t) {
            return Ext.data.SortTypes.asNaturalUCString(e).localeCompare(Ext.data.SortTypes.asNaturalUCString(t))
        },
        FCStatusRender: function(t) {
            var i = SYNO.SDS.SAN.FC.Status[t];
            return void 0 !== i ? String.format('<span class="{0}">{1}</span>', i.color, i.text) : e.StatusNameRender(t)
        }
    }
}(), SYNO.SDS.iSCSI.Utils.ISCSITRG_UNIT_GB = 1073741824, SYNO.SDS.iSCSI.Utils.T = function(e, t) {
    return _TT("SYNO.SDS.iSCSI.Application", e, t) ? _TT("SYNO.SDS.iSCSI.Application", e, t) : _TT("SYNO.SDS.DisasterRecovery.Application", e, t) ? _TT("SYNO.SDS.DisasterRecovery.Application", e, t) : _T(e, t) ? _T(e, t) : e + ":" + t
}, SYNO.SDS.iSCSI.Utils.TipRender = function(e, t) {
    return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(e)) + '"', Ext.util.Format.htmlEncode(e)
}, SYNO.SDS.iSCSI.Utils.EmptyMsgRender = function(e) {
    return '<div class="iscsi-empty-text-inner-wrap"><div class="iscsi-empty-text-icon"></div><div class="iscsi-empty-text">' + e + "</div></div>"
}, SYNO.SDS.iSCSI.Utils.EmptyPlanTextRender = function(e) {
    return '<div class="iscsi-empty-text-inner-wrap"><div class="iscsi-empty-text">' + e + "</div></div>"
}, SYNO.SDS.iSCSI.Utils.lunCanSnapshot = function(e) {
    var t;
    return !!e && (!e.get("is_actioning") && ("crashed" !== (t = e.get("status")) && "unavailabling" !== t && (!0 === e.get("support_snapshot") && ("be_cloning" === t || "using" === t || "snapshotting" === t || !e.get("is_actioning")))))
}, SYNO.SDS.iSCSI.Utils.UIRender = function() {
    return {
        getManagedByRender: function(e) {
            return e ? "Openstack Cinder" : "DSM"
        },
        planNextTimeRender: function(e, t, i) {
            var n = SYNO.SDS.iSCSI.Utils,
                s = n.GetTime(e - t, !0);
            return SYNO.SDS.iSCSI.invalid === s ? s : String.format(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "next_time_msg"), n.TextRender(s.value, i), s.unit)
        },
        lockIconRenderer: function(e) {
            return !0 === e ? '<div class="iscsi-snapshot-lock-icon"></div>' : ""
        }
    }
}(), SYNO.SDS.iSCSI.Utils.UpdateGridCheckMsg = function(e, t, i) {
    t.forEach(function(t, n) {
        var s = SYNO.SDS.Utils.GetFeasibilityCheckMsg(t);
        0 === n ? i.appendSub(e, s) : i.appendSub("", s)
    })
}, SYNO.SDS.iSCSI.Utils.CheckMsg = function(e, t, i, n) {
    var s, a, o = SYNO.SDS.iSCSI.Utils;
    if (e && e[i])
        for (s in e[i]) e[i].hasOwnProperty(s) && (a = s, t ? e[i][s].hard && o.UpdateGridCheckMsg(a, e[i][s].hard, n) : e[i][s].soft && o.UpdateGridCheckMsg(a, e[i][s].soft, n))
}, SYNO.SDS.iSCSI.Utils.CheckFailedMsg = function(e) {
    var t, i, n = "pass";
    if (!e) return n;
    for (t in e)
        if (e.hasOwnProperty(t)) {
            if ("hard_failed" === n) break;
            for (i in e[t])
                if (e[t].hasOwnProperty(i)) {
                    if (e[t][i].hard) {
                        n = "hard_failed";
                        break
                    }
                    e[t][i].soft && (n = "soft_failed")
                }
        } return n
}, SYNO.SDS.iSCSI.Utils.fillGridByFeasMsgWithType = function(e, t, i) {
    var n = SYNO.SDS.iSCSI.Utils,
        s = !1,
        a = {},
        o = "";
    if (a.iscsiObjs = {}, "feasibility_hard" === i ? (s = !0, o = "hard") : o = "soft", e.hasOwnProperty(i))
        for (var r = e[i], l = 0; l < r.length; l++) a.iscsiObjs[r[l].name] = {}, a.iscsiObjs[r[l].name][o] = r[l].check_message;
    var S = Object.keys(a.iscsiObjs);
    "lun" === e.objType ? t.append("LUN", S.join(", ")) : "target" === e.objType && t.append("iSCSI Target", S.join(", ")), n.CheckMsg(a, s, "iscsiObjs", t)
}, SYNO.SDS.iSCSI.Utils.fillGridByFeasMsg = function(e, t) {
    e.hasOwnProperty("feasibility_soft") ? SYNO.SDS.iSCSI.Utils.fillGridByFeasMsgWithType(e, t, "feasibility_soft") : e.hasOwnProperty("feasibility_hard") && SYNO.SDS.iSCSI.Utils.fillGridByFeasMsgWithType(e, t, "feasibility_hard")
}, SYNO.SDS.iSCSI.Utils.ReportWebapiFailure = function(e, t) {
    var i = SYNO.SDS.iSCSI.Utils.T("error", "error_subject");
    if (void 0 !== t && void 0 !== e)
        if (i = SYNO.SDS.iSCSI.Utils.API.getErrorString(t), e.getMsgBox) e.getMsgBox().alert(e.title, i);
        else {
            if (!e.owner.getMsgBox) throw Error("Not found 'getMsgBox'");
            e.owner.getMsgBox().alert(e.title, i)
        }
}, SYNO.SDS.iSCSI.Utils.HARemoteCheckErrParsing = function(e) {
    var t, i = [];
    _S("ha_running") && void 0 !== e && e.hasOwnProperty("errors") && (t = e.errors, void 0 !== t.ha_remote_empty_err_disks && 0 < t.ha_remote_empty_err_disks.size() && i.push(String.format(_TT("SYNO.SDS.HA.Instance", "wizard", "error_disk_empty"), t.ha_remote_empty_err_disks.map(SYNO.SDS.HA.HADiskIndexRenderer).join(", "))), void 0 !== t.ha_remote_size_err_disks && 0 < t.ha_remote_size_err_disks.size() && i.push(String.format(_TT("SYNO.SDS.HA.Instance", "wizard", "error_disk_size"), t.ha_remote_size_err_disks.map(SYNO.SDS.HA.HADiskIndexRenderer).join(", "))), void 0 !== t.ha_remote_type_err_disks && 0 < t.ha_remote_type_err_disks.size() && i.push(String.format(_TT("SYNO.SDS.HA.Instance", "wizard", "error_disk_type"), t.ha_remote_type_err_disks.map(SYNO.SDS.HA.HADiskIndexRenderer).join(", "))), void 0 !== t.ha_remote_log_sect_size_err_disks && 0 < t.ha_remote_log_sect_size_err_disks.size() && i.push(String.format(_TT("SYNO.SDS.HA.Instance", "wizard", "error_disk_log_sect_size"), t.ha_remote_log_sect_size_err_disks.map(SYNO.SDS.HA.HADiskIndexRenderer).join(", "))), !0 === t.ha_remote_offline && i.push(_TT("SYNO.SDS.HA.Instance", "ui", "error_passive_not_online")), !0 === t.ha_remote_space_failed && i.push(_TT("SYNO.SDS.HA.Instance", "wizard", "error_passive_space_unmatched")), !0 === t.ha_remote_memory_size_mismatch && i.push(_TT("SYNO.SDS.HA.Instance", "ui", "error_fcache_memsize")), e.text = i.join("<br><br>"), "" === e.text && (e.text = SYNO.SDS.iSCSI.Utils.T("error", "error_error_system")))
}, SYNO.SDS.iSCSI.Utils.getLUNNameByUUID = function(e, t) {
    var i = t.find(function(t) {
        return t.get("uuid") === e
    });
    return i ? i.get("name") : e
}, SYNO.SDS.iSCSI.Utils.getLUNPoolInfo = function(e, t) {
    var i = e.find(function(e) {
        return -1 < t.search(e.space_path)
    });
    return void 0 === i ? {
        pool_id: "",
        status: "unknown",
        used_size: 0,
        total_size: 0
    } : {
        pool_id: i.id,
        status: i.status,
        used_size: i.size.used,
        total_size: i.size.total
    }
}, SYNO.SDS.iSCSI.Utils.checkLUNSnapCompoundError = function(e, t, i) {
    return SYNO.SDS.iSCSI.Utils.checkCompoundError.call(this, e, t, i, SYNO.SDS.iSCSI.LUNSnapGetErrMsg)
}, SYNO.SDS.iSCSI.Utils.checkCompoundError = function(e, t, i, n) {
    var s = this,
        a = {},
        o = !1,
        r = SYNO.SDS.iSCSI.Utils.T("common", "commfail");
    if (Ext.each(t.result, function(e, t) {
            if (e.success) return !0;
            var r = SYNO.SDS.iSCSI.Utils.getLUNNameByUUID(i.compound[t].src_lun_uuid, s.luns);
            o = !0;
            var l = n(e.error.code, s) || SYNO.SDS.iSCSI.Utils.T("common", "error_system");
            a.hasOwnProperty(l) ? a[l].push(r) : a[l] = [r]
        }, s), o) {
        r = SYNO.SDS.iSCSI.Utils.T("common", "following_targets_failed") + "<br><br>";
        for (var l in a) a.hasOwnProperty(l) && (r += a[l].join(", ") + ": " + l + "<br>")
    }
    return r
}, SYNO.SDS.iSCSI.Utils.StatusRender = function(e, t, i, n, s, a, o) {
    t ? (e.snapStatusText = SYNO.SDS.iSCSI.Utils.T("iscsimgr", "status_volume_crash_title"), e.snapStatus = String.format("&nbsp;-&nbsp;{0}", '<font class="red-status">' + e.snapStatus + "</font>"), e.statusCategory = SYNO.SDS.iSCSI.STATUS_VOLUME_CRASHED) : e.volume_read_only ? (e.snapStatusText = SYNO.SDS.iSCSI.Utils.T("common", "readonly"), e.snapStatus = String.format("&nbsp;-&nbsp;{0}", '<font class="red-status">' + e.snapStatusText + "</font>"), e.statusCategory = SYNO.SDS.iSCSI.STATUS_VOLUME_READONLY) : i ? a || o ? a ? (e.snapStatusText = SYNO.SDS.iSCSI.Utils.T("iscsimgr", "status_replica"), e.snapStatus = String.format("&nbsp;-&nbsp;{0}", '<font class="green-status">' + e.snapStatusText + "</font>"), e.statusCategory = SYNO.SDS.iSCSI.STATUS_REPLICA) : (e.snapStatusText = SYNO.SDS.iSCSI.Utils.T("iscsimgr", "status_schedule"), e.snapStatus = String.format("&nbsp;-&nbsp;{0}", '<font class="blue-status">' + e.snapStatusText + "</font>"), e.statusCategory = SYNO.SDS.iSCSI.STATUS_SCHEDULE) : e.support_snapshot ? (e.snapStatusText = SYNO.SDS.iSCSI.Utils.T("iscsimgr", "status_no_protection"), e.snapStatus = String.format("&nbsp;-&nbsp;{0}", '<font class="orange-status">' + e.snapStatusText + "</font>"), e.statusCategory = SYNO.SDS.iSCSI.STATUS_NO_PROTECTED) : (e.snapStatusText = e.lun.isThinProvisioningLun() ? SYNO.SDS.iSCSI.Utils.T("snapmgr", "snap_lun_snapshot_disable") : SYNO.SDS.iSCSI.Utils.T("snapmgr", "snap_lun_not_support"), e.snapStatus = String.format("&nbsp;-&nbsp;{0}", '<font class="gray-status">' + e.snapStatusText + "</font>")) : (e.snapStatusText = String.format(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "target_managed_by"), SYNO.SDS.iSCSI.Utils.UIRender.getManagedByRender(n)), e.snapStatus = String.format("&nbsp;-&nbsp;{0}", '<font class="orange-status">' + e.snapStatusText + "</font>"), e.statusCategory = SYNO.SDS.iSCSI.STATUS_NOT_MANAGEABLE), s && (e.snapStatusText = SYNO.SDS.iSCSI.Utils.T("iscsimgr", "status_processing"), e.snapStatus = String.format("&nbsp;-&nbsp;{0}", '<font class="blue-status">' + e.snapStatusText + "</font>"))
}, SYNO.SDS.iSCSI.Utils.GetTime = function(e) {
    if (isNaN(e) || e < 0) return SYNO.SDS.iSCSI.invalid;
    var t, i;
    return 2 > e ? (t = e / 1, i = SYNO.SDS.iSCSI.Utils.T("common", "time_second")) : 60 > e ? (t = e / 1, i = SYNO.SDS.iSCSI.Utils.T("common", "time_seconds")) : 120 > e ? (t = e / 60, i = SYNO.SDS.iSCSI.Utils.T("common", "time_minute")) : 3600 > e ? (t = e / 60, i = SYNO.SDS.iSCSI.Utils.T("common", "time_minutes")) : 7200 > e ? (t = e / 3600, i = SYNO.SDS.iSCSI.Utils.T("common", "time_hour")) : 86400 > e ? (t = e / 3600, i = SYNO.SDS.iSCSI.Utils.T("common", "time_hours")) : 172800 > e ? (t = e / 86400, i = SYNO.SDS.iSCSI.Utils.T("common", "time_day")) : (t = e / 86400, i = SYNO.SDS.iSCSI.Utils.T("common", "time_days")), t = Math.floor(t), {
        value: t,
        unit: i
    }
}, SYNO.SDS.iSCSI.Utils.GetSizeGB = function(e, t) {
    var i = Ext.isNumber(t),
        n = Math.pow(10, i ? t : 2),
        s = e / SYNO.SDS.iSCSI.Utils.ISCSITRG_UNIT_GB,
        a = s;
    return n > 1 ? a = Math.round(s * n) / n : 1 == n && (a = Math.floor(s)), a
}, SYNO.SDS.iSCSI.Utils.TextRender = function(e, t) {
    return t ? '<span style="' + t + '">' + e + "</span>" : e
}, SYNO.SDS.iSCSI.Utils.GetDailySchedule = function(e) {
    return {
        week_name: "0,1,2,3,4,5,6",
        repeat_hour: 0,
        repeat_min: 0,
        hour: e,
        min: 0,
        last_work_hour: e
    }
}, SYNO.SDS.iSCSI.Utils.volumeFsTypeRender = function(e) {
    return e ? "btrfs" === e ? SYNO.SDS.iSCSI.Utils.T("volume", "volume_add_fs_btrfs_type") : "ext4" === e ? SYNO.SDS.iSCSI.Utils.T("volume", "volume_add_fs_ext4_type") : e : ""
}, SYNO.SDS.iSCSI.Utils.volumePathRenderer = function(e) {
    return SYNO.SDS.iSCSI.Utils.T("volume", "volume") + " " + e.split("/volume")[1]
}, SYNO.SDS.iSCSI.Utils.volumeInfoRenderer = function(e, t) {
    var i = SYNO.SDS.iSCSI.Utils,
        n = String.format(SYNO.SDS.iSCSI.Utils.T("volume", "volume_default_desc"), i.volumePathRenderer(e));
    return t ? String.format("{0}, {1}", n, i.volumeFsTypeRender(t)) : n
}, SYNO.SDS.iSCSI.Utils.dsNowSec = 0, SYNO.SDS.iSCSI.Utils.timestampNow = 0, SYNO.SDS.iSCSI.Utils.timeRender = function(e, t) {
    var i, n;
    return 0 > e && (e = 0), 2 > e ? (i = e, n = SYNO.SDS.iSCSI.Utils.T("common", "time_second")) : 60 > e ? (i = e, n = SYNO.SDS.iSCSI.Utils.T("common", "time_seconds")) : 120 > e ? (i = Math.floor(e / 60), n = SYNO.SDS.iSCSI.Utils.T("common", "time_minute")) : 3600 > e ? (i = Math.floor(e / 60), n = SYNO.SDS.iSCSI.Utils.T("common", "time_minutes")) : 7200 > e ? (i = Math.floor(e / 3600), n = SYNO.SDS.iSCSI.Utils.T("common", "time_hour")) : 86400 > e ? (i = Math.floor(e / 3600), n = SYNO.SDS.iSCSI.Utils.T("common", "time_hours")) : 172800 > e ? (i = Math.floor(e / 86400), n = SYNO.SDS.iSCSI.Utils.T("common", "time_day")) : (i = Math.floor(e / 86400), n = SYNO.SDS.iSCSI.Utils.T("common", "time_days")), String.format(t || SYNO.SDS.iSCSI.Utils.T("iscsimgr", "snap_last_time_msg"), i, n)
}, SYNO.SDS.iSCSI.Utils.processScheduledRender = function(e) {
    var t, i;
    return t = new SYNO.ux.ScheduleField, t.setValue(e), i = t.rawValue, Ext.destroy(t), i
}, SYNO.SDS.iSCSI.Utils.retentionStringCombine = function(e, t, i) {
    return "" === e ? t + " " + i : t + " " + i + ", " + e
}, SYNO.SDS.iSCSI.Utils.retentionRender = function(e) {
    var t = SYNO.SDS.iSCSI.Utils;
    if (!e || !e.policyType) return t.T("iscsimgr", "ret_all_snap");
    var i = "",
        n = ~SYNO.SDS.iSCSI.RTT_TRRIGER_BY_TIME & e.policyType;
    if (SYNO.SDS.iSCSI.RTT_ALL === n) i = t.T("iscsimgr", "ret_all_snap");
    else if (SYNO.SDS.iSCSI.RTT_DEL_OLD === n) i = String.format(t.T("iscsimgr", "ret_recent_num"), e.recently);
    else if (SYNO.SDS.iSCSI.RTT_BY_DAY === n) i = String.format(t.T("snapmgr", "ret_day_nums"), e.retainDay);
    else {
        i = String.format(t.T("snapmgr", "ret_adv_nums"), e.advMinimum);
        var s = "";
        SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_YEARLY & e.advPolicyType && (s = t.retentionStringCombine(s, e.advYearly, t.T("iscsimgr", "ret_yearly_short"))), SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_MONTHLY & e.advPolicyType && (s = t.retentionStringCombine(s, e.advMonthly, t.T("iscsimgr", "ret_monthly_short"))), SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_WEEKLY & e.advPolicyType && (s = t.retentionStringCombine(s, e.advWeekly, t.T("iscsimgr", "ret_weekly_short"))), SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_DAILY & e.advPolicyType && (s = t.retentionStringCombine(s, e.advDaily, t.T("iscsimgr", "ret_daily_short"))), SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_HOURLY & e.advPolicyType && (s = t.retentionStringCombine(s, e.advHourly, t.T("iscsimgr", "ret_hourly_short"))), "" !== s && (i = s + "<br>" + i), SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_DAY & e.advPolicyType && (i = String.format(t.T("snapmgr", "ret_day_nums"), e.advRetainDay) + "<br>" + i)
    }
    return i
}, SYNO.SDS.iSCSI.Utils.retentionTriggerRender = function(e) {
    if (!e || !e.policyType) return null;
    var t = ~SYNO.SDS.iSCSI.RTT_TRRIGER_BY_TIME & e.policyType;
    if (SYNO.SDS.iSCSI.RTT_ALL === t) return null;
    if (SYNO.SDS.iSCSI.RTT_TRRIGER_BY_TIME & e.policyType && e.schedule) {
        var i = Date.parseDate(String.leftPad(String(e.schedule.hour), 2, "0") + ":00", "H:i");
        return String.format(SYNO.SDS.iSCSI.Utils.T("snapmgr", "ret_trigger_at"), SYNO.SDS.DateTimeFormatter(i, {
            type: "time"
        }))
    }
    return SYNO.SDS.iSCSI.Utils.T("snapmgr", "ret_trigger_after_snap")
}, SYNO.SDS.iSCSI.Utils.freqRender = function(e) {
    return 0 !== e.repeat_hour ? String.format(SYNO.SDS.iSCSI.Utils.T("schedule", "every_x_hours"), e.repeat_hour.toString()) : 0 !== e.repeat_min ? String.format(SYNO.SDS.iSCSI.Utils.T("schedule", "every_x_minutes"), e.repeat_min.toString()) : SYNO.SDS.iSCSI.Utils.T("schedule", "schedule_every_once")
}, SYNO.SDS.iSCSI.Utils.TipRenderer = function(e, t) {
    return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(e)) + '"', Ext.util.Format.htmlEncode(e)
}, SYNO.SDS.iSCSI.Utils.ColumnTipRenderer = function(e, t) {
    var i = document.createElement("p");
    i.innerHTML = e;
    var n = i.querySelector("span").innerText;
    return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(n) + '"', e
}, SYNO.SDS.iSCSI.Utils.check = function() {
    var e, t;
    for (e = 0; e < arguments.length; e++) {
        if (t = arguments[e], Ext.isFunction(t) && !t.call(this)) return !1;
        if (Ext.isString(t) && !this[t]()) return !1
    }
    return !0
}, SYNO.SDS.iSCSI.Utils.LunSnapTypeRenderer = function(e) {
    var t = "";
    switch (e) {
        case SYNO.SDS.iSCSI.LUN_TYPE_ADV:
            break;
        case SYNO.SDS.iSCSI.LUN_TYPE_BTRFS:
            t = SYNO.SDS.iSCSI.Utils.T("iscsimgr", "instant_snapshot");
            break;
        case SYNO.SDS.iSCSI.LUN_TYPE_NOT_SUPPORT:
            t = SYNO.SDS.iSCSI.invalid
    }
    return t
}, SYNO.SDS.iSCSI.Utils.renderCheckBox = function(e, t, i) {
    var n = "disabled" === e ? "disabled" : e ? "checked" : "unchecked",
        s = "disabled" !== n && "checked" === n,
        a = i ? i.id + "_" + this.dataIndex : Ext.id(),
        o = "disabled" === n ? SYNO.SDS.iSCSI.Utils.T("common", "disabled") : _JSLIBSTR("uicommon", "enable_column_" + n),
        r = "disabled" === n;
    return t = t || {}, t.cellAttr = String.format('aria-label="{0} {1}" aria-checked="{2}" aria-disabled="{3}" role="checkbox"', Ext.util.Format.stripTags(this.orgHeader), o, s, r), String.format('<div class="syno-ux-grid-enable-column-{0}" id="{1}"></div>', n, a)
}, SYNO.SDS.iSCSI.Utils.NoteRender = function(e) {
    var t = !(arguments.length > 1 && void 0 !== arguments[1]) || arguments[1],
        i = t ? SYNO.SDS.iSCSI.Utils.T("common", "colon") : "";
    return '<span class="iscsi-note">' + SYNO.SDS.iSCSI.Utils.T("common", "note") + i + " </span>" + e
}, SYNO.SDS.iSCSI.Utils.IsAnyMappedTargetConnected = function(e, t) {
    return t.some(function(t) {
        return "connected" === t.get("status") && t.isMappedToLUN(e)
    })
}, SYNO.SDS.iSCSI.Utils.NoteRenderer = function(e) {
    return '<span class="syno-ux-note">' + SYNO.SDS.iSCSI.Utils.T("common", "note") + SYNO.SDS.iSCSI.Utils.T("common", "colon") + " </span>" + e
}, SYNO.SDS.iSCSI.Utils.API = {
    convertToMsg: function(e) {
        switch (e) {
            case 18990002:
                return SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_set_failed_space_not_enough");
            case 18990433:
                return SYNO.SDS.iSCSI.Utils.T("iscsimgr", "err_connect_to_isns_server");
            case 18990538:
                return SYNO.SDS.iSCSI.Utils.T("iscsimgr", "err_lunname_duplicated");
            case 18990541:
                return SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_up_to_max");
            case 18990542:
                return SYNO.SDS.iSCSI.Utils.T("iscsimgr", "target_up_to_max");
            case 18990543:
                return SYNO.SDS.iSCSI.Utils.T("iscsimgr", "snap_up_to_max");
            case 18990718:
                return SYNO.SDS.iSCSI.Utils.T("iscsimgr", "err_enable_target");
            case 18990744:
                return SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_name_exists");
            case 18990745:
                return SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_iqn_exists");
            default:
                return SYNO.SDS.iSCSI.Utils.T("error", "error_subject")
        }
    },
    getErrorString: function(e) {
        var t, i;
        return Ext.isNumber(e) ? t = e : Ext.isObject(e) && (i = SYNO.API.Util.GetFirstError(e), t = Ext.isNumber(i.code) ? i.code : 100), this.convertToMsg(t)
    }
}, SYNO.SDS.iSCSI.invalid = "--", Ext.namespace("SYNO.SDS.iSCSI.TARGET"), SYNO.SDS.iSCSI.TARGET.DefaultIQN = "iqn.2000-01.com.synology:default.acl", SYNO.SDS.iSCSI.TARGET.FAKE_PWD = "1234567890AB", SYNO.SDS.iSCSI.TARGET.FAKE_PWDC = "BA0987654321", SYNO.SDS.iSCSI.TARGET.MAX_MAPPING_LUNS = 256, SYNO.SDS.iSCSI.TP_HARD_THRESHOLD_MAX_SIZE = 1073741824, SYNO.SDS.iSCSI.TP_HARD_THRESHOLD_MIN_SIZE = 134217728, SYNO.SDS.iSCSI.TP_HARD_THRESHOLD_DEFAULT_SIZE = SYNO.SDS.iSCSI.TP_HARD_THRESHOLD_MAX_SIZE, SYNO.SDS.iSCSI.Utils.htmlEncodeRender = function(e, t) {
    var i = Ext.util.Format.htmlEncode(e);
    return t.attr += ' ext:qtip="' + Ext.util.Format.htmlEncode(i) + '" ', i
}, SYNO.SDS.iSCSI.Utils.htmlEventEncodeRender = function(e, t) {
    var i = /([12]\d{3}\/(0[1-9]|1[0-2])\/(0[1-9]|[12]\d|3[01]) ([01]\d|2[0-3]):([0-5]\d):([0-5]\d))/g;
    if (e.match(i)) {
        var n = Date.parseDate(e.match(i)[0], "Y/n/j h:i:s"),
            s = SYNO.SDS.DateTimeFormatter(n, {
                type: "datetimesec"
            });
        e = e.replace(i, s)
    }
    return SYNO.SDS.iSCSI.Utils.htmlEncodeRender(e, t)
}, SYNO.SDS.iSCSI.Utils.htmlSelectingGridEncodeRender = function(e, t, i) {
    return (i.get("banned") || !1 === i.get("enabled")) && (t.attr += ' style="color: gray"; '), SYNO.SDS.iSCSI.Utils.htmlEncodeRender(e, t)
}, SYNO.SDS.iSCSI.Utils.HostOSTypeInverse = ["none", "vmware_esxi", "windows", "windows_cluster", "linux", "mac_os", "citrix_hypervisor", "others"], SYNO.SDS.iSCSI.Utils.HostOSType = SYNO.SDS.iSCSI.Utils.HostOSTypeInverse.reduce(function(e, t, i) {
    return e[t] = i, e
}, {}), SYNO.SDS.iSCSI.Utils.genRenderPermissionData = function(e) {
    return e.map(function(e) {
        return [e, SYNO.SDS.iSCSI.Utils.renderPermission(e)]
    })
}, SYNO.SDS.iSCSI.Utils.permissionRendererInGridPanel = function(e, t, i) {
    var n = SYNO.SDS.iSCSI.Utils.renderPermission(e);
    return SYNO.SDS.iSCSI.Utils.htmlSelectingGridEncodeRender(n, t, i)
}, SYNO.SDS.iSCSI.Utils.HostOSString = [
    ["vmware_esxi", "VMware ESXi"],
    ["windows", "Windows"],
    ["windows_cluster", "Windows (failover cluster)"],
    ["linux", "Linux"],
    ["mac_os", "macOS"],
    ["citrix_hypervisor", "Citrix Hypervisor"],
    ["others", "Others"]
], SYNO.SDS.iSCSI.Utils.GetHostOSString = function(e) {
    var t = SYNO.SDS.iSCSI.Utils.HostOSString.find(function(t) {
        return e === t[0]
    });
    return t ? t[1] : ""
}, SYNO.SDS.iSCSI.Utils.ClusterAwareOS = ["vmware_esxi", "windows_cluster", "others"], SYNO.SDS.iSCSI.Utils.HostProtocolString = [
    ["iscsi", "iSCSI"],
    ["fc", SYNO.SDS.iSCSI.Utils.T("san_fibre", "fibre_channel")],
    ["fc_disabled_undetected", SYNO.SDS.iSCSI.Utils.T("san_lun", "map_fc_undetected_adapter")]
], SYNO.SDS.iSCSI.Utils.GetHostProtocolString = function(e) {
    var t = SYNO.SDS.iSCSI.Utils.HostProtocolString.find(function(t) {
        return e === t[0]
    });
    return t ? t[1] : ""
}, SYNO.SDS.iSCSI.Utils.LUNUsageProcess = function(e) {
    var t = parseInt(e.get("size"), 10),
        i = e.get("allocated_size") ? parseInt(e.get("allocated_size"), 10) : 0;
    return i = i > t ? t : i, {
        totalSize: t,
        usedSize: i
    }
}, SYNO.SDS.iSCSI.Utils.ACLValidator = function(e) {
    return SYNO.SDS.iSCSI.Utils.PermissionValidator(e) && SYNO.SDS.iSCSI.Utils.OSValidator(e)
}, SYNO.SDS.iSCSI.Utils.PermissionValidator = function(e) {
    var t = SYNO.SDS.iSCSI.Utils.HostOSTypeInverse.reduce(function(e, t) {
        return e[t] = [], e
    }, []);
    return e.forEach(function(e) {
        var i = SYNO.SDS.iSCSI.Utils.HostOSTypeInverse[e.type];
        e.acls.forEach(function(e) {
            t[i].push(e)
        })
    }), Object.keys(t).every(function(e) {
        if (-1 !== SYNO.SDS.iSCSI.Utils.ClusterAwareOS.indexOf(e)) return !0;
        var i = [];
        return t[e].every(function(e) {
            return "rw" !== e.permission || -1 === i.indexOf(e.lun_uuid) && (i.push(e.lun_uuid), !0)
        })
    })
}, SYNO.SDS.iSCSI.Utils.OSValidator = function(e) {
    var t = !0;
    if (!Array.isArray(e)) return !1;
    var i = {};
    return e.forEach(function(e) {
        var n = !1;
        if (e.acls && e.acls.forEach(function(t) {
                if ("-" !== t.permission) {
                    var s = SYNO.SDS.iSCSI.Utils.HostOSTypeInverse[e.type];
                    if (i[t.lun_uuid]) {
                        if (i[t.lun_uuid] !== s) return void(n = !0)
                    } else i[t.lun_uuid] = s
                }
            }), n) return void(t = !1)
    }), t
}, SYNO.SDS.iSCSI.Utils.SetEmptyIcon = function(e, t) {
    var i = e.el.child(".contentwrapper");
    if (i) {
        for (; i.child(".contentwrapper");) i = i.child(".contentwrapper");
        t && !i.hasClass("san-is-empty") ? i.addClass("san-is-empty") : !t && i.hasClass("san-is-empty") && i.removeClass("san-is-empty")
    }
}, SYNO.SDS.iSCSI.Utils.GetFCRadioString = function(e) {
    return e ? SYNO.SDS.iSCSI.Utils.T("san_lun", "map_fc") : SYNO.SDS.iSCSI.Utils.T("san_lun", "map_fc_undetected_adapter")
}, Ext.namespace("SYNO.SDS.iSCSI.FCTARGET"), SYNO.SDS.iSCSI.FCTARGET.DefaultWWPN = "iqn.2000-01.com.synology:default.acl", SYNO.SDS.iSCSI.FCTARGET.MAX_MAPPING_LUNS = 256, Ext.namespace("SYNO.SDS.iSCSI.LUN"), SYNO.SDS.iSCSI.LUN.Status = function() {
    return {
        defragging: {
            text: SYNO.SDS.iSCSI.Utils.T("iscsilun", "defragging"),
            color: "blue-status"
        },
        Unhealthy: {
            text: SYNO.SDS.iSCSI.Utils.T("iscsilun", "crashed"),
            color: "red-status"
        },
        unavailabling: {
            text: SYNO.SDS.iSCSI.Utils.T("iscsilun", "crashed"),
            color: "red-status"
        },
        crashed: {
            text: SYNO.SDS.iSCSI.Utils.T("iscsilun", "crashed"),
            color: "red-status"
        },
        expanding: {
            text: SYNO.SDS.iSCSI.Utils.T("lun", "status_expanding"),
            color: "blue-status"
        }
    }
}(), Ext.namespace("SYNO.SDS.SAN.FC"), SYNO.SDS.SAN.FC.Status = function() {
    return {
        disabled: {
            text: SYNO.SDS.iSCSI.Utils.T("common", "disabled"),
            color: "red-status"
        },
        offline: {
            text: SYNO.SDS.iSCSI.Utils.T("san_fibre", "status_link_down"),
            color: "disable-font"
        },
        online: {
            text: SYNO.SDS.iSCSI.Utils.T("san_fibre", "status_link_up"),
            color: "green-status"
        },
        connected: {
            text: SYNO.SDS.iSCSI.Utils.T("san_fibre", "status_link_up"),
            color: "green-status"
        },
        sfp_unsupported: {
            text: SYNO.SDS.iSCSI.Utils.T("san_fibre", "sfp_unsupported"),
            color: "red-status"
        }
    }
}(), Ext.define("SYNO.SDS.iSCSI.DataView", {
    extend: "SYNO.ux.ExpandableListView",
    singleExpanded: !0,
    constructor: function(e) {
        var t, i = this;
        i.expandedItemId = {}, i.selectedItemId = {}, i.appWin = e.appWin, i.owner = e.owner, i.usageTpl = e.usageTpl, i.detailTpl = e.detailTpl, t = {
            tpl: this.createTpl(),
            trackResetOnLoad: !1
        }, i.callParent([Ext.apply(t, e)])
    },
    createTpl: function() {
        var e = this;
        return new Ext.XTemplate('<tpl for=".">', '<div class="item-wrap" itemId="{id}" id="{id}">', '<div class="item-summary">', '<div class="item-icon {iconPic} {iconCls}"></div>', '<div class="iscsi-list-status-icon {statusIconCls}"></div>', '<div style="display: inline-block; padding-right: 12px; width:', e.usageTpl ? "calc(78% - 77px)" : "90%", '">', '<span class="item-title" style="max-width: 80%" ext:qtip="{displayName}">{displayName}</span>', '<span class="item-title item-title-status">{summaryStatus}</span>', '<span class="item-title item-title-status">{progressStatus}</span>', '<div class="item-status">{desc}</div>', "</div>", e.usageTpl ? e.usageTpl.html : "", '<tpl if="property">', e.detailTpl ? '<div class="item-toggle"><div class="item-toggle-img"></div></div>' : "", "</tpl>", "</div>", '<tpl if="property">', '<div class="item-detail" style="display:none; padding-bottom:14px">', e.detailTpl ? e.detailTpl.html : "", "</div>", "</tpl>", "</div>", "</tpl>", '<div class="x-clear"></div>', {
            compiled: !0,
            hasValues: function(e) {
                return !!e && 0 < e.length
            }
        })
    },
    getSelectedItemIds: function() {
        var e, t, i = [];
        for (e = this.getSelectedRecords(), t = 0; t < e.length; ++t) e[t] && i.push(e[t].get("id"));
        return i
    },
    getSelectedItems: function() {
        var e = this,
            t = e.getSelectedItemIds(),
            i = e.appWin[e.dataType].data,
            n = [];
        return Ext.each(t, function(e) {
            e in i && i[e] && n.push(i[e])
        }), n
    },
    getSelectedItem: function() {
        var e = this,
            t = e.getSelectedItems();
        if (0 !== t.length) return t[0]
    },
    onClick: function(e, t, i) {
        this.callParent(arguments)
    },
    onDblClick: function(e, t, i) {
        this.callParent(arguments)
    }
}), Ext.define("SYNO.SDS.iSCSI.ListDataView", {
    extend: "SYNO.ux.ExpandableListView",
    singleExpanded: !0,
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.owner = e.owner, i.progressTpl = e.progressTpl, i.innerTpl = e.innerTpl, i.blRestore = e.blRestore, t = {
            trackResetOnLoad: !1,
            tpl: i.createTpl()
        }, i.callParent([Ext.apply(t, e)])
    },
    createTpl: function() {
        var e = this;
        return new Ext.XTemplate('<tpl for=".">', '<div class="item-wrap {cls}" id="{name}">', '<div class="item-summary">', '<div class="item-icon {iconCls}"></div>', '<div class="{statusCls}"></div>', e.progressTpl ? '<div class="iscsi-item-title-progress-{displayProg}">' : "<div>", '<span class="item-title" style="float:left; max-width: 70%;" ext:qtip="{name}">{name}</span>', '<span class="item-title item-title-status" style="display:block; margin-right:60px;" ext:qtip="{snapStatusText}">{snapStatus}</span>', e.blRestore ? '<div class="item-status">{vol_info}, {restorePageLastSnapshot}</div>' : '<tpl if="values.vol_info && values.capacity && capacity == \'--\'"><div class="item-status">{vol_info}</div></tpl><tpl if="values.capacity && capacity != \'--\' && values.lun_snap_type_desc"><div class="item-status">{vol_info}, {lun_snap_type_desc}, {capacity}</div></tpl><tpl if="values.capacity && capacity != \'--\' && !values.lun_snap_type_desc"><div class="item-status">{vol_info}, {capacity}</div></tpl>', "</div>", e.progressTpl ? e.progressTpl.html : "", '<tpl if="false != values.support_snapshot">', e.innerTpl ? '<div class="item-toggle"><div class="item-toggle-img"></div></div>' : "", "</tpl>", "</div>", '<tpl if="false != values.support_snapshot">', '<div class="item-detail" style="display:none; padding-bottom:10px">', e.innerTpl ? e.innerTpl.html : "", "</div>", "</tpl>", "</div>", "</tpl>", '<div class="x-clear"></div>', {
            hasValues: function(e) {
                return !!e && 0 < e.length
            }
        })
    },
    getSelectedItems: function() {
        return this.getSelectedItemIds()
    },
    getSelectedItem: function() {
        var e = this.getSelectedItems();
        if (0 !== e.length) return e[0]
    },
    setEmptyText: function(e) {
        this.emptyText = ['<div class="empty-text-wrap">', '<div class="empty-text-inner-wrap">', '<div class="empty-text-icon"></div>', '<div class="empty-text">', e, "</div>", "</div>", "</div>"].join("")
    },
    expandDetail: function(e, t) {
        if (this.innerTpl && e) {
            var i;
            i = this.getRecord(e.dom), e.child(".item-toggle-expanded") ? this.doExpand(!0, e, !1) : (this.doExpand(!0, e, t), 0 > this.toggledItemIds.indexOf(i.id) && this.toggledItemIds.push(i.id))
        }
    }
}), Ext.define("SYNO.SDS.iSCSI.LunList.Store", {
    extend: "Ext.data.JsonStore",
    constructor: function(e) {
        var t, i = this;
        t = {
            autoDestroy: !0,
            idProperty: "name",
            fields: [{
                name: "name",
                sortType: "asNaturalUCString"
            }, "id", "lid", "snapshots", "extent_based", "is_actioning", "status", "snapStatus", "snapStatusText", "isProtected", "capacity", "snapshotProp", "restoreProp", "iconCls", "type", "isSnapScheduled", "progress", "barWidth", "displayProg", "lastSnapshot", "vol_path", "vol_info", "restorePageLastSnapshot", "statusCategory", "next_run_time", "scheduleTask", "support_snapshot", "volume_crashed", "volume_read_only", "uuid", "size", "lun", "lun_type", "lun_snap_type_desc"],
            listeners: {
                load: function() {
                    i.sort("name", "ASC"), i.sort("support_snapshot", "DESC")
                },
                scope: i
            }
        }, i.callParent([Ext.apply(t, e)])
    }
}), Ext.define("SYNO.SDS.iSCSI.ModalWindow", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function() {
        this.callParent(arguments), this.addClass("syno-app-iscsi")
    },
    setMaskMsgVisible: function(e) {
        if (this.el.isMasked()) {
            var t = Ext.Element.data(this.el, "maskMsg");
            t && t.dom && (t.setVisibilityMode(Ext.Element.VISIBILITY), t.setVisible(e))
        }
    },
    setMaskOpacity: function(e) {
        SYNO.SDS.AppWindow.superclass.setMaskOpacity.call(this, e), this.setMaskMsgVisible(0 !== e)
    },
    delayedMask: function(e, t, i, n) {
        if (this.getFooterToolbar()) return void this.callParent(arguments);
        t = t || 200, this.maskTask || (this.maskTask = new Ext.util.DelayedTask(this.setMaskOpacity, this, [e])), this.mask(0, i, n), this.setMaskMsgVisible(!1), this.maskTask.delay(t)
    },
    setStatusBusy: function(e, t, i) {
        if (this.getFooterToolbar()) return void this.callParent(arguments);
        e = e || {}, Ext.applyIf(e, {
            text: SYNO.SDS.iSCSI.Utils.T("common", "loading"),
            iconCls: "x-mask-loading"
        }), t = t || .4, i = i || 400, this.delayedMask(t, i, e.text, e.iconCls), this.canClose = !1
    },
    clearStatusBusy: function(e) {
        if (this.getFooterToolbar()) return void this.callParent(arguments);
        this.unmask(), this.canClose = !0
    }
}), 
/**
 * @class SYNO.SDS.iSCSI.Snapshot.MultiDeleteError
 * @extends SYNO.SDS.iSCSI.ModalWindow
 * iSCSI snapshot multi delete error 
 *
 */ 
Ext.define("SYNO.SDS.iSCSI.Snapshot.MultiDeleteError", {
    extend: "SYNO.SDS.iSCSI.ModalWindow",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.data = e.errorData;
        var i = {
            layout: "fit",
            items: [],
            width: 350,
            height: 300,
            minHeight: 200,
            buttons: [{
                text: SYNO.SDS.iSCSI.Utils.T("common", "alt_close"),
                scope: t,
                handler: t.onCancel
            }]
        };
        t.callParent([Ext.apply(i, e)])
    },
    initComponent: function() {
        var e = this;
        e.items.push(e.createPanel()), e.callParent(arguments)
    },
    onCancel: function() {
        this.close()
    },
    initEvents: function() {
        this.callParent(arguments);
        var e = this,
            t = [],
            i = 0;
        for (var n in e.data)
            if (e.data.hasOwnProperty(n)) {
                var s = "",
                    a = "";
                for (var o in e.data[n]) e.data[n].hasOwnProperty(o) && (s = o, a = e.data[n][o]);
                t[i] = [], t[i][0] = i, t[i][1] = String(s), t[i][2] = String(a), ++i
            } e.store.loadData(t), e.setHeight(350)
    },
    createPanel: function() {
        var e, t, i = this,
            n = Ext.data.Record.create([{
                name: "idIndex"
            }, {
                name: "name"
            }, {
                name: "error"
            }]),
            s = new Ext.data.Store({
                appWindow: i.appWin,
                autoDestroy: !0,
                reader: new Ext.data.ArrayReader({
                    idIndex: 0
                }, n)
            });
        i.store = s, e = "snapshot_time", t = SYNO.SDS.iSCSI.Utils.T("time", "time_time");
        var a = new Ext.grid.ColumnModel({
                defaults: {
                    width: 120,
                    sortable: !1
                },
                columns: [{
                    id: "idIndex",
                    header: SYNO.SDS.iSCSI.Utils.T("time", "time_time"),
                    dataIndex: "idIndex",
                    hidden: !0
                }, {
                    id: e,
                    header: t,
                    dataIndex: "name",
                    renderer: function(e) {
                        var t = new Date(1e3 * e);
                        return SYNO.SDS.DateTimeFormatter(t, {
                            type: "datetimesec"
                        })
                    }
                }, {
                    id: "error",
                    header: SYNO.SDS.iSCSI.Utils.T("error", "error_error_reason"),
                    dataIndex: "error",
                    renderer: function(e, t, i) {
                        var n = parseInt(e, 10);
                        return SYNO.SDS.iSCSI.LUNSnapGetErrMsg(n, this) || SYNO.SDS.iSCSI.Utils.T("error", "error_error_system")
                    }
                }]
            }),
            o = {
                forceFit: !0,
                onLoad: Ext.emptyFn,
                listeners: {
                    beforerefresh: function(e) {
                        e.scrollTop = e.scroller.dom.scrollTop
                    },
                    refresh: function(e) {
                        e.scroller.dom.scrollTop = e.scrollTop
                    }
                }
            };
        return {
            layout: "fit",
            xtype: "syno_gridpanel",
            itemId: "snapshots",
            style: {
                padding: "0px 12px 0px 16px"
            },
            store: s,
            colModel: a,
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: !1
            }),
            enableHdMenu: !1,
            viewConfig: o,
            enableColumnMove: !1,
            cls: "without-dirty-red-grid"
        }
    }
}), Ext.define("SYNO.SDS.iSCSI.Lun.TextFilter", {
    extend: "SYNO.ux.TextFilter",
    reset: function() {
        !1 === this.localFilterField && this.store && (this.store.clearFilter(!1), this.trigger.hide())
    }
}), Ext.define("SYNO.SDS.iSCSI.Snapshot.SearchField", {
    extend: "SYNO.ux.SearchField",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.allDisaplayText = e.allDisaplayText;
        var i = this.fillConfig(e);
        SYNO.SDS.iSCSI.Snapshot.SearchField.superclass.constructor.call(this, i)
    },
    fillConfig: function(e) {
        var t = this,
            i = {
                iconStyle: "search",
                itemId: "searchShareName",
                listeners: {
                    keyup: function() {
                        t.owner.fireEvent("data_ready")
                    },
                    scope: t.owner
                }
            };
        return Ext.apply(i, e), i
    },
    getSearchText: function() {
        return this.getValue().trim()
    },
    onTriggerClick: function() {
        SYNO.SDS.iSCSI.Snapshot.SearchField.superclass.onTriggerClick.apply(this, arguments), this.owner.fireEvent("data_ready")
    },
    getMenu: function() {
        if (this.menu) return this.menu;
        var e = [];
        return e.push({
            text: this.allDisaplayText,
            checked: !0,
            itemId: SYNO.SDS.iSCSI.STATUS_ALL,
            checkHandler: this.setSearchFilter
        }), e.push({
            text: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "snap_filter_with_schedule"),
            checked: !1,
            itemId: SYNO.SDS.iSCSI.STATUS_SCHEDULE,
            checkHandler: this.setSearchFilter
        }), e.push({
            text: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "snap_filter_no_protected"),
            checked: !1,
            itemId: SYNO.SDS.iSCSI.STATUS_NO_PROTECTED,
            checkHandler: this.setSearchFilter
        }), this.menu = new SYNO.ux.Menu({
            defaults: {
                group: "filter",
                scope: this
            },
            items: e,
            cls: "syno-ux-check-menu",
            listeners: {
                scope: this,
                beforeshow: function(e) {
                    e.items.get(this.getSearchFilter()).setChecked(!0)
                }
            }
        })
    },
    setSearchFilter: function(e) {
        var t = e.itemId;
        t !== this.gSearchFilter && (this.gSearchFilter = t, this.owner.fireEvent("data_ready"))
    },
    getSearchFilter: function() {
        return this.gSearchFilter || SYNO.SDS.iSCSI.STATUS_ALL
    },
    isAllDisplay: function() {
        return SYNO.SDS.iSCSI.STATUS_ALL === this.getSearchFilter() && "" === this.getSearchText()
    }
}), Ext.define("SYNO.SDS.iSCSI.AdvancedSearchField", {
    extend: "SYNO.ux.SearchField",
    initEvents: function() {
        this.callParent(arguments), this.mon(Ext.getDoc(), "mousedown", this.onMouseDown, this), this.mon(this, "keypress", function(e, t) {
            t.getKey() === Ext.EventObject.ENTER && (this.searchPanel.setKeyWord(this.getValue()), this.searchPanel.onSearch())
        }, this), this.mon(this, "destroy", function() {
            this.searchPanel.destroy()
        }, this)
    },
    isInnerComponent: function(e, t) {
        var i = !1;
        return e.getTarget(".syno-datetimepicker-inner-menu") && (i = !0), t.items.each(function(t) {
            if (t instanceof Ext.form.ComboBox) {
                if (t.view && e.within(t.view.getEl())) return i = !0, !1
            } else if (t instanceof Ext.form.DateField) {
                if (t.menu && e.within(t.menu.getEl())) return i = !0, !1
            } else if (t instanceof Ext.form.CompositeField && this.isInnerComponent(e, t)) return i = !0, !1
        }, this), i
    },
    onMouseDown: function(e) {
        var t = this.searchPanel;
        !t || !t.isVisible() || t.inEl || e.within(t.getEl()) || e.within(this.searchtrigger) || this.isInnerComponent(e, this.searchPanel.getForm()) || t.hide()
    },
    onSearchTriggerClick: function() {
        if (this.searchPanel.isVisible()) return void this.searchPanel.hide();
        this.searchPanel.getEl().alignTo(this.wrap, "tr-br?", [6, 0]), this.searchPanel.show(), this.searchPanel.setKeyWord(this.getValue())
    },
    onTriggerClick: function() {
        this.callParent(), this.searchPanel.onReset()
    }
}), Ext.define("SYNO.SDS.iSCSI.SearchFormPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        this.dateType = {
            custom: 1,
            today: 2,
            yesterday: 4,
            lastweek: 8,
            lastmonth: 16
        }, this.dataRange = [
            [this.dateType.custom, SYNO.SDS.iSCSI.Utils.T("log", "date_custom")],
            [this.dateType.today, SYNO.SDS.iSCSI.Utils.T("log", "date_today")],
            [this.dateType.yesterday, SYNO.SDS.iSCSI.Utils.T("log", "date_yesterday")],
            [this.dateType.lastweek, SYNO.SDS.iSCSI.Utils.T("log", "date_lastweek")],
            [this.dateType.lastmonth, SYNO.SDS.iSCSI.Utils.T("log", "date_lastmonth")]
        ], this.logLevelType = {
            info: "info",
            warn: "warning",
            error: "err"
        }, this.logLevel = [
            [this.logLevelType.info, SYNO.SDS.iSCSI.Utils.T("log", "info_level")],
            [this.logLevelType.warn, SYNO.SDS.iSCSI.Utils.T("log", "warn_level")],
            [this.logLevelType.error, SYNO.SDS.iSCSI.Utils.T("log", "error_level")]
        ], this.defaultAnimation = ["#000", 1, {
            duration: .35
        }], Ext.apply(this, e || {});
        var t = this.fillConfig(e);
        this.callParent([t]), this.mon(this, "afterlayout", function() {
            this.defineBehaviors()
        }, this)
    },
    initComponent: function() {
        this.callParent(arguments), this.addEvents("search")
    },
    fillConfig: function(e) {
        var t, i, n, s, a = [];
        return t = this.createKeyword(), i = this.createFriendlyDate(), n = this.createCustDate(), s = this.createLevel(), a.push(t), a.push(i), a.push(n), a.push(s), a.push({
            xtype: "toolbar",
            border: !1,
            itemId: "btns",
            toolbarCls: "search-panel-fbar-btnPanel",
            items: [{
                xtype: "lctbtext",
                itemId: "search-loading",
                text: ""
            }, {
                xtype: "lctbtext",
                itemId: "msg",
                height: 26,
                style: "-webkit-text-size-adjust:none;font-size:11px;height:26px;overflow:hidden;",
                cls: "red-status",
                text: ""
            }, {
                xtype: "tbfill"
            }, {
                xtype: "syno_button",
                minWidth: 80,
                text: SYNO.SDS.iSCSI.Utils.T("common", "reset"),
                handler: this.onReset,
                scope: this
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                style: "margin-right: 10px",
                text: SYNO.SDS.iSCSI.Utils.T("log", "search"),
                itemId: "btn_search",
                handler: this.onSearch,
                scope: this
            }]
        }), {
            width: 368,
            heigh: 480,
            floating: !0,
            labelAlign: "left",
            trackResetOnLoad: !0,
            waitMsgTarget: !0,
            border: !1,
            bodyStyle: "padding: 16px 24px 16px 24px;",
            autoFlexcroll: !1,
            defaults: {
                hideLabel: !0,
                anchor: "100%"
            },
            items: a,
            listeners: {
                actionfailed: {
                    fn: function() {
                        this.setMsg(""), this.form.reset()
                    },
                    scope: this
                },
                beforeshow: {
                    fn: function() {
                        this.doLayout()
                    },
                    single: !0
                },
                show: {
                    fn: this.doLayout,
                    single: !0
                }
            },
            keys: [{
                key: [10, 13],
                fn: function() {
                    this.isVisible() && (this.btnSearch.hidden || this.btnSearch.disabled || this.onSearch())
                },
                scope: this
            }]
        }
    },
    setComboBoxValue: function(e, t) {
        this.frameAnimation(e.el, this.defaultAnimation), e.setMultiValue && e.setMultiValue(t.split(","))
    },
    getComboBoxValue: function(e) {
        var t = this.getForm().findField(e);
        return t.getMultiValue ? t.getMultiValue().toString() : t.getValue()
    },
    multiSelect: function(e, t, i, n, s) {
        if (Ext.applyIf(e, {
                setMultiValue: function(e) {
                    Ext.isArray(e) || (e = [e]), this.multiValue = e
                },
                getMultiValue: function() {
                    return this.multiValue && this.multiValue.length > 0 ? this.multiValue : this.getValue().split(",")
                }
            }), "more" === t.get("value")) return this.attriWin = new SYNO.SDS.LogCenter.MultiSelectedDialog({
            title: n,
            combo: e,
            emptyValue: s,
            anim: this.defaultAnimation,
            owner: this.owner.appInst
        }), this.attriWin.showUp(), e.collapse(), !1
    },
    createTpl: function() {
        return new Ext.XTemplate('<tpl for=".">', '<div class="x-combo-list-item" ext:qtip="{displayText:htmlEncode}">', "{displayText:htmlEncode}", "</div>", "</tpl>")
    },
    logSelect: function(e, t, i) {
        this.setComboBoxValue(e, e.getValue())
    },
    createKeyword: function() {
        return [{
            xtype: "syno_displayfield",
            value: SYNO.SDS.iSCSI.Utils.T("log", "attr_keyword") + SYNO.SDS.iSCSI.Utils.T("common", "colon"),
            style: "margin-top: 0px",
            flex: 1
        }, {
            xtype: "syno_textfield",
            msgTarget: "qtip",
            validateOnBlur: !0,
            validationEvent: "blur",
            name: "keyword",
            flex: 2,
            vaule: ""
        }]
    },
    setDate: function(e, t, i) {
        !0 === i && (this.frameAnimation(this.form.findField("searchdatefrom").el, this.defaultAnimation), this.frameAnimation(this.form.findField("searchdateto").el, this.defaultAnimation)), this.form.findField("searchdatefrom").setMaxValue(t), this.form.findField("searchdateto").setMinValue(e), this.form.findField("searchdatefrom").setValue(e), this.form.findField("searchdateto").setValue(t)
    },
    getFromToDate: function(e) {
        var t, i, n = new Date;
        if (e === this.dateType.today) t = n, i = n;
        else if (e === this.dateType.yesterday) t = n.add(Date.DAY, -1), i = t;
        else if (e === this.dateType.lastweek) {
            var s = n.getDay();
            t = n.add(Date.DAY, -7 - s), i = t.add(Date.DAY, 6)
        } else e === this.dateType.lastmonth && (n = n.add(Date.MONTH, -1), t = n.getFirstDateOfMonth(), i = n.getLastDateOfMonth());
        return {
            from: t,
            to: i
        }
    },
    friendlyDateSelect: function(e, t, i) {
        var n = t.get("id"),
            s = this.getFromToDate(n);
        this.setDate(s.from, s.to, !0)
    },
    getFriendlyDateStore: function() {
        var e = this.dataRange;
        return new Ext.data.ArrayStore({
            autoDestroy: !0,
            fields: ["id", "displayText"],
            data: e
        })
    },
    createFriendlyDate: function() {
        return this.FriendlyDate = new SYNO.ux.ComboBox({
            mode: "local",
            editable: !1,
            name: "dateRange",
            tpl: this.createTpl(),
            resizable: !1,
            store: this.getFriendlyDateStore(),
            displayField: "displayText",
            valueField: "id",
            triggerAction: "all",
            lazyRender: !0,
            flex: 6,
            value: this.dateType.custom,
            listeners: {
                scope: this,
                beforequery: function(e) {
                    delete e.combo.lastQuery
                },
                beforeselect: this.friendlyDateSelect
            }
        }), [{
            xtype: "syno_displayfield",
            value: SYNO.SDS.iSCSI.Utils.T("log", "date_range") + SYNO.SDS.iSCSI.Utils.T("common", "colon"),
            flex: 1
        }, this.FriendlyDate]
    },
    createCustDate: function() {
        return this.DateFrom = new SYNO.ux.DateTimeField({
            name: "searchdatefrom",
            editable: !1,
            isAllDay: !0,
            emptyText: SYNO.SDS.iSCSI.Utils.T("log", "date_from"),
            allowBlank: !0,
            flex: 1,
            value: "",
            listeners: {
                scope: this,
                select: function(e, t) {
                    this.form.findField("searchdateto").setMinValue(t)
                }
            }
        }), this.DateTo = new SYNO.ux.DateTimeField({
            name: "searchdateto",
            editable: !1,
            isAllDay: !0,
            emptyText: SYNO.SDS.iSCSI.Utils.T("log", "date_to"),
            allowBlank: !0,
            flex: 1,
            value: "",
            listeners: {
                scope: this,
                select: function(e, t) {
                    this.form.findField("searchdatefrom").setMaxValue(t)
                }
            }
        }), [{
            xtype: "syno_displayfield",
            value: SYNO.SDS.iSCSI.Utils.T("time", "time_date") + SYNO.SDS.iSCSI.Utils.T("common", "colon")
        }, {
            xtype: "syno_compositefield",
            hideLabel: !0,
            defaults: {
                flex: 1
            },
            defaultMargins: "0 8 0 0",
            items: [this.DateFrom, this.DateTo]
        }]
    },
    getLogLevelStore: function() {
        var e = this.logLevel.slice(0, this.logLevel.length);
        return e.length > 1 && e.splice(0, 0, ["", SYNO.SDS.iSCSI.Utils.T("log", "log_all")]), new Ext.data.ArrayStore({
            autoDestroy: !0,
            fields: ["value", "displayText"],
            data: e
        })
    },
    multiLogLevelSelect: function(e, t, i) {
        this.multiSelect(e, t, i, SYNO.SDS.iSCSI.Utils.T("log", "logattr"))
    },
    createLevel: function() {
        return this.LogLevel = new SYNO.ux.ComboBox({
            xtype: "syno_combobox",
            mode: "local",
            editable: !1,
            name: "logLevel",
            tpl: this.createTpl(),
            resizable: !1,
            store: this.getLogLevelStore(),
            displayField: "displayText",
            valueField: "value",
            triggerAction: "all",
            lazyRender: !0,
            flex: 3,
            value: "",
            listeners: {
                scope: this,
                beforequery: function(e) {
                    delete e.combo.lastQuery
                },
                beforeselect: this.multiLogLevelSelect,
                select: this.logSelect
            }
        }), [{
            xtype: "syno_displayfield",
            name: "logLevelLabel",
            value: SYNO.SDS.iSCSI.Utils.T("log", "logattr") + SYNO.SDS.iSCSI.Utils.T("common", "colon"),
            flex: 1
        }, this.LogLevel]
    },
    hideItems: function(e) {
        var t;
        Ext.isArray(e) || (e = [e]);
        for (var i = e.length - 1; i >= 0; i--)(t = this.form.findField(e[i])) && t.setVisible(!1)
    },
    frameAnimation: function(e, t) {
        e && e.isVisible() && Ext.Element.prototype.frame.apply(e, t)
    },
    defineBehaviors: function() {
        var e = this.get("btns");
        this.btnSearch = e.get("btn_search")
    },
    setMsg: function(e) {
        var t = this.get("btns"),
            i = t.get("msg");
        i.setText(e), "" !== e.trim() && this.frameAnimation(i.el, this.defaultAnimation)
    },
    setKeyWord: function(e) {
        var t = this.form.findField("keyword");
        t && Ext.isString(e) && t.setValue(e), t.focus("", 1)
    },
    isOwnerDestroyed: function() {
        return this.owner && this.owner.isDestroyed
    },
    showMsg: function(e, t) {
        this.isOwnerDestroyed() || this.owner.getMsgBox().alert(e, t)
    },
    hideMsg: function() {
        this.isOwnerDestroyed() || this.owner.getMsgBox().hide()
    },
    isFieldDirty: function(e) {
        return this.form.findField(e).isDirty()
    },
    validateForm: function() {
        return !!this.form.isValid() && (this.isFieldDirty("searchdatefrom") || this.isFieldDirty("searchdateto") || this.isFieldDirty("keyword"))
    },
    onSearch: function(e, t) {
        var i, n, s, a, o, r;
        i = this.getForm(), n = i.findField("keyword").getValue(), s = i.findField("searchdatefrom").getRawValue(), a = i.findField("searchdateto").getRawValue(), o = this.getComboBoxValue("logLevel"), r = {
            keyword: n
        }, o && (r.log_level = [o]), s && (r.date_from = s), a && (r.date_to = a), this.fireEvent("search", this, r)
    },
    onReset: function() {
        this.form.items.each(function(e) {
            e.isDirty() && this.frameAnimation(e.el, this.defaultAnimation)
        }, this), this.setMsg(""), this.form.reset(), this.form.findField("searchdatefrom").setMaxValue(null), this.form.findField("searchdateto").setMinValue(null), this.form.findField("logLevel").multiValue = "", this.onSearch()
    }
}), Ext.define("SYNO.SDS.iSCSI.SmartRetention", {
    extend: "SYNO.SDS.iSCSI.ModalWindow",
    constructor: function(e) {
        var t = this,
            i = SYNO.SDS.iSCSI.Utils;
        t = Ext.apply(t, e), t.helpLinkId = Ext.id();
        var n = '<span id="' + t.helpLinkId + '" class="link-font" tabindex="0" role="link" style="cursor:pointer">',
            s = function(e) {
                e.setValue(e.originalValue)
            },
            a = [{
                xtype: "syno_displayfield",
                htmlEncode: !1,
                value: String.format(i.T("snapmgr", "ret_pol_desc"), n, "</span>"),
                listeners: {
                    afterrender: t.addLinks,
                    scope: t,
                    single: !0,
                    buffer: 100
                }
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                height: 28,
                ref: "../advDayComp",
                items: [{
                    xtype: "syno_checkbox",
                    name: "advPolicyByDay",
                    boxLabel: i.T("snapmgr", "ret_keep_days_description"),
                    checked: !0,
                    ref: "checkBox"
                }, {
                    xtype: "syno_displayfield",
                    width: 2,
                    value: ""
                }, {
                    xtype: "syno_numberfield",
                    name: "advRetainDay",
                    value: 1,
                    width: 60,
                    minValue: 1,
                    maxLength: 4
                }, {
                    xtype: "syno_displayfield",
                    value: i.T("common", "time_days")
                }]
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                height: 28,
                ref: "../advHourlyComp",
                items: [{
                    xtype: "syno_checkbox",
                    name: "advPolicyByHourly",
                    boxLabel: i.T("snapmgr", "ret_gfs_hours_description"),
                    checked: !0,
                    ref: "checkBox"
                }, {
                    xtype: "syno_displayfield",
                    width: 2,
                    value: ""
                }, {
                    xtype: "syno_numberfield",
                    name: "advHourly",
                    value: 24,
                    width: 60,
                    minValue: 1,
                    maxLength: 5,
                    ref: "numberfield",
                    listeners: {
                        disable: s,
                        scope: this
                    }
                }, {
                    xtype: "syno_displayfield",
                    value: i.T("common", "time_hours")
                }]
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                height: 28,
                ref: "../advDailyComp",
                items: [{
                    xtype: "syno_checkbox",
                    name: "advPolicyByDaily",
                    boxLabel: i.T("snapmgr", "ret_gfs_days_description"),
                    checked: !0,
                    ref: "checkBox"
                }, {
                    xtype: "syno_displayfield",
                    width: 2,
                    value: ""
                }, {
                    xtype: "syno_numberfield",
                    name: "advDaily",
                    value: 7,
                    width: 60,
                    minValue: 1,
                    maxLength: 5,
                    listeners: {
                        disable: s,
                        scope: this
                    }
                }, {
                    xtype: "syno_displayfield",
                    value: i.T("common", "time_days")
                }]
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                height: 28,
                ref: "../advWeeklyComp",
                items: [{
                    xtype: "syno_checkbox",
                    name: "advPolicyByWeekly",
                    boxLabel: i.T("snapmgr", "ret_gfs_weeks_description"),
                    checked: !0,
                    ref: "checkBox"
                }, {
                    xtype: "syno_displayfield",
                    width: 2,
                    value: ""
                }, {
                    xtype: "syno_numberfield",
                    name: "advWeekly",
                    value: 2,
                    width: 60,
                    minValue: 1,
                    maxLength: 4,
                    listeners: {
                        disable: s,
                        scope: this
                    }
                }, {
                    xtype: "syno_displayfield",
                    value: i.T("common", "time_weeks")
                }]
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                height: 28,
                ref: "../advMonthlyComp",
                items: [{
                    xtype: "syno_checkbox",
                    name: "advPolicyByMonthly",
                    boxLabel: i.T("snapmgr", "ret_gfs_months_description"),
                    checked: !0,
                    ref: "checkBox"
                }, {
                    xtype: "syno_displayfield",
                    width: 2,
                    value: ""
                }, {
                    xtype: "syno_numberfield",
                    name: "advMonthly",
                    value: 1,
                    width: 60,
                    minValue: 1,
                    maxLength: 3,
                    listeners: {
                        disable: s,
                        scope: this
                    }
                }, {
                    xtype: "syno_displayfield",
                    value: i.T("common", "time_months")
                }]
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                height: 28,
                ref: "../advYearlyComp",
                items: [{
                    xtype: "syno_checkbox",
                    name: "advPolicyByYearly",
                    boxLabel: i.T("snapmgr", "ret_gfs_years_description"),
                    checked: !0,
                    ref: "checkBox"
                }, {
                    xtype: "syno_displayfield",
                    width: 2,
                    value: ""
                }, {
                    xtype: "syno_numberfield",
                    name: "advYearly",
                    value: 1,
                    width: 60,
                    minValue: 1,
                    maxLength: 2,
                    listeners: {
                        disable: s,
                        scope: this
                    }
                }, {
                    xtype: "syno_displayfield",
                    value: i.T("common", "time_years")
                }]
            }, {
                xtype: "syno_displayfield",
                value: i.T("snapmgr", "ret_keep_versions_ensure_desc")
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                height: 28,
                items: [{
                    xtype: "syno_displayfield",
                    value: i.T("snapmgr", "ret_keep_versions_description"),
                    ref: "../../advMinimumComp",
                    isDirty: function() {
                        return !1
                    }
                }, {
                    xtype: "syno_numberfield",
                    name: "advMinimum",
                    value: 5,
                    width: 60,
                    minValue: 1,
                    maxValue: t.maxSnapshot,
                    maxLength: t.countDigitLength(t.maxSnapshot)
                }]
            }],
            o = {
                width: 660,
                height: 460,
                resizable: !1,
                title: i.T("iscsimgr", "setting"),
                id: t.id = Ext.id(),
                layout: "fit",
                buttons: [{
                    xtype: "syno_button",
                    text: i.T("common", "alt_cancel"),
                    scope: t,
                    handler: t.close
                }, {
                    itemId: "btApply",
                    xtype: "syno_button",
                    btnStyle: "blue",
                    text: i.T("common", "apply"),
                    scope: t,
                    handler: t.onApply
                }],
                items: [{
                    ref: "formpanel",
                    xtype: "syno_formpanel",
                    padding: "0px 20px 0px 20px",
                    me: t,
                    trackResetOnLoad: !0,
                    items: a
                }]
            };
        t.callParent([Ext.apply(o, e)]), t.mon(t, "afterlayout", function() {
            var e = t.formpanel.getForm();
            new SYNO.ux.Utils.EnableCheckGroup(e, "advPolicyByDay", ["advRetainDay"]), new SYNO.ux.Utils.EnableCheckGroup(e, "advPolicyByHourly", ["advHourly"]), new SYNO.ux.Utils.EnableCheckGroup(e, "advPolicyByDaily", ["advDaily"]), new SYNO.ux.Utils.EnableCheckGroup(e, "advPolicyByWeekly", ["advWeekly"]), new SYNO.ux.Utils.EnableCheckGroup(e, "advPolicyByMonthly", ["advMonthly"]), new SYNO.ux.Utils.EnableCheckGroup(e, "advPolicyByYearly", ["advYearly"])
        }, t, {
            single: !0
        })
    },
    countDigitLength: function(e) {
        return void 0 === e || isNaN(e) ? -1 : e.toString().length
    },
    adjustLayout: function() {
        var e = this,
            t = ["advDayComp", "advHourlyComp", "advDailyComp", "advWeeklyComp", "advMonthlyComp", "advYearlyComp"],
            i = Math.max.apply(Math, [e.advMinimumComp.getWidth()].concat(_toConsumableArray(t.map(function(t) {
                return e[t].checkBox.getWidth()
            })))) + 1;
        t.forEach(function(t) {
            return e[t].checkBox.setWidth(i)
        }), e.advMinimumComp.setWidth(i)
    },
    onOpen: function() {
        var e = this;
        e.loadData(), e.adjustLayout(), e.callParent()
    },
    loadData: function() {
        var e = this,
            t = {};
        void 0 !== e.advPolicyType && (t.advPolicyByDay = !!(SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_DAY & e.advPolicyType), t.advPolicyByHourly = !!(SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_HOURLY & e.advPolicyType), t.advPolicyByDaily = !!(SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_DAILY & e.advPolicyType), t.advPolicyByWeekly = !!(SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_WEEKLY & e.advPolicyType), t.advPolicyByMonthly = !!(SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_MONTHLY & e.advPolicyType), t.advPolicyByYearly = !!(SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_YEARLY & e.advPolicyType), t.advRetainDay = e.advRetainDay, t.advHourly = e.advHourly, t.advDaily = e.advDaily, t.advWeekly = e.advWeekly, t.advMonthly = e.advMonthly, t.advYearly = e.advYearly, t.advMinimum = e.advMinimum, e.formpanel.getForm().setValues(t))
    },
    addLinks: function(e) {
        var t = this;
        t.mon(Ext.get(t.helpLinkId), "click", function() {
            SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                topic: "SYNO.SDS.iSCSI.Application:snapshot.html",
                anchor: "smart_retention"
            }, !1)
        }, t)
    },
    onApply: function() {
        var e = this,
            t = e.formpanel.getForm();
        if (t.isValid()) {
            if (t.isDirty()) {
                var i = t.getValues();
                if ("false" === i.advPolicyByDay && "false" === i.advPolicyByHourly && "false" === i.advPolicyByDaily && "false" === i.advPolicyByWeekly && "false" === i.advPolicyByMonthly && "false" === i.advPolicyByYearly) return void e.owner.getMsgBox().alert("", SYNO.SDS.iSCSI.Utils.T("snapmgr", "ret_adv_at_least_one"));
                var n = {
                    advPolicyType: SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_MINIMUM
                };
                "true" === i.advPolicyByDay && (n.advPolicyType |= SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_DAY, n.advRetainDay = parseInt(i.advRetainDay, 10)), "true" === i.advPolicyByHourly && (n.advPolicyType |= SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_HOURLY, n.advHourly = parseInt(i.advHourly, 10)), "true" === i.advPolicyByDaily && (n.advPolicyType |= SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_DAILY, n.advDaily = parseInt(i.advDaily, 10)), "true" === i.advPolicyByWeekly && (n.advPolicyType |= SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_WEEKLY, n.advWeekly = parseInt(i.advWeekly, 10)), "true" === i.advPolicyByMonthly && (n.advPolicyType |= SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_MONTHLY, n.advMonthly = parseInt(i.advMonthly, 10)), "true" === i.advPolicyByYearly && (n.advPolicyType |= SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_YEARLY, n.advYearly = parseInt(i.advYearly, 10)), n.advMinimum = parseInt(i.advMinimum, 10), e.fireEvent("ret_adv_edited", n)
            }
            e.close()
        }
    }
}), Ext.define("SYNO.SDS.iSCSI.Schedule.MoreOption", {
    extend: "SYNO.SDS.iSCSI.ModalWindow",
    constructor: function(e) {
        for (var t = this, i = SYNO.SDS.iSCSI.Utils, n = e.minArr[0][1], s = 1; s < e.minArr.length; s++) e.minArr[s][1] == e.repeat_hour && (n = e.repeat_hour);
        t.repeat_hour_store = new Ext.data.ArrayStore({
            fields: ["display", "value"],
            data: e.minArr
        }), t.addManagedComponent(t.repeat_hour_store), t.org_repeat_hour = e.repeat_hour;
        var a = [{
                xtype: "syno_combobox",
                store: t.repeat_hour_store,
                value: n,
                fieldLabel: i.T("schedule", "schedule_every"),
                labelWidth: 150,
                displayField: "display",
                valueField: "value",
                id: t.repeat_hour_id = Ext.id(),
                triggerAction: "all",
                width: 170,
                editable: !1
            }],
            o = {
                xtype: "syno_panel",
                items: [{
                    xtype: "syno_displayfield",
                    htmlEncode: !1,
                    value: i.NoteRenderer(i.T("iscsimgr", "sched_more_option_note"))
                }]
            },
            r = {
                owner: e.owner,
                width: 400,
                resizable: !1,
                title: i.T("iscsimgr", "sched_more_option"),
                buttons: [{
                    xtype: "syno_button",
                    text: _T("common", "alt_cancel"),
                    scope: t,
                    handler: t.close
                }, {
                    itemId: "btApply",
                    xtype: "syno_button",
                    btnStyle: "blue",
                    text: _T("common", "apply"),
                    scope: t,
                    handler: t.onApply
                }],
                items: [{
                    xtype: "syno_formpanel",
                    border: !1,
                    height: 200,
                    items: a,
                    bbar: o
                }]
            };
        t.callParent([Ext.apply(r, e)])
    },
    onApply: function() {
        var e = this,
            t = Ext.getCmp(e.repeat_hour_id).getValue();
        e.org_repeat_hour != t && e.fireEvent("more_option_edited", {
            repeat_hour: t
        }), e.close()
    }
}), SYNO.SDS.iSCSI.UsageTpl = function() {
    return new Ext.XTemplate('<div class="iscsi-usage-box">', '<div class="iscsi-usage-bg">', '<div class="iscsi-usage-bar" style="width:{barWidth}%"></div>', "</div>", "<div>", '<div class="item-title iscsi-usage" style="font-weight: unset;font-size: unset; line-height: unset">{usage}</div>', "</div>", "</div>")
}, SYNO.SDS.iSCSI.PropertyTpl = function(e) {
    return void 0 === e && (e = "property"), new Ext.XTemplate('<div style="padding-top: 4px">', String.format('<tpl for="{0}">', e), '<dl style="padding-bottom: 4px">', '<dt class="iscsi-grid-property-name">{name}' + SYNO.SDS.iSCSI.Utils.T("common", "colon") + "</dt>", '<dt class="iscsi-grid-property-value">{value}', '<tpl if="this.hasValues(values.iconTip) == true">', '<div class="syno-ux-whitetip-icon iscsi-grid-property-icon" ext:wtip="{iconTip}" style="display:inline-block"></div>', "</tpl>", "</dt>", '<div style="clear:both"></div>', "</dl>", "</tpl>", '<div class="x-clear"></div>', "</div>")
}, SYNO.SDS.iSCSI.ProgressTpl = function() {
    return new Ext.XTemplate('<div class="iscsi-progress iscsi-progress-{displayProg}">', "<div>{progress}</div>", '<div class="iscsi-progress-bg">', '<div class="iscsi-progress-bar" style="width:{barWidth}px"></div>', "</div>", "</div>")
}, SYNO.SDS.iSCSI.ListTpl = function(e) {
    var t, i, n, s, a = [],
        o = [];
    return i = e.title || SYNO.SDS.iSCSI.Utils.T("smart", "smart_toolbar_disk_info"), t = e.emptyText || SYNO.SDS.iSCSI.Utils.T("volume", "volume_status_none"), n = 100 / e.columns.length, Ext.each(e.columns, function(e) {
        a.push(String.format('<dt class="iscsi-grid-list-column" style="width:calc({0}% - 8px)">{1}</dt>', n, e.header)), o.push(String.format('<dt class="iscsi-grid-list-column" style="width:calc({0}% - 8px)">{{1}}</dt>', n, e.dataIndex))
    }), s = new Ext.XTemplate(String.format('<tpl if="this.hasValues(values.{0}) == false">', e.scope), String.format('<div style="padding-left:10px;height:28px;line-height:28px">{0}</div>', t), "</tpl>", String.format('<tpl for="{0}">', e.scope), '<dl class="iscsi-grid-list-row">', o.join(""), '<div class="x-clear"></div>', "</dl>", "</tpl>"), new Ext.XTemplate(String.format('<div class="iscsi-grid-section-header iscsi-grid-section-header-bold">{0}</div>', i), '<div class="iscsi-grid-list">', '<div class="iscsi-grid-list-header">', '<dl style="padding-left:10px;">', a.join(""), '<div class="x-clear"></div>', "</dl>", "</div>", '<div class="iscsi-grid-list-body">', s.html, "</div>", "</div>", '<div class="x-clear"></div>')
}, SYNO.SDS.iSCSI.TargetTpl = function(e) {
    var t, i, n;
    return i = e.title || SYNO.SDS.iSCSI.Utils.T("smart", "smart_toolbar_disk_info"), t = e.emptyText || SYNO.SDS.iSCSI.Utils.T("volume", "volume_status_none"), n = new Ext.XTemplate(String.format('<tpl if="this.hasValues(values.{0}) == false">', e.scope), String.format('<div style="padding-left:10px;height:28px;line-height:28px">{0}</div>', t), "</tpl>", String.format('<tpl for="{0}">', e.scope), '<dl class="iscsi-grid-list-row">', '<dt class="iscsi-grid-list-column" style="width:calc(50% - 8px)">{name}</dt>', '<dt class="iscsi-grid-list-column" style="width:calc(50% - 8px)">{status}</dt>', '<div class="x-clear"></div>', "</dl>", "</tpl>"), new Ext.XTemplate(String.format('<div class="iscsi-grid-section-header iscsi-grid-section-header-bold">{0}</div>', i), '<div class="iscsi-grid-list">', '<div class="iscsi-grid-list-header">', '<dl style="padding-left:10px;">', String.format('<dt class="iscsi-grid-list-column" style="width:calc(50% - 8px)">{0}</dt>', SYNO.SDS.iSCSI.Utils.T("common", "name")), String.format('<dt class="iscsi-grid-list-column" style="width:calc(50% - 8px)">{0}</dt>', SYNO.SDS.iSCSI.Utils.T("volume", "volume_volumestatus")), '<div class="x-clear"></div>', "</dl>", "</div>", '<div class="iscsi-grid-list-body">', n.html, "</div>", "</div>", '<div class="x-clear"></div>')
}, SYNO.SDS.iSCSI.LunPrivTpl = function(e) {
    var t = SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_permission") + SYNO.SDS.iSCSI.Utils.T("common", "colon"),
        i = SYNO.SDS.iSCSI.Utils.T("san_lun", "no_permission_settings"),
        n = new Ext.XTemplate(String.format('<tpl if="this.hasValues(values.{0}) == false">', e.scope), String.format('<div style="padding-left:10px;height:28px;line-height:28px">{0}</div>', i), "</tpl>", String.format('<tpl for="{0}">', e.scope), '<dl class="iscsi-grid-list-row">', '<dt class="iscsi-grid-list-column" style="width:calc(40% - 8px)">{name}</dt>', '<dt class="iscsi-grid-list-column" style="width:calc(30% - 8px)">{description}</dt>', '<dt class="iscsi-grid-list-column" style="width:calc(30% - 8px)">{status}</dt>', '<div class="x-clear"></div>', "</dl>", "</tpl>");
    return new Ext.XTemplate(String.format('<tpl if="values.allow_all == false">', e.scope), String.format('<div class="iscsi-grid-section-header">{0}</div>', t), '<div class="iscsi-grid-list">', '<div class="iscsi-grid-list-header">', '<dl style="padding-left:10px;">', String.format('<dt class="iscsi-grid-list-column" style="width:calc(40% - 8px)">{0}</dt>', SYNO.SDS.iSCSI.Utils.T("san_host", "host")), String.format('<dt class="iscsi-grid-list-column" style="width:calc(30% - 8px)">{0}</dt>', SYNO.SDS.iSCSI.Utils.T("san_host", "description")), String.format('<dt class="iscsi-grid-list-column" style="width:calc(30% - 8px)">{0}</dt>', SYNO.SDS.iSCSI.Utils.T("common", "status")), '<div class="x-clear"></div>', "</dl>", "</div>", '<div class="iscsi-grid-list-body">', n.html, "</div>", "</div>", '<div class="x-clear"></div>', "</tpl>", String.format('<tpl if="values.allow_all == true">'), "<dl>", String.format('<dt class="iscsi-grid-property-name">{0}</dt>', t), String.format('<dt class="iscsi-grid-property-value">{0}</dt>', SYNO.SDS.iSCSI.Utils.T("san_lun", "allow_all")), '<div class="x-clear"></div>', "</dl>", "</tpl>")
}, SYNO.SDS.iSCSI.SnapshotTpl = function() {
    var e = SYNO.SDS.iSCSI.ScheduleTpl(),
        t = SYNO.SDS.iSCSI.PropertyTpl("snapshotProp"),
        i = new Ext.XTemplate('<tpl if="support_snapshot === true">', e.html, "</tpl>", t.html);
    return Ext.destroy(e), Ext.destroy(t), i
}, SYNO.SDS.iSCSI.ScheduleTpl = function() {
    var e, t;
    return e = new Ext.XTemplate('<tpl if="this.hasValues(values.scheduleTask) === false">', String.format('<div style="padding-left:10px;height:28px;line-height:28px">{0}</div>', SYNO.SDS.iSCSI.Utils.T("iscsimgr", "snap_no_schedule")), "</tpl>", '<tpl for="scheduleTask">', '<dl class="iscsi-grid-list-row">', '<dt class="iscsi-grid-list-column" style="width:calc(40% - 8px)">{type}</dt>', '<dt class="iscsi-grid-list-column" style="width:calc(30% - 8px)">{date}</dt>', '<dt class="iscsi-grid-list-column" style="width:calc(30% - 8px)">{freq}</dt>', '<div class="x-clear"></div>', "</dl>", "</tpl>"), t = new Ext.XTemplate(String.format('<div class="iscsi-grid-section-header iscsi-grid-section-header-bold" style="margin-top: 0px">{0}</div>', SYNO.SDS.iSCSI.Utils.T("iscsimgr", "snap_snapshot_schedule")), '<div class="iscsi-grid-list">', '<div class="iscsi-grid-list-header">', '<dl style="padding-left:10px;">', String.format('<dt class="iscsi-grid-list-column" style="width:calc(40% - 8px)">{0}</dt>', SYNO.SDS.iSCSI.Utils.T("iscsimgr", "snap_schedule_snapshot_type")), String.format('<dt class="iscsi-grid-list-column" style="width:calc(30% - 8px)">{0}</dt>', SYNO.SDS.iSCSI.Utils.T("iscsimgr", "sche_exec_day")), String.format('<dt class="iscsi-grid-list-column" style="width:calc(30% - 8px)">{0}</dt>', SYNO.SDS.iSCSI.Utils.T("iscsimgr", "sche_repeat_every")), '<div class="x-clear"></div>', "</dl>", "</div>", '<div class="iscsi-grid-list-body" style="margin-bottom: 8px">', e.html, "</div>", "</div>", '<div class="x-clear"></div>'), Ext.destroy(e), t
}, SYNO.SDS.iSCSI.applyWithRetention = function(e, t, i) {
    t ? e.getMsgBox().confirm(SYNO.SDS.iSCSI.Utils.T("common", "common_settings"), SYNO.SDS.iSCSI.Utils.T("iscsimgr", "run_retention_immed"), function(e) {
        "ok" === e && i()
    }, e, Ext.MessageBox.OKCANCEL) : i()
}, SYNO.SDS.iSCSI.GetDRErrMsg = function(e) {
    var t;
    switch (e) {
        case 1001:
            t = SYNO.SDS.iSCSI.Utils.T("s2s", "err_invalid_param_value");
            break;
        case 1002:
            t = SYNO.SDS.iSCSI.Utils.T("iscsimgr", "err_get_ret_policy");
            break;
        case 1003:
            t = SYNO.SDS.iSCSI.Utils.T("iscsimgr", "err_set_ret_policy");
            break;
        default:
            t = SYNO.SDS.iSCSI.Utils.T("common", "error_system")
    }
    return t
}, SYNO.SDS.iSCSI.LUNSnapGetErrMsg = function(e, t) {
    var i;
    switch (e) {
        case 18990543:
            i = String.format(SYNO.SDS.iSCSI.Utils.T("iscsilun", "iscsitrg_max_snapshot_per_lun"), _D("max_snapshot_per_lun", "256"));
            break;
        case 18990002:
            i = SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_set_failed_space_not_enough");
            break;
        case 18990535:
            i = SYNO.SDS.iSCSI.Utils.T("backup", "target_busy");
            break;
        case 18990540:
            i = SYNO.SDS.iSCSI.Utils.T("snapmgr", "snap_system_preserved");
            break;
        default:
            i = SYNO.SDS.iSCSI.Utils.T("common", "error_system")
    }
    return i
}, Ext.define("SYNO.SDS.iSCSI.Comp.TextItem", {
    extend: "Ext.Toolbar.TextItem",
    onRender: function(e, t) {
        this.autoEl = {
            cls: "xtb-text",
            html: this.text || "",
            "ext:qtip": this.text || ""
        }, SYNO.SDS.iSCSI.Comp.TextItem.superclass.onRender.call(this, e, t)
    },
    setText: function(e) {
        SYNO.SDS.iSCSI.Comp.TextItem.superclass.setText.call(this, e), this.rendered && this.el.set({
            "ext:qtip": e
        })
    }
}), Ext.reg("lctbtext", SYNO.SDS.iSCSI.Comp.TextItem), Ext.define("SYNO.SDS.iSCSI.LUN.DisplayField", {
    extend: "SYNO.ux.DisplayField",
    rawData: void 0,
    height: 28,
    setValue: function(e) {
        if (this.callParent(arguments), this.rawData = e, this.originalValue = e, void 0 !== e && void 0 !== this.store) {
            for (var t = 0; t < this.store.length; t++)
                if (e === this.store[t][0]) return void this.callParent([this.store[t][1]]);
            if (void 0 !== this.store.data && void 0 !== this.store.data.items)
                for (var i = 0; i < this.store.data.items.length; i++)
                    if (e == this.store.data.items[i].data.value) return void this.callParent([this.store.data.items[i].data.display])
        }
    },
    getValue: function() {
        return void 0 !== this.rawData ? this.rawData : this.callParent(arguments)
    },
    enable: function() {},
    disable: function() {},
    isDirty: function() {
        return !1
    }
}), Ext.reg("syno_lun_displayfield", SYNO.SDS.iSCSI.LUN.DisplayField), Ext.define("SYNO.SDS.SAN.LUN.Selecting.GridPanel", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(e) {
        var t = this;
        t.owner = e.owner, t.appWin = e.appWin, t.parent = e.parent, t.protocol = e.protocol, t.hidebbar = e.hidebbar;
        var i = t.createEnableColumn(),
            n = {
                plugins: [i],
                columns: [i, {
                    id: "name",
                    header: SYNO.SDS.iSCSI.Utils.T("san_lun", "lun"),
                    dataIndex: "name",
                    renderer: SYNO.SDS.iSCSI.Utils.htmlSelectingGridEncodeRender
                }, {
                    id: "description",
                    header: SYNO.SDS.iSCSI.Utils.T("san_host", "description"),
                    dataIndex: "description",
                    renderer: SYNO.SDS.iSCSI.Utils.htmlSelectingGridEncodeRender
                }, {
                    id: "note",
                    header: SYNO.SDS.iSCSI.Utils.T("san_host", "detail"),
                    dataIndex: "note",
                    hidden: !0,
                    renderer: function(e, i, n) {
                        if (n.get("note")) return t.getColumnModel().setHidden(3, !1), SYNO.SDS.iSCSI.Utils.htmlSelectingGridEncodeRender(n.get("note"), i, n)
                    }
                }],
                store: t.createStore(),
                enableHdMenu: !1,
                enableColumnMove: !1,
                autoScroll: !0,
                cls: "without-dirty-red-grid bbar-note-no-padding iscsi-remove-sort-icon",
                listeners: {
                    activate: function() {
                        t.setMask()
                    }
                },
                bbar: {
                    xtype: "syno_panel",
                    padding: "0px 0px",
                    style: "border-top-color: #EBF0F5; border-width: 1px 0 0;",
                    items: [{
                        xtype: "syno_displayfield",
                        padding: "0px 0px",
                        htmlEncode: !1,
                        value: String.format('<span style="color:green">{0}: </span><span>{1}</span>', SYNO.SDS.iSCSI.Utils.T("common", "note"), "iscsi" === t.protocol ? SYNO.SDS.iSCSI.Utils.T("san_host", "desc_list_luns_only_iscsi") : SYNO.SDS.iSCSI.Utils.T("san_host", "desc_list_luns_only_fc"))
                    }],
                    hidden: t.hidebbar || !t.appWin.hasFibreChannels()
                }
            };
        t.callParent([Ext.apply(n, e)])
    },
    configEnableColumn: function() {
        return {
            dataIndex: "checked",
            width: 40,
            align: "center",
            bindRowClick: !0,
            renderer: function(e, t, i) {
                return i.get("banned") ? SYNO.SDS.iSCSI.Utils.htmlSelectingGridEncodeRender("-", t, i) : SYNO.ux.EnableColumn.prototype.renderer.call(this, e, t, i)
            },
            isIgnore: function(e, t) {
                return t.get("banned")
            }
        }
    },
    createEnableColumn: function() {
        return new SYNO.ux.EnableColumn(this.configEnableColumn())
    },
    createStore: function() {
        var e = this;
        return new Ext.data.JsonStore({
            autoDestory: !0,
            idProperty: "name",
            fields: ["checked", {
                name: "name",
                sortType: "asNaturalUCString"
            }, "uuid", "description", "status", "mapped_target_type", "enabled", "note", "allow_all", "auto_selected", "sort_type", "banned"],
            sortInfo: {
                field: "name",
                direction: "ASC"
            },
            listeners: {
                load: function() {
                    e.parent && e.parent.fireEvent("data_change")
                },
                update: function() {
                    e.parent && e.parent.fireEvent("data_change")
                }
            }
        })
    },
    loadLUN: function(e) {
        var t = this,
            i = t.processData(e);
        t.getStore().loadData(t.decorateData(i))
    },
    processData: function(e) {
        var t = this,
            i = t.appWin.volumes,
            n = t.appWin.pools;
        return t.appWin.iscsiLuns.getAll().filter(function(s) {
            switch (e) {
                case "edit":
                    return s.canBeMapped(i, n) && s.get("mappingType") === t.protocol;
                case "delete":
                    return s.canBeDeleted(i, n) && s.get("mappingType") === t.protocol;
                default:
                    return !1
            }
        }).map(function(e) {
            return {
                checked: !0,
                uuid: e.get("uuid"),
                name: e.get("name"),
                description: e.get("description"),
                status: e.getSummaryStatus(i, n, t.appWin.isLowCapacityWriteEnable())
            }
        })
    },
    decorateData: function(e) {
        return e
    },
    setMask: function() {
        var e = this;
        0 === e.getStore().getCount() && e.mask(SYNO.SDS.iSCSI.Utils.T("lun", "no_lun"), "syno-ux-mask-info"), 0 < e.getStore().getCount() && e.unmask()
    }
}), Ext.define("SYNO.SDS.SAN.CardsMainPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.panels = e.panels, t.callParent([t.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = this,
            i = {
                layout: "card",
                activeItem: null,
                items: t.panels,
                listeners: {
                    activate: t.onActivate,
                    data_ready: t.onDataReady,
                    scope: t
                }
            };
        return Ext.apply(i, e)
    },
    onActivate: function() {
        var e = this;
        e.appWin.setStatusBusy(), e.appWin.fireEvent("poll_activate")
    },
    onDataReady: function() {}
}), Ext.define("SYNO.SDS.SAN.EmptyMainPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.callParent([t.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = {
            layout: {
                type: "vbox",
                align: "center",
                pack: "center"
            },
            items: [{
                xtype: "label",
                cls: "iscsi-empty-text-icon"
            }, {
                xtype: "label",
                style: {
                    padding: "10px 0px 0px"
                }
            }]
        };
        return Ext.apply(t, e)
    }
}), SYNO.SDS.iSCSI.RTT_KEEP_ALL = 1 << 31, SYNO.SDS.iSCSI.RTT_ALL = 0, SYNO.SDS.iSCSI.RTT_POL_TIME = 1, SYNO.SDS.iSCSI.RTT_DEL_OLD = 20, SYNO.SDS.iSCSI.RTT_DEL_OLD_DEPRECATED = 16, SYNO.SDS.iSCSI.RTT_TRRIGER_BY_TIME = 32, SYNO.SDS.iSCSI.RTT_BY_DAY = 64, SYNO.SDS.iSCSI.RTT_BY_ADVANCE = 128, SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_MINIMUM = 1, SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_HOURLY = 2, SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_DAILY = 4, SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_WEEKLY = 8, SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_MONTHLY = 16, SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_YEARLY = 32, SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_DAY = 64, SYNO.SDS.iSCSI.TARGET_TYPE_UNKNOWN = 0, SYNO.SDS.iSCSI.TARGET_TYPE_LUN = 1, SYNO.SDS.iSCSI.TARGET_TYPE_SHARE = 2, SYNO.SDS.iSCSI.ROLE_UNKNOWN = 0, SYNO.SDS.iSCSI.ROLE_MAINSITE = 1, SYNO.SDS.iSCSI.ROLE_DRSITE = 2, SYNO.SDS.iSCSI.SOLUTION_UNKNOWN = 0, SYNO.SDS.iSCSI.SOLUTION_SYNOLOGY_DR = 1, SYNO.SDS.iSCSI.SOLUTION_VMWARE_SRM = 2, SYNO.SDS.iSCSI.LUN_ADVANCED = 8, SYNO.SDS.iSCSI.REPLICATED_SITE_MAX = 3, SYNO.SDS.iSCSI.DEFAULT_MAX_REPLICA = "64", SYNO.SDS.iSCSI.DATASITE_MAX = 4, SYNO.SDS.iSCSI.STATUS_ALL = "all", SYNO.SDS.iSCSI.STATUS_REPLICA = "isReplica", SYNO.SDS.iSCSI.STATUS_SCHEDULE = "isSchedule", SYNO.SDS.iSCSI.STATUS_NOT_SUPPORT = "notSupport", SYNO.SDS.iSCSI.STATUS_NO_PROTECTED = "notProtected", SYNO.SDS.iSCSI.STATUS_NOT_MANAGEABLE = "notManageable", SYNO.SDS.iSCSI.STATUS_VOLUME_CRASHED = "volCrashed", SYNO.SDS.iSCSI.STATUS_VOLUME_READONLY = "volReadOnly", SYNO.SDS.iSCSI.DSM_HTTP_PORT = 5e3, SYNO.SDS.iSCSI.DSM_HTTPS_PORT = 5001, SYNO.SDS.iSCSI.STATUS_LOCAL_PREFIX = "local_", SYNO.SDS.iSCSI.STATUS_REMOTE_PREFIX = "remote_", SYNO.SDS.iSCSI.TARGET_NAME_HOMES = "homes", SYNO.SDS.iSCSI.ADVREPLICA_ENC_SHARE = "encrypted_share", SYNO.SDS.iSCSI.ADVREPLICA_HOMES = "homes", SYNO.SDS.iSCSI.LUN_TYPE_BTRFS = "btrfs", SYNO.SDS.iSCSI.LUN_TYPE_ADV = "adv", SYNO.SDS.iSCSI.LUN_TYPE_NOT_SUPPORT = "notSupport", SYNO.SDS.iSCSI.RET_TRIGGER_BY_TIME = "trigger_by_time", SYNO.SDS.iSCSI.READONLY_HELP_WEB_LINK = "https://www.synology.com/zh-tw/knowledgebase/DSM/tutorial/Virtualization/What_should_I_do_when_my_Thin_Provisioned_iSCSI_LUN_is_read_only", Ext.define("SYNO.SDS.iSCSI.Overview.HealthPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        this.iconTpl = this.createIconTpl(), this.titleTpl = this.createTitleTpl(), this.upperPanel = this.createUpperPanel(), this.lowerPanel = this.createLowerPanel(), this.descMapping = {
            normal: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "status_desc_good"),
            target_abnormal: [SYNO.SDS.iSCSI.Utils.T("iscsimgr", "target_status_desc_abnormal"), SYNO.SDS.iSCSI.Utils.T("iscsimgr", "target_status_desc_abnormal_multi")],
            fc_target_abnormal: [SYNO.SDS.iSCSI.Utils.T("iscsimgr", "fctarget_status_desc_abnormal"), SYNO.SDS.iSCSI.Utils.T("iscsimgr", "fctarget_status_desc_abnormal_multi")],
            soft_limit_reach: [SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_desc_soft_limit"), SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_desc_soft_limit_multi")],
            low_capacity_write_should_turn_off: [SYNO.SDS.iSCSI.Utils.T("iscsimgr", "low_capacity_write_should_turn_off"), SYNO.SDS.iSCSI.Utils.T("iscsimgr", "low_capacity_write_should_turn_off")],
            hard_limit_reach_without_low_capacity_write: [SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_desc_hard_limit_without_low_capacity"), SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_desc_hard_limit_without_low_capacity_multi")],
            hard_limit_reach: [SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_desc_hard_limit"), SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_desc_hard_limit_multi")],
            low_capacity_write_on: [SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_desc_low_capacity_write_on"), SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_desc_low_capacity_write_on_multi")],
            volume_degrade: [SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_desc_volume_degrade"), SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_desc_volume_degrade_multi")],
            volume_crashed: [SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_desc_volume_crash"), SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_desc_volume_crash_multi")],
            volume_read_only: [SYNO.SDS.iSCSI.Utils.T("lun", "lun_status_desc_read_only"), SYNO.SDS.iSCSI.Utils.T("lun", "lun_status_desc_read_only_multi")],
            cache_crashed: [SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_desc_cache_crash"), SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_desc_cache_crash_multi")],
            unavailabling: [SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_desc_unavailabling"), SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_desc_unavailabling_multi")],
            Unhealthy: [SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_desc_clone_fail"), SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_desc_clone_fail_multi")]
        };
        var t = {
            layout: "hbox",
            cls: "iscsi-overview-health-panel",
            autoHeight: !0,
            items: [{
                xtype: "box",
                itemId: "icon",
                cls: "health-icon-block"
            }, {
                xtype: "syno_panel",
                itemId: "rightPanel",
                cls: "health-text-block",
                flex: 1,
                height: 96,
                layout: "vbox",
                layoutConfig: {
                    align: "stretch"
                },
                items: [this.upperPanel, this.lowerPanel]
            }],
            listeners: {
                scope: this,
                data_ready: this.onDataReady
            }
        };
        return Ext.apply(t, e), t
    },
    createIconTpl: function() {
        return new Ext.XTemplate('<div class="health-icon {status}"></div>', {
            compiled: !0,
            disableFormats: !0
        })
    },
    createTitleTpl: function() {
        return new Ext.XTemplate('<div class="health-text-title {status}">{[this.getStatusText(values.status)]}</div>', {
            compiled: !0,
            disableFormats: !0,
            statusText: {
                normal: SYNO.SDS.iSCSI.Utils.T("widget", "good_status"),
                warning: SYNO.SDS.iSCSI.Utils.T("log", "warn_level"),
                error: SYNO.SDS.iSCSI.Utils.T("log", "crit_level")
            },
            getStatusText: function(e) {
                return this.statusText[e]
            }
        })
    },
    createUpperPanel: function() {
        return new SYNO.ux.Panel({
            layout: "hbox",
            items: [{
                xtype: "box",
                itemId: "title",
                flex: 1,
                cls: "iscsi-overview-health-title-block"
            }, {
                xtype: "syno_button",
                itemId: "leftBtn",
                hidden: !0,
                cls: "iscsi-overview-health-prev-btn",
                scope: this,
                handler: this.onLeftBtnClick,
                text: " "
            }, {
                xtype: "syno_button",
                itemId: "rightBtn",
                hidden: !0,
                cls: "iscsi-overview-health-next-btn",
                scope: this,
                handler: this.onRightBtnClick,
                text: " "
            }]
        })
    },
    createLowerPanel: function() {
        return new SYNO.ux.Panel({
            flex: 1,
            items: [{
                xtype: "syno_displayfield",
                itemId: "desc",
                cls: "health-text-content",
                htmlEncode: !1,
                setValue: function(e, t) {
                    if (this.constructor.prototype.setValue.apply(this, arguments), "fc_target_abnormal" !== t) {
                        var i = this.getEl().query("a")[0],
                            n = Ext.get(i),
                            s = function(e) {
                                e.preventDefault(), SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance", {
                                    fn: "SYNO.SDS.StorageManager.Volume.Main"
                                })
                            };
                        n && SYNO.SDS.iSCSI.Utils.T("volume", "storage_manager") === i.text && this.mon(n, "click", s, this)
                    }
                }
            }]
        })
    },
    updateDesc: function(e) {
        var t, i, n = this,
            s = -1,
            a = this.descs.length,
            o = this.getComponent("rightPanel"),
            r = this.lowerPanel.getComponent("desc"),
            l = this.upperPanel.getComponent("leftBtn"),
            S = this.upperPanel.getComponent("rightBtn"),
            d = r.getHeight(),
            c = o.getHeight(),
            p = !1;
        if (0 === a) i = this.descMapping.normal, r.setValue(i);
        else {
            for (var u = 0; u < this.descs.length; ++u) {
                var h = this.descs[u];
                if (n.curDesc && n.curDesc.location && n.curDesc.location === h.location || n.curDesc && !n.curDesc.location && n.curDesc.status == h.status) {
                    s = u;
                    break
                }
            }
            t = -1 === s ? 0 : "cur" === e ? s : "prev" === e ? 0 === s ? a - 1 : s - 1 : s === a - 1 ? 0 : s + 1, this.curDesc = this.descs[t], i = "low_capacity_write_on" === this.curDesc.status ? String.format(this.descMapping[this.curDesc.status][this.curDesc.num > 1 ? 1 : 0], this.curDesc.num, SYNO.SDS.iSCSI.Utils.volumePathRenderer(this.curDesc.location), String.format('<a target="_blank" rel="noopener noreferrer" href="{0}">', SYNO.SDS.iSCSI.READONLY_HELP_WEB_LINK), "</a>") : "hard_limit_reach_without_low_capacity_write" === this.curDesc.status || "hard_limit_reach" === this.curDesc.status || "soft_limit_reach" === this.curDesc.status ? String.format(this.descMapping[this.curDesc.status][this.curDesc.num > 1 ? 1 : 0], this.curDesc.num, SYNO.SDS.iSCSI.Utils.volumePathRenderer(this.curDesc.location), String.format('<a target="_blank" rel="noopener noreferrer" href="{0}">', SYNO.SDS.iSCSI.READONLY_HELP_WEB_LINK), "</a>", '<a class="link-font" href="">', "</a>") : "fc_target_abnormal" === this.curDesc.status ? String.format(this.descMapping[this.curDesc.status][this.curDesc.num > 1 ? 1 : 0], this.curDesc.num, '<a target="_blank" rel="noopener noreferer" href="https://www.synology.com/company/contact_us">', "</a>") : "hard_limit_reach_without_low_capacity_write" === this.curDesc.status || "soft_limit_reach" === this.curDesc.status || "hard_limit_reach" === this.curDesc.status ? String.format(this.descMapping[this.curDesc.status][this.curDesc.num > 1 ? 1 : 0], this.curDesc.num, SYNO.SDS.iSCSI.Utils.volumePathRenderer(this.curDesc.location), String.format('<a target="_blank" rel="noopener noreferrer" href="{0}">', SYNO.SDS.iSCSI.READONLY_HELP_WEB_LINK), "</a>", '<a class="link-font" href="">', "</a>") : String.format(this.descMapping[this.curDesc.status][this.curDesc.num > 1 ? 1 : 0], this.curDesc.num, String.format('<a class="link-font" style="cursor:pointer">{0}</a>', SYNO.SDS.iSCSI.Utils.T("volume", "storage_manager"))), r.setValue(i, this.curDesc.status)
        }
        var m = r.getHeight();
        if (m !== d && (c = c - d + m, p = !0), p && (o.height = c, this.doLayout(), this.owner.doLayout()), this.descs.length <= 1) return l.hide(), void S.hide();
        (l.hidden || S.hidden) && (l.show(), S.show(), this.doLayout())
    },
    prepareSummaryStatus: function(e, t) {
        var i = this,
            n = i.appWin.iscsiLuns.getAll(),
            s = i.appWin.volumes,
            a = i.appWin.pools,
            o = i.appWin.iscsiTargets.getAll(),
            r = !1;
        if (Ext.each(n, function(n) {
                var o = n.get("location"),
                    l = n.getSpace(s, a),
                    S = parseInt(l.size_free_byte, 10),
                    d = n.getCrashType(i.appWin.volumes, i.appWin.pools, i.appWin.isLowCapacityWriteEnable());
                n.isThinProvisioningLun() && S < SYNO.SDS.iSCSI.TP_HARD_THRESHOLD_DEFAULT_SIZE && (r = !0), "hard_limit_reach_without_low_capacity_write" === d || "hard_limit_reach" === d || "soft_limit_reach" === d || "low_capacity_write_on" === d ? t.hasOwnProperty(o) ? t[o].count += 1 : t[o] = {
                    stat: d,
                    count: 1
                } : e[d]++
            }), !r && i.appWin.isLowCapacityWriteEnable() && (e.low_capacity_write_should_turn_off = 1), e.target_abnormal = o.filter(function(e) {
                return e.get("is_enabled") && "offline" === e.get("status")
            }).length, i.appWin.supportFC) {
            var l = i.appWin.fcTargets.getAll();
            e.fc_target_abnormal = l.filter(function(e) {
                return !e.get("is_enabled") && "disabled" !== e.get("status")
            }).length
        }
    },
    onLeftBtnClick: function() {
        this.updateDesc("prev")
    },
    onRightBtnClick: function() {
        this.updateDesc("next")
    },
    onDataReady: function() {
        var e = {
                normal: "normal",
                soft_limit_reach: "warning",
                volume_degrade: "warning",
                target_abnormal: "warning",
                fc_target_abnormal: "warning",
                Unhealthy: "warning",
                low_capacity_write_should_turn_off: "warning",
                hard_limit_reach_without_low_capacity_write: "error",
                hard_limit_reach: "error",
                low_capacity_write_on: "error",
                volume_crashed: "error",
                volume_read_only: "error",
                cache_crashed: "error",
                unavailabling: "error"
            },
            t = {
                normal: 0,
                low_capacity_write_should_turn_off: 0,
                target_abnormal: 0,
                fc_target_abnormal: 0,
                volume_crashed: 0,
                volume_read_only: 0,
                cache_crashed: 0,
                unavailabling: 0,
                volume_degrade: 0,
                Unhealthy: 0
            },
            i = {},
            n = "normal";
        this.prepareSummaryStatus(t, i), this.descs = [];
        for (var s in e)
            if (t.hasOwnProperty(s)) {
                if ("normal" === s) continue;
                0 < t[s] && (n = e[s], this.descs.push({
                    status: s,
                    num: t[s]
                }))
            } for (var a in i)
            if (i.hasOwnProperty(a)) {
                var o = i[a].stat,
                    r = i[a].count;
                if ("normal" === o) continue;
                0 < r && (n = e[o], this.descs.push({
                    status: o,
                    num: r,
                    location: a
                }))
            } this.iconTpl.overwrite(this.getComponent("icon").getEl(), {
            status: n
        }), this.titleTpl.overwrite(this.upperPanel.getComponent("title").getEl(), {
            status: n
        }), this.updateDesc("cur")
    }
}), Ext.define("SYNO.SDS.iSCSI.Overview.StatusBoxTmpl", {
    extend: "Ext.XTemplate",
    constructor: function(e) {
        var t = this.createTpl();
        t.push(this.fillConfig(e)), this.callParent(t)
    },
    fillConfig: function(e) {
        var t = {
                compiled: !0,
                disableFormats: !0
            },
            i = {
                fctarget: SYNO.SDS.iSCSI.Utils.T("san_fibre", "fibre_channel"),
                target: "iSCSI",
                lun: "LUN",
                event: SYNO.SDS.iSCSI.Utils.T("schedule", "event"),
                status: {
                    fctarget: {
                        healthy: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_status_connected"),
                        warning: SYNO.SDS.iSCSI.Utils.T("log", "warn_level")
                    },
                    target: {
                        healthy: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_status_connected"),
                        warning: SYNO.SDS.iSCSI.Utils.T("log", "warn_level")
                    },
                    lun: {
                        healthy: SYNO.SDS.iSCSI.Utils.T("iscsilun", "healthy"),
                        warning: SYNO.SDS.iSCSI.Utils.T("log", "warn_level"),
                        error: SYNO.SDS.iSCSI.Utils.T("log", "crit_level")
                    },
                    event: {
                        healthy: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "unread"),
                        warning: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "unread_warn"),
                        error: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "unread_crit")
                    }
                }
            };
        return t.getTranslate = function(e) {
            return i[e]
        }, t.getStatusText = function(e, t) {
            return "fctarget" === e ? i.status.fctarget[t] : "target" === e ? i.status.target[t] : "lun" === e ? i.status.lun[t] : "event" === e ? i.status.event[t] : void 0
        }, t.isBothErrorWarn = function(e, t) {
            return 0 !== e && 0 !== t
        }, t.showNumber = function(e) {
            return e > 99 ? "99+" : e
        }, Ext.apply(t, e)
    },
    createTpl: function() {
        return ['<div class="iscsi-overview-statusbox iscsi-overview-statusbox-{type} iscsi-overview-statusbox-{errorlevel} iscsi-overview-statusbox-{clickType}">', '<div class="statusbox-titlebar"></div>', '<div class="statusbox-box">', '<div class="statusbox-title">', "<h3>{[ this.getTranslate(values.type) ]}</h3>", "</div>", '<div class="statusbox-title-right">', "<h3>{[ this.showNumber(values.total) ]}</h3>", "</div>", '<div class="x-clear"></div>', '<div class="statusbox-title-padding">', "</div>", '<tpl if="this.isBothErrorWarn(error, warning)">', '<div class="statusbox-halfblock-left statusbox-block-error">', '<div class="statusbox-number">{[ this.showNumber(values.error) ]}</div>', '<div class="statusbox-text" ext:qtip="{[ this.getStatusText(values.type, "error") ]}">{[ this.getStatusText(values.type, "error") ]}</div>', "</div>", '<div class="statusbox-halfblock-right statusbox-block-warning">', '<div class="statusbox-number">{[ this.showNumber(values.warning) ]}</div>', '<div class="statusbox-text" ext:qtip="{[ this.getStatusText(values.type, "warning") ]}">{[ this.getStatusText(values.type, "warning") ]}</div>', "</div>", "</tpl>", '<tpl if="! this.isBothErrorWarn(error, warning)">', '<div class="statusbox-block statusbox-block-{errorlevel}">', '<div class="statusbox-number">{[ this.showNumber(values[values.errorlevel]) ]}</div>', '<div class="statusbox-text" ext:qtip="{[ this.getStatusText(values.type, values.errorlevel) ]}">{[ this.getStatusText(values.type, values.errorlevel) ]}</div>', "</div>", "</tpl>", "</div>", "</div>"]
    }
}), Ext.define("SYNO.SDS.iSCSI.Overview.StatusBox", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        this.appWin = e.appWin, this.tpl = new SYNO.SDS.iSCSI.Overview.StatusBoxTmpl;
        var t = {
            items: [{
                itemId: "statusBox",
                xtype: "box",
                cls: "iscsi-overview-statusbox-block",
                html: ""
            }],
            listeners: {
                scope: this,
                afterrender: this.onAfterRender,
                update: this.updateTpl,
                data_ready: this.onDataReady
            }
        };
        return Ext.apply(t, e), t
    },
    onAfterRender: function() {
        this.mon(this.body, "click", this.onMouseClick, this)
    },
    updateTpl: function() {
        this.tpl.overwrite(this.getComponent("statusBox").getEl(), Ext.apply({
            type: this.type,
            clickType: this.owner.clickedBox === this.type ? "click" : "unclick",
            errorlevel: this.errorlevel,
            total: this.data.total || this.data.error + this.data.warning + this.data.healthy
        }, this.data))
    },
    onMouseClick: function() {
        this.owner.fireEvent("selectchange", this.type)
    },
    processFCTrgSummary: function() {
        var e = this,
            t = e.appWin.fcTargets.getAll();
        e.data.total = 0, Ext.each(t, function(t) {
            e.data.total++, "connected" === t.get("status") ? e.data.healthy++ : t.get("is_enabled") || !1 !== t.get("status") || e.data.warning++
        }, e)
    },
    processTrgSummary: function() {
        var e = this,
            t = e.appWin.iscsiTargets.getAll();
        e.data.total = 0, Ext.each(t, function(t) {
            e.data.total++, "connected" === t.get("status") ? e.data.healthy++ : t.get("is_enabled") && "offline" === t.get("status") && e.data.warning++
        }, e)
    },
    processLUNSummary: function() {
        var e = this,
            t = e.appWin.iscsiLuns.getAll();
        Ext.each(t, function(t) {
            var i = "healthy";
            t.isSummaryWarning(this.appWin.volumes, this.appWin.pools) ? i = "warning" : t.isSummaryCrashed(this.appWin.volumes, this.appWin.pools, this.appWin.isLowCapacityWriteEnable()) && (i = "error"), e.data[i]++
        }, e)
    },
    processEventSummary: function() {
        var e = this.appWin.summary;
        this.data.warning = e.warn_count ? e.warn_count : 0, this.data.error = e.error_count ? e.error_count : 0, this.data.healthy = e.info_count ? e.info_count : 0
    },
    onDataReady: function() {
        switch (this.data = {
                error: 0,
                warning: 0,
                healthy: 0
            }, this.storeKey) {
            case "fc_target_summ":
                this.processFCTrgSummary();
                break;
            case "target_summ":
                this.processTrgSummary();
                break;
            case "lun_summ":
                this.processLUNSummary();
                break;
            case "event_summ":
                this.processEventSummary()
        }
        this.errorlevel = 0 !== this.data.error ? "error" : 0 !== this.data.warning ? "warning" : "healthy", this.updateTpl()
    }
}), Ext.define("SYNO.SDS.iSCSI.Overview.StatusBoxsPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = {
            owner: this,
            appWin: e.appWin,
            flex: 1
        };
        this.clickedBox = "lun", this.statusBoxs = [new SYNO.SDS.iSCSI.Overview.StatusBox(Ext.apply({
            type: "lun",
            title: "LUN",
            storeKey: "lun_summ"
        }, t)), new SYNO.ux.Panel({
            width: 10
        }), new SYNO.SDS.iSCSI.Overview.StatusBox(Ext.apply({
            type: "target",
            title: "Target",
            storeKey: "target_summ"
        }, t)), new SYNO.ux.Panel({
            width: 10
        }), new SYNO.SDS.iSCSI.Overview.StatusBox(Ext.apply({
            type: "fctarget",
            title: "FCTarget",
            storeKey: "fc_target_summ"
        }, t)), new SYNO.ux.Panel({
            width: 10
        }), new SYNO.SDS.iSCSI.Overview.StatusBox(Ext.apply({
            type: "event",
            title: SYNO.SDS.iSCSI.Utils.T("schedule", "event"),
            storeKey: "event_summ"
        }, t))], e.appWin.supportFC || this.statusBoxs.splice(4, 2);
        var i = {
            cls: "iscsi-overview-status-panel",
            layout: "hbox",
            layoutConfig: {
                align: "stretch"
            },
            items: this.statusBoxs,
            listeners: {
                scope: this,
                selectchange: this.onSelectChange,
                data_ready: this.onDataReady
            }
        };
        return Ext.apply(i, e), i
    },
    onSelectChange: function(e) {
        this.clickedBox = e, Ext.each(this.statusBoxs, function(e) {
            e.fireEvent("update")
        }), this.owner.panels.detailPanel.fireEvent("select", e)
    },
    onDataReady: function() {
        Ext.each(this.statusBoxs, function(e) {
            e.fireEvent("data_ready")
        })
    }
}), Ext.define("SYNO.SDS.iSCSI.Overview.ListViewTmpl", {
    extend: "Ext.XTemplate",
    utils: SYNO.SDS.iSCSI.Utils,
    constructor: function(e) {
        this.owner = e.owner;
        var t = this.createTpl();
        t.push(this.fillConfig(e)), this.callParent(t)
    },
    fillConfig: function(e) {
        var t = {
            compiled: !0,
            disableFormats: !0
        };
        return t.getTitleClass = function(e) {
            return "none" === e ? "iscsi-title-no-status" : ""
        }, t.getShort = function(e) {
            return 3 < e.length ? (e = e.slice(0, 3), e.join(", ") + ",...") : e.join(", ")
        }, t.getFull = function(e) {
            return e.join(", ")
        }, t.getMapTrgName = function(e) {
            var t = e.mapped_trgs[e.mapTrgIdx];
            return t ? t.name : ""
        }, t.getMapTrgStatus = function(e) {
            var t = e.mapped_trgs[e.mapTrgIdx];
            return t ? t.status : ""
        }, t.hasAnyMappedTrg = function(e) {
            return e.mapped_trgs.length > 0
        }, t.hasMultiMappedTrg = function(e) {
            return e.mapped_trgs.length > 1
        }, t.getLUNUsedInfo = function(e) {
            return e.is_thin_provision ? String.format("{0} / {1}", e.allocated_size, e.size) : e.size
        }, t.getLUNUsedRatio = function(e) {
            return e.totalUsed / e.totalSize * 100
        }, t.getSpacePath = function(e) {
            if (e.is_block_lun) {
                var t = this.owner.getPoolInfo(e.location).pool_id;
                return SYNO.SDS.iSCSI.Utils.SpaceIDParser(t).str
            }
            return String.format("{0} {1}", SYNO.SDS.iSCSI.Utils.T("volume", "volume"), this.owner.getVolumeInfo(e.location).vol_id)
        }, t.getSpaceUsedRatio = function(e) {
            var t, i = {},
                n = Math.pow(10, 2);
            return e.is_block_lun ? (i = this.owner.getPoolInfo(e.location), t = i.used_size / i.total_size * 100) : (i = this.owner.getVolumeInfo(e.location), t = (i.total_size - i.free_size) / i.total_size * 100), Math.round(t * n) / n
        }, t.getPoolPath = function(e) {
            return ""
        }, Ext.apply(t, e)
    },
    createTpl: function() {
        return ['<tpl for=".">', '<div class="item-wrap iscsi-overview-detail-{type}" id="{id}">', '<div class="item-summary">', '<div class="item-icon iscsi-overview-detail-icon iscsi-overview-detail-icon-{cls}"></div>', "<tpl if=\"type != 'healthy'\">", '<div class="item-icon-status iscsi-overview-detail-status iscsi-overview-detail-status-{type}"></div>', "</tpl>", '<div class="iscsi-title-area">', '<div class="iscsi-title {[ this.getTitleClass(values.status) ]}">', '<div ext:qtip="{name}" class="item-title">{name}</div>', '<div class="item-status">{values.status}</div>', "</div>", "</div>", '<div class="iscsi-desc-area">', "<tpl if=\"cls =='fctarget'\">", "<div>", '<div class="iscsi-space">', '<div class="iscsi-sizespace-info">', '<div class="iscsi-sizespace-title">WWPN</div>', '<div class="x-clear"></div>', "</div>", '<div ext:qtip="{values.desc}" class="iscsi-trg-iqn">{values.desc}</div>', "</div>", "</div>", "</tpl>", "<tpl if=\"cls =='target'\">", '<div class="iscsi-mapping-wrap">', '<div class="iscsi-space">', '<div class="iscsi-sizespace-info">', '<div class="iscsi-sizespace-title">Mapped LUNs</div>', '<div class="x-clear"></div>', "</div>", '<div ext:qtip="{[ this.getFull(values.mapped_luns) ]}" class="iscsi-maplun">{[ this.getFull(values.mapped_luns) ]}</div>', "</div>", "</div>", '<div class="iscsi-mapping-wrap-ex">', '<div class="iscsi-space">', '<div class="iscsi-sizespace-info">', '<div class="iscsi-sizespace-title">IQN</div>', '<div class="x-clear"></div>', "</div>", '<div ext:qtip="{values.desc}" class="iscsi-trg-iqn">{values.desc}</div>', "</div>", "</div>", "</tpl>", "<tpl if=\"cls =='lun'\">", '<div class="iscsi-maptrg-wrap">', '<tpl if="this.hasAnyMappedTrg(values)">', '<div class="iscsi-maptrg-title-wrap">', '<div ext:qtip="{[ this.getMapTrgName(values) ]}" class="iscsi-maptrg-title">{[ this.getMapTrgName(values) ]}</div>', '<tpl if="this.hasMultiMappedTrg(values)">', '<div class="iscsi-maptrg-title-icon"></div>', "</tpl>", '<div class="x-clear"></div>', "</div>", '<div class="item-status">{[ this.getMapTrgStatus(values) ]}</div>', "</tpl>", '<tpl if="!this.hasAnyMappedTrg(values)">', '<div class="iscsi-maptrg-no-title">', "-", "</div>", "</tpl>", "</div>", '<div class="iscsi-mapping-wrap" style="float: right">', '<div class="iscsi-space">', '<div class="iscsi-sizespace-info">', '<div class="iscsi-sizespace-title">{[ this.getSpacePath(values) ]} ({[ this.getSpaceUsedRatio(values) ]}%)</div>', '<div class="x-clear"></div>', "</div>", '<div class="iscsi-sizespace-bar">', '<div class="iscsi-sizespace-bar-progress" style="width: {[ this.getSpaceUsedRatio(values) ]}%"></div>', "</div>", "</div>", "</div>", '<div class="iscsi-mapping-wrap" style="float: right">', '<div class="iscsi-size">', '<div class="iscsi-sizespace-info">', '<div class="iscsi-sizespace-title">{[ this.getLUNUsedInfo(values) ]}</div>', '<div class="x-clear"></div>', "</div>", '<div class="iscsi-sizespace-bar">', '<div class="iscsi-sizespace-bar-progress" style="width: {[ this.getLUNUsedRatio(values) ]}%"></div>', "</div>", "</div>", "</div>", "</tpl>", "</div>", "</div>", "</div>", "</tpl>", '<div class="x-clear"></div>']
    }
}), Ext.define("SYNO.SDS.iSCSI.Overview.ListView", {
    extend: "SYNO.ux.ExpandableListView",
    constructor: function(e) {
        this.owner = e.owner, this.callParent([e])
    },
    createTpl: function(e) {
        return new SYNO.SDS.iSCSI.Overview.ListViewTmpl(e)
    },
    onClick: function(e, t, i) {
        var n = Ext.fly(t),
            s = e.getTarget(this.itemSelector, this.getTemplateTarget()),
            a = null,
            o = n.getXY();
        s && (a = this.getRecord(s)), n.hasClass("iscsi-maptrg-title-icon") && !this.menuShowed ? (o[0] = o[0] - 45, this.onMapTrgClick(this, e, a, o)) : (this.menuShowed = !1, this.callParent(arguments))
    },
    onMapTrgClick: function(e, t, i, n) {
        var s = i.data.mapped_trgs,
            a = [];
        a = a.concat(s.map(function(e, t) {
            var n = {};
            return n.id = i.data.id, n.idx = t, new Ext.Action({
                text: e.name,
                scope: this,
                data: n,
                handler: this.onMapTrgChange
            })
        }, this));
        var o = new SYNO.ux.Menu({
            items: a
        });
        n[1] = n[1] + 18, o.showAt(n), this.menuShowed = !0
    },
    onMapTrgChange: function(e) {
        this.owner.fireEvent("trgselectchange", e.data.id, e.data.idx), this.menuShowed = !1
    }
}), Ext.define("SYNO.SDS.iSCSI.Overview.DetailFCTargetPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        this.store = this.createStore(), this.listView = this.createListView(e);
        var t = {
            title: "",
            layout: "fit",
            items: [this.listView],
            listeners: {
                scope: this,
                activate: this.onActivate,
                data_ready: this.onActivate
            }
        };
        return Ext.apply(t, e), t
    },
    createStore: function() {
        var e = ["id", {
            name: "name",
            sortType: "asNaturalUCString"
        }, "status", "cls", "type", "desc", "mapped_luns"];
        return new Ext.data.JsonStore({
            autoDestroy: !0,
            idProperty: "id",
            fields: e,
            sortInfo: {
                field: "name",
                direction: "ASC"
            }
        })
    },
    createListView: function(e) {
        return new SYNO.SDS.iSCSI.Overview.ListView({
            owner: this,
            appWin: e.appWin,
            store: this.store,
            customizeEmptyText: SYNO.SDS.iSCSI.Utils.T("san_trg", "iscsitrg_no_fcport"),
            trackResetOnLoad: !1
        })
    },
    getMappedLuns: function(e) {
        var t = this,
            i = t.appWin.iscsiLuns,
            n = [];
        return e.get("mapped_luns").forEach(function(e) {
            var t = i.getById(e.lun_uuid);
            n.push(t.get("name"))
        }), n
    },
    prepareUiData: function() {
        var e, t = this,
            i = t.appWin.fcTargets.getAll();
        delete t.uiData, t.uiData = [], Ext.each(i, function(i) {
            e = {}, e.cls = "fctarget", e.status = SYNO.SDS.iSCSI.Utils.FCStatusRender(i.get("status")), e.type = "healthy", e.id = i.get("target_id").toString(), e.name = i.get("displayPort"), e.desc = i.get("wwpn"), e.mapped_luns = t.getMappedLuns(i), t.uiData.push(e)
        })
    },
    onActivate: function() {
        var e = this;
        e.prepareUiData(), e.store.loadData(e.uiData)
    }
}), Ext.define("SYNO.SDS.iSCSI.Overview.DetailTargetPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        this.store = this.createStore(), this.listView = this.createListView(e);
        var t = {
            title: "",
            layout: "fit",
            items: [this.listView],
            listeners: {
                scope: this,
                activate: this.onActivate,
                data_ready: this.onActivate
            }
        };
        return Ext.apply(t, e), t
    },
    createStore: function() {
        var e = ["id", {
            name: "name",
            sortType: "asNaturalUCString"
        }, "status", "cls", "type", "desc", "mapped_luns"];
        return new Ext.data.JsonStore({
            autoDestroy: !0,
            idProperty: "id",
            fields: e,
            sortInfo: {
                field: "name",
                direction: "ASC"
            }
        })
    },
    createListView: function(e) {
        return new SYNO.SDS.iSCSI.Overview.ListView({
            owner: this,
            appWin: e.appWin,
            store: this.store,
            customizeEmptyText: "<div>" + SYNO.SDS.iSCSI.Utils.T("san_mgr", "empty_text_iscsi") + "</div><div>" + String.format(SYNO.SDS.iSCSI.Utils.T("san_mgr", "empty_text_iscsi_link"), "iSCSI", '<a class="link-font" href="">', "</a>") + "</div>",
            trackResetOnLoad: !1
        })
    },
    getMappedLuns: function(e) {
        var t = this,
            i = t.appWin.iscsiLuns,
            n = [];
        return e.get("mapped_luns").forEach(function(e) {
            var t = i.getById(e.lun_uuid);
            n.push(t.get("name"))
        }), n
    },
    prepareUiData: function() {
        var e, t = this,
            i = t.appWin.iscsiTargets.getAll();
        delete t.uiData, t.uiData = [], Ext.each(i, function(i) {
            e = {}, e.cls = "target", e.status = SYNO.SDS.iSCSI.Utils.TargetStatusRender(i.get("status")), e.type = "healthy", e.id = i.get("target_id").toString(), e.name = i.get("name"), e.desc = i.get("iqn"), e.mapped_luns = t.getMappedLuns(i), t.uiData.push(e)
        })
    },
    onActivate: function() {
        var e = this;
        e.prepareUiData(), e.store.loadData(e.uiData), e.addLink()
    },
    addLink: function() {
        var e = this;
        if (0 === e.uiData.length) {
            var t = e.listView.el.select("a");
            t && e.mon(t, "click", function(t) {
                t.preventDefault(), e.appWin.selectPage("SYNO.SDS.iSCSI.Target.Main");
                var i = e.appWin.activePage;
                i && i.onCreate && i.onCreate()
            })
        }
    }
}), Ext.define("SYNO.SDS.iSCSI.Overview.DetailLUNPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        this.lastSelectTrg = {}, this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        this.store = this.createStore(), this.listView = this.createListView(e);
        var t = {
            title: "",
            layout: "fit",
            items: [this.listView],
            listeners: {
                scope: this,
                trgselectchange: this.onTrgSelectChange,
                activate: this.onActivate,
                data_ready: this.onActivate
            }
        };
        return Ext.apply(t, e), t
    },
    createStore: function() {
        var e = ["id", "lun_uuid", {
            name: "name",
            sortType: "asNaturalUCString"
        }, "status", "cls", "type", "is_thin_provision", "is_block_lun", "location", "size", "allocated_size", "totalSize", "totalUsed", "totalUsed", "volume_path", "mapTrgIdx", "mapped_trgs"];
        return new Ext.data.JsonStore({
            autoDestroy: !0,
            idProperty: "id",
            fields: e,
            sortInfo: {
                field: "name",
                direction: "ASC"
            }
        })
    },
    createListView: function(e) {
        return new SYNO.SDS.iSCSI.Overview.ListView({
            owner: this,
            appWin: e.appWin,
            store: this.store,
            customizeEmptyText: "<div>" + SYNO.SDS.iSCSI.Utils.T("lun", "no_lun") + "</div><div>" + String.format(SYNO.SDS.iSCSI.Utils.T("san_mgr", "empty_text_lun_link"), "LUN", '<a class="link-font" href="">', "</a>") + "</div>",
            trackResetOnLoad: !1
        })
    },
    getVolumeInfo: function(e) {
        var t = this,
            i = t.appWin.volumes,
            n = {};
        return Ext.each(i, function(t) {
            if (t.volume_path === e) return n.vol_id = t.volume_id, n.free_size = t.size_free_byte, n.total_size = t.size_total_byte, n
        }), n
    },
    getPoolInfo: function(e) {
        var t = SYNO.SDS.iSCSI.Utils,
            i = this.appWin.pools;
        return t.getLUNPoolInfo(i, e)
    },
    prepareLastSelectTrg: function(e, t) {
        var i = this,
            n = e.get("uuid"),
            s = 0;
        if (void 0 === i.lastSelectTrg[n]) return void(t.mapTrgIdx = 0);
        for (; s < t.mapped_trgs.length && t.mapped_trgs[s].name !== i.lastSelectTrg[n]; s++);
        t.mapTrgIdx = s < t.mapped_trgs.length ? s : 0
    },
    prepareSummary: function(e, t) {
        var i = "healthy";
        e.isSummaryWarning(this.appWin.volumes, this.appWin.pools) ? i = "warning" : e.isSummaryCrashed(this.appWin.volumes, this.appWin.pools) && (i = "error"), t.id = e.get("lun_id"), t.lun_uuid = e.get("uuid"), t.status = e.getSummaryStatus(this.appWin.volumes, this.appWin.pools), t.type = i, t.is_thin_provision = e.isThinProvisioningLun(), t.is_block_lun = e.isBlockLun(), t.totalSize = parseInt(e.get("size"), 10), t.totalUsed = parseInt(e.get("allocated_size"), 10), t.location = e.get("location"), t.name = e.get("name"), t.mapped_trgs = this.appWin.getMappedTrgs(e.get("uuid"), !0)
    },
    prepareFileLunProperty: function(e, t) {
        var i = SYNO.SDS.iSCSI.Utils;
        t.size = i.SizeRender(e.get("size")), t.allocated_size = i.SizeRender(e.get("allocated_size"))
    },
    prepareUiData: function() {
        var e, t = this,
            i = t.appWin.iscsiLuns.getAll();
        delete t.uiData, t.uiData = [], Ext.each(i, function(i) {
            e = {}, e.cls = "lun", t.prepareSummary(i, e), t.prepareFileLunProperty(i, e), t.prepareLastSelectTrg(i, e), t.uiData.push(e)
        }, t)
    },
    onTrgSelectChange: function(e, t) {
        var i = this.store.getById(e),
            n = i.data.lun_uuid;
        this.lastSelectTrg[n] = i.data.mapped_trgs[t].name, i.set("mapTrgIdx", t)
    },
    onActivate: function() {
        var e = this;
        e.prepareUiData(), e.store.loadData(e.uiData), e.addLink()
    },
    addLink: function() {
        var e = this;
        if (0 === e.uiData.length) {
            var t = e.listView.el.select("a");
            t && e.mon(t, "click", function(t) {
                t.preventDefault(), e.appWin.selectPage("SYNO.SDS.iSCSI.LUN.Main"), e.appWin.activePage.createFromLink = !0
            })
        }
    }
}), Ext.define("SYNO.SDS.iSCSI.Overview.DetailEventPanel", {
    extend: "SYNO.ux.GridPanel",
    total: 100,
    refreshInterval: 5e3,
    constructor: function(e) {
        var t, i = this;
        i.pollingTask = this.createPollingTask(), i.scrollDownFlag = !1, i.scrollPosition = 0, i.last_date_from = 0, Ext.apply(i, e), t = i.fillConfig(e), i.callParent([t])
    },
    onPageActivate: function() {
        this.onActive()
    },
    getPageRecordStore: function() {
        return new Ext.data.SimpleStore({
            fields: ["value", "display"],
            data: [
                [100, 100],
                [500, 500],
                [1e3, 1e3],
                [3e3, 3e3]
            ]
        })
    },
    initEvents: function() {
        this.mon(this, "activate", this.onActive, this), this.mon(this, "deactivate", this.onDeactive, this)
    },
    getStore: function() {
        return new SYNO.API.Store({
            api: "SYNO.Core.ISCSI.Node",
            version: 1,
            method: "log_list",
            appWindow: this.appWin,
            remoteSort: !1,
            reader: new Ext.data.JsonReader({
                idProperty: "id",
                root: "logs",
                totalProperty: "summary.total",
                fields: [{
                    name: "log_level",
                    mapping: "log_level"
                }, {
                    name: "time",
                    mapping: "time"
                }, {
                    name: "user",
                    mapping: "user"
                }, {
                    name: "event",
                    mapping: "event"
                }]
            }),
            listeners: {
                exception: this.loadException,
                beforeload: this.onBeforeStoreLoad,
                load: this.onAfterStoreLoad,
                scope: this
            }
        })
    },
    logLevelRenderer: function(e) {
        switch (e) {
            case "err":
                return "<span class='red-status'>Error</span>";
            case "warning":
                return "<span class='orange-status'>Warning</span>";
            case "info":
                return "<span class='green-status'>Information</span>";
            default:
                return "Undefined"
        }
    },
    htmlTimeRender: function(e) {
        var t = new Date(1e3 * e);
        return SYNO.SDS.DateTimeFormatter(t, {
            type: "datetimesec"
        })
    },
    htmlEncodeRender: function(e, t) {
        var i = Ext.util.Format.htmlEncode(e);
        return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(i) + '"', i
    },
    getColumnModel: function() {
        return new Ext.grid.ColumnModel({
            columns: [{
                header: SYNO.SDS.iSCSI.Utils.T("common", "attr_priority"),
                dataIndex: "log_level",
                width: 100,
                align: "left",
                renderer: this.logLevelRenderer
            }, {
                header: SYNO.SDS.iSCSI.Utils.T("log", "log_time"),
                dataIndex: "time",
                width: 150,
                align: "left",
                renderer: this.htmlTimeRender
            }, {
                header: SYNO.SDS.iSCSI.Utils.T("log", "log_account"),
                dataIndex: "user",
                width: 100,
                align: "left",
                renderer: SYNO.SDS.iSCSI.Utils.htmlEncodeRender
            }, {
                id: "descr",
                header: SYNO.SDS.iSCSI.Utils.T("log", "log_action"),
                dataIndex: "event",
                css: "white-space:normal;",
                width: 300,
                renderer: SYNO.SDS.iSCSI.Utils.htmlEventEncodeRender
            }],
            defaults: {
                sortable: !1,
                menuDisabled: !1
            }
        })
    },
    fillConfig: function(e) {
        var t = this;
        t.logStore = t.getStore(), t.bufferView = new SYNO.ux.FleXcroll.grid.BufferView({
            rowHeight: 27,
            scrollDelay: 30,
            borderHeight: 1,
            trackResetOnLoad: !1,
            emptyText: SYNO.SDS.iSCSI.Utils.EmptyMsgRender(SYNO.SDS.iSCSI.Utils.T("log", "no_log_available")),
            templates: {
                cell: new Ext.XTemplate('<td class="x-grid3-col x-grid3-cell x-grid3-td-{id} x-selectable {css}" style="{style}" tabIndex="-1" {cellAttr}>', '<div class="{this.selectableCls} x-grid3-cell-inner x-grid3-col-{id}" {attr}>{value}</div>', "</td>", {
                    selectableCls: SYNO.SDS.Utils.SelectableCLS
                })
            },
            listeners: {
                scope: t,
                flexcroll: t.scrollHandler
            }
        });
        var i = {
            border: !1,
            trackResetOnLoad: !0,
            title: "",
            layout: "fit",
            itemId: "iscsi_log",
            enableColumnMove: !1,
            enableHdMenu: !1,
            store: t.logStore,
            colModel: t.getColumnModel(),
            view: t.bufferView,
            loadMask: !0,
            stripeRows: !0
        };
        return Ext.apply(i, e), i
    },
    scrollHandler: function() {
        var e = this.scrollPosition,
            t = this.bufferView.getScrollTop();
        t > e ? (this.scrollDownFlag = !0, e = t) : 0 === t && this.scrollDownFlag && (this.setUnread(), this.scrollDownFlag = !1)
    },
    isTheSame: function(e, t) {
        var i;
        for (i in t)
            if (t[i] !== e[i]) return !1;
        return !0
    },
    onActive: function() {
        this.last_date_from = 0, this.pollingTask.start(!0)
    },
    onDeactive: function() {
        this.pollingTask.stop()
    },
    loadException: function() {
        this.setMask(!0)
    },
    onBeforeStoreLoad: function(e, t) {
        this.setMask(!1)
    },
    onAfterStoreLoad: function(e, t, i) {
        this.logStore.getCount() < 1 ? this.setMask(!0) : this.setMask(!1)
    },
    setMask: function(e) {
        SYNO.SDS.iSCSI.Utils.SetEmptyIcon(this, e)
    },
    setUnread: function() {
        var e = this;
        e.sendWebAPI({
            api: "SYNO.Core.ISCSI.Node",
            version: 1,
            method: "log_list",
            params: {
                additional: ["update_unread"]
            },
            scope: e
        })
    },
    createPollingTask: function() {
        return this.addWebAPITask({
            scope: this,
            api: "SYNO.Core.ISCSI.Node",
            method: "log_list",
            version: 1,
            params: {
                date_from: this.last_date_from,
                additional: ["unread"]
            },
            interval: this.refreshInterval,
            callback: function(e, t, i, n) {
                if (e) {
                    var s = {
                            err: 2,
                            warning: 1,
                            info: 0
                        },
                        a = t.logs;
                    if (0 === this.last_date_from && this.setUnread(), 0 !== this.last_date_from) {
                        var o = Ext.pluck(this.logStore.data.items, "json");
                        a = a.concat(o)
                    }
                    t.logs.length > 0 && (this.last_date_from = t.logs[0].time), a.sort(function(e, t) {
                        return e.log_level !== t.log_level ? s[t.log_level] - s[e.log_level] : t.time - e.time
                    }).slice(0, this.total), this.logStore.loadData({
                        summary: t.summary,
                        logs: a
                    })
                }
            }
        })
    },
    setLogLevelText: function(e, t, i, n, s) {
        e && (s = s || "0", e.setText(String.format(t, i, n, s)))
    },
    destroy: function() {
        this.rowNav && (Ext.destroy(this.rowNav), this.rowNav = null), this.callParent([this])
    }
}), Ext.define("SYNO.SDS.iSCSI.Overview.DetailTabPanel", {
    extend: "SYNO.ux.TabPanel",
    constructor: function(e) {
        this.appWin = e.appWin, this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        this.panels = {
            lun: new SYNO.SDS.iSCSI.Overview.DetailLUNPanel({
                appWin: this.appWin,
                itemId: "lun"
            }),
            target: new SYNO.SDS.iSCSI.Overview.DetailTargetPanel({
                appWin: this.appWin,
                itemId: "target"
            }),
            fctarget: new SYNO.SDS.iSCSI.Overview.DetailFCTargetPanel({
                appWin: this.appWin,
                itemId: "fctarget"
            }),
            event: new SYNO.SDS.iSCSI.Overview.DetailEventPanel({
                appWin: this.appWin,
                itemId: "event"
            })
        }, e.appWin.supportFC || delete this.panels.fctarget;
        var t = {
            cls: "iscsi-overview-detail",
            items: Object.values(this.panels),
            listeners: {
                scope: this,
                select: this.onSelect,
                data_ready: this.onSelect
            }
        };
        return Ext.apply(t, e), t
    },
    onSelect: function(e) {
        this.owner.loaded && ("event" !== e ? this.addClass("iscsi-overview-detail-top-border") : this.removeClass("iscsi-overview-detail-top-border"), this.setActiveTab(e), this.panels[e].fireEvent("data_ready"))
    }
}), Ext.define("SYNO.SDS.iSCSI.Overview.Main", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        this.loaded = !1, this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        this.panels = {
            healthPanel: new SYNO.SDS.iSCSI.Overview.HealthPanel({
                appWin: e.appWin,
                owner: this
            }),
            statusBoxsPanel: new SYNO.SDS.iSCSI.Overview.StatusBoxsPanel({
                appWin: e.appWin,
                owner: this
            }),
            detailPanel: new SYNO.SDS.iSCSI.Overview.DetailTabPanel({
                appWin: e.appWin,
                owner: this,
                flex: 1
            })
        };
        var t = {
            layout: "vbox",
            cls: "blue-border",
            layoutConfig: {
                align: "stretch"
            },
            items: Object.values(this.panels),
            listeners: {
                scope: this,
                activate: this.onActivate,
                deactivate: this.onDeactive,
                data_ready: this.onDataReady
            }
        };
        return Ext.apply(t, e), t
    },
    onActivate: function() {
        var e = this;
        e.panels.detailPanel.fireEvent("select", e.panels.statusBoxsPanel.clickedBox), e.loaded || e.appWin.setStatusBusy(null, null, 50), e.appWin.fireEvent("poll_activate")
    },
    onDeactive: function() {
        this.panels.detailPanel.fireEvent("deactivate", this.panels.statusBoxsPanel.clickedBox)
    },
    onDataReady: function() {
        var e = this;
        e.loaded || (e.appWin.clearStatusBusy(), e.loaded = !0), e.panels.healthPanel.fireEvent("data_ready"), e.panels.statusBoxsPanel.fireEvent("data_ready"), e.panels.detailPanel.fireEvent("data_ready", e.panels.statusBoxsPanel.clickedBox)
    }
}), Ext.define("SYNO.SDS.SAN.Fibre.ConnectionStatus", {
    extend: "SYNO.SDS.iSCSI.ModalWindow",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner;
        var i = {
            title: SYNO.SDS.iSCSI.Utils.T("san_fibre", "connected_client"),
            layout: "fit",
            width: 800,
            height: 500,
            resizable: !1,
            closable: !0,
            items: [t.gridpanel = t.getGridpanel()]
        };
        t.callParent([Ext.apply(i, e)])
    },
    onOpen: function() {
        var e = this;
        e.callParent(arguments), e.initValues()
    },
    initValues: function() {
        var e = this;
        e.gridpanel.getStore().loadData(function() {
            return e.appWin.fcTargets.getAll().reduce(function(t, i) {
                var n = function(e, t) {
                    return t.initiator_ids.some(function(t) {
                        return t === e.wwpn
                    })
                };
                return t = t.concat(i.get("connected_sessions").map(function(t) {
                    var s = e.owner.hosts.find(function(e) {
                        return n(t, e)
                    });
                    return {
                        wwpn: t.wwpn,
                        host: s ? s.name : "-",
                        port: i.get("displayPort"),
                        duration: t.login_duration
                    }
                }))
            }, [])
        }()), e.gridpanel.store.getCount() || e.gridpanel.mask(SYNO.SDS.iSCSI.Utils.EmptyPlanTextRender(SYNO.SDS.iSCSI.Utils.T("san_fibre", "desc_no_connected_session")), "iscsi-no-hover")
    },
    getGridpanel: function() {
        return new SYNO.ux.GridPanel({
            enableHdMenu: !1,
            enableColumnMove: !1,
            colModel: this.getColumnModel(),
            store: this.getStore(),
            cls: "iscsi-remove-sort-icon"
        })
    },
    getColumnModel: function() {
        return new Ext.grid.ColumnModel({
            columns: [{
                header: "WWPN",
                dataIndex: "wwpn",
                width: 150,
                sortable: !0,
                renderer: SYNO.SDS.iSCSI.Utils.htmlEncodeRender
            }, {
                header: SYNO.SDS.iSCSI.Utils.T("san_host", "host"),
                dataIndex: "host",
                width: 100,
                renderer: SYNO.SDS.iSCSI.Utils.htmlEncodeRender
            }, {
                header: SYNO.SDS.iSCSI.Utils.T("common", "port"),
                dataIndex: "port",
                width: 100,
                renderer: SYNO.SDS.iSCSI.Utils.htmlEncodeRender
            }, {
                header: SYNO.SDS.iSCSI.Utils.T("san_fibre", "connected_duration"),
                dataIndex: "duration",
                width: 150,
                renderer: function(e, t) {
                    var i = Math.floor(e / 864e5),
                        n = Math.floor(e % 864e5 / 36e5),
                        s = Math.floor(e % 864e5 % 36e5 / 6e4),
                        a = String.format("{0} {1} {2} {3} {4} {5}", i, SYNO.SDS.iSCSI.Utils.T("san_fibre", "day"), n, SYNO.SDS.iSCSI.Utils.T("san_fibre", "hour"), s, SYNO.SDS.iSCSI.Utils.T("san_fibre", "minute"));
                    return SYNO.SDS.iSCSI.Utils.htmlEncodeRender(a, t)
                }
            }]
        })
    },
    getStore: function() {
        return new Ext.data.JsonStore({
            autoDestroy: !0,
            fields: ["wwpn", "host", "port", "duration"],
            sortInfo: {
                field: "wwpn",
                direction: "ASC"
            }
        })
    }
}), Ext.define("SYNO.SDS.SAN.Fibre.Main", {
    extend: "SYNO.SDS.SAN.CardsMainPanel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.panels = [t.emptyPage = new SYNO.SDS.SAN.Fibre.EmptyMain({
            appWin: t.appWin,
            owner: t.owner,
            itemId: "emptyPage"
        }), t.normalPage = new SYNO.SDS.SAN.Fibre.NormalMain({
            appWin: t.appWin,
            owner: t.owner,
            itemId: "normalPage"
        })];
        var i = {
            panels: t.panels
        };
        t.callParent([Ext.apply(i, e)])
    },
    onDataReady: function() {
        var e = this;
        e.appWin.clearStatusBusy(), e.appWin.fcTargets.getAll().length ? (e.getLayout().setActiveItem("normalPage"), e.normalPage.fireEvent("data_ready")) : e.getLayout().setActiveItem("emptyPage")
    }
}), Ext.define("SYNO.SDS.SAN.Fibre.EmptyMain", {
    extend: "SYNO.SDS.SAN.EmptyMainPanel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.callParent([e])
    },
    fillConfig: function(e) {
        var t = this,
            i = t.callParent([e]);
        return i.items.push({
            xtype: "label",
            text: SYNO.SDS.iSCSI.Utils.T("san_fibre", "desc_no_fctarget"),
            cls: "iscsi-empty-text"
        }), i
    }
}), Ext.define("SYNO.SDS.SAN.Fibre.NormalMain", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        var t = this;
        t.owner = e.owner, t.appWin = e.appWin, t.callParent([t.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = this,
            i = {
                title: SYNO.SDS.iSCSI.Utils.T("common", "port"),
                layout: "fit",
                tbar: t.toolbar = new Ext.Toolbar({
                    defaultType: "syno_button",
                    style: "border-bottom: 0px",
                    items: [{
                        itemId: "enable",
                        text: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_enable"),
                        handler: t.onFlip,
                        disabled: !0,
                        hidden: !0,
                        scope: t
                    }, {
                        itemId: "disable",
                        text: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_disable"),
                        handler: t.onFlip,
                        disabled: !0,
                        hidden: !0,
                        scope: t
                    }, {
                        itemId: "status",
                        text: SYNO.SDS.iSCSI.Utils.T("san_fibre", "connected_client"),
                        handler: t.onStatus,
                        scope: t
                    }]
                }),
                items: [t.gridpanel = this.getGridPanel()],
                listeners: {
                    activate: t.onActivate,
                    data_ready: t.onDataReady,
                    scope: t
                }
            };
        return Ext.apply(i, e), i
    },
    onActivate: function() {
        var e = this;
        e.loaded || (e.body.unmask(), e.appWin.setStatusBusy(), e.toolbar.getComponent("status").setDisabled(!1)), e.appWin.fireEvent("poll_activate")
    },
    onDataReady: function() {
        var e = this;
        e.loadStore(), e.loaded || e.appWin.clearStatusBusy(), e.appWin.genLunMappingType()
    },
    onFlip: function() {
        var e = this,
            t = e.gridpanel.selModel.getSelected();
        e.owner.setStatusBusy({
            text: SYNO.SDS.iSCSI.Utils.T("common", "saving")
        }), e.sendWebAPI({
            api: "SYNO.Core.ISCSI.FCTarget",
            method: t.get("enabled") ? "disable" : "enable",
            version: 1,
            params: {
                target_id: t.get("target_id")
            },
            callback: function(t, i) {
                t || SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(e.owner, i), e.appWin.restartPollTask()
            }
        })
    },
    onStatus: function() {
        new SYNO.SDS.SAN.Fibre.ConnectionStatus({
            owner: this.owner,
            appWin: this.appWin
        }).open()
    },
    getGridPanel: function() {
        return this.store = this.getStore(), {
            xtype: "syno_gridpanel",
            store: this.store,
            colModel: this.getColumnModel(),
            selModel: this.getSelModel(),
            enableHdMenu: !1,
            enableColumnMove: !1,
            cls: "iscsi-remove-sort-icon"
        }
    },
    getStore: function() {
        var e = new Ext.data.JsonReader({
            idProperty: "wwpn",
            fields: [{
                name: "target_id",
                mapping: "target_id"
            }, {
                name: "port",
                mapping: "port"
            }, {
                name: "model",
                mapping: "model"
            }, {
                name: "wwpn",
                mapping: "wwpn"
            }, {
                name: "status",
                mapping: "status"
            }, {
                name: "speed",
                mapping: "speed"
            }, {
                name: "connected_sessions",
                mapping: "connected_sessions"
            }, {
                name: "enabled",
                mapping: "enabled"
            }]
        });
        return new Ext.data.Store({
            reader: e,
            data: [],
            autoDestroy: !0
        })
    },
    getColumnModel: function() {
        return new Ext.grid.ColumnModel({
            defaults: {
                width: 100,
                align: "left"
            },
            columns: [{
                header: SYNO.SDS.iSCSI.Utils.T("common", "port"),
                width: 150,
                dataIndex: "port",
                align: "left"
            }, {
                header: SYNO.SDS.iSCSI.Utils.T("san_fibre", "model"),
                width: 200,
                dataIndex: "model",
                align: "left"
            }, {
                header: "WWPN",
                width: 200,
                dataIndex: "wwpn",
                align: "left"
            }, {
                header: SYNO.SDS.iSCSI.Utils.T("common", "status"),
                width: 200,
                dataIndex: "status",
                align: "left",
                renderer: SYNO.SDS.iSCSI.Utils.FCStatusRender
            }, {
                header: SYNO.SDS.iSCSI.Utils.T("router_tc", "speed_header"),
                width: 100,
                dataIndex: "speed"
            }]
        })
    },
    prepareData: function(e) {
        return e.map(function(e) {
            return {
                target_id: e.get("target_id").toString(),
                port: e.get("displayPort"),
                model: e.get("displayModel"),
                wwpn: e.get("wwpn"),
                enabled: e.get("is_enabled"),
                status: e.get("status"),
                connected_sessions: e.get("connected_sessions"),
                speed: "unknown" !== e.get("speed") ? e.get("speed") : ""
            }
        })
    },
    loadStore: function() {
        var e = this;
        e.store.loadData(e.prepareData(e.owner.fcTargets.getAll()))
    },
    getSelModel: function() {
        return new Ext.grid.RowSelectionModel({
            singleSelect: !0,
            listeners: {
                scope: this,
                rowselect: this.onRowselect
            }
        })
    },
    onRowselect: function(e) {
        var t = this,
            i = e.getSelected();
        t.toolbar.getComponent("enable").setDisabled(i.get("enabled")), t.toolbar.getComponent("disable").setDisabled(!i.get("enabled"))
    }
}), Ext.define("SYNO.SDS.iSCSI.Target.Property", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.owner = e.owner, i.isCinderTarget = e.isCinderTarget || !1, i.isDefaultTarget = e.isDefaultTarget || !1;
        var n = i.isDefaultTarget ? {
            xtype: "syno_displayfield",
            fieldLabel: SYNO.SDS.iSCSI.Utils.T("common", "name"),
            name: "name"
        } : {
            xtype: "syno_textfield",
            fieldLabel: SYNO.SDS.iSCSI.Utils.T("common", "name"),
            vtype: "iscsitrgname",
            maxlength: 128,
            allowBlank: !1,
            name: "name",
            appWin: i.appWin,
            disabled: i.isCinderTarget,
            validator: function(e) {
                return e === this.originalValue || (!!this.appWin.isUniqueTargetName(e) || SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_name_exists"))
            }
        };
        t = {
            title: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_title_basic"),
            trackResetOnLoad: !0,
            labelWidth: 270,
            fieldWidth: 270,
            border: !1,
            items: [n, {
                xtype: "syno_textfield",
                fieldLabel: "IQN",
                vtype: "iscsitrgiqn",
                maxlength: 128,
                allowBlank: !1,
                name: "iqn",
                appWin: i.appWin,
                disabled: i.isCinderTarget,
                validator: function(e) {
                    return e === this.originalValue || (!!this.appWin.isUniqueIQN(e) || SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_iqn_exists"))
                }
            }, {
                xtype: "syno_checkbox",
                boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_enable_auth_chap"),
                id: this.chap = Ext.id(),
                name: "chap"
            }, {
                xtype: "syno_textfield",
                indent: 1,
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("common", "name"),
                allowBlank: !1,
                maxlength: 64,
                name: "user",
                vtype: "iscsitrg_username"
            }, {
                xtype: "syno_textfield",
                textType: "password",
                indent: 1,
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("common", "password"),
                maxlength: 16,
                ref: "chapPwd",
                name: "password",
                allowBlank: !1,
                vtype: "iscsitrg_password"
            }, {
                xtype: "syno_checkbox",
                indent: 1,
                boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_enable_auth_mutual_chap"),
                id: this.mutualChap = Ext.id(),
                name: "mutual_chap"
            }, {
                xtype: "syno_textfield",
                indent: 2,
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("common", "name"),
                maxlength: 64,
                name: "mutual_user",
                vtype: "iscsitrg_username",
                allowBlank: !1
            }, {
                xtype: "syno_textfield",
                textType: "password",
                indent: 2,
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("common", "password"),
                maxlength: 16,
                ref: "mutualChapPwd",
                name: "mutual_password",
                vtype: "iscsitrg_password",
                allowBlank: !1,
                validator: function() {
                    return i.chapPwd.getValue() !== i.mutualChapPwd.getValue() || SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_error_same_as_password")
                }
            }],
            listeners: {
                afterlayout: {
                    fn: function(e) {
                        var t = e.getForm();
                        new SYNO.ux.Utils.EnableCheckGroup(t, "chap", ["user", "password", "mutual_chap"]), new SYNO.ux.Utils.EnableCheckGroup(t, "mutual_chap", ["mutual_user", "mutual_password"]);
                        if (this.appWin.env.chap_info.auth_type) {
                            var i = SYNO.SDS.iSCSI.Utils.T("iscsimgr", "global_chap_tip");
                            SYNO.ux.AddTip(Ext.getCmp(this.chap).getEl(), i), Ext.getCmp(this.chap).setDisabled(!0), Ext.getCmp(this.mutualChap).setDisabled(!0)
                        }
                    },
                    scope: this,
                    single: !0
                }
            }
        }, i.callParent([Ext.apply(t, e)])
    },
    getMappingCmp: function() {
        return this.getComponent("mapping")
    }
}), Ext.define("SYNO.SDS.iSCSI.Target.Wizard.PropertyStep", {
    extend: "SYNO.SDS.iSCSI.Target.Property",
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, t = {
            header: !1,
            headline: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_target_create")
        }, this.callParent([Ext.apply(t, e)])
    },
    activate: function() {
        this.loaded || (this.getForm().setValues({
            iqn: this.appWin.genNewIQN(this.appWin.genNewTargetName()),
            name: this.appWin.genNewTargetName()
        }), this.loaded = !0)
    },
    getNext: function() {
        return !!this.getForm().isValid() && this.nextId
    },
    summary: function(e) {
        var t = this.getForm().getValues(),
            i = "";
        "host_prop" === this.nextId ? e.append(SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_mapping"), String.format("iSCSI ({0})", t.name)) : e.append(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "target_name"), t.name), e.append("IQN", t.iqn), i = SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_title_authen"), "true" === t.mutual_chap ? e.append(i, SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_auth_mutual_chap")) : "true" === t.chap ? e.append(i, SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_auth_chap")) : e.append(i, SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_auth_none")), "true" === t.chap && e.append(SYNO.SDS.iSCSI.Utils.T("common", "name"), t.user), "true" === t.mutual_chap && e.append(SYNO.SDS.iSCSI.Utils.T("common", "name"), t.mutual_user)
    }
}), Ext.define("SYNO.SDS.iSCSI.Target.Wizard.MappingStep", {
    extend: "Ext.form.FormPanel",
    luns: null,
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.canCreateLun = e.canCreateLun || !1, i.canMapLun = !1, i.lun_create_radio = new SYNO.ux.Radio({
            boxLabel: SYNO.SDS.iSCSI.Utils.T("lun", "lun_create"),
            name: "lun_source",
            inputValue: "create",
            checked: !!Ext.isDefined(i.canCreateLun) && i.canCreateLun,
            disabled: !i.canCreateLun
        }), i.map_lun_radio = new SYNO.ux.Radio({
            boxLabel: SYNO.SDS.iSCSI.Utils.T("lun", "map_existent_lun"),
            name: "lun_source",
            itemId: "exists",
            inputValue: "exists",
            checked: !1,
            disabled: !0,
            listeners: {
                check: function(e, t) {
                    t ? this.ownerCt.getComponent("mapped_lun").enable() : this.ownerCt.getComponent("mapped_lun").disable()
                }
            }
        }), i.none_lun_radio = new SYNO.ux.Radio({
            boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "no_map_lun_desc"),
            name: "lun_source",
            htmlEncode: !1,
            inputValue: "none"
        }), t = {
            headline: SYNO.SDS.iSCSI.Utils.T("volume", "volume_set_iscsitrg_lun_mapping"),
            items: [{
                xtype: "syno_displayfield",
                htmlEncode: !1,
                value: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_mapping_step_subtitle")
            }, i.lun_create_radio, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                indent: 1,
                value: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_create_desc")
            }, i.map_lun_radio, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                indent: 1,
                value: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "map_exist_lun_desc")
            }, {
                xtype: "syno_combobox",
                name: "mapped_lun",
                hiddenName: "mapped_lun",
                itemId: "mapped_lun",
                tpl: '<tpl for="."><div ext:qtip="{name}" class="x-combo-list-item">{name}</div></tpl>',
                displayField: "name",
                forceSelection: !0,
                hideLabel: !0,
                editable: !1,
                disabled: !0,
                indent: 1,
                width: 250,
                store: this.lun_store = new Ext.data.JsonStore({
                    autoDestroy: !0,
                    idProperty: "name",
                    fields: ["lun_id", {
                        name: "name",
                        sortType: "asNaturalUCString"
                    }, "uuid"],
                    listeners: {
                        load: function(e, t) {
                            e.sort("name", "ASC"), this.onLoad(t)
                        },
                        scope: this
                    }
                })
            }, i.none_lun_radio]
        }, i.callParent([Ext.apply(t, e)])
    },
    getSource: function() {
        return this.getForm().getValues().lun_source
    },
    activate: function() {
        var e = this,
            t = e.appWin.iscsiLuns.getAll(),
            i = e.appWin.volumes,
            n = e.appWin.pools,
            s = [];
        Ext.each(t, function(e) {
            !e.get("is_mapped") && e.canBeMapped(i, n) && s.push({
                lun_id: e.get("lun_id"),
                name: e.get("name"),
                uuid: e.get("uuid")
            })
        }), e.lun_store.loadData(s)
    },
    onLoad: function(e) {
        this.canMapLun = void 0 !== e && 0 < e.length, this.canMapLun ? (this.canCreateLun ? this.map_lun_radio.enable() : (this.getComponent("mapped_lun").enable(), this.map_lun_radio.enable(), this.map_lun_radio.setValue(!0)), this.getForm().setValues({
            mapped_lun: e[0].id
        })) : this.canCreateLun || this.none_lun_radio.setValue(!0)
    },
    getLunUUIDs: function() {
        var e = this.getForm().getValues().mapped_lun;
        return this.lun_store.getById(e).get("uuid")
    },
    getNext: function() {
        return this.nextId[this.getSource()]
    },
    summary: function(e) {
        switch (this.getSource()) {
            case "create":
                break;
            case "exists":
                e.append(SYNO.SDS.iSCSI.Utils.T("lun", "mapped_lun"), this.getForm().getValues().mapped_lun.toString());
                break;
            case "none":
                e.append(SYNO.SDS.iSCSI.Utils.T("lun", "mapped_lun"), SYNO.SDS.iSCSI.Utils.T("system", "none_opt"))
        }
    }
}), Ext.define("SYNO.SDS.iSCSI.Target.Wizard.CreateSummaryStep", {
    extend: "SYNO.SDS.Wizard.SummaryStep",
    getNext: function() {
        return this.owner.applySettings(null), !1
    },
    descRenderer: function(e, t, i, n, s, a) {
        var o = e.toString().replace(/<.*?>/g, "");
        return t.attr = 'ext:qtip="' + o + '"', e
    },
    disableNextInDemoMode: !0
}), Ext.define("SYNO.SDS.iSCSI.Target.WizardCreate", {
    extend: "SYNO.SDS.Wizard.ModalWindow",
    isDataChanged: !1,
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.owner = e.owner, i.canCreateLunTypes = i.appWin.getCanCreateLunTypes(), t = {
            title: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_target_create"),
            width: 680,
            height: 600,
            minHeight: 475,
            minWidth: 680,
            resizable: !1,
            cls: "syno-app-iscsi",
            steps: [new SYNO.SDS.iSCSI.Target.Wizard.PropertyStep({
                appWin: i.appWin,
                itemId: "target_prop",
                nextId: "map_luns"
            }), new SYNO.SDS.iSCSI.Target.Wizard.MappingStep({
                appWin: i.appWin,
                canCreateLun: i.canCreateLun(),
                itemId: "map_luns",
                nextId: {
                    create: "lun_property_step",
                    exists: "summary",
                    none: "summary"
                }
            }), new SYNO.SDS.iSCSI.Target.Wizard.CreateSummaryStep({
                appWin: i.appWin,
                itemId: "summary",
                nextId: null
            }), new SYNO.SDS.iSCSI.LUN.Wizard.PropertyStep({
                appWin: i.appWin,
                vol_type_of_lun: "all",
                mode: "create",
                itemId: "lun_property_step",
                nextId: "summary"
            })]
        }, i.callParent([Ext.apply(t, e)])
    },
    canCreateLun: function() {
        if (this.appWin.isUpToLunMaxCount()) return !1;
        for (var e in this.canCreateLunTypes)
            if (this.canCreateLunTypes.hasOwnProperty(e)) return !0;
        return !1
    },
    applySettings: function(e) {
        var t = {},
            i = [],
            n = !1,
            s = !1,
            a = !0,
            o = !0,
            r = this.getStep("map_luns").getSource(),
            l = [],
            S = {};
        if (t = this.getStep("target_prop").getForm().getValues(), t.auth_type = "true" === t.chap ? 1 : 0, "true" === t.chap && "true" === t.mutual_chap && (t.auth_type = 2), i.push({
                api: "SYNO.Core.ISCSI.Target",
                method: "create",
                version: 1,
                params: t
            }), S.lun_uuids = [], "exists" === r) S.lun_uuids.push(this.getStep("map_luns").getLunUUIDs());
        else if ("create" === r) {
            var d, c = {};
            d = this.getStep("lun_property_step").getProps(), c.name = d.name, c.location = d.location, d.hasOwnProperty("size") && (c.size = parseInt(d.size, 10) * SYNO.SDS.iSCSI.Utils.ISCSITRG_UNIT_GB), "btrfs" === d.volumeType ? d.thin_provision ? (c.type = "BLUN", s = !0) : c.type = "BLUN_THICK" : "ext4" === d.volumeType && (d.adv_legacy ? (c.type = "ADV", s = !0) : (c.type = d.thin_provision ? "THIN" : "FILE", a = !1, o = !1)), c.dev_attribs = [{
                dev_attrib: "emulate_tpws",
                enable: a ? 1 : 0
            }, {
                dev_attrib: "emulate_caw",
                enable: 1
            }, {
                dev_attrib: "emulate_3pc",
                enable: o ? 1 : 0
            }, {
                dev_attrib: "emulate_tpu",
                enable: d.adv_unmap ? 1 : 0
            }, {
                dev_attrib: "can_snapshot",
                enable: s ? 1 : 0
            }], i.push({
                api: "SYNO.Core.ISCSI.LUN",
                method: "create",
                version: 1,
                params: c
            }), n = !0
        }
        "none" !== r && l.push({
            api: "SYNO.Core.ISCSI.Target",
            method: "map_lun",
            version: 1,
            params: S
        }), null !== e && (i = e), this.getButton("next").disable(), this.setStatusBusy({
            text: SYNO.SDS.iSCSI.Utils.T("common", "saving")
        }), this.sendWebAPI({
            scope: this,
            compound: {
                stopwhenerror: !0,
                mode: "sequential",
                params: i
            },
            callback: function(e, t, s, a) {
                var o = [];
                e && !t.has_fail || this.clearStatusBusy();
                for (var r = 0; r < t.result.length; r++)
                    if (!t.result[r].success) {
                        var d = void 0,
                            c = "",
                            p = "";
                        i[r].params.is_soft_feas_ignored = !0;
                        for (var u = 0; u < i.length; u++) t.result[u].success || o.push(i[u]);
                        return t.result[r].hasOwnProperty("error") && t.result[r].error.hasOwnProperty("errors") && (d = t.result[r].error.errors, "SYNO.Core.ISCSI.Target" === i[r].api ? p = i[r].params.name : "SYNO.Core.ISCSI.LUN" === i[r].api && (c = i[r].params.name), d.hasOwnProperty("feasibility_hard") || d.hasOwnProperty("feasibility_soft")) ? void SYNO.SDS.iSCSI.LUN.GeneralFeasChkFailCallback(d, o, c, p, this, this.getButton("next").getId()) : void SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(this, t.result[r].error)
                    } t.result[0] && t.result[0].success && t.result[0].data && (S.target_id = t.result[0].data.target_id.toString()), n && t.result[1] && t.result[1].success && t.result[1].data && (S.lun_uuids = [t.result[1].data.uuid]), this.sendWebAPI({
                    scope: this,
                    compound: {
                        stopwhenerror: !0,
                        mode: "sequential",
                        params: l
                    },
                    callback: function(e, t, i, n) {
                        this.clearStatusBusy(), this.getButton("next").enable(), this.getButton("next").setText(SYNO.SDS.iSCSI.Utils.T("common", "alt_finish")), t.str ? this.getMsgBox().alert(this.title, t.str, this.close, this) : (SYNO.SDS.StatusNotifier.setServiceDisabled("SYNO.SDS.iSCSI.Target.ISCSI", !1), this.isDataChanged = !0, this.close())
                    }
                })
            }
        })
    },
    contFromSoftFeasCheck: function(e) {
        this.applySettings(e)
    }
}), Ext.define("SYNO.SDS.iSCSI.Target.Delete", {
    extend: "SYNO.SDS.ModalWindow",
    isDataChanged: !1,
    target: null,
    mapped_luns: null,
    lunbkp_tasks: [],
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.owner = e.owner, i.target = e.target, i.mapped_luns = e.mapped_luns, i.isCinderTarget = e.isCinderTarget || !1, i.ignoreSoftFeasibility = !1, t = {
            title: SYNO.SDS.iSCSI.Utils.T("common", "remove") + ": " + SYNO.SDS.iSCSI.Utils.T("tree", "leaf_iscsitrg"),
            width: 600,
            height: 475,
            layout: "fit",
            items: [{
                xtype: "form",
                itemId: "main",
                border: !1,
                items: [{
                    xtype: "syno_displayfield",
                    hideLabel: !0,
                    itemId: "desc",
                    style: "word-wrap:break-word;",
                    value: String.format(SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_delete_warning"), i.target.get("name"))
                }, {
                    xtype: "syno_checkbox",
                    boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_delete_confirm"),
                    name: "delete_luns",
                    itemId: "delete_luns",
                    disabled: !i.mapped_luns || 0 === i.mapped_luns.length,
                    listeners: {
                        check: function(e, t) {
                            this.ownerCt.getComponent("grid").setDisabled(!t)
                        }
                    }
                }, i.map = new SYNO.SDS.iSCSI.Target.Mapping({
                    height: 190,
                    itemId: "grid",
                    disabled: !0,
                    appWin: i.appWin,
                    owner: i,
                    hidebbar: !0,
                    decorateData: function(e) {
                        var t = i.appWin.iscsiLuns;
                        return e.filter(function(e) {
                            var n = t.getById(e.uuid);
                            return i.target.isMappedToLUN(n.get("uuid"))
                        }).map(function(e) {
                            return e.checked = !1, e
                        })
                    }
                })]
            }],
            buttons: [{
                xtype: "syno_button",
                text: SYNO.SDS.iSCSI.Utils.T("common", "alt_cancel"),
                scope: this,
                handler: this.onCancel
            }, {
                xtype: "syno_button",
                btnStyle: "red",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                text: SYNO.SDS.iSCSI.Utils.T("common", "remove"),
                id: i.applyButtonID = Ext.id(),
                scope: this,
                handler: this.onSave
            }],
            listeners: {
                afterlayout: function(e) {
                    var t = e.getComponent("main").getHeight(),
                        i = e.getComponent("main").getComponent("desc").getHeight(),
                        n = e.getComponent("main").getComponent("delete_luns").getHeight();
                    e.map.setHeight(t - i - n)
                }
            }
        }, i.callParent([Ext.apply(t, e)])
    },
    onOpen: function() {
        this.callParent(arguments), this.map.loadLUN("delete")
    },
    applySetting: function(e) {
        var t = {},
            i = {},
            n = {},
            s = [];
        t.is_soft_feas_ignored = this.ignoreSoftFeasibility, t.uuid = "", t.uuids = [];
        for (var a = 0; a < e.luns.length; a++) t.uuids.push(e.luns[a].uuid), n[e.luns[a].uuid] = e.luns[a].name;
        e.luns.length > 0 && s.push({
            api: "SYNO.Core.ISCSI.LUN",
            method: "delete",
            version: 1,
            params: t
        }), i.target_id = e.tid.toString(), s.push({
            api: "SYNO.Core.ISCSI.Target",
            method: "delete",
            version: 1,
            params: i
        }), this.doApply(s)
    },
    doApply: function(e) {
        this.setStatusBusy({
            text: SYNO.SDS.iSCSI.Utils.T("common", "saving")
        });
        for (var t = 0; t < e.length; t++) e[t].params.hasOwnProperty("is_soft_feas_ignored") && (e[t].params.is_soft_feas_ignored = this.ignoreSoftFeasibility);
        this.sendWebAPI({
            scope: this,
            compound: {
                stopwhenerror: !0,
                mode: "sequential",
                params: e
            },
            callback: function(t, i) {
                this.clearStatusBusy();
                for (var n = 0; n < i.result.length; n++) {
                    if (!i.result[n].success) {
                        var s = void 0;
                        return i.result[n].hasOwnProperty("error") && i.result[n].error.hasOwnProperty("errors") && (s = i.result[n].error.errors, s.hasOwnProperty("feasibility_hard") || s.hasOwnProperty("feasibility_soft")) ? void SYNO.SDS.iSCSI.Target.LUNBackupTaskCallback(s, this, e) : void SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(this, i)
                    }
                    this.isDataChanged = !0, this.close()
                }
            }
        })
    },
    onSave: function() {
        var e = this,
            t = SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_remove_cinder_target_warning"),
            i = this.getComponent("main").getForm(),
            n = {
                tid: this.target.id,
                luns: []
            },
            s = {
                yes: {
                    text: SYNO.SDS.iSCSI.Utils.T("common", "remove"),
                    btnStyle: "red"
                },
                no: {
                    text: SYNO.SDS.iSCSI.Utils.T("common", "cancel")
                }
            },
            a = function() {
                SYNO.SDS.Utils.PasswordConfirmDialog.openDialog(e, e.applySetting, [n])
            };
        "true" === i.getValues().delete_luns && Ext.each(e.map.getStore().getModifiedRecords(), function(e) {
            n.luns.push({
                uuid: e.json.uuid,
                name: e.json.name,
                lid: e.id
            })
        }, this), e.isCinderTarget ? this.getMsgBox().confirmDelete(this.title, t, function(e) {
            "yes" == e && a()
        }, this, s) : a()
    },
    onCancel: function() {
        this.close()
    },
    contFromSoftFeasCheck: function(e) {
        this.ignoreSoftFeasibility = !0, this.doApply(e)
    }
}), SYNO.SDS.iSCSI.Target.LUNBackupTaskCallback = function(e, t, i) {
    var n = {},
        s = "",
        a = "";
    if (n.iscsiluns = {}, e.hasOwnProperty("feasibility_soft") ? (s = "feasibility_soft", a = "soft") : e.hasOwnProperty("feasibility_hard") && (s = "feasibility_hard", a = "hard"), e.hasOwnProperty(s))
        for (var o = e[s], r = 0; r < o.length; r++) n.iscsiluns[o[r].name] = {}, n.iscsiluns[o[r].name][a] = o[r].check_message;
    var l = Object.keys(n.iscsiluns);
    t.getMsgBox().confirm(t.title, String.format(SYNO.SDS.iSCSI.Utils.T("lunbkp", "warning_deleting_lun"), l.join(", ")), function(e) {
        if ("yes" !== e) return void this.close();
        t.contFromSoftFeasCheck(i)
    }, t)
}, Ext.define("SYNO.SDS.iSCSI.Target.Mapping", {
    extend: "SYNO.SDS.SAN.LUN.Selecting.GridPanel",
    constructor: function(e) {
        var t = this;
        e.protocol = "iscsi", t.callParent([e])
    },
    decorateData: function(e) {
        var t = this;
        return e.forEach(function(e) {
            var i = t.appWin.iscsiLuns.getById(e.uuid);
            e.checked = t.owner.target.isMappedToLUN(i.get("uuid")), i.isCrashed() && (e.banned = !0, e.note = SYNO.SDS.iSCSI.Utils.T("san_lun", "status_abnormal"))
        }), e
    }
}), Ext.define("SYNO.SDS.iSCSI.Target.Portal", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(e) {
        var t, i, n = this;
        n.appWin = e.appWin, t = new SYNO.ux.EnableColumn({
            dataIndex: "enabled",
            width: 40,
            align: "center",
            bindRowClick: !0
        });
        var s = new Ext.data.JsonStore({
                autoDestroy: !0,
                idProperty: "ifname",
                fields: ["ifname", "status", "ip", "enabled", {
                    name: "name",
                    sortType: "asNaturalUCString"
                }],
                sortInfo: {
                    field: "name",
                    direction: "ASC"
                }
            }),
            a = new Ext.grid.ColumnModel({
                defaults: {
                    align: "center"
                },
                xtype: "datecolumn",
                columns: [t, {
                    id: "name",
                    name: "name",
                    header: SYNO.SDS.iSCSI.Utils.T("network", "interface"),
                    dataIndex: "name",
                    align: "left",
                    width: 120,
                    sortable: !0,
                    renderer: SYNO.SDS.iSCSI.TipRenderer
                }, {
                    id: "status",
                    name: "status",
                    header: SYNO.SDS.iSCSI.Utils.T("common", "status"),
                    dataIndex: "status",
                    align: "left",
                    width: 90,
                    sortable: !0,
                    renderer: SYNO.SDS.iSCSI.TipRenderer
                }, {
                    id: "ip",
                    name: "ip",
                    header: SYNO.SDS.iSCSI.Utils.T("common", "ip_addr"),
                    dataIndex: "ip",
                    align: "left",
                    width: 200,
                    sortable: !0,
                    renderer: SYNO.SDS.iSCSI.TipRenderer
                }],
                enableHdMenu: !1,
                autoExpandColumn: "ip"
            }),
            o = [{
                xtype: "syno_displayfield",
                value: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "network_binding_desc")
            }, {
                xtype: "syno_radio",
                name: "sel_all_interface",
                inputValue: !0,
                boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "network_binding_all_if"),
                id: this.allInterface = Ext.id(),
                listeners: {
                    check: function(e, t, i) {
                        t ? n.portalGridPanel.disable() : n.portalGridPanel.enable()
                    }
                }
            }, {
                xtype: "syno_radio",
                id: this.selCertainIf = Ext.id(),
                name: "sel_all_interface",
                inputValue: !0,
                boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "network_binding_only_selected_if")
            }, {
                xtype: "syno_fieldset",
                itemId: "portal_selector",
                name: "portal_selector",
                id: this.portalGridPanel = Ext.id(),
                collapsible: !1,
                items: [{
                    xtype: "syno_gridpanel",
                    id: Ext.id(),
                    cm: a,
                    store: s,
                    selModel: new Ext.grid.RowSelectionModel,
                    height: 200,
                    enableColumnMove: !1,
                    enableHdMenu: !1,
                    hideMode: "offsets",
                    plugins: t
                }]
            }];
        i = {
            title: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_network_binding"),
            items: o
        }, n.callParent([Ext.apply(i, e)]), this.portalStore = s, this.allInterface = Ext.getCmp(this.allInterface), this.portalGridPanel = Ext.getCmp(this.portalGridPanel), this.selCertainIf = Ext.getCmp(this.selCertainIf)
    }
}), Ext.define("SYNO.SDS.iSCSI.Target.Edit", {
    extend: "SYNO.SDS.ModalWindow",
    isDataChanged: !1,
    target: null,
    luns: null,
    constructor: function(e) {
        var t, i, n = this;
        n.appWin = e.appWin, n.owner = e.owner, n.target = e.target, n.isCinderTarget = e.isCinderTarget || !1, n.prop = new SYNO.SDS.iSCSI.Target.Property({
                itemId: "prop",
                appWin: n.appWin,
                owner: n,
                isCinderTarget: n.isCinderTarget,
                isDefaultTarget: n.target.get("is_default_target")
            }),
            n.advProp = new SYNO.ux.FormPanel(n.configAdvanceForm({
                itemId: "advance",
                appWin: n.appWin,
                owner: n
            })), n.map = new SYNO.SDS.iSCSI.Target.Mapping({
                title: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_mapping"),
                itemId: "map",
                appWin: n.appWin,
                owner: n
            }), n.portal = new SYNO.SDS.iSCSI.Target.Portal({
                itemId: "portal",
                appWin: n.appWin,
                owner: n
            }), i = [n.prop, n.advProp], n.isCinderTarget || (i.push(n.map), i.push(n.portal)), t = {
                title: SYNO.SDS.iSCSI.Utils.T("common", "alt_edit"),
                width: 625,
                height: 500,
                minWidth: 625,
                minHeight: 475,
                resizable: !0,
                layout: "fit",
                cls: "syno-app-iscsi",
                border: !1,
                items: [{
                    itemId: "main",
                    xtype: "syno_tabpanel",
                    activeTab: 0,
                    plain: !0,
                    hideMode: "offsets",
                    deferredRender: !1,
                    items: i
                }],
                buttons: [{
                    xtype: "syno_button",
                    text: SYNO.SDS.iSCSI.Utils.T("common", "alt_cancel"),
                    scope: this,
                    handler: this.onCancel
                }, {
                    xtype: "syno_button",
                    btnStyle: "blue",
                    disabled: _S("demo_mode"),
                    tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                    text: SYNO.SDS.iSCSI.Utils.T("common", "save"),
                    scope: this,
                    handler: this.onSave
                }]
            }, n.callParent([Ext.apply(t, e)])
    },
    configAdvanceForm: function(e) {
        return Ext.apply({
            title: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_title_adv"),
            trackResetOnLoad: !0,
            labelWidth: 300,
            items: [{
                xtype: "syno_displayfield",
                value: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_form_crc_checksum")
            }, {
                xtype: "syno_checkbox",
                boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_checksum_header"),
                name: "has_header_checksum",
                value: !1
            }, {
                xtype: "syno_checkbox",
                boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_checksum_data"),
                name: "has_data_checksum",
                value: !1
            }, {
                xtype: "syno_displayfield"
            }, {
                xtype: "syno_checkbox",
                boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_multi_sessions_desc"),
                name: "multi_sessions",
                value: !1
            }, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                indent: 1,
                value: String.format('<span class="red-status">{0}</span>', SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_multi_sessions_warning"))
            }, {
                xtype: "syno_displayfield"
            }, {
                xtype: "syno_combobox",
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_max_recv_segment"),
                name: "max_recv_seg_bytes",
                hiddenName: "max_recv_seg_bytes",
                itemId: "max_recv_seg_bytes",
                store: [
                    [262144, 262144],
                    [65536, 65536],
                    [8192, 8192],
                    [4096, 4096]
                ],
                editable: !1,
                value: 4096
            }, {
                xtype: "syno_combobox",
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_max_send_segment"),
                name: "max_send_seg_bytes",
                hiddenName: "max_send_seg_bytes",
                itemId: "max_send_seg_bytes",
                store: [
                    [262144, 262144],
                    [65536, 65536],
                    [8192, 8192],
                    [4096, 4096]
                ],
                editable: !1,
                value: 4096
            }]
        }, e)
    },
    onOpen: function() {
        var e = this;
        e.callParent(arguments), e.loadLuns(), e.loadForm(), e.loadPortal()
    },
    loadForm: function() {
        var e, t = this,
            i = {};
        i.name = t.target.get("name"), i.iqn = t.target.get("iqn"), e = t.target.get("auth_type"), i.chap = 0 !== e, i.mutual_chap = 2 === e, i.chap && Ext.apply(i, {
            user: t.target.get("user"),
            password: t.target.get("password")
        }), i.mutual_chap && Ext.apply(i, {
            mutual_user: t.target.get("mutual_user"),
            mutual_password: t.target.get("mutual_password")
        }), Ext.apply(i, {
            has_header_checksum: t.target.get("has_header_checksum"),
            has_data_checksum: t.target.get("has_data_checksum"),
            max_recv_seg_bytes: t.target.get("max_recv_seg_bytes"),
            max_send_seg_bytes: t.target.get("max_send_seg_bytes"),
            multi_sessions: 0 === t.target.get("max_sessions")
        }), t.prop.getForm().setValues(i), t.advProp.getForm().setValues(i), t.prop.getForm().clearInvalid()
    },
    loadLuns: function() {
        this.map.loadLUN("edit")
    },
    loadPortal: function() {
        for (var e = this, t = this.portal.portalStore, i = e.appWin.netInterfaces, n = e.target.data.network_portals, s = [], a = !1, o = 0; o < n.length; ++o)
            if (0 <= n[o].interface_name.search("all")) {
                a = !0;
                break
            } a ? (e.portal.allInterface.originalValue = !0, e.portal.allInterface.setValue(!0), e.portal.portalGridPanel.disable()) : (e.portal.selCertainIf.originalValue = !0, e.portal.selCertainIf.setValue(!0), e.portal.portalGridPanel.enable()), Ext.each(i, function(e) {
            var t = e.status,
                i = "",
                a = !1;
            if (-1 == e.ifname.indexOf("eth") && -1 == e.ifname.indexOf("bond")) return !1;
            i = "connected" == t ? String.format('<span class="blue-status" style="white-space:pre-warp">{0}</span>', SYNO.SDS.iSCSI.Utils.T("network", "status_connected")) : String.format('<span class="disable-font" style="white-space:pre-warp">{0}</span>', SYNO.SDS.iSCSI.Utils.T("network", "status_disconnected"));
            for (var o = 0; o < n.length; ++o) {
                var r = n[o].interface_name,
                    l = new RegExp(String.format("{0}$", r));
                if ("" !== r && 0 <= e.ifname.search(l)) {
                    a = !0;
                    break
                }
            }
            s.push({
                ifname: e.ifname,
                name: SYNO.SDS.Utils.Network.idToString(e.ifname, e.type),
                ip: e.ip,
                status: i,
                enabled: a
            })
        }, e), t.removeAll(), t.loadData(s, !1), t.commitChanges()
    },
    isDirty: function() {
        var e, t = this;
        return e = t.appWin.supportRaidGroup ? t.prop.getMappingCmp().getStore() : t.map.getStore(), !!t.prop.getForm().isDirty() || (!!t.advProp.getForm().isDirty() || (!!e.getModifiedRecords().length || !!(t.portal.portalStore.getModifiedRecords().length || t.portal.allInterface.isDirty() || t.portal.selCertainIf.isDirty())))
    },
    onSave: function() {
        var e, t = this,
            i = {},
            n = "",
            s = t.map.getStore(),
            a = t.portal.portalStore;
        if (!t.prop.getForm().isValid()) return t.getComponent("main").activate("prop"), void t.advProp.getForm().isValid();
        if (!t.advProp.getForm().isValid()) return void t.getComponent("main").activate("advance");
        if (!t.isDirty()) return void t.close();
        Ext.apply(i, t.prop.getForm().getValues()), Ext.apply(i, t.advProp.getForm().getValues());
        var o = s.getModifiedRecords(),
            r = [],
            l = [],
            S = {},
            d = {};
        for (S.target_id = t.target.id.toString(), d.target_id = t.target.id.toString(), e = 0; e < o.length; e++) {
            var c = o[e].data;
            !0 === c.checked ? l.push(c.uuid) : r.push(c.uuid)
        }
        S.lun_uuids = l, d.lun_uuids = r;
        var p = 0;
        for (e = 0; e < s.getCount(); e++) s.getAt(e).get("checked") && (p += 1);
        if (SYNO.SDS.iSCSI.TARGET.MAX_MAPPING_LUNS < p + 1) return n = SYNO.SDS.iSCSI.Utils.T("trg", "max_lun_per_target"), n = String.format(n, SYNO.SDS.iSCSI.TARGET.MAX_MAPPING_LUNS), void t.getMsgBox().alert(t.title, n);
        var u = a.getModifiedRecords(),
            h = [],
            m = [],
            g = {},
            _ = {};
        for (g.target_id = t.target.id.toString(), _.target_id = t.target.id.toString(), e = 0; e < u.length; e++) {
            var f = u[e].data,
                v = f.ifname.replace("ovs_", "");
            !0 === f.enabled ? h.push({
                interface_name: v
            }) : m.push({
                interface_name: v
            })
        }
        g.network_portals = [], _.network_portals = [], !0 === t.portal.allInterface.getValue() && t.portal.allInterface.isDirty() ? g.network_portals = [{
            interface_name: "all"
        }] : !0 === t.portal.selCertainIf.getValue() && (g.network_portals = h, _.network_portals = m), i.target_id = t.target.id.toString(), i.auth_type = "true" === i.chap ? 1 : 0, "true" === i.chap && "true" === i.mutual_chap && (i.auth_type = 2), i.has_header_checksum && (i.has_header_checksum = "true" === i.has_header_checksum), i.has_data_checksum && (i.has_data_checksum = "true" === i.has_data_checksum), i.multi_sessions && (i.max_sessions = "true" === i.multi_sessions ? 0 : 1), i.max_recv_seg_bytes && (i.max_recv_seg_bytes = parseInt(i.max_recv_seg_bytes, 10)), i.max_send_seg_bytes && (i.max_send_seg_bytes = parseInt(i.max_send_seg_bytes, 10));
        var y = [];
        (t.prop.getForm().isDirty() || t.advProp.getForm().isDirty()) && y.push({
            api: "SYNO.Core.ISCSI.Target",
            method: "set",
            version: 1,
            params: i
        }), l.length > 0 && y.push({
            api: "SYNO.Core.ISCSI.Target",
            method: "map_lun",
            version: 1,
            params: S
        }), r.length > 0 && y.push({
            api: "SYNO.Core.ISCSI.Target",
            method: "unmap_lun",
            version: 1,
            params: d
        }), g.network_portals.length > 0 && y.push({
            api: "SYNO.Core.ISCSI.Target",
            method: "network_portals_add",
            version: 1,
            params: g
        }), _.network_portals.length > 0 && y.push({
            api: "SYNO.Core.ISCSI.Target",
            method: "network_portals_remove",
            version: 1,
            params: _
        }), this.doApply(y)
    },
    doApply: function(e) {
        this.setStatusBusy({
            text: SYNO.SDS.iSCSI.Utils.T("common", "saving")
        }), this.sendWebAPI({
            scope: this,
            mode: "sequential",
            compound: {
                stopwhenerror: !0,
                params: e
            },
            callback: function(e, t, i, n) {
                if (this.clearStatusBusy(), !e || t.has_fail) return void SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(this, t);
                SYNO.SDS.StatusNotifier.setServiceDisabled("SYNO.SDS.StorageManager.ISCSI", !1), this.isDataChanged = !0, this.close()
            }
        })
    },
    onCancel: function() {
        if (this.isDirty()) return void this.confirmLostChangePromise({
            save: function() {
                this.onSave()
            },
            dontSave: function() {
                this.close()
            },
            cancel: function() {}
        }, this);
        this.close()
    }
}), Ext.namespace("SYNO.SDS.iSCSI.Target"), Ext.define("SYNO.SDS.iSCSI.Target.Target", {
    check: SYNO.SDS.iSCSI.Utils.check,
    get: function(e) {
        if (this.data) return this.data[e]
    },
    isActing: function() {
        return !1
    },
    isMappedToLUN: function(e) {
        return void 0 !== this.get("mapped_luns").find(function(t, i, n) {
            return t.lun_uuid === e
        })
    }
}), Ext.define("SYNO.SDS.iSCSI.Target.Main", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        this.appWin = e.appWin, this.owner = e.appWin, this.loaded = !1, this.view = this.createView(), this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t, i = this;
        return t = {
            border: !1,
            layout: "fit",
            itemId: "iscsi_target",
            tbar: i.toolbar = new Ext.Toolbar({
                defaultType: "syno_button",
                items: [{
                    itemId: "create",
                    text: SYNO.SDS.iSCSI.Utils.T("common", "create"),
                    handler: i.onCreate,
                    scope: i
                }, {
                    itemId: "manage",
                    text: SYNO.SDS.iSCSI.Utils.T("common", "alt_edit"),
                    handler: i.onEdit,
                    scope: i
                }, {
                    itemId: "remove",
                    text: SYNO.SDS.iSCSI.Utils.T("common", "delete"),
                    handler: i.onDelete,
                    scope: i
                }, {
                    tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                    itemId: "flip",
                    text: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_enable"),
                    handler: i.onFlip,
                    scope: i
                }]
            }),
            items: i.view,
            listeners: {
                activate: i.onActivate,
                data_ready: i.onDataReady,
                scope: i
            }
        }, Ext.apply(t, e), t
    },
    createView: function() {
        var e, t, i = this,
            n = SYNO.SDS.iSCSI.PropertyTpl(),
            s = SYNO.SDS.iSCSI.ListTpl({
                scope: "map",
                title: SYNO.SDS.iSCSI.Utils.T("lun", "mapped_lun"),
                emptyText: SYNO.SDS.iSCSI.Utils.T("lun", "no_mapped_lun"),
                columns: [{
                    header: SYNO.SDS.iSCSI.Utils.T("common", "name"),
                    dataIndex: "name"
                }, {
                    header: String.format("{0} / {1}", SYNO.SDS.iSCSI.Utils.T("san_lun", "used"), SYNO.SDS.iSCSI.Utils.T("san_lun", "total")),
                    dataIndex: "usage"
                }, {
                    header: SYNO.SDS.iSCSI.Utils.T("volume", "volume_volumestatus"),
                    dataIndex: "status"
                }]
            });
        return e = new Ext.XTemplate('<div class="item-detail-inner">', n.html, s.html, "</div>"), t = {
            appWin: i.appWin,
            owner: i,
            dataType: "iscsiTargets",
            itemId: "targetView",
            multiSelect: !1,
            singleSelect: !0,
            detailTpl: e,
            store: i.createTrgStore(),
            listeners: {
                selectionchange: i.onSelectChange,
                scope: i
            }
        }, new SYNO.SDS.iSCSI.DataView(t)
    },
    createTrgStore: function() {
        var e = ["id", "iconPic", "iconCls", "statusIconCls", {
            name: "displayName",
            sortType: "asNaturalUCString"
        }, "summaryStatus", "property", "map", "mask", "desc"];
        return new Ext.data.JsonStore({
            autoDestroy: !0,
            idProperty: "id",
            fields: e,
            sortInfo: {
                field: "displayName",
                direction: "ASC"
            }
        })
    },
    prepareUiData: function() {
        var e = this,
            t = e.appWin.iscsiTargets.getAll();
        e.uiData = t.map(function(t) {
            var i = {};
            return e.prepareSummary(t, i), e.prepareProperty(t, i), e.prepareMap(t, i), i
        })
    },
    prepareSummary: function(e, t) {
        t.status = e.get("status"), t.id = e.get("target_id").toString(), t.displayName = e.get("name"), t.summaryStatus = String.format("&nbsp;-&nbsp;{0}", SYNO.SDS.iSCSI.Utils.TargetStatusRender(e.get("status"), -1)), t.iconPic = "iscsi-general-list-icon", t.iconCls = "iscsi-list-icon-target", t.desc = e.get("iqn")
    },
    prepareProperty: function(e, t) {
        var i, n = this,
            s = [SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_auth_none"), SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_auth_chap"), SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_auth_mutual_chap")],
            a = SYNO.SDS.iSCSI.Utils,
            o = e.get("status"),
            r = [],
            l = e.get("iqn");
        if ("connected" === o) {
            for (var S = 0; S < e.get("connected_sessions").length; ++S) ! function(t) {
                var i = e.get("connected_sessions")[t].ip,
                    s = e.get("connected_sessions")[t].iqn,
                    a = n.appWin.hosts.find(function(e) {
                        return -1 !== e.initiator_ids.indexOf(s)
                    });
                a ? r.push(String.format("{0}  ({1})", a.name, i)) : r.push(String.format('{0}  ({1}) (<a data-session="{0}" style="cursor:pointer;font-weight:bold" class="create-session-host">{2}</a>)', s, i, "Create Host"))
            }(S);
            i = String.format('<span class="blue-status" style="white-space:pre-warp">{0}</span>', r.join("<br/>"))
        } else "processing" === o || "creating" === o || "deleting" === o ? (i = a.TargetStatusRender(o, e.get("progress")), e.get("progress") > 0 && (i = String.format("{0} {1}", i, a.PercentRender(e.get("progress"))))) : i = a.TargetStatusRender(o, -1);
        t.property = [], this.isCinderTarget(e) && t.property.push({
            name: SYNO.SDS.iSCSI.Utils.T("iscsilun", "user"),
            value: "Openstack Cinder"
        }), t.property.push({
            name: SYNO.SDS.iSCSI.Utils.T("common", "name"),
            value: e.get("name")
        }, {
            name: "IQN",
            value: String.format('{0} (<a data-iqn="{1}" style="cursor:pointer" class="target-copy-iqn">{2}</a>)', l, l, SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_copy_iqn"))
        }, {
            name: SYNO.SDS.iSCSI.Utils.T("volume", "volume_iscsitrg_status"),
            value: i
        }, {
            name: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_title_authen"),
            value: s[e.get("auth_type")]
        }, {
            name: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_multi_sessions"),
            value: 0 === e.get("max_sessions") ? SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_enable") : SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_disable")
        }, {
            name: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_checksum_header"),
            value: e.get("has_header_checksum") ? SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_enable") : SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_disable")
        }, {
            name: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_checksum_data"),
            value: e.get("has_data_checksum") ? SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_enable") : SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_disable")
        }, {
            name: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_max_recv_segment"),
            value: e.get("max_recv_seg_bytes") + " " + SYNO.SDS.iSCSI.Utils.T("common", "size_byte")
        }, {
            name: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_max_send_segment"),
            value: e.get("max_send_seg_bytes") + " " + SYNO.SDS.iSCSI.Utils.T("common", "size_byte")
        })
    },
    prepareMap: function(e, t) {
        var i = e.get("mapped_luns"),
            n = this.appWin.iscsiLuns,
            s = this.appWin.volumes,
            a = this.appWin.pools;
        t.map = i.map(function(e, t) {
            var i = n.getById(e.lun_uuid),
                o = SYNO.SDS.iSCSI.Utils,
                r = o.LUNUsageProcess(i),
                l = r.totalSize,
                S = r.usedSize;
            return {
                name: i.get("name"),
                usage: String.format("{0}&nbsp;/&nbsp;{1}", o.SizeRender(S), o.SizeRender(l)),
                status: String.format("{0}&nbsp;{1}", i.getSummaryStatus(s, a), i.getProgress())
            }
        })
    },
    copyToClipboard: function(e) {
        var t = document.createElement("textarea"),
            i = !1;
        t.style.position = "fixed", t.style.top = "-999px", t.style.left = "-999px", t.style.width = "1px", t.style.height = "1px", t.style.padding = 0, t.style.border = "none", t.style.outline = "none", t.style.boxShadow = "none", t.style.background = "transparent", t.style.color = "transparent", t.value = e, document.body.appendChild(t), t.select();
        try {
            i = !!document.queryCommandEnabled("copy") && document.execCommand("copy"), SYNO.Debug.debug("Copying text command was " + (i ? "successful" : "unsuccessful"))
        } catch (e) {
            i = !1, SYNO.Debug.debug("Oops, unable to copy")
        }
        return document.body.removeChild(t), i
    },
    onActivate: function() {
        var e = this;
        e.loaded || e.appWin.setStatusBusy(null, null, 50), e.appWin.fireEvent("poll_activate")
    },
    onDataReady: function() {
        var e = this,
            t = e.view.store;
        e.loaded || (e.appWin.clearStatusBusy(), e.loaded = !0), e.appWin.genTargetLUNMapping(), e.prepareUiData(), t.suspendEvents(!0), t.loadData(e.uiData), t.resumeEvents(), Ext.select(".syno-app-iscsi .create-session-host").on("click", function(t, i) {
            var n = i.dataset ? i.dataset.session : i.getAttribute("data-session");
            e.openCreateHostWindow({
                mode: "create_from_session",
                createFromSession: n
            })
        }), Ext.select(".syno-app-iscsi .target-copy-iqn").on("click", function(t, i) {
            var n = i.dataset ? i.dataset.iqn : i.getAttribute("data-iqn"),
                s = String.format(SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_iqn_copied"), n);
            e.appWin.getMsgBox().alert(SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_copy_iqn"), e.copyToClipboard(n) ? s : SYNO.SDS.iSCSI.Utils.T("error", "clip_failed"))
        }), 0 < e.view.store.getCount() && 0 === e.view.getSelectedItemIds().length && e.view.select(0, !0, !0), e.onSelectChange()
    },
    onSelectChange: function() {
        var e = this.view.getSelectedItem(),
            t = this.getButton("create"),
            i = this.getButton("remove"),
            n = this.getButton("manage"),
            s = this.getButton("flip");
        this.enableButton(t, this.canCreate()), this.enableButton(i, this.canDelete(e)), this.enableButton(n, this.canManage(e)), this.enableButton(s, this.canFlip(e)), e && s.setText(e.get("is_enabled") && "offline" !== e.get("status") ? SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_disable") : SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_enable"))
    },
    canCreate: function() {
        return !this.appWin.isUpToTargetMaxCount()
    },
    canDelete: function(e) {
        return !!e && !e.get("is_default_target")
    },
    canManage: function(e) {
        return !!e
    },
    canFlip: function(e) {
        return !!e && !e.get("is_default_target")
    },
    getButton: function(e) {
        return this.getTopToolbar().getComponent(e)
    },
    enableButton: function(e, t) {
        if (!e) throw Error("could not get button");
        e.setDisabled(!t)
    },
    onCreate: function() {
        this.openWindow("WizardCreate", {})
    },
    onDelete: function() {
        var e, t = this,
            i = t.view.getSelectedItem();
        i && (e = t.appWin.iscsiLuns.getMatched(function() {
            return i.isMappedToLUN(this.get("uuid"))
        }), e && 0 !== e.length ? t.openWindow("Delete", {
            target: i,
            mapped_luns: e,
            isCinderTarget: t.isCinderTarget(i)
        }) : SYNO.SDS.Utils.PasswordConfirmDialog.openDialog(t.appWin, function() {
            this.setStatusBusy({
                text: SYNO.SDS.iSCSI.Utils.T("common", "saving")
            }), this.sendWebAPI({
                api: "SYNO.Core.ISCSI.Target",
                method: "delete",
                version: 1,
                params: {
                    target_id: i.id.toString()
                },
                scope: this,
                callback: function(e, t) {
                    if (this.clearStatusBusy(), !e) return void SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(this, t);
                    this.fireEvent("poll_activate")
                }
            })
        }))
    },
    onEdit: function() {
        var e = this.view.getSelectedItem();
        e && this.openWindow("Edit", {
            target: e,
            isCinderTarget: this.isCinderTarget(e)
        })
    },
    onFlip: function() {
        var e = this,
            t = e.view.getSelectedItem(),
            i = t.get("is_enabled") && "offline" !== t.get("status"),
            n = t.get("status"),
            s = {
                target_id: t.get("target_id").toString()
            };
        "connected" === n ? this.appWin.getMsgBox().confirm(this.title, SYNO.SDS.iSCSI.Utils.T("san_trg", "disconnect_warning"), function(e) {
            "yes" === e && this.doFlip(i, s)
        }, this) : this.doFlip(i, s)
    },
    doFlip: function(e, t) {
        var i = e ? "disable" : "enable",
            n = this,
            s = this.owner;
        s.setStatusBusy({
            text: SYNO.SDS.iSCSI.Utils.T("common", "saving")
        }), this.sendWebAPI({
            api: "SYNO.Core.ISCSI.Target",
            method: i,
            version: 1,
            params: t,
            callback: function(t, i) {
                if (s.clearStatusBusy(), !t) return void SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(s, i);
                SYNO.SDS.StatusNotifier.setServiceDisabled("SYNO.SDS.StorageManager.ISCSI", e), s.setStatusBusy(), n.loaded = !1, s.fireEvent("poll_activate")
            }
        })
    },
    openWindow: function(e, t) {
        var i = this,
            n = new SYNO.SDS.iSCSI.Target[e](Ext.apply({
                appWin: i.appWin,
                owner: i.owner
            }, t));
        i.mon(n, "close", function() {
            Ext.isFunction(n.hideFromOwner) && n.hideFromOwner(), n.isDataChanged && (i.owner.setStatusBusy(), i.loaded = !1, i.appWin.fireEvent("poll_activate"))
        }, i, {
            single: !0
        }), n.open()
    },
    openCreateHostWindow: function(e) {
        var t = this,
            i = new SYNO.SDS.iSCSI.Host.Create(Ext.apply({
                appWin: t.appWin,
                owner: t.owner
            }, e));
        t.mon(i, "close", function() {
            Ext.isFunction(i.hideFromOwner) && i.hideFromOwner(), i.isDataChanged && (t.owner.setStatusBusy(), t.loaded = !1, t.appWin.fireEvent("poll_activate"))
        }, t, {
            single: !0
        }), i.open()
    },
    isCinderTarget: function(e) {
        var t = e.get("mapped_luns"),
            i = this.appWin.iscsiLuns;
        return t.some(function(e) {
            return i.getById(e.lun_uuid).isLunOwnedByCinder()
        })
    }
}), Ext.define("SYNO.SDS.iSCSI.Host.Initiator", {
    extend: "SYNO.ux.EditorGridPanel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.parent = e.parent, t.removeIndex = void 0, t.createFromSession = e.createFromSession, t.rendered = !1, t.loaded = !1, t.alreadyMappedInitiator = [];
        var i = new SYNO.ux.EnableColumn({
            dataIndex: "checked",
            width: 40,
            align: "center",
            bindRowClick: !0,
            disableSelectAll: t.createFromSession,
            isIgnore: function(e, i) {
                return i.get("is_added") || t.createFromSession
            },
            renderer: function(e, i, n) {
                return n.get("is_added") || t.createFromSession ? String.format('<div class="syno-ux-grid-enable-column-disabled-checked"></div>') : SYNO.ux.EnableColumn.prototype.renderer.call(this, e, i, n)
            }
        });
        t.initiatorId = Ext.id(), t.initiatorColumn = {
            itemId: "initiator",
            headerHtmlEncode: !1,
            header: String.format('<span id="{0}">{1}</span>', t.initiatorId, SYNO.SDS.iSCSI.Utils.T("san_host", "initiator_iqn_or_wwpn")),
            dataIndex: "initiator",
            width: 200,
            renderer: SYNO.SDS.iSCSI.Utils.htmlSelectingGridEncodeRender
        }, t.store = t.createStore();
        var n = {
            plugins: [i],
            tbar: {
                defaultType: "syno_button",
                items: [{
                    itemId: "createBtn",
                    text: SYNO.SDS.iSCSI.Utils.T("san_host", "add_host_button"),
                    handler: t.onCreate,
                    scope: t
                }],
                hidden: t.createFromSession
            },
            bbar: {
                xtype: "syno_panel",
                padding: "0px 0px",
                style: "border-top-color: #EBF0F5; border-width: 1px 0 0;",
                items: [{
                    xtype: "syno_displayfield",
                    padding: "0px 0px",
                    htmlEncode: !1,
                    value: String.format('<span style="color:green">{0}: </span><span>{1}</span>', SYNO.SDS.iSCSI.Utils.T("common", "note"), SYNO.SDS.iSCSI.Utils.T("san_host", "desc_not_listed_initiator"))
                }],
                hidden: t.createFromSession
            },
            colModel: new Ext.grid.ColumnModel({
                columns: [i, t.initiatorColumn, {
                    id: "type",
                    header: SYNO.SDS.iSCSI.Utils.T("common", "type"),
                    dataIndex: "is_added",
                    renderer: function(e, t, i) {
                        return SYNO.SDS.iSCSI.Utils.htmlSelectingGridEncodeRender(e ? SYNO.SDS.iSCSI.Utils.T("san_host", "added_manually") : SYNO.SDS.iSCSI.Utils.T("san_host", "discovered"), t, i)
                    }
                }, {
                    id: "is_added",
                    dataIndex: "is_added",
                    align: "center",
                    renderer: function(e, i, n) {
                        if (!e) return "";
                        var s = Ext.id();
                        return Ext.defer(function() {
                            document.getElementById(s) && new SYNO.ux.Button({
                                text: SYNO.SDS.iSCSI.Utils.T("common", "remove"),
                                timestamp: n.get("timestamp"),
                                listeners: {
                                    afterrender: function(e) {
                                        e.mon(e.getEl(), {
                                            mousedown: function(i) {
                                                t.mousedownInitiator = e.timestamp, i.stopEvent()
                                            },
                                            mouseup: function() {
                                                if (t.mousedownInitiator === e.timestamp)
                                                    for (var i = 0; i < t.getStore().getCount(); ++i)
                                                        if (t.getStore().getAt(i).get("timestamp") === e.timestamp) {
                                                            t.removeRow = i, t.lastEditorValue = t.currentEditor.getValue(), t.getStore().removeAt(i), t.currentEditor.cancelEdit(), t.setMask(), t.adjustIsAddedColumn();
                                                            break
                                                        } delete t.mousedownInitiator
                                            }
                                        })
                                    }
                                }
                            }).render(document.body, s)
                        }, 50), String.format('<div id="{0}"></div>', s)
                    }
                }],
                editors: {
                    discovered: new Ext.grid.GridEditor(new Ext.form.DisplayField({})),
                    added: new Ext.grid.GridEditor(new SYNO.ux.TextField({
                        maxlength: 128,
                        vtype: "iscsilunname",
                        selectOnFocus: !0,
                        listeners: {
                            focus: t.onFocus,
                            blur: t.onBlur,
                            scope: t
                        }
                    }))
                },
                getCellEditor: function(e, i) {
                    if (t.editRow = i, delete t.removeRow, "initiator" === this.getDataIndex(e)) {
                        var n = t.store.getAt(i);
                        return t.currentEditor = this.editors[n.get("is_added") ? "added" : "discovered"], t.currentEditor
                    }
                    return Ext.grid.ColumnModel.prototype.getCellEditor.call(this, e, i)
                },
                destroy: function() {
                    this.editors.added.destroy(), this.editors.discovered.destroy(), Ext.grid.ColumnModel.prototype.destroy.apply(this, arguments)
                }
            }),
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: !0,
                moveEditorOnEnter: !1,
                listeners: {
                    selectionchange: function(e) {
                        var i = e.getSelected();
                        i && i.get("is_added") ? t.getColumnModel().setEditable(1, !0) : t.getColumnModel().setEditable(1, !1)
                    },
                    scope: t
                }
            }),
            store: t.store,
            enableHdMenu: !1,
            enableColumnMove: !1,
            autoScroll: !0,
            cls: "bbar-note-no-padding without-dirty-red-grid iscsi-remove-sort-icon",
            listeners: {
                afterrender: function() {
                    t.rendered = !0;
                    var e = t.getColumnModel();
                    t.isAddedColumnOriWidth = e.getColumnWidth(e.getIndexById("is_added")), t.typeColumnOriWidth = e.getColumnWidth(e.getIndexById("type")), t.rendered && t.loaded && (t.adjustIsAddedColumn(), t.setMask())
                }
            }
        };
        t.callParent([Ext.apply(n, e)])
    },
    addTip: function() {
        var e = this;
        SYNO.ux.AddTip(document.getElementById(e.initiatorId), SYNO.SDS.iSCSI.Utils.T("san_host", "desc_initiator_iqn_or_wwpn"))
    },
    createStore: function() {
        var e = this;
        return new Ext.data.JsonStore({
            autoDestory: !0,
            idProperty: "initiator",
            fields: ["checked", "initiator", "is_added", "timestamp"],
            sortInfo: {
                field: "initiator",
                direction: "ASC"
            },
            listeners: {
                load: function(t, i) {
                    e.loaded = !0, e.rendered && e.loaded && (e.adjustIsAddedColumn(), e.setMask(), e.addTip())
                }
            }
        })
    },
    onCreate: function() {
        var e = this,
            t = e.getStore().recordType;
        e.stopEditing(), e.setColumnVisible(), e.getStore().insert(0, new t({
            checked: !0,
            initiator: "",
            is_added: !0,
            timestamp: Date.now()
        })), e.startEdit(0)
    },
    onFocus: function() {
        this.disableButton(!0)
    },
    onBlur: function(e) {
        var t = this,
            i = e.getValue(),
            n = 0;
        if (!t.owner.mouseoverCancelBtn) {
            if (void 0 !== t.removeRow) {
                var s = t.removeRow;
                if (delete t.removeRow, s < t.editRow) return t.editRow--, t.restartEdit(), void t.currentEditor.setValue(t.lastEditorValue);
                if (s > t.editRow) return t.restartEdit(), void t.currentEditor.setValue(t.lastEditorValue)
            } else if (i)
                if (t.stopEditing(), e.getValue()) {
                    t.getStore().each(function(e) {
                        e.get("initiator").toLowerCase() === i.toLowerCase() && n++
                    });
                    t.isExistedIqnOrWwpn(i) ? t.openExistedIQNWWPNErrorWindow() : ! function(e) {
                        var i = new RegExp("^([0-9A-Fa-f]{2}:){7}[0-9A-Fa-f]{2}$");
                        return "fc" === t.protocol && !i.test(e)
                    }(i) ? ! function(e) {
                        return n > 1 || t.alreadyMappedInitiator.some(function(t) {
                            return t.toLowerCase() === e.toLowerCase()
                        })
                    }(i) ? t.isAlreadyBindedByOtherHost(i) && t.openAlreadyBindedWindow(t.findBindedHost(i).name) : t.openDuplicatedWindow() : t.openFormatErrorWindow()
                } else t.currentEditor.cancelEdit(), t.getStore().removeAt(t.editRow);
            else t.currentEditor.cancelEdit(), t.getStore().removeAt(t.editRow);
            t.disableButton(!1), t.adjustIsAddedColumn(), t.setMask()
        }
    },
    isExistedIqnOrWwpn: function(e) {
        var t = this,
            i = t.appWin.fcTargets.getAll(),
            n = t.appWin.iscsiTargets.getAll(),
            s = n.filter(function(t) {
                return t.get("iqn") === e
            }),
            a = i.filter(function(t) {
                return t.get("wwpn") === e
            });
        return s.length || a.length
    },
    disableButton: function(e) {
        var t = this;
        t.getTopToolbar().getComponent("createBtn").setDisabled(e), t.parent.setNextEnable(!e)
    },
    startEdit: function(e) {
        this.getSelectionModel().selectRow(e), this.startEditing(e, 1), this.setMask()
    },
    openDuplicatedWindow: function() {
        var e = this;
        this.owner.getMsgBox().alert("Initiator", SYNO.SDS.iSCSI.Utils.T("san_host", "err_initiator_duplicated"), function() {
            this.restartEdit()
        }, e)
    },
    openAlreadyBindedWindow: function(e) {
        var t = this;
        this.owner.getMsgBox().alert("Initiator", String.format(SYNO.SDS.iSCSI.Utils.T("san_host", "err_initiator_assigned"), e), function() {
            this.restartEdit()
        }, t)
    },
    openFormatErrorWindow: function() {
        var e = this;
        this.owner.getMsgBox().alert("Initiator", SYNO.SDS.iSCSI.Utils.T("san_host", "err_wwpn_format"), function() {
            this.restartEdit()
        }, e)
    },
    openExistedIQNWWPNErrorWindow: function() {
        var e = this;
        e.owner.getMsgBox().alert("Initiator", SYNO.SDS.iSCSI.Utils.T("san_host", "desc_initiator_iqn_or_wwpn_existed"), function() {
            e.restartEdit()
        }, e)
    },
    findBindedHost: function(e) {
        return this.appWin.hosts.find(function(t) {
            return t.initiator_ids.some(function(t) {
                return t.toLowerCase() === e.toLowerCase()
            })
        })
    },
    isAlreadyBindedByOtherHost: function(e) {
        var t = this,
            i = t.findBindedHost(e);
        return i && t.hostName !== i.name
    },
    reload: function(e) {
        this.loadInitiatorWithMasking(e, [])
    },
    loadInitiatorWithMasking: function(e, t, i) {
        var n = this;
        n.protocol = e;
        var s = [];
        if (n.createFromSession) return void n.getStore().loadData([{
            initiator: n.createFromSession,
            is_added: !1,
            checked: !0
        }]);
        if (n.hostName = i, n.alreadyMappedInitiator = t, "fc" === e) {
            n.appWin.fcTargets.getAll().forEach(function(e) {
                e.get("connected_sessions").forEach(function(e) {
                    -1 === t.indexOf(e.wwpn) && (n.isAlreadyBindedByOtherHost(e.wwpn) || s.push({
                        initiator: e.wwpn,
                        is_added: !1
                    }))
                })
            })
        } else {
            n.appWin.iscsiTargets.getAll().forEach(function(e) {
                e.get("connected_sessions").forEach(function(e) {
                    -1 === t.indexOf(e.iqn) && (n.isAlreadyBindedByOtherHost(e.iqn) || s.push({
                        initiator: e.iqn,
                        is_added: !1
                    }))
                })
            })
        }
        n.getStore().loadData(s)
    },
    getSelectedInitiators: function() {
        return this.getStore().data.items.reduce(function(e, t) {
            return t.get("checked") && e.push(t.get("initiator")), e
        }, [])
    },
    setMask: function() {
        this.getStore().getCount() ? this.body.unmask() : this.body.mask(SYNO.SDS.iSCSI.Utils.T("san_host", "desc_no_discovered_initiator"), "syno-ux-mask-info")
    },
    adjustIsAddedColumn: function() {
        var e = this,
            t = e.getColumnModel(),
            i = t.getIndexById("is_added"),
            n = t.getIndexById("type"),
            s = e.getStore().data.items.every(function(e) {
                return !e.get("is_added")
            });
        t.isHidden(i) !== s && (t.setColumnWidth(n, s ? e.typeColumnOriWidth + e.isAddedColumnOriWidth : e.typeColumnOriWidth), t.setHidden(i, s))
    },
    setColumnVisible: function() {
        var e = this,
            t = e.getColumnModel(),
            i = t.getIndexById("is_added"),
            n = t.getIndexById("type");
        t.isHidden(i) && (t.setColumnWidth(n, e.typeColumnOriWidth), t.setHidden(i, !1))
    },
    restartEdit: function() {
        var e = this;
        e.startEdit(e.editRow)
    }
}), Ext.define("SYNO.SDS.iSCSI.Host.Property", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.parent = e.parent, t.mode = e.mode || "edit";
        var i = [{
                xtype: "syno_textfield",
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("common", "name"),
                vtype: "iscsihostname",
                maxlength: 128,
                allowBlank: !1,
                name: "name",
                validator: function(e) {
                    return e === this.originalValue || (!!t.appWin.isUniqueHostName(e) || SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_lun_name_exists"))
                }
            }, {
                xtype: "syno_textfield",
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("san_host", "description"),
                maxlength: 128,
                name: "description"
            }, {
                xtype: "syno_combobox",
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("san_host", "operation_system"),
                name: "operation_system",
                forceSelection: !0,
                value: "vmware_esxi",
                store: new Ext.data.ArrayStore({
                    autoDestroy: !0,
                    fields: ["value", "display"],
                    data: SYNO.SDS.iSCSI.Utils.HostOSString
                }),
                valueField: "value",
                displayField: "display"
            }, {
                xtype: "syno_combobox",
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("san_host", "protocol"),
                name: "protocol",
                itemId: "protocol",
                forceSelection: !0,
                allowBlank: !1,
                value: "iscsi",
                store: new Ext.data.ArrayStore({
                    autoDestroy: !0,
                    fields: ["value", "display"],
                    data: SYNO.SDS.iSCSI.Utils.HostProtocolString
                }),
                valueField: "value",
                displayField: "display",
                tpl: ['<tpl for=".">', "<tpl if=\"value =='fc_disabled_undetected'\">", '<div class="syno-app-iscsi">', '<div ext:qtip="{display}" class="x-combo-list-item host-protocol-disabled">{display}</div>', "</div>", "</tpl>", "<tpl if=\"value !='fc_disabled_undetected'\">", '<div class="x-combo-list-item">{display}</div>', "</tpl>", "</tpl>"],
                listeners: {
                    beforeselect: function(e, i) {
                        return !t.isProtocolDisabled(i.get("value"))
                    },
                    select: function(e, i) {
                        t.parent && t.parent.fireEvent("protocol_change", this.ownerCt.getComponent("protocol").getValue())
                    },
                    expand: function() {
                        this.getStore().filterBy(function(e, i) {
                            return t.filterProtocolByKey(e.get("value"), t.appWin.hasFibreChannels() ? "fc" : "fc_disabled_undetected")
                        })
                    }
                },
                hidden: "create" !== t.mode || !t.appWin.supportFC
            }, {
                xtype: "syno_displayfield",
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("san_host", "protocol"),
                name: "protocolText",
                itemId: "protocolText",
                value: "iSCSI",
                hidden: "create" === t.mode || !t.appWin.supportFC
            }, {
                xtype: "syno_textfield",
                name: "host_id",
                hidden: !0
            }],
            n = {
                title: SYNO.SDS.iSCSI.Utils.T("common", "general"),
                labelWidth: 260,
                fieldWidth: 260,
                trackResetOnLoad: !0,
                items: i
            };
        t.callParent([Ext.apply(n, e)])
    },
    getProps: function() {
        return this.getForm().getFieldValues()
    },
    setProps: function(e) {
        this.getForm().setValues({
            name: e.name,
            description: e.description,
            operation_system: e.operation_system,
            protocol: e.protocol,
            protocolText: SYNO.SDS.iSCSI.Utils.GetHostProtocolString(e.protocol),
            host_id: e.host_id
        }), this.getForm().clearInvalid()
    },
    getProtocol: function() {
        return this.getProps().protocol
    },
    getOSType: function() {
        return this.getProps().operation_system
    },
    setProtocol: function(e) {
        this.getForm().setValues({
            protocol: e,
            protocolText: SYNO.SDS.iSCSI.Utils.GetHostProtocolString(e)
        }), this.getForm().clearInvalid()
    },
    isValid: function() {
        return this.getForm().isValid()
    },
    isProtocolDisabled: function(e) {
        return "fc_disabled_undetected" === e
    },
    filterProtocolByKey: function(e, t) {
        return "iscsi" === e || t === e
    }
}), Ext.define("SYNO.SDS.iSCSI.Host.Wizard.PropertyStep", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.parent = e.parent, t.mode = e.mode, t.createFromSession = e.createFromSession;
        var i = {
            headline: SYNO.SDS.iSCSI.Utils.T("san_host", "title_property_step"),
            height: 440,
            width: 540,
            layout: "vbox",
            items: [t.formpanel = new SYNO.SDS.iSCSI.Host.Property({
                width: 540,
                height: t.appWin.supportFC ? 160 : 120,
                appWin: t.appWin,
                owner: t.owner,
                parent: t,
                mode: t.mode
            }), {
                xtype: "syno_displayfield",
                value: SYNO.SDS.iSCSI.Utils.T("san_host", "desc_select_initiator"),
                hidden: t.createFromSession
            }, t.initiator = new SYNO.SDS.iSCSI.Host.Initiator({
                width: 540,
                appWin: t.appWin,
                owner: t.owner,
                parent: t,
                createFromSession: t.createFromSession,
                flex: 1
            })],
            listeners: {
                protocol_change: function(e) {
                    t.initiator.reload(e)
                }
            }
        };
        t.callParent([Ext.apply(i, e)])
    },
    activate: function() {
        var e = this;
        e.loaded || (e.setProtocol(e.getProtocol()), e.loaded = !0)
    },
    getProps: function() {
        return this.formpanel.getProps()
    },
    getForm: function() {
        return this.formpanel.getForm()
    },
    getProtocol: function() {
        return this.formpanel.getProtocol()
    },
    getOSType: function() {
        return this.formpanel.getOSType()
    },
    setProtocol: function(e) {
        this.formpanel.setProtocol(e), this.initiator.reload(e)
    },
    getSelectedInitiators: function() {
        return this.initiator.getSelectedInitiators()
    },
    getNext: function() {
        var e = this;
        return !!e.getForm().isValid() && (0 >= e.getSelectedInitiators().length ? (e.owner.getMsgBox().alert(SYNO.SDS.iSCSI.Utils.T("sanmgr", "app_title"), SYNO.SDS.iSCSI.Utils.T("san_host", "err_initiator_empty")), !1) : e.nextId)
    },
    setNextEnable: function(e) {
        this.parent.setNextEnable(e)
    },
    summary: function(e) {
        var t = this,
            i = t.getProps(),
            n = SYNO.SDS.iSCSI.Utils.GetHostOSString(i.operation_system),
            s = SYNO.SDS.iSCSI.Utils.GetHostProtocolString(i.protocol);
        e.append(SYNO.SDS.iSCSI.Utils.T("san_host", "host_name"), i.name), e.append(SYNO.SDS.iSCSI.Utils.T("san_host", "description"), i.description), e.append(SYNO.SDS.iSCSI.Utils.T("san_host", "operation_system"), n), t.appWin.supportFC && e.append(SYNO.SDS.iSCSI.Utils.T("san_host", "protocol"), s), e.append(SYNO.SDS.iSCSI.Utils.T("san_host", "initiator"), t.getSelectedInitiators())
    }
}), Ext.define("SYNO.SDS.iSCSI.Host.Privilege", {
    extend: "SYNO.ux.EditorGridPanel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.mode = e.mode, t.originalACLSetting = {};
        var i = {
            title: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_permission"),
            bbar: {
                xtype: "syno_panel",
                padding: "0px 0px",
                style: "border-top-color: #EBF0F5; border-width: 1px 0 0;",
                items: [{
                    xtype: "syno_displayfield",
                    itemId: "desc_list_luns_with_protocol",
                    padding: "0px 0px",
                    htmlEncode: !1,
                    value: ""
                }],
                hidden: !0
            },
            colModel: new Ext.grid.ColumnModel({
                columns: [{
                    id: "lun",
                    width: 100,
                    header: SYNO.SDS.iSCSI.Utils.T("san_lun", "lun"),
                    dataIndex: "lun",
                    renderer: SYNO.SDS.iSCSI.Utils.htmlSelectingGridEncodeRender
                }, {
                    id: "description",
                    width: 130,
                    header: SYNO.SDS.iSCSI.Utils.T("san_host", "description"),
                    dataIndex: "description",
                    renderer: SYNO.SDS.iSCSI.Utils.htmlSelectingGridEncodeRender
                }, {
                    id: "hostpermission",
                    width: 120,
                    header: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_permission"),
                    dataIndex: "permission",
                    renderer: function(e, t, i) {
                        var n = i.get("enabled"),
                            s = "noaccess" === i.get("editors");
                        t.css += n ? " syno-ux-triggerfield lun-permission " : " iscsi-host-no-triggerfield lun-permission ";
                        var a = SYNO.SDS.iSCSI.Utils.renderPermission(e);
                        return s ? String.format('<span style="color: gray">{0}</span>', a) : a
                    }
                }, {
                    id: "hosttip",
                    width: 30,
                    header: "",
                    dataIndex: "hosttip",
                    renderer: function(e, t, i) {
                        var n = Ext.id();
                        return e && Ext.defer(function() {
                            var t = document.getElementById(n);
                            t && SYNO.ux.AddTip(t, e)
                        }, 50), String.format('<span id="{0}"></span>', n)
                    }
                }],
                editors: {
                    noaccess: new Ext.grid.GridEditor(new Ext.form.DisplayField({})),
                    readonly: new Ext.grid.GridEditor(new SYNO.ux.ComboBox({
                        forceSelection: !0,
                        editable: !1,
                        allowBlank: !1,
                        lazyInit: !1,
                        store: new Ext.data.ArrayStore({
                            autoDestory: !0,
                            fields: ["value", "display"],
                            data: SYNO.SDS.iSCSI.Utils.genRenderPermissionData(["r", "-"])
                        }),
                        valueField: "value",
                        displayField: "display",
                        listeners: {
                            focus: function() {
                                this.expand(), this.restrictHeight()
                            }
                        }
                    })),
                    all: new Ext.grid.GridEditor(new SYNO.ux.ComboBox({
                        forceSelection: !0,
                        editable: !1,
                        allowBlank: !1,
                        lazyInit: !1,
                        store: new Ext.data.ArrayStore({
                            autoDestory: !0,
                            fields: ["value", "display"],
                            data: SYNO.SDS.iSCSI.Utils.genRenderPermissionData(["rw", "r", "-"])
                        }),
                        valueField: "value",
                        displayField: "display",
                        listeners: {
                            focus: function() {
                                this.expand(), this.restrictHeight()
                            },
                            select: function(e, i) {
                                "rw" === i.get("value") && t.downgradeNotifyIfNeeded()
                            }
                        }
                    }))
                },
                getCellEditor: function(e, i) {
                    if ("permission" === this.getDataIndex(e)) {
                        var n = t.store.getAt(i);
                        return this.editors[n.get("editors")]
                    }
                    return Ext.grid.ColumnModel.prototype.getCellEditor.call(this, e, i)
                },
                destroy: function() {
                    this.editors.noaccess.destroy(), this.editors.readonly.destroy(), this.editors.all.destroy(), Ext.grid.ColumnModel.prototype.destroy.apply(this, arguments)
                }
            }),
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: !0,
                listeners: {
                    selectionchange: function(e) {
                        var t = e.getSelected(),
                            i = t && t.get("enabled");
                        this.getColumnModel().setEditable(2, i)
                    },
                    scope: t
                }
            }),
            store: t.createStore(),
            enableHdMenu: !1,
            enableColumnMove: !1,
            enableColumnResize: !1,
            autoScroll: !0,
            cls: "bbar-note-no-padding without-dirty-red-grid iscsi-remove-sort-icon"
        };
        t.callParent([Ext.apply(i, e)])
    },
    downgradeNotifyIfNeeded: function() {
        var e = this;
        if ("create" !== e.mode) {
            var t = e.getSelectionModel().getSelected(),
                i = e.appWin.hosts.some(function(t) {
                    return e.owner.host.get("uuid") === t.uuid && t.is_connected
                });
            "edit" === e.mode && i && e.originalACLSetting.hasOwnProperty(t.get("uuid")) && "r" === e.originalACLSetting[t.get("uuid")].permission && e.owner.getMsgBox().alert(SYNO.SDS.iSCSI.Utils.T("common", "remove"), String.format(SYNO.SDS.iSCSI.Utils.T("san_host", "desc_downgrade_lun"), e.owner.host.get("name"), t.get("lun")))
        }
    },
    createStore: function() {
        var e = this;
        return new Ext.data.JsonStore({
            autoDestory: !0,
            idProperty: "lun",
            fields: [{
                name: "lun",
                sortType: "asNaturalUCString"
            }, "uuid", "acls", "description", "permission", "privilege_type", "enabled", "editors", "hosttip"],
            sortInfo: {
                field: "lun",
                direction: "ASC"
            },
            listeners: {
                load: function() {
                    e.getStore().sort([{
                        field: "enabled",
                        direction: "DESC"
                    }, {
                        field: "lun",
                        direction: "ASC"
                    }], "ASC")
                }
            }
        })
    },
    loadLUN: function() {
        var e = this,
            t = e.owner.getStep("property_step").getProtocol(),
            i = e.appWin.iscsiLuns.getAll().reduce(function(e, t) {
                return e[t.get("uuid")] = {
                    permission: "rw"
                }, e
            }, {});
        e.initProps(t, i)
    },
    initEditProps: function(e, t) {
        var i = this,
            n = i.appWin.iscsiLuns.getAll().reduce(function(e, i) {
                var n = "-";
                return "allow_all" === i.get("privilege") ? n = "rw" : t[i.get("uuid")] && (n = t[i.get("uuid")].permission), e[i.get("uuid")] = {
                    permission: n
                }, e
            }, {});
        this.initProps(e, n)
    },
    initProps: function(e, t) {
        var i = this,
            n = "edit" === i.mode ? SYNO.SDS.iSCSI.Utils.HostOSTypeInverse[i.owner.host.get("type")] : i.owner.getStep("property_step").getOSType();
        i.loaded || (i.loaded = !0, i.originalACLSetting = t), i.protocol = e;
        var s = i.appWin.iscsiLuns.getAll().filter(function(t) {
            return t.canBeShownAsAllowAll() && e === t.get("mappingType")
        }).reduce(function(e, s) {
            var a = s.get("name"),
                o = s.get("description"),
                r = s.get("uuid"),
                l = s.get("acls"),
                S = "allow_all" === s.get("privilege"),
                d = !S && function() {
                    return i.appWin.hosts.find(function(e) {
                        return SYNO.SDS.iSCSI.Utils.HostOSTypeInverse[e.type] != n && e.acls.find(function(e) {
                            return e.lun_uuid === r && "-" !== e.permission
                        })
                    })
                }(),
                c = !S && function() {
                    return ("edit" !== i.mode || "rw" !== t[r].permission) && (l && l.find(function(e) {
                        return "rw" === e.permission
                    }))
                }() && ! function() {
                    return -1 !== SYNO.SDS.iSCSI.Utils.ClusterAwareOS.indexOf(n)
                }(),
                p = "";
            if (d) p = SYNO.SDS.iSCSI.Utils.T("san_host", "desc_map_another_os");
            else if (c) {
                var u = l.find(function(e) {
                        return "rw" === e.permission
                    }),
                    h = i.appWin.hosts.find(function(e) {
                        return -1 !== e.initiator_ids.indexOf(u.iqn)
                    });
                p = String.format(SYNO.SDS.iSCSI.Utils.T("san_host", "already_assigned_host"), h.name)
            }
            return e.push({
                lun: a,
                uuid: r,
                description: o,
                permission: "create" === i.mode ? d ? "-" : c ? "r" : "rw" : S ? "rw" : t[r].permission,
                privilege_type: s.get("privilege"),
                enabled: !d,
                editors: d ? "noaccess" : c ? "readonly" : "all",
                acls: l,
                hosttip: p
            }), e
        }, []);
        i.getStore().loadData(s), i.setBBar()
    },
    getLunPrivilege: function(e) {
        var t = {};
        return this.getStore().each(function(i) {
            e === ("allow_all" === i.get("privilege_type") && "rw" === i.get("permission")) && (t[i.get("uuid")] = {
                type: i.get("privilege_type"),
                lun: i.get("lun"),
                permission: i.get("permission")
            })
        }), t
    },
    getAllLunPrivilege: function() {
        var e = {};
        return this.getStore().each(function(t) {
            e[t.get("uuid")] = {
                type: t.get("privilege_type"),
                lun: t.get("lun"),
                permission: t.get("permission")
            }
        }), e
    },
    getAllowAllLunPrivilege: function() {
        return this.getLunPrivilege(!0)
    },
    getCustomLunPrivilege: function() {
        return this.getLunPrivilege(!1)
    },
    getAllowAlltoCustomLuns: function() {
        var e = this,
            t = e.getCustomLunPrivilege();
        return e.appWin.iscsiLuns.getAll().reduce(function(e, i) {
            return "allow_all" === i.get("privilege") && t[i.get("uuid")] && e.push(i.get("name")), e
        }, [])
    },
    setMask: function() {
        var e = this;
        e.getStore().getCount() ? e.body.unmask() : e.body.mask(SYNO.SDS.iSCSI.Utils.T("san_host", "desc_no_mapped_lun"), "syno-ux-mask-info")
    },
    aclIsValid: function() {
        var e = this,
            t = e.owner.prop.getProps(),
            i = JSON.parse(JSON.stringify(e.appWin.hosts)),
            n = i.findIndex(function(e) {
                return parseInt(t.host_id, 10) === e.host_id
            });
        if (0 > n) return !1;
        i[n].type = SYNO.SDS.iSCSI.Utils.HostOSType[t.operation_system];
        var s = e.getCustomLunPrivilege();
        return i[n].acls = [], Object.keys(s).forEach(function(e) {
            i[n].acls.push({
                lun_uuid: e,
                permission: s[e].permission
            })
        }), SYNO.SDS.iSCSI.Utils.ACLValidator(i)
    },
    isValid: function() {
        return this.aclIsValid()
    },
    getInvalidPrivileges: function() {
        var e = this,
            t = e.owner.prop.getProps(),
            i = JSON.parse(JSON.stringify(e.appWin.hosts)),
            n = i.findIndex(function(e) {
                return parseInt(t.host_id, 10) === e.host_id
            });
        if (0 > n) return !1;
        i[n].type = SYNO.SDS.iSCSI.Utils.HostOSType[t.operation_system];
        var s = e.getCustomLunPrivilege(),
            a = [];
        return Object.keys(s).forEach(function(e) {
            i[n].acls = [{
                lun_uuid: e,
                permission: s[e].permission
            }], SYNO.SDS.iSCSI.Utils.ACLValidator(i) || a.push(s[e].lun)
        }), a
    },
    setBBar: function() {
        var e = this,
            t = "create" === e.mode ? e.owner.getStep("property_step").getProtocol() : e.owner.host.get("protocol");
        if (e.appWin.hasFibreChannels()) {
            var i = String.format('<span style="color:green">{0}: </span><span>{1}</span>', SYNO.SDS.iSCSI.Utils.T("common", "note"), "iscsi" === t ? SYNO.SDS.iSCSI.Utils.T("san_host", "desc_list_luns_only_iscsi") : SYNO.SDS.iSCSI.Utils.T("san_host", "desc_list_luns_only_fc"));
            e.getBottomToolbar().getComponent("desc_list_luns_with_protocol").setValue(i), e.getBottomToolbar().setVisible(!0), e.getBottomToolbar().doLayout()
        }
    }
}), Ext.define("SYNO.SDS.iSCSI.Host.Wizard.PrivilegeStep", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.owner = e.owner, i.grid = new SYNO.SDS.iSCSI.Host.Privilege({
            appWin: e.appWin,
            owner: e.owner,
            mode: "create",
            width: 540,
            flex: 1
        }), t = {
            headline: SYNO.SDS.iSCSI.Utils.T("san_host", "title_assign_lun"),
            height: 440,
            layout: "vbox",
            items: [i.grid]
        }, i.callParent([Ext.apply(t, e)])
    },
    activate: function() {
        this.grid.loadLUN()
    },
    getLunPrivilege: function() {
        var e = this.grid.getCustomLunPrivilege();
        return Object.keys(e).reduce(function(t, i) {
            return t[i] = e[i].permission, t
        }, {})
    },
    getNext: function() {
        var e = this;
        return 0 < e.grid.getAllowAlltoCustomLuns().length ? (e.owner.getMsgBox().confirm(SYNO.SDS.iSCSI.Utils.T("sanmgr", "app_title"), String.format(SYNO.SDS.iSCSI.Utils.T("san_host", "allow_all_to_custom"), e.grid.getAllowAlltoCustomLuns().join("<br>")), function(t) {
            "yes" === t && e.owner.goNext(e.nextId)
        }), !1) : e.nextId
    },
    summary: function(e) {
        var t = Object.values(this.grid.getAllLunPrivilege());
        e.append(SYNO.SDS.iSCSI.Utils.T("san_host", "lun_privilege"), t.map(function(e) {
            return String.format("{0} ({1})", e.lun, SYNO.SDS.iSCSI.Utils.renderPermission(e.permission))
        }))
    }
}), Ext.define("SYNO.SDS.iSCSI.Host.Wizard.SummaryStep", {
    extend: "SYNO.SDS.Wizard.SummaryStep",
    constructor: function(e) {
        var t = Ext.apply({
            headline: SYNO.SDS.iSCSI.Utils.T("ezinternet", "ezinternet_summary_title"),
            description: SYNO.SDS.iSCSI.Utils.T("san_host", "desc_confirm_setting"),
            viewConfig: {
                forceFit: !1
            },
            columns: [{
                width: 200,
                header: SYNO.SDS.iSCSI.Utils.T("status", "header_item"),
                dataIndex: "key",
                renderer: this.fieldRenderer
            }, {
                id: "value",
                autoExpand: !0,
                header: SYNO.SDS.iSCSI.Utils.T("status", "header_value"),
                dataIndex: "value",
                renderer: this.descRenderer,
                scope: this
            }],
            enableHdMenu: !1,
            enableColumnMove: !1,
            autoExpandColumn: "value",
            store: new SYNO.SDS.Wizard.SummaryStore
        }, e);
        SYNO.SDS.Wizard.SummaryStep.superclass.constructor.call(this, t)
    },
    descRenderer: function(e, t, i, n, s, a) {
        var o = e;
        return ("string" == typeof o || o instanceof String) && (o = [o]), o = o.map(function(e) {
            return Ext.util.Format.htmlEncode(e)
        }).join("<br>"), t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(o) + '"', o
    },
    getNext: function() {
        return this.owner.applySettings(null), !1
    }
}), Ext.define("SYNO.SDS.iSCSI.Host.Create", {
    extend: "SYNO.SDS.Wizard.ModalWindow",
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.owner = e.owner, i.mode = e.mode || "create", i.createFromSession = e.createFromSession, t = {
            title: SYNO.SDS.iSCSI.Utils.T("san_host", "create_title"),
            cls: "syno-app-iscsi",
            width: 620,
            height: 600,
            resizable: !1,
            border: !1,
            steps: []
        }, t.steps.push(new SYNO.SDS.Wizard.WelcomeStep({
            appWin: i.appWin,
            owner: i,
            headline: SYNO.SDS.iSCSI.Utils.T("san_host", "host"),
            itemId: "welcome_step",
            layout: "vbox",
            height: 440,
            layoutConfig: {
                align: "stretch"
            },
            items: [{
                xtype: "syno_displayfield",
                value: SYNO.SDS.iSCSI.Utils.T("san_host", "desc_add_host"),
                htmlEncode: !1
            }, {
                xtype: "syno_panel",
                itemId: "icon_panel",
                flex: 1,
                region: "center",
                layout: {
                    type: "vbox",
                    align: "center",
                    pack: "center"
                },
                items: [{
                    xtype: "box",
                    itemId: "icon",
                    cls: "host-welcome-icon-block"
                }]
            }],
            nextId: "property_step"
        })), t.steps.push(new SYNO.SDS.iSCSI.Host.Wizard.PropertyStep({
            appWin: i.appWin,
            owner: i,
            parent: i,
            itemId: "property_step",
            nextId: "privilege_step",
            mode: i.mode,
            createFromSession: i.createFromSession
        })), t.steps.push(new SYNO.SDS.iSCSI.Host.Wizard.PrivilegeStep({
            appWin: i.appWin,
            owner: i,
            itemId: "privilege_step",
            nextId: "summary"
        })), t.steps.push(new SYNO.SDS.iSCSI.Host.Wizard.SummaryStep({
            appWin: i.appWin,
            owner: i,
            itemId: "summary",
            nextId: null
        })), i.callParent([Ext.apply(t, e)])
    },
    getHostProps: function() {
        return this.getStep("property_step").getProps()
    },
    getSelectedInitiators: function() {
        return this.getStep("property_step").getSelectedInitiators()
    },
    getLunPrivilege: function() {
        return this.getStep("privilege_step").getLunPrivilege()
    },
    setNextEnable: function(e) {
        this.getButton("next").setDisabled(!e)
    },
    applySettings: function(e) {
        var t = this,
            i = t.getHostProps(),
            n = SYNO.SDS.iSCSI.Utils.HostOSType,
            s = {
                name: i.name,
                type: n[i.operation_system],
                protocol: i.protocol,
                description: i.description
            };
        t.setStatusBusy({
            text: SYNO.SDS.iSCSI.Utils.T("common", "saving")
        }), t.sendWebAPI({
            api: "SYNO.Core.ISCSI.Host",
            method: "create",
            version: 1,
            params: s,
            callback: function(e, i) {
                if (!e) return SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(this, i), void t.clearStatusBusy();
                t.isDataChanged = !0, t.editHostWebAPI(i.host_id, i.uuid)
            },
            scope: t
        })
    },
    editHostWebAPI: function(e, t) {
        var i = this,
            n = i.getSelectedInitiators(),
            s = i.getLunPrivilege(),
            a = {
                host_id: e.toString(),
                initiator_ids: n
            },
            o = {
                uuid: t,
                acls: []
            },
            r = [];
        Object.keys(s).forEach(function(e) {
            o.acls.push({
                lun_uuid: e,
                permission: s[e]
            }), "rw" !== s[e] && r.push({
                api: "SYNO.Core.ISCSI.LUN",
                method: "acl_masks_add",
                version: 1,
                params: {
                    uuid: e,
                    acls: [{
                        iqn: "iqn.2000-01.com.synology:default.acl",
                        permission: "-"
                    }]
                }
            })
        }), a.initiator_ids.length && r.push({
            api: "SYNO.Core.ISCSI.Host",
            method: "map_initiator",
            version: 1,
            params: a
        }), o.acls.length && r.push({
            api: "SYNO.Core.ISCSI.Host",
            method: "lun_acl_masks_set",
            version: 1,
            params: o
        }), r.length ? i.sendWebAPI({
            compound: {
                stopwhenerror: !0,
                mode: "sequential",
                params: r
            },
            callback: function(e, t) {
                if (i.clearStatusBusy(), !e || t.has_fail) return SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(this, t), void i.clearStatusBusy();
                i.close()
            },
            scope: i
        }) : (i.clearStatusBusy(), i.close())
    }
}), Ext.define("SYNO.SDS.iSCSI.Host.InitiatorEditWindow", {
    extend: "SYNO.SDS.iSCSI.ModalWindow",
    constructor: function(e) {
        var t = this;
        t.gridpanel = new SYNO.SDS.iSCSI.Host.Initiator({
            appWin: e.appWin,
            owner: t,
            parent: t,
            flex: 1
        });
        var i = {
            title: SYNO.SDS.iSCSI.Utils.T("san_host", "title_add_initiator"),
            layout: "fit",
            width: 640,
            height: 480,
            resizable: !1,
            items: [{
                xtype: "syno_panel",
                padding: "0px 20px",
                border: !1,
                layout: "vbox",
                layoutConfig: {
                    aligh: "stretch"
                },
                items: [{
                    xtype: "syno_displayfield",
                    value: SYNO.SDS.iSCSI.Utils.T("san_host", "desc_select_initiator")
                }, t.gridpanel]
            }],
            buttons: [{
                xtype: "syno_button",
                text: SYNO.SDS.iSCSI.Utils.T("common", "alt_cancel"),
                handler: t.onCancel,
                listeners: {
                    mouseover: function() {
                        this.mouseoverCancelBtn = !0
                    },
                    mouseout: function() {
                        this.mouseoverCancelBtn = !1
                    },
                    scope: t
                },
                scope: t
            }, {
                xtype: "syno_button",
                itemId: "apply",
                btnStyle: "blue",
                text: SYNO.SDS.iSCSI.Utils.T("common", "alt_apply"),
                handler: t.onSave,
                scope: t
            }]
        };
        t.callParent([Ext.apply(i, e)])
    },
    onOpen: function() {
        var e = this;
        e.callParent(arguments), e.initUnmappedTarget(), e.gridpanel.setMask()
    },
    onCancel: function() {
        this.close()
    },
    onSave: function() {
        var e = this,
            t = e.gridpanel.getSelectedInitiators().reduce(function(e, t) {
                return e.push({
                    initiator: t
                }), e
            }, []);
        e.parent.getStore().loadData(t, !0), e.parent.setMask(), e.close()
    },
    initUnmappedTarget: function() {
        var e = this;
        e.gridpanel.loadInitiatorWithMasking(e.protocol, e.alreadyAddedInitiators, e.host)
    },
    setNextEnable: function(e) {
        this.fbar.getComponent("apply").setDisabled(!e)
    }
}), Ext.define("SYNO.SDS.iSCSI.Host.InitiatorDisplay", {
    extend: "SYNO.ux.EditorGridPanel",
    constructor: function(e) {
        var t = this;
        t.owner = e.owner, t.host = e.host, t.protocol = e.protocol;
        var i = {
            title: SYNO.SDS.iSCSI.Utils.T("san_host", "initiator"),
            tbar: {
                defaultType: "syno_button",
                items: [{
                    itemId: "createBtn",
                    text: SYNO.SDS.iSCSI.Utils.T("common", "add"),
                    handler: t.onCreate,
                    scope: t
                }, {
                    itemId: "removeBtn",
                    text: SYNO.SDS.iSCSI.Utils.T("common", "remove"),
                    handler: t.onRemove,
                    disabled: !0,
                    scope: t
                }]
            },
            columns: [{
                itemId: "initiator",
                header: SYNO.SDS.iSCSI.Utils.T("san_host", "initiator"),
                dataIndex: "initiator",
                renderer: SYNO.SDS.iSCSI.Utils.htmlSelectingGridEncodeRender
            }],
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: !0,
                listeners: {
                    selectionchange: function(e) {
                        var t = e.getSelected();
                        this.getTopToolbar().getComponent("removeBtn").setDisabled(!t)
                    },
                    scope: t
                }
            }),
            store: new Ext.data.JsonStore({
                autoDestory: !0,
                idProperty: "initiator",
                fields: ["initiator"],
                sortInfo: {
                    field: "initiator",
                    direction: "ASC"
                }
            }),
            enableHdMenu: !1,
            enableColumnMove: !1,
            cls: "without-dirty-red-grid iscsi-remove-sort-icon",
            listeners: {
                activate: function() {
                    this.setMask()
                }
            }
        };
        t.callParent([Ext.apply(i, e)])
    },
    onCreate: function() {
        var e = this;
        new SYNO.SDS.iSCSI.Host.InitiatorEditWindow({
            appWin: e.appWin,
            owner: e.owner,
            alreadyAddedInitiators: e.getStore().data.keys,
            parent: e,
            host: e.host,
            protocol: e.protocol
        }).open()
    },
    onRemove: function() {
        var e = this;
        e.getStore().remove(e.getSelectionModel().getSelected()), e.setMask()
    },
    initEditProps: function(e, t) {
        var i = this;
        i.originalInitiators = t, i.getStore().loadData(t.map(function(e) {
            return {
                initiator: e
            }
        }))
    },
    getSelectedInitiators: function() {
        var e = [];
        return this.getStore().data.each(function(t) {
            e.push(t.get("initiator"))
        }), e
    },
    getOriginalInitiators: function() {
        return this.originalInitiators
    },
    setMask: function() {
        var e = this;
        e.getStore().getCount() ? e.body.unmask() : e.body.mask(SYNO.SDS.iSCSI.Utils.T("san_host", "desc_no_mapped_initiator"), "syno-ux-mask-info")
    }
}), Ext.define("SYNO.SDS.iSCSI.Host.PrivilegeDisplay", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner;
        var i = {
            title: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_permission"),
            layout: "vbox",
            items: [t.grid = new SYNO.SDS.iSCSI.Host.Privilege({
                appWin: t.appWin,
                owner: t.owner,
                width: 640,
                mode: "edit",
                flex: 1
            })],
            style: "padding-top: 0px",
            listeners: {
                activate: function() {
                    t.grid.setMask()
                }
            }
        };
        t.callParent([Ext.apply(i, e)])
    },
    initEditProps: function(e, t) {
        this.grid.initEditProps(e, t)
    },
    getLunPrivilege: function() {
        return this.grid.getCustomLunPrivilege()
    },
    getAllowAlltoCustomLuns: function() {
        return this.grid.getAllowAlltoCustomLuns()
    },
    isValid: function() {
        return this.grid.isValid()
    },
    getInvalidPrivileges: function() {
        return this.grid.getInvalidPrivileges()
    }
}), Ext.define("SYNO.SDS.iSCSI.Host.Edit", {
    extend: "SYNO.SDS.ModalWindow",
    isDataChanged: !1,
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.host = e.host, t.prop = new SYNO.SDS.iSCSI.Host.Property({
            appWin: t.appWin,
            owner: t,
            itemId: "prop",
            mode: "edit"
        }), t.initiator = new SYNO.SDS.iSCSI.Host.InitiatorDisplay({
            appWin: t.appWin,
            owner: t,
            itemId: "initiator",
            host: t.host.get("name"),
            protocol: t.host.get("protocol")
        }), t.privilege = new SYNO.SDS.iSCSI.Host.PrivilegeDisplay({
            appWin: t.appWin,
            itemId: "privilege",
            owner: t
        });
        var i = {
            title: SYNO.SDS.iSCSI.Utils.T("common", "alt_edit"),
            width: 680,
            height: 370,
            resizable: !1,
            layout: "fit",
            cls: "syno-app-iscsi",
            items: [{
                itemId: "main",
                xtype: "syno_tabpanel",
                activeTab: 0,
                deferredRender: !1,
                items: [t.prop, t.initiator, t.privilege]
            }],
            buttons: [{
                xtype: "syno_button",
                text: SYNO.SDS.iSCSI.Utils.T("common", "alt_cancel"),
                scope: this,
                handler: this.onCancel
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                text: SYNO.SDS.iSCSI.Utils.T("common", "save"),
                scope: this,
                handler: this.onSave
            }]
        };
        t.callParent([Ext.apply(i, e)])
    },
    onOpen: function() {
        var e = this;
        e.callParent(arguments), e.loadProp(), e.loadInitiator(), e.loadPrivilege()
    },
    loadProp: function() {
        var e = this,
            t = SYNO.SDS.iSCSI.Utils.HostOSType,
            i = Object.keys(t).reduce(function(e, i) {
                return e[t[i]] = i, e
            }, {});
        e.prop.setProps({
            name: e.host.get("name"),
            description: e.host.get("description"),
            operation_system: i[e.host.get("type")],
            protocol: e.host.get("protocol"),
            host_id: e.host.get("host_id")
        })
    },
    loadInitiator: function() {
        var e = this;
        e.initiator.initEditProps(e.host.get("protocol"), e.host.get("initiators")), e.originalInitiatorSetting = e.initiator.getSelectedInitiators()
    },
    loadPrivilege: function() {
        var e = this,
            t = e.host.get("acls").reduce(function(e, t) {
                return e[t.lun_uuid] = {
                    permission: t.permission
                }, e
            }, {});
        e.privilege.initEditProps(e.host.get("protocol"), t), e.originalPrivilege = e.privilege.getLunPrivilege()
    },
    onSave: function() {
        var e = this;
        return e.prop.isValid() ? e.privilege.isValid() ? 0 >= e.initiator.getSelectedInitiators().length ? (e.getComponent("main").activate("initiator"), void e.getMsgBox().alert(SYNO.SDS.iSCSI.Utils.T("sanmgr", "app_title"), SYNO.SDS.iSCSI.Utils.T("san_host", "err_initiator_empty"))) : 0 < e.privilege.getAllowAlltoCustomLuns().length ? (e.getComponent("main").activate("privilege"), void e.getMsgBox().confirm(SYNO.SDS.iSCSI.Utils.T("sanmgr", "app_title"), String.format(SYNO.SDS.iSCSI.Utils.T("san_host", "allow_all_to_custom"), e.privilege.getAllowAlltoCustomLuns().join("<br>")), function(t) {
            "yes" === t && e.applySettings()
        })) : void e.applySettings() : (e.getComponent("main").activate("privilege"), void e.getMsgBox().alert(SYNO.SDS.iSCSI.Utils.T("sanmgr", "app_title"), String.format(SYNO.SDS.iSCSI.Utils.T("san_host", "err_os_permission_conflict"), SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_permission"), e.privilege.getInvalidPrivileges().join("<br>")))) : void e.getComponent("main").activate("prop")
    },
    applySettings: function() {
        var e = this,
            t = [];
        e.isPropertyChange() && e.addPropertyAPI(t), e.isInitiatorChange() && e.addInitiatorAPI(t), e.isPrivilegeChange() && e.addPrivilegeAPI(t), e.setStatusBusy(), e.sendWebAPI({
            compound: {
                stopwhenerror: !0,
                mode: "sequential",
                params: t
            },
            callback: function(t, i) {
                if (e.clearStatusBusy(), !t || i.has_fail) return void e.getMsgBox().alert(SYNO.SDS.iSCSI.Utils.T("common", "app_title"), SYNO.SDS.iSCSI.Utils.T("san_host", "err_failed_edit_host"));
                e.isDataChanged = !0, e.close()
            },
            scope: e
        })
    },
    onCancel: function() {
        var e = this;
        if (e.isPropertyChange() || e.isInitiatorChange() || e.isPrivilegeChange()) return void this.confirmLostChangePromise({
            save: function() {
                this.onSave()
            },
            dontSave: function() {
                this.close()
            },
            cancel: function() {}
        }, this);
        e.close()
    },
    addPropertyAPI: function(e) {
        var t = this,
            i = t.prop.getProps(),
            n = SYNO.SDS.iSCSI.Utils.HostOSType;
        e.push({
            api: "SYNO.Core.ISCSI.Host",
            method: "set",
            params: {
                host_id: t.host.get("host_id").toString(),
                name: i.name,
                type: n[i.operation_system],
                description: i.description,
                protocol: i.protocol
            },
            version: 1
        })
    },
    addInitiatorAPI: function(e) {
        var t = this,
            i = t.initiator.getOriginalInitiators(),
            n = t.initiator.getSelectedInitiators(),
            s = [],
            a = [];
        i.forEach(function(e) {
            -1 === n.indexOf(e) && s.push(e)
        }), n.forEach(function(e) {
            -1 === i.indexOf(e) && a.push(e)
        }), a.length && e.push({
            api: "SYNO.Core.ISCSI.Host",
            method: "map_initiator",
            params: {
                host_id: t.host.get("host_id").toString(),
                initiator_ids: a
            },
            version: 1
        }), s.length && e.push({
            api: "SYNO.Core.ISCSI.Host",
            method: "unmap_initiator",
            params: {
                host_id: t.host.get("host_id").toString(),
                initiator_ids: s
            },
            version: 1
        })
    },
    addPrivilegeAPI: function(e) {
        var t = this,
            i = t.privilege.getLunPrivilege(),
            n = Object.keys(i).reduce(function(t, n) {
                return t.push({
                    lun_uuid: n,
                    permission: i[n].permission
                }), "rw" !== i[n].permission && e.push({
                    api: "SYNO.Core.ISCSI.LUN",
                    method: "acl_masks_add",
                    version: 1,
                    params: {
                        uuid: n,
                        acls: [{
                            iqn: "iqn.2000-01.com.synology:default.acl",
                            permission: "-"
                        }]
                    }
                }), t
            }, []);
        e.push({
            api: "SYNO.Core.ISCSI.Host",
            method: "lun_acl_masks_set",
            params: {
                uuid: t.host.get("uuid"),
                acls: n
            },
            version: 1
        })
    },
    isPropertyChange: function() {
        return this.prop.getForm().isDirty()
    },
    isInitiatorChange: function() {
        var e = this;
        return JSON.stringify(e.originalInitiatorSetting.sort()) !== JSON.stringify(e.initiator.getSelectedInitiators().sort())
    },
    isPrivilegeChange: function() {
        var e = this,
            t = e.privilege.getLunPrivilege(),
            i = !1;
        return JSON.stringify(Object.keys(e.originalPrivilege).sort()) !== JSON.stringify(Object.keys(t).sort()) ? i = !0 : Object.keys(t).forEach(function(n) {
            e.originalPrivilege[n].permission !== t[n].permission && (i = !0)
        }), i
    }
}), Ext.define("SYNO.SDS.iSCSI.Host.Overview", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = this;
        t.appWin = e.appWin;
        var i = {
            region: "center",
            colModel: t.getColumnModel(),
            store: t.createStore(),
            selModel: t.getSelModel(),
            enableHdMenu: !1,
            enableColumnMove: !1,
            viewConfig: {
                forceFit: !0,
                onLoad: Ext.emptyFn,
                listeners: {
                    beforerefresh: function(e) {
                        e.scrollTop = e.scroller.dom.scrollTop
                    },
                    refresh: function(e) {
                        e.scroller.dom.scrollTop = e.scrollTop
                    }
                }
            },
            cls: "iscsi-remove-sort-icon"
        };
        return Ext.apply(i, e), i
    },
    getColumnModel: function() {
        var e = this;
        return new Ext.grid.ColumnModel({
            columns: [{
                header: SYNO.SDS.iSCSI.Utils.T("san_host", "host_name"),
                dataIndex: "name",
                width: 200,
                renderer: SYNO.SDS.iSCSI.Utils.htmlEncodeRender
            }, {
                header: SYNO.SDS.iSCSI.Utils.T("san_host", "description"),
                dataIndex: "description",
                width: 300,
                renderer: SYNO.SDS.iSCSI.Utils.htmlEncodeRender
            }, {
                header: SYNO.SDS.iSCSI.Utils.T("san_host", "operation_system"),
                dataIndex: "type",
                width: 300,
                renderer: function(e) {
                    var t = SYNO.SDS.iSCSI.Utils.HostOSTypeInverse[e];
                    return SYNO.SDS.iSCSI.Utils.GetHostOSString(t)
                }
            }, {
                header: SYNO.SDS.iSCSI.Utils.T("san_host", "protocol"),
                dataIndex: "protocol",
                width: 200,
                hidden: !e.appWin.supportFC,
                renderer: function(e) {
                    return SYNO.SDS.iSCSI.Utils.GetHostProtocolString(e)
                }
            }, {
                header: SYNO.SDS.iSCSI.Utils.T("san_host", "initiator"),
                dataIndex: "initiators",
                width: 100,
                renderer: function(e) {
                    return e.length
                }
            }, {
                header: SYNO.SDS.iSCSI.Utils.T("san_lun", "lun"),
                dataIndex: "lun_number",
                width: 100
            }]
        })
    },
    createStore: function() {
        var e = ["name", "host_id", "description", "type", "protocol", "initiators", "uuid", "acls", "lun_number"];
        return new Ext.data.JsonStore({
            autoDestroy: !0,
            idProperty: "name",
            fields: e,
            sortInfo: {
                field: "name",
                direction: "ASC"
            }
        })
    },
    getSelModel: function() {
        var e = this;
        return new Ext.grid.RowSelectionModel({
            singleSelect: !0,
            listeners: {
                scope: e,
                rowselect: e.onRowselect
            }
        })
    },
    onRowselect: function(e) {
        this.ownerCt.detail.fireEvent("data_ready", e.getSelected())
    },
    loadHostInfo: function(e) {
        var t = this,
            i = t.ownerCt.appWin.iscsiLuns.getAll().filter(function(e) {
                return e.canBeShownAsAllowAll()
            });
        t.getStore().loadData(e.map(function(e) {
            return {
                name: e.name,
                host_id: e.host_id,
                uuid: e.uuid,
                acls: e.acls,
                description: e.description,
                type: e.type,
                protocol: e.protocol,
                initiators: e.initiator_ids,
                lun_number: i.filter(function(t) {
                    return e.protocol === t.get("mappingType")
                }).length
            }
        }))
    }
}), Ext.define("SYNO.SDS.iSCSI.Host.Detail", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = this;
        t.appWin = e.appWin;
        var i = {
            region: "south",
            split: !0,
            cls: "host-details-panel",
            collapseMode: "mini",
            height: 240,
            items: [{
                xtype: "syno_displayfield",
                id: t.hostName = Ext.id(),
                htmlEncode: !1
            }, {
                xtype: "syno_displayfield",
                cls: "host-details-initiators",
                id: t.initiators = Ext.id(),
                htmlEncode: !1
            }, {
                xtype: "syno_displayfield",
                value: "LUN"
            }, t.gridpanel = t.createGridpanel()],
            listeners: {
                scope: t,
                data_ready: t.onDataReady,
                resize: function() {
                    var e = t.appWin.getHeight() - 165;
                    e < t.getHeight() && (t.setHeight(e), t.appWin.doLayout())
                }
            }
        };
        return Ext.apply(i, e), i
    },
    createColumnModel: function() {
        return new Ext.grid.ColumnModel({
            columns: [{
                header: SYNO.SDS.iSCSI.Utils.T("san_lun", "lun"),
                dataIndex: "name",
                width: 150
            }, {
                header: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_permission"),
                dataIndex: "permission",
                width: 175,
                renderer: function(e) {
                    return SYNO.SDS.iSCSI.Utils.renderPermission(e)
                }
            }, {
                id: "statusCol",
                header: SYNO.SDS.iSCSI.Utils.T("common", "status"),
                dataIndex: "status",
                renderer: SYNO.SDS.iSCSI.Utils.ColumnTipRenderer
            }]
        })
    },
    createStore: function() {
        var e = [{
            name: "name",
            sortType: "asNaturalUCString"
        }, "permission", "status"];
        return new Ext.data.JsonStore({
            autoDestroy: !0,
            idProperty: "name",
            fields: e,
            sortInfo: {
                field: "name",
                direction: "ASC"
            }
        })
    },
    createGridpanel: function() {
        var e = this;
        return new SYNO.ux.GridPanel({
            xtype: "syno_gridpanel",
            store: this.createStore(),
            colModel: this.createColumnModel(),
            autoExpandColumn: "statusCol",
            enableHdMenu: !1,
            enableColumnMove: !1,
            viewConfig: {
                forceFit: !1
            },
            listeners: {
                resize: function() {
                    e.setMask()
                }
            },
            cls: "iscsi-remove-sort-icon"
        })
    },
    onDataReady: function(e) {
        var t = this;
        t.getComponent(t.hostName).setValue(String.format('<div class="host-details-title" ext:qtip="{0}">{0}</div>', e.get("name"))), t.getComponent(t.initiators).setValue('<div><dl><dt class="iscsi-grid-property-name" style="width:100px;">' + SYNO.SDS.iSCSI.Utils.T("san_host", "initiator") + '</dt><dt class="iscsi-grid-property-value" style="">' + e.data.initiators.join("<br>") + '</dt><div class="x-clear"></div></dl></div>');
        var i = {};
        e.get("acls").forEach(function(e) {
            i[e.lun_uuid] = e.permission
        });
        var n = t.ownerCt.owner.iscsiLuns.getAll().filter(function(t) {
            return t.canBeShownAsAllowAll() && e.get("protocol") === t.get("mappingType")
        }).reduce(function(e, n) {
            var s = "-";
            return "allow_all" === n.get("privilege") ? s = "rw" : i[n.get("uuid")] && (s = i[n.get("uuid")]), e.push({
                name: n.get("name"),
                permission: s,
                status: n.getSummaryStatus(t.appWin.volumes, t.appWin.pools, t.appWin.isLowCapacityWriteEnable())
            }), e
        }, []);
        t.gridpanel.setHeight(60 + 28 * n.length), t.gridpanel.store.loadData(n), t.setMask(), t.doLayout()
    },
    setMask: function() {
        var e = this;
        e.gridpanel.getStore().getCount() ? e.gridpanel.unmask() : (e.gridpanel.setHeight(140), e.gridpanel.mask(SYNO.SDS.iSCSI.Utils.T("lun", "no_mapped_lun"), "syno-ux-mask-info"))
    }
}), Ext.define("SYNO.SDS.iSCSI.Host.Main", {
    extend: "SYNO.SDS.SAN.CardsMainPanel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.panels = [t.emptyPage = new SYNO.SDS.SAN.Host.EmptyMain({
            appWin: t.appWin,
            owner: t.owner,
            itemId: "emptyPage"
        }), t.normalPage = new SYNO.SDS.iSCSI.Host.NormalMain({
            appWin: t.appWin,
            owner: t.owner,
            itemId: "normalPage"
        })];
        var i = {
            panels: t.panels
        };
        this.callParent([Ext.apply(i, e)])
    },
    onDataReady: function() {
        var e = this;
        e.owner.hosts.length ? e.getLayout().setActiveItem("normalPage") : e.getLayout().setActiveItem("emptyPage"), e.getLayout().activeItem.fireEvent("data_ready"), e.appWin.clearStatusBusy()
    }
}), Ext.define("SYNO.SDS.SAN.Host.EmptyMain", {
    extend: "SYNO.SDS.SAN.EmptyMainPanel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.normalMainLayout = new SYNO.SDS.iSCSI.Host.NormalMain({
            owner: t.owner,
            appWin: t.appWin
        }), t.callParent([e])
    },
    fillConfig: function(e) {
        var t = this,
            i = this.callParent([e]);
        return i.items.push({
            xtype: "label",
            text: SYNO.SDS.iSCSI.Utils.T("san_host", "desc_no_host"),
            cls: "iscsi-empty-text"
        }), i.items.push({
            xtype: "label",
            style: {
                padding: "10px 0px 0px"
            }
        }), i.items.push({
            xtype: "syno_button",
            text: SYNO.SDS.iSCSI.Utils.T("common", "add"),
            btnStyle: "blue",
            handler: t.onCreate,
            scope: t
        }), i.listeners = {
            data_ready: t.onDataReady,
            scope: t
        }, i
    },
    onCreate: function() {
        this.normalMainLayout.onCreate()
    },
    onDataReady: function() {
        this.normalMainLayout.processData()
    }
});
Ext.define("SYNO.SDS.iSCSI.Host.NormalMain", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.loaded = !1, this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = this,
            i = new Ext.Toolbar({
                defaultType: "syno_button",
                style: "border-bottom: 0px",
                items: [{
                    text: SYNO.SDS.iSCSI.Utils.T("common", "add"),
                    handler: t.onCreate,
                    scope: t
                }, {
                    text: SYNO.SDS.iSCSI.Utils.T("common", "alt_edit"),
                    id: "edit",
                    handler: t.onEdit,
                    scope: t
                }, {
                    text: SYNO.SDS.iSCSI.Utils.T("common", "remove"),
                    id: "remove",
                    handler: t.onDelete,
                    scope: t
                }]
            }),
            n = [t.overview = new SYNO.SDS.iSCSI.Host.Overview({
                appWin: t.appWin
            }), t.detail = new SYNO.SDS.iSCSI.Host.Detail({
                appWin: t.appWin
            })],
            s = {
                layout: "border",
                tbar: i,
                items: n,
                listeners: {
                    activate: t.onActivate,
                    data_ready: t.onDataReady,
                    resize: function() {
                        var e = t.getHeight() - 110;
                        e < t.detail.getHeight() && (t.detail.setHeight(e), t.appWin.doLayout())
                    },
                    scope: t
                }
            };
        return Ext.apply(s, e), s
    },
    onCreate: function() {
        this.openWindow("Create", {})
    },
    onEdit: function() {
        var e = this.overview.selModel.getSelected();
        this.openWindow("Edit", {
            host: e
        })
    },
    onDelete: function() {
        var e = this,
            t = e.overview.getSelectionModel().getSelected();
        if (t) {
            var i, n = e.appWin.hosts.some(function(e) {
                return t.get("uuid") === e.uuid && e.is_connected
            });
            i = n ? String.format(SYNO.SDS.iSCSI.Utils.T("san_host", "desc_delete_host_session"), t.get("name"), t.get("name")) : String.format(SYNO.SDS.iSCSI.Utils.T("san_host", "desc_delete_host"), t.get("name")), e.owner.getMsgBox().confirmDelete(SYNO.SDS.iSCSI.Utils.T("common", "remove"), i, function(i) {
                "yes" === i && e.doDelete(t.get("uuid"))
            }, e)
        }
    },
    doDelete: function(e) {
        var t = this;
        t.owner.setStatusBusy(), t.getHostDeletePromise(e).then(function() {
            t.appWin.restartPollTask()
        }, function() {
            SYNO.Debug("Failed to delete host."), t.appWin.restartPollTask()
        })
    },
    getHostDeletePromise: function(e) {
        return this.sendWebAPIPromise({
            api: "SYNO.Core.ISCSI.Host",
            method: "delete",
            params: {
                uuid: e
            },
            version: 1
        })
    },
    openWindow: function(e, t) {
        var i = this,
            n = new SYNO.SDS.iSCSI.Host[e](Ext.apply({
                appWin: i.appWin,
                owner: i.owner
            }, t));
        i.mon(n, "close", function() {
            Ext.isFunction(n.hideFromOwner) && n.hideFromOwner(), n.isDataChanged && (i.owner.setStatusBusy(), i.loaded = !1, i.appWin.fireEvent("poll_activate"))
        }, i, {
            single: !0
        }), n.open()
    },
    onActivate: function() {
        var e = this;
        e.loaded || e.appWin.setStatusBusy(), e.appWin.fireEvent("poll_activate")
    },
    onDataReady: function() {
        var e = this,
            t = e.owner.hosts;
        e.processData(), e.overview.loadHostInfo(t), e.loaded || (e.loaded = !0), e.appWin.clearStatusBusy();
        var i = e.getTopToolbar(),
            n = i.getComponent("edit"),
            s = i.getComponent("remove");
        e.detail.setMask(), e.detail.setVisible(!!t.length), e.doLayout(), n.setDisabled(!t.length), s.setDisabled(!t.length), t.length && !e.overview.getSelectionModel().getSelected() && e.overview.getSelectionModel().selectFirstRow()
    },
    processData: function() {
        var e = this;
        e.appWin.genLunMappingType(), e.appWin.genLunPrivilegeType(), e.appWin.genHostConnectedSessions()
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.Property", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        var t, i, n, s, a, o, r, l = this,
            S = this,
            d = [
                [!1, SYNO.SDS.iSCSI.Utils.T("common", "no")],
                [!0, SYNO.SDS.iSCSI.Utils.T("common", "yes")]
            ];
        S.vol_type_of_lun = e.vol_type_of_lun || "all", S.selectedVolumeType = "", S.appWin = e.appWin, S.owner = e.owner, S.mode = e.mode || "edit", S.lunType = e.lunType || "file", S.lun = null, S.isExtentBased = S.appWin.supportVAAI, S.volumes = S.appWin.volumes, S.isLocationCanEdit = !("edit" === S.mode && (S.owner.lun.isBlockLun() || S.owner.lun.isAdvancedLun() || S.owner.lun.hasReplicationTask)), o = {
            title: SYNO.SDS.iSCSI.Utils.T("common", "properties"),
            trackResetOnLoad: !0,
            labelWidth: 230,
            fieldWidth: 330,
            items: [{
                xtype: "syno_textfield",
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("common", "name"),
                vtype: "iscsilunname",
                maxlength: 128,
                allowBlank: !1,
                name: "name",
                validator: function(e) {
                    return e === this.originalValue || (!!S.appWin.isUniqueLunName(e) || SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_lun_name_exists"))
                }
            }, {
                xtype: "syno_textfield",
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("san_lun", "desc"),
                maxlength: 128,
                name: "description"
            }]
        }, t = {
            xtype: S.isLocationCanEdit ? "syno_message_combobox" : "syno_lun_displayfield",
            fieldLabel: SYNO.SDS.iSCSI.Utils.T("volume", "volume_raid_location"),
            name: "location",
            hiddenName: "location",
            itemId: "location",
            forceSelection: !0,
            displayField: "name",
            descriptionField: "desc",
            valueField: "path",
            allowBlank: !1,
            editable: !1,
            tpl: '<tpl for="."><div ext:qtip="{name}" class="x-combo-list-item" role="option" aria-label="{name}" id="{[Ext.id()]}" style="height: 52px"><div ext:qtip="{name}" class="sds-combo-list-item-name">{name}</div><div ext:qtip="{desc}" class="sds-combo-list-item-description">{desc}</div></div></tpl>',
            store: this.vol_store = new Ext.data.JsonStore({
                autoDestroy: !0,
                idProperty: "path",
                fields: ["id", {
                    name: "name",
                    sortType: "asNaturalUCString"
                }, "size_total", "size_free", "fs_type", "raid_type", "numId", "desc", "path"],
                listeners: {
                    load: function(e, t) {
                        e.sort("name", "ASC")
                    },
                    scope: this
                }
            }),
            validator: function(e) {
                var t = this.ownerCt.mode;
                if ("edit" !== t && "clone" !== t) return !0;
                var i = this.store.getById(this.getValue());
                if (i) {
                    var n = this.ownerCt.lun;
                    if ("edit" === t && n.get("location") === i.get("path") || n.get("allocated_size") <= i.get("size_free")) return !0
                }
                return SYNO.SDS.iSCSI.Utils.T("iscsimgr", "err_no_space")
            },
            listeners: {
                select: function(e, t) {
                    var i = S.getComponent("thin_provision");
                    if (S.selectedVolumeType = t.get("fs_type"), "syno_lun_displayfield" === this.xtype) return void this.setValue(t.data.name);
                    if (S.maxExpandSizeGB = SYNO.SDS.iSCSI.Utils.GetSizeGB(t.get("size_free"), 0), "clone" !== S.mode && "convert" !== S.mode || (i.setValue(S.lun.isThinProvisioningLun()), S.lunType = "btrfs" === S.selectedVolumeType ? "btrfs" : "file"), "pool" === S.vol_type_of_lun || "block" === S.lunType) {
                        var n = this.ownerCt.getComponent("size_panel");
                        return "create" === S.mode && n.get("size").setValue(S.maxExpandSizeGB), void("Single" === t.get("raid_type") ? (n.get("size").disable(), n.get("size_max").disable()) : (n.get("size").enable(), n.get("size_max").enable()))
                    }
                    this.ownerCt.getForm().isValid();
                    var s = i.getValue();
                    if (i.enable(), i.fireEvent("select", i, S.thin_provision_store.getAt(s ? 1 : 0), 0), "clone" === S.mode) {
                        var a = "btrfs" === S.selectedVolumeType;
                        if (S.displayfield_adv_features_ep.setVisible(!S.lun.isBtrfsLun() && !a), S.displayfield_adv_features_btrfs.setVisible(S.lun.isBtrfsLun() || a), !S.lun.isBtrfsLun()) {
                            var o = [];
                            a ? (o.push(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_adv_feature_write_same")), o.push(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_adv_feature_acw")), o.push(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_adv_feature_xcopy")), S.lun.isThinProvisioningLun() && o.push(SYNO.SDS.iSCSI.Utils.T("iscsilun", "snapshot")), S.lun.isEnableUnmap() && o.push(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "unmap_command")), S.getForm().setValues({
                                extent_based_display_only: o.join(", ")
                            })) : S.getForm().setValues({
                                extent_based_display_only: S.lun.getAdvFeatureDesc()
                            })
                        }
                    }
                }
            }
        }, i = {
            xtype: "syno_compositefield",
            itemId: "size_panel",
            width: 330,
            fieldLabel: String.format("{0} ({1})", SYNO.SDS.iSCSI.Utils.T("common", "size"), SYNO.SDS.iSCSI.Utils.T("common", "size_gb")),
            items: [{
                xtype: "syno_lun_displayfield",
                fieldLabel: String.format("{0} ({1})", SYNO.SDS.iSCSI.Utils.T("volume", "volume_totalsize"), SYNO.SDS.iSCSI.Utils.T("common", "size_gb")),
                name: "size",
                itemId: "size",
                width: 200
            }]
        }, n = {
            xtype: "clone" === S.mode || "convert" === S.mode ? "syno_lun_displayfield" : "syno_numberfield",
            fieldLabel: String.format("{0} ({1})", SYNO.SDS.iSCSI.Utils.T("volume", "volume_totalsize"), SYNO.SDS.iSCSI.Utils.T("common", "size_gb")),
            name: "size",
            itemId: "size",
            value: 1,
            allowBlank: !1,
            minValue: 1,
            ref: "sizeConfig",
            validator: function(e) {
                var t;
                if (!this.ownerCt) return "Failed to find ownerCt";
                t = this.ownerCt;
                var i = t.get("thin_provision").getValue(),
                    n = t.get("location").getValue(),
                    s = "ext4" === S.selectedVolumeType && t.checkbox_adv_legacy.getValue(),
                    a = s ? 10 : 1,
                    o = !1;
                if ("create" === t.mode && e < a) return !0;
                if (e < this.originalValue || e < a) return SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_size_too_small");
                if (i) {
                    if (e > 1024e3) return String.format(SYNO.SDS.iSCSI.Utils.T("volume", "volume_exceed_max_size_msg"), String.format("{0} GB", 1024e3));
                    if (s) {
                        var r = SYNO.SDS.Utils.StorageUtils.ISCSIVAAILUN_EP_SIZE(1024 * e * 1024 * 1024);
                        if (SYNO.SDS.iSCSI.Utils.GetSizeGB(r, 0) > S.maxExpandSizeGB) return SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_set_failed_space_not_enough")
                    }
                    return S.thinprovisioningWarning = !0, !0
                }
                return S.thinprovisioningWarning = !1, o = t.get("location").originalValue !== n, !(e - (o ? 0 : this.originalValue) > S.maxExpandSizeGB) || SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_set_failed_space_not_enough")
            }
        }, s = {
            xtype: "create" === S.mode ? "syno_combobox" : "syno_lun_displayfield",
            fieldLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "space_allocation_type"),
            name: "thin_provision",
            hiddenName: "thin_provision",
            itemId: "thin_provision",
            editable: !1,
            forceSelection: !0,
            allowBlank: "pool" === S.vol_type_of_lun,
            value: !1,
            tpl: '<tpl for="."><div ext:qtip="{display}" class="x-combo-list-item" role="option" aria-label="{' + this.displayField + '}" id="{[Ext.id()]}">{display}</div></tpl>',
            hidden: "pool" === S.vol_type_of_lun,
            store: this.thin_provision_store = new Ext.data.ArrayStore({
                autoDestroy: !0,
                fields: ["value", "display"],
                data: [
                    [!1, "create" === S.mode ? SYNO.SDS.iSCSI.Utils.T("iscsimgr", "iscsitrg_thick_provisioning_option") : SYNO.SDS.iSCSI.Utils.T("iscsimgr", "iscsitrg_thick_provisioning")],
                    [!0, "create" === S.mode ? SYNO.SDS.iSCSI.Utils.T("iscsimgr", "iscsitrg_thin_provisioning_option") : SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_thin_provisioning")]
                ]
            }),
            valueField: "value",
            displayField: "display",
            listeners: {
                select: function(e, t, i) {
                    if (this.ownerCt.getForm().isValid(), S.isExtentBased) {
                        var n = t.data.value;
                        "syno_lun_displayfield" === this.xtype && this.setValue(n);
                        var s = this.ownerCt.checkbox_adv_unmap,
                            a = this.ownerCt.checkbox_adv_legacy;
                        "btrfs" === S.selectedVolumeType ? "create" == S.mode && (n ? (s.enable(), s.show()) : s.hide(), a.hide(), s.setValue(!1)) : ("create" == S.mode && (n ? (a.show(), s.show(), a.setValue(!0), s.setValue(!1)) : (a.hide(), s.hide(), a.setValue(!1), s.setValue(!1))), "syno_numberfield" === this.ownerCt.getComponent("size").xtype && this.ownerCt.getComponent("size").setMinValue(n ? 10 : 1)), S.updatePage()
                    }
                }
            }
        };
        var c = {
                xtype: "syno_displayfield",
                name: "unmap_config_display_only",
                hidden: "create" === S.mode,
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "unmap_command")
            },
            p = {
                xtype: "syno_checkbox",
                name: "adv_legacy",
                itemId: "adv_legacy",
                ref: "checkbox_adv_legacy",
                hidden: !S.isExtentBased || "create" !== S.mode,
                hideLabel: !1,
                boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_adv_feature_legacy"),
                value: !1,
                store: d,
                listeners: {
                    check: function(e, t) {
                        var i = t ? 10 : 1,
                            n = this.ownerCt.getComponent("size");
                        n.getValue() < i && n.setValue(i), "syno_numberfield" === n.xtype && n.setMinValue(i), this.ownerCt.checkbox_adv_unmap.setDisabled(!t), this.ownerCt.checkbox_adv_unmap.setValue(!1)
                    },
                    hide: function() {
                        Ext.isFunction(l.sizeConfig.setMinValue) && l.sizeConfig.setMinValue(1)
                    }
                },
                isDirty: function() {
                    return !1
                }
            },
            u = {
                xtype: "syno_checkbox",
                name: "adv_unmap",
                itemId: "adv_unmap",
                hidden: !S.isExtentBased || "create" !== S.mode,
                boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "unmap_command"),
                hideLabel: !1,
                value: !1,
                store: d,
                ref: "checkbox_adv_unmap",
                isDirty: function() {
                    return !1
                },
                listeners: {
                    render: function(e) {
                        SYNO.ux.AddTip(e, SYNO.SDS.iSCSI.Utils.T("san_lun", "unmap_feature_tip"))
                    },
                    single: !0
                }
            },
            h = {
                xtype: "syno_displayfield",
                name: "extent_based_display_only_ep",
                hidden: !S.isExtentBased || S.appWin.isSDRRunning || "create" === S.mode,
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_adv_feature_legacy"),
                ref: "displayfield_adv_features_ep",
                value: ""
            };
        a = {
            xtype: "syno_displayfield",
            itemId: "extent_based_display_only",
            name: "extent_based_display_only",
            hidden: !S.isExtentBased || S.appWin.isSDRRunning || "create" === S.mode,
            fieldLabel: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_vaai"),
            ref: "displayfield_adv_features_btrfs",
            value: ""
        }, r = {
            xtype: "syno_checkbox",
            itemId: "delete_orig_lun_after_convert",
            name: "delete_orig_lun_after_convert",
            boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "iscsilun_convert_delete_orig_check"),
            checked: "convert" === S.mode
        }, o.items.push(t), "block" === S.lunType ? o.items.splice(2, 0, i) : ("edit" === S.mode ? o.items.splice(2, 0, n) : o.items.push(n), o.items.push(s), o.items.push(c), o.items.push(p), o.items.push(u), o.items.push(h), o.items.push(a), "convert" === S.mode && (o.items.push({
            xtype: "tbspacer",
            height: 16
        }), o.items.push(r))), S.callParent([Ext.apply(o, e)])
    },
    getField: function(e) {
        return this.getForm().findField(e)
    },
    loadLunData: function(e) {
        var t, i = this,
            n = SYNO.SDS.iSCSI.Utils,
            s = i.getForm(),
            a = e.get("location"),
            o = null;
        if (i.lun = e, "block" === this.lunType) {
            for (var r = this.appWin.pools, l = 0; l < r.length; l++)
                if (-1 < a.search(r[l].space_path)) {
                    "single" === r[l].raidType ? (i.getField("location").disable(), i.getField("size").disable(), i.getField("size").setValue(n.GetSizeGB(e.get("size"), 0))) : o = r[l].space_path;
                    break
                } t = o || e.get("location")
        } else t = e.get("location");
        var S;
        "convert" === i.mode ? (S = e.getDefaultAdvFeatureDesc(), e.isEnableUnmap() && (S += ", " + SYNO.SDS.iSCSI.Utils.T("iscsimgr", "unmap_command"))) : S = e.getAdvFeatureDesc(), s.setValues({
            name: e.get("name"),
            description: e.get("description"),
            location: t,
            size: n.GetSizeGB(e.get("size"), 0),
            extent_based_display_only: S,
            extent_based_display_only_ep: S,
            unmap_config_display_only: e.isEnableUnmap() ? SYNO.SDS.iSCSI.Utils.T("common", "enabled") : e.isThinProvisioningLun() ? SYNO.SDS.iSCSI.Utils.T("common", "disabled") : SYNO.SDS.iSCSI.Utils.T("common", "not_support")
        }), "edit" === i.mode && "block" !== i.lunType && (i.displayfield_adv_features_ep.setVisible(e.isEPLun()), i.displayfield_adv_features_btrfs.setVisible(e.isBtrfsLun()));
        var d = this.vol_store.getById(t);
        d ? (s.findField("location").fireEvent("select", s.findField("location"), d), this.maxExpandSizeGB = SYNO.SDS.iSCSI.Utils.GetSizeGB(d.get("size_free"), 0)) : s.findField("location").resetValue(), "block" === this.lunType ? this.maxExpandSizeGB += n.GetSizeGB(e.get("size"), 0) : d && s.findField("thin_provision").fireEvent("select", s.findField("thin_provision"), this.thin_provision_store.getAt(e.isThinProvisioningLun() ? 1 : 0), 0), e.isSinkLun() && i.getField("size").disable(), s.clearInvalid()
    },
    loadPools: function() {
        var e, t = this,
            i = [],
            n = SYNO.SDS.iSCSI.Utils;
        e = t.appWin.pools, Ext.each(e, function(e) {
            var s = parseInt(e.size.used, 10),
                a = parseInt(e.size.total, 10),
                o = "" === e.desc ? "&nbsp" : Ext.util.Format.htmlEncode(e.desc);
            !("single" === e.raidType && -1 != e.device_type.search("shr")) && ("edit" === t.mode || SYNO.SDS.iSCSI.Utils.ISCSITRG_UNIT_GB < a - s) && i.push({
                id: e.id,
                name: String.format("{0} ({1}: {2})", n.SpaceIDParser(e.id).str, SYNO.SDS.iSCSI.Utils.T("volume", "volume_freesize"), n.SizeRender(a - s)),
                desc: o,
                size_total: a,
                size_free: a - s,
                raid_type: "single" === e.raidType ? "Single" : "Multiple",
                path: e.space_path
            })
        }), this.vol_store.loadData(i, !1)
    },
    loadVolumes: function(e) {
        var t = this,
            i = SYNO.SDS.iSCSI.Utils;
        e || (e = t.volumes), t.vol_store.loadData(e.reduce(function(e, n) {
            var s = parseInt(n.size_free_byte, 10),
                a = n.fs_type,
                o = parseInt(n.volume_id, 10);
            return "all" !== t.vol_type_of_lun && t.vol_type_of_lun !== a ? e : 0 >= i.GetSizeGB(s, 0) || "crashed" === n.status || "read_only" === n.status || "deleting" === n.status ? e : "external" === n.container && "sata" === n.location ? e : (e.push({
                id: n.volume_id,
                name: String.format("{0} ({1}: {2} {3}) - {4}", n.display_name, SYNO.SDS.iSCSI.Utils.T("volume", "volume_freesize"), i.GetSizeGB(s, 0), SYNO.SDS.iSCSI.Utils.T("common", "size_gb"), a),
                size_total: parseInt(n.size_total_byte, 10),
                size_free: s,
                fs_type: a,
                numId: o,
                desc: String.format("{0}", Ext.util.Format.htmlEncode(n.description)),
                path: n.volume_path
            }), e)
        }, []), !1), 0 >= t.vol_store.getCount() && SYNO.Debug("no volume can create iSCSI LUN")
    },
    updatePage: function() {}
}), Ext.define("SYNO.SDS.iSCSI.LUN.Wizard.PropertyStep", {
    extend: "SYNO.SDS.iSCSI.LUN.Property",
    isAfterCreateTarget: !1,
    canCreateTarget: !1,
    volumes: null,
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.owner = e.owner, i.volume = e.volume;
        var n = {
            xtype: "syno_panel",
            hidden: !i.appWin.supportVAAI || i.appWin.isSDRRunning,
            items: [{
                cls: "iscsi-retention-descpanel",
                xtype: "syno_displayfield",
                htmlEncode: !1,
                value: String.format(SYNO.SDS.iSCSI.Utils.T("san_lun", "thick_provisioning_warning")),
                listeners: {
                    afterrender: function(e) {
                        var t = e.el.first("a");
                        t && i.mon(t, "click", function(e) {
                            e.preventDefault(), SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                                topic: "SYNO.SDS.iSCSI.Application:lun.html",
                                anchor: "terminologies_advanced_features"
                            }, !1)
                        })
                    }
                },
                isDirty: function() {
                    return !1
                }
            }]
        };
        t = {
            isAfterCreateTarget: e.isAfterCreateTarget,
            headline: SYNO.SDS.iSCSI.Utils.T("lun", "set_property_title"),
            bbar: n,
            listeners: {
                afterlayout: function() {
                    i.ownerCt.fitStepHeight && (i.body.setHeight(i.ownerCt.getHeight() - 130), i.ownerCt.fitStepHeight())
                }
            }
        }, i.callParent([Ext.apply(t, e)])
    },
    getProps: function() {
        var e = this.getForm().getFieldValues();
        return e.volumeType = this.selectedVolumeType, e
    },
    activate: function() {
        var e = this,
            t = e.getForm();
        if (!e.loaded)
            if (e.loaded = !0, t.findField("name").setValue(e.appWin.genNewLunName()), "pool" == e.vol_type_of_lun) e.loadPools(), t.findField("location").setValue(e.vol_store.getAt(0).get("path")), t.findField("location").fireEvent("select", t.findField("location"), e.vol_store.getAt(0), 0);
            else {
                if ("convert" == e.mode) {
                    e.loadVolumes(e.avail_dst_locations), e.loadLunData(e.lun);
                    var i = t.findField("name");
                    i.setValue(String.format("{0}-New", i.getValue()))
                } else e.loadVolumes(), e.addTip();
                t.findField("location").setValue(e.vol_store.getAt(0).get("path")), t.findField("location").fireEvent("select", t.findField("location"), e.vol_store.getAt(0), 0)
            }
    },
    getNext: function() {
        var e = this;
        if (!e.getForm().isValid()) return !1;
        if (!0 !== e.thinprovisioningWarning) return e.nextId;
        var t = this.vol_store.getById(this.getProps().location).get("size_free"),
            i = this.getProps().size * SYNO.SDS.iSCSI.Utils.ISCSITRG_UNIT_GB;
        if (!(i > t)) return e.nextId;
        var n = SYNO.SDS.iSCSI.Utils,
            s = String.format(n.T("iscsitrg", "iscsitrg_thin_provisioning_warning"), n.SizeRender(i), n.SizeRender(t), n.volumePathRenderer(this.getProps().location));
        return e.owner.getMsgBox().confirm(e.owner.title, s, function(t) {
            "yes" === t && e.owner.goNext(e.nextId)
        }), !1
    },
    summary: function(e) {
        var t = this.getProps(),
            i = this.getForm().findField("thin_provision").getValue(),
            n = this.vol_store.getById(t.location).get("name"),
            s = this.getForm().findField("delete_orig_lun_after_convert"),
            a = !!s && s.getValue(),
            o = this.isAfterCreateTarget ? function(t, i) {
                e.appendSub(t, i)
            } : function(t, i) {
                e.append(t, i)
            };
        this.isAfterCreateTarget ? e.append(SYNO.SDS.iSCSI.Utils.T("lun", "mapped_lun"), String.format("{0} ({1})", t.name, SYNO.SDS.iSCSI.Utils.T("common", "create"))) : o(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_name"), t.name), o(SYNO.SDS.iSCSI.Utils.T("san_lun", "desc"), t.description), o(SYNO.SDS.iSCSI.Utils.T("volume", "volume_raid_location"), n), o(SYNO.SDS.iSCSI.Utils.T("volume", "volume_totalsize"), String.format("{0} ({1})", t.size || this.maxExpandSizeGB, SYNO.SDS.iSCSI.Utils.T("common", "size_gb"))), o(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "space_allocation_type"), i ? SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_thin_provisioning") : SYNO.SDS.iSCSI.Utils.T("iscsimgr", "iscsitrg_thick_provisioning")), this.appWin.supportVAAI && this.appWin.supportVAAI && ("btrfs" == t.volumeType ? o(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "unmap_command"), t.adv_unmap ? SYNO.SDS.iSCSI.Utils.T("common", "enabled") : SYNO.SDS.iSCSI.Utils.T("common", "disabled")) : (o(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_adv_feature_legacy"), t.adv_legacy ? SYNO.SDS.iSCSI.Utils.T("common", "enabled") : SYNO.SDS.iSCSI.Utils.T("common", "disabled")), o(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "unmap_command"), t.adv_unmap ? SYNO.SDS.iSCSI.Utils.T("common", "enabled") : SYNO.SDS.iSCSI.Utils.T("common", "disabled")))), a && o(SYNO.SDS.iSCSI.Utils.T("pkgmgr", "other_information"), SYNO.SDS.iSCSI.Utils.T("iscsimgr", "iscsilun_convert_delete_orig_check"))
    },
    addTip: function() {
        SYNO.ux.AddTip(this.getForm().findField("thin_provision").getEl(), SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_thin_provisioning_notify"), !1, !1)
    },
    updatePage: function() {
        var e = this,
            t = e.getForm().findField("thin_provision").getValue();
        e.bottomToolbar.setVisible(!t)
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.Wizard.MappingStep", {
    extend: "Ext.form.FormPanel",
    luns: null,
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.map_to_iscsi_radio = new SYNO.ux.Radio({
            boxLabel: SYNO.SDS.iSCSI.Utils.T("san_lun", "map_iscsi"),
            name: "target_source",
            htmlEncode: !1,
            inputValue: "iscsi",
            checked: !0,
            listeners: {
                check: function(e, t) {
                    this.ownerCt.getComponent("mapped_target").setDisabled(!t)
                }
            }
        }), i.mapped_to_fc_radio = new SYNO.ux.Radio({
            boxLabel: SYNO.SDS.iSCSI.Utils.GetFCRadioString(i.appWin.hasFibreChannels()),
            name: "target_source",
            htmlEncode: !1,
            inputValue: "fc",
            disabled: !i.appWin.canMapFCTarget()
        }), t = {
            headline: SYNO.SDS.iSCSI.Utils.T("lun", "set_mapping"),
            items: [i.map_to_iscsi_radio, {
                xtype: "syno_displayfield",
                indent: 1,
                value: SYNO.SDS.iSCSI.Utils.T("san_lun", "choose_target_to_map")
            }, {
                xtype: "syno_combobox",
                name: "mapped_target",
                hiddenName: "mapped_target",
                itemId: "mapped_target",
                tpl: '<tpl for="."><div ext:qtip="{name}" class="x-combo-list-item">{name}</div></tpl>',
                displayField: "name",
                forceSelection: !0,
                hideLabel: !0,
                editable: !1,
                indent: 1,
                width: 250,
                store: i.target_store = new Ext.data.JsonStore({
                    autoDestroy: !0,
                    idProperty: "name",
                    fields: ["target_id", "name"],
                    listeners: {
                        load: function(e, t) {
                            this.onLoad(t)
                        },
                        scope: this
                    }
                }),
                validator: function(e) {
                    return !!e
                }
            }, i.mapped_to_fc_radio]
        }, i.callParent([Ext.apply(t, e)])
    },
    getTargetId: function() {
        var e = this.getForm().getValues().mapped_target;
        return this.target_store.getById(e).get("target_id")
    },
    getFCTargetIds: function() {
        return this.appWin.fcTargets.getAll().map(function(e) {
            return e.id
        })
    },
    getProtocol: function() {
        return this.getForm().getValues().target_source
    },
    activate: function() {
        var e = this;
        e.setGroup(), this.sendWebAPI({
            api: "SYNO.Core.ISCSI.Target",
            version: 1,
            method: "list",
            params: {
                additional: ["mapped_lun"]
            },
            callback: function(t, i) {
                var n = i.targets;
                n.sort(function(e, t) {
                    return SYNO.SDS.iSCSI.Utils.stringNaturalSort(e.name, t.name)
                }), n.sort(function(e, t) {
                    return e.is_default_target ? -1 : t.is_default_target ? 1 : 0
                }), e.target_store.loadData(n)
            }
        })
    },
    onLoad: function(e) {
        this.getForm().setValues({
            mapped_target: e[0] ? e[0].id : ""
        })
    },
    setGroup: function() {
        var e = this;
        e.radioGroupProtocol = new SYNO.ux.Utils.EnableCheckGroup(e.getForm(), "target_source", {
            iscsi: ["mapped_target"]
        })
    },
    getNext: function() {
        return !!this.getForm().isValid() && this.nextId
    },
    summary: function(e) {
        var t = this.getProtocol();
        "iscsi" === t ? e.append(SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_mapping"), String.format("iSCSI ({0})", this.getForm().getValues().mapped_target.toString())) : "fc" === t && e.append(SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_mapping"), "Fibre Channel")
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.Privilege", {
    extend: "SYNO.ux.EditorGridPanel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner;
        var i = {
            header: !1,
            border: !0,
            store: t.createStore(),
            colModel: new Ext.grid.ColumnModel({
                columns: [{
                    id: "host",
                    header: SYNO.SDS.iSCSI.Utils.T("san_host", "host"),
                    dataIndex: "host",
                    renderer: SYNO.SDS.iSCSI.Utils.htmlSelectingGridEncodeRender
                }, {
                    id: "os",
                    header: SYNO.SDS.iSCSI.Utils.T("san_host", "operation_system"),
                    dataIndex: "os",
                    renderer: function(e, t, i) {
                        var n = SYNO.SDS.iSCSI.Utils.GetHostOSString(e);
                        return SYNO.SDS.iSCSI.Utils.htmlSelectingGridEncodeRender(n, t, i)
                    }
                }, {
                    id: "protocol",
                    header: SYNO.SDS.iSCSI.Utils.T("san_host", "protocol"),
                    dataIndex: "protocol",
                    hidden: !t.appWin.supportFC,
                    renderer: function(e, t, i) {
                        var n = SYNO.SDS.iSCSI.Utils.GetHostProtocolString(e);
                        return SYNO.SDS.iSCSI.Utils.htmlSelectingGridEncodeRender(n, t, i)
                    }
                }, {
                    id: "permission",
                    header: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_permission"),
                    dataIndex: "permission",
                    editor: new Ext.grid.GridEditor(new SYNO.ux.ComboBox({
                        forceSelection: !0,
                        editable: !1,
                        allowBlank: !1,
                        lazyInit: !1,
                        store: SYNO.SDS.iSCSI.Utils.genRenderPermissionData(["rw", "r", "-"]),
                        listeners: {
                            focus: function() {
                                this.expand(), this.restrictHeight()
                            }
                        }
                    })),
                    renderer: function(e, t, i) {
                        return t.css += " syno-ux-triggerfield host-permission ", SYNO.SDS.iSCSI.Utils.permissionRendererInGridPanel(e, t, i)
                    }
                }],
                getCellEditor: function(e, i) {
                    return t.editRow = i, Ext.grid.ColumnModel.prototype.getCellEditor.call(this, e, i)
                }
            }),
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: !0,
                listeners: {
                    selectionchange: function(e) {
                        var t = e.getSelected(),
                            i = t && t.get("enabled");
                        this.getColumnModel().setEditable(3, i)
                    },
                    scope: t
                }
            }),
            enableHdMenu: !1,
            enableColumnMove: !1,
            autoScroll: !0,
            cls: "without-dirty-red-grid iscsi-remove-sort-icon",
            listeners: {
                resize: function() {
                    t.setMask()
                }
            }
        };
        t.callParent([Ext.apply(i, e)])
    },
    createStore: function() {
        var e = this;
        return new Ext.data.JsonStore({
            autoDestory: !0,
            idProperty: "host",
            fields: ["host", "uuid", "os", "protocol", "permission", "enabled"],
            sortInfo: {
                field: "host",
                direction: "ASC"
            },
            listeners: {
                load: function(t, i) {
                    this.setHeight(Math.max(180, 70 + 29 * i.length)), this.owner.setGridHeight && this.owner.setGridHeight(), this.owner.doLayout(), e.setMask()
                },
                scope: this
            }
        })
    },
    loadHosts2Store: function(e, t) {
        var i = this,
            n = i.getHostPrivilege(),
            s = t.filter(function(t) {
                return e === t.protocol
            }).map(function(e) {
                return {
                    host: e.name,
                    uuid: e.uuid,
                    os: SYNO.SDS.iSCSI.Utils.HostOSTypeInverse[e.type],
                    protocol: e.protocol,
                    permission: n.hasOwnProperty(e.uuid) ? n[e.uuid].permission : "-",
                    enabled: !0
                }
            });
        i.getStore().loadData(s)
    },
    loadHostFromWebAPI: function() {
        function e(e) {
            return t.apply(this, arguments)
        }
        var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
            var i, n;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        return i = this, e.prev = 1, e.next = 4, i.sendWebAPIPromise({
                            api: "SYNO.Core.ISCSI.Host",
                            method: "list",
                            version: 1,
                            params: {},
                            scope: i
                        });
                    case 4:
                        n = e.sent, i.loadHosts2Store(t, n.hosts), e.next = 11;
                        break;
                    case 8:
                        return e.prev = 8, e.t0 = e.catch(1), e.abrupt("return");
                    case 11:
                    case "end":
                        return e.stop()
                }
            }, e, this, [
                [1, 8]
            ])
        }));
        return e
    }(),
    loadHostFromMainPooling: function() {
        var e = this,
            t = e.owner.owner,
            i = t.getMappingType(),
            n = t.lun.get("uuid"),
            s = "allow_all" === e.owner.getLunDefaultPrivilege(),
            a = SYNO.SDS.iSCSI.Utils.HostOSTypeInverse,
            o = e.appWin.hosts.reduce(function(e, t) {
                if (i === t.protocol) {
                    var o = t.acls.find(function(e) {
                        return n === e.lun_uuid
                    });
                    e.push({
                        host: t.name,
                        uuid: t.uuid,
                        os: a[t.type],
                        protocol: t.protocol,
                        permission: s ? "rw" : o ? o.permission : "-",
                        enabled: !s
                    })
                }
                return e
            }, []);
        e.getStore().loadData(o)
    },
    getHostPrivilege: function() {
        var e = {};
        return this.getStore().each(function(t) {
            e[t.get("uuid")] = {
                host: t.get("host"),
                permission: t.get("permission")
            }
        }), e
    },
    setMask: function() {
        var e = this;
        e.getStore().getCount() ? e.body.unmask() : e.body.mask(SYNO.SDS.iSCSI.Utils.T("san_host", "desc_no_host"), "syno-ux-mask-info")
    },
    getWarningString: function(e) {
        var t = {
                none: {
                    category: "",
                    text: ""
                },
                multi_os: {
                    category: "error",
                    text: SYNO.SDS.iSCSI.Utils.T("san_lun", "err_multi_os")
                },
                multi_rw_non_cluster: {
                    category: "error",
                    text: SYNO.SDS.iSCSI.Utils.T("san_lun", "err_non_cluster_aware")
                },
                multi_rw_cluster: {
                    category: "warn",
                    text: SYNO.SDS.iSCSI.Utils.T("san_lun", "warn_cluster_aware")
                },
                no_any_permission: {
                    category: "warn",
                    text: SYNO.SDS.iSCSI.Utils.T("san_lun", "warn_no_any_permission")
                }
            },
            i = this,
            n = !0,
            s = 0,
            a = JSON.parse(JSON.stringify(i.appWin.hosts));
        return i.getStore().each(function(t) {
            var i = t.get("permission");
            switch (i) {
                case "-":
                    break;
                case "r":
                    n = !1;
                    break;
                case "rw":
                    n = !1, "others" === t.get("os") && s++;
                    break;
                default:
                    SYNO.Debug("Undefined permission!!!")
            }
            var o = a.find(function(e) {
                return t.get("uuid") === e.uuid
            });
            o || (o = {
                uuid: t.get("uuid"),
                type: SYNO.SDS.iSCSI.Utils.HostOSType[t.get("os")],
                acls: []
            }, a.push(o));
            var r = o.acls.find(function(t) {
                return e === t.lun_uuid
            });
            r ? r.permission = i : o.acls.push({
                lun_uuid: e,
                permission: i
            })
        }), SYNO.SDS.iSCSI.Utils.OSValidator(a) ? SYNO.SDS.iSCSI.Utils.PermissionValidator(a) ? n ? t.no_any_permission : 1 < s ? t.multi_rw_cluster : t.none : t.multi_rw_non_cluster : t.multi_os
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.Wizard.CreateHost", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.parent = e.parent, t.protocol = e.protocol, t.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = this;
        t.property_panel = new SYNO.SDS.iSCSI.Host.Wizard.PropertyStep({
            appWin: t.appWin,
            owner: t,
            parent: t,
            padding: "24px 40px 0px",
            mode: "create_in_lun_wizard"
        });
        var i = {
            width: 620,
            height: 500,
            layout: "fit",
            resizable: !1,
            title: SYNO.SDS.iSCSI.Utils.T("san_host", "create_title"),
            cls: "syno-app-iscsi",
            buttons: [{
                xtype: "syno_button",
                text: SYNO.SDS.iSCSI.Utils.T("common", "alt_cancel"),
                scope: t,
                handler: t.close,
                listeners: {
                    mouseover: function() {
                        t.mouseoverCancelBtn = !0
                    },
                    mouseout: function() {
                        t.mouseoverCancelBtn = !1
                    }
                }
            }, {
                xtype: "syno_button",
                itemId: "apply",
                btnStyle: "blue",
                text: SYNO.SDS.iSCSI.Utils.T("common", "apply"),
                scope: t,
                handler: t.onApply
            }],
            items: [t.property_panel]
        };
        return Ext.apply(i, e), i
    },
    onOpen: function() {
        this.property_panel.setProtocol(this.protocol), this.callParent(arguments)
    },
    getHostProps: function() {
        return this.property_panel.getProps()
    },
    getSelectedInitiators: function() {
        return this.property_panel.getSelectedInitiators()
    },
    setNextEnable: function(e) {
        this.fbar.getComponent("apply").setDisabled(!e)
    },
    onApply: function() {
        function e() {
            return t.apply(this, arguments)
        }
        var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t, i, n, s, a;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        if (t = this, t.property_panel.getForm().isValid()) {
                            e.next = 3;
                            break
                        }
                        return e.abrupt("return", !1);
                    case 3:
                        if (!(0 >= t.getSelectedInitiators().length)) {
                            e.next = 6;
                            break
                        }
                        return t.getMsgBox().alert(SYNO.SDS.iSCSI.Utils.T("common", "app_title"), SYNO.SDS.iSCSI.Utils.T("san_host", "err_initiator_empty")), e.abrupt("return", !1);
                    case 6:
                        return t.setStatusBusy({
                            text: SYNO.SDS.iSCSI.Utils.T("common", "saving")
                        }), e.prev = 7, e.next = 10, t.getCreateHostAPIPromise();
                    case 10:
                        n = e.sent, i = n.host_id, t.parent.host_list.loadHostFromWebAPI(t.protocol), e.next = 20;
                        break;
                    case 15:
                        e.prev = 15, e.t0 = e.catch(7), t.clearStatusBusy(), t.owner.getMsgBox().alert(SYNO.SDS.iSCSI.Utils.T("common", "app_title"), SYNO.SDS.iSCSI.Utils.T("san_host", "err_create_host")), t.close();
                    case 20:
                        if (s = n.uuid, a = t.getSelectedInitiators(), !a.length) {
                            e.next = 42;
                            break
                        }
                        return e.prev = 23, e.next = 26, t.getSetHostWebAPIPromise(i);
                    case 26:
                        n = e.sent, e.next = 42;
                        break;
                    case 29:
                        return e.prev = 29, e.t1 = e.catch(23), e.prev = 31, e.next = 34, t.getDeleteHostWebAPIPromise(s);
                    case 34:
                        e.next = 38;
                        break;
                    case 36:
                        e.prev = 36, e.t2 = e.catch(31);
                    case 38:
                        t.clearStatusBusy(), t.parent.host_list.loadHostFromWebAPI(t.protocol), t.owner.getMsgBox().alert(SYNO.SDS.iSCSI.Utils.T("common", "app_title"), SYNO.SDS.iSCSI.Utils.T("san_host", "err_map_initiator")), t.close();
                    case 42:
                        t.clearStatusBusy(), t.close();
                    case 44:
                    case "end":
                        return e.stop()
                }
            }, e, this, [
                [7, 15],
                [23, 29],
                [31, 36]
            ])
        }));
        return e
    }(),
    getCreateHostAPIPromise: function() {
        var e = this,
            t = e.getHostProps(),
            i = SYNO.SDS.iSCSI.Utils.HostOSType,
            n = {
                name: t.name,
                type: i[t.operation_system],
                protocol: t.protocol,
                description: t.description
            };
        return e.sendWebAPIPromise({
            api: "SYNO.Core.ISCSI.Host",
            method: "create",
            version: 1,
            params: n,
            scope: e
        })
    },
    getSetHostWebAPIPromise: function(e) {
        var t = this,
            i = t.getSelectedInitiators(),
            n = {
                host_id: e.toString(),
                initiator_ids: i
            };
        return t.sendWebAPIPromise({
            api: "SYNO.Core.ISCSI.Host",
            method: "map_initiator",
            version: 1,
            params: n
        })
    },
    getDeleteHostWebAPIPromise: function(e) {
        return this.sendWebAPIPromise({
            api: "SYNO.Core.ISCSI.Host",
            method: "delete",
            version: 1,
            params: {
                uuid: e
            }
        })
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.Wizard.HostMappingStep", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        var t = this,
            i = this;
        i.appWin = e.appWin, i.owner = e.owner, i.allow_all_radio = new SYNO.ux.Radio({
            boxLabel: SYNO.SDS.iSCSI.Utils.T("san_lun", "allow_all"),
            name: "permission_setting",
            itemId: "allow_all_radio",
            inputValue: "allow_all",
            checked: !0
        }), i.for_each_radio = new SYNO.ux.Radio({
            boxLabel: SYNO.SDS.iSCSI.Utils.T("san_lun", "for_each"),
            name: "permission_setting",
            itemId: "for_each_radio",
            inputValue: "for_each",
            listeners: {
                check: function(e, t) {
                    t ? (this.ownerCt.getComponent("add_new_host_btn").enable(), i.host_list.enable()) : (this.ownerCt.getComponent("add_new_host_btn").disable(), i.host_list.disable())
                }
            }
        }), i.host_list = new SYNO.SDS.iSCSI.LUN.Privilege({
            appWin: i.appWin,
            owner: i,
            itemId: "host_list_grid",
            disabled: !0
        }), i.grid_field = new SYNO.ux.CompositeField({
            hideLabel: !0,
            height: 180,
            indent: 1,
            items: [i.host_list]
        });
        var n = {
            headline: SYNO.SDS.iSCSI.Utils.T("san_lun", "title_set_privilege"),
            items: [{
                xtype: "syno_displayfield",
                htmlEncode: !1,
                value: String.format(SYNO.SDS.iSCSI.Utils.T("san_lun", "desc_set_permission"), '<a class="link-font" href="">', "</a>"),
                listeners: {
                    afterrender: function(e) {
                        var i = e.el.first("a");
                        i && t.mon(i, "click", function(e) {
                            e.preventDefault(), SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                                topic: "SYNO.SDS.iSCSI.Application:host.html"
                            }, !1)
                        })
                    }
                }
            }, i.allow_all_radio, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                indent: 1,
                style: "margin-bottom:8px",
                value: SYNO.SDS.iSCSI.Utils.T("san_lun", "desc_allow_all_permission")
            }, i.for_each_radio, {
                xtype: "syno_displayfield",
                indent: 1,
                style: "margin-bottom:8px",
                html: String.format(SYNO.SDS.iSCSI.Utils.T("san_lun", "desc_for_each_permission"), SYNO.SDS.iSCSI.Utils.T("san_lun", "add_new_host"))
            }, {
                xtype: "syno_button",
                itemId: "add_new_host_btn",
                text: SYNO.SDS.iSCSI.Utils.T("san_lun", "add_new_host"),
                indent: 1,
                style: "margin-bottom:8px",
                disabled: !0,
                handler: i.onCreateHost,
                scope: i
            }, i.grid_field],
            autoScroll: !0
        };
        i.callParent([Ext.apply(n, e)])
    },
    getNext: function() {
        var e = this;
        if ("allow_all" === e.getDefaultPrivilege()) return e.nextId;
        var t = e.host_list.getWarningString("00000000-0000-0000-0000-000000000000");
        return "error" === t.category ? (e.owner.getMsgBox().alert(SYNO.SDS.iSCSI.Utils.T("common", "app_title"), t.text), !1) : "warn" === t.category ? (e.owner.getMsgBox().confirm(SYNO.SDS.iSCSI.Utils.T("common", "app_title"), t.text, function(t) {
            "yes" === t && e.owner.goNext(e.nextId)
        }), !1) : e.nextId
    },
    setGridHeight: function() {
        this.grid_field.setHeight(this.host_list.getHeight())
    },
    onCreateHost: function() {
        var e = this;
        new SYNO.SDS.iSCSI.LUN.Wizard.CreateHost({
            appWin: e.appWin,
            owner: e.owner,
            parent: e,
            protocol: e.owner.getStep("mapping_step").getProtocol()
        }).open()
    },
    activate: function() {
        var e = this,
            t = e.owner.getStep("mapping_step").getProtocol();
        e.host_list.loadHosts2Store(t, e.appWin.hosts)
    },
    getDefaultPrivilege: function() {
        return this.getForm().getValues().permission_setting
    },
    getHostPrivilege: function() {
        return this.host_list.getHostPrivilege()
    },
    summary: function(e) {
        var t = this,
            i = this.getDefaultPrivilege();
        if ("allow_all" === i) e.append(SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_permission"), SYNO.SDS.iSCSI.Utils.T("san_lun", "allow_all"));
        else if ("for_each" === i) {
            var n = t.getHostPrivilege(),
                s = Object.keys(n).map(function(e) {
                    return String.format("{0} ({1})", n[e].host, SYNO.SDS.iSCSI.Utils.renderPermission(n[e].permission))
                });
            e.append(SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_permission"), s)
        }
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.Wizard.CreateSummaryStep", {
    extend: "SYNO.SDS.Wizard.SummaryStep",
    constructor: function(e) {
        var t = Ext.apply({
            headline: SYNO.SDS.iSCSI.Utils.T("ezinternet", "ezinternet_summary_title"),
            description: SYNO.SDS.iSCSI.Utils.T("wizcommon", "summary_descr"),
            viewConfig: {
                forceFit: !1
            },
            columns: [{
                width: 200,
                header: SYNO.SDS.iSCSI.Utils.T("status", "header_item"),
                dataIndex: "key",
                renderer: this.fieldRenderer
            }, {
                id: "value",
                autoExpand: !0,
                header: SYNO.SDS.iSCSI.Utils.T("status", "header_value"),
                dataIndex: "value",
                renderer: this.descRenderer,
                scope: this
            }],
            enableHdMenu: !1,
            enableColumnMove: !1,
            autoExpandColumn: "value",
            store: new SYNO.SDS.Wizard.SummaryStore
        }, e);
        SYNO.SDS.Wizard.SummaryStep.superclass.constructor.call(this, t)
    },
    getNext: function() {
        return this.owner.applySettings(null), !1
    },
    descRenderer: function(e, t, i, n, s, a) {
        var o = e;
        return ("string" == typeof o || o instanceof String) && (o = [o]), o = o.map(function(e) {
            return Ext.util.Format.htmlEncode(e)
        }).join("<br>"), t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(o) + '"', o
    },
    disableNextInDemoMode: !0
}), Ext.define("SYNO.SDS.iSCSI.LUN.FeasibilityCheck", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t, i = this;
        e.hasOwnProperty("params") && (i.parentParams = e.params), t = {
            listeners: {
                beforeclose: function() {
                    Ext.getCmp(this.parentNextBtnID).enable()
                }
            },
            title: i.title,
            width: 640,
            height: 350,
            resizable: !1,
            layout: "fit",
            items: [{
                xtype: "syno_formpanel",
                itemId: "main",
                border: !1,
                items: [{
                    xtype: "syno_displayfield",
                    value: "",
                    id: i.descID = Ext.id(),
                    itemId: "desc"
                }, i.grid = new SYNO.SDS.Wizard.SummaryStep({
                    layout: "fit",
                    height: 200
                })]
            }],
            buttons: [{
                xtype: "syno_button",
                text: SYNO.SDS.iSCSI.Utils.T("common", "cancel"),
                scope: i,
                handler: i.onCancel
            }, {
                xtype: "syno_button",
                btnStyle: "red",
                text: SYNO.SDS.iSCSI.Utils.T("common", "yes"),
                id: i.applyButtonID = Ext.id(),
                scope: i,
                handler: i.onConfirm
            }]
        }, i.callParent([Ext.apply(t, e)])
    },
    onOpen: function() {
        var e = this,
            t = e.grid.getStore(),
            i = !1,
            n = !1,
            s = "",
            a = e.feasCheckMsg,
            o = "";
        e.feasCheckMsg.hasOwnProperty("feasibility_soft") ? (i = !0, s = "feasibility_soft") : e.feasCheckMsg.hasOwnProperty("feasibility_hard") && (n = !0, s = "feasibility_hard"), e.hasOwnProperty("srcLun") && "" !== e.srcLun.name ? (o = e.srcLun.name, a.objType = "lun") : e.hasOwnProperty("target") && "" !== e.target.name && (o = e.target.name, a.objType = "target");
        var r = {};
        if (r.name = o, r.check_message = a[s], a[s] = [r], e.callParent(arguments), e.setStatusBusy({
                text: SYNO.SDS.iSCSI.Utils.T("common", "loading")
            }), !0 === n) Ext.getCmp(e.applyButtonID).disable(), Ext.getCmp(e.descID).setValue(SYNO.SDS.iSCSI.Utils.T("volume", "del_hard_check_fail"));
        else {
            if (!0 !== i) return void e.clearStatusBusy();
            Ext.getCmp(e.descID).setValue(SYNO.SDS.iSCSI.Utils.T("share", "edit_soft_check_fail"))
        }
        SYNO.SDS.iSCSI.Utils.fillGridByFeasMsg(a, t), e.clearStatusBusy()
    },
    onCancel: function() {
        this.close()
    },
    onConfirm: function() {
        var e = {};
        this.hasOwnProperty("parentParams") ? Ext.getCmp(this.parentWizardID).contFromSoftFeasCheck(this.parentParams) : Ext.getCmp(this.parentWizardID).contFromSoftFeasCheck(e), this.close()
    }
}), SYNO.SDS.iSCSI.LUN.GeneralFeasChkFailCallback = function(e, t, i, n, s, a) {
    if (e.hasOwnProperty("feasibility_soft") || e.hasOwnProperty("feasibility_hard")) {
        new SYNO.SDS.iSCSI.LUN.FeasibilityCheck({
            appWin: s.appWin,
            owner: s,
            title: "",
            parentParams: t,
            parentWizardID: s.getId(),
            parentNextBtnID: a || s.applyButtonID,
            srcLun: {
                name: i
            },
            target: {
                name: n
            },
            feasCheckMsg: e
        }).open()
    }
}, Ext.define("SYNO.SDS.iSCSI.LUN.WizardCreate", {
    extend: "SYNO.SDS.Wizard.ModalWindow",
    isDataChanged: !1,
    canCreate: !1,
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.owner = e.owner, t = {
            title: SYNO.SDS.iSCSI.Utils.T("lun", "create_title"),
            cls: "syno-app-iscsi",
            width: 680,
            height: 640,
            resizable: !1,
            border: !1,
            steps: []
        }, t.steps.push(new SYNO.SDS.iSCSI.LUN.Wizard.PropertyStep({
            appWin: i.appWin,
            mode: "create",
            itemId: "lun_property_step",
            nextId: "mapping_step"
        })), t.steps.push(new SYNO.SDS.iSCSI.LUN.Wizard.MappingStep({
            appWin: i.appWin,
            itemId: "mapping_step",
            nextId: "host_prop"
        })), t.steps.push(new SYNO.SDS.iSCSI.Target.Wizard.PropertyStep({
            appWin: i.appWin,
            itemId: "target_prop",
            nextId: "host_prop"
        })), t.steps.push(new SYNO.SDS.iSCSI.LUN.Wizard.HostMappingStep({
            appWin: i.appWin,
            owner: i,
            itemId: "host_prop",
            nextId: "summary"
        })), t.steps.push(new SYNO.SDS.iSCSI.LUN.Wizard.CreateSummaryStep({
            appWin: i.appWin,
            itemId: "summary",
            nextId: null
        })), i.callParent([Ext.apply(t, e)])
    },
    getLunType: function() {
        if (!this.appWin.supportBtrfsLun) return "file";
        if (this.appWin.isVDSM || this.appWin.isSDRRunning) return "btrfs";
        throw Error("wrong flow control: get lun type")
    },
    getTargetInfo: function() {
        if (!this.inHistory("target_prop")) throw Error("wrong flow control: get target info");
        return this.getStep("target_prop").getForm().getValues()
    },
    getMappedType: function() {
        if (!this.inHistory("mapping_step")) throw Error("wrong flow control: get mapping info");
        return this.getStep("mapping_step").getProtocol()
    },
    applySettings: function() {
        function e(e) {
            return t.apply(this, arguments)
        }
        var t = _asyncToGenerator(regeneratorRuntime.mark(function e(t) {
            var i, n, s, a, o, r, l, S, d, c, p, u, h, m, g, _, f, v, y, C, I, D, N, x = this;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        return n = [], s = !1, a = !0, o = !0, r = [], l = [], S = !0, d = !1, c = {}, p = {}, u = this.getStep("lun_property_step"), h = this.getStep("host_prop").getDefaultPrivilege(), m = this.getStep("host_prop").getHostPrivilege(), i = u.getProps(), p.name = i.name, p.description = i.description, p.location = i.location, i.hasOwnProperty("size") && (p.size = parseInt(i.size, 10) * SYNO.SDS.iSCSI.Utils.ISCSITRG_UNIT_GB), "btrfs" === i.volumeType ? i.thin_provision ? (p.type = "BLUN", s = !0) : p.type = "BLUN_THICK" : "ext4" === i.volumeType && (i.adv_legacy ? (p.type = "ADV", s = !0) : (p.type = i.thin_provision ? "THIN" : "FILE", a = !1, o = !1)), g = u.getField("adv_unmap").getValue(), p.dev_attribs = [{
                            dev_attrib: "emulate_tpws",
                            enable: a ? 1 : 0
                        }, {
                            dev_attrib: "emulate_caw",
                            enable: 1
                        }, {
                            dev_attrib: "emulate_3pc",
                            enable: o ? 1 : 0
                        }, {
                            dev_attrib: "emulate_tpu",
                            enable: g ? 1 : 0
                        }, {
                            dev_attrib: "can_snapshot",
                            enable: s ? 1 : 0
                        }], n.push({
                            api: "SYNO.Core.ISCSI.LUN",
                            method: "create",
                            version: 1,
                            params: p
                        }), _ = this.getMappedType(), c.target_ids = [], "iscsi" === _ ? c.target_ids.push(this.getStep("mapping_step").getTargetId()) : "fc" === _ && (c.target_ids = this.getStep("mapping_step").getFCTargetIds()), "iscsi" === _ ? l.push({
                            api: "SYNO.Core.ISCSI.LUN",
                            method: "map_target",
                            version: 1,
                            params: c
                        }) : "fc" === _ && l.push({
                            api: "SYNO.Core.ISCSI.LUN",
                            method: "map_fctarget",
                            version: 1,
                            params: c
                        }), null !== t && (n = t), n.forEach(function(e) {
                            var t = JSON.parse(JSON.stringify(e));
                            t.method = "create_feasibility_check", r.push(t)
                        }), this.getButton("next").disable(), this.setStatusBusy({
                            text: SYNO.SDS.iSCSI.Utils.T("common", "saving")
                        }), e.prev = 30, e.next = 33, this.getFeasibilityCheckWebAPIPromise(r);
                    case 33:
                        f = e.sent, e.next = 40;
                        break;
                    case 36:
                        return e.prev = 36, e.t0 = e.catch(30), this.getMsgBox().alert(SYNO.SDS.iSCSI.Utils.T("error", "error_subject"), SYNO.SDS.iSCSI.Utils.T("error", "error_subject")), e.abrupt("return");
                    case 40:
                        if (!f.has_fail) {
                            e.next = 62;
                            break
                        }
                        this.clearStatusBusy(), v = 0;
                    case 43:
                        if (!(v < f.result.length)) {
                            e.next = 61;
                            break
                        }
                        if (f.result[v].success) {
                            e.next = 58;
                            break
                        }
                        if (y = void 0, C = "", I = "", n[v].params.is_soft_feas_ignored = !0, !f.result[v].hasOwnProperty("error") || !f.result[v].error.hasOwnProperty("errors")) {
                            e.next = 55;
                            break
                        }
                        if (y = f.result[v].error.errors, "SYNO.Core.ISCSI.Target" === n[v].api ? I = n[v].params.name : "SYNO.Core.ISCSI.LUN" === n[v].api && (C = n[v].params.name), !y.hasOwnProperty("feasibility_hard") && !y.hasOwnProperty("feasibility_soft")) {
                            e.next = 55;
                            break
                        }
                        return SYNO.SDS.iSCSI.LUN.GeneralFeasChkFailCallback(y, n, C, I, this, this.getButton("next").getId()), e.abrupt("return");
                    case 55:
                        return SYNO.SDS.iSCSI.Utils.HARemoteCheckErrParsing(f.result[v].error), SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(this, f.result[v].error), e.abrupt("return");
                    case 58:
                        v++, e.next = 43;
                        break;
                    case 61:
                        return e.abrupt("return");
                    case 62:
                        return setTimeout(function() {
                            x.clearStatusBusy(), x.close(), x.appWin.fireEvent("poll_activate")
                        }, 5e3), e.next = 65, this.getCreateWebAPIPromise(n);
                    case 65:
                        if (f = e.sent, !f.has_fail) {
                            e.next = 77;
                            break
                        }
                        D = 0;
                    case 68:
                        if (!(D < f.result.length)) {
                            e.next = 76;
                            break
                        }
                        if (f.result[D].success) {
                            e.next = 73;
                            break
                        }
                        return SYNO.SDS.iSCSI.Utils.HARemoteCheckErrParsing(f.result[D].error), SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(this, f.result[D].error), e.abrupt("return");
                    case 73:
                        D++, e.next = 68;
                        break;
                    case 76:
                        return e.abrupt("return");
                    case 77:
                        if (N = f.result[0].data.uuid, S && f.result[0] && f.result[0].success && f.result[0].data && (c.uuid = N), d && f.result[1] && f.result[1].success && f.result[1].data && c.target_ids.push(f.result[1].data.target_id.toString()), "for_each" !== h) {
                            e.next = 85;
                            break
                        }
                        return e.next = 83, this.getHostWebAPIPromise(N, m);
                    case 83:
                        f = e.sent, f.has_fail && this.appWin.getMsgBox().alert(SYNO.SDS.iSCSI.Utils.T("common", "app_title"), SYNO.SDS.iSCSI.Utils.T("san_lun", "err_set_privilege"));
                    case 85:
                        return e.next = 87, this.getTargetWebAPIPromise(l);
                    case 87:
                        f = e.sent, f.str ? this.appWin.getMsgBox().alert(this.title, f.str, this.close, this) : f.has_fail ? this.appWin.getMsgBox().alert(SYNO.SDS.iSCSI.Utils.T("common", "app_title"), SYNO.SDS.iSCSI.Utils.T("san_lun", "err_map_target")) : this.isDataChanged = !0;
                    case 89:
                    case "end":
                        return e.stop()
                }
            }, e, this, [
                [30, 36]
            ])
        }));
        return e
    }(),
    getFeasibilityCheckWebAPIPromise: function(e) {
        return this.sendWebAPIPromise({
            compound: {
                stopwhenerror: !1,
                mode: "sequential",
                params: e
            },
            scope: this
        })
    },
    getCreateWebAPIPromise: function(e) {
        return this.sendWebAPIPromise({
            timeout: 6e5,
            compound: {
                stopwhenerror: !0,
                mode: "sequential",
                params: e
            },
            scope: this
        })
    },
    getHostWebAPIPromise: function(e, t) {
        var i = this,
            n = [{
                api: "SYNO.Core.ISCSI.LUN",
                method: "acl_masks_set",
                version: 1,
                params: {
                    uuid: e,
                    acls: [{
                        iqn: "iqn.2000-01.com.synology:default.acl",
                        permission: "-"
                    }]
                }
            }],
            s = {
                uuid: e,
                acls: []
            };
        return Object.keys(t).forEach(function(e) {
            "-" !== t[e].permission && s.acls.push({
                host_uuid: e,
                permission: t[e].permission
            })
        }), n.push({
            api: "SYNO.Core.ISCSI.LUN",
            method: "host_acl_masks_set",
            version: 1,
            params: s
        }), i.sendWebAPIPromise({
            compound: {
                stopwhenerror: !0,
                mode: "sequential",
                params: n
            },
            scope: i
        })
    },
    getTargetWebAPIPromise: function(e) {
        return this.sendWebAPIPromise({
            compound: {
                stopwhenerror: !0,
                mode: "sequential",
                params: e
            },
            scope: this
        })
    },
    contFromSoftFeasCheck: function(e) {
        this.applySettings(e)
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.Delete", {
    extend: "SYNO.SDS.ModalWindow",
    isDataChanged: !1,
    target: null,
    mapped_luns: null,
    task_luns: [],
    lunbkp_tasks: [],
    constructor: function(e) {
        var t, i = this;
        i.ignoreSoftFeasibility = !1, i.isDataChanged = !1, i.task_luns = "", i.lunbkp_tasks = "", i.appWin = e.appWin, i.owner = e.owner, i.luns = e.luns, t = {
            title: SYNO.SDS.iSCSI.Utils.T("lun", "remove_title"),
            width: 640,
            height: 350,
            resizable: !1,
            layout: "fit",
            items: [{
                xtype: "form",
                itemId: "main",
                border: !1,
                items: [{
                    xtype: "syno_displayfield",
                    htmlEncode: !1,
                    value: "",
                    id: i.descID = Ext.id(),
                    itemId: "desc"
                }, i.grid = new SYNO.SDS.Wizard.SummaryStep({
                    layout: "fit",
                    height: 200,
                    style: {
                        paddingTop: "8px"
                    }
                })]
            }],
            buttons: [{
                xtype: "syno_button",
                text: SYNO.SDS.iSCSI.Utils.T("common", "alt_cancel"),
                scope: i,
                handler: i.onCancel
            }, {
                xtype: "syno_button",
                btnStyle: "red",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                text: SYNO.SDS.iSCSI.Utils.T("common", "remove"),
                id: i.applyButtonID = Ext.id(),
                scope: i,
                handler: i.onDelete
            }]
        }, i.callParent([Ext.apply(t, e)])
    },
    onOpen: function() {
        this.callParent(arguments), this.loadData("")
    },
    loadData: function(e) {
        var t = this,
            i = t.grid.getStore(),
            n = {},
            s = !1;
        n.uuids = [], n.uuid = "", n.uuids = this.luns.map(function(e) {
            return e.get("uuid")
        }), n.feasibility_precheck = !0, Ext.each(this.luns, function(e) {
            if (e.isAdvancedLun()) return s = !0, !1
        }), this.setStatusBusy({
            text: SYNO.SDS.iSCSI.Utils.T("common", "saving")
        }), this.sendWebAPI({
            api: "SYNO.Core.ISCSI.LUN",
            method: "delete",
            version: 1,
            params: n,
            callback: function(e, a) {
                if (this.clearStatusBusy(), !e) {
                    if (a.hasOwnProperty("errors")) {
                        var o = a.errors;
                        if (o.hasOwnProperty("feasibility_hard") || o.hasOwnProperty("feasibility_soft")) return this.feasPreCheckCallback(o, n), void(this.ignoreSoftFeasibility = !0)
                    }
                    return void SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(this, a)
                }
                i.append(SYNO.SDS.iSCSI.Utils.T("lun", "lun"), t.genLunsStr(t.luns));
                var r = t.genFlashCacheStr(t.luns);
                r && i.append(SYNO.SDS.iSCSI.Utils.T("volume", "ssd_cache"), r), s ? Ext.getCmp(t.descID).setValue(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_delete_adv_desc")) : Ext.getCmp(t.descID).setValue(SYNO.SDS.iSCSI.Utils.T("volume", "volume_delete_summary_desc"))
            },
            scope: this
        })
    },
    genLunsStr: function(e) {
        return e.map(function(e) {
            return e.get("name")
        }).join(", ")
    },
    genFlashCacheStr: function(e) {
        return e.filter(function(e) {
            return "no_cache" !== e.get("flashcache_status")
        }).map(function(e) {
            return String.format("{0} {1}", SYNO.SDS.iSCSI.Utils.T("volume", "ssd_cache"), e.get("flashcache_id"))
        }).join(", ")
    },
    onDelete: function() {
        var e = this,
            t = SYNO.SDS.iSCSI.Utils.T("iscsilun", "iscsilun_remove_cinder_lun_warning"),
            i = {
                yes: {
                    text: SYNO.SDS.iSCSI.Utils.T("common", "remove"),
                    btnStyle: "red"
                },
                no: {
                    text: SYNO.SDS.iSCSI.Utils.T("common", "cancel")
                }
            };
        this.luns.some(function(e) {
            return e.isLunOwnedByCinder()
        }) ? this.getMsgBox().confirmDelete(this.title, t, function(t) {
            "yes" == t && SYNO.SDS.Utils.PasswordConfirmDialog.openDialog(e, e.onSave)
        }, this, i) : SYNO.SDS.Utils.PasswordConfirmDialog.openDialog(e, e.onSave)
    },
    onSave: function() {
        var e = {};
        e.uuids = [], e.uuid = "", e.uuids = this.luns.map(function(e) {
            return e.get("uuid")
        }), this.apply(e)
    },
    onCancel: function() {
        this.close()
    },
    apply: function(e) {
        e.is_soft_feas_ignored = this.ignoreSoftFeasibility, this.setStatusBusy({
            text: SYNO.SDS.iSCSI.Utils.T("common", "saving")
        }), this.sendWebAPI({
            api: "SYNO.Core.ISCSI.LUN",
            method: "delete",
            version: 1,
            params: e,
            callback: function(e, t) {
                if (this.clearStatusBusy(), !e) return void SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(this, t);
                this.isDataChanged = !0, this.close()
            },
            scope: this
        })
    },
    contFromSoftFeasCheck: function(e) {
        this.ignoreSoftFeasibility = !0, this.apply(e)
    },
    feasPreCheckCallback: function(e, t) {
        var i = !1,
            n = !1,
            s = this,
            a = s.grid.getStore(),
            o = "";
        e.hasOwnProperty("feasibility_soft") ? (i = !0, o = "feasibility_soft") : e.hasOwnProperty("feasibility_hard") && (n = !0, o = "feasibility_hard");
        var r = e;
        if (r.objType = "lun", t.hasOwnProperty("name")) {
            var l = {};
            l.name = t.name, l.check_message = r[o], r[o] = [l]
        }
        if (SYNO.SDS.iSCSI.Utils.fillGridByFeasMsg(r, a), !0 === n) Ext.getCmp(s.applyButtonID).disable(), Ext.getCmp(s.descID).setValue(SYNO.SDS.iSCSI.Utils.T("volume", "del_hard_check_fail"));
        else {
            if (!0 !== i) return void s.clearStatusBusy();
            Ext.getCmp(s.descID).setValue(SYNO.SDS.iSCSI.Utils.T("volume", "del_soft_check_fail"))
        }
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.Mapping", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner;
        var i = new SYNO.ux.EnableColumn({
            dataIndex: "enabled",
            width: 40,
            align: "center",
            bindRowClick: !0
        });
        t.iscsi_radio = new SYNO.ux.Radio({
            boxLabel: SYNO.SDS.iSCSI.Utils.T("san_lun", "map_iscsi"),
            name: "target_type",
            inputValue: "iscsi"
        }), t.fc_radio = new SYNO.ux.Radio({
            boxLabel: SYNO.SDS.iSCSI.Utils.GetFCRadioString(t.appWin.hasFibreChannels()),
            name: "target_type",
            inputValue: "fc",
            disabled: !t.appWin.canMapFCTarget()
        }), t.radiogroup = new Ext.form.RadioGroup({
            hideLabel: !0,
            columns: 1,
            vertical: !0,
            items: [t.fc_radio, t.iscsi_radio],
            hidden: !t.appWin.supportFC,
            listeners: {
                change: function(e, t) {
                    this.getComponent("iscsi_grid").setDisabled("iscsi" !== t.value), this.owner.privilege.fireEvent("changeTargetType")
                },
                scope: t
            }
        }), t.gridpanel = new SYNO.ux.GridPanel({
            itemId: "iscsi_grid",
            disabled: !0,
            plugins: i,
            columns: [i, {
                id: "name",
                header: SYNO.SDS.iSCSI.Utils.T("common", "name"),
                dataIndex: "name",
                align: "left",
                width: 120,
                sortable: !0,
                renderer: null
            }, {
                id: "iqn",
                header: "IQN",
                dataIndex: "iqn",
                align: "left",
                width: 200,
                sortable: !0,
                renderer: SYNO.SDS.iSCSI.Utils.TipRenderer
            }],
            store: new Ext.data.JsonStore({
                autoDestroy: !0,
                idProperty: "id",
                fields: ["id", "iqn", "enabled", {
                    name: "name",
                    sortType: "asNaturalUCString"
                }],
                sortInfo: {
                    field: "name",
                    direction: "ASC"
                },
                listeners: {
                    load: function(e, t) {
                        this.setHeight(50 + 28 * t.length)
                    },
                    scope: t
                }
            }),
            enableHdMenu: !1,
            autoExpandColumn: "name",
            cls: "without-dirty-red-grid"
        });
        var n = {
            title: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_mapping"),
            padding: "0px",
            items: [t.radiogroup, t.gridpanel]
        };
        t.callParent([Ext.apply(n, e)])
    },
    initSetting: function(e) {
        var t = this,
            i = t.owner.lun.get("uuid");
        t.originalMappingType = t.appWin.iscsiLuns.getById(i).get("mappingType"), t.getForm().setValues({
            target_type: t.originalMappingType
        }), t.gridpanel.setDisabled(!e.length || "iscsi" !== t.originalMappingType), t.gridpanel.getStore().loadData(e), t.gridpanel.getStore().commitChanges(), t.originalMappingTargets = e.reduce(function(e, t) {
            return t.enabled && e.push(t.id), e
        }, []), t.loaded = !0
    },
    getOriginalMappingType: function() {
        return this.originalMappingType
    },
    getMappingType: function() {
        return this.getForm().getValues().target_type
    },
    getOriginalMappingTargets: function() {
        return this.originalMappingTargets
    },
    getMappingTargets: function() {
        return this.gridpanel.getStore().data.items.reduce(function(e, t) {
            return t.get("enabled") && e.push(t.get("id")), e
        }, [])
    },
    getTargetStore: function() {
        return this.gridpanel.getStore()
    },
    isDirty: function() {
        var e = this;
        return !!e.loaded && (e.getMappingType() !== e.getOriginalMappingType() || "iscsi" === e.getMappingType() && 0 < e.gridpanel.getStore().getModifiedRecords().length)
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.EditPrivilegeTab", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        var t = this,
            i = this;
        i.appWin = e.appWin, i.owner = e.owner, i.descriptions = {
            allow_all: SYNO.SDS.iSCSI.Utils.T("san_lun", "desc_allow_all"),
            for_each: SYNO.SDS.iSCSI.Utils.T("san_lun", "desc_for_each")
        };
        var n = [{
                xtype: "syno_displayfield",
                htmlEncode: !1,
                value: String.format(SYNO.SDS.iSCSI.Utils.T("san_lun", "desc_set_permission"), '<a class="link-font" href="">', "</a>"),
                listeners: {
                    afterrender: function(e) {
                        var i = e.el.first("a");
                        i && t.mon(i, "click", function(e) {
                            e.preventDefault(), SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                                topic: "SYNO.SDS.iSCSI.Application:host.html"
                            }, !1)
                        })
                    }
                }
            }, {
                xtype: "syno_combobox",
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("san_lun", "privilege_type"),
                name: "privilege_type",
                itemId: "privilege_type",
                forceSelection: !0,
                value: "allow_all",
                store: new Ext.data.ArrayStore({
                    autoDestroy: !0,
                    fields: ["value", "display"],
                    data: [
                        ["allow_all", SYNO.SDS.iSCSI.Utils.T("san_lun", "allow_all")],
                        ["for_each", SYNO.SDS.iSCSI.Utils.T("san_lun", "for_each")]
                    ]
                }),
                valueField: "value",
                displayField: "display",
                listeners: {
                    select: function(e, t) {
                        this.ownerCt.getComponent("privilege_description").setValue(i.descriptions[t.get("value")]), i.gridpanel.setVisible("for_each" === t.get("value")), i.gridpanel.loadHostFromMainPooling()
                    }
                }
            }, {
                xtype: "syno_displayfield",
                hideLabel: !1,
                itemId: "privilege_description"
            }, i.gridpanel = new SYNO.SDS.iSCSI.LUN.Privilege({
                appWin: i.appWin,
                owner: i,
                itemId: "host_list_grid"
            })],
            s = {
                title: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_permission"),
                labelWidth: 145,
                fieldWidth: 425,
                items: n,
                listeners: {
                    changeTargetType: function() {
                        i.gridpanel.loadHostFromMainPooling()
                    }
                }
            };
        i.callParent([Ext.apply(s, e)])
    },
    initSetting: function() {
        var e = this;
        e.originalLunDefaultPrivilege = e.owner.lun.get("privilege"), e.originalMappingType = e.owner.getMappingType(), e.getComponent("privilege_type").setValue(e.originalLunDefaultPrivilege), e.getComponent("privilege_description").setValue(e.descriptions[e.originalLunDefaultPrivilege]), e.gridpanel.setVisible("for_each" === e.originalLunDefaultPrivilege), e.gridpanel.loadHostFromMainPooling(), e.originalHostPrivilege = e.getHostPrivilege()
    },
    getHostPrivilege: function() {
        return this.gridpanel.getHostPrivilege()
    },
    getLunDefaultPrivilege: function() {
        return this.getForm().getFieldValues().privilege_type
    },
    isLunDefaultPrivilegeChange: function() {
        return this.originalLunDefaultPrivilege !== this.getLunDefaultPrivilege()
    },
    isDirty: function() {
        var e = this;
        return !!e.isLunDefaultPrivilegeChange() || JSON.stringify(e.getHostPrivilege()) !== JSON.stringify(e.originalHostPrivilege)
    },
    aclIsValid: function() {
        var e = this;
        return "allow_all" === e.getForm().getValues().privilege_type || "error" !== e.gridpanel.getWarningString(e.owner.lun.get("uuid")).category
    },
    isValid: function() {
        var e = this;
        return e.getForm().isValid() && e.aclIsValid()
    },
    getWarningString: function() {
        var e = this;
        return e.gridpanel.getWarningString(e.owner.lun.get("uuid"))
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.AdvSettings", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.owner = e.owner, t = {
            title: SYNO.SDS.iSCSI.Utils.T("common", "cache"),
            labelWidth: 260,
            fieldWidth: 270,
            trackResetOnLoad: !0,
            border: !1,
            items: [{
                xtype: "syno_fieldset",
                title: SYNO.SDS.iSCSI.Utils.T("common", "support_command"),
                items: [{
                    xtype: "syno_checkbox",
                    boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "fua_and_sync_cache"),
                    name: "fua_and_sync_cache"
                }, {
                    xtype: "syno_displayfield",
                    value: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "fua_and_sync_cache_desc"),
                    indent: 1
                }]
            }, {
                xtype: "syno_fieldset",
                title: SYNO.SDS.iSCSI.Utils.T("common", "write_policy"),
                items: [{
                    xtype: "syno_displayfield",
                    value: SYNO.SDS.iSCSI.Utils.T("common", "write_policy_desc")
                }, {
                    xtype: "syno_radio",
                    boxLabel: SYNO.SDS.iSCSI.Utils.T("common", "write_back"),
                    name: "direct_io_pattern",
                    itemId: "buffered_rw",
                    inputValue: 0
                }, {
                    xtype: "syno_displayfield",
                    indent: 1,
                    value: SYNO.SDS.iSCSI.Utils.T("common", "write_back_desc")
                }, {
                    xtype: "syno_radio",
                    boxLabel: SYNO.SDS.iSCSI.Utils.T("common", "write_through"),
                    name: "direct_io_pattern",
                    itemId: "direct_rw",
                    inputValue: 3
                }, {
                    xtype: "syno_displayfield",
                    indent: 1,
                    value: SYNO.SDS.iSCSI.Utils.T("common", "write_through_desc")
                }]
            }]
        }, i.callParent([Ext.apply(t, e)])
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.Edit", {
    extend: "SYNO.SDS.ModalWindow",
    isDataChanged: !1,
    lun: null,
    targets: null,
    constructor: function(e) {
        var t, i, n = this;
        n.appWin = e.appWin, n.owner = e.owner, n.lun = e.lun, n.lunType = n.lun.getLunType(), n.prop = new SYNO.SDS.iSCSI.LUN.Property({
            appWin: n.appWin,
            owner: n,
            itemId: "prop",
            mode: "edit",
            lunType: n.lunType,
            vol_type_of_lun: n.lun.isBtrfsLun() ? "btrfs" : "all"
        }), n.map = new SYNO.SDS.iSCSI.LUN.Mapping({
            itemId: "map",
            appWin: n.appWin,
            owner: n
        }), n.advSettings = new SYNO.SDS.iSCSI.LUN.AdvSettings({
            itemId: "advSet",
            appWin: n.appWin,
            owner: n
        }), n.privilege = new SYNO.SDS.iSCSI.LUN.EditPrivilegeTab({
            itemId: "privilege",
            appWin: n.appWin,
            owner: n
        }), "btrfs" === n.lunType ? (i = [n.prop, n.map, n.privilege], n.appWin.isLio4x && i.push(n.advSettings)) : i = [n.prop, n.map, n.privilege], t = {
            title: SYNO.SDS.iSCSI.Utils.T("common", "alt_edit"),
            width: 640,
            height: 450,
            minWidth: 625,
            minHeight: 450,
            resizable: !0,
            layout: "fit",
            cls: "syno-app-iscsi",
            border: !1,
            items: [{
                itemId: "main",
                xtype: "syno_tabpanel",
                activeTab: 0,
                plain: !0,
                hideMode: "offsets",
                deferredRender: !1,
                items: i
            }],
            buttons: [{
                xtype: "syno_button",
                text: SYNO.SDS.iSCSI.Utils.T("common", "alt_cancel"),
                scope: this,
                handler: this.onCancel
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                text: SYNO.SDS.iSCSI.Utils.T("common", "save"),
                id: n.applyButtonID = Ext.id(),
                scope: this,
                handler: this.onSave
            }]
        }, n.callParent([Ext.apply(t, e)])
    },
    onOpen: function() {
        this.callParent(arguments), this.lun.isSinkLun() ? (this.advSettings.disable(), this.map.disable(), this.privilege.disable()) : this.loadTargets(), "block" === this.lunType ? this.prop.loadPools() : this.prop.loadVolumes(), "btrfs" === this.lunType && this.appWin.isLio4x && this.loadAdvSettings(), this.loadForm(), this.loadHostPrivilege()
    },
    loadForm: function() {
        this.prop.loadLunData(this.lun)
    },
    loadHostPrivilege: function() {
        this.privilege.initSetting()
    },
    loadAdvSettings: function() {
        var e = this,
            t = {};
        Ext.apply(t, {
            direct_io_pattern: e.lun.get("direct_io_pattern"),
            fua_and_sync_cache: e.lun.isEnableFuaAndSyncCache()
        }), e.advSettings.getForm().setValues(t)
    },
    loadTargets: function() {
        var e = this,
            t = e.lun.get("uuid"),
            i = e.appWin.iscsiTargets.getAll(),
            n = e.appWin.iscsiLuns,
            s = [],
            a = String.format(' - <span class="blue-status">{0}</span>', SYNO.SDS.iSCSI.Utils.T("iscsimgr", "target_mapped"));
        Ext.each(i, function(e) {
            for (var i = e.get("mapped_luns"), o = !1, r = !1, l = 0; l < i.length; l++) {
                if (i[l].lun_uuid === t) {
                    o = !0;
                    break
                }
                if (n.getById(i[l].lun_uuid).isLunOwnedByCinder()) {
                    r = !0;
                    break
                }
            }
            if (r) return !0;
            s.push({
                id: e.get("target_id"),
                name: e.get("name") + (0 === i.length ? "" : a),
                iqn: e.get("iqn"),
                enabled: o
            })
        }, e), e.map.initSetting(s)
    },
    isDirty: function() {
        var e = this;
        return !!e.prop.getForm().isDirty() || (!!e.map.isDirty() || (!!e.privilege.isDirty() || !!e.getAdvSettingPanel().getForm().isDirty()))
    },
    getPropPanel: function() {
        return this.prop
    },
    getAdvSettingPanel: function() {
        return "btrfs" === this.lunType && this.appWin.isLio4x ? this.advSettings : {
            getForm: function() {
                return {
                    isDirty: function() {
                        return !1
                    }
                }
            }
        }
    },
    getMappingType: function() {
        return this.map.getMappingType()
    },
    getOriginalMappingType: function() {
        return this.map.getOriginalMappingType()
    },
    getMappingTargets: function() {
        return this.map.getMappingTargets()
    },
    getOriginalMappingTargets: function() {
        return this.map.getOriginalMappingTargets()
    },
    getLunDefaultPrivilege: function() {
        return this.privilege.getLunDefaultPrivilege()
    },
    getHostPrivilege: function() {
        return this.privilege.getHostPrivilege()
    },
    addsettingPropsAPIIfNeeded: function(e) {
        var t, i, n = this,
            s = {},
            a = {},
            o = !1;
        if (a.uuid = n.lun.get("uuid"), a.is_soft_feas_ignored = this.ignoreSoftFeasibility, n.getPropPanel().getForm().isDirty() && (Ext.apply(s, n.getPropPanel().getForm().getValues()), i = s.size, t = parseInt(i, 10) * SYNO.SDS.iSCSI.Utils.ISCSITRG_UNIT_GB, a.new_size = t, a.new_name = s.name, a.description = s.description, s.hasOwnProperty("location") && n.lun.get("location") !== s.location && (a.new_location = s.location, n.lun.isEnableSnapshot() && n.pushConfirm(SYNO.SDS.iSCSI.Utils.T("lun", "warning_move_location"))), o = !0, n.lun.isThinProvisioningLun())) {
            var r = s.location ? s.location : n.lun.space.volume_path,
                l = n.appWin.volumes,
                S = l.findIndex(function(e) {
                    return e.volume_path == r
                }),
                d = l[S].size_free_byte;
            if (t > d) {
                var c = String.format(SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_thin_provisioning_warning"), SYNO.SDS.iSCSI.Utils.SizeRender(t), SYNO.SDS.iSCSI.Utils.SizeRender(d), SYNO.SDS.iSCSI.Utils.volumePathRenderer(r));
                n.pushConfirm(c)
            }
        }
        if (n.getAdvSettingPanel().getForm().isDirty()) {
            var p = {};
            Ext.apply(p, n.getAdvSettingPanel().getForm().getValues()), a.direct_io_pattern = parseInt(p.direct_io_pattern, 10);
            var u = "true" === p.fua_and_sync_cache && "true" === p.fua_and_sync_cache;
            a.dev_attribs = [], a.dev_attribs.push({
                dev_attrib: "emulate_fua_write",
                enable: u ? 1 : 0
            }), a.dev_attribs.push({
                dev_attrib: "emulate_sync_cache",
                enable: u ? 1 : 0
            }), o = !0
        }
        o && e.push({
            api: "SYNO.Core.ISCSI.LUN",
            method: "set",
            version: 1,
            params: a
        })
    },
    addModifyTargetAPIIfNeeded: function(e) {
        var t = this,
            i = t.map.getTargetStore(),
            n = i.getModifiedRecords(),
            s = [],
            a = [],
            o = {},
            r = {};
        o.uuid = t.lun.get("uuid"), r.uuid = t.lun.get("uuid");
        var l = t.appWin.iscsiTargets;
        if (n.find(function(e) {
                if (!e.get("enabled")) return !1;
                var t = l.getById(e.get("id"));
                return t && SYNO.SDS.iSCSI.TARGET.MAX_MAPPING_LUNS <= t.get("mapped_luns").length + 1
            })) {
            var S = SYNO.SDS.iSCSI.Utils.T("trg", "max_lun_per_target");
            return S = String.format(S, SYNO.SDS.iSCSI.TARGET.MAX_MAPPING_LUNS), t.getMsgBox().alert(t.title, S), !1
        }
        return n.forEach(function(e) {
            var i = e.get("id"),
                n = l.getById(i);
            n && (e.get("enabled") ? a.push(i) : (s.push(i), 0 < n.get("connected_sessions").length && t.pushConfirm(SYNO.SDS.iSCSI.Utils.T("san_trg", "disconnect_warning"))))
        }), o.target_ids = a, r.target_ids = s, a.length > 0 && e.push({
            api: "SYNO.Core.ISCSI.LUN",
            method: "map_target",
            version: 1,
            params: o
        }), s.length > 0 && e.push({
            api: "SYNO.Core.ISCSI.LUN",
            method: "unmap_target",
            version: 1,
            params: r
        }), !0
    },
    getISCSITargetAPIs: function(e) {
        var t = this,
            i = {};
        return i.uuid = t.lun.get("uuid"), "unmap_target" === e ? i.target_ids = t.getOriginalMappingTargets() : "map_target" === e && (i.target_ids = t.getMappingTargets()), i.target_ids.length ? [{
            api: "SYNO.Core.ISCSI.LUN",
            method: e,
            version: 1,
            params: i
        }] : []
    },
    getFCTargetAPIs: function(e) {
        var t = this,
            i = {};
        return i.uuid = t.lun.get("uuid"), i.target_ids = t.appWin.fcTargets.getAll().map(function(e) {
            return e.get("target_id")
        }), i.target_ids.length ? [{
            api: "SYNO.Core.ISCSI.LUN",
            method: e,
            version: 1,
            params: i
        }] : []
    },
    addTargetAPIIfNeeded: function(e, t) {
        var i = this,
            n = "iscsi" === (e ? i.getMappingType() : i.getOriginalMappingType()),
            s = String.format("{0}_{1}", e ? "map" : "unmap", n ? "target" : "fctarget");
        n ? i.getISCSITargetAPIs(s).forEach(function(e) {
            t.push(e)
        }) : i.getFCTargetAPIs(s).forEach(function(e) {
            t.push(e)
        })
    },
    addSettingHostMappingAPI: function(e) {
        var t, i = this,
            n = i.lun.get("uuid"),
            s = {
                uuid: n,
                acls: []
            };
        if ("allow_all" === i.getLunDefaultPrivilege()) t = "rw";
        else {
            t = "-";
            var a = i.getHostPrivilege();
            Object.keys(a).forEach(function(e) {
                "-" !== a[e].permission && s.acls.push({
                    host_uuid: e,
                    permission: a[e].permission
                })
            })
        }
        e.push(function(e) {
            return {
                api: "SYNO.Core.ISCSI.LUN",
                method: "acl_masks_set",
                version: 1,
                params: {
                    uuid: n,
                    acls: [{
                        iqn: "iqn.2000-01.com.synology:default.acl",
                        permission: e
                    }]
                }
            }
        }(t)), e.push({
            api: "SYNO.Core.ISCSI.LUN",
            method: "host_acl_masks_set",
            version: 1,
            params: s
        })
    },
    onSave: function() {
        var e = this,
            t = [];
        if (!e.privilege.isValid()) {
            e.getComponent("main").activate("privilege");
            var i = e.privilege.getWarningString();
            return void("error" === i.category ? e.getMsgBox().alert(e.title, i.text) : "warn" === i.category && e.pushConfirm(i.text))
        }
        if (!e.getPropPanel().getForm().isValid()) return void e.getComponent("main").activate("prop");
        if (!e.isDirty()) return void e.close();
        if (e.addsettingPropsAPIIfNeeded(t), e.privilege.isDirty() && (e.lun.isConnected && "allow_all" === e.lun.get("privilege") && e.privilege.isLunDefaultPrivilegeChange() && e.pushConfirm(SYNO.SDS.iSCSI.Utils.T("san_trg", "disconnect_warning")), e.addSettingHostMappingAPI(t)), e.getOriginalMappingType() !== e.getMappingType()) e.addTargetAPIIfNeeded(!1, t), e.addTargetAPIIfNeeded(!0, t), e.lun.isConnected && e.pushConfirm(SYNO.SDS.iSCSI.Utils.T("san_trg", "disconnect_warning"));
        else if ("iscsi" === e.getMappingType() && !e.addModifyTargetAPIIfNeeded(t)) return;
        e.doConfirms(t)
    },
    pushConfirm: function(e) {
        this.confirms || (this.confirms = []), -1 === this.confirms.indexOf(e) && this.confirms.push(e)
    },
    doConfirms: function(e) {
        var t = this;
        if (this.confirms && this.confirms.length) {
            var i = this.confirms.shift();
            this.getMsgBox().confirm(this.title, i, function(i) {
                "yes" === i && t.doConfirms(e)
            })
        } else this.doApply(e)
    },
    doApply: function(e) {
        var t = this,
            i = !1;
        t.setStatusBusy({
            text: SYNO.SDS.iSCSI.Utils.T("common", "saving")
        });
        for (var n = 0; n < e.length; n++) e[n].params.hasOwnProperty("is_soft_feas_ignored") && (e[n].params.is_soft_feas_ignored = this.ignoreSoftFeasibility), "map_target" != e[n].method && "unmap_target" != e[n].method && "map_fctarget" != e[n].method && "unmap_fctarget" != e[n].method || (i = !0);
        this.sendWebAPI({
            scope: this,
            compound: {
                stopwhenerror: !0,
                mode: "sequential",
                params: e
            },
            callback: function(n, s) {
                var a = t.lun.get("name");
                this.clearStatusBusy();
                for (var o = 0; o < s.result.length; o++)
                    if (!s.result[o].success) {
                        var r = void 0;
                        return s.result[o].hasOwnProperty("error") && s.result[o].error.hasOwnProperty("errors") && (r = s.result[o].error.errors, r.hasOwnProperty("feasibility_hard") || r.hasOwnProperty("feasibility_soft")) ? void SYNO.SDS.iSCSI.LUN.GeneralFeasChkFailCallback(r, e, a, "", this, this.applyButtonID) : (SYNO.SDS.iSCSI.Utils.HARemoteCheckErrParsing(s.result[o].error), void SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(this, s.result[o].error))
                    }
                "ture" === i && SYNO.SDS.StatusNotifier.setServiceDisabled("SYNO.SDS.StorageManager.ISCSI", !1), this.isDataChanged = !0, this.close()
            }
        })
    },
    onCancel: function() {
        if (this.isDirty()) return void this.confirmLostChangePromise({
            save: function() {
                this.onSave()
            },
            dontSave: function() {
                this.close()
            },
            cancel: function() {}
        }, this);
        this.close()
    },
    contFromSoftFeasCheck: function(e) {
        this.ignoreSoftFeasibility = !0, this.doApply(e)
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.Clone", {
    extend: "SYNO.SDS.ModalWindow",
    isDataChanged: !1,
    lun: null,
    volumes: null,
    targets: null,
    pool: null,
    constructor: function(e) {
        var t, i = this;
        i.owner = e.owner, i.appWin = e.appWin, i.lun = e.lun, i.ignoreSoftFeasibility = !1, i.forceReload = !1, i.lunType = i.lun.getLunType(), i.needWarning = !1, i.extraWarning = SYNO.SDS.iSCSI.Utils.IsAnyMappedTargetConnected(i.lun.get("uuid"), i.appWin.iscsiTargets.getAll()), t = {
            title: SYNO.SDS.iSCSI.Utils.T("iscsilun", "clone"),
            width: 640,
            height: i.extraWarning ? 500 : 400,
            resizable: !1,
            layout: "fit",
            plain: !0,
            border: !1,
            items: [i.createPanel()],
            buttons: [{
                xtype: "syno_button",
                text: SYNO.SDS.iSCSI.Utils.T("common", "alt_cancel"),
                scope: this,
                handler: this.onCancel
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                text: SYNO.SDS.iSCSI.Utils.T("iscsilun", "clone"),
                id: i.applyButtonID = Ext.id(),
                scope: this,
                handler: this.onSave
            }]
        }, i.callParent([Ext.apply(t, e)])
    },
    createPanel: function() {
        var e = this;
        return {
            xtype: "syno_formpanel",
            itemId: "main",
            border: !1,
            bodyStyle: "padding: 0;",
            items: [e.prop = new SYNO.SDS.iSCSI.LUN.Property({
                appWin: e.appWin,
                renderTo: Ext.getBody(),
                height: 250,
                itemId: "property",
                mode: "clone",
                vol_type_of_lun: "btrfs" === e.lunType && e.lun.isThinProvisioningLun() ? "btrfs" : "all",
                lunType: e.lunType
            }), {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                hidden: !e.extraWarning,
                value: String.format('<span class="red-status"> {0}</span>', String.format(SYNO.SDS.iSCSI.Utils.T("iscsilun", "clone_snapshot_inconsistent_warning"), e.lun.get("name")))
            }]
        }
    },
    onOpen: function() {
        this.callParent(arguments), this.prop.loadVolumes(), this.prop.loadLunData(this.lun), this.prop.getForm().setValues({
            name: this.appWin.genNewLunName()
        })
    },
    getPropPanel: function() {
        return this.prop
    },
    isDirty: function() {
        return !!this.getComponent("property").getForm().isDirty()
    },
    prepareCloneParams: function() {
        var e = this,
            t = e.getPropPanel(),
            i = t.getForm().getValues(),
            n = [],
            s = {};
        return s.is_soft_feas_ignored = this.ignoreSoftFeasibility, s.src_lun_uuid = e.lun.get("uuid"), s.dst_lun_name = i.name, s.dst_location = i.location, s.description = i.description, this.lun.canSnapshot() || (e.needWarning = !0), this.lun.isLunOnBtrfsVol(this.appWin.volumes, this.appWin.pools) && this.lun.isThinProvisioningLun() && !this.lun.isAdvancedLun() && (e.needWarning = !1), "btrfs" === t.lunType ? t.getComponent("thin_provision").getValue() ? s.clone_type = "BLUN" : s.clone_type = "BLUN_THICK" : this.lun.isAdvancedLun() ? s.clone_type = "ADV" : this.lun.isThinProvisioningLun() ? s.clone_type = "THIN" : s.clone_type = "FILE", n.push({
            api: "SYNO.Core.ISCSI.LUN",
            method: "clone",
            version: 1,
            params: s
        }), n
    },
    onSave: function() {
        var e, t = this,
            i = this.getPropPanel().getForm();
        i.isValid() && (e = t.prepareCloneParams(), t.needWarning ? this.getMsgBox().confirm(this.title, SYNO.SDS.iSCSI.Utils.T("san_trg", "disconnect_warning"), function(t) {
            "yes" === t && this.doApply(e)
        }, this) : this.doApply(e))
    },
    doApply: function(e) {
        var t = this;
        this.setStatusBusy({
            text: SYNO.SDS.iSCSI.Utils.T("common", "saving")
        }), this.sendWebAPI({
            scope: this,
            compound: {
                stopwhenerror: !0,
                mode: "sequential",
                params: e
            },
            callback: function(i, n) {
                var s = t.lun.get("name");
                this.clearStatusBusy();
                for (var a = 0; a < n.result.length; a++)
                    if (!n.result[a].success) {
                        var o = void 0;
                        return n.result[a].hasOwnProperty("error") && n.result[a].error.hasOwnProperty("errors") && (o = n.result[a].error.errors, o.hasOwnProperty("feasibility_hard") || o.hasOwnProperty("feasibility_soft")) ? void SYNO.SDS.iSCSI.LUN.GeneralFeasChkFailCallback(o, e, s, "", this, this.applyButtonID) : (SYNO.SDS.iSCSI.Utils.HARemoteCheckErrParsing(n.result[a].error), void SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(this, n.result[a].error))
                    } t.isDataChanged = !0, t.forceReload && t.appWin.pollTask.restart(!0), t.close()
            }
        })
    },
    onCancel: function() {
        this.close()
    },
    contFromSoftFeasCheck: function() {
        this.ignoreSoftFeasibility = !0, this.onSave()
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.Wizard.ConvertReadmeStep", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.lun = e.lun, t.cannotConvertReason = e.cannotConvertReason;
        var i = {
            headline: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "iscsilun_convert_desc"),
            items: [{
                xtype: "syno_displayfield",
                htmlEncode: !1,
                value: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "iscsilun_convert_desc_detail")
            }, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                value: String.format(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "iscsilun_convert_rqmt"), '<span style="font-weight: bold">', "</span>")
            }, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                value: '<span class="syno-ux-note">' + SYNO.SDS.iSCSI.Utils.T("common", "note") + SYNO.SDS.iSCSI.Utils.T("common", "colon") + " </span>" + SYNO.SDS.iSCSI.Utils.T("iscsimgr", "iscsilun_convert_note")
            }]
        };
        t.callParent([Ext.apply(i, e)])
    },
    getNext: function() {
        return this.cannotConvertReason && "" != this.cannotConvertReason ? (this.owner.getMsgBox().alert("", this.cannotConvertReason), !1) : this.nextId
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.Wizard.ConvertSummaryStep", {
    extend: "SYNO.SDS.Wizard.SummaryStep",
    constructor: function(e) {
        this.lun = e.lun;
        var t = Ext.apply({
            headline: SYNO.SDS.iSCSI.Utils.T("ezinternet", "ezinternet_summary_title"),
            viewConfig: {
                forceFit: !1
            },
            columns: [{
                width: 150,
                header: SYNO.SDS.iSCSI.Utils.T("status", "header_item"),
                dataIndex: "key",
                renderer: this.fieldRenderer
            }, {
                id: "value",
                autoExpand: !0,
                header: SYNO.SDS.iSCSI.Utils.T("status", "header_value"),
                dataIndex: "value",
                renderer: this.descRenderer,
                scope: this
            }],
            enableHdMenu: !1,
            enableColumnMove: !1,
            autoExpandColumn: "value",
            store: new SYNO.SDS.Wizard.SummaryStore
        }, e);
        SYNO.SDS.Wizard.SummaryStep.superclass.constructor.call(this, t)
    },
    getNext: function() {
        var e = this,
            t = e.checkConvertRule();
        if (!t.has_any_mapped_target && !t.has_any_snapshot) return this.owner.applySettings(null), !1;
        var i = "";
        return t.has_any_mapped_target && (i += SYNO.SDS.iSCSI.Utils.T("iscsimgr", "iscsilun_convert_mapped_trg_warn"), e.owner.needUnmap = !0), t.has_any_snapshot && (i += SYNO.SDS.iSCSI.Utils.T("iscsimgr", "iscsilun_convert_snap_warn")), i += SYNO.SDS.iSCSI.Utils.T("common", "ask_cont"), e.owner.getMsgBox().confirm(e.owner.title, i, function(e) {
            "yes" === e && this.owner.applySettings(null)
        }, this, {
            yes: {
                text: Ext.MessageBox.buttonText.yes,
                btnStyle: "red"
            },
            no: {
                text: Ext.MessageBox.buttonText.no
            }
        }), !1
    },
    checkConvertRule: function() {
        return {
            has_any_mapped_target: this.lun.mappedTargets.length > 0,
            has_any_snapshot: (this.lun.data.snapshots && this.lun.data.snapshots.length) > 0
        }
    },
    descRenderer: function(e, t, i, n, s, a) {
        var o = e.toString().replace(/<.*?>/g, "");
        return t.attr = 'ext:qtip="' + o + '"', e
    },
    checkState: function() {
        SYNO.SDS.Wizard.Step.prototype.checkState.apply(this, arguments), this.owner.getButton("next").setText(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "iscsilun_convert"))
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.WizardConvert", {
    extend: "SYNO.SDS.Wizard.ModalWindow",
    isDataChanged: !1,
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.owner = e.owner, i.lun = e.lun, i.cannotConvertReason = "", i.availDstLocations = i.getCanConvertVols(), i.needUnmap = !1, i.readmeStep = new SYNO.SDS.iSCSI.LUN.Wizard.ConvertReadmeStep({
            appWin: i.appWin,
            lun: i.lun,
            cannotConvertReason: i.cannotConvertReason,
            itemId: "convert_readme_step",
            nextId: "convert_prop_step"
        }), i.propStep = new SYNO.SDS.iSCSI.LUN.Wizard.PropertyStep({
            appWin: i.appWin,
            mode: "convert",
            itemId: "convert_prop_step",
            vol_type_of_lun: "btrfs",
            lun: i.lun,
            avail_dst_locations: i.availDstLocations,
            nextId: "convert_summary"
        }), i.summaryStep = new SYNO.SDS.iSCSI.LUN.Wizard.ConvertSummaryStep({
            appWin: i.appWin,
            itemId: "convert_summary",
            lun: i.lun,
            nextId: null
        }), t = {
            title: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "iscsilun_convert_title"),
            cls: "syno-app-iscsi",
            width: 680,
            height: 640,
            resizable: !1,
            border: !1,
            steps: [i.readmeStep, i.propStep, i.summaryStep]
        }, i.callParent([Ext.apply(t, e)])
    },
    getPropPanel: function() {
        return this.propStep
    },
    getCanConvertVols: function() {
        var e = this,
            t = [];
        return e.cannotConvertReason = "", t = e.appWin.volumes.filter(function(e) {
            return "btrfs" === e.fs_type
        }), 0 === t.length ? (e.cannotConvertReason = SYNO.SDS.iSCSI.Utils.T("iscsimgr", "convert_no_btrfs_volume"), e.canConvertVols) : (t = t.filter(function(t) {
            return e.lun.get("allocated_size") <= parseInt(t.size_free_byte, 10)
        }), 0 === t.length && (e.cannotConvertReason = SYNO.SDS.iSCSI.Utils.T("iscsimgr", "convert_btrfs_no_available_capacity")), t)
    },
    prepareConvertParams: function() {
        var e = this,
            t = e.getPropPanel(),
            i = t.getForm().getValues(),
            n = {};
        return n.src_lun_uuid = e.lun.get("uuid"), n.dst_lun_name = i.name, n.dst_location = i.location, n.clone_type = "BLUN", "true" === i.delete_orig_lun_after_convert && (n.is_delete_parent_lun = !0, n.map_new_lun_to_target_ids = e.lun.mappedTargets), {
            api: "SYNO.Core.ISCSI.LUN",
            method: "clone",
            version: 1,
            params: n
        }
    },
    applySettings: function(e) {
        var t = this,
            i = [];
        t.getPropPanel().getForm().isValid() && (t.needUnmap && i.push({
            api: "SYNO.Core.ISCSI.LUN",
            method: "unmap_target",
            version: 1,
            params: {
                uuid: t.lun.get("uuid"),
                target_ids: t.lun.mappedTargets
            }
        }), i.push(t.prepareConvertParams()), null !== e && (i = e), t.getButton("next").disable(), t.setStatusBusy({
            text: SYNO.SDS.iSCSI.Utils.T("common", "saving")
        }), t.sendWebAPI({
            compound: {
                stopwhenerror: !0,
                mode: "sequential",
                params: i
            },
            callback: function(e, n, s) {
                var a = [];
                t.clearStatusBusy(), t.getButton("next").enable(), t.getButton("next").setText(SYNO.SDS.iSCSI.Utils.T("common", "alt_finish"));
                for (var o = 0; o < n.result.length; o++)
                    if (!n.result[o].success) {
                        var r = void 0;
                        i[o].params.is_soft_feas_ignored = !0;
                        for (var l = 0; l < i.length; l++) n.result[l].success || a.push(i[l]);
                        return n.result[o].hasOwnProperty("error") && n.result[o].error.hasOwnProperty("errors") && (r = n.result[o].error.errors, r.hasOwnProperty("feasibility_hard") || r.hasOwnProperty("feasibility_soft")) ? void SYNO.SDS.iSCSI.LUN.GeneralFeasChkFailCallback(r, a, t.lun.get("name"), "", t, t.getButton("next").getId()) : (SYNO.SDS.iSCSI.Utils.HARemoteCheckErrParsing(n.result[o].error), void SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(t, n.result[o].error))
                    } t.isDataChanged = !0, t.close()
            }
        }))
    },
    contFromSoftFeasCheck: function(e) {
        this.applySettings(e)
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.iSCSILUN", {
    check: SYNO.SDS.iSCSI.Utils.check,
    utils: SYNO.SDS.iSCSI.Utils,
    prepareDevAttribsJson: function() {
        var e = this.get("dev_attribs"),
            t = {};
        e && (t = e.reduce(function(e, t) {
            return e[t.dev_attrib] = t.enable, e
        }, t)), this.data.dev_attribs_json = t
    },
    get: function(e) {
        if (this.data) return this.data[e]
    },
    set: function(e, t) {
        this.data && (this.data[e] = t)
    },
    getLunType: function() {
        return this.isBtrfsLun() ? "btrfs" : this.isFileLun() ? "file" : "block"
    },
    getSpace: function(e, t) {
        var i = this;
        return this.space ? this.space : (this.space = this.isBlockLun() ? this.utils.getLUNPoolInfo(t, this.get("location")) : e.find(function(e) {
            return e.volume_path === i.get("location")
        }), this.space ? this.space : {
            size_free_byte: 0,
            status: "unknown"
        })
    },
    getSpaceStatus: function(e, t) {
        return this.getSpace(e, t).status
    },
    getSpaceFreeSize: function(e, t) {
        var i = this.getSpace(e, t);
        return parseInt(i.size_free_byte, 10)
    },
    getSummaryStatus: function(e, t, i) {
        var n = this.getSpace(e, t),
            s = n.status,
            a = parseInt(n.size_free_byte, 10),
            o = ["degrade", "crashed", "read_only"];
        return this.cacheMissing() ? this.utils.StatusNameRender("cache_missing") : this.cacheCrashed() && !this.isDeleting() ? this.utils.StatusNameRender("crashed") : (this.isNormal() || this.isFinished()) && -1 < o.indexOf(s) ? this.utils.StatusNameRender(s) : this.isHardLimit() ? String.format('<span class="{0}">{1}</span>', "red-status", SYNO.SDS.iSCSI.Utils.T("iscsimgr", "hard_limit_reach")) : this.isThinProvisioningLun() && a < SYNO.SDS.iSCSI.TP_HARD_THRESHOLD_DEFAULT_SIZE && i ? String.format('<span class="{0}">{1}</span>', "red-status", SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_low_capacity")) : this.isSoftLimit() ? String.format('<span class="{0}">{1}</span>', "orange-status", SYNO.SDS.iSCSI.Utils.T("iscsimgr", "soft_limit_reach")) : this.utils.StatusNameRender(this.get("status"))
    },
    getProgress: function() {
        var e, t, i = this.get("status");
        return "cloning" === i && "" !== this.get("family_config").parent_lun_uuid && (e = this.get("sync_done"), t = this.get("sync_total")), "defragging" === i && (e = this.get("sync_done"), t = this.get("sync_total")), t && void 0 !== e ? String.format('<span class="blue-status">({0}%)</span>', Math.floor(100 * e / t)) : ""
    },
    getAdvFeatureDesc: function() {
        if (this.isEPLun()) return this.isAdvancedLun() ? SYNO.SDS.iSCSI.Utils.T("common", "enabled") : SYNO.SDS.iSCSI.Utils.T("common", "disabled");
        var e = [];
        return this.isEnableTPWriteSame() && e.push(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_adv_feature_write_same")), this.isEnableCompareAndWrite() && e.push(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_adv_feature_acw")), this.isEnableXcopy() && e.push(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_adv_feature_xcopy")), this.isEnableUnmap() && e.push(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "unmap_command")), this.isEnableSnapshot() && e.push(SYNO.SDS.iSCSI.Utils.T("iscsilun", "snapshot")), 0 === e.length ? SYNO.SDS.iSCSI.Utils.T("common", "no") : e.join(", ")
    },
    getDefaultAdvFeatureDesc: function() {
        return [SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_adv_feature_write_same"), SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_adv_feature_acw"), SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_adv_feature_xcopy"), SYNO.SDS.iSCSI.Utils.T("iscsilun", "snapshot")].join(", ")
    },
    getCrashType: function(e, t, i) {
        var n = this.getSpace(e, t),
            s = n.status,
            a = parseInt(n.size_free_byte, 10);
        return this.cacheCrashed() ? "cache_crashed" : this.isHardLimit() ? i ? "hard_limit_reach" : "hard_limit_reach_without_low_capacity_write" : this.isThinProvisioningLun() && a < SYNO.SDS.iSCSI.TP_HARD_THRESHOLD_DEFAULT_SIZE && i ? "low_capacity_write_on" : this.isSoftLimit() ? "soft_limit_reach" : "unavailabling" === this.get("status") ? "unavailabling" : this.isUnhealthy() ? "Unhealthy" : "crashed" === s ? "volume_crashed" : "read_only" === s ? "volume_read_only" : "degrade" === s ? "volume_degrade" : "normal"
    },
    isSummaryWarning: function(e, t) {
        return this.isSoftLimit() || this.isUnhealthy() || "volume_degrade" === this.getCrashType(e, t)
    },
    isSummaryCrashed: function(e, t, i) {
        var n = this.getCrashType(e, t, i);
        return "normal" !== n && "soft_limit_reach" !== n
    },
    isActioning: function() {
        return this.get("is_action_locked")
    },
    isDeleting: function() {
        return "deleting" === this.get("status")
    },
    isFinished: function() {
        return "finished" === this.get("status")
    },
    isUnhealthy: function() {
        return "Unhealthy" === this.get("status")
    },
    isNormal: function() {
        return "normal" === this.get("status")
    },
    isSoftLimit: function() {
        return "soft_limit_reach" === this.get("status")
    },
    isHardLimit: function() {
        return "hard_limit_reach" === this.get("status")
    },
    isCrashed: function() {
        return "unavailabling" === this.get("status") || this.isUnhealthy()
    },
    cacheMissing: function() {
        return "cache_missing" === this.get("flashcache_status")
    },
    cacheCrashed: function() {
        return "cache_crashed" === this.get("flashcache_status")
    },
    isFileLun: function() {
        return 0 != (2 & this.get("type"))
    },
    isThinProvisioningLun: function() {
        return 0 != (4 & this.get("type"))
    },
    isAdvancedLun: function() {
        return 0 != (8 & this.get("type"))
    },
    isSinkLun: function() {
        return 0 != (16 & this.get("type"))
    },
    isVdiskLun: function() {
        return 0 != (32 & this.get("type"))
    },
    isBtrfsLun: function() {
        return 0 != (256 & this.get("type"))
    },
    isLunOwnedByCinder: function() {
        return 0 != (128 & this.get("type"))
    },
    isBlockLun: function() {
        return !this.isFileLun()
    },
    isEPLun: function() {
        return this.isFileLun() && !this.isBtrfsLun()
    },
    isEnableAnyAdvancedFeature: function() {
        return this.isEnableTPWriteSame() || this.isEnableCompareAndWrite() || this.isEnableXcopy() || this.isEnableUnmap() || this.isEnableSnapshot()
    },
    isEnableTPWriteSame: function() {
        return 1 === this.get("dev_attribs_json").emulate_tpws
    },
    isEnableCompareAndWrite: function() {
        return 1 === this.get("dev_attribs_json").emulate_caw
    },
    isEnableXcopy: function() {
        return 1 === this.get("dev_attribs_json").emulate_3pc
    },
    isEnableUnmap: function() {
        return 1 === this.get("dev_attribs_json").emulate_tpu
    },
    isEnableSnapshot: function() {
        return 1 === this.get("dev_attribs_json").can_snapshot
    },
    isLunOnBtrfsVol: function(e, t) {
        return "btrfs" == this.getSpace(e, t).fs_type
    },
    isEnableFuaAndSyncCache: function() {
        return 1 === this.get("dev_attribs_json").emulate_fua_write && 1 === this.get("dev_attribs_json").emulate_sync_cache
    },
    canSnapshot: function() {
        return this.isEnableSnapshot()
    },
    isAbnormalStatus: function() {
        switch (this.get("status")) {
            case "unavailabling":
            case "Unhealthy":
            case "deleting":
            case "creating":
                return !0
        }
        return !1
    },
    canBeDeleted: function(e, t) {
        return !(this.isAbnormalStatus() || this.isActioning() || this.isSinkLun() || this.cacheCrashed() || "crashed" === this.getSpaceStatus(e, t))
    },
    canBeMapped: function(e, t) {
        return this.canBeDeleted(e, t) && !this.isLunOwnedByCinder()
    },
    canBeShownAsAllowAll: function() {
        return !this.isSinkLun() && !this.isLunOwnedByCinder()
    },
    canManage: function() {
        return !this.isLunOwnedByCinder()
    },
    getMappedType: function() {
        return this.get("mappingType")
    },
    isMappedFC: function() {
        return "fc" === this.getMappedType()
    },
    isMappedISCSI: function() {
        return "iscsi" === this.getMappedType()
    },
    getLunActionProgress: function(e, t) {
        var i;
        if ("-1" !== e.percent && -1 !== e.percent) i = parseInt(e.percent, 10);
        else {
            var n = t ? t[t.length - 1] : null;
            i = n ? parseInt(n.status.progress.percent, 10) : -1
        }
        return 0 > i ? 0 : i
    },
    getSnapshotPageInfo: function(e, t) {
        var i, n = {},
            s = SYNO.SDS.iSCSI.Utils,
            a = s.UIRender;
        this.get("snapshots") ? n.snapshots = this.get("snapshots") : n.snapshots = [], n.progress = {
            percent: "-1",
            step: "none"
        }, n.lun = this, n.name = this.get("name"), n.id = this.get("uuid"), n.lid = this.get("lun_id"), n.extent_based = this.isAdvancedLun(), n.extent_size = this.get("extent_size"), n.status = this.get("status"), n.retention = this.get("retention"), n.scheduled_task = this.get("scheduled_task"), n.uuid = this.get("uuid"), n.size = this.get("size"), this.isSinkLun() ? n.iconCls = "iscsi-lun-icon iscsi-lun-icon-sink" : this.isBtrfsLun() && this.isThinProvisioningLun() ? n.iconCls = "iscsi-lun-icon iscsi-lun-icon-btrfs" : this.isThinProvisioningLun() ? n.iconCls = "iscsi-lun-icon iscsi-lun-icon-file" : n.iconCls = "iscsi-lun-icon iscsi-lun-icon-block", n.is_actioning = this.isActioning(), i = n.is_actioning ? this.getLunActionProgress(n.progress, n.snapshots) : 0;
        var o = this.getSpace(e, t),
            r = this.getSpaceStatus(e, t);
        if (this.volume_crashed = "crashed" === r, this.volume_read_only = "read_only" === r, n.volume_crashed = "crashed" === r, n.volume_read_only = "read_only" === r, n.vol_path = this.get("location"), n.vol_fs_type = o.fs_type, this.isBlockLun()) {
            var l = s.getLUNPoolInfo(t, this.get("location")).pool_id,
                S = s.SpaceIDParser(l).str;
            n.vol_info = String.format(SYNO.SDS.iSCSI.Utils.T("volume", "volume_default_desc"), S)
        } else n.vol_info = s.volumeInfoRenderer(n.vol_path, n.vol_fs_type);
        n.isProtected = n.snapshots && 0 < n.snapshots.length, n.isSnapScheduled = n.scheduled_task && n.scheduled_task[0].general.task_enabled;
        var d = "unavailabling" !== this.get("status") && n.is_actioning;
        n.displayProg = d ? "show" : "hide", n.progress = i.toString() + " %", n.barWidth = 200 * i / 100, n.lastSnapshot = n.isProtected ? s.timeRender(Math.round(s.dsNowSec - this.getSnapTime(n.snapshots[n.snapshots.length - 1]) / 1e3)) : SYNO.SDS.iSCSI.invalid;
        var c = n.isSnapScheduled ? n.scheduled_task[0].schedule.next_trigger_time : "";
        if (c = c.split(" ").join("T"), n.next_run_time = n.isSnapScheduled ? new Date(c).getTime() / 1e3 : SYNO.SDS.iSCSI.invalid, this.isAdvancedLun() ? n.lun_type = SYNO.SDS.iSCSI.LUN_TYPE_ADV : this.isBtrfsLun() && this.isThinProvisioningLun() ? n.lun_type = SYNO.SDS.iSCSI.LUN_TYPE_BTRFS : n.lun_type = SYNO.SDS.iSCSI.LUN_TYPE_NOT_SUPPORT, n.lun_snap_type_desc = s.LunSnapTypeRenderer(n.lun_type), this.isEnableSnapshot()) {
            n.support_snapshot = !0, n.snapshotProp = [{
                name: SYNO.SDS.iSCSI.Utils.T("schedule", "next_trigger_time"),
                value: n.isSnapScheduled ? a.planNextTimeRender(n.next_run_time, s.dsNowSec) : SYNO.SDS.iSCSI.invalid
            }, {
                name: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "snap_last_time"),
                value: n.lastSnapshot
            }, {
                name: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "snap_can_restore"),
                value: n.isProtected ? n.snapshots.length : SYNO.SDS.iSCSI.invalid
            }, {
                name: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "snap_ret_time"),
                value: s.retentionRender(n.retention)
            }];
            var p = s.retentionTriggerRender(n.retention);
            p && n.snapshotProp.push({
                name: SYNO.SDS.iSCSI.Utils.T("snapmgr", "snap_ret_trigger_time"),
                value: p
            })
        } else n.support_snapshot = !1;
        return n.capacity = n.support_snapshot ? SYNO.SDS.Utils.StorageUtils.UiRenderHelper.SizeRender(this.get("size")) : SYNO.SDS.iSCSI.invalid, n.scheduleTask = [], n.isSnapScheduled && n.scheduleTask.push({
            date: s.processScheduledRender(n.scheduled_task[0].schedule.week_name),
            freq: s.freqRender(n.scheduled_task[0].schedule),
            type: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "snap_local_snapshot")
        }), n.restorePageLastSnapshot = SYNO.SDS.iSCSI.Utils.T("iscsimgr", "snap_last_time") + " - " + n.lastSnapshot, n.volume_crashed ? n.recoveryStatus = "crashed" : n.recoveryStatus = n.is_actioning ? "processing" : n.isProtected ? "normal" : "warning", n.restoreProp = [{
            name: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "snap_can_restore"),
            value: n.isProtected ? n.snapshots.length : SYNO.SDS.iSCSI.invalid
        }], n.isProtected && Ext.each(n.snapshots, function(e) {
            e.epoch_msec = this.getSnapTime(e), e.ownername = this.get("name")
        }, this), s.StatusRender(n, n.volume_crashed, this.canManage(), this.isLunOwnedByCinder(), n.is_actioning, null, n.isSnapScheduled), n
    },
    getSnapTime: function(e) {
        if (e) return 1e3 * e.create_time
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.Main", {
    extend: "SYNO.SDS.SAN.CardsMainPanel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.panels = [t.emptyPage = new SYNO.SDS.SAN.LUN.EmptyMain({
            appWin: t.appWin,
            owner: t.owner,
            itemId: "emptyPage"
        }), t.normalPage = new SYNO.SDS.iSCSI.LUN.NormalMain({
            appWin: t.appWin,
            owner: t.owner,
            itemId: "normalPage"
        })];
        var i = {
            panels: t.panels
        };
        this.callParent([Ext.apply(i, e)])
    },
    onDataReady: function() {
        var e = this;
        e.canCreateLunTypes = e.appWin.getCanCreateLunTypes(), e.appWin.iscsiLuns.getAll().length ? (e.getLayout().setActiveItem("normalPage"), e.normalPage.fireEvent("data_ready")) : (e.getLayout().setActiveItem("emptyPage"), e.createFromLink && (e.emptyPage.onCreate(), e.createFromLink = !1)), e.appWin.clearStatusBusy()
    }
}), Ext.define("SYNO.SDS.SAN.LUN.EmptyMain", {
    extend: "SYNO.SDS.SAN.EmptyMainPanel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.callParent([e])
    },
    fillConfig: function(e) {
        var t = this,
            i = this.callParent([e]);
        return i.items.push({
            xtype: "label",
            text: SYNO.SDS.iSCSI.Utils.T("lun", "no_lun"),
            cls: "iscsi-empty-text"
        }), i.items.push({
            xtype: "label",
            style: {
                padding: "10px 0px 0px"
            }
        }), i.items.push({
            xtype: "syno_button",
            text: SYNO.SDS.iSCSI.Utils.T("common", "create"),
            btnStyle: "blue",
            handler: t.onCreate,
            scope: t
        }), i
    },
    onCreate: function() {
        var e = this,
            t = new SYNO.SDS.iSCSI.LUN.NormalMain({
                owner: e.owner,
                appWin: e.appWin
            });
        t.processData(), t.onCreate()
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.NormalMain", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.appWin, t.loaded = !1, t.canCreateLunTypes = {}, t.view = t.createView(), this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = this,
            i = {
                border: !1,
                layout: "fit",
                itemId: "iscsi_lun",
                cls: "syno-app-iscsi",
                tbar: this.toolbar = new Ext.Toolbar({
                    defaultType: "syno_button",
                    items: [{
                        text: SYNO.SDS.iSCSI.Utils.T("common", "create"),
                        handler: t.onCreate,
                        ref: "createBtn",
                        scope: t
                    }, {
                        text: SYNO.SDS.iSCSI.Utils.T("common", "alt_edit"),
                        handler: t.onEdit,
                        ref: "editBtn",
                        scope: t
                    }, {
                        text: SYNO.SDS.iSCSI.Utils.T("common", "delete"),
                        handler: t.onDelete,
                        ref: "removeBtn",
                        scope: t
                    }, {
                        text: SYNO.SDS.iSCSI.Utils.T("iscsilun", "clone"),
                        handler: t.onClone,
                        hidden: !(t.appWin.supportVAAI && t.appWin.isLio4x),
                        ref: "cloneBtn",
                        scope: t
                    }, {
                        text: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "iscsilun_convert"),
                        handler: t.onConvert,
                        ref: "convertBtn",
                        scope: t
                    }]
                }),
                items: t.view,
                listeners: {
                    activate: t.onActivate,
                    data_ready: t.onDataReady,
                    scope: t
                }
            };
        return t.defragMenu = new SYNO.ux.Menu({
            itemId: "defrag_menu",
            items: [{
                itemId: "start",
                text: SYNO.SDS.iSCSI.Utils.T("common", "start"),
                handler: t.onDefrag,
                disabled: !1,
                scope: t
            }, {
                itemId: "stop",
                text: SYNO.SDS.iSCSI.Utils.T("common", "stop"),
                handler: t.onStopDefrag,
                disabled: !1,
                scope: t
            }]
        }), this.toolbar.add({
            hidden: !0,
            text: SYNO.SDS.iSCSI.Utils.T("iscsilun", "defrag"),
            ref: "defragBtn",
            menu: t.defragMenu
        }), Ext.apply(i, e), i
    },
    createView: function() {
        var e = this,
            t = SYNO.SDS.iSCSI.UsageTpl(),
            i = SYNO.SDS.iSCSI.PropertyTpl(),
            n = SYNO.SDS.iSCSI.TargetTpl({
                scope: "targets",
                title: SYNO.SDS.iSCSI.Utils.T("trg", "mapped_target"),
                emptyText: SYNO.SDS.iSCSI.Utils.T("trg", "no_mapped_target")
            }),
            s = SYNO.SDS.iSCSI.TargetTpl({
                scope: "targets",
                title: SYNO.SDS.iSCSI.Utils.T("trg", "fibre_channel_ports"),
                emptyText: SYNO.SDS.iSCSI.Utils.T("trg", "no_mapped_target")
            }),
            a = SYNO.SDS.iSCSI.LunPrivTpl({
                scope: "lunpriv",
                allow_all: "allow_all"
            }),
            o = new Ext.XTemplate('<div class="item-detail-inner">', i.html, a.html, "<tpl if=\"mappingType =='iscsi'\">", n.html, "</tpl>", "<tpl if=\"mappingType =='fc'\">", s.html, "</tpl>", "</div>"),
            r = {
                appWin: e.appWin,
                owner: e,
                dataType: "iscsiLuns",
                itemId: "lunView",
                multiSelect: !0,
                usageTpl: t,
                detailTpl: o,
                store: e.createLunStore(),
                listeners: {
                    selectionchange: e.onSelectChange,
                    scope: e
                }
            };
        return new SYNO.SDS.iSCSI.DataView(r)
    },
    createLunStore: function() {
        var e = ["numId", "id", "iconPic", "iconCls", "statusIconCls", {
            name: "displayName",
            sortType: "asNaturalUCString"
        }, "property", "targets", "desc", "usage", "barWidth", "summaryStatus", "progressStatus", "status", "totalSize", "location", "lunpriv", "allow_all", "mappingType"];
        return new Ext.data.JsonStore({
            autoDestroy: !0,
            idProperty: "id",
            fields: e,
            sortInfo: {
                field: "displayName",
                direction: "ASC"
            }
        })
    },
    prepareSummary: function(e, t) {
        var i = SYNO.SDS.iSCSI.Utils,
            n = SYNO.SDS.iSCSI.Utils.LUNUsageProcess(e),
            s = n.totalSize,
            a = n.usedSize;
        if (t.iconPic = "iscsi-lun-icon", t.numId = e.get("lun_id"), t.status = e.get("status"), t.totalSize = s, t.usedSize = a, t.location = e.get("location"), t.id = e.get("uuid"), t.displayName = e.get("name"), e.isThinProvisioningLun() ? t.usage = String.format('<span class="san-color-blue">{0}</span>&nbsp;/&nbsp;{1}', i.SizeRender(a), i.SizeRender(s)) : t.usage = i.SizeRender(s), t.barWidth = 0 === s ? 0 : Math.floor(100 * a / s), t.summaryStatus = String.format("&nbsp;-&nbsp;{0}&nbsp;", e.getSummaryStatus(this.appWin.volumes, this.appWin.pools, this.appWin.isLowCapacityWriteEnable())), t.progressStatus = e.getProgress(), t.desc = "", "" === t.location);
        else if (e.isBlockLun()) {
            var o = e.get("location"),
                r = i.getLUNPoolInfo(this.appWin.pools, o).pool_id;
            t.desc = String.format(SYNO.SDS.iSCSI.Utils.T("volume", "volume_default_desc"), i.SpaceIDParser(r).str)
        } else t.desc = String.format(SYNO.SDS.iSCSI.Utils.T("volume", "volume_default_desc"), i.RootPathParser(t.location).str);
        e.isSinkLun() ? (t.iconCls = "iscsi-lun-icon-sink", t.desc += ", " + SYNO.SDS.iSCSI.Utils.T("iscsimgr", "sink_lun")) : e.isBtrfsLun() && e.isThinProvisioningLun() ? t.iconCls = "iscsi-lun-icon-btrfs" : e.isAdvancedLun() ? t.iconCls = "iscsi-lun-icon-file" : e.isThinProvisioningLun() ? t.iconCls = "iscsi-lun-icon-file" : (t.iconCls = "iscsi-lun-icon-block", "no_cache" !== e.get("flashcache_status") && (t.desc += ", " + SYNO.SDS.iSCSI.Utils.T("volume", "ssd_cache"))), this.appWin.supportFC && (e.isMappedFC() ? t.desc += ", " + SYNO.SDS.iSCSI.Utils.T("san_lun", "map_fc") : e.isMappedISCSI() && (t.desc += ", " + SYNO.SDS.iSCSI.Utils.T("san_lun", "map_iscsi"))), e.isActioning() ? t.statusIconCls = "iscsi-list-status-icon-acting" : e.isSummaryWarning(this.appWin.volumes, this.appWin.pools) ? t.statusIconCls = "iscsi-list-status-icon-warning" : e.isSummaryCrashed(this.appWin.volumes, this.appWin.pools, this.appWin.isLowCapacityWriteEnable()) && (t.statusIconCls = "iscsi-list-status-icon-crashed")
    },
    prepareUiData: function() {
        var e, t = this,
            i = t.appWin.iscsiLuns.getAll();
        delete t.uiData, t.uiData = [], Ext.each(i, function(i) {
            e = {}, t.prepareSummary(i, e), t.prepareFileLunProperty(i, e), t.prepareMap(i, e), t.preparePriv(i, e), t.uiData.push(e)
        }, t)
    },
    prepareFileLunProperty: function(e, t) {
        var i, n, s = SYNO.SDS.iSCSI.Utils,
            a = e.getSpaceStatus(this.appWin.volumes, this.appWin.pools),
            o = e.getSpaceFreeSize(this.appWin.volumes, this.appWin.pools);
        i = e.getSummaryStatus(this.appWin.volumes, this.appWin.pools, this.appWin.isLowCapacityWriteEnable()), n = "", t.property = [], e.isLunOwnedByCinder() && t.property.push({
            name: SYNO.SDS.iSCSI.Utils.T("iscsilun", "user"),
            value: "Openstack Cinder"
        });
        var r = "";
        e.isHardLimit() || e.isThinProvisioningLun() && o < SYNO.SDS.iSCSI.TP_HARD_THRESHOLD_DEFAULT_SIZE && this.appWin.isLowCapacityWriteEnable() ? r = e.isHardLimit() ? o > SYNO.SDS.iSCSI.TP_HARD_THRESHOLD_MIN_SIZE && !this.appWin.isLowCapacityWriteEnable() ? SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_hard_limit_without_low_capacity_tip") : SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_hard_limit_tip") : SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_low_capacity_write_on_tip") : e.isSoftLimit() && (r = SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_status_soft_limit_tip")), t.property.push({
            name: SYNO.SDS.iSCSI.Utils.T("volume", "volume_volumestatus"),
            value: i + n,
            iconTip: r
        }, {
            name: SYNO.SDS.iSCSI.Utils.T("san_lun", "desc"),
            value: e.get("description")
        }, {
            name: SYNO.SDS.iSCSI.Utils.T("volume", "volume_totalsize"),
            value: s.SizeRender(e.get("size"))
        });
        var l = "";
        e.isThinProvisioningLun() && (l = SYNO.SDS.iSCSI.Utils.T("lun", "lun_used_size_tip"), t.property.push({
            name: SYNO.SDS.iSCSI.Utils.T("volume", "volume_used"),
            value: s.SizeRender(e.get("allocated_size")),
            iconTip: l
        })), e.isFileLun() ? (t.property.push({
            name: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "space_allocation_type"),
            value: e.isThinProvisioningLun() ? SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_thin_provisioning") : SYNO.SDS.iSCSI.Utils.T("iscsimgr", "iscsitrg_thick_provisioning")
        }), this.appWin.supportVAAI && t.property.push({
            name: e.isBtrfsLun() ? SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_vaai") : SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_adv_feature_legacy"),
            value: e.getAdvFeatureDesc()
        })) : "no_cache" !== e.get("flashcache_status") && t.property.push({
            name: SYNO.SDS.iSCSI.Utils.T("volume", "ssd_cache"),
            value: e.cacheCrashed() ? SYNO.SDS.iSCSI.Utils.T("volume", "volume_status_crashed") : SYNO.SDS.iSCSI.Utils.T("common", "yes")
        });
        var S = "";
        if (e.isBlockLun()) {
            var d = s.getLUNPoolInfo(this.appWin.pools, e.get("location")).pool_id;
            S = s.SpaceIDParser(d).str
        } else S = s.RootPathParser(e.get("location")).str;
        if (t.property.push({
                name: SYNO.SDS.iSCSI.Utils.T("volume", "volume_raid_location"),
                value: S
            }), e.isThinProvisioningLun()) {
            var c = s.StatusNameRender(a);
            o < SYNO.SDS.iSCSI.TP_HARD_THRESHOLD_MIN_SIZE ? c += " (" + SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_volume_status_hard_limit") + ")" : o < SYNO.SDS.iSCSI.TP_HARD_THRESHOLD_DEFAULT_SIZE ? c += " (" + SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_volume_status_freesize_less_than_default_size") + ")" : e.isSoftLimit() && (c += " (" + SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_volume_status_soft_limit") + ")"), t.property.push({
                name: SYNO.SDS.iSCSI.Utils.T("volume", "volume_status"),
                value: c
            })
        }
        var p = e.get("family_config"),
            u = p.parent_snapshot_time,
            h = p.parent_lun_name;
        if ("" !== h) {
            if (0 !== u) {
                var m = new Date(1e3 * u);
                h += " ( " + SYNO.SDS.DateTimeFormatter(m, {
                    type: "datetimesec"
                }) + " )"
            }
            t.property.push({
                name: SYNO.SDS.iSCSI.Utils.T("iscsilun", "source"),
                value: h
            })
        }
    },
    prepareMap: function(e, t) {
        t.targets = this.appWin.getMappedTrgs(e.get("uuid"), !0), t.mappingType = e.get("mappingType")
    },
    preparePriv: function(e, t) {
        t.lunpriv = this.appWin.getLunACLs(e.get("uuid")), "allow_all" === e.get("privilege") ? t.allow_all = !0 : t.allow_all = !1
    },
    onActivate: function() {
        var e = this;
        e.loaded || e.appWin.setStatusBusy(null, null, 50), e.appWin.fireEvent("poll_activate")
    },
    resetBtnStatus: function() {
        this.toolbar.createBtn.setDisabled(!this.canCreate())
    },
    prepareVolumeMapping: function() {
        var e = this,
            t = e.appWin.volumes;
        e.mappedVolume = {}, Ext.each(t, function(t) {
            e.mappedVolume[t.volume_path] = t
        })
    },
    onDataReady: function() {
        var e = this,
            t = e.view.store;
        e.loaded || (e.appWin.clearStatusBusy(), e.loaded = !0), e.processData(), e.prepareVolumeMapping(), e.prepareUiData(), t.suspendEvents(!0), t.loadData(e.uiData, !1), t.resumeEvents(), e.resetBtnStatus(), 0 < e.view.store.getCount() && 0 === e.view.getSelectedItemIds().length && e.view.select(0, !0, !0), e.onSelectChange(), e.appWin.fireEvent("afterlaunchlunpage"), e.layoutDrawn = !0
    },
    processData: function() {
        var e = this;
        e.appWin.genLunMappingType(), e.appWin.genLunPrivilegeType(), e.canCreateLunTypes = e.appWin.getCanCreateLunTypes()
    },
    onSelectChange: function() {
        var e = this,
            t = e.view.getSelectedItems(),
            i = e.toolbar.defragBtn,
            n = e.toolbar.editBtn,
            s = e.toolbar.cloneBtn,
            a = e.toolbar.convertBtn;
        if (n.disable(), s.disable(), a.disable(), e.toolbar.removeBtn.setDisabled(!e.canDelete(t)), 1 === t.length) {
            var o = t[0],
                r = "defragging" === o.get("status");
            o.isLunOwnedByCinder() || n.setDisabled(!e.canEdit(o)), o.isFileLun() && e.appWin.supportVAAI && e.appWin.isLio4x && s.setDisabled(!e.canClone(o)), a.setVisible(o.isAdvancedLun() && e.appWin.supportBtrfsLun), a.setDisabled(!e.canConvert(o)), i.setVisible(o.isBtrfsLun() && o.isThinProvisioningLun() && !o.isSinkLun()), i.setDisabled(!r && !e.canDefrag(o)), i.menu.getComponent("start").setDisabled(r), i.menu.getComponent("stop").setDisabled(!r)
        } else i.setVisible(!1)
    },
    setFocus: function(e) {
        this.view.focusNode(e), this.view.select(e, !1, !1);
        var t = Ext.get(e);
        return t && "true" != t.getAttribute("aria-expanded") && this.view.toggleDetail(t, !0), !0
    },
    canCreate: function() {
        var e = this.toolbar.createBtn;
        return this.appWin.isUpToLunMaxCount() ? (e.setTooltip(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_up_to_max")), !1) : (e.setTooltip(), !0)
    },
    canDelete: function(e) {
        var t = this;
        return 0 !== e.length && (!e.filter(function(e) {
            return "read_only" === e.getSpaceStatus(t.appWin.volumes, t.appWin.pools)
        }).length && !e.some(function(e) {
            return e.isDeleting()
        }))
    },
    canEdit: function(e) {
        return e && !e.isActioning() && !e.cacheMissing() && !e.cacheCrashed() && "crashed" !== e.getSpaceStatus(this.appWin.volumes, this.appWin.pools) && "read_only" !== e.getSpaceStatus(this.appWin.volumes, this.appWin.pools)
    },
    canClone: function(e) {
        if (this.appWin.isUpToLunMaxCount()) {
            return this.toolbar.cloneBtn.setTooltip(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_up_to_max")), !1
        }
        return !(!e || e.isSinkLun() || e.isActioning() || e.isCrashed() || "crashed" === e.getSpaceStatus(this.appWin.volumes, this.appWin.pools) || "read_only" === e.getSpaceStatus(this.appWin.volumes, this.appWin.pools))
    },
    canConvert: function(e) {
        var t = this,
            i = t.toolbar.convertBtn;
        return !!e && (i.setTooltip(""), t.appWin.isUpToLunMaxCount() ? (i.setTooltip(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_up_to_max")), !1) : !e.isActioning() && !e.isCrashed() && "read_only" !== e.getSpaceStatus(t.appWin.volumes, t.appWin.pools) && "crashed" !== e.getSpaceStatus(t.appWin.volumes, t.appWin.pools))
    },
    canDefrag: function(e) {
        return e && !e.isActioning() && !e.isCrashed() && "crashed" !== e.getSpaceStatus(this.appWin.volumes, this.appWin.pools) && "read_only" !== e.getSpaceStatus(this.appWin.volumes, this.appWin.pools)
    },
    onCreate: function() {
        0 === Object.keys(this.canCreateLunTypes).length || -1 === Object.values(this.canCreateLunTypes).indexOf(!0) ? this.appWin.getMsgBox().confirm("", SYNO.SDS.iSCSI.Utils.T("san_lun", "create_lun_no_volume"), function(e) {
            "ok" === e && SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance", {
                fn: "SYNO.SDS.StorageManager.Pool.Main"
            })
        }, this, {
            ok: {
                text: SYNO.SDS.iSCSI.Utils.T("common", "set_up_now")
            },
            cancel: {
                text: SYNO.SDS.iSCSI.Utils.T("common", "later")
            }
        }) : this.openWindow("WizardCreate", {
            canCreate: this.canCreateLunTypes
        })
    },
    onEdit: function() {
        var e = this,
            t = e.view.getSelectedItem();
        t && e.openWindow("Edit", {
            lun: t
        })
    },
    onDelete: function() {
        var e = this,
            t = e.view.getSelectedItems();
        0 !== t.length && e.openWindow("Delete", {
            luns: t
        })
    },
    onClone: function() {
        var e = this,
            t = e.view.getSelectedItem();
        t && e.openWindow("Clone", {
            lun: t
        })
    },
    onConvert: function() {
        var e = this,
            t = e.view.getSelectedItem();
        t && e.openWindow("WizardConvert", {
            lun: t
        })
    },
    doDefrag: function(e, t) {
        var i = this;
        i.sendWebAPI({
            api: "SYNO.Core.ISCSI.LUN",
            version: 1,
            method: t ? "defrag" : "stop_defrag",
            params: {
                uuid: e.get("uuid")
            },
            scope: i,
            callback: function(e, t) {
                e || SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(this, t), i.owner.setStatusBusy(), i.loaded = !1, i.appWin.fireEvent("poll_activate")
            }
        })
    },
    onDefrag: function(e) {
        var t, i, n, s, a = this,
            o = a.view.getSelectedItem(),
            r = SYNO.SDS.iSCSI.Utils;
        o && (t = o.getSpace(this.appWin.volumes, this.appWin.pools), n = parseInt(t.size_free_byte, 10), i = parseInt(o.get("allocated_size"), 10), s = '<span class="blue-status" style="font-weight:bold;">' + r.SizeRender(i) + "</span>", a.sendWebAPI({
            api: "SYNO.Core.ISCSI.LUN",
            version: 1,
            method: "list_snapshot",
            params: {
                src_lun_uuid: o.get("uuid"),
                is_count_only: !0
            },
            scope: a,
            callback: function(e, t) {
                var r;
                if (e && t.count > 0) {
                    if (i > n) return void a.appWin.getMsgBox().alert(SYNO.SDS.iSCSI.Utils.T("iscsilun", "defrag"), String.format(SYNO.SDS.iSCSI.Utils.T("iscsilun", "defrag_alert_insufficient_space"), s));
                    r = String.format(SYNO.SDS.iSCSI.Utils.T("iscsilun", "defrag_confirm_with_snap"), s)
                } else r = SYNO.SDS.iSCSI.Utils.T("iscsilun", "defrag_confirm_without_snap");
                a.appWin.getMsgBox().confirm(SYNO.SDS.iSCSI.Utils.T("iscsilun", "defrag"), r, function(e) {
                    "yes" === e && a.doDefrag(o, !0)
                }, this, {
                    yes: {
                        text: SYNO.SDS.iSCSI.Utils.T("common", "continue")
                    },
                    no: {
                        text: SYNO.SDS.iSCSI.Utils.T("common", "cancel")
                    }
                })
            }
        }))
    },
    onStopDefrag: function(e) {
        var t = this,
            i = t.view.getSelectedItem();
        i && t.appWin.getMsgBox().confirm(SYNO.SDS.iSCSI.Utils.T("iscsilun", "defrag"), SYNO.SDS.iSCSI.Utils.T("common", "task_cancel_confirm"), function(e) {
            "yes" === e && t.doDefrag(i, !1)
        })
    },
    openWindow: function(e, t) {
        var i = this,
            n = new SYNO.SDS.iSCSI.LUN[e](Ext.apply({
                appWin: i.appWin,
                owner: i.owner
            }, t));
        i.mon(n, "close", function() {
            Ext.isFunction(n.hideFromOwner) && n.hideFromOwner(), n.isDataChanged && (i.owner.setStatusBusy(), i.loaded = !1, i.appWin.fireEvent("poll_activate"))
        }, i, {
            single: !0
        }), n.open()
    }
}), Ext.define("SYNO.SDS.iSCSI.Snapshot.TakeSnapshot", {
    extend: "SYNO.SDS.iSCSI.ModalWindow",
    constructor: function(e) {
        var t, i = this,
            n = !1;
        i.appWin = e.appWin, i.owner = e.owner, i.luns = e.luns, i.snapshot = e.snapshot, i.connectedLuns = i.getMappedConnectedLuns(i.luns, i.appWin.iscsiTargets.getAll()), n = i.connectedLuns.length > 0, t = {
            title: e.title,
            width: 572,
            height: n ? 436 : 250,
            resizable: !1,
            buttons: [{
                xtype: "syno_button",
                text: SYNO.SDS.iSCSI.Utils.T("common", "alt_cancel"),
                scope: i,
                handler: i.onCancel
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                text: SYNO.SDS.iSCSI.Utils.T("common", "alt_apply"),
                scope: i,
                handler: i.onSave
            }],
            items: [i.createForm(n)]
        }, Ext.QuickTips.init(), i.callParent([Ext.apply(t, e)])
    },
    getMappedConnectedLuns: function(e, t) {
        return void 0 === e || void 0 === t ? [] : e.filter(function(e) {
            return t.some(function(t) {
                return t.get("mapped_luns").some(function(i) {
                    return i.lun_uuid === e.get("uuid") && "connected" === t.get("status")
                })
            })
        })
    },
    formatLunArray: function(e) {
        if (void 0 === e) return "";
        var t = e.map(function(e) {
            return e.get("name")
        });
        return 0 < t.length ? t.join(", ") : ""
    },
    getForm: function() {
        return this.getComponent("lunSnapshot").getForm()
    },
    onOpen: function() {
        var e = this;
        e.callParent(arguments), e.initValues(), e.addTip()
    },
    addTip: function() {
        var e = this;
        SYNO.ux.AddTip(e.getForm().findField("lock").getEl(), Ext.util.Format.htmlEncode(SYNO.SDS.iSCSI.Utils.T("iscsilun", "snapshot_lock_notify")))
    },
    initValues: function() {
        this.getForm().setValues({
            type: "app"
        })
    },
    onCancel: function() {
        if (this.getForm().isDirty()) return void this.confirmLostChangePromise({
            save: function() {
                this.onSave()
            },
            dontSave: function() {
                this.close()
            },
            cancel: function() {}
        }, this);
        this.close()
    },
    createForm: function(e) {
        var t = this;
        return {
            xtype: "form",
            itemId: "lunSnapshot",
            border: !1,
            trackResetOnLoad: !0,
            defaults: {
                width: 260,
                labelWidth: 200
            },
            items: [{
                xtype: "syno_displayfield",
                htmlEncode: !1,
                height: 8
            }, {
                xtype: "syno_textfield",
                name: "desc",
                itemId: "desc",
                maxlength: 255,
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("share", "share_comment")
            }, {
                xtype: "syno_combobox",
                name: "type",
                hiddenName: "type",
                itemId: "type",
                hidden: !e,
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("iscsilun", "snapshot_method"),
                store: [
                    ["app", SYNO.SDS.iSCSI.Utils.T("iscsilun", "snapshot_application_consistent")],
                    ["crash", SYNO.SDS.iSCSI.Utils.T("iscsilun", "snapshot_crash_consistent")]
                ]
            }, {
                xtype: "syno_checkbox",
                name: "lock",
                itemId: "lock",
                boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsilun", "snapshot_lock"),
                checked: !0
            }, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                width: 528,
                hidden: !e,
                value: String.format('<span class="red-status"><b>{0}</b>: </span>{1}', SYNO.SDS.iSCSI.Utils.T("widget", "attention_status"), String.format(SYNO.SDS.iSCSI.Utils.T("snapmgr", "clone_snapshot_inconsistent_warning_multiple_sc"), '<a href="https://www.synology.com/en-global/support/download/' + _D("upnpmodelname", "") + '/#utilities" target="_blank">', "</a>", '<a id="' + (t.helpLinkId = Ext.id()) + '"class="link-font" href="">', "</a>")),
                listeners: {
                    afterrender: function(e) {
                        t.mon(Ext.get(t.helpLinkId), "click", function(e) {
                            e.preventDefault(), SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                                topic: "SYNO.SDS.iSCSI.Application:snapshot.html"
                            }, !1)
                        }, t)
                    }
                }
            }, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                name: "connected_luns",
                itemId: "connected_luns",
                width: 410,
                autoHeight: !0,
                hidden: !e,
                value: e ? String.format('<div ext:qtip="{0}">{1}</div>', t.formatLunArray(t.connectedLuns), t.formatLunArray(t.connectedLuns)) : ""
            }]
        }
    },
    genParams: function(e, t, i) {
        return {
            desc: e,
            type: t,
            lock: i
        }
    },
    prepareCreateParams: function(e, t, i, n, s) {
        var a;
        return a = {
            api: "SYNO.Core.ISCSI.LUN",
            method: "take_snapshot",
            version: 1,
            src_lun_uuid: e,
            description: i,
            is_locked: t
        }, void 0 !== n && Ext.apply(a, {
            is_app_consistent: n
        }), void 0 !== s && Ext.apply(a, {
            taken_by: s
        }), a
    },
    onSave: function() {
        var e = this,
            t = e.getForm();
        if (t.isValid()) {
            e.setStatusBusy({
                text: SYNO.SDS.iSCSI.Utils.T("common", "saving")
            });
            var i = t.findField("desc").getValue(),
                n = t.findField("type").getValue(),
                s = "app" === n,
                a = t.findField("lock").getValue(),
                o = [];
            Ext.each(e.luns, function(t) {
                var n = t.get("uuid"),
                    r = e.prepareCreateParams(n, a, i, s, "user");
                o.push(r)
            }, e), e.sendWebAPI({
                api: "SYNO.Entry.Request",
                version: 2,
                method: "request",
                params: {
                    mode: "parallel",
                    compound: o
                },
                scope: e,
                callback: function(t, i, n) {
                    t && !i.has_fail || e.owner.getMsgBox().alert(void 0, SYNO.SDS.iSCSI.Utils.checkLUNSnapCompoundError.call(e, t, i, n)), e.clearStatusBusy(), e.fireEvent("smart_close"), e.close()
                }
            })
        }
    }
}), Ext.define("SYNO.SDS.iSCSI.Snapshot.CloneSnapshot", {
    extend: "SYNO.SDS.iSCSI.ModalWindow",
    utils: SYNO.SDS.iSCSI.Utils,
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.owner = e.owner, i.lun = e.lun, i.snapshot = e.snapshot, t = {
            title: e.title,
            width: 625,
            height: 500,
            resizable: !1,
            buttons: [{
                xtype: "syno_button",
                text: SYNO.SDS.iSCSI.Utils.T("common", "alt_cancel"),
                scope: i,
                handler: i.onCancel
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                text: SYNO.SDS.iSCSI.Utils.T("iscsilun", "clone"),
                scope: i,
                handler: i.onSave
            }],
            items: [i.createForm()]
        }, i.callParent([Ext.apply(t, e)])
    },
    getForm: function() {
        return this.getComponent("snapshotClone").getForm()
    },
    onCancel: function() {
        if (this.getForm().isDirty()) return void this.confirmLostChangePromise({
            save: function() {
                this.onSave()
            },
            dontSave: function() {
                this.close()
            },
            cancel: function() {}
        }, this);
        this.close()
    },
    createForm: function() {
        var e = this,
            t = [
                [!1, SYNO.SDS.iSCSI.Utils.T("common", "no")],
                [!0, SYNO.SDS.iSCSI.Utils.T("common", "yes")]
            ],
            i = e.appWin.supportVAAI;
        return e.cloneInfo = e.prepareCloneInfo(), {
            xtype: "form",
            itemId: "snapshotClone",
            border: !1,
            trackResetOnLoad: !0,
            fieldWidth: 280,
            labelWidth: 280,
            items: [{
                xtype: "syno_textfield",
                name: "name",
                vtype: "iscsilunname",
                itemId: "name",
                maxlength: 128,
                allowBlank: !1,
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("common", "name"),
                value: e.appWin.genNewLunName(),
                validator: function(t) {
                    return !!e.appWin.isUniqueLunName(t) || SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_lun_name_exists")
                }
            }, {
                xtype: "syno_displayfield",
                name: "location",
                itemId: "location",
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("volume", "volume_raid_location"),
                value: e.cloneInfo.location
            }, {
                xtype: "syno_displayfield",
                name: "thin_provision",
                itemId: "thin_provision",
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "space_allocation_type"),
                value: e.cloneInfo.thin_provision,
                hidden: !i,
                store: t
            }, {
                xtype: "syno_displayfield",
                name: "unmap",
                itemId: "unmap",
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "unmap_command"),
                value: e.cloneInfo.unmap,
                hidden: !i
            }, {
                xtype: "syno_displayfield",
                name: "extent_based",
                itemId: "extent_based",
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_vaai"),
                value: e.cloneInfo.extent_based,
                hidden: !i
            }, {
                xtype: "syno_displayfield",
                name: "size",
                itemId: "size",
                fieldLabel: String.format("{0} ({1})", SYNO.SDS.iSCSI.Utils.T("volume", "volume_totalsize"), SYNO.SDS.iSCSI.Utils.T("common", "size_gb")),
                value: e.cloneInfo.size
            }]
        }
    },
    prepareCloneInfo: function() {
        var e = this,
            t = e.lun,
            i = e.appWin.volumes,
            n = e.appWin.supportVAAI,
            s = {},
            a = e.appWin.iscsiLuns.getById(t.get("uuid"));
        s.size = e.utils.GetSizeGB(t.get("size"), 0);
        var o, r;
        return Ext.each(i, function(i) {
            if (t.get("location") === i.volume_path) return o = parseInt(i.size_free_byte, 10), r = i.fs_type, s.location = String.format("{0} ({1}: {2} {3}) - {4}", i.display_name, SYNO.SDS.iSCSI.Utils.T("volume", "volume_freesize"), e.utils.GetSizeGB(o, 0), SYNO.SDS.iSCSI.Utils.T("common", "size_gb"), r), !0
        }), n && (s.thin_provision = t.isThinProvisioningLun() ? SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_thin_provisioning") : SYNO.SDS.iSCSI.Utils.T("iscsimgr", "iscsitrg_thick_provisioning"), s.extent_based = a.getAdvFeatureDesc(), s.unmap = a.isEnableUnmap() ? SYNO.SDS.iSCSI.Utils.T("common", "enabled") : SYNO.SDS.iSCSI.Utils.T("common", "disabled")), s
    },
    onSave: function() {
        var e = this,
            t = e.getForm();
        if (t.isValid()) {
            e.setStatusBusy({
                text: SYNO.SDS.iSCSI.Utils.T("common", "saving")
            });
            var i = {
                src_lun_uuid: e.lun.get("uuid"),
                snapshot_uuid: e.snapshot.uuid,
                cloned_lun_name: t.findField("name").getValue()
            };
            e.sendWebAPI({
                api: "SYNO.Core.ISCSI.LUN",
                version: 1,
                method: "clone_snapshot",
                params: i,
                scope: e,
                callback: function(t, i) {
                    e.clearStatusBusy(), t ? e.close() : SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(this, i)
                }
            })
        }
    }
}), Ext.define("SYNO.SDS.iSCSI.Snapshot.Edit", {
    extend: "SYNO.SDS.iSCSI.ModalWindow",
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.owner = e.owner, i.luns = e.luns, i.snapshot = e.snapshot, t = {
            title: e.title,
            width: 450,
            height: 250,
            resizable: !1,
            buttons: [{
                xtype: "syno_button",
                text: SYNO.SDS.iSCSI.Utils.T("common", "alt_cancel"),
                scope: i,
                handler: i.onCancel
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                disabled: _S("demo_mode"),
                tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                text: SYNO.SDS.iSCSI.Utils.T("common", "alt_apply"),
                scope: i,
                handler: i.onSave
            }],
            items: [i.createForm()]
        }, Ext.QuickTips.init(), i.callParent([Ext.apply(t, e)])
    },
    getForm: function() {
        return this.getComponent("lunSnapshot").getForm()
    },
    onOpen: function() {
        var e = this;
        e.callParent(arguments), e.initValues(), e.addTip()
    },
    addTip: function() {
        var e = this;
        SYNO.ux.AddTip(e.getForm().findField("lock").getEl(), Ext.util.Format.htmlEncode(SYNO.SDS.iSCSI.Utils.T("iscsilun", "snapshot_lock_notify")))
    },
    initValues: function() {
        var e, t = this;
        e = new Date(1e3 * t.snapshot.time), t.getForm().setValues(t.snapshot), t.getForm().setValues({
            time: SYNO.SDS.DateTimeFormatter(e, {
                type: "datetimesec"
            })
        })
    },
    onCancel: function() {
        if (this.getForm().isDirty()) return void this.confirmLostChangePromise({
            save: function() {
                this.onSave()
            },
            dontSave: function() {
                this.close()
            },
            cancel: function() {}
        }, this);
        this.close()
    },
    createForm: function() {
        return {
            xtype: "form",
            itemId: "lunSnapshot",
            border: !1,
            trackResetOnLoad: !0,
            defaults: {
                width: 250,
                labelWidth: 150
            },
            items: [{
                xtype: "syno_textfield",
                name: "desc",
                itemId: "desc",
                maxlength: 255,
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("share", "share_comment")
            }, {
                xtype: "syno_checkbox",
                name: "lock",
                itemId: "lock",
                boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsilun", "snapshot_lock"),
                checked: !0
            }]
        }
    },
    prepareEditParams: function(e, t, i) {
        return {
            api: "SYNO.Core.ISCSI.LUN",
            method: "set_snapshot",
            version: 1,
            snapshot_uuid: e,
            description: i,
            is_user_locked: t
        }
    },
    onSave: function() {
        var e = this,
            t = e.getForm();
        if (!t.isDirty()) return void e.close();
        if (t.isValid()) {
            e.setStatusBusy({
                text: SYNO.SDS.iSCSI.Utils.T("common", "saving")
            });
            var i = t.findField("desc").getValue(),
                n = t.findField("lock").getValue(),
                s = [],
                a = e.snapshot.uuid,
                o = e.prepareEditParams(a, n, i);
            s.push(o), e.sendWebAPI({
                api: "SYNO.Entry.Request",
                version: 2,
                method: "request",
                params: {
                    mode: "parallel",
                    compound: s
                },
                scope: e,
                callback: function(t, i, n) {
                    t && !i.has_fail || e.owner.getMsgBox().alert(void 0, SYNO.SDS.iSCSI.Utils.checkLUNSnapCompoundError.call(e, t, i, n)), e.clearStatusBusy(), e.close()
                }
            })
        }
    }
}), Ext.define("SYNO.SDS.iSCSI.Snapshot.LUNSnapList", {
    extend: "SYNO.SDS.iSCSI.ModalWindow",
    constructor: function(e) {
        var t, i = this;
        i.appWin = e.appWin, i.owner = e.owner, i.lun = e.lun, i.mainPage = e.mainPage, i.canManage = i.lun.canManage(), i.launchfrom3rd = e.launchfrom3rd || !1, i.snapshotuuidfrom3rd = e.snapshotuuidfrom3rd, i.isOwnedByCinder = i.lun.isLunOwnedByCinder(), i.launched3rd = !1, t = {
            title: e.title,
            layout: "fit",
            items: [],
            minWidth: 760,
            minHeight: 450,
            width: 760,
            height: 450,
            useStatusBar: !0,
            closable: !0,
            border: !1,
            buttons: [{
                text: SYNO.SDS.iSCSI.Utils.T("common", "close"),
                scope: this,
                handler: this.onCancel
            }]
        }, i.callParent([Ext.apply(t, e)])
    },
    initComponent: function() {
        this.items.push(this.createPanel()), this.callParent(arguments)
    },
    getGrid: function() {
        return this.get("lunSnapshots")
    },
    getSelections: function() {
        return this.getGrid().getSelectionModel().getSelections()
    },
    getSelected: function() {
        return this.getGrid().getSelectionModel().getSelected()
    },
    getButton: function(e) {
        return this.getGrid().getTopToolbar().get(e)
    },
    initEvents: function() {
        this.callParent(arguments)
    },
    onSelectionChange: function(e) {
        var t = this,
            i = e.getCount(),
            n = !1,
            s = t.lun.volume_crashed,
            a = t.lun.volume_read_only,
            o = t.lun.canManage();
        Ext.each(e.selections.items, function(e) {
            if ("Healthy" !== e.data.status.type && "Unhealthy" !== e.data.status.type) return n = !0, !1
        }), t.getButton("btDelete").disable(), t.getButton("btEdit").disable(), t.getButton("btRestore").disable(), t.getButton("btClone").disable(), t.getButton("btClone").setTooltip(), 0 === i || !1 !== n || s || a || !o || t.getButton("btDelete").enable(), 1 !== i || !1 !== n || s || a || !o || t.getButton("btEdit").enable(), 1 !== i || t.isLunActioning() || t.isSinkLun() || a || t.getButton("btRestore").enable(), 1 !== i || a || (t.appWin.isUpToLunMaxCount() ? t.getButton("btClone").setTooltip(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_up_to_max")) : t.getButton("btClone").enable())
    },
    onOpen: function() {
        var e = this;
        e.callParent(arguments), e.startPollingTask()
    },
    onCancel: function() {
        this.close()
    },
    startPollingTask: function() {
        var e = this;
        Ext.isDefined(e.storePollingTask) || (e.storePollingTask = e.addWebAPITask({
            api: "SYNO.Core.ISCSI.LUN",
            method: "list_snapshot",
            version: 1,
            params: {
                src_lun_uuid: e.lun.get("uuid"),
                additional: ["locked_app_keys"]
            },
            interval: 5e3,
            callback: function(t, i) {
                if (!t) return void SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(e, i);
                var n = [];
                Ext.each(i.snapshots, function(e) {
                    var t = {
                        sid: e.snapshot_id,
                        uuid: e.uuid,
                        desc: e.description,
                        snapshot_time: e.snapshot_time,
                        status: {
                            progress: {
                                percent: -1,
                                step: "waiting"
                            },
                            type: e.status
                        },
                        canClone: !0,
                        type: e.is_app_consistent ? "app" : "crash",
                        lock: e.is_user_locked,
                        is_locked_by_app: 0 < e.locked_app_keys.length,
                        total_size: e.total_size
                    };
                    n.push(t)
                }, this), e.loadGrid({
                    data: n
                }), e.launchfrom3rd && !e.launched3rd && e.snapshotCheckingAndCloneFrom3rdApp(n)
            }
        })), !0 !== e.storePollingTask.running && (e.setLoadingMask(), e.storePollingTask.start())
    },
    stopPollingTask: function() {
        var e = this.storePollingTask;
        Ext.isDefined(e) && !0 === e.running && e.stop()
    },
    setLoadingMask: function() {
        this.setStatusBusy({
            text: SYNO.SDS.iSCSI.Utils.T("common", "loading")
        }), this.loadingMask = !0
    },
    clearLoadingMask: function() {
        var e = this;
        !0 === e.loadingMask && (e.clearStatusBusy(), e.loadingMask = !1)
    },
    loadGrid: function(e) {
        var t, i, n = this;
        void 0 !== n.getGrid() && (t = n.getGrid().getStore(), t.loadData(e), i = n.getGrid().getTopToolbar().get("search").getValue(), "" !== i && t.filter("desc", i, !0), n.clearLoadingMask())
    },
    createPanel: function() {
        var e = this,
            t = new Ext.data.JsonStore({
                autoDestroy: !0,
                pruneModifiedRecords: !0,
                sortInfo: {
                    field: "snapshot_time",
                    direction: "DESC"
                },
                idProperty: "sid",
                root: "data",
                fields: ["sid", "uuid", "desc", "snapshot_time", "status", "canClone", "type", "lock", "is_locked_by_app", "total_size"]
            });
        e.store = t;
        var i = [{
                id: "snapshot_time",
                header: SYNO.SDS.iSCSI.Utils.T("time", "time_time"),
                dataIndex: "snapshot_time",
                width: 170,
                renderer: function(e) {
                    var t = new Date(1e3 * e);
                    return SYNO.SDS.DateTimeFormatter(t, {
                        type: "datetimesec"
                    })
                }
            }, {
                id: "snapshot_method",
                header: SYNO.SDS.iSCSI.Utils.T("iscsilun", "snapshot_method"),
                dataIndex: "type",
                width: 160,
                renderer: function(e) {
                    return "app" === e ? SYNO.SDS.iSCSI.Utils.T("iscsilun", "snapshot_application_consistent") : SYNO.SDS.iSCSI.Utils.T("iscsilun", "snapshot_crash_consistent")
                }
            }, {
                id: "desc",
                header: SYNO.SDS.iSCSI.Utils.T("share", "share_comment"),
                dataIndex: "desc",
                width: 190,
                renderer: SYNO.SDS.iSCSI.Utils.TipRender
            }, {
                id: "status",
                header: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_status"),
                dataIndex: "status",
                width: 70,
                renderer: SYNO.SDS.Utils.StorageUtils.UiRenderHelper.SnapShotStatusRender
            }, {
                id: "lock",
                header: SYNO.SDS.iSCSI.Utils.T("iscsilun", "snapshot_lock"),
                dataIndex: "lock",
                width: 45,
                renderer: SYNO.SDS.iSCSI.Utils.UIRender.lockIconRenderer,
                align: "center"
            }],
            n = {
                defaultType: "syno_button",
                items: [{
                    text: SYNO.SDS.iSCSI.Utils.T("iscsilun", "clone"),
                    itemId: "btClone",
                    handler: this.snapshotClone,
                    disabled: !0,
                    scope: this
                }, {
                    text: SYNO.SDS.iSCSI.Utils.T("common", "delete"),
                    itemId: "btDelete",
                    handler: this.snapshotDelete,
                    hidden: this.isOwnedByCinder,
                    disabled: !0,
                    scope: this
                }, {
                    text: SYNO.SDS.iSCSI.Utils.T("iscsilun", "restore"),
                    itemId: "btRestore",
                    handler: this.snapshotRestore,
                    hidden: this.isOwnedByCinder,
                    disabled: !0,
                    scope: this
                }, {
                    text: SYNO.SDS.iSCSI.Utils.T("common", "alt_edit"),
                    itemId: "btEdit",
                    handler: this.snapshotEdit,
                    hidden: this.isOwnedByCinder,
                    disabled: !0,
                    scope: this
                }, "->", new SYNO.SDS.iSCSI.Lun.TextFilter({
                    iconStyle: "search",
                    itemId: "search",
                    store: t,
                    localFilter: !0,
                    localFilterField: "desc"
                })]
            },
            s = new SYNO.ux.PageLessToolbar({
                store: e.store,
                displayInfo: !0,
                showRefreshBtn: !1
            }),
            a = {
                forceFit: !0,
                onLoad: Ext.emptyFn,
                listeners: {
                    beforerefresh: function(e) {
                        e.scrollTop = e.scroller.dom.scrollTop
                    },
                    refresh: function(e) {
                        e.scroller.dom.scrollTop = e.scrollTop
                    }
                }
            };
        return {
            layout: "fit",
            xtype: "syno_gridpanel",
            itemId: "lunSnapshots",
            style: {
                padding: "16px 20px 0px 20px"
            },
            tbar: n,
            bbar: s,
            store: t,
            columns: i,
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: !1,
                listeners: {
                    selectionchange: e.onSelectionChange,
                    scope: e
                }
            }),
            listeners: {
                scope: e,
                activate: e.onActivate,
                rowdblclick: {
                    scope: e,
                    fn: function(t, i, n) {
                        e.store.getAt(i) && e.canManage && !e.lun.volume_read_only && e.snapshotEdit()
                    }
                }
            },
            enableHdMenu: !1,
            autoExpandColumn: "desc",
            viewConfig: a,
            enableColumnMove: !1,
            cls: "without-dirty-red-grid"
        }
    },
    isLunActioning: function() {
        return this.lun.isActioning()
    },
    isSinkLun: function() {
        return this.lun.isSinkLun()
    },
    snapshotClone: function() {
        var e = this.getSelected().data;
        this.doSnapshotClone(e)
    },
    snapshotDelete: function() {
        var e = this;
        e.getMsgBox().confirmDelete(e.title, String.format("{0}<br>{1}", SYNO.SDS.iSCSI.Utils.T("common", "remove_cfrmrmv"), SYNO.SDS.iSCSI.Utils.T("iscsilun", "space_reclamation_warning")), function(t) {
            "yes" === t && e.doSnapshotDelete()
        }, e)
    },
    snapshotRestore: function() {
        var e = this,
            t = e.getSelected(),
            i = SYNO.SDS.DateTimeFormatter(new Date(1e3 * t.get("snapshot_time")), {
                type: "datetimesec"
            }),
            n = '<span class="red-status">' + String.format(SYNO.SDS.iSCSI.Utils.T("iscsilun", "restore_data_lost_warning"), i) + "</span><br/>" + String.format(SYNO.SDS.iSCSI.Utils.T("iscsilun", "snapshot_restore_confirm"), i);
        if (SYNO.SDS.iSCSI.Utils.IsAnyMappedTargetConnected(e.lun.get("uuid"), e.appWin.iscsiTargets.getAll())) {
            n = String.format('<span class="red-status"> {0} </span><br/><br/>', String.format(SYNO.SDS.iSCSI.Utils.T("iscsilun", "online_restore_warning"), e.lun.get("name"))) + n
        }
        return t.get("canClone") ? e.isSinkLun() ? void e.getMsgBox().alert(e.title, SYNO.SDS.iSCSI.Utils.T("iscsilun", "dr_readonly_register_message")) : void e.getMsgBox().confirm(e.title, n, function(t) {
            "yes" === t && e.snapshotCheckingAndRestore()
        }) : void e.getMsgBox().alert(e.title, SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_set_failed_space_not_enough"))
    },
    snapshotEdit: function() {
        var e = this,
            t = e.getSelected().data,
            i = new SYNO.SDS.iSCSI.Snapshot.Edit({
                owner: e,
                appWin: e.appWin,
                title: SYNO.SDS.iSCSI.Utils.T("common", "alt_edit") + " - " + e.lun.get("name"),
                luns: [e.lun],
                snapshot: t
            });
        e.mon(i, "destroy", function() {
            e.startPollingTask()
        }, e, {
            single: !0
        }), e.stopPollingTask(), i.open()
    },
    snapshotCheckingAndCloneFrom3rdApp: function(e) {
        var t, i = this;
        Ext.each(e, function(e) {
            if (e.uuid === i.snapshotuuidfrom3rd) return t = e, !1
        }), void 0 !== t && (i.launched3rd = !0, i.doSnapshotClone(t))
    },
    snapshotCheckingAndRestore: function() {
        var e = this;
        e.getSelected().get("total_size") >= parseInt(e.lun.get("size"), 10) ? e.doSnapshotRestore() : this.sendWebAPI({
            api: "SYNO.Core.ISCSI.Replication",
            version: 1,
            method: "list",
            params: {
                lun_uuid: e.lun.get("uuid")
            },
            scope: this,
            callback: function(t, i) {
                if (t)
                    if (i.tasks.length > 0) {
                        var n = SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_restore_to_smaller_size_with_replication");
                        this.getMsgBox().confirm(this.title, n, function(t) {
                            "yes" === t && e.doSnapshotRestore()
                        })
                    } else e.doSnapshotRestore()
            }
        })
    },
    doSnapshotRestore: function() {
        var e = this,
            t = e.getSelected();
        e.setStatusBusy({
            text: SYNO.SDS.iSCSI.Utils.T("common", "msg_waiting")
        }), e.sendWebAPI({
            api: "SYNO.Core.ISCSI.LUN",
            version: 1,
            method: "restore_snapshot",
            params: {
                src_lun_uuid: e.lun.get("uuid"),
                snapshot_uuid: t.get("uuid")
            },
            callback: function(t, i) {
                if (e.clearStatusBusy(), !t) return void SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(e, i);
                e.isDataChanged = !0, e.fireEvent("smart_close"), e.close()
            }
        })
    },
    doSnapshotDelete: function() {
        var e = this,
            t = e.getSelections(),
            i = [];
        e.setStatusBusy({
            text: SYNO.SDS.iSCSI.Utils.T("common", "saving")
        }), Ext.each(t, function(e) {
            i.push(e.get("uuid"))
        }), e.stopPollingTask(), this.sendWebAPI({
            api: "SYNO.Core.ISCSI.LUN",
            version: 1,
            method: "delete_snapshot",
            params: {
                snapshot_uuids: i,
                deleted_by: "user"
            },
            callback: function(n, s) {
                if (e.clearStatusBusy(), !n) return e.startPollingTask(), void SYNO.SDS.iSCSI.Utils.ReportWebapiFailure(this, s);
                if (e.isDataChanged = !0, s && 0 < s.length) {
                    var a = [];
                    s.forEach(function(e) {
                        var n = Object.getOwnPropertyNames(e)[0],
                            s = e[n],
                            o = t[i.indexOf(n)].get("snapshot_time"),
                            r = {};
                        r[o] = s, a.push(r)
                    }, e);
                    new SYNO.SDS.iSCSI.Snapshot.MultiDeleteError({
                        appWin: e.appWin,
                        owner: e,
                        title: SYNO.SDS.iSCSI.Utils.T("share", "share_snapshot_delete_failed"),
                        errorData: a,
                        listeners: {
                            close: function() {
                                e.startPollingTask()
                            }
                        }
                    }).open()
                } else e.startPollingTask()
            },
            scope: e
        })
    },
    doSnapshotClone: function(e) {
        var t = this;
        if (!e.canClone) return void t.getMsgBox().alert(t.title, SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_set_failed_space_not_enough"));
        var i = new SYNO.SDS.iSCSI.Snapshot.CloneSnapshot({
            appWin: t.appWin,
            owner: t,
            lun: t.lun,
            snapshot: e,
            title: SYNO.SDS.iSCSI.Utils.T("iscsilun", "clone")
        });
        t.mon(i, "close", function() {
            t.mainPage && (t.appWin.setStatusBusy(), t.mainPage.loaded = !1), t.appWin.fireEvent("poll_activate")
        }, t, {
            single: !0
        }), i.open()
    },
    reportFailure: function(e) {
        this.getMsgBox().alert(this.title, e.text)
    }
}), Ext.define("SYNO.SDS.iSCSI.Snapshot.Configure.Main", {
    extend: "SYNO.SDS.iSCSI.ModalWindow",
    constructor: function(e) {
        var t = this,
            i = [],
            n = !1;
        t.owner = e.owner, t.appWin = e.appWin, t.mainPage = e.mainPage, t.luns = e.luns, t.multiple = 1 < t.luns.length, t.maxSnapshot = t.appWin.maxSnapshotPerLun, i.push(new SYNO.SDS.iSCSI.Snapshot.Configure.Schedule({
            appWin: t.appWin,
            owner: t
        })), i.push(new SYNO.SDS.iSCSI.Snapshot.Configure.Retention({
            appWin: t.appWin,
            owner: t,
            type: "Lun",
            showKeepAll: t.multiple
        })), i.push(new SYNO.SDS.iSCSI.Snapshot.Configure.LunApplication({
            appWin: t.appWin,
            owner: t,
            multiple: t.multiple
        })), Ext.each(t.luns, function(e) {
            if (e.isSinkLun()) return n = !0, !1
        }, t), t.tabPanel = new SYNO.SDS.Utils.TabPanel({
            appWin: t.appWin,
            owner: t.owner,
            activeTab: 0,
            items: i
        });
        var s = {
            items: [t.tabPanel],
            width: 680,
            height: 574,
            minWidth: 680,
            minHeight: 574,
            resizable: !1,
            buttons: [{
                xtype: "syno_button",
                text: SYNO.SDS.iSCSI.Utils.T("common", "alt_cancel"),
                scope: t,
                handler: t.onCancel
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                text: SYNO.SDS.iSCSI.Utils.T("common", "alt_apply"),
                scope: t,
                handler: t.onSave
            }]
        };
        t.callParent([Ext.apply(s, e)]), t.getiSCSILunScheData(), t.getiSCSIPluginData(), n && (t.tabPanel.get("scheduleSnapshot").setDisabled(!0), t.tabPanel.get("lunApplication").setDisabled(!0), t.tabPanel.setActiveTab("retentionSnapshot"))
    },
    getForm: function(e) {
        return this.tabPanel.getItem(e).getForm()
    },
    setTargetConf: function() {
        var e = this;
        e.setStatusBusy({
            text: SYNO.SDS.iSCSI.Utils.T("common", "saving")
        }), e.setiSCSILunConf()
    },
    onSave: function() {
        var e = this,
            t = e.tabPanel.get("retentionSnapshot");
        if (!t.isValid()) return void e.tabPanel.setActiveTab("retentionSnapshot");
        var i = t.getRetention().policyType,
            n = e.getForm("scheduleSnapshot").findField("enable_schedule").getValue(),
            s = SYNO.SDS.iSCSI.RTT_KEEP_ALL !== i && SYNO.SDS.iSCSI.RTT_ALL !== i,
            a = SYNO.SDS.iSCSI.Utils.T("common", "common_settings"),
            o = "";
        t.isDirty() ? (o = SYNO.SDS.iSCSI.Utils.T("snapmgr", "run_retention_immed"), e.getMsgBox().confirm(a, o, function(t) {
            "ok" === t && e.setTargetConf()
        }, e, Ext.MessageBox.OKCANCEL)) : n && !s ? (o = SYNO.SDS.iSCSI.Utils.T("snapmgr", "ret_setting_remind"), e.getMsgBox().confirm(a, o, function(t) {
            "ok" === t ? e.tabPanel.setActiveTab("retentionSnapshot") : e.setTargetConf()
        }, e, {
            ok: {
                text: SYNO.SDS.iSCSI.Utils.T("volume", "change_settings")
            },
            cancel: {
                text: Ext.MessageBox.buttonText.ok
            }
        })) : e.setTargetConf()
    },
    geniSCSILunConfWebapi: function(e, t, i, n) {
        var s = this,
            a = e.get("uuid"),
            o = i ? s.taskMap[a].schedule : t;
        return {
            api: "SYNO.Core.ISCSI.LUN",
            method: "set_sched_snapshot",
            version: 1,
            uuid: a,
            general: s.getGeneralData(a, i, n),
            schedule: o
        }
    },
    setiSCSILunConf: function() {
        var e = this,
            t = e.getScheData(),
            i = e.getForm("scheduleSnapshot").findField("schedule_keep_all").getValue(),
            n = e.getForm("lunApplication").findField("application_keep_all").getValue();
        if (i && n) return void e.setRetention();
        var s = [];
        Ext.each(e.luns, function(a) {
            s.push(e.geniSCSILunConfWebapi(a, t, i, n))
        }, e), e.sendWebAPI({
            api: "SYNO.Entry.Request",
            method: "request",
            version: 2,
            params: {
                mode: "parallel",
                compound: s
            },
            scope: e,
            callback: function(t, i, n) {
                if (!t || i.has_fail) {
                    var s = SYNO.SDS.iSCSI.Utils.T("iscsimgr", "err_set_sche");
                    return e.clearStatusBusy(), e.getMsgBox().alert(SYNO.SDS.iSCSI.Utils.T("common", "common_settings"), s, function() {
                        e.close()
                    }, e), !1
                }
                e.setRetention()
            }
        })
    },
    onCancel: function() {
        this.close()
    },
    genRetentionTaskMap: function(e, t) {
        var i = this;
        if (i.rttTaskMap = {}, e.result.length !== t.compound.length) return !1;
        for (var n = 0; n < e.result.length; n++) i.rttTaskMap[t.compound[n].name] = e.result[n].data.tid;
        return !0
    },
    genLunTaskMap: function(e) {
        var t = this;
        t.taskMap = {};
        var i = t.appWin.iscsiLuns;
        Ext.each(e, function(e) {
            var n = e.general;
            t.taskMap[n.uuid] = {}, t.taskMap[n.uuid].task_enabled = n.task_enabled, t.taskMap[n.uuid].tid = n.tid, n.task_name ? t.taskMap[n.uuid].task_name = n.task_name : t.taskMap[n.uuid].task_name = "Task " + i.getById(n.uuid).get("name"), t.taskMap[n.uuid].snap_type = n.snap_type, t.taskMap[n.uuid].schedule = e.schedule
        })
    },
    genLoadPluginWebapi: function() {
        return {
            api: "SYNO.Core.ISCSI.Node",
            version: 1,
            method: "get",
            additional: ["plugin_info"]
        }
    },
    getiSCSILunScheData: function() {
        var e = this,
            t = [],
            i = {};
        Ext.each(e.luns, function(e) {
            var i = e.get("scheduled_task");
            i && t.push(i[0])
        }), Ext.each(e.tabPanel.items.items, function(n) {
            e.multiple ? Ext.isFunction(n.loadDefaultData) && n.loadDefaultData() : (e.processLunSched(t[0], i), Ext.isFunction(n.updateScheData) && n.updateScheData(i))
        }, e), e.genLunTaskMap(t)
    },
    getiSCSIPluginData: function() {
        var e = this,
            t = [];
        t.push(e.genLoadPluginWebapi()), e.setStatusBusy({
            text: SYNO.SDS.iSCSI.Utils.T("common", "msg_waiting")
        }), e.sendWebAPI({
            api: "SYNO.Entry.Request",
            method: "request",
            version: 2,
            params: {
                mode: "parallel",
                compound: t
            },
            scope: e,
            callback: function(t, i, n) {
                if (!t || i.has_fail) {
                    var s = SYNO.SDS.iSCSI.Utils.T("iscsimgr", "err_get_sche");
                    return e.clearStatusBusy(), void e.getMsgBox().alert(SYNO.SDS.iSCSI.Utils.T("common", "common_settings"), s, function() {
                        e.close()
                    }, e)
                }
                Ext.each(i.result, function(t) {
                    !0 === SYNO.ux.Utils.checkApiConsistency(e.genLoadPluginWebapi(), t) && e.tabPanel.getItem("lunApplication").updateNASTpl(t)
                }), e.getRetention()
            }
        })
    },
    processLunSched: function(e, t) {
        t.enable_snapshot_schedule = e.general.task_enabled, t.enable_app_consist = "crash" !== e.general.snap_type, t.schedule = e.schedule
    },
    updateLunListPanel: function() {
        var e = this;
        e.appWin.setStatusBusy(), e.mainPage.loaded = !1, e.appWin.fireEvent("poll_activate"), e.clearStatusBusy(), e.close()
    },
    genSetRetentionWebapi: function(e, t) {
        var i = {
            api: "SYNO.DisasterRecovery.Retention",
            method: "set",
            version: 1,
            type: "Lun",
            name: e
        };
        return Ext.apply(i, t), Ext.apply(i, {
            tid: this.rttTaskMap[e]
        }), i
    },
    setRetention: function() {
        var e = this,
            t = e.tabPanel.get("retentionSnapshot");
        if (!t.isDirty()) return void e.updateLunListPanel();
        var i = Ext.apply({
                type: "Lun"
            }, t.getRetention()),
            n = e.luns.map(function(t) {
                return e.genSetRetentionWebapi(t.get("uuid"), i)
            });
        e.sendWebAPI({
            api: "SYNO.Entry.Request",
            method: "request",
            version: 2,
            params: {
                mode: "sequential",
                compound: n
            },
            scope: e,
            callback: function(t, i, n) {
                if (!t || i.has_fail) return e.clearStatusBusy(), void e.getMsgBox().alert(void 0, SYNO.SDS.iSCSI.Utils.T("snapmgr", "err_set_ret_policy"));
                e.updateLunListPanel()
            }
        })
    },
    getRetention: function() {
        var e = this;
        e.sendWebAPI({
            compound: {
                stopwhenerror: !0,
                mode: "parallel",
                params: e.luns.map(function(e) {
                    return {
                        api: "SYNO.DisasterRecovery.Retention",
                        method: "get",
                        version: 1,
                        params: {
                            type: "Lun",
                            name: e.get("uuid").toString()
                        }
                    }
                })
            },
            scope: e,
            callback: function(t, i, n) {
                if (e.clearStatusBusy(), !t || i.has_fail) return void e.getMsgBox().alert(void 0, SYNO.SDS.iSCSI.Utils.T("snapmgr", "err_get_ret_policy"), function() {
                    e.close()
                }, e);
                e.tabPanel.items.each(function(e) {
                    Ext.isFunction(e.updateRetData) && (1 === n.compound.length ? e.updateRetData(i.result[0].data) : Ext.isFunction(e.loadDefaultData) && e.loadDefaultData())
                }, e), e.genRetentionTaskMap(i, n)
            }
        })
    },
    getGeneralData: function(e, t, i) {
        var n = this,
            s = {},
            a = n.tabPanel.getItem("scheduleSnapshot").getForm(),
            o = n.tabPanel.getItem("lunApplication").getForm();
        return s.task_enabled = t ? n.taskMap[e].task_enabled : a.findField("enable_schedule").getValue(), s.snap_type = i ? n.taskMap[e].snap_type : o.findField("enable_app_consist").getValue() ? "app" : "crash", s.task_name = n.taskMap[e].task_name, s.tid = n.taskMap[e].tid, s
    },
    getScheData: function() {
        return this.tabPanel.getItem("scheduleSnapshot").getScheduleData()
    }
}), Ext.define("SYNO.SDS.iSCSI.Snapshot.Configure.Schedule", {
    extend: "SYNO.SDS.TaskScheduler2.EditSchedulePanel",
    constructor: function(e) {
        var t = this;
        t.more_option_val = 99, t.callParent(arguments), t.mon(t, "afterlayout", t.setEnableCheckGroup, t, {
            single: !0
        })
    },
    fillConfig: function(e) {
        var t = this,
            i = [],
            n = [],
            s = 0;
        for (s = 0; s < 24; ++s) i.push([String.leftPad(String(s), 2, "0"), s]);
        for (s = 0; s < 60; ++s) n.push([String.leftPad(String(s), 2, "0"), s]);
        var a = new Ext.data.ArrayStore({
                fields: ["display", "value"],
                data: i
            }),
            o = new Ext.data.ArrayStore({
                fields: ["display", "value"],
                data: n
            });
        t.addManagedComponent(a), t.addManagedComponent(o), t.repeat_hour_store = new Ext.data.ArrayStore({
            fields: ["display", "value"]
        }), t.addManagedComponent(t.repeat_hour_store), t.last_work_hour_store = new Ext.data.ArrayStore({
            fields: ["display", "value"]
        }), t.addManagedComponent(t.last_work_hour_store);
        var r = {
            title: SYNO.SDS.iSCSI.Utils.T("common", "schedule"),
            itemId: "scheduleSnapshot",
            border: !1,
            height: 480,
            MinInterval: [5, 15, 30],
            HourInterval: [1, 2, 3, 4, 6, 8, 12],
            items: [{
                xtype: "syno_checkbox",
                name: "schedule_keep_all",
                id: t.schedule_keep_all_id = Ext.id(),
                boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "sche_keep_all"),
                checked: !1,
                hidden: !0
            }, {
                xtype: "syno_checkbox",
                name: "enable_schedule",
                id: t.enable_schedule_id = Ext.id(),
                listeners: {
                    disable: function() {
                        this.setValue(!1)
                    }
                },
                boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsilun", "snapshot_schedule_enable")
            }, {
                xtype: "syno_compositefield",
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "sche_exec_day"),
                labelWidth: 180,
                width: 200,
                indent: 1,
                items: [{
                    xtype: "syno_schedulefield",
                    id: t.week_name_id = Ext.id(),
                    hideLabel: !0,
                    allowBlank: !1,
                    editable: !1,
                    width: 200
                }]
            }, {
                xtype: "syno_compositefield",
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("schedule", "run_time_first"),
                labelWidth: 180,
                width: 200,
                indent: 1,
                defaults: {
                    flex: 1
                },
                items: [{
                    xtype: "syno_combobox",
                    store: a,
                    displayField: "display",
                    id: t.hour_id = Ext.id(),
                    valueField: "value",
                    triggerAction: "all",
                    mode: "local",
                    width: 90,
                    editable: !1,
                    listeners: {
                        select: {
                            fn: function() {
                                t.updateRepeatHourStore(), t.updateMinComboBox(), t.updateLastWorkTimeStore()
                            },
                            scope: t
                        }
                    }
                }, {
                    xtype: "syno_displayfield",
                    value: ":",
                    style: {
                        "text-align": "center"
                    }
                }, {
                    xtype: "syno_combobox",
                    store: o,
                    displayField: "display",
                    id: t.min_id = Ext.id(),
                    valueField: "value",
                    triggerAction: "all",
                    mode: "local",
                    width: 90,
                    editable: !1,
                    listeners: {
                        select: {
                            fn: function() {
                                t.updateRepeatHourStore(), t.updateLastWorkTimeStore()
                            },
                            scope: t
                        }
                    }
                }]
            }, {
                xtype: "syno_combobox",
                store: t.repeat_hour_store,
                value: 0,
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("schedule", "schedule_every"),
                labelWidth: 180,
                displayField: "display",
                valueField: "value",
                id: t.repeat_hour_id = Ext.id(),
                triggerAction: "all",
                width: 200,
                mode: "local",
                editable: !1,
                indent: 1,
                listeners: {
                    select: {
                        fn: function(e, i) {
                            t.onSelectRepeatHour(i.get("value"))
                        },
                        scope: t
                    },
                    expand: {
                        fn: function(e) {
                            t.repeat_hour >= 100 && e.setValue(t.more_option_val)
                        },
                        scope: t
                    },
                    collapse: {
                        fn: function(e) {
                            t.setRepeatHour(t.repeat_hour)
                        },
                        scope: t
                    },
                    enable: {
                        fn: function() {
                            t.updateMinComboBox(), t.updateLastWorkHourComboBox()
                        },
                        scope: t,
                        delay: 5
                    }
                }
            }, {
                xtype: "syno_combobox",
                store: t.last_work_hour_store,
                value: 0,
                labelWidth: 180,
                fieldLabel: SYNO.SDS.iSCSI.Utils.T("schedule", "last_run_time"),
                displayField: "display",
                valueField: "value",
                id: t.last_work_hour_id = Ext.id(),
                triggerAction: "all",
                width: 200,
                mode: "local",
                editable: !1,
                indent: 1
            }]
        };
        return Ext.apply(r, e), r
    },
    setRepeatHour: function(e) {
        var t = this;
        if (t.repeat_hour = e, e < 100) return void Ext.getCmp(t.repeat_hour_id).setValue(e);
        for (var i = 0; i < t.minArr.length; i++)
            if (t.minArr[i][1] == e) {
                Ext.getCmp(t.repeat_hour_id).setValue(t.minArr[i][0]);
                break
            }
    },
    updateMinComboBox: function() {
        var e = this;
        Math.floor(e.repeat_hour / 100) > 0 ? (Ext.getCmp(e.min_id).setValue(0), Ext.getCmp(e.min_id).setDisabled(!0)) : Ext.getCmp(e.min_id).setDisabled(!1)
    },
    updateLastWorkHourComboBox: function() {
        var e = this,
            t = Math.floor(e.repeat_hour / 100),
            i = e.repeat_hour % 100,
            n = 0 === t && 0 === i,
            s = Ext.getCmp(e.repeat_hour_id).disabled;
        Ext.getCmp(e.last_work_hour_id).setDisabled(n || s)
    },
    onSelectMoreOption: function() {
        var e = this,
            t = new SYNO.SDS.iSCSI.Schedule.MoreOption({
                appWin: e.appWin,
                owner: e.owner,
                repeat_hour: e.repeat_hour,
                minArr: e.minArr
            });
        e.mon(t, "more_option_edited", e.onMoreOptionEdit, e, {
            single: !0
        }), t.open()
    },
    afterSelectRepeatHour: function() {
        this.updateMinComboBox(), this.updateLastWorkTimeStore()
    },
    onMoreOptionEdit: function(e) {
        this.setRepeatHour(e.repeat_hour), this.afterSelectRepeatHour()
    },
    onSelectRepeatHour: function(e) {
        var t = this;
        if (t.more_option_val === e) return void t.onSelectMoreOption();
        t.setRepeatHour(e), t.afterSelectRepeatHour()
    },
    updateRepeatHourStore: function(e, t) {
        var i = this,
            n = 0,
            s = 0,
            a = 0,
            o = [],
            r = Ext.getCmp(this.hour_id).getValue();
        for (o.push([_T("schedule", "schedule_every_once"), 0]), n = 23; n >= 0; n--)
            if (n > r)
                for (a = n - r, s = 0; s < i.HourInterval.length; s++)
                    if (a === i.HourInterval[s]) {
                        var l = String.format(_T("schedule", "every_x_hours"), a);
                        o.push([l, a]);
                        break
                    } for (o.push([SYNO.SDS.iSCSI.Utils.T("iscsimgr", "sched_more_option"), i.more_option_val]), i.minArr = [], n = i.MinInterval.length - 1; n >= 0; n--) i.minArr.push([String.format(_T("schedule", "every_x_minutes"), i.MinInterval[n]), 100 * i.MinInterval[n]]);
        i.repeat_hour_store.loadData(o), i.repeat_hour > a && i.setRepeatHour(0)
    },
    updateLastWorkTimeStore: function() {
        var e = this,
            t = -1,
            i = [],
            n = Ext.getCmp(e.hour_id).getValue(),
            s = Ext.getCmp(e.min_id).getValue(),
            a = Math.floor(e.repeat_hour / 100),
            o = e.repeat_hour % 100,
            r = Ext.getCmp(e.last_work_hour_id).getValue();
        a > 0 && (o = 1), e.updateLastWorkHourComboBox();
        for (var l = n; l < 24; l += o) {
            var S = String.leftPad(String(l), 2, "0") + ":";
            if (S += 0 < a ? String.leftPad(String(60 - a), 2, "0") : String.leftPad(String(s), 2, "0"), i.push([S, l]), l === r && (t = l), 0 === o) break
        }
        e.last_work_hour_store.loadData(i), -1 === t ? Ext.getCmp(e.last_work_hour_id).setValue(i[i.length - 1][1]) : Ext.getCmp(e.last_work_hour_id).setValue(t), 0 < a && Ext.getCmp(e.last_work_hour_id).setValue(i[i.length - 1][1]), e.last_work_hour_store.totalLength > 0 && Ext.getCmp(e.last_work_hour_id).setValue(e.last_work_hour_store.getAt(e.last_work_hour_store.totalLength - 1).data.value)
    },
    loadDefaultData: function() {
        var e = this;
        Ext.getCmp(e.schedule_keep_all_id).show(), Ext.getCmp(e.schedule_keep_all_id).setValue(!0), e.updateScheData({
            schedule: SYNO.SDS.iSCSI.Utils.GetDailySchedule(0)
        })
    },
    updateScheData: function(e) {
        var t = this,
            i = e.schedule;
        Ext.getCmp(t.week_name_id).setValue(i.week_name), t.form.findField("enable_schedule").setValue(e.enable_snapshot_schedule), Ext.getCmp(t.hour_id).setValue(i.hour), Ext.getCmp(t.min_id).setValue(i.min), t.updateRepeatHourStore(), t.setRepeatHour(i.repeat_hour + 100 * i.repeat_min), t.updateLastWorkTimeStore(), Ext.getCmp(t.last_work_hour_id).setValue(i.last_work_hour)
    },
    setEnableCheckGroup: function() {
        var e = this;
        e.dummy1 = new SYNO.ux.Utils.EnableCheckGroup(e.form, "enable_schedule", [e.week_name_id, e.hour_id, e.min_id, e.repeat_hour_id, e.last_work_hour_id]), e.dummy2 = new SYNO.ux.Utils.EnableCheckGroup(e.form, "schedule_keep_all", [], [e.enable_schedule_id])
    },
    getScheduleData: function() {
        var e = this,
            t = {};
        return t.date_type = 0, t.week_name = Ext.getCmp(e.week_name_id).getValue(), t.hour = Ext.getCmp(e.hour_id).getValue(), t.min = Ext.getCmp(e.min_id).getValue(), t.repeat_hour = e.repeat_hour % 100, t.repeat_min = parseInt(e.repeat_hour / 100, 10), t.last_work_hour = Ext.getCmp(e.last_work_hour_id).getValue(), t
    },
    onDestroy: function() {
        Ext.destroy(this.dummy1), Ext.destroy(this.dummy2), this.callParent()
    }
}), Ext.define("SYNO.SDS.iSCSI.Snapshot.Configure.Retention", {
    extend: "Ext.Container",
    constructor: function(e) {
        var t = this,
            i = SYNO.SDS.iSCSI.Utils;
        t.appWin = e.appWin, t.maxSnapshot = t.appWin.maxSnapshotPerLun, t.supportTimeTrigger = e.appWin.supportTimeTrigger, t.isAdvDirty = !1, Ext.apply(t, {
            MAX_RET_RECENTLY: t.maxSnapshot,
            MIN_RET_RECENTLY: 1
        }), t.ret_trigger_time_store = new Ext.data.ArrayStore({
            fields: ["display", "value"]
        });
        for (var n = [], s = 0; s < 24; s++) {
            var a = String.leftPad(String(s), 2, "0") + ":00",
                o = Date.parseDate(a, "H:i"),
                r = SYNO.SDS.DateTimeFormatter(o, {
                    type: "time"
                });
            n.push([r, s])
        }
        n.push([i.T("snapmgr", "ret_trigger_after_snap"), -1]), t.ret_trigger_time_store.loadData(n);
        var l = [{
                xtype: "syno_displayfield",
                value: i.T("snapmgr", "ret_policy_description")
            }, {
                xtype: "syno_checkbox",
                name: "retention_keep_all",
                boxLabel: i.T("snapmgr", "ret_keep_all"),
                inputValue: SYNO.SDS.iSCSI.RTT_KEEP_ALL,
                checked: e.showKeepAll,
                hidden: !e.showKeepAll
            }, {
                xtype: "syno_checkbox",
                name: "retention_enabled",
                checked: !1,
                boxLabel: i.T("snapmgr", "ret_policy_enable")
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                height: 28,
                indent: 1,
                items: [{
                    xtype: "syno_radio",
                    name: "policyType",
                    boxLabel: i.T("snapmgr", "ret_keep_versions_description"),
                    checked: !0,
                    inputValue: SYNO.SDS.iSCSI.RTT_DEL_OLD
                }, {
                    xtype: "syno_displayfield",
                    width: 2,
                    value: ""
                }, {
                    xtype: "syno_numberfield",
                    name: "recently",
                    value: 128 < t.MAX_RET_RECENTLY ? 128 : t.MAX_RET_RECENTLY,
                    width: 51,
                    minValue: t.MIN_RET_RECENTLY,
                    maxValue: t.MAX_RET_RECENTLY,
                    maxLength: t.countDigitLength(t.MAX_RET_RECENTLY),
                    listeners: {
                        disable: function(e) {
                            e.setValue(e.originalValue)
                        },
                        scope: this
                    }
                }]
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                height: 28,
                indent: 1,
                items: [{
                    xtype: "syno_radio",
                    name: "policyType",
                    boxLabel: i.T("snapmgr", "ret_keep_days_description"),
                    inputValue: SYNO.SDS.iSCSI.RTT_BY_DAY
                }, {
                    xtype: "syno_displayfield",
                    width: 2,
                    value: ""
                }, {
                    xtype: "syno_numberfield",
                    name: "retainDay",
                    value: 7,
                    width: 60,
                    minValue: 1,
                    maxLength: 4,
                    listeners: {
                        disable: function(e) {
                            e.setValue(e.originalValue)
                        },
                        scope: this
                    }
                }, {
                    xtype: "syno_displayfield",
                    name: "displayfield_days",
                    value: i.T("common", "time_days")
                }]
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                height: 28,
                indent: 1,
                items: [{
                    xtype: "syno_radio",
                    name: "policyType",
                    boxLabel: i.T("iscsilun", "ret_adv"),
                    inputValue: SYNO.SDS.iSCSI.RTT_BY_ADVANCE,
                    ref: "../../policyByAdv"
                }, {
                    xtype: "syno_displayfield",
                    width: 2,
                    value: ""
                }, {
                    xtype: "syno_button",
                    text: i.T("iscsimgr", "setting"),
                    disabled: !0,
                    id: t.button_adv = Ext.id(),
                    listeners: {
                        disable: function() {
                            t.isAdvDirty = !1
                        }
                    },
                    scope: t,
                    handler: t.onAdvance
                }]
            }, {
                xtype: "syno_displayfield",
                name: "ret_trigger_time_title",
                indent: 1,
                value: i.T("snapmgr", "snap_ret_trigger_time")
            }, {
                xtype: "syno_combobox",
                store: t.ret_trigger_time_store,
                name: "ret_trigger_time",
                width: 160,
                hideLabel: !0,
                editable: !1,
                displayField: "display",
                valueField: "value",
                value: t.supportTimeTrigger ? 2 : -1,
                disabled: !t.supportTimeTrigger,
                mode: "local",
                triggerAction: "all",
                indent: 1,
                listeners: {
                    disable: function() {
                        this.reset()
                    },
                    afterrender: function(e) {
                        var t = new Ext.util.TextMetrics.createInstance(e.getEl());
                        e.setWidth(39 + t.getWidth(i.T("snapmgr", "ret_trigger_after_snap")))
                    }
                },
                scope: t
            }, {
                xtype: "syno_displayfield",
                name: "ret_note",
                htmlEncode: !1,
                indent: 1,
                value: i.NoteRenderer(i.T("iscsilun", "space_reclamation_warning"))
            }],
            S = {
                xtype: "syno_panel",
                padding: "0px 10px 14px 0px",
                items: [{
                    cls: "iscsi-retention-descpanel",
                    xtype: "syno_displayfield",
                    value: String.format("Share" === t.type ? i.T("snapmgr", "ret_desc_share") : i.T("snapmgr", "ret_desc_lun"), t.maxSnapshot)
                }]
            },
            d = {
                title: i.T("snapmgr", "ret_title"),
                trackResetOnLoad: !0,
                itemId: "retentionSnapshot",
                items: [{
                    itemId: "retentionSnapshotPanel",
                    xtype: "syno_formpanel",
                    width: 640,
                    height: 436,
                    minWidth: 640,
                    minHeight: 436,
                    items: l,
                    bbar: S,
                    trackResetOnLoad: !0
                }]
            };
        t.callParent([Ext.apply(d, e)]), t.mon(t, "activate", t.adjustPanelSize, t), t.mon(t, "afterlayout", function() {
            var e = {};
            e[String(SYNO.SDS.iSCSI.RTT_DEL_OLD)] = ["recently"], e[String(SYNO.SDS.iSCSI.RTT_BY_DAY)] = ["retainDay"], e[String(SYNO.SDS.iSCSI.RTT_BY_ADVANCE)] = [t.button_adv];
            new SYNO.ux.Utils.EnableRadioGroup(t.getForm(), "policyType", e), new SYNO.ux.Utils.EnableCheckGroup(t.getForm(), "retention_enabled", ["policyType", "displayfield_days", "ret_trigger_time_title", "ret_trigger_time", "ret_note"]), new SYNO.ux.Utils.EnableCheckGroup(t.getForm(), "retention_keep_all", [], ["retention_enabled"])
        }, t, {
            single: !0
        })
    },
    getForm: function() {
        return this.getComponent("retentionSnapshotPanel").getForm()
    },
    adjustPanelSize: function() {
        this.setHeight(this.owner.getInnerHeight() - 34)
    },
    isValid: function() {
        return this.getForm().isValid()
    },
    isDirty: function() {
        var e = this,
            t = e.getForm();
        return "true" !== t.getValues().retention_keep_all && (t.isDirty() || e.isAdvDirty)
    },
    countDigitLength: function(e) {
        return void 0 === e || isNaN(e) ? -1 : e.toString().length
    },
    updateRetData: function(e) {
        this.loadData(e)
    },
    getRetention: function() {
        var e = this,
            t = e.getForm(),
            i = t.getValues(),
            n = {
                policyType: "true" === i.retention_enabled ? parseInt(i.policyType, 10) : 0,
                recently: t.findField("recently").getValue(),
                retainDay: t.findField("retainDay").getValue()
            };
        return -1 < i.ret_trigger_time && (n.policyType |= SYNO.SDS.iSCSI.RTT_TRRIGER_BY_TIME, n.tid = -1, n.schedule = SYNO.SDS.iSCSI.Utils.GetDailySchedule(i.ret_trigger_time)), Ext.apply(n, e.getAdvData()), n
    },
    loadData: function(e) {
        var t = this,
            i = t.getForm().getValues(),
            n = e.policyType & ~SYNO.SDS.iSCSI.RTT_TRRIGER_BY_TIME;
        i.recently = e.recently, i.retainDay = e.retainDay, i.retention_enabled = !!n, SYNO.SDS.iSCSI.RTT_ALL === n ? i.ret_trigger_time = 2 : e.policyType & SYNO.SDS.iSCSI.RTT_TRRIGER_BY_TIME ? i.ret_trigger_time = e.schedule.hour : i.ret_trigger_time = -1, i.policyType = n || SYNO.SDS.iSCSI.RTT_DEL_OLD, t.advRetainDay = e.advRetainDay, t.advHourly = e.advHourly, t.advDaily = e.advDaily, t.advWeekly = e.advWeekly, t.advMonthly = e.advMonthly, t.advYearly = e.advYearly, t.advMinimum = e.advMinimum, t.advPolicyType = e.advPolicyType, t.initAdvRetainDay = e.advRetainDay, t.initAdvHourly = e.advHourly, t.initAdvDaily = e.advDaily, t.initAdvWeekly = e.advWeekly, t.initAdvMonthly = e.advMonthly, t.initAdvYearly = e.advYearly, t.initAdvMinimum = e.advMinimum, t.initAdvPolicyType = e.advPolicyType, t.getForm().setValues(i)
    },
    getAdvData: function() {
        var e = this,
            t = {
                advRetainDay: e.isAdvDirty ? e.advRetainDay : e.initAdvRetainDay,
                advHourly: e.isAdvDirty ? e.advHourly : e.initAdvHourly,
                advDaily: e.isAdvDirty ? e.advDaily : e.initAdvDaily,
                advWeekly: e.isAdvDirty ? e.advWeekly : e.initAdvWeekly,
                advMonthly: e.isAdvDirty ? e.advMonthly : e.initAdvMonthly,
                advYearly: e.isAdvDirty ? e.advYearly : e.initAdvYearly,
                advMinimum: e.isAdvDirty ? e.advMinimum : e.initAdvMinimum,
                advPolicyType: e.isAdvDirty ? e.advPolicyType : e.initAdvPolicyType
            };
        return e.isHourlyFieldDisabled && (t.advPolicyType &= ~SYNO.SDS.iSCSI.RTT_ADV_POLICY_BY_HOURLY, t.advHourly = 0), t
    },
    onAdvance: function() {
        var e = this,
            t = {
                appWin: e.appWin,
                owner: e.owner,
                maxSnapshot: e.maxSnapshot
            };
        Ext.apply(t, e.getAdvData());
        var i = new SYNO.SDS.iSCSI.SmartRetention(t);
        e.mon(i, "ret_adv_edited", e.onAdvanceEdited, e, {
            single: !0
        }), i.open()
    },
    onAdvanceEdited: function(e) {
        var t = this;
        t.isAdvDirty = !0, t = Ext.apply(t, e)
    },
    onDestroy: function() {
        Ext.destroy(this.dummy), this.callParent()
    }
}), Ext.define("SYNO.SDS.iSCSI.Snapshot.Configure.LunApplication", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(e) {
        var t = this;
        t.multiple = e.multiple;
        var i = "https://www.synology.com/en-global/support/download/" + _D("upnpmodelname"),
            n = String.format(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "appaware_link"), '<a href="' + i + '" target="_blank">', "</a>");
        t.nasTpl = t.createNASTpl();
        var s = {
            title: SYNO.SDS.iSCSI.Utils.T("backup", "application"),
            itemId: "lunApplication",
            items: [{
                xtype: "syno_checkbox",
                name: "application_keep_all",
                id: t.application_keep_all_id = Ext.id(),
                boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "application_keep_all"),
                checked: t.multiple,
                hidden: !t.multiple
            }, {
                xtype: "syno_checkbox",
                name: "enable_app_consist",
                id: t.enable_app_consist_id = Ext.id(),
                boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "appaware_desc")
            }, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                value: n
            }, {
                xtype: "syno_displayfield",
                itemId: "nasPanel",
                height: 200,
                autoScroll: !0,
                value: t.nasTpl.html
            }]
        };
        this.callParent([Ext.apply(s, e)]), t.mon(t, "afterlayout", t.setEnableCheckGroup, t, {
            single: !0
        })
    },
    createNASTpl: function() {
        var e, t;
        return e = new Ext.XTemplate('<tpl if="this.hasValues(values) === false">', String.format('<div style="padding-left:10px;height:28px;line-height:28px">{0}</div>', SYNO.SDS.iSCSI.Utils.T("iscsimgr", "no_snapshot_manager")), "</tpl>", '<tpl for=".">', '<dl class="iscsi-grid-list-row">', '<dt class="iscsi-grid-list-column" style="width:calc(50% - 8px)">{ip}</dt>', '<dt class="iscsi-grid-list-column" style="width:calc(50% - 8px)">{type}</dt>', '<div class="x-clear"></div>', "</dl>", "</tpl>"), t = new Ext.XTemplate(String.format('<div class="iscsi-grid-section-header">{0}</div>', SYNO.SDS.iSCSI.Utils.T("iscsilun", "snapshot_manager_list")), '<div class="iscsi-grid-list">', '<div class="iscsi-grid-list-header">', '<dl style="padding-left:10px;">', String.format('<dt class="iscsi-grid-list-column" style="width:calc(50% - 8px)">{0}</dt>', SYNO.SDS.iSCSI.Utils.T("common", "ip_addr")), String.format('<dt class="iscsi-grid-list-column" style="width:calc(50% - 8px)">{0}</dt>', SYNO.SDS.iSCSI.Utils.T("iscsimgr", "plugin_env")), '<div class="x-clear"></div>', "</dl>", "</div>", '<div class="iscsi-grid-list-body">', e.html, "</div>", "</div>", '<div class="x-clear"></div>', {
            compiled: !0,
            hasValues: function(e) {
                return !!e && 0 < e.length
            }
        }), Ext.destroy(e), t
    },
    updateNASTpl: function(e) {
        this.nasTpl.overwrite(this.getComponent("nasPanel").getEl(), e.data.plugin_info || [])
    },
    updateScheData: function(e) {
        Ext.getCmp(this.form.findField("enable_app_consist").setValue(e.enable_app_consist))
    },
    isAppConsist: function() {
        return this.form.findField("enable_app_consist").getValue()
    },
    setEnableCheckGroup: function() {
        var e = this;
        e.dummy1 = new SYNO.ux.Utils.EnableCheckGroup(e.form, "application_keep_all", [], [e.enable_app_consist_id])
    }
}), Ext.namespace("SYNO.SDS.iSCSI.Snapshot"), Ext.define("SYNO.SDS.iSCSI.Snapshot.Main", {
    extend: "SYNO.SDS.SAN.CardsMainPanel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.panels = [t.emptyPage = new SYNO.SDS.SAN.Snapshot.EmptyMain({
            appWin: t.appWin,
            owner: t.owner,
            itemId: "emptyPage"
        }), t.normalPage = new SYNO.SDS.iSCSI.Snapshot.NormalMain({
            appWin: t.appWin,
            owner: t.owner,
            itemId: "normalPage"
        })];
        var i = {
            panels: t.panels
        };
        t.callParent([Ext.apply(i, e)])
    },
    onDataReady: function() {
        var e = this;
        e.appWin.clearStatusBusy(), e.appWin.iscsiLuns.getAll().length ? (e.getLayout().setActiveItem("normalPage"), e.normalPage.fireEvent("data_ready")) : (e.getLayout().setActiveItem("emptyPage"), e.emptyPage.addLink())
    }
}), Ext.define("SYNO.SDS.SAN.Snapshot.EmptyMain", {
    extend: "SYNO.SDS.SAN.EmptyMainPanel",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.callParent([e])
    },
    fillConfig: function(e) {
        var t = this.callParent([e]);
        return t.items.push({
            xtype: "label",
            text: SYNO.SDS.iSCSI.Utils.T("lun", "no_lun"),
            cls: "iscsi-empty-text"
        }), t.items.push({
            xtype: "label",
            html: String.format(SYNO.SDS.iSCSI.Utils.T("san_mgr", "empty_text_lun_link"), "LUN", '<a class="link-font" href="">', "</a>"),
            cls: "iscsi-empty-text"
        }), t
    },
    addLink: function() {
        var e = this,
            t = e.el.select("a");
        t && this.mon(t, "click", function(t) {
            t.preventDefault(), e.appWin.selectPage("SYNO.SDS.iSCSI.LUN.Main"), e.appWin.activePage.createFromLink = !0
        })
    }
}), Ext.define("SYNO.SDS.iSCSI.Snapshot.NormalMain", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        var t, i = this,
            n = [];
        i.appWin = e.appWin, i.owner = e.owner, i.loaded = !1, i.luns = [], i.defaultEmptyText = SYNO.SDS.iSCSI.Utils.T("lun", "no_lun"), i.list = new SYNO.SDS.iSCSI.ListDataView({
            appWin: i.appWin,
            owner: i,
            multiSelect: !0,
            singleSelect: !1,
            customizeEmptyText: i.defaultEmptyText,
            store: new SYNO.SDS.iSCSI.LunList.Store,
            progressTpl: SYNO.SDS.iSCSI.ProgressTpl(),
            innerTpl: SYNO.SDS.iSCSI.SnapshotTpl(),
            listeners: {
                selectionchange: i.onSelectionChange,
                scope: i
            }
        }), n.push({
            itemId: "snapshot_menu",
            text: SYNO.SDS.iSCSI.Utils.T("iscsilun", "snapshot"),
            disabled: !0,
            menu: {
                items: [{
                    itemId: "take_snapshot",
                    text: SYNO.SDS.iSCSI.Utils.T("iscsilun", "take_snapshot"),
                    handler: i.onTakeSnapshot,
                    disabled: !0,
                    scope: i
                }, {
                    itemId: "manage",
                    text: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "snap_list"),
                    handler: i.onManage,
                    disabled: !0,
                    scope: i
                }]
            }
        }, {
            itemId: "configure",
            text: SYNO.SDS.iSCSI.Utils.T("common", "common_settings"),
            handler: i.onConfigure,
            disabled: !0,
            scope: i
        }, {
            itemId: "replication",
            text: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "replication"),
            handler: i.onReplication,
            disabled: "no" === _D("support_dr_snap", "no"),
            scope: i
        });
        var s = new SYNO.SDS.iSCSI.Snapshot.SearchField({
            appWin: i.appWin,
            owner: i,
            allDisaplayText: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "snap_lun_all")
        });
        t = {
            title: SYNO.SDS.iSCSI.Utils.T("tree", "leaf_iscsilun"),
            border: !1,
            layout: "fit",
            tbar: {
                defaultType: "syno_button",
                items: [n, "->", s]
            },
            items: [i.list],
            listeners: {
                activate: i.onActivate,
                data_ready: i.onDataReady,
                scope: i
            }
        }, i.callParent([Ext.apply(t, e)])
    },
    onActivate: function() {
        var e = this;
        e.loaded || e.appWin.setStatusBusy(null, null, 50), e.appWin.fireEvent("poll_activate")
    },
    onDataReady: function() {
        var e = this.appWin.volumes,
            t = this.appWin.pools,
            i = this.appWin.iscsiLuns.getAll();
        this.luns = [], Ext.each(i, function(i) {
            this.luns.push(i.getSnapshotPageInfo(e, t))
        }, this), this.loadData(this.luns)
    },
    loadData: function(e) {
        var t = this,
            i = t.list.store,
            n = [],
            s = "",
            a = "protected";
        t.loaded || (t.appWin.clearStatusBusy(), t.loaded = !0), i.suspendEvents(!0), i.loadData(e), a = t.getTopToolbar().get("searchShareName").getSearchFilter(), s = t.getTopToolbar().get("searchShareName").getSearchText(), "protected" === a ? n.push({
            property: "isProtected",
            value: !0,
            anyMatch: !0
        }) : null !== a && a !== SYNO.SDS.iSCSI.STATUS_ALL && n.push({
            property: "statusCategory",
            value: a,
            anyMatch: !0
        }), "" !== s && n.push({
            property: "name",
            value: s,
            anyMatch: !0
        }), n.length > 0 && i.filter(n), i.resumeEvents(), 0 < i.getCount() && 0 === t.list.getSelectedItemIds().length && t.list.select(0, !0, !0), 0 === i.getCount() && (t.list.setEmptyText(SYNO.SDS.iSCSI.Utils.T("iscsilun", "mask_no_match_found")), t.list.refresh()), t.onSelectionChange(), t.appWin.fireEvent("afterlaunchpage")
    },
    onSelectionChange: function() {
        var e = this,
            t = e.list.getSelectedRecords();
        e.getButton("snapshot_menu").setDisabled(!1), e.getButton("snapshot_menu").menu.get("take_snapshot").setDisabled(!1), e.getButton("snapshot_menu").menu.get("manage").setDisabled(!1), e.getButton("replication").setDisabled(!1), e.getButton("configure").setDisabled(!1);
        var i = !0,
            n = !0,
            s = !0,
            a = !1,
            o = !0,
            r = !1;
        Ext.each(t, function(e) {
            i = i && e.get("volume_crashed"), n = n && e.get("volume_read_only"), s = s && e.get("support_snapshot"), a = a || SYNO.SDS.iSCSI.Utils.lunCanSnapshot(e), o = o && e.get("lun").isSinkLun(), r = r || e.get("lun").canManage()
        }), n && (e.getButton("snapshot_menu").menu.get("take_snapshot").setDisabled(!0), e.getButton("configure").setDisabled(!0), e.getButton("replication").setDisabled(!0)), a && !i || e.getButton("snapshot_menu").menu.get("take_snapshot").setDisabled(!0), 0 !== t.length && o && e.getButton("snapshot_menu").menu.get("take_snapshot").setDisabled(!0), s && 0 !== t.length || (e.getButton("snapshot_menu").setDisabled(!0), e.getButton("configure").setDisabled(!0), e.getButton("replication").setDisabled(!0)), r || (e.getButton("snapshot_menu").menu.get("take_snapshot").setDisabled(!0), e.getButton("configure").setDisabled(!0)), 0 === t.length && e.getButton("snapshot_menu").setDisabled(!0), 1 < t.length && e.getButton("snapshot_menu").menu.get("manage").setDisabled(!0)
    },
    getButton: function(e) {
        return this.getTopToolbar().get(e)
    },
    checkSelected: function(e, t) {
        var i = this,
            n = t.call(i, e);
        if (0 < n.length) {
            var s = SYNO.SDS.iSCSI.Utils.T("iscsimgr", "selected_targets_operation_deny"),
                a = n.map(function(e) {
                    return e.get("name")
                }, i),
                o = a.filter(function(e, t, i) {
                    return i.indexOf(e) === t
                }, i),
                r = 0 < o.length ? o.join(", ") : "";
            return i.owner.getMsgBox().alert("Operations not allowed", s + "<br><br>" + r, function() {
                i.deselectRecords(n)
            }, i), !1
        }
        return !0
    },
    deselectRecords: function(e) {
        var t = this,
            i = t.list.getSelectedRecords();
        Ext.each(i, function(i) {
            e.find(function(e) {
                return i.id === e.id
            }) && t.list.deselect(i)
        }), t.doLayout()
    },
    checkTakeSnapshot: function(e) {
        var t = this,
            i = [];
        return Ext.each(e, function(e) {
            var t = e.get("volume_crashed"),
                n = e.get("support_snapshot"),
                s = e.get("lun").isSinkLun(),
                a = SYNO.SDS.iSCSI.Utils.lunCanSnapshot(e),
                o = e.get("lun").canManage();
            !t && n && !s && a && o || i.push(e)
        }, t), i
    },
    onTakeSnapshot: function() {
        var e = this,
            t = [];
        if (e.records = e.list.getSelectedRecords(), e.checkSelected(e.records, e.checkTakeSnapshot)) {
            Ext.each(e.records, function(e) {
                t.push(e.get("lun"))
            });
            var i = new SYNO.SDS.iSCSI.Snapshot.TakeSnapshot({
                appWin: e.appWin,
                owner: e.appWin,
                luns: t,
                title: SYNO.SDS.iSCSI.Utils.T("iscsilun", "take_snapshot")
            });
            e.mon(i, "smart_close", function(t) {
                var i = e.luns;
                Ext.each(e.records, function(e) {
                    Ext.each(i, function(t) {
                        e.data.id == t.id && (t.displayProg = "show", t.snapStatus = String.format("&nbsp;-&nbsp;{0}", '<font class="blue-status">' + SYNO.SDS.iSCSI.Utils.T("iscsimgr", "status_processing") + "</font>"))
                    })
                }), e.loadData(i);
                var n = function() {
                    e.appWin.fireEvent("poll_activate")
                };
                e.appWin.setStatusBusy(), e.loaded = !1, setTimeout(n, 500)
            }, e, {
                single: !0
            }), i.open()
        }
    },
    onManage: function() {
        var e = this;
        e.record = e.list.getSelectedRecords();
        var t = new SYNO.SDS.iSCSI.Snapshot.LUNSnapList({
            appWin: e.appWin,
            owner: e.appWin,
            mainPage: e,
            title: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "snap_list") + " - " + e.record[0].get("name"),
            lun: e.record[0].get("lun")
        });
        e.mon(t, "smart_close", function(t) {
            var i = e.luns;
            Ext.each(i, function(t) {
                e.record[0].data.id == t.id && (t.displayProg = "show", t.snapStatus = String.format("&nbsp;-&nbsp;{0}", '<font class="blue-status">' + SYNO.SDS.iSCSI.Utils.T("iscsimgr", "status_processing") + "</font>"))
            }), e.loadData(i), e.appWin.setStatusBusy(), e.loaded = !1, setTimeout(e.appWin.fireEvent("poll_activate"), 500)
        }, e, {
            single: !0
        }), t.open()
    },
    checkConfigure: function(e) {
        var t = this,
            i = [];
        return Ext.each(e, function(e) {
            var t = e.get("volume_crashed"),
                n = e.get("support_snapshot"),
                s = SYNO.SDS.iSCSI.Utils.lunCanSnapshot(e),
                a = e.get("lun").canManage();
            !t && n && s && a || i.push(e)
        }, t), i
    },
    onConfigure: function() {
        var e = this,
            t = e.list.getSelectedRecords(),
            i = [];
        if (e.checkSelected(t, e.checkConfigure)) {
            Ext.each(t, function(e) {
                i.push(e.get("lun"))
            });
            new SYNO.SDS.iSCSI.Snapshot.Configure.Main({
                appWin: e.appWin,
                owner: e.appWin,
                mainPage: e,
                luns: i,
                title: SYNO.SDS.iSCSI.Utils.T("common", "common_settings")
            }).open()
        }
    },
    onReplication: function() {
        var e, t = this;
        t.owner.setStatusBusy(), t.sendWebAPI({
            api: "SYNO.Core.Package",
            method: "get",
            version: 1,
            params: {
                additional: ["status"],
                id: "SnapshotReplication"
            },
            callback: function(i, n) {
                e = !!i && "running" === n.additional.status, t.owner.clearStatusBusy(), t.launchApp(e)
            }
        })
    },
    launchApp: function(e) {
        e ? SYNO.SDS.AppLaunch("SYNO.SDS.DisasterRecovery.Application", {
            fn: "SYNO.SDS.DisasterRecovery.Replication.Main",
            tab: "iSCSILUN"
        }) : SYNO.SDS.AppLaunch("SYNO.SDS.PkgManApp.Instance", {
            action: "open",
            packages: ["SnapshotReplication"]
        })
    }
}), Ext.define("SYNO.SDS.iSCSI.Setting.GeneralTab", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        this.suspendLcwPrompt = !1;
        var t = {
            title: SYNO.SDS.iSCSI.Utils.T("common", "general"),
            items: [{
                xtype: "syno_fieldset",
                title: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_low_capacity_write_header"),
                itemId: "lcw",
                name: "lcw",
                id: "lcw",
                hidden: !e.appWin.isLio4x,
                items: [{
                    xtype: "syno_checkbox",
                    boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_low_capacity_write_enable"),
                    name: "lcw_enabled",
                    id: this.lcw_enabled = Ext.id()
                }, {
                    xtype: "syno_displayfield",
                    indent: 1,
                    value: String.format(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_low_capacity_write_desc"), String.format('<a target="_blank" rel="noopener noreferrer" href="{0}">', SYNO.SDS.iSCSI.READONLY_HELP_WEB_LINK), "</a>", '<span class="red-status">', "</span>"),
                    htmlEncode: !1
                }]
            }, {
                xtype: "syno_fieldset",
                title: SYNO.SDS.iSCSI.Utils.T("rsrcmonitor", "performance_event"),
                itemId: "perf_fieldset",
                name: "perf_fieldset",
                id: "perf_fieldset",
                hidden: !e.appWin.supportPerfEvent,
                items: [{
                    xtype: "syno_displayfield",
                    htmlEncode: !1,
                    value: String.format(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "call_resource_monitor_desc"), '<a class="link-font" style="cursor:pointer">', "</a>"),
                    listeners: {
                        afterrender: this.addLink
                    },
                    isDirty: function() {
                        return !1
                    }
                }]
            }, {
                xtype: "syno_fieldset",
                title: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "ep_buf_unmap_mode_title"),
                itemId: "unmap_mode_fieldset",
                name: "unmap_mode_fieldset",
                id: "unmap_mode_fieldset",
                items: [{
                    xtype: "syno_displayfield",
                    value: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "ep_buf_unmap_mode_desc")
                }, {
                    xtype: "syno_combobox",
                    name: "ep_unmap_buf_mode",
                    fieldLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "ep_buf_unmap_mode_field_label"),
                    hiddenName: "ep_unmap_buf_mode",
                    itemId: "ep_unmap_buf_mode",
                    store: [
                        [1, SYNO.SDS.iSCSI.Utils.T("iscsimgr", "ep_buf_unmap_mode_io")],
                        [2, String.format("{0} ({1})", SYNO.SDS.iSCSI.Utils.T("iscsimgr", "ep_buf_unmap_mode_reclaim_balanced"), SYNO.SDS.iSCSI.Utils.T("common", "default"))],
                        [3, SYNO.SDS.iSCSI.Utils.T("iscsimgr", "ep_buf_unmap_mode_space_reclaim")]
                    ]
                }]
            }]
        };
        return Ext.apply(t, e), t
    },
    initEvents: function() {
        this.mon(this, "activate", this.onActivate, this)
    },
    onActivate: function() {
        this.getComponent("unmap_mode_fieldset").setVisible(this.appWin.iscsiLuns.getAll().some(function(e) {
            return e.isAdvancedLun()
        })), this.mon(Ext.getCmp(this.lcw_enabled), "check", this.promptLcwDialog, this)
    },
    loadForm: function(e) {
        var t = Ext.getCmp(this.lcw_enabled);
        this.appWin.setTpHardThreshold(e.tp_hard_threshold_bytes), e.lcw_enabled = this.appWin.isLowCapacityWriteEnable(), t.suspendEvents(), this.getForm().setValues(e), t.resumeEvents()
    },
    promptLcwDialog: function(e, t) {
        t && !this.suspendLcwPrompt && this.appWin.getMsgBox().show({
            title: this.title,
            msg: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_low_capacity_write_dialog"),
            buttons: {
                yes: {
                    text: Ext.MessageBox.buttonText.yes,
                    btnStyle: "red"
                },
                no: {
                    text: Ext.MessageBox.buttonText.no
                }
            },
            fn: function(e) {
                "yes" !== e && this.form.findField("lcw_enabled").setValue(!1)
            },
            scope: this,
            icon: Ext.MessageBox.ERRORRED,
            minWidth: Ext.MessageBox.minWidth
        })
    },
    addLink: function(e) {
        var t = e.el.first("a"),
            i = Ext.get(t),
            n = function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.ResourceMonitor.Instance", {
                    fn: "SYNO.SDS.ResourceMonitor.Perfalarm.Tab"
                })
            };
        this.mon(i, "click", n, this)
    }
}), Ext.define("SYNO.SDS.iSCSI.Setting.iSCSITab", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = this,
            i = {
                title: SYNO.SDS.iSCSI.Utils.T("service", "iscsi_service"),
                items: [{
                    xtype: "syno_fieldset",
                    title: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "io_queue_length"),
                    itemId: "ioqueue_fieldset",
                    name: "ioqueue_fieldset",
                    id: "ioqueue_fieldset",
                    hidden: !e.appWin.isLio4x,
                    items: [{
                        xtype: "syno_displayfield",
                        value: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "io_queue_length_desc")
                    }, {
                        xtype: "syno_combobox",
                        name: "io_queue_length",
                        fieldLabel: "I/O",
                        hiddenName: "io_queue_length",
                        itemId: "io_queue_length",
                        store: [
                            [1, 1],
                            [16, String.format("{0} ({1})", 16, SYNO.SDS.iSCSI.Utils.T("common", "default"))],
                            [64, 64],
                            [128, 128]
                        ]
                    }]
                }, {
                    xtype: "syno_fieldset",
                    title: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "global_chap"),
                    ref: "globalChap",
                    hidden: !e.appWin.isLio4x,
                    items: [{
                        xtype: "syno_checkbox",
                        boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "global_chap_enable"),
                        name: "global_chap"
                    }, {
                        xtype: "syno_displayfield",
                        indent: 1,
                        value: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "global_chap_feature_desc")
                    }, {
                        xtype: "syno_textfield",
                        fieldLabel: SYNO.SDS.iSCSI.Utils.T("common", "name"),
                        allowBlank: !1,
                        maxlength: 64,
                        name: "user",
                        vtype: "iscsitrg_username",
                        indent: 1
                    }, {
                        xtype: "syno_textfield",
                        textType: "password",
                        fieldLabel: SYNO.SDS.iSCSI.Utils.T("common", "password"),
                        maxlength: 16,
                        ref: "chapPwd",
                        name: "password",
                        allowBlank: !1,
                        vtype: "iscsitrg_password",
                        indent: 1
                    }, {
                        xtype: "syno_checkbox",
                        boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_enable_auth_mutual_chap"),
                        checked: 2 === e.auth_type,
                        name: "mutual_chap",
                        indent: 2
                    }, {
                        xtype: "syno_textfield",
                        fieldLabel: SYNO.SDS.iSCSI.Utils.T("common", "name"),
                        maxlength: 64,
                        name: "mutual_user",
                        vtype: "iscsitrg_username",
                        allowBlank: !1,
                        indent: 2
                    }, {
                        xtype: "syno_textfield",
                        textType: "password",
                        fieldLabel: SYNO.SDS.iSCSI.Utils.T("common", "password"),
                        maxlength: 16,
                        ref: "mutualChapPwd",
                        name: "mutual_password",
                        vtype: "iscsitrg_password",
                        allowBlank: !1,
                        indent: 2,
                        validator: function(e) {
                            return t.globalChap.chapPwd.getValue() !== t.globalChap.mutualChapPwd.getValue() || SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_error_same_as_password")
                        }
                    }]
                }, {
                    xtype: "syno_fieldset",
                    title: "iSNS (Internet Storage Name Service)",
                    itemId: "isns_fieldset",
                    name: "isns_fieldset",
                    id: "isns_fieldset",
                    items: [{
                        xtype: "syno_checkbox",
                        boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsitrg", "iscsitrg_isns_enable"),
                        name: "isns_enabled",
                        listeners: {
                            check: function(e, t) {
                                var i = Ext.getCmp(this.isns_address);
                                t || i.reset(), i.setDisabled(!t)
                            },
                            scope: this
                        }
                    }, {
                        xtype: "syno_textfield",
                        name: "isns_address",
                        fieldLabel: SYNO.SDS.iSCSI.Utils.T("router_networktools", "server"),
                        emptyText: String.format("{0}, {1}", SYNO.SDS.iSCSI.Utils.T("common", "ip_addr"), SYNO.SDS.iSCSI.Utils.T("mailstation", "mailstation_fqdn")),
                        indent: 1,
                        disabled: !0,
                        allowBlank: !0,
                        id: this.isns_address = Ext.id(),
                        validator: function(e) {
                            var t = /(?=^.{1,254}$)(^(?:(?!\d+\.|-)[a-zA-Z0-9_-]{1,63}\.)*(?:[a-zA-Z]{2,})$)/;
                            return Ext.form.VTypes.looseip(e) || t.test(e)
                        }
                    }]
                }],
                listeners: {
                    afterlayout: {
                        fn: function(e) {
                            new SYNO.ux.Utils.EnableCheckGroup(e.getForm(), "global_chap", ["user", "password", "mutual_chap"]), new SYNO.ux.Utils.EnableCheckGroup(e.getForm(), "mutual_chap", ["mutual_user", "mutual_password"])
                        },
                        scope: this,
                        single: !0
                    }
                }
            };
        return Ext.apply(i, e), i
    },
    loadForm: function(e) {
        var t = e.chap_info;
        0 != t.auth_type ? (e.global_chap = !0, e.user = t.user, e.password = t.password) : (e.global_chap = !1, e.user = "", e.password = ""), 2 == t.auth_type ? (e.mutual_chap = !0, e.mutual_user = t.mutual_user, e.mutual_password = t.mutual_password) : (e.mutual_chap = !1, e.mutual_user = "", e.mutual_password = ""), this.getForm().setValues(e)
    }
}), Ext.define("SYNO.SDS.iSCSI.Setting.Main", {
    extend: "SYNO.SDS.Utils.TabPanel",
    API: SYNO.SDS.iSCSI.Utils.API,
    constructor: function(e) {
        this.appWin = e.appWin, this.owner = e.owner, this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        this.generalTab = new SYNO.SDS.iSCSI.Setting.GeneralTab({
            appWin: this.appWin,
            owner: this,
            itemId: "GeneralTab"
        }), this.iscsiTab = new SYNO.SDS.iSCSI.Setting.iSCSITab({
            appWin: this.appWin,
            owner: this,
            itemId: "iSCSITab"
        });
        var t = [];
        this.appWin.supportVAAI && t.push(this.generalTab), t.push(this.iscsiTab);
        var i = {
            title: SYNO.SDS.iSCSI.Utils.T("common", "common_settings"),
            autoScroll: !0,
            useDefaultBtn: !0,
            labelWidth: 200,
            fieldWidth: 240,
            activeTab: 0,
            deferredRender: !1,
            items: t,
            listeners: {
                activate: this.updateAllForm,
                scope: this
            }
        };
        return Ext.apply(i, e), i
    },
    loadAllForms: function(e) {
        this.items.each(function(t) {
            Ext.isFunction(t.loadForm) && t.loadForm(e)
        })
    },
    updateEnv: function(e) {
        this.appWin.env.chap_info = e.chap_info, this.appWin.tp_hard_threshold_bytes = e.tp_hard_threshold_bytes
    },
    updateAllForm: function() {
        function e() {
            return t.apply(this, arguments)
        }
        var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        return this.setStatusBusy(), e.prev = 1, e.next = 4, this.getConf();
                    case 4:
                        t = e.sent, this.loadAllForms(t), this.updateEnv(t), e.next = 12;
                        break;
                    case 9:
                        e.prev = 9, e.t0 = e.catch(1), SYNO.Debug(e.t0);
                    case 12:
                        this.clearStatusBusy();
                    case 13:
                    case "end":
                        return e.stop()
                }
            }, e, this, [
                [1, 9]
            ])
        }));
        return e
    }(),
    applyHandler: function() {
        this.confirmApply() && this.doApply().catch(function() {})
    },
    doApply: function() {
        function e() {
            return t.apply(this, arguments)
        }
        var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        return this.setStatusBusy(), e.prev = 1, e.next = 4, this.setConf();
                    case 4:
                        return e.next = 6, this.updateAllForm();
                    case 6:
                        e.next = 14;
                        break;
                    case 8:
                        throw e.prev = 8, e.t0 = e.catch(1), SYNO.Debug(e.t0), this.clearStatusBusy(), this.appWin.getMsgBox().alert(this.title, this.API.getErrorString(e.t0)), e.t0;
                    case 14:
                        this.clearStatusBusy(), this.setStatusOK();
                    case 16:
                    case "end":
                        return e.stop()
                }
            }, e, this, [
                [1, 8]
            ])
        }));
        return e
    }(),
    getParams: function() {
        var e = {},
            t = this.generalTab.getForm().getValues();
        e.tp_hard_threshold_bytes = t.lcw_enabled ? SYNO.SDS.iSCSI.TP_HARD_THRESHOLD_MIN_SIZE : SYNO.SDS.iSCSI.TP_HARD_THRESHOLD_MAX_SIZE, delete t.lcw_enabled, Ext.apply(e, t);
        var i = this.iscsiTab.getForm().getValues(),
            n = {};
        return i.chap_info = n, n.auth_type = 0, i.global_chap && (n.auth_type = 1, n.user = i.user, n.password = i.password, delete i.user, delete i.password), delete i.global_chap, i.mutual_chap && (n.auth_type = 2, n.mutual_user = i.mutual_user, n.mutual_password = i.mutual_password, delete i.mutual_user, delete i.mutual_password), delete i.mutual_chap, i.isns_enabled || (i.isns_address = i.isns_address ? i.isns_address : ""), Ext.apply(e, i), e
    },
    getConf: function() {
        return this.sendWebAPIPromise({
            api: "SYNO.Core.ISCSI.Node",
            version: 1,
            method: "get",
            params: {
                additional: ["no_rod_key", "isns_info", "io_queue_length", "ep_unmap_buf_mode", "tp_hard_threshold_bytes"]
            }
        })
    },
    setConf: function() {
        return this.sendWebAPIPromise({
            api: "SYNO.Core.ISCSI.Node",
            version: 1,
            method: "set",
            params: this.getParams()
        })
    },
    confirmApply: function() {
        if (!this.isAnyFormDirty()) return this.setStatusError({
            text: SYNO.SDS.iSCSI.Utils.T("error", "nochange_subject"),
            clear: !0
        }), !1;
        var e = this.getAllForms().find(function(e) {
            return !e.isValid()
        });
        return !e || (this.setActiveTab(e.itemId), this.setStatusError({
            text: SYNO.SDS.iSCSI.Utils.T("common", "forminvalid")
        }), !1)
    },
    onPageConfirmLostChangeSave: function() {
        return this.confirmApply() ? this.doApply() : Promise.reject()
    }
}), Ext.define("SYNO.SDS.iSCSI.Log.Main", {
    extend: "SYNO.ux.GridPanel",
    itemsPerPage: 1e3,
    constructor: function(e) {
        var t, i = this;
        Ext.apply(i, e), t = i.fillConfig(e), i.itemsPerPage = i.appWin.appInstance.getUserSettings(i.itemId + "-dsPageLimit") || i.itemsPerPage, i.callParent([t]), i.mon(i, "resize", function(e, t, n) {
            i.updateFbarItems(t)
        }, i)
    },
    getPageRecordStore: function() {
        return new Ext.data.SimpleStore({
            fields: ["value", "display"],
            data: [
                [100, 100],
                [500, 500],
                [1e3, 1e3],
                [3e3, 3e3]
            ]
        })
    },
    getCategoryStore: function() {
        return new Ext.data.SimpleStore({
            fields: ["value", "display"],
            data: [
                ["", SYNO.SDS.iSCSI.Utils.T("log", "log_all")],
                ["general", SYNO.SDS.iSCSI.Utils.T("log", "general")],
                ["connection", SYNO.SDS.iSCSI.Utils.T("log", "log_link_connection")]
            ]
        })
    },
    onChangeDisplayRecord: function(e, t, i) {
        var n = this,
            s = n.logStore;
        n.itemsPerPage !== e.getValue() && (n.itemsPerPage = e.getValue(), n.paging.pageSize = n.itemsPerPage, s.load({
            params: {
                offset: 0,
                limit: n.itemsPerPage
            }
        }), n.appWin.appInstance.setUserSettings(n.itemId + "-dsPageLimit", n.itemsPerPage))
    },
    onChangeCategory: function(e, t, i) {
        var n = this,
            s = n.logStore,
            a = e.getValue();
        a !== s.baseParams.category && (Ext.apply(s.baseParams, {
            category: a
        }), n.loadData())
    },
    initPageComboBox: function(e) {
        return new SYNO.ux.ComboBox({
            name: "page_rec",
            hiddenName: "page_rec",
            hiddenId: Ext.id(),
            store: e,
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            value: this.itemsPerPage,
            editable: !1,
            width: 72,
            mode: "local",
            listeners: {
                select: {
                    fn: this.onChangeDisplayRecord,
                    scope: this
                }
            }
        })
    },
    initCategoryComboBox: function(e) {
        return new SYNO.ux.ComboBox({
            name: "category",
            store: e,
            displayField: "display",
            valueField: "value",
            value: "",
            width: 120,
            mode: "local",
            listeners: {
                select: {
                    fn: this.onChangeCategory,
                    scope: this
                }
            }
        })
    },
    initPagingToolbar: function() {
        return new SYNO.ux.PagingToolbar({
            store: this.logStore,
            displayInfo: !0,
            pageSize: this.itemsPerPage,
            showRefreshBtn: !0,
            cls: "iscsi-log-toolbar",
            items: [{
                xtype: "tbtext",
                style: "padding-right: 4px",
                text: SYNO.SDS.iSCSI.Utils.T("common", "items_perpage")
            }, this.initPageComboBox(this.getPageRecordStore())]
        })
    },
    initSearchForm: function() {
        return new SYNO.SDS.iSCSI.SearchFormPanel({
            cls: "iscsi-search-panel",
            renderTo: Ext.getBody(),
            shadow: !1,
            hidden: !0,
            owner: this
        })
    },
    initToolbar: function() {
        var e = this,
            t = new SYNO.ux.Toolbar;
        return e.clearButton = new SYNO.ux.Button({
            xtype: "syno_button",
            text: SYNO.SDS.iSCSI.Utils.T("common", "btn_clear"),
            handler: e.onLogClear,
            scope: e
        }), e.exportButton = new SYNO.ux.SplitButton({
            xtype: "syno_splitbutton",
            text: SYNO.SDS.iSCSI.Utils.T("common", "btn_export"),
            handler: e.onExportHtml,
            scope: e,
            menu: {
                items: [{
                    text: SYNO.SDS.iSCSI.Utils.T("log", "html_type"),
                    handler: e.onExportHtml,
                    scope: e
                }, {
                    text: SYNO.SDS.iSCSI.Utils.T("log", "csv_type"),
                    handler: e.onExportCSV,
                    scope: e
                }]
            }
        }), e.searchField = new SYNO.SDS.iSCSI.AdvancedSearchField({
            iconStyle: "filter",
            owner: e
        }), e.searchField.searchPanel = e.searchPanel, t.add(e.clearButton), t.add(e.exportButton), t.add("->"), t.add(e.initCategoryComboBox(e.getCategoryStore())), t.add({
            xtype: "tbspacer",
            width: 4
        }), t.add(e.searchField), t
    },
    initEvents: function() {
        this.mon(this.searchPanel, "search", this.onSearch, this), this.mon(this, "activate", this.onActive, this)
    },
    getStore: function() {
        return new SYNO.API.Store({
            api: "SYNO.Core.ISCSI.Node",
            version: 1,
            method: "log_list",
            baseParams: {
                keyword: ""
            },
            appWindow: this.appWin,
            sortInfo: {
                field: "time",
                direction: "DESC"
            },
            remoteSort: !1,
            reader: new Ext.data.JsonReader({
                idProperty: "id",
                root: "logs",
                totalProperty: "summary.total",
                fields: [{
                    name: "log_level",
                    mapping: "log_level"
                }, {
                    name: "time",
                    mapping: "time"
                }, {
                    name: "user",
                    mapping: "user"
                }, {
                    name: "event",
                    mapping: "event"
                }]
            }),
            listeners: {
                exception: this.loadException,
                beforeload: this.onBeforeStoreLoad,
                load: this.onAfterStoreLoad,
                scope: this
            }
        })
    },
    logLevelRenderer: function(e) {
        switch (e) {
            case "err":
                return "<span class='red-status'>" + SYNO.SDS.iSCSI.Utils.T("log", "error_level") + "</span>";
            case "warning":
                return "<span class='orange-status'>" + SYNO.SDS.iSCSI.Utils.T("log", "warn_level") + "</span>";
            case "info":
                return "<span class='iscsi-log-text-info'>" + SYNO.SDS.iSCSI.Utils.T("log", "info_level") + "</span>";
            default:
                return "Undefined"
        }
    },
    htmlTimeRender: function(e) {
        var t = new Date(1e3 * e);
        return SYNO.SDS.DateTimeFormatter(t, {
            type: "datetimesec"
        })
    },
    getColumnModel: function() {
        return new Ext.grid.ColumnModel({
            columns: [{
                header: SYNO.SDS.iSCSI.Utils.T("common", "attr_priority"),
                dataIndex: "log_level",
                width: 100,
                align: "left",
                sortable: !0,
                renderer: this.logLevelRenderer
            }, {
                header: SYNO.SDS.iSCSI.Utils.T("log", "log_time"),
                dataIndex: "time",
                width: 150,
                align: "left",
                sortable: !0,
                renderer: this.htmlTimeRender
            }, {
                header: SYNO.SDS.iSCSI.Utils.T("log", "log_account"),
                dataIndex: "user",
                width: 100,
                align: "left",
                sortable: !0,
                renderer: SYNO.SDS.iSCSI.Utils.htmlEncodeRender
            }, {
                id: "descr",
                header: SYNO.SDS.iSCSI.Utils.T("log", "log_action"),
                dataIndex: "event",
                css: "white-space:normal;",
                width: 300,
                renderer: SYNO.SDS.iSCSI.Utils.htmlEventEncodeRender
            }],
            defaults: {
                sortable: !1,
                menuDisabled: !1
            }
        })
    },
    fillConfig: function(e) {
        var t = this;
        t.searchPanel = t.initSearchForm(), t.logStore = t.getStore(), t.paging = t.initPagingToolbar();
        var i = {
            border: !1,
            trackResetOnLoad: !0,
            layout: "fit",
            itemId: "iscsi_log",
            tbar: t.initToolbar(),
            enableColumnMove: !1,
            enableHdMenu: !1,
            bbar: t.paging,
            store: t.logStore,
            colModel: t.getColumnModel(),
            view: new SYNO.ux.FleXcroll.grid.BufferView({
                rowHeight: 27,
                scrollDelay: 30,
                borderHeight: 1,
                emptyText: SYNO.SDS.iSCSI.Utils.EmptyMsgRender(SYNO.SDS.iSCSI.Utils.T("log", "no_log_available")),
                templates: {
                    cell: new Ext.XTemplate('<td class="x-grid3-col x-grid3-cell x-grid3-td-{id} x-selectable {css}" style="{style}" tabIndex="-1" {cellAttr}>', '<div class="{this.selectableCls} x-grid3-cell-inner x-grid3-col-{id}" {attr}>{value}</div>', "</td>", {
                        selectableCls: SYNO.SDS.Utils.SelectableCLS
                    })
                }
            }),
            loadMask: !0,
            stripeRows: !0
        };
        return Ext.apply(i, e), i
    },
    isBelong: function(e, t) {
        var i;
        for (i in t)
            if (t[i] !== e[i]) return !1;
        return !0
    },
    isTheSame: function(e, t) {
        return this.isBelong(e, t) && this.isBelong(t, e)
    },
    onSearch: function(e, t) {
        var i = this,
            n = i.logStore;
        if (!i.isTheSame(n.baseParams, t)) {
            var s = ["date_from", "date_to", "keyword", "log_level"];
            if (t.date_from && (t.date_from = Date.parseDate(t.date_from, SYNO.SDS.DateTimeUtils.GetDateFormat()) / 1e3), t.date_to) {
                var a = Date.parseDate(t.date_to, SYNO.SDS.DateTimeUtils.GetDateFormat());
                a.setDate(a.getDate() + 1), t.date_to = a / 1e3 - 1
            }
            s.forEach(function(e) {
                n.baseParams[e] = t[e]
            }), i.loadData()
        }
    },
    setUnread: function() {
        var e = this;
        e.sendWebAPI({
            api: "SYNO.Core.ISCSI.Node",
            version: 1,
            method: "log_list",
            params: {
                additional: ["update_unread"]
            },
            scope: e
        })
    },
    onActive: function() {
        this.loadData(), this.setUnread()
    },
    enableButtonCheck: function() {
        this.logStore.getTotalCount() ? (this.exportButton.enable(), this.clearButton.enable()) : (this.exportButton.disable(), this.clearButton.disable())
    },
    loadData: function() {
        var e = this.logStore,
            t = {
                offset: 0,
                limit: this.itemsPerPage
            };
        e.load({
            params: t
        }), this.enableButtonCheck()
    },
    loadException: function() {
        this.appWin.clearStatusBusy(), this.setMask(!0)
    },
    onBeforeStoreLoad: function(e, t) {
        this.appWin.setStatusBusy()
    },
    onAfterStoreLoad: function(e, t, i) {
        var n = this;
        n.appWin.clearStatusBusy(), t.length < 1 ? n.setMask(!0) : n.setMask(!1), n.setPagingToolbar(e, n.paging), this.enableButtonCheck()
    },
    setMask: function(e) {
        SYNO.SDS.iSCSI.Utils.SetEmptyIcon(this, e)
    },
    setPagingToolbar: function(e, t) {
        this.setPagingToolbarVisible(t, e.getTotalCount() > this.itemsPerPage)
    },
    setPagingToolbarVisible: function(e, t) {
        e.setButtonsVisible(!0)
    },
    updateFbarItems: function(e) {
        this.isVisible()
    },
    onClearLogDone: function(e, t, i, n) {
        e ? this.loadData() : this.appWin.getMsgBox().alert(this.appWin.title, SYNO.SDS.iSCSI.Utils.T("common", "error_system")), this.appWin.clearStatusBusy()
    },
    onLogClear: function() {
        var e = this;
        e.appWin.getMsgBox().confirmDelete(e.appWin.title, SYNO.SDS.iSCSI.Utils.T("log", "log_cfrm_clear"), function(t) {
            "yes" === t && (e.appWin.setStatusBusy(), e.appWin.sendWebAPI({
                api: "SYNO.Core.ISCSI.Node",
                version: 1,
                method: "log_clear",
                callback: e.onClearLogDone,
                scope: e
            }))
        }, e, {
            yes: {
                text: SYNO.SDS.iSCSI.Utils.T("common", "btn_clear"),
                btnStyle: "red"
            },
            no: {
                text: Ext.MessageBox.buttonText.no
            }
        })
    },
    onExportCSV: function() {
        this.onLogSave("csv")
    },
    onExportHtml: function() {
        this.onLogSave("html")
    },
    onLogSave: function(e) {
        if (_S("demo_mode")) return void this.appWin.getMsgBox().alert(this.appWin.title, _JSLIBSTR("uicommon", "error_demo"));
        this.saveLog(e)
    },
    saveLog: function(e) {
        var t = this,
            i = t.logStore,
            n = {
                export_format: e
            };
        Ext.apply(n, i.baseParams), t.downloadWebAPI({
            webapi: {
                version: 1,
                api: "SYNO.Core.ISCSI.Node",
                method: "log_export",
                params: n
            },
            scope: t
        })
    },
    destroy: function() {
        this.rowNav && (Ext.destroy(this.rowNav), this.rowNav = null), this.searchField && this.searchField.fireEvent("destroy"), this.callParent([this])
    }
}), Ext.define("SYNO.SDS.iSCSI.Welcome.MainWindow", {
    extend: "SYNO.SDS.iSCSI.ModalWindow",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner, t.curDot = 0, t.content = [SYNO.SDS.iSCSI.Utils.T("san_welcome", "desc_support_fibre_and_iscsi"), SYNO.SDS.iSCSI.Utils.T("san_welcome", "desc_host_management"), SYNO.SDS.iSCSI.Utils.T("san_welcome", "desc_storage_console")], t.contentId = Ext.id(), t.prevBtnId = Ext.id(), t.nextBtnId = Ext.id(), t.startBtnId = Ext.id();
        var i = t.initDotsHtml(),
            n = {
                width: 600,
                height: 450,
                bodyBorder: !1,
                elements: "body",
                resizable: !1,
                header: !1,
                draggable: !1,
                useStatusBar: !1,
                items: [{
                    xtype: "box",
                    html: '<div class="iscsi-welcome-top-picture"></div><div class="iscsi-welcome-title-container"><p class="iscsi-welcome-title">' + SYNO.SDS.iSCSI.Utils.T("san_welcome", "title") + '</p></div><div class="iscsi-welcome-main-container"><div id="' + t.prevBtnId + '" class="iscsi-welcome-main-left-arrow"></div><div class="iscsi-welcome-main-content-container"><p id="' + t.contentId + '"class="iscsi-welcome-main-content">' + t.content[t.curDot] + '</p></div><div id="' + t.nextBtnId + '" class="iscsi-welcome-main-right-arrow"></div></div><div class="iscsi-welcome-button-container"><span id="' + t.startBtnId + '" class="x-btn syno-ux-button syno-ux-button-blue x-btn-noicon iscsi-welcome-start-btn"><button class="x-btn-text">' + SYNO.SDS.iSCSI.Utils.T("common", "start") + '</button></span></div><div class="iscsi-welcome-dot-container">' + i + "</div>",
                    listeners: {
                        afterrender: function() {
                            t.updatePage(), t.bindBtnListeners()
                        },
                        scope: t,
                        single: !0
                    }
                }]
            };
        t.callParent([Ext.apply(n, e)])
    },
    initDotsHtml: function() {
        var e = this,
            t = "";
        return e.content.forEach(function(e, i) {
            var n = "sanmgr_welcome_page_dot_" + i;
            t += String.format('<span id="{0}"></span>', n)
        }), t
    },
    bindBtnListeners: function() {
        var e = this,
            t = function(e, t) {
                return (e % t + t) % t
            };
        Ext.get(e.prevBtnId).on("click", function() {
            e.curDot = t(e.curDot - 1, e.content.length), e.updatePage()
        }), Ext.get(e.nextBtnId).on("click", function() {
            e.curDot = t(e.curDot + 1, e.content.length), e.updatePage()
        }), Ext.get(e.startBtnId).on("click", function() {
            e.close()
        }), e.content.forEach(function(t, i) {
            Ext.get("sanmgr_welcome_page_dot_" + i).on("click", function() {
                e.curDot = i, e.updatePage()
            })
        })
    },
    updatePage: function() {
        var e = this,
            t = "sanmgr_welcome_page_dot_" + e.curDot;
        Ext.get(e.contentId).update(e.content[e.curDot]), e.content.forEach(function(e, i) {
            var n = "sanmgr_welcome_page_dot_" + i;
            t === n ? Ext.get(t).replaceClass("iscsi-welcome-dot", "iscsi-welcome-dot-click") : Ext.get(n).replaceClass("iscsi-welcome-dot-click", "iscsi-welcome-dot")
        })
    },
    onClose: function() {
        var e = this;
        e.sendWebAPI({
            api: "SYNO.Core.ISCSI.Node",
            version: 1,
            method: "welcome_set",
            scope: e
        })
    }
}), Ext.define("SYNO.SDS.iSCSI.Welcome.PromoteWindow", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(e) {
        var t = this;
        t.appWin = e.appWin, t.owner = e.owner;
        var i = {
            title: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "storage_console_promote_title"),
            width: 560,
            height: 320,
            resizable: !0,
            buttons: [{
                xtype: "syno_button",
                btnStyle: "blue",
                text: SYNO.SDS.iSCSI.Utils.T("common", "alt_apply"),
                scope: t,
                handler: t.onSave
            }],
            items: [t.createForm()]
        };
        t.callParent([Ext.apply(i, e)])
    },
    createForm: function() {
        var e = this,
            t = "https://www.synology.com/en-global/support/download/" + _D("upnpmodelname", "") + "#utilities";
        return {
            xtype: "syno_formpanel",
            height: 220,
            itemId: "info",
            cls: "syno-app-iscsi",
            trackResetOnLoad: !1,
            items: [{
                xtype: "syno_panel",
                layout: "vbox",
                layoutConfig: {
                    align: "stretch"
                },
                items: [{
                    xtype: "syno_panel",
                    layout: "hbox",
                    layoutConfig: {
                        align: "middle"
                    },
                    height: 116,
                    padding: "0px 0px 20px",
                    items: [{
                        xtype: "syno_displayfield",
                        width: 80,
                        cls: "iscsi-storage-console-icon",
                        value: "",
                        htmlEncode: !1
                    }, {
                        xtype: "syno_displayfield",
                        value: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "storage_console_promote_desc") + " " + String.format('<a href="https://www.synology.com/dsm/software_spec/iscsi_manager" target="_blank">{0}</a>', SYNO.SDS.iSCSI.Utils.T("iscsimgr", "learn_more")),
                        htmlEncode: !1
                    }]
                }, {
                    xtype: "syno_displayfield",
                    cls: "iscsi-retention-descpanel",
                    value: String.format(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "storage_console_download_desc"), '<a href="' + t + '" target="_blank">', "</a>"),
                    htmlEncode: !1
                }]
            }],
            bbar: e.checkout_panel = new SYNO.ux.Panel({
                itemId: "bbar_panel",
                padding: "0px 10px 14px 0px",
                items: [{
                    xtype: "syno_checkbox",
                    name: "never_remind",
                    itemId: "never_remind",
                    boxLabel: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "storage_console_promote_not_show_again")
                }]
            })
        }
    },
    onSave: function() {
        var e = this;
        e.checkout_panel.getComponent("never_remind").getValue() && e.sendWebAPI({
            api: "SYNO.Core.ISCSI.Node",
            method: "set",
            params: {
                promote_storage_console: !1
            },
            version: 1,
            scope: this,
            callback: function(e, t) {
                SYNO.Debug("SYNO.Core.ISCSI.Node set: " + (e ? "succeeded" : "faileded"))
            }
        }), e.close()
    }
}), Ext.define("SYNO.SDS.iSCSI.Application", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.iSCSI.MainWindow"
}), Ext.define("SYNO.SDS.iSCSI.Store", {
    constructor: function(e) {
        var t = this;
        t.count = 0, t.data = {}, t.env = {}, t.dataArray = [], t.callParent([e])
    },
    getAll: function() {
        return this.dataArray
    },
    getMatched: function() {
        var e, t, i = this,
            n = arguments,
            s = [];
        for (e in i.data) i.data.hasOwnProperty(e) && (t = i.data[e], t.check.apply(t, n) && s.push(t));
        return s.sort(function(e, t) {
            return e = e.get("id"), t = t.get("id"), e > t ? 1 : e < t ? -1 : 0
        }), s
    },
    isAnyMatched: function() {
        var e = arguments;
        return void 0 !== this.findBy(function(t) {
            return t.check.apply(t, e)
        })
    },
    findBy: function(e) {
        var t, i, n = this;
        for (t in n.data)
            if (n.data.hasOwnProperty(t) && (i = n.data[t], e(i))) return i
    },
    getById: function(e) {
        return this.data[e]
    },
    prepareArray: function() {
        var e, t = this;
        for (e in t.data) t.data.hasOwnProperty(e) && t.dataArray.push(t.data[e]);
        t.dataArray.sort(function(e, t) {
            return e.get("num_id") > t.get("num_id") ? 1 : e.get("num_id") === t.get("num_id") ? 0 : -1
        })
    }
}), Ext.define("SYNO.SDS.iSCSI.MainWindow", {
    extend: "SYNO.SDS.PageListAppWindow",
    activePage: "SYNO.SDS.iSCSI.Overview.Main",
    defaultWinSize: {
        width: 1160,
        height: 620
    },
    SizeRender: SYNO.SDS.Utils.StorageUtils.UiRenderHelper.SizeRender,
    pollingInterval: 5,
    webapiTimeGet: {
        api: "SYNO.Core.Region.NTP",
        version: 1,
        method: "get"
    },
    webapiFCTrgList: {
        api: "SYNO.Core.ISCSI.FCTarget",
        version: 1,
        method: "list",
        additional: ["mapped_lun", "acls", "connected_sessions", "status", "speed"]
    },
    webapiTrgList: {
        api: "SYNO.Core.ISCSI.Target",
        version: 1,
        method: "list",
        additional: ["mapped_lun", "acls", "connected_sessions", "status"]
    },
    webapiVolumeList: {
        api: "SYNO.Core.Storage.Volume",
        version: 1,
        method: "list",
        limit: -1,
        offset: 0,
        location: "all"
    },
    webapiPoolList: {
        api: "SYNO.Core.Storage.Pool",
        version: 1,
        method: "list",
        limit: -1,
        offset: 0
    },
    webapiiSCSILunList: {
        api: "SYNO.Core.ISCSI.LUN",
        version: 1,
        method: "list",
        types: ["BLOCK", "FILE", "THIN", "ADV", "SINK", "CINDER", "CINDER_BLUN", "CINDER_BLUN_THICK", "BLUN", "BLUN_THICK", "BLUN_SINK", "BLUN_THICK_SINK"],
        additional: ["is_action_locked", "is_mapped", "extent_size", "allocated_size", "status", "allow_bkpobj", "flashcache_status", "family_config", "sync_progress", "snapshot_info", "acls"]
    },
    webapiUnreadEventList: {
        api: "SYNO.Core.ISCSI.Node",
        version: 1,
        method: "log_list",
        limit: 0,
        additional: ["unread"]
    },
    webapiNetInterfaceList: {
        api: "SYNO.Core.Network.Interface",
        version: 1,
        method: "list"
    },
    webapiRetentionInfo: {
        api: "SYNO.DisasterRecovery.Retention",
        method: "info",
        version: 1
    },
    webpaiReplicationList: {
        api: "SYNO.Core.ISCSI.Replication",
        method: "list",
        version: 1
    },
    webapiHostList: {
        api: "SYNO.Core.ISCSI.Host",
        method: "list",
        version: 1,
        additional: ["acls"]
    },
    constructor: function(e) {
        var t = this;
        t.isVDSM = "kvmx64" === _D("synobios") || "nextkvmx64" === _D("synobios"), t.isSDRRunning = _S("systemdr_running"), t.supportVAAI = "yes" === _D("support_vaai", "no"), t.isLio4x = "lio4x" === _D("iscsi_target_type"), t.supportPerfEvent = "yes" === _D("support_performance_event"), t.supportBtrfsLun = "yes" === _D("support_iscsi_btrfs_lun", "no"), t.maxSnapshotPerLun = _D("max_snapshot_per_lun", "256"), t.supportFC = "yes" === _D("support_fc", "no"), t.webapis = {
            "SYNO.SDS.iSCSI.Host.Main": [t.webapiVolumeList, t.webapiPoolList, t.webapiTrgList, t.webapiFCTrgList, t.webapiiSCSILunList, t.webapiHostList],
            "SYNO.SDS.SAN.Fibre.Main": [t.webapiVolumeList, t.webapiPoolList, t.webapiFCTrgList, t.webapiiSCSILunList, t.webapiTrgList, t.webapiHostList],
            "SYNO.SDS.iSCSI.Target.Main": [t.webapiVolumeList, t.webapiPoolList, t.webapiTrgList, t.webapiiSCSILunList, t.webapiNetInterfaceList, t.webapiHostList],
            "SYNO.SDS.iSCSI.LUN.Main": [t.webapiVolumeList, t.webapiPoolList, t.webapiTrgList, t.webapiFCTrgList, t.webapiiSCSILunList, t.webapiHostList, t.webpaiReplicationList],
            "SYNO.SDS.iSCSI.Snapshot.Main": [t.webapiTimeGet, t.webapiVolumeList, t.webapiPoolList, t.webapiTrgList, t.webapiFCTrgList, t.webapiiSCSILunList, t.webapiRetentionInfo],
            "SYNO.SDS.iSCSI.Overview.Main": [t.webapiVolumeList, t.webapiPoolList, t.webapiTrgList, t.webapiFCTrgList, t.webapiiSCSILunList, t.webapiUnreadEventList],
            "SYNO.SDS.iSCSI.Setting.Main": [t.webapiiSCSILunList]
        }, t.callParent([t.fillConfig(e)]), t.mon(t, "data_ready", function() {
            t.getActivePage().fireEvent("data_ready")
        }, t), t.mon(t, "poll_activate", function() {
            t.stopPollTask(), t.createPollTask(), t.startPollTask()
        }, t)
    },
    fillConfig: function(e) {
        var t;
        t = this.getListItems();
        var i = {
            cls: "syno-app-iscsi",
            width: this.defaultWinSize.width,
            height: this.defaultWinSize.height,
            minWidth: this.defaultWinSize.width,
            minHeight: this.defaultWinSize.height,
            activePage: "SYNO.SDS.iSCSI.Overview.Main",
            listItems: t
        };
        return Ext.apply(i, e), i
    },
    getListItems: function() {
        return [{
            text: SYNO.SDS.iSCSI.Utils.T("tree", "leaf_overview"),
            iconCls: "icon-overview",
            fn: "SYNO.SDS.iSCSI.Overview.Main",
            help: "overview.html"
        }, {
            text: "LUN",
            iconCls: "icon-iscsi-lun",
            fn: "SYNO.SDS.iSCSI.LUN.Main",
            help: "lun.html"
        }, {
            text: "iSCSI",
            iconCls: "icon-iscsi-target",
            fn: "SYNO.SDS.iSCSI.Target.Main",
            help: "iscsi.html"
        }, {
            text: SYNO.SDS.iSCSI.Utils.T("san_fibre", "fibre_channel"),
            iconCls: "icon-fc-target",
            fn: "SYNO.SDS.SAN.Fibre.Main",
            help: "fibre_channel.html",
            hidden: !this.supportFC
        }, {
            text: SYNO.SDS.iSCSI.Utils.T("san_host", "host"),
            iconCls: "icon-host",
            fn: "SYNO.SDS.iSCSI.Host.Main",
            help: "lun.html"
        }, {
            text: SYNO.SDS.iSCSI.Utils.T("iscsilun", "snapshot"),
            iconCls: "icon-snapshot",
            fn: "SYNO.SDS.iSCSI.Snapshot.Main",
            help: "snapshot.html",
            hidden: !this.supportVAAI
        }, {
            text: SYNO.SDS.iSCSI.Utils.T("common", "common_settings"),
            iconCls: "icon-settings",
            fn: "SYNO.SDS.iSCSI.Setting.Main",
            help: "setting.html"
        }, {
            text: SYNO.SDS.iSCSI.Utils.T("tree", "leaf_log"),
            iconCls: "icon-log",
            fn: "SYNO.SDS.iSCSI.Log.Main",
            help: "overview.html"
        }]
    },
    launchPageOnOpen: function(e) {
        var t = this;
        if (!this.checkModalOrMask())
            if (this.openParams = e, "CloneSnapshot" === e.dlg) this.selectPage("SYNO.SDS.iSCSI.Snapshot.Main"), this.on("afterlaunchpage", function() {
                var e = this.openParams.params,
                    t = new SYNO.SDS.iSCSI.LUN.iSCSILUN,
                    i = this.volumes,
                    n = this.pools,
                    s = this.iscsiLuns.getById(e.lun_uuid);
                if (s) {
                    s.getSnapshotPageInfo(i, n), t = s;
                    new SYNO.SDS.iSCSI.Snapshot.LUNSnapList({
                        appWin: this,
                        owner: this,
                        launchfrom3rd: !0,
                        snapshotuuidfrom3rd: e.snapshot_uuid,
                        title: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "snap_list") + " - " + t.get("name"),
                        lun: t
                    }).open()
                }
            }, this, {
                single: !0
            });
            else if ("FocusLun" === e.dlg) {
            if (!this.openParams || !this.openParams.params || !this.openParams.params.lun_uuid) return;
            var i = this.openParams.params.lun_uuid;
            this.selectPage("SYNO.SDS.iSCSI.LUN.Main");
            var n = function() {
                    var e = t.getActivePage();
                    e && Ext.isFunction(e.setFocus) && e.setFocus(i)
                },
                s = this.getActivePage();
            s && s.layoutDrawn ? n() : this.on("afterlaunchlunpage", function() {
                n()
            }, this, {
                single: !0
            })
        }
    },
    onSelectionModelChange: function() {
        var e = this,
            t = e.getActivePage();
        t && ("SYNO.SDS.iSCSI.Overview.Main" === t.itemId ? e.getPageCt().addClass("iscsi-overview-panel") : e.getPageCt().removeClass("iscsi-overview-panel"))
    },
    onOpen: function(e) {
        var t = this;
        t.initEnv(), t.callParent(arguments), t.mon(SYNO.SDS.StatusNotifier, "redirect", t.stopPollTask, t), t.mon(SYNO.SDS.StatusNotifier, "logout", t.stopPollTask, t), t.mon(SYNO.SDS.StatusNotifier, "halt", t.stopPollTask, t), t.mon(t.getPageList().getSelectionModel(), "selectionchange", t.onSelectionModelChange, t)
    },
    onClose: function() {
        this.stopPollTask()
    },
    initEnv: function() {
        function e() {
            return t.apply(this, arguments)
        }
        var t = _asyncToGenerator(regeneratorRuntime.mark(function e() {
            var t, i;
            return regeneratorRuntime.wrap(function(e) {
                for (;;) switch (e.prev = e.next) {
                    case 0:
                        return t = this, e.prev = 1, e.next = 4, t.sendWebAPIPromise({
                            api: "SYNO.Core.ISCSI.Node",
                            version: 1,
                            method: "get",
                            params: {
                                additional: ["no_rod_key", "iqn_hash_key", "tp_hard_threshold_bytes", "promote_storage_console"]
                            },
                            scope: t
                        });
                    case 4:
                        i = e.sent, i && (t.env = {
                            chap_info: i.chap_info,
                            iqn_hash_key: i.iqn_hash_key,
                            tp_hard_threshold_bytes: i.tp_hard_threshold_bytes,
                            promote_storage_console: i.promote_storage_console,
                            show_welcome_page: i.show_welcome_page
                        }), e.next = 11;
                        break;
                    case 8:
                        e.prev = 8, e.t0 = e.catch(1), t.env = {};
                    case 11:
                        t.selectPage(t.activePage);
                    case 12:
                    case "end":
                        return e.stop()
                }
            }, e, this, [
                [1, 8]
            ])
        }));
        return e
    }(),
    processTargetsStore: function(e) {
        var t = e.reduce(function(e, t) {
            var i = new SYNO.SDS.iSCSI.Target.Target,
                n = t.target_id;
            return i.data = t, i.id = t.target_id, e.data[n] = i, e
        }, new SYNO.SDS.iSCSI.Store);
        return t.prepareArray(), t.count = e.length, t
    },
    processISCSITargets: function(e) {
        this.iscsiTargets = this.processTargetsStore(e)
    },
    processFCTargets: function(e) {
        e = e.map(function(e) {
            return e.status = e.is_enabled ? e.status : "disabled", e.displayPort = String.format("{0} {1}-{2}", SYNO.SDS.iSCSI.Utils.T("common", "port"), e.pcie_slot_id, e.pcie_port_id), e.displayModel = e.name.split(" ").slice(0, -2).join(" "), e
        }), this.fcTargets = this.processTargetsStore(e)
    },
    processLUNs: function(e) {
        var t = e.reduce(function(e, t) {
            var i = new SYNO.SDS.iSCSI.LUN.iSCSILUN,
                n = t.uuid;
            return i.data = t, i.id = t.lun_id, i.prepareDevAttribsJson(), e.data[n] = i, e
        }, new SYNO.SDS.iSCSI.Store);
        t.prepareArray(), t.count = e.length, this.iscsiLuns = t
    },
    processReplication: function(e) {
        var t = this;
        e.forEach(function(e) {
            var i = e.is_source ? t.iscsiLuns.getById(e.src_lun_uuid) : t.iscsiLuns.getById(e.dst_lun_uuid);
            i && (i.hasReplicationTask = !0)
        })
    },
    processHosts: function(e) {
        this.hosts = e.map(function(e) {
            return e.initiator_ids = e.initiator_ids ? e.initiator_ids : [], e
        })
    },
    getCanCreateLunTypes: function() {
        var e = {},
            t = this.supportBtrfsLun ? "btrfs_lun" : "file_lun";
        return Ext.each(this.volumes, function(i) {
            return i.size_free_byte < SYNO.SDS.iSCSI.Utils.ISCSITRG_UNIT_GB || ("crashed" === i.status || ("read_only" === i.status || void("btrfs" === i.fs_type ? e[t] = !0 : "ext4" === i.fs_type && (e.file_lun = !0))))
        }), e
    },
    isUpToLunMaxCount: function() {
        var e = parseInt(_D("max_iscsiluns", 10), 10);
        return !!this.iscsiLuns && this.iscsiLuns.count >= e
    },
    isUpToTargetMaxCount: function() {
        var e = parseInt(_D("max_iscsitrgs", 10), 10);
        return !!this.iscsiTargets && this.iscsiTargets.count >= e
    },
    createPollTask: function(e) {
        var t = this,
            i = t.getActivePage().getItemId();
        t.pollTaskConf = {
            interval: t.pollingInterval,
            immediate: !0,
            appWindow: t,
            webapi: {
                api: "SYNO.Entry.Request",
                version: 2,
                method: "request",
                params: {
                    mode: "parallel",
                    compound: t.webapis[i]
                }
            },
            scope: t,
            status_callback: function(e, i, n) {
                if (!e) return t.clearStatusBusy(), t.getMsgBox().alert(SYNO.SDS.iSCSI.Utils.T("common", "app_title"), SYNO.SDS.iSCSI.Utils.T("common", "error_system")), void t.stopPollTask();
                t.processData(i), t.fireEvent("data_ready")
            }
        }
    },
    stopPollTask: function() {
        var e = this;
        void 0 !== e.pollTaskID && (e.pollUnreg(e.pollTaskID), delete e.pollTaskID)
    },
    startPollTask: function() {
        var e = this;
        void 0 === e.pollTaskID && (e.pollTaskID = e.pollReg(e.pollTaskConf))
    },
    restartPollTask: function() {
        this.stopPollTask(), this.startPollTask()
    },
    processData: function(e) {
        var t = this;
        t.volumes && delete t.volumes, t.volumes = [], Ext.each(e.result, function(e) {
            !0 === SYNO.ux.Utils.checkApiConsistency(t.webapiTimeGet, e) ? t.processNtpData(e.success ? e.data : null) : !0 === SYNO.ux.Utils.checkApiConsistency(t.webapiRetentionInfo, e) ? t.supportTimeTrigger = !!e.success && -1 !== e.data.adv_features.indexOf(SYNO.SDS.iSCSI.RET_TRIGGER_BY_TIME) : !0 === SYNO.ux.Utils.checkApiConsistency(t.webapiVolumeList, e) ? t.volumes = e.success ? e.data.volumes.filter(function(e) {
                return "usb" != e.location
            }) : [] : !0 === SYNO.ux.Utils.checkApiConsistency(t.webapiPoolList, e) ? t.pools = e.success ? e.data.pools : [] : !0 === SYNO.ux.Utils.checkApiConsistency(t.webapiTrgList, e) ? t.processISCSITargets(e.success ? e.data.targets : []) : !0 === SYNO.ux.Utils.checkApiConsistency(t.webapiFCTrgList, e) ? t.processFCTargets(e.success ? e.data.targets : []) : !0 === SYNO.ux.Utils.checkApiConsistency(t.webapiiSCSILunList, e) ? t.processLUNs(e.success ? e.data.luns : []) : !0 === SYNO.ux.Utils.checkApiConsistency(t.webapiUnreadEventList, e) ? t.summary = e.success ? e.data.summary : {} : !0 === SYNO.ux.Utils.checkApiConsistency(t.webapiNetInterfaceList, e) ? t.netInterfaces = e.success ? e.data : [] : !0 === SYNO.ux.Utils.checkApiConsistency(t.webpaiReplicationList, e) ? t.processReplication(e.success ? e.data.tasks : []) : !0 === SYNO.ux.Utils.checkApiConsistency(t.webapiHostList, e) && t.processHosts(e.success ? e.data.hosts : [])
        }, t), t.env.promote_storage_console && (t.env.promote_storage_console = !1, t.openPromoteWindow()), t.env.show_welcome_page && (t.env.show_welcome_page = !1, t.openWelcomeWindow())
    },
    processNtpData: function(e) {
        if (e) {
            var t = SYNO.SDS.iSCSI.Utils;
            t.dsNowSec = e.timestamp, t.timestampNow = Math.round((new Date).getTime() / 1e3)
        }
    },
    createPage: function(e) {
        var t = Ext.getClassByName(e),
            i = new t({
                appWin: this,
                owner: this
            });
        return i.itemId = e, i
    },
    genNewTargetName: function() {
        for (var e, t = 0; !this.isUniqueTargetName(e = "Target-" + ++t););
        return e
    },
    genNewIQN: function(e) {
        var t = _S("hostname");
        t = t.replace(/_/g, "-"), t = t.replace(/\+/g, "p");
        for (var i = "iqn.2000-01.com.synology:" + t + "." + e, n = "." + this.getUniqueKey(), s = i, a = 1; !this.isUniqueIQN(s + n);) s = i + a++;
        return s + n
    },
    genNewLunName: function() {
        for (var e, t = 0; !this.isUniqueLunName(e = "LUN-" + ++t););
        return e
    },
    getUniqueKey: function() {
        return this.env && Ext.isString(this.env.iqn_hash_key) ? this.env.iqn_hash_key : ""
    },
    setTpHardThreshold: function(e) {
        this.env && (this.env.tp_hard_threshold_bytes = e)
    },
    getTpHardThreshold: function() {
        return this.env && this.env.tp_hard_threshold_bytes ? this.env.tp_hard_threshold_bytes : SYNO.SDS.iSCSI.TP_HARD_THRESHOLD_DEFAULT_SIZE
    },
    isLowCapacityWriteEnable: function() {
        return this.getTpHardThreshold() < SYNO.SDS.iSCSI.TP_HARD_THRESHOLD_DEFAULT_SIZE
    },
    isUniqueIQN: function(e) {
        return !this.iscsiTargets.isAnyMatched(function() {
            return this.get("iqn").toUpperCase() === e.toUpperCase()
        })
    },
    isUniqueWWPN: function(e) {
        return !this.fcTargets.isAnyMatched(function() {
            return this.get("wwpn").toUpperCase() === e.toUpperCase()
        })
    },
    isUniqueTargetName: function(e) {
        return !this.iscsiTargets.isAnyMatched(function() {
            return this.get("name") === e
        })
    },
    isUniqueFCTargetName: function(e) {
        return !this.fcTargets.isAnyMatched(function() {
            return this.get("name") === e
        })
    },
    isUniqueLunName: function(e) {
        return !this.iscsiLuns.isAnyMatched(function() {
            return this.get("name") === e
        })
    },
    isUniqueHostName: function(e) {
        return !this.hosts.find(function(t) {
            return t.name === e
        })
    },
    genTargetLUNMapping: function() {
        var e = this.iscsiTargets.getAll(),
            t = this.fcTargets.getAll(),
            i = this.iscsiLuns,
            n = i.getAll();
        Ext.each(n, function(e) {
            e.mappedTargets = [], e.isConnected = !1
        }), Ext.each(e, function(e) {
            Ext.each(e.get("mapped_luns"), function(t) {
                var n = i.getById(t.lun_uuid);
                n.mappedTargets.push(e.id), n.isConnected = n.isConnected || 0 < e.get("connected_sessions").length
            })
        }), Ext.each(t, function(e) {
            Ext.each(e.get("mapped_luns"), function(t) {
                var n = i.getById(t.lun_uuid);
                n.mappedTargets.push(e.id), n.isConnected = n.isConnected || 0 < e.get("connected_sessions").length
            })
        }), this.genLunMappingType(), this.genLunPrivilegeType()
    },
    genLunMappingType: function() {
        var e = this;
        e.iscsiLuns.getAll().forEach(function(t) {
            var i = t.get("uuid"),
                n = function(e) {
                    return i === e.lun_uuid
                },
                s = e.fcTargets.getAll().some(function(e) {
                    return e.get("mapped_luns").some(n)
                });
            e.iscsiLuns.getById(i).set("mappingType", s ? "fc" : "iscsi")
        })
    },
    genLunPrivilegeType: function() {
        var e = this,
            t = e.iscsiLuns.getAll().filter(function(e) {
                return e.get("acls").find(function(e) {
                    return "iqn.2000-01.com.synology:default.acl" === e.iqn && "rw" === e.permission
                })
            }).map(function(e) {
                return e.get("uuid")
            });
        e.iscsiLuns.getAll().forEach(function(i) {
            var n = i.get("uuid");
            e.iscsiLuns.getById(n).set("privilege", -1 !== t.indexOf(n) ? "allow_all" : "for_each")
        })
    },
    genHostConnectedSessions: function() {
        var e = this,
            t = [];
        e.fcTargets.getAll().forEach(function(e) {
            e.get("connected_sessions").forEach(function(e) {
                t.push(e.wwpn)
            })
        }), e.iscsiTargets.getAll().forEach(function(e) {
            e.get("connected_sessions").forEach(function(e) {
                t.push(e.iqn)
            })
        }), e.hosts.map(function(e) {
            return e.is_connected = e.initiator_ids.some(function(e) {
                return -1 !== t.indexOf(e)
            }), e
        })
    },
    getMappedTrgs: function(e, t) {
        void 0 === this.iscsiLuns.getById(e).mappedTargets && this.genTargetLUNMapping();
        var i = this.iscsiTargets,
            n = this.fcTargets,
            s = [];
        return Ext.each(this.iscsiLuns.getById(e).mappedTargets, function(e) {
            var a = i.getById(e),
                o = n.getById(e);
            a ? s.push({
                name: a.get("name"),
                status: t ? SYNO.SDS.iSCSI.Utils.TargetStatusRender(a.get("status")) : a.get("status")
            }) : o && s.push({
                name: o.get("displayPort"),
                status: t ? SYNO.SDS.iSCSI.Utils.FCStatusRender(o.get("status")) : o.get("status")
            })
        }), s
    },
    getLunACLs: function(e) {
        var t = function(t) {
            return t.find(function(t) {
                return t.lun_uuid === e
            })
        };
        return this.hosts.reduce(function(e, i) {
            var n = t(i.acls);
            return n && e.push({
                name: i.name,
                description: "" === i.description ? "&nbsp" : Ext.util.Format.htmlEncode(i.description),
                status: SYNO.SDS.iSCSI.Utils.renderPermission(n.permission)
            }), e
        }, [])
    },
    hasFibreChannels: function() {
        return this.supportFC && 0 < this.fcTargets.getAll().length
    },
    canMapFCTarget: function() {
        return this.hasFibreChannels()
    },
    openWelcomeWindow: function() {
        var e = this;
        new SYNO.SDS.iSCSI.Welcome.MainWindow({
            appWin: e.appWin,
            owner: e
        }).open()
    },
    openPromoteWindow: function() {
        var e = this;
        new SYNO.SDS.iSCSI.Welcome.PromoteWindow({
            appWin: e.appWin,
            owner: e
        }).open()
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.Wizard.LunTypeBoxTmpl", {
    extend: "Ext.XTemplate",
    constructor: function(e) {
        var t = this.createTpl();
        this.no_subtitle = e.no_subtitle || !1, t.push(this.fillConfig(e)), this.callParent(t)
    },
    fillConfig: function(e) {
        var t = {
                compiled: !0,
                disableFormats: !0
            },
            i = {
                btrfs: {
                    title: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "btrfs_lun"),
                    subtitle: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "btrfs_lun_subtitle"),
                    desc: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "btrfs_lun_desc")
                },
                file: {
                    title: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "file_lun"),
                    subtitle: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "ext4_lun_subtitle"),
                    desc: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "file_lun_desc")
                },
                block: {
                    title: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "block_lun"),
                    subtitle: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "block_lun_subtitle"),
                    desc: SYNO.SDS.iSCSI.Utils.T("iscsimgr", "block_lun_desc")
                }
            };
        return t.getTitle = function(e) {
            return i[e].title
        }, t.getSubTitle = function(e) {
            return this.no_subtitle ? "" : i[e].subtitle
        }, t.getDesc = function(e) {
            return i[e].desc
        }, Ext.apply(t, e)
    },
    createTpl: function() {
        return ['<tpl if="canCreate === true">', '<div class="iscsi-lun-typebox iscsi-lun-typebox-{clickType} iscsi-grid-row">', "</tpl>", '<tpl if="canCreate === false">', '<div class="iscsi-lun-typebox-disable iscsi-grid-row">', '<div class="lun-disable-overlap">', '<div class="lun-disable-tip">', String.format(SYNO.SDS.iSCSI.Utils.T("iscsimgr", "lun_create_tip"), '<a class="link-font" style="cursor:pointer">', "</a>"), "</div>", "</div>", "</tpl>", '<div class="item-icon-wrap">', '<tpl if="canCreate === true">', '<div class="item-icon iscsi-lun-icon-wizard iscsi-lun-icon-wizard-{type}"></div>', "</tpl>", '<tpl if="canCreate === false">', '<div class="item-icon iscsi-lun-icon-wizard iscsi-lun-icon-wizard-disable"></div>', "</tpl>", "</div>", '<div class="lun-title">', '<p class="title">{[ this.getTitle(values.type) ]}<span class="sub-title">{[ this.getSubTitle(values.type) ]}</span></p>', "</div>", '<div class="lun-desc-wrap">', '<div class="lun-desc">{[ this.getDesc(values.type) ]}</div>', "</div>", '<div class="x-clear"></div>', "<div>"]
    }
}), Ext.define("SYNO.SDS.iSCSI.LUN.Wizard.LunTypeBox", {
    extend: "SYNO.ux.Panel",
    constructor: function(e) {
        this.type = e.type, this.hidden = e.hidden || !1, this.can_create = e.can_create || !0, this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        this.tpl = new SYNO.SDS.iSCSI.LUN.Wizard.LunTypeBoxTmpl(e);
        var t = {
            hidden: this.hidden,
            items: [{
                itemId: "lunBox",
                xtype: "box",
                html: ""
            }],
            listeners: {
                scope: this,
                afterrender: this.onAfterRender,
                update: this.updateTpl
            }
        };
        return Ext.apply(t, e), t
    },
    onAfterRender: function() {
        this.can_create && this.mon(this.body, "click", this.onMouseClick, this)
    },
    updateTpl: function() {
        this.tpl.overwrite(this.getComponent("lunBox").getEl(), {
            type: this.type,
            clickType: this.owner.lunType === this.type ? "click" : "unclick",
            canCreate: this.can_create
        });
        var e = this.getComponent("lunBox").getEl().query("a");
        if (e.length > 0) {
            var t = Ext.get(e[0]),
                i = function() {
                    SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance", {
                        fn: "block" === this.type ? "SYNO.SDS.StorageManager.Pool.Main" : "SYNO.SDS.StorageManager.Volume.Main"
                    })
                };
            this.mon(t, "click", i, this)
        }
    },
    onMouseClick: function() {
        this.owner.typeSelect(this.type)
    }
});
