/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.USBCopy.Model.TypeMenu
 * @extends Ext.menu.Menu
 * USBCopy model menu 
 *
 */
Ext.define("SYNO.SDS.USBCopy.Model.TypeMenu", {
    extend: "Ext.menu.Menu",
    typeItems: null,
    allTypeId: null,
    clearAllId: null,
    shadow: false,
    cls: "syno-ux-schedule-menu",
    constructor: function(a) {
        this.owner = a.owner;
        SYNO.SDS.USBCopy.Model.TypeMenu.superclass.constructor.call(this, a);
        this.initMenu()
    },
    initMenu: function() {
        var b = [{
            desc_id: SYNO.SDS.USBCopy.DESC_ID.TASK_CREATED,
            text: _USBCOPY_STR("log_search", "task_created")
        }, {
            desc_id: SYNO.SDS.USBCopy.DESC_ID.TASK_REMOVED,
            text: _USBCOPY_STR("log_search", "task_removed")
        }, {
            desc_id: SYNO.SDS.USBCopy.DESC_ID.TASK_ENABLED,
            text: _USBCOPY_STR("log_search", "task_enabled")
        }, {
            desc_id: SYNO.SDS.USBCopy.DESC_ID.TASK_DISABLED,
            text: _USBCOPY_STR("log_search", "task_disabled")
        }, {
            desc_id: SYNO.SDS.USBCopy.DESC_ID.SETTING_CHANGED_NAME,
            text: _USBCOPY_STR("log_search", "setting_changed_name")
        }, {
            desc_id: SYNO.SDS.USBCopy.DESC_ID.SETTING_EDITED,
            text: _USBCOPY_STR("log_search", "setting_edited")
        }, {
            desc_id: SYNO.SDS.USBCopy.DESC_ID.TASK_START,
            text: _USBCOPY_STR("log_search", "task_start")
        }, {
            desc_id: SYNO.SDS.USBCopy.DESC_ID.TASK_FINISH,
            text: _USBCOPY_STR("log_search", "task_finish")
        }, {
            desc_id: SYNO.SDS.USBCopy.DESC_ID.TASK_ABORT,
            text: _USBCOPY_STR("log_search", "task_abort")
        }, {
            desc_id: SYNO.SDS.USBCopy.DESC_ID.TASK_ERROR,
            text: _USBCOPY_STR("log_search", "task_error")
        }, {
            desc_id: SYNO.SDS.USBCopy.DESC_ID.TASK_ERROR_PARTIALLY_SUCCESS,
            text: _USBCOPY_STR("log_search", "task_error_partially_success")
        }, {
            desc_id: SYNO.SDS.USBCopy.DESC_ID.TASK_VERSION_ROTATION,
            text: _USBCOPY_STR("log_search", "task_version_rotation")
        }, {
            desc_id: SYNO.SDS.USBCopy.DESC_ID.FILE_ERROR,
            text: _USBCOPY_STR("log_search", "file_error")
        }];
        this.add({
            text: _USBCOPY_STR("log", "all_type"),
            id: this.allTypeId = Ext.id()
        }, {
            text: _USBCOPY_STR("log", "clear_all"),
            id: this.clearAllId = Ext.id()
        }, "-");
        this.typeItems = [];
        for (var a = 0; a < b.length; a++) {
            var c = new Ext.menu.CheckItem({
                text: b[a].text,
                checked: false,
                desc_id: b[a].desc_id
            });
            this.add(c);
            this.typeItems.push(c)
        }
    },
    setAllType: function() {
        for (var a = 0; a < this.typeItems.length; a++) {
            this.typeItems[a].setChecked(true)
        }
    },
    setClearAll: function() {
        for (var a = 0; a < this.typeItems.length; a++) {
            this.typeItems[a].setChecked(false)
        }
    },
    getCheckItems: function() {
        var a = [];
        for (var b = 0; b < this.typeItems.length; b++) {
            if (this.typeItems[b].checked) {
                a.push(this.typeItems[b])
            }
        }
        return a
    },
    getUncheckItems: function() {
        var a = [];
        for (var b = 0; b < this.typeItems.length; b++) {
            if (!this.typeItems[b].checked) {
                a.push(this.typeItems[b])
            }
        }
        return a
    }
});
Ext.define("SYNO.SDS.USBCopy.Model.LogDescTypeField", {
    extend: "Ext.form.TriggerField",
    defaultTriggerWidth: 27,
    editable: false,
    overCls: "syno-ux-schedulefield-hover",
    triggerClass: "syno-ux-schedulefield-trigger",
    msgTarget: "itip",
    constructor: function(a) {
        SYNO.SDS.USBCopy.Model.LogDescTypeField.superclass.constructor.call(this, a);
        this.menu = new SYNO.SDS.USBCopy.Model.TypeMenu(a);
        this.menu.mon(this.menu, "click", this.onItemClick, this);
        this.menu.mon(this.menu, "itemclick", this.onBeforeItemClick, this);
        this.menu.mon(this.menu, "hide", this.onHide, this);
        this.addClass("syno-ux-schedulefield")
    },
    isAfterItemClickInvoked: false,
    defaultAutoCreate: {
        tag: "input",
        type: "text",
        size: "10",
        autocomplete: "off"
    },
    onTriggerClick: function() {
        if (this.disabled) {
            return
        }
        this.menu.show(this.el, "tl-bl?");
        this.fireEvent("triggerClick")
    },
    getCheckedDescIDList: function() {
        var a = this.menu.getCheckItems();
        var c = [];
        for (var b = 0; b < a.length; b++) {
            c.push(a[b].desc_id)
        }
        return c
    },
    getUncheckValue: function() {
        var a = this.menu.getUncheckItems();
        var d = [];
        for (var b = 0; b < a.length; b++) {
            d.push(a[b].desc_id)
        }
        var c = d.join(",");
        return c
    },
    getValue: function() {
        var a = this.menu.getCheckItems();
        var d = [];
        for (var b = 0; b < a.length; b++) {
            d.push(a[b].desc_id)
        }
        var c = d.join(",");
        return c
    },
    setValue: function(e) {
        var d = _USBCOPY_STR("log", "all_type");
        if (e && typeof e == "string") {
            if (e === "all_type") {
                d = _USBCOPY_STR("log", "all_type");
                this.menu.setAllType()
            } else {
                if (e === "clear_all") {
                    d = "";
                    this.menu.setClearAll()
                }
            }
        } else {
            var b = [];
            var c = [];
            for (var a = 0; a < e.length; a++) {
                b.push(e[a].text);
                c.push(e[a].desc_id)
            }
            d = b.join(", ")
        }
        SYNO.SDS.USBCopy.Model.LogDescTypeField.superclass.setValue.call(this, d)
    },
    onRender: function(b, a) {
        SYNO.SDS.USBCopy.Model.LogDescTypeField.superclass.onRender.call(this, b, a);
        if (this.label) {
            this.label.addClass("syno-ux-item-label")
        }
        if (this.trigger) {
            this.trigger.addListener("mouseover", this.onMouseover, this);
            this.trigger.addListener("mouseout", this.onMouseout, this)
        }
        this.mon(this.el, {
            scope: this,
            mouseover: this.onMouseover,
            mouseout: this.onMouseout
        });
        SYNO.ux.Utils.setFormItemIndent(this);
        SYNO.ux.Utils.setFormFieldWidth(this);
        this.el.dom.removeAttribute("name")
    },
    onBeforeItemClick: function() {
        this.isAfterItemClickInvoked = true
    },
    onItemClick: function(d, b, c) {
        if (b.getId() == d.allTypeId) {
            this.setValue("all_type")
        } else {
            if (b.getId() == d.clearAllId) {
                this.setValue("clear_all")
            } else {
                var a = this.menu.getCheckItems();
                if (a.length === this.menu.typeItems.length) {
                    this.setValue("all_type")
                } else {
                    this.setValue(a)
                }
            }
        }
    },
    onHide: function() {
        if (this.isAfterItemClickInvoked) {
            this.menu.show(this.el, "tl-bl?")
        } else {
            this.owner.triggerClick = false
        }
        this.isAfterItemClickInvoked = false
    },
    onMouseover: function() {
        this.addClass("syno-ux-schedulefield-hover");
        this.trigger.addClass("x-form-trigger-over")
    },
    onMouseout: function() {
        this.removeClass("syno-ux-schedulefield-hover");
        this.trigger.removeClass("x-form-trigger-over")
    },
    markInvalid: function(a) {
        if (this.trigger) {
            this.trigger.addClass("syno-ux-trigger-invalid")
        }
        SYNO.SDS.USBCopy.Model.LogDescTypeField.superclass.markInvalid.call(this, a)
    },
    clearInvalid: function() {
        if (this.trigger) {
            this.trigger.removeClass("syno-ux-trigger-invalid")
        }
        SYNO.SDS.USBCopy.Model.LogDescTypeField.superclass.clearInvalid.call(this)
    },
    setReadOnly: function(a) {
        if (a) {
            this.addClass("syno-ux-triggerfield-readonly")
        } else {
            this.removeClass("syno-ux-triggerfield-readonly")
        }
        SYNO.SDS.USBCopy.Model.LogDescTypeField.superclass.setReadOnly.call(this, a)
    }
});
Ext.define("SYNO.SDS.USBCopy.Model.SearchPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(a) {
        this.searchPanel = null;
        this.dateType = {
            custom: 1,
            today: 2,
            yesterday: 4,
            lastweek: 8,
            lastmonth: 16
        };
        this.dataRange = [
            [this.dateType.custom, _T("log", "date_custom")],
            [this.dateType.today, _T("log", "date_today")],
            [this.dateType.yesterday, _T("log", "date_yesterday")],
            [this.dateType.lastweek, _T("log", "date_lastweek")],
            [this.dateType.lastmonth, _T("log", "date_lastmonth")]
        ];
        this.defaultAnimation = ["#000", 1, {
            duration: 0.35
        }];
        this.owner = a.owner;
        this.callParent([this.fillConfig(a)]);
        this.triggerClick = false;
        this.mon(this, "hide", this.onHide, this);
        this.logDescSelector.addListener("triggerClick", Ext.createDelegate(this.onTriggerClickSelector, this))
    },
    fillConfig: function(c) {
        var f, a, e, b, i, h;
        var g = [];
        f = this.createKeyword();
        h = this.createLogType();
        i = this.createLogDesc();
        a = this.createFriendlyDate();
        e = this.createCustDate();
        b = this.createFootBar();
        g.push(f);
        g.push(h);
        g.push(i);
        g.push(a);
        g.push(e);
        g.push(b);
        var d = {
            width: 368,
            heigh: 480,
            floating: true,
            labelAlign: "left",
            trackResetOnLoad: true,
            waitMsgTarget: true,
            border: false,
            bodyStyle: "padding-left: 24px; padding-right: 24px; padding-top: 4px; padding-bottom: 16px",
            autoFlexcroll: false,
            defaults: {
                hideLabel: true,
                anchor: "100%"
            },
            itemId: "search_panel",
            items: g
        };
        return Ext.apply(d, c)
    },
    onHide: function() {
        if (!this.triggerClick) {
            SYNO.SDS.USBCopy.Model.SearchPanel.superclass.onHide.call(this)
        }
    },
    onTriggerClickSelector: function() {
        this.triggerClick = true
    },
    createKeyword: function() {
        return [{
            xtype: "syno_displayfield",
            value: _T("log", "attr_keyword") + _T("common", "colon"),
            flex: 1
        }, {
            xtype: "syno_textfield",
            name: "key_word",
            flex: 2,
            vaule: ""
        }]
    },
    createLogType: function() {
        this.logTypeSelector = new SYNO.ux.ComboBox({
            mode: "local",
            editable: false,
            name: "log_type",
            store: new Ext.data.ArrayStore({
                autoDestroy: true,
                fields: ["value", "display"],
                data: [
                    [SYNO.SDS.USBCopy.LOG_TYPE.ALL_TYPE, _USBCOPY_STR("log", "all_type")],
                    [SYNO.SDS.USBCopy.LOG_TYPE.INFO_TYPE, _USBCOPY_STR("log", "info_type")],
                    [SYNO.SDS.USBCopy.LOG_TYPE.ERROR_TYPE, _USBCOPY_STR("log", "error_type")],
                    [SYNO.SDS.USBCopy.LOG_TYPE.WARN_TYPE, _USBCOPY_STR("log", "warn_type")]
                ]
            }),
            displayField: "display",
            valueField: "value",
            triggerAction: "all",
            value: SYNO.SDS.USBCopy.LOG_TYPE.ALL_TYPE
        });
        return [{
            xtype: "syno_displayfield",
            value: _USBCOPY_STR("log", "log_type") + _T("common", "colon"),
            flex: 1
        }, this.logTypeSelector]
    },
    createLogDesc: function() {
        this.logDescSelector = new SYNO.SDS.USBCopy.Model.LogDescTypeField({
            owner: this,
            width: 328,
            name: "log_desc_id"
        });
        this.logDescSelector.setValue("all_type");
        return [{
            xtype: "syno_displayfield",
            value: _USBCOPY_STR("log", "log_desc_type") + _T("common", "colon"),
            flex: 1
        }, this.logDescSelector]
    },
    createFriendlyDate: function() {
        this.friendlyDate = new SYNO.ux.ComboBox({
            mode: "local",
            editable: false,
            name: "dateRange",
            store: this.getFriendlyDateStore(),
            displayField: "displayText",
            valueField: "id",
            triggerAction: "all",
            value: this.dateType.custom,
            listeners: {
                scope: this,
                beforeselect: this.friendlyDateSelect
            }
        });
        return [{
            xtype: "syno_displayfield",
            value: _T("log", "date_range") + _T("common", "colon"),
            flex: 1
        }, this.friendlyDate]
    },
    createCustDate: function() {
        this.dateFrom = new SYNO.ux.DateTimeField({
            name: "searchdatefrom",
            editable: false,
            emptyText: _T("log", "date_from"),
            value: "",
            listeners: {
                scope: this,
                select: function(b, a) {
                    this.form.findField("searchdateto").setMinValue(a)
                }
            }
        });
        this.dateTo = new SYNO.ux.DateTimeField({
            name: "searchdateto",
            editable: false,
            emptyText: _T("log", "date_to"),
            value: "",
            listeners: {
                scope: this,
                select: function(b, a) {
                    this.form.findField("searchdatefrom").setMaxValue(a)
                }
            }
        });
        return [{
            xtype: "syno_displayfield",
            value: _T("time", "time_date") + _T("common", "colon")
        }, {
            xtype: "syno_compositefield",
            hideLabel: true,
            defaults: {
                flex: 1
            },
            defaultMargins: "0 8 0 0",
            items: [this.dateFrom, this.dateTo]
        }]
    },
    createFootBar: function() {
        return [{
            xtype: "toolbar",
            border: false,
            itemId: "btns",
            toolbarCls: "search-panel-fbar-btnPanel",
            items: [{
                xtype: "tbfill"
            }, {
                xtype: "syno_button",
                minWidth: 80,
                text: _T("common", "reset"),
                style: "border-radius: 100px",
                handler: this.onReset,
                scope: this
            }, {
                xtype: "syno_button",
                minWidth: 120,
                btnStyle: "blue",
                cls: "search-apply",
                text: _T("log", "search"),
                itemId: "btn_search",
                handler: this.onSearch,
                scope: this
            }]
        }]
    },
    setKeyWord: function(a) {
        var b = this.getForm().findField("key_word");
        if (b && Ext.isString(a)) {
            b.setValue(a)
        }
        b.focus("", 1)
    },
    onSearch: function() {
        var g = {};
        var d = this.getForm();
        var a = d.findField("key_word").getValue();
        var f = d.findField("log_type").getValue();
        var c = d.findField("log_desc_id").getCheckedDescIDList();
        var b = d.findField("searchdatefrom").getRawValue();
        var e = d.findField("searchdateto").getRawValue();
        if (a) {
            g.key_word = a
        }
        if (b) {
            g.from_timestamp = new Date(b + " 00:00:00").getTime() / 1000
        }
        if (e) {
            g.to_timestamp = new Date(e + " 23:59:59").getTime() / 1000
        }
        g.log_desc_id_list = c;
        g.log_type = f;
        this.fireEvent("search", this, g)
    },
    onReset: function() {
        this.getForm().reset();
        this.getForm().findField("searchdatefrom").setMaxValue(null);
        this.getForm().findField("searchdateto").setMinValue(null);
        this.logDescSelector.setValue("all_type")
    },
    setDate: function(c, b, a) {
        this.form.findField("searchdatefrom").setMaxValue(b);
        this.form.findField("searchdateto").setMinValue(c);
        this.form.findField("searchdatefrom").setValue(c);
        this.form.findField("searchdateto").setValue(b)
    },
    getFromToDate: function(c) {
        var e, d, a;
        var b = new Date();
        d = b;
        if (c === this.dateType.today) {
            e = d = b
        } else {
            if (c === this.dateType.yesterday) {
                e = d = b.add(Date.DAY, -1)
            } else {
                if (c === this.dateType.lastweek) {
                    a = b.getDay();
                    e = b.add(Date.DAY, -7)
                } else {
                    if (c === this.dateType.lastmonth) {
                        e = b.add(Date.MONTH, -1)
                    }
                }
            }
        }
        return {
            from: e,
            to: d
        }
    },
    friendlyDateSelect: function(c, e, a) {
        var b = e.get("id");
        var d = this.getFromToDate(b);
        this.setDate(d.from, d.to, true)
    },
    getFriendlyDateStore: function() {
        var a = this.dataRange;
        return new Ext.data.ArrayStore({
            autoDestroy: true,
            fields: ["id", "displayText"],
            data: a
        })
    }
});
Ext.define("SYNO.SDS.USBCopy.Model.AdvancedSearchField", {
    extend: "SYNO.ux.SearchField",
    initEvents: function() {
        this.callParent(arguments);
        this.mon(Ext.getDoc(), "mousedown", this.onMouseDown, this);
        this.mon(this, "keypress", function(b, a) {
            if (a.getKey() == Ext.EventObject.ENTER) {
                this.searchPanel.setKeyWord(this.getValue());
                this.searchPanel.onSearch()
            }
        }, this)
    },
    isInnerComponent: function(c, b) {
        var a = false;
        b.items.each(function(d) {
            if (d instanceof Ext.form.ComboBox) {
                if (d.view && c.within(d.view.getEl())) {
                    a = true;
                    return false
                }
            } else {
                if (d instanceof Ext.form.DateField) {
                    if (d.menu && (c.within(d.menu.getEl()) || c.getTarget(".syno-datetimepicker-inner-menu"))) {
                        a = true;
                        return false
                    }
                } else {
                    if (d instanceof Ext.form.CompositeField) {
                        if (this.isInnerComponent(c, d)) {
                            a = true;
                            return false
                        }
                    }
                }
            }
        }, this);
        return a
    },
    onMouseDown: function(b) {
        var a = this.searchPanel;
        if (a && a.isVisible() && !a.isDestroyed && !a.inEl && !b.within(a.getEl()) && !b.within(this.searchtrigger) && !this.isInnerComponent(b, this.searchPanel.getForm())) {
            a.hide()
        }
    },
    onSearchTriggerClick: function() {
        if (this.searchPanel.isVisible()) {
            this.searchPanel.hide();
            return
        }
        this.searchPanel.getEl().alignTo(this.wrap, "tl-bl?", [0, 0]);
        this.searchPanel.show();
        this.searchPanel.setKeyWord(this.getValue())
    },
    onTriggerClick: function() {
        this.callParent();
        this.searchPanel.onReset();
        this.searchPanel.onSearch()
    }
});
