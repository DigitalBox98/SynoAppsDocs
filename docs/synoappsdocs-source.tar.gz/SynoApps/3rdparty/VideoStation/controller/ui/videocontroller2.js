/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.define("SYNO.VideoController2.Constant", {
        statics: {
            UNLIMIT: 5e5,
            ERROR_CODE_OFFLINE_CONVERTING_CONFIRM_LEGACY: 449,
            ERROR_CODE_OFFLINE_CONVERTING_BLOCK_LEGACY: 450,
            ERROR_CODE_OFFLINE_CONVERTING_CONFIRM: 1201,
            ERROR_CODE_OFFLINE_CONVERTING_BLOCK: 1202,
            ERROR_CODE_PIN_CODE_REQUIRED: 1400,
            ERROR_CODE_PIN_CODE_WRONG: 1401
        }
    }), Ext.define("SYNO.VideoController2.SharingHelper", {
        statics: {
            isPublicSharing: function() {
                return !0 === _S("IsPublicSharing")
            },
            getSharingID: function() {
                return SYNO.VideoController2.SharingHelper.isPublicSharing() ? _S("SharingId") : ""
            },
            API: {
                Movie: ["SYNO.VideoStation2.Movie", "getinfo", 1],
                TVShowEpisode: ["SYNO.VideoStation2.TVShowEpisode", "getinfo", 1],
                HomeVideo: ["SYNO.VideoStation2.HomeVideo", "getinfo", 1],
                TVRecord: ["SYNO.VideoStation2.TVRecording", "getinfo", 1],
                File: ["SYNO.VideoStation2.File", "getinfo", 1],
                AudioTrack: ["SYNO.VideoStation2.File", "get_track_info", 1],
                StreamingOpen: ["SYNO.VideoStation2.Streaming", "open", 2],
                Streaming: ["SYNO.VideoStation2.Streaming", "stream", 2],
                StreamingClose: ["SYNO.VideoStation2.Streaming", "close", 2],
                SubtitleList: ["SYNO.VideoStation2.Subtitle", "list", 3],
                Subtitle: ["SYNO.VideoStation2.Subtitle", "get", 3],
                CollectionListVideo: ["SYNO.VideoStation2.Collection", "list_video", 1],
                Poster: ["SYNO.VideoStation2.Poster", "get", 1]
            },
            LEGACY_API: {
                Movie: ["SYNO.VideoStation.Movie", "getinfo", 2],
                TVShowEpisode: ["SYNO.VideoStation.TVShowEpisode", "getinfo", 2],
                HomeVideo: ["SYNO.VideoStation.HomeVideo", "getinfo", 2],
                TVRecord: ["SYNO.VideoStation.TVRecording", "getinfo", 2],
                AudioTrack: ["SYNO.VideoStation.AudioTrack", "list", 1],
                StreamingOpen: ["SYNO.VideoStation.Streaming", "open", 3],
                Streaming: ["SYNO.VideoStation.Streaming", "stream", 1],
                StreamingClose: ["SYNO.VideoStation.Streaming", "close", 1],
                SubtitleList: ["SYNO.VideoStation.Subtitle", "list", 2],
                Subtitle: ["SYNO.VideoStation.Subtitle", "get", 2],
                CollectionListVideo: ["SYNO.VideoStation.Collection", "video_list", 2],
                Poster: ["SYNO.VideoStation.Poster", "getimage", 2]
            },
            ROOT: {
                Movie: "movie",
                TVShowEpisode: "episode",
                HomeVideo: "video",
                TVRecord: "recording",
                File: "video",
                AudioTrack: "audio",
                SubtitleList: "subtitle",
                CollectionListVideo: "video"
            },
            LEGACY_ROOT: {
                Movie: "movies",
                TVShowEpisode: "episodes",
                HomeVideo: "videos",
                TVRecord: "recordings",
                AudioTrack: "trackinfo",
                CollectionListVideo: "videos"
            },
            VIDEO_TYPE_MAP: {
                movie: "Movie",
                tvshow_episode: "TVShowEpisode",
                home_video: "HomeVideo",
                tv_record: "TVRecord",
                filevideo: "File"
            },
            getAPI: function(t) {
                var e = [];
                if (e = SYNO.VideoController2.SharingHelper.isPublicSharing() ? SYNO.VideoController2.SharingHelper.LEGACY_API[t] : SYNO.VideoController2.SharingHelper.API[t], 3 === e.length) return {
                    api: e[0],
                    method: e[1],
                    version: e[2]
                };
                throw String.format("Wrong API name: {0}", t)
            },
            getAPIRoot: function(t) {
                return SYNO.VideoController2.SharingHelper.isPublicSharing() ? SYNO.VideoController2.SharingHelper.LEGACY_ROOT.hasOwnProperty(t) ? SYNO.VideoController2.SharingHelper.LEGACY_ROOT[t] : "" : SYNO.VideoController2.SharingHelper.ROOT.hasOwnProperty(t) ? SYNO.VideoController2.SharingHelper.ROOT[t] : ""
            },
            getVideoAPI: function(t) {
                var e = SYNO.VideoController2.SharingHelper.VIDEO_TYPE_MAP[t];
                return SYNO.VideoController2.SharingHelper.getAPI(e)
            },
            getVideoAPIRoot: function(t) {
                var e = SYNO.VideoController2.SharingHelper.VIDEO_TYPE_MAP[t];
                return SYNO.VideoController2.SharingHelper.getAPIRoot(e)
            },
            getCGIPath: function(t) {
                var e = SYNO.VideoController2.SharingHelper.isPublicSharing() ? "VideoStation/" + t : "entry";
                return String.format("webapi/{0}.cgi", e)
            },
            getVideoParams: function(t) {
                var e = SYNO.VideoController2.SharingHelper.isPublicSharing();
                return {
                    id: e ? t : [t],
                    additional: e ? Ext.encode(["file"]) : ["file"]
                }
            },
            getRawVideoParam: function(t) {
                var e = {};
                return SYNO.VideoController2.SharingHelper.isPublicSharing() ? (e = t, e.accept_format = "raw") : (e.file = t, e.raw = {}), e
            },
            getTranscodeVideoParam: function(t, e, i) {
                var n = {};
                return SYNO.VideoController2.SharingHelper.isPublicSharing() ? (n = t, Ext.apply(n, i), n.accept_format = e, n.audio_id = n.audio_track, delete n.audio_track) : (n.file = t, n[e] = i), n
            },
            getForceOpenVTEParam: function(t) {
                return SYNO.VideoController2.SharingHelper.isPublicSharing() ? t.force_open_vte = !0 : t.hls.force_open_vte = !0, t
            },
            getStreamingParam: function(t, e) {
                var i = {};
                return SYNO.VideoController2.SharingHelper.isPublicSharing() ? i.id = t : (i.tid = Ext.encode(e), i.stream_id = Ext.encode(t)), i
            },
            getStreamingCloseParam: function(t) {
                var e = {};
                return SYNO.VideoController2.SharingHelper.isPublicSharing() ? e.id = t : e.stream_id = t, e
            },
            getCollectionListVideoParam: function(t, e) {
                var i = SYNO.VideoController2.SharingHelper.isPublicSharing(),
                    n = i ? -1 : SYNO.VideoController2.Constant.UNLIMIT,
                    o = {
                        sort_by: t.sort_by,
                        sort_direction: t.sort_direction,
                        offset: 0,
                        limit: n
                    };
                return i ? (o.sharing_id = SYNO.VideoController2.SharingHelper.getSharingID(), o.additional = Ext.encode(["file"])) : o.id = e, o
            }
        }
    }), _VCT = function(t, e) {
        var i = "";
        try {
            i = _TT("SYNO.SDS.VideoStation.AppInstance", t, e)
        } catch (n) {
            i = _T(t, e)
        } finally {
            return i || String.format("{0}:{1}", t, e)
        }
    }, Ext.define("SYNO.VideoController2.Util", {
        statics: {
            IS_MOBILE: /Android|webOS|iPhone|iPad|iPod|BlackBerry|Opera Mini|IEMobile|windows phone os 7|windows phone 8/i.test(navigator.userAgent),
            STATE: {
                NO_MEDIA: 0,
                STOPPED: 1,
                PLAYING: 2,
                PAUSED: 3,
                BUFFERING: 4,
                ERROR: 5,
                CLEAR: 6,
                AUTO_PLAY_FAIL: 7
            },
            MimeType: {
                ogg: "audio/ogg",
                ogv: "video/ogg",
                wav: "audio/wav",
                mp3: "audio/mpeg",
                m4a: "audio/mp4",
                m4b: "audio/mp4",
                m4v: "video/mp4",
                mov: "video/mp4"
            },
            getFileExt: function(t) {
                return (/[.]/.exec(t) ? /[^.]+$/.exec(t)[0] : "").toLowerCase()
            },
            createVLCElement: function(t, e, i, n, o) {
                return Ext.isIE || Ext.isIE11 ? t.createChild({
                    tag: "object",
                    id: e,
                    classid: "clsid:9BE31822-FDAD-461B-AD51-BE1D1C159921",
                    codebase: "http://download.videolan.org/pub/videolan/vlc/last/win32/axvlc.cab",
                    width: i || "100%",
                    height: n || "100%",
                    style: o || "",
                    cn: [{
                        tag: "param",
                        name: "src",
                        value: ""
                    }, {
                        tag: "param",
                        name: "allowfullscreen",
                        value: "false"
                    }, {
                        tag: "param",
                        name: "bgcolor",
                        value: "#000000"
                    }, {
                        tag: "param",
                        name: "toolbar",
                        value: "false"
                    }]
                }) : t.createChild({
                    tag: "embed",
                    id: e,
                    type: "application/x-vlc-plugin",
                    version: "VideoLAN.VLCPlugin.2",
                    pluginspage: "http://www.videolan.org/",
                    width: i || "100%",
                    height: n || "100%",
                    style: o || "",
                    src: "",
                    allowfullscreen: "false",
                    bgcolor: "#000000",
                    toolbar: "false"
                })
            },
            isVLCSupported: function() {
                return !this.isMobile() && (SYNO.VideoController2.Util.detectPlugin("VideoLAN.VLCPlugin.2", "VideoLAN", "VLC") || SYNO.VideoController2.Util.detectPlugin("VideoLAN.VLCPlugin.2", "VLC", "VLC") || SYNO.VideoController2.Util.detectPluginForMacSafari10())
            },
            detectPlugin: function() {
                var t, e, i, n = navigator.plugins || [],
                    o = arguments;
                if (Ext.isIE || Ext.isIE11) {
                    try {
                        if (new ActiveXObject(o[0])) return !0
                    } catch (t) {}
                    return !1
                }
                for (t = 0; t < n.length; ++t) {
                    for (i = !0, e = 1; e < o.length; ++e)
                        if (-1 === n[t].name.indexOf(o[e]) && -1 === n[t].description.indexOf(o[e])) {
                            i = !1;
                            break
                        } if (i) return !0
                }
                return !1
            },
            detectPluginForMacSafari10: function() {
                if (!SYNO.VideoController2.Util.isMacSafari1x()) return !1;
                var t = !1,
                    e = document.createElement("div"),
                    i = new SYNO.VideoController2.Util.createVLCElement(new Ext.Element(e), "vlc_tester");
                return document.body.appendChild(e), t = i.dom.hasOwnProperty("getVersionInfo"), document.body.removeChild(e), t
            },
            addDomListener: function(t) {
                return function(e, i, n) {
                    e && Ext.isString(i) && Ext.isFunction(n) && (t && Ext.isIE && e.attachEvent ? e.attachEvent(i, n) : Ext.isFunction(e.addEventListener) ? e.addEventListener(i, n, !1) : e["on" + i] = n)
                }
            },
            removeDomListener: function(t) {
                return function(e, i, n) {
                    e && Ext.isString(i) && Ext.isFunction(n) && (t && Ext.isIE && e.detachEvent ? e.detachEvent(i, n) : Ext.isFunction(e.removeEventListener) ? e.removeEventListener(i, n, !1) : e["on" + i] = null)
                }
            },
            FullscreenEventMap: {
                requestFullscreen: "fullscreenchange",
                webkitRequestFullscreen: "webkitfullscreenchange",
                mozRequestFullScreen: "mozfullscreenchange",
                msRequestFullscreen: "MSFullscreenChange"
            },
            FullscreenFn: ["requestFullscreen", "webkitRequestFullscreen", "mozRequestFullScreen", "msRequestFullscreen"],
            exitFullscreenFn: ["exitFullscreen", "webkitExitFullscreen", "mozCancelFullScreen", "msExitFullscreen"],
            isFullscreen: function() {
                if (SYNO.VideoController2.Util.isIos()) {
                    var t = document.getElementsByTagName("video")[0];
                    return t && t.webkitDisplayingFullscreen
                }
                return !Ext.isEmpty(document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement || document.msFullscreenElement)
            },
            hookDoLayout: function(t) {
                var e, i = t.getEl();
                if (Ext.each(SYNO.VideoController2.Util.FullscreenFn, function(t) {
                        if (Ext.isFunction(i.dom[t])) return e = SYNO.VideoController2.Util.FullscreenEventMap[t], !1
                    }), Ext.isString(e)) {
                    var n = function() {
                        t.getOptionsBar().getFullscreenButton().setFullscreen(SYNO.VideoController2.Util.isFullscreen()), t.doLayout()
                    };
                    document.addEventListener(e, n, !1)
                }
            },
            setDomFullscreen: function(t) {
                if (SYNO.VideoController2.Util.isIos()) {
                    var e = document.getElementsByTagName("video")[0];
                    return void(e && e.webkitEnterFullscreen())
                }
                Ext.each(SYNO.VideoController2.Util.FullscreenFn, function(e) {
                    if (Ext.isFunction(t[e])) return t[e](), !1
                })
            },
            exitFullscreen: function() {
                Ext.each(SYNO.VideoController2.Util.exitFullscreenFn, function(t) {
                    if (Ext.isFunction(document[t])) return document[t](), !1
                })
            },
            isDomFullscreenSupported: function() {
                var t = document.body,
                    e = !1;
                return Ext.each(SYNO.VideoController2.Util.FullscreenFn, function(i) {
                    if (Ext.isFunction(t[i])) return e = !0, !1
                }), e
            },
            isMobile: function() {
                return SYNO.VideoController2.Util.IS_MOBILE
            },
            isMacSafari: function() {
                return Ext.isMac && Ext.isSafari
            },
            isMacSafari1x: function() {
                return SYNO.VideoController2.Util.isMacSafari() && /version\/1\d/.test(navigator.userAgent.toLowerCase())
            },
            isWindows10: function() {
                return -1 !== window.navigator.userAgent.indexOf("Windows NT 10")
            },
            isIos: function() {
                return /iPhone|iPad|iPod/i.test(navigator.userAgent)
            },
            isWindows10EdgeIE: function() {
                return SYNO.VideoController2.Util.isWindows10() && (Ext.isIE11 || Ext.isEdge)
            },
            isHTML5Base: function(t) {
                return "HLS" === t || "HTML5" === t
            },
            REPEAT_NONE: 0,
            REPEAT_ALL: 1,
            REPEAT_ONE: 2,
            APIErrorStringMap: {
                "SYNO.VideoStation.Streaming": {
                    413: _VCT("controller", "unsupported_format"),
                    419: _VCT("error", "record_quota_reached"),
                    420: _VCT("controller", "in_transcoding"),
                    421: _VCT("controller", "unsupported_format"),
                    439: _VCT("controller", "unsupported_audio_codec"),
                    440: _VCT("controller", "unsupported_format"),
                    444: _VCT("controller", "need_change_mem_layout"),
                    445: _VCT("controller", "unsupported_hardware_transcode_format"),
                    446: _VCT("controller", "out_of_transcoding_resolution_capability"),
                    447: _VCT("controller", "out_of_transcoding_framerate_capability"),
                    448: _VCT("controller", "out_of_transcoding_profile_capability"),
                    449: _VCT("offline_conversion", "error_confirm"),
                    450: _VCT("offline_conversion", "error_block"),
                    451: _VCT("controller", "system_daemon_not_running")
                },
                "SYNO.VideoStation2.Controller.Playback": {
                    117: _VCT("controller", "error_state")
                },
                "SYNO.VideoStation2.Controller.Volume": {
                    117: _VCT("controller", "error_state")
                },
                "SYNO.VideoStation2.Controller.Password": {
                    117: _VCT("controller", "error_state")
                },
                "SYNO.VideoStation2.Screenshot": {
                    101: _VCT("controller", "error_screenshot_create"),
                    117: _VCT("controller", "error_screenshot_create")
                }
            },
            API2ErrorStringMap: {
                1152: _VCT("controller", "download_subtitle_fail_retry_later"),
                1200: _VCT("controller", "in_transcoding"),
                1201: _VCT("offline_conversion", "error_confirm"),
                1202: _VCT("offline_conversion", "error_block"),
                1203: _VCT("error", "record_quota_reached"),
                1204: _VCT("controller", "unsupported_audio_codec"),
                1205: _VCT("controller", "unsupported_format"),
                1206: _VCT("controller", "need_change_mem_layout"),
                1207: _VCT("controller", "unsupported_hardware_transcode_format"),
                1208: _VCT("controller", "out_of_transcoding_resolution_capability"),
                1209: _VCT("controller", "out_of_transcoding_framerate_capability"),
                1210: _VCT("controller", "out_of_transcoding_profile_capability"),
                1211: _VCT("controller", "unsupported_format"),
                1212: _VCT("controller", "unsupported_format"),
                1214: _VCT("controller", "system_daemon_not_running"),
                1400: _VCT("parental_control", "enter_pin_description"),
                1401: _VCT("parental_control", "wrong_pin"),
                1514: _VCT("controller", "unsupported_format"),
                2001: _VCT("controller", "unsupported_format"),
                2002: _VCT("controller", "error_renderer_password_incorrect"),
                2200: _VCT("error", "record_quota_reached")
            },
            STREAMING_ID: "streaming",
            CHROMECAST_ID: "chromecast",
            PLAYERTYPE_STREAMING: "streaming",
            PLAYERTYPE_AIRPLAY: "airplay",
            PLAYERTYPE_UPNP: "upnp",
            PLAYERTYPE_CHROMECAST: "chromecast",
            SCREENSHOT_CREATE: "screenshot_create",
            SCREENSHOT_DONE: "screenshot_done",
            SCREENSHOT_FAILED: "screenshot_failed",
            SUBTITLE_NONE: "none",
            SUBTITLE_DISCOVER: "discover",
            SUBTITLE_SEARCH: "search",
            SUBTITLE_BROWSE: "browse",
            SUBTITLE_SYNC: "sync",
            SUBTITLE_RESIZE: "resize",
            QUALITY_RAW: null,
            QUALITY_FHD_HIGH_BITRATE: "fhd_high_bitrate",
            QUALITY_HD_HIGH: "hd_high",
            QUALITY_HD_MEDIUM: "hd_medium",
            QUALITY_HD_LOW: "hd_low",
            PLAYBACK_RATE_050X: "050x",
            PLAYBACK_RATE_075X: "075x",
            PLAYBACK_RATE_100X: "100x",
            PLAYBACK_RATE_125X: "125x",
            PLAYBACK_RATE_150X: "150x",
            PLAYBACK_RATE_175X: "175x",
            PLAYBACK_RATE_200X: "200x",
            TYPE_MANIFEST: "manifest",
            TYPE_FRAGMENT: "fragment",
            systemErrorString: function(t) {
                return SYNO.API.Errors.common[t] || _T("error", "error_error_system")
            },
            getErrorCode: function(t) {
                if (!Ext.isObject(t)) return 100;
                var e = t.code;
                if (Ext.isArray(t.errors) && t.errors.length > 0) {
                    var i = t.errors[0];
                    Ext.isNumber(i.code) && (e = i.code)
                }
                return Ext.isNumber(e) ? e : 100
            },
            getErrorString: function(t, e) {
                if (!Ext.isObject(t)) return "";
                var i, n = SYNO.VideoController2.Util.getErrorCode(t);
                try {
                    i = SYNO.VideoController2.Util.APIErrorStringMap.hasOwnProperty(e) && SYNO.VideoController2.Util.APIErrorStringMap[e].hasOwnProperty(n) ? SYNO.VideoController2.Util.APIErrorStringMap[e][n] || SYNO.VideoController2.Util.systemErrorString(n) : SYNO.VideoController2.Util.API2ErrorStringMap[n] || SYNO.VideoController2.Util.systemErrorString(n)
                } catch (t) {
                    i = SYNO.VideoController2.Util.systemErrorString(n)
                }
                return i
            },
            getLocationFullPath: function() {
                var t = window.location.pathname.replace(new RegExp("(?:\\/+[^\\/]*){0,1}$"), "/");
                return String.format("{0}{1}", window.location.origin, t)
            },
            getStreamURL: function(t, e, i, n) {
                var o = {
                    format: e
                };
                Ext.apply(o, SYNO.VideoController2.SharingHelper.getAPI("Streaming")), Ext.apply(o, SYNO.VideoController2.SharingHelper.getStreamingParam(t, n)), SYNO.VideoController2.Util.applySharingID(o);
                var r = String.format("{0}{1}/1.{2}", SYNO.VideoController2.Util.getLocationFullPath(), SYNO.VideoController2.SharingHelper.getCGIPath("vtestreaming"), "raw" === e ? i : "m3u8");
                return Ext.urlAppend(r, Ext.urlEncode(o))
            },
            getExtM3U: function(t, e, i) {
                var n = {
                        width: t,
                        height: e,
                        url: i
                    },
                    o = String.format("{0}webman/3rdparty/VideoStation/controller/ui/cgi/extm3u.cgi/1.m3u8", SYNO.VideoController2.Util.getLocationFullPath());
                return Ext.urlAppend(o, Ext.urlEncode(n))
            },
            getLocationOrigin: function() {
                var t = location.origin;
                return "/" === t[t.length - 1] ? t : t + "/"
            },
            getImageURL: function(t, e) {
                var i = {
                    api: "SYNO.VideoStation.Poster",
                    method: "getimage",
                    version: 2,
                    id: t,
                    type: e
                };
                return SYNO.VideoController2.Util.applySharingID(i), SYNO.SDS.UIFeatures.test("isRetina") && Ext.apply(i, {
                    hr: 2
                }), Ext.urlAppend("webapi/VideoStation/poster.cgi", Ext.urlEncode(i))
            },
            getBackdropURL: function(t) {
                var e = {
                    api: "SYNO.VideoStation.Backdrop",
                    method: "get",
                    version: "1",
                    mapper_id: t
                };
                return Ext.urlAppend("webapi/entry.cgi", Ext.urlEncode(e))
            },
            toHex: function(t) {
                for (var e = "", i = 0; i < t.length; ++i) e += t.charCodeAt(i).toString(16);
                return e
            },
            roundPercentage: function(t) {
                return Ext.isNumber(t) ? Math.round(100 * parseFloat(t)) : NaN
            },
            tryCallback: function(t) {
                Ext.isFunction(t) && t()
            },
            isVideoControllerOnly: function() {
                return Ext.query(".syno-vc-appwin.sds-standalone-main-window").length > 0 || SYNO.VideoController2.Util.isPublicSharing()
            },
            isPublicSharing: function() {
                return !0 === _S("IsPublicSharing")
            },
            applySharingID: function(t) {
                SYNO.VideoController2.Util.isPublicSharing() && (t.sharing_id = SYNO.VideoController2.SharingHelper.getSharingID())
            },
            getIDorPathParam: function(t) {
                return Ext.isString(t) ? {
                    path: t
                } : {
                    id: t
                }
            },
            prepareTicketId: function(t, e) {
                return synowebapi.promises.request({
                    api: "SYNO.API.Auth.Key",
                    version: 7,
                    method: "grant",
                    params: {
                        allow_api: t,
                        allow_methods: e
                    }
                })
            },
            isMP4Container: function(t) {
                return -1 != t.indexOf("mp4")
            },
            testHTML5VideoCanPlayType: function(t) {
                var e = document.createElement("video");
                return !(!e || !Ext.isFunction(e.canPlayType)) && (!Ext.isDefined(t) || e.canPlayType(t))
            },
            isWebPlayableMP4: function(t, e) {
                if (!Ext.isEmpty(e) && "mp3" !== e && -1 === e.indexOf("aac")) return !1;
                if (Ext.isMac && Ext.isSafari && "mpeg4" == t) return !0;
                if ("hevc" === t && (Ext.isSafari || SYNO.VideoController2.Util.isWindows10EdgeIE())) return !0;
                if ("av1" === t) {
                    if (SYNO.VideoController2.Util.testHTML5VideoCanPlayType('video/mp4; codecs="av01"')) return !0;
                    if (SYNO.VideoController2.Util.testHTML5VideoCanPlayType('video/mp4; codecs="av01.0.05M.08"')) return !0
                }
                return "h264" === t
            },
            getComboBoxCodepageList: function(t) {
                var e = [
                    ["BIG5", _VCT("codepage", "chinese_traditional") + " (BIG5)"],
                    ["BIG5-HKSCS", _VCT("codepage", "chinese_traditional") + " (BIG5-HKSCS)"],
                    ["GBK", _VCT("codepage", "chinese_simplified") + " (GBK)"],
                    ["GB18030", _VCT("codepage", "chinese_simplified") + " (GB18030)"],
                    ["EUC-JP", _VCT("codepage", "japanese") + " (EUC-JP)"],
                    ["SHIFT_JIS", _VCT("codepage", "japanese") + " (SHIFT_JIS)"],
                    ["ISO-2022-JP", _VCT("codepage", "japanese") + " (ISO-2022-JP)"],
                    ["EUC-KR", _VCT("codepage", "korean") + " (EUC-KR)"],
                    ["CP949", _VCT("codepage", "korean") + " (CP949)"],
                    ["CP1258", _VCT("codepage", "vietnamese") + " (CP1258)"],
                    ["VISCII", _VCT("codepage", "vietnamese") + " (VISCII)"],
                    ["TIS-620", _VCT("codepage", "thai") + " (TIS-620)"],
                    ["ISO-8859-11", _VCT("codepage", "thai") + " (ISO-8859-11)"],
                    ["ISO-8859-2", _VCT("codepage", "central_european") + " (ISO-8859-2)"],
                    ["CP1250", _VCT("codepage", "central_european") + " (CP1250)"],
                    ["ISO-8859-10", _VCT("codepage", "nordic") + " (ISO-8859-10)"],
                    ["ISO-8859-1", _VCT("codepage", "western") + " (ISO-8859-1)"],
                    ["ISO-8859-15", _VCT("codepage", "western") + " (ISO-8859-15)"],
                    ["CP1252", _VCT("codepage", "western") + " (CP1252)"],
                    ["Macintosh", _VCT("codepage", "western") + " (Macintosh)"],
                    ["CP1254", _VCT("codepage", "turkish") + " (CP1254)"],
                    ["CP1255", _VCT("codepage", "hebrew") + " (CP1255)"],
                    ["ISO-8859-8", _VCT("codepage", "hebrew") + " (ISO-8859-8)"],
                    ["ISO-8859-7", _VCT("codepage", "greek") + " (ISO-8859-7)"],
                    ["CP1253", _VCT("codepage", "greek") + " (CP1253)"],
                    ["CP1256", _VCT("codepage", "arabic") + " (CP1256)"],
                    ["ISO-8859-6", _VCT("codepage", "arabic") + " (ISO-8859-6)"],
                    ["ISO-8859-4", _VCT("codepage", "baltic") + " (ISO-8859-4)"],
                    ["ISO-8859-13", _VCT("codepage", "baltic") + " (ISO-8859-13)"],
                    ["CP1257", _VCT("codepage", "baltic") + " (CP1257)"],
                    ["ISO-8859-3", _VCT("codepage", "south_european") + " (ISO-8859-3)"],
                    ["ISO-8859-5", _VCT("codepage", "cyrillic") + " (ISO-8859-5)"],
                    ["CP1251", _VCT("codepage", "cyrillic") + " (CP1251)"],
                    ["KOI8-R", _VCT("codepage", "cyrillic") + " (KOI8-R)"],
                    ["KOI8-U", _VCT("codepage", "cyrillic") + " (KOI8-U)"],
                    ["ISO-8859-14", _VCT("codepage", "celtic") + " (ISO-8859-14)"],
                    ["ISO-8859-16", _VCT("codepage", "romanian") + " (ISO-8859-16)"],
                    ["ARMSCII-8", _VCT("codepage", "armenian") + " (ARMSCII-8)"],
                    ["Georgian-Academy", _VCT("codepage", "georgian") + " (Georgian-Academy)"],
                    ["KOI8-T", _VCT("codepage", "tajik") + " (KOI8-T)"],
                    ["CP1133", _VCT("codepage", "laotian") + " (CP1133)"],
                    ["PT154", _VCT("codepage", "kazakh") + " (PT154)"]
                ];
                return e.sort(function(t, e) {
                    return t[1].localeCompare(e[1])
                }), e.unshift(["UTF-16", _VCT("codepage", "unicode") + " (UTF-16)"]), e.unshift(["UTF-8", _VCT("codepage", "unicode") + " (UTF-8)"]), t && e.unshift(["auto", _VCT("controller", "auto_detect")]), e
            },
            SubtitleExtensions: {
                ssa: "plain_text",
                ass: "plain_text",
                srt: "plain_text",
                smi: "plain_text",
                sami: "plain_text"
            },
            TextFileExtensions: {
                abap: "abap",
                as: "actionsctipt",
                ada: "ada",
                s: "assembly_x86",
                ahk: "autohotkey",
                bat: "batchfile",
                c: "c_cpp",
                cpp: "c_cpp",
                clj: "clojure",
                edn: "clojure",
                cbl: "cobol",
                coffee: "coffee",
                cfm: "coldfusion",
                cs: "csharp",
                css: "css",
                d: "d",
                dart: "dart",
                diff: "diff",
                dot: "dot",
                ejs: "ejs",
                erl: "erlang",
                f: "forth",
                fth: "forth",
                forth: "forth",
                ftl: "ftl",
                glsl: "glsl",
                go: "golang",
                groovy: "groovy",
                haml: "haml",
                handlebars: "handlebars",
                hs: "haskell",
                hx: "haxe",
                ht3: "html",
                htm: "html",
                html: "html",
                htmls: "html",
                ini: "ini",
                jack: "jack",
                jade: "jade",
                java: "java",
                js: "javascript",
                json: "json",
                jsp: "jsp",
                jsx: "jsx",
                jl: "julia",
                latex: "latex",
                less: "less",
                liquid: "liquid",
                lisp: "lisp",
                ls: "livescript",
                lsl: "lsl",
                lua: "lua",
                mk: "makefile",
                markdown: "markdown",
                m: "matlab",
                mysql: "mysql",
                nix: "nix",
                ocaml: "ocaml",
                pascal: "pascal",
                perl: "perl",
                php: "php",
                txt: "plain_text",
                pl: "prolog",
                py: "python",
                r: "r",
                rhtml: "rhtml",
                rb: "ruby",
                rbw: "ruby",
                rs: "rust",
                sass: "sass",
                scad: "scad",
                scala: "scala",
                scm: "scheme",
                ss: "scheme",
                scss: "scss",
                sh: "sh",
                sjs: "sjs",
                sql: "sql",
                styl: "stylus",
                svg: "svg",
                tcl: "tcl",
                tex: "tex",
                textile: "textile",
                vb: "vbscript",
                v: "verilog",
                vhdl: "vhdl",
                xml: "xml",
                xq: "xquery",
                xqy: "xquery",
                xquery: "xquery",
                yml: "yaml",
                yaml: "yaml",
                "!!!": "plain_text",
                $00: "plain_text",
                $01: "plain_text",
                $02: "plain_text",
                $04: "plain_text",
                $05: "plain_text",
                $o1: "plain_text",
                $ol: "plain_text",
                "001": "plain_text",
                "12da": "plain_text",
                "1st": "plain_text",
                7: "plain_text",
                "82t": "plain_text",
                "92t": "plain_text",
                abl: "plain_text",
                ac: "plain_text",
                adiumhtmllog: "plain_text",
                adiumlog: "plain_text",
                adl: "plain_text",
                adt: "plain_text",
                adw: "plain_text",
                aiml: "plain_text",
                alx: "plain_text",
                aml: "plain_text",
                android: "plain_text",
                annot: "plain_text",
                ans: "plain_text",
                ansi: "plain_text",
                application: "plain_text",
                aprj: "plain_text",
                apx: "plain_text",
                aqt: "plain_text",
                arff: "plain_text",
                ARTask: "plain_text",
                asc: "plain_text",
                ascii: "plain_text",
                asl: "plain_text",
                asp: "plain_text",
                ass: "plain_text",
                assoc: "plain_text",
                atc: "plain_text",
                att: "plain_text",
                awa: "plain_text",
                awb: "plain_text",
                awd: "plain_text",
                awh: "plain_text",
                awp: "plain_text",
                axt: "plain_text",
                ba1: "plain_text",
                bad: "plain_text",
                bas: "plain_text",
                bbs: "plain_text",
                bbxt: "plain_text",
                bcr: "plain_text",
                bdp: "plain_text",
                bdr: "plain_text",
                bea: "plain_text",
                bel: "plain_text",
                bep: "plain_text",
                big: "plain_text",
                big5: "plain_text",
                bk: "plain_text",
                blm: "plain_text",
                bln: "plain_text",
                blw: "plain_text",
                bmtp: "plain_text",
                bna: "plain_text",
                bnx: "plain_text",
                bog: "plain_text",
                box: "plain_text",
                bpdx: "plain_text",
                brf: "plain_text",
                bsdl: "plain_text",
                bss: "plain_text",
                bt: "plain_text",
                bzw: "plain_text",
                cag: "plain_text",
                cas: "plain_text",
                cascii: "plain_text",
                cc: "plain_text",
                cd2: "plain_text",
                charset: "plain_text",
                cho: "plain_text",
                chord: "plain_text",
                cif: "plain_text",
                cil: "plain_text",
                ckn: "plain_text",
                clg: "plain_text",
                cli: "plain_text",
                clix: "plain_text",
                cmd: "plain_text",
                cmtx: "plain_text",
                cof: "plain_text",
                conf: "plain_text",
                coo: "plain_text",
                crash: "plain_text",
                crd: "plain_text",
                csassembly: "plain_text",
                csmanifest: "plain_text",
                csv: "plain_text",
                ctd: "plain_text",
                ctf: "plain_text",
                ctl: "plain_text",
                ctx: "plain_text",
                dat: "plain_text",
                dcd: "plain_text",
                dce: "plain_text",
                ddd: "plain_text",
                ddt: "plain_text",
                de: "plain_text",
                dectest: "plain_text",
                des: "plain_text",
                desc: "plain_text",
                dfe: "plain_text",
                dfm: "plain_text",
                dii: "plain_text",
                diskdefines: "plain_text",
                diz: "plain_text",
                dk: "plain_text",
                dkz: "plain_text",
                dmr: "plain_text",
                dne: "plain_text",
                dok: "plain_text",
                dp: "plain_text",
                dpv: "plain_text",
                dqy: "plain_text",
                drp: "plain_text",
                dsc: "plain_text",
                dsml: "plain_text",
                dtd: "plain_text",
                dwl: "plain_text",
                ecsv: "plain_text",
                edml: "plain_text",
                edt: "plain_text",
                efm: "plain_text",
                eia: "plain_text",
                emulecollection: "plain_text",
                en: "plain_text",
                enc: "plain_text",
                enf: "plain_text",
                eng: "plain_text",
                err: "plain_text",
                es: "plain_text",
                esw: "plain_text",
                etf: "plain_text",
                etx: "plain_text",
                euc: "plain_text",
                ext: "plain_text",
                extra: "plain_text",
                faq: "plain_text",
                fff: "plain_text",
                ffp: "plain_text",
                fin: "plain_text",
                first: "plain_text",
                flr: "plain_text",
                fmr: "plain_text",
                fnx: "plain_text",
                fon: "plain_text",
                fr: "plain_text",
                fra: "plain_text",
                frm: "plain_text",
                fsa: "plain_text",
                full: "plain_text",
                gbf: "plain_text",
                gdt: "plain_text",
                gen: "plain_text",
                ger: "plain_text",
                gnu: "plain_text",
                gpl: "plain_text",
                gs: "plain_text",
                gthr: "plain_text",
                gtx: "plain_text",
                guide: "plain_text",
                hdr: "plain_text",
                hhc: "plain_text",
                hhs: "plain_text",
                hlm: "plain_text",
                hlx: "plain_text",
                hp8: "plain_text",
                hsk: "plain_text",
                htx: "plain_text",
                hvc: "plain_text",
                hwl: "plain_text",
                hz: "plain_text",
                id31: "plain_text",
                id32: "plain_text",
                idc: "plain_text",
                idt: "plain_text",
                idx: "plain_text",
                iem: "plain_text",
                igv: "plain_text",
                igy: "plain_text",
                iif: "plain_text",
                ill: "plain_text",
                inc: "plain_text",
                inuse: "plain_text",
                ion: "plain_text",
                ipr: "plain_text",
                iqy: "plain_text",
                isr: "plain_text",
                it: "plain_text",
                ivp: "plain_text",
                ja: "plain_text",
                jad: "plain_text",
                jam: "plain_text",
                jeb: "plain_text",
                jis: "plain_text",
                jp1: "plain_text",
                jss: "plain_text",
                jtx: "plain_text",
                kahl: "plain_text",
                kar: "plain_text",
                kch: "plain_text",
                kix: "plain_text",
                klg: "plain_text",
                kor: "plain_text",
                la: "plain_text",
                label: "plain_text",
                las: "plain_text",
                lay: "plain_text",
                lin: "plain_text",
                linux: "plain_text",
                linx: "plain_text",
                lnc: "plain_text",
                log: "plain_text",
                lo_: "plain_text",
                lrc: "plain_text",
                lst: "plain_text",
                ltr: "plain_text",
                ltt: "plain_text",
                ltx: "plain_text",
                lue: "plain_text",
                luf: "plain_text",
                lwd: "plain_text",
                lxfml: "plain_text",
                lyr: "plain_text",
                lyt: "plain_text",
                man: "plain_text",
                manifest: "plain_text",
                map: "plain_text",
                mar: "plain_text",
                mathml: "plain_text",
                maxFR: "plain_text",
                mcw: "plain_text",
                md: "plain_text",
                mdl: "plain_text",
                mdle: "plain_text",
                mdown: "plain_text",
                mdtext: "plain_text",
                mdtxt: "plain_text",
                mdwn: "plain_text",
                me: "plain_text",
                mez: "plain_text",
                mf: "plain_text",
                mib: "plain_text",
                mit: "plain_text",
                mkd: "plain_text",
                mkdn: "plain_text",
                mno: "plain_text",
                mnu: "plain_text",
                modd: "plain_text",
                mpsub: "plain_text",
                mss: "plain_text",
                mtx: "plain_text",
                mtxt: "plain_text",
                mvg: "plain_text",
                mw: "plain_text",
                nbr: "plain_text",
                nclk: "plain_text",
                ncm: "plain_text",
                new: "plain_text",
                nfo: "plain_text",
                nlc: "plain_text",
                nmbd: "plain_text",
                nokogiri: "plain_text",
                not: "plain_text",
                notes: "plain_text",
                now: "plain_text",
                npdt: "plain_text",
                nt: "plain_text",
                nwctxt: "plain_text",
                ocr: "plain_text",
                odc: "plain_text",
                oh: "plain_text",
                ojp: "plain_text",
                omn: "plain_text",
                oogl: "plain_text",
                oot: "plain_text",
                opc: "plain_text",
                openbsd: "plain_text",
                opml: "plain_text",
                ort: "plain_text",
                osi: "plain_text",
                p3x: "plain_text",
                panic: "plain_text",
                pbd: "plain_text",
                pc5: "plain_text",
                pcl: "plain_text",
                pd: "plain_text",
                pdu: "plain_text",
                pfs: "plain_text",
                pgw: "plain_text",
                pjs: "plain_text",
                pla: "plain_text",
                plf: "plain_text",
                plg: "plain_text",
                plist: "plain_text",
                plk: "plain_text",
                pln: "plain_text",
                pml: "plain_text",
                pmo: "plain_text",
                pod: "plain_text",
                prc: "plain_text",
                prn: "plain_text",
                pro: "plain_text",
                prr: "plain_text",
                ps: "plain_text",
                psb: "plain_text",
                psi2: "plain_text",
                pt3: "plain_text",
                pts: "plain_text",
                pvj: "plain_text",
                pvw: "plain_text",
                "q&a": "plain_text",
                qdt: "plain_text",
                qud: "plain_text",
                rbdf: "plain_text",
                rdf: "plain_text",
                rea: "plain_text",
                readme: "plain_text",
                reg: "plain_text",
                rel: "plain_text",
                rep: "plain_text",
                resp: "plain_text",
                rest: "plain_text",
                rff: "plain_text",
                ris: "plain_text",
                rml: "plain_text",
                rqy: "plain_text",
                rst: "plain_text",
                rt: "plain_text",
                rtf: "plain_text",
                rtl: "plain_text",
                rtx: "plain_text",
                ru: "plain_text",
                rus: "plain_text",
                rzk: "plain_text",
                rzn: "plain_text",
                s19: "plain_text",
                s2k: "plain_text",
                sami: "plain_text",
                sbv: "plain_text",
                sct: "plain_text",
                sdnf: "plain_text",
                sen: "plain_text",
                seq: "plain_text",
                set: "plain_text",
                sfb: "plain_text",
                sgp: "plain_text",
                sha1: "plain_text",
                sha512: "plain_text",
                skcard: "plain_text",
                skv: "plain_text",
                sls: "plain_text",
                smali: "plain_text",
                smf: "plain_text",
                smi: "plain_text",
                sms: "plain_text",
                snw: "plain_text",
                soap: "plain_text",
                soundscript: "plain_text",
                spa: "plain_text",
                spec: "plain_text",
                spg: "plain_text",
                spn: "plain_text",
                spx: "plain_text",
                srt: "plain_text",
                srx: "plain_text",
                ssa: "plain_text",
                ssf: "plain_text",
                st1: "plain_text",
                stf: "plain_text",
                stq: "plain_text",
                strings: "plain_text",
                sub: "plain_text",
                syn: "plain_text",
                t: "plain_text",
                t2t: "plain_text",
                tab: "plain_text",
                tbd: "plain_text",
                tbl: "plain_text",
                tbx: "plain_text",
                tce: "plain_text",
                tcm: "plain_text",
                tdf: "plain_text",
                ted: "plain_text",
                text: "plain_text",
                textclipping: "plain_text",
                tfw: "plain_text",
                tgf: "plain_text",
                thml: "plain_text",
                thp: "plain_text",
                tlb: "plain_text",
                tle: "plain_text",
                tlx: "plain_text",
                tm: "plain_text",
                tml: "plain_text",
                tmprtf: "plain_text",
                tmx: "plain_text",
                tnef: "plain_text",
                tph: "plain_text",
                tpl: "plain_text",
                trn: "plain_text",
                trt: "plain_text",
                tsv: "plain_text",
                tt: "plain_text",
                ttbl: "plain_text",
                tte: "plain_text",
                ttf: "plain_text",
                ttpl: "plain_text",
                ttxt: "plain_text",
                tx8: "plain_text",
                "tx?": "plain_text",
                txa: "plain_text",
                txd: "plain_text",
                txe: "plain_text",
                txh: "plain_text",
                u3i: "plain_text",
                uax: "plain_text",
                uhtml: "plain_text",
                uk: "plain_text",
                unauth: "plain_text",
                uni: "plain_text",
                unx: "plain_text",
                us: "plain_text",
                usa: "plain_text",
                user: "plain_text",
                usf: "plain_text",
                usg: "plain_text",
                utf8: "plain_text",
                utx: "plain_text",
                utxt: "plain_text",
                ver: "plain_text",
                vet: "plain_text",
                vfk: "plain_text",
                vhd: "plain_text",
                vis: "plain_text",
                vkp: "plain_text",
                vmg: "plain_text",
                vmsg: "plain_text",
                vna: "plain_text",
                vsmproj: "plain_text",
                vw: "plain_text",
                vw3: "plain_text",
                vxml: "plain_text",
                wer: "plain_text",
                wir: "plain_text",
                wkf: "plain_text",
                wn: "plain_text",
                wrd: "plain_text",
                wrl: "plain_text",
                wsc: "plain_text",
                wst: "plain_text",
                wtf: "plain_text",
                wtl: "plain_text",
                wtx: "plain_text",
                x20: "plain_text",
                x60: "plain_text",
                x70: "plain_text",
                x80: "plain_text",
                x90: "plain_text",
                xb0: "plain_text",
                xc0: "plain_text",
                xct: "plain_text",
                xd0: "plain_text",
                xdl: "plain_text",
                xdp: "plain_text",
                xfd: "plain_text",
                xff: "plain_text",
                xhtm: "plain_text",
                xlf: "plain_text",
                xsd: "plain_text",
                xsl: "plain_text",
                xslt: "plain_text",
                xsr: "plain_text",
                xwp: "plain_text",
                xy: "plain_text",
                xy3: "plain_text",
                xyp: "plain_text",
                xyw: "plain_text",
                xyz: "plain_text",
                zanebug: "plain_text",
                zed: "plain_text",
                zhp: "plain_text",
                zib: "plain_text",
                zw: "plain_text",
                zxe: "plain_text",
                _me: "plain_text"
            }
        }
    }), Ext.define("SYNO.VideoController2.SupportFileVideo", {}), Ext.define("SYNO.VideoController2.SupportDrive", {}), Ext.onReady(function() {
        SYNO.VideoController2.Util.isPublicSharing() || Ext.define("SYNO.VideoController2.BrowseSubtitleDialog", {
            extend: "SYNO.SDS.Utils.FileChooser.Chooser",
            constructor: function(t) {
                this.appWin = t.appWin, this.sharepath = t.sharepath || "";
                var e = {
                    cls: "syno-vc-dialog",
                    owner: this.appWin,
                    width: 960,
                    height: 480,
                    title: _VCT("controller", "browse_subtitle"),
                    gotoPath: this.sharepath,
                    listeners: {
                        afterrender: function() {
                            this.getEl().select(".syno-ux-treepanel").each(function(t) {
                                t.addClass("syno-vc-treepanel")
                            }), this.getEl().select(".syno-ux-gridpanel").each(function(t) {
                                t.addClass("syno-vc-gridpanel")
                            }), this.getEl().select(".syno-ux-pagingtoolbar").each(function(t) {
                                t.addClass("syno-vc-pagingtoolbar")
                            }), this.getEl().select(".syno-ux-button").each(function(t) {
                                t.addClass("syno-vc-button")
                            }), this.getEl().select(".syno-ux-combobox").each(function(t) {
                                t.addClass("syno-vc-combobox")
                            });
                            var t = this.items.itemAt(1).items;
                            t.itemAt(0).items.itemAt(0).listClass = "syno-vc-combobox-list", t.itemAt(0).items.itemAt(1).listClass = "syno-vc-combobox-list"
                        }
                    },
                    columnCfg: {
                        filename: {
                            width: 500
                        }
                    },
                    comboOption: [{
                        label: _VCT("controller", "file_type"),
                        value: "allSubtitle",
                        data: [
                            ["allSubtitle", _VCT("controller", "subtitle_type")],
                            ["allText", _VCT("controller", "all_text_file")],
                            ["all", _VCT("controller", "all_file")]
                        ]
                    }, {
                        label: _VCT("controller", "codepage"),
                        value: "auto",
                        data: SYNO.VideoController2.Util.getComboBoxCodepageList(!0)
                    }],
                    getFilterPattern: function(t) {
                        var e = [],
                            i = {};
                        if ("allSubtitle" === t[0].value) {
                            for (i in SYNO.VideoController2.Util.SubtitleExtensions) SYNO.VideoController2.Util.SubtitleExtensions.hasOwnProperty(i) && e.push(i);
                            return e.join()
                        }
                        if ("allText" === t[0].value) {
                            for (i in SYNO.VideoController2.Util.TextFileExtensions) SYNO.VideoController2.Util.TextFileExtensions.hasOwnProperty(i) && e.push(i);
                            return e.join()
                        }
                        return ""
                    }
                };
                this.callParent([e])
            },
            initBottomPanelConfig: function(t) {
                var e = this.callParent([t]);
                return e.height = 36 * t.comboOption.length + 12, e
            }
        })
    }), Ext.define("SYNO.VideoController2.ControlPanelButtonStatus", {
        statics: {
            EVENT_ENABLE_CONTROLPANEL_BUTTONS: "enablecontrolpanelbuttons",
            EVENT_SET_PLAY_DISABLED: "setplaydisabled",
            EVENT_RESET_BUTTONS: "resetbuttons",
            instance: null,
            get: function() {
                return Ext.isObject(SYNO.VideoController2.ControlPanelButtonStatus.instance) || (SYNO.VideoController2.ControlPanelButtonStatus.instance = new SYNO.VideoController2.ControlPanelButtonStatus), SYNO.VideoController2.ControlPanelButtonStatus.instance
            }
        },
        extend: "Ext.util.Observable",
        constructor: function() {
            this.callParent(arguments), this.addEvents(SYNO.VideoController2.ControlPanelButtonStatus.EVENT_ENABLE_CONTROLPANEL_BUTTONS), this.addEvents(SYNO.VideoController2.ControlPanelButtonStatus.EVENT_SET_PLAY_DISABLED), this.addEvents(SYNO.VideoController2.ControlPanelButtonStatus.EVENT_RESET_BUTTONS)
        },
        setHasPrev: function(t) {
            this.has_prev = t
        },
        setPlay: function(t) {
            this.play = t
        },
        setHasNext: function(t) {
            this.has_next = t
        },
        setProgressSlider: function(t) {
            this.progress_slider = t
        },
        setList: function(t) {
            this.list = t
        },
        setSeekForward: function(t) {
            this.seek_forward = t
        },
        setSeekBackward: function(t) {
            this.seek_backward = t
        },
        setPlaybackRate: function(t) {
            this.playback_rate = t
        },
        setVolume: function(t) {
            this.volume = t
        },
        setSettings: function(t) {
            this.settings = t
        },
        setFullscreen: function(t) {
            this.fullscreen = t
        },
        getVolume: function() {
            return this.volume
        },
        getFullscreen: function() {
            return this.fullscreen
        },
        getPlay: function() {
            return this.play
        },
        setDefaultButtons: function() {
            this.progress_slider = !0, this.seek_forward = !0, this.seek_backward = !0, this.settings = !0, this.list = !0
        },
        setOpenFailedStatus: function() {
            this.play = !0, this.list = !0, this.progress_slider = !1, this.seek_forward = !1, this.seek_backward = !1, this.playback_rate = !1, this.volume = !1, this.settings = !0, this.fullscreen = !1
        },
        enableControlPanelButtons: function() {
            this.fireEvent(SYNO.VideoController2.ControlPanelButtonStatus.EVENT_ENABLE_CONTROLPANEL_BUTTONS)
        },
        resetButtons: function() {
            this.fireEvent(SYNO.VideoController2.ControlPanelButtonStatus.EVENT_RESET_BUTTONS)
        },
        changePlayButton: function(t) {
            this.play = t, this.fireEvent(SYNO.VideoController2.ControlPanelButtonStatus.EVENT_SET_PLAY_DISABLED)
        },
        has_prev: !1,
        play: !1,
        has_next: !1,
        progress_slider: !0,
        list: !0,
        seek_backward: !0,
        seek_forward: !0,
        playback_rate: !1,
        volume: !0,
        settings: !0,
        fullscreen: !1
    }), Ext.define("SYNO.VideoController2.Player", {
        extend: "Ext.util.Observable",
        constructor: function(t) {
            var e = Ext.apply({
                subtitle_is_srt: !0,
                name: "",
                player: null,
                pluginInit: !1,
                is_resumed: null,
                duration: null
            }, t);
            this.callParent([e]), Ext.apply(this, e)
        },
        canPlayType: Ext.emptyFn,
        isAvailable: Ext.emptyFn,
        checkResumed: Ext.emptyFn,
        getName: function() {
            return this.name
        },
        fullscreen: Ext.emptyFn,
        play: Ext.emptyFn,
        pause: Ext.emptyFn,
        resume: Ext.emptyFn,
        stop: Ext.emptyFn,
        seek: Ext.emptyFn,
        getPosition: Ext.emptyFn,
        getDuration: Ext.emptyFn,
        getVolume: Ext.emptyFn,
        setVolume: Ext.emptyFn,
        getMute: Ext.emptyFn,
        setMute: Ext.emptyFn,
        getState: Ext.emptyFn,
        disablePlayerSubtitle: Ext.emptyFn,
        setPlayerSubtitle: Ext.emptyFn,
        setSubtitleDelay: Ext.emptyFn,
        setSubtitleSize: Ext.emptyFn,
        setStartPosition: function(t) {
            Ext.isNumber(t) && t > 0 && (this.start_position = t)
        },
        notifyClear: function() {
            this.controller.updateState(SYNO.VideoController2.Util.STATE.CLEAR)
        },
        notifyAutoPlayFail: function() {
            this.controller.updateState(SYNO.VideoController2.Util.STATE.AUTO_PLAY_FAIL)
        },
        clear: function() {
            this.player && (this.el.remove(), this.el = null, this.player = null, this.is_resumed = null, this.pluginInit = !1, this.duration = null, this.notifyClear())
        },
        stateHandler: function(t) {
            var e = this.getState();
            if (e === SYNO.VideoController2.Util.STATE.PLAYING && (this.disablePlayerSubtitle(), Ext.isNumber(this.start_position))) {
                var i = this.start_position;
                this.start_position = null, this.is_resumed = !1;
                this.seek.createDelegate(this, [i]).defer(200)
            }
            this.controller.updateState(e, t)
        },
        durationHandler: function(t) {
            var e = Ext.isNumber(t) ? t : this.getDuration();
            null === this.duration && e > 0 && (this.duration = e, this.controller.updateDuration(e))
        },
        positionHandler: function(t) {
            var e = Ext.isNumber(t) ? t : this.getPosition();
            this.controller.updatePosition(e)
        },
        isVideoPlaying: function() {
            return 0 === this.controller.start_position || null === this.start_position
        },
        isResumed: function(t) {
            return !0 !== this.is_resumed && (this.is_resumed = this.isVideoPlaying() && this.checkResumed(t)), this.is_resumed
        },
        checkResumedByPosition: function(t) {
            return t > this.controller.start_position
        },
        checkResumedByCase: function(t) {
            var e = null === this.is_resumed && t >= 0,
                i = !1 === this.is_resumed && Math.floor(t) > 0;
            return e || i
        },
        volumeHandler: function() {
            this.controller.updateMute(this.getMute());
            var t = this.getVolume();
            Ext.isNumber(t) && t >= 0 && t <= 100 && !this.controller.volume_lock && this.controller.updateVolume(t)
        },
        webkitHandler: function() {
            this.controller.stop(), this.controller.play(), this.controller.pause()
        },
        playerReadyHandler: function() {
            SYNO.VideoController2.ControlPanelButtonStatus.get().setFullscreen(this.controller.isSupportFullscreen()), SYNO.VideoController2.ControlPanelButtonStatus.get().enableControlPanelButtons()
        },
        registerEventHandler: Ext.emptyFn,
        unregisterEventHandler: Ext.emptyFn,
        createPollingTask: function() {
            this.task_runner = new SYNO.SDS.TaskRunner, this.polling_status = this.task_runner.createTask({
                scope: this,
                run: function() {
                    this.pollingTaskFn()
                },
                interval: 100
            }), this.polling_status.start(!0)
        },
        destroyPollingTask: function() {
            this.task_runner && (this.polling_status = null, this.task_runner.destroy(), this.task_runner = null)
        },
        pollingTaskFn: Ext.emptyFn
    }), Ext.define("SYNO.VideoController2.SubtitlePreference", {
        statics: {
            EVENT_DATA_LOADED: "dataloaded",
            EVENT_DATA_CHANGED: "datachanged",
            DEFAULT_SUBTITLE_SIZE: 36,
            DEFAULT_USER_SETTINGS: {
                subtitle_font: "arial",
                subtitle_size: "36",
                subtitle_color: "#FFFFFF",
                subtitle_transparency: "100",
                subtitle_shadow: "default",
                subtitle_position: "bottom",
                background_color: "#000000",
                background_transparency: "0"
            },
            SUBTITLE_SIZE_MAP: {
                "extra-large": "56",
                large: "48",
                medium: "40",
                small: "36",
                "extra-small": "28"
            },
            instance: null,
            get: function() {
                return Ext.isObject(SYNO.VideoController2.SubtitlePreference.instance) || (SYNO.VideoController2.SubtitlePreference.instance = new SYNO.VideoController2.SubtitlePreference), SYNO.VideoController2.SubtitlePreference.instance
            }
        },
        extend: "Ext.util.Observable",
        constructor: function() {
            this.callParent(arguments), this.addEvents(SYNO.VideoController2.SubtitlePreference.EVENT_DATA_LOADED), this.addEvents(SYNO.VideoController2.SubtitlePreference.EVENT_DATA_CHANGED), this.user_settings = {}, this.subtitle_shadow = {}
        },
        getSetting: function(t) {
            if (SYNO.VideoController2.SubtitlePreference.DEFAULT_USER_SETTINGS.hasOwnProperty(t)) return this.user_settings[t]
        },
        setSetting: function(t, e) {
            SYNO.VideoController2.SubtitlePreference.DEFAULT_USER_SETTINGS.hasOwnProperty(t) && ("subtitle_size" === t && (e = parseInt(e)), this.user_settings[t] = e, this.fireEvent(SYNO.VideoController2.SubtitlePreference.EVENT_DATA_CHANGED, this.getSettings()))
        },
        getSettings: function() {
            return this.user_settings
        },
        setSettings: function(t) {
            Ext.iterate(t, function(e, i) {
                this.user_settings[e] = t[e]
            }, this), this.fireEvent(SYNO.VideoController2.SubtitlePreference.EVENT_DATA_CHANGED, this.getSettings())
        },
        getUserSetting: function(t) {
            if (SYNO.VideoController2.Util.isPublicSharing()) return null;
            var e = SYNO.SDS.UserSettings.getProperty("SYNO.SDS.VideoStation.AppInstance", t);
            return "subtitle_size" === t && isNaN(e) ? SYNO.VideoController2.SubtitlePreference.SUBTITLE_SIZE_MAP[e] : e
        },
        setUserSetting: function(t, e) {
            SYNO.VideoController2.Util.isPublicSharing() || SYNO.SDS.UserSettings.setProperty("SYNO.SDS.VideoStation.AppInstance", t, e)
        },
        loadUserSetting: function() {
            Ext.iterate(SYNO.VideoController2.SubtitlePreference.DEFAULT_USER_SETTINGS, function(t, e) {
                this.user_settings[t] = this.getUserSetting(t) || SYNO.VideoController2.SubtitlePreference.DEFAULT_USER_SETTINGS[t]
            }, this), this.resetOriginUserSettings(), this.fireEvent(SYNO.VideoController2.SubtitlePreference.EVENT_DATA_LOADED, this.getSettings())
        },
        saveUserSetting: function() {
            Ext.iterate(SYNO.VideoController2.SubtitlePreference.DEFAULT_USER_SETTINGS, function(t, e) {
                this.setUserSetting(t, this.user_settings[t])
            }, this), this.resetOriginUserSettings()
        },
        resetOriginUserSettings: function() {
            this.origin_user_settings = SYNO.Util.copy(this.user_settings)
        },
        isDirty: function() {
            var t = !1;
            return Ext.iterate(SYNO.VideoController2.SubtitlePreference.DEFAULT_USER_SETTINGS, function(e, i) {
                if (this.origin_user_settings[e] !== this.user_settings[e]) return t = !0, !1
            }, this), t
        },
        loadDefault: function() {
            Ext.iterate(SYNO.VideoController2.SubtitlePreference.DEFAULT_USER_SETTINGS, function(t, e) {
                this.user_settings[t] = SYNO.VideoController2.SubtitlePreference.DEFAULT_USER_SETTINGS[t]
            }, this), this.fireEvent(SYNO.VideoController2.SubtitlePreference.EVENT_DATA_CHANGED, this.getSettings())
        },
        rejectChanges: function() {
            for (var t in SYNO.VideoController2.SubtitlePreference.DEFAULT_USER_SETTINGS) SYNO.VideoController2.SubtitlePreference.DEFAULT_USER_SETTINGS.hasOwnProperty(t) && (this.user_settings[t] = this.origin_user_settings[t]);
            this.fireEvent(SYNO.VideoController2.SubtitlePreference.EVENT_DATA_CHANGED, this.getSettings())
        },
        repeatStr: function(t, e) {
            return new Array(e + 1).join(t)
        },
        getSubtitleSize: function(t) {
            var e = parseInt(t);
            return isNaN(t) ? SYNO.VideoController2.SubtitlePreference.DEFAULT_SUBTITLE_SIZE : e
        },
        getRGBA: function(t, e) {
            var i = t.slice(1);
            i = 3 === i.length ? this.repeatStr(i[0], 2) + this.repeatStr(i[1], 2) + this.repeatStr(i[2], 2) : i;
            var n = parseInt(i.slice(0, 2), 16),
                o = parseInt(i.slice(2, -2), 16),
                r = parseInt(i.slice(-2), 16);
            return String.format("rgba({0}, {1}, {2}, {3})", n, o, r, e / 100)
        },
        getShadow: function(t, e) {
            if (this.subtitle_shadow.hasOwnProperty(t) && this.subtitle_shadow[t].hasOwnProperty(e)) return this.subtitle_shadow[t][e];
            var i = this.getRGBA("#000", e),
                n = this.getRGBA("#222", e),
                o = this.getRGBA("#ccc", e),
                r = {
                    none: "",
                    default: String.format("{0} 0 1px 2px, {0} 1px 0 2px, {0} 0 -1px 2px, {0} -1px 0 2px", i),
                    drop_shadow: String.format("{0} 2px 2px 3px, {0} 2px 2px 4px, {0} 2px 2px 5px", n),
                    raised: String.format("{0} 1px 1px, {0} 2px 2px, {0} 3px 3px", n),
                    depressed: String.format("{1} 1px 1px, {1} 0 1px, {0} -1px -1px, {0} 0 -1px", n, o),
                    outline: String.format("{0} 0 0 4px, {0} 0 0 4px, {0} 0 0 4px, {0} 0 0 4px", n)
                };
            return this.subtitle_shadow = this.subtitle_shadow || {}, this.subtitle_shadow[t] = this.subtitle_shadow[t] || {}, this.subtitle_shadow[t][e] = r[t], this.subtitle_shadow[t][e]
        },
        isNoSubtitlePreference: function() {
            return void 0 === this.getUserSetting("subtitle_color")
        }
    }), Ext.define("SYNO.VideoController2.ChromecastPlayer", {
        statics: {
            APP_ID: "41BF9C95",
            SESSION: null,
            RECEIVER_AVAILABLE: !1,
            isCastAvailable: function() {
                return Ext.isDefined(window.chrome) && Ext.isDefined(window.chrome.cast) && window.chrome.cast.isAvailable
            },
            init: function() {
                return new Promise(function(t, e) {
                    var i = new chrome.cast.SessionRequest(SYNO.VideoController2.ChromecastPlayer.APP_ID),
                        n = new chrome.cast.ApiConfig(i, Ext.emptyFn, function(t) {
                            SYNO.VideoController2.ChromecastPlayer.RECEIVER_AVAILABLE = "available" === t
                        });
                    chrome.cast.initialize(n, t, e)
                })
            },
            launchCast: function() {
                return new Promise(function(t, e) {
                    chrome.cast.requestSession(function(e) {
                        SYNO.VideoController2.ChromecastPlayer.SESSION = e, t(e)
                    }, e)
                })
            },
            stopCast: function() {
                return new Promise(function(t, e) {
                    SYNO.VideoController2.ChromecastPlayer.SESSION.stop(function() {
                        SYNO.VideoController2.ChromecastPlayer.SESSION = null, t()
                    }, e)
                })
            }
        },
        extend: "SYNO.VideoController2.Player",
        constructor: function(t) {
            var e = {
                id: SYNO.VideoController2.Util.CHROMECAST_ID,
                type: SYNO.VideoController2.Util.PLAYERTYPE_CHROMECAST,
                name: "Chromecast",
                pluginInit: !1,
                retry_request_session: 10,
                state: SYNO.VideoController2.Util.STATE.STOPPED,
                volume: 50,
                muted: !1,
                password_protected: !1,
                volume_adjustable: !0,
                seekable: !0,
                video_url: "",
                enable_ac3_passthrough: !0 === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.VideoStation.AppInstance", "enable_ac3_passthrough"),
                namespace: "urn:x-cast:com.synology.dsvideo",
                auth_key: "",
                identify_command: {
                    version: 1,
                    command: "identify",
                    data: {
                        platform: "videostation",
                        platform_version: "1.5",
                        app_version: 108,
                        client_id: ""
                    }
                },
                first_start_playing: !1
            };
            this.callParent([Ext.apply(e, t)])
        },
        StateMap: {
            STOPPED: SYNO.VideoController2.Util.STATE.STOPPED,
            PLAYING: SYNO.VideoController2.Util.STATE.PLAYING,
            PAUSED: SYNO.VideoController2.Util.STATE.PAUSED,
            ERROR: SYNO.VideoController2.Util.STATE.ERROR
        },
        CastRepeatMap: ["REPEAT_OFF", "REPEAT_OFF", "REPEAT_SINGLE"],
        getIdentifyCommand: function() {
            return SYNO.Util.copy(this.identify_command)
        },
        getChallengeCommand: function(t) {
            this.auth_key = md5(t);
            var e = this.getIdentifyCommand();
            return Ext.apply(e.data, {
                auth_key: this.auth_key
            }), e
        },
        getTimeoutTask: function() {
            return Ext.isDefined(this.timeout_task) || (this.timeout_task = new Ext.util.DelayedTask(this.showNetworkError.createDelegate(this), this)), this.timeout_task
        },
        getVideoUrl: function(t) {
            this.video_url = t || this.video_url;
            var e = SYNO.VideoController2.Util.getLocationOrigin();
            return 0 === this.video_url.indexOf(e) ? this.video_url : e + this.video_url
        },
        getMappedSubtitleSize: function(t) {
            return t <= 28 ? "extra-small" : t <= 36 ? "small" : t <= 40 ? "medium" : t <= 48 ? "large" : "extra-large"
        },
        getSubtitleUrl: function(t) {
            var e = {
                id: t.video_list.getFileUniqueKey(),
                subtitle_codepage: t.subtitle_codepage,
                subtitle_id: Ext.encode(t.subtitle_id),
                tid: this.subtitle_tid
            };
            return Ext.apply(e, SYNO.VideoController2.SharingHelper.getAPI("Subtitle")), Ext.urlAppend(String.format("{0}{1}", SYNO.VideoController2.Util.getLocationFullPath(), SYNO.VideoController2.SharingHelper.getCGIPath("subtitle")), Ext.urlEncode(e))
        },
        getPosterUrl: function(t) {
            var e = {
                id: t.video_id,
                type: t.type,
                tid: this.poster_tid
            };
            return Ext.apply(e, SYNO.VideoController2.SharingHelper.getAPI("Poster")), Ext.urlAppend(String.format("{0}{1}", SYNO.VideoController2.Util.getLocationOrigin(), SYNO.VideoController2.SharingHelper.getCGIPath("poster")), Ext.urlEncode(e))
        },
        ableToPlayRaw: function(t, e) {
            var i = e.width / e.height > 1;
            if (!0 === i && (e.width > 1920 || e.height > 1080) || !1 === i && (e.width > 1080 || e.height > 1920)) return !1;
            if (!SYNO.VideoController2.Util.isMP4Container(t.container_type) && -1 === t.container_type.indexOf("webm")) return !1;
            var n = t.video_codec;
            return ("mpeg4" === n || "h264" === n || "mjpeg" === n) && this.ableToPlayRawAudio(t.audio_codec, t.channel)
        },
        ableToPlayRawAudio: function(t, e) {
            return -1 !== t.indexOf("aac") && 2 === e || -1 !== t.indexOf("mp3") || -1 !== t.indexOf("ac3") && this.enable_ac3_passthrough
        },
        ableToRemux: function(t, e) {
            return !(e.width > 1920 || e.height > 1080) && this.controller.hls_handler.ableToRemux(t)
        },
        ableToTranscode: function() {
            return this.controller.supportTranscode()
        },
        isRaw: function(t) {
            return -1 !== t.indexOf("format=raw")
        },
        isAvailable: function() {
            return SYNO.VideoController2.ChromecastPlayer.RECEIVER_AVAILABLE
        },
        checkResumed: function() {
            return !0
        },
        play: function(t) {
            Promise.all([SYNO.VideoController2.Util.prepareTicketId("SYNO.VideoStation2.Poster", ["get"]), SYNO.VideoController2.Util.prepareTicketId("SYNO.VideoStation2.Subtitle", ["get"])]).then(function(e) {
                this.poster_tid = e[0].tid, this.subtitle_tid = e[1].tid, this.playImpl(t)
            }.bind(this))
        },
        playImpl: function(t) {
            this.connect();
            var e = this.getVideoUrl(t),
                i = this.controller.video_list.getCurrentVideo(),
                n = this.getSubtitleUrl(this.controller),
                o = this.controller.getDelayedTime(),
                r = SYNO.VideoController2.SubtitlePreference.get().getSetting("subtitle_size"),
                l = this.controller.subtitle_id;
            l = l === SYNO.VideoController2.Util.SUBTITLE_NONE || l === SYNO.VideoController2.Util.SUBTITLE_DISCOVER ? "" : l, this.timeout = this.isRaw(e) ? 15e3 : 3e4;
            var s = new chrome.cast.media.MediaInfo(e);
            s.contentType = this.isRaw(e) ? "video/mp4" : "application/x-mpegURL", s.duration = this.controller.video_list.getDuration(), s.customData = {
                type: i.type,
                title: this.controller.video_list.getName(),
                date: this.controller.video_list.getDate(),
                poster_uri: this.getPosterUrl(i),
                video_format: this.isRaw(e) ? "mp4" : "hls",
                subtitle_uri: n,
                subtitle_offset: o,
                subtitle_size: this.getMappedSubtitleSize(r),
                remote_addr: location.host,
                extra: {
                    audio_id: this.controller.audio_id.toString(),
                    video_id: this.controller.video_list.getVideoID().toString(),
                    file_id: this.controller.video_list.getFileUniqueKey().toString(),
                    subtitle_id: l
                }
            };
            var a = new chrome.cast.media.QueueItem(s);
            a.autoplay = !0, a.startTime = this.start_position || 0;
            var d = new chrome.cast.media.QueueLoadRequest([a]);
            d.startIndex = 0, d.repeatMode = this.CastRepeatMap[this.controller.repeat], this.media_loading = !0, SYNO.VideoController2.ChromecastPlayer.SESSION.queueLoad(d, this.onMediaDiscovered.createDelegate(this, ["loadMedia"], !0), this.onError.createDelegate(this)), this.state = SYNO.VideoController2.Util.STATE.BUFFERING, this.startPolling()
        },
        onMediaDiscovered: function(t, e) {
            this.media = t, this.media_loading = !1
        },
        pause: function() {
            this.media.pause(null, Ext.emptyFn, this.onError.createDelegate(this))
        },
        resume: function() {
            this.media.play(null, Ext.emptyFn, this.onError.createDelegate(this))
        },
        stop: function() {
            this.task_runner && this.media.stop(null, Ext.emptyFn, this.onError.createDelegate(this))
        },
        seek: function(t) {
            if (this.media && !this.media_loading) {
                var e = new chrome.cast.media.SeekRequest;
                e.currentTime = parseInt(t.toFixed(0), 10), this.media.seek(e, Ext.emptyFn, this.onError.createDelegate(this))
            }
        },
        getPosition: function() {
            return this.pluginInit ? this.position : -1
        },
        getDuration: function() {
            return this.pluginInit ? this.duration : -1
        },
        getVolume: function() {
            return this.volume
        },
        setVolume: function(t) {
            SYNO.VideoController2.ChromecastPlayer.SESSION.setReceiverVolumeLevel(t / 100)
        },
        getMute: function() {
            return this.muted
        },
        setMute: function(t) {
            SYNO.VideoController2.ChromecastPlayer.SESSION.setReceiverMuted(t)
        },
        getState: function() {
            return this.state
        },
        disablePlayerSubtitle: Ext.emptyFn,
        setPlayerSubtitle: function(t) {
            this.sendMessage({
                version: 1,
                command: "subtitle.uri",
                data: {
                    subtitle_uri: t
                }
            })
        },
        setSubtitleDelay: function(t) {
            this.sendMessage({
                version: 1,
                command: "subtitle.offset",
                data: {
                    offset: t
                }
            })
        },
        setSubtitleSize: function(t) {
            this.sendMessage({
                version: 1,
                command: "subtitle.size",
                data: {
                    size: this.getMappedSubtitleSize(t)
                }
            })
        },
        setRepeat: function(t) {
            this.media.queueSetRepeatMode(this.CastRepeatMap[t], Ext.emptyFn, this.onError.createDelegate(this))
        },
        close: function() {
            this.sendMessage({
                version: 1,
                command: "close"
            })
        },
        clear: function() {
            this.stopPolling(), this.stopAttachPolling(), this.controller.hls_handler.closeStream(), this.notifyClear(), this.pluginInit = !1, this.duration = null
        },
        connect: function() {
            this.pluginInit = !0, SYNO.VideoController2.ChromecastPlayer.SESSION.addMessageListener(this.namespace, this.receiverMessage.bind(this)), SYNO.VideoController2.ChromecastPlayer.SESSION.addUpdateListener(this.sessionUpdateListener.bind(this)), SYNO.VideoController2.ChromecastPlayer.SESSION.sendMessage(this.namespace, this.getIdentifyCommand(), this.onSuccess.createDelegate(this), this.onError.createDelegate(this))
        },
        disconnect: function() {
            this.getTimeoutTask().cancel(), this.stopPolling(), this.pluginInit = !1
        },
        sessionUpdateListener: function(t) {
            this.getTimeoutTask().cancel(), t || (this.state === SYNO.VideoController2.Util.STATE.STOPPED ? this.clear() : (this.controller.hls_handler.closeStream(), this.showNetworkError()))
        },
        sendMessage: function(t) {
            null !== SYNO.VideoController2.ChromecastPlayer.SESSION && SYNO.VideoController2.ChromecastPlayer.SESSION.sendMessage(this.namespace, t, this.onSuccess.createDelegate(this, [Ext.encode(t)]), this.onError.createDelegate(this))
        },
        receiverMessage: function(t, e) {
            this.getTimeoutTask().cancel(), this.stopAttachPolling();
            var i = Ext.decode(e);
            if (!i || !i.type) return this.state = SYNO.VideoController2.Util.STATE.ERROR, void(this.prev_state = this.state);
            if ("challenge" === i.type) return void this.sendMessage(this.getChallengeCommand(i.data.seed));
            if ("status" === i.type && i.data && i.data.state && (this.state = this.StateMap[i.data.state.toUpperCase()] || SYNO.VideoController2.Util.STATE.ERROR), this.state !== SYNO.VideoController2.Util.STATE.PLAYING || this.first_start_playing) {
                if (this.state === SYNO.VideoController2.Util.STATE.PLAYING) {
                    if (this.prev_state === SYNO.VideoController2.Util.STATE.ERROR) this.pluginInit = !0, this.startPolling();
                    else if (i.data.video_uri !== this.getVideoUrl()) return this.pluginInit = !0, void(this.prev_state = this.state);
                    this.getTimeoutTask().delay(this.timeout), this.position = i.data.position, this.durationHandler(i.data.duration);
                    var n = 100 * SYNO.VideoController2.ChromecastPlayer.SESSION.receiver.volume.level,
                        o = SYNO.VideoController2.ChromecastPlayer.SESSION.receiver.volume.muted;
                    n !== this.volume && (this.volume = n), o !== this.muted && (this.muted = o)
                }
            } else this.playerReadyHandler(), this.first_start_playing = !0;
            this.prev_state = this.state
        },
        onSuccess: function(t) {},
        showNetworkError: function() {
            this.onError({
                code: "timeout_error",
                description: _VCT("controller", "error_state")
            })
        },
        onError: function(t) {
            this.getTimeoutTask().cancel(), this.stopPolling(), this.controller.getPlayer().id !== SYNO.VideoController2.Util.CHROMECAST_ID && this.controller.init_player_id !== SYNO.VideoController2.Util.CHROMECAST_ID || (("cancel" === t.code || "receiver_unavailable" === t.code || "channel_error" === t.code || "timeout_error" === t.code || "session_error" === t.code && !this.attach_polling_status) && (this.pluginInit = !1, this.state = SYNO.VideoController2.Util.STATE.ERROR, this.prev_state = this.state, this.stateHandler(t.description)), "timeout_error" === t.code && this.startAttachPolling())
        },
        startAttachPolling: function() {
            this.stopAttachPolling(), this.attach_task_runner = new SYNO.SDS.TaskRunner, this.attach_polling_status = this.attach_task_runner.createTask({
                scope: this,
                run: this.sendMessage.createDelegate(this, [this.getIdentifyCommand()]),
                interval: 1e3
            }), this.attach_polling_status.start(!0)
        },
        stopAttachPolling: function() {
            this.attach_task_runner && (this.attach_polling_status = null, this.attach_task_runner.destroy(), this.attach_task_runner = null)
        },
        startPolling: function() {
            this.stopPolling(), this.task_runner = new SYNO.SDS.TaskRunner, this.polling_status = this.task_runner.createTask({
                scope: this,
                run: function() {
                    this.stateHandler(), this.positionHandler(), this.durationHandler(), this.volumeHandler()
                },
                interval: 150
            }), this.polling_status.start(!0)
        },
        stopPolling: function() {
            this.task_runner && (this.polling_status = null, this.task_runner.destroy(), this.task_runner = null, this.first_start_playing = !1)
        }
    }), Ext.define("SYNO.VideoController2.FlashPlayer", {
        extend: "SYNO.VideoController2.Player",
        constructor: function(t) {
            var e = {
                name: "Flash",
                player_id: "_flash_video_player",
                error: !1,
                first_start_playing: !1
            };
            this.callParent([Ext.apply(e, t)])
        },
        ableToRemux: function(t) {
            return this.controller.hls_handler.ableToRemux(t)
        },
        ableToTranscode: function() {
            return this.controller.supportTranscode()
        },
        canPlayType: function(t, e) {
            var i = ["mp4", "mov", "m4v", "flv", "f4v"];
            return "hevc" !== e && -1 !== i.indexOf(t)
        },
        isAvailable: function() {
            return SYNO.VideoController2.Util.detectPlugin("ShockwaveFlash.ShockwaveFlash", "Shockwave", "Flash")
        },
        checkResumed: function(t) {
            return this.checkResumedByCase(t)
        },
        fullscreen: function() {
            this.pluginInit && SYNO.VideoController2.Util.setDomFullscreen(this.controller.container.dom)
        },
        clear: function() {
            this.delayDestroy.defer(1, this, arguments), this.controller.hls_handler.closeStream()
        },
        play: function(t) {
            this.error = !1, this.url = t, this.createPlayer() || this.player.load([{
                file: this.url
            }])
        },
        pause: function() {
            this.pluginInit && this.player.pause(!0)
        },
        resume: function() {
            this.pluginInit && this.player.play(!0)
        },
        stop: function() {
            this.pluginInit && this.player.stop(), this.controller.hls_handler.closeStream()
        },
        seek: function(t) {
            this.pluginInit && t >= 0 && t <= this.player.getDuration() && this.player.seek(t)
        },
        getPosition: function() {
            return this.pluginInit ? this.player.getPosition() : -1
        },
        getDuration: function() {
            return this.pluginInit ? this.player.getDuration() : -1
        },
        getVolume: function() {
            return this.pluginInit ? this.player.getVolume() : -1
        },
        setVolume: function(t) {
            this.pluginInit && this.player.setVolume(t)
        },
        getMute: function() {
            return !!this.pluginInit && this.player.getMute()
        },
        setMute: function(t) {
            this.pluginInit && this.player.setMute(t)
        },
        StateMap: {
            IDLE: SYNO.VideoController2.Util.STATE.STOPPED,
            BUFFERING: SYNO.VideoController2.Util.STATE.BUFFERING,
            PLAYING: SYNO.VideoController2.Util.STATE.PLAYING,
            PAUSED: SYNO.VideoController2.Util.STATE.PAUSED
        },
        getPlayerState: function() {
            return this.pluginInit ? this.player.getState() : "IDLE"
        },
        getState: function() {
            if (!this.pluginInit) return SYNO.VideoController2.Util.STATE.NO_MEDIA;
            if (this.error) return SYNO.VideoController2.Util.STATE.ERROR;
            var t = this.StateMap[this.getPlayerState()] || SYNO.VideoController2.Util.STATE.ERROR;
            return t !== SYNO.VideoController2.Util.STATE.PLAYING || this.first_start_playing || (this.playerReadyHandler(), this.first_start_playing = !0), t
        },
        delayDestroy: function() {
            this.player && (this.player.remove(), this.el.remove(), this.el = null, this.player = null, this.pluginInit = !1, this.duration = null, this.notifyClear(), this.first_start_playing = !1)
        },
        onReady: function() {
            this.pluginInit = !0, this.player = jwplayer(this.player_id), this.registerEventHandler(), this.setVolume(this.controller.volume)
        },
        onError: function() {
            this.error = !0, this.stateHandler()
        },
        onPlaylist: function() {
            this.player.playlistItem(0)
        },
        onTime: function(t) {
            Ext.isObject(t) && (Ext.isNumber(t.duration) && this.durationHandler(t.duration), Ext.isNumber(t.position) && this.positionHandler(t.position))
        },
        createPlayer: function() {
            if (this.player) return !1;
            this.el = Ext.get(this.player_id) || this.controller.video.createChild({
                tag: "div",
                id: this.player_id,
                style: {
                    width: "100%",
                    height: "100%"
                }
            });
            var t = String.format("{0}/skin/empty-controlbar.xml", this.controller.jsBaseURL),
                e = String.format("{0}/jwplayer.flash.swf?v=6.8.4616", this.controller.jsBaseURL);
            return this.setJWPlayerKey(), this.player = jwplayer(this.player_id).setup({
                fallback: !1,
                flashplayer: e,
                file: this.url,
                controls: !1,
                autostart: !1,
                skin: t,
                height: "100%",
                width: "100%",
                stretching: "uniform",
                primary: "flash",
                analytics: {
                    enabled: !1
                }
            }), this.registerSetupHandler(), !0
        },
        registerSetupHandler: function() {
            jwplayer(this.player_id).onReady(this.onReady.createDelegate(this)), jwplayer(this.player_id).onSetupError(this.onError.createDelegate(this))
        },
        registerEventHandler: function() {
            this.player.onPlaylist(this.onPlaylist.createDelegate(this)), this.player.onPlaylistComplete(this.stateHandler.createDelegate(this)), this.player.onPlay(this.stateHandler.createDelegate(this)), this.player.onPause(this.stateHandler.createDelegate(this)), this.player.onBuffer(this.stateHandler.createDelegate(this)), this.player.onIdle(this.stateHandler.createDelegate(this)), this.player.onComplete(this.stateHandler.createDelegate(this)), this.player.onError(this.onError.createDelegate(this)), this.player.onTime(this.onTime.createDelegate(this)), this.player.onMute(this.volumeHandler.createDelegate(this)), this.player.onVolume(this.volumeHandler.createDelegate(this))
        },
        setJWPlayerKey: function() {
            jwplayer.key || (jwplayer.key = "ADrNpyYVQ13xVOfDuZpCXl4Bioq40D0Omx8S/CIM46w=")
        }
    }), Ext.define("SYNO.VideoController2.WebAPI", {
        statics: {
            send: function(t) {
                return new Promise(function(e, i) {
                    SYNO.API.Request(Ext.apply(t, {
                        scope: null,
                        callback: function(t, n, o, r) {
                            t ? e(n) : i([n, o, r])
                        }
                    }))
                })
            },
            keepaliveFetch: function(t, e, i, n) {
                if (!window.fetch || !window.URLSearchParams) return SYNO.VideoController2.WebAPI.send({
                    api: t,
                    method: e,
                    version: i,
                    async: !1,
                    params: n
                });
                var o = SYNO.API.GetKnownAPI(t);
                if (!o) return SYNO.Debug.error("No Such API: " + t), new Promise;
                "JSON" === o.requestFormat && (n = SYNO.API.EncodeParams(n));
                var r = "webapi/" + o.path + "/" + t,
                    l = new URLSearchParams(Ext.apply({
                        api: t,
                        method: e,
                        version: i
                    }, n)),
                    s = {};
                return Ext.isEmpty(_S("SynoToken")) || (s["X-SYNO-TOKEN"] = _S("SynoToken")), new Promise(function(t, e) {
                    fetch(r, {
                        method: "POST",
                        credentials: "same-origin",
                        keepalive: !0,
                        headers: s,
                        body: l
                    }).then(function(t) {
                        return t.json()
                    }).then(function(i) {
                        i.success ? t(i.data) : e(i.error)
                    })
                })
            },
            all: function(t, e, i) {
                return Promise.all(t).then(e).catch(i)
            },
            instance: null,
            get: function() {
                return Ext.isObject(SYNO.VideoController2.WebAPI.instance) || (SYNO.VideoController2.WebAPI.instance = new SYNO.VideoController2.WebAPI), SYNO.VideoController2.WebAPI.instance
            }
        }
    }), Ext.define("SYNO.VideoController2.HLSHandler", {
        extend: "Ext.util.Observable",
        constructor: function(t) {
            this.callParent([t]), Ext.apply(this, t)
        },
        supportRemux: Ext.emptyFn,
        ableToRemux: function(t) {
            if (!this.supportRemux()) return !1;
            var e = t.container_type;
            return "h264" === t.video_codec && (SYNO.VideoController2.Util.isMP4Container(e) || "matroska,webm" === e)
        },
        openStream: function(t) {
            var e = Ext.apply({
                async: !SYNO.VideoController2.Util.isMacSafari() || !SYNO.VideoController2.Util.isMobile(),
                params: t
            }, SYNO.VideoController2.SharingHelper.getAPI("StreamingOpen"));
            return SYNO.VideoController2.WebAPI.send(e)
        },
        closeStream: function() {
            if (!Ext.isEmpty(this.controller.stream_id) && !Ext.isEmpty(this.controller.stream_format)) {
                var t = SYNO.VideoController2.SharingHelper.getAPI("StreamingClose"),
                    e = Ext.apply({
                        format: this.controller.stream_format
                    }, SYNO.VideoController2.SharingHelper.getStreamingCloseParam(this.controller.stream_id));
                SYNO.VideoController2.Util.applySharingID(e), SYNO.VideoController2.WebAPI.keepaliveFetch(t.api, t.method, t.version, e).then(function() {
                    this.controller.stream_id = null, this.controller.stream_format = null
                }.bind(this)).catch(Ext.emptyFn)
            }
        }
    }), Ext.define("SYNO.VideoController2.HTML5Player", {
        extend: "SYNO.VideoController2.Player",
        constructor: function(t) {
            var e = {
                name: "HTML5",
                player_id: "_html5_video_player",
                stopped: !1
            };
            this.callParent([Ext.apply(e, t)])
        },
        ableToRemux: function(t) {
            return this.controller.hls_handler.ableToRemux(t)
        },
        ableToTranscode: function() {
            return this.controller.supportTranscode()
        },
        canPlayType: function(t, e) {
            if ("avi" === t && SYNO.VideoController2.Util.isMacSafari()) return !1;
            var i = SYNO.VideoController2.Util.MimeType[t] || "video/" + t;
            return "hevc" === e && (i += '; codecs="hvc1"'), SYNO.VideoController2.Util.testHTML5VideoCanPlayType(i)
        },
        isAvailable: function() {
            return SYNO.VideoController2.Util.testHTML5VideoCanPlayType()
        },
        checkResumed: function(t) {
            return this.checkResumedByPosition(t)
        },
        fullscreen: function() {
            this.pluginInit && SYNO.VideoController2.Util.setDomFullscreen(this.controller.container.dom)
        },
        playImpl: function() {
            var t = this.player.play();
            Ext.isEmpty(t) || t.catch(function() {
                this.notifyAutoPlayFail()
            }.bind(this))
        },
        clear: function() {
            this.unregisterEventHandler(), this.callParent(arguments), this.controller.hls_handler.closeStream()
        },
        play: function(t) {
            var e = t || this.player.src;
            this.stopped = !1, this.createPlayer(), this.player.src = e, this.playImpl(), this.setVolume(this.controller.volume), this.setPlaybackRate(this.controller.playback_rate)
        },
        pause: function() {
            this.pluginInit && this.player.pause()
        },
        resume: function() {
            this.pluginInit && this.player.play()
        },
        stop: function() {
            this.pluginInit && (this.stopped = !0, this.player.pause(), this.stateHandler()), this.controller.hls_handler.closeStream()
        },
        seek: function(t) {
            this.pluginInit && t >= 0 && t <= this.player.duration && (this.player.currentTime = t)
        },
        getPosition: function() {
            return this.pluginInit ? this.player.currentTime : -1
        },
        getDuration: function() {
            return this.pluginInit ? this.player.duration : -1
        },
        getVolume: function() {
            return this.pluginInit ? 100 * this.player.volume : -1
        },
        setVolume: function(t) {
            this.pluginInit && (this.player.volume = t / 100)
        },
        setPlaybackRate: function(t) {
            this.pluginInit && (this.player.playbackRate = t)
        },
        getMute: function() {
            var t = !1;
            return this.pluginInit && (t = this.player.muted), t
        },
        setMute: function(t) {
            this.pluginInit && (this.player.muted = t)
        },
        getState: function() {
            return this.pluginInit ? this.player.error ? SYNO.VideoController2.Util.STATE.ERROR : this.player.ended || this.player.HAVE_NOTHING === this.player.readyState || this.stopped ? SYNO.VideoController2.Util.STATE.STOPPED : this.player.paused ? SYNO.VideoController2.Util.STATE.PAUSED : this.player.HAVE_CURRENT_DATA >= this.player.readyState ? SYNO.VideoController2.Util.STATE.BUFFERING : SYNO.VideoController2.Util.STATE.PLAYING : SYNO.VideoController2.Util.STATE.NO_MEDIA
        },
        setVisible: function(t) {
            Ext.isSafari && this.el && this.el.setVisible(t)
        },
        createPlayer: function() {
            return !this.player && (this.el = Ext.get(this.player_id) || this.controller.video.createChild({
                tag: "video",
                id: this.player_id,
                playsinline: !0,
                style: {
                    width: "100%",
                    height: "100%"
                }
            }), this.player = this.el.dom, this.registerEventHandler(), this.pluginInit = !0, this.el.enableDisplayMode(), this.el.show(), this.player.pause(), !0)
        },
        registerEventHandler: function() {
            this._stateHandlerWithScope = this.stateHandler.createDelegate(this), this._durationHandlerWithScope = this.durationHandler.createDelegate(this), this._volumeHandlerWithScope = this.volumeHandler.createDelegate(this), this._playerReadyHandlerWithScope = this.playerReadyHandler.createDelegate(this);
            var t = SYNO.VideoController2.Util.addDomListener(!1);
            t(this.player, "play", this._stateHandlerWithScope), t(this.player, "playing", this._stateHandlerWithScope), t(this.player, "canplaythrough", this._stateHandlerWithScope), t(this.player, "waiting", this._stateHandlerWithScope), t(this.player, "pause", this._stateHandlerWithScope), t(this.player, "ended", this._stateHandlerWithScope), t(this.player, "error", this._stateHandlerWithScope), t(this.player, "durationchange", this._durationHandlerWithScope), t(this.player, "volumechange", this._volumeHandlerWithScope), this.player.addEventListener("playing", this._playerReadyHandlerWithScope, {
                single: !0
            }), SYNO.VideoController2.Util.isIos() || (this._webkitHandlerWithScope = this.webkitHandler.createDelegate(this), t(this.player, "webkitendfullscreen", this._webkitHandlerWithScope)), this.createPollingTask()
        },
        unregisterEventHandler: function() {
            var t = SYNO.VideoController2.Util.removeDomListener(!1);
            t(this.player, "play", this._stateHandlerWithScope), t(this.player, "playing", this._stateHandlerWithScope), t(this.player, "waiting", this._stateHandlerWithScope), t(this.player, "pause", this._stateHandlerWithScope), t(this.player, "ended", this._stateHandlerWithScope), t(this.player, "error", this._stateHandlerWithScope),
                t(this.player, "durationchange", this._durationHandlerWithScope), t(this.player, "volumechange", this._volumeHandlerWithScope), SYNO.VideoController2.Util.isIos() || (t(this.player, "webkitendfullscreen", this._webkitHandlerWithScope), this._webkitHandlerWithScope = null), this.destroyPollingTask(), this._stateHandlerWithScope = null, this._durationHandlerWithScope = null, this._volumeHandlerWithScope = null, this._playerReadyHandlerWithScope = null
        },
        pollingTaskFn: function() {
            this.positionHandler()
        }
    }), Ext.define("SYNO.VideoController2.HLSPlayer", {
        extend: "SYNO.VideoController2.HTML5Player",
        constructor: function(t) {
            var e = {
                name: "HLS",
                player_id: "_hls_video_player"
            };
            this.callParent([Ext.apply(e, t)]), this.hls = null
        },
        canPlayType: function(t) {
            return !1
        },
        isAvailable: function() {
            return Hls.isSupported() && this.callParent(arguments)
        },
        play: function(t) {
            var e = t || this.player_src;
            this.player_src = e, this.stopped = !1, this.createPlayer(), this.hls = new Hls, this.hls.loadSource(e), this.hls.attachMedia(this.player), this.playImpl(), this.setVolume(this.controller.volume), this.setPlaybackRate(this.controller.playback_rate)
        },
        clear: function() {
            this.hls && this.hls.destroy(), this.callParent(arguments)
        },
        getState: function() {
            var t = this.callParent(arguments);
            return t !== SYNO.VideoController2.Util.STATE.NO_MEDIA && this.player.HAVE_NOTHING === this.player.readyState && (t = SYNO.VideoController2.Util.STATE.BUFFERING), t
        }
    }), Ext.define("SYNO.VideoController2.MessageBox", {
        extend: "SYNO.SDS.MessageBoxV5",
        constructor: function() {
            this.callParent(arguments), this.addClass("syno-vc-msgbox")
        },
        onRender: function() {
            this.callParent(arguments), this.progressBar.addClass("syno-vc-progress")
        },
        getButtons: function() {
            var t = this.callParent(arguments);
            return t.forEach(function(t) {
                t.addClass && t.addClass("syno-vc-button")
            }), t
        }
    }), Ext.define("SYNO.VideoController2.Dialog", {
        extend: "SYNO.SDS.ModalWindow",
        constructor: function(t) {
            var e = Ext.isString(t.cls) ? t.cls + " syno-vc-dialog" : "syno-vc-dialog";
            t.cls = e;
            var i = Ext.apply({}, t);
            i.listeners = i.listeners || {}, Ext.apply(i.listeners, {
                show: this.onDialogShow.createDelegate(this),
                hide: this.onDialogHide.createDelegate(this),
                close: this.onDialogClose.createDelegate(this)
            }), this.callParent([i])
        },
        onDialogShow: function() {
            Ext.isDefined(this.controller) && (this.controller.spaceenabled = !1)
        },
        onDialogHide: function() {
            Ext.isDefined(this.controller) && (this.controller.spaceenabled = !0)
        },
        onDialogClose: function() {
            Ext.isDefined(this.controller) && (this.controller.spaceenabled = !0)
        },
        getMsgBox: function(t) {
            if (!this.msgBox || this.msgBox.isDestroyed) {
                var e = t && t.owner || this;
                e = e.isDestroyed ? null : e, this.msgBox = new SYNO.VideoController2.MessageBox({
                    owner: e
                })
            }
            return this.callParent(arguments)
        }
    }), Ext.define("SYNO.VideoController2.ListDialog", {
        extend: "SYNO.VideoController2.Dialog",
        constructor: function(t) {
            this.setDataFromStore(t.orgStore), this.pageSize = 10;
            var e = {
                padding: 0,
                autoFlexcroll: !0,
                cls: "syno-vs-sharing-list-dialog",
                title: _VCT("controller", "share_playlist_title"),
                maximized: SYNO.VideoController2.Util.isMobile(),
                minWidth: 540,
                width: 540,
                minHeight: 586,
                height: 586,
                useStatusBar: !1,
                layout: "fit",
                closeAction: "hide",
                items: [this.getDataView()],
                bbar: this.getPagingToolbar(),
                listeners: {
                    scope: this,
                    beforerender: function() {
                        this.orig_useShims = Ext.useShims, Ext.useShims = !0
                    },
                    afterrender: function() {
                        Ext.useShims = this.orig_useShims
                    }
                }
            };
            0 === this.data.videos.length && (e.cls += " empty", e.height = 360, e.minHeight = 360), this.callParent([Ext.apply(e, t)]), this.maskEl.on("click", function() {
                this.hide()
            }, this), this.maskEl.addClass("syno-vs-sharing-mask")
        },
        getDataView: function() {
            return {
                xtype: "syno_flexcroll_dataview",
                singleSelect: !0,
                itemSelector: "div.vc-sharing-list-playicon",
                store: this.getStore(),
                tpl: this.getTpl(),
                emptyText: this.getEmptyTpl(),
                deferEmptyText: !1,
                listeners: {
                    scope: this,
                    click: function(t, e, i) {
                        var n = t.getStore().getAt(e).data,
                            o = n.unique_id;
                        this.controller.jump(o), this.hide()
                    }
                }
            }
        },
        getEmptyTpl: function() {
            return ["<div>", '<div class="vc-sharing-list-empty"></div>', '<div class="vc-sharing-list-empty-text">', _VCT("controller", "empty_list_msg"), "</div>", "</div>"].join("")
        },
        getTpl: function() {
            return new Ext.XTemplate('<tpl for=".">', '<div class="vc-sharing-list-video">', '<div class="{[this.getImgClass(values.type)]}" style="{[this.getBackground(values.type, values.video_id)]}"></div>', '<div class="vc-sharing-list-info">', '<div class="vc-sharing-list-title">{[this.getTitle(values)]}</div>', '<div class="vc-sharing-list-filename">{[this.getFileName(values)]}</div>', "</div>", '<div class="vc-sharing-list-playicon" unique_id="{unique_id}"></div>', "</div>", "</tpl>", {
                getImgClass: function(t) {
                    return "movie" === t ? "vc-sharing-poster" : "vc-sharing-screenshot"
                },
                getBackground: function(t, e) {
                    var i = SYNO.VideoController2.Util.getImageURL(e, t);
                    return String.format(Ext.isIE8 || Ext.isIE7 ? "filter: progid:DXImageTransform.Microsoft.AlphaImageLoader(src='{0}', sizingMethod='scale')" : "background-image: url('{0}')", i)
                },
                getTitle: function(t) {
                    var e = t.original_data,
                        i = Ext.util.Format.htmlEncode(e.title),
                        n = Date.parseDate(e.time, "Y-m-d H:i:s"),
                        o = e.type;
                    if ("movie" === o) return i + (Ext.isEmpty(n) ? "" : " (" + n.getFullYear() + ")");
                    if ("tvshow_episode" === o) {
                        var r = this.getFormatNumber(e.season),
                            l = this.getFormatNumber(e.episode);
                        return i + "(" + e.tagline + " " + _VST("season_title") + " " + r + "-" + l + (Ext.isEmpty(n) ? "" : " (" + n.getFullYear() + ")")
                    }
                    return i + (Ext.isEmpty(n) ? "" : " (" + e.time + ")")
                },
                getFormatNumber: function(t) {
                    return t < 10 ? "0" + t : t
                },
                getFileName: function(t) {
                    var e = t.original_data.additional.file[0].path,
                        i = e.substr(e.lastIndexOf("/") + 1);
                    return Ext.util.Format.htmlEncode(i)
                }
            })
        },
        getPagingToolbar: function() {
            return Ext.isDefined(this.paging) || (this.paging = new SYNO.ux.PagingToolbar({
                displayInfo: !0,
                showRefreshBtn: !1,
                store: this.getStore(),
                hidden: 0 === this.data.videos.length,
                pageSize: this.pageSize,
                cls: "syno-vc-pagingtoolbar"
            })), this.paging
        },
        setDataFromStore: function(t) {
            if (Ext.isEmpty(t)) return void(this.data = {
                offset: 0,
                total: 0,
                videos: []
            });
            this.data = {
                offset: t.getTotalCount(),
                total: t.getTotalCount(),
                videos: []
            }, t.data.each(function(t) {
                this.data.videos.push(t.data)
            }, this)
        },
        getStore: function() {
            if (this.gridStore) return this.gridStore;
            var t = new Ext.data.MemoryProxy([]);
            return t.allData = this.data, t.on("beforeload", function(t, e) {
                var i = {
                    offset: e.start,
                    total: t.allData.total,
                    videos: t.allData.videos.slice(e.start, e.start + e.limit)
                };
                t.data = i
            }), this.gridStore = new Ext.data.JsonStore({
                data: {
                    offset: this.pageSize,
                    total: this.data.total,
                    videos: this.data.videos.slice(0, this.pageSize)
                },
                proxy: t,
                root: "videos",
                idProperty: "unique_id",
                fields: ["unique_id", "type", "video_id", "original_data"],
                listeners: {
                    scope: this,
                    load: this.onAfterLoadStore
                }
            }), this.gridStore
        },
        onAfterLoadStore: function() {
            Ext.select(".syno-vs-sharing-playicon").elements.forEach(function(t) {
                var e = t.getAttribute("unique_id"),
                    i = Ext.fly(t);
                i.addClassOnOver("playicon-mouseover"), i.addClassOnClick("playicon-click"), i.on("click", function() {
                    this.controller.jump(e), this.hide()
                }, this)
            }, this)
        },
        show: function() {
            this.playerState = this.controller.getPlayer().getState(), this.playerState === SYNO.VideoController2.Util.STATE.PLAYING && this.controller.play(), this.callParent(arguments)
        },
        hide: function() {
            0 !== this.data.videos.length && (this.playerState === SYNO.VideoController2.Util.STATE.PLAYING && this.controller.getPlayer().getState() === SYNO.VideoController2.Util.STATE.PAUSED && this.controller.play(), this.callParent(arguments))
        }
    }), Ext.define("SYNO.VideoController2.NullPlayer", {
        extend: "SYNO.VideoController2.Player",
        constructor: function(t) {
            var e = {
                name: "Null",
                error: !1
            };
            this.callParent([Ext.apply(e, t)])
        },
        canPlayType: function() {
            return !1
        },
        isAvailable: function() {
            return !0
        },
        play: function() {
            this.error = !0;
            var t = SYNO.VideoController2.Util.isMobile(),
                e = !t && !Ext.isMac,
                i = SYNO.VideoController2.Util.isVLCSupported(),
                n = _T("video_player", "error_play");
            e && (n = i ? _VCT("video_player", "error_play_pc") : _VCT("video_player", "error_play_other_browser_or_desktop_vlc")), this.stateHandler(n)
        },
        getState: function() {
            return this.error ? SYNO.VideoController2.Util.STATE.ERROR : SYNO.VideoController2.Util.STATE.STOPPED
        }
    }), Ext.define("SYNO.VideoController2.PasswordDialog", {
        extend: "SYNO.VideoController2.Dialog",
        constructor: function(t) {
            this.player_title = t.player_title;
            var e = {
                dsmStyle: "v5",
                cls: "password-dialog",
                title: _VCT("controller", "renderer_password_title"),
                width: 460,
                height: 180,
                padding: "8px 30px 8px 30px",
                items: [this.getFormPanel()],
                buttons: [{
                    cls: "syno-vc-button",
                    text: _T("common", "ok"),
                    btnStyle: "blue",
                    scope: this,
                    handler: this.applyHandler
                }, {
                    cls: "syno-vc-button",
                    text: _T("common", "cancel"),
                    btnStyle: "grey",
                    scope: this,
                    handler: this.close
                }],
                listeners: {
                    scope: this,
                    afterrender: this.focusInputField
                }
            };
            this.callParent([Ext.apply(e, t)])
        },
        getFormPanel: function() {
            if (this.form) return this.form;
            var t = {
                cls: "password-form syno-vs2-form",
                items: [{
                    xtype: "syno_displayfield",
                    cls: "syno-vc-displayfield",
                    value: String.format(_VCT("controller", "renderer_password_desc"), this.player_title)
                }, {
                    xtype: "syno_textfield",
                    cls: "syno-vc-base-textfield",
                    textType: "password",
                    fieldLabel: _VCT("common", "password"),
                    name: "password",
                    maxlength: 50
                }]
            };
            return this.form = new SYNO.ux.FormPanel(t), this.form
        },
        getPasswordField: function() {
            return this.getFormPanel().getForm().findField("password")
        },
        focusInputField: function() {
            this.getPasswordField().focus(!1, 300)
        },
        applyHandler: function() {
            var t = this.getPasswordField().getValue();
            Ext.isString(t) && !Ext.isEmpty(t) ? this.setPassword(t) : this.focusInputField()
        },
        setPassword: function(t) {
            SYNO.API.Request({
                api: "SYNO.VideoStation2.Controller.Password",
                method: "set",
                version: 1,
                params: {
                    device_id: this.player_id,
                    password: t
                },
                scope: this,
                callback: function(t, e, i, n) {
                    if (t) this.correctCallback.defer(1), this.close();
                    else {
                        var o = e.code && 2002 === e.code ? _T("video_player", "title") : this.title;
                        this.getMsgBox().show({
                            title: o,
                            msg: SYNO.VideoController2.Util.getErrorString(e, "SYNO.VideoStation2.Controller.Password"),
                            buttons: Ext.MessageBox.OK
                        })
                    }
                }
            })
        }
    }), Ext.define("SYNO.VideoController2.PinCodeField", {
        extend: "Ext.BoxComponent",
        statics: {
            EVENT_CLICK: "click"
        },
        constructor: function(t) {
            var e = t.index || 0,
                i = {
                    autoEl: {
                        tag: "div",
                        cls: String.format("pin-code-field pin-{0} {1}", e, 0 === e ? "focus" : ""),
                        cn: [{
                            tag: "div",
                            cls: "star"
                        }]
                    },
                    listeners: {
                        afterrender: {
                            fn: function() {
                                this.getEl().on("mousedown", this.mouseDown, this)
                            },
                            scope: this,
                            single: !0
                        }
                    }
                };
            this.callParent([Ext.apply(i, t)]), this.index = e, this.digit = ""
        },
        setPinCode: function(t) {
            this.digit = t, this[Ext.isEmpty(t) ? "removeClass" : "addClass"]("entered")
        },
        focusField: function(t) {
            this[t ? "addClass" : "removeClass"]("focus")
        },
        mouseDown: function() {
            this.fireEvent(SYNO.VideoController2.PinCodeField.EVENT_CLICK, this.index)
        }
    }), Ext.define("SYNO.VideoController2.PinCodeDialog", {
        extend: "SYNO.VideoController2.Dialog",
        constructor: function(t) {
            this.controller = t.controller, this.ok_btn = new SYNO.ux.Button({
                cls: "syno-vc-button",
                text: _T("common", "ok"),
                btnStyle: "blue",
                scope: this,
                handler: this.applyHandler
            }), this._pin_code_wrong = t.code === SYNO.VideoController2.Constant.ERROR_CODE_PIN_CODE_WRONG;
            var e = {
                cls: "pin-code-dialog",
                title: _VCT("parental_control", "enter_pin"),
                layout: "fit",
                width: 540,
                height: 290,
                resizable: !1,
                items: [this.getFormPanel()],
                buttons: [this.ok_btn, {
                    cls: "syno-vc-button",
                    text: _T("common", "cancel"),
                    btnStyle: "grey",
                    scope: this,
                    handler: this.close
                }],
                listeners: {
                    scope: this,
                    afterrender: this.insertInvalidText,
                    beforeclose: this.onBeforeClose
                },
                keys: [{
                    key: SYNO.VideoController2.PinCodeKeyMapping.KEYS,
                    scope: this,
                    handler: this.onPinEntered
                }, {
                    key: Ext.EventObject.BACKSPACE,
                    scope: this,
                    handler: this.onBackspace
                }, {
                    key: Ext.EventObject.ENTER,
                    scope: this,
                    handler: this.applyHandler
                }, {
                    key: Ext.EventObject.ESC,
                    scope: this,
                    handler: this.close
                }]
            };
            this.callParent([Ext.apply(e, t)]), Ext.each(this.getPinItems(), function(t) {
                this.mon(t, SYNO.VideoController2.PinCodeField.EVENT_CLICK, this.focusPinField, this)
            }, this), this._index = 0, this._callback = t.callback, this._applyAction = !1
        },
        insertInvalidText: function() {
            this._pin_code_wrong && this.setStatusError({
                text: _VCT("parental_control", "wrong_pin")
            })
        },
        getPinItems: function() {
            return this._pin_item = this._pin_item || [0, 1, 2, 3].map(function(t) {
                return new SYNO.VideoController2.PinCodeField({
                    index: t
                })
            }, this), this._pin_item
        },
        getFormPanel: function() {
            if (this.form) return this.form;
            var t = {
                labelWidth: 0,
                cls: "password-form syno-vs2-form",
                items: [{
                    name: "desc",
                    xtype: "syno_displayfield",
                    cls: "pin-description",
                    value: _VCT("parental_control", "enter_pin_description")
                }].concat(this.getPinItems())
            };
            return this.form = new SYNO.ux.FormPanel(t), this.form
        },
        onPinEntered: function(t) {
            this._index < 4 && (this.getPinItems()[this._index].setPinCode(SYNO.VideoController2.PinCodeKeyMapping.getChar(t)), this.focusPinField(this._index + 1))
        },
        onBackspace: function() {
            this._index <= 0 || (this.focusPinField(this._index - 1), this.getPinItems()[this._index].setPinCode(""))
        },
        focusPinField: function(t) {
            Ext.each(this.getPinItems(), function(e) {
                e.focusField(e.index === t)
            }, this), this._index = t
        },
        applyHandler: function() {
            var t = this.getPinItems().map(function(t) {
                return t.digit
            }).join("");
            Ext.isString(t) && 4 === t.length && Ext.isNumber(parseInt(t, 10)) && (this._callback.resolve(t), this._applyAction = !0, this.close())
        },
        onBeforeClose: function() {
            this._applyAction || this._callback.reject()
        }
    }), Ext.define("SYNO.VideoController2.PinCodeKeyMapping", {
        extend: "Ext.util.Observable",
        statics: {
            KEYS: [Ext.EventObject.ZERO, Ext.EventObject.ONE, Ext.EventObject.TWO, Ext.EventObject.THREE, Ext.EventObject.FOUR, Ext.EventObject.FIVE, Ext.EventObject.SIX, Ext.EventObject.SEVEN, Ext.EventObject.EIGHT, Ext.EventObject.NINE, Ext.EventObject.NUM_ZERO, Ext.EventObject.NUM_ONE, Ext.EventObject.NUM_TWO, Ext.EventObject.NUM_THREE, Ext.EventObject.NUM_FOUR, Ext.EventObject.NUM_FIVE, Ext.EventObject.NUM_SIX, Ext.EventObject.NUM_SEVEN, Ext.EventObject.NUM_EIGHT, Ext.EventObject.NUM_NINE],
            instance: null,
            get: function() {
                return Ext.isObject(SYNO.VideoController2.PinCodeKeyMapping.instance) || (SYNO.VideoController2.PinCodeKeyMapping.instance = new SYNO.VideoController2.PinCodeKeyMapping), SYNO.VideoController2.PinCodeKeyMapping.instance
            },
            getChar: function(t) {
                return SYNO.VideoController2.PinCodeKeyMapping.get().getChar(t)
            }
        },
        constructor: function() {
            this.callParent(arguments), this._mapping = {}, Ext.each(SYNO.VideoController2.PinCodeKeyMapping.KEYS, function(t, e) {
                this._mapping[t] = String.fromCharCode("0".charCodeAt(0) + parseInt(e % 10, 10))
            }, this)
        },
        getChar: function(t) {
            try {
                return this._mapping[t]
            } catch (t) {
                return ""
            }
        }
    }), Ext.define("SYNO.VideoController2.PinCodeManager", {
        extend: "Ext.util.Observable",
        statics: {
            RESET_TIMEOUT: 9e5,
            instance: null,
            get: function(t) {
                return Ext.isObject(SYNO.VideoController2.PinCodeManager.instance) || (SYNO.VideoController2.PinCodeManager.instance = new SYNO.VideoController2.PinCodeManager), Ext.isObject(t) && (SYNO.VideoController2.PinCodeManager.instance.app_win = t), SYNO.VideoController2.PinCodeManager.instance
            }
        },
        _pin: "",
        constructor: function(t) {
            this.callParent([t])
        },
        promptRequestPinCode: function(t) {
            return new Promise(function(e, i) {
                new SYNO.VideoController2.PinCodeDialog({
                    owner: this.app_win,
                    controller: this.app_win.controller,
                    code: t,
                    callback: {
                        resolve: e,
                        reject: i
                    }
                }).show()
            }.bind(this))
        },
        requestPinCode: function(t) {
            return this.promptRequestPinCode(t).then(function(t) {
                return this._pin = t, this.getResetTimer().delay(SYNO.VideoController2.PinCodeManager.RESET_TIMEOUT), this._pin
            }.bind(this))
        },
        getPinCode: function() {
            return this._pin
        },
        clearPinCode: function() {
            this._pin = ""
        },
        getResetTimer: function() {
            return this._reset_timer = this._reset_timer || new Ext.util.DelayedTask(function() {
                this._pin = ""
            }, this), this._reset_timer
        }
    }), Ext.define("SYNO.VideoController2.PlayerStore", {
        extend: "SYNO.API.Store",
        PlayerRecord: Ext.data.Record.create([{
            name: "id",
            type: "string"
        }, {
            name: "type",
            type: "string"
        }, {
            name: "title",
            type: "string"
        }, {
            name: "volume_adjustable",
            type: "boolean"
        }, {
            name: "password_protected",
            type: "boolean"
        }, {
            name: "seekable",
            type: "boolean"
        }]),
        constructor: function(t) {
            var e = {
                api: "SYNO.VideoStation2.Controller.Device",
                method: "list",
                version: 1,
                baseParams: {
                    limit: SYNO.VideoController2.Constant.UNLIMIT
                },
                reader: new Ext.data.JsonReader({
                    root: "device"
                }, this.PlayerRecord)
            };
            this.callParent([Ext.apply(e, t)])
        }
    }), Ext.define("SYNO.VideoController2.RemotePlayer", {
        extend: "SYNO.VideoController2.Player",
        PlaybackAPI: {
            api: "SYNO.VideoStation2.Controller.Playback",
            version: 1
        },
        VolumeAPI: {
            api: "SYNO.VideoStation2.Controller.Volume",
            version: 1
        },
        constructor: function(t) {
            var e = {
                name: "Remote",
                pluginInit: !0,
                initPlaying: !1,
                state: SYNO.VideoController2.Util.STATE.STOPPED,
                volume: 50,
                volume_adjustable: !0,
                seekable: !0,
                first_start_playing: !1
            };
            this.callParent([Ext.apply(e, t)])
        },
        checkResumed: function() {
            return !0
        },
        ableToPlayRaw: function(t, e) {
            if (this.type !== SYNO.VideoController2.Util.PLAYERTYPE_AIRPLAY) return !0;
            if (e.width > 1920 || e.height > 1080) return !1;
            if (!SYNO.VideoController2.Util.isMP4Container(t.container_type)) return !1;
            var i = t.video_codec;
            if ("mpeg4" !== i && "h264" !== i && "mjpeg" !== i) return !1;
            var n = t.audio_codec;
            return -1 !== n.indexOf("aac") || -1 !== n.indexOf("ac3") || -1 !== n.indexOf("mp3")
        },
        ableToRemux: function(t, e) {
            if (!this.controller.supportRemux() || this.type !== SYNO.VideoController2.Util.PLAYERTYPE_AIRPLAY) return !1;
            if (e.width > 1920 || e.height > 1080) return !1;
            var i = t.container_type;
            return "h264" === t.video_codec && (SYNO.VideoController2.Util.isMP4Container(i) || "matroska,webm" === i)
        },
        getState: function() {
            return this.state
        },
        getDuration: function() {
            return this.duration
        },
        getPosition: function() {
            return this.position
        },
        getMute: function() {
            return !1
        },
        getVolume: function() {
            return this.volume
        },
        getClientID: function() {
            return this.client_id
        },
        generateClientID: function() {
            return this.client_id = SYNO.Encryption.Base64.hex2b64(SYNO.VideoController2.Util.toHex(this.title)) + (new Date).format("U"), this.client_id
        },
        sendPlaybackAPI: function(t, e) {
            return SYNO.VideoController2.WebAPI.send({
                api: "SYNO.VideoStation2.Controller.Playback",
                method: t,
                version: 2,
                params: e
            })
        },
        sendVolumeAPI: function(t, e) {
            return SYNO.VideoController2.WebAPI.send({
                api: "SYNO.VideoStation2.Controller.Volume",
                method: t,
                version: 1,
                params: e
            })
        },
        play: function() {
            var t = {
                device_id: this.id,
                file_id: this.file_id,
                client_id: this.generateClientID(),
                playback_target: "file_id",
                pin: this.controller._pin_manager.getPinCode()
            };
            Ext.isNumber(this.start_position) && (t.position = this.start_position, this.start_position = null), t.subtitle = {}, Ext.isEmpty(this.subtitle_id) || (t.subtitle.id = this.subtitle_id), Ext.isEmpty(this.subtitle_codepage) || (t.subtitle.codepage = this.subtitle_codepage), Ext.isEmpty(this.audio_id) || (t.audio_track = this.audio_id), Ext.isEmpty(this.profile) || (t.profile = this.profile), this.state = SYNO.VideoController2.Util.STATE.BUFFERING, this.stateHandler(), this.sendPlay(t)
        },
        sendPlay: function(t) {
            return this.sendPlaybackAPI("play", t).then(this.startPolling.bind(this)).catch(function(t) {
                this.handlePinCodeError(t[0], t[1], t[2]).then(function(t) {
                    return this.sendPlay(SYNO.Util.copy(t))
                }.bind(this)).catch(this.showError.bind(this))
            }.bind(this))
        },
        sendStop: function() {
            SYNO.VideoController2.WebAPI.keepaliveFetch("SYNO.VideoStation2.Controller.Playback", "stop", 2, {
                device_id: this.id
            }).catch(this.handleError.bind(this))
        },
        pause: function() {
            this.sendPlaybackAPI("pause", {
                device_id: this.id
            }).catch(this.handleError.bind(this))
        },
        resume: function() {
            this.pause()
        },
        stop: function() {
            this.task_runner ? this.sendStop() : this.notifyClear()
        },
        seek: function(t) {
            if (this.seekable) {
                var e = {
                    device_id: this.id,
                    position: parseInt(t.toFixed(0), 10)
                };
                this.sendPlaybackAPI("seek", e).catch(this.handleError.bind(this))
            }
        },
        setVolume: function(t) {
            if (this.volume_adjustable) {
                var e = {
                    device_id: this.id,
                    volume: t
                };
                this.sendVolumeAPI("set", e).catch(this.handleError.bind(this))
            }
        },
        clear: function() {
            this.stopPolling(), this.sendStop(), this.notifyClear()
        },
        StateMap: {
            STOPPED: SYNO.VideoController2.Util.STATE.STOPPED,
            PLAYING: SYNO.VideoController2.Util.STATE.PLAYING,
            PAUSED: SYNO.VideoController2.Util.STATE.PAUSED,
            TRANSITIONING: SYNO.VideoController2.Util.STATE.BUFFERING,
            ERROR: SYNO.VideoController2.Util.STATE.ERROR
        },
        updateStatus: function(t, e, i, n) {
            if (!t) return void this.setStatusError();
            this.position = e.position, this.state = this.StateMap[e.state] || SYNO.VideoController2.Util.STATE.ERROR, this.client_id !== e.client_id && (this.state = SYNO.VideoController2.Util.STATE.STOPPED), this.durationHandler(e.duration), this.positionHandler(this.position), this.state === SYNO.VideoController2.Util.STATE.ERROR ? this.setStatusError() : this.state !== SYNO.VideoController2.Util.STATE.PLAYING || this.first_start_playing ? this.stateHandler() : (this.playerReadyHandler(), this.first_start_playing = !0, this.stateHandler())
        },
        setStatusError: function() {
            this.state = SYNO.VideoController2.Util.STATE.ERROR, this.stopPolling(), this.stateHandler(_VCT("controller", "error_state"))
        },
        updateVolume: function(t, e, i, n) {
            this.volume = e.volume, this.volumeHandler()
        },
        startPolling: function() {
            this.stopPolling(), this.task_runner = new SYNO.SDS.TaskRunner, this.polling_status = this.task_runner.createWebAPITask({
                id: "SYNOVideoControllerPollingStatus",
                interval: 1e3,
                api: "SYNO.VideoStation2.Controller.Playback",
                method: "status",
                version: 1,
                params: {
                    device_id: this.id
                },
                scope: this,
                callback: this.updateStatus
            }), this.polling_status.start(!0), this.volume_adjustable && (this.polling_volume = this.task_runner.createWebAPITask({
                id: "SYNOVideoControllerPollingVolume",
                interval: 1e3,
                api: "SYNO.VideoStation2.Controller.Volume",
                method: "get",
                version: 1,
                params: {
                    device_id: this.id
                },
                scope: this,
                callback: this.updateVolume
            }), this.polling_volume.start(!0))
        },
        stopPolling: function() {
            this.task_runner && (this.task_runner.destroy(), this.task_runner = null, this.polling_status = null, this.polling_volume = null, this.first_start_playing = !1)
        },
        handlePinCodeError: function(t, e, i) {
            var n = t.code,
                o = i.params.api;
            return SYNO.VideoController2.Constant.ERROR_CODE_PIN_CODE_REQUIRED === n || SYNO.VideoController2.Constant.ERROR_CODE_PIN_CODE_WRONG === n ? this.controller.pinCodeErrorHandler(t, e, o) : Promise.reject(this.errorString(t, o))
        },
        errorString: function(t, e) {
            return String.format(SYNO.VideoController2.Util.getErrorString(t, e), this.controller.player_info.title)
        },
        handleError: function(t) {
            var e = t[0],
                i = t[2];
            this.stopPolling(), this.showError(this.errorString(e, i.params.api))
        },
        showError: function(t) {
            this.controller.onErrorOccur(t)
        }
    }), Ext.define("SYNO.VideoController2.SubtitleDialog", {
        extend: "SYNO.VideoController2.Dialog",
        constructor: function(t) {
            this.unique_key = t.unique_key;
            var e = {
                cls: "search-subtitle-dialog",
                title: _VCT("controller", "search_subtitle"),
                width: 720,
                height: 380,
                layout: "fit",
                items: [this.getGridPanel()],
                buttons: [{
                    cls: "syno-vc-button",
                    text: _T("common", "cancel"),
                    btnStyle: "grey",
                    itemId: "cancel",
                    scope: this,
                    handler: this.close
                }, {
                    cls: "syno-vc-button",
                    text: _T("common", "ok"),
                    btnStyle: "blue",
                    disabled: !0,
                    itemId: "ok",
                    scope: this,
                    handler: this.applyHandler
                }],
                listeners: {
                    scope: this,
                    beforeclose: this.onBeforeClose
                }
            };
            this.callParent([Ext.apply(e, t)])
        },
        getGridPanel: function() {
            return {
                cls: "syno-vc-gridpanel",
                xtype: "syno_gridpanel",
                itemId: "grid",
                stripeRows: !0,
                loadMask: {
                    msg: _VCT("search", "searching")
                },
                viewConfig: {
                    autoFill: !0,
                    forceFit: !0,
                    emptyText: _T("search", "no_search_result")
                },
                selModel: this.getSelectionModel(),
                colModel: new Ext.grid.ColumnModel({
                    columns: [this.getSelectionModel(), {
                        header: _VCT("language", "title"),
                        dataIndex: "language",
                        renderer: function(t, e, i) {
                            return Ext.util.Format.htmlEncode(t)
                        }
                    }, {
                        header: _VCT("file", "file_name"),
                        dataIndex: "filename",
                        renderer: function(t, e, i) {
                            return Ext.util.Format.htmlEncode(t)
                        }
                    }, {
                        header: _VCT("video_info", "source"),
                        dataIndex: "plugin_title",
                        renderer: function(t, e, i) {
                            return Ext.util.Format.htmlEncode(t)
                        }
                    }]
                }),
                enableHdMenu: !1,
                enableColumnMove: !1,
                store: this.getStore()
            }
        },
        getStore: function() {
            if (this.gridStore) return this.gridStore;
            var t = SYNO.VideoController2.Util.getIDorPathParam(this.unique_key);
            return this.gridStore = new SYNO.API.JsonStore({
                api: "SYNO.VideoStation2.Subtitle",
                method: "search",
                version: 3,
                appWindow: !1,
                autoLoad: !0,
                baseParams: t,
                root: "subtitle",
                fields: ["id", "language", "language_id", "plugin_id", "plugin_title", "filename", "downloaded", "subtitle_id"]
            }), this.gridStore
        },
        getSelectionModel: function() {
            return this.selection_model = this.selection_model || new Ext.grid.CheckboxSelectionModel({
                width: 34,
                checkOnly: !0,
                listeners: {
                    scope: this,
                    selectionchange: function() {
                        this.setOkDisabled(!this.isGridHasSelection()), this.getRecordSelections().length === this.gridStore.getTotalCount() ? Ext.fly(this.selection_model.grid.view.innerHd).child(".x-grid3-hd-checker").addClass("x-grid3-hd-checker-on") : Ext.fly(this.selection_model.grid.view.innerHd).child(".x-grid3-hd-checker").removeClass("x-grid3-hd-checker-on")
                    }
                }
            }), this.selection_model
        },
        isGridHasSelection: function() {
            return this.getComponent("grid").getSelectionModel().hasSelection()
        },
        setOkDisabled: function(t) {
            this.getFooterToolbar().getComponent("ok").setDisabled(t)
        },
        getRecordSelections: function() {
            return this.getComponent("grid").getSelectionModel().getSelections()
        },
        downloadSubtitle: function() {
            var t = this.getRecordSelections();
            if (0 !== t.length) {
                this.setStatusBusy();
                var e = t.map(function(t) {
                    var e;
                    return e = SYNO.VideoController2.Util.getIDorPathParam(this.unique_key), e.plugin_id = t.get("plugin_id"), e.download_id = t.get("id"), {
                        api: "SYNO.VideoStation2.Subtitle",
                        method: "download",
                        version: 3,
                        params: e,
                        downloaded: t.get("downloaded"),
                        id: t.get("subtitle_id")
                    }
                }, this);
                SYNO.VideoController2.WebAPI.all(e.map(function(t) {
                    return t.downloaded ? Promise.resolve(t) : SYNO.VideoController2.WebAPI.send(t)
                }), function(t) {
                    this.clearStatusBusy();
                    var e = t.pop().id;
                    this.setDownloadedSubtitle(e)
                }.bind(this), function(t) {
                    this.clearStatusBusy();
                    var e = t.map(function(t) {
                        return SYNO.VideoController2.Util.getErrorString(t)
                    });
                    e.push(_VCT("controller", "download_subtitle_fail")), this.setStatusError({
                        text: e[0]
                    })
                }.bind(this))
            }
        },
        setDownloadedSubtitle: function(t, e) {
            this.findAppWindow().getController().setDownloadedSubtitle(t, e), this.close()
        },
        applyHandler: function() {
            this.downloadSubtitle()
        },
        onBeforeClose: function() {
            this.findAppWindow().getController().setDownloadedSubtitle()
        }
    }), Ext.define("SYNO.VideoController2.SubtitleManager", {
        extend: "Ext.Component",
        constructor: function(t) {
            this.addEvents({
                subtitleready: !0,
                discoverready: !0
            });
            var e = Ext.apply({
                ms_base: 1e3,
                subtitle: {}
            }, t);
            Ext.apply(this, e), this.callParent([e])
        },
        isSubtitleReady: function(t, e, i) {
            return Ext.isDefined(this.subtitle[t]) && Ext.isDefined(this.subtitle[t][e]) && Ext.isString(this.subtitle[t][e][i])
        },
        getSubtitle: function(t, e, i) {
            return this.isSubtitleReady(t, e, i) ? this.subtitle[t][e][i] : ""
        },
        putSubtitle: function(t, e, i, n) {
            Ext.isDefined(this.subtitle[t]) || (this.subtitle[t] = {}), Ext.isDefined(this.subtitle[t][e]) || (this.subtitle[t][e] = {}), this.subtitle[t][e][n] = i
        },
        requestSubtitle: function(t, e, i, n) {
            if (this.isSubtitleReady(t, e, n)) return void this.fireEvent("subtitleready", t, e, n);
            i && this.sendRequest(t, e, !0, n), this.sendRequest(t, e, !1, n)
        },
        sendRequest: function(t, e, i, n) {
            var o = SYNO.VideoController2.Util.getIDorPathParam(t);
            Ext.apply(o, {
                subtitle_codepage: n,
                subtitle_id: e,
                preview: i,
                keep_srt_tag: SYNO.VideoController2.SubtitlePreference.get().isNoSubtitlePreference(),
                remove_special_char: !1
            });
            var r = {
                timeout: 36e4,
                params: o,
                scope: this,
                callback: function(i, o, r, l) {
                    if (200 === o.status) {
                        var s = o.responseText;
                        this.putSubtitle(t, e, s, n), this.fireEvent("subtitleready", t, e, n)
                    }
                }
            };
            Ext.apply(r, SYNO.VideoController2.SharingHelper.getAPI("Subtitle")), SYNO.VideoController2.Util.applySharingID(r.params), SYNO.API.Request(r)
        },
        getDiscoverRequest: function(t) {
            SYNO.VideoController2.Util.isPublicSharing() || SYNO.API.Request({
                api: "SYNO.VideoStation2.Subtitle",
                method: "discover",
                version: 3,
                params: {
                    id: t,
                    keep_srt_tag: SYNO.VideoController2.SubtitlePreference.get().isNoSubtitlePreference(),
                    remove_special_char: !1
                },
                scope: this,
                callback: function(e, i, n, o) {
                    var r = 200 === i.status;
                    if (r) {
                        var l = i.responseText;
                        this.putSubtitle(t, SYNO.VideoController2.Util.SUBTITLE_DISCOVER, l, "auto")
                    }
                    this.fireEvent("discoverready", r)
                }
            })
        },
        isExternal: function(t) {
            return "discover" !== t && !Ext.isNumber(parseInt(t, 10))
        },
        isOffsetNotSupported: function(t, e) {
            return !this.isExternal(t) && !Ext.isNumber(parseInt(e, 10))
        },
        getOffset: function(t, e) {
            if (!SYNO.VideoController2.Util.isPublicSharing() && !this.isOffsetNotSupported(e, t)) {
                var i = {
                    subtitle_id: e
                };
                this.isExternal(e) || Ext.apply(i, {
                    file_id: t
                }), SYNO.API.Request({
                    api: "SYNO.VideoStation2.Subtitle",
                    method: "get_offset",
                    version: 2,
                    params: i,
                    scope: this,
                    callback: function(t, e, i, n) {
                        t && this.fireEvent("getoffsetsuccess", e.offset / this.ms_base)
                    }
                })
            }
        },
        setOffset: function(t, e, i, n) {
            if (SYNO.VideoController2.Util.isPublicSharing() || this.isOffsetNotSupported(e, t)) return void SYNO.VideoController2.Util.tryCallback(n);
            var o = {
                subtitle_id: e,
                offset: i * this.ms_base
            };
            this.isExternal(e) || Ext.apply(o, {
                file_id: t
            }), SYNO.API.Request({
                api: "SYNO.VideoStation2.Subtitle",
                method: "set_offset",
                version: 2,
                params: o,
                scope: this,
                callback: function(t, e, i, o) {
                    SYNO.VideoController2.Util.tryCallback(n)
                }
            })
        }
    }), Ext.define("SYNO.VideoController2.SubtitleParser", {
        extend: "Ext.util.Observable",
        subtitles: null,
        destroy: function() {
            delete this.subtitles
        },
        parseSeconds: function(t) {
            if (t) {
                var e = 0,
                    i = t.split(":");
                if (!(i.length > 3)) {
                    for (var n = 0; n < i.length; ++n) e = 60 * e + parseFloat(i[n].replace(",", "."));
                    return e
                }
            }
        },
        parseSrt: function(t) {
            var e = t.replace(/\r\n|\r/g, "\n").trim(),
                i = e.split("\n\n");
            this.clear();
            for (var n = 0; n < i.length; ++n) {
                for (var o = [], r = i[n].split("\n"), l = 0; l < r.length; l++) "" !== r[l] && o.push(r[l]);
                if (!(o.length < 3)) {
                    o.shift();
                    var s = o.shift().split(" --\x3e ");
                    this.subtitles.push({
                        from: this.parseSeconds(s[0]),
                        to: this.parseSeconds(s[1]),
                        text: o.join("<br/>")
                    })
                }
            }
            this.subtitles.sort(function(t, e) {
                return t.from < e.from ? -1 : 1
            })
        },
        clear: function() {
            this.subtitles = []
        },
        getText: function(t) {
            var e = this.subtitles,
                i = [];
            if (!e) return "";
            for (var n = 0; n < e.length; ++n) {
                var o = e[n];
                if (t < o.from) break;
                o.from <= t && t <= o.to && i.push(o.text)
            }
            return i.join("<br/>")
        }
    }), Ext.define("SYNO.VideoController2.TimeText", {
        extend: "Ext.Toolbar.TextItem",
        constructor: function(t) {
            var e = {
                text: "00:00"
            };
            this.callParent([Ext.apply(e, t)])
        },
        formatTime: function(t) {
            t = parseInt(Math.round(t), 10);
            var e = parseInt(t / 3600, 10),
                i = parseInt(t % 3600 / 60, 10),
                n = t % 60;
            return (e > 0 ? e + ":" : "") + String.leftPad(i, 2, "0") + ":" + String.leftPad(n, 2, "0")
        },
        updateView: function(t) {
            !Ext.isNumber(t) || 0 >= t ? this.setText("00:00") : this.setText(this.formatTime(t))
        }
    }), Ext.define("SYNO.SDS.VideoController2.Radio", {
        extend: "SYNO.ux.Radio",
        xtype: "syno_vc_radio",
        checkIconCls: "syno-vc-radio syno-ux-radio-icon",
        constructor: function(t) {
            this.callParent(arguments)
        }
    }), Ext.define("SYNO.SDS.VideoController2.RadioGroup", {
        extend: "SYNO.ux.RadioGroup",
        xtype: "syno_vc_radiogroup",
        defaultType: "syno_vc_radio",
        constructor: function(t) {
            this.callParent(arguments)
        }
    }), Ext.define("SYNO.VideoController2.Button", {
        extend: "SYNO.ux.Button",
        constructor: function(t) {
            var e = {
                cls: "vc-button",
                listeners: {
                    scope: this,
                    afterrender: function(t) {
                        SYNO.VideoController2.Util.isMobile() && !Ext.isChrome && t.getEl().on("touchstart", this.clickHandler.bind(this))
                    },
                    click: function() {
                        SYNO.VideoController2.Util.isMobile() && !Ext.isChrome || this.clickHandler()
                    }
                }
            };
            this.callParent([Ext.apply(e, t)])
        },
        getController: function() {
            return this.module.getController()
        },
        clickHandler: Ext.emptyFn
    }), Ext.define("SYNO.VideoController2.MenuButton", {
        extend: "SYNO.VideoController2.Button",
        constructor: function(t) {
            var e = {
                menu: this.createMenu(),
                menuAlign: "br-tr"
            };
            this.callParent([Ext.apply(e, t)])
        },
        createMenu: Ext.emptyFn,
        getMenuClass: function() {
            return ""
        }
    }), Ext.define("SYNO.VideoController2.Menu", {
        extend: "Ext.menu.Menu",
        constructor: function(t) {
            var e = {
                cls: "syno-vc-menu",
                listeners: {
                    scope: this,
                    beforerender: function() {
                        this.orig_useShims = Ext.useShims, Ext.useShims = !0
                    },
                    afterrender: function() {
                        Ext.useShims = this.orig_useShims, this.keyNav.disable()
                    },
                    show: Ext.isFunction(t.onShow) ? t.onShow : Ext.emptyFn
                }
            };
            this.callParent([Ext.apply(e, t)])
        }
    }), Ext.define("SYNO.VideoController2.Slider", {
        extend: "Ext.slider.SingleSlider",
        constructor: function(t) {
            var e = {
                animate: !1,
                increment: 1,
                value: 0,
                listeners: {
                    scope: this,
                    change: this.onChange,
                    changecomplete: this.onChangeComplete,
                    afterrender: this.onAfterRender
                }
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("vc-slider")
        },
        onChange: Ext.emptyFn,
        onChangeComplete: Ext.emptyFn,
        onAfterRender: Ext.emptyFn,
        isDragging: function() {
            return !!this.isDestroyed || this.thumbs[0].dragging
        }
    }), Ext.define("SYNO.VideoController2.ItemMenu", {
        extend: "SYNO.VideoController2.Menu",
        constructor: function(t) {
            var e = {
                defaultOffsets: [0, -11]
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("item-menu")
        },
        addItemGeneral: function(t, e, i, n, o) {
            var r = Ext.util.Format.ellipsis(e, 40, !1),
                l = new Ext.menu.Item({
                    item_id: t,
                    text: r,
                    cls: i,
                    group: n || "",
                    scope: this,
                    handler: o,
                    listeners: {
                        render: function() {
                            this.getEl().dom.qtip = Ext.util.Format.htmlEncode(e)
                        }
                    }
                });
            this.addItem(l)
        },
        addTitle: function(t, e) {
            Ext.isString(t) && this.addItemGeneral(Ext.id(), t, "title", e, Ext.emptyFn)
        },
        addOneItem: function(t, e, i, n, o) {
            if (Ext.isDefined(t) && Ext.isString(e) && Ext.isFunction(i)) {
                var r = function() {
                    this.setItemSelected(t, o), i()
                };
                this.addItemGeneral(t, e, !0 === n ? "selected" : "", o, r)
            }
        },
        setItemSelected: function(t, e) {
            this.items && Ext.isDefined(t) && this.items.each(function(i) {
                var n = Ext.get(i.getId());
                Ext.isDefined(e) && i.group !== e || (n.removeClass("selected"), n[i.item_id === t ? "addClass" : "removeClass"]("selected"))
            })
        },
        removeGroup: function(t) {
            Ext.isObject(this.items) && this.items.each(function(e) {
                e.group === t && this.remove(e)
            }, this)
        }
    }), Ext.define("SYNO.VideoController2.MenuDataView", {
        extend: "SYNO.ux.FleXcroll.DataView",
        constructor: function(t) {
            var e = {
                singleSelect: !0,
                itemSelector: "div.item",
                selectedClass: "x-view-selected",
                overClass: "x-view-over",
                store: this.getStore(),
                tpl: this.getTpl(),
                listeners: {
                    scope: this,
                    beforeclick: function(t, e, i, n) {
                        var o = t.getRecord(i);
                        return !o.get("disabled") && (!1 === o.get("able_to_be_selected") ? (o.get("handler")(), !1) : void 0)
                    },
                    click: function(t, e, i, n) {
                        t.getRecord(i).get("handler")()
                    },
                    selectionchange: function(t, e, i) {
                        0 === e.length && this.setItemSelected(this.getSelectedItem().id)
                    },
                    afterrender: function() {
                        this.setItemSelected(this.default_id)
                    }
                }
            };
            this.callParent([Ext.apply(e, t)])
        },
        getStore: function() {
            return Ext.isDefined(this.store) || (this.store = new Ext.data.JsonStore({
                fields: ["id", "title", "handler", "able_to_be_selected", "disabled", "visible"]
            })), this.store
        },
        getTpl: function() {
            return new Ext.XTemplate('<tpl for=".">', '<div class="item sds-ellipsis {[this.getDisabledClass(values.disabled)]} {[this.getHiddenClass(values.visible)]}" ext:qtip="{[this.doubleEncode(values.title)]}">', '<span class="menu-tick">&nbsp;</span>', "{title:htmlEncode}", "</div>", "</tpl>", {
                doubleEncode: function(t) {
                    return Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(t))
                },
                getDisabledClass: function(t) {
                    return t ? "x-item-disabled" : ""
                },
                getHiddenClass: function(t) {
                    return !0 === t ? "" : "x-hide-display"
                }
            })
        },
        getSelectedItem: function() {
            return this.selected_item
        },
        setItemSelected: function(t) {
            if (this.store) {
                var e = this.store.getAt(0);
                return this.store.each(function(i) {
                    if (i.id === t) return e = i, !1
                }), this.select(e), this.selected_item = e, e
            }
        },
        setInitItem: function(t, e) {
            this.default_id = t;
            var i = this.setItemSelected(t);
            e && i.data.handler()
        }
    }), Ext.define("SYNO.VideoController2.MenuPanel", {
        extend: "SYNO.ux.Panel",
        constructor: function(t) {
            this.module = t.module, this.list = [];
            var e = {
                header: !0,
                autoFlexcroll: !0,
                layout: "fit",
                items: [this.getDataview()]
            };
            this.callParent([Ext.apply(e, t)])
        },
        getDataview: function() {
            return Ext.isDefined(this.dataview) || (this.dataview = new SYNO.VideoController2.MenuDataView), this.dataview
        },
        getListLength: function() {
            return this.list.length
        },
        setDefault: function(t) {
            this.getDataview().default_id = t
        },
        setItemSelected: function(t) {
            this.getDataview().setItemSelected(t)
        },
        setInitItem: function(t, e) {
            this.getDataview().setInitItem(t, e || !0)
        },
        setItemVisible: function(t, e) {
            for (var i = 0, n = this.list.length; i < n; i++) this.list[i].id === t && (this.list[i].visible = e);
            this.loadItems()
        },
        setItemDisable: function(t, e) {
            for (var i = 0, n = this.list.length; i < n; i++) this.list[i].id === t && (this.list[i].disabled = e);
            this.loadItems()
        },
        addItem: function(t, e, i, n, o, r) {
            this.list.push({
                id: t,
                title: e,
                handler: i,
                able_to_be_selected: n,
                disabled: o || !1,
                visible: !Ext.isDefined(r) || r
            })
        },
        loadItems: function() {
            this.isDestroyed || this.getDataview().store.loadData(this.list)
        },
        removeItems: function() {
            this.isDestroyed || (this.list = [], this.getDataview().store.removeAll())
        }
    }), Ext.define("SYNO.VideoController2.FieldSet", {
        extend: "SYNO.ux.FieldSet",
        xtype: "syno_vc_fieldset",
        constructor: function(t) {
            this.callParent(arguments), this.addClass("syno-vc-fieldset")
        }
    }), Ext.define("SYNO.VideoController2.ComboBox", {
        statics: {
            CLASS_MENU_EXPANDED: "menu-expanded"
        },
        extend: "SYNO.ux.ComboBox",
        xtype: "syno_vc_combobox",
        listClass: "syno-vc-combobox-list",
        constructor: function() {
            this.callParent(arguments), this.addClass("syno-vc-combobox"), this.mon(this, "expand", this.addExpandedClass, this), this.mon(this, "collapse", this.removeExpandedClass, this)
        },
        addExpandedClass: function() {
            this.addClass(SYNO.VideoController2.ComboBox.CLASS_MENU_EXPANDED)
        },
        removeExpandedClass: function() {
            this.removeClass(SYNO.VideoController2.ComboBox.CLASS_MENU_EXPANDED)
        },
        onDestroy: function() {
            this.mun(this, "expand", this.addExpandedClass, this), this.mun(this, "collapse", this.removeExpandedClass, this), this.callParent(arguments)
        }
    }), Ext.define("SYNO.VideoController2.ColorField", {
        extend: "SYNO.ux.ColorField",
        xtype: "syno_vc_colorfield",
        constructor: function() {
            this.callParent(arguments), this.addClass("syno-vc-colorfield")
        }
    }), Ext.define("SYNO.VideoController2.SubtitlePreferenceDialog", {
        extend: "SYNO.VideoController2.Dialog",
        constructor: function(t) {
            this.controller = t.controller;
            var e = {
                cls: "subtitle-preference-dialog",
                title: _VCT("controller", "subtitle_preference"),
                layout: "fit",
                width: 460,
                height: 520,
                items: [this.getFormPanel({
                    is_remote_mode: this.controller.isRemoteMode(),
                    is_chromecast: this.controller.isChromecast()
                })],
                useStatusBar: !1,
                buttonAlign: "left",
                fbar: new SYNO.ux.Toolbar({
                    cls: "x-statusbar",
                    items: [{
                        cls: "syno-vc-button",
                        text: _T("common", "reset"),
                        btnStyle: "red",
                        itemId: "reset",
                        scope: this,
                        handler: this.resetHandler
                    }, "->", {
                        cls: "syno-vc-button",
                        text: _T("common", "cancel"),
                        btnStyle: "grey",
                        itemId: "cancel",
                        scope: this,
                        handler: this.close
                    }, {
                        cls: "syno-vc-button",
                        text: _T("common", "ok"),
                        btnStyle: "blue",
                        itemId: "ok",
                        scope: this,
                        handler: this.applyHandler
                    }]
                }),
                listeners: {
                    scope: this,
                    beforeclose: this.onBeforeClose
                }
            };
            this.callParent([Ext.apply(e, t)])
        },
        isValid: function() {
            return this.getFormPanel().getForm().isValid()
        },
        onShow: function() {
            this.callParent(arguments);
            var t = SYNO.VideoController2.SubtitlePreference.get().getSettings();
            this.getFormPanel().getForm().setValues(t)
        },
        getFormPanel: function(t) {
            return this.form_panel = this.form_panel || new SYNO.VideoController2.Preference.FormPanel(t), this.form_panel
        },
        resetHandler: function() {
            SYNO.VideoController2.SubtitlePreference.get().loadDefault();
            var t = SYNO.VideoController2.SubtitlePreference.get().getSettings();
            this.getFormPanel().getForm().setValues(t)
        },
        applyHandler: function() {
            if (!this.isValid()) return void this.getMsgBox().alert(_VCT("controller", "subtitle_preference"), _T("error", "error_bad_field"));
            var t = this.getFormPanel().getForm().getValues();
            SYNO.VideoController2.SubtitlePreference.get().setSettings(t), SYNO.VideoController2.SubtitlePreference.get().saveUserSetting(), this.close()
        },
        onBeforeClose: function() {
            SYNO.VideoController2.SubtitlePreference.get().rejectChanges()
        }
    }), Ext.define("SYNO.VideoController2.Preference.FormPanel", {
        extend: "SYNO.ux.FormPanel",
        constructor: function(t) {
            var e = {
                cls: "syno-vs2-form",
                labelWidth: 150,
                items: [this.getSubtitleFieldSet(t), this.getBackgroundFieldSet(t)]
            };
            this.callParent([Ext.apply(e, t)])
        },
        getSubtitleFieldSet: function(t) {
            return this.subtitle_fieldset = this.subtitle_fieldset || new SYNO.VideoController2.Preference.SubtitleFieldSet(t), this.subtitle_fieldset
        },
        getBackgroundFieldSet: function(t) {
            return this.background_fieldset = this.background_fieldset || new SYNO.VideoController2.Preference.BackgroundFieldSet(t), this.background_fieldset
        }
    }), Ext.define("SYNO.VideoController2.Preference.SubtitleFieldSet", {
        extend: "SYNO.VideoController2.FieldSet",
        constructor: function(t) {
            var e = {
                    fieldLabel: _VCT("options", "font_family"),
                    name: "subtitle_font",
                    values: [
                        ["arial", "Arial"],
                        ["times new roman", "Times New Roman"],
                        ["verdana", "Verdana"]
                    ],
                    disabled: t.is_remote_mode
                },
                i = {
                    fieldLabel: _T("common", "size"),
                    editable: !0,
                    name: "subtitle_size",
                    values: [
                        ["56", "56"],
                        ["48", "48"],
                        ["40", "40"],
                        ["36", "36"],
                        ["28", "28"]
                    ],
                    disabled: t.is_remote_mode && !t.is_chromecast,
                    validator: this.validateNumber
                },
                n = {
                    fieldLabel: _VCT("options", "transparency"),
                    name: "subtitle_transparency",
                    values: [
                        ["100", "0%"],
                        ["75", "25%"],
                        ["50", "50%"],
                        ["25", "75%"]
                    ],
                    disabled: t.is_remote_mode
                },
                o = {
                    fieldLabel: _VCT("options", "shadow"),
                    name: "subtitle_shadow",
                    values: [
                        ["none", _T("common", "none")],
                        ["default", _T("common", "default")],
                        ["drop_shadow", _VCT("options", "drop_shadow")],
                        ["raised", _VCT("options", "raised")],
                        ["depressed", _VCT("options", "depressed")],
                        ["outline", _VCT("options", "outline")]
                    ],
                    disabled: t.is_remote_mode
                },
                r = {
                    fieldLabel: _VCT("options", "text_color"),
                    name: "subtitle_color",
                    disabled: t.is_remote_mode
                },
                l = {
                    fieldLabel: _VCT("options", "subtitle_position"),
                    name: "subtitle_position",
                    values: [
                        ["top", _VCT("options", "top")],
                        ["bottom", _VCT("options", "bottom")]
                    ],
                    disabled: t.is_remote_mode
                },
                s = {
                    title: _VCT("options", "subtitle"),
                    items: [new SYNO.VideoController2.Preference.ComboBox(e), new SYNO.VideoController2.Preference.ComboBox(i), new SYNO.VideoController2.Preference.ColorField(r), new SYNO.VideoController2.Preference.ComboBox(n), new SYNO.VideoController2.Preference.ComboBox(o), new SYNO.VideoController2.Preference.ComboBox(l)]
                };
            this.callParent([Ext.apply(s, t)])
        },
        validateNumber: function(t) {
            return !!/^[0-9]+$/.exec(t) && 0 < parseInt(t)
        }
    }), Ext.define("SYNO.VideoController2.Preference.BackgroundFieldSet", {
        extend: "SYNO.VideoController2.FieldSet",
        constructor: function(t) {
            var e = {
                    fieldLabel: _VCT("options", "transparency"),
                    name: "background_transparency",
                    values: [
                        ["100", "0%"],
                        ["75", "25%"],
                        ["50", "50%"],
                        ["25", "75%"],
                        ["0", "100%"]
                    ],
                    disabled: t.is_remote_mode
                },
                i = {
                    fieldLabel: _VCT("options", "background_color"),
                    name: "background_color",
                    disabled: t.is_remote_mode
                },
                n = {
                    title: _VCT("options", "background"),
                    items: [new SYNO.VideoController2.Preference.ColorField(i), new SYNO.VideoController2.Preference.ComboBox(e)]
                };
            this.callParent([Ext.apply(n, t)])
        }
    }), Ext.define("SYNO.VideoController2.Preference.ComboBox", {
        extend: "SYNO.VideoController2.ComboBox",
        constructor: function(t) {
            var e = {
                displayField: "display",
                valueField: "value",
                editable: !!t.editable && t.editable,
                allowBlank: !1,
                validator: t.validator ? t.validator : null,
                store: this.getArrayStore(t.values)
            };
            this.callParent([Ext.apply(e, t)])
        },
        getArrayStore: function(t) {
            return this.store = this.store || new Ext.data.ArrayStore({
                fields: ["value", "display"],
                data: t
            }), this.store
        },
        onSelect: function(t, e) {
            this.callParent(arguments), SYNO.VideoController2.SubtitlePreference.get().setSetting(this.name, t.data.value)
        }
    }), Ext.define("SYNO.VideoController2.Preference.ColorField", {
        extend: "SYNO.VideoController2.ColorField",
        constructor: function(t) {
            this.callParent(arguments), this.mon(this, "change", this.onColorChange.bind(this))
        },
        onColorChange: function(t, e, i) {
            SYNO.VideoController2.SubtitlePreference.get().setSetting(this.name, e)
        },
        onColorSelect: function(t, e) {
            this.callParent(arguments), SYNO.VideoController2.SubtitlePreference.get().setSetting(this.name, "#" + t.value)
        }
    }), Ext.define("SYNO.VideoController2.SyncDialog", {
        extend: "SYNO.VideoController2.Dialog",
        constructor: function(t) {
            this.controller = t.controller, this.sync_time_field = new SYNO.ux.NumberField({
                cls: "syno-vc-base-textfield",
                layout: "fix",
                fieldLabel: "Shift Time",
                allowNegative: !0,
                allowDecimals: !0,
                decimalPrecision: 3,
                scope: this,
                listeners: {
                    scope: this,
                    change: this.shiftValueHandler,
                    keyup: this.shiftValueHandler
                },
                value: this.controller.getDelayedTime()
            }), this.sync_time_unit = {
                cls: "sync-time-unit",
                xtype: "label",
                html: "S"
            }, this.shift_right_button = new SYNO.ux.Button({
                cls: "syno-vc-button icon-add",
                scope: this,
                handler: this.shiftRightHandler
            }), this.shift_left_button = new SYNO.ux.Button({
                cls: "syno-vc-button icon-delete",
                scope: this,
                handler: this.shiftLeftHandler
            }), this.reset_button = new SYNO.ux.Button({
                cls: "syno-vc-button icon-undo",
                scope: this,
                handler: this.resetHandler
            }), this.panel = new SYNO.ux.Panel({
                border: !1,
                frame: !1,
                layout: {
                    type: "table",
                    columns: 5
                },
                scope: this,
                items: [this.sync_time_field, this.sync_time_unit, this.shift_right_button, this.shift_left_button, this.reset_button]
            });
            var e = {
                cls: "sync-subtitle-dialog",
                title: _VCT("controller", "shift_subtitle"),
                closable: !1,
                layout: "fit",
                width: "357px",
                height: "142px",
                resizable: !1,
                offset: .25,
                items: [this.panel],
                buttons: [{
                    cls: "syno-vc-button",
                    text: _T("common", "ok"),
                    btnStyle: "blue",
                    itemId: "ok",
                    scope: this,
                    handler: this.applyHandler
                }]
            };
            this.callParent([Ext.apply(e, t)])
        },
        shiftLeftHandler: function() {
            var t = this.controller.getDelayedTime() - this.offset;
            this.controller.setDelayedTime(t), this.sync_time_field.setValue(t)
        },
        shiftRightHandler: function() {
            var t = this.controller.getDelayedTime() + this.offset;
            this.controller.setDelayedTime(t), this.sync_time_field.setValue(t)
        },
        shiftValueHandler: function() {
            var t = this.sync_time_field.getValue();
            this.controller.setDelayedTime(t)
        },
        resetHandler: function() {
            this.controller.setDelayedTime(0), this.sync_time_field.setValue(0)
        },
        applyHandler: function() {
            var t = this.controller.video_list.getSubtitleList(),
                e = this.controller.getUsingSubtitle(t),
                i = this.controller.video_list.getFileUniqueKey(),
                n = e.subtitle_id;
            this.controller.subtitle_manager.setOffset(i, n, this.controller.getDelayedTime(), function() {
                this.controller.setSubtitle(n)
            }.createDelegate(this)), this.close()
        }
    }), Ext.define("SYNO.VideoController2.VLCPlayer", {
        extend: "SYNO.VideoController2.Player",
        constructor: function(t) {
            var e = {
                name: "VLC",
                player_id: "_vlc_video_player",
                error: !1,
                first_start_playing: !1
            };
            this.callParent([Ext.apply(e, t)])
        },
        canPlayType: function(t) {
            return "ogg" !== t && "ogv" !== t
        },
        isAvailable: function() {
            return SYNO.VideoController2.Util.isVLCSupported()
        },
        checkResumed: function(t) {
            return this.checkResumedByCase(t)
        },
        fullscreen: function() {
            this.pluginInit && SYNO.VideoController2.Util.setDomFullscreen(this.controller.container.dom)
        },
        clear: function() {
            this.unregisterEventHandler(), this.callParent(arguments)
        },
        play: function(t) {
            this.url = t, this.createPlayer() || this.onVLCReady()
        },
        pause: function() {
            this.pluginInit && this.player.playlist.pause()
        },
        resume: function() {
            this.pluginInit && this.player.playlist.play()
        },
        stop: function() {
            var t = this.getState();
            this.pluginInit && (t === SYNO.VideoController2.Util.STATE.PLAYING || t === SYNO.VideoController2.Util.STATE.PAUSED ? this.player.playlist.stop() : this.stop.defer(100, this, arguments))
        },
        seek: function(t) {
            var e = 1e3 * t;
            this.pluginInit && e >= 0 && e <= this.player.input.length && (this.player.input.time = e)
        },
        getPosition: function() {
            return this.pluginInit ? this.player.input.time / 1e3 : -1
        },
        getDuration: function() {
            return this.pluginInit ? this.player.input.length / 1e3 : -1
        },
        getVolume: function() {
            return this.pluginInit ? this.player.audio.volume : -1
        },
        setVolume: function(t) {
            this.pluginInit && (this.player.audio.volume = t, this.volumeHandler())
        },
        getMute: function() {
            var t = !1;
            return this.pluginInit && (t = this.player.audio.mute), t
        },
        setMute: function(t) {
            this.pluginInit && (this.player.audio.mute = t, this.volumeHandler())
        },
        StateMap: {
            0: SYNO.VideoController2.Util.STATE.NO_MEDIA,
            1: SYNO.VideoController2.Util.STATE.BUFFERING,
            2: SYNO.VideoController2.Util.STATE.BUFFERING,
            3: SYNO.VideoController2.Util.STATE.PLAYING,
            4: SYNO.VideoController2.Util.STATE.PAUSED,
            5: SYNO.VideoController2.Util.STATE.STOPPED,
            6: SYNO.VideoController2.Util.STATE.STOPPED,
            7: SYNO.VideoController2.Util.STATE.ERROR
        },
        getPlayerState: function() {
            var t = 1;
            try {
                t = this.player.input.state
            } catch (t) {}
            return 7 === t && (this.error = !0), t
        },
        getState: function() {
            if (!this.pluginInit) return SYNO.VideoController2.Util.STATE.NO_MEDIA;
            if (this.error) return SYNO.VideoController2.Util.STATE.ERROR;
            var t = this.StateMap[this.getPlayerState()] || SYNO.VideoController2.Util.STATE.ERROR;
            return t !== SYNO.VideoController2.Util.STATE.PLAYING || this.first_start_playing || (this.playerReadyHandler(), this.first_start_playing = !0), t
        },
        disablePlayerSubtitle: function() {
            if (this.pluginInit && !0 === this.subtitle_is_srt) {
                var t = this.player.VersionInfo.match(/\d+/g),
                    e = parseInt(t[0], 10),
                    i = parseInt(t[1], 10);
                e < 2 || 2 == e && i < 2 ? this.player.subtitle.track = -1 : this.player.subtitle.count > 0 && (this.player.subtitle.track = 0)
            }
        },
        setPlayerSubtitle: function(t) {
            this.pluginInit && !0 !== this.subtitle_is_srt && (this.player.subtitle.track = t)
        },
        createPlayer: function() {
            return !this.player && (this.el = SYNO.VideoController2.Util.createVLCElement(this.controller.video, this.player_id), this.player = this.el.dom, this.registerEventHandler(), this.el.enableDisplayMode(), this.el.show(), this.pluginInit = !0, this.onVLCReady(), !0)
        },
        onVLCReady: function() {
            if (this.player) {
                if (!this.player.VersionInfo) return void this.onVLCReady.defer(100, this);
                this.fitPlayer.defer(100, this), this.fitPlayer.defer(500, this), Ext.isString(this.url) && (this.player.playlist.items && this.player.playlist.items.count > 0 && this.player.playlist.items.clear(), this.playlistItemId = this.player.playlist.add(this.url), this.player.playlist.playItem(this.playlistItemId)), Ext.isIE && this.adjustPlayerWidthHack()
            }
        },
        fitPlayer: function() {
            this.el && this.el.setSize("100%", "100%")
        },
        adjustPlayerWidthHack: function() {
            this.el && (this.el.setWidth(this.el.getWidth() + 1), this.el.setWidth(this.el.getWidth() - 1))
        },
        durationHandler: function(t) {
            var e = Ext.isNumber(t) ? t / 1e3 : null;
            this.callParent([e])
        },
        positionHandler: function(t) {
            this.callParent([t / 1e3])
        },
        stateHandler: function() {
            this.volume_inited || (this.setVolume.defer(1e3, this, [this.controller.volume]), this.volume_inited = !0), this.durationHandler(), this.callParent(arguments)
        },
        needUsePollingTask: function() {
            return Ext.isIE11 || Ext.isMac && Ext.isSafari
        },
        registerEventHandler: function() {
            this.volume_inited = !1, this[this.needUsePollingTask() ? "createPollingTask" : "registerDomEventHandler"]()
        },
        registerDomEventHandler: function() {
            this._stateHandlerWithScope = this.stateHandler.createDelegate(this), this._durationHandlerWithScope = this.durationHandler.createDelegate(this), this._positionHandlerWithScope = this.positionHandler.createDelegate(this);
            var t = SYNO.VideoController2.Util.addDomListener(!0);
            t(this.player, "MediaPlayerOpening", this._stateHandlerWithScope), t(this.player, "MediaPlayerPlaying", this._stateHandlerWithScope), t(this.player, "MediaPlayerPaused", this._stateHandlerWithScope), t(this.player, "MediaPlayerStopped", this._stateHandlerWithScope), t(this.player, "MediaPlayerEndReached", this._stateHandlerWithScope), t(this.player, "MediaPlayerEncounteredError", this._stateHandlerWithScope), t(this.player, "MediaPlayerTimeChanged", this._positionHandlerWithScope), t(this.player, "MediaPlayerLengthChanged", this._durationHandlerWithScope)
        },
        unregisterEventHandler: function() {
            this[this.needUsePollingTask() ? "destroyPollingTask" : "unregisterDomEventHandler"](), this.first_start_playing = !1
        },
        unregisterDomEventHandler: function() {
            var t = SYNO.VideoController2.Util.removeDomListener(!0);
            t(this.player, "MediaPlayerOpening", this._stateHandlerWithScope), t(this.player, "MediaPlayerPlaying", this._stateHandlerWithScope), t(this.player, "MediaPlayerPaused", this._stateHandlerWithScope), t(this.player, "MediaPlayerStopped", this._stateHandlerWithScope), t(this.player, "MediaPlayerEndReached", this._stateHandlerWithScope), t(this.player, "MediaPlayerEncounteredError", this._stateHandlerWithScope), t(this.player, "MediaPlayerTimeChanged", this._positionHandlerWithScope), t(this.player, "MediaPlayerLengthChanged", this._durationHandlerWithScope), this._stateHandlerWithScope = null, this._positionHandlerWithScope = null, this._durationHandlerWithScope = null
        },
        pollingTaskFn: function() {
            this.stateHandler(), this.positionHandler(), this.durationHandler()
        }
    }), Ext.define("SYNO.VideoController2.AudioTrackStore", {
        extend: "SYNO.API.Store",
        AudioTrackRecord: Ext.data.Record.create([{
            name: "id",
            type: "int"
        }, {
            name: "track",
            type: "int"
        }, {
            name: "codec",
            type: "string"
        }, {
            name: "language",
            type: "string"
        }]),
        constructor: function(t) {
            var e = {
                reader: new Ext.data.JsonReader({
                    root: SYNO.VideoController2.SharingHelper.getAPIRoot("AudioTrack")
                }, this.AudioTrackRecord)
            };
            Ext.apply(e, SYNO.VideoController2.SharingHelper.getAPI("AudioTrack")), this.callParent([Ext.apply(e, t)])
        }
    }), Ext.define("SYNO.VideoController2.SubtitleStore", {
        extend: "SYNO.API.Store",
        SubtitleRecord: Ext.data.Record.create([{
            name: "subtitle_id",
            type: "string",
            mapping: "id"
        }, {
            name: "lang",
            type: "string"
        }, {
            name: "title",
            type: "string"
        }, {
            name: "format",
            type: "string"
        }, {
            name: "embedded",
            type: "boolean"
        }, {
            name: "need_preview",
            type: "boolean"
        }]),
        constructor: function(t) {
            var e = {
                baseParams: {
                    image_based: !0
                },
                reader: new Ext.data.JsonReader({
                    root: SYNO.VideoController2.SharingHelper.getAPIRoot("SubtitleList")
                }, this.SubtitleRecord)
            };
            Ext.apply(e, SYNO.VideoController2.SharingHelper.getAPI("SubtitleList")), this.callParent([Ext.apply(e, t)])
        }
    }), Ext.define("SYNO.VideoController2.VideoFile", {
        extend: "Ext.Component",
        constructor: function(t) {
            var e = {
                video_info_fetched: !1,
                video_id: null,
                type: null,
                seasion: null,
                episode: null,
                file_id: null,
                title: null,
                name: null,
                duration: null,
                resolution: null,
                rotation: 0,
                codec_info: null,
                position: 0,
                last_watched_position: 0,
                audio_track_fetched: !1,
                audio_store: null,
                audio_track: [],
                subtitle_fetched: !1,
                subtitle_store: null,
                subtitle_list: [],
                path: null,
                symlink: null,
                drive_path: null
            };
            this.callParent([Ext.apply(e, t)])
        },
        onLoad: Ext.emptyFn,
        isAllFetched: function() {
            return this.audio_track_fetched && this.video_info_fetched && this.subtitle_fetched
        },
        getInfo: function(t) {
            this.isAllFetched() ? SYNO.VideoController2.Util.tryCallback(t) : this.getInfoSequence(t)
        },
        getInfoSequence: function(t) {
            return this.video_info_fetched ? this.audio_track_fetched ? this.subtitle_fetched ? void SYNO.VideoController2.Util.tryCallback(t) : void this.getSubtitleList(this.getInfoSequence.createDelegate(this, [t])) : void this.getAudioTrack(this.getInfoSequence.createDelegate(this, [t])) : void this.getVideoInfo(this.getInfoSequence.createDelegate(this, [t]))
        },
        getVideoInfo: function(t) {
            var e = SYNO.VideoController2.SharingHelper.getVideoAPI(this.type);
            if (!Ext.isDefined(e)) return void SYNO.VideoController2.Util.tryCallback(t);
            var i = {};
            i = "filevideo" === this.type ? this.getFileParams() : SYNO.VideoController2.SharingHelper.getVideoParams(this.video_id);
            var n = {
                params: i,
                scope: this,
                callback: function(e, i, n, o) {
                    if (this.video_info_fetched = !0, e) this.fillVideoInfo(i, o), SYNO.VideoController2.Util.tryCallback(t);
                    else {
                        var r = this.list.appWin.getController();
                        r.onAPIError.apply(r, arguments)
                    }
                }
            };
            Ext.apply(n, e), SYNO.VideoController2.Util.applySharingID(n.params), SYNO.API.Request(n)
        },
        fillVideoInfo: function(t, e) {
            var i = t[SYNO.VideoController2.SharingHelper.getVideoAPIRoot(this.type)][0],
                n = i.additional,
                o = n.file;
            if (Ext.isNumber(this.file_id)) {
                var r = this.file_id;
                o = o.filter(function(t) {
                    return r == t.id
                })
            } else {
                var l = this.parseDuration;
                o.sort(function(t, e) {
                    return l(e.duration) - l(t.duration)
                })
            }
            var s = o[0],
                a = s.path,
                d = s.sharepath,
                h = {},
                u = a.substring(a.lastIndexOf("/") + 1);
            Ext.copyTo(h, s, ["container_type", "audio_codec", "video_codec", "channel"]), Ext.apply(this, {
                mapper_id: this.getMapperId(i),
                name: this.getName(i) || u,
                date: this.getDate(i),
                title: u,
                file_id: parseInt(s.id, 10),
                resolution: {
                    width: s.resolutionx,
                    height: s.resolutiony
                },
                display_resolution: {
                    width: s.display_x,
                    height: s.display_y
                },
                rotation: s.rotation,
                duration: this.parseDuration(s.duration),
                codec_info: h,
                path: a,
                sharepath: d
            }), "filevideo" === this.type || SYNO.VideoController2.Util.isVideoControllerOnly() || Ext.apply(this, {
                position: s.position,
                watched_ratio: s.watched_ratio
            })
        },
        getName: function(t) {
            if ("tvshow_episode" !== this.type) return t.title;
            var e = t.season < 10 ? "0" + t.season : t.season,
                i = t.episode < 10 ? "0" + t.episode : t.episode,
                n = Ext.isEmpty(t.tagline) ? "" : ", " + t.tagline;
            return String.format("{0} - S{1}E{2}{3}", t.title, e, i, n)
        },
        getDate: function(t) {
            return "movie" === this.type || "tvshow_episode" === this.type ? t.original_available : "home_video" === this.type || "tv_record" === this.type ? t.record_date : ""
        },
        getMapperId: function(t) {
            return "tvshow_episode" === this.type ? t.tvshow_mapper_id : t.mapper_id
        },
        getResumePosition: function(t) {
            var e = parseInt(Math.max(0, Ext.isNumber(this.position) ? this.position - 2 : 0), 10);
            if (!0 === t) return e;
            var i = SYNO.VideoController2.Util.roundPercentage(this.watched_ratio);
            return Ext.isNumber(this.watched_ratio) && 0 !== i && 100 !== i ? e : null
        },
        updateWatchedPosition: function(t) {
            !Ext.isNumber(t) || t < this.last_watched_position + 10 || (this.last_watched_position = t, this.setWatchStatus(t, Ext.emptyFn))
        },
        setWatched: function(t) {
            this.setWatchStatus(this.duration, t)
        },
        setWatchStatus: function(t, e) {
            return SYNO.VideoController2.Util.isVideoControllerOnly() ? void SYNO.VideoController2.Util.tryCallback(e) : !Ext.isNumber(this.file_id) || !Ext.isNumber(t) || t <= 0 ? void SYNO.VideoController2.Util.tryCallback(e) : (this.position = t, this.position >= 0 && this.duration > 0 && (this.watched_ratio = this.position / this.duration, this.watched_ratio = this.watched_ratio <= .02 ? 0 : this.watched_ratio, this.watched_ratio = this.watched_ratio >= .98 ? 1 : this.watched_ratio), void SYNO.VideoController2.WebAPI.keepaliveFetch("SYNO.VideoStation2.File", "set_watchstatus", 1, {
                id: this.file_id,
                position: Math.floor(t)
            }).then(function() {
                SYNO.VideoController2.Util.tryCallback(e)
            }))
        },
        setPlaybackSetting: function(t, e) {
            !SYNO.VideoController2.Util.isVideoControllerOnly() && Ext.isNumber(this.file_id) && Ext.isString(t) && Ext.isNumber(e) && SYNO.API.Request({
                api: "SYNO.VideoStation2.File",
                method: "set_playback_setting",
                version: 2,
                params: {
                    id: this.file_id,
                    subtitle_id: t === SYNO.VideoController2.Util.SUBTITLE_NONE ? "" : t,
                    audio_track: e
                }
            })
        },
        deleteSymLink: function() {
            Ext.isEmpty(this.path) || Ext.isEmpty(this.symlink) || SYNO.VideoController2.WebAPI.keepaliveFetch("SYNO.VideoStation2.File", "delete_symlink", 1, {
                path: this.path,
                symlink: this.symlink
            })
        },
        getUniqueKey: function() {
            return "filevideo" === this.type ? this.path : this.file_id
        },
        getFileParams: function() {
            return "filevideo" === this.type ? Ext.isString(this.symlink) ? {
                path: this.path,
                symlink: this.symlink
            } : Ext.isString(this.drive_path) ? {
                drive_path: this.drive_path
            } : {
                path: this.path
            } : {
                id: this.file_id
            }
        },
        getAudioTrack: function(t) {
            if (this.audio_track_fetched) return void SYNO.VideoController2.Util.tryCallback(t);
            this.audio_store = new SYNO.VideoController2.AudioTrackStore({
                appWindow: this.list.appWin
            }), this.addManagedComponent(this.audio_store);
            var e = this.getFileParams(),
                i = {
                    scope: this,
                    callback: function() {
                        this.audio_track_fetched = !0, this.audio_store.data.each(function(t) {
                            this.audio_track.push(t.data)
                        }, this), SYNO.VideoController2.Util.tryCallback(t)
                    },
                    params: e
                };
            SYNO.VideoController2.Util.applySharingID(i.params), this.audio_store.load(i)
        },
        getSubtitleList: function(t) {
            if (this.symlink && (this.subtitle_fetched = !0), this.subtitle_fetched) return void SYNO.VideoController2.Util.tryCallback(t);
            this.subtitle_store = new SYNO.VideoController2.SubtitleStore({
                appWindow: this.list.appWin
            }), this.addManagedComponent(this.subtitle_store), this.loadSubtitleStore(t)
        },
        loadSubtitleStore: function(t) {
            var e = this.getFileParams(),
                i = {
                    scope: this,
                    callback: function() {
                        this.subtitle_fetched = !0, this.subtitle_list = [], this.subtitle_store.data.each(function(t) {
                            this.subtitle_list.push(t.data)
                        }, this), SYNO.VideoController2.Util.tryCallback(t)
                    },
                    params: e
                };
            SYNO.VideoController2.Util.applySharingID(i.params), this.subtitle_store.load(i)
        },
        parseDuration: function(t) {
            if (!Ext.isDefined(t)) return 0;
            if (Ext.isNumber(t)) return t;
            for (var e = 0, i = t.split(":"), n = 0; n < i.length; ++n) e = 60 * e + parseFloat(i[n]);
            return e
        }
    }), Ext.define("SYNO.VideoController2.VideoStore", {
        extend: "SYNO.API.Store",
        CollectionRecord: Ext.data.Record.create([{
            name: "video_id",
            type: "int",
            mapping: "id"
        }, {
            name: "type",
            type: "string"
        }, {
            name: "original_data",
            type: "object",
            convert: function(t, e) {
                return e
            }
        }, {
            name: "unique_id",
            type: "string",
            convert: function(t, e) {
                return String.format("{0}-{1}", e.type, e.id)
            }
        }]),
        TvshowRecord: Ext.data.Record.create([{
            name: "episode",
            type: "int"
        }, {
            name: "season",
            type: "int"
        }, {
            name: "video_id",
            type: "int",
            mapping: "id"
        }, {
            name: "type",
            type: "string",
            defaultValue: "tvshow_episode"
        }, {
            name: "unique_id",
            type: "string",
            convert: function(t, e) {
                return String.format("{0}-{1}", e.type, e.id)
            }
        }]),
        constructor: function(t) {
            var e = t.is_collection ? this.CollectionRecord : this.TvshowRecord,
                i = {
                    reader: new Ext.data.JsonReader({
                        root: t.reader_root,
                        idProperty: "unique_id"
                    }, e)
                };
            this.callParent([Ext.apply(i, t)])
        }
    }), Ext.define("SYNO.VideoController2.VideoList", {
        extend: "Ext.Component",
        constructor: function(t) {
            var e = {
                loaded: !1,
                browse_type: null,
                sharing_id: null,
                type_id: null,
                store: null,
                video_list: [],
                current_index: -1
            };
            this.callParent([Ext.apply(e, t)])
        },
        NullVideoFile: new SYNO.VideoController2.VideoFile,
        isCollection: function() {
            return "collection" === this.browse_type
        },
        isTVShow: function() {
            return "tvshow_episode" === this.browse_type || "tvshow" === this.browse_type
        },
        isSingleVideo: function() {
            return !Ext.isNumber(this.type_id) && !Ext.isString(this.sharing_id) || !this.isCollection() && !this.isTVShow()
        },
        getStore: function() {
            if (this.store) return this.store;
            var t;
            return this.isCollection() ? (t = {
                is_collection: !0
            }, Ext.apply(t, SYNO.VideoController2.SharingHelper.getAPI("CollectionListVideo")), Ext.apply(t, {
                reader_root: SYNO.VideoController2.SharingHelper.getAPIRoot("CollectionListVideo")
            }), Ext.apply(t, {
                baseParams: SYNO.VideoController2.SharingHelper.getCollectionListVideoParam(this.sort_info, this.type_id)
            })) : t = {
                is_collection: !1,
                reader_root: "episodes",
                api: "SYNO.VideoStation.TVShowEpisode",
                method: "list",
                version: 1,
                baseParams: {
                    tvshow: this.type_id
                }
            }, this.store = new SYNO.VideoController2.VideoStore(Ext.apply(t, {
                appWindow: this.appWin
            })), this.addManagedComponent(this.store), this.store
        },
        initSingleVideo: function(t, e) {
            this.video_list.push(new SYNO.VideoController2.VideoFile(Ext.apply({
                list: this
            }, t))), this.current_index = 0, this.loaded = !0, SYNO.VideoController2.Util.tryCallback(e)
        },
        init: function(t, e) {
            if (this.isSingleVideo()) return void this.initSingleVideo(t, e);
            this.getStore().load({
                callback: this.onVideoListLoad.createDelegate(this, [t, e]),
                scope: this
            })
        },
        onVideoListLoad: function(t, e) {
            var i = t.video_id,
                n = t.file_id,
                o = t.title;
            this.store.data.each(function(t) {
                this.video_list.push(new SYNO.VideoController2.VideoFile(Ext.apply({
                    list: this
                }, t.data)))
            }, this);
            var r = this.video_list[this.getCurrentIndex(i, t.type)];
            if (r.file_id = n, r.title = o, this.isTVShow()) {
                var l = r.season;
                this.video_list = this.video_list.filter(function(t) {
                    return l === t.season
                }), this.video_list.sort(this.tvshowSortFunction)
            }
            this.getCurrentIndex(i, t.type), this.loaded = !0, SYNO.VideoController2.Util.tryCallback(e)
        },
        tvshowSortFunction: function(t, e) {
            var i = 0,
                n = 0;
            return i += 0 === t.episode ? 1024 : 0, n += 0 === e.episode ? 1024 : 0, i += t.season > e.season ? 2 : 0, n += e.season > t.season ? 2 : 0, i += t.episode > e.episode ? 1 : 0, n += e.episode > t.episode ? 1 : 0, i - n
        },
        getCurrentIndex: function(t, e) {
            if (!Ext.isDefined(t) || !Ext.isDefined(e)) return Ext.isNumber(this.current_index) && 0 <= this.current_index ? this.current_index : -1;
            for (var i = 0; i < this.video_list.length; ++i)
                if (t === this.video_list[i].video_id && e === this.video_list[i].type) {
                    this.current_index = i;
                    break
                } return this.current_index
        },
        getCurrentVideo: function() {
            var t = this.getCurrentIndex();
            return 0 > t ? this.NullVideoFile : this.video_list[t]
        },
        getNextIndex: function() {
            return Ext.isNumber(this.current_index) && this.current_index >= 0 && this.hasNext() ? this.current_index + 1 : -1
        },
        getNextVideo: function() {
            var t = this.getNextIndex();
            return 0 > t ? this.NullVideoFile : this.video_list[t]
        },
        getVideoID: function() {
            return this.getCurrentVideo().video_id
        },
        getVideoType: function() {
            return this.getCurrentVideo().type
        },
        getFileUniqueKey: function() {
            return this.getCurrentVideo().getUniqueKey()
        },
        getFileParams: function() {
            return this.getCurrentVideo().getFileParams()
        },
        getTitle: function() {
            return this.getCurrentVideo().title
        },
        getName: function() {
            return this.getCurrentVideo().name
        },
        getDate: function() {
            return this.getCurrentVideo().date
        },
        getDuration: function() {
            return this.getCurrentVideo().duration
        },
        getResolution: function() {
            return this.getCurrentVideo().resolution
        },
        getDisplayResolution: function() {
            return this.getCurrentVideo().display_resolution
        },
        getCodecInfo: function() {
            return this.getCurrentVideo().codec_info
        },
        getAudioTrack: function() {
            return this.getCurrentVideo().audio_track
        },
        getDefaultAudioID: function() {
            var t = 0,
                e = this.getAudioTrack();
            return e.length > 0 && (t = e[0].id), t
        },
        getDefaultAudioCodec: function() {
            var t = "",
                e = this.getAudioTrack();
            return e.length > 0 && (t = e[0].codec), t
        },
        getSubtitleList: function() {
            return this.getCurrentVideo().subtitle_list
        },
        hasPrev: function() {
            return this.current_index - 1 >= 0
        },
        hasNext: function() {
            return this.video_list.length > this.current_index + 1
        },
        goPrev: function(t) {
            return this.hasPrev() ? (this.current_index--, !0) : !0 === t && (this.current_index = this.video_list.length - 1, !0)
        },
        goNext: function(t) {
            return this.hasNext() ? (this.current_index++, !0) : !0 === t && (this.current_index = 0, !0)
        },
        goJump: function(t) {
            var e = -1;
            return this.video_list.forEach(function(i, n) {
                i.unique_id === t && (e = n)
            }), -1 !== e && (this.current_index = e, !0)
        },
        canDiscoverSubtitle: function() {
            if (SYNO.VideoController2.Util.isPublicSharing()) return !1;
            var t = this.getSubtitleList().length > 0,
                e = "movie" === this.getVideoType(),
                i = "tvshow_episode" === this.getVideoType();
            return !t && (e || i) && !0 === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.VideoStation.AppInstance", "enable_discover")
        }
    }), Ext.define("SYNO.VideoController2.Controller", {
        extend: "Ext.util.Observable",
        constructor: function(t) {
            this.addEvents({
                statechange: !0,
                mutechange: !0,
                volumechange: !0,
                timechange: !0,
                timeinit: !0,
                subtitlechange: !0,
                discoverchange: !0,
                capabilityready: !0,
                playerlistchange: !0,
                videolistready: !0,
                busy: !0,
                clear: !0,
                fhd_high_bitrate_enabled: !0,
                rawdisabled: !0,
                targetchange: !0,
                titlechange: !0,
                videochange: !0,
                screenshot_state_change: !0
            });
            var e = Ext.apply({
                audio_id: null,
                subtitle_id: null,
                subtitle_codepage: "auto",
                profile: null,
                player_info: {
                    id: null,
                    type: SYNO.VideoController2.Util.PLAYERTYPE_STREAMING,
                    title: _VCT("controller", "streaming_mode"),
                    volume_adjustable: !0,
                    seekable: !1,
                    password_protected: !1
                },
                repeat: SYNO.VideoController2.Util.REPEAT_NONE,
                player_store: null,
                player_list: null,
                video_list: null,
                force_resume: !1,
                start_position: 0,
                delayed_time: 0,
                support_remux: null,
                support_transcode: null,
                support_fhd_hardware_transcode: null,
                fhd_high_bitrate_enabled: !1,
                rawdisabled: !1,
                screenshot_creating: !1,
                spaceenabled: !0,
                subtitle_visible: !1,
                mute: !1,
                state: SYNO.VideoController2.Util.STATE.STOPPED,
                volume: 50,
                playback_rate: 1,
                position: -1,
                duration: -1,
                initPlaying: !1,
                tid: null
            }, t);
            Ext.apply(this, e), this.callParent([e]), this.relayEvents(SYNO.VideoController2.SubtitlePreference.get(), [SYNO.VideoController2.SubtitlePreference.EVENT_DATA_CHANGED]), this.on(SYNO.VideoController2.SubtitlePreference.EVENT_DATA_CHANGED, this.onSubtitlePreferenceChanged, this), this.initPlayers(), this.subtitle_manager = new SYNO.VideoController2.SubtitleManager({
                listeners: {
                    subtitleready: this.onSubtitleReady.createDelegate(this),
                    discoverready: this.onDiscoverReady.createDelegate(this),
                    getoffsetsuccess: this.onGetOffsetSuccess.createDelegate(this)
                }
            }), this.hls_handler = new SYNO.VideoController2.HLSHandler({
                supportRemux: this.supportRemux.bind(this),
                controller: this
            }), this._pin_manager = SYNO.VideoController2.PinCodeManager.get(this.appWin)
        },
        onStateChange: function(t, e) {
            this.fireEvent("statechange", t, e)
        },
        onMuteChange: function(t) {
            this.fireEvent("mutechange", t)
        },
        onVolumeChange: function(t, e) {
            this.fireEvent("volumechange", t, e)
        },
        onTimeChange: function(t, e) {
            this.fireEvent("timechange", t, e)
        },
        onTimeInit: function(t, e) {
            this.fireEvent("timeinit", t, e)
        },
        onSubtitleChange: function(t, e) {
            this.fireEvent("subtitlechange", t, e)
        },
        onSubtitlePreferenceChanged: function(t) {
            this.getPlayer().setSubtitleSize(t.subtitle_size)
        },
        onScreenshotStateChange: function(t, e) {
            this.fireEvent("screenshot_state_change", t, e)
        },
        initPlayers: function() {
            var t;
            t = [new SYNO.VideoController2.NullPlayer({
                controller: this
            }), this.html5Player(), this.hlsPlayer(), this.flashPlayer(), new SYNO.VideoController2.VLCPlayer({
                controller: this
            })], this.players = [], Ext.each(t, function(t) {
                t.isAvailable() && this.players.push(t)
            }, this)
        },
        updatePlayer: function(t) {
            var e, i = t.filename,
                n = t.codec;
            if (Ext.isString(i)) {
                var o = SYNO.VideoController2.Util.getFileExt(i);
                Ext.each(this.players, function(t) {
                    if (t.canPlayType(o, n)) return e = t, !1
                }, this)
            }
            this.player = e || this.players[0]
        },
        closePlayers: function() {
            this.clearCallback = null, Ext.each(this.players, function(t) {
                t.clear()
            }, this)
        },
        selectPlayer: function(t) {
            var e = null;
            return Ext.each(this.players, function(i) {
                if (t === i.getName()) return e = i, !1
            }), null === e && (e = this.players[0]), this.player = e, e
        },
        getPlayer: function() {
            return Ext.isObject(this.player) ? this.player : this.players[0]
        },
        isPlaybackRateAdjustable: function(t) {
            return !this.isRemoteMode() && SYNO.VideoController2.Util.isHTML5Base(t)
        },
        setPlaybackRate: function(t) {
            this.playback_rate = t, this.getPlayer().setPlaybackRate(this.playback_rate)
        },
        play: function(t) {
            switch (this.state) {
                case SYNO.VideoController2.Util.STATE.ERROR:
                    var e = this.play.createDelegate(this, arguments);
                    this.initPlaying = !1, this.updateState(SYNO.VideoController2.Util.STATE.NO_MEDIA), this.stop(e);
                    break;
                case SYNO.VideoController2.Util.STATE.NO_MEDIA:
                case SYNO.VideoController2.Util.STATE.CLEAR:
                case SYNO.VideoController2.Util.STATE.STOPPED:
                case SYNO.VideoController2.Util.STATE.AUTO_PLAY_FAIL:
                    this.initPlaying = !0, this.url = t || this.url, this.playCurrentVideo();
                    break;
                case SYNO.VideoController2.Util.STATE.PLAYING:
                    this.getPlayer().pause();
                    break;
                case SYNO.VideoController2.Util.STATE.PAUSED:
                    this.getPlayer().resume()
            }
        },
        loadVideoList: function(t) {
            var e = this.init_type_info,
                i = this.init_video_info;
            this.video_list = new SYNO.VideoController2.VideoList({
                appWin: this.appWin,
                browse_type: e.type,
                sharing_id: e.sharing_id,
                type_id: parseInt(e.id, 10),
                sort_info: Ext.apply({
                    sort_by: "title",
                    sort_direction: "asc"
                }, e.sort_info)
            });
            var n = {
                video_id: parseInt(i.video_id, 10),
                type: i.type,
                file_id: parseInt(i.file_id, 10),
                title: i.title,
                path: i.path,
                symlink: i.symlink,
                drive_path: i.drive_path
            };
            this.video_list.init(n, t)
        },
        requestTranscodeCapability: function(t) {
            if (_S("demo_mode")) return this.support_remux = !1, this.support_transcode = !1, this.support_hardware_transcode = !1, void SYNO.VideoController2.Util.tryCallback(t);
            var e = {
                api: "SYNO.VideoStation.Info",
                method: "getinfo",
                version: 1,
                scope: this,
                params: {},
                callback: function(e, i, n, o) {
                    e ? (Ext.apply(this, i), this.fireEvent("capabilityready", this.support_transcode, this.support_remux), SYNO.VideoController2.Util.tryCallback(t)) : this.onAPIError.apply(this, arguments)
                }
            };
            SYNO.VideoController2.Util.applySharingID(e.params), SYNO.API.Request(e)
        },
        requestPlayerList: function(t) {
            if (_S("demo_mode") || SYNO.VideoController2.Util.isVideoControllerOnly()) return this.player_list = [], void SYNO.VideoController2.Util.tryCallback(t);
            this.player_store = new SYNO.VideoController2.PlayerStore({
                appWindow: this.appWin
            }), this.player_store.load({
                scope: this,
                callback: function(e, i, n, o) {
                    e && (this.player_list = [], this.player_store.each(function(t) {
                        this.player_list.push(t.data)
                    }, this), this.fireEvent("playerlistchange", this.player_list), SYNO.VideoController2.Util.tryCallback(t))
                }
            })
        },
        initSequenceVideo: function() {
            var t = this.initSequenceVideo.createDelegate(this);
            return Ext.isObject(this.video_list) && this.video_list.loaded ? (this.fireEvent("videolistready"), Ext.isBoolean(this.support_remux) ? Ext.isArray(this.player_list) ? (this.fireEvent("clear"), void this.onReadyToPlay()) : void this.requestPlayerList(t) : void this.requestTranscodeCapability(t)) : void this.loadVideoList(t)
        },
        flashPlayer: function() {
            return new SYNO.VideoController2.FlashPlayer({
                controller: this
            })
        },
        html5Player: function() {
            return new SYNO.VideoController2.HTML5Player({
                controller: this
            })
        },
        hlsPlayer: function() {
            return new SYNO.VideoController2.HLSPlayer({
                controller: this
            })
        },
        getChromecastPlayer: function() {
            return this.chromecast_player ? this.chromecast_player : (this.chromecast_player = new SYNO.VideoController2.ChromecastPlayer({
                controller: this
            }), this.chromecast_player)
        },
        onReadyToPlay: function() {
            var t = function() {
                if (SYNO.VideoController2.Util.isPublicSharing()) {
                    var t = this.video_list.getCurrentVideo();
                    location.hash = "!" + btoa(t.type + "-" + t.video_id)
                }
                this.fireEvent("clear"), this.audio_id = this.init_audiotrack_id || this.video_list.getDefaultAudioID(), this.subtitle_id = this.init_subtitle_id || this.subtitle_id, this.init_audiotrack_id = null, this.init_subtitle_id = null, this.fireEvent("videochange", this.video_list.hasPrev(), this.video_list.hasNext(), this.video_list.getCurrentVideo(), this.video_list.getAudioTrack(), this.video_list.getSubtitleList()), this.subtitle_decided = !1, this.fireEvent("titlechange", this.video_list.getName()), Ext.isEmpty(this.init_player_id) ? this.checkUpnextVideo() : this.appWin.getSettingsMenu().getPlayerPanel().setInitItem(this.init_player_id), this.video_list.hasNext() && this.video_list.getNextVideo().getInfo(Ext.emptyFn), this.fireEvent("discoverchange", !1), this.player_info.id === SYNO.VideoController2.Util.STREAMING_ID && this.video_list.canDiscoverSubtitle() && this.subtitle_manager.getDiscoverRequest(this.video_list.getFileUniqueKey())
            }.createDelegate(this);
            this.video_list.getCurrentVideo().isAllFetched() ? SYNO.VideoController2.Util.tryCallback(t) : (this.fireEvent("busy"), this.video_list.getCurrentVideo().getInfo(t))
        },
        playCurrentVideo: function() {
            SYNO.VideoController2.ControlPanelButtonStatus.get().setDefaultButtons(), SYNO.VideoController2.ControlPanelButtonStatus.get().setVolume(!0 === this.player_info.volume_adjustable), this.checkResumeVideo()
        },
        checkUpnextVideo: function() {
            var t = this.video_list.getCurrentVideo();
            if (this.is_after_playback && !this.is_target_change) {
                var e = SYNO.VideoController2.Util.getImageURL(t.video_id, t.type);
                this.appWin.getUpnextView().confirmPlayNextVideo(this.play.createDelegate(this)), this.appWin.getHeaderPanel().setPoster(e)
            } else this.play()
        },
        checkResumeVideo: function() {
            var t = this.video_list.getCurrentVideo().getResumePosition(this.force_resume);
            if (!Ext.isNumber(t)) return this.start_position = 0, void this.playVideo();
            if (this.force_resume) return this.start_position = t, void this.playVideo();
            if (this.repeat !== SYNO.VideoController2.Util.REPEAT_NONE) return this.start_position = 0, void this.playVideo();
            if (this.is_after_playback) return this.start_position = 0, void this.playVideo();
            var e = {
                title: _T("video_player", "title"),
                msg: _VCT("controller", "resume_watch_desc"),
                buttons: Ext.MessageBox.YESNO,
                scope: this,
                fn: function(e) {
                    this.start_position = "no" === e ? 0 : t, this.playVideo()
                }
            };
            this.appWin.getMsgBox().show(e), this.appWin.hidePanels()
        },
        playVideo: function() {
            if (this.updateAfterPlaybackAction(), this.isRemoteMode()) {
                var t = this.isChromecast(),
                    e = t ? this.playChromecast.createDelegate(this) : this.playRemote.createDelegate(this);
                this.player_info.password_protected ? this.checkPassword(e) : e()
            } else this.playStreaming()
        },
        rotateVideo: function() {
            var t = this.video_list.getCurrentVideo();
            if (!(Ext.isChrome || Ext.isSafari || Ext.isGecko || 0 === t.rotation || null !== this.profile || SYNO.VideoController2.Util.isWindows10EdgeIE())) {
                var e = 1,
                    i = this.video.dom,
                    n = this.getPlayer().player,
                    o = t.rotation;
                n && (e = t.resolution.width < t.resolution.height ? 90 === Math.abs(o % 180) ? i.offsetHeight / n.offsetWidth : 1 : 90 === Math.abs(o % 180) ? i.offsetWidth / n.offsetHeight : 1, this.getPlayer().player.style.transform = "rotate(" + o + "deg) scale(" + e + ")")
            }
        },
        getErrorPlayMessage: function() {
            var t = SYNO.VideoController2.Util.isMobile(),
                e = !t && !Ext.isMac,
                i = SYNO.VideoController2.Util.isVLCSupported(),
                n = _T("video_player", "error_play");
            return e && (n = i ? _VCT("video_player", "error_play_pc") : _VCT("video_player", "error_play_other_browser_or_desktop_vlc")), n
        },
        tryStreamingPlayerFn: function(t, e) {
            return function(i, n) {
                Ext.isFunction(t) && !t() || this.selectPlayer(e).getName() !== e ? n() : i({
                    name: e
                })
            }.bind(this)
        },
        tryHTML5HLS: function() {
            return new Promise(this.tryStreamingPlayerFn(SYNO.VideoController2.Util.isMacSafari, "HTML5"))
        },
        tryFlash: function() {
            return new Promise(this.tryStreamingPlayerFn(null, "Flash"))
        },
        tryHLS: function(t) {
            return t ? Promise.reject() : new Promise(this.tryStreamingPlayerFn(null, "HLS"))
        },
        tryRawPlayer: function() {
            return new Promise(function(t, e) {
                Ext.isString(this.profile) && e(), this.updateToRawPlayer();
                var i = this.getPlayer().getName();
                "Null" === i || this.audio_id !== this.video_list.getDefaultAudioID() && -1 !== this.audio_id ? e() : t({
                    name: i,
                    raw: !0
                })
            }.bind(this))
        },
        tryStreamingPlayer: function() {
            var t = SYNO.VideoController2.Util.isWindows10EdgeIE();
            return this.tryRawPlayer().catch(this.tryHTML5HLS.bind(this)).catch(this.tryHLS.bind(this, t)).catch(this.tryFlash.bind(this)).catch(this.tryHLS.bind(this, !t))
        },
        playStreaming: function() {
            this.setFHDHighBitrateEnabled(this.is4KVideo(this.video_list.getResolution())), this.setRawDisabled(!this.ableToPlayRawQuality()), this.tryStreamingPlayer().then(function(t) {
                this.onPlayerDecided("VLC" === t.name), !0 === t.raw ? this.playRawVideo() : this.playTranscodeVideo()
            }.bind(this)).catch(function() {
                this.onPlayerDecided(!1), this.onErrorOccur(this.getErrorPlayMessage())
            }.bind(this))
        },
        updateToRawPlayer: function() {
            var t = this.video_list.getTitle(),
                e = this.video_list.getCodecInfo();
            this.updatePlayer({
                filename: t,
                codec: e.video_codec
            }), "VLC" !== this.getPlayer().getName() && SYNO.VideoController2.Util.isMP4Container(e.container_type) && !SYNO.VideoController2.Util.isWebPlayableMP4(e.video_codec, this.video_list.getDefaultAudioCodec()) && this.selectPlayer("VLC")
        },
        ableToPlayRawQuality: function() {
            this.updateToRawPlayer();
            var t = "Null" !== this.getPlayer().getName(),
                e = !1;
            return ("Flash" === this.selectPlayer("Flash").getName() || "HLS" === this.selectPlayer("HLS").getName() || SYNO.VideoController2.Util.isMacSafari() && "HTML5" === this.selectPlayer("HTML5").getName()) && (e = this.getPlayer().ableToRemux(this.video_list.getCodecInfo(), this.video_list.getResolution())), t || e
        },
        playRawVideo: function() {
            var t = Ext.apply(SYNO.VideoController2.SharingHelper.getRawVideoParam(this.video_list.getFileParams()), {
                pin: this._pin_manager.getPinCode()
            });
            SYNO.VideoController2.Util.applySharingID(t), this.sendStreamingOpen(t)
        },
        playTranscodeVideo: function() {
            var t = this.profile,
                e = this.audio_id,
                i = this.video_list.getCodecInfo(),
                n = this.getPlayer().ableToRemux(i, this.video_list.getResolution()),
                o = this.getPlayer().ableToTranscode();
            if (!n && !o) return void this.onErrorOccur(String.format(_VCT("controller", "unsupported_format"), this.player_info.title));
            var r = !n || Ext.isString(t) ? "hls" : "hls_remux",
                l = this.video_list.getFileParams(),
                s = {
                    hls_header: this.canUseHlsHeader(r)
                };
            Ext.isString(t) ? s.profile = t : "hls" === r && (s.profile = this.getTranscodeDefaultProfile()), Ext.isNumber(e) && (s.audio_track = e), this.isChromecast() && -1 !== i.audio_codec.indexOf("ac3") && this.getChromecastPlayer().enable_ac3_passthrough && (s.audio_format = "ac3_copy"), "HLS" === this.getPlayer().getName() && SYNO.VideoController2.Util.isWindows10EdgeIE() && (s.audio_format = "aac"), this.isChromecast() && (s.device = "chromecast"), "hls_remux" === r && "Flash" === this.getPlayer().getName() && (s.use_pre_analysis = !1);
            var a = SYNO.VideoController2.SharingHelper.getTranscodeVideoParam(l, r, s);
            Ext.apply(a, {
                pin: this._pin_manager.getPinCode()
            }), SYNO.VideoController2.Util.applySharingID(a), this.sendStreamingOpen(a)
        },
        canUseHlsHeader: function(t) {
            var e = this.isChromecast(),
                i = SYNO.VideoController2.Util.isMacSafari() && "HTML5" === this.getPlayer().getName(),
                n = "hls" === t;
            return !(e || i && n)
        },
        inTranscodingHandler: function(t, e, i) {
            var n = SYNO.VideoController2.Util.getErrorString(t, i);
            return new Promise(function(t, i) {
                this.appWin.getMsgBox().confirm(_T("video_player", "title"), n, function(n) {
                    "yes" == n ? t(SYNO.VideoController2.SharingHelper.getForceOpenVTEParam(e)) : i(String.format(_VCT("controller", "in_transcoding"), this.player_info.title))
                }, this)
            }.bind(this))
        },
        pinCodeErrorHandler: function(t, e) {
            return this._pin_manager.requestPinCode(SYNO.VideoController2.Util.getErrorCode(t)).then(function(t) {
                return Ext.apply(e, {
                    pin: t
                })
            }).catch(function() {
                throw this._pin_manager.clearPinCode(), _VCT("parental_control", "enter_pin_description")
            }.bind(this))
        },
        handleOpenFailed: function(t, e, i) {
            var n = t.code,
                o = i.params.api;
            return SYNO.VideoController2.Constant.ERROR_CODE_OFFLINE_CONVERTING_CONFIRM === n || SYNO.VideoController2.Constant.ERROR_CODE_OFFLINE_CONVERTING_BLOCK === n || SYNO.VideoController2.Constant.ERROR_CODE_OFFLINE_CONVERTING_BLOCK_LEGACY === n || SYNO.VideoController2.Constant.ERROR_CODE_OFFLINE_CONVERTING_CONFIRM_LEGACY === n ? this.inTranscodingHandler(t, e, o) : SYNO.VideoController2.Util.isPublicSharing() && SYNO.VideoController2.Util.isMobile() && SYNO.VideoController2.Constant.ERROR_CODE_PIN_CODE_REQUIRED === n ? Promise.reject(SYNO.VideoController2.Util.systemErrorString(105)) : SYNO.VideoController2.Constant.ERROR_CODE_PIN_CODE_REQUIRED === n || SYNO.VideoController2.Constant.ERROR_CODE_PIN_CODE_WRONG === n ? this.pinCodeErrorHandler(t, e) : Promise.reject(String.format(SYNO.VideoController2.Util.getErrorString(t, o), this.player_info.title))
        },
        prepareStreamTid: function() {
            return SYNO.VideoController2.Util.isPublicSharing() ? Promise.resolve() : SYNO.VideoController2.Util.prepareTicketId("SYNO.VideoStation2.Streaming", ["stream"]).then(function(t) {
                this.tid = t.tid
            }.bind(this))
        },
        sendStreamingOpen: function(t) {
            return SYNO.VideoController2.Util.isMobile() && SYNO.VideoController2.Util.isPublicSharing() && this.stream_id ? (this.getPlayer().setStartPosition(this.start_position), this.getPlayer().play(), void(this.force_resume = !1)) : (this.fireEvent("busy"), this.prepareStreamTid().then(this.hls_handler.openStream.bind(this, t)).then(this.onStreamingReady.bind(this)).catch(function(t) {
                this.fireEvent("clear"), this.handleOpenFailed(t[0], t[1], t[2]).then(function(t) {
                    return this.sendStreamingOpen(SYNO.Util.copy(t))
                }.bind(this)).catch(this.onErrorOccur.bind(this))
            }.bind(this)))
        },
        onStreamingReady: function(t) {
            this.fireEvent("clear"), this.stream_id = t.stream_id, this.stream_format = t.format;
            var e = SYNO.VideoController2.Util.getFileExt(this.video_list.getTitle()),
                i = SYNO.VideoController2.Util.getStreamURL(this.stream_id, this.stream_format, e, this.tid);
            if ("raw" === this.stream_format) this.appWin.setVideoDisplayHeight(), this.rotateVideo();
            else if ("Flash" === this.getPlayer().getName()) {
                var n = this.video_list.getDisplayResolution();
                i = SYNO.VideoController2.Util.getExtM3U(n.width, n.height, i)
            }
            this.getPlayer().setStartPosition(this.start_position), this.getPlayer().play(i), this.force_resume = !1
        },
        checkPassword: function(t) {
            SYNO.API.Request({
                api: "SYNO.VideoStation2.Controller.Password",
                method: "test",
                version: 1,
                params: {
                    device_id: this.player_info.id
                },
                scope: this,
                callback: function(e, i, n, o) {
                    e ? i.correct ? SYNO.VideoController2.Util.tryCallback(t) : this.promptPasswordDialog(t) : this.onAPIError.apply(this, arguments)
                }
            })
        },
        promptPasswordDialog: function(t) {
            var e = {
                owner: this.appWin,
                correctCallback: t,
                player_title: this.player_info.title,
                player_id: this.player_info.id,
                controller: this
            };
            new SYNO.VideoController2.PasswordDialog(e).show()
        },
        playRemote: function() {
            this.onPlayerDecided(!1);
            var t = {
                controller: this,
                id: this.player_info.id,
                type: this.player_info.type,
                volume_adjustable: this.player_info.volume_adjustable,
                seekable: this.player_info.seekable,
                file_id: this.video_list.getFileUniqueKey(),
                title: this.video_list.getTitle(),
                profile: this.profile
            };
            Ext.isEmpty(this.subtitle_id) || this.subtitle_id === SYNO.VideoController2.Util.SUBTITLE_NONE || (t.subtitle_id = this.subtitle_id), Ext.isEmpty(this.subtitle_codepage) || (t.subtitle_codepage = this.subtitle_codepage), this.audio_id !== this.video_list.getDefaultAudioID() && (t.audio_id = this.audio_id);
            var e = this.video_list.getCodecInfo(),
                i = this.video_list.getResolution();
            this.player = new SYNO.VideoController2.RemotePlayer(t), this.setFHDHighBitrateEnabled(!1), this.setRawDisabled(!this.player.ableToPlayRaw(e, i) && !this.player.ableToRemux(e, i)), this.getPlayer().setStartPosition(this.start_position), this.player.play(), this.force_resume = !1
        },
        playChromecast: function() {
            this.player = this.getChromecastPlayer();
            var t = this.video_list.getCodecInfo(),
                e = this.video_list.getResolution();
            this.setFHDHighBitrateEnabled(this.is4KVideo(e)), this.setRawDisabled(!this.player.ableToPlayRaw(t, e) && !this.player.ableToRemux(t, e)), this.onPlayerDecided(!1), !Ext.isString(this.profile) && this.audio_id === this.video_list.getDefaultAudioID() && this.getPlayer().ableToPlayRaw(t, e) ? this.playRawVideo() : this.playTranscodeVideo()
        },
        unlink: function() {
            Ext.isObject(this.init_video_info) && Ext.isString(this.init_video_info.symlink) && this.video_list.getCurrentVideo().deleteSymLink()
        },
        updateState: function(t, e) {
            if (this.state = t, this.initPlaying || t !== SYNO.VideoController2.Util.STATE.STOPPED || (this.getPlayer().clear(), this.updateDuration(-1), this.updatePosition(-1)), !this.initPlaying || t !== SYNO.VideoController2.Util.STATE.PLAYING && t !== SYNO.VideoController2.Util.STATE.BUFFERING || (this.initPlaying = !1), t === SYNO.VideoController2.Util.STATE.ERROR && (e = Ext.isString(e) ? e : _T("video_player", "error_play")), this.onStateChange(this.state, e), t === SYNO.VideoController2.Util.STATE.CLEAR && Ext.isFunction(this.clearCallback)) {
                var i = this.clearCallback;
                this.clearCallback = null, i()
            }
        },
        toggleMute: function() {
            this.getPlayer().setMute(!this.mute)
        },
        getVolumeDelayedTask: function() {
            return this.volume_delayed_task = this.volume_delayed_task || new Ext.util.DelayedTask(function() {
                this.volume_lock = !1
            }, this), this.volume_delayed_task
        },
        updateMute: function(t) {
            this.mute = t, this.onMuteChange(this.mute)
        },
        setVolume: function(t) {
            this.getPlayer().setVolume(t), this.isRemoteMode() && (this.volume_lock = !0, this.getVolumeDelayedTask().cancel(), this.getVolumeDelayedTask().delay(3e3))
        },
        updateVolume: function(t, e) {
            this.volume = t, this.onVolumeChange(this.volume, e)
        },
        updateDuration: function(t) {
            this.duration = t, this.onTimeInit(this.position, this.duration)
        },
        seek: function(t) {
            Ext.isNumber(t) && (this.video_list.getCurrentVideo().last_watched_position = t), this.getPlayer().seek(t)
        },
        updatePosition: function(t) {
            this.position = t, this.onTimeChange(this.position, this.duration)
        },
        toggleFullscreen: function() {
            SYNO.VideoController2.Util.isFullscreen() ? SYNO.VideoController2.Util.exitFullscreen() : SYNO.VideoController2.Util.setDomFullscreen(Ext.getBody().dom)
        },
        isSubtitleVisible: function() {
            return this.subtitle_visible
        },
        setSubtitleEnabled: function(t, e) {
            this.subtitle_visible = t, this.onSubtitleChange(t, e)
        },
        getSubtitleParser: function() {
            return Ext.isDefined(this.subtitle_parser) || (this.subtitle_parser = new SYNO.VideoController2.SubtitleParser), this.subtitle_parser
        },
        stop: function(t) {
            SYNO.VideoController2.ControlPanelButtonStatus.get().resetButtons(), this.clearCallback = null;
            var e = this.getPlayer().getPosition();
            if (!Ext.isNumber(e) || e <= 0) return void this.stopActual(t);
            var i = this.stopActual.createDelegate(this, arguments);
            this.video_list.getCurrentVideo().setWatchStatus(e, i)
        },
        stopActual: function(t) {
            if (!this.getPlayer().pluginInit) return void(Ext.isFunction(t) && t());
            this.clearCallback = t, this.getPlayer().stop()
        },
        prev: function() {
            this.stop(this.goPrev.createDelegate(this))
        },
        goPrev: function(t) {
            this.video_list.goPrev(t) && (this.is_after_playback = !1, this.onReadyToPlay())
        },
        next: function() {
            this.stop(this.goNext.createDelegate(this))
        },
        goNext: function(t, e) {
            this.video_list.goNext(t) ? (this.is_after_playback = e || !1, this.is_target_change = !1, this.onReadyToPlay()) : SYNO.VideoController2.Util.isVideoControllerOnly() || this.appWin.close()
        },
        jump: function(t) {
            this.initPlaying = !1, this.stop(this.goJump.createDelegate(this, [t]))
        },
        goJump: function(t) {
            this.video_list.goJump(t) && this.onReadyToPlay()
        },
        isValidIP: function(t) {
            if (t.indexOf(".") < 0) return !1;
            var e = t.split(".");
            if (4 != e.length) return !1;
            for (var i = 0; i < e.length; i++) {
                var n = parseInt(e[i], 10);
                if (n < 0 || n > 255) return !1
            }
            return !0
        },
        isLocalNetwork: function(t) {
            for (var e = t.split("."), i = 0; i < e.length; i++) e.hasOwnProperty(i) && (e[i] = parseInt(e[i], 10));
            return 10 === e[0] || (172 === e[0] && e[1] >= 16 && e[1] <= 31 || 192 === e[0] && 168 === e[1])
        },
        getTranscodeDefaultProfile: function() {
            var t = SYNO.VideoController2.Util.QUALITY_HD_HIGH,
                e = location.hostname;
            return this.isValidIP(e) ? (this.fhd_high_bitrate_enabled && this.isLocalNetwork(e) && (t = SYNO.VideoController2.Util.QUALITY_FHD_HIGH_BITRATE), t) : (SYNO.Debug("Invalid IP: ", e), t)
        },
        setProfile: function(t) {
            t !== this.profile && (this.rawdisabled && t === this.getTranscodeDefaultProfile() && null === this.profile || (this.profile = t, this.force_resume = !0, this.stop(this.close.createDelegate(this, [this.play.createDelegate(this)]))))
        },
        close: function(t) {
            SYNO.VideoController2.Util.tryCallback(t)
        },
        setAudioTrack: function(t) {
            t !== this.audio_id && (this.audio_id = t, this.init_audiotrack_id = null, this.video_list.getCurrentVideo().setPlaybackSetting(this.subtitle_id, this.audio_id), this.force_resume = !0, this.stop(this.play.createDelegate(this)))
        },
        onPlayerDecided: function(t) {
            var e = this.video_list.getSubtitleList();
            this.fireEvent("playerdecided", e, t), this.selectUsingSubtitle(e, t)
        },
        selectSubtitle: function(t, e, i) {
            var n = !0 !== i;
            if (this.subtitle_decided = !0, this.subtitle_id = t, this.init_subtitle_id = null, this.video_list.getCurrentVideo().setPlaybackSetting(this.subtitle_id, this.audio_id), this.getPlayer().subtitle_is_srt = n, this.isRemoteMode()) {
                if (this.setSubtitleEnabled(!1, t), this.isChromecast()) {
                    var o = this.getPlayer().getSubtitleUrl(this);
                    this.getPlayer().setPlayerSubtitle(o)
                }
            } else {
                n ? this.getPlayer().disablePlayerSubtitle() : this.getPlayer().setPlayerSubtitle(parseInt(t, 10));
                var r = t !== SYNO.VideoController2.Util.SUBTITLE_NONE && n;
                r && this.subtitle_manager.requestSubtitle(this.video_list.getFileUniqueKey(), t, e, this.subtitle_codepage), this.setSubtitleEnabled(r, t)
            }
        },
        findPreviousSubtitle: function(t, e) {
            if (!this.subtitle_decided) return null;
            var i = null;
            return Ext.each(t, function(t) {
                if (t.subtitle_id === this.subtitle_id && (e || "srt" === t.format)) return i = t, !1
            }, this), i
        },
        getUsingSubtitle: function(t, e) {
            var i = {
                subtitle_id: SYNO.VideoController2.Util.SUBTITLE_NONE,
                need_preview: !1,
                format: "srt"
            };
            if (this.subtitle_id === SYNO.VideoController2.Util.SUBTITLE_NONE) return i;
            if (this.subtitle_id === SYNO.VideoController2.Util.SUBTITLE_DISCOVER) return {
                subtitle_id: SYNO.VideoController2.Util.SUBTITLE_DISCOVER,
                need_preview: !1,
                format: "srt"
            };
            var n = this.findPreviousSubtitle(t, e);
            return Ext.isObject(n) ? n : e && t.length > 0 ? t[0] : (Ext.each(t, function(t) {
                if ("srt" === t.format && this.subtitle_id === t.subtitle_id) return i = t, !1
            }, this), i)
        },
        selectUsingSubtitle: function(t, e) {
            var i = this.getUsingSubtitle(t, e);
            this.selectSubtitle(i.subtitle_id, i.need_preview, "srt" !== i.format)
        },
        setSubtitle: function(t, e, i) {
            (!this.isRemoteMode() || t !== this.subtitle_id && null !== t) && (this.selectSubtitle(t, e, i), this.isRemoteMode() && !this.isChromecast() && (this.force_resume = !0, this.stop(this.play.createDelegate(this))))
        },
        browseSubtitle: function() {
            this.getPlayer().pause();
            var t = this.video_list.getCurrentVideo(),
                e = t.sharepath.substring(0, t.sharepath.lastIndexOf("/")),
                i = new SYNO.VideoController2.BrowseSubtitleDialog({
                    appWin: this.appWin,
                    sharepath: e
                });
            i.mon(i, "choose", this.onBrowseSelect, this), i.mon(i, "cancel", this.onBrowseCancel, this), i.open()
        },
        onBrowseSelect: function(t, e, i) {
            var n = -1;
            if (this.subtitle_codepage = i[1], e && Ext.isString(e.fullpath)) {
                for (var o = this.video_list.getSubtitleList(), r = new RegExp(/[srt|ass|ssa|sami|smi]/i), l = e.fullpath.substr(e.fullpath.lastIndexOf(".") + 1), s = e.fullpath.substr(e.fullpath.lastIndexOf("/") + 1), a = {
                        embedded: !1,
                        format: r.test(l) ? "srt" : l,
                        lang: this.subtitle_codepage,
                        subtitle_id: e.fullpath,
                        title: s,
                        need_preview: !1
                    }, d = 0, h = o.length; d < h; d++)
                    if (o[d].subtitle_id === e.fullpath) {
                        n = d;
                        break
                    } - 1 !== n ? o[n] = a : o.push(a), this.appWin.getSettingsMenu().getSubtitlePanel().setList(o, e.fullpath), this.setSubtitle(e.fullpath)
            }
            t.close(), this.getPlayer().resume()
        },
        onBrowseCancel: function() {
            var t = this.video_list.getSubtitleList(),
                e = this.getUsingSubtitle(t);
            this.setSubtitle(e.subtitle_id), this.getPlayer().resume()
        },
        getDelayedTime: function() {
            return this.delayed_time
        },
        setDelayedTime: function(t) {
            this.delayed_time = t, this.getPlayer().setSubtitleDelay(this.delayed_time)
        },
        syncSubtitle: function() {
            new SYNO.VideoController2.SyncDialog({
                owner: this.appWin,
                controller: this
            }).show()
        },
        resizeSubtitle: function() {
            new SYNO.VideoController2.ResizeSubtitleDialog({
                owner: this.appWin,
                controller: this
            }).show()
        },
        openSubtitlePreference: function() {
            new SYNO.VideoController2.SubtitlePreferenceDialog({
                owner: this.appWin,
                controller: this
            }).show()
        },
        setPlayer: function(t) {
            t.id !== this.player_info.id && (this.player_info = t, this.fireEvent("targetchange", this.player_info), this.is_target_change = !0, this.force_resume = Ext.isEmpty(this.init_player_id), this.init_player_id = null, this.stop(this.play.createDelegate(this)))
        },
        toggleList: function() {
            this.getListDialog().show()
        },
        getListDialog: function() {
            if (!Ext.isDefined(this.listDialog)) {
                var t = Ext.isEmpty(this.video_list) ? null : this.video_list.getStore();
                this.listDialog = new SYNO.VideoController2.ListDialog({
                    controller: this,
                    orgStore: t
                })
            }
            return this.listDialog
        },
        setRepeat: function(t) {
            this.repeat = t, this.isChromecast() && this.getPlayer().setRepeat(this.repeat), this.updateAfterPlaybackAction()
        },
        updateAfterPlaybackAction: function() {
            var t = Ext.emptyFn;
            this.repeat === SYNO.VideoController2.Util.REPEAT_ALL ? t = this.goNext.createDelegate(this, [!0, !0]) : this.repeat === SYNO.VideoController2.Util.REPEAT_ONE ? t = this.play.createDelegate(this) : this.repeat === SYNO.VideoController2.Util.REPEAT_NONE && (t = this.goNext.createDelegate(this, [!1, !0]));
            var e = this.video_list.getCurrentVideo();
            this.clearCallback = e.setWatched.createDelegate(e, [t])
        },
        is4KVideo: function(t) {
            return !(t.width <= 1920 && t.height <= 1080)
        },
        setFHDHighBitrateEnabled: function(t) {
            this.fhd_high_bitrate_enabled = this.support_fhd_hardware_transcode && t, this.profile !== SYNO.VideoController2.Util.QUALITY_FHD_HIGH_BITRATE || this.fhd_high_bitrate_enabled || (this.profile = null), this.fireEvent("fhd_high_bitrate_enabled", this.fhd_high_bitrate_enabled)
        },
        setRawDisabled: function(t) {
            this.rawdisabled = t, this.fireEvent("rawdisabled", t, this.profile)
        },
        onSubtitleReady: function(t, e, i) {
            if (t === this.video_list.getFileUniqueKey() && e === this.subtitle_id) {
                var n = this.subtitle_manager.getSubtitle(t, e, i);
                this.getSubtitleParser().parseSrt(n), this.subtitle_manager.getOffset(t, e)
            }
        },
        onDiscoverReady: function(t) {
            this.fireEvent("discoverchange", t)
        },
        onGetOffsetSuccess: function(t) {
            this.setDelayedTime(t)
        },
        onAPIError: function(t, e, i, n) {
            if (!t) {
                var o = SYNO.VideoController2.Util.getErrorString(e, n.params.api);
                this.onErrorOccur(String.format(o, this.player_info.title))
            }
        },
        onErrorOccur: function(t) {
            SYNO.VideoController2.ControlPanelButtonStatus.get().setOpenFailedStatus(), SYNO.VideoController2.ControlPanelButtonStatus.get().enableControlPanelButtons(), this.updateState(SYNO.VideoController2.Util.STATE.ERROR, t)
        },
        isRemoteMode: function() {
            return this.player_info.type !== SYNO.VideoController2.Util.PLAYERTYPE_STREAMING
        },
        isChromecast: function() {
            return this.player_info.type === SYNO.VideoController2.Util.PLAYERTYPE_CHROMECAST
        },
        searchSubtitle: function() {
            this.getPlayer().pause(), this.promptSubtitleDialog()
        },
        promptSubtitleDialog: function() {
            var t = {
                owner: this.appWin,
                unique_key: this.video_list.getFileUniqueKey(),
                controller: this
            };
            new SYNO.VideoController2.SubtitleDialog(t).show()
        },
        setDownloadedSubtitle: function(t, e) {
            t && (this.setSubtitle(t), !1 !== e && this.reloadSubtitleList(t)), this.getPlayer().resume()
        },
        reloadSubtitleList: function(t) {
            var e = this;
            this.video_list.getCurrentVideo().loadSubtitleStore(function() {
                e.onPlayerDecided("VLC" === e.getPlayer().getName()), e.selectSubtitle(t)
            })
        },
        seekInterval: function(t) {
            var e = this.position + t;
            e < 0 && (e = 0), e > this.duration && (e = this.duration), this.seek(e)
        },
        adjustVolume: function(t) {
            if (!this.mute && this.player_info.volume_adjustable) {
                var e = this.volume + t;
                e < 0 && (e = 0), e > 100 && (e = 100), this.setVolume(e), this.updateVolume(e, !0)
            }
        },
        updateWatchedPosition: function(t) {
            Ext.isObject(this.video_list) && this.video_list.loaded && this.video_list.getCurrentVideo().updateWatchedPosition(t)
        },
        createScreenshot: function() {
            this.screenshot_creating = !0, this.onScreenshotStateChange(SYNO.VideoController2.Util.SCREENSHOT_CREATE, _VCT("controller", "screenshot_create"));
            var t = this.video_list.getCurrentVideo().getFileParams();
            if (!Ext.isDefined(t.symlink) && !Ext.isDefined(t.drive_path)) {
                var e = parseInt(100 * this.position),
                    i = {
                        time: e
                    };
                Ext.apply(i, t), SYNO.API.Request({
                    api: "SYNO.VideoStation2.Screenshot",
                    method: "create",
                    version: 1,
                    params: i,
                    scope: this,
                    callback: function(t, e, i, n) {
                        if (t) this.onScreenshotStateChange(SYNO.VideoController2.Util.SCREENSHOT_DONE, _VCT("common", "done"));
                        else {
                            var o = SYNO.VideoController2.Util.getErrorString(e, n.params.api);
                            this.onScreenshotStateChange(SYNO.VideoController2.Util.SCREENSHOT_FAILED, o)
                        }
                        this.screenshot_creating = !1
                    }
                })
            }
        },
        supportRemux: function() {
            return !0 === this.support_remux
        },
        supportTranscode: function() {
            return !0 === this.support_transcode
        },
        isScreenshotCreating: function() {
            return !0 === this.screenshot_creating
        },
        isSupportFullscreen: function() {
            if (this.isRemoteMode()) return !1;
            if (SYNO.VideoController2.Util.isIos() && SYNO.VideoController2.Util.isHTML5Base(this.getPlayer().getName())) {
                var t = document.getElementsByTagName("video")[0];
                return t && t.webkitSupportsFullscreen
            }
            return SYNO.VideoController2.Util.isDomFullscreenSupported()
        }
    }), Ext.define("SYNO.VideoController2.PlayButton", {
        extend: "SYNO.VideoController2.Button",
        constructor: function(t) {
            var e = {
                disabled: !0
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("play")
        },
        clickHandler: function() {
            this.getController().play()
        }
    }), Ext.define("SYNO.VideoController2.PrevButton", {
        extend: "SYNO.VideoController2.Button",
        constructor: function(t) {
            var e = {
                disabled: !0,
                hidden: !0
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("prev")
        },
        clickHandler: function() {
            this.getController().prev()
        }
    }), Ext.define("SYNO.VideoController2.NextButton", {
        extend: "SYNO.VideoController2.Button",
        constructor: function(t) {
            var e = {
                disabled: !0,
                hidden: !0
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("next")
        },
        clickHandler: function() {
            this.getController().next()
        }
    }),
    Ext.define("SYNO.VideoController2.ControlsBar", {
        extend: "Ext.Container",
        constructor: function(t) {
            this.module = t.module;
            var e = {
                items: [this.getPrevButton(), this.getPlayButton(), this.getNextButton()]
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("syno-vc-controls-bar"), this.mon(SYNO.VideoController2.ControlPanelButtonStatus.get(), SYNO.VideoController2.ControlPanelButtonStatus.EVENT_ENABLE_CONTROLPANEL_BUTTONS, this.setButtonsEnabled, this), this.mon(SYNO.VideoController2.ControlPanelButtonStatus.get(), SYNO.VideoController2.ControlPanelButtonStatus.EVENT_SET_PLAY_DISABLED, this.setPlayDisabled, this)
        },
        setButtonsEnabled: function() {
            var t = SYNO.VideoController2.ControlPanelButtonStatus.get();
            this.getPlayButton().setDisabled(!t.play);
            var e = t.has_prev,
                i = t.has_next,
                n = e || i;
            n && (this.getPrevButton().setDisabled(!e), this.getPrevButton().setVisible(n), this.getNextButton().setDisabled(!i), this.getNextButton().setVisible(n))
        },
        resetButtons: function() {
            this.items.each(function(t) {
                t.setDisabled(!0)
            }, this)
        },
        setPlayDisabled: function() {
            this.getPlayButton().setDisabled(!SYNO.VideoController2.ControlPanelButtonStatus.get().play)
        },
        getPlayButton: function() {
            return Ext.isDefined(this.play_button) || (this.play_button = new SYNO.VideoController2.PlayButton({
                module: this.module
            })), this.play_button
        },
        getPrevButton: function() {
            return Ext.isDefined(this.prev_button) || (this.prev_button = new SYNO.VideoController2.PrevButton({
                module: this.module
            })), this.prev_button
        },
        getNextButton: function() {
            return Ext.isDefined(this.next_button) || (this.next_button = new SYNO.VideoController2.NextButton({
                module: this.module
            })), this.next_button
        }
    }), Ext.define("SYNO.VideoController2.AudiotrackPanel", {
        extend: "SYNO.VideoController2.MenuPanel",
        constructor: function(t) {
            var e = {
                title: _VCT("options", "audio_track"),
                itemId: "audiotrack"
            };
            this.callParent([Ext.apply(e, t)])
        },
        setList: function(t, e) {
            this.setDefault(e), this.removeItems(), this.addAvailableAudioTrack(t, e), this.loadItems(), this.setItemSelected(e)
        },
        addAvailableAudioTrack: function(t, e) {
            Ext.each(t, function(t) {
                var e = t.language,
                    i = String.format("#{0}{1} ({2})", t.track, 0 >= e.length ? "" : " - " + e, t.codec);
                this.addItem(t.id, i, this.selectAudioTrack.createDelegate(this, [t.id]), !0)
            }, this)
        },
        selectAudioTrack: function(t) {
            this.module.getController().setAudioTrack(t)
        }
    }), Ext.define("SYNO.VideoController2.PlayerPanel", {
        extend: "SYNO.VideoController2.MenuPanel",
        constructor: function(t) {
            var e = {
                title: _VCT("controller", "tooltip_player"),
                itemId: "player"
            };
            this.callParent([Ext.apply(e, t)]), this.addStreamingPlayer(), this.loadItems()
        },
        setList: function(t, e) {
            this.setDefault(e), this.removeItems(), this.addStreamingPlayer(), SYNO.VideoController2.ChromecastPlayer.isCastAvailable() && this.addChromecastPlayer(), this.addRemotePlayers(t), this.loadItems()
        },
        addStreamingPlayer: function() {
            this.addItem(SYNO.VideoController2.Util.PLAYERTYPE_STREAMING, _VCT("controller", "streaming_mode"), this.selectStreamingPlayer.createDelegate(this), !0)
        },
        addChromecastPlayer: function() {
            this.addItem(SYNO.VideoController2.Util.PLAYERTYPE_CHROMECAST, _VCT("controller", "chromecast_mode"), this.selectChromecastPlayer.createDelegate(this), !1)
        },
        addRemotePlayers: function(t) {
            Ext.each(t, function(t) {
                this.addItem(t.id, t.title, this.selectPlayer.createDelegate(this, [t]), !0)
            }, this)
        },
        selectPlayer: function(t) {
            this.module.getController().setPlayer(t), this.setItemSelected(t.id)
        },
        selectStreamingPlayer: function() {
            var t = {
                id: SYNO.VideoController2.Util.STREAMING_ID,
                type: SYNO.VideoController2.Util.PLAYERTYPE_STREAMING,
                title: _VCT("controller", "streaming_mode"),
                volume_adjustable: !0,
                password_protected: !1,
                seekable: !0
            };
            this.selectPlayer(t)
        },
        selectChromecastPlayer: function() {
            var t = {
                id: SYNO.VideoController2.Util.CHROMECAST_ID,
                type: SYNO.VideoController2.Util.PLAYERTYPE_CHROMECAST,
                title: _VCT("controller", "chromecast_mode"),
                password_protected: !1,
                volume_adjustable: !0,
                seekable: !0
            };
            (SYNO.VideoController2.ChromecastPlayer.SESSION ? Promise.resolve() : SYNO.VideoController2.ChromecastPlayer.init().then(function() {
                return SYNO.VideoController2.ChromecastPlayer.launchCast()
            })).then(this.selectPlayer.bind(this, t))
        }
    }), Ext.define("SYNO.VideoController2.QualityPanel", {
        extend: "SYNO.VideoController2.MenuPanel",
        constructor: function(t) {
            var e = {
                title: _VCT("controller", "playback_quality"),
                itemId: "quality"
            };
            this.callParent([Ext.apply(e, t)]), this.setList(), this.transcode_disable = !0, this.fhd_high_bitrate_enable = !1
        },
        setList: function() {
            this.removeItems(), this.addRaw(), this.addFHDHighBitrate(), this.addHigh(), this.addMedium(), this.addLow(), this.loadItems()
        },
        addRaw: function() {
            this.addItem(SYNO.VideoController2.Util.QUALITY_RAW, _VCT("controller", "quality_raw"), this.selectProfile.createDelegate(this, [SYNO.VideoController2.Util.QUALITY_RAW]), !0, this.raw_disable, !0)
        },
        addFHDHighBitrate: function() {
            this.addItem(SYNO.VideoController2.Util.QUALITY_FHD_HIGH_BITRATE, _VCT("controller", "quality_fhd_high_bitrate"), this.selectProfile.createDelegate(this, [SYNO.VideoController2.Util.QUALITY_FHD_HIGH_BITRATE]), !0, this.transcode_disable, this.fhd_high_bitrate_enable)
        },
        addHigh: function() {
            this.addItem(SYNO.VideoController2.Util.QUALITY_HD_HIGH, _VCT("controller", "quality_high"), this.selectProfile.createDelegate(this, [SYNO.VideoController2.Util.QUALITY_HD_HIGH]), !0, this.transcode_disable, !0)
        },
        addMedium: function() {
            this.addItem(SYNO.VideoController2.Util.QUALITY_HD_MEDIUM, _VCT("controller", "quality_medium"), this.selectProfile.createDelegate(this, [SYNO.VideoController2.Util.QUALITY_HD_MEDIUM]), !0, this.transcode_disable, !0)
        },
        addLow: function() {
            this.addItem(SYNO.VideoController2.Util.QUALITY_HD_LOW, _VCT("controller", "quality_low"), this.selectProfile.createDelegate(this, [SYNO.VideoController2.Util.QUALITY_HD_LOW]), !0, this.transcode_disable, !0)
        },
        selectProfile: function(t) {
            this.module.getController().setProfile(t), this.setItemSelected(t)
        },
        setRawDisabled: function(t) {
            this.raw_disable = t, this.setItemDisable(SYNO.VideoController2.Util.QUALITY_RAW, t)
        },
        setTranscodeDisabled: function(t) {
            this.transcode_disable = t
        },
        setFHDHighBitrateEnabled: function(t) {
            this.fhd_high_bitrate_enable = t, this.setItemVisible(SYNO.VideoController2.Util.QUALITY_FHD_HIGH_BITRATE, this.fhd_high_bitrate_enable)
        }
    }), Ext.define("SYNO.VideoController2.RepeatPanel", {
        extend: "SYNO.VideoController2.MenuPanel",
        constructor: function(t) {
            var e = {
                title: _VCT("controller", "repeat_mode"),
                itemId: "repeat"
            };
            this.callParent([Ext.apply(e, t)]), this.setDefault(SYNO.VideoController2.Util.REPEAT_NONE), this.setList()
        },
        setList: function() {
            this.removeItems(), this.addRepeatNone(), this.addRepeatAll(), this.addRepeatOne(), this.loadItems()
        },
        addRepeatNone: function() {
            this.addItem(SYNO.VideoController2.Util.REPEAT_NONE, _VCT("controller", "repeat_none"), this.selectRepeatMode.createDelegate(this, [SYNO.VideoController2.Util.REPEAT_NONE]), !0)
        },
        addRepeatAll: function() {
            this.addItem(SYNO.VideoController2.Util.REPEAT_ALL, _VCT("controller", "repeat_all"), this.selectRepeatMode.createDelegate(this, [SYNO.VideoController2.Util.REPEAT_ALL]), !0)
        },
        addRepeatOne: function() {
            this.addItem(SYNO.VideoController2.Util.REPEAT_ONE, _VCT("controller", "repeat_one"), this.selectRepeatMode.createDelegate(this, [SYNO.VideoController2.Util.REPEAT_ONE]), !0)
        },
        selectRepeatMode: function(t) {
            this.module.getController().setRepeat(t)
        }
    }), Ext.define("SYNO.VideoController2.SubtitlePanel", {
        extend: "SYNO.VideoController2.MenuPanel",
        constructor: function(t) {
            var e = {
                title: _VCT("options", "subtitle"),
                itemId: "subtitle"
            };
            this.callParent([Ext.apply(e, t)])
        },
        setList: function(t, e) {
            this.removeItems(), this.addNoneSubtitle(), this.addAvailableSubtitles(t, e), this.addDiscoverSubtitle(t), this.addSearchItem(), this.addBrowseItem(), this.addSyncItem(), this.addPreferenceItem(), this.loadItems()
        },
        addNoneSubtitle: function() {
            this.addItem(SYNO.VideoController2.Util.SUBTITLE_NONE, _VCT("controller", "no_subtitle"), this.selectSubtitle.createDelegate(this, [SYNO.VideoController2.Util.SUBTITLE_NONE]), !0)
        },
        addDiscoverSubtitle: function(t) {
            var e = this.module.getController();
            e.video_list && e.player_info.id === SYNO.VideoController2.Util.STREAMING_ID && e.video_list.canDiscoverSubtitle() && this.addItem(SYNO.VideoController2.Util.SUBTITLE_DISCOVER, _VCT("controller", "discover_subtitle"), this.selectSubtitle.createDelegate(this, [SYNO.VideoController2.Util.SUBTITLE_DISCOVER]), !0)
        },
        addSearchItem: function() {
            SYNO.VideoController2.Util.isPublicSharing() || this.addItem(SYNO.VideoController2.Util.SUBTITLE_SEARCH, _VCT("controller", "search_subtitle"), this.searchSubtitle.createDelegate(this), !1)
        },
        addBrowseItem: function() {
            SYNO.VideoController2.Util.isPublicSharing() || this.addItem(SYNO.VideoController2.Util.SUBTITLE_BROWSE, _VCT("controller", "browse_subtitle"), this.browseSubtitle.createDelegate(this), !1)
        },
        addSyncItem: function() {
            var t = this.module.getController();
            t.isRemoteMode() && !t.isChromecast() || this.addItem(SYNO.VideoController2.Util.SUBTITLE_SYNC, _VCT("controller", "shift_subtitle"), this.syncSubtitle.createDelegate(this), !1)
        },
        addPreferenceItem: function() {
            !this.module.getController().isChromecast() && this.module.getController().isRemoteMode() || this.addItem(SYNO.VideoController2.Util.SUBTITLE_PREFERENCE, _VCT("controller", "subtitle_preference"), this.openSubtitlePreference.createDelegate(this), !1)
        },
        addAvailableSubtitles: function(t, e) {
            var i = [];
            Ext.each(t, function(t) {
                var n = t.format.toLowerCase();
                if (!this.supportedSubtitle(n, e)) return !0;
                i.push(this.convertSubtitleItem(t))
            }, this), i.sort(function(t, e) {
                return (t.embedded ? 2 : 0) + (t.display < e.display ? 0 : 1) - ((e.embedded ? 2 : 0) + (t.display > e.display ? 0 : 1))
            }), Ext.each(i, function(t) {
                this.addItem(t.subtitle_id, t.display, this.selectSubtitle.createDelegate(this, [t.subtitle_id, t.need_preview, !t.is_srt]), !0)
            }, this)
        },
        convertSubtitleItem: function(t) {
            var e, i = SYNO.Util.copy(t),
                n = t.format.toLowerCase(),
                o = "srt" === n,
                r = t.lang.toLowerCase();
            return !1 === t.embedded ? (e = "" === t.title ? _VCT("controller", "external_subtitle") : t.title, e += r.length > 0 ? " - " + r : "") : (e = Ext.isEmpty(t.title) ? Ext.isEmpty(r) ? String.format("Subtitle Track #{0}", t.subtitle_id) : r : t.title, o || (e += String.format(" ({0})", n))), i.is_srt = o, i.display = e || "", i
        },
        selectSubtitle: function(t, e, i) {
            this.module.getController().setSubtitle(t, e, i)
        },
        searchSubtitle: function() {
            this.module.getController().searchSubtitle(), this.module.getOptionsBar().getSettingsButton().hideMenu()
        },
        browseSubtitle: function() {
            this.module.getController().browseSubtitle(), this.module.getOptionsBar().getSettingsButton().hideMenu()
        },
        syncSubtitle: function() {
            this.module.getController().syncSubtitle(), this.module.getOptionsBar().getSettingsButton().hideMenu()
        },
        openSubtitlePreference: function() {
            this.module.getController().openSubtitlePreference(), this.module.getOptionsBar().getSettingsButton().hideMenu()
        },
        supportedSubtitle: function(t, e) {
            return !!Ext.isString(t) && (e ? -1 !== ["srt", "pgs", "dvdsub"].indexOf(t) : "srt" === t)
        }
    }), Ext.define("SYNO.VideoController2.SettingsMenu", {
        extend: "SYNO.ux.Panel",
        constructor: function(t) {
            this.module = t.module;
            var e = {
                header: !0,
                title: _VCT("action", "settings"),
                cls: "vc-setting-panel",
                layout: "accordion",
                layoutConfig: {
                    titleCollapse: !0,
                    animate: !0
                },
                items: [this.getQualityPanel(), this.getAudioTrackPanel(), this.getSubtitlePanel(), this.getPlayerPanel(), this.getRepeatPanel()],
                listeners: {
                    scope: this,
                    afterrender: function() {
                        var t = this.getComponent("subtitle");
                        this.getLayout().setActiveItem(t), this.setMenuHeight()
                    }
                }
            };
            this.callParent([Ext.apply(e, t)])
        },
        getQualityPanel: function() {
            return Ext.isDefined(this.quality_panel) || (this.quality_panel = new SYNO.VideoController2.QualityPanel({
                module: this.module
            })), this.quality_panel
        },
        getAudioTrackPanel: function() {
            return Ext.isDefined(this.audiotrack_panel) || (this.audiotrack_panel = new SYNO.VideoController2.AudiotrackPanel({
                module: this.module
            })), this.audiotrack_panel
        },
        getSubtitlePanel: function() {
            return Ext.isDefined(this.subtitle_panel) || (this.subtitle_panel = new SYNO.VideoController2.SubtitlePanel({
                module: this.module
            })), this.subtitle_panel
        },
        getPlayerPanel: function() {
            return Ext.isDefined(this.player_panel) || (this.player_panel = new SYNO.VideoController2.PlayerPanel({
                module: this.module
            })), this.player_panel
        },
        getRepeatPanel: function() {
            return Ext.isDefined(this.repeat_panel) || (this.repeat_panel = new SYNO.VideoController2.RepeatPanel({
                module: this.module
            })), this.repeat_panel
        },
        getItemMaxLength: function() {
            var t = this.items.getRange().map(function(t) {
                return t.getListLength()
            });
            return Math.max.apply(null, t)
        },
        setMenuHeight: function() {
            var t = 34 * (this.items.length + 1),
                e = 32 * this.getItemMaxLength(),
                i = 11 + t + e,
                n = Ext.getBody().getViewSize().height - 80 - 10 - 10;
            this.setHeight(i > n ? n : i)
        }
    }), Ext.define("SYNO.VideoController2.PlaybackRateMenu", {
        extend: "SYNO.VideoController2.MenuPanel",
        constructor: function(t) {
            this.module = t.module;
            var e = {
                header: !0,
                title: _VCT("controller", "playback_rate"),
                cls: "vc-playback-rate-panel",
                height: 259
            };
            this.callParent([Ext.apply(e, t)]), this.setList(), this.setDefault(SYNO.VideoController2.Util.PLAYBACK_RATE_100X)
        },
        setList: function() {
            this.removeItems(), this.add050x(), this.add075x(), this.add100x(), this.add125x(), this.add150x(), this.add175x(), this.add200x(), this.loadItems()
        },
        add050x: function() {
            this.addItem(SYNO.VideoController2.Util.PLAYBACK_RATE_050X, "0.5", this.selectPlaybackRate.createDelegate(this, [.5]), !0, !1, !0)
        },
        add075x: function() {
            this.addItem(SYNO.VideoController2.Util.PLAYBACK_RATE_075X, "0.75", this.selectPlaybackRate.createDelegate(this, [.75]), !0, !1, !0)
        },
        add100x: function() {
            this.addItem(SYNO.VideoController2.Util.PLAYBACK_RATE_100X, "1.0", this.selectPlaybackRate.createDelegate(this, [1]), !0, !1, !0)
        },
        add125x: function() {
            this.addItem(SYNO.VideoController2.Util.PLAYBACK_RATE_125X, "1.25", this.selectPlaybackRate.createDelegate(this, [1.25]), !0, !1, !0)
        },
        add150x: function() {
            this.addItem(SYNO.VideoController2.Util.PLAYBACK_RATE_150X, "1.5", this.selectPlaybackRate.createDelegate(this, [1.5]), !0, !1, !0)
        },
        add175x: function() {
            this.addItem(SYNO.VideoController2.Util.PLAYBACK_RATE_175X, "1.75", this.selectPlaybackRate.createDelegate(this, [1.75]), !0, !1, !0)
        },
        add200x: function() {
            this.addItem(SYNO.VideoController2.Util.PLAYBACK_RATE_200X, "2.0", this.selectPlaybackRate.createDelegate(this, [2]), !0, !1, !0)
        },
        selectPlaybackRate: function(t) {
            isNaN(t) || t < .5 || t > 4 || this.module.getController().setPlaybackRate(t)
        }
    }), Ext.define("SYNO.VideoController2.VolumePanel", {
        extend: "Ext.Panel",
        constructor: function(t) {
            this.volumeBar = new SYNO.VideoController2.VolumeBar({
                module: t.module
            });
            var e = {
                cls: "vc-volume-panel",
                frame: !0,
                items: [this.volumeBar]
            };
            this.callParent([Ext.apply(e, t)])
        }
    }), Ext.define("SYNO.VideoController2.VolumeBar", {
        extend: "SYNO.VideoController2.Slider",
        constructor: function(t) {
            var e = {
                cls: "vc-volume-bar",
                minValue: 0,
                maxValue: 100,
                vertical: !0
            };
            this.callParent([Ext.apply(e, t)])
        },
        updateView: function(t) {
            this.disabled || this.isDragging() || this.setValue(t)
        },
        insertVolumeStrip: function() {
            this.volumeStrip || (this.volumeStrip = Ext.DomHelper.insertBefore(this.thumbs[0].el, {
                tag: "div",
                cls: "volume"
            }, !0), this.volumeStrip.setHeight(0), this.halfThumb = 8)
        },
        onAfterRender: function() {
            this.insertVolumeStrip();
            var t = this.getValue();
            this.setValue(1), this.setValue(t)
        },
        onChange: function(t, e, i) {
            var n = e / 100 * 138;
            this.volumeStrip.setHeight(n)
        },
        onChangeComplete: function(t, e, i) {
            this.disabled || this.module.getController().setVolume(e)
        },
        setDisable: function(t) {
            t ? (this.setValue(0), this.volumeStrip.setWidth(0), this.disable()) : this.enable()
        }
    }), Ext.define("SYNO.VideoController2.VolumeButton", {
        extend: "SYNO.VideoController2.MenuButton",
        constructor: function(t) {
            this.module = t.module;
            var e = {
                muted: !1,
                menuAlign: "b-t",
                disabled: !0
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("volume")
        },
        createMenu: function() {
            return this.volume_panel = new SYNO.VideoController2.VolumePanel({
                module: this.module
            }), new SYNO.VideoController2.Menu({
                cls: "syno-vc-volume-menu",
                defaultOffsets: [0, -11],
                items: [this.volume_panel]
            })
        },
        setMute: function(t) {
            this.isDestroyed || (this.muted = t, this.muted ? (this.addClass("mute"), this.hideMenu()) : (this.removeClass("mute"), this.getEl().hasClass("x-btn-over") && this.showMenu()))
        },
        setVolume: function(t) {
            this.volume_panel.volumeBar.updateView(t)
        },
        clickHandler: function() {
            this.getController().toggleMute()
        },
        onClick: function(t) {
            t && t.preventDefault(), 0 !== t.button || this.disabled || (this.doToggle(), this.fireEvent("click", this, t), this.handler && this.handler.call(this.scope || this, this, t))
        },
        onMouseOver: function(t) {
            this.muted || this.disabled || this.showMenu(), this.callParent(arguments)
        }
    }), Ext.define("SYNO.VideoController2.SettingsButton", {
        extend: "SYNO.VideoController2.MenuButton",
        constructor: function(t) {
            this.module = t.module, this.align_config = "br-tr", this.align_offset = [88, -38];
            var e = {
                menuAlign: this.align_config,
                disabled: !0
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("setting")
        },
        createMenu: function() {
            return new SYNO.VideoController2.Menu({
                cls: "syno-vc-setting-panel",
                defaultOffsets: this.align_offset,
                items: this.getSettingsMenu(),
                onShow: function(t) {
                    t.getEl().alignTo(this.getEl(), this.align_config, this.align_offset), this.getSettingsMenu().items.each(function(t, e) {
                        t.updateFleXcroll(), t.getDataview().updateFleXcroll()
                    })
                }.createDelegate(this)
            })
        },
        getSettingsMenu: function() {
            return Ext.isDefined(this.settings_menu) || (this.settings_menu = new SYNO.VideoController2.SettingsMenu({
                module: this.module
            })), this.settings_menu
        }
    }), Ext.define("SYNO.VideoController2.FullscreenButton", {
        extend: "SYNO.VideoController2.Button",
        constructor: function(t) {
            var e = {
                isFullscreen: !1,
                disabled: !0
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("fullscreen")
        },
        setFullscreen: function(t) {
            this.isDestroyed || (this.fullscreen = t)
        },
        clickHandler: function() {
            this.getController().toggleFullscreen()
        }
    }), Ext.define("SYNO.VideoController2.ListButton", {
        extend: "SYNO.VideoController2.Button",
        constructor: function(t) {
            var e = {
                disabled: !0
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("list")
        },
        clickHandler: function() {
            this.getController().toggleList()
        }
    }), Ext.define("SYNO.VideoController2.PlaybackRateButton", {
        extend: "SYNO.VideoController2.MenuButton",
        constructor: function(t) {
            this.module = t.module, this.align_config = "br-tr", this.align_offset = [200, -38];
            var e = {
                menuAlign: this.align_config,
                disabled: !0
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("playbackrate")
        },
        createMenu: function() {
            return new SYNO.VideoController2.Menu({
                cls: "syno-vc-playback-rate-panel",
                defaultOffsets: this.align_offset,
                items: this.getPlaybackRateMenu()
            })
        },
        getPlaybackRateMenu: function() {
            return Ext.isDefined(this.playback_rate_menu) || (this.playback_rate_menu = new SYNO.VideoController2.PlaybackRateMenu({
                module: this.module
            })), this.playback_rate_menu
        }
    }), Ext.define("SYNO.VideoController2.SeekForwardButton", {
        extend: "SYNO.VideoController2.Button",
        constructor: function(t) {
            var e = {
                disabled: !0
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("seekforward")
        },
        clickHandler: function() {
            this.getController().seekInterval(10)
        }
    }), Ext.define("SYNO.VideoController2.SeekBackwardButton", {
        extend: "SYNO.VideoController2.Button",
        constructor: function(t) {
            var e = {
                disabled: !0
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("seekbackward")
        },
        clickHandler: function() {
            this.getController().seekInterval(-10)
        }
    }), Ext.define("SYNO.VideoController2.OptionsBar", {
        extend: "Ext.Container",
        constructor: function(t) {
            this.module = t.module;
            var e = {
                items: [this.getListButton(), this.getSeekBackwardButton(), this.getSeekForwardButton(), this.getPlaybackRateButton(), this.getVolumeButton(), this.getSettingsButton(), this.getFullscreenButton()]
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("syno-vc-options-bar"), this.mon(SYNO.VideoController2.ControlPanelButtonStatus.get(), SYNO.VideoController2.ControlPanelButtonStatus.EVENT_ENABLE_CONTROLPANEL_BUTTONS, this.setButtonsEnabled, this)
        },
        hasMenuVisible: function() {
            return this.getVolumeButton().menu.isVisible() || this.getSettingsButton().menu.isVisible() || this.getPlaybackRateButton().menu.isVisible()
        },
        setButtonsEnabled: function() {
            var t = SYNO.VideoController2.ControlPanelButtonStatus.get();
            this.getListButton().setDisabled(!t.list), this.getSeekBackwardButton().setDisabled(!t.seek_backward), this.getSeekForwardButton().setDisabled(!t.seek_forward), this.getPlaybackRateButton().setDisabled(!t.playback_rate), this.getVolumeButton().setDisabled(!t.volume), this.getSettingsButton().setDisabled(!t.settings), this.getFullscreenButton().setDisabled(!t.fullscreen)
        },
        resetButtons: function() {
            this.items.each(function(t) {
                t.setDisabled(!0)
            })
        },
        getSeekBackwardButton: function() {
            return Ext.isDefined(this.seekbackward_button) || (this.seekbackward_button = new SYNO.VideoController2.SeekBackwardButton({
                module: this.module
            })), this.seekbackward_button
        },
        getSeekForwardButton: function() {
            return Ext.isDefined(this.seekforward_button) || (this.seekforward_button = new SYNO.VideoController2.SeekForwardButton({
                module: this.module
            })), this.seekforward_button
        },
        getPlaybackRateButton: function() {
            return Ext.isDefined(this.playback_rate_button) || (this.playback_rate_button = new SYNO.VideoController2.PlaybackRateButton({
                module: this.module
            })), this.playback_rate_button
        },
        getVolumeButton: function() {
            return Ext.isDefined(this.volume_button) || (this.volume_button = new SYNO.VideoController2.VolumeButton({
                module: this.module
            })), this.volume_button
        },
        getSettingsButton: function() {
            return Ext.isDefined(this.settings_button) || (this.settings_button = new SYNO.VideoController2.SettingsButton({
                module: this.module
            })), this.settings_button
        },
        getFullscreenButton: function() {
            return Ext.isDefined(this.fullscreen_button) || (this.fullscreen_button = new SYNO.VideoController2.FullscreenButton({
                module: this.module
            })), this.fullscreen_button
        },
        getListButton: function() {
            return Ext.isDefined(this.list_button) || (this.list_button = new SYNO.VideoController2.ListButton({
                module: this.module,
                hidden: !0
            })), this.list_button
        }
    }), Ext.define("SYNO.VideoController2.ProgressSlider", {
        extend: "SYNO.VideoController2.Slider",
        clickRange: [5, 23],
        promoteThumb: Ext.emptyFn,
        progressMax: 1e4,
        constructor: function(t) {
            var e = {
                minValue: 0,
                maxValue: this.progressMax
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("syno-vc-progress-slider"), this.duration = 0
        },
        setDuration: function(t) {
            this.duration = t
        },
        getTimeText: function() {
            return Ext.isDefined(this.time_text) || (this.time_text = new SYNO.VideoController2.TimeText({
                cls: "time-bubble"
            })), this.time_text
        },
        updateView: function(t) {
            this.isDragging() || (this.setValue(this.progressMax * t / this.duration), this.getTimeText().updateView(t))
        },
        insertSeekProgress: function() {
            this.seekProgress || (this.seekProgress = Ext.DomHelper.insertBefore(this.thumbs[0].el, {
                tag: "div",
                cls: "progress"
            }, !0), this.seekProgress.setWidth(0))
        },
        onAfterRender: function() {
            this.insertSeekProgress(), this.setValue(1), this.setValue(0)
        },
        onChange: function(t, e, i) {
            var n = this.duration * e / this.progressMax;
            this.module.getControlPanel().setPlaybackPosition(n), this.seekProgress.setWidth(i.el.getLeft(!0)), this.getTimeText().updateView(n), Ext.DomHelper.overwrite(i.el.dom, {
                tag: "div",
                cls: "time-bubble",
                html: this.getTimeText().text
            })
        },
        onChangeComplete: function(t, e, i) {
            var n = this.duration * e / this.progressMax;
            Ext.isNumber(n) && this.module.getController().seek(n)
        },
        setDisable: function(t) {
            this.isDestroyed || (t ? (this.setValue(0), this.seekProgress.setWidth(0), this.disable()) : this.enable())
        },
        resizeWidth: function() {
            this.syncThumb(), this.seekProgress.setWidth(this.thumbs[0].el.getLeft(!0))
        }
    }), Ext.define("SYNO.VideoController2.ProgressBar", {
        extend: "Ext.Container",
        constructor: function(t) {
            this.module = t.module;
            var e = {
                items: [this.getProgressSlider()]
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("syno-vc-progress-bar"), this.mon(SYNO.VideoController2.ControlPanelButtonStatus.get(), SYNO.VideoController2.ControlPanelButtonStatus.EVENT_ENABLE_CONTROLPANEL_BUTTONS, this.setProgressSliderEnabled, this)
        },
        getProgressSlider: function() {
            return Ext.isDefined(this.progress_slider) || (this.progress_slider = new SYNO.VideoController2.ProgressSlider({
                module: this.module
            })), this.progress_slider
        },
        setProgressSliderEnabled: function() {
            this.getProgressSlider().setDisable(!SYNO.VideoController2.ControlPanelButtonStatus.get().progress_slider)
        },
        resetSlider: function() {
            this.getProgressSlider().setDisable(!0)
        },
        resizeWidth: function() {
            this.getProgressSlider().resizeWidth()
        }
    }), Ext.define("SYNO.VideoController2.ProgressTimeBar", {
        extend: "Ext.Container",
        constructor: function(t) {
            this.module = t.module;
            var e = {
                items: [this.getPositionText(), {
                    xtype: "box",
                    html: "&nbsp;/&nbsp;",
                    cls: "duration"
                }, this.getDurationText()]
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("syno-vc-progress-time-bar")
        },
        getPositionText: function() {
            return Ext.isDefined(this.position_text) || (this.position_text = new SYNO.VideoController2.TimeText({
                cls: "position"
            })), this.position_text
        },
        getDurationText: function() {
            return Ext.isDefined(this.duration_text) || (this.duration_text = new SYNO.VideoController2.TimeText({
                cls: "duration"
            })), this.duration_text
        }
    }), Ext.define("SYNO.VideoController2.MetaDisplay", {
        extend: "Ext.Container",
        constructor: function(t) {
            var e = {
                itemId: "meta_display",
                cls: "meta-display",
                hidden: !0,
                hideMode: "offsets",
                html: this.getHtml()
            };
            this.callParent([Ext.apply(e, t)])
        },
        setImage: function(t) {
            if (!this.isDestroyed) {
                var e = Ext.get(this.getIconID());
                if ("" === t) this.icon_src = "", e.hide(), e.setStyle("background-image", "");
                else {
                    if (t === this.icon_src) return;
                    this.icon_src = t, e.setStyle("background-image", String.format("url({0})", t)), e.show()
                }
            }
        },
        setText: function(t) {
            !this.isDestroyed && Ext.isString(t) && Ext.get(this.getTextID()).update(t)
        },
        getTextID: function() {
            return Ext.isDefined(this.text_id) || (this.text_id = Ext.id()), this.text_id
        },
        getIconID: function() {
            return Ext.isDefined(this.icon_id) || (this.icon_id = Ext.id()), this.icon_id
        },
        getHtml: function() {
            return ['<table width="100%" height="100%" cellspacing="0" cellpadding="0" border="0">', "<tbody>", "<tr><td>", '<div class="frame">', '<div class="cover-frame"></div>', '<div class="icon-frame"><div class="icon" id="' + this.getIconID() + '"></div></div>', "</div>", '<div class="status-text" id="' + this.getTextID() + '"></div>', "</td></tr>", "</tbody>", "</table>"].join("")
        }
    }), Ext.define("SYNO.VideoController2.SubtitleDisplay", {
        extend: "Ext.Container",
        SUBTITLE_HEIGHT: 80,
        MAX_LINE: 6,
        PADDING: 4,
        constructor: function(t) {
            var e = {
                itemId: "subtitle",
                hidden: !0,
                cls: "subtitle",
                prev_text: "",
                margin_bottom: 0,
                items: [this.getSubtitleWrapper()]
            };
            this.callParent([Ext.apply(e, t)]), this.mon(SYNO.VideoController2.SubtitlePreference.get(), SYNO.VideoController2.SubtitlePreference.EVENT_DATA_LOADED, this.updatePreference, this), this.mon(SYNO.VideoController2.SubtitlePreference.get(), SYNO.VideoController2.SubtitlePreference.EVENT_DATA_CHANGED, this.updatePreference, this), this.mac_safari_repaint_workaround = SYNO.VideoController2.Util.isMacSafari()
        },
        getSubtitleWrapper: function() {
            return this.subtitle_wrapper = this.subtitle_wrapper || new Ext.Container({
                listeners: {
                    afterrender: {
                        fn: function() {
                            SYNO.VideoController2.SubtitlePreference.get().loadUserSetting()
                        },
                        single: !0
                    }
                }
            }), this.subtitle_wrapper
        },
        setText: function(t) {
            if (t !== this.prev_text) {
                var e = this.font_size;
                this.prev_text = t, this.getSubtitleWrapper().getEl().update(this.getSubtitleText(t)), this.getSubtitleWrapper().getEl().setStyle("padding", this.getSubtitlePadding(t)), this.getSubtitleWrapper().getEl().setStyle("background-color", this.getSubtitleBackgroundRGBA(t)), this.updateSize(e, this.getSubtitleLineHeight(t), this.getSubtitleLine(t)), this.mac_safari_repaint_workaround && this.hasSubtitleText(t) && this.getSubtitleWrapper().getEl().repaint()
            }
        },
        hasSubtitleText: function(t) {
            return Ext.isString(t) && t.length > 0
        },
        getSubtitleLine: function(t) {
            return this.hasSubtitleText(t) ? Ext.min([t.split("<br/>").length, this.MAX_LINE]) : 0
        },
        getSubtitleText: function(t) {
            return this.hasSubtitleText(t) ? t : "&nbsp;"
        },
        getSubtitlePadding: function(t) {
            return this.hasSubtitleText(t) ? "5px" : "0"
        },
        getSubtitleBackgroundRGBA: function(t) {
            return SYNO.VideoController2.Util.isMacSafari() && !this.hasSubtitleText(t) ? "rgba(0, 0, 0, 1)" : this.background_rgba || ""
        },
        getSubtitleLineHeight: function(t) {
            return this.hasSubtitleText(t) || this.is_vlc ? this.getLineHeight() : 0
        },
        updatePreference: function(t) {
            this.font_size = t.subtitle_size || this.font_size, this.updateSize(this.font_size, this.getLineHeight(), this.getSubtitleLine(this.prev_text));
            var e = SYNO.VideoController2.SubtitlePreference.get(),
                i = e.getRGBA(t.subtitle_color, t.subtitle_transparency),
                n = e.getShadow(t.subtitle_shadow, t.subtitle_transparency);
            this.subtitle_position = t.subtitle_position || this.subtitle_position, "top" === this.subtitle_position ? this.getEl().setStyle("top", "") : this.getEl().setStyle("top", Ext.isIE || Ext.isIE11 ? "auto" : "initial"), this.getEl().setStyle("font-family", t.subtitle_font), this.getEl().setStyle("color", i), this.getEl().setStyle("text-shadow", n);
            var o = e.getRGBA(t.background_color, t.background_transparency);
            this.getSubtitleWrapper().getEl().setStyle("background-color", o), this.background_rgba = o
        },
        updateSize: function(t, e, i) {
            var n = SYNO.VideoController2.SubtitlePreference.get().getSubtitleSize(t);
            if (this.is_vlc) {
                var o = 2 * e;
                e = i > 1 ? o / i : o, n = i > 1 ? .9 * e : n, this.setHeight(o)
            }
            var r = this.getEl();
            r.setStyle("font-size", String.format("{0}px", n)), r.setStyle("line-height", String.format("{0}px", 0 === i ? 0 : e))
        },
        setIsVLC: function(t) {
            this.is_vlc = t, this.updateSize(this.font_size, this.getLineHeight(), this.getSubtitleLine(this.prev_text))
        },
        getLineHeight: function() {
            return SYNO.VideoController2.SubtitlePreference.get().getSubtitleSize(this.font_size) + this.PADDING
        },
        setSubtitleMarginBottom: function(t, e) {
            var i = t + 10;
            this.margin = 0, this.is_vlc && !SYNO.VideoController2.Util.isMacSafari() || (this.margin = i, e && (this.margin = 78 > t ? 10 : i - 78)), this.getEl().setStyle("bottom" === this.subtitle_position ? "margin-bottom" : "margin-top", String.format("{0}px", this.margin))
        }
    }), Ext.define("SYNO.VideoController2.VideoDisplay", {
        extend: "Ext.Container",
        constructor: function(t) {
            var e = {
                itemId: "video_display",
                cls: "video-display",
                hideMode: "offsets",
                items: [this.getVideoContainer(), this.getSubtitleDisplay()]
            };
            this.callParent([Ext.apply(e, t)])
        },
        getVideoContainer: function() {
            return {
                xtype: "container",
                itemId: "video",
                cls: "video"
            }
        },
        getSubtitleDisplay: function() {
            return this.subtitle_display = this.subtitle_display || new SYNO.VideoController2.SubtitleDisplay, this.subtitle_display
        }
    }), Ext.define("SYNO.VideoController2.Display", {
        extend: "Ext.Container",
        ALL_META_CLASSES: ["poster", "screenshot", "buffer", "error"],
        constructor: function(t) {
            var e = {
                layout: "card",
                itemId: "body",
                cls: "syno-vc-body",
                activeItem: this.getInitItemID(),
                items: [this.getVideoDisplay(), this.getMetaDisplay()],
                listeners: {
                    scope: this
                },
                remote_mode: !1,
                video_info: {}
            };
            this.callParent([Ext.apply(e, t)])
        },
        getInitItemID: function() {
            return Ext.isLinux && Ext.isGecko || Ext.isMac && Ext.isGecko ? 0 : 1
        },
        setSubtitle: function(t) {
            this.getVideoDisplay().getComponent("subtitle") && this.getVideoDisplay().getComponent("subtitle").setText(t)
        },
        updateSubtitlePreference: function() {
            this.getVideoDisplay().getComponent("subtitle") && this.getVideoDisplay().getComponent("subtitle").updatePreference(SYNO.VideoController2.SubtitlePreference.get().getSettings())
        },
        showSubtitle: function(t) {
            var e = this.getVideoDisplay().getComponent("subtitle");
            e && (e[!0 === t ? "show" : "hide"](), this.doLayout())
        },
        getVideoDisplay: function() {
            return Ext.isDefined(this.video_display) || (this.video_display = new SYNO.VideoController2.VideoDisplay), this.video_display
        },
        getMetaDisplay: function() {
            return Ext.isDefined(this.meta_display) || (this.meta_display = new SYNO.VideoController2.MetaDisplay), this.meta_display
        },
        setState: function(t, e) {
            switch (t) {
                case SYNO.VideoController2.Util.STATE.CLEAR:
                case SYNO.VideoController2.Util.STATE.STOPPED:
                    this.setStopped();
                    break;
                case SYNO.VideoController2.Util.STATE.PAUSED:
                case SYNO.VideoController2.Util.STATE.PLAYING:
                    this.setPlaying();
                    break;
                case SYNO.VideoController2.Util.STATE.BUFFERING:
                    this.setBuffering();
                    break;
                case SYNO.VideoController2.Util.STATE.ERROR:
                    SYNO.Debug("error: ", e), this.setError(e)
            }
        },
        getVideoInfo: function() {
            return this.video_info
        },
        setVideoInfo: function(t) {
            this.video_info = t, this.playing_cls = "movie" === this.video_info.type ? "poster" : "screenshot", this.playing_exclude_cls = this.ALL_META_CLASSES.filter(function(t) {
                return this.playing_cls !== t
            }, this), this.image_url = SYNO.VideoController2.Util.getImageURL(t.video_id, t.type)
        },
        setRemoteMode: function(t, e) {
            this.remote_mode = t, this.remote_mode && (this.status_text = String.format(_VCT("controller", "playing_on"), e))
        },
        setStopped: function() {
            if (!this.remote_mode) return this.layout.setActiveItem(0), void this.getMetaDisplay().removeClass(["buffer", "error"]);
            this.layout.setActiveItem(1), this.getMetaDisplay().removeClass(this.ALL_META_CLASSES),
                this.getMetaDisplay().setImage(""), this.getMetaDisplay().setText("")
        },
        setPlaying: function() {
            if (!this.isDestroyed) {
                if (!this.remote_mode) return void this.layout.setActiveItem(0);
                this.layout.setActiveItem(1), this.getMetaDisplay().removeClass(this.playing_exclude_cls), this.getMetaDisplay().addClass(this.playing_cls), this.getMetaDisplay().setImage(this.image_url), this.getMetaDisplay().setText(this.status_text)
            }
        },
        setBuffering: function() {
            this.getMetaDisplay().removeClass("error"), this.getMetaDisplay().setText("")
        },
        setError: function(t) {
            this.isDestroyed || (this.layout.setActiveItem(1), this.getMetaDisplay().addClass("error"), this.getMetaDisplay().removeClass("buffer"), this.getMetaDisplay().setText(t), this.getMetaDisplay().setImage(""))
        }
    }), Ext.define("SYNO.VideoController2.ControlPanel", {
        extend: "Ext.Container",
        constructor: function(t) {
            this.module = t.module;
            var e = {
                mouse_over: !1,
                items: [this.getProgressBar(), {
                    xtype: "container",
                    cls: "syno-vc-control-panel-subcontainer",
                    items: [this.getControlsBar(), this.getProgressTimeBar(), this.getOptionsBar()]
                }]
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("syno-vc-control-panel"), this.mon(SYNO.VideoController2.ControlPanelButtonStatus.get(), SYNO.VideoController2.ControlPanelButtonStatus.EVENT_RESET_BUTTONS, this.resetControlPanelButtons, this)
        },
        getProgressBar: function() {
            return Ext.isDefined(this.progress_bar) || (this.progress_bar = new SYNO.VideoController2.ProgressBar({
                module: this.module
            })), this.progress_bar
        },
        getControlsBar: function() {
            return Ext.isDefined(this.controls_bar) || (this.controls_bar = new SYNO.VideoController2.ControlsBar({
                module: this.module
            })), this.controls_bar
        },
        getProgressTimeBar: function() {
            return Ext.isDefined(this.progress_time_bar) || (this.progress_time_bar = new SYNO.VideoController2.ProgressTimeBar({
                module: this.module
            })), this.progress_time_bar
        },
        getOptionsBar: function() {
            return Ext.isDefined(this.options_bar) || (this.options_bar = new SYNO.VideoController2.OptionsBar({
                module: this.module
            })), this.options_bar
        },
        setTime: function(t) {
            this.getProgressBar().getProgressSlider().updateView(t)
        },
        initTime: function(t, e) {
            this.setPlaybackPosition(t), this.setPlaybackDuration(e), this.getProgressBar().getProgressSlider().setDuration(e)
        },
        setPlaybackPosition: function(t) {
            this.getProgressTimeBar().getPositionText().updateView(t)
        },
        setPlaybackDuration: function(t) {
            this.getProgressTimeBar().getDurationText().updateView(t)
        },
        setMute: function(t) {
            this.getOptionsBar().getVolumeButton().setMute(t)
        },
        setVolume: function(t) {
            this.getOptionsBar().getVolumeButton().setVolume(t)
        },
        setState: function(t, e) {
            if (!this.isDestroyed) {
                var i = this.getControlsBar().getPlayButton();
                switch (t) {
                    case SYNO.VideoController2.Util.STATE.CLEAR:
                    case SYNO.VideoController2.Util.STATE.STOPPED:
                    case SYNO.VideoController2.Util.STATE.PAUSED:
                    case SYNO.VideoController2.Util.STATE.ERROR:
                    case SYNO.VideoController2.Util.STATE.AUTO_PLAY_FAIL:
                        i.removeClass("pause"), i.addClass("play");
                        break;
                    case SYNO.VideoController2.Util.STATE.BUFFERING:
                    case SYNO.VideoController2.Util.STATE.PLAYING:
                        i.removeClass("play"), i.addClass("pause")
                }
                t === SYNO.VideoController2.Util.STATE.ERROR ? SYNO.VideoController2.ControlPanelButtonStatus.get().changePlayButton(!1) : t === SYNO.VideoController2.Util.STATE.AUTO_PLAY_FAIL ? SYNO.VideoController2.ControlPanelButtonStatus.get().changePlayButton(!0) : SYNO.VideoController2.ControlPanelButtonStatus.get().setPlay(!0)
            }
        },
        setMouseOver: function(t) {
            this.mouse_over = t
        },
        resetControlPanelButtons: function() {
            this.getOptionsBar().resetButtons(), this.getControlsBar().resetButtons(), this.getProgressBar().resetSlider()
        },
        isMouseOver: function() {
            return this.mouse_over
        }
    }), Ext.define("SYNO.VideoController2.HeaderPanel", {
        extend: "Ext.Container",
        constructor: function(t) {
            this.appwin = t.module;
            var e = {
                items: [this.getHeaderPoster(), this.getTextArea(), this.getCloseButton()]
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("syno-vc-header-panel")
        },
        getCloseButton: function() {
            return Ext.isDefined(this.close_button) || (this.close_button = new SYNO.VideoController2.CloseButton({
                appwin: this.appwin
            })), this.close_button
        },
        getTextArea: function() {
            return Ext.isDefined(this.text_area) || (this.text_area = new SYNO.VideoController2.TextArea({
                appwin: this.appwin
            })), this.text_area
        },
        getTitleText: function() {
            return this.getTextArea().getTitleText()
        },
        getHeaderPoster: function() {
            return Ext.isDefined(this.header_poster) || (this.header_poster = new SYNO.VideoController2.HeaderPoster), this.header_poster
        },
        setTitle: function(t) {
            this.getTextArea().getTitleText().setText(Ext.util.Format.htmlEncode(t))
        },
        setPoster: function(t) {
            this.getHeaderPoster().setPoster(t)
        },
        showUpnextMode: function() {
            this.getEl().hasClass("upnext-mode") || (this.appwin.showPanels(), this.getEl().addClass("upnext-mode"))
        },
        hideUpnextMode: function() {
            this.getEl().hasClass("upnext-mode") && (this.appwin.hidePanels(), this.getEl().removeClass("upnext-mode"))
        }
    }), Ext.define("SYNO.VideoController2.CloseButton", {
        extend: "SYNO.ux.Button",
        constructor: function(t) {
            this.appwin = t.appwin;
            var e = {
                scope: this,
                listeners: {
                    scope: this,
                    click: this.close
                }
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("close")
        },
        close: function() {
            this.appwin.restoreDsmBeforeUnload(), this.appwin.close()
        }
    }), Ext.define("SYNO.VideoController2.TextArea", {
        extend: "Ext.Container",
        constructor: function(t) {
            var e = {
                items: [this.getNextText(), this.getTitleText()]
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("text-area")
        },
        getTitleText: function() {
            return Ext.isDefined(this.title_text) || (this.title_text = new SYNO.VideoController2.TitleText), this.title_text
        },
        getNextText: function() {
            return Ext.isDefined(this.next_text) || (this.next_text = new SYNO.VideoController2.NextText), this.next_text
        }
    }), Ext.define("SYNO.VideoController2.NextText", {
        extend: "Ext.Toolbar.TextItem",
        constructor: function(t) {
            var e = {
                text: "Next"
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("next-text")
        }
    }), Ext.define("SYNO.VideoController2.TitleText", {
        extend: "Ext.Toolbar.TextItem",
        constructor: function(t) {
            var e = {
                text: ""
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("title")
        }
    }), Ext.define("SYNO.VideoController2.HeaderPoster", {
        extend: "Ext.Container",
        constructor: function(t) {
            var e = {};
            this.callParent([Ext.apply(e, t)]), this.addClass("header-poster")
        },
        setPoster: function(t) {
            this.getEl().setStyle("background-image", String.format("url({0})", t))
        }
    }), Ext.define("SYNO.VideoController2.BackdropView", {
        extend: "Ext.Container",
        constructor: function(t) {
            var e = {
                cls: "backdrop",
                items: [{
                    xtype: "container",
                    cls: "image"
                }, {
                    xtype: "container",
                    cls: "gradient"
                }]
            };
            this.callParent([Ext.apply(e, t)])
        },
        setState: function(t, e, i) {
            if (!this.isDestroyed) switch (t) {
                case SYNO.VideoController2.Util.STATE.PLAYING:
                case SYNO.VideoController2.Util.STATE.PAUSED:
                case SYNO.VideoController2.Util.STATE.BUFFERING:
                    this.setVisible(t === SYNO.VideoController2.Util.STATE.BUFFERING || i);
                    break;
                case SYNO.VideoController2.Util.STATE.ERROR:
                    this.hide();
                    break;
                default:
                    this.show()
            }
        },
        setBackdrop: function(t) {
            this.setBackdropByMapperId(t.mapper_id)
        },
        setBackdropByMapperId: function(t) {
            if (!SYNO.VideoController2.Util.isVideoControllerOnly()) {
                var e = SYNO.VideoController2.Util.getBackdropURL(t);
                this.getEl().select(".image").setStyle("background-image", String.format('url("{0}")', e))
            }
        }
    }), Ext.define("SYNO.VideoController2.BufferView", {
        extend: "Ext.Container",
        constructor: function(t) {
            var e = {
                cls: "buffer",
                items: [{
                    xtype: "container",
                    cls: "loading"
                }]
            };
            this.callParent([Ext.apply(e, t)])
        },
        setState: function(t) {
            if (!this.isDestroyed) switch (t) {
                case SYNO.VideoController2.Util.STATE.BUFFERING:
                    this.show();
                    break;
                default:
                    this.hide()
            }
        }
    }), Ext.define("SYNO.VideoController2.ReadyToPlayView", {
        extend: "Ext.Container",
        constructor: function(t) {
            var e = {
                cls: "ready-to-play",
                hidden: !0,
                items: [{
                    xtype: "container",
                    cls: "play",
                    listeners: {
                        scope: this,
                        afterrender: function(t) {
                            t.mon(t.getEl(), "click", this.onPlayButtonClick, this)
                        }
                    }
                }]
            };
            this.callParent([Ext.apply(e, t)])
        },
        onPlayButtonClick: function() {
            this.module.getController().play()
        },
        setState: function(t) {
            if (!this.isDestroyed) switch (t) {
                case SYNO.VideoController2.Util.STATE.AUTO_PLAY_FAIL:
                    this.show();
                    break;
                default:
                    this.hide()
            }
        }
    }), Ext.define("SYNO.VideoController2.UpnextView", {
        extend: "Ext.Container",
        constructor: function(t) {
            var e = {
                cls: "upnext",
                count: 0,
                countdown: 1e4,
                interval: 100,
                hidden: !0,
                items: [this.getPlayButton(), this.getRingProgress(), this.getCancelButton()]
            };
            this.callParent([Ext.apply(e, t)])
        },
        confirmPlayNextVideo: function(t) {
            this.module.getHeaderPanel().showUpnextMode(), this.show(), this.getCancelButton().show(), this.getEl().hasClass("canceled") && this.getEl().removeClass("canceled"), this.callback = t, this.startCountdown()
        },
        getRingProgress: function() {
            return this.ring_progress = this.ring_progress || new Ext.Container({
                cls: "ring",
                listeners: {
                    scope: this,
                    afterrender: function(t) {
                        Ext.DomHelper.append(t.getEl(), this.getRingSvg())
                    }
                }
            }), this.ring_progress
        },
        getRingSvg: function() {
            return this.circle_diameter = 108, this.circle_radius = this.circle_diameter / 2, this.ring_width = 4, this.ring_radius = this.circle_radius - this.ring_width / 2, this.ring_diameter = 2 * this.ring_radius, this.ring_perimeter = this.ring_diameter * Math.PI, {
                tag: "svg",
                version: "1.1",
                viewBox: "0 0 108 108",
                style: "width:108px;height:108px;",
                children: [{
                    tag: "circle",
                    cls: "ring",
                    cx: this.circle_radius,
                    cy: this.circle_radius,
                    r: this.circle_radius,
                    fill: "#FFFFFF",
                    "fill-opacity": "0.15"
                }, {
                    tag: "circle",
                    cls: "circle",
                    cx: this.circle_radius,
                    cy: this.circle_radius,
                    r: this.circle_radius - this.ring_width,
                    fill: "#000000",
                    "fill-opacity": "0.4"
                }, {
                    tag: "circle",
                    cls: "progress",
                    cx: -1 * this.circle_radius,
                    cy: this.circle_radius,
                    r: this.ring_radius,
                    "fill-opacity": "0",
                    stroke: "#BF2A2A",
                    "stroke-dasharray": this.ring_perimeter,
                    "stroke-dashoffset": -1 * this.ring_perimeter,
                    "stroke-width": "4",
                    transform: "rotate(-90)"
                }]
            }
        },
        getPlayButton: function() {
            return this.play_button = this.play_button || new Ext.Container({
                cls: "play",
                listeners: {
                    scope: this,
                    afterrender: function(t) {
                        t.mon(t.getEl(), "click", this.onPlayButtonClick, this)
                    }
                }
            }), this.play_button
        },
        getCancelButton: function() {
            return this.cancel_button = this.cancel_button || new Ext.Container({
                cls: "cancel",
                html: _T("common", "cancel"),
                listeners: {
                    scope: this,
                    afterrender: function(t) {
                        t.mon(t.getEl(), "click", this.onCancelButtonClick, this)
                    }
                }
            }), this.cancel_button
        },
        onPlayButtonClick: function() {
            this.stopCountdown(), this.callback(), this.hide(), this.module.getHeaderPanel().hideUpnextMode()
        },
        onCancelButtonClick: function() {
            this.stopCountdown(), this.getCancelButton().hide(), this.getEl().addClass("canceled"), this.count = 0
        },
        getDashOffset: function(t) {
            return -1 * this.ring_perimeter - this.ring_perimeter * t
        },
        refetchRingProgress: function() {
            var t = this.count / this.countdown;
            0 !== this.getRingProgress().getEl().query(".progress").length && this.getRingProgress().getEl().query(".progress")[0].setAttribute("stroke-dashoffset", this.getDashOffset(t))
        },
        startCountdown: function() {
            this.stopCountdown(), this.task_runner = new SYNO.SDS.TaskRunner, this.polling_status = this.task_runner.createTask({
                scope: this,
                run: function() {
                    this.count = this.count + this.interval, this.refetchRingProgress(), this.count >= this.countdown && this.onPlayButtonClick()
                },
                interval: this.interval
            }), this.polling_status.start(!0)
        },
        stopCountdown: function() {
            this.task_runner && (this.count = 0, this.refetchRingProgress(), this.polling_status = null, this.task_runner.destroy(), this.task_runner = null)
        }
    }), Ext.define("SYNO.VideoController2.Application", {
        extend: "SYNO.SDS.AppInstance",
        appWindowName: "SYNO.VideoController2.AppWindow"
    }), Ext.define("SYNO.VideoController2.AppWindow", {
        extend: "SYNO.SDS.AppWindow",
        constructor: function(t) {
            this.addEvents({
                videochange: !0
            });
            var e = {
                dsmStyle: "v5",
                showHelp: !1,
                cls: "syno-vc-appwin",
                minHeight: 480,
                minWidth: 720,
                items: [this.getReadyToPlayView(), this.getBufferView(), this.getBackdropView(), this.getHeaderPanel(), this.getDisplay(), this.getControlPanel(), this.getUpnextView()],
                listeners: {
                    scope: this,
                    show: this.onMainWindowShow,
                    afterrender: function() {
                        this.bindKeyboardEvent(), this.bindMouseEvent()
                    },
                    afterlayout: function() {
                        this.getProgressBar().resizeWidth()
                    },
                    resize: {
                        scope: this,
                        delay: 600,
                        fn: function() {
                            this.alignTo(Ext.getBody(), "tl-tl")
                        }
                    }
                }
            };
            this.callParent([Ext.apply(e, t)]), this.addClass("syno-vc-win"), this.addClass("show-panels"), this.addClass("backdrop"), this.hideToastTask = new Ext.util.DelayedTask(function() {
                this.toastCt && (this.toastCt.hide(), this.toastCt.remove(), delete this.toastCt)
            }, this), _S("standalone") && (this.onModalWindowResize(), Ext.EventManager.onWindowResize(this.onModalWindowResize, this))
        },
        onMainWindowShow: Ext.emptyFn,
        onModalWindowResize: function() {
            this.setPosition(0, 0), this.setSize(Ext.lib.Dom.getViewWidth(), Ext.lib.Dom.getViewHeight())
        },
        getReadyToPlayView: function() {
            return Ext.isDefined(this.ready_to_plary_view) || (this.ready_to_plary_view = new SYNO.VideoController2.ReadyToPlayView({
                module: this
            })), this.ready_to_plary_view
        },
        getBufferView: function() {
            return Ext.isDefined(this.buffer_view) || (this.buffer_view = new SYNO.VideoController2.BufferView({
                module: this
            })), this.buffer_view
        },
        getBackdropView: function() {
            return Ext.isDefined(this.backdrop_view) || (this.backdrop_view = new SYNO.VideoController2.BackdropView({
                module: this
            })), this.backdrop_view
        },
        getUpnextView: function() {
            return Ext.isDefined(this.upnext_view) || (this.upnext_view = new SYNO.VideoController2.UpnextView({
                module: this
            })), this.upnext_view
        },
        getHeaderPanel: function() {
            return Ext.isDefined(this.header_panel) || (this.header_panel = new SYNO.VideoController2.HeaderPanel({
                module: this
            })), this.header_panel
        },
        getDisplay: function() {
            return Ext.isDefined(this.display) || (this.display = new SYNO.VideoController2.Display), this.display
        },
        getControlPanel: function() {
            return Ext.isDefined(this.control_panel) || (this.control_panel = new SYNO.VideoController2.ControlPanel({
                module: this
            })), this.control_panel
        },
        getControlsBar: function() {
            return this.getControlPanel().getControlsBar()
        },
        getProgressBar: function() {
            return this.getControlPanel().getProgressBar()
        },
        getOptionsBar: function() {
            return this.getControlPanel().getOptionsBar()
        },
        getSettingsMenu: function() {
            return this.getOptionsBar().getSettingsButton().getSettingsMenu()
        },
        getController: function() {
            if (!Ext.isDefined(this.controller)) {
                var t = this.getControlPanel();
                this.controller = new SYNO.VideoController2.Controller({
                    appWin: this,
                    tid: this.tid,
                    container: this.getDisplay().getEl(),
                    video: this.getDisplay().getComponent("video_display").getComponent("video").getEl(),
                    jsBaseURL: String.format("{0}/controller/ui", this.jsConfig.jsBaseURL),
                    init_player_id: this.init_player_id,
                    init_subtitle_id: this.init_subtitle_id,
                    init_audiotrack_id: this.init_audiotrack_id,
                    init_type_info: this.init_type_info,
                    init_video_info: this.init_video_info,
                    listeners: {
                        busy: this.delayedMask.createDelegate(this, 0, 0),
                        clear: this.clearStatusBusy.createDelegate(this),
                        fhd_high_bitrate_enabled: this.onFHDHighBitrateEnabled.createDelegate(this),
                        rawdisabled: this.onRawDisabled.createDelegate(this),
                        capabilityready: this.onCapabilityReady.createDelegate(this),
                        videolistready: this.onVideoListReady.createDelegate(this),
                        playerlistchange: this.onPlayerListChange.createDelegate(this),
                        playerdecided: this.onPlayerDecided.createDelegate(this),
                        targetchange: this.onTargetChange.createDelegate(this),
                        titlechange: this.onTitleChange.createDelegate(this),
                        videochange: this.onVideoChange.createDelegate(this),
                        statechange: this.setState.createDelegate(this),
                        mutechange: t.setMute.createDelegate(t),
                        volumechange: this.onVolumeChange.createDelegate(this),
                        timechange: this.setTime.createDelegate(this),
                        timeinit: this.initTime.createDelegate(this),
                        subtitlechange: this.setSubtitle.createDelegate(this),
                        discoverchange: this.onDiscoverChange.createDelegate(this),
                        screenshot_state_change: this.setScreenshotStateChange.createDelegate(this)
                    }
                })
            }
            return this.controller
        },
        onDiscoverChange: function(t) {
            this.getSettingsMenu().getSubtitlePanel().setItemVisible(SYNO.VideoController2.Util.SUBTITLE_DISCOVER, t), t ? this.getController().setSubtitle(SYNO.VideoController2.Util.SUBTITLE_DISCOVER, !1) : this.getController().setSubtitle(this.init_subtitle_id, !1)
        },
        onVolumeChange: function(t, e) {
            this.getControlPanel().setVolume(t), e && (this.showPanels(!0), this.getOptionsBar().getVolumeButton().showMenu())
        },
        setScreenshotStateChange: function(t, e) {
            t === SYNO.VideoController2.Util.SCREENSHOT_CREATE ? this.showToast(e, !1) : this.showToast(e, !0)
        },
        setSubtitle: function(t, e) {
            this.getDisplay().showSubtitle(t), this.getSettingsMenu().getSubtitlePanel().setDefault(e), this.getSettingsMenu().getSubtitlePanel().setItemSelected(e)
        },
        setTime: function(t, e) {
            if (this.getController().isSubtitleVisible()) {
                var i = this.getController().getSubtitleParser().getText(t - this.getController().getDelayedTime());
                this.getDisplay().setSubtitle(0 === t ? "" : i)
            }
            this.getController().updateWatchedPosition(t), this.getControlPanel().setTime(t), this.getController().isRemoteMode() || this.setDisplayVisibleByCase(t, e)
        },
        initTime: function(t, e) {
            this.getControlPanel().initTime(t, e)
        },
        setDisplayVisibleByCase: function(t, e) {
            var i = !(t <= 0 || e <= 0) && this.getController().getPlayer().isResumed(t),
                n = 0 === t && 0 === e,
                o = i || n;
            this.getDisplay().getVideoDisplay().setVisible(o), "VLC" === this.getController().getPlayer().getName() && this.getDisplay().getVideoDisplay().getEl().setHeight(o ? "100%" : "0%")
        },
        setState: function(t, e) {
            var i = this.getController().isRemoteMode();
            this.getReadyToPlayView().setState(t), this.getBufferView().setState(t), this.getBackdropView().setState(t, e, i), this.getDisplay().setState(t, e), this.getControlPanel().setState(t, e)
        },
        hasModalWin: function() {
            return null !== this.modalWin && this.modalWin.length > 0
        },
        onFHDHighBitrateEnabled: function(t) {
            this.getSettingsMenu().getQualityPanel().setFHDHighBitrateEnabled(t)
        },
        onRawDisabled: function(t, e) {
            var i = e;
            null === e && (i = t ? this.getController().getTranscodeDefaultProfile() : null), this.getSettingsMenu().getQualityPanel().setRawDisabled(t), this.getSettingsMenu().getQualityPanel().selectProfile(i), this.getSettingsMenu().getQualityPanel().setDefault(i)
        },
        onCapabilityReady: function(t, e) {
            if (!e) return this.getSettingsMenu().getQualityPanel().hide(), void this.getSettingsMenu().getAudioTrackPanel().hide();
            t ? (this.getSettingsMenu().getQualityPanel().setTranscodeDisabled(!1), this.getSettingsMenu().getQualityPanel().selectProfile(this.getController().profile)) : this.getSettingsMenu().getQualityPanel().hide()
        },
        onVideoListReady: function() {
            this.mon(this.getDisplay().getComponent("video_display"), "resize", function() {
                this.getController().rotateVideo()
            }, this)
        },
        onPlayerListChange: function(t) {
            this.getSettingsMenu().getPlayerPanel().setList(t, this.getController().player_info.id)
        },
        onPlayerDecided: function(t, e) {
            this.getSettingsMenu().getSubtitlePanel().setList(t, e), this.getDisplay().getVideoDisplay().getComponent("subtitle").setIsVLC(e), SYNO.VideoController2.ControlPanelButtonStatus.get().setPlaybackRate(this.getController().isPlaybackRateAdjustable(this.getController().getPlayer().getName())), e && !Ext.isMac ? this.addClass("vlc") : this.removeClass("vlc")
        },
        onTargetChange: function(t) {
            if (!this.isDestroyed) {
                this.stopChromecast(), this.getDisplay().setRemoteMode(this.getController().isRemoteMode(), t.title), SYNO.VideoController2.ControlPanelButtonStatus.get().setVolume(!0 === t.volume_adjustable), this.getSettingsMenu().getQualityPanel().setDisabled(SYNO.VideoController2.Util.PLAYERTYPE_UPNP === t.type), this.getSettingsMenu().getAudioTrackPanel().setDisabled(SYNO.VideoController2.Util.PLAYERTYPE_UPNP === t.type);
                var e = SYNO.VideoController2.Util.PLAYERTYPE_AIRPLAY !== t.type || this.getController().supportRemux();
                this.getSettingsMenu().getSubtitlePanel().setDisabled(!e), SYNO.VideoController2.ControlPanelButtonStatus.get().setFullscreen(this.getController().isSupportFullscreen())
            }
        },
        onVideoChange: function(t, e, i, n, o) {
            this.getBackdropView().setBackdrop(i), this.getDisplay().setVideoInfo(i), SYNO.VideoController2.ControlPanelButtonStatus.get().setHasPrev(t), SYNO.VideoController2.ControlPanelButtonStatus.get().setHasNext(e);
            var r = this.getController();
            this.getSettingsMenu().getSubtitlePanel().setList(o, r.subtitle_id), r.supportRemux() && this.getSettingsMenu().getAudioTrackPanel().setList(n, r.audio_id), this.fireEvent("videochange", i)
        },
        onTitleChange: function(t) {
            this.setTitle(t), this.getHeaderPanel().setTitle(t)
        },
        registerOnExitHandler: function() {
            var t = this;
            this.backupDsmBeforeUnload();
            var e = function() {
                t.closeHandler(), t.runDsmBeforeUnload()
            };
            this.setBeforeUnloadOrPageHide(e)
        },
        runDsmBeforeUnload: function() {
            Ext.isFunction(this.dsm_beforeunload) && this.dsm_beforeunload()
        },
        backupDsmBeforeUnload: function() {
            Ext.isFunction(window.onbeforeunload) && (this.dsm_beforeunload = window.onbeforeunload, window.onbeforeunload = null)
        },
        restoreDsmBeforeUnload: function() {
            Ext.isFunction(this.dsm_beforeunload) && (window.onbeforeunload = this.dsm_beforeunload)
        },
        setBeforeUnloadOrPageHide: function(t) {
            Ext.isSafari && navigator.userAgent.match(/iPhone|iPad/i) ? window.onpagehide = t : window.onbeforeunload = t
        },
        onOpen: function(t) {
            this.callParent(arguments), this.initTask(), this.registerOnExitHandler(), this.delayedMask(0, 0), Ext.isDefined(t.video_id) ? (this.init_player_id = t.player_id, this.init_subtitle_id = t.subtitle_id, this.init_audiotrack_id = t.audiotrack_id, this.init_type_info = {
                type: t.browse_type,
                sort_info: t.sort_info,
                id: parseInt(t.type_id, 10)
            }, this.init_video_info = {
                video_id: parseInt(t.video_id, 10),
                type: t.video_type,
                file_id: t.file_id,
                title: t.title
            }, this.getController().initSequenceVideo()) : (Ext.isDefined(t.path) || Ext.isDefined(t.drive_path)) && (this.getSettingsMenu().getPlayerPanel().hide(), this.init_player_id = t.player_id, this.init_type_info = {
                type: t.browse_type
            }, this.init_video_info = {
                path: t.path,
                type: t.video_type,
                symlink: Ext.isString(t.symlink) ? t.symlink : null,
                drive_path: t.drive_path
            }, this.getController().initSequenceVideo())
        },
        onClose: function() {
            this.closeHandler(), this.callParent(arguments)
        },
        closeHandler: function() {
            this.getController().unlink(), this.getController().stop(Ext.emptyFn), this.getController().closePlayers(), this.stopChromecast(), this.stopRemotePlayer(), this.getUpnextView().stopCountdown(), this.unbindKeyboardEvent(), this.unbindMouseEvent(), SYNO.VideoController2.Util.isFullscreen() && SYNO.VideoController2.Util.exitFullscreen()
        },
        stopChromecast: function() {
            this.getController().getPlayer().id === SYNO.VideoController2.Util.CHROMECAST_ID && SYNO.VideoController2.ChromecastPlayer.stopCast().then(function() {
                this.getController().getChromecastPlayer().disconnect(), this.getController().chromecast_player = null
            }.bind(this))
        },
        stopRemotePlayer: function() {
            this.getController().isRemoteMode() && !this.getController().isChromecast() && this.getController().getPlayer().clear()
        },
        initTask: function() {
            SYNO.VideoController2.Util.hookDoLayout(this), SYNO.VideoController2.Util.isVideoControllerOnly() && this.getHeaderPanel().getCloseButton().hide(), SYNO.VideoController2.Util.isPublicSharing() || (this.preventTimeoutTask = this.addWebAPITask({
                interval: 3e4,
                single: !1,
                api: "SYNO.VideoStation2.Misc",
                version: 1,
                method: "reset_timeout",
                scope: this,
                callback: function(t, e, i, n) {
                    t || this.preventTimeoutTask.stop()
                }
            }).start())
        },
        setVideoDisplayHeight: function() {
            var t = this.getDisplay().getVideoInfo();
            if (t.resolution) {
                var e = t.resolution.height * this.getWidth() / t.resolution.width,
                    i = (this.getHeight() - e) / 2;
                i = i > 0 ? i : 0, this.getDisplay().getVideoDisplay().getSubtitleDisplay().setSubtitleMarginBottom(i, this.isPanelsShow())
            }
            if (this.getSettingsMenu().setMenuHeight(), this.getEl().hasClass("vlc")) {
                var n = this.getHeight();
                this.getDisplay().getVideoDisplay().setHeight(n - 136)
            }
        },
        bindKeyboardEvent: function() {
            Ext.getBody().on("keydown", this.setBodyToggleFullscreen, this, {
                buffer: 250
            }), Ext.getBody().on("keydown", this.setBodyPlayPause, this, {
                buffer: 100
            }), Ext.getBody().on("keydown", this.setBodySeekInterval, this, {
                buffer: 100
            }), Ext.getBody().on("keydown", this.setBodyAdjustVolume, this, {
                buffer: 100
            }), Ext.getBody().on("keydown", this.setBodyCreateScreenshot, this, {
                buffer: 100
            })
        },
        unbindKeyboardEvent: function() {
            Ext.getBody().un("keydown", this.setBodyToggleFullscreen, this), Ext.getBody().un("keydown", this.setBodyPlayPause, this), Ext.getBody().un("keydown", this.setBodySeekInterval, this), Ext.getBody().un("keydown", this.setBodyAdjustVolume, this), Ext.getBody().un("keydown", this.setBodyCreateScreenshot, this)
        },
        setBodyToggleFullscreen: function(t) {
            t.keyCode == Ext.EventObject.ENTER && !this.hasModalWin() && SYNO.VideoController2.ControlPanelButtonStatus.get().getFullscreen() && this.getController().toggleFullscreen()
        },
        setBodyPlayPause: function(t) {
            t.keyCode == Ext.EventObject.SPACE && this.getController().spaceenabled && SYNO.VideoController2.ControlPanelButtonStatus.get().getPlay() && (this.setBodyMouseMove(), this.getController().play())
        },
        setBodySeekInterval: function(t) {
            var e = {
                37: {
                    none: -10,
                    ctrl: -30,
                    shift: -60
                },
                39: {
                    none: 10,
                    ctrl: 30,
                    shift: 60
                }
            };
            if ((t.keyCode == Ext.EventObject.LEFT || t.keyCode == Ext.EventObject.RIGHT) && !this.hasModalWin() && SYNO.VideoController2.ControlPanelButtonStatus.get().getPlay()) {
                var i = this.getFnKey(t);
                this.getController().seekInterval(e[t.keyCode][i])
            }
        },
        setBodyAdjustVolume: function(t) {
            var e = {
                38: {
                    none: 10,
                    ctrl: 25,
                    shift: 50
                },
                40: {
                    none: -10,
                    ctrl: -25,
                    shift: -50
                }
            };
            if (!this.hasModalWin() && (t.keyCode === Ext.EventObject.UP || t.keyCode === Ext.EventObject.DOWN) && SYNO.VideoController2.ControlPanelButtonStatus.get().getVolume()) {
                var i = this.getFnKey(t);
                this.getController().adjustVolume(e[t.keyCode][i])
            }
        },
        setBodyAdjustVolumeByWheel: function(t) {
            if (!(this.hasModalWin() || this.getSettingsMenu().isVisible() || this.getController().state !== SYNO.VideoController2.Util.STATE.PLAYING && this.getController().state !== SYNO.VideoController2.Util.STATE.PAUSED)) {
                var e = t.getWheelDelta();
                if (!(e < .1 && e > -.1)) {
                    var i = e > 0 ? 1 : -1,
                        n = SYNO.VideoController2.Util.isMacSafari1x() ? -1 : 1;
                    this.getController().adjustVolume(i * n * 10)
                }
            }
        },
        setBodyCreateScreenshot: function(t) {
            "83" != t.keyCode || this.hasModalWin() || SYNO.VideoController2.Util.isPublicSharing() || this.getController().isScreenshotCreating() || !SYNO.VideoController2.ControlPanelButtonStatus.get().getPlay() || this.getController().createScreenshot()
        },
        getFnKey: function(t) {
            var e = "none";
            return t.ctrlKey && !t.shiftKey && (e = "ctrl"), !t.ctrlKey && t.shiftKey && (e = "shift"), e
        },
        bindMouseEvent: function() {
            Ext.getBody().on("click", this.setBodyMouseMove, this), Ext.getBody().on("mousemove", this.setBodyMouseMove, this), Ext.getBody().on("mousewheel", this.setBodyAdjustVolumeByWheel, this), this.getControlPanel().getEl().on("mouseover", this.setControlPanelMouseOver, this), this.getControlPanel().getEl().on("mouseout", this.setControlPanelMouseOut, this)
        },
        unbindMouseEvent: function() {
            Ext.getBody().un("click", this.setBodyMouseMove, this), Ext.getBody().un("mousemove", this.setBodyMouseMove, this), Ext.getBody().un("mousewheel", this.setBodyAdjustVolumeByWheel, this), this.getControlPanel().getEl().un("mouseover", this.setControlPanelMouseOver, this), this.getControlPanel().getEl().un("mouseout", this.setControlPanelMouseOut, this)
        },
        setBodyMouseMove: function(t) {
            if (this.getMsgBox().isVisible()) return void this.hidePanels();
            this.getHidePanelsEvent().cancel(), this.getEl().hasClass("hide-panels") && this.showPanels(), this.getController().state === SYNO.VideoController2.Util.STATE.PLAYING && this.getHidePanelsEvent().delay(1500)
        },
        setControlPanelMouseOver: function(t) {
            this.getControlPanel().setMouseOver(!0)
        },
        setControlPanelMouseOut: function(t) {
            this.getControlPanel().setMouseOver(!1)
        },
        getHidePanelsEvent: function() {
            return Ext.isDefined(this.hide_panels) || (this.hide_panels = new Ext.util.DelayedTask(function() {
                this.getController().state !== SYNO.VideoController2.Util.STATE.PLAYING || this.hasModalWin() || this.getController().isRemoteMode() || this.getControlPanel().isMouseOver() || this.getOptionsBar().hasMenuVisible() || this.hidePanels()
            }, this)), this.hide_panels
        },
        showPanels: function(t) {
            this.removeClass("hide-panels"), this.removeClass("hide-panels-base"), this.addClass("show-panels" + (t ? "-base" : "")), this.animateToast(), this.setVideoDisplayHeight()
        },
        hidePanels: function(t) {
            this.isDestroyed || (this.removeClass("show-panels"), this.removeClass("show-panels-base"), this.addClass("hide-panels" + (t ? "-base" : "")), this.animateToast(), this.setVideoDisplayHeight())
        },
        isPanelsShow: function() {
            if (!this.isDestroyed) return this.getEl().hasClass("show-panels")
        },
        showToast: function(t, e) {
            this.toastTpl || (this.toastTpl = new Ext.XTemplate('<div class="syno-vc-toast-content">', '<span class="message">{message}</span>', "</div>", {
                compiled: !0
            })), this.toastCt = this.toastCt || Ext.DomHelper.append(this.getEl(), {
                class: "syno-vc-toast"
            }, !0), this.toastTpl.overwrite(this.toastCt, {
                message: t
            }), this.toastCt.show(), this.hideToastTask.cancel(), e && this.hideToastTask.delay(3e3)
        },
        animateToast: function() {
            this.toastCt && !this.toastCt.hasClass("sliding") && this.toastCt.addClass("sliding")
        },
        getMsgBox: function(t) {
            if (!this.msgBox || this.msgBox.isDestroyed) {
                var e = t && t.owner || this;
                e = e.isDestroyed ? null : e, this.msgBox = new SYNO.VideoController2.MessageBox({
                    owner: e
                })
            }
            return this.callParent(arguments)
        }
    });