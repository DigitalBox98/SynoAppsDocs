/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function _VST(t, e) {
    var i = "";
    try {
        i = _TT("SYNO.SDS.VideoStation.AppInstance", t, e)
    } catch (o) {
        i = _T(t, e)
    } finally {
        return i || String.format("{0}:{1}", t, e)
    }
}
Ext.define("SYNO.SDS.VideoStation2.Constant", {
    singleton: !0,
    CLASS: {
        UNWATCHED: "unwatched",
        LASTWATCHED: "lastwatched"
    },
    EVENT: {
        PLAYLIST_CHANGE: "playlistchange",
        SHARING_STATUS_LOAD: "sharingstatusload",
        VIDEO_LOAD: "videoload",
        VIEW_LOADING: "viewloading",
        VIEW_LOADED: "viewloaded",
        VIEW_NOVIDEO: "viewnovideo",
        VIEW_NOTUNER: "viewnotuner",
        VIEW_CHANNEL_SCAN: "viewchannelscan",
        LOAD_PLAYER_OPTION: "loadplayeroption",
        VIDEO_INFO_UPDATE: "videoinfoupdate"
    },
    EXTRA: {
        KEY_RATING: "rating",
        KEY_REFERENCE: "reference",
        KEY_TMDB: "themoviedb",
        KEY_TMDB_TV: "themoviedb_tv",
        KEY_IMDB: "imdb",
        KEY_ATMOVIE: "atmovie"
    },
    PLAYLIST_TYPE: {
        ORIGINAL: "original",
        SMART: "smart"
    },
    REFRESH_INFO: {
        VIDEO: "video",
        SUBTITLE: "subtitle",
        NEXT_PREV_BTN: "next_prev_btn"
    },
    PLAYER_STREAMING: "streaming",
    TITLE_FAVORITE: "syno_favorite",
    TITLE_WATCHLIST: "syno_watchlist",
    COLLECTION: "collection",
    PLAYLIST: "playlist",
    PLAYLIST_VIDEOLIST: "playlistvideolist",
    MOVIE: "movie",
    TVSHOW: "tvshow",
    TVSHOW_EPISODE: "tvshow_episode",
    HOME_VIDEO: "home_video",
    TV_RECORDING: "tv_record",
    GETINFO_ADDITIONAL: ["summary", "file", "actor", "writer", "director", "extra", "genre", "collection", "poster_mtime", "watched_ratio", "backdrop_mtime"],
    ADDITIONAL_DICT: {
        movie: ["summary", "poster_mtime", "backdrop_mtime", "file", "collection", "watched_ratio", "conversion_produced", "actor", "director", "genre", "writer", "extra"],
        home_video: ["summary", "poster_mtime", "backdrop_mtime", "file", "collection", "watched_ratio", "conversion_produced", "actor", "director", "genre", "writer", "extra"],
        tvshow: ["summary", "poster_mtime", "backdrop_mtime"],
        tvshow_episode: ["summary", "poster_mtime", "backdrop_mtime", "file", "collection", "watched_ratio", "conversion_produced", "actor", "director", "genre", "writer", "extra", "tvshow_summary"],
        tv_record: ["summary", "poster_mtime", "backdrop_mtime", "file", "collection", "watched_ratio", "conversion_produced"]
    },
    CHANNEL: "channel",
    PROGRAM: "program",
    FOLDER: "folder",
    SQUARE: "square",
    FILE: "file",
    LIBRARY: "library",
    CATEGORY: "category",
    DTV: "dtv",
    FILTER: "filter",
    SEASON: "season",
    VIDEO: "video",
    PAGE: "page",
    RECORDING_SPECIFIC: "recording_specific",
    VIDEO_PROFILE_ORIGINAL: "original",
    VIDEO_PROFILE_HIGH: "high",
    VIDEO_PROFILE_MEDIUM: "medium",
    VIDEO_PROFILE_LOW: "low",
    RESOLUTION_DEFINITION: {
        SD: {
            x_from: -1,
            x_to: 640,
            y_from: -1,
            y_to: 480
        },
        "480p": {
            x_from: 640,
            x_to: 1024,
            y_from: 480,
            y_to: 576
        },
        "720p": {
            x_from: 1024,
            x_to: 1280,
            y_from: 576,
            y_to: 720
        },
        "1080p": {
            x_from: 1280,
            x_to: 1920,
            y_from: 720,
            y_to: 1080
        },
        "4K": {
            x_from: 1920,
            x_to: -1,
            y_from: 1080,
            y_to: -1
        }
    },
    PROGRAM_STATUS: {
        STATUS_NONE: "none",
        STATUS_PASS: "pass",
        STATUS_STREAMING: "streaming",
        STATUS_RECORDING: "recording",
        STATUS_SCHEDULED: "scheduled",
        STATUS_REPEAT_SCHEDULED: "repeatscheduled"
    },
    SCHEDULE_STATUS: {
        STATUS_ERROR: "error",
        STATUS_WAIT: "wait",
        STATUS_STREAMING: "streaming",
        STATUS_RECORDING: "recording",
        STATUS_DONGLE_NOT_FOUND: "nodonglenotfound",
        STATUS_RECORDING_INTERRUPT: "recordinginterrupt",
        STATUS_DONE: "done",
        STATUS_NO_PERMISSION: "nopermission",
        STATUS_USER_INVALID: "userinvalid",
        STATUS_NO_QUOTA: "noquota",
        STATUS_VOLUME_FULL: "volumefull",
        STATUS_CREATE_FILE_ERROR: "createfileerror",
        STATUS_WEEKLY_SCHEDULE: "weeklyschedule",
        STATUS_DAILY_SCHEDULE: "dailyschedule",
        STATUS_VLC_INTERRUPT: "vlcinterrupt",
        STATUS_SKIP: "skip"
    },
    RECORDING_ACTION_KEY: {
        RECORDING_CREATE: "record",
        RECORDING_CANCEL: "cancel_recording",
        RECORDING_CREATE_REPEAT: "repeat_record",
        RECORDING_CREATE_USERDEFINE: "user_define_schedule"
    },
    TUNER_TYPE: {
        TYPE_QPSK: 0,
        TYPE_QAM: 1,
        TYPE_OFDM: 2,
        TYPE_ATSC: 3,
        TYPE_HDHOMERUN: 99
    },
    STORE_UNLIMIT: 5e5,
    MAX_NUMBER_OF_RECOMMENDATION: {
        movie: 50,
        tvshow_episode: 5e5,
        home_video: 10,
        tv_record: 10
    },
    MAX_LENGTH: {
        PLAYLIST_NAME: 255,
        DVB_CHANNEL_NAME: 110,
        DVB_PROGRAM_NAME: 110,
        VIDEO_METADATA_CERTIFICATE: 255,
        VIDEO_METADATA_COMMON_FIELD: 255,
        VIDEO_METADATA_SUMMARY: 4096,
        VIDEO_METADATA_TAGLINE: 255,
        VIDEO_METADATA_TITLE: 255
    }
}), Ext.define("SYNO.SDS.VideoStation2.Error", {
    singleton: !0,
    VIDEO_STATION_ERROR: {
        400: _VST("error", "download_failed"),
        417: _VST("error", "image_format"),
        418: String.format(_VST("error", "image_too_big"), 4),
        431: _VST("playlist", "error_name_duplicated"),
        800: _VST("error", "download_failed"),
        801: _VST("error", "image_format"),
        803: String.format(_VST("error", "image_too_big"), 4),
        804: String.format(_VST("error", "image_too_big"), 10),
        903: _VST("playlist", "error_name_duplicated"),
        1002: _VST("error", "invalid_apikey"),
        1152: _VST("controller", "download_subtitle_fail_retry_later"),
        1153: _VST("error", "unsupported_subtitle_format"),
        1500: _VST("error", "dtv_request_dongle"),
        1502: _VST("error", "error_someone_scaning"),
        1503: _VST("action", "scan_fail"),
        1505: _VST("error", "error_someone_scaning"),
        1506: _VST("error", "dtv_channeltable_not_found"),
        1510: _VST("error", "record_program_not_exist"),
        1511: _VST("error", "update_recording"),
        1512: _VST("error", "update_streaming"),
        1513: _VST("error", "dtv_device_busy"),
        1517: _T("error", "error_file_exist"),
        1520: _VST("error", "dtv_folder_not_found"),
        1521: _VST("error", "recorde_duplicate"),
        1522: _VST("error", "no_data"),
        1526: _VST("action", "dvbs_scan_fail")
    },
    DTV_CHANNEL_FILE_NOT_FOUND: 1506,
    DTV_INDEX_FOLDER_NOT_FOUND: 1520,
    getAPIErrorCode: function(t) {
        var e = 100;
        if (Ext.isNumber(t)) e = t;
        else if (Ext.isObject(t)) {
            var i = SYNO.API.Util.GetFirstError(t) || t;
            e = Ext.isNumber(i.code) ? i.code : 100
        }
        return e
    },
    getAPIErrorString: function(t) {
        var e = 100;
        if (Ext.isNumber(t)) e = t;
        else if (Ext.isObject(t)) {
            var i = SYNO.API.Util.GetFirstError(t) || t;
            e = Ext.isNumber(i.code) ? i.code : 100
        }
        return e < 400 ? SYNO.API.Errors.common[e] || _T("error", "error_error_system") : SYNO.SDS.VideoStation2.Error.VIDEO_STATION_ERROR[e] || _T("error", "error_error_system")
    },
    getErrorInfoString: function(t, e) {
        if (!Ext.isObject(t)) return e;
        if (!0 === t.success) return "";
        var i, o = t.errinfo || {};
        return i = o.sec && o.key ? _VST(o.sec, o.key) : _T("error", "error_error_system"), Ext.isNumber(o.line) && (i = String.format("{0} ({1})", i, o.line)), i
    }
}), Ext.define("SYNO.SDS.VideoStation2.PromiseOP", {
    statics: {
        defaultFailureCallback: function(t, e, i) {
            var o = SYNO.SDS.VideoStation2.Error.getAPIErrorString(t);
            SYNO.SDS.VideoStation2.Window.getMsgBox().alert("", o)
        },
        getPromise: function(t, e, i, o, n) {
            return new Promise(function(r, a) {
                SYNO.API.Request({
                    api: t,
                    method: e,
                    version: i,
                    params: o,
                    callback: function(t, e, i, o) {
                        t ? r(e) : Ext.isObject(n) && n.catch ? a(e) : SYNO.SDS.VideoStation2.PromiseOP.defaultFailureCallback(e, i, o)
                    }
                })
            })
        },
        getStoreLoad: function(t, e, i) {
            return new Promise(function(o, n) {
                t.load({
                    params: e,
                    callback: function(t, e, r) {
                        r ? o(t) : Ext.isObject(i) && i.empty_on_error ? o([]) : n(e)
                    }
                })
            })
        },
        all: function(t, e, i) {
            return Promise.all(t).then(e).catch(Ext.isFunction(i) ? i : SYNO.SDS.VideoStation2.PromiseOP.defaultFailureCallback)
        },
        instance: null,
        get: function() {
            return Ext.isObject(SYNO.SDS.VideoStation2.PromiseOP.instance) || (SYNO.SDS.VideoStation2.PromiseOP.instance = new SYNO.SDS.VideoStation2.PromiseOP), SYNO.SDS.VideoStation2.PromiseOP.instance
        }
    },
    extend: "Ext.util.Observable",
    constructor: function() {
        this.callParent(arguments);
        var t = {
            getVideoStationInfo: ["SYNO.VideoStation2.Info", "get", 1],
            getPlaybackSetting: ["SYNO.VideoStation2.File", "get_playback_setting", 2],
            getPreferredInterface: ["SYNO.VideoStation2.Setting.Network", "get_preferred_interface", 1],
            setPreferredInterface: ["SYNO.VideoStation2.Setting.Network", "set_preferred_interface", 1],
            getPreAnalysisInfo: ["SYNO.VideoStation2.Setting.PreAnalysis", "get", 1],
            setPreAnalysisInfo: ["SYNO.VideoStation2.Setting.PreAnalysis", "set", 1],
            deleteParentalControl: ["SYNO.VideoStation2.ParentalControl", "delete", 1],
            listIndexFolder: ["SYNO.VideoStation2.Setting.Folder", "list", 1],
            getVoiceAssistantSetting: ["SYNO.VideoStation2.Setting.VoiceAssistant", "get", 1],
            setVoiceAssistantSetting: ["SYNO.VideoStation2.Setting.VoiceAssistant", "set", 1],
            listControllerDevice: ["SYNO.VideoStation2.Controller.Device", "list", 1],
            getDSMTimezone: ["SYNO.Core.Region.NTP", "listzone", 1]
        };
        Ext.iterate(t, function(t, e, i) {
            this[t] = function(t, i) {
                var o = e[0],
                    n = e[1],
                    r = e[2];
                return SYNO.SDS.VideoStation2.PromiseOP.getPromise(o, n, r, t, i)
            }
        }, this)
    }
}), Ext.define("SYNO.SDS.VideoStation2.Filter", {
    statics: {
        EVENT_FILTER_CHANGE: "filterchange",
        FILTER_ACTOR: "actor",
        FILTER_DIRECTOR: "director",
        FILTER_GENRE: "genre",
        FILTER_WRITER: "writer",
        FILTER_CERTIFICATE: "certificate",
        FILTER_RATING: "rating",
        FILTER_YEAR: "year",
        FILTER_RESOLUTION: "resolution",
        FILTER_WATCHED_STATUS: "watchedstatus",
        FILTER_FILE_COUNT: "filecount",
        FILTER_CONTAINER: "container",
        FILTER_DURATION: "duration",
        FILTER_DATE: "date",
        FILTER_CHANNEL_NAME: "channel_name",
        FILTER_TITLE: "title",
        FILTER_KEYWORD: "keyword",
        DATA_RATING: [{
            key: _VST("filter", "star_0"),
            value: {
                from: -1,
                to: 14
            }
        }, {
            key: _VST("filter", "star_1"),
            value: {
                from: 15,
                to: 34
            }
        }, {
            key: _VST("filter", "star_2"),
            value: {
                from: 35,
                to: 54
            }
        }, {
            key: _VST("filter", "star_3"),
            value: {
                from: 55,
                to: 74
            }
        }, {
            key: _VST("filter", "star_4"),
            value: {
                from: 75,
                to: 94
            }
        }, {
            key: _VST("filter", "star_5"),
            value: {
                from: 95,
                to: 100
            }
        }],
        DATA_RESOLUTION: [{
            key: _VST("filter", "resolution_sd"),
            value: {
                x_from: -1,
                x_to: 1024,
                y_from: -1,
                y_to: 576
            }
        }, {
            key: "720p",
            value: {
                x_from: 1024,
                x_to: 1280,
                y_from: 576,
                y_to: 720
            }
        }, {
            key: "1080p",
            value: {
                x_from: 1280,
                x_to: 1920,
                y_from: 720,
                y_to: 1080
            }
        }, {
            key: String.format(_VST("filter", "andabove"), "4K"),
            value: {
                x_from: 1920,
                x_to: -1,
                y_from: 1080,
                y_to: -1
            }
        }],
        DATA_WATCHED_STATUS: [{
            key: _VST("advanced", "unwatched"),
            value: "unwatched"
        }, {
            key: _VST("advanced", "watching"),
            value: "watching"
        }, {
            key: _VST("advanced", "watched"),
            value: "watched"
        }],
        DATA_FILE_COUNT: [{
            key: _VST("filter", "singlefile"),
            value: "single"
        }, {
            key: _VST("filter", "multiplefile"),
            value: "multiple"
        }],
        DATA_DURATION: [{
            key: String.format(_VST("filter", "andbelow"), "10 " + _VST("common", "minutes")),
            value: {
                from: 0,
                to: 10
            }
        }, {
            key: String.format("{0} ~ {1} {2}", "10", "30", _VST("common", "minutes")),
            value: {
                from: 10,
                to: 30
            }
        }, {
            key: String.format("{0} ~ {1} {2}", "30", "60", _VST("common", "minutes")),
            value: {
                from: 30,
                to: 60
            }
        }, {
            key: String.format("{0} ~ {1} {2}", "60", "120", _VST("common", "minutes")),
            value: {
                from: 60,
                to: 120
            }
        }, {
            key: String.format(_VST("filter", "andabove"), "120 " + _VST("common", "minutes")),
            value: {
                from: 120,
                to: -1
            }
        }],
        instance: null,
        get: function() {
            return Ext.isObject(SYNO.SDS.VideoStation2.Filter.instance) || (SYNO.SDS.VideoStation2.Filter.instance = new SYNO.SDS.VideoStation2.Filter), SYNO.SDS.VideoStation2.Filter.instance
        },
        getLocalFilterData: function(t) {
            switch (t) {
                case SYNO.SDS.VideoStation2.Filter.FILTER_RATING:
                    return SYNO.SDS.VideoStation2.Filter.DATA_RATING;
                case SYNO.SDS.VideoStation2.Filter.FILTER_RESOLUTION:
                    return SYNO.SDS.VideoStation2.Filter.DATA_RESOLUTION;
                case SYNO.SDS.VideoStation2.Filter.FILTER_WATCHED_STATUS:
                    return SYNO.SDS.VideoStation2.Filter.DATA_WATCHED_STATUS;
                case SYNO.SDS.VideoStation2.Filter.FILTER_FILE_COUNT:
                    return SYNO.SDS.VideoStation2.Filter.DATA_FILE_COUNT;
                case SYNO.SDS.VideoStation2.Filter.FILTER_DURATION:
                    return SYNO.SDS.VideoStation2.Filter.DATA_DURATION;
                default:
                    throw String.format("no such local filter {0}", t)
            }
        }
    },
    extend: "Ext.util.Observable",
    constructor: function() {
        this.callParent(arguments), this.addEvents(SYNO.SDS.VideoStation2.Filter.EVENT_FILTER_CHANGE), this.current_filter = {}, this.current_keyword = ""
    },
    addFilter: function(t, e) {
        this.hasFilter(t, e) || (this.current_filter[t] = this.current_filter[t] || [], this.current_filter[t].push(e), this.fireEvent(SYNO.SDS.VideoStation2.Filter.EVENT_FILTER_CHANGE, t))
    },
    deleteFilter: function(t, e) {
        this.hasFilter(t, e) && (this.current_filter[t] = this.current_filter[t].filter(function(t) {
            return t.key !== e.key
        }), 0 === this.current_filter[t].length && delete this.current_filter[t], this.fireEvent(SYNO.SDS.VideoStation2.Filter.EVENT_FILTER_CHANGE, t))
    },
    toggleFilter: function(t, e) {
        this.hasFilter(t, e) ? this.deleteFilter(t, e) : this.addFilter(t, e)
    },
    hasFilter: function(t, e) {
        if (!this.current_filter[t]) return !1;
        var i = !1;
        return Ext.each(this.current_filter[t], function(t) {
            if (t.key === e.key) return i = !0, !1
        }), i
    },
    setKeyword: function(t) {
        this.current_keyword !== t && (this.current_keyword = t, this.fireEvent(SYNO.SDS.VideoStation2.Filter.EVENT_FILTER_CHANGE, SYNO.SDS.VideoStation2.Filter.FILTER_KEYWORD))
    },
    hasKeyword: function() {
        return !Ext.isEmpty(this.current_keyword)
    },
    clearFilter: function(t) {
        if (t === SYNO.SDS.VideoStation2.Filter.FILTER_KEYWORD) return void(this.hasKeyword() && (this.current_keyword = "", this.fireEvent(SYNO.SDS.VideoStation2.Filter.EVENT_FILTER_CHANGE, SYNO.SDS.VideoStation2.Filter.FILTER_KEYWORD)));
        this.current_filter[t] && (delete this.current_filter[t], this.fireEvent(SYNO.SDS.VideoStation2.Filter.EVENT_FILTER_CHANGE, t))
    },
    clearAllFilter: function() {
        Object.keys(this.current_filter).forEach(function(t) {
            this.clearFilter(t)
        }, this), this.clearFilter(SYNO.SDS.VideoStation2.Filter.FILTER_KEYWORD)
    },
    isFilterEmpty: function() {
        return 0 === Object.keys(this.current_filter).length
    },
    getFilter: function(t) {
        return this.current_filter[t]
    },
    getFilterOption: function() {
        var t = {};
        return Ext.iterate(this.current_filter, function(e, i) {
            t[e] = i.map(function(t) {
                return t.value
            })
        }), t
    },
    getKeywordOption: function() {
        var t = {};
        return this.hasKeyword() && (t[SYNO.SDS.VideoStation2.Filter.FILTER_KEYWORD] = this.getKeyword()), t
    },
    getKeyword: function() {
        return this.current_keyword
    },
    current_filter: null,
    current_keyword: null
}), Ext.define("SYNO.SDS.VideoStation2.Util", {
    singleton: !0,
    applyCallback: function(t) {
        Ext.isObject(t) && Ext.isFunction(t.fn) && t.fn.apply(t.scope || window, t.args || [])
    },
    convertCollectionID: function(t) {
        return Ext.isArray(t) ? t.map(function(t) {
            var e = parseInt(t.id, 10),
                i = t.title;
            return SYNO.SDS.VideoStation2.Constant.TITLE_FAVORITE === i ? e = -1 : SYNO.SDS.VideoStation2.Constant.TITLE_WATCHLIST === i && (e = -2), {
                id: e,
                title: t.title
            }
        }) : t
    },
    getVideoActionString: function(t) {
        var e = ["view_video_info", "edit_metadata", "correct_metadata", "set_watched", "set_unwatched", "del_file", "del_video"],
            i = ["search_subtitle"],
            o = ["public_sharing"],
            n = ["offline_conversion"];
        return -1 !== e.indexOf(t) ? _VST("action", t) : -1 !== i.indexOf(t) ? _VST("controller", t) : -1 !== o.indexOf(t) ? _VST("advanced", t) : -1 !== n.indexOf(t) ? _VST(t, "action") : void 0
    },
    getFilterCategoryString: function(t) {
        switch (t) {
            case SYNO.SDS.VideoStation2.Filter.FILTER_ACTOR:
                return _VST("actor", "title");
            case SYNO.SDS.VideoStation2.Filter.FILTER_DIRECTOR:
                return _VST("director", "title");
            case SYNO.SDS.VideoStation2.Filter.FILTER_GENRE:
                return _VST("genre", "title");
            case SYNO.SDS.VideoStation2.Filter.FILTER_WRITER:
                return _VST("writer", "title");
            case SYNO.SDS.VideoStation2.Filter.FILTER_CERTIFICATE:
                return _VST("metadata", "rating_classification");
            case SYNO.SDS.VideoStation2.Filter.FILTER_RATING:
                return _VST("metadata", "rating");
            case SYNO.SDS.VideoStation2.Filter.FILTER_YEAR:
                return _VST("year", "title");
            case SYNO.SDS.VideoStation2.Filter.FILTER_RESOLUTION:
                return _VST("video_info", "resolution");
            case SYNO.SDS.VideoStation2.Filter.FILTER_WATCHED_STATUS:
                return _VST("common", "watch_status");
            case SYNO.SDS.VideoStation2.Filter.FILTER_FILE_COUNT:
                return _VST("filter", "file_count");
            case SYNO.SDS.VideoStation2.Filter.FILTER_CONTAINER:
                return _VST("video_info", "container");
            case SYNO.SDS.VideoStation2.Filter.FILTER_DURATION:
                return _VST("duration", "title");
            case SYNO.SDS.VideoStation2.Filter.FILTER_DATE:
                return _VST("classification", "bydate");
            case SYNO.SDS.VideoStation2.Filter.FILTER_CHANNEL_NAME:
                return _VST("classification", "bychannel");
            case SYNO.SDS.VideoStation2.Filter.FILTER_TITLE:
                return _VST("classification", "byprogram");
            case SYNO.SDS.VideoStation2.Filter.FILTER_KEYWORD:
                return _VST("search", "keyword");
            default:
                return ""
        }
    },
    getRecordingActionString: function(t) {
        return t === SYNO.SDS.VideoStation2.Constant.RECORDING_ACTION_KEY.RECORDING_CREATE_USERDEFINE ? _VST("schedule", t) : _VST("action", t)
    },
    getAPIName: function(t) {
        switch (t) {
            case SYNO.SDS.VideoStation2.Constant.MOVIE:
                return "SYNO.VideoStation2.Movie";
            case SYNO.SDS.VideoStation2.Constant.TVSHOW:
                return "SYNO.VideoStation2.TVShow";
            case SYNO.SDS.VideoStation2.Constant.TVSHOW_EPISODE:
                return "SYNO.VideoStation2.TVShowEpisode";
            case SYNO.SDS.VideoStation2.Constant.HOME_VIDEO:
                return "SYNO.VideoStation2.HomeVideo";
            case SYNO.SDS.VideoStation2.Constant.TV_RECORDING:
                return "SYNO.VideoStation2.TVRecording";
            default:
                throw String.format("unexpected type {0}", t)
        }
    },
    getVideoRoot: function(t) {
        switch (t) {
            case SYNO.SDS.VideoStation2.Constant.MOVIE:
                return "movie";
            case SYNO.SDS.VideoStation2.Constant.TVSHOW:
                return "tvshow";
            case SYNO.SDS.VideoStation2.Constant.TVSHOW_EPISODE:
                return "episode";
            case SYNO.SDS.VideoStation2.Constant.HOME_VIDEO:
                return "video";
            case SYNO.SDS.VideoStation2.Constant.TV_RECORDING:
                return "recording";
            default:
                throw String.format("unexpected type {0}", t)
        }
    },
    getWebAPIURL: function(t) {
        return String.format("{0}/{1}", "webapi/VideoStation", t)
    },
    getCGIURL: function(t) {
        return String.format("webman/3rdparty/VideoStation/cgi/{0}", t)
    },
    getImageURL: function(t) {
        return t = Ext.apply(t || {}, {
            api: "SYNO.VideoStation2.Poster",
            method: "get",
            version: "1"
        }), SYNO.SDS.UIFeatures.test("isRetina") && Ext.apply(t, {
            resolution: Ext.encode("2x")
        }), Ext.urlAppend("webapi/entry.cgi", Ext.urlEncode(t))
    },
    getImageURLByRecord: function(t, e) {
        return SYNO.SDS.VideoStation2.Util.getImageURL({
            type: Ext.isString(e) ? e : t.type,
            id: t.id,
            mtime: t.additional ? t.additional.poster_mtime || "" : ""
        })
    },
    getBackdropURL: function(t) {
        return t = Ext.apply(t || {}, {
            api: "SYNO.VideoStation2.Backdrop",
            method: "get",
            version: "1"
        }), Ext.urlAppend("webapi/entry.cgi", Ext.urlEncode(t))
    },
    getVideoDate: function(t) {
        var e = "";
        return Ext.isString(t.original_available) && !Ext.isEmpty(t.original_available) ? e = "0" === t.original_available ? "" : t.original_available.split("-")[0] : Ext.isString(t.record_date) && !Ext.isEmpty(t.record_date) && (e = "0" === t.record_date ? "" : t.record_date.split(" ")[0]), "" !== e && SYNO.SDS.DateTimeFormatter && (e = SYNO.SDS.DateTimeFormatter(Date.parseDate(e, "Y-m-d"), {
            type: "date"
        }) || e), e
    },
    getYMDFormatedDate: function(t) {
        return "" === t ? t : Date.parseDate(t, SYNO.SDS.DateTimeUtils.GetDateFormat()).format("Y-m-d")
    },
    hideDTVUI: function() {
        return SYNO.SDS.isNSM || "yes" === _D("support_dual_head") || SYNO.SDS.Utils.isInVirtualDSM() || "yes" === _D("dockerdsm")
    },
    isWatched: function(t) {
        return Ext.isNumber(t) && 1 === t
    },
    isUnwatched: function(t) {
        return Ext.isNumber(t) && 0 === Math.floor(100 * t)
    },
    classifyVideos: function(t) {
        var e = {};
        return t.forEach(function(t) {
            e[t.type] = e[t.type] || [], e[t.type].push(t)
        }), e
    },
    formatBitrate: function(t) {
        var e = parseInt(t, 10),
            i = (e / 1024).toFixed(1);
        return String.format("{0} Kbps", i)
    },
    extractFileName: function(t) {
        return t.substring(t.lastIndexOf("/") + 1)
    },
    getShareData: function(t) {
        var e = t,
            i = e.indexOf("/", 1),
            o = "";
        return e = e.substr(1), i > 0 && (o = e.substr(i), e = e.substr(0, i - 1)), {
            share: Ext.util.Format.lowercase(e),
            orishare: e,
            subpath: o
        }
    },
    getLangStore: function() {
        var t = SYNO.SDS.Utils.getSupportedLanguage();
        return new Ext.data.SimpleStore({
            fields: ["value", "display"],
            data: t,
            autoDestroy: !0
        })
    },
    onProxyBeforeLoad: function(t, e) {
        var i = t.activeRequest.read;
        i && Ext.Ajax.abort(i)
    },
    getCombinationPosterDiv: function(t, e) {
        return Ext.isArray(t) && Ext.isFunction(e) ? 1 === t.length ? String.format('<div class="center loading" url="{0}"></div>', e(t[0])) : 2 === t.length ? [String.format('<div class="top loading" url="{0}"></div>', e(t[0])), String.format('<div class="bottom loading" url="{0}"></div>', e(t[1]))].join("") : 3 === t.length ? [String.format('<div class="top loading" url="{0}"></div>', e(t[0])), String.format('<div class="bottom-left loading" url="{0}"></div>', e(t[1])), String.format('<div class="bottom-right loading" url="{0}"></div>', e(t[2]))].join("") : 4 <= t.length ? [String.format('<div class="top-left loading" url="{0}"></div>', e(t[0])), String.format('<div class="top-right loading" url="{0}"></div>', e(t[1])), String.format('<div class="bottom-left loading" url="{0}"></div>', e(t[2])), String.format('<div class="bottom-right loading" url="{0}"></div>', e(t[3]))].join("") : "" : ""
    },
    getWatchStatusDiv: function(t) {
        var e = t.additional || {};
        if (Ext.isDefined(e.total_seasons)) return "";
        var i = e.watched_ratio || 0;
        return i = 0 === i ? 0 : Math.floor(100 * i), 100 === i ? "" : ['<div class="watch-status-wrap">', '<div class="grey-bar"></div>', String.format('<div class="blue-bar" style="width:{0}%"></div>', i), "</div>"].join("")
    },
    mask: function(t, e, i, o, n, r) {
        var a;
        if (t && (a = t.getEl())) {
            a.delayedUnmask && (a.delayedUnmask.cancel(), a.delayedUnmask = null), a.mask.apply(a, Array.prototype.slice.call(arguments, 1, 3));
            var s = a.down(".ext-el-mask");
            if (s.addClass("syno-vs2-el-mask"), Ext.isFunction(o)) {
                var l = a.down(".ext-el-mask-msg div");
                l.addClass("clickable"), l.on("click", o, r)
            }
            a.delayedMask && (a.delayedMask.cancel(), a.delayedMask = null), a.delayedMask = new Ext.util.DelayedTask(function() {
                s && s.dom && s.addClass("mask"), a.delayedMask = null
            }), a.delayedMask.delay(n || 1)
        }
    },
    delayMask: function(t, e, i, o) {
        SYNO.SDS.VideoStation2.Util.mask(t, e, i, o, 500)
    },
    unmask: function(t) {
        var e;
        if (t && (e = t.getEl())) {
            e.delayedMask && (e.delayedMask.cancel(), e.delayedMask = null);
            var i = e.down(".ext-el-mask");
            i && (e.delayedUnmask || (i.addClass("unmask"), e.delayedUnmask = new Ext.util.DelayedTask(function() {
                e.unmask(), e.delayedUnmask = null
            })), e.delayedUnmask.delay(300))
        }
    },
    maskLoading: function(t, e) {
        var i = _T("common", "loading");
        SYNO.SDS.VideoStation2.Util.maskLoadingMsg(t, i, e)
    },
    maskLoadingMsg: function(t, e, i) {
        SYNO.SDS.VideoStation2.Util[i ? "delayMask" : "mask"](t, e, "x-mask-loading syno-vs2-mask-loading")
    },
    maskInfo: function(t, e, i, o, n) {
        SYNO.SDS.VideoStation2.Util[o ? "delayMask" : "mask"](t, e, "syno-ux-mask-info syno-vs2-mask-info", i, null, n)
    },
    findValueInObject: function(t, e) {
        var i;
        return Ext.iterate(t, function(t, o) {
            if (t === e) return i = o, !1;
            if (Ext.isObject(o)) {
                var n = SYNO.SDS.VideoStation2.Util.findValueInObject(o, e);
                if (Ext.isDefined(n)) return i = n, !1
            }
        }), i
    },
    launchHelp: function() {
        SYNO.SDS.WindowLaunch("SYNO.SDS.HelpBrowser.Application", {
            topic: "SYNO.SDS.VideoStation.AppInstance"
        })
    },
    getPathTitleForEpisode: function(t, e) {
        var i = [t > 0 ? String.format(_VST("episode", "title"), t) : _VST("metadata", "unknown")];
        return Ext.isEmpty(e) || i.push(e), i.join(" - ")
    },
    getPathTitleForOfflineEpisode: function(t) {
        var e = [t.title],
            i = "";
        return 0 < t.season && (i = String.format("S{0}", t.season)), 0 < t.episode && (i += String.format("E{0}", t.episode)), Ext.isEmpty(i) || e.push(i), Ext.isEmpty(t.tagline) || e.push(t.tagline), e.join(" - ")
    },
    getLibraryTypeByVideoType: function(t) {
        return t === SYNO.SDS.VideoStation2.Constant.TVSHOW_EPISODE ? SYNO.SDS.VideoStation2.Constant.TVSHOW : t
    },
    getTVShowEpisodeTitle: function(t) {
        var e = t.episode > 0 ? String.format(_VST("episode", "title"), t.episode) : _VST("metadata", "unknown");
        return Ext.isString(t.tagline) && !Ext.isEmpty(t.tagline) ? t.tagline : e
    },
    getTVShowEpisodeDescription: function(t) {
        return t.episode > 0 ? String.format(_VST("episode", "title"), t.episode) : ""
    },
    parseLazyDate: function(t, e, i) {
        e = e || "-", i = i || ":";
        var o = t.split(" "),
            n = [],
            r = [];
        return 1 <= o.length && (n = o[0].split(e)), 2 <= o.length && (r = o[1].split(i)), {
            year: 1 <= n.length ? parseInt(n[0], 10) : 1970,
            month: 2 <= n.length ? parseInt(n[1], 10) : 1,
            day: 3 <= n.length ? parseInt(n[2], 10) : 1,
            hour: 1 <= r.length ? parseInt(r[0], 10) : 0,
            minute: 2 <= r.length ? parseInt(r[1], 10) : 0,
            second: 3 <= r.length ? parseInt(r[2], 10) : 0
        }
    },
    lengthValidator: function(t, e) {
        return window.unescape(encodeURIComponent(t)).length <= e
    },
    copyTextFieldContent: function(t) {
        var e = Ext.getCmp(t),
            i = e.readOnly;
        e.setReadOnly(!1), e.focus(!0, 0), document.execCommand("copy"), e.setReadOnly(i)
    }
}), Ext.define("SYNO.SDS.VideoStation2.FilteringBaseProxy", {
    extend: "SYNO.API.Proxy",
    constructor: function(t) {
        this.callParent([t])
    },
    onRequestAPI: function(t, e, i, o, n, r, a, s, l) {
        try {
            var S = n.getRoot(e);
            Ext.each(S, function(t) {
                Ext.isObject(t.additional) && (t.additional.collection && (t.additional.collection = SYNO.SDS.VideoStation2.Util.convertCollectionID(t.additional.collection)), t.additional.extra && (t.additional.extra = Ext.decode(t.additional.extra)), t.additional.tvshow_extra && (t.additional.tvshow_extra = Ext.decode(t.additional.tvshow_extra)))
            }, this), this.callParent(arguments)
        } catch (t) {
            return this.fireEvent("loadexception", this, s, e, t), void this.fireEvent("exception", this, "response", l, s, e, t)
        }
    }
}), Ext.define("SYNO.SDS.VideoStation2.ByFolderProxy", {
    extend: "SYNO.API.Proxy",
    constructor: function(t) {
        this.callParent([t])
    },
    onRequestAPI: function(t, e, i, o, n, r, a, s, l) {
        try {
            var S = 0,
                c = n.getRoot(e);
            Ext.each(c, function(t) {
                t.additional && t.additional.collection && (t.additional.collection = SYNO.SDS.VideoStation2.Util.convertCollectionID(t.additional.collection)), SYNO.SDS.VideoStation2.Constant.FOLDER === t.type && (S += 1)
            }, this), 0 < S && (c[S - 1].last_folder = !0), this.callParent(arguments)
        } catch (t) {
            return this.fireEvent("loadexception", this, s, e, t), void this.fireEvent("exception", this, "response", l, s, e, t)
        }
    }
}), Ext.define("SYNO.SDS.VideoStation2.FilterMetadataProxy", {
    extend: "SYNO.API.Proxy",
    constructor: function(t) {
        this.callParent([t])
    },
    onRequestAPI: function(t, e, i, o, n, r, a, s, l) {
        e.metadata = e.metadata.map(function(t) {
            return {
                key: t,
                value: t
            }
        }), this.callParent(arguments)
    }
}), Ext.define("SYNO.SDS.VideoStation2.Util.Styles", {
    singleton: !0,
    updateMarginBySelector: function(t, e, i, o, n) {
        var r, a, s = SYNO.SDS.VideoStation2.Util.Styles;
        if (s.styleRules || (s.styleRules = {}), a = s.getVideoStyleRule(t)) {
            var l = i - 32 + n;
            l = 0 >= l ? i : l, r = Math.floor(l / (o + n)), r < 1 && (r = 1), a.style[e] = String.format("calc(99% / {0} - {1}px)", r, o)
        }
    },
    getVideoStyleRule: function(t) {
        var e, i = SYNO.SDS.VideoStation2.Util.Styles;
        if (i.styleRules[t]) return i.styleRules[t];
        if (!document.styleSheets) return null;
        for (e = document.styleSheets.length - 1; e >= 0; e--)
            if (Ext.isString(document.styleSheets[e].href) && document.styleSheets[e].href.indexOf("/VideoStation/style.css") >= 0) return i.styleRules[t] = i.getRuleBySelector(document.styleSheets[e], t), i.styleRules[t];
        return null
    },
    getRuleBySelector: function(t, e) {
        var i, o, n;
        if (!t.rules) return null;
        for (i = 0, o = t.rules.length; i < o; i++)
            if (n = t.rules[i], Ext.isString(n.selectorText) && n.selectorText === e) return n;
        return null
    }
}), Ext.define("SYNO.SDS.VideoStation2.VoiceAssistantPlugin.FormPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(t) {
        this.callParent([t])
    },
    isDirty: function() {
        return !SYNO.ux.Utils.checkObjectConsistency(this._originalValues, this.getForm().getValues())
    },
    rejectChanges: function() {
        if (!this.isDirty()) return void this.owner.setStatusError({
            text: _T("error", "nochange_subject"),
            clear: !0
        });
        this.getForm().setValues(this._originalValues)
    },
    loadData: function() {
        var t = this;
        return this.owner.setStatusBusy(), this.loadDataImp().then(function() {
            t.owner.clearStatusBusy()
        }).catch(function(e) {
            t.owner.clearStatusBusy(), t.owner.getMsgBox().alert("", SYNO.SDS.VideoStation2.Error.getAPIErrorString(e))
        })
    },
    saveChanges: function() {
        var t = this;
        return this.isDirty() ? (this.owner.setStatusBusy(), this.saveChangesImp().then(function() {
            t.owner.clearStatusBusy(), t.owner.setStatusOK()
        })) : (this.owner.setStatusError({
            text: _T("error", "nochange_subject"),
            clear: !0
        }), Promise.resolve())
    }
}), Ext.define("SYNO.SDS.VideoStation2.VoiceAssistantPlugin.AudioSubtitlePanel", {
    extend: "SYNO.SDS.VideoStation2.VoiceAssistantPlugin.FormPanel",
    constructor: function(t) {
        this._subtitleSetting = new SYNO.SDS.VideoStation2.VoiceAssistantPlugin.SettingPanel.SubtitleSetting, this._audioTrackSetting = new SYNO.SDS.VideoStation2.VoiceAssistantPlugin.SettingPanel.AudioTrackSetting;
        var e = {
            title: _VST("voice_assistant", "audio_subtitle_setting_title"),
            labelWidth: 235,
            trackResetOnLoad: !0,
            items: [{
                xtype: "syno_displayfield",
                itemId: "audio_subtitle_setting_description",
                name: "audio_subtitle_setting_description",
                value: _VST("voice_assistant", "audio_subtitle_setting_description"),
                style: {
                    marginBottom: "2px"
                }
            }, this._subtitleSetting, this._audioTrackSetting],
            listeners: {
                scope: this,
                activate: {
                    fn: this.loadData
                },
                afterrender: {
                    fn: this.onAfterRender,
                    single: !0
                }
            }
        };
        this.callParent([Ext.apply(e, t)]), this.updateScrollBarEventNames.push(SYNO.SDS.VideoStation2.VAP.SettingPanel.Constant.EVENT_HEIGHT_CHANGE), this.items.each(function(t) {
            this.relayEvents(t, [SYNO.SDS.VideoStation2.VAP.SettingPanel.Constant.EVENT_HEIGHT_CHANGE])
        }, this)
    },
    onAfterRender: function() {
        this.enableCheckGroup()
    },
    enableCheckGroup: function() {
        new SYNO.ux.Utils.EnableCheckGroup(this.getForm(), "enable_subtitle", ["subtitle_priority_1", "subtitle_priority_2", "subtitle_priority_3"]), this.hiddenCheckGroup("enable_subtitle", ["subtitle_priority_1", "subtitle_priority_2", "subtitle_priority_3"])
    },
    hiddenCheckGroup: function(t, e) {
        var i = this,
            o = SYNO.ux.Utils.findFormField(this.getForm(), t),
            n = function(t, o) {
                for (var n = 0; n < e.length; n++) {
                    SYNO.ux.Utils.findFormField(i.getForm(), e[n]).setVisible(o)
                }
            };
        o.mon(o, "check", n), n(0, o.getValue())
    },
    loadDataImp: function() {
        var t = this;
        return SYNO.SDS.VideoStation2.PromiseOP.get().getVoiceAssistantSetting({}, {
            catch: !0
        }).then(function(e) {
            t.applyValuesToForm(e)
        })
    },
    saveChangesImp: function() {
        var t = this;
        return SYNO.SDS.VideoStation2.PromiseOP.get().setVoiceAssistantSetting(this.toVoiceAssistantSetting(), {
            catch: !0
        }).then(function() {
            t.applyValuesToForm(t.toVoiceAssistantSetting())
        })
    },
    toVoiceAssistantSetting: function() {
        var t = SYNO.Util.copy(this.getForm().getValues()),
            e = function(t, e) {
                !Ext.isEmpty(e) && Ext.isString(e) && t.push(e === SYNO.SDS.VideoStation2.VAP.SettingPanel.Constant.DEFAULT_TRACK ? "" : e)
            };
        return t.enable_subtitle = "true" === t.enable_subtitle, t.enable_subtitle ? (t.subtitle_priority = [], e(t.subtitle_priority, t.subtitle_priority_1), e(t.subtitle_priority, t.subtitle_priority_2), e(t.subtitle_priority, t.subtitle_priority_3), Ext.isEmpty(t.subtitle_priority) && t.subtitle_priority.push("")) : delete t.subtitle_priority, delete t.subtitle_priority_1, delete t.subtitle_priority_2, delete t.subtitle_priority_3, t.audio_priority = [], e(t.audio_priority, t.audio_track_priority_1), e(t.audio_priority, t.audio_track_priority_2), e(t.audio_priority, t.audio_track_priority_3), Ext.isEmpty(t.audio_priority) && t.audio_priority.push(""), delete t.audio_track_priority_1, delete t.audio_track_priority_2, delete t.audio_track_priority_3, t
    },
    applyValuesToForm: function(t) {
        var e = SYNO.Util.copy(t),
            i = function(t) {
                return Ext.isString(t) ? Ext.isEmpty(t) ? SYNO.SDS.VideoStation2.VAP.SettingPanel.Constant.DEFAULT_TRACK : t : ""
            };
        e.enable_subtitle && (e.subtitle_priority_1 = i(e.subtitle_priority[0]), e.subtitle_priority_2 = i(e.subtitle_priority[1]), e.subtitle_priority_3 = i(e.subtitle_priority[2])), delete e.subtitle_priority, e.audio_track_priority_1 = i(e.audio_priority[0]), e.audio_track_priority_2 = i(e.audio_priority[1]), e.audio_track_priority_3 = i(e.audio_priority[2]), delete e.audio_priority, delete e.enable_auto_resume, delete e.remote_player_id, delete e.remote_player_title, this.getForm().setValues(e), this._originalValues = this.getForm().getValues()
    }
}), Ext.define("SYNO.SDS.VideoStation2.VoiceAssistantPlugin.GeneralPanel", {
    extend: "SYNO.SDS.VideoStation2.VoiceAssistantPlugin.FormPanel",
    constructor: function(t) {
        this._miscSetting = new SYNO.SDS.VideoStation2.VoiceAssistantPlugin.SettingPanel.MiscSetting({
            owner: t.owner
        });
        var e = {
            title: _VST("voice_assistant", "general_setting_title"),
            labelWidth: 203,
            trackResetOnLoad: !0,
            items: [this._miscSetting],
            listeners: {
                scope: this,
                activate: {
                    fn: this.loadData
                }
            }
        };
        this.callParent([Ext.apply(e, t)])
    },
    loadDataImp: function() {
        var t = this;
        return Promise.all([SYNO.SDS.VideoStation2.PromiseOP.get().getVoiceAssistantSetting({}, {
            catch: !0
        }), SYNO.SDS.VideoStation2.PromiseOP.get().listControllerDevice({
            limit: SYNO.SDS.VideoStation2.Constant.STORE_UNLIMIT
        }, {
            catch: !0
        })]).then(function(e) {
            t.applyValuesToForm(e)
        })
    },
    saveChangesImp: function() {
        var t = this;
        return SYNO.SDS.VideoStation2.PromiseOP.get().setVoiceAssistantSetting(this.toVoiceAssistantSetting(), {
            catch: !0
        }).then(function() {
            t._originalValues = t.getForm().getValues()
        })
    },
    toVoiceAssistantSetting: function() {
        var t = SYNO.Util.copy(this.getForm().getValues());
        return t.enable_auto_resume = "true" === t.enable_auto_resume, t.remote_player_title = this._miscSetting.getRemotePlayerCombobox().getRawValue(), t
    },
    applyValuesToForm: function(t) {
        var e = SYNO.Util.copy(t[0]);
        delete e.enable_subtitle, delete e.subtitle_priority, delete e.audio_priority, this.getForm().setValues(e), this._originalValues = this.getForm().getValues(), this._miscSetting.loadDataRemotePlayer(SYNO.SDS.VideoStation2.VAP.Util.controllerDeviceToRecord({
            id: e.remote_player_id,
            title: e.remote_player_title
        }, t[1].device))
    }
}), Ext.define("SYNO.SDS.VideoStation2.VAP.SettingPanel.Constant", {
    statics: {
        EVENT_HEIGHT_CHANGE: "heightchange",
        DEFAULT_TRACK: "SYNO_DEFAULT_TRACK_LOGY"
    }
}), Ext.define("SYNO.SDS.VideoStation2.VAP.Util", {
    singleton: !0,
    getLanguageStoreWithDefault: function() {
        var t = SYNO.SDS.VideoStation2.Util.getLangStore();
        return t.insert(0, [new t.recordType({
            value: SYNO.SDS.VideoStation2.VAP.SettingPanel.Constant.DEFAULT_TRACK,
            display: _T("common", "default")
        })]), t
    },
    getComboboxConfig: function(t, e) {
        return {
            xtype: "syno_combobox",
            name: t,
            indent: e,
            fieldLabel: _VST("voice_assistant", t),
            valueField: "value",
            displayField: "display",
            maxLength: 100,
            width: 240,
            editable: !0
        }
    },
    controllerDeviceToRecord: function(t, e) {
        var i = [];
        return t.id && -1 === e.findIndex(function(e) {
            return e.id === t.id
        }) && i.push({
            value: t.id,
            display: t.title ? t.title : t.id
        }), i.concat(e.map(function(t) {
            return {
                value: t.id,
                display: t.title
            }
        }))
    }
}), Ext.define("SYNO.SDS.VideoStation2.VoiceAssistantPlugin.SettingPanel.SubtitleSetting", {
    extend: "SYNO.ux.FieldSet",
    constructor: function(t) {
        var e = {
            title: _VST("voice_assistant", "subtitle_settings"),
            collapsible: !0,
            items: this.getItems()
        };
        this.callParent([Ext.apply(e, t)])
    },
    getStore: function() {
        return this._store = this._store || SYNO.SDS.VideoStation2.VAP.Util.getLanguageStoreWithDefault(), this._store
    },
    getItems: function() {
        return [{
            xtype: "syno_checkbox",
            name: "enable_subtitle",
            boxLabel: _VST("voice_assistant", "enable_subtitle"),
            listeners: {
                scope: this,
                check: this.notifyHeightChange
            }
        }, Ext.apply(SYNO.SDS.VideoStation2.VAP.Util.getComboboxConfig("subtitle_priority_1", 1), {
            store: this.getStore()
        }), Ext.apply(SYNO.SDS.VideoStation2.VAP.Util.getComboboxConfig("subtitle_priority_2", 1), {
            store: this.getStore()
        }), Ext.apply(SYNO.SDS.VideoStation2.VAP.Util.getComboboxConfig("subtitle_priority_3", 1), {
            store: this.getStore()
        })]
    },
    notifyHeightChange: function() {
        this.fireEvent(SYNO.SDS.VideoStation2.VAP.SettingPanel.Constant.EVENT_HEIGHT_CHANGE)
    }
}), Ext.define("SYNO.SDS.VideoStation2.VoiceAssistantPlugin.SettingPanel.AudioTrackSetting", {
    extend: "SYNO.ux.FieldSet",
    constructor: function(t) {
        var e = {
            title: _VST("voice_assistant", "audio_track_settings"),
            collapsible: !0,
            items: this.getItems()
        };
        this.callParent([Ext.apply(e, t)])
    },
    getStore: function() {
        return this._store = this._store || SYNO.SDS.VideoStation2.VAP.Util.getLanguageStoreWithDefault(), this._store
    },
    getItems: function() {
        return [Ext.apply(SYNO.SDS.VideoStation2.VAP.Util.getComboboxConfig("audio_track_priority_1", 0), {
            store: this.getStore()
        }), Ext.apply(SYNO.SDS.VideoStation2.VAP.Util.getComboboxConfig("audio_track_priority_2", 0), {
            store: this.getStore()
        }), Ext.apply(SYNO.SDS.VideoStation2.VAP.Util.getComboboxConfig("audio_track_priority_3", 0), {
            store: this.getStore()
        })]
    }
}), Ext.define("SYNO.SDS.VideoStation2.VoiceAssistantPlugin.SettingPanel.MiscSetting", {
    extend: "SYNO.ux.FieldSet",
    constructor: function(t) {
        var e = {
            items: this.getItems()
        };
        this.callParent([Ext.apply(e, t)])
    },
    getItems: function() {
        return [{
            xtype: "syno_displayfield",
            itemId: "misc_setting_description",
            name: "misc_setting_description",
            htmlEncode: !1,
            value: _VST("voice_assistant", "misc_setting_description")
        }, this.getRemotePlayerCombobox(), this.getRefreshButton(), {
            xtype: "syno_checkbox",
            name: "enable_auto_resume",
            boxLabel: _VST("voice_assistant", "enable_auto_resume")
        }]
    },
    getRefreshButton: function() {
        return this._refreshButton = this._refreshButton || new SYNO.ux.Button({
            cls: "refresh-button",
            text: _T("common", "refresh"),
            scope: this,
            width: 105,
            style: {
                marginLeft: "208px",
                marginBottom: "12px"
            },
            handler: this.loadRemotePlayer
        }), this._refreshButton
    },
    getRemotePlayerStore: function() {
        return this._store = this._store || new Ext.data.JsonStore({
            id: "value",
            fields: ["value", "display"],
            autoDestroy: !0
        }), this._store
    },
    getRemotePlayerCombobox: function() {
        return this._remotePlayerCombobox = this._remotePlayerCombobox || new SYNO.ux.ComboBox({
            name: "remote_player_id",
            itemId: "remote_player_id",
            fieldLabel: _VST("voice_assistant", "remote_player_name"),
            store: this.getRemotePlayerStore(),
            valueField: "value",
            displayField: "display",
            width: 260,
            indent: 0
        }), this._remotePlayerCombobox
    },
    setRemotePlayerSectionDisabled: function(t) {
        t && this.owner.setStatusBusy({
            text: _T("common", "searching")
        }), this._refreshButton.setDisabled(t), this._remotePlayerCombobox.setDisabled(t), t || this.owner.clearStatusBusy()
    },
    loadRemotePlayer: function() {
        var t = this;
        return this.setRemotePlayerSectionDisabled(!0), SYNO.SDS.VideoStation2.PromiseOP.get().listControllerDevice({
            limit: SYNO.SDS.VideoStation2.Constant.STORE_UNLIMIT
        }, {
            catch: !0
        }).then(function(e) {
            t.loadDataRemotePlayer(SYNO.SDS.VideoStation2.VAP.Util.controllerDeviceToRecord(t._remotePlayerCombobox.getValue(), e.device)), t.setRemotePlayerSectionDisabled(!1)
        }).catch(function(e) {
            t.setRemotePlayerSectionDisabled(!1)
        })
    },
    loadDataRemotePlayer: function(t) {
        this.getRemotePlayerStore().loadData(t), this._remotePlayerCombobox.setValue(this._remotePlayerCombobox.getValue())
    }
}), Ext.define("SYNO.SDS.VideoStation2.VoiceAssistantPlugin.SettingWindow", {
    extend: "SYNO.SDS.ModalWindow",
    initActiveTab: 0,
    constructor: function(t) {
        var e = this,
            i = {
                layout: "fit",
                width: 620,
                height: 500,
                minWidth: 620,
                minHeight: 400,
                title: _VST("voice_assistant", "setting_title"),
                closable: !0,
                onEsc: function() {
                    e.close()
                },
                items: [this.getTabPanel()],
                listeners: {
                    scope: this,
                    beforeclose: {
                        fn: this.onBeforeClose
                    }
                },
                buttons: [{
                    text: _T("common", "reset"),
                    scope: this,
                    handler: this.onReset
                }, {
                    text: _T("common", "commit"),
                    btnStyle: "blue",
                    scope: this,
                    handler: this.onApplyClick
                }]
            };
        this.callParent([Ext.apply(i, t)])
    },
    onBeforeClose: function() {
        var t = this;
        return !this.getTabPanel().isActiveTabDirty() || (this.confirmLostChangePromise({
            save: function() {
                return t.onApplyClick()
            },
            cancel: Ext.emptyFn,
            dontSave: function() {
                t.getTabPanel().getActiveTab().rejectChanges(), t.close()
            }
        }, this), !1)
    },
    onReset: function() {
        this.getTabPanel().getActiveTab().rejectChanges()
    },
    onApplyClick: function() {
        var t = this;
        return this.getTabPanel().getActiveTab().saveChanges().catch(function(e) {
            t.getMsgBox().alert("", SYNO.SDS.VideoStation2.Error.getAPIErrorString(e))
        })
    },
    getTabPanel: function() {
        return this._tabPanel = this._tabPanel || new SYNO.SDS.VideoStation2.VoiceAssistantPlugin.SettingTabPanel({
            owner: this,
            activeTab: this.initActiveTab
        }), this._tabPanel
    }
}), 
/**
 * @class SYNO.SDS.VideoStation2.VoiceAssistantPlugin.SettingTabPanel
 * @extends SYNO.ux.TabPanel
 * VideoStation voice assistant setting tab panel class
 *
 */
Ext.define("SYNO.SDS.VideoStation2.VoiceAssistantPlugin.SettingTabPanel", {
    extend: "SYNO.ux.TabPanel",
    constructor: function(t) {
        this.callParent([Ext.apply(this.getConfig(t), t)])
    },
    getConfig: function(t) {
        var e = [],
            i = ["getAudioSubtitlePanel", "getGeneralPanel"];
        return Ext.each(i, function(i) {
            var o = this[i]({
                owner: t.owner
            });
            Ext.isObject(o) && e.push(o)
        }, this), {
            activeTab: 0,
            items: e,
            listeners: {
                scope: this,
                beforetabchange: this.onBeforeTabChange
            }
        }
    },
    getAudioSubtitlePanel: function(t) {
        return this._audioSubtitle = this._audioSubtitle || new SYNO.SDS.VideoStation2.VoiceAssistantPlugin.AudioSubtitlePanel(t), this._audioSubtitle
    },
    getGeneralPanel: function(t) {
        return this._general = this._general || new SYNO.SDS.VideoStation2.VoiceAssistantPlugin.GeneralPanel(t), this._general
    },
    onBeforeTabChange: function(t, e, i) {
        return !this.isActiveTabDirty() || (this.ownerCt.confirmLeave(function(o) {
            "cancel" !== o && (Ext.isFunction(i.rejectChanges) && i.rejectChanges(), t.setActiveTab(e))
        }), !1)
    },
    isActiveTabDirty: function() {
        var t = this.getActiveTab();
        return Ext.isObject(t) && Ext.isFunction(t.isDirty) && t.isDirty()
    }
});
