/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.VideoStation.SharingAppWin");
Ext.define("SYNO.SDS.VideoStation.SharingAppWin", {
    extend: "SYNO.VideoController2.AppWindow",
    constructor: function(a) {
        var b = this.fillConfig(a);
        this.callParent([b]);
        this.addClass("syno-vs-sharing-appwin")
    },
    fillConfig: function(a) {
        var b = Ext.apply({
            headerAsText: true,
            headerCfg: {
                cls: "syno-vs-sharing-header"
            },
            maximized: true,
            maximizable: false,
            minimized: false,
            minimizable: false,
            closable: false,
            toggleMinimizable: false
        }, a);
        return b
    },
    onMainWindowShow: function() {
        this.header.setHeight(0);
        var a = Ext.getBody();
        this.onResize(a.getWidth(), a.getHeight());
        this.setTitle(_VST("controller", "public_sharing_title"));
        a.on("contextmenu", function(b) {
            b.stopEvent()
        }, this)
    },
    init: function() {
        if (this.initialized) {
            return
        }
        this.initialized = true
    },
    onOpen: function(b) {
        SYNO.SDS.AppWindow.superclass.onOpen.apply(this, arguments);
        this.registerOnExitHandler();
        var a = this.getControlPanel().getOptionsBar();
        this.getHeaderPanel().getCloseButton().hide();
        this.getSettingsMenu().getPlayerPanel().hide();
        if (!_S("IsSingleVideo")) {
            a.getListButton().show()
        }
        if (b.emptyCollection) {
            this.getController().toggleList();
            return
        }
        this.setStatusBusy();
        this.init_player_id = b.player_id;
        this.init_type_info = {
            type: b.browse_type,
            sharing_id: b.sharing_id
        };
        this.init_video_info = {
            video_id: parseInt(b.video_id, 10),
            type: b.video_type,
            file_id: b.file_id,
            title: b.title
        };
        this.getController().initSequenceVideo()
    },
    saveRestoreData: Ext.emptyFn
});
Ext.namespace("SYNO.SDS.VideoStation");
var _S, _TT, _VST, _VCT;
_S = function(a) {
    return SYNO.SDS.VideoStation.SessionData[a]
};
_VST = _VCT = function(b, a) {
    try {
        if (Ext.isDefined(SYNO_SDS_VideoStation_Strings)) {
            return SYNO_SDS_VideoStation_Strings[b][a]
        } else {
            return _TT("SYNO.SDS.VideoStation.AppInstance", b, a)
        }
    } catch (c) {
        return _T(b, a)
    }
};
SYNO.SDS.VideoStation.init = function() {
    var f;
    try {
        f = atob(location.hash.substr(2))
    } catch (d) {
        f = ""
    }
    var a = f.split("-");
    var c = Ext.isEmpty(a[1]) ? 0 : a[1];
    var b = Ext.isEmpty(a[0]) ? "movie" : a[0];
    var g = {
        api: "SYNO.VideoStation.Collection",
        method: "video_list",
        version: 2,
        sharing_id: _S("SharingId"),
        sort_by: "title",
        sort_direction: "asc",
        offset: 0,
        limit: -1
    };
    if (_S("IsSingleVideo")) {
        g.video_id = parseInt(c, 10);
        g.video_type = b
    }
    Ext.Ajax.request({
        url: String.format("{0}/{1}", "webapi/VideoStation", "collection.cgi"),
        params: g,
        callback: function(e, q, n) {
            if (q && n.responseText) {
                var k = Ext.util.JSON.decode(n.responseText);
                if (!k.success) {
                    return
                }
                var j = k.data.videos;
                var h = {
                    jsConfig: {
                        jsBaseURL: SYNO.SDS.VideoStation.SessionData.BaseUrl
                    }
                };
                var p = {
                    ieMode: 9,
                    player_id: "streaming",
                    browse_type: _S("IsSingleVideo") ? null : "collection"
                };
                if (j.length === 0) {
                    p = Ext.apply({
                        emptyCollection: true
                    }, p)
                } else {
                    var o = 0;
                    for (var l = 0; l < j.length; l++) {
                        if (j[l].id.toString() === c.toString() && j[l].type === b) {
                            o = l;
                            break
                        }
                    }
                    p = Ext.apply({
                        video_id: j[o].id,
                        video_type: j[o].type,
                        title: j[o].title,
                        sharing_id: _S("IsSingleVideo") ? null : _S("SharingId")
                    }, p)
                }
                var m = new SYNO.SDS.VideoStation.SharingAppWin(h);
                m.open(p);
                return
            }
            window.alert("failed to load video list")
        },
        scope: this
    })
};
Ext.onReady(function() {
    if (SYNO.SDS.VideoStation.SessionData.SynohdpackStatus && SYNO.SDS.UIFeatures.test("isRetina")) {
        Ext.getBody().addClass("synohdpack")
    }
    SYNO.SDS.StatusNotifier = new SYNO.SDS._StatusNotifier({});
    SYNO.SDS.WindowMgr = new SYNO.SDS._WindowMgr();
    if (!SYNO.API.Manager) {
        SYNO.API.Manager = new SYNO.API._Manager()
    }
    SYNO.API.Manager.queryAPI("all", SYNO.SDS.VideoStation.init)
});