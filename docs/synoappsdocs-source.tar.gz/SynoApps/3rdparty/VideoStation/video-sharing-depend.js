/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function _defineProperty(e, t, i) {
    return t in e ? Object.defineProperty(e, t, {
        value: i,
        enumerable: !0,
        configurable: !0,
        writable: !0
    }) : e[t] = i, e
}

function _possibleConstructorReturn(e, t) {
    return !t || "object" !== _typeof(t) && "function" != typeof t ? _assertThisInitialized(e) : t
}

function _assertThisInitialized(e) {
    if (void 0 === e) throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
    return e
}

function _getPrototypeOf(e) {
    return (_getPrototypeOf = Object.setPrototypeOf ? Object.getPrototypeOf : function(e) {
        return e.__proto__ || Object.getPrototypeOf(e)
    })(e)
}

function _inherits(e, t) {
    if ("function" != typeof t && null !== t) throw new TypeError("Super expression must either be null or a function");
    e.prototype = Object.create(t && t.prototype, {
        constructor: {
            value: e,
            writable: !0,
            configurable: !0
        }
    }), t && _setPrototypeOf(e, t)
}

function _setPrototypeOf(e, t) {
    return (_setPrototypeOf = Object.setPrototypeOf || function(e, t) {
        return e.__proto__ = t, e
    })(e, t)
}

function _classCallCheck(e, t) {
    if (!(e instanceof t)) throw new TypeError("Cannot call a class as a function")
}

function _defineProperties(e, t) {
    for (var i = 0; i < t.length; i++) {
        var s = t[i];
        s.enumerable = s.enumerable || !1, s.configurable = !0, "value" in s && (s.writable = !0), Object.defineProperty(e, s.key, s)
    }
}

function _createClass(e, t, i) {
    return t && _defineProperties(e.prototype, t), i && _defineProperties(e, i), e
}

function _typeof(e) {
    return (_typeof = "function" == typeof Symbol && "symbol" == typeof Symbol.iterator ? function(e) {
        return typeof e
    } : function(e) {
        return e && "function" == typeof Symbol && e.constructor === Symbol && e !== Symbol.prototype ? "symbol" : typeof e
    })(e)
}

function getModalWindow(e) {
    if (e) {
        if ("ModalWindow" === e.$options.name || "MessageBoxWindow" === e.$options.name || "WizardWindow" === e.$options.name) return e;
        var t = !0,
            i = !1,
            s = void 0;
        try {
            for (var n, r = e.$children[Symbol.iterator](); !(t = (n = r.next()).done); t = !0) {
                var o = n.value,
                    a = getModalWindow(o);
                if (a) return a
            }
        } catch (e) {
            i = !0, s = e
        } finally {
            try {
                t || null == r.return || r.return()
            } finally {
                if (i) throw s
            }
        }
    }
}

function inJsdom() {
    return navigator.userAgent.includes("Node.js") || navigator.userAgent.includes("jsdom")
}

function inJsdom() {
    return navigator.userAgent.includes("Node.js") || navigator.userAgent.includes("jsdom")
}
_TT = function(e, t, i) {
        try {
            return Ext.isDefined(SYNO_SDS_VideoStation_Strings) ? SYNO_SDS_VideoStation_Strings[t][i] : SYNO.SDS.Strings[e][t][i]
        } catch (e) {
            return ""
        }
    },
    function(e, t) {
        "use strict";

        function i(e) {
            return l[a] = s.apply(t, e), a++
        }

        function s(e) {
            var i = [].slice.call(arguments, 1);
            return function() {
                "function" == typeof e ? e.apply(t, i) : new Function("" + e)()
            }
        }

        function n(e) {
            if (c) setTimeout(s(n, e), 0);
            else {
                var t = l[e];
                if (t) {
                    c = !0;
                    try {
                        t()
                    } finally {
                        r(e), c = !1
                    }
                }
            }
        }

        function r(e) {
            delete l[e]
        }
        if (!e.setImmediate) {
            var o, a = 1,
                l = {},
                c = !1,
                d = e.document,
                h = Object.getPrototypeOf && Object.getPrototypeOf(e);
            h = h && h.setTimeout ? h : e, "[object process]" === {}.toString.call(e.process) ? function() {
                o = function() {
                    var e = i(arguments);
                    return process.nextTick(s(n, e)), e
                }
            }() : function() {
                if (e.postMessage && !e.importScripts) {
                    var t = !0,
                        i = e.onmessage;
                    return e.onmessage = function() {
                        t = !1
                    }, e.postMessage("", "*"), e.onmessage = i, t
                }
            }() ? function() {
                var t = "setImmediate$" + Math.random() + "$",
                    s = function(i) {
                        i.source === e && "string" == typeof i.data && 0 === i.data.indexOf(t) && n(+i.data.slice(t.length))
                    };
                e.addEventListener ? e.addEventListener("message", s, !1) : e.attachEvent("onmessage", s), o = function() {
                    var s = i(arguments);
                    return e.postMessage(t + s, "*"), s
                }
            }() : e.MessageChannel ? function() {
                var e = new MessageChannel;
                e.port1.onmessage = function(e) {
                    n(e.data)
                }, o = function() {
                    var t = i(arguments);
                    return e.port2.postMessage(t), t
                }
            }() : d && "onreadystatechange" in d.createElement("script") ? function() {
                var e = d.documentElement;
                o = function() {
                    var t = i(arguments),
                        s = d.createElement("script");
                    return s.onreadystatechange = function() {
                        n(t), s.onreadystatechange = null, e.removeChild(s), s = null
                    }, e.appendChild(s), t
                }
            }() : function() {
                o = function() {
                    var e = i(arguments);
                    return setTimeout(s(n, e), 0), e
                }
            }(), h.setImmediate = o, h.clearImmediate = r
        }
    }(new Function("return this")()),
    function(e) {
        function t(e, t) {
            return function() {
                e.apply(t, arguments)
            }
        }

        function i(e) {
            if ("object" !== _typeof(this)) throw new TypeError("Promises must be constructed via new");
            if ("function" != typeof e) throw new TypeError("not a function");
            this._state = null, this._value = null, this._deferreds = [], l(e, t(n, this), t(r, this))
        }

        function s(e) {
            var t = this;
            if (null === this._state) return void this._deferreds.push(e);
            c(function() {
                var i = t._state ? e.onFulfilled : e.onRejected;
                if (null === i) return void(t._state ? e.resolve : e.reject)(t._value);
                var s;
                try {
                    s = i(t._value)
                } catch (t) {
                    return void e.reject(t)
                }
                e.resolve(s)
            })
        }

        function n(e) {
            try {
                if (e === this) throw new TypeError("A promise cannot be resolved with itself.");
                if (e && ("object" === _typeof(e) || "function" == typeof e)) {
                    var i = e.then;
                    if ("function" == typeof i) return void l(t(i, e), t(n, this), t(r, this))
                }
                this._state = !0, this._value = e, o.call(this)
            } catch (e) {
                r.call(this, e)
            }
        }

        function r(e) {
            this._state = !1, this._value = e, o.call(this)
        }

        function o() {
            for (var e = 0, t = this._deferreds.length; e < t; e++) s.call(this, this._deferreds[e]);
            this._deferreds = null
        }

        function a(e, t, i, s) {
            this.onFulfilled = "function" == typeof e ? e : null, this.onRejected = "function" == typeof t ? t : null, this.resolve = i, this.reject = s
        }

        function l(e, t, i) {
            var s = !1;
            try {
                e(function(e) {
                    s || (s = !0, t(e))
                }, function(e) {
                    s || (s = !0, i(e))
                })
            } catch (e) {
                if (s) return;
                s = !0, i(e)
            }
        }
        var c = "function" == typeof setImmediate && setImmediate || function(e) {
                setTimeout(e, 1)
            },
            d = Array.isArray || function(e) {
                return "[object Array]" === Object.prototype.toString.call(e)
            };
        i.prototype.catch = function(e) {
            return this.then(null, e)
        }, i.prototype.then = function(e, t) {
            var n = this;
            return new i(function(i, r) {
                s.call(n, new a(e, t, i, r))
            })
        }, i.all = function() {
            var e = Array.prototype.slice.call(1 === arguments.length && d(arguments[0]) ? arguments[0] : arguments);
            return new i(function(t, i) {
                function s(r, o) {
                    try {
                        if (o && ("object" === _typeof(o) || "function" == typeof o)) {
                            var a = o.then;
                            if ("function" == typeof a) return void a.call(o, function(e) {
                                s(r, e)
                            }, i)
                        }
                        e[r] = o, 0 == --n && t(e)
                    } catch (e) {
                        i(e)
                    }
                }
                if (0 === e.length) return t([]);
                for (var n = e.length, r = 0; r < e.length; r++) s(r, e[r])
            })
        }, i.resolve = function(e) {
            return e && "object" === _typeof(e) && e.constructor === i ? e : new i(function(t) {
                t(e)
            })
        }, i.reject = function(e) {
            return new i(function(t, i) {
                i(e)
            })
        }, i.race = function(e) {
            return new i(function(t, i) {
                for (var s = 0, n = e.length; s < n; s++) e[s].then(t, i)
            })
        }, i._setImmediateFn = function(e) {
            c = e
        }, "undefined" != typeof module && module.exports ? module.exports = i : e.Promise || (e.Promise = i)
    }(this), SYNO.SDS.HandShake = function() {
        var e = void 0,
            t = void 0;
        return {
            get: function() {
                return t
            },
            Init: function(e) {
                SYNO.SDS.HandShake._noise = e, SYNO.SDS.HandShake._hhid = sodium.randombytes_random() % 65536, Ext.Ajax.on("beforerequest", function(e, t) {
                    if (SYNO.SDS.HandShake.IsSupport()) return !0 === SYNO.SDS.Session.updateSession ? (SYNO.SDS.Session.DelayAjax.push(t), !1) : void(t && t.params && t.params.api && "SYNO.Entry.Request" !== t.params.api && (Ext.isEmpty(t.headers) && (t.headers = {}), t.headers["X-SYNO-HASH"] || (t.headers["X-SYNO-HASH"] = SYNO.SDS.HandShake.Encrypt(""), t.headers["X-SYNO-HHID"] = SYNO.SDS.HandShake._hhid)))
                })
            },
            GetLoginParams: function(t) {
                var i = {
                    api: "SYNO.API.Auth",
                    version: 6,
                    method: "login",
                    session: "webui",
                    hhid: SYNO.SDS.HandShake._hhid,
                    enable_syno_token: _S("enable_syno_token")
                };
                i = Object.assign(i, t);
                var s = Ext.urlDecode(window.location.search.split("?")[1]);
                if ("code" === s.response_type) {
                    var n = {};
                    ["client_id", "session", "redirect_uri", "code_challenge", "code_challenge_method", "response_type"].forEach(function(e) {
                        e in s && (n[e] = s[e])
                    }), i = Object.assign(i, n)
                }
                return i = Object.assign(s, i), SYNO.SDS.HandShake.IsSupport() && (e = SYNO.SDS.HandShake.GetInstance("Noise_IK_25519_ChaChaPoly_BLAKE2b"), e ? (i.ik_message = SYNO.SDS.HandShake.Write(e), i.version = 7, i.client = "browser") : SYNO.SDS.HandShake.UnSupport()), i
            },
            GetLoginSynoToken: function(t) {
                var i = null,
                    s = Ext.urlDecode(window.location.search.split("?")[1]),
                    n = s.state;
                if (!0 === t.success && "true" === s.synossoJSSDK) return void window.location.replace("webman/sso/SSOOauth.cgi" + window.location.search);
                if (t.data.code && t.data.code.length > 0) {
                    if (window.opener && "" === t.data.redirect_uri) return t.data.rs = Ext.util.Cookies.get("_SSID"), window.opener.postMessage(t.data, s.opener), void window.close();
                    if ("" === t.data.redirect_uri) return void window.location.replace("/error");
                    var r = t.data.redirect_uri + "?code=" + t.data.code;
                    return r += "&rs=" + Ext.util.Cookies.get("_SSID"), n && (r += "&state=" + n), void window.location.replace(r)
                }
                if (!0 === t.success) {
                    var o = localStorage.getItem("choseAuthType");
                    o && (localStorage.setItem(t.data.account + ".AuthType", o), localStorage.removeItem("choseAuthType"))
                }
                return t.data && t.data.synotoken && (i = t.data.synotoken, SYNO.SDS.HandShake.IsSupport() && (e && t.data.ik_message ? (SYNO.SDS.HandShake.Read(e, t.data.ik_message), SYNO.SDS.CrossPortStorage.SetItem("currentLoginUser", t.data.account), e = void 0) : SYNO.SDS.HandShake.UnSupport())), i
            },
            GetHeaderError: function(e) {
                if (e && e.getResponseHeader) try {
                    return e.getResponseHeader("x-request-error") || e.getResponseHeader("X-Request-Error")
                } catch (t) {
                    return e.getResponseHeader["x-request-error"] || e.getResponseHeader["X-Request-Error"]
                }
            },
            CheckServerError: function(e) {
                if (SYNO.SDS.HandShake.IsSupport() && "unauth" === this.GetHeaderError(e)) return !1
            },
            CheckAPIResponse: function(e, t) {
                if (SYNO.SDS.HandShake.IsSupport() && "unauth" === this.GetHeaderError(t)) return Ext.isEmpty(SYNO.SDS.Session.DelayAjax) && (SYNO.SDS.Session.DelayAjax = []), SYNO.SDS.Session.DelayAjax.push(e), !0 === SYNO.SDS.Session.updateSession ? (SYNO.SDS.Session.DelayAjax.push(e), !1) : (SYNO.SDS.Session.updateSession = !0, SYNO.SDS.HandShake.TryResumeSession().then(function(e) {
                    SYNO.SDS.Session.updateSession = !1, e ? SYNO.SDS.Session.DelayAjax.forEach(function(e) {
                        e.headers["X-SYNO-HASH"] && (e.headers["X-SYNO-HASH"] = SYNO.SDS.HandShake.Encrypt("")), Ext.Ajax.request(e)
                    }) : SYNO.SDS.Utils.Logout.action(!0, SYNO.API.Errors.common[106], !0, !1), SYNO.SDS.Session.DelayAjax = void 0
                }), !1)
            },
            GetInstance: function(e) {
                var t = SYNO.SDS.HandShake._noise,
                    i = Ext.util.Cookies.get("_SSID");
                if (i) {
                    var s = SYNO.SDS.CrossPortStorage.GetItem("_HSID");
                    if (!s) {
                        if ("Noise_IK_25519_ChaChaPoly_BLAKE2b" !== e) return;
                        s = sodium.to_base64(t.CreateKeyPair(t.constants.NOISE_DH_CURVE25519)[0]), SYNO.SDS.CrossPortStorage.PromoteLocal(), SYNO.SDS.CrossPortStorage.SetItem("_HSID", s)
                    }
                    var n = t.constants.NOISE_ROLE_INITIATOR,
                        r = t.HandshakeState(e, n),
                        o = sodium.from_base64(s),
                        a = sodium.from_base64(i);
                    return r.Initialize(null, o, a, null), r
                }
            },
            Write: function(e) {
                var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : "";
                return sodium.to_base64(e.WriteMessage(t))
            },
            Read: function(e, i) {
                e.ReadMessage(sodium.from_base64(i), !0), t = e.Split(), t[0].n = 0, t[1].n = 0
            },
            Encrypt: function() {
                arguments.length > 0 && void 0 !== arguments[0] && arguments[0], arguments.length > 1 && void 0 !== arguments[1] && arguments[1];
                return t ? sodium.to_base64(t[0].EncryptWithAd(new Uint8Array, new Uint8Array)) + "." + sodium.to_base64("" + t[0].n++) : ""
            },
            IsSupport: function() {
                return ("http:" !== window.location.protocol || !0 !== _S("is_secure")) && void 0 !== SYNO.SDS.HandShake._noise
            },
            UnSupport: function() {
                SYNO.SDS.HandShake._noise = void 0
            },
            TryResumeSession: function() {
                return new Promise(function(e, t) {
                    var i = SYNO.SDS.HandShake.GetInstance("Noise_KK_25519_ChaChaPoly_BLAKE2b");
                    if (!i) return e(!1);
                    var s = SYNO.SDS.CrossPortStorage.GetItem("currentLoginUser");
                    if (!s) return e(!1);
                    synowebapi.request({
                        url: "webapi/entry.cgi?api=SYNO.API.Auth",
                        requestFormat: "raw",
                        responseFormat: "raw",
                        method: "POST",
                        params: {
                            api: "SYNO.API.Auth",
                            version: 7,
                            method: "resume",
                            kk_message: SYNO.SDS.HandShake.Write(i),
                            hhid: SYNO.SDS.HandShake._hhid,
                            account: s
                        },
                        callback: function(t, s) {
                            if (!s.data || !s.data.kk_message) return e(!1);
                            SYNO.SDS.HandShake.Read(i, s.data.kk_message), SYNO.SDS.Session.isLogined = !0, e(!0)
                        }
                    })
                })
            }
        }
    }(), Ext.BLANK_IMAGE_URL = "scripts/ext-3/resources/images/default/s.gif", Ext.data.Connection.prototype.timeout = 12e4, Ext.form.BasicForm.prototype.timeout = 120, Ext.QuickTip.prototype.maxWidth = 500, Ext.override(Ext.QuickTip, {
        hide: function() {
            var e = function() {
                delete this.activeTarget, Ext.QuickTip.superclass.hide.call(this), this.getEl().setOpacity(1)
            };
            return this.getEl().animate({
                opacity: {
                    from: 1,
                    to: 0
                }
            }, .3, e.createDelegate(this))
        }
    }), Ext.override(Ext.Element, {
        addClassOnHover: function(e) {
            var t = this;
            "ontouchstart" in window || window.navigator.msPointerEnabled && window.navigator.msMaxTouchPoints > 0 ? Ext.getDoc().on("click", function(i) {
                i.within(t) ? t.addClass(e) : t.removeClass(e)
            }, t) : t.addClassOnOver(e)
        }
    }), Ext.override(Ext.Component, {
        labelSeparator: _T("common", "colon"),
        getTaskRunner: function() {
            return this.taskRunner || (this.taskRunner = new SYNO.SDS.TaskRunner, this.addManagedComponent(this.taskRunner)), this.taskRunner
        },
        addTask: function(e) {
            return this.getTaskRunner().createTask(e)
        },
        addAjaxTask: function(e) {
            return this.getTaskRunner().createAjaxTask(e)
        },
        addWebAPITask: function(e) {
            return this.getTaskRunner().createWebAPITask(e)
        },
        getTask: function(e) {
            return this.taskRunner ? this.taskRunner.getTask(e) : null
        },
        removeTask: function(e) {
            var t = this.getTask(e);
            return t && t.remove(), t
        },
        addManagedComponent: function(e) {
            return this.components = this.components || [], this.components.push(e), e
        },
        removeManagedComponent: function(e) {
            return this.components = this.components || [], this.components.remove(e), e
        },
        beforeDestroy: function() {
            this.taskRunner = null, this.components = this.components || [];
            for (var e = 0; e < this.components.length; ++e) try {
                this.components[e] instanceof Vue ? this.components[e].$destroy() : this.components[e].destroy()
            } catch (t) {
                if (Ext.isDefined(SYNO.SDS.JSDebug)) throw SYNO.Debug.error(this.id, "sub-components[" + e + "] destroy failed.", this.components[e]), t
            }
            delete this.components
        },
        findWindow: function() {
            var e = this;
            if (e instanceof SYNO.SDS.BaseWindow) return e;
            for (; Ext.isObject(e.ownerCt); e = e.ownerCt);
            return e instanceof SYNO.SDS.BaseWindow ? e : void 0
        },
        findAppWindow: function() {
            var e = function(e) {
                    return e && e._isVue && "AppWindow" === e.$options.name
                },
                t = this,
                i = Ext.getClassByName("SYNO.SDS.AppWindow");
            if (!Ext.isEmpty(i)) {
                if (t instanceof i || e(t)) return t;
                if (t._appWindow instanceof i || e(t._appWindow)) return t._appWindow;
                for (; Ext.isObject(t.ownerCt); t = t.ownerCt);
                if (t instanceof i || e(t._appWindow)) return this._appWindow = t, t;
                if (Ext.isObject(t)) {
                    for (; Ext.isObject(t.owner || t.$options && t.$options.owner); t = t._isVue ? t.$options.owner : t.owner);
                    return t instanceof i || e(t) ? (this._appWindow = t, t) : t.module && t.module.appWin && t.module.appWin instanceof i ? (this._appWindow = t.module.appWin, t.module.appWin) : void 0
                }
            }
        },
        getDsmVersion: function() {
            var e = this.findAppWindow();
            return e ? e.getOpenConfig("dsm_version") : null
        },
        getDsmHttpPort: function() {
            var e, t = this.findAppWindow();
            return t && t.hasOpenConfig("cms_ds_data") && (e = t.getOpenConfig("cms_ds_data").http_port), e
        },
        getDsmHost: function() {
            var e, t = this.findAppWindow();
            return t && t.hasOpenConfig("cms_ds_data") && (e = t.getOpenConfig("cms_ds_data").host), e
        },
        getBaseURL: function(e, t, i) {
            return e.appWindow = this.findAppWindow(), SYNO.API.GetBaseURL(e, t, i)
        },
        sendWebAPI: function(e) {
            return e.appWindow = this.findAppWindow(), SYNO.API.Request(e)
        },
        sendWebAPIPromise: function(e) {
            return new Promise(function(t, i) {
                e.callback = function(e, s, n, r) {
                    e ? t(s) : i(s)
                }, this.sendWebAPI(e)
            }.bind(this))
        },
        pollReg: function(e) {
            return e.appWindow = this.findAppWindow(), SYNO.API.Request.Polling.Register(e)
        },
        pollUnreg: function(e) {
            return SYNO.API.Request.Polling.Unregister(e)
        },
        pollList: function(e) {
            return e.appWindow = this.findAppWindow(), SYNO.API.Request.Polling.List(e)
        },
        downloadWebAPI: function(e) {
            return e.appWindow = this.findAppWindow(), SYNO.SDS.Utils.IFrame.requestWebAPI(e)
        },
        IsAllowRelay: function() {
            var e = this.findAppWindow();
            return !!Ext.isObject(e) && (SYNO.SDS.Utils.CMS.IsAllowRelay && SYNO.SDS.Utils.CMS.IsAllowRelay(e))
        },
        _S: function(e) {
            var t = this.findAppWindow();
            return SYNO.API.Info.GetSession(t, e)
        },
        _D: function(e, t) {
            var i = this.findAppWindow();
            return SYNO.API.Info.GetDefine(i, e, t)
        },
        getKnownAPI: function(e) {
            var t = this.findAppWindow();
            return SYNO.API.Info.GetKnownAPI(t, e)
        },
        IsKnownAPI: function(e, t) {
            var i = SYNO.API.Info.GetKnownAPI(this.findAppWindow(), e);
            return !!Ext.isObject(i) && !(t < i.minVersion || i.maxVersion < t)
        }
    }), Ext.override(Ext.grid.GridView, {
        onLayout: function() {
            var e = this.el.select(".x-grid3-scroller", this),
                t = e.elements[0];
            t.clientWidth === t.offsetWidth ? this.scrollOffset = 2 : this.scrollOffset = void 0, this.fitColumns(!1)
        }
    }), Ext.override(Ext.data.Record, {
        set: function(e, t) {
            var i, s = Ext.isPrimitive(t) ? String : Ext.encode;
            if (s(this.data[e]) != s(t)) {
                if (this.dirty = !0, this.modified || (this.modified = {}), e in this.modified && this.modified[e] === t) {
                    this.dirty = !1, delete this.modified[e];
                    for (i in this.modified)
                        if (this.modified.hasOwnProperty(i)) {
                            this.dirty = !0;
                            break
                        }
                } else e in this.modified || (this.modified[e] = this.data[e]);
                this.data[e] = t, this.editing || this.afterEdit()
            }
        }
    }), Ext.override(Ext.data.Store, {
        afterEdit: function(e) {
            var t = this.modified.indexOf(e);
            e.dirty && -1 == t ? this.modified.push(e) : e.dirty || -1 == t || this.modified.splice(t, 1), this.fireEvent("update", this, e, Ext.data.Record.EDIT)
        }
    }), Ext.Element.addMethods(Ext.Fx), Ext.override(Ext.dd.DragSource, {
        validateTarget: function(e, t, i) {
            return !(i !== t.getTarget().id && !t.within(i)) || (this.getProxy().setStatus(this.dropNotAllowed), !1)
        },
        beforeDragEnter: function(e, t, i) {
            return this.validateTarget(e, t, i)
        },
        beforeDragOver: function(e, t, i) {
            var s = this.validateTarget(e, t, i);
            return this.proxy && this.proxy.setStatus(s ? this.dropAllowed : this.dropNotAllowed), s
        },
        beforeDragOut: function(e, t, i) {
            return this.validateTarget(e, t, i)
        },
        beforeDragDrop: function(e, t, i) {
            return !!this.validateTarget(e, t, i) || (this.onInvalidDrop(e, t, i), !1)
        }
    }), Ext.override(Ext.form.CompositeField, {
        combineErrors: !1
    }), Ext.isIE && (Ext.menu.BaseItem.prototype.clickHideDelay = -1), Ext.override(Ext.Window, {
        onRender: function(e, t) {
            Ext.Window.superclass.onRender.call(this, e, t), this.plain && this.el.addClass("x-window-plain"), this.focusEl = this.el.createChild({
                tag: "div",
                cls: "x-dlg-focus",
                tabIndex: "0",
                role: this.ariaRole || "dialog",
                "aria-label": this.title
            }, this.el.first()), this.focusEl.swallowEvent("click", !0), this.focusEl.addKeyListener(Ext.EventObject.TAB, this.onFirstTab, this), this.lastEl = this.el.createChild({
                tag: "div",
                cls: "x-dlg-focus",
                tabIndex: 0,
                role: "article",
                html: _T("desktop", "window_last_hint")
            }), this.lastEl.addKeyListener(Ext.EventObject.TAB, this.onLastTab, this), this.proxy = this.el.createProxy("x-window-proxy"), this.proxy.enableDisplayMode("block"), this.modal && (this.maskEl = this.container.createChild({
                cls: "ext-el-mask"
            }, this.el.dom), this.maskEl.enableDisplayMode("block"), this.maskEl.hide(), this.mon(this.maskEl, "click", this.focus, this)), this.maximizable && this.mon(this.header, "dblclick", this.toggleMaximize, this), this.frame && this.header && (this.tl = this.header.dom.parentNode.parentNode.parentNode)
        },
        onLastTab: function(e, t) {
            t.shiftKey || (t.preventDefault(), this.focusEl.focus())
        },
        onFirstTab: function(e, t) {
            if (t.shiftKey) t.preventDefault(), this.lastEl.focus();
            else if (Ext.isFunction(this.findTopWin)) {
                var i = this.findTopWin();
                i !== this && (t.preventDefault(), i.focus())
            }
        },
        beforeShow: function() {
            if (delete this.el.lastXY, delete this.el.lastLT, void 0 === this.x || void 0 === this.y) {
                var e = this.el.getAlignToXY(this.container, "c-c"),
                    t = this.el.translatePoints(e[0], e[1]);
                this.x = void 0 === this.x ? t.left : this.x, this.y = void 0 === this.y ? t.top : this.y
            }
            this.el.setLeftTop(this.x, this.y), this.expandOnShow && this.expand(!1), this.modal && (Ext.getBody().addClass("x-body-masked"), this.maskEl.setSize(Ext.lib.Dom.getViewWidth(!0), Ext.lib.Dom.getViewHeight(!0)), this.maskEl.show())
        },
        onWindowResize: function() {
            this.maximized && this.fitContainer(), this.modal && (this.maskEl.setSize("100%", "100%"), this.maskEl.setSize(Ext.lib.Dom.getViewWidth(!0), Ext.lib.Dom.getViewHeight(!0))), this.doConstrain()
        },
        setZIndex: function(e) {
            this.modal && this.maskEl.setStyle("z-index", e), this.el.setZIndex(++e), e += 5, this.resizer && this.resizer.proxy.setStyle("z-index", ++e), this.lastZIndex = e
        },
        beforeDestroy: function() {
            this.rendered && (this.hide(), this.clearAnchor(), Ext.destroy(this.focusEl, this.resizer, this.dd, this.proxy, this.maskEl)), Ext.Window.superclass.beforeDestroy.call(this)
        },
        hide: function(e, t, i) {
            return this.hidden || !1 === this.fireEvent("beforehide", this) ? this : (t && this.on("hide", t, i, {
                single: !0
            }), this.hidden = !0, void 0 !== e && this.setAnimateTarget(e), this.modal && (this.maskEl.hide(), Ext.getBody().removeClass("x-body-masked")), this.animateTarget ? this.animHide() : (this.el.hide(), this.afterHide()), this)
        },
        getFrameHeight: function() {
            var e = this.el.getFrameWidth("tb") + this.bwrap.getFrameWidth("tb");
            return e += (this.tbar ? this.tbar.getHeight() : 0) + (this.bbar ? this.bbar.getHeight() : 0), this.frame ? e += (this.tl || this.el.dom.firstChild).offsetHeight + this.ft.dom.offsetHeight + this.mc.getFrameWidth("tb") : e += (this.header ? this.header.getHeight() : 0) + (this.footer ? this.footer.getHeight() : 0), e
        },
        toFront: function(e) {
            this.manager.bringToFront(this) && (this.focusLeave = !1, e && e.getTarget().focus ? (e.getTarget().focus(), document.activeElement !== e.getTarget() && this.focus()) : this.focus())
        }
    }), Ext.override(Ext.grid.RowSelectionModel, {
        silentMode: !1,
        onRefresh: function() {
            var e, t, i = this.grid.store,
                s = this.getSelections(),
                n = 0,
                r = s.length;
            for (this.silent = this.silentMode && !0, this.clearSelections(!0); n < r; n++) t = s[n], -1 != (e = i.indexOfId(t.id)) && this.selectRow(e, !0);
            s.length != this.selections.getCount() && this.fireEvent("selectionchange", this), this.silent = !1
        }
    }), Ext.override(Ext.grid.GridPanel, {
        getValues: function() {
            var e = [],
                t = this.getStore();
            return Ext.isObject(t) ? (t.each(function(t, i, s) {
                e.push(Ext.apply({}, t.data))
            }, this), e) : e
        },
        setValues: function(e) {
            var t = this.getStore(),
                i = [];
            if (!Ext.isObject(t) || !Ext.isArray(e)) return !1;
            t.removeAll(), Ext.each(e, function(e) {
                i.push(new Ext.data.Record(e))
            }, this), t.add(i)
        }
    }), Ext.override(Ext.grid.GridView.ColumnDragZone, {
        getDragData: function(e) {
            var t = Ext.lib.Event.getTarget(e),
                i = this.view.findHeaderCell(t);
            return !!i && {
                ddel: Ext.fly(i).child("div.x-grid3-hd-inner", !0),
                header: i
            }
        }
    }), Ext.override(Ext.grid.HeaderDropZone, {
        positionIndicator: function(e, t, i) {
            var s, n, r = Ext.lib.Event.getPageX(i),
                o = Ext.lib.Dom.getRegion(Ext.fly(t).child("div.x-grid3-hd-inner", !0)),
                a = o.top + this.proxyOffsets[1];
            return o.right - r <= (o.right - o.left) / 2 ? (s = o.right + this.view.borderWidth, n = "after") : (s = o.left, n = "before"), !this.grid.colModel.isFixed(this.view.getCellIndex(t)) && (s += this.proxyOffsets[0], this.proxyTop.setLeftTop(s, a), this.proxyTop.show(), this.bottomOffset || (this.bottomOffset = this.view.mainHd.getHeight()), this.proxyBottom.setLeftTop(s, a + this.proxyTop.dom.offsetHeight + this.bottomOffset), this.proxyBottom.show(), n)
        },
        onNodeDrop: function(e, t, i, s) {
            var n = s.header;
            if (n != e) {
                var r = this.grid.colModel,
                    o = Ext.lib.Event.getPageX(i),
                    a = Ext.lib.Dom.getRegion(Ext.fly(e).child("div.x-grid3-hd-inner", !0)),
                    l = a.right - o <= (a.right - a.left) / 2 ? "after" : "before",
                    c = this.view.getCellIndex(n),
                    d = this.view.getCellIndex(e);
                return "after" == l && d++, c < d && d--, r.moveColumn(c, d), !0
            }
            return !1
        }
    }), Ext.override(SYNO.ux.ModuleList, {
        getLocalizedString: function(e) {
            return SYNO.SDS.UIString.GetLocalizedString(e)
        }
    }), Ext.override(SYNO.ux.FieldSet, {
        stateful: !0,
        stateEvents: ["expand", "collapse"],
        getState: function() {
            return {
                collapsed: this.collapsed
            }
        },
        saveState: function() {
            var e = this.getState();
            this.setUserCollapseState(e.collapsed)
        },
        getUserCollapseState: function() {
            var e = this.getStateId(),
                t = this.findAppWindow();
            if (t && t.appInstance && e) {
                var i = t.appInstance.getUserSettings("fieldset_collapse_status") || {};
                return Ext.isBoolean(i[e]) ? i[e] : this.collapsed
            }
            return this.collapsed
        },
        setUserCollapseState: function(e) {
            var t = this.getStateId(),
                i = this.findAppWindow();
            if (i && i.appInstance && t) {
                var s = i.appInstance.getUserSettings("fieldset_collapse_status") || {};
                s[t] = e, i.appInstance.setUserSettings("fieldset_collapse_status", s)
            }
        },
        updateUserCollapseState: function() {
            var e = this.getUserCollapseState(),
                t = {
                    collapsed: e
                };
            this.applyState(t)
        }
    });
var _urlAppend = Ext.urlAppend;
Ext.urlAppend = function(e, t, i) {
        var s = Ext.urlDecode(t);
        return i = void 0 === i || i, i && -1 === e.indexOf("SynoToken") && !Ext.isEmpty(_S("SynoToken")) && (s.SynoToken = decodeURIComponent(_S("SynoToken"))), _urlAppend(e, Ext.urlEncode(s))
    }, Ext.ns("SYNO.SDS"), Ext.Ajax.on("beforerequest", function(e, t) {
        !0 !== t.updateSynoToken && Ext.isEmpty(t.skipSynoToken) && !Ext.isEmpty(_S("SynoToken")) && (Ext.isEmpty(t.headers) && (t.headers = {}), void 0 === t.headers["X-SYNO-TOKEN"] && (t.headers["X-SYNO-TOKEN"] = _S("SynoToken")))
    }), Ext.util.Observable.observeClass(Ext.form.BasicForm), Ext.form.BasicForm.on("beforeaction", function(e, t) {
        e.url && (e.url = Ext.urlAppend(e.url))
    }), Ext.util.Observable.observeClass(Ext.data.Connection), Ext.data.Connection.on("beforerequest", function(e, t) {
        Ext.isEmpty(t.skipSynoToken) && !Ext.isEmpty(_S("SynoToken")) && (Ext.isEmpty(t.headers) && (t.headers = {}), t.headers["X-SYNO-TOKEN"] = _S("SynoToken"))
    }), Ext.define("Ext.data.JsonP", {
        singleton: !0,
        requestCount: 0,
        requests: {},
        timeout: 3e4,
        disableCaching: !0,
        disableCachingParam: "_dc",
        callbackKey: "callback",
        request: function(e) {
            e = Ext.apply({}, e);
            var t, i, s = this,
                n = Ext.isDefined(e.disableCaching) ? e.disableCaching : s.disableCaching,
                r = e.disableCachingParam || s.disableCachingParam,
                o = ++s.requestCount,
                a = e.callbackName || "callback" + o,
                l = e.callbackKey || s.callbackKey,
                c = Ext.isDefined(e.timeout) ? e.timeout : s.timeout,
                d = Ext.apply({}, e.params),
                h = e.url;
            return n && !d[r] && (d[r] = (new Date).getTime()), e.params = d, d[l] = "Ext.data.JsonP." + a, i = e.iframeUrl ? s.createIframe(h, d, e) : s.createScript(h, d, e), s.requests[o] = t = {
                url: h,
                params: d,
                script: i,
                id: o,
                scope: e.scope,
                success: e.success,
                failure: e.failure,
                callback: e.callback,
                callbackKey: l,
                callbackName: a
            }, c > 0 && (t.timeout = setTimeout(Ext.createDelegate(s.handleTimeout, s, [t]), c)), s.setupErrorHandling(t), s[a] = Ext.createDelegate(s.handleResponse, s, [t], !0), s.loadScript(t), t
        },
        abort: function(e) {
            var t, i = this,
                s = i.requests;
            if (e) e.id || (e = s[e]), i.handleAbort(e);
            else
                for (t in s) s.hasOwnProperty(t) && i.abort(s[t])
        },
        setupErrorHandling: function(e) {
            e.script.onerror = Ext.createDelegate(this.handleError, this, [e])
        },
        handleAbort: function(e) {
            e.errorType = "abort", this.handleResponse(null, e)
        },
        handleError: function(e) {
            e.errorType = "error", this.handleResponse(null, e)
        },
        cleanupErrorHandling: function(e) {
            e.script.onerror = null
        },
        handleTimeout: function(e) {
            e.errorType = "timeout", this.handleResponse(null, e)
        },
        handleResponse: function(e, t) {
            var i = !0;
            t.timeout && clearTimeout(t.timeout), delete this[t.callbackName], delete this.requests[t.id], this.cleanupErrorHandling(t), Ext.fly(t.script).remove(), t.errorType ? (i = !1, Ext.callback(t.failure, t.scope, [t.errorType])) : Ext.callback(t.success, t.scope, [e]), Ext.callback(t.callback, t.scope, [i, e, t.errorType])
        },
        createScript: function(e, t, i) {
            var s = document.createElement("script");
            return s.setAttribute("src", Ext.urlAppend(e, Ext.urlEncode(t))), s.setAttribute("async", !0), s.setAttribute("type", "text/javascript"), s
        },
        createIframe: function(e, t, i) {
            var s, n = Ext.urlAppend(e, Ext.urlEncode(t), !1);
            if (void 0 === i.iframeUrl) return void SYNO.Debug("no iframe url");
            var r = i.iframeUrl;
            return r += "&url=" + encodeURIComponent(n), r = Ext.urlAppend(r, "", !0), s = document.createElement("iframe"), s.setAttribute("src", r), s.setAttribute("style", "visibility: hidden"), s
        },
        loadScript: function(e) {
            Ext.get(document.getElementsByTagName("head")[0]).appendChild(e.script)
        }
    }), Ext.override(SYNO.ux.Button, {
        getUXMenu: function(e) {
            if (!Ext.menu.MenuMgr.getMenuList) return Ext.menu.MenuMgr.get(e);
            var t = Ext.menu.MenuMgr.getMenuList();
            return "string" == typeof e ? t ? t[e] : null : e.events ? e : "number" == typeof e.length ? new SYNO.ux.Menu({
                items: e
            }) : Ext.create(e, "syno_menu")
        },
        initComponent: function() {
            this.menu && (Ext.isArray(this.menu) && (this.menu = {
                items: this.menu
            }), Ext.isObject(this.menu) && (this.menu.ownerCt = this), this.menu = this.getUXMenu(this.menu), this.menu.ownerCt = void 0), SYNO.ux.Button.superclass.initComponent.call(this)
        }
    }), Ext.override(SYNO.ux.ComboBox, {
        afterRender: function() {
            SYNO.ux.ComboBox.superclass.afterRender.call(this), this.mon(this, "expand", this.onListExpand, this)
        },
        onDestroy: function() {
            this.mun(this, "expand", this.onListExpand, this), SYNO.ux.ComboBox.superclass.onDestroy.call(this)
        },
        onListExpand: function() {
            if (SYNO.SDS.Desktop) {
                var e = SYNO.SDS.UIFeatures.isFullScreenMode(),
                    t = SYNO.SDS.Desktop.getEl();
                e && this.list.parent() === Ext.getBody() ? t.appendChild(this.list) : e || this.list.parent() !== t || Ext.getBody().appendChild(this.list)
            }
        }
    }), Ext.override(SYNO.ux.DateField, {
        onDestroy: function() {
            this.menu && this.mun(this.menu, "show", this.onMenuShow, this), this.callParent(arguments)
        },
        onMenuShow: function() {
            if (SYNO.SDS.Desktop) {
                var e = SYNO.SDS.UIFeatures.isFullScreenMode(),
                    t = SYNO.SDS.Desktop.getEl(),
                    i = this.menu.el;
                e && i.parent() === Ext.getBody() ? t.appendChild(i) : e || i.parent() !== t || Ext.getBody().appendChild(i)
            }
        }
    }), Ext.override(SYNO.ux.DateTimeField, {
        initComponent: function() {
            Ext.ux.form.DateTimeField.superclass.initComponent.call(this);
            var e = this.initialConfig,
                t = SYNO.SDS.DateTimeUtils;
            this.dateFormat = void 0 === e.dateFormat ? t.GetDateFormat() : e.dateFormat, this.timeFormat = void 0 === e.timeFormat ? t.GetTimeFormat() : e.timeFormat, this.format = this.isAllDay ? this.dateFormat : this.dateFormat + " " + this.timeFormat, this.afterMethod("afterRender", function() {
                this.getEl().applyStyles("top:0")
            })
        }
    }), Ext.override(SYNO.ux.Menu, {
        onMenuShow: function() {
            if (SYNO.SDS.Desktop) {
                var e = SYNO.SDS.UIFeatures.isFullScreenMode(),
                    t = SYNO.SDS.Desktop.getEl();
                e && this.el.parent() === Ext.getBody() ? t.appendChild(this.el) : e || this.el.parent() !== t || Ext.getBody().appendChild(this.el), this.resetWidthForFlexcroll()
            }
        }
    }), Ext.override(SYNO.ux.DatePicker, {
        getWeekdayHeader: function(e) {
            var t = this.dayNames,
                i = "ger" === _S("lang") ? 2 : 1;
            return t[e].substr(0, i)
        }
    }), Ext.override(Ext.form.Radio, {
        setValue: function(e) {
            if ("boolean" == typeof e) Ext.form.Radio.superclass.setValue.call(this, e);
            else if (this.rendered) {
                var t = this.getCheckEl().select("input[name=" + this.el.dom.name + "]");
                t.each(function(t) {
                    var i = Ext.getCmp(t.dom.id);
                    i.setValue(e === t.dom.value), i.fireEvent("check", i, i.checked)
                }, this)
            }
            return this
        },
        onClick: function() {
            this.el.dom.checked != this.checked && this.setValue(this.el.dom.value)
        }
    }), Ext.namespace("SYNO.SDS.BaseWindow"), Ext.define("SYNO.SDS.AbstractWindow", {
        extend: "Ext.Window",
        closeDisabled: !1,
        toolTarget: "toolCt",
        toolCtCls: "x-window-toolCt",
        toolTemplate: new Ext.XTemplate('<div class="x-tool x-tool-{id}" role="option" aria-label="{text}">&#160;</div>'),
        realHeight: void 0,
        realWidth: void 0,
        constructor: function(e) {
            var t = Ext.urlDecode(location.search.substr(1));
            this.enableAlertHeight = t.alertHeight;
            var i = SYNO.SDS.Desktop ? SYNO.SDS.Desktop.getEl() : Ext.getBody();
            e = Ext.apply({
                autoFitDesktopHeight: !1,
                maximizable: !0,
                minimizable: !0,
                closable: !0,
                width: 300,
                height: 300,
                constrain: !1,
                constrainHeader: !0,
                modal: !1,
                renderTo: i,
                manager: SYNO.SDS.WindowMgr
            }, e), SYNO.SDS.AbstractWindow.superclass.constructor.call(this, e), (this.constrain || this.constrainHeader) && this.resizer && (this.resizer.constrainTo = this.container), this.mon(this, "titlechange", this.onWindowTitleChanged, this)
        },
        initEvents: function() {
            if (SYNO.SDS.AbstractWindow.superclass.initEvents.apply(this, arguments), this.resizer) {
                var e = Ext.Resizable.positions;
                for (var t in e) this.resizer[e[t]] && this.mon(this.resizer[e[t]].el, "mousedown", this.toFront, this)
            }
            this.mon(this, "beforeclose", this._onClose, this), this.mon(this, "beforemaximize", this._onBeforeMaximize, this), this.mon(this, "maximize", this._onMaximize, this), this.mon(this, "minimize", this._onMinimize, this), this.mon(this, "restore", this._onRestore, this), this.mon(this, "activate", this._onActivate, this), this.mon(this, "deactivate", this._onDeactivate, this), this.header && this.mon(this.header, "contextmenu", this.onHeaderContextMenu, this)
        },
        _onClose: function() {
            return !this.closeDisabled && this.onClose.apply(this, arguments)
        },
        _onMaximize: function() {
            return this.onMaximize.apply(this, arguments)
        },
        _onBeforeMaximize: function() {
            return this.onBeforeMaximize.apply(this, arguments)
        },
        _onMinimize: function() {
            return this.onMinimize.apply(this, arguments)
        },
        _onRestore: function() {
            return this.onRestore.apply(this, arguments)
        },
        _onActivate: function() {
            return this.onActivate.apply(this, arguments)
        },
        _onDeactivate: function() {
            return this.onDeactivate.apply(this, arguments)
        },
        _onDragWindow: function(e) {
            SYNO.SDS.TaskBar
        },
        _endDragWindow: function(e, t) {
            SYNO.SDS.TaskBar && SYNO.SDS.TaskBar.toggleCollideOverlay(!1)
        },
        onClose: Ext.emptyFn,
        onMaximize: Ext.emptyFn,
        onBeforeMaximize: Ext.emptyFn,
        onMinimize: Ext.emptyFn,
        onRestore: Ext.emptyFn,
        onActivate: Ext.emptyFn,
        onDeactivate: Ext.emptyFn,
        onHeaderContextMenu: function(e) {
            e.preventDefault()
        },
        onShow: function() {
            this.removeClass("syno-window-hide"), delete this.hideForMinimize,
                this.enableAlertHeight && this.isVisible() && this.getHeight() > 580 && window.alert(String.format("Height: {0}px, Plz contact your PM to adjust UI.", this.getHeight())), this.tryConstrainHeight()
        },
        doConstrain: function() {
            var e, t;
            this.constrainHeader && (e = this.getSize(), t = this.el.getConstrainToXY(this.container, !0, void 0), t && (t[0] + e.width > this.container.getWidth() && (t[0] = this.container.getWidth() - e.width), this.setPosition(t[0], t[1])), this.tryConstrainHeight())
        },
        tryConstrainHeight: function() {
            if (this.realHeight = this.getHeight(), this.realWidth = this.getWidth(), !0 !== this.isWizard) {
                var e = Ext.getBody().getHeight();
                e < this.minHeight && (e = this.minHeight), this.constrainHeight(e)
            }
        },
        constrainHeight: function(e, t) {
            (this.isVisible() || Ext.isDefined(t)) && this.realHeight > e && (this.setHeight(e), this.heightConstrained = !0)
        },
        disableCloseButton: function() {
            var e = this.toolCt.child(".x-tool.x-tool-close");
            this.closeDisabled = !0, e && e.addClass("disabled")
        },
        enableCloseButton: function() {
            var e = this.toolCt.child(".x-tool.x-tool-close");
            this.closeDisabled = !1, e && e.removeClass("disabled")
        },
        _onCloseAction: function() {
            if (this.closeDisabled) return !1;
            this[this.closeAction].apply(this, arguments)
        },
        beforeDestroy: function() {
            this.onBeforeDestroy(), SYNO.SDS.AbstractWindow.superclass.beforeDestroy.apply(this, arguments)
        },
        setIcon: function(e) {
            this.header && this.header.setStyle("background-image", e ? "url(" + e + ")" : "")
        },
        onBeforeDestroy: function() {
            this.appInstance && this.appInstance.removeInstance(this)
        },
        open: function() {
            return this.opened ? this.onRequest.apply(this, arguments) : (this.opened = !0, this.onOpen.apply(this, arguments))
        },
        onOpen: function() {
            this.minimized ? this.el.hide() : this.show()
        },
        onRequest: function() {
            if (!this.isVisible()) return void this.show();
            this.toFront()
        },
        onWindowTitleChanged: function(e, t) {
            this.rendered && this.focusEl instanceof Ext.Element && this.focusEl.set({
                "aria-label": Ext.util.Format.stripTags(t)
            })
        },
        getSizeAndPosition: function() {
            var e, t = {};
            return this.maximized || this.hidden ? (this.draggable && this.restorePos ? (t.x = this.restorePos[0], t.y = this.restorePos[1]) : (t.x = this.x, t.y = this.y), this.resizable && (this.restoreSize ? (t.width = this.restoreSize.width, t.height = this.restoreSize.height) : (t.width = this.width, t.height = this.height))) : (e = this.el.origXY || this.getPosition(!1), t.pageX = e[0], t.pageY = e[1], this.resizable && (t.width = this.getWidth(), t.height = this.getHeight())), t
        },
        setResizable: function(e) {
            this.el[e ? "removeClass" : "addClass"]("no-resize")
        },
        getConstrainSize: function() {
            var e = this.getSize();
            return e.width < this.minWidth && (e.width = this.minWidth), e.height < this.minHeight && (e.height = this.minHeight), e
        },
        maximize: function() {
            return this.maximized || (this.fireEvent("beforemaximize", this), this.expand(!1), this.restoreSize = this.getConstrainSize(), this.restorePos = this.getPosition(!0), this.maximizable && (this.tools.maximize.hide(), this.tools.restore.show()), this.maximized = !0, this.el.disableShadow(), this.dd && this.dd.lock(), this.collapsible && this.tools.toggle.hide(), this.el.addClass("x-window-maximized"), this.container.addClass("x-window-maximized-ct"), SYNO.SDS.TaskBar && this.setPosition(0, this.isFullScreen ? 0 : SYNO.SDS.TaskBar.height()), this.fitContainer(), this.fireEvent("maximize", this)), this
        },
        fitContainer: function() {
            var e = this.container.getViewSize(!1);
            SYNO.SDS.TaskBar && !this.isFullScreen ? this.setSize(e.width, e.height - SYNO.SDS.TaskBar.height()) : this.setSize(e.width, e.height)
        },
        setTitle: function(e, t, i) {
            return this.titleEncoded = i, this.title = e, !1 !== i && (e = Ext.util.Format.htmlEncode(e)), this.header && this.headerAsText && this.header.child("span").update(e), t && this.setIconClass(t), this.fireEvent("titlechange", this, this.title), this
        },
        getStateParam: function() {
            var e = {};
            return (this.maximized || this.hidden) && (e.maximized = this.maximized, e.minimized = this.hidden), e
        },
        getToolSelectedEl: function() {
            var e = this.toolCt.dom.getAttribute("aria-activedescendant");
            return e ? Ext.get(e) : null
        },
        selectToolNext: function() {
            var e, t = this.getToolSelectedEl();
            if (!t) return this.toolCt.set({
                "aria-activedescendant": this.toolCt.first().id
            }), void this.toolCt.first().addClass("x-tool-selected");
            for (e = t.next(); e && !e.isVisible();) e = e.next();
            e && (t.removeClass("x-tool-selected"), this.toolCt.set({
                "aria-activedescendant": e.id
            }), e.addClass("x-tool-selected"))
        },
        selectToolPre: function() {
            var e, t = this.getToolSelectedEl();
            if (!t) return this.toolCt.set({
                "aria-activedescendant": this.toolCt.last().id
            }), void this.toolCt.last().addClass("x-tool-selected");
            for (e = t.prev(); e && !e.isVisible();) e = e.prev();
            e && (t.removeClass("x-tool-selected"), this.toolCt.set({
                "aria-activedescendant": e.id
            }), e.addClass("x-tool-selected"))
        },
        onToolCtKenEnter: function() {
            var e = this.getToolSelectedEl();
            e && e.handler.call(this)
        },
        addTool: function() {
            if (this.rendered && !this.toolCt && this.header && (this.elements += ",toolCt", this.toolCt = this.header.createChild({
                    cls: "x-window-toolCt"
                }, this.header.first("." + this.headerTextCls, !0)), this.toolCt.setARIA({
                    role: "listbox",
                    label: _T("desktop", "window_toolbar_list"),
                    activedescendant: "false"
                }), this.toolCt.addKeyListener(Ext.EventObject.LEFT, this.selectToolNext, this), this.toolCt.addKeyListener(Ext.EventObject.RIGHT, this.selectToolPre, this), this.toolCt.addKeyListener(Ext.EventObject.DOWN, this.selectToolNext, this), this.toolCt.addKeyListener(Ext.EventObject.UP, this.selectToolPre, this), this.toolCt.addKeyListener(Ext.EventObject.ENTER, this.onToolCtKenEnter, this)), this.callParent(arguments), this.rendered && this.header) {
                var e, t = arguments,
                    i = t.length,
                    s = this.tools;
                for (e = 0; e < i; e++) {
                    var n = t[e];
                    s[n.id].handler || (s[n.id].handler = n.handler)
                }
            }
        },
        createGhost: function(e, t, i) {
            var s = document.createElement("div");
            if (s.className = "x-panel-ghost " + (e || ""), this.header && s.appendChild((this.tl || this.el.dom.firstChild).cloneNode(!0)), Ext.fly(s.appendChild(document.createElement("ul"))).setHeight(this.bwrap.getHeight()), s.style.width = this.el.dom.offsetWidth + "px", i ? Ext.getDom(i).appendChild(s) : this.container.dom.appendChild(s), !1 !== t && !1 !== this.el.useShim) {
                var n = new Ext.Layer({
                    shadow: !1,
                    useDisplay: !0,
                    constrain: !1
                }, s);
                return n.show(), n
            }
            return new Ext.Element(s)
        },
        initTools: function() {
            this.minimizable && this.addTool({
                id: "minimize",
                text: _T("desktop", "minimize"),
                handler: this.minimize.createDelegate(this, [])
            }), this.maximizable && (this.addTool({
                id: "maximize",
                text: _T("desktop", "maximize"),
                handler: this.maximize.createDelegate(this, [])
            }), this.addTool({
                id: "restore",
                text: _T("destop", "restore"),
                handler: this.restore.createDelegate(this, []),
                hidden: !0
            })), this.closable && this.addTool({
                id: "close",
                text: _T("common", "close"),
                handler: this._onCloseAction.createDelegate(this, [])
            })
        },
        openVueWindow: function(e, t) {
            var i, s, n;
            if (Ext.isString(e)) {
                i = Ext.getClassByName(e)
            } else i = e;
            if (i._isVue) n = s = i, document.querySelector("#sds-desktop").appendChild(i.$el);
            else {
                var r = document.createElement("div");
                n = new i({
                    propsData: t
                }), SYNO.SDS.Desktop && n && SYNO.SDS.Desktop.appendChild(n), document.querySelector("#sds-desktop").appendChild(r), n.$mount(r), s = getModalWindow(n)
            }
            return s.setOwner(this), s.init(), this.modalWin.push(s), {
                window: s,
                component: n
            }
        }
    }), SYNO.SDS.BaseWindow = Ext.extend(SYNO.SDS.AbstractWindow, {
        maskCnt: 0,
        maskTask: null,
        siblingWin: null,
        sinkModalWin: null,
        modalWin: null,
        msgBox: null,
        dsmStyle: "v5",
        owner: null,
        useDefualtKey: !0,
        onEsc: function() {
            !1 !== this.useDefualtKey && SYNO.SDS.BaseWindow.superclass.onEsc.apply(this, arguments)
        },
        constructor: function(e) {
            var t, i = !!e.owner;
            this.siblingWin = [], this.modalWin = [], this.sinkModalWin = [], this.updateDsmStyle(e), e.useStatusBar && (e = this.addStatusBar(e)), t = Ext.urlDecode(location.search.substr(1)), t.dsmStyle && (this.dsmStyle = t.dsmStyle), e.cls = String.format("{0}{1}", e.cls ? e.cls : "", this.isV5Style() ? " sds-window-v5" : " sds-window"), this.fillPadding(e), SYNO.SDS.BaseWindow.superclass.constructor.call(this, Ext.applyIf(e, {
                border: !0,
                plain: !1,
                shadow: !this.isV5Style() && !SYNO.SDS.UIFeatures.test("disableWindowShadow") && "frame",
                shadowOffset: 6,
                closeAction: "close"
            })), !i || e.owner instanceof SYNO.SDS.BaseWindow || e.owner._isVue || SYNO.Debug.warn(String.format('WARNING! owner of window "{0}" is not BaseWindow', this.title || this.id)), this.mon(this, "hide", this.restoreWindowFocus, this)
        },
        findTopWin: function() {
            for (var e, t = !1, i = this; !1 === t;)
                if (Ext.isArray(i.modalWin) && i.modalWin.length > 0)
                    for (e = i.modalWin.length - 1; e >= 0; e--) {
                        if (i.modalWin[e] && !(i.modalWin[e].hidden || i.modalWin[e].isDestroyed || i.modalWin[e].destroying)) {
                            i = i.modalWin[e];
                            break
                        }
                        0 === e && (t = !0)
                    } else t = !0;
            return i
        },
        restoreWindowFocus: function() {
            !0 !== this.focusLeave && SYNO.SDS.FocusMgr && (SYNO.SDS.FocusMgr.focusActiveWindow(), this.focusLeave = !0)
        },
        focusLastWindowPt: function() {
            var e, t = this.findTopWin();
            if (!(e = t.focusStack)) return void t.focusEl.focus();
            var i, s, n = !1;
            for (i = e.length - 1; i >= 0 && !0 !== n; i--)(s = Ext.fly(e[i])) && s.dom && s.isVisible() && -1 !== s.dom.getAttribute("tabIndex") && (s.focus(), n = !0);
            n || (this.focusEl.focus(), s = this.focusEl), t.focusStack = [s.dom]
        },
        addFocusPt: function() {
            var e, t = document.activeElement;
            t && Ext.fly(t).up(".x-window") && (e = this.findTopWin(), e.focusStack || (e.focusStack = []), e.focusStack.push(t))
        },
        updateDsmStyle: function(e) {
            Ext.isDefined(e) && (e.dsmStyle ? this.dsmStyle = e.dsmStyle : e.owner && this.setToOwnerDsmStyle(e.owner))
        },
        getDsmStyle: function() {
            return this.dsmStyle
        },
        isV5Style: function() {
            return "v5" === this.getDsmStyle()
        },
        setToOwnerDsmStyle: function(e) {
            Ext.isFunction(e.getDsmStyle) && (this.dsmStyle = e.getDsmStyle())
        },
        addStatusBar: function(e) {
            var t = {
                xtype: "statusbar",
                defaultText: "&nbsp;",
                statusAlign: "left",
                buttonAlign: "left",
                items: []
            };
            return this.isV5Style() && (t.defaults = {
                xtype: "syno_button",
                btnStyle: "grey"
            }), e.buttons && (t.items = t.items.concat(e.buttons), delete e.buttons), Ext.applyIf(e, {
                fbar: t
            }), e
        },
        createGhost: function(e, t, i) {
            if (this.isV5Style() && (e += " sds-window-v5"), SYNO.SDS.UIFeatures.test("windowGhost")) return SYNO.SDS.BaseWindow.superclass.createGhost.apply(this, arguments);
            var s = this.el.dom,
                n = document.createElement("div"),
                r = n.style;
            return n.className = "x-panel-ghost-simple", r.width = s.offsetWidth + "px", r.height = s.offsetHeight + "px", i ? Ext.getDom(i).appendChild(n) : this.container.dom.appendChild(n), new Ext.Element(n)
        },
        isModalized: function() {
            return !1
        },
        hasOwnerWin: function(e) {
            var t = this;
            do {
                if (e === t) return !0;
                t = t._isVue ? t.$options.owner : t.owner
            } while (t);
            return !1
        },
        getTopWin: function() {
            for (var e = this, t = this; e;) t = e, e = e._isVue ? e.$options.owner : e.owner;
            return t
        },
        getGroupWinAccessTime: function() {
            var e = this._lastAccess || 0;
            return Ext.each(this.modalWin, function(t) {
                t && t._lastAccess && t._lastAccess > e && (e = t._lastAccess)
            }), Ext.each(this.siblingWin, function(t) {
                t && t._lastAccess && t._lastAccess > e && (e = t._lastAccess)
            }), e
        },
        getMsgBox: function(e) {
            if (!this.msgBox || this.msgBox.isDestroyed) {
                var t = e && e.owner || this;
                t = t.isDestroyed ? null : t, this.isV5Style() ? this.msgBox = new SYNO.SDS.MessageBoxV5({
                    owner: t,
                    preventDelay: !!e && (e.preventDelay || !1),
                    draggable: !!e && (e.draggable || !1)
                }) : this.msgBox = new SYNO.SDS.MessageBox({
                    owner: t
                })
            }
            return this.msgBox.getWrapper(e)
        },
        confirmLeave: function(e) {
            var t = {
                yes: {
                    text: _T("common", "leave")
                },
                cancel: !0
            };
            this.getMsgBox().confirm("", _T("common", "confirm_lostchange"), e, this, t)
        },
        confirmLostChangePromise: function(e, t, i, s, n) {
            var r, o = {};
            if (Ext.isFunction(e)) r = e;
            else {
                if (!Ext.isObject(e)) return void SYNO.Debug.error("func should be object(for promise) or function(for callback)");
                o = e
            }
            var a = o.save,
                l = o.dontSave,
                c = o.cancel,
                d = o.confirmText;
            i = i || Ext.emptyFn, s = s || Ext.emptyFn, n = n || Ext.emptyFn, this.getMsgBox().confirm("", d || _T("common", "confirm_lostchange_without_save"), r || function(e) {
                Ext.isFunction(i) && i.apply(t, []), "yes" === e ? this.confirmLostChangeCallback(a, s, t) : "cancel" === e ? this.confirmLostChangeCallback(c, n, t) : "leftCustom" === e && this.confirmLostChangeCallback(l, s, t)
            }.bind(this), this, {
                yes: _T("common", "save"),
                cancel: !0,
                leftCustom: {
                    text: _T("common", "dont_save"),
                    extraStyle: "syno-ux-button-dontsave"
                }
            })
        },
        confirmLostChangeCallback: function(e, t, i) {
            if (!Ext.isFunction(e)) return void SYNO.Debug.error("Callback should be callable");
            var s = e.apply(i, []);
            s && s.then && Ext.isFunction(s.then) || (s = Promise.resolve()), s.then(function(e) {
                Ext.isFunction(t) && t.apply(i, [])
            }.bind(i)).catch(function(e) {}.bind(i))
        },
        getToastBox: function(e, t, i, s) {
            this.toastBox && !this.toastBox.isDestroyed && this.toastBox.destroy();
            var n = {
                text: e,
                closable: t,
                owner: this
            };
            return Ext.isObject(i) && (Ext.isString(i.text) && (n.actionText = i.text), Ext.isFunction(i.fn) && (n.actionHandler = i.fn), Ext.isObject(i.scope) && (n.actionHandlerScope = i.scope)), Ext.isObject(s) && (Ext.isNumber(s.delay) && (n.delay = s.delay), Ext.isNumber(s.offsetY) && (n.offsetY = s.offsetY), Ext.isNumber(s.offsetX) && (n.offsetX = s.offsetX), Ext.isDefined(s.alignEl) && (n.alignEl = s.alignEl), n.alignBottom = !0 === s.alignBottom), this.toastBox = new SYNO.SDS.ToastBox(n), this.toastBox
        },
        onBeforeDestroy: function() {
            function e(e) {
                e && e.destroy()
            }
            this.msgBox && this.msgBox.destroy(), this.toastBox && this.toastBox.destroy(), Ext.each(this.modalWin, e), Ext.each(this.siblingWin, e), delete this.msgBox, delete this.modalWin, delete this.siblingWin, delete this.maskTask, SYNO.SDS.BaseWindow.superclass.onBeforeDestroy.apply(this, arguments)
        },
        onMinimize: function() {
            function e(e) {
                e && (e.hideForMinimize = !0, e.minimize())
            }
            SYNO.SDS.BaseWindow.superclass.onMinimize.apply(this, arguments), Ext.each(this.modalWin, e), Ext.each(this.siblingWin, e)
        },
        applyToAllWindows: function(e) {
            Ext.each(this.modalWin, e), Ext.each(this.siblingWin, e)
        },
        addClassToAllWindows: function(e) {
            function t(t) {
                t.addClassToAllWindows(e)
            }
            this.el.addClass(e), this.applyToAllWindows(t)
        },
        removeClassFromAllWindows: function(e) {
            function t(t) {
                t.removeClassFromAllWindows(e)
            }
            this.el.removeClass(e), this.applyToAllWindows(t)
        },
        disableAllShadow: function() {
            function e(e) {
                e.disableAllShadow()
            }
            this.el.disableShadow(), this.applyToAllWindows(e)
        },
        onClose: function() {
            function e(e) {
                return !e || (e.close(), e.isDestroyed)
            }
            var t;
            return Ext.each(this.modalWin, e), Ext.each(this.sinkModalWin, e), this.modalWin.length || Ext.each(this.siblingWin, e), t = !this.modalWin.length && !this.siblingWin.length, t && (t = !1 !== SYNO.SDS.BaseWindow.superclass.onClose.apply(this, arguments)), t
        },
        onActivate: function() {
            var e = this.getTopWin();
            e.taskButton && e.taskButton.setState("active"), this.el.replaceClass("deactive-win", "active-win"), SYNO.SDS.BaseWindow.superclass.onActivate.apply(this, arguments)
        },
        onDeactivate: function() {
            var e = this.getTopWin();
            e.taskButton && e.taskButton.setState("deactive"), this.el.replaceClass("active-win", "deactive-win"), SYNO.SDS.BaseWindow.superclass.onDeactivate.apply(this, arguments), this.el && this.el.enableShadow(!0)
        },
        blinkShadow: function(e) {
            if (this.isV5Style()) return this.blinkShadowV5(e);
            !this.shadow || e <= 0 || (this.el.disableShadow(), function() {
                this.el.enableShadow(!0), this.blinkShadow.createDelegate(this, [--e]).defer(100)
            }.createDelegate(this).defer(100))
        },
        blinkShadowV5: function(e) {
            !this.el || !this.el.isVisible() || e <= 0 || (this.el.addClass("sds-window-v5-no-shadow"), function() {
                this.el && this.el.isVisible() && (this.el.removeClass("sds-window-v5-no-shadow"), this.blinkShadowV5.createDelegate(this, [--e]).defer(100))
            }.createDelegate(this).defer(100))
        },
        synchronizedMask: function(e) {
            this.mask(e)
        },
        delayedMask: function(e, t) {
            t = Ext.isNumber(t) ? t : 200, this.maskTask || (this.maskTask = new Ext.util.DelayedTask(this.setMaskOpacity, this, [e])), this.mask(0), this.maskTask.delay(t)
        },
        setMaskOpacity: function(e) {
            if (this.el.dom) {
                var t = Ext.Element.data(this.el.dom, "mask");
                t && t.setOpacity(e)
            }
        },
        mask: function(e, t, i, s) {
            if (!this.isDestroyed) {
                if (e = Ext.isNumber(e) ? e : 0, ++this.maskCnt > 1) return void this.setMaskOpacity(e, s);
                var n = this.el.mask(t, i);
                n.addClass("sds-window-mask"), this.mon(n, "mousedown", this.blinkModalChild, this), this.setMaskOpacity(e, s)
            }
        },
        unmask: function() {
            if (!(this.isDestroyed || --this.maskCnt > 0)) {
                this.maskCnt = 0, this.maskTask && this.maskTask.cancel();
                var e = Ext.Element.data(this.el, "mask");
                this.mun(e, "mousedown", this.blinkModalChild, this), this.el.unmask()
            }
        },
        blinkModalChild: function() {
            if (SYNO.SDS.WindowMgr) {
                this.modalWin.sort(SYNO.SDS.WindowMgr.sortWindows);
                var e = this.modalWin[this.modalWin.length - 1];
                if (!e) return void(this.isModalized() && (this.toFront(), this.blinkShadow(3)));
                e.blinkModalChild()
            }
        },
        clearStatus: function(e) {
            var t = this.getFooterToolbar();
            t && Ext.isFunction(t.clearStatus) && t.clearStatus(e)
        },
        clearStatusBusy: function(e) {
            this.unmask(), 0 === this.maskCnt && this.clearStatus(e)
        },
        setStatus: function(e) {
            e = e || {};
            var t = this.getFooterToolbar();
            t && Ext.isFunction(t.setStatus) && t.setStatus(e)
        },
        setStatusOK: function(e) {
            e = e || {}, Ext.applyIf(e, {
                text: _T("common", "setting_applied"),
                iconCls: this.isV5Style() ? "syno-ux-statusbar-success" : "x-status-valid",
                clear: !0
            }), this.setStatus(e)
        },
        setStatusError: function(e) {
            e = e || {}, Ext.applyIf(e, {
                text: _T("common", "error_system"),
                iconCls: this.isV5Style() ? "syno-ux-statusbar-error" : "x-status-error"
            }), this.setStatus(e)
        },
        setStatusBusy: function(e, t, i) {
            e = e || {}, Ext.applyIf(e, {
                text: _T("common", "loading"),
                iconCls: this.isV5Style() ? "syno-ux-statusbar-loading" : "x-status-busy"
            }), this.setStatus(e), this.maskForBusy(t, i)
        },
        maskForBusy: function(e, t) {
            e = Ext.isNumber(e) ? e : .4, t = Ext.isNumber(t) ? t : 400, t > 0 ? this.delayedMask(e, t) : this.synchronizedMask(e)
        },
        hide: function() {
            this.maximized || (this.restoreSize = this.getSize(), this.restorePos = this.getPosition(!0)), this.addClass("syno-window-hide"), SYNO.SDS.BaseWindow.superclass.hide.apply(this, arguments)
        },
        centerTitle: function() {
            var e, t = 0,
                i = ["help", "minimize", "maximize", "close"];
            this.tools && (Ext.each(i, function(e) {
                this.tools[e] && (t += 32)
            }, this), this.header && (e = this.header.child(".x-window-header-text")) && e.setStyle("padding-left", t + "px"))
        },
        fillPadding: function(e) {
            var t;
            return t = this.getFirstItem(e), t ? this.isGridPanel(t) || this.isFormPanel(t) ? void this.fillWindowPadding(e) : this.isTabPanel(t) && this.hasItems(t) ? void this.fillWindowPadding(e) : void 0 : e
        },
        hasItems: function(e) {
            return !!Ext.isArray(e.items) || e.items instanceof Ext.util.MixedCollection
        },
        fillWindowPadding: function(e) {
            Ext.applyIf(e, {
                padding: "16px 16px 0 16px"
            })
        },
        getFirstItem: function(e) {
            var t;
            return Ext.isArray(e.items) && 1 === e.items.length ? t = e.items[0] : Ext.isObject(e.items) && (t = e.items), t
        },
        isTabPanel: function(e) {
            return this.isPanelOf(e, Ext.TabPanel, ["tabpanel", "syno_tabpanel"])
        },
        isFormPanel: function(e) {
            return this.isPanelOf(e, Ext.form.FormPanel, ["form", "syno_formpanel"])
        },
        isGridPanel: function(e) {
            return this.isPanelOf(e, Ext.grid.GridPanel, ["grid", "syno_gridpanel"])
        },
        isPanelOf: function(e, t, i) {
            var s, n, r;
            if (!e) return !1;
            if (e instanceof t) return !0;
            for (s = e.xtype, n = 0, r = i.length; n < r; n++)
                if (s === i[n]) return !0;
            return !1
        },
        destroy: function() {
            this.isDestroyed || !1 !== this.fireEvent("beforedestroy", this) && (this.destroying = !0, this.focusStack && (this.focusStack = null), this.restoreWindowFocus(), SYNO.SDS.BaseWindow.superclass.destroy.call(this))
        }
    }), Ext.namespace("SYNO.SDS.Window"), SYNO.SDS.Window = Ext.extend(SYNO.SDS.BaseWindow, {
        constructor: function(e) {
            e = Ext.apply({
                minimizable: !1
            }, e), SYNO.SDS.Window.superclass.constructor.call(this, e), this.owner && Ext.isArray(this.owner.siblingWin) && this.owner.siblingWin.push(this)
        },
        onBeforeDestroy: function() {
            this.owner && Ext.isArray(this.owner.siblingWin) && this.owner.siblingWin.remove(this), SYNO.SDS.Window.superclass.onBeforeDestroy.apply(this, arguments)
        },
        onMinimize: function() {
            this.hide(), SYNO.SDS.Window.superclass.onMinimize.apply(this, arguments)
        },
        isAlwaysOnTop: function() {
            return _S("standalone")
        }
    }), Ext.namespace("SYNO.SDS._WindowMgr"), SYNO.SDS._WindowMgr = Ext.extend(Ext.util.Observable, {
        zseed: 9e3,
        list: null,
        accessList: null,
        minimizedWin: null,
        centeredWindowCount: 0,
        centerOffsets: [20, 20],
        front: null,
        offsetX: 10,
        offsetY: 10,
        exposeTransformDelayTime: 900,
        exposeRestoreDelayTime: 300,
        exposeIconHeight: 38,
        exposeIconShift: 38,
        constructor: function() {
            this.list = {}, this.accessList = [], this.minimizedWin = [], SYNO.SDS._WindowMgr.superclass.constructor.apply(this, arguments), Ext.EventManager.onWindowResize(this.onWindowResize, this)
        },
        getVueModalWindow: function(e) {
            if (e) {
                if ("ModalWindow" === e.$options.name || "MessageBoxWindow" === e.$options.name || "WizardWindow" === e.$options.name) return e;
                var t = !0,
                    i = !1,
                    s = void 0;
                try {
                    for (var n, r = e.$children[Symbol.iterator](); !(t = (n = r.next()).done); t = !0) {
                        var o = n.value,
                            a = this.getVueModalWindow(o);
                        if (a) return a
                    }
                } catch (e) {
                    i = !0, s = e
                } finally {
                    try {
                        t || null == r.return || r.return()
                    } finally {
                        if (i) throw s
                    }
                }
            }
        },
        openModalWindow: function(e) {
            var t = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                i = document.querySelector("#sds-desktop"),
                s = document.createElement("div"),
                n = new e({
                    propsData: t
                });
            i.appendChild(s), n.$mount(s);
            var r = this.getVueModalWindow(n);
            return r.init(), Vue.nextTick(function() {
                r.alignCenterToElement && r.alignCenterToElement(i)
            }), {
                window: r,
                component: n
            }
        },
        onWindowResize: function() {
            SYNO.SDS.WindowMgr.allHided && SYNO.SDS.WindowMgr.toggleAllWin(), this.exposeMask && this.exposeWindow()
        },
        sortWindows: function(e, t) {
            var i = e.getTopWin ? e.getTopWin() : e,
                s = t.getTopWin ? t.getTopWin() : t,
                n = e.isModalized && e.isModalized() ? 1 : 0,
                r = t.isModalized && t.isModalized() ? 1 : 0,
                o = e.isAlwaysOnTop && e.isAlwaysOnTop() ? 1 : 0,
                a = t.isAlwaysOnTop && t.isAlwaysOnTop() ? 1 : 0,
                l = e.isAlwaysOnBottom && e.isAlwaysOnBottom() ? 1 : 0,
                c = t.isAlwaysOnBottom && t.isAlwaysOnBottom() ? 1 : 0;
            return l !== c ? c ? 1 : -1 : o !== a ? a ? -1 : 1 : i !== s ? i.getGroupWinAccessTime() < s.getGroupWinAccessTime() ? -1 : 1 : n && e.hasOwnerWin(t) ? 1 : r && t.hasOwnerWin(e) ? -1 : e.sinkable && e.hasOwnerWin(t) ? e._lastClick < t._lastClick ? -1 : 1 : t.sinkable && t.hasOwnerWin(e) ? e._lastClick < t._lastClick ? 1 : -1 : !e._lastAccess || e._lastAccess < t._lastAccess ? -1 : 1
        },
        orderWindows: function() {
            var e = this.accessList,
                t = e.length;
            if (t > 0) {
                e.sort(this.sortWindows);
                for (var i = e[0].manager.zseed, s = 0; s < t; s++) {
                    var n = e[s];
                    n && !n.hidden && n.setZIndex(i + 10 * s)
                }
            }
            var r = this.activateLast();
            SYNO.SDS.StatusNotifier.fireEvent("allwinordered", this.accessList, r)
        },
        centerWindow: function(e) {
            var t = this,
                i = arguments.length > 1 && void 0 !== arguments[1] ? arguments[1] : {},
                s = i.withOffset,
                n = void 0 !== s && s;
            if (SYNO.SDS.Desktop && SYNO.SDS.Desktop.getEl())
                if (e._isVue) e.alignCenterToElement(SYNO.SDS.Desktop.getEl().dom);
                else {
                    var r = [0, 0];
                    n && (r = this.centerOffsets.map(function(e) {
                        return e * t.centeredWindowCount
                    })), e.alignTo(SYNO.SDS.Desktop.getEl(), "c-c", r), this.centeredWindowCount++
                }
        },
        setActiveWin: function(e) {
            e !== this.front && (this.front && this.front.setActive(!1), this.front = e, e && (e._isVue || (Ext.each(e.modalWin || [], function(e) {
                e && e.hideForMinimize && (delete e.hideForMinimize, e.show())
            }), Ext.each(e.siblingWin || [], function(e) {
                e && e.hideForMinimize && (delete e.hideForMinimize, e.show())
            })), this.bringToFront(e), e.setActive(!0)))
        },
        activateLast: function() {
            for (var e, t = this.accessList.length - 1; t >= 0; --t)
                if (e = this.accessList[t], !e.hidden) {
                    if (e.isSkipActive && e.isSkipActive()) continue;
                    return this.setActiveWin(this.accessList[t]), this.accessList[t]
                } this.setActiveWin(null)
        },
        getMaximizeAppWindowCount: function(e) {
            return this.accessList.reduce(function(t, i) {
                return e && e.id && i.id && e.id === i.id ? t : (i._isVue || i instanceof SYNO.SDS.AppWindow) && i.isVisible() && !0 === i.maximized ? t + 1 : t
            }, 0)
        },
        register: function(e) {
            if (e.manager && e.manager.unregister(e), e.manager = this, this.list[e.id] = e, this.accessList.push(e), this.bindActivateLast = this.activateLast.bind(this), e.on ? e.on("hide", this.activateLast, this) : e._isVue && e.$on("hide", this.bindActivateLast), e.fromRestore || e.isModalized && e.isModalized() || this.cascadeOverlap(e), e.autoStart && e.maximized && e.appInstance) {
                var t = e.appInstance.getRestoreSizePos(),
                    i = t.x,
                    s = t.y,
                    n = t.pageX,
                    r = t.pageY;
                Ext.isDefined(i) || Ext.isDefined(s) || Ext.isDefined(n) || Ext.isDefined(r) || this.cascadeOverlap(e)
            }
        },
        unregister: function(e) {
            delete e.manager, delete this.list[e.id], e.un ? e.un("hide", this.activateLast, this) : e._isVue && e.$off("hide", this.bindActivateLast), this.accessList.remove(e), this.minimizedWin.remove(e)
        },
        get: function(e) {
            return "object" == _typeof(e) ? e : this.list[e]
        },
        bringToFront: function(e) {
            if (e = this.get(e), e._lastClick = (new Date).getTime(), e === this.front) return SYNO.SDS.StatusNotifier.fireEvent("allwinordered", this.accessList, e), !1;
            do {
                if (e._lastAccess = (new Date).getTime(), e.isModalized && !e.isModalized()) break;
                e = e._isVue ? e.$options.owner : e.owner
            } while (e);
            return this.orderWindows(), !0
        },
        sendToBack: function(e) {
            return e = this.get(e), e._lastAccess = -(new Date).getTime(), this.orderWindows(), e
        },
        hideAll: function() {
            for (var e in this.list) this.list[e] && "function" != typeof this.list[e] && this.list[e].isVisible() && this.list[e].hide()
        },
        getActive: function() {
            return this.front
        },
        getActiveAppWindow: function() {
            var e = this.getActive();
            if (e instanceof SYNO.SDS.AppWindow) return e;
            for (; e && !e.appInstance;) e = e.owner;
            return e
        },
        getBy: function(e, t) {
            for (var i = [], s = this.accessList.length - 1; s >= 0; --s) {
                var n = this.accessList[s];
                !1 !== e.call(t || n, n) && i.push(n)
            }
            return i
        },
        each: function(e, t) {
            for (var i in this.list)
                if (this.list[i] && "function" != typeof this.list[i] && !1 === e.call(t || this.list[i], this.list[i])) return
        },
        cascadeOverlap: function(e) {
            var t;
            t = e.container ? e.container.getSize() : e.getSize();
            var i = {
                width: this.offsetX + e.getWidth(),
                height: this.offsetY + e.getHeight()
            };
            i.width > t.width && i.height > t.height ? this.offsetX = this.offsetY = 10 : i.width > t.width ? (10 == this.offsetX && (this.offsetY = 10), this.offsetX = 10) : i.height > t.height && (this.offsetX += 30, this.offsetY = 10), e.setPosition(this.offsetX, this.offsetY), this.offsetX += 30, this.offsetY += 30
        },
        toggleAllWin: function(e) {
            this.showAllButton = this.showAllButton || e, this.toggleAllWinMinimize()
        },
        setShowAllButtonDisabled: function(e) {
            this.showAllButton && this.showAllButton.setDisabled(e)
        },
        toggleAllWinMinimize: function() {
            this.setShowAllButtonDisabled(!0);
            var e = [],
                t = 0,
                i = function() {
                    if (!(--t > 0)) {
                        var e = (new Date).getTime();
                        Ext.each(this.minimizedWin, function(t, i) {
                            t._lastAccess = e + i
                        }), this.orderWindows(), this.setShowAllButtonDisabled(!1)
                    }
                };
            Ext.each(this.accessList, function(t) {
                t.isVisible() && (!1 === t.toggleMinimizable ? t.close() : e.push(t))
            }, this), e.length ? (Ext.invoke(e, "minimize"), this.minimizedWin = e, this.setShowAllButtonDisabled(!1)) : this.minimizedWin.length ? Ext.each(this.minimizedWin, function(e) {
                t++, e.show(void 0, i, this)
            }, this) : this.setShowAllButtonDisabled(!1)
        },
        restoreWin: function(e) {
            var t = function() {
                --this.allToggleing <= 0 && (this.allToggleing = 0, SYNO.SDS.StatusNotifier.fireEvent("allwinrestored"))
            };
            e.el.origXY && (Ext.isIE ? (e.el.setXY([e.el.origXY[0], e.el.origXY[1]]), delete e.el.origXY, this.allToggleing++, t.defer(50, this)) : (this.allToggleing++, e.el.shift({
                x: e.el.origXY[0],
                y: e.el.origXY[1],
                easing: "easeOutStrong",
                duration: this.animDuration,
                scope: this,
                callback: function() {
                    e.el.origShadowDisabled || e.el.enableShadow(!0), e.unmask(), delete e.el.origXY, t.apply(this)
                }
            })), e.childWinMgr && e.childWinMgr.each(this.restoreWin, this))
        },
        exposeWindow: function() {
            if (SYNO.SDS.UIFeatures.test("exposeWindow")) {
                if (this.exposeMask) return void this.restoreTransform();
                if (SYNO.SDS.DesktopMgr.show(SYNO.SDS.Desktop), !this.isRestoreTransform) {
                    if (SYNO.SDS.WindowMgr.allHided) return SYNO.SDS.WindowMgr.toggleAllWin(), void SYNO.SDS.StatusNotifier.on("allwinrestored", this.exposeWindow, this, {
                        single: !0
                    });
                    this.shownAppWins = [];
                    var e = SYNO.SDS.TaskButtons.getAllAppWins();
                    if (0 !== e.length) {
                        Ext.each(e, function(e) {
                            if (!e.isVisible()) {
                                if (this.isSkipExposeAppWindow(e)) return !0;
                                e.show(!1), this.shownAppWins.push(e)
                            }
                        }, this), this.hiddenNonAppWins = [], Ext.each(this.accessList, function(e) {
                            e.isVisible() && !e.taskButton && (e.hide(!1), this.hiddenNonAppWins.push(e))
                        }, this);
                        var t = this.calWindowPosition(e),
                            i = t.xyValues;
                        this.exposeMask = Ext.getBody().createChild({
                            tag: "div",
                            cls: "sds-expose-mask",
                            tabIndex: 0
                        }), this.focusMask(), this.exposeMask.on("click", this.restoreTransform, this);
                        var s = 0;
                        Ext.each(e, function(e) {
                            e.isVisible() && (e.el._origPos = {
                                x: e.el.getLeft(!0),
                                y: e.el.getTop(!0)
                            }, e.el._toWin = i[s], this.transformWindow(e, t.noWin), s++)
                        }, this), this.exposeMask.setStyle({
                            opacity: "0.6",
                            "z-index": 1e3
                        }), SYNO.SDS.StatusNotifier.fireEvent("allwinexpose")
                    }
                }
            }
        },
        focusMask: function() {
            this.exposeMask.focus()
        },
        transformWindow: function(e, t) {
            if (!e) return !1;
            var i = e.el;
            i.disableShadow();
            var s = i._toWin;
            if (i._exposeMask = i.createChild({
                    tag: "div",
                    cls: "sds-expose-win-mask"
                }), e.focusEl.on("focus", this.focusMask, this), !0 === t) i.addClass("sds-expose-win-hidden");
            else {
                var n = i.getSize(),
                    r = s.w / n.width;
                n.height * r > s.h && (r = s.h / n.height), r = Math.min(r, 1).toFixed(2);
                var o = s.x - i._origPos.x,
                    a = s.y - i._origPos.y;
                i.addClass("sds-expose-win-transform"), i.setStyle("-webkit-transform", String.format("translate3d({1}px, {2}px, 0) scale3d({0}, {0}, 1)", r, o, a)), i.setStyle("-moz-transform", String.format("translate({1}px, {2}px) scale({0})", r, o, a)), i.setStyle("-o-transform", String.format("translate({1}px, {2}px) scale({0})", r, o, a)), i.setStyle("transform", String.format("translate({1}px, {2}px) scale({0})", r, o, a))
            }
            return e._deferTaskId = this.afterTransformWindow.defer(!0 === t ? 0 : this.exposeTransformDelayTime, this, [e, t]), e
        },
        afterTransformWindow: function(e, t) {
            if (!e) return !1;
            var i = e.el,
                s = i._toWin;
            if (Ext.isEmpty(i.dom)) return !1;
            var n = i._exposeMask;
            if (e.mon(n, "mousedown", function(e) {
                    e.stopEvent()
                }, this), e.mon(n, "click", this.onWinMaskClick, this, {
                    win: e
                }), e.mon(n, "mouseenter", function(e) {
                    var t = e.getTarget();
                    Ext.fly(t).addClass("sds-expose-win-over")
                }, this), e.mon(n, "mouseleave", function(e) {
                    var t = e.getTarget();
                    Ext.fly(t).removeClass("sds-expose-win-over")
                }, this), i.iconBadge = new SYNO.SDS.IconBadge, e.jsConfig && e.getTitle() && e.jsConfig.icon) {
                var r = e.jsConfig.jsBaseURL + "/" + (e.jsConfig.icon || e.jsConfig.icon_16);
                i.iconBadge.setIconText(SYNO.SDS.UIFeatures.IconSizeManager.getIconPath(r, "Header"), SYNO.SDS.UIString.GetLocalizedString(e.getTitle(), e.jsConfig.jsID))
            } else i.iconBadge.setIconText("", e.title || "");
            i.iconBadge.setXY(s.x, s.y - this.exposeIconHeight + this.exposeIconShift), e.mon(i.iconBadge.el, "click", this.onWinMaskClick, this, {
                win: e
            })
        },
        onWinMaskClick: function(e, t, i) {
            return this.restoreTransform(),
                function() {
                    i.win.show()
                }.defer(this.exposeRestoreDelayTime, this), e.stopEvent(), !1
        },
        restoreTransform: function() {
            this.isRestoreTransform || (this.isRestoreTransform = !0, this.exposeMask && this.exposeMask.setStyle("opacity", "0"), Ext.each(this.accessList, function(e) {
                var t = e.el;
                if (e.focusEl.un("focus", this.focusMask, this), e._deferTaskId && (window.clearTimeout(e._deferTaskId), e._deferTask = null), t._origPos) {
                    t.iconBadge && (t.iconBadge.el.hide(), t.iconBadge.el.remove(), t.iconBadge = null), t._exposeMask && (t._exposeMask.remove(), delete t._exposeMask, t._exposeMask = null), t.hasClass("sds-expose-win-hidden") ? t.removeClass("sds-expose-win-hidden") : (t.addClass("sds-expose-win-transform-restore"), t.setStyle("-webkit-transform", ""), t.setStyle("-moz-transform", ""), t.setStyle("-o-transform", ""), t.setStyle("transform", ""));
                    (function() {
                        t.removeClass("sds-expose-win-transform"), t.removeClass("sds-expose-win-transform-restore"), t.enableShadow(!0)
                    }).defer(this.exposeRestoreDelayTime, this)
                }
            }, this), Ext.each(this.hiddenNonAppWins, function(e) {
                e.isSkipUnexpose && e.isSkipUnexpose() || e.show(!1)
            }, this), Ext.each(this.shownAppWins, function(e) {
                e.hide(!1), e.minimize()
            }, this), function() {
                this.exposeMask && (this.exposeMask.un("click", this.restoreTransform, this), this.exposeMask.remove(), this.exposeMask = null), SYNO.SDS.StatusNotifier.fireEvent("allwinunexpose"), this.isRestoreTransform = !1
            }.defer(this.exposeRestoreDelayTime, this))
        },
        calWindowPosition: function(e) {
            var t = 0;
            Ext.each(e, function(e) {
                e.isVisible() && t++
            });
            var i = SYNO.SDS.Desktop.getEl().getSize(),
                s = i.width,
                n = i.height,
                r = 0,
                o = 0,
                a = this.exposeIconHeight,
                l = 1;
            t < 3 ? (r = 1 === t ? s - 100 : (s - 150) / 2, o = n - 100 - a) : (l = Math.ceil(t / 3), r = (s - 200) / 3, o = (n - 50 * (l + 1) - l * a) / l), r = Math.round(r), o = Math.round(o);
            for (var c = {}, d = [], h = 0; h < t; ++h) {
                var u = h % 3 + 1,
                    p = Math.max(Math.ceil((h + 1) / 3), 1),
                    _ = 0,
                    f = 0;
                f = t < 3 ? 50 + a : p * (50 + a) + (p - 1) * o, _ = (u - 1) * r + 50 * u, d[h] = {
                    x: _,
                    y: f,
                    w: r,
                    h: o
                }
            }
            return c.xyValues = d, (r < 80 || o < 80 || t > 9) && (c.noWin = !0), c
        },
        isSkipExposeAppWindow: function(e) {
            return !(!e.isSkipExpose || !0 !== e.isSkipExpose()) || !!(SYNO.SDS.AudioStation && SYNO.SDS.AudioStation.MainWindow && e instanceof SYNO.SDS.AudioStation.MainWindow && !0 === e.gIsOnMiniPlayerMode)
        }
    }), Ext.namespace("SYNO.SDS.AppWindow"), Ext.define("SYNO.SDS.FullScreenToolbar", {
        extend: "Ext.Container",
        constructor: function(e) {
            if (!(e.appWin && e.appWin instanceof SYNO.SDS.AppWindow)) return void SYNO.Debug.error("Need to add appWin in config!");
            this.offsetX = e && e.offset ? e.offset[0] : 0, this.offsetY = e && e.offset ? e.offset[1] : 0, this.callParent([this.fillConfig(e)])
        },
        fillConfig: function(e) {
            this.contentBox = new Ext.BoxComponent({
                cls: "syno-sds-fullscreen-toolbar-content-container"
            });
            var t = {
                hideMode: "offset",
                cls: "syno-sds-fullscreen-toolbar",
                renderTo: SYNO.SDS.Desktop.getEl(),
                items: [this.contentBox]
            };
            return Ext.apply(t, e)
        },
        adjustPos: function() {
            var e = "tl",
                t = [_S("standalone") ? 10 : 0, _S("standalone") ? 10 : 0],
                i = this.appWin.fsHandler,
                s = this.el.parent();
            i ? (s = i.el, e = "br", t[0] -= this.el.getWidth()) : "b" === this.dir ? (e = "bl", t[1] -= _S("standalone") ? this.el.getHeight() + 10 : this.el.getHeight()) : "r" === this.dir && (e = "tr", t[0] -= _S("standalone") ? this.el.getWidth() + 10 : this.el.getWidth()), t[0] += this.offsetX, t[1] += this.offsetY, this.el.alignTo(s, e, t), this.el.applyStyles({
                zIndex: parseInt(this.appWin.el.getStyle("zIndex"), 10) + 1
            })
        },
        cancleHideTask: function() {
            this.hideTask || (this.hideTask = new Ext.util.DelayedTask(this.hide, this)), this.hideTask.delay(2e3)
        },
        show: function(e, t) {
            this.cancleHideTask(), this.adjustPos(), this.el.hasClass("dissolve-in") || (this.removeClass("dissolve-out"), this.addClass("dissolve-in"))
        },
        hide: function(e) {
            if (e) return Ext.each(this.contentBox.el.dom.childNodes, function(e) {
                var t = Ext.get(e);
                t.orgParent.appendChild(t)
            }), this.removeParentClsFromContentBox(), void this.callParent();
            this.el.hasClass("dissolve-in") && (this.removeClass("dissolve-in"), this.addClass("dissolve-out")), this.hideTask && (this.hideTask = null)
        },
        addParentClsToContentBox: function(e) {
            Ext.isArray(e) ? Ext.each(e, this.addParentClsToContentBox, this) : Ext.isString(e) && (this.contentBox.addClass(e), this.contentBox.addedCls || (this.contentBox.addedCls = []), this.contentBox.addedCls.push(e))
        },
        removeParentClsFromContentBox: function() {
            this.contentBox.addedCls && this.contentBox.addedCls.each(function(e) {
                this.contentBox.removeClass(e)
            }, this)
        },
        addElements: function(e) {
            Ext.isArray(e) ? Ext.each(e, this.addElements, this) : Ext.isObject(e) && e instanceof Ext.Element && (e.orgParent = e.parent(), this.contentBox.el.appendChild(e))
        }
    }), Ext.define("SYNO.SDS.AppWindow", {
        extend: "SYNO.SDS.BaseWindow",
        moveDirty: !1,
        resizeDirty: !1,
        autoCenter: !0,
        initialized: !1,
        taskButton: null,
        ariaRole: "application",
        constructor: function(e) {
            var t;
            e = Ext.apply({}, e, {
                useStatusBar: Ext.isDefined(e.buttons),
                showHelp: !0,
                toggleGrayOverlay: !0,
                toggleFullScreen: !1,
                autoCenter: !0
            }), e = Ext.apply(e, {
                title: null,
                iconCls: "x-panel-icon",
                openConfig: {
                    dsm_version: _S("majorversion") + "." + _S("minorversion")
                }
            }), !_S("standalone") && e.appInstance && (!0 === e.autoStart || !0 !== e.fromRestore && !1 !== e.autoRestoreSizePos) && Ext.apply(e, this.getRestoreSizePos(e)), !_S("standalone") && e.showHelp && (Ext.isArray(e.tools) || (e.tools = []), e.tools.push({
                id: "help",
                text: _T("common", "alt_help"),
                scope: this,
                handler: this.onClickHelp
            })), e.toggleFullScreen && SYNO.SDS.UIFeatures.test("isSupportFullScreen") && (this.isFullScreen = !1, Ext.isArray(e.tools) || (e.tools = []), e.tools.push({
                id: "fullscreen",
                text: _T("personal_settings", "menu_style_fullscreen"),
                scope: this,
                handler: this.onClickFullScrren
            })), t = !Ext.isDefined(e.maximizable) || e.maximizable;
            var i = !!e.appInstance && e.appInstance.blMainApp;
            if (_S("standalone")) {
                if (i) Ext.apply(e, {
                    maximizable: !1,
                    maximized: t,
                    closable: !1,
                    modal: !1
                }), e.cls = (e.cls || "") + (this.cls || "") + " sds-standalone-main-window", "true" === _S("remove_banner") && (e.cls += " sds-standalone-main-window--no-banner"), document.title = e.title || document.title;
                else if (Ext.apply(e, {
                        maximizable: !1,
                        maximized: !1,
                        closable: !0,
                        modal: !0
                    }), t) {
                    Ext.EventManager.onWindowResize(this.onModalWindowResize, this), Ext.apply(e, {
                        x: 10,
                        y: 10,
                        width: Ext.lib.Dom.getViewWidth() - 20,
                        height: Ext.lib.Dom.getViewHeight() - 20
                    })
                }
                Ext.apply(e, {
                    resizable: !1,
                    draggable: !1,
                    minimizable: !1
                })
            }
            if ((_S("isMobile") || Ext.isIE10Touch) && t && Ext.apply(e, {
                    maximized: !0
                }), e = this.overwriteAppWinConfig(e), SYNO.SDS.AppWindow.superclass.constructor.call(this, e), e.maximized ? SYNO.SDS.StatusNotifier.fireEvent("windowMaximize") : (_S("standalone") && this.anchorTo(this.container, "c-c"), (_S("isMobile") || Ext.isIE10Touch) && this.anchorTo(this.container, "t-t")), this.mon(this, "move", this.onWindowMove, this), this.resizer && this.mon(this.resizer, "resize", this.onHandlerResize, this), e.toggleFullScreen && this.bindFullScreenEvents(), _S("standalone") && i) {
                var s, n = this.getSmallIcon(!0);
                s = SYNO.SDS.UIFeatures.test("isRetina") ? [32, 64, 256] : [16, 32, 128], Ext.each(s, function(e) {
                    n.indexOf("webman/3rdparty/") >= 0 ? SYNO.SDS.Utils.addFavIconLink(n.replace(/(res=)(\d)*/, "$1" + e), "image/png", e + "x" + e) : SYNO.SDS.Utils.addFavIconLink(n.replace(/(_16|_32)/, "_" + e), "image/png", e + "x" + e)
                }), this.mon(this, "titlechange", function() {
                    document.title = this.title || document.title
                }, this)
            }!0 === this.splitWindow && this.addClass("x-window-split")
        },
        getTrait: function() {
            return this.jsConfig && this.jsConfig.jsID ? this.jsConfig.jsID : this.callParent()
        },
        _onBeforeMaximize: function() {
            return SYNO.SDS.StatusNotifier.fireEvent("windowBeforeMaximize", this), this.callParent()
        },
        _onMinimize: function() {
            return SYNO.SDS.StatusNotifier.fireEvent("windowMinimize", this), this.callParent()
        },
        _onActivate: function() {
            return SYNO.SDS.StatusNotifier.fireEvent("windowActivate", this), this.callParent()
        },
        _onRestore: function() {
            return SYNO.SDS.StatusNotifier.fireEvent("windowRestore", this), this.callParent()
        },
        _onClose: function() {
            return SYNO.SDS.StatusNotifier.fireEvent("windowClose", this), this.callParent()
        },
        bindFullScreenEvents: function() {
            document.fullscreenEnabled ? document.addEventListener("fullscreenchange", this.handleFSChange.createDelegate(this), !1) : document.webkitFullscreenEnabled ? document.addEventListener("webkitfullscreenchange", this.handleFSChange.createDelegate(this), !1) : document.mozFullScreenEnabled ? document.addEventListener("mozfullscreenchange", this.handleFSChange.createDelegate(this), !1) : document.msFullscreenEnabled && document.addEventListener("MSFullscreenChange", this.handleFSChange.createDelegate(this), !1)
        },
        isAlwaysOnTop: function() {
            if (!0 === this.toggleFullScreen && !0 === this.isFullScreen) return !0
        },
        handleFSChange: function() {
            if (this.isFullScreen) {
                if (SYNO.SDS.UIFeatures.isFullScreenMode()) {
                    if (!1 === this.fireEvent("beforeenablefullscreen")) return;
                    _S("standalone") || (SYNO.SDS.TaskBar.hide(), SYNO.SDS.Desktop.getEl().setStyle({
                        top: "0px",
                        zIndex: 0,
                        height: window.screen.height + "px"
                    }), this.lastStateMaximized = this.maximized, this.lastStateMaximized ? (this.setPosition(0, 0), this.fitContainer()) : this.toggleMaximize()), this.hideTools(), this.fireEvent("windowfullscreenenabled")
                } else {
                    if (!1 === this.fireEvent("beforedisablefullscreen")) return;
                    this.isFullScreen = !1, this.showTools(), _S("standalone") || (this.lastStateMaximized ? (SYNO.SDS.TaskBar && this.setPosition(0, SYNO.SDS.TaskBar.height()), this.fitContainer()) : this.toggleMaximize(), SYNO.SDS.Desktop.getEl().setStyle({
                        zIndex: "",
                        height: Ext.getBody().getHeight() + "px"
                    }), SYNO.SDS.TaskBar.show()), this.fireEvent("windowfullscreendisabled")
                }
                SYNO.SDS.WindowMgr.orderWindows()
            }
        },
        showFSToolbar: function() {
            this.fsToolbar.show()
        },
        initFSToolbar: function(e, t, i, s, n) {
            t = t || "t", this.fsToolbar || (this.fsToolbar = new SYNO.SDS.FullScreenToolbar({
                appWin: this,
                dir: t,
                offset: n
            })), e && this.fsToolbar.addElements(e, i), i && this.fsToolbar.addParentClsToContentBox(i), !0 === s && this.fsToolbar.show(), this.el.on("mousemove", this.showFSToolbar, this), this.el.on("click", this.showFSToolbar, this)
        },
        destroyFSToolbar: function(e) {
            this.el.un("mousemove", this.showFSToolbar, this), this.el.un("click", this.showFSToolbar, this), this.fsToolbar && this.fsToolbar.hide(!e)
        },
        overwriteAppWinConfig: function(e) {
            return e
        },
        genIndPortHeader: function() {
            var e = this.el.createChild({
                    tag: "div",
                    cls: "sds-standalone-main-window-header"
                }, this.header.dom),
                t = !1 === this.showHelp;
            new Ext.Toolbar({
                renderTo: e,
                toolbarCls: "sds-standalone-main-window-header__toolbar",
                buttonAlign: "right",
                items: [{
                    xtype: "syno_button",
                    cls: "sds-standalone-main-window-header__toolbar__btn",
                    text: _S("user"),
                    scope: this,
                    menu: new SYNO.ux.Menu({
                        cls: "sds-standalone-main-window-header__toolbar__menu",
                        items: [{
                            cls: "sds-standalone-logout",
                            iconCls: "sds-standalone-logout-icon",
                            text: _T("common", "logout"),
                            scope: this,
                            hidden: !_S("rewrite_mode") || t,
                            handler: function() {
                                SYNO.SDS.StatusNotifier.fireEvent("logout"), window.onbeforeunload = SYNO.SDS.onBasicBeforeUnload;
                                try {
                                    SYNO.SDS.Utils.Logout.action()
                                } catch (e) {}
                            }
                        }, {
                            cls: "sds-standalone-help",
                            iconCls: "sds-standalone-help-icon",
                            text: _T("common", "alt_help"),
                            hidden: t,
                            scope: this,
                            handler: this.onClickHelp
                        }]
                    })
                }],
                listeners: {
                    scope: this,
                    single: !0,
                    buffer: 80
                }
            })
        },
        afterRender: function() {
            SYNO.SDS.AppWindow.superclass.afterRender.apply(this, arguments), _S("standalone") && this.alignTo(document.body, "c-c"), this.isStandaloneMainWindow() && (this.header.dom.innerHTML = '<div class="sds-standalone-main-window-header-text">' + this.header.dom.innerHTML + "</div>", "true" !== _S("remove_banner") && this.genIndPortHeader()), !0 === this.maximized && 0 == this.minimized && SYNO.SDS.StatusNotifier && SYNO.SDS.StatusNotifier.fireEvent("windowMaximize", this), !1 === this.autoCenter || _S("standalone") || this.centerItIfOutOfBound()
        },
        destroy: function() {
            _S("standalone") && Ext.EventManager.removeResizeListener(this.onModalWindowResize, this), this.aboutWindow && this.aboutWindow.destroy(), SYNO.SDS.AppWindow.superclass.destroy.apply(this, arguments)
        },
        onModalWindowResize: function() {
            this.setPosition(10, 10), this.setSize(Ext.lib.Dom.getViewWidth() - 20, Ext.lib.Dom.getViewHeight() - 20)
        },
        isStandaloneMainWindow: function() {
            return _S("standalone") && this.appInstance && this.appInstance.blMainApp
        },
        getSmallIcon: function(e) {
            var t, i = this.jsConfig.jsBaseURL + "/" + (this.jsConfig.icon || this.jsConfig.icon_16),
                s = this.isStandaloneMainWindow();
            return t = e ? "FavHeader" : s ? "StandaloneHeader" : this.isV5Style() ? "Header" : "HeaderV4", SYNO.SDS.UIFeatures.IconSizeManager.getIconPath(i, t)
        },
        init: function() {
            this.initialized || (!1 !== this.toggleMinimizable && this.setIcon(this.getSmallIcon()), _S("standalone") || !1 === this.toggleMinimizable || (this.taskButton = this.appInstance.taskButton || SYNO.SDS.TaskButtons.add(this.appInstance.jsConfig.jsID, this.jsConfig.jsID), this.taskButton.init(this), this.taskButton.setState("deactive"), this.addManagedComponent(this.taskButton)), this.setTitle(SYNO.SDS.UIString.GetLocalizedString(this.getTitle(), this.appInstance.jsConfig.jsID)), this.initialized = !0)
        },
        onBeforeDestroy: function() {
            SYNO.SDS.AppWindow.superclass.onBeforeDestroy.apply(this, arguments), this.taskButton = null
        },
        showAboutWindow: function() {
            var e = arguments.length > 0 && void 0 !== arguments[0] ? arguments[0] : {};
            this.aboutWindow || (this.aboutWindow = Vue.extend({
                template: '<v-about-window :syno-id="synoId" :name="name" :custom-name="customName" :desc="desc" :icon="icon" :copyright-year="copyrightYear" :is-beta="isBeta" :swap-name-and-desc="swapNameAndDesc" :theme="theme" :class="customCls" />',
                props: ["synoId", "name", "customName", "desc", "icon", "copyrightYear", "isBeta", "swapNameAndDesc", "theme", "customCls"]
            }));
            var t = this.getJsConfig();
            this.openVueWindow(this.aboutWindow, {
                synoId: e.synoId || t.jsID,
                name: SYNO.SDS.UIString.GetLocalizedString(this.getTitle(), t.jsID),
                customName: Array.isArray(t.customAboutTitle) ? [SYNO.SDS.UIString.GetLocalizedString(t.customAboutTitle[0], t.jsID), SYNO.SDS.UIString.GetLocalizedString(t.customAboutTitle[1], t.jsID)] : null,
                desc: e.desc || "",
                icon: SYNO.SDS.UIFeatures.IconSizeManager.getIconPath(t.jsBaseURL + "/" + (t.icon || t.icon_32), "desktop"),
                copyrightYear: t.buildTime ? t.buildTime.split("-")[0] : _S && _S("builddate") ? _S("builddate").split("/")[0] : "",
                isBeta: void 0 !== e.isBeta ? e.isBeta : this.isBeta || !1,
                swapNameAndDesc: e.swapNameAndDesc || !1,
                theme: e.theme || {},
                customCls: e.customCls || ""
            })
        },
        hideAboutWindow: function() {
            this.aboutWindow && this.aboutWindow.hide()
        },
        showTools: function() {
            var e, t = this.maximized;
            for (e in this.tools)
                if (this.tools.hasOwnProperty(e)) {
                    if (!this.maximizable && "maximize" === e || !this.maximizable && "restore" === e || t && "maximize" === e || !t && "restore" === e) continue;
                    "fullscreen" == e && this.tools[e].removeClass("collapse"), this.tools[e].show()
                }
        },
        hideTools: function() {
            var e;
            for (e in this.tools)
                if (this.tools.hasOwnProperty(e)) {
                    if ("fullscreen" === e) {
                        this.tools[e].addClass("collapse");
                        continue
                    }
                    this.tools[e].hide()
                }
        },
        onClickFullScrren: function() {
            var e = SYNO.SDS.Desktop.getEl().dom;
            SYNO.SDS.UIFeatures.isFullScreenMode() ? document.exitFullscreen ? document.exitFullscreen() : document.msExitFullscreen ? document.msExitFullscreen() : document.mozCancelFullScreen ? document.mozCancelFullScreen() : document.webkitExitFullscreen && document.webkitExitFullscreen() : (this.isFullScreen = !0, e.requestFullscreen ? e.requestFullscreen() : e.msRequestFullscreen ? e.msRequestFullscreen() : e.mozRequestFullScreen ? e.mozRequestFullScreen() : e.webkitRequestFullscreen && e.webkitRequestFullscreen())
        },
        onClickHelp: function() {
            var e = this.appInstance ? this.appInstance.jsConfig.jsID : this.jsConfig.jsID,
                t = this.getHelpParam();
            Ext.isString(t) && t.length && (e += ":" + t), _S("standalone") ? SYNO.SDS.WindowLaunch("SYNO.SDS.HelpBrowser.Application", {
                topic: e
            }) : SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                topic: e
            }, !1)
        },
        getHelpParam: Ext.emptyFn,
        setTitle: function(e, t, i) {
            if (SYNO.SDS.AppWindow.superclass.setTitle.apply(this, arguments), this.taskButton) {
                var s = !1 !== i ? Ext.util.Format.htmlEncode(e) : e;
                this.taskButton.setTooltip(s)
            }
        },
        getTitle: function() {
            var e = this.getJsConfig();
            return this.title || e.title
        },
        getJsConfig: function() {
            return this.appInstance ? this.appInstance.jsConfig : this.jsConfig
        },
        updateTaskButton: function(e) {
            this.taskButton && this.taskButton.updateContextMenu(e)
        },
        restore: function() {
            !0 !== this.isFullScreen && SYNO.SDS.AppWindow.superclass.restore.call(this)
        },
        onHeaderContextMenu: function(e) {
            !0 !== this.isFullScreen && (SYNO.SDS.AppWindow.superclass.onHeaderContextMenu.apply(this, arguments), _S("standalone") || this.taskButton.getContextMenu(!1).showAt(e.getXY()))
        },
        onMaximize: function() {
            SYNO.SDS.AppWindow.superclass.onMaximize.apply(this, arguments), this.updateTaskButton("maximize"), this.saveRestoreData()
        },
        onMinimize: function() {
            _S("standalone") || (this.minimizable ? this.hide() : this.el.frame(), SYNO.SDS.AppWindow.superclass.onMinimize.apply(this, arguments), this.updateTaskButton("minimize"))
        },
        onRestore: function() {
            SYNO.SDS.AppWindow.superclass.onRestore.apply(this, arguments), this.updateTaskButton("restore"), this.saveRestoreData()
        },
        mask: function() {
            SYNO.SDS.AppWindow.superclass.mask.apply(this, arguments), this.updateTaskButton("mask")
        },
        unmask: function() {
            SYNO.SDS.AppWindow.superclass.unmask.apply(this, arguments), this.updateTaskButton("unmask")
        },
        onWindowMove: function() {
            this.moveDirty = !0, this.saveRestoreData()
        },
        onHandlerResize: function() {
            this.resizeDirty = !0, this.saveRestoreData()
        },
        saveRestoreData: function() {
            var e = this.appInstance.getUserSettings("restoreSizePos"),
                t = Ext.apply(this.getSizeAndPosition(), {
                    fromRestore: !0,
                    maximized: this.maximized
                });
            e && (this.moveDirty ? this.moveDirty = !1 : (e.pageX && (t.pageX = e.pageX), e.pageY && (t.pageY = e.pageY)), this.resizeDirty ? this.resizeDirty = !1 : (e.width && (t.width = e.width), e.height && (t.height = e.height))), this.appInstance.setUserSettings("restoreSizePos", t)
        },
        adjustPageXY: function(e) {
            return e ? (Ext.isDefined(e.pageX) && e.pageX < 0 && (e.pageX = 0), Ext.isDefined(e.pageY) && e.pageY < 0 && (e.pageY = 0), Ext.isDefined(e.x) && e.x < 0 && (e.x = 0), Ext.isDefined(e.y) && e.y < 0 && (e.y = 0), e) : {}
        },
        isOutOfBound: function() {
            var e = Ext.lib.Dom.getViewWidth(!0),
                t = Ext.lib.Dom.getViewHeight(!0);
            if (Ext.isDefined(this.pageX) && (this.pageX < 0 || this.pageX + this.width > e)) return !0;
            var i = SYNO.SDS.TaskBar ? SYNO.SDS.TaskBar.height() : 0;
            return !(!Ext.isDefined(this.pageY) || !(this.pageY < i || this.pageY + this.height > t))
        },
        centerItIfOutOfBound: function() {
            this.isOutOfBound() && (SYNO.SDS.WindowMgr.centerWindow(this, {
                withOffset: this.autoStart
            }), this.moveDirty = !0)
        },
        getRestoreSizePos: function(e) {
            var t = e.appInstance.getUserSettings("restoreSizePos") || {};
            return Ext.isDefined(e.minWidth) && Ext.isDefined(t.width) && t.width < e.minWidth && (Ext.isDefined(e.width) ? t.width = e.width : t.width = e.minWidth), Ext.isDefined(e.minHeight) && Ext.isDefined(t.height) && t.height < e.minHeight && (Ext.isDefined(e.height) ? t.height = e.height : t.height = e.minHeight), Ext.isDefined(t.maximized) || (t.maximized = e.defaultMaximized), e.maximized && (t.maximized = e.maximized), t
        },
        onOpen: function(e) {
            var t;
            if (this.initialized || this.init(), Ext.isObject(e)) {
                for (t in e) e.hasOwnProperty(t) && this.setOpenConfig(t, e[t]);
                e.title && this.setTitle(e.title), SYNO.API.Info.Update(this)
            }
            this.appInstance.skipRecord || this.recordAppOpened(), SYNO.SDS.AppWindow.superclass.onOpen.apply(this, arguments)
        },
        recordAppOpened: function() {
            var e = this.appInstance,
                t = e.appWindowName,
                i = e.jsConfig.jsID;
            t && _S("isLogined") && this.sendWebAPI({
                callback: function() {
                    SYNO.SDS.StatusNotifier.fireEvent("apprecordupdated", i, t)
                }.bind(this),
                compound: {
                    stopwhenerror: !1,
                    params: [{
                        api: "SYNO.Core.DataCollect.Application",
                        version: 1,
                        method: "record",
                        params: {
                            app: t
                        }
                    }, {
                        api: "SYNO.Core.AppNotify",
                        version: 1,
                        method: "view",
                        params: {
                            app: i
                        }
                    }]
                }
            })
        },
        onShow: function() {
            SYNO.SDS.AppWindow.superclass.onShow.apply(this, arguments), this.updateTaskButton("restore")
        },
        checkModalOrMask: function() {
            return !!(this.modalWin && this.modalWin.length > 0 || this.maskCnt > 0) && (this.blinkModalChild(), !0)
        },
        setMaskMsgVisible: function(e) {
            if (this.el.isMasked()) {
                var t = Ext.Element.data(this.el, "maskMsg");
                t && t.dom && (t.setVisibilityMode(Ext.Element.VISIBILITY), t.setVisible(e))
            }
        },
        setMaskOpacity: function(e) {
            SYNO.SDS.AppWindow.superclass.setMaskOpacity.call(this, e), this.setMaskMsgVisible(0 !== e)
        },
        delayedMask: function(e, t, i, s) {
            t = t || 200, this.maskTask || (this.maskTask = new Ext.util.DelayedTask(this.setMaskOpacity, this, [e])), this.mask(0, i, s), this.setMaskMsgVisible(!1), this.maskTask.delay(t)
        },
        synchronizedMask: function(e, t, i) {
            this.mask(e, t, i), this.setMaskMsgVisible(0 !== e)
        },
        setStatusBusy: function(e, t, i) {
            e = e || {}, Ext.applyIf(e, {
                text: _T("common", "loading"),
                iconCls: "x-mask-loading"
            }), t = Ext.isNumber(t) ? t : .4, i = Ext.isNumber(i) ? i : 400, i > 0 ? this.delayedMask(t, i, e.text, e.iconCls) : this.synchronizedMask(t, e.text, e.iconCls), this.canClose = !1
        },
        clearStatusBusy: function(e) {
            this.unmask(), this.canClose = !0
        },
        onClose: function() {
            if (this.isStandaloneMainWindow() || !1 === this.canClose) return !1;
            this.saveRestoreData(), this.callParent()
        },
        getOpenConfig: function(e) {
            if (Ext.isString(e) && !Ext.isEmpty(this.openConfig[e])) return this.openConfig[e]
        },
        setOpenConfig: function(e, t) {
            Ext.isString(e) && !Ext.isEmpty(e) && (this.openConfig[e] = t)
        },
        hasOpenConfig: function(e) {
            return !(!Ext.isString(e) || Ext.isEmpty(e)) && void 0 !== this.openConfig[e]
        }
    }), Ext.namespace("SYNO.SDS.AppInstance"), SYNO.SDS.AppInstance = Ext.extend(Ext.Component, {
        window: null,
        trayItem: null,
        instances: null,
        taskButton: null,
        blMainApp: !1,
        constructor: function(e) {
            _S("standalone") && (this.blMainApp = this.jsConfig.jsID === _S("standaloneAppName")), SYNO.SDS.AppInstance.superclass.constructor.apply(this, arguments), SYNO.SDS.AppMgr.register(this)
        },
        beforeDestroy: function() {
            !0 === this.fullsize && SYNO.SDS.StatusNotifier.fireEvent("fullsizeappdestroy"), this.jsConfig.upgradeApp && !0 === this.jsConfig.upgradeApp && SYNO.SDS.StatusNotifier.fireEvent("upgradeappdestroy"), SYNO.SDS.AppInstance.superclass.beforeDestroy.apply(this, arguments), this.onBeforeDestroy()
        },
        onBeforeDestroy: function() {
            this.instances = null, this.window = null, this.trayItem = null, this.appItem = null, this.taskButton = null, SYNO.SDS.AppMgr.unregister(this)
        },
        beforeOpen: Ext.emptyFn,
        initInstance: function(e) {
            var t;
            if (!this.window && this.appWindowName) {
                if (!0 === this.fullsize) {
                    if (!(!!this.shouldLaunch && this.shouldLaunch(e))) return void this.destroy()
                }
                t = Ext.getClassByName(this.appWindowName), this.window = new t(Ext.apply({
                    appInstance: this,
                    fromRestore: e.fromRestore,
                    autoStart: e.autoStart,
                    autoCenter: e.autoCenter
                }, e.windowState || {})), this.addInstance(this.window), this.window.init(), this.window.open(e)
            }!this.trayItem && this.appTrayItemName && (t = Ext.getClassByName(this.appTrayItemName), this.trayItem = new t(Ext.apply({
                appInstance: this
            })), this.addInstance(this.trayItem), this.trayItem.open(e)), !this.appItem && this.appItemName && (t = Ext.getClassByName(this.appItemName), this.appItem = new t(Ext.apply({
                appInstance: this
            })), this.addInstance(this.appItem), this.appItem.open(e))
        },
        open: function(e) {
            if (!Ext.isObject(e) || !Ext.isNumber(e.cms_id) || 0 >= e.cms_id) return this.delayOpen(e);
            SYNO.API.Info.UpdateById({
                cms_id: e.cms_id,
                callback: this.delayOpen,
                args: arguments,
                scope: this
            }, !0)
        },
        delayOpen: function() {
            return this.opened ? this.onRequest.apply(this, arguments) : (this.opened = !0, this.onOpen.apply(this, arguments))
        },
        onOpen: function(e) {
            if (!1 === this.beforeOpen(e)) return void this.destroy();
            this.initInstance(e), this.checkAlive()
        },
        onRequest: function(e) {
            this.window && this.window.open(e), this.trayItem && this.trayItem.open(e), this.appItem && this.appItem.open(e)
        },
        checkAlive: function() {
            this.destroying || this.instances && this.instances.length || this.destroy()
        },
        addInstance: function(e) {
            e.appInstance = this, this.instances = this.instances || [], this.instances.push(e), this.addManagedComponent(e)
        },
        removeInstance: function(e) {
            e.appInstance = null, this.instances = this.instances || [], this.instances.remove(e), this.removeManagedComponent(e), this.checkAlive()
        },
        shouldNotifyMsg: function(e, t) {
            return !0
        },
        getJsConfig: function() {
            return this.jsConfig
        },
        getRestoreSizePos: function(e) {
            return this.getUserSettings("restoreSizePos") || {}
        },
        getUserSettings: function(e) {
            return SYNO.SDS.UserSettings.getProperty(this.jsConfig.jsID, e)
        },
        setUserSettings: function(e, t) {
            return SYNO.SDS.UserSettings.setProperty(this.jsConfig.jsID, e, t)
        },
        getStateParam: function() {
            var e = {
                windowState: {}
            };
            return Ext.isEmpty(this.window) ? e : (Ext.apply(e, {
                windowState: this.window.getStateParam()
            }, this.window.openConfig), e)
        }
    }), Ext.namespace("SYNO.SDS.ModalWindow"), Ext.define("SYNO.SDS.ModalWindow", {
        extend: "SYNO.SDS.BaseWindow",
        ownerMasked: !1,
        constructor: function(e) {
            e = Ext.apply({
                useStatusBar: !0,
                closable: !0,
                maximizable: !1,
                minimizable: !1,
                modal: !e.owner
            }, e), this.callParent([e])
        },
        afterRender: function() {
            if (this.callParent(arguments), !this.heightConstrained) {
                var e = this.owner ? this.owner.el : document.body;
                this.owner && this.owner._isVue || this.alignTo(e, "c-c")
            }
            "emphasized" === this.popupStyle && this.el.addClass("syno-em-window")
        },
        isModalized: function() {
            return !0
        },
        hideFromOwner: function() {
            if (this.owner) {
                var e = this.sinkable ? "sinkModalWin" : "modalWin";
                return Ext.isArray(this.owner[e]) && this.owner[e].remove(this), this.ownerMasked && (this.owner.unmask(!0), this.ownerMasked = !1), !0
            }
            return !1
        },
        afterShow: function() {
            this.callParent(arguments), this.owner && this.owner._isVue || (this.owner && this.sinkable ? this.owner.sinkModalWin.push(this) : !this.ownerMasked && this.owner && (this.owner.modalWin.push(this), this.owner.mask(0, null, null, !0), this.ownerMasked = !0))
        },
        afterHide: function() {
            SYNO.SDS.ModalWindow.superclass.afterHide.apply(this, arguments), this.owner && this.owner._isVue || this.hideForMinimize || this.hideFromOwner()
        },
        onBeforeDestroy: function() {
            this.owner && this.owner._isVue || this.hideFromOwner() && (this.owner = null), SYNO.SDS.ModalWindow.superclass.onBeforeDestroy.apply(this, arguments)
        },
        onMinimize: function() {
            this.hide(), SYNO.SDS.ModalWindow.superclass.onMinimize.apply(this, arguments)
        },
        onWindowClose: function() {
            this.owner ? this.owner.focus() : Ext.get("sds-taskbar-startbutton").child("button").focus()
        },
        fillWindowPadding: function(e) {
            Ext.applyIf(e, {
                padding: "16px 20px 0 20px"
            })
        }
    }), Ext.define("SYNO.SDS.MessageBoxV5", {
        extend: "SYNO.SDS.ModalWindow",
        ariaRole: "alertdialog",
        maxWidth: 600,
        minWidth: 420,
        minProgressWidth: 250,
        minPromptWidth: 250,
        emptyText: "&#160;",
        defaultTextHeight: 75,
        mbIconCls: "",
        fbButtons: null,
        opt: null,
        bodyEl: null,
        msgEl: null,
        progressBar: null,
        gridEl: null,
        constructor: function(e) {
            this.opt = {}, this.buttonNames = ["custom", "cancel", "no", "ok", "yes"], this.leftButtonNames = ["leftCustom"], this.buttonText = Ext.MessageBox.buttonText, e = e || {}, e.cls = e.cls ? e.cls + " x-window-dlg" : "x-window-dlg", e.fbar = e.fbar || this.getButtons(e), this.callParent([Ext.apply(e, {
                closable: !0,
                stateful: !1,
                resizable: !1,
                minimizable: !1,
                maximizable: !1,
                header: e.draggable || !1,
                draggable: e.draggable || !1,
                buttonAlign: "left",
                elements: "body",
                padding: "24px 30px 0 30px"
            })]), this.draggable && this.addClass("msgbox-draggable")
        },
        onRender: function() {
            this.callParent(arguments);
            var e = Ext.id();
            this.bodyEl = this.body.createChild({
                html: '<div class="ext-mb-content"><div class="ext-mb-title"></div><span class="ext-mb-text" id=' + e + '></span><br class="ext-mb-br"/><div class="ext-mb-fix-cursor"></div></div><div class="ext-mb-grid"></div>'
            }), this.titleEl = this.bodyEl.child(".ext-mb-title"), this.msgEl = this.bodyEl.child(".ext-mb-text"), this.brEl = this.bodyEl.child(".ext-mb-br"), this.wrapperEl = this.bodyEl.child(".ext-mb-fix-cursor"), this.gridEl = this.bodyEl.child(".ext-mb-grid"), this.progressBar = new Ext.ProgressBar({
                renderTo: this.bodyEl
            }), this.focusEl.set({
                "aria-labelledby": this.msgEl.id
            }), this.focusEl.dom.removeAttribute("aria-label"), this.bodyEl.createChild({
                cls: "x-clear"
            }), this.titleEl.enableDisplayMode(), this.gridEl.enableDisplayMode(), this.addManagedComponent(this.progressBar), this.progressStatus = this.bodyEl.createChild({
                tag: "span",
                cls: "syno-mb-progress-status"
            }, this.bodyEl.child(".x-clear")), this.progressBar.addClass("syno-mb-progress")
        },
        handleButton: function(e, t) {
            this.fbButtons[e].blur();
            var i = this.activeTextField ? this.activeTextField.getValue() : "";
            this.preventDelay ? this.opt.fn.call(this.opt.scope || window, e, i, this.opt, t) : Ext.callback(this.opt.fn, this.opt.scope || window, [e, i, this.opt, t], 1), SYNO.SDS.MessageBoxV5.superclass.close.call(this)
        },
        setIconClass: function(e) {
            if (e && "" !== e) return this.bodyEl.addClass("x-dlg-icon"), this.addClass(e), void(this.mbIconCls = e);
            this.bodyEl.removeClass("x-dlg-icon"), this.mbIconCls = ""
        },
        createTextField: function() {
            this.textbox || (this.textbox = new SYNO.ux.TextField({
                renderTo: this.wrapperEl
            }), this.textbox.el.addKeyListener(Ext.EventObject.ENTER, this.handleButton.createDelegate(this, ["ok"])))
        },
        createTextArea: function() {
            this.textarea || (this.textarea = new SYNO.ux.TextArea({
                renderTo: this.wrapperEl
            }), this.textarea.el.addKeyListener(Ext.EventObject.ENTER, this.handleButton.createDelegate(this, ["ok"])))
        },
        createPasswordField: function() {
            this.passwordField || (this.passwordField = new SYNO.ux.TextField({
                renderTo: this.wrapperEl,
                type: "password"
            }), this.passwordField.el.addKeyListener(Ext.EventObject.ENTER, this.handleButton.createDelegate(this, ["ok"])))
        },
        removeTextArea: function() {
            this.textarea && (this.textarea.destroy(), this.textarea = null)
        },
        removeTextfield: function() {
            this.textbox && (this.textbox.destroy(), this.textbox = null)
        },
        removePassword: function() {
            this.passwordField && (this.passwordField.destroy(), this.passwordField = null)
        },
        setTitle: function(e, t) {
            !0 === t ? (this.titleEl.update(e), this.titleEl.show()) : (this.titleEl.hide(), SYNO.SDS.MessageBoxV5.superclass.setTitle.apply(this, [e]))
        },
        showMsg: function(e) {
            if (this.opt = e, this.setTitle(e.title || this.emptyText, this.opt.useMessageTitle), this.tools.close && this.tools.close.setDisplayed(!1 !== e.closable && !0 !== e.progress && !0 !== e.wait), this.gridEl.hide(), this.activeTextField = null, e.prompt = e.prompt || !!e.multiline, e.prompt ? (e.multiline ? (this.createTextArea(), this.activeTextField = this.textarea, this.textarea.setHeight(Ext.isNumber(e.multiline) ? e.multiline : this.defaultTextHeight), this.removeTextfield(), this.removePassword()) : e.password ? (this.createPasswordField(), this.activeTextField = this.passwordField, this.removeTextfield(), this.removeTextArea()) : (this.createTextField(), this.activeTextField = this.textbox, this.removeTextArea(), this.removePassword()), this.activeTextField.setValue(e.value || "")) : (this.removeTextfield(), this.removeTextArea(), this.removePassword()), this.setIconClass(Ext.isDefined(e.icon) ? e.icon : null), this.buttonWidth = this.updateButtons(e.buttons), this.progressBar.setVisible(!0 === e.progress || !0 === e.wait), this.updateProgress(0, e.progressText), this.updateText(e.msg), e.wait && this.progressBar.wait(e.waitConfig), e.cls && this.el.addClass(e.cls), e.progress ? this.progressBar.progressBar.set({
                    "aria-labelledby": this.msgEl.id
                }) : this.progressBar.progressBar.set({
                    tabIndex: "-1"
                }), !0 === e.wait && this.progressBar.wait(e.waitConfig), Ext.isArray(e.msgArray)) {
                var t = this.bodyEl.child("div.ext-mb-content"),
                    i = Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(e.msg));
                this.brEl.enableDisplayMode("DISPLAY"), this.brEl.hide(), this.msgEl.set({
                    "ext:qtip": i
                }), t.addClass("ext-mb-grid-desc"), this.gridEl.show(), this.createGridPanel(e.msgArray)
            }
            e.hideBrElement && (this.brEl.enableDisplayMode("DISPLAY"), this.brEl.hide()), this.show(), this.owner && !this.owner.isVisible() && (this.hideForMinimize = !0, this.minimize())
        },
        createGridPanel: function(e) {
            var t = e.map(function(e) {
                return [e]
            });
            if (this.grid) return void this.grid.store.loadData(t);
            var i = new Ext.grid.ColumnModel({
                columns: [{
                    dataIndex: "data",
                    renderer: function(e, t, i) {
                        var s = Ext.util.Format.htmlEncode(e);
                        return t.attr = 'ext:qtip="' + Ext.util.Format.htmlEncode(s) + '"', s
                    }
                }]
            });
            this.grid = new SYNO.ux.GridPanel({
                colModel: i,
                store: new Ext.data.ArrayStore({
                    autoDestroy: !0,
                    fields: ["data"],
                    data: t
                }),
                viewConfig: {
                    rowOverCls: "",
                    selectedRowClass: ""
                },
                hideHeaders: !0,
                enableHdMenu: !1,
                height: 304,
                autoHeight: !1,
                renderTo: this.gridEl,
                listeners: {
                    viewready: function(e) {
                        this.view.updateScroller()
                    }
                }
            }), this.addManagedComponent(this.grid)
        },
        selectBtn: function(e, t, i) {
            var s = Object.values(this.fbButtons).filter(function(e) {
                return !e.hidden
            });
            if (0 !== s.length) {
                var n = "previous" === i ? -1 : "next" === i && 1 || 0,
                    r = Ext.getCmp(Ext.get(e.target).up(".syno-ux-button").id),
                    o = s.findIndex(function(e) {
                        return e === r
                    });
                s[Math.min(Math.max(0, o + n), s.length - 1)].focus()
            }
        },
        close: function() {
            !1 !== this.opt.canClose && (this.opt.buttons && this.opt.buttons.no && !this.opt.buttons.cancel ? this.handleButton("no", "close") : this.handleButton("cancel", "close"))
        },
        doClose: function() {
            if (this.activeGhost) {
                var e = Ext.dd.DragDropMgr;
                this.dd === e.dragCurrent && (e.dragCurrent = null, e.dragOvers = {}), this.unghost(!1, !1)
            }
            this.removePassword(), this.removeTextArea(), this.removeTextfield(), this.callParent(arguments)
        },
        genButtonConfig: function(e) {
            return {
                btnStyle: this.getButtonStyle(e),
                text: this.buttonText[e],
                handler: this.handleButton.createDelegate(this, [e]),
                msgWin: this,
                transitionFocus: function() {
                    this.el.hasClass("focus-effect") ? this.el.removeClass("focus-effect") : this.el.addClass("focus-effect")
                },
                onBtnElFocus: function(e) {
                    this.focusTask = this.focusTask || this.addTask({
                        id: "focus_effect",
                        interval: 600,
                        run: this.transitionFocus,
                        scope: this
                    }), this.focusTask.start()
                },
                onBtnElBlur: function(e) {
                    this.focusTask.stop(), this.el.removeClass("focus-effect")
                },
                listeners: {
                    afterrender: function() {
                        this.hidden || (this.nav = new Ext.KeyNav(this.btnEl, {
                            left: this.msgWin.selectBtn.createDelegate(this.msgWin, ["previous"], !0),
                            right: this.msgWin.selectBtn.createDelegate(this.msgWin, ["next"], !0)
                        }), this.mon(this.btnEl, {
                            focus: this.onBtnElFocus,
                            blur: this.onBtnElBlur,
                            scope: this
                        }, this))
                    }
                }
            }
        },
        getButtons: function(e) {
            var t = [],
                i = this;
            return this.fbButtons = {}, this.buttonText.custom = this.buttonText.no, Ext.each(this.leftButtonNames, function(e) {
                t.push(i.fbButtons[e] = new SYNO.ux.Button(i.genButtonConfig(e), this))
            }), t.push("->"), Ext.each(this.buttonNames, function(e) {
                t.push(i.fbButtons[e] = new SYNO.ux.Button(i.genButtonConfig(e), this))
            }), t
        },
        setButtonsCls: function(e) {
            for (var t in this.fbButtons) {
                this.fbButtons[t].addClass(e)
            }
        },
        getButtonStyle: function(e) {
            return "ok" == e || "yes" == e ? "blue" : "grey"
        },
        isModalized: function() {
            return !this.sinkable
        },
        getTopWin: function() {
            return this.sinkable ? this : this.callParent()
        },
        isCustomBtnVisible: function() {
            return !this.fbButtons.custom.hidden
        },
        updateProgress: function(e, t, i, s) {
            return s = s || !1, this.progressStatus.update(t), (i || t) && !0 !== s ? this.updateText(i) : i && this.msgEl.update(i), this.progressBar.updateProgress(e, t), this
        },
        updateButtons: function(e) {
            var t, i, s, n = 0;
            return this.fbButtons.custom.removeClass("syno-mb-custom-btn"), e ? (Ext.iterate(this.fbButtons, function(r, o) {
                t = e[r], t ? (o.show(), this.updateBtnByCfg(r, o, t), !this.extra || this.extra.btnStyle === o.btnStyle || "yes" !== r && "ok" !== r || !o.el || o.el.hasClass(s) || (i = String.format("syno-ux-button-{0}", o.btnStyle), s = String.format("syno-ux-button-{0}", this.extra.btnStyle || "blue"), o.removeClass(i), o.addClass(s)), n += o.container.getWidth()) : o.hide()
            }, this), this.isCustomBtnVisible() && this.fbButtons.custom.addClass("syno-mb-custom-btn"), n) : (Ext.each(this.buttonNames, function(e) {
                this.fbButtons[e].hide()
            }, this), Ext.each(this.leftButtonNames, function(e) {
                this.fbButtons[e].hide()
            }, this), n)
        },
        updateBtnByCfg: function(e, t, i) {
            var s = this.buttonText[e],
                n = "grey";
            t.el && (Ext.isString(i) ? s = i : Ext.isObject(i) && i.text && (s = i.text), t.setText(s), t.removeClass("syno-ux-button-blue"), t.removeClass("syno-ux-button-red"), t.removeClass("syno-ux-button-grey"), Ext.isObject(i) && i.btnStyle ? n = i.btnStyle : "yes" !== e && "ok" !== e || (n = "blue"), t.addClass("syno-ux-button-" + n), Ext.isObject(i) && i.extraStyle && t.addClass(i.extraStyle))
        },
        updateText: function(e) {
            this.opt.width || this.setSize(this.maxWidth, 100), this.msgEl.update(e || this.emptyText);
            var t, i = this.msgEl.getWidth() + this.msgEl.getMargins("lr"),
                s = this.getFrameWidth("lr"),
                n = this.body.getFrameWidth("lr");
            t = Math.max(Math.min(this.opt.width || i + s + n, this.opt.maxWidth || this.maxWidth), Math.max(this.opt.minWidth || this.minWidth, this.buttonWidth || 0)), t += 2 * (this.fbar.getBox().x - this.getBox().x), !0 === this.opt.prompt && this.activeTextField.setWidth(t - s - n), Ext.isIE && t == this.buttonWidth && (t += 4), this.setSize(t, "auto")
        },
        confirmDelete: function(e, t, i, s, n, r) {
            var o = {
                yes: {
                    text: _T("common", "delete"),
                    btnStyle: "red"
                },
                cancel: {
                    text: this.buttonText.cancel
                }
            };
            return this.showMsg(Object.assign({
                title: e,
                msg: t,
                buttons: n || o,
                fn: i,
                icon: "confirm-delete-icon",
                scope: s,
                minWidth: this.minWidth
            }, r)), this
        },
        focus: function() {
            var e = this.focusEl;
            if (this.fbButtons.yes && this.fbButtons.yes.isVisible()) return void this.fbButtons.yes.focus();
            e = e || this.focusEl, e.focus.defer(10, e)
        },
        progress: function(e, t, i, s) {
            return this.showMsg(Object.assign({
                title: e,
                msg: t,
                buttons: !1,
                progress: !0,
                closable: !1,
                minWidth: this.minProgressWidth,
                progressText: i
            }, s)), this
        },
        wait: function(e, t, i, s) {
            return this.showMsg(Object.assign({
                title: t,
                msg: e,
                buttons: !1,
                closable: !1,
                wait: !0,
                minWidth: this.minProgressWidth,
                waitConfig: i
            }, s)), this
        },
        alert: function(e, t, i, s, n) {
            return this.showMsg(Object.assign({
                title: e,
                msg: t,
                buttons: Ext.MessageBox.OK,
                fn: i,
                scope: s,
                minWidth: this.minWidth
            }, n)), this
        },
        showGridMsg: function(e, t, i, s, n, r, o) {
            return this.showMsg(Object.assign({
                title: e,
                msg: t,
                msgArray: i,
                buttons: r || Ext.MessageBox.YESNO,
                fn: s,
                scope: n,
                maxWidth: 380,
                minWidth: this.minWidth
            }, o)), this
        },
        confirm: function(e, t, i, s, n, r) {
            return this.showMsg(Object.assign({
                title: e,
                msg: t,
                buttons: n || Ext.MessageBox.YESNO,
                fn: i,
                scope: s,
                minWidth: this.minWidth
            }, r)), this
        },
        prompt: function(e, t, i, s, n, r, o, a) {
            return this.showMsg(Object.assign({
                title: e,
                msg: t,
                buttons: Ext.MessageBox.OKCANCEL,
                fn: i,
                minWidth: this.minPromptWidth,
                scope: s,
                prompt: !0,
                multiline: n,
                value: r,
                password: o
            }, a)), this
        },
        show: function() {
            this.alignTo(this.owner ? this.owner.el : document.body, "c-c"), this.callParent(arguments)
        },
        getWrapper: function(e) {
            function t(e, t) {
                return function() {
                    return t.apply(e, arguments)
                }
            }
            return this.msgBoxWrapper || (this.msgBoxWrapper = {
                confirmGrid: t(this, this.showGridMsg),
                show: t(this, this.showMsg),
                hide: t(this, this.doClose),
                progress: t(this, this.progress),
                wait: t(this, this.wait),
                alert: t(this, this.alert),
                confirm: t(this, this.confirm),
                confirmDelete: t(this, this.confirmDelete),
                prompt: t(this, this.prompt),
                getDialog: function() {
                    return this
                }.createDelegate(this),
                isVisible: t(this, this.isVisible),
                setIcon: t(this, this.setIconClass),
                updateProgress: t(this, this.updateProgress),
                updateText: t(this, this.updateText)
            }), this.extra = {}, Ext.apply(this.extra, e || {}), this.extra && this.extra.sinkable && Ext.apply(this, {
                sinkable: !!this.extra.sinkable
            }), this.msgBoxWrapper
        }
    }), SYNO.SDS.MessageBoxV5.YESNOCANCEL = {
        custom: !0,
        yes: !0,
        cancel: !0
    }, SYNO.SDS.MessageBox = SYNO.SDS.MessageBoxV5, Ext.namespace("SYNO.SDS"), Ext.namespace("SYNO.SDS.Utils"), SYNO.SDS.emptyFn = function() {}, SYNO.SDS.isFunction = function(e) {
        return "[object Function]" === Object.prototype.toString.apply(e)
    }, SYNO.SDS.isDefined = function(e) {
        return void 0 !== e
    }, SYNO.SDS.GetBody = function() {
        return document.body || document.documentElement
    }, SYNO.SDS.Utils.UserAgent = function() {
        var e = navigator.userAgent.toLowerCase(),
            t = function(t) {
                return t.test(e)
            },
            i = {};
        return i.isEdge = t(/edge/), i.isOpera = t(/opera/), i.isChrome = !i.isEdge && t(/\bchrome\b/), i.isWebKit = !i.isEdge && t(/webkit/), i.isSafari = !(i.isChrome || i.isEdge) && t(/safari/), i.isSafari2 = i.isSafari && t(/applewebkit\/4/), i.isSafari3 = i.isSafari && t(/version\/3/), i.isSafari4 = i.isSafari && t(/version\/4/), i.isSafari5 = i.isSafari && t(/version\/5/), i.isSafari5_0 = i.isSafari && t(/version\/5.0/), i.isGecko = !(i.isWebKit || i.isIE11 || i.isEdge) && t(/gecko/), i.isGecko2 = i.isGecko && t(/rv:1\.8/), i.isGecko3 = i.isGecko && t(/rv:1\.9/), i.isIE = !i.isOpera && t(/msie/), i.isTrident7 = t(/trident\/7/), i.isIE11 = i.isTrident7, i.isIE12 = t(/edge\/(\d+)./), i.isIE10 = i.isIE && (t(/msie 10/) || t(/trident\/6/)), i.isTrident6 = i.isIE && t(/trident\/6/), i.isIE10Touch = i.isTrident6 && t(/touch;/), i.isIE9 = i.isIE && t(/trident\/5/), i.isIE8 = i.isIE && !i.isIE9 && !i.isIE10 && !i.isIE11 && t(/trident/), i.isIE7 = i.isIE && !i.isIE8 && !i.isIE9 && !i.isIE10 && !i.isIE11 && t(/msie 7/), i.isIE6 = i.isIE && !i.isIE7 && !i.isIE8 && !i.isIE9 && !i.isIE10 && !i.isIE11 && t(/msie 6/), i.isModernIE = i.isIE12 || i.isIE11 || i.isIE && !i.isIE6 && !i.isIE7 && !i.isIE8, i.isIE9m = i.isIE && (i.isIE6 || i.isIE7 || i.isIE8 || i.isIE9), i.isBorderBox = i.isIE9m && !i.isStrict, i.isWindows = t(/windows|win32/), i.isMac = t(/macintosh|mac os x/), i.isAir = t(/adobeair/), i.isLinux = t(/linux/), i
    }(), SYNO.SDS.Utils.GetURLParam = function(e, t) {
        var i, s, n = e.split("&"),
            r = decodeURIComponent,
            o = {};
        return n.forEach(function(e) {
            e = e.split("="), i = r(e[0]), s = r(e[1]), o[i] = t || !o[i] ? s : [].concat(o[i]).concat(s)
        }), o
    }, Ext.define("SYNO.SDS.IEUpgradeAlert", {
        extend: "SYNO.SDS.Window",
        constructor: function() {
            var e = {
                cls: "ie-upgrade-alert",
                width: 450,
                height: 230,
                maximizable: !1,
                title: _D("manager"),
                items: [{
                    xtype: "syno_formpanel",
                    name: "ie_alert_form",
                    items: [{
                        xtype: "syno_displayfield",
                        hideLabel: !0,
                        value: _T("desktop", "upgrade_ie_browser")
                    }, {
                        name: "skip_alert",
                        xtype: "syno_checkbox",
                        checked: !1,
                        boxLabel: _T("common", "dont_alert_again")
                    }]
                }],
                fbar: {
                    toolbarCls: "x-panel-fbar x-statusbar",
                    items: [{
                        xtype: "syno_button",
                        text: _T("common", "ok"),
                        btnStyle: "blue",
                        handler: function() {
                            var e = this.find("name", "skip_alert")[0],
                                t = new Date;
                            !0 === e.getValue() && Ext.util.Cookies.set("skip_upgrade_ie_alert", !0, t.add(Date.YEAR, 1)), this.close()
                        },
                        scope: this
                    }]
                }
            };
            this.callParent([e])
        }
    }), SYNO.SDS.HTML5Utils = function() {
        var e = window.XMLHttpRequest ? new XMLHttpRequest : {},
            t = SYNO.SDS.Utils.UserAgent;
        return {
            HTML5Progress: !!e.upload,
            HTML5SendBinary: !(!e.sendAsBinary && !e.upload),
            HTML5ReadBinary: !!(window.FileReader || window.File && window.File.prototype.getAsBinary),
            HTML5Slice: !(!window.File || !(window.File.prototype.slice || window.File.prototype.mozSlice || window.File.prototype.webkitSlice)),
            isSupportHTML5Upload: function() {
                return (t.isChrome || !t.isSafari4 && !t.isSafari5_0 && !(t.isWindows && t.isSafari) && !t.isGecko3 && !t.isOpera) && (!!window.FormData || SYNO.SDS.HTML5Utils.HTML5SendBinary && SYNO.SDS.HTML5Utils.HTML5ReadBinary && SYNO.SDS.HTML5Utils.HTML5Slice)
            },
            isDragFile: function(e) {
                try {
                    if (t.isWebKit) {
                        return e.dataTransfer.types && -1 != e.dataTransfer.types.indexOf("Files")
                    }
                    if (t.isGecko) return e.dataTransfer.types.contains && e.dataTransfer.types.contains("application/x-moz-file") || 0 <= e.dataTransfer.types.indexOf("application/x-moz-file");
                    if (t.isIE10 || t.isModernIE) return e.dataTransfer.files && e.dataTransfer.types && e.dataTransfer.types.contains("Files")
                } catch (e) {
                    SYNO.Debug.log("Error in isDragFile")
                }
                return !1
            }
        }
    }(), SYNO.SDS.UpdateSynoToken = function(e) {
        Ext.Ajax.request({
            url: "webapi/entry.cgi?api=SYNO.API.Auth&version=6&method=token",
            updateSynoToken: !0,
            callback: function(t, i, s) {
                var n = Ext.util.JSON.decode(s.responseText);
                i && n.data && !Ext.isEmpty(n.data.synotoken) && (SYNO.SDS.Session.SynoToken = encodeURIComponent(n.data.synotoken), synowebapi && synowebapi.env.setSynoToken(SYNO.SDS.Session.SynoToken)), Ext.isFunction(e) && e(t, i)
            }
        })
    }, SYNO.SDS.UIFeatures = function() {
        var e, t, i = SYNO.SDS.Utils.UserAgent,
            s = {
                previewBox: !i.isIE || i.isModernIE,
                expandMenuHideAll: !0,
                windowGhost: !i.isIE || i.isModernIE,
                disableWindowShadow: i.isIE && !i.isModernIE,
                exposeWindow: !i.isIE || i.isIE10p,
                msPointerEnabled: window.navigator.msPointerEnabled && window.navigator.msMaxTouchPoints > 0,
                isTouch: "ontouchstart" in window || window.navigator.msPointerEnabled && window.navigator.msMaxTouchPoints > 0,
                isRetina: function() {
                    var e = !1;
                    return window.devicePixelRatio >= 1.5 && (e = !0), window.matchMedia && window.matchMedia("(-webkit-min-device-pixel-ratio: 1.5),(min--moz-device-pixel-ratio: 1.5),(-o-min-device-pixel-ratio: 3/2),(min-resolution: 1.5dppx)").matches && (e = !0), e
                }(),
                isSupportFullScreen: document.fullscreenEnabled || document.webkitFullscreenEnabled || document.mozFullScreenEnabled || document.msFullscreenEnabled
            },
            n = SYNO.SDS.Utils.GetURLParam(location.search.substr(1));
        for (e in n) n.hasOwnProperty(e) && (t = n[e], void 0 !== s[e] && (s[e] = "false" !== t));
        return {
            test: function(e) {
                return !!s[e]
            },
            listAll: function() {
                var e, t = "== Feature List ==\n";
                for (e in s) s.hasOwnProperty(e) && (t += String.format("{0}: {1}\n", e, s[e]));
                return t
            },
            isFullScreenMode: function() {
                return !!(document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement || document.msFullscreenElement)
            }
        }
    }(), SYNO.SDS.UIFeatures.IconSizeManager = {
        PortalIcon: 64,
        GroupView: 24,
        Taskbar: 24,
        WidgetHeader: 32,
        GroupViewHover: 48,
        Desktop: 64,
        ClassicalDesktop: 48,
        AppView: 72,
        AppViewClassic: 48,
        Header: 24,
        HeaderV4: 16,
        TreeIcon: 16,
        StandaloneHeader: 24,
        FavHeader: 16,
        FinderPreview: 128,
        isEnableHDPack: !1,
        cls: "synohdpack",
        debugCls: "synohdpackdebug",
        getAppPortalIconPath: function(e) {
            var t = this.isRetinaMode(),
                i = t ? 256 : this.PortalIcon,
                s = t ? "2x" : "1x";
            return String.format(e, i, s)
        },
        getIconPath: function(e, t, i) {
            var s, n, r = this.isRetinaMode(),
                o = function(e, t, i, s) {
                    return e.replace(t, "48" === t ? "128" : 2 * t)
                },
                a = function(e, t, i, s) {
                    return e.replace(t, "48" === t ? "128" : 2 * t)
                };
            if (0 === e.indexOf("webman/3rdparty/")) {
                r = "FavHeader" !== t && r;
                return String.format("webapi/entry.cgi?api=SYNO.Core.Synohdpack&version=1&method=getHDIcon&res={0}&retina={1}&path={2}", this.getRes(t), r, e)
            }
            switch (-1 === e.indexOf("{1}") ? r ? (i = i || !1, n = i || -1 !== e.indexOf("shortcut_icons") || -1 !== e.indexOf("webfm/images") ? e : 0 === e.indexOf("webman/") ? "/synohdpack/images/dsm/" + e.substr("webman/".length) : "/synohdpack/images/dsm/" + e) : n = e : n = e.replace("{1}", r ? "2x" : "1x"), t) {
                case "Taskbar":
                    s = String.format(n, r ? 2 * this.Taskbar : this.Taskbar);
                    break;
                case "Desktop":
                    -1 != n.indexOf("files_ext_48") && "classical" != SYNO.SDS.UserSettings.getProperty("Desktop", "desktopStyle") && (n = n.replace("files_ext_48", "files_ext_64")), -1 != n.indexOf("files_ext_") ? (n = n.replace(/webfm\/images/, r ? "images/2x" : "images/1x"), s = r ? n.replace(/.*\/files_ext_(\d+)\/.*/, o) : n) : -1 != n.indexOf("shortcut_icons") ? (n = n.replace(/images\/default\/.+\/shortcut_icons/, r ? "images/2x/shortcut_icons" : "images/1x/shortcut_icons"), s = r ? n.replace(/.*\/.*_(\d+)\.png$/, a) : n) : s = String.format(n, r ? 256 : this.Desktop);
                    break;
                case "ClassicalDesktop":
                    -1 != n.indexOf("files_ext_") ? (n = n.replace(/webfm\/images/, r ? "images/2x" : "images/1x"), s = r ? n.replace(/.*\/files_ext_(\d+)\/.*/, o) : n) : -1 != n.indexOf("shortcut_icons") ? (n = n.replace(/images\/default\/.+\/shortcut_icons/, r ? "images/2x/shortcut_icons" : "images/1x/shortcut_icons"), s = r ? n.replace(/.*\/.*_(\d+)\.png$/, a) : n) : s = String.format(n, r ? 256 : this.ClassicalDesktop);
                    break;
                case "AppView":
                    s = String.format(n, r ? 256 : this.AppView);
                    break;
                case "AppViewClassic":
                    s = String.format(n, r ? 256 : this.AppViewClassic);
                    break;
                case "Header":
                    s = String.format(n, r ? 2 * this.Header : this.Header);
                    break;
                case "HeaderV4":
                    s = String.format(n, r ? 2 * this.HeaderV4 : this.HeaderV4);
                    break;
                case "StandaloneHeader":
                    s = String.format(n, r ? 2 * this.StandaloneHeader : this.StandaloneHeader);
                    break;
                case "FavHeader":
                    s = String.format(n, r ? 2 * this.FavHeader : this.FavHeader);
                    break;
                case "FileType":
                    s = r ? n.replace(/.*\/files_ext_(\d+)\/.*/, o) : n;
                    break;
                case "TreeIcon":
                    s = String.format(n, r ? 3 * this.TreeIcon : this.TreeIcon);
                    break;
                case "FinderPreview":
                    s = String.format(n, r ? 256 : 128);
                    break;
                case "WidgetHeader":
                    s = String.format(n, r ? 2 * this.WidgetHeader : this.WidgetHeader);
                    break;
                default:
                    s = n
            }
            return -1 == s.indexOf(String.format("?v={0}", _S("fullversion"))) && ".png" === s.substr(s.length - 4) && (s += "?v=" + _S("fullversion")), s = encodeURI(s)
        },
        enableHDDisplay: function(e) {
            SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = e
        },
        isRetinaMode: function() {
            return SYNO.SDS.UIFeatures.test("isRetina") && this.isEnableHDPack
        },
        getRetinaAndSynohdpackStatus: function() {
            return SYNO.Debug("SYNO.SDS.UIFeatures.IconSizeManager.getRetinaAndSynohdpackStatus() was renamed, please call SYNO.SDS.UIFeatures.IconSizeManager.isRetinaMode() instead."), this.isRetinaMode()
        },
        addHDClsAndCSS: function() {
            var e = !1;
            SYNO.SDS.UIFeatures.test("isRetina") && (document.documentElement.classList.add(this.cls), e = !0), SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = e
        },
        enableRetinaDisplay: function() {
            document.documentElement.classList.remove(this.debugCls), document.documentElement.classList.add(this.cls), SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = !0
        },
        enableRetinaDebugMode: function() {
            document.documentElement.classList.remove(this.cls), document.documentElement.classList.add(this.debugCls), SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = !0
        },
        disableRetinaDisplay: function() {
            document.documentElement.classList.remove(this.cls), document.documentElement.classList.remove(this.debugCls), SYNO.SDS.UIFeatures.IconSizeManager.isEnableHDPack = !1
        },
        getRes: function(e) {
            return this[e] ? this[e] : -1
        }
    }, Ext.namespace("SYNO"), SYNO.Debug = function() {
        function e(e) {
            performance.getEntriesByName(e, "mark").length > 0 && (o.warn("Mark", e, "already exists"), performance.clearMarks(e)), performance.mark(e)
        }

        function t(e) {
            if (!performance.getEntriesByName(e, "mark")[0]) return void o.warn("Mark", e, "not found");
            performance.measure(e, e);
            var t = performance.getEntriesByName(e, "measure")[0];
            o.log("%c" + e, "font-weight: bold;", "\n", "\t ", "start:", t.startTime, "\n", "\t ", "duration:", t.duration, "ms", "\n"), performance.clearMeasures(e), performance.clearMarks(e)
        }
        var i = Ext.urlDecode(location.search.substr(1)).jsDebug,
            s = window.console && window.console.log && !0,
            n = window.console || Ext.emptyFn,
            r = function(e) {
                function t(e) {
                    return !i && -1 === r.indexOf(e) || !s ? Ext.emptyFn : (Ext.isFunction(window.console[e]) ? window.console[e] : Ext.emptyFn).bind(n)
                }
                var r = "error".split(",");
                e = e.split(",");
                var o = {};
                return Ext.each(e, function(e) {
                    o[e] = t(e)
                }), o
            }("debug,trace,log,info,warn,error,group,groupCollapsed,groupEnd,profile,profileEnd,table,time,timeEnd,timeStamp"),
            o = r.log;
        Ext.apply(o, r);
        var a = Ext.urlDecode(location.search.substr(1)).perf;
        return Ext.apply(o, {
            isPerf: a,
            mark: a ? e : Ext.emptyFn,
            measure: a ? t : Ext.emptyFn
        }), o
    }(), SYNO.Assert = function(e, t) {
        if (!e) throw t
    }, Ext.namespace("SYNO.API"), SYNO.API.Proxy = Ext.extend(Ext.util.Observable, {
        constructor: function(e) {
            e = e || {}, Ext.apply(this, e), this.addEvents("exception", "beforeload", "loadexception"), SYNO.API.Proxy.superclass.constructor.call(this);
            var t = Ext.data.Api.actions;
            this.activeRequest = {};
            for (var i in t) t.hasOwnProperty(i) && (this.activeRequest[t[i]] = void 0)
        },
        request: function(e, t, i, s, n, r, o) {
            !1 !== this.fireEvent("beforeload", this, i) ? this.doRequest.apply(this, arguments) : n.call(r || this, null, o, !1)
        },
        doRequest: function(e, t, i, s, n, r, o) {
            if (s) {
                var a = {};
                this.appWindow && (a.appWindow = this.appWindow), !o.timeout && this.timeout && Ext.apply(a, {
                    timeout: this.timeout
                }), this.encryption && Ext.apply(a, {
                    encryption: this.encryption
                }), Ext.isObject(s.meta.compound) && Ext.isArray(s.meta.compound.params) && (a.compound = Ext.apply({}, s.meta.compound), Ext.isObject(i) && Ext.each(a.compound.params, function(e) {
                    e.params = Ext.apply(e.params || {}, i)
                }, this), i = {}), this.activeRequest[e] = SYNO.API.Manager.requestAjaxAPI(this.api, this.method, this.version, a, i, Ext.createDelegate(this.onRequestAPI, this, [s, n, r, o, e], !0)), Ext.isEmpty(this.activeRequest[e]) && this.onRequestAPI(!1, void 0, i, o, s, n, r, o, e)
            }
        },
        onRequestAPI: function(e, t, i, s, n, r, o, a, l) {
            this.activeRequest[l] = void 0;
            var c = null,
                d = null;
            if (e) try {
                c = n.readRecords(t)
            } catch (e) {
                d = e, SYNO.Debug.error("Failed to read data, ", e)
            }!e || d ? (this.fireEvent("loadexception", this, a, t, d), this.fireEvent("exception", this, "response", Ext.data.Api.actions.read, a, t, d)) : this.fireEvent("load", this, t, a), r.call(o || this, c, a, e)
        }
    }), Ext.namespace("SYNO.API"), SYNO.API.Store = Ext.extend(Ext.data.Store, {
        defaultParamNames: {
            start: "offset",
            limit: "limit",
            sort: "sort_by",
            dir: "sort_direction"
        },
        constructor: function(e) {
            e.api && e.method && e.version && !e.proxy && (this.proxy = new SYNO.API.Proxy({
                api: e.api,
                method: e.method,
                version: e.version,
                appWindow: e.appWindow,
                encryption: e.encryption
            })), SYNO.API.Store.superclass.constructor.apply(this, arguments)
        },
        load: function() {
            return !this.isDestroyed && SYNO.API.Store.superclass.load.apply(this, arguments)
        }
    }), SYNO.API.CompoundStore = Ext.extend(SYNO.API.Store, {
        constructor: function(e) {
            Ext.apply(e, {
                api: "SYNO.Entry.Request",
                version: 1,
                method: "request"
            }), SYNO.API.JsonStore.superclass.constructor.call(this, Ext.apply(e, {
                reader: new SYNO.API.CompoundReader(e)
            }))
        }
    }), SYNO.API.JsonStore = Ext.extend(SYNO.API.Store, {
        constructor: function(e) {
            SYNO.API.JsonStore.superclass.constructor.call(this, Ext.apply(e, {
                reader: new Ext.data.JsonReader(e)
            }))
        }
    }), inJsdom() ? window.SYNO = {
        SDS: {}
    } : Ext.namespace("SYNO.SDS.EventEmitter"), SYNO.SDS.EventEmitter = function() {
        function e() {
            _classCallCheck(this, e), this._events = Object.create(null), this._eventsCount = 0
        }
        return _createClass(e, [{
            key: "hasListener",
            value: function(e) {
                return !!this._events[e]
            }
        }, {
            key: "_createListenerFn",
            value: function(e, t, i) {
                if (!i) return e;
                if (i.delay) return function() {
                    var s = arguments;
                    setTimeout(function() {
                        e.apply(t, s)
                    }, i.delay)
                };
                if (i.single) {
                    var s = !1;
                    return function() {
                        s || (e.apply(t, arguments), s = !0)
                    }
                }
                if (i.buffer) {
                    var n;
                    return function() {
                        var s = arguments;
                        clearTimeout(n), n = setTimeout(function() {
                            e.apply(t, s)
                        }, i.buffer)
                    }
                }
                return e
            }
        }, {
            key: "addListener",
            value: function(e, t, i, s) {
                if ("function" != typeof t) throw new TypeError("fn is not a function");
                var n = {
                    fn: this._createListenerFn(t, i, s),
                    scope: i || this,
                    options: s
                };
                return this._events[e] ? this._events[e].push(n) : (this._events[e] = [n], this._eventsCount++), this
            }
        }, {
            key: "getListeners",
            value: function(e) {
                var t = this._events[e];
                return t || []
            }
        }, {
            key: "getListenerCount",
            value: function(e) {
                var t = this._events[e];
                return t ? t.length : 0
            }
        }, {
            key: "emit",
            value: function() {
                var e = Array.prototype.slice.call(arguments, 0),
                    t = e[0],
                    i = !0;
                if (!this._events[t]) return i;
                var s = this._events[t].slice(),
                    n = !0,
                    r = !1,
                    o = void 0;
                try {
                    for (var a, l = s[Symbol.iterator](); !(n = (a = l.next()).done); n = !0) {
                        var c = a.value;
                        !1 === c.fn.apply(c.scope || this, e.slice(1)) && (i = !1), c.options && c.options.single && this.removeListener(t, c.fn)
                    }
                } catch (e) {
                    r = !0, o = e
                } finally {
                    try {
                        n || null == l.return || l.return()
                    } finally {
                        if (r) throw o
                    }
                }
                return i
            }
        }, {
            key: "removeListener",
            value: function(e, t, i) {
                if (!this._events[e]) return this;
                if (t) {
                    var s = this._events[e].filter(function(e) {
                        return e.fn !== t
                    });
                    0 === s.length ? this._clearEvents(e) : this._events[e] = s
                } else this._clearEvents(e);
                return this
            }
        }, {
            key: "removeAllListeners",
            value: function(e) {
                e ? this._events[e] && this._clearEvents(e) : (this._events = Object.create(null), this._eventsCount = 0)
            }
        }, {
            key: "_clearEvents",
            value: function(e) {
                this._eventsCount--, 0 === this._eventsCount ? this._events = Object.create(null) : delete this._events[e]
            }
        }, {
            key: "on",
            get: function() {
                return this.addListener
            }
        }, {
            key: "un",
            get: function() {
                return this.removeListener
            }
        }, {
            key: "fireEvent",
            get: function() {
                return this.emit
            }
        }]), e
    }(), inJsdom() && (module.exports = SYNO.SDS.EventEmitter), Ext.namespace("SYNO.SDS._StatusNotifier"), SYNO.SDS._StatusNotifier = function(e) {
        function t() {
            return _classCallCheck(this, t), _possibleConstructorReturn(this, _getPrototypeOf(t).call(this, arguments))
        }
        return _inherits(t, e), _createClass(t, [{
            key: "isAppValid",
            value: function(e) {
                return !0 === this.isSupportedApp(e) && (!!this.isAppHasPrivilege(e) && (!!this.isServiceEnabled(e) && !SYNO.SDS.Packages.isStop(e)))
            }
        }, {
            key: "isAppLaunchable",
            value: function(e) {
                var t = SYNO.SDS.Config.FnMap[e];
                return !(!t || !Ext.isDefined(t.config)) && !1 !== t.config.launchable
            }
        }, {
            key: "isAppEnabled",
            value: function(e) {
                return !0 === this.isSupportedApp(e) && (!!this.isAppHasPrivilege(e) && (!!this.isServiceEnabled(e) && !(SYNO.SDS.Packages.isPackage(e) && !SYNO.SDS.Packages.isEnable(e))))
            }
        }, {
            key: "isSupportedApp",
            value: function(e) {
                var t, i, s, n = SYNO.SDS.Config.FnMap[e],
                    r = !0;
                return !(!n || !Ext.isDefined(n.config)) && (t = n.config, "app" !== t.type || !Ext.isDefined(t.supportKey) || (i = Ext.isArray(t.supportKey) ? t.supportKey : [t.supportKey], Ext.each(i, function(e) {
                    s = Ext.isDefined(e.value) ? _D(e.key) === e.value : !Ext.isEmpty(_D(e.key)), r = Ext.isDefined(e.cond) && "or" === e.cond ? r || s : r && s
                }, this), r))
            }
        }, {
            key: "isAppHasActionPrivilege",
            value: function(e) {
                if (!_S("is_admin") && SYNO.SDS.ActionPrivilege.AllowList && 0 < SYNO.SDS.ActionPrivilege.AllowList.length) return SYNO.SDS.ActionPrivilege.AllowList.includes(e)
            }
        }, {
            key: "isAppHasPrivilege",
            value: function(e) {
                var t, i = SYNO.SDS.Config.FnMap[e];
                return (!Ext.isDefined(SYNO.SDS.AppPrivilege[e]) || !0 === SYNO.SDS.AppPrivilege[e]) && (!!i && ((!_S("ha_safemode") || -1 != e.search("SYNO.SDS.HA") || -1 != e.search("SYNO.SDS.SupportForm") || -1 != e.search("SYNO.SDS.App.FileStation3") || -1 != e.search("SYNO.Desktop") || -1 != e.search("SYNO.SDS.App.WelcomeApp") || -1 != e.search("SYNO.SDS.UDC")) && (!(!i.config.publicAccess || !this.isPublicAccess()) || (i.config.grantAppPrivilege ? SYNO.SDS.AppPrivilege["SYNO.ALLOW.ALL.APPLICATIONS"] || SYNO.SDS.AppPrivilege[i.config.grantAppPrivilege] : (t = i.config.grantPrivilege, "all" === t || "false" === _S("domainUser") && "local" === t || "true" === _S("domainUser") && "domain" === t ? SYNO.SDS.AppPrivilege["SYNO.ALLOW.ALL.APPLICATIONS"] || SYNO.SDS.AppPrivilege[e] : !!this.isAppHasActionPrivilege(e) || (!0 === _S("is_admin") || !0 === i.config.allUsers) && !("local" === t && "true" === _S("domainUser") || "domain" === t && "false" === _S("domainUser")))))))
            }
        }, {
            key: "isPublicAccess",
            value: function() {
                return !_S("isLogined")
            }
        }, {
            key: "isServiceEnabled",
            value: function(e) {
                return !Ext.isDefined(SYNO.SDS.ServiceStatus[e]) || !0 === SYNO.SDS.ServiceStatus[e]
            }
        }, {
            key: "setServiceDisabled",
            value: function(e, t, i) {
                !t != !!SYNO.SDS.ServiceStatus[e] && (SYNO.SDS.ServiceStatus[e] = !t, this.fireEvent("servicechanged", e, !t, i))
            }
        }, {
            key: "checkServiceBlocked",
            value: function(e) {
                this.fireEvent("checkserviceblocked", e, "checkserviceblocked")
            }
        }, {
            key: "setAppPrivilege",
            value: function(e, t) {
                !!t != !!SYNO.SDS.AppPrivilege[e] && (SYNO.SDS.AppPrivilege[e] = !!t, this.fireEvent("appprivilegechanged", e, !!t))
            }
        }]), t
    }(SYNO.SDS.EventEmitter), Ext.namespace("SYNO.API"), Ext.define("SYNO.API.QueryAPI", {
        singleton: !0,
        IsQuerying: !1,
        QueryAPIInfo: function() {
            var e = this;
            return e.IsQuerying && e.promise ? e.promise : (SYNO.API.Manager || (SYNO.API.Manager = new SYNO.API._Manager), SYNO.API.currentManager || (SYNO.API.currentManager = SYNO.API.Manager, SYNO.API.currentManager.isDeprecated = !0), e.promise = new Promise(function(t, i) {
                var s = function(s) {
                    s ? t() : i(), e.IsQuerying = !1
                };
                e.IsQuerying = !0, SYNO.API.Manager.queryAPI("all", s)
            }), e.promise)
        }
    }), SYNO.API.getErrorString = function(e) {
        var t, i = 100;
        return Ext.isNumber(e) ? i = e : Ext.isObject(e) && (t = SYNO.API.Response.GetFirstError(e), i = Ext.isNumber(t.code) ? t.code : 100), i <= 119 ? SYNO.API.Errors.common[i] : Ext.isString(SYNO.API.Errors.core[i]) ? SYNO.API.Errors.core[i] : _T("common", "error_system")
    }, SYNO.API.CheckSpecialError = function(e, t, i) {
        var s;
        return "SYNO.DSM.Share" === i.api && ("delete" === i.method && 404 === t.code ? s = _T("error", "delete_default_share") : "edit" === i.method && 406 === t.code && (s = _T("error", "share_mounted_rename"))), s
    }, SYNO.API.CheckResponse = function(e, t, i, s) {
        var n, r;
        if (e && t && !0 === t.has_fail && "array" === Ext.type(t.result)) return t.result.forEach(function(e) {
            Ext.isDefined(e.success) && !1 === e.success && Ext.isDefined(e.error) && "object" === Ext.type(e.error) && (105 === e.error.code || 107 === e.error.code ? SYNO.SDS.Utils.Logout.action(!0, SYNO.API.Errors.common[e.error.code], !0, !0) : 106 === e.error.code && SYNO.SDS.Utils.Logout.action(!0, SYNO.API.Errors.common[e.error.code], !0, !1, !0, n))
        }), !0;
        if (e) return !0;
        if (Ext.isEmpty(t) || 0 === t.status) return !1;
        try {
            n = Ext.isDefined(t.status) ? 0 : t.code || 100, r = n < SYNO.API.Errors.minCustomeError ? SYNO.API.Errors.common[n] : SYNO.API.CheckSpecialError(e, t, i) || SYNO.API.Errors.core[n]
        } catch (e) {} finally {
            r || (n = 100, r = SYNO.API.Errors.common[n])
        }
        return s && Ext.isFunction(s.getResponseHeader) && !Ext.isEmpty(s.getResponseHeader("X-SYNO-SOURCE-ID")) || (105 === n || 107 === n ? SYNO.SDS.Utils.Logout.action(!0, r, !0, !0) : 106 === n && SYNO.SDS.Utils.Logout.action(!0, r, !0, !1)), r
    }, SYNO.API.CheckRelayResponse = function(e, t, i, s, n) {
        var r, o = !1,
            a = Ext.getClassByName("SYNO.SDS.AppWindow");
        if (Ext.isEmpty(t) || Ext.isObject(n) && 0 === n.status) return o;
        if (!SYNO.SDS.Utils.CMS.IsAllowRelay(s.appWindow) || Ext.isEmpty(a)) return o;
        if (!((r = s.appWindow.findAppWindow()) instanceof a) || Ext.isEmpty(r.appInstance)) return o;
        if (!Ext.isObject(s.params)) return o;
        if ("SYNO.API.Info" === s.params.api) o = !0;
        else if ('"SYNO.CMS.DS"' !== s.params.api || '"relay"' !== s.params.method) return o;
        return !0 === o || (Ext.isObject(n) && Ext.isEmpty(n.getResponseHeader("X-SYNO-SOURCE-ID")) ? !Ext.isNumber(t.code) || 414 !== t.code && 406 !== t.code && 401 !== t.code && 423 !== t.code ? Ext.isObject(n) && n.status >= 400 && n.status < 600 && (o = !0) : o = !0 : Ext.isObject(s.userInfo.params) && Ext.isArray(s.userInfo.params.compound) ? Ext.each(t.result, function(e) {
            if (Ext.isObject(e.error) && e.error.code >= 105 && e.error.code <= 107) return o = !0, !1
        }, this) : Ext.isNumber(t.code) ? t.code >= 105 && t.code <= 107 && (o = !0) : Ext.isObject(n) && n.status >= 400 && n.status < 600 && (o = !0)), !0 === o && r.getMsgBox().alert(_T("error", "error_error"), _T("cms", "relaunch_app"), function() {
            r.close()
        }), o
    }, SYNO.API._Manager = Ext.extend(Ext.util.Observable, {
        isDeprecated: !1,
        baseURL: "webapi",
        constructor: function() {
            SYNO.API._Manager.superclass.constructor.apply(this, arguments), this.jsDebug = Ext.urlDecode(location.search.substr(1)).jsDebug, this.knownAPI = {
                "SYNO.API.Info": {
                    path: "query.cgi",
                    minVersion: 1,
                    maxVersion: 1
                }
            }
        },
        queryAPI: function(e, t, i, s) {
            var n = [];
            Ext.isArray(e) || (e = [e]), Ext.each(e, function(e) {
                this.knownAPI.hasOwnProperty(e) || n.push(e)
            }, this), this.requestAjaxAPI("SYNO.API.Info", "query", 1, {
                async: !Ext.isBoolean(s) || s
            }, {
                query: n.join(",")
            }, Ext.createDelegate(this.onQueryAPI, this, [t, i], !0))
        },
        onQueryAPI: function(e, t, i, s, n, r) {
            e && (Ext.isObject(i) && "all" === i.query ? this.knownAPI = Ext.apply({}, t) : Ext.apply(this.knownAPI, t)), n && n.call(r, e, t, i, s)
        },
        getKnownAPI: function(e, t) {
            var i, s, n = this.knownAPI[e];
            return Ext.isDefined(this.jsDebug) && Ext.isObject(n) ? (i = n.path + "/", "SYNO.Entry.Request" === e && Ext.isObject(t) && Ext.isArray(t.compound) ? (s = [], Ext.each(t.compound, function(e) {
                Ext.isString(e.api) && s.push(e.api)
            }), i += s.join()) : i += e, Ext.apply({}, {
                path: i
            }, n)) : n
        },
        getBaseURL: function(e, t, i, s, n) {
            var r, o, a, l;
            if (Ext.isObject(e))
                if (o = e, s = t, n = i, o.webapi && (o = o.webapi), Ext.isObject(o.compound)) {
                    if (!Ext.isArray(o.compound.params)) return void SYNO.Debug.error("params must be array", o.compound.params);
                    e = "SYNO.Entry.Request", t = "request", i = 1;
                    for (var c = o.compound.params || [], d = [], h = 0; h < c.length; h++) d.push(Ext.apply({
                        api: c[h].api,
                        method: c[h].method,
                        version: c[h].version
                    }, c[h].params));
                    a = {
                        stop_when_error: !!Ext.isBoolean(o.compound.stopwhenerror) && o.compound.stopwhenerror,
                        mode: Ext.isString(o.compound.mode) ? o.compound.mode : "sequential",
                        compound: d
                    }
                } else e = o.api, t = o.method, i = o.version, a = o.params;
            return (r = this.getKnownAPI(e, a)) ? (l = this.baseURL + "/" + r.path, Ext.isString(n) && !Ext.isEmpty(n) && (l += "/" + window.encodeURIComponent(n)), t && i ? (o = {
                api: e,
                method: t,
                version: i
            }, a && Ext.apply(o, "JSON" === r.requestFormat ? SYNO.API.EncodeParams(a) : a), Ext.urlAppend(l, Ext.urlEncode(o), s)) : l) : (SYNO.Debug.error("No Such API: " + e), void SYNO.API.QueryAPI.QueryAPIInfo())
        },
        requestAjaxAPI: function(e, t, i, s, n, r, o) {
            var a, l, c, d, h, u, p = arguments.length > 7 && void 0 !== arguments[7] ? arguments[7] : "POST",
                _ = SYNO.Util.copy(n),
                f = null;
            if (Ext.isObject(e) && (l = e, l.webapi && (l = l.webapi), s = {}, Ext.apply(s, l), delete s.api, delete s.method, delete s.version, delete s.scope, delete s.callback, delete s.httpMethod, r = l.callback || e.callback, o = l.scope || e.scope, s.appWindow = e.appWindow, l.httpMethod && (p = l.httpMethod), Ext.isObject(l.compound) ? d = l.compound : (e = l.api, t = l.method, i = l.version, _ = l.params)), s && s.compound && (d = s.compound), d) {
                if (!Ext.isArray(d.params)) return void SYNO.Debug.error("params must be array", d.params);
                e = "SYNO.Entry.Request", t = "request", i = 1;
                for (var m = d.params || [], S = [], g = 0; g < m.length; g++) S.push(Ext.apply({
                    api: m[g].api,
                    method: m[g].method,
                    version: m[g].version
                }, m[g].params));
                _ = {
                    stop_when_error: !!Ext.isBoolean(d.stopwhenerror) && d.stopwhenerror,
                    mode: Ext.isString(d.mode) ? d.mode : "sequential",
                    compound: S
                }
            }
            if (!(a = Ext.isObject(s.appWindow) && "SYNO.API.Info" !== e ? SYNO.API.Info.GetKnownAPI(s.appWindow, e, _) : this.getKnownAPI(e, _))) return u = Ext.isObject(s.appWindow) && s.appWindow.IsAllowRelay(), SYNO.Debug.error("No Such API: " + e), h = {
                error: {
                    code: 102
                }
            }, SYNO.API.QueryAPI.QueryAPIInfo(), u && SYNO.API.CheckRelayResponse(!1, h, _, s), void(Ext.isFunction(r) && r.call(o || window, !1, h, _, s));
            if ((i < a.minVersion || a.maxVersion < i) && SYNO.Debug.warn(String.format("WARN: API({0}) version ({1}) is higher then server ({2})", e, i, a.version)), !Ext.isObject(_) && !Ext.isEmpty(_)) return void SYNO.Debug.error("params must be object, ", _);
            !Ext.isSecure && Ext.isArray(s.encryption) && (f = Ext.apply([], s.encryption)), delete s.encryption;
            var x, v = {
                    api: e,
                    method: t,
                    version: i
                },
                y = this.baseURL + "/" + a.path;
            if (s && s.url) {
                var w = s.url;
                x = Ext.urlDecode(w.substr(w.indexOf("?") + 1)), x && x.api && x.method && x.version && (delete x.api, delete x.method, delete x.version, delete x.SynoToken, v = x, y = s.url)
            }
            return s && Ext.isElement(s.form) && /multipart\/form-data/i.test(s.form.enctype) ? (y = SYNO.API.GetBaseURL(v), v = {}) : Ext.isObject(s) && !0 === s.html5upload && (y = SYNO.API.GetBaseURL(Ext.apply({
                params: _
            }, v)), v = {}), s.method = p, c = Ext.apply(s || {}, {
                url: y,
                params: Ext.apply({}, v, "JSON" === a.requestFormat ? SYNO.API.EncodeParams(_) : _),
                callback: this.onRequestAPI.bind(this),
                userInfo: {
                    params: _,
                    cb: r,
                    scope: o
                }
            }), Ext.isEmpty(f) ? this.sendRequest(c) : this.requestAjaxAPI("SYNO.API.Encryption", "getinfo", 1, {
                appWindow: c.appWindow || void 0,
                reqObj: c,
                reqEnc: f
            }, {
                format: "module"
            }, this.onEncryptRequestAPI, this)
        },
        onEncryptRequestAPI: function(e, t, i, s) {
            var n, r, o, a = s.reqObj,
                l = s.reqEnc,
                c = function(e) {
                    for (var t in e)
                        if (e.hasOwnProperty(t)) return !1;
                    return !0
                };
            if (!e) return Ext.Ajax.request(a);
            if (SYNO.Encryption.CipherKey = t.cipherkey, SYNO.Encryption.RSAModulus = t.public_key, SYNO.Encryption.CipherToken = t.ciphertoken, SYNO.Encryption.TimeBias = t.server_time - Math.floor(+new Date / 1e3), Ext.isEmpty(a.params.compound)) {
                for (n = SYNO.Encryption.EncryptParam(Ext.copyTo({}, a.params, l)), r = 0; r < l.length; r++) delete a.params[l[r]];
                return a.params = Ext.apply(a.params, n), this.sendRequest(a)
            }
            var d = Ext.apply({}, a.userInfo.params),
                h = this,
                u = 5;
            (Ext.isIE6 || Ext.isIE7 || Ext.isIE8) && (u = 1), r = 0;
            ! function e() {
                for (; r < d.compound.length; r++) {
                    var t = Ext.apply({}, d.compound[r], d.compound[r].params),
                        i = {};
                    for (n = {}, i = SYNO.API.EncodeParams(Ext.copyTo({}, t, l)), c(i) || (n = SYNO.Encryption.EncryptParam(i)), o = 0; o < l.length; o++) delete t[l[o]];
                    if (d.compound[r] = Ext.apply(t, n), r + 1 === d.compound.length) return Ext.apply(a.params, SYNO.API.EncodeParams(d)), void h.sendRequest(a);
                    if (r % u == 0) return r++, void window.setTimeout(e, 80)
                }
            }()
        },
        sendRequest: function(e) {
            var t, i, s, n = e.appWindow,
                r = this.getKnownAPI("SYNO.CMS.DS");
            if (Ext.isObject(n) && n.findAppWindow && (n = n.findAppWindow()), !Ext.isEmpty(r) && SYNO.SDS.Utils.CMS.IsAllowRelay(n) && n.hasOpenConfig("cms_id") && (i = n.getOpenConfig("cms_timeout") || 120, s = {
                    api: "SYNO.CMS.DS",
                    version: 1,
                    method: "relay",
                    id: n.getOpenConfig("cms_id"),
                    timeout: i
                }, Ext.isElement(e.form) && /multipart\/form-data/i.test(e.form.enctype) ? (t = Ext.urlDecode(e.url.substr(e.url.indexOf("?") + 1)), s.webapi = Ext.encode(Ext.copyTo({}, t, "api,version,method")), t.SynoToken && (s.SynoToken = t.SynoToken), e.url = this.baseURL + "/" + r.path + "?" + Ext.urlEncode(s)) : (e.url = this.baseURL + "/" + r.path, s.webapi = Ext.apply({
                    api: e.params.api,
                    version: e.params.version,
                    method: e.params.method
                }, e.userInfo.params), e.params = SYNO.API.EncodeParams(s)), e.timeout = e.timeout || 1e3 * (i + 10)), SYNO.Debug.isPerf) {
                e.headers || (e.headers = {}), e.headers["Cusotm-Perf-Id"] = Date.now();
                var o = this.generatePerfName(e);
                SYNO.Debug.mark(o)
            }
            return Ext.Ajax.request(e)
        },
        requestAPI: function(e, t, i, s, n, r) {
            return this.requestAjaxAPI(e, t, i, {}, s, n, r)
        },
        onRequestAPI: function(e, t, i) {
            var s, n = !1,
                r = i;
            if (t) {
                try {
                    s = Ext.decode(i.responseText)
                } catch (e) {}
                if (!1 === SYNO.SDS.HandShake.CheckAPIResponse(e, i)) return;
                Ext.isObject(s) && (s.success ? (n = !0, r = s.data) : (n = !1, r = s.error))
            }
            if (SYNO.API.CheckResponse(n, r, e.userInfo.params, i), (!SYNO.SDS.Utils.CMS.IsAllowRelay(e.appWindow) || !SYNO.API.CheckRelayResponse(n, r, void 0, e, i)) && (e.userInfo.cb && e.userInfo.cb.call(e.userInfo.scope, n, r, e.userInfo.params, e), SYNO.Debug.isPerf)) {
                var o = this.generatePerfName(e);
                SYNO.Debug.measure(o)
            }
        },
        generatePerfName: function(e) {
            return (e.compound && e.compound.params || [e.params]).map(function(e) {
                return "[API] " + e.api + " :" + e.method
            }).join("\n") + " - " + e.headers["Cusotm-Perf-Id"]
        }
    }), SYNO.API.EscapeStr = function(e) {
        return e ? e.replace(/[\\]/g, "\\\\").replace(/[,]/g, "\\,") : ""
    }, SYNO.API.Request = function(e) {
        return SYNO.API.Manager.requestAjaxAPI(e)
    }, SYNO.API.RequestPromise = function(e) {
        return new Promise(function(t, i) {
            e.callback = function(e, s, n, r) {
                e ? t(s) : i(s)
            }, SYNO.API.Request(e)
        }.bind(this))
    }, SYNO.API.GetKnownAPI = function(e, t) {
        return SYNO.API.Manager.getKnownAPI(e, t)
    }, Ext.namespace("SYNO.API"), SYNO.API.GetErrors = function() {
        var e = {};
        return e.minCustomeError = 400, e.common = {
            0: _T("common", "commfail"),
            100: _T("common", "error_system"),
            101: "Bad Request",
            102: "No Such API",
            103: "No Such Method",
            104: "Not Supported Version",
            105: _T("error", "error_privilege_not_enough"),
            106: _JSLIBSTR("uicommon", "error_timeout"),
            107: _T("login", "error_interrupt"),
            108: _T("user", "user_file_upload_fail"),
            109: _T("error", "error_error_system"),
            110: _T("error", "error_error_system"),
            111: _T("error", "error_error_system"),
            112: "Stop Handling Compound Request",
            113: "Invalid Compound Request",
            114: _T("error", "error_invalid"),
            115: _T("error", "error_invalid"),
            116: _JSLIBSTR("uicommon", "error_demo"),
            117: _T("error", "error_error_system"),
            118: _T("error", "error_error_system"),
            119: _JSLIBSTR("uicommon", "error_timeout"),
            122: _T("error", "error_privilege_not_enough"),
            123: _T("error", "error_privilege_not_enough"),
            124: _T("error", "error_privilege_not_enough"),
            125: _JSLIBSTR("uicommon", "error_timeout"),
            126: _T("error", "error_privilege_not_enough"),
            127: _T("error", "error_privilege_not_enough"),
            160: _T("error", "error_privilege_not_enough"),
            164: String.format(_T("error", "error_load_system_settings"), '<a href="https://www.synology.com/company/contact_us" target="_blank">', "</a>"),
            165: String.format(_T("error", "error_set_system_settings"), '<a href="https://www.synology.com/company/contact_us" target="_blank">', "</a>")
        }, e.core = {
            402: _T("share", "no_such_share"),
            403: _T("error", "error_invalid"),
            404: _T("error", "error_privilege_not_enough"),
            1101: _T("error", "error_subject"),
            1102: _T("firewall", "firewall_restore_failed"),
            1103: _T("firewall", "firewall_block_admin_client"),
            1104: _T("firewall", "firewall_rule_exceed_max_number"),
            1105: _T("firewall", "firewall_rule_disable_fail"),
            1198: _T("common", "version_not_support"),
            1201: _T("error", "error_subject"),
            1202: _T("firewall", "firewall_tc_ceil_exceed_system_upper_bound"),
            1203: _T("firewall", "firewall_tc_max_ceil_too_large"),
            1204: _T("firewall", "firewall_tc_restore_failed"),
            1301: _T("error", "error_subject"),
            1302: _T("firewall", "firewall_dos_restore_failed"),
            1402: _T("service", "service_ddns_domain_load_error"),
            1410: _T("service", "service_ddns_operation_fail"),
            1500: _T("common", "error_system"),
            1501: _T("common", "error_apply_occupied"),
            1502: _T("routerconf", "routerconf_external_ip_warning"),
            1503: _T("routerconf", "routerconf_require_gateway"),
            1504: _T("routerconf", "dns_setting_no_response"),
            1510: _T("routerconf", "routerconf_update_db_failed"),
            1521: _T("routerconf", "routerconf_exceed_singel_max_port"),
            1522: _T("routerconf", "routerconf_exceed_combo_max_port"),
            1523: _T("routerconf", "routerconf_exceed_singel_range_max_port"),
            1524: _T("routerconf", "routerconf_exceed_max_rule"),
            1525: _T("routerconf", "routerconf_port_conflict"),
            1526: _T("routerconf", "routerconf_add_port_failed"),
            1527: _T("routerconf", "routerconf_apply_failed"),
            1528: _T("routerconf", "protocol_on_router_not_enabled"),
            1530: _T("routerconf", "routerconf_syntax_version_error"),
            1600: _T("ups", "operation_failed"),
            1601: _T("ups", "set_info_failed"),
            1602: _T("ups", "get_info_failed"),
            1701: _T("error", "error_port_conflict"),
            1702: _T("error", "error_file_exist"),
            1703: _T("error", "error_no_path"),
            1704: _T("error", "error_error_system"),
            1706: _T("error", "error_volume_ro"),
            1903: _T("error", "error_port_conflict"),
            1904: _T("error", "error_port_conflict"),
            1905: _T("ftp", "ftp_annoymous_root_share_invalid"),
            1951: _T("error", "error_port_conflict"),
            2001: _T("error", "error_error_system"),
            2002: _T("error", "error_error_system"),
            2101: _T("error", "error_error_system"),
            2102: _T("error", "error_error_system"),
            2201: _T("error", "error_error_system"),
            2202: _T("error", "error_error_system"),
            2301: _T("error", "error_invalid"),
            2303: _T("error", "error_port_conflict"),
            2331: _T("nfs", "nfs_key_wrong_format"),
            2332: _T("user", "user_file_upload_fail"),
            2371: _T("error", "error_mount_point_nfs"),
            2372: _T("error", "error_hfs_plus_mount_point_nfs"),
            2401: _T("error", "error_error_system"),
            2402: _T("error", "error_error_system"),
            2403: _T("error", "error_port_conflict"),
            2500: _T("error", "error_unknown_desc"),
            2502: _T("error", "error_invalid"),
            2503: _T("error", "error_error_system"),
            2504: _T("error", "error_error_system"),
            2505: _T("error", "error_error_system"),
            2601: _T("network", "domain_name_err"),
            2602: _T("network", "domain_dns_name_err"),
            2603: _T("network", "domain_kdc_ip_error"),
            2604: _T("network", "error_badgname"),
            2605: _T("network", "domain_unreachserver_err"),
            2606: _T("network", "domain_port_unreachable_err"),
            2607: _T("network", "domain_password_err"),
            2608: _T("network", "domain_acc_revoked_ads"),
            2609: _T("network", "domain_acc_revoked_rpc"),
            2610: _T("network", "domain_acc_err"),
            2611: _T("network", "domain_notadminuser"),
            2612: _T("network", "domain_change_passwd"),
            2613: _T("network", "domain_check_kdcip"),
            2614: _T("network", "domain_error_misc_rpc"),
            2615: _T("network", "domain_join_err"),
            2616: _T("directory_service", "warr_enable_samba"),
            2626: _T("directory_service", "warr_db_not_ready"),
            2628: _T("directory_service", "warr_synoad_exists"),
            2702: _T("network", "status_connected"),
            2703: _T("network", "status_disconnected"),
            2704: _T("common", "error_occupied"),
            2705: _T("common", "error_system"),
            2706: _T("ldap_error", "ldap_invalid_credentials"),
            2707: _T("ldap_error", "ldap_operations_error"),
            2708: _T("ldap_error", "ldap_server_not_support"),
            2709: _T("domain", "domain_ldap_conflict"),
            2710: _T("ldap_error", "ldap_operations_error"),
            2712: _T("ldap_error", "ldap_no_such_object"),
            2713: _T("ldap_error", "ldap_protocol_error"),
            2714: _T("ldap_error", "ldap_invalid_dn_syntax"),
            2715: _T("ldap_error", "ldap_insufficient_access"),
            2716: _T("ldap_error", "ldap_insufficient_access"),
            2717: _T("ldap_error", "ldap_timelimit_exceeded"),
            2718: _T("ldap_error", "ldap_inappropriate_auth"),
            2719: _T("ldap_error", "ldap_smb2_enable_warning"),
            2721: _T("ldap_error", "ldap_confidentiality_required"),
            2723: _T("ldap_error", "ldap_weak_pwd"),
            2799: _T("common", "error_system"),
            2800: _T("error", "error_unknown_desc"),
            2801: _T("error", "error_unknown_desc"),
            2900: _T("error", "error_unknown_desc"),
            2901: _T("error", "error_unknown_desc"),
            2902: _T("relayservice", "relayservice_err_network"),
            2903: _T("relayservice", "error_alias_server_internal"),
            2904: _T("relayservice", "relayservice_err_alias_in_use"),
            2905: _T("pkgmgr", "myds_error_account"),
            2906: _T("relayservice", "error_alias_used_in_your_own"),
            3e3: _T("error", "error_unknown_desc"),
            3001: _T("error", "error_unknown_desc"),
            3002: _T("relayservice", "relayservice_err_resolv"),
            3003: _T("relayservice", "myds_server_internal_error"),
            3004: _T("error", "error_auth"),
            3005: _T("relayservice", "relayservice_err_alias_in_use"),
            3006: _T("relayservice", "myds_exceed_max_register_error"),
            3009: _T("error", "error_unknown_desc"),
            3010: _T("myds", "already_logged_in"),
            3013: _T("myds", "error_migrate_authen"),
            3015: _T("myds", "invalid_machine"),
            3106: _T("user", "no_such_user"),
            3107: _T("user", "error_nameused"),
            3108: _T("user", "error_nameused"),
            3109: _T("user", "error_disable_admin"),
            3110: _T("user", "error_too_much_user"),
            3111: _T("user", "homes_not_found"),
            3112: _T("common", "error_apply_occupied"),
            3113: _T("common", "error_occupied"),
            3114: _T("user", "error_nameused"),
            3115: _T("user", "user_cntrmvdefuser"),
            3116: _T("user", "user_set_fail"),
            3117: _T("user", "user_quota_set_fail"),
            3118: _T("common", "error_no_enough_space"),
            3119: _T("user", "error_home_is_moving"),
            3121: _T("common", "err_pass"),
            3122: _T("login", "password_in_history"),
            3123: _T("login", "password_too_common"),
            3124: _T("common", "err_pass"),
            3130: _T("user", "invalid_syntax_enclosed_trailing"),
            3131: _T("user", "invalid_syntax_double_quote_in_middle"),
            3132: _T("user", "invalid_syntax_not_double_quote_ending"),
            3191: _T("user", "user_file_open_fail"),
            3192: _T("user", "user_file_empty"),
            3193: _T("user", "user_file_not_utf8"),
            3194: _T("user", "user_upload_no_volume"),
            3202: _T("common", "error_occupied"),
            3204: _T("group", "failed_load_group"),
            3205: _T("group", "failed_load_group"),
            3206: _T("group", "error_nameused"),
            3207: _T("group", "error_nameused"),
            3208: _T("group", "error_badname"),
            3209: _T("group", "error_toomanygr"),
            3210: _T("group", "error_rmmember"),
            3217: _T("group", "error_too_many_dir_admin"),
            3221: _T("share", "error_too_many_acl_rules") + "(" + _T("acl_editor", "acl_rules_reach_limit_report").replace(/.*\//, "").trim().replace("_maxCount_", "200") + ")",
            3299: _T("common", "error_system"),
            3301: _T("share", "share_already_exist"),
            3302: _T("share", "share_acl_volume_not_support"),
            3303: _T("share", "error_encrypt_reserve"),
            3304: _T("share", "error_volume_not_found"),
            3305: _T("share", "error_badname"),
            3308: _T("share", "encryption_wrong_key"),
            3309: _T("share", "error_toomanysh"),
            3312: _T("share", "share_normal_folder_exist"),
            3313: _T("share", "error_volume_not_found"),
            3314: _T("share", "error_volume_read_only"),
            3319: _T("share", "error_nameused"),
            3320: _T("share", "share_space_not_enough"),
            3321: _T("share", "error_too_many_acl_rules") + "(" + _T("acl_editor", "acl_rules_reach_limit_report").replace(/.*\//, "").trim().replace("_maxCount_", "200") + ")",
            3322: _T("share", "mount_point_not_empty"),
            3323: _T("error", "error_mount_point_change_vol"),
            3324: _T("error", "error_mount_point_rename"),
            3326: _T("share", "error_key_file"),
            3327: _T("share", "share_conflict_on_new_volume"),
            3328: _T("share", "get_lock_failed"),
            3329: _T("share", "error_toomanysnapshot"),
            3330: _T("share", "share_snapshot_busy"),
            3332: _T("backup", "is_backing_up_restoring"),
            3334: _T("share", "error_mount_point_restore"),
            3335: _T("share", "share_cannot_move_fstype_not_support"),
            3336: _T("share", "share_cannot_move_replica_busy"),
            3337: _T("snapmgr", "snap_system_preserved"),
            3338: _T("share", "error_mounted_encrypt_restore"),
            3340: _T("snapmgr", "snap_restore_share_conf_err"),
            3341: _T("snapmgr", "err_quota_is_not_enough"),
            3344: _T("keymanager", "error_invalid_passphrase"),
            3345: _T("keymanager", "error_used_keystore"),
            3400: _T("error", "error_error_system"),
            3401: _T("error", "error_error_system"),
            3402: _T("error", "error_error_system"),
            3403: _T("app_privilege", "error_no_such_user_or_group"),
            3404: _T("error", "error_privilege_not_enough"),
            3405: _T("app_privilege", "error_wrong_data_format"),
            3500: _T("error", "error_invalid"),
            3501: _T("common", "error_badport"),
            3502: _T("error", "error_port_conflict"),
            3503: _T("error", "error_port_conflict"),
            3504: _T("error", "error_port_conflict"),
            3505: _T("app_port_alias", "err_fqdn_duplicated"),
            3510: _T("error", "error_invalid"),
            3511: _T("app_port_alias", "err_port_dup"),
            3550: _T("volume", "volume_no_volumes"),
            3551: _T("error", "error_no_shared_folder"),
            3552: String.format(_T("volume", "volume_crashed_service_disable"), _T("common", "web_station")),
            3553: _T("volume", "volume_expanding_waiting"),
            3554: _T("error", "error_port_conflict"),
            3555: _T("common", "error_badport"),
            3603: _T("volume", "volume_share_volumeno"),
            3604: _T("error", "error_space_not_enough"),
            3605: _T("usb", "usb_printer_driver_fail"),
            3606: _T("login", "error_cantlogin"),
            3607: _T("common", "error_badip"),
            3608: _T("usb", "net_prntr_ip_exist_error"),
            3609: _T("usb", "net_prntr_ip_exist_unknown"),
            3610: _T("common", "error_demo"),
            3611: _T("usb", "net_prntr_name_exist_error"),
            3700: _T("error", "error_invalid"),
            3701: _T("status", "status_not_available"),
            3702: _T("error", "error_invalid"),
            3710: _T("status", "status_not_available"),
            3711: _T("error", "error_invalid"),
            3712: _T("cms", "fan_mode_not_supported"),
            3720: _T("status", "status_not_available"),
            3721: _T("error", "error_invalid"),
            3730: _T("status", "status_not_available"),
            3731: _T("error", "error_invalid"),
            3740: _T("status", "status_not_available"),
            3741: _T("error", "error_invalid"),
            3750: _T("status", "status_not_available"),
            3751: _T("error", "error_invalid"),
            3760: _T("status", "status_not_available"),
            3761: _T("error", "error_invalid"),
            3795: _T("error", "error_port_conflict"),
            3800: _T("error", "error_invalid"),
            3801: _T("error", "error_invalid"),
            4e3: _T("error", "error_invalid"),
            4001: _T("error", "error_error_system"),
            4002: _T("dsmoption", "error_format"),
            4003: _T("dsmoption", "error_size"),
            4100: _T("error", "error_invalid"),
            4101: _T("error", "error_invalid"),
            4102: _T("app_port_alias", "err_alias_refused"),
            4103: _T("app_port_alias", "err_alias_used"),
            4104: _T("app_port_alias", "err_port_used"),
            4105: _T("app_port_alias", "err_port_used"),
            4106: _T("app_port_alias", "err_port_used"),
            4107: _T("app_port_alias", "err_fqdn_duplicated"),
            4154: _T("app_port_alias", "err_fqdn_duplicated"),
            4155: _T("app_port_alias", "err_port_used"),
            4156: _T("app_port_alias", "err_invalid_backend_host"),
            4164: _T("app_port_alias", "err_invalid_header_name"),
            4165: _T("app_port_alias", "err_invalid_header_value"),
            4166: _T("app_port_alias", "err_header_name_duplicated"),
            4168: _T("app_port_alias", "err_proxy_timeout"),
            4169: _T("app_port_alias", "err_proxy_timeout"),
            4170: _T("app_port_alias", "err_proxy_timeout"),
            4300: _T("error", "error_error_system"),
            4301: _T("error", "error_error_system"),
            4302: _T("error", "error_error_system"),
            4303: _T("error", "error_invalid"),
            4304: _T("error", "error_error_system"),
            4305: _T("error", "error_error_system"),
            4306: _T("error", "error_error_system"),
            4307: _T("error", "error_error_system"),
            4308: _T("error", "error_error_system"),
            4309: _T("error", "error_invalid"),
            4310: _T("error", "error_error_system"),
            4311: _T("network", "interface_not_found"),
            4312: _T("tcpip", "tcpip_ip_used"),
            4313: _T("tcpip", "ipv6_ip_used"),
            4314: _T("tunnel", "tunnel_conn_fail"),
            4315: _T("tcpip", "ipv6_err_link_local"),
            4316: _T("network", "error_applying_network_setting"),
            4317: _T("common", "error_notmatch"),
            4319: _T("error", "error_error_system"),
            4320: _T("vpnc", "name_conflict"),
            4321: _T("service", "service_illegel_crt"),
            4322: _T("service", "service_illegel_key"),
            4323: _T("service", "service_ca_not_utf8"),
            4324: _T("service", "service_unknown_cipher"),
            4325: _T("vpnc", "l2tp_conflict"),
            4326: _T("vpnc", "vpns_conflict"),
            4327: _T("vpnc", "ovpnfile_invalid_format"),
            4340: _T("background_task", "task_processing"),
            4350: _T("tcpip", "ipv6_invalid_config"),
            4351: _T("tcpip", "ipv6_router_bad_lan_req"),
            4352: _T("tcpip", "ipv6_router_err_enable"),
            4353: _T("tcpip", "ipv6_router_err_disable"),
            4354: _T("tcpip", "ipv6_no_public_ip"),
            4370: _T("ovs", "ovs_not_support_bonding"),
            4371: _T("ovs", "ovs_not_support_vlan"),
            4372: _T("ovs", "ovs_not_support_bridge"),
            4373: _T("network", "linkaggr_mode_inconsistent_err"),
            4380: _T("router_networktools", "ping_target_invalid"),
            4381: _T("router_networktools", "ping_timeout"),
            4382: _T("router_networktools", "traceroute_target_invalid"),
            4500: _T("error", "error_error_system"),
            4501: _T("error", "error_error_system"),
            4502: _T("pkgmgr", "pkgmgr_space_not_ready"),
            4503: _T("error", "volume_creating"),
            4504: _T("pkgmgr", "error_sys_no_space"),
            4506: _T("pkgmgr", "noncancellable"),
            4520: _T("error", "error_space_not_enough"),
            4521: _T("pkgmgr", "pkgmgr_file_not_package"),
            4522: _T("pkgmgr", "broken_package"),
            4529: _T("pkgmgr", "pkgmgr_pkg_cannot_upgrade"),
            4530: _T("pkgmgr", "error_occupied"),
            4531: _T("pkgmgr", "pkgmgr_not_syno_publish"),
            4532: _T("pkgmgr", "pkgmgr_unknown_publisher"),
            4533: _T("pkgmgr", "pkgmgr_cert_expired"),
            4534: _T("pkgmgr", "pkgmgr_cert_revoked"),
            4535: _T("pkgmgr", "broken_package"),
            4540: _T("pkgmgr", "pkgmgr_file_install_failed"),
            4541: _T("pkgmgr", "upgrade_fail"),
            4542: _T("error", "error_error_system"),
            4543: _T("pkgmgr", "pkgmgr_file_not_package"),
            4544: _T("pkgmgr", "pkgmgr_pkg_install_already"),
            4545: _T("pkgmgr", "pkgmgr_pkg_not_available"),
            4548: _T("pkgmgr", "install_version_less_than_limit"),
            4549: _T("pkgmgr", "depend_cycle"),
            4570: _T("common", "error_invalid_serial"),
            4580: _T("pkgmgr", "pkgmgr_pkg_start_failed"),
            4581: _T("pkgmgr", "pkgmgr_pkg_stop_failed"),
            4590: _T("pkgmgr", "invalid_feed"),
            4591: _T("pkgmgr", "duplicate_feed"),
            4592: _T("pkgmgr", "duplicate_certificate"),
            4593: _T("pkgmgr", "duplicate_certificate_sys"),
            4594: _T("pkgmgr", "revoke_certificate"),
            4595: _T("service", "service_illegel_crt"),
            4600: _T("error", "error_error_system"),
            4601: _T("error", "error_error_system"),
            4602: _T("notification", "google_auth_failed"),
            4631: _T("error", "error_error_system"),
            4632: _T("error", "error_error_system"),
            4633: _T("error", "sms_provider_not_found"),
            4634: _T("error", "sms_provider_exist"),
            4635: _T("error", "error_error_system"),
            4661: _T("pushservice", "error_update_ds_info"),
            4681: _T("error", "error_error_system"),
            4682: _T("error", "error_error_system"),
            4683: _T("error", "webhook_provider_not_found"),
            4684: _T("error", "webhook_provider_exist"),
            4685: _T("error", "error_error_system"),
            4800: _T("schedule", "error_unknown"),
            4801: _T("schedule", "error_load_failed"),
            4802: _T("schedule", "error_delete_failed"),
            4803: _T("schedule", "error_run_failed"),
            4804: _T("schedule", "error_save_failed"),
            4900: _T("error", "error_invalid"),
            4901: _T("error", "error_error_system"),
            4902: _T("user", "no_such_user"),
            4903: _T("report", "err_dest_share_not_exist"),
            4904: _T("error", "error_file_exist"),
            4905: _T("error", "error_space_not_enough"),
            5e3: _T("error", "error_invalid"),
            5001: _T("error", "error_invalid"),
            5002: _T("error", "error_invalid"),
            5003: _T("error", "error_invalid"),
            5004: _T("error", "error_invalid"),
            5005: _T("syslog", "err_server_disconnected"),
            5006: _T("syslog", "service_ca_copy_failed"),
            5007: _T("syslog", "service_ca_copy_failed"),
            5008: _T("error", "error_invalid"),
            5009: _T("error", "error_port_conflict"),
            5010: _T("error", "error_invalid"),
            5011: _T("error", "error_invalid"),
            5012: _T("syslog", "err_name_conflict"),
            5016: String.format(_T("error", "error_load_system_settings"), '<a href="https://www.synology.com/company/contact_us" target="_blank">', "</a>"),
            5017: String.format(_T("error", "error_load_system_settings"), '<a href="https://www.synology.com/company/contact_us" target="_blank">', "</a>"),
            5018: String.format(_T("error", "error_unexpected_load_settings"), '<a href="https://www.synology.com/company/contact_us" target="_blank">', "</a>"),
            5019: String.format(_T("error", "error_load_system_settings"), '<a href="https://www.synology.com/company/contact_us" target="_blank">', "</a>"),
            5020: String.format(_T("error", "error_set_system_settings"), '<a href="https://www.synology.com/company/contact_us" target="_blank">', "</a>"),
            5021: String.format(_T("error", "error_load_system_settings"), '<a href="https://www.synology.com/company/contact_us" target="_blank">', "</a>"),
            5100: _T("error", "error_invalid"),
            5101: _T("error", "error_invalid"),
            5102: _T("error", "error_invalid"),
            5103: _T("error", "error_invalid"),
            5104: _T("error", "error_invalid"),
            5105: _T("error", "error_invalid"),
            5106: _T("error", "error_invalid"),
            5202: _T("update", "error_apply_lock"),
            5203: _T("volume", "volume_busy_waiting"),
            5205: _T("update", "error_bad_dsm_version"),
            5206: _T("update", "update_notice"),
            5207: _T("update", "error_model"),
            5208: _T("update", "error_apply_lock"),
            5209: _T("update", "error_patch"),
            5211: _T("update", "upload_err_no_space"),
            5213: _T("pkgmgr", "error_occupied"),
            5214: _T("update", "check_new_dsm_err"),
            5215: _T("error", "error_space_not_enough"),
            5216: _T("error", "error_fs_ro"),
            5217: _T("error", "error_dest_no_path"),
            5219: _T("update", "autoupdate_cancel_failed_running"),
            5220: _T("update", "autoupdate_cancel_failed_no_task"),
            5221: _T("update", "autoupdate_cancel_failed"),
            5222: _T("update", "error_verify_patch"),
            5223: _T("update", "error_updater_prehook_failed"),
            5224: _T("update", "error_hybrid_ha_patch_version_inconsistent"),
            5225: _T("update", "error_hybrid_ha_passive_bad_model"),
            5300: _T("error", "error_invalid"),
            5301: _T("user", "no_such_user"),
            5510: _T("service", "service_illegel_crt"),
            5511: _T("service", "service_illegel_key"),
            5512: _T("service", "service_illegal_inter_crt"),
            5513: _T("service", "service_unknown_cypher"),
            5514: _T("service", "service_key_not_match"),
            5515: _T("service", "service_ca_copy_failed"),
            5516: _T("service", "service_ca_not_utf8"),
            5517: _T("certificate", "inter_and_crt_verify_error"),
            5518: _T("certificate", "not_support_dsa"),
            5519: _T("service", "service_illegal_csr"),
            5520: _T("backup", "general_backup_destination_no_response"),
            5521: _T("certificate", "err_connection"),
            5522: _T("certificate", "err_server_not_match"),
            5523: _T("certificate", "err_too_many_reg"),
            5524: _T("certificate", "err_too_many_req"),
            5525: _T("certificate", "err_mail"),
            5526: _T("s2s", "err_invalid_param_value"),
            5527: _T("certificate", "err_le_server_busy"),
            5528: _T("certificate", "err_not_synoddns"),
            5529: _T("certificate", "err_invalid_domain"),
            5530: _T("certificate", "err_challenge_unauthorized"),
            5600: _T("error", "error_no_path"),
            5601: _T("file", "error_bad_file_content"),
            5602: _T("error", "error_error_system"),
            5603: _T("texteditor", "LoadFileFail"),
            5604: _T("texteditor", "SaveFileFail"),
            5605: _T("error", "error_privilege_not_enough"),
            5606: _T("texteditor", "CodepageConvertFail"),
            5607: _T("texteditor", "AskForceSave"),
            5608: _T("error", "error_encryption_long_path"),
            5609: _T("error", "error_long_path"),
            5610: _T("error", "error_quota_not_enough"),
            5611: _T("error", "error_space_not_enough"),
            5612: _T("error", "error_io"),
            5613: _T("error", "error_privilege_not_enough"),
            5614: _T("error", "error_fs_ro"),
            5615: _T("error", "error_file_exist"),
            5616: _T("error", "error_no_path"),
            5617: _T("error", "error_dest_no_path"),
            5618: _T("error", "error_testjoin"),
            5619: _T("error", "error_reserved_name"),
            5620: _T("error", "error_fat_reserved_name"),
            5621: _T("texteditor", "exceed_load_max"),
            5703: _T("time", "ntp_service_disable_warning"),
            5800: _T("error", "error_invalid"),
            5801: _T("share", "no_such_share"),
            5901: _T("error", "error_subject"),
            5902: _T("firewall", "firewall_vpnpassthrough_restore_failed"),
            5903: _T("firewall", "firewall_vpnpassthrough_specific_platform"),
            6e3: _T("error", "error_error_system"),
            6001: _T("error", "error_error_system"),
            6002: _T("error", "error_error_system"),
            6003: _T("error", "error_error_system"),
            6004: _T("common", "loadsetting_fail"),
            6005: _T("error", "error_subject"),
            6006: _T("error", "error_service_start_failed"),
            6007: _T("error", "error_service_stop_failed"),
            6008: _T("error", "error_service_start_failed"),
            6009: _T("firewall", "firewall_save_failed"),
            6010: _T("common", "error_badip"),
            6011: _T("common", "error_badip"),
            6012: _T("common", "error_badip"),
            6013: _T("share", "no_such_share"),
            6014: _T("cms", "cms_no_volumes"),
            6015: _T("ftp", "tftp_no_privilege_restart_service"),
            6016: _T("ftp", "tftp_invalid_root_folder"),
            6200: _T("error", "error_error_system"),
            6201: _T("error", "error_acl_volume_not_support"),
            6202: _T("error", "error_fat_privilege"),
            6203: _T("error", "error_remote_privilege"),
            6204: _T("error", "error_fs_ro"),
            6205: _T("error", "error_privilege_not_enough"),
            6206: _T("error", "error_no_path"),
            6207: _T("error", "error_no_path"),
            6208: _T("error", "error_testjoin"),
            6209: _T("error", "error_privilege_not_enough"),
            6210: _T("acl_editor", "admin_cannot_set_acl_perm"),
            6211: _T("acl_editor", "error_invalid_user_or_group"),
            6212: _T("error", "error_acl_mp_not_support"),
            6213: _T("acl_editor", "quota_exceeded"),
            6215: _T("acl_editor", "acl_rules_reach_limit"),
            6216: _T("acl_editor", "error_xattr_exceeded"),
            6703: _T("error", "error_port_conflict"),
            6704: _T("error", "error_port_conflict"),
            6705: _T("user", "no_such_user"),
            6706: _T("user", "error_nameused"),
            6708: _T("share", "error_volume_not_found"),
            6709: _T("netbackup", "err_create_service_share"),
            7100: _T("connections", "error_disable_admin_name"),
            8e3: _T("router_wireless", "wifi_daemon_not_ready"),
            8001: _T("network", "net_daemon_not_ready"),
            8002: _T("network", "usbmodem_daemon_not_ready"),
            8003: _T("wireless_ap", "ap_ssid_limit_alert"),
            8010: _T("router_topology", "get_topology_fail"),
            8011: _T("network", "net_get_fail"),
            8012: _T("network", "net_get_setting_fail"),
            8013: _T("router_wireless", "wifi_setting_get_fail"),
            8020: _T("router_topology", "set_topology_fail"),
            8021: _T("network", "net_set_fail"),
            8022: _T("network", "net_set_setting_fail"),
            8023: _T("router_wireless", "wifi_setting_set_fail"),
            8030: _T("network", "get_redirect_info_fail"),
            8031: _T("router_common", "dhcp_range_conflict_err"),
            8100: _T("router_wireless", "guest_network_get_count_down_fail"),
            8101: _T("router_wireless", "guest_network_set_count_down_fail"),
            8130: _T("pppoe", "pppoe_get_setting_fail"),
            8131: _T("pppoe", "pppoe_set_setting_fail"),
            8132: _T("pppoe", "pppoe_no_interface_available"),
            8133: _T("pppoe", "pppoe_service_start_fail"),
            8134: _T("pppoe", "pppoe_service_stop_fail"),
            8135: _T("pppoe", "pppoe_connection_failed"),
            8136: _T("pppoe", "pppoe_disconnect_fail"),
            8150: _T("wireless_ap", "country_code_get_fail"),
            8151: _T("wireless_ap", "country_code_set_fail"),
            8152: _T("wireless_ap", "country_code_read_list_fail"),
            8153: _T("wireless_ap", "country_code_region_not_support"),
            8170: _T("routerconf", "routerconf_exceed_max_rule"),
            8175: _T("smartwan", "sw_too_many_rules"),
            8180: _T("routerconf", "routerconf_exceed_max_rule"),
            8190: _T("router_parental", "err_device_reach_max"),
            8200: _T("router_parental", "err_domain_name_reach_max"),
            8230: _T("routerconf", "routerconf_exceed_max_reservation"),
            8231: _T("routerconf", "routerconf_exceed_max_reservation_v6"),
            9060: _T("disk_info", "disk_upload_db_error_verify"),
            9061: _T("error", "error_space_not_enough"),
            9062: _T("disk_info", "disk_upload_db_error_version_too_old"),
            9063: _T("disk_info", "disk_upload_db_error_model_not_match")
        }, e
    }, SYNO.API.AssignErrorStr = function() {
        SYNO.API.Errors = SYNO.API.GetErrors()
    }, SYNO.API.AssignErrorStr(), SYNO.API.Erros = function() {
        if (Ext.isIE8) return SYNO.API.Errors;
        var e = {};
        for (var t in SYNO.API.Errors) SYNO.API.Errors.hasOwnProperty(t) && function(t) {
            Object.defineProperty(e, t, {
                get: function() {
                    return SYNO.Debug.warn("SYNO.API.Erros is deprecated (typo), please use SYNO.API.Errors instead."), SYNO.API.Errors[t]
                },
                configurable: !1
            })
        }(t);
        return e
    }(), Ext.define("SYNO.API.InfoObject", {
        extend: "Ext.util.Observable",
        local: "info_local",
        constructor: function() {
            this.callParent(arguments), this._session = {}, this._define = {}, this._knownAPI = {}
        },
        check: function(e) {
            var t;
            if (!Ext.isObject(e)) throw "Error! appwindow is incorrect!";
            if (Ext.isFunction(e.findAppWindow) && (t = e.findAppWindow(), Ext.isObject(t) && Ext.isObject(t.openConfig) && Ext.isFunction(t.hasOpenConfig) && Ext.isFunction(t.getOpenConfig) && Ext.isFunction(t.setOpenConfig))) return t
        },
        getInstName: function(e) {
            var t = this.local,
                i = this.check(e);
            return Ext.isObject(i) && SYNO.SDS.Utils.CMS.IsAllowRelay(i) && i.hasOpenConfig("cms_id") && (t = "cms_ds_" + i.getOpenConfig("cms_id")), t
        },
        getInstNameById: function(e) {
            var t = this.local;
            return Ext.isNumber(e) && 0 <= e && (t = "cms_ds_" + e), t
        },
        checkInst: function(e, t, i, s, n) {
            return e !== this.local && (Ext.isObject(s) && Ext.isObject(i) ? (this.handleResponse(t, i, s, n), !1) : !(e in this._define && e in this._session && !0 !== i) || (this.handleResponse({
                cms_id: 0
            }, void 0, void 0, n), !1))
        },
        updateInstById: function(e, t, i) {
            var s, n, r;
            Ext.isObject(e) && (n = e, e = n.cms_id, s = this.getInstNameById(n.cms_id), r = Ext.copyTo({}, n, "callback,args,scope")), !1 !== this.checkInst(s, {
                cms_id: e
            }, t, i, r) && (SYNO.API.Request({
                api: "SYNO.CMS.DS",
                version: 1,
                method: "relay",
                timeout: 3e4,
                params: {
                    id: e,
                    timeout: 30,
                    webapi: {
                        api: "SYNO.API.Info",
                        version: 1,
                        method: "query"
                    }
                },
                appOpt: r,
                cms_id: e,
                callback: function(e, t, i, n) {
                    this._knownAPI[s] = !0 !== e ? void 0 : t
                },
                scope: this
            }), SYNO.API.Request({
                api: "SYNO.CMS.DS",
                version: 1,
                method: "relay",
                timeout: 3e4,
                params: {
                    id: e,
                    timeout: 30,
                    webapi: {
                        api: "SYNO.Entry.Request",
                        version: 1,
                        method: "request",
                        compound: [{
                            api: "SYNO.Core.System",
                            version: 1,
                            method: "info",
                            type: "define"
                        }, {
                            api: "SYNO.Core.System",
                            version: 1,
                            method: "info",
                            type: "session"
                        }]
                    }
                },
                appOpt: r,
                cms_id: e,
                callback: this.onUpdateInst,
                scope: this
            }))
        },
        updateInst: function(e, t, i) {
            var s = this.check(e),
                n = this.getInstName(e);
            !1 !== this.checkInst(n, {
                appWindow: e
            }, t, i) && (s.sendWebAPI({
                api: "SYNO.API.Info",
                version: 1,
                method: "query",
                callback: function(e, t, i, s) {
                    this._knownAPI[n] = !0 !== e ? void 0 : t
                },
                scope: this
            }), this._knownAPI.hasOwnProperty(n) && Ext.isEmpty(this._knownAPI[n]) || s.sendWebAPI({
                compound: {
                    stopwhenerror: !1,
                    params: [{
                        api: "SYNO.Core.System",
                        version: 1,
                        method: "info",
                        params: {
                            type: "define"
                        }
                    }, {
                        api: "SYNO.Core.System",
                        version: 1,
                        method: "info",
                        params: {
                            type: "session"
                        }
                    }]
                },
                callback: this.onUpdateInst,
                scope: this
            }))
        },
        checkUpdateResponse: function(e, t, i, s) {
            var n;
            return n = Ext.isNumber(s.cms_id) ? this.getInstNameById(s.cms_id) : this.getInstName(s.appWindow), e ? n !== this.local && (2 !== t.result.length ? (SYNO.Debug.error("Incorrect response:" + Ext.encode(t.result)), !1) : !1 !== t.result[0].success && !1 !== t.result[1].success || (delete this._session[n], delete this._define[n], !1)) : (SYNO.Debug.error("Update session and define fail"), !1)
        },
        onUpdateInst: function(e, t, i, s) {
            this.checkUpdateResponse(e, t, i, s) ? this.handleResponse(s, t.result[0].data, t.result[1].data, s.appOpt) : this.handleResponse({
                cms_id: 0
            }, void 0, void 0, s.appOpt)
        },
        handleResponse: function(e, t, i, s) {
            var n;
            n = Ext.isNumber(e.cms_id) ? this.getInstNameById(e.cms_id) : this.getInstName(e.appWindow), n !== this.local && (this._define[n] = Ext.apply({}, t), this._session[n] = Ext.apply({}, i)), Ext.isObject(s) && Ext.isFunction(s.callback) && (n in this._knownAPI ? s.callback.apply(s.scope || this, s.args) : s.callback.defer(1e3, s.scope || this, s.args))
        },
        removeById: function(e) {
            var t = this.getInstNameById(e);
            t !== this.local && (delete this._define[t], delete this._session[t], delete this._knownAPI[t])
        },
        getDefine: function(e, t, i) {
            var s = this.getInstName(e);
            return s === this.local ? _D(t, i) : Ext.isEmpty(this._session[s]) ? (this.updateInst(e), void SYNO.Debug.error("Please update first")) : t in this._define[s] ? this._define[s][t] : Ext.isString(i) ? i : ""
        },
        getSession: function(e, t) {
            var i = this.getInstName(e);
            if (i === this.local) return _S(t);
            switch (t) {
                case "lang":
                case "isMobile":
                case "demo_mode":
                case "SynoToken":
                    return _S(t);
                default:
                    return Ext.isEmpty(this._session[i]) ? (this.updateInst(e), void SYNO.Debug.error("[Info]Please update first")) : this._session[i][t]
            }
        },
        getKnownAPI: function(e, t, i) {
            var s = this.getInstName(e);
            return s === this.local ? SYNO.API.GetKnownAPI(t, i) : Ext.isEmpty(this._knownAPI[s]) || Ext.isEmpty(this._knownAPI[s][t]) ? (this.updateInst(e), void SYNO.Debug.warn("[Info]Please update first")) : this._knownAPI[s][t]
        }
    }), SYNO.API._InfoInstance = null, SYNO.API._Info = function() {
        function e() {
            return _classCallCheck(this, e), Ext.isEmpty(SYNO.API._InfoInstance) && (SYNO.API._InfoInstance = new SYNO.API.InfoObject), this
        }
        return _createClass(e, [{
            key: "GetSession",
            value: function(e, t) {
                return SYNO.API._InfoInstance.getSession(e, t)
            }
        }, {
            key: "GetDefine",
            value: function(e, t, i) {
                return SYNO.API._InfoInstance.getDefine(e, t, i)
            }
        }, {
            key: "GetKnownAPI",
            value: function(e, t, i) {
                return SYNO.API._InfoInstance.getKnownAPI(e, t, i)
            }
        }, {
            key: "Update",
            value: function(e, t, i) {
                return SYNO.API.Info.Instance.updateInst(e, t, i)
            }
        }, {
            key: "UpdateById",
            value: function(e) {
                return SYNO.API._InfoInstance.updateInstById(e)
            }
        }, {
            key: "RemoveById",
            value: function(e) {
                return SYNO.API._InfoInstance.removeById(e)
            }
        }, {
            key: "Instance",
            get: function() {
                return SYNO.API._InfoInstance
            }
        }]), e
    }(), SYNO.API.Info = new SYNO.API._Info, Ext.namespace("SYNO.API"), SYNO.API.EncodeFlatParams = function(e) {
        var t = {};
        if (!e) return t;
        var i = function e(t, i, s) {
            for (var n in t)
                if (t.hasOwnProperty(n)) {
                    var r = t[n],
                        o = i ? i + "|" + n : n;
                    Ext.isFunction(r) || (Ext.isObject(r) ? e(t[n], o, s) : s[o] = r)
                }
        };
        if (!Ext.isArray(e)) return i(e, void 0, t), t;
        for (var s = 0; s < (void 0).length; s++)(void 0)[s].api && (void 0)[s].method ? i((void 0)[s], (void 0)[s].api + "|" + (void 0)[s].method, t) : i(e, void 0, t);
        return t
    }, SYNO.API.DecodeFlatParams = function(e) {
        var t = {};
        for (var i in e) Ext.isObject(e[i]) ? t[i] = e[i] : function e(t, i, s) {
            var n, r = t.indexOf("|");
            0 < r ? (n = t.substring(0, r), Ext.isObject(s[n]) || (s[n] = {}), e(t.substring(r + 1), i, s[n])) : s[t] = i
        }(i, e[i], t);
        return t
    }, SYNO.API.EncodeParams = function(e) {
        var t = {};
        for (var i in e) e.hasOwnProperty(i) && (t[i] = Ext.encode(e[i]));
        return t
    }, SYNO.API.DecodeParams = function(e) {
        var t = {};
        for (var i in e)
            if (e.hasOwnProperty(i)) try {
                t[i] = Ext.decode(e[i])
            } catch (s) {
                t[i] = SYNO.Util.copy(e[i])
            }
        return t
    }, Ext.namespace("SYNO.SDS.TaskRunner"), SYNO.SDS._TaskMgr = function(e) {
        var t = e || 10,
            i = [],
            s = [],
            n = 0,
            r = !1,
            o = !1,
            a = function(e, t) {
                for (var i; 0 !== t;) i = e % t, e = t, t = i;
                return e
            },
            l = function() {
                var t, s, n = i[0].interval;
                for (t = 1; s = i[t]; t++) n = a(n, s.interval);
                return Math.max(n, e)
            },
            c = function() {
                var e = l();
                return e !== t && (t = e, !0)
            },
            d = function() {
                r = !1, clearTimeout(n), n = 0
            },
            h = function() {
                r || (r = !0, c(), setImmediate(_))
            },
            u = function(e) {
                s.push(e), e.onStop && e.onStop.apply(e.scope || e)
            },
            p = function(e) {
                e.processing = !0, Promise.resolve(e.run.apply(e.scope || e, e.args || [++e.taskRunCount])).then(function(t) {
                    !1 === t && u(e), e.processing = !1
                })
            },
            _ = function e() {
                var r, a, l, h, _ = !1,
                    f = (new Date).getTime();
                for (r = 0; a = s[r]; r++) i.remove(a), _ = !0;
                if (s = [], !i.length) return void d();
                for (r = 0; a = i[r]; ++r)
                    if (a = i[r], !o || !0 === a.preventHalt) {
                        if (h = f - a.taskRunTime, a.interval <= h) {
                            if (!1 === a.processing) try {
                                p(a)
                            } catch (e) {
                                if (!Ext.isIE && (SYNO.Debug.error("TaskRunner: task " + a.id + " exception: ", e), Ext.isDefined(SYNO.SDS.JSDebug))) throw a.taskRunTime = f, e
                            }
                            if (a.taskRunTime = f, l = a.interval, a.interval = a.adaptiveInterval(), l !== a.interval && (_ = !0), a.taskRunCount === a.repeat) return void u(a)
                        }
                        a.duration && a.duration <= f - a.taskStartTime && u(a)
                    } _ && c(), n = setTimeout(e, t)
            };
        this.start = function(e, t) {
            var s = (new Date).getTime();
            return i.push(e), e.taskStartTime = s, e.taskRunTime = !1 === t ? s : 0, e.taskRunCount = 0, r ? (c(), clearTimeout(n), setImmediate(_)) : h(), e
        }, this.stop = function(e) {
            return u(e), e
        }, this.stopAll = function() {
            var e, t;
            for (d(), e = 0; t = i[e]; e++) t.onStop && t.onStop();
            i = [], s = []
        }, this.setHalt = function(e) {
            o = e
        }
    },
    SYNO.SDS.TaskMgr = new SYNO.SDS._TaskMgr(100), SYNO.SDS.TaskRunner = Ext.extend(Ext.util.Observable, {
        tasks: null,
        constructor: function() {
            SYNO.SDS.TaskRunner.superclass.constructor.apply(this, arguments), this.addEvents("add", "remove", "beforestart"), this.tasks = {}
        },
        destroy: function() {
            this.stopAll(), this.tasks = {}, this.isDestroyed = !0
        },
        start: function(e, t) {
            if (!this.isDestroyed) return e.running || (this.fireEvent("beforestart", e), SYNO.SDS.TaskMgr.start(e, t)), e.running = !0, e
        },
        stop: function(e) {
            return e.running && SYNO.SDS.TaskMgr.stop(e), e.running = !1, e
        },
        stopAll: function() {
            for (var e in this.tasks)
                if (this.tasks.hasOwnProperty(e)) {
                    if (!this.tasks[e].running) continue;
                    SYNO.SDS.TaskMgr.stop(this.tasks[e])
                }
        },
        addTask: function(e) {
            return e.id = e.id || Ext.id(), this.tasks[e.id] = e, this.fireEvent("add", e), e
        },
        createTask: function(e) {
            e.id = e.id || Ext.id();
            var t = this.tasks[e.id];
            return t ? t.apply(e) : (t = new SYNO.SDS.TaskRunner.Task(e, this), this.addTask(t)), t
        },
        createAjaxTask: function(e) {
            e.id = e.id || Ext.id();
            var t = this.tasks[e.id];
            return t ? t.apply(e) : (t = new SYNO.SDS.TaskRunner.AjaxTask(e, this), this.addTask(t)), t
        },
        createWebAPITask: function(e) {
            e.id = e.id || Ext.id();
            var t = this.tasks[e.id];
            return t ? t.apply(e) : (t = new SYNO.SDS.TaskRunner.WebAPITask(e, this), this.addTask(t)), t
        },
        removeTask: function(e) {
            var t = this.tasks[e];
            t && (this.fireEvent("remove", t), delete this.tasks[e])
        },
        getTask: function(e) {
            return this.tasks[e] || null
        }
    });
var LOW_LEVEL_RUNNER_INTERVAL_PENALTY = 2;
SYNO.SDS.TaskRunner.Task = Ext.extend(Ext.util.Observable, {
    INTERVAL_DEFAULT: 6e4,
    INTERVAL_FALLBACK: 6e4,
    manager: null,
    running: !1,
    processing: !1,
    removed: !1,
    taskFirstRunTime: 0,
    constructor: function(e, t) {
        SYNO.SDS.TaskRunner.Task.superclass.constructor.apply(this, arguments), this.manager = t, this.apply(e)
    },
    apply: function(e) {
        this.applyInterval(e.interval), delete e.interval, this.applyConfig(e)
    },
    applyConfig: function(e) {
        Ext.apply(this, e)
    },
    applyInterval: function(e) {
        this.intervalData = e, Ext.isFunction(this.intervalData) || Ext.isArray(this.intervalData) || Ext.isNumber(this.intervalData) || (this.intervalData = this.INTERVAL_DEFAULT), this.interval = this.adaptiveInterval()
    },
    adaptiveInterval: function() {
        var e, t = 0,
            i = this.intervalData,
            s = null;
        if (this.taskFirstRunTime && (t = (new Date).getTime() - this.taskFirstRunTime), Ext.isNumber(i)) s = i;
        else if (Ext.isFunction(i)) s = i.call(this.scope || this, t);
        else if (Ext.isArray(i))
            for (e = 0; e < i.length && !(i[e].time > t); ++e) s = i[e].interval;
        return Ext.isNumber(s) || (SYNO.Debug.debug("TaskRunner: Task " + this.id + " interval fallback to " + this.INTERVAL_FALLBACK), s = this.INTERVAL_FALLBACK), SYNO.SDS.Utils.isLowLevelModel() && (s *= LOW_LEVEL_RUNNER_INTERVAL_PENALTY), s
    },
    start: function(e) {
        var t = (new Date).getTime();
        if (!this.removed) return this.taskFirstRunTime || (this.taskFirstRunTime = !1 === e ? t + this.interval : t), this.manager.start(this, e)
    },
    stop: function() {
        if (!this.removed) return this.manager.stop(this)
    },
    restart: function(e) {
        this.stop(), this.start(e)
    },
    remove: function() {
        this.stop(), this.manager.removeTask(this.id), this.removed = !0
    }
}), SYNO.SDS.TaskRunner.AjaxTask = Ext.extend(SYNO.SDS.TaskRunner.Task, {
    constructor: function(e, t) {
        this.reqId = null, this.reqConfig = null, this.cbHandler = null, this.autoJsonDecode = !1, this.single = !1, SYNO.SDS.TaskRunner.AjaxTask.superclass.constructor.call(this, e, t)
    },
    applyConfig: function(e) {
        Ext.apply(this, {
            run: this.run,
            scope: this
        }), this.autoJsonDecode = !0 === e.autoJsonDecode, this.single = !0 === e.single, this.preventHalt = !0 === e.preventHalt, this.cbHandler = {}, this.reqConfig = {}, Ext.copyTo(this.cbHandler, e, ["scope", "callback", "success", "failure"]), Ext.apply(this.reqConfig, e), Ext.apply(this.reqConfig, {
            success: null,
            failure: null,
            callback: this.onCallback,
            scope: this
        }), Ext.applyIf(this.reqConfig, {
            method: "GET"
        }), delete this.reqConfig.id, delete this.reqConfig.autoJsonDecode, delete this.reqConfig.single
    },
    stop: function() {
        this.reqId && (Ext.Ajax.abort(this.reqId), this.reqId = null), SYNO.SDS.TaskRunner.AjaxTask.superclass.stop.apply(this, arguments)
    },
    run: function() {
        if (!this.reqConfig.url) return void this.remove();
        SYNO.SDS.TaskRunner.AjaxTask.superclass.stop.call(this), this.reqId = Ext.Ajax.request(this.reqConfig)
    },
    onCallback: function(e, t, i) {
        var s = i,
            n = Ext.apply({}, e);
        if (Ext.apply(n, {
                scope: this.cbHandler.scope,
                callback: this.cbHandler.callback,
                success: this.cbHandler.success,
                failure: this.cbHandler.failure
            }), t && this.autoJsonDecode) try {
            s = Ext.util.JSON.decode(i.responseText)
        } catch (e) {
            s = {
                success: !1
            }, t = !1
        }
        t && n.success ? n.success.call(n.scope, s, e) : !t && n.failure && n.failure.call(n.scope, s, e), n.callback && n.callback.call(n.scope, e, t, s), this.fireEvent("callback", e, t, s), t && this.single ? (this.reqId = null, this.remove()) : this.reqId && (this.reqId = null, this.start(!1))
    }
}), SYNO.SDS.TaskRunner.WebAPITask = Ext.extend(SYNO.SDS.TaskRunner.AjaxTask, {
    constructor: function(e, t) {
        SYNO.SDS.TaskRunner.WebAPITask.superclass.constructor.call(this, e, t)
    },
    applyConfig: function(e) {
        Ext.apply(this, {
            run: this.run,
            scope: this
        }), this.single = !0 === e.single, this.preventHalt = !0 === e.preventHalt, this.cbHandler = {}, this.reqConfig = {}, Ext.copyTo(this.cbHandler, e, ["callback", "scope"]), Ext.apply(this.reqConfig, e), Ext.apply(this.reqConfig, {
            callback: this.onCallback,
            scope: this
        }), delete this.reqConfig.id, delete this.reqConfig.single
    },
    run: function() {
        SYNO.SDS.TaskRunner.AjaxTask.superclass.stop.call(this), this.reqId = SYNO.API.Request(this.reqConfig)
    },
    onCallback: function(e, t, i, s) {
        var n = Ext.apply({}, s);
        Ext.apply(n, {
            scope: this.cbHandler.scope,
            callback: this.cbHandler.callback
        }), n.callback && n.callback.call(n.scope, e, t, i, n), this.fireEvent("callback", e, t, i, n), this.single ? (this.reqId = null, this.remove()) : this.reqId && (this.reqId = null, this.start(!1))
    }
}), inJsdom() ? window.SYNO = {
    SDS: {
        Utils: {}
    }
} : Ext.namespace("SYNO.SDS.Utils"), window._D = window._D || function() {}, window._S = window._S || function() {}, String.prototype.hashCode = function() {
    var e, t, i = 0;
    if (0 === this.length) return i;
    for (e = 0; e < this.length; e++) t = this.charCodeAt(e), i = (i << 5) - i + t, i |= 0;
    return i
}, SYNO.SDS.Utils.addFavIconLink = function(e, t, i) {
    var s, n = document.getElementsByTagName("link"),
        r = document.createElement("link");
    r.rel = "icon", r.href = e, r.setAttribute("sizes", i), t && (r.type = t);
    for (var o = document.head || document.getElementsByTagName("head")[0], a = n.length - 1; a >= 0; a--) n[a] && "icon" === n[a].getAttribute("rel") && ((s = n[a].getAttribute("sizes")) && i !== s || o.removeChild(n[a]));
    o.appendChild(r)
}, SYNO.SDS.Utils.clone = function(e) {
    if (!e || "object" !== _typeof(e)) return e;
    if ("function" == typeof e.clone) return e.clone();
    var t, i, s = "[object Array]" === Object.prototype.toString.call(e) ? [] : {};
    for (t in e) e.hasOwnProperty(t) && (i = e[t], i && "object" === _typeof(i) ? s[t] = SYNO.SDS.Utils.clone(i) : s[t] = i);
    return s
}, SYNO.SDS.Utils.mergeDeep = function(e) {
    for (var t, i = arguments.length, s = new Array(i > 1 ? i - 1 : 0), n = 1; n < i; n++) s[n - 1] = arguments[n];
    if (!s.length) return e;
    var r = s.shift();
    if (Ext.isObject(e) && Ext.isObject(r))
        for (var o in r) Ext.isObject(r[o]) ? (e[o] || Object.assign(e, _defineProperty({}, o, {})), SYNO.SDS.Utils.mergeDeep(e[o], r[o])) : Object.assign(e, _defineProperty({}, o, r[o]));
    return (t = SYNO.SDS.Utils).mergeDeep.apply(t, [e].concat(s))
}, SYNO.SDS.Utils.nextElementSibling = function(e, t) {
    var i = e.nextElementSibling;
    if (!t) return i;
    for (; i;) {
        if (i.matches(t)) return i;
        i = i.nextElementSibling
    }
    return null
}, SYNO.SDS.Utils.SelectableCLS = "allowDefCtxMenu selectabletext", SYNO.SDS.Utils.IsJson = function(e) {
    return "" !== e && (e = e.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, "@"), e = e.replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+-]?\d+)?/g, "]"), e = e.replace(/(?:^|:|,)(?:\s*\[)+/g, ""), /^[\],:{}\s]*$/.test(e))
};
var isLowLevelModel;
SYNO.SDS.Utils.isLowLevelModel = function() {
    if (Ext.isDefined(isLowLevelModel)) return isLowLevelModel;
    var e = _D("upnpmodelname");
    return isLowLevelModel = /(j|slim|se)$/.test(e) && e.indexOf("620slim") < 0
}, inJsdom() && (module.exports = SYNO.SDS.Utils), SYNO.SDS.Utils._Language = {
    ENU: "enu",
    FRE: "fre",
    GER: "ger",
    ITA: "ita",
    SPN: "spn",
    CHT: "cht",
    CHS: "chs",
    JPN: "jpn",
    KRN: "krn",
    THA: "tha",
    RUS: "rus",
    NLD: "nld",
    CSY: "csy",
    PLK: "plk",
    DAN: "dan",
    SVE: "sve",
    HUN: "hun",
    TRK: "trk",
    NOR: "nor",
    PTG: "ptg",
    PTB: "ptb"
}, SYNO.SDS.Utils.Language = function() {
    var e = {},
        t = {},
        i = "",
        s = function(e, t, i) {
            Ext.isIE8 ? e[t] = i : Object.defineProperty(e, t, {
                value: i,
                enumerable: !0
            })
        };
    e = {
        GetDefaultHelpLanguage: function() {
            return SYNO.SDS.Utils._Language.ENU
        },
        GetSupportedLanguage: function() {
            return t
        }
    };
    for (var n in SYNO.SDS.Utils._Language) SYNO.SDS.Utils._Language.hasOwnProperty(n) && (i = SYNO.SDS.Utils._Language[n], s(e, n, i), s(t, i, _T("common", "language_" + i)));
    return e
}(), SYNO.SDS.Utils.getHelpLanguage = function(e) {
    var t = [SYNO.SDS.Utils.Language.DAN, SYNO.SDS.Utils.Language.SVE, SYNO.SDS.Utils.Language.HUN, SYNO.SDS.Utils.Language.TRK, SYNO.SDS.Utils.Language.NOR, SYNO.SDS.Utils.Language.PTG, SYNO.SDS.Utils.Language.PTB, SYNO.SDS.Utils.Language.THA];
    return e = e || _S("lang"), -1 !== t.indexOf(e) ? SYNO.SDS.Utils.Language.GetDefaultHelpLanguage() : SYNO.SDS.Utils.Language.GetSupportedLanguage()[e] ? e : SYNO.SDS.Utils.Language.GetDefaultHelpLanguage()
}, SYNO.SDS.Utils.getSupportedLanguage = function(e) {
    var t = SYNO.SDS.Utils.Language.GetSupportedLanguage(),
        i = [],
        s = 0;
    for (var n in t) t.hasOwnProperty(n) && (i[s++] = [n, t[n]]);
    var r = function(e, t) {
        return e[1] > t[1] ? 1 : e[1] < t[1] ? -1 : 0
    };
    return i = i.sort(r), e && i.unshift(["def", _T("common", "language_def")]), i
}, SYNO.SDS.Utils.getSupportedLanguageCodepage = function(e) {
    var t = {
            enu: _T("common", "language_enu"),
            fre: _T("common", "language_fre"),
            ger: _T("common", "language_ger"),
            gre: _T("common", "language_gre"),
            heb: _T("common", "language_heb"),
            tha: _T("common", "language_tha"),
            ita: _T("common", "language_ita"),
            spn: _T("common", "language_spn"),
            cht: _T("common", "language_cht"),
            chs: _T("common", "language_chs"),
            jpn: _T("common", "language_jpn"),
            krn: _T("common", "language_krn"),
            ptb: _T("common", "language_ptb"),
            rus: _T("common", "language_rus"),
            dan: _T("common", "language_dan"),
            nor: _T("common", "language_nor"),
            sve: _T("common", "language_sve"),
            nld: _T("common", "language_nld"),
            plk: _T("common", "language_plk"),
            ptg: _T("common", "language_ptg"),
            hun: _T("common", "language_hun"),
            trk: _T("common", "language_trk"),
            csy: _T("common", "language_csy"),
            ara: _T("common", "language_ara")
        },
        i = [],
        s = 0;
    for (var n in t) t.hasOwnProperty(n) && (i[s++] = [n, t[n]]);
    var r = function(e, t) {
        return e[1] > t[1] ? 1 : e[1] < t[1] ? -1 : 0
    };
    return i = i.sort(r), e && i.unshift(["def", _T("common", "language_def")]), i
}, SYNO.SDS.Utils.isCJKLang = function() {
    switch (SYNO.SDS.Session.lang) {
        case "cht":
        case "chs":
        case "jpn":
        case "krn":
            return !0;
        default:
            return !1
    }
}, SYNO.SDS.Utils.IsCJK = function(e) {
    if (!e) return !1;
    for (var t, i = 0; i < e.length; i++)
        if (" " !== (t = e[i]) && (void 0 === t || ! function(e) {
                return /^[\u4E00-\u9FA5]|^[\uFE30-\uFFA0]/.test(e)
            }(t) && ! function(e) {
                return /^[\u0800-\u4e00]/.test(e)
            }(t) && ! function(e) {
                return /^[\u3130-\u318F]|^[\uAC00-\uD7AF]/.test(e)
            }(t))) return !1;
    return !0
}, SYNO.SDS.Utils.createTimeItemStore = function(e) {
    var t = [],
        i = {
            hour: 24,
            min: 60,
            sec: 60
        };
    if (e in i) {
        for (var s = 0; s < i[e]; s++) t.push([s, String.leftPad(String(s), 2, "0")]);
        return new Ext.data.SimpleStore({
            id: 0,
            fields: ["value", "display"],
            data: t
        })
    }
    return null
}, SYNO.SDS.Utils.isBSTinEffect = function() {
    var e, t, i, s, n = new Date;
    for (e = 31; e > 0; e--)
        if (t = new Date(n.getFullYear(), 2, e), 0 === t.getDay()) {
            i = t;
            break
        } for (e = 31; e > 0; e--)
        if (t = new Date(n.getFullYear(), 9, e), 0 === t.getDay()) {
            s = t;
            break
        } return !(n < i || n > s)
}, Ext.define("SYNO.SDS._System", {
    extend: "Ext.Component",
    isDifferentNode: !1,
    nodeData: {},
    Reboot: function() {
        SYNO.SDS.System.RebootWithMsg()
    },
    RebootWithNode: function(e) {
        this.nodeData = e, this.isDifferentNode = e && e.isDifferentNode;
        var t = "ha" == this.nodeData.node ? this.nodeData.msg.reboot.ha : "active" == this.nodeData.node ? this.nodeData.msg.reboot.active : this.nodeData.msg.reboot.passive;
        SYNO.SDS.System.RebootMsgBox(t)
    },
    RebootWithMsg: function(e) {
        var t = SYNO.SDS.System;
        return "yes" === _D("support_dual_head", "no") ? void t._launchAHA() : _S("manage_pw_btn_in_ha_pkg") ? void t._launchHA() : _S("ha_support_pw_btn") ? void SYNO.SDS.RebootPowerOff.HAShow(this, "reboot", function(e) {
            var t = {
                isDifferentNode: !1,
                node: "ha",
                type: "reboot",
                msg: e.msg,
                can_switchover: e.can_switchover
            };
            SYNO.SDS.System.RebootWithNode(t)
        }) : void SYNO.SDS.System.RebootMsgBox(e)
    },
    RebootMsgBox: function(e) {
        var t = SYNO.SDS.System;
        SYNO.SDS.Desktop.hide(), SYNO.SDS.Desktop.getMsgBox().confirm(_D("product"), e || _JSLIBSTR("uicommon", "reboot_warn"), function(e) {
            "yes" === e ? t._rebootSystem(!1) : "no" === e && SYNO.SDS.Desktop.show()
        }, t)
    },
    PowerOff: function() {
        SYNO.SDS.System.PowerOffWithMsg()
    },
    PowerOffWithNode: function(e) {
        this.nodeData = e, this.isDifferentNode = e && e.isDifferentNode;
        var t = "ha" === this.nodeData.node ? this.nodeData.msg.shutdown.ha : "active" == this.nodeData.node ? this.nodeData.msg.shutdown.active : this.nodeData.msg.shutdown.passive;
        SYNO.SDS.System.PowerOffMsgBox(t)
    },
    PowerOffWithMsg: function(e) {
        var t = SYNO.SDS.System;
        return "yes" === _D("support_dual_head", "no") ? void t._launchAHA() : _S("manage_pw_btn_in_ha_pkg") ? void t._launchHA() : _S("ha_support_pw_btn") ? void SYNO.SDS.RebootPowerOff.HAShow(this, "reboot", function(e) {
            var t = {
                isDifferentNode: !1,
                node: "ha",
                type: "poweroff",
                msg: e.msg,
                can_switchover: e.can_switchover
            };
            SYNO.SDS.System.PowerWithNode(t)
        }) : void SYNO.SDS.System.PowerOffMsgBox(e)
    },
    PowerOffMsgBox: function(e) {
        var t = SYNO.SDS.System;
        SYNO.SDS.Desktop.hide(), SYNO.SDS.Desktop.getMsgBox().confirm(_D("product"), e || _JSLIBSTR("uicommon", "shutdown_warn"), function(e) {
            "yes" === e ? t._shutdownSystem(!1) : "no" === e && SYNO.SDS.Desktop.show()
        }, t)
    },
    WaitForBootUp: function() {
        SYNO.SDS.Desktop.hide(), SYNO.SDS.System._rebootSystem(!1, !1, !0, !1)
    },
    Logout: function() {
        SYNO.SDS.StatusNotifier.fireEvent("logout"), window.onbeforeunload = SYNO.SDS.onBasicBeforeUnload;
        try {
            SYNO.SDS.Utils.Logout.action()
        } catch (e) {}
    },
    FirmwareUpgradeReboot: function() {
        var e = SYNO.SDS.System;
        SYNO.SDS.Desktop.hide(), _S("ha_support_pw_btn") && (this.nodeData = {
            isDifferentNode: !1,
            node: "ha",
            type: "reboot"
        }, this.isDifferentNode = this.nodeData && this.nodeData.isDifferentNode), e._rebootSystem(!1, void 0, void 0, !0)
    },
    _launchHA: function() {
        SYNO.SDS.Desktop.getMsgBox().confirm(_D("product"), _TT("SYNO.SDS.HA.Instance", "ui", "warning_forbid_power_option"), function(e) {
            "yes" === e && SYNO.SDS.AppLaunch("SYNO.SDS.HA.Instance")
        })
    },
    _launchAHA: function() {
        SYNO.SDS.Desktop.getMsgBox().confirm(_D("product"), _TT("SYNO.SDS.AHA.Instance", "uicommon", "warning_forbid_power_option"), function(e) {
            "yes" === e && SYNO.SDS.AppLaunch("SYNO.SDS.AHA.Instance")
        })
    },
    _waitHAStatus: function() {
        var e = this,
            t = e.addTask({
                interval: 5e3,
                run: function() {
                    e.sendWebAPI({
                        api: "SYNO.SHA.Panel.Overview",
                        version: 1,
                        method: "load",
                        scope: this,
                        callback: function(e, i, s) {
                            if (!e || !i) return void t.stop();
                            !0 !== i.ha.passive_is_rebooting_triggered_by_webapi && !0 !== i.ha.passive_is_shutting_down_triggered_by_webapi && "desc_passive_offline" !== i.ha.description[0] || (SYNO.SDS.Desktop.getMsgBox().hide(), SYNO.SDS.Desktop.show(), t.stop())
                        }
                    })
                }
            }).start()
    },
    _rebootSystem: function(e, t, i, s) {
        var n, r = !0 === i ? _T("login", "error_system_getting_ready") : _JSLIBSTR("uicommon", "system_reboot").replace(/_DISKSTATION_/g, _D("product"));
        this.isDifferentNode ? r = _TT("SYNO.SDS.HA.Instance", "ui", "rebooting_" + this.nodeData.node) : _S("ha_support_pw_btn") && "active" === this.nodeData.node && this.nodeData.can_switchover && "poweroff" === this.nodeData.type && (r = this.nodeData.msg.shutting_down.active), SYNO.SDS.Desktop.getMsgBox().show({
            wait: !0,
            closable: !1,
            maxWidth: 300,
            title: _D("product"),
            msg: r
        }), n = !1 === e && !1 === t ? "skip_cmd" : "reboot", _S("ha_support_pw_btn") && "poweroff" === this.nodeData.type && "active" === this.nodeData.node && this.nodeData.can_switchover && (n = "shutdown"), s = s || !1, this._haltSystem(n, e, s, function() {
            var e, t = 0,
                i = 1;
            if (this.isDifferentNode) return void this._waitHAStatus();
            "skip_cmd" === n && (t = 1), _S("ha_support_pw_btn") && (i = 1), e = this.addAjaxTask({
                preventHalt: !0,
                interval: 5e3,
                autoJsonDecode: !0,
                url: "webman/pingpong.cgi",
                startTime: (new Date).getTime(),
                timeLimit: 6e5,
                quickConnectTimeout: 15e3,
                scope: this,
                success: function(s, n) {
                    var r = (new Date).getTime();
                    if (SYNO.SDS.QuickConnect.Utils.isInTunnel() && r - n.startTime > n.quickConnectTimeout && t <= 0 && (t = i), t < i) return void(t = 0);
                    s && s.boot_done && (e.stop(), window.location.href = "/")
                },
                failure: function(e, i) {
                    var s = (new Date).getTime();
                    !i.timeoutNotified && s - i.startTime > i.timeLimit && (SYNO.SDS.Desktop.getMsgBox().show({
                        closable: !1,
                        maxWidth: 300,
                        title: _D("product"),
                        msg: _JSLIBSTR("uicommon", "system_reboot_timeout").replace(/_DISKSTATION_/g, _D("product"))
                    }), i.timeoutNotified = !0), t++
                }
            }).start()
        }, this)
    },
    _shutdownSystem: function(e, t) {
        if (!this.isDifferentNode) {
            if (_S("ha_support_pw_btn") && "active" === this.nodeData.node && this.nodeData.can_switchover) return this._rebootSystem(e);
            SYNO.SDS.Desktop.getMsgBox().show({
                closable: !1,
                maxWidth: 300,
                title: _D("product"),
                msg: _JSLIBSTR("uicommon", "system_poweroff").replace(/_DISKSTATION_/g, _D("product"))
            })
        }
        this._haltSystem("shutdown", e, !1, function() {
            if (this.isDifferentNode) return SYNO.SDS.Desktop.getMsgBox().show({
                wait: !0,
                closable: !1,
                maxWidth: 300,
                title: _D("product"),
                msg: _TT("SYNO.SDS.HA.Instance", "ui", "shutting_down_" + this.nodeData.node + "_desc")
            }), void this._waitHAStatus()
        }, this)
    },
    _confirmCache: function() {
        if (!1 === SYNO.SDS.UserSettings.getProperty("Personal", "cacheShutdownQuery")) return void this._shutdownSystem(!0);
        var e, t, i = this,
            s = Ext.id();
        SYNO.SDS.Desktop.getMsgBox().hide(), t = '&nbsp<a class="link-font" id="' + s + '" href="#">' + _T("volume", "storage_manager") + " </a>", e = new SYNO.SDS.CacheConfirmMessage({
            modal: !0,
            draggable: !1,
            renderTo: document.body,
            scope: this
        }), e.showMsg({
            title: _D("product"),
            msg: String.format(_T("volume", "cache_shutdown_warn"), t) + "</br>",
            buttons: {
                ok: _T("volume", "cache_shutdown"),
                cancel: !0
            },
            fn: function(t) {
                "ok" === t ? (e.checkbox.checked && (SYNO.SDS.UserSettings.setProperty("Personal", "cacheShutdownQuery", !1), SYNO.SDS.UserSettings.syncSave()), this._shutdownSystem(!0)) : SYNO.SDS.Desktop.show()
            },
            closable: !1,
            minWidth: 250,
            scope: this
        }), i.mon(Ext.fly(s), "click", function() {
            SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance", Ext.apply({}, {
                fn: "SYNO.SDS.StorageManager.SsdCache.Main"
            })), e.close(), SYNO.SDS.Desktop.show()
        }, i, {
            single: !0
        })
    },
    _haltSystem: function(e, t, i, s, n) {
        if ("skip_cmd" === (e = e || "reboot")) return void this._beforeHaltSystem(s, n);
        var r = "SYNO.Core.System",
            o = e,
            a = {
                force: !!t,
                local: !0,
                firmware_upgrade: !!i,
                cache_check_shutdown: "shutdown" === e
            };
        _S("ha_support_pw_btn") && (r = "SYNO.SHA.Panel.Action", o = "active" === this.nodeData.node ? e + "_active" : "ha" === this.nodeData.node ? e + "_ha" : e + "_passive", a.mode = o, a.is_skip_soft = t), SYNO.API.Request({
            api: r,
            method: o,
            version: 1,
            relay_node: this.nodeData.node,
            params: a,
            callback: function(t, r) {
                var o = "reboot" === e ? _T("system", "running_tasks_confirm_reboot") : _T("system", "running_tasks_confirm_shutdown");
                if (_S("ha_support_pw_btn") && t && !1 === r.success) {
                    var a = SYNO.SDS.HA.GenErrMsg(r.errinfo, this);
                    return void SYNO.SDS.Desktop.getMsgBox().alert(_D("product"), a, function(e) {
                        SYNO.SDS.Desktop.show()
                    }, this)
                }
                var l = r.errors;
                if (!1 === t && l.blockingTasks) {
                    var c = this.getTasks(l.blockingTasks);
                    return void SYNO.SDS.Desktop.getMsgBox().alert(_D("product"), _T("system", "running_tasks_warning") + "<br><br>" + c + "<br><br>" + _T("system", "try_later_warning"), function(e) {
                        SYNO.SDS.Desktop.show()
                    }, this)
                }
                if (!1 === t && l.runningTasks) {
                    var d, h = l.runningTasks,
                        u = 0 <= h.indexOf("volume:cache_shutdown_warn");
                    return h.remove("volume:cache_shutdown_warn"), void(0 < h.length ? (d = this.getTasks(h), SYNO.SDS.Desktop.getMsgBox().confirm(_D("product"), o + "<br><br>" + d, function(t) {
                        "yes" === t ? "shutdown" === e ? u ? this._confirmCache() : this._shutdownSystem(!0) : this._rebootSystem(!0, void 0, void 0, i) : "no" === t && SYNO.SDS.Desktop.show()
                    }, this)) : "shutdown" === e ? this._confirmCache() : this._rebootSystem(!0, void 0, void 0, i))
                }
                this._beforeHaltSystem(s, n)
            },
            scope: this
        })
    },
    CountCharInStr: function(e, t) {
        var i = 0,
            s = 0;
        for (s = 0; s < e.length; ++s) t == e[s] && i++;
        return i
    },
    getTasks: function(e) {
        var t, i, s = [];
        return Ext.each(e, function(e) {
            if (-1 === e.indexOf(":")) s.push(e);
            else {
                if (t = e.split(":"), 1 === this.CountCharInStr(e, ":")) i = 0 === _T(t[0], t[1]).length ? _JSLIBSTR(t[0], t[1]) : _T(t[0], t[1]);
                else {
                    if (2 !== this.CountCharInStr(e, ":")) return !0;
                    i = _TT(t[0], t[1], t[2])
                }
                s.push(i)
            }
        }, this), s.join("<br> ")
    },
    _beforeHaltSystem: function(e, t) {
        this.isDifferentNode || (SYNO.SDS.StatusNotifier.fireEvent("halt"), window.onbeforeunload = null), e && e.apply(t)
    }
}), Ext.define("SYNO.SDS.Utils.Logout", {
    statics: {
        logoutTriggered: !1,
        reserveQueryString: !1,
        action: function(e, t, i, s, n, r) {
            this.logoutTriggered || (!0 === i && (SYNO.SDS.Desktop && SYNO.SDS.Desktop.hide(), Ext.getBody().mask().addClass("desktop-timeout-mask")), this.logout(e, t, s, n, r))
        },
        showMessage: function(e) {
            return new Promise(function(t, i) {
                Ext.isDefined(e) ? (Ext.getBody().unmask(), Ext.getClassByName("SYNO.SDS.StatusNotifier") && SYNO.SDS.StatusNotifier.fireEvent("halt"), SYNO.SDS.Desktop.getMsgBox().alert("", e, t, this)) : t()
            })
        },
        logout: function(e, t, i, s, n) {
            var r = this,
                o = function() {
                    Ext.isSafari && Ext.isMac ? r.redirect(i, n).defer(300, r) : r.redirect(i, n)
                },
                a = function() {
                    !0 === e && (window.onbeforeunload = null), !1 !== i && "azure_sso" === Ext.util.Cookies.get("login_type") && SYNO.SDS.AzureSSOUtils.logout(), SYNO.SDS.CrossPortStorage.SetItem("currentLoginUser", "", o, r)
                };
            r.logoutTriggered = !0, SYNO.SDS.SocketInst && SYNO.SDS.SocketInst.disconnect(), s ? a.apply(this) : r.showMessage(t).then(a.bind(r), a.bind(r)).catch(a.bind(r))
        },
        setConfig: function(e) {
            Ext.apply(this, e)
        },
        doRefresh: function() {
            if (this.reserveQueryString) window.location.reload(!0);
            else {
                var e = window.location.href;
                window.location.href = window.location.pathname, e === window.location.href && window.setTimeout(function() {
                    window.location.reload(!0)
                }, 100)
            }
        },
        doLogout: function(e) {
            synowebapi.request({
                url: "webapi/entry.cgi?api=SYNO.API.Auth",
                requestFormat: "raw",
                responseFormat: "raw",
                method: "GET",
                params: {
                    version: 7,
                    method: "logout"
                },
                scope: this,
                callback: function() {
                    window.sessionStorage && e && window.sessionStorage.setItem("errCode", e), this.doRefresh()
                }
            })
        },
        redirect: function(e, t) {
            var i = this;
            if (!1 === e) {
                var s = new XMLHttpRequest;
                s.onreadystatechange = function() {
                    if (4 === s.readyState) {
                        if (200 === s.status) {
                            if (!0 === JSON.parse(s.response).success) return void i.doRefresh()
                        }
                        i.doLogout(t)
                    }
                }, s.open("POST", "webapi/auth.cgi?api=SYNO.API.Auth&version=6&method=token", !0), s.send()
            } else i.doLogout(t)
        }
    }
}), SYNO.SDS.Utils.CheckServerErrorString = function(e, t) {
    var i, s, n = !0,
        r = !1;
    if (e && Ext.isEmpty(t)) {
        switch (e = Ext.util.Format.trim(e)) {
            case "timeout":
                i = _JSLIBSTR("uicommon", "error_timeout"), n = !1, r = !0, s = 106;
                break;
            case "unauth":
                i = _JSLIBSTR("uicommon", "error_timeout"), n = !1, r = !0, s = 119;
                break;
            case "noprivilege":
                i = _JSLIBSTR("uicommon", "error_noprivilege");
                break;
            case "relogin":
                i = _JSLIBSTR("uicommon", "error_relogin");
                break;
            case "errorip":
                i = void 0;
                break;
            default:
                i = _JSLIBSTR("uicommon", "error_system")
        }
        return SYNO.SDS.Utils.Logout.action(!0, i, !0, n, r, s), !0
    }
    return !1
}, SYNO.SDS.Utils.CheckServerError = function(e) {
    var t, i;
    if (!e || !e.getResponseHeader) return !1;
    try {
        t = e.getResponseHeader("x-request-error") || e.getResponseHeader("X-Request-Error")
    } catch (i) {
        t = e.getResponseHeader["x-request-error"] || e.getResponseHeader["X-Request-Error"]
    }
    try {
        i = e.getResponseHeader("X-SYNO-SOURCE-ID")
    } catch (e) {
        i = void 0
    }
    return !1 !== SYNO.SDS.HandShake.CheckServerError(e) && SYNO.SDS.Utils.CheckServerErrorString(t, i)
}, 
/**
 * @class SYNO.SDS.CacheConfirmMessage
 * @extends SYNO.SDS.MessageBoxV5
 * VideoStation confirm message class
 *
 */
Ext.define("SYNO.SDS.CacheConfirmMessage", {
    extend: "SYNO.SDS.MessageBoxV5",
    checkbox: null,
    onRender: function() {
        this.callParent(arguments), this.checkbox = new SYNO.ux.Checkbox({
            xtype: "syno_checkbox",
            htmlEncode: !1,
            boxLabel: _T("volume", "cache_shutdown_remind"),
            renderTo: this.bodyEl,
            scope: this
        }), this.addManagedComponent(this.checkbox)
    }
}), Ext.namespace("SYNO.SDS.Utils.CMS"), SYNO.SDS.Utils.CMS.IsAllowRelay = function(e) {
    var t, i;
    return !!Ext.isObject(e) && (t = Ext.getClassByName("SYNO.SDS.AdminCenter.MainWindow"), i = Ext.getClassByName("SYNO.SDS.ResourceMonitor.App"), !(!(!Ext.isEmpty(t) && e instanceof t || !Ext.isEmpty(i) && e instanceof i || !0 === function(e) {
        return !!(!0 === e._relayObject && Ext.isFunction(e.findAppWindow) && Ext.isObject(e.openConfig) && Ext.isFunction(e.hasOpenConfig) && Ext.isFunction(e.getOpenConfig) && Ext.isFunction(e.setOpenConfig))
    }(e)) || !e.hasOpenConfig("cms_id")))
};
