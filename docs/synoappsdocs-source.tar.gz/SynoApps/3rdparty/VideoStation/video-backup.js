/* Copyright (c) 2020 Synology Inc. All rights reserved. */

function _VST(t, e) {
    var i = "";
    try {
        i = _TT("SYNO.SDS.VideoStation.AppInstance", t, e)
    } catch (o) {
        i = _T(t, e)
    } finally {
        return i || String.format("{0}:{1}", t, e)
    }
}
Ext.define("SYNO.SDS.VideoStation2.Constant", {
    singleton: !0,
    CLASS: {
        UNWATCHED: "unwatched",
        LASTWATCHED: "lastwatched"
    },
    EVENT: {
        PLAYLIST_CHANGE: "playlistchange",
        SHARING_STATUS_LOAD: "sharingstatusload",
        VIDEO_LOAD: "videoload",
        VIEW_LOADING: "viewloading",
        VIEW_LOADED: "viewloaded",
        VIEW_NOVIDEO: "viewnovideo",
        VIEW_NOTUNER: "viewnotuner",
        VIEW_CHANNEL_SCAN: "viewchannelscan",
        LOAD_PLAYER_OPTION: "loadplayeroption",
        VIDEO_INFO_UPDATE: "videoinfoupdate"
    },
    EXTRA: {
        KEY_RATING: "rating",
        KEY_REFERENCE: "reference",
        KEY_TMDB: "themoviedb",
        KEY_TMDB_TV: "themoviedb_tv",
        KEY_IMDB: "imdb",
        KEY_ATMOVIE: "atmovie"
    },
    PLAYLIST_TYPE: {
        ORIGINAL: "original",
        SMART: "smart"
    },
    REFRESH_INFO: {
        VIDEO: "video",
        SUBTITLE: "subtitle",
        NEXT_PREV_BTN: "next_prev_btn"
    },
    PLAYER_STREAMING: "streaming",
    TITLE_FAVORITE: "syno_favorite",
    TITLE_WATCHLIST: "syno_watchlist",
    COLLECTION: "collection",
    PLAYLIST: "playlist",
    PLAYLIST_VIDEOLIST: "playlistvideolist",
    MOVIE: "movie",
    TVSHOW: "tvshow",
    TVSHOW_EPISODE: "tvshow_episode",
    HOME_VIDEO: "home_video",
    TV_RECORDING: "tv_record",
    GETINFO_ADDITIONAL: ["summary", "file", "actor", "writer", "director", "extra", "genre", "collection", "poster_mtime", "watched_ratio", "backdrop_mtime"],
    ADDITIONAL_DICT: {
        movie: ["summary", "poster_mtime", "backdrop_mtime", "file", "collection", "watched_ratio", "conversion_produced", "actor", "director", "genre", "writer", "extra"],
        home_video: ["summary", "poster_mtime", "backdrop_mtime", "file", "collection", "watched_ratio", "conversion_produced", "actor", "director", "genre", "writer", "extra"],
        tvshow: ["summary", "poster_mtime", "backdrop_mtime"],
        tvshow_episode: ["summary", "poster_mtime", "backdrop_mtime", "file", "collection", "watched_ratio", "conversion_produced", "actor", "director", "genre", "writer", "extra", "tvshow_summary"],
        tv_record: ["summary", "poster_mtime", "backdrop_mtime", "file", "collection", "watched_ratio", "conversion_produced"]
    },
    CHANNEL: "channel",
    PROGRAM: "program",
    FOLDER: "folder",
    SQUARE: "square",
    FILE: "file",
    LIBRARY: "library",
    CATEGORY: "category",
    DTV: "dtv",
    FILTER: "filter",
    SEASON: "season",
    VIDEO: "video",
    PAGE: "page",
    RECORDING_SPECIFIC: "recording_specific",
    VIDEO_PROFILE_ORIGINAL: "original",
    VIDEO_PROFILE_HIGH: "high",
    VIDEO_PROFILE_MEDIUM: "medium",
    VIDEO_PROFILE_LOW: "low",
    RESOLUTION_DEFINITION: {
        SD: {
            x_from: -1,
            x_to: 640,
            y_from: -1,
            y_to: 480
        },
        "480p": {
            x_from: 640,
            x_to: 1024,
            y_from: 480,
            y_to: 576
        },
        "720p": {
            x_from: 1024,
            x_to: 1280,
            y_from: 576,
            y_to: 720
        },
        "1080p": {
            x_from: 1280,
            x_to: 1920,
            y_from: 720,
            y_to: 1080
        },
        "4K": {
            x_from: 1920,
            x_to: -1,
            y_from: 1080,
            y_to: -1
        }
    },
    PROGRAM_STATUS: {
        STATUS_NONE: "none",
        STATUS_PASS: "pass",
        STATUS_STREAMING: "streaming",
        STATUS_RECORDING: "recording",
        STATUS_SCHEDULED: "scheduled",
        STATUS_REPEAT_SCHEDULED: "repeatscheduled"
    },
    SCHEDULE_STATUS: {
        STATUS_ERROR: "error",
        STATUS_WAIT: "wait",
        STATUS_STREAMING: "streaming",
        STATUS_RECORDING: "recording",
        STATUS_DONGLE_NOT_FOUND: "nodonglenotfound",
        STATUS_RECORDING_INTERRUPT: "recordinginterrupt",
        STATUS_DONE: "done",
        STATUS_NO_PERMISSION: "nopermission",
        STATUS_USER_INVALID: "userinvalid",
        STATUS_NO_QUOTA: "noquota",
        STATUS_VOLUME_FULL: "volumefull",
        STATUS_CREATE_FILE_ERROR: "createfileerror",
        STATUS_WEEKLY_SCHEDULE: "weeklyschedule",
        STATUS_DAILY_SCHEDULE: "dailyschedule",
        STATUS_VLC_INTERRUPT: "vlcinterrupt",
        STATUS_SKIP: "skip"
    },
    RECORDING_ACTION_KEY: {
        RECORDING_CREATE: "record",
        RECORDING_CANCEL: "cancel_recording",
        RECORDING_CREATE_REPEAT: "repeat_record",
        RECORDING_CREATE_USERDEFINE: "user_define_schedule"
    },
    TUNER_TYPE: {
        TYPE_QPSK: 0,
        TYPE_QAM: 1,
        TYPE_OFDM: 2,
        TYPE_ATSC: 3,
        TYPE_HDHOMERUN: 99
    },
    STORE_UNLIMIT: 5e5,
    MAX_NUMBER_OF_RECOMMENDATION: {
        movie: 50,
        tvshow_episode: 5e5,
        home_video: 10,
        tv_record: 10
    },
    MAX_LENGTH: {
        PLAYLIST_NAME: 255,
        DVB_CHANNEL_NAME: 110,
        DVB_PROGRAM_NAME: 110,
        VIDEO_METADATA_CERTIFICATE: 255,
        VIDEO_METADATA_COMMON_FIELD: 255,
        VIDEO_METADATA_SUMMARY: 4096,
        VIDEO_METADATA_TAGLINE: 255,
        VIDEO_METADATA_TITLE: 255
    }
}), Ext.define("SYNO.SDS.VideoStation2.Util", {
    singleton: !0,
    applyCallback: function(t) {
        Ext.isObject(t) && Ext.isFunction(t.fn) && t.fn.apply(t.scope || window, t.args || [])
    },
    convertCollectionID: function(t) {
        return Ext.isArray(t) ? t.map(function(t) {
            var e = parseInt(t.id, 10),
                i = t.title;
            return SYNO.SDS.VideoStation2.Constant.TITLE_FAVORITE === i ? e = -1 : SYNO.SDS.VideoStation2.Constant.TITLE_WATCHLIST === i && (e = -2), {
                id: e,
                title: t.title
            }
        }) : t
    },
    getVideoActionString: function(t) {
        var e = ["view_video_info", "edit_metadata", "correct_metadata", "set_watched", "set_unwatched", "del_file", "del_video"],
            i = ["search_subtitle"],
            o = ["public_sharing"],
            n = ["offline_conversion"];
        return -1 !== e.indexOf(t) ? _VST("action", t) : -1 !== i.indexOf(t) ? _VST("controller", t) : -1 !== o.indexOf(t) ? _VST("advanced", t) : -1 !== n.indexOf(t) ? _VST(t, "action") : void 0
    },
    getFilterCategoryString: function(t) {
        switch (t) {
            case SYNO.SDS.VideoStation2.Filter.FILTER_ACTOR:
                return _VST("actor", "title");
            case SYNO.SDS.VideoStation2.Filter.FILTER_DIRECTOR:
                return _VST("director", "title");
            case SYNO.SDS.VideoStation2.Filter.FILTER_GENRE:
                return _VST("genre", "title");
            case SYNO.SDS.VideoStation2.Filter.FILTER_WRITER:
                return _VST("writer", "title");
            case SYNO.SDS.VideoStation2.Filter.FILTER_CERTIFICATE:
                return _VST("metadata", "rating_classification");
            case SYNO.SDS.VideoStation2.Filter.FILTER_RATING:
                return _VST("metadata", "rating");
            case SYNO.SDS.VideoStation2.Filter.FILTER_YEAR:
                return _VST("year", "title");
            case SYNO.SDS.VideoStation2.Filter.FILTER_RESOLUTION:
                return _VST("video_info", "resolution");
            case SYNO.SDS.VideoStation2.Filter.FILTER_WATCHED_STATUS:
                return _VST("common", "watch_status");
            case SYNO.SDS.VideoStation2.Filter.FILTER_FILE_COUNT:
                return _VST("filter", "file_count");
            case SYNO.SDS.VideoStation2.Filter.FILTER_CONTAINER:
                return _VST("video_info", "container");
            case SYNO.SDS.VideoStation2.Filter.FILTER_DURATION:
                return _VST("duration", "title");
            case SYNO.SDS.VideoStation2.Filter.FILTER_DATE:
                return _VST("classification", "bydate");
            case SYNO.SDS.VideoStation2.Filter.FILTER_CHANNEL_NAME:
                return _VST("classification", "bychannel");
            case SYNO.SDS.VideoStation2.Filter.FILTER_TITLE:
                return _VST("classification", "byprogram");
            case SYNO.SDS.VideoStation2.Filter.FILTER_KEYWORD:
                return _VST("search", "keyword");
            default:
                return ""
        }
    },
    getRecordingActionString: function(t) {
        return t === SYNO.SDS.VideoStation2.Constant.RECORDING_ACTION_KEY.RECORDING_CREATE_USERDEFINE ? _VST("schedule", t) : _VST("action", t)
    },
    getAPIName: function(t) {
        switch (t) {
            case SYNO.SDS.VideoStation2.Constant.MOVIE:
                return "SYNO.VideoStation2.Movie";
            case SYNO.SDS.VideoStation2.Constant.TVSHOW:
                return "SYNO.VideoStation2.TVShow";
            case SYNO.SDS.VideoStation2.Constant.TVSHOW_EPISODE:
                return "SYNO.VideoStation2.TVShowEpisode";
            case SYNO.SDS.VideoStation2.Constant.HOME_VIDEO:
                return "SYNO.VideoStation2.HomeVideo";
            case SYNO.SDS.VideoStation2.Constant.TV_RECORDING:
                return "SYNO.VideoStation2.TVRecording";
            default:
                throw String.format("unexpected type {0}", t)
        }
    },
    getVideoRoot: function(t) {
        switch (t) {
            case SYNO.SDS.VideoStation2.Constant.MOVIE:
                return "movie";
            case SYNO.SDS.VideoStation2.Constant.TVSHOW:
                return "tvshow";
            case SYNO.SDS.VideoStation2.Constant.TVSHOW_EPISODE:
                return "episode";
            case SYNO.SDS.VideoStation2.Constant.HOME_VIDEO:
                return "video";
            case SYNO.SDS.VideoStation2.Constant.TV_RECORDING:
                return "recording";
            default:
                throw String.format("unexpected type {0}", t)
        }
    },
    getWebAPIURL: function(t) {
        return String.format("{0}/{1}", "webapi/VideoStation", t)
    },
    getCGIURL: function(t) {
        return String.format("webman/3rdparty/VideoStation/cgi/{0}", t)
    },
    getImageURL: function(t) {
        return t = Ext.apply(t || {}, {
            api: "SYNO.VideoStation2.Poster",
            method: "get",
            version: "1"
        }), SYNO.SDS.UIFeatures.test("isRetina") && Ext.apply(t, {
            resolution: Ext.encode("2x")
        }), Ext.urlAppend("webapi/entry.cgi", Ext.urlEncode(t))
    },
    getImageURLByRecord: function(t, e) {
        return SYNO.SDS.VideoStation2.Util.getImageURL({
            type: Ext.isString(e) ? e : t.type,
            id: t.id,
            mtime: t.additional ? t.additional.poster_mtime || "" : ""
        })
    },
    getBackdropURL: function(t) {
        return t = Ext.apply(t || {}, {
            api: "SYNO.VideoStation2.Backdrop",
            method: "get",
            version: "1"
        }), Ext.urlAppend("webapi/entry.cgi", Ext.urlEncode(t))
    },
    getVideoDate: function(t) {
        var e = "";
        return Ext.isString(t.original_available) && !Ext.isEmpty(t.original_available) ? e = "0" === t.original_available ? "" : t.original_available.split("-")[0] : Ext.isString(t.record_date) && !Ext.isEmpty(t.record_date) && (e = "0" === t.record_date ? "" : t.record_date.split(" ")[0]), "" !== e && SYNO.SDS.DateTimeFormatter && (e = SYNO.SDS.DateTimeFormatter(Date.parseDate(e, "Y-m-d"), {
            type: "date"
        }) || e), e
    },
    getYMDFormatedDate: function(t) {
        return "" === t ? t : Date.parseDate(t, SYNO.SDS.DateTimeUtils.GetDateFormat()).format("Y-m-d")
    },
    hideDTVUI: function() {
        return SYNO.SDS.isNSM || "yes" === _D("support_dual_head") || SYNO.SDS.Utils.isInVirtualDSM() || "yes" === _D("dockerdsm")
    },
    isWatched: function(t) {
        return Ext.isNumber(t) && 1 === t
    },
    isUnwatched: function(t) {
        return Ext.isNumber(t) && 0 === Math.floor(100 * t)
    },
    classifyVideos: function(t) {
        var e = {};
        return t.forEach(function(t) {
            e[t.type] = e[t.type] || [], e[t.type].push(t)
        }), e
    },
    formatBitrate: function(t) {
        var e = parseInt(t, 10),
            i = (e / 1024).toFixed(1);
        return String.format("{0} Kbps", i)
    },
    extractFileName: function(t) {
        return t.substring(t.lastIndexOf("/") + 1)
    },
    getShareData: function(t) {
        var e = t,
            i = e.indexOf("/", 1),
            o = "";
        return e = e.substr(1), i > 0 && (o = e.substr(i), e = e.substr(0, i - 1)), {
            share: Ext.util.Format.lowercase(e),
            orishare: e,
            subpath: o
        }
    },
    getLangStore: function() {
        var t = SYNO.SDS.Utils.getSupportedLanguage();
        return new Ext.data.SimpleStore({
            fields: ["value", "display"],
            data: t,
            autoDestroy: !0
        })
    },
    onProxyBeforeLoad: function(t, e) {
        var i = t.activeRequest.read;
        i && Ext.Ajax.abort(i)
    },
    getCombinationPosterDiv: function(t, e) {
        return Ext.isArray(t) && Ext.isFunction(e) ? 1 === t.length ? String.format('<div class="center loading" url="{0}"></div>', e(t[0])) : 2 === t.length ? [String.format('<div class="top loading" url="{0}"></div>', e(t[0])), String.format('<div class="bottom loading" url="{0}"></div>', e(t[1]))].join("") : 3 === t.length ? [String.format('<div class="top loading" url="{0}"></div>', e(t[0])), String.format('<div class="bottom-left loading" url="{0}"></div>', e(t[1])), String.format('<div class="bottom-right loading" url="{0}"></div>', e(t[2]))].join("") : 4 <= t.length ? [String.format('<div class="top-left loading" url="{0}"></div>', e(t[0])), String.format('<div class="top-right loading" url="{0}"></div>', e(t[1])), String.format('<div class="bottom-left loading" url="{0}"></div>', e(t[2])), String.format('<div class="bottom-right loading" url="{0}"></div>', e(t[3]))].join("") : "" : ""
    },
    getWatchStatusDiv: function(t) {
        var e = t.additional || {};
        if (Ext.isDefined(e.total_seasons)) return "";
        var i = e.watched_ratio || 0;
        return i = 0 === i ? 0 : Math.floor(100 * i), 100 === i ? "" : ['<div class="watch-status-wrap">', '<div class="grey-bar"></div>', String.format('<div class="blue-bar" style="width:{0}%"></div>', i), "</div>"].join("")
    },
    mask: function(t, e, i, o, n, a) {
        var r;
        if (t && (r = t.getEl())) {
            r.delayedUnmask && (r.delayedUnmask.cancel(), r.delayedUnmask = null), r.mask.apply(r, Array.prototype.slice.call(arguments, 1, 3));
            var S = r.down(".ext-el-mask");
            if (S.addClass("syno-vs2-el-mask"), Ext.isFunction(o)) {
                var s = r.down(".ext-el-mask-msg div");
                s.addClass("clickable"), s.on("click", o, a)
            }
            r.delayedMask && (r.delayedMask.cancel(), r.delayedMask = null), r.delayedMask = new Ext.util.DelayedTask(function() {
                S && S.dom && S.addClass("mask"), r.delayedMask = null
            }), r.delayedMask.delay(n || 1)
        }
    },
    delayMask: function(t, e, i, o) {
        SYNO.SDS.VideoStation2.Util.mask(t, e, i, o, 500)
    },
    unmask: function(t) {
        var e;
        if (t && (e = t.getEl())) {
            e.delayedMask && (e.delayedMask.cancel(), e.delayedMask = null);
            var i = e.down(".ext-el-mask");
            i && (e.delayedUnmask || (i.addClass("unmask"), e.delayedUnmask = new Ext.util.DelayedTask(function() {
                e.unmask(), e.delayedUnmask = null
            })), e.delayedUnmask.delay(300))
        }
    },
    maskLoading: function(t, e) {
        var i = _T("common", "loading");
        SYNO.SDS.VideoStation2.Util.maskLoadingMsg(t, i, e)
    },
    maskLoadingMsg: function(t, e, i) {
        SYNO.SDS.VideoStation2.Util[i ? "delayMask" : "mask"](t, e, "x-mask-loading syno-vs2-mask-loading")
    },
    maskInfo: function(t, e, i, o, n) {
        SYNO.SDS.VideoStation2.Util[o ? "delayMask" : "mask"](t, e, "syno-ux-mask-info syno-vs2-mask-info", i, null, n)
    },
    findValueInObject: function(t, e) {
        var i;
        return Ext.iterate(t, function(t, o) {
            if (t === e) return i = o, !1;
            if (Ext.isObject(o)) {
                var n = SYNO.SDS.VideoStation2.Util.findValueInObject(o, e);
                if (Ext.isDefined(n)) return i = n, !1
            }
        }), i
    },
    launchHelp: function() {
        SYNO.SDS.WindowLaunch("SYNO.SDS.HelpBrowser.Application", {
            topic: "SYNO.SDS.VideoStation.AppInstance"
        })
    },
    getPathTitleForEpisode: function(t, e) {
        var i = [t > 0 ? String.format(_VST("episode", "title"), t) : _VST("metadata", "unknown")];
        return Ext.isEmpty(e) || i.push(e), i.join(" - ")
    },
    getPathTitleForOfflineEpisode: function(t) {
        var e = [t.title],
            i = "";
        return 0 < t.season && (i = String.format("S{0}", t.season)), 0 < t.episode && (i += String.format("E{0}", t.episode)), Ext.isEmpty(i) || e.push(i), Ext.isEmpty(t.tagline) || e.push(t.tagline), e.join(" - ")
    },
    getLibraryTypeByVideoType: function(t) {
        return t === SYNO.SDS.VideoStation2.Constant.TVSHOW_EPISODE ? SYNO.SDS.VideoStation2.Constant.TVSHOW : t
    },
    getTVShowEpisodeTitle: function(t) {
        var e = t.episode > 0 ? String.format(_VST("episode", "title"), t.episode) : _VST("metadata", "unknown");
        return Ext.isString(t.tagline) && !Ext.isEmpty(t.tagline) ? t.tagline : e
    },
    getTVShowEpisodeDescription: function(t) {
        return t.episode > 0 ? String.format(_VST("episode", "title"), t.episode) : ""
    },
    parseLazyDate: function(t, e, i) {
        e = e || "-", i = i || ":";
        var o = t.split(" "),
            n = [],
            a = [];
        return 1 <= o.length && (n = o[0].split(e)), 2 <= o.length && (a = o[1].split(i)), {
            year: 1 <= n.length ? parseInt(n[0], 10) : 1970,
            month: 2 <= n.length ? parseInt(n[1], 10) : 1,
            day: 3 <= n.length ? parseInt(n[2], 10) : 1,
            hour: 1 <= a.length ? parseInt(a[0], 10) : 0,
            minute: 2 <= a.length ? parseInt(a[1], 10) : 0,
            second: 3 <= a.length ? parseInt(a[2], 10) : 0
        }
    },
    lengthValidator: function(t, e) {
        return window.unescape(encodeURIComponent(t)).length <= e
    },
    copyTextFieldContent: function(t) {
        var e = Ext.getCmp(t),
            i = e.readOnly;
        e.setReadOnly(!1), e.focus(!0, 0), document.execCommand("copy"), e.setReadOnly(i)
    }
}), Ext.define("SYNO.SDS.VideoStation2.FilteringBaseProxy", {
    extend: "SYNO.API.Proxy",
    constructor: function(t) {
        this.callParent([t])
    },
    onRequestAPI: function(t, e, i, o, n, a, r, S, s) {
        try {
            var d = n.getRoot(e);
            Ext.each(d, function(t) {
                Ext.isObject(t.additional) && (t.additional.collection && (t.additional.collection = SYNO.SDS.VideoStation2.Util.convertCollectionID(t.additional.collection)), t.additional.extra && (t.additional.extra = Ext.decode(t.additional.extra)), t.additional.tvshow_extra && (t.additional.tvshow_extra = Ext.decode(t.additional.tvshow_extra)))
            }, this), this.callParent(arguments)
        } catch (t) {
            return this.fireEvent("loadexception", this, S, e, t), void this.fireEvent("exception", this, "response", s, S, e, t)
        }
    }
}), Ext.define("SYNO.SDS.VideoStation2.ByFolderProxy", {
    extend: "SYNO.API.Proxy",
    constructor: function(t) {
        this.callParent([t])
    },
    onRequestAPI: function(t, e, i, o, n, a, r, S, s) {
        try {
            var d = 0,
                l = n.getRoot(e);
            Ext.each(l, function(t) {
                t.additional && t.additional.collection && (t.additional.collection = SYNO.SDS.VideoStation2.Util.convertCollectionID(t.additional.collection)), SYNO.SDS.VideoStation2.Constant.FOLDER === t.type && (d += 1)
            }, this), 0 < d && (l[d - 1].last_folder = !0), this.callParent(arguments)
        } catch (t) {
            return this.fireEvent("loadexception", this, S, e, t), void this.fireEvent("exception", this, "response", s, S, e, t)
        }
    }
}), Ext.define("SYNO.SDS.VideoStation2.FilterMetadataProxy", {
    extend: "SYNO.API.Proxy",
    constructor: function(t) {
        this.callParent([t])
    },
    onRequestAPI: function(t, e, i, o, n, a, r, S, s) {
        e.metadata = e.metadata.map(function(t) {
            return {
                key: t,
                value: t
            }
        }), this.callParent(arguments)
    }
}), Ext.define("SYNO.SDS.VideoStation2.Util.Styles", {
    singleton: !0,
    updateMarginBySelector: function(t, e, i, o, n) {
        var a, r, S = SYNO.SDS.VideoStation2.Util.Styles;
        if (S.styleRules || (S.styleRules = {}), r = S.getVideoStyleRule(t)) {
            var s = i - 32 + n;
            s = 0 >= s ? i : s, a = Math.floor(s / (o + n)), a < 1 && (a = 1), r.style[e] = String.format("calc(99% / {0} - {1}px)", a, o)
        }
    },
    getVideoStyleRule: function(t) {
        var e, i = SYNO.SDS.VideoStation2.Util.Styles;
        if (i.styleRules[t]) return i.styleRules[t];
        if (!document.styleSheets) return null;
        for (e = document.styleSheets.length - 1; e >= 0; e--)
            if (Ext.isString(document.styleSheets[e].href) && document.styleSheets[e].href.indexOf("/VideoStation/style.css") >= 0) return i.styleRules[t] = i.getRuleBySelector(document.styleSheets[e], t), i.styleRules[t];
        return null
    },
    getRuleBySelector: function(t, e) {
        var i, o, n;
        if (!t.rules) return null;
        for (i = 0, o = t.rules.length; i < o; i++)
            if (n = t.rules[i], Ext.isString(n.selectorText) && n.selectorText === e) return n;
        return null
    }
}), Ext.define("SYNO.SDS.VideoStation2.AppBackupEdit.Window", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(t) {
        var e = {
            width: 640,
            height: 420,
            autoScroll: !0,
            closable: !0,
            title: _VST("backup", "config_title"),
            onEsc: function() {
                this.close()
            },
            items: [new SYNO.SDS.VideoStation2.AppBackupEdit.Panel({
                itemId: "data_panel",
                config: t.config
            })],
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: this.close
            }, {
                text: _T("common", "apply"),
                btnStyle: "blue",
                scope: this,
                handler: this.onApplyClick
            }]
        };
        Ext.apply(e, t), this.callParent([e])
    },
    getConfig: function() {
        return this.getComponent("data_panel").getConfig()
    },
    onApplyClick: function() {
        this.submitFn(this.getConfig()), this.close()
    }
}), 
/**
 * @class SYNO.SDS.VideoStation2.AppBackupEdit.Panel
 * @extends SYNO.ux.FormPanel
 * VideoStation backup edit panel class
 *
 */
Ext.define("SYNO.SDS.VideoStation2.AppBackupEdit.Panel", {
    extend: "SYNO.ux.FormPanel",
    textWidth: 270,
    constructor: function(t) {
        this._conf = t.config;
        var e = {
            items: [{
                xtype: "syno_displayfield",
                value: _VST("backup", "description")
            }],
            autoWidth: !0,
            autoHeight: !0
        };
        this.getStore(), this.callParent([Ext.apply(e, t)])
    },
    getConfig: function() {
        return this.getForm().getValues()
    },
    getStore: function() {
        return this._store = this._store || new Ext.data.JsonStore({
            autoLoad: !0,
            autoDestroy: !0,
            root: "data.folders",
            baseParams: {
                action: "list-all-path"
            },
            fields: ["path"],
            proxy: new Ext.data.HttpProxy({
                url: SYNO.SDS.VideoStation2.Util.getCGIURL("folder_manage.cgi"),
                listeners: {
                    scope: this,
                    beforeload: SYNO.SDS.VideoStation2.Util.onProxyBeforeLoad
                }
            }),
            listeners: {
                scope: this,
                load: this.onDataLoad
            }
        }), this._store
    },
    onDataLoad: function(t, e) {
        var i = [],
            o = "" !== this._conf;
        t.each(function(t) {
            var e = new SYNO.ux.Checkbox({
                name: t.data.path,
                boxLabel: t.data.path,
                checked: !o || this._conf[t.data.path]
            });
            i.push(e)
        }, this), this.add(i), this.doLayout()
    }
});
