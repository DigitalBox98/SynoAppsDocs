/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.SynologyDriveShareSync.View.Tray.TrayPanel
 * @extends SYNO.SDS.Tray.Panel
 * SynologyDrive share sync view tray panel class
 *
 */
Ext.define("SYNO.SDS.SynologyDriveShareSync.View.Tray.TrayPanel", {
    extend: "SYNO.SDS.Tray.Panel",
    constructor: function(a) {
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(b) {
        var a = {
            id: "syno-sdss-tray",
            itemId: "trayPanel",
            hidden: true,
            floating: true,
            shadow: false,
            title: _SDSSAPPNAME,
            cls: "syno-sdss",
            renderTo: document.body,
            items: [{
                itemId: "menu",
                xtype: "syno_menu",
                cls: "syno-sdss-menu",
                style: "z-index: 15000",
                floating: false,
                plain: true,
                items: [{
                    itemId: "sync_status_item",
                    text: "",
                    cls: "syno-sdss-menu-status-item",
                    iconCls: "sds-user-menu-options",
                    disabled: true
                }, {
                    itemId: "sync_status_description",
                    text: "-",
                    cls: "syno-sdss-menu-status-description",
                    iconCls: "syno-sdss-menu-icon",
                    disabled: true,
                    hidden: true
                }, "-", {
                    itemId: "resume_item",
                    text: _SDSS("tray", "resume"),
                    disabled: _S("demo_mode"),
                    tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                    hidden: true,
                    iconCls: "syno-sdss-menu-icon resume",
                    overCls: "syno-sdss-menu-over",
                    listeners: {
                        render: function(c) {
                            c.el.addClassOnClick("syno-sdss-menu-click")
                        }
                    }
                }, {
                    itemId: "pause_item",
                    text: _SDSS("tray", "pause"),
                    disabled: _S("demo_mode"),
                    tooltip: _S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                    iconCls: "syno-sdss-menu-icon pause",
                    overCls: "syno-sdss-menu-over",
                    listeners: {
                        render: function(c) {
                            c.el.addClassOnClick("syno-sdss-menu-click")
                        }
                    }
                }, "-", {
                    itemId: "sync_folder_item",
                    text: _SDSS("tray", "opendir"),
                    iconCls: "syno-sdss-menu-icon folder",
                    overCls: "syno-sdss-menu-over",
                    listeners: {
                        render: function(c) {
                            c.el.addClassOnClick("syno-sdss-menu-click")
                        }
                    },
                    menu: {
                        itemId: "syno-sdss-tray-opensycnfolder",
                        cls: "syno-sdss-menu syno-sdss-submenu",
                        listeners: {
                            afterlayout: this.adjustMenuPosition
                        },
                        items: [{
                            text: "(none)",
                            disabled: true
                        }]
                    }
                }, {
                    itemId: "recent_change_item",
                    text: _SDSS("tray", "updatedfile"),
                    iconCls: "syno-sdss-menu-icon recent",
                    overCls: "syno-sdss-menu-over",
                    listeners: {
                        render: function(c) {
                            c.el.addClassOnClick("syno-sdss-menu-click")
                        }
                    },
                    menu: {
                        itemId: "syno-sdss-tray-recentchange",
                        cls: "syno-sdss-menu syno-sdss-submenu",
                        listeners: {
                            afterlayout: this.adjustMenuPosition
                        },
                        items: [{
                            text: "(none)",
                            disabled: true
                        }]
                    }
                }, "-", {
                    itemId: "syno-sdss-tray-launchapp",
                    text: _SDSS("tray", "launch", _SDSSAPPNAME),
                    iconCls: "syno-sdss-menu-icon launch",
                    overCls: "syno-sdss-menu-over",
                    listeners: {
                        render: function(c) {
                            c.el.addClassOnClick("syno-sdss-menu-click")
                        }
                    }
                }]
            }]
        };
        return Ext.apply(a, b)
    },
    adjustMenuPosition: function(b) {
        if (!b.el || b.hidden || b.parentMenu.ownerCt.hidden || b.items.getCount() === 0) {
            return
        }
        var a = b.el.getAlignToXY(b.initialConfig.ownerCt.el, b.parentMenu.subMenuAlign || "tl-tr?", b.defaultOffsets);
        if (b.enableScrolling) {
            b.el.setXY(a);
            a[1] = b.constrainScroll(a[1]);
            a = [b.el.adjustForConstraints(a)[0], a[1]]
        } else {
            a = b.el.adjustForConstraints(a)
        }
        b.el.setXY(a)
    }
});
Ext.ns("SYNO.SDS.SynologyDriveShareSync.View.Tray");
Ext.define("SYNO.SDS.SynologyDriveShareSync.View.Tray.Viewport", {
    extend: "SYNO.SDS.Tray.ArrowTray",
    initPanel: function() {
        var a = this;
        return new SYNO.SDS.SynologyDriveShareSync.View.Tray.TrayPanel({
            module: a
        })
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.Controller.Tray", {
    extend: "SYNO.SDS.SynologyDriveShareSync.core.Controller",
    statics: {
        UPDATE_STATUS_INTERVAL: 10 * 1000,
        UPDATE_STATUS_INTERVAL_FAST: 5 * 1000,
        LOAD_SHARE_FOLDER_INTERVAL: 5 * 1000,
        LOAD_RECENT_FILE_INTERVAL: 5 * 1000
    },
    init: function() {
        this.control({
            trayPanel: {
                beforeshow: function() {
                    this.updateStatusAjaxTask.applyInterval(this.self.UPDATE_STATUS_INTERVAL_FAST);
                    this.updateStatusAjaxTask.restart(true);
                    this.createLoadShareFolderAjaxTask(true).run();
                    this.createLoadRecentFileAjaxTask(true).run()
                },
                hide: function() {
                    this.updateStatusAjaxTask.applyInterval(this.self.UPDATE_STATUS_INTERVAL);
                    this.recentFileAjaxTask.stop();
                    this.shareFolderAjaxTask.stop()
                }
            },
            "trayPanel menu sync_folder_item": {
                activate: function() {
                    this.shareFolderAjaxTask.start(false)
                },
                deactivate: function() {
                    this.shareFolderAjaxTask.stop()
                }
            },
            "trayPanel menu recent_change_item": {
                activate: function() {
                    this.recentFileAjaxTask.start(false)
                },
                deactivate: function() {
                    this.recentFileAjaxTask.stop()
                }
            },
            "trayPanel menu resume_item": {
                click: this.onClickResumeItem
            },
            "trayPanel menu pause_item": {
                click: this.onClickPauseItem
            },
            "trayPanel menu syno-sdss-tray-launchapp": {
                click: function() {
                    SYNO.SDS.AppLaunch("SYNO.SDS.SynologyDriveShareSync.Instance")
                }
            }
        });
        this.module = this.componentQuery("trayPanel").module;
        this.updateStatusAjaxTask = this.createUpdateStatusAjaxTask();
        this.shareFolderAjaxTask = this.createLoadShareFolderAjaxTask();
        this.recentFileAjaxTask = this.createLoadRecentFileAjaxTask();
        this.pre_update_count = -1;
        this.updateStatusAjaxTask.start(true)
    },
    onClickResumeItem: function(b, a) {
        this.getWebAPI().resume(0, function(f, c, e, d) {
            if (f) {
                this.updateStatusAjaxTask.restart(true)
            }
        }, this)
    },
    onClickPauseItem: function() {
        this.getWebAPI().pause(0, function(d, a, b, c) {
            if (d) {
                this.updateStatusAjaxTask.restart(true)
            }
        }, this)
    },
    showMsgWin: function(b, a) {
        SYNO.SDS.SystemTray.notifyMsg("SYNO.SDS.SynologyDriveShareSync.Instance", b, Ext.util.Format.htmlEncode(a))
    },
    createUpdateStatusAjaxTask: function(a) {
        var h = a || false,
            g = "",
            d = this.componentQuery("trayPanel menu sync_status_item"),
            b = this.componentQuery("trayPanel menu sync_status_description"),
            f = this.componentQuery("trayPanel menu pause_item"),
            e = this.componentQuery("trayPanel menu resume_item"),
            c = this.componentQuery("trayPanel");
        return this.addWebAPITask({
            interval: this.self.UPDATE_STATUS_INTERVAL,
            api: "SYNO.SynologyDriveShareSync.Connection",
            version: 1,
            method: "list",
            params: {
                additional: ["tray_status", "newest_change"]
            },
            single: h,
            callback: function(n, j, m, k) {
                var i = Ext.encode(j);
                if (i === g) {
                    return
                }
                g = i;
                if (!n) {
                    return
                }
                if (this.pre_update_count === -1) {
                    this.pre_update_count = j.update_count
                }
                if (j.newest_change && j.update_count !== this.pre_update_count && c.hidden === true) {
                    var l;
                    if (j.update_count - this.pre_update_count > 1) {
                        l = String.format(_SDSS("tray", "files_update"), j.update_count - this.pre_update_count)
                    } else {
                        if (j.newest_change.action === "delete") {
                            l = String.format(_SDSS("tray", "del_file"), j.newest_change.base_name)
                        } else {
                            l = String.format(_SDSS("tray", "add_file"), j.newest_change.base_name)
                        }
                    }
                    this.showMsgWin(_SDSSAPPNAME, l);
                    this.pre_update_count = j.update_count
                }
                if (j.total > 0) {
                    this.module.setTaskButtonVisible(true);
                    var o = "";
                    if (j.tray_status !== "unlink" && j.tray_status !== "uptodate" && j.tray_status !== "syncing" && j.tray_status !== "connecting" && j.tray_status !== "pause") {
                        o = "error"
                    } else {
                        o = j.tray_status
                    }
                    this.module.setIconClass("syno-sdss syno-sdss-tray-" + o + "-icon");
                    if (b) {
                        if (o === "error") {
                            d.setText(_SDSS("msg", "notify_abnormal_short"));
                            b.setVisible(true);
                            b.setText(SYNO.SDS.SynologyDriveShareSync.Util.MapStatusToString(j.tray_status))
                        } else {
                            d.setText(SYNO.SDS.SynologyDriveShareSync.Util.MapStatusToString(j.tray_status));
                            b.setVisible(false)
                        }
                    } else {
                        d.setText(SYNO.SDS.SynologyDriveShareSync.Util.MapStatusToString(j.tray_status))
                    }
                    d.setIconClass("syno-sdss-status-" + o + "-icon");
                    if (j.tray_status === "unlink") {
                        f.disable();
                        e.hide();
                        f.show()
                    } else {
                        if (!_S("demo_mode")) {
                            f.enable()
                        }
                        if (!j.is_pause) {
                            e.hide();
                            f.show()
                        } else {
                            e.show();
                            f.hide()
                        }
                    }
                } else {
                    this.module.setTaskButtonVisible(false)
                }
            },
            scope: this
        })
    },
    createLoadShareFolderAjaxTask: function(a) {
        var d = a || false,
            c = "",
            b = this.componentQuery("trayPanel menu sync_folder_item").menu;
        return this.addWebAPITask({
            interval: this.self.LOAD_SHARE_FOLDER_INTERVAL,
            api: "SYNO.SynologyDriveShareSync.Session",
            version: 1,
            method: "list_syncfolder",
            params: {},
            single: d,
            callback: function(j, e, i, h) {
                var f = Ext.encode(e);
                if (f === c) {
                    return
                }
                c = f;
                var g = e;
                b.removeAll();
                if (g.syncfolder_list.length === 0) {
                    b.addItem(new Ext.menu.Item({
                        text: "(none)",
                        disabled: true
                    }))
                }
                g.syncfolder_list.forEach(function(k) {
                    b.addItem(new Ext.menu.Item({
                        text: k.display_text,
                        ctCls: "syno-sdss-menu-folder-items",
                        iconCls: "syno-sdss-menu-folder",
                        overCls: "syno-sdss-menu-folder-items-over",
                        info: k,
                        handler: function(m, l) {
                            SYNO.SDS.AppLaunch("SYNO.SDS.App.FileStation3.Instance", {
                                opendir: m.info.folder_path
                            }, true)
                        },
                        listeners: {
                            render: function(l) {
                                l.el.addClassOnClick("syno-sdss-menu-folder-items-click")
                            }
                        }
                    }))
                })
            }
        })
    },
    createLoadRecentFileAjaxTask: function(a) {
        var d = a || false,
            c = "",
            b = this.componentQuery("trayPanel menu recent_change_item").menu;
        return this.addWebAPITask({
            interval: this.self.LOAD_RECENT_FILE_INTERVAL,
            api: "SYNO.SynologyDriveShareSync.Session",
            version: 1,
            method: "list_sync_history",
            params: {
                limit: 5,
                is_distinct: true
            },
            single: d,
            callback: function(l, j, k, h) {
                var f = Ext.encode(j);
                if (f === c) {
                    return
                }
                c = f;
                var e = 5;
                b.removeAll();
                if (j.history_items) {
                    e = 5 - j.history_items.length;
                    e = (e < 0) ? 0 : e;
                    j.history_items.forEach(function(i) {
                        b.addItem(new Ext.menu.Item({
                            text: function(n, o, p) {
                                var m = p ? "" : _SDSS("tray", "file_deleted") + ":";
                                return m + o + ":" + n
                            }(i.base_name, i.sync_folder, i.action),
                            ctCls: "syno-sdss-menu-recent-items",
                            overCls: "syno-sdss-menu-recent-items-over",
                            info: i,
                            handler: function(n, m) {
                                SYNO.SDS.AppLaunch("SYNO.SDS.App.FileStation3.Instance", {
                                    openfile: n.info.path
                                }, true)
                            },
                            listeners: {
                                render: function(m) {
                                    m.el.addClassOnClick("syno-sdss-menu-folder-items-click")
                                }
                            },
                            disabled: (i.action === "delete") ? true : false
                        }))
                    })
                }
                for (var g = 0; g < e; ++g) {
                    b.addItem(new Ext.menu.Item({
                        text: "(none)",
                        ctCls: "syno-sdss-menu-recent-items",
                        disabled: true
                    }))
                }
                if (j.processing_items) {
                    b.addSeparator();
                    j.processing_items.forEach(function(i) {
                        b.addItem(new Ext.menu.Item({
                            text: function(n, q, p, v, o) {
                                var r = "";
                                var u = "";
                                var m = "";
                                var t = 0;
                                var s = "B/s";
                                r = function(w) {
                                    if (w === "uploading") {
                                        return _SDSS("tray", "uploading")
                                    } else {
                                        if (w === "downloading") {
                                            return _SDSS("tray", "downloading")
                                        } else {
                                            return _SDSS("tray", "preparing")
                                        }
                                    }
                                }(q);
                                t = (p !== 0) ? Math.round(v / p * 100) : 0;
                                if (t > 100) {
                                    t = 100
                                }
                                if (t !== 0) {
                                    u = ", " + t + "%"
                                }
                                if (o > 1000) {
                                    o /= 1000;
                                    s = "KB/s"
                                }
                                if (o > 1000) {
                                    o /= 1000;
                                    s = "MB/s"
                                }
                                if (o > 1000) {
                                    o /= 1000;
                                    s = "GB/s"
                                }
                                if (o !== "0" && s !== "B/s") {
                                    m = ", " + o.toFixed(2) + " " + s
                                }
                                return n + " (" + r + u + m + " )"
                            }(i.base_name, i.status, i.total_size, i.current_size, i.bit_rate),
                            ctCls: "syno-sdss-menu-recent-items",
                            info: i,
                            disabled: true
                        }))
                    })
                }
            }
        })
    }
});
Ext.define("SYNO.SDS.SynologyDriveShareSync.TrayApp", {
    extend: "SYNO.SDS.SynologyDriveShareSync.core.App",
    appTrayItemName: "SYNO.SDS.SynologyDriveShareSync.View.Tray.Viewport",
    controllers: ["SYNO.SDS.SynologyDriveShareSync.Controller.Tray"],
    updateTrayStatus: function() {
        var a = this.getController("Tray").updateStatusAjaxTask;
        if (a) {
            a.restart(true)
        }
    },
    init: function() {
        if (SYNO.SDS.Strings["SYNO.SDS.SynologyDriveShareSync.TrayApp"] !== undefined) {
            SYNO.SDS.Strings["SYNO.SDS.SynologyDriveShareSync.Instance"] = SYNO.SDS.Strings["SYNO.SDS.SynologyDriveShareSync.TrayApp"];
            SYNO.SDS.Strings["SYNO.SDS.SynologyDriveShareSync.View.Tray.Viewport"] = SYNO.SDS.Strings["SYNO.SDS.SynologyDriveShareSync.TrayApp"]
        }
    }
});
