/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.Personal.Mail");

Ext.define("SYNO.Personal.Mail.Config", {
    singleton: true,
    btnStyle: "default",
    emailWizardStyle: {
        marginBottom: "4px"
    }
});
