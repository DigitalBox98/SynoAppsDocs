/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.Avatar.Container
 * @extends Ext.Container
 * ApplicationService avatar container 
 *
 */
Ext.define("SYNO.SDS.Avatar.Container", {
    extend: "Ext.Container",
    constructor: function(a) {
        var b = {
            useEmptyImg: true,
            items: [this.imgAvatar = new Ext.BoxComponent({
                itemId: "imgAvatar",
                cls: "img-avatar",
                autoEl: {
                    tag: "img"
                }
            }), this.fakeAvatar = new Ext.BoxComponent({
                itemId: "fakeAvatar",
                cls: "fake-avatar"
            })],
            listeners: {
                scope: this,
                afterrender: this.refreshAvatar
            }
        };
        if (a.size) {
            b.width = a.size;
            b.height = a.size
        }
        this.addEvents({
            showfake: true,
            showreal: true
        });
        this.callParent([Ext.apply(b, a)]);
        this.addClass("avatar")
    },
    refreshAvatar: function() {
        if (this.avatarURL) {
            this.updateAvatar(this.avatarURL)
        } else {
            if (this.useEmptyImg) {
                this.fakeAvatar.addClass("empty-img")
            }
            this._showFake()
        }
    },
    removeAvatar: function() {
        this.avatarURL = null;
        this.avatarChanged = false;
        this.refreshAvatar()
    },
    getAvatarURI: function() {
        return this.imgAvatar.el.dom.src
    },
    _showFake: function() {
        this.fakeAvatar.el.setStyle({
            display: "block"
        });
        this.imgAvatar.el.setStyle({
            display: "none"
        });
        this.fireEvent("showfake", this, {})
    },
    _showReal: function() {
        this.fakeAvatar.el.setStyle({
            display: "none"
        });
        this.imgAvatar.el.setStyle({
            display: "block"
        });
        this.fireEvent("showreal", this, {})
    },
    updateAvatar: function(a) {
        this.imgAvatar.el.dom.onerror = this._showFake.bind(this);
        this.imgAvatar.el.dom.src = a;
        this._showReal()
    }
});
Ext.define("SYNO.SDS.Avatar.Dialog", {
    extend: "SYNO.SDS.ModalWindow",
    EDITOR_WIDTH: 460,
    EDITOR_HEIGHT: 400,
    CROP_VIEWPORT_SIZE_MAX: 400,
    CROP_VIEWPORT_SIZE_MIN: 100,
    constructor: function(b) {
        this.dataURL = b.dataURL;
        var f = b.EDITOR_WIDTH || this.EDITOR_WIDTH,
            a = b.EDITOR_HEIGHT || this.EDITOR_HEIGHT,
            c = b.CROP_VIEWPORT_SIZE_MIN || this.CROP_VIEWPORT_SIZE_MIN,
            e = b.CROP_VIEWPORT_SIZE_MAX ? b.CROP_VIEWPORT_SIZE_MAX : Math.max(f || this.CROP_VIEWPORT_SIZE_MAX);
        var d = {
            width: 500,
            height: 560,
            resizable: false,
            title: _TT("SYNO.Application.Service.Instance", "common", "avatar_crop_photo"),
            cls: "edit-avatar-dialog",
            padding: "0 20px",
            items: [this.descField = new Ext.BoxComponent({
                cls: "desc",
                html: _TT("SYNO.Application.Service.Instance", "common", "avatar_drag_drop")
            }), this.avatarEditor = new SYNO.SDS.Avatar.Editor({
                width: f,
                height: a,
                cropViewportSizeMin: c,
                cropViewportSizeMax: e,
                dataURL: this.dataURL
            })],
            buttons: SYNO.SDS.Avatar.Utils.reorderFooterButtons(Ext.apply({
                xtype: "syno_button",
                text: _T("common", "commit"),
                btnStyle: "blue",
                handler: this.onConfirmAvatar,
                scope: this
            }, (b.buttonCfg || {}).confirm), Ext.apply({
                xtype: "syno_button",
                text: _T("common", "cancel"),
                handler: this.close,
                scope: this
            }, (b.buttonCfg || {}).cancel)),
            listeners: {
                scope: this,
                beforeshow: this.onBeforeShow,
                afterrender: this.onAfterRender,
                move: this.onMove,
                resize: this.onResize
            }
        };
        this.callParent([Ext.apply(d, b || {})])
    },
    onBeforeShow: function() {
        if (!this.avatarEditor.isLoaded) {
            return false
        }
        if (!this.avatarEditor.isImageOK()) {
            this.owner.getMsgBox().alert("", _TT("SYNO.Application.Service.Instance", "common", "avatar_broken_image"));
            this.close.defer(100, this);
            return false
        }
        return true
    },
    onAfterRender: function() {
        this.mon(this.avatarEditor, "errorimage", this.onErrorImage, this);
        this.mon(this.avatarEditor, "loaded", this.onLoadedImage, this)
    },
    onLoadedImage: function() {
        this.avatarEditor.initRatio();
        this.avatarEditor.initResizer();
        this.show()
    },
    onErrorImage: function() {
        this.owner.getMsgBox().alert("", "broken image");
        this.close()
    },
    onConfirmAvatar: function() {
        var a = this.avatarEditor.getCurrentCropDataURL();
        if (!a) {
            return
        }
        this.fireEvent("avatarchanged", a);
        this.close()
    },
    onMove: function() {
        this.avatarEditor.updateResizerConstrain()
    },
    onResize: function() {
        this.avatarEditor.updateResizerConstrain()
    }
});
Ext.define("SYNO.SDS.Avatar.Editor", {
    extend: "Ext.Container",
    blConstraintMask: false,
    constructor: function(a) {
        this.dataURL = a.dataURL;
        var b = {
            cls: "avatar-editor",
            items: [this.baseImg = new Ext.BoxComponent({
                cls: "avatar-img base-img",
                itemId: "baseImg",
                autoEl: {
                    tag: "img",
                    src: this.dataURL
                }
            }), this.baseImgMask = new Ext.BoxComponent({
                cls: "base-img-mask"
            }), this.cropViewportWrapper = new Ext.Container({
                cls: "crop-viewport-wrapper",
                items: [this.cropViewport = new Ext.Container({
                    cls: "crop-viewport",
                    itemId: "cropViewport",
                    items: [this.cropImg = new Ext.BoxComponent({
                        cls: "avatar-img crop-img",
                        itemId: "cropImg",
                        autoEl: {
                            tag: "img",
                            src: this.dataURL
                        }
                    })]
                })]
            }), {
                xtype: "box",
                itemId: "canvas",
                autoEl: {
                    tag: "canvas"
                },
                style: {
                    position: "absolute",
                    top: "-10000px",
                    left: "-10000px"
                }
            }],
            listeners: {
                scope: this,
                afterrender: this.onAfterRender,
                beforedestroy: this.onBeforeDestroy
            }
        };
        this.callParent([Ext.apply(b, a || {})])
    },
    onAfterRender: function() {
        this.canvas = this.getComponent("canvas").el.dom;
        this.baseImg.el.dom.onload = this.onImgLoaded.bind(this)
    },
    onImgLoaded: function() {
        this.isLoaded = true;
        this.fireEvent("loaded")
    },
    isImageOK: function() {
        var a = this.canvas.getContext("2d");
        try {
            a.drawImage(this.baseImg.el.dom, 0, 0)
        } catch (b) {
            return false
        }
        return true
    },
    initRatio: function() {
        var e = this.baseImg.el.dom;
        var c = e.width / this.getWidth();
        var f = e.height / this.getHeight();
        if (c === 0 || f === 0) {
            this.fireEvent("errorimage");
            return
        }
        this.ratio = (c > f) ? c : f;
        var d = e.width / this.ratio;
        var a = e.height / this.ratio;
        var b = (this.cropViewportSizeMax + this.cropViewportSizeMin) / 2;
        this.setEditAreaSize(d, a);
        SmartCrop.crop(this.baseImg.el.dom, {
            width: b,
            height: b
        }, function(h) {
            var i = h.topCrop,
                g = Math.floor(i.x / this.ratio + this.baseImgOffset.left),
                k = Math.floor(i.y / this.ratio + this.baseImgOffset.top),
                j = Math.floor(Math.min(i.width, i.height) / this.ratio);
            this.setCropViewportSize(j);
            this.setCropViewportOffset(g, k)
        }.bind(this))
    },
    onBeforeDestroy: function() {
        if (this.cropViewportResizer) {
            this.cropViewportResizer.destroy()
        }
    },
    onCropViewportDrag: function() {
        this.adjustCropImageOffset()
    },
    onCropViewportResize: function() {
        this.adjustCropImageOffset()
    },
    initResizer: function() {
        this.cropViewportResizer = new Ext.Resizable(this.cropViewportWrapper.el.dom.id, {
            handles: "all",
            minWidth: this.cropViewportSizeMin,
            maxWidth: this.cropViewportSizeMax,
            minHeight: this.cropViewportSizeMin,
            maxHeight: this.cropViewportSizeMax,
            pinned: true,
            draggable: true,
            preserveRatio: true,
            dynamic: true,
            constrainTo: this.baseImg.el.dom.id
        });
        this.cropViewportResizer.dd.onDrag = this.onCropViewportDrag.bind(this);
        var a = this.cropViewportResizer.resizeElement;
        this.cropViewportResizer.resizeElement = function() {
            var b = a.apply(this.cropViewportResizer, arguments);
            this.onCropViewportResize();
            return b
        }.bind(this);
        this.cropViewportResizer.onMouseMove = function(u) {
            if (this.enabled && this.activeHandle) {
                try {
                    var r = this.curSize || this.startBox,
                        j = this.startBox.x,
                        i = this.startBox.y,
                        k = r.width,
                        s = r.height,
                        c = k,
                        m = s,
                        l = this.minWidth,
                        v = this.minHeight,
                        p = this.maxWidth,
                        B = this.maxHeight,
                        f = this.widthIncrement,
                        b = this.heightIncrement,
                        z = u.getXY(),
                        q = -(this.startPoint[0] - Math.max(this.minX, z[0])),
                        n = -(this.startPoint[1] - Math.max(this.minY, z[1])),
                        g = this.activeHandle.position,
                        C, d;
                    switch (g) {
                        case "east":
                            k += q;
                            k = Math.min(Math.max(l, k), p);
                            break;
                        case "south":
                            s += n;
                            s = Math.min(Math.max(v, s), B);
                            break;
                        case "southeast":
                            k += q;
                            s += n;
                            k = Math.min(Math.max(l, k), p);
                            s = Math.min(Math.max(v, s), B);
                            break;
                        case "north":
                            n = this.constrain(s, n, v, B);
                            i += n;
                            s -= n;
                            break;
                        case "west":
                            q = this.constrain(k, q, l, p);
                            j += q;
                            k -= q;
                            break;
                        case "northeast":
                            k += q;
                            k = Math.min(Math.max(l, k), p);
                            n = this.constrain(s, n, v, B);
                            i += n;
                            s -= n;
                            break;
                        case "northwest":
                            q = this.constrain(k, q, l, p);
                            n = this.constrain(s, n, v, B);
                            i += n;
                            s -= n;
                            j += q;
                            k -= q;
                            break;
                        case "southwest":
                            q = this.constrain(k, q, l, p);
                            s += n;
                            s = Math.min(Math.max(v, s), B);
                            j += q;
                            k -= q;
                            break
                    }
                    var o = this.snap(k, f, l);
                    var A = this.snap(s, b, v);
                    if (o != k || A != s) {
                        switch (g) {
                            case "northeast":
                                i -= A - s;
                                break;
                            case "north":
                                i -= A - s;
                                break;
                            case "southwest":
                                j -= o - k;
                                break;
                            case "west":
                                j -= o - k;
                                break;
                            case "northwest":
                                j -= o - k;
                                i -= A - s;
                                break
                        }
                        k = o;
                        s = A
                    }
                    if (this.preserveRatio) {
                        switch (g) {
                            case "southeast":
                            case "east":
                                s = m * (k / c);
                                s = Math.min(Math.max(v, s), B);
                                k = c * (s / m);
                                break;
                            case "south":
                                k = c * (s / m);
                                k = Math.min(Math.max(l, k), p);
                                s = m * (k / c);
                                break;
                            case "northeast":
                                k = c * (s / m);
                                k = Math.min(Math.max(l, k), p);
                                s = m * (k / c);
                                break;
                            case "north":
                                C = k;
                                k = c * (s / m);
                                k = Math.min(Math.max(l, k), p);
                                s = m * (k / c);
                                j += (C - k) / 2;
                                break;
                            case "southwest":
                                s = m * (k / c);
                                s = Math.min(Math.max(v, s), B);
                                C = k;
                                k = c * (s / m);
                                j += C - k;
                                break;
                            case "west":
                                d = s;
                                s = m * (k / c);
                                s = Math.min(Math.max(v, s), B);
                                i += (d - s) / 2;
                                C = k;
                                k = c * (s / m);
                                j += C - k;
                                break;
                            case "northwest":
                                C = k;
                                d = s;
                                s = m * (k / c);
                                s = Math.min(Math.max(v, s), B);
                                k = c * (s / m);
                                i += d - s;
                                j += C - k;
                                break
                        }
                    }
                    if (this.resizeRegion && !this.resizeRegion.contains({
                            top: i,
                            left: j,
                            right: j + k,
                            bottom: i + s
                        })) {
                        return
                    }
                    this.proxy.setBounds(j, i, k, s);
                    if (this.dynamic) {
                        this.resizeElement()
                    }
                } catch (t) {}
            }
        }
    },
    updateResizerConstrain: function() {
        if (!this.cropViewportResizer) {
            return
        }
        this.cropViewportResizer.dd.constrainTo(this.cropViewportResizer.constrainTo)
    },
    adjustCropImageOffset: function() {
        this.setCropViewportOffset(this.cropViewportWrapper.el.getLeft(true), this.cropViewportWrapper.el.getTop(true))
    },
    setEditAreaSize: function(b, a) {
        this.baseImg.el.dom.width = b;
        this.baseImg.el.dom.height = a;
        this.cropImg.el.dom.width = b;
        this.cropImg.el.dom.height = a;
        this.baseImgOffset = {
            left: (this.getWidth() - b) / 2,
            top: (this.getHeight() - a) / 2
        };
        this.baseImg.el.setLeftTop(this.baseImgOffset.left, this.baseImgOffset.top);
        if (this.blConstraintMask) {
            this.baseImgMask.el.setWidth(b);
            this.baseImgMask.el.setHeight(a);
            this.baseImgMask.el.setLeftTop(this.baseImgOffset.left, this.baseImgOffset.top)
        }
    },
    setCropViewportSize: function(a) {
        if (!this.checkSetCropViewportSize(a)) {
            return
        }
        this.cropViewportWrapper.setSize(a, a)
    },
    checkSetCropViewportSize: function(a) {
        if (a > this.cropViewportSizeMax || a < this.cropViewportSizeMin) {
            return false
        }
        if (this.cropViewportWrapper.el.getLeft(true) + a > this.getWidth()) {
            return false
        }
        if (this.cropViewportWrapper.el.getTop(true) + a > this.getHeight()) {
            return false
        }
        return true
    },
    setCropViewportOffset: function(b, a) {
        if (!this.checkSetCropViewportOffset(b, a)) {
            return
        }
        this.cropViewportWrapper.el.setLeftTop(b, a);
        this.cropImg.el.setLeftTop(this.baseImgOffset.left - b, this.baseImgOffset.top - a)
    },
    checkSetCropViewportOffset: function(b, a) {
        if (b + this.cropViewportWrapper.getWidth() > this.getWidth()) {
            return false
        }
        if (a + this.cropViewportWrapper.getHeight() > this.getHeight()) {
            return false
        }
        return true
    },
    getCurrentCropDataURL: function() {
        this.canvas.width = this.cropViewport.getWidth();
        this.canvas.height = this.cropViewport.getHeight();
        var a = this.canvas.getContext("2d");
        a.transform(1 / this.ratio, 0, 0, 1 / this.ratio, this.baseImgOffset.left - this.cropViewportWrapper.el.getLeft(true), this.baseImgOffset.top - this.cropViewportWrapper.el.getTop(true));
        a.drawImage(this.baseImg.el.dom, 0, 0);
        return this.canvas.toDataURL("image/png")
    }
});
Ext.define("SYNO.Application.Service.Instance", {
    extend: "SYNO.SDS.AppInstance"
});
Ext.define("SYNO.SDS.Profile.Defaults", {
    statics: {
        getFieldNames: function() {
            return {
                username: "userName",
                nickname: "nickName",
                desc: "title",
                email: "email",
                emails: "emails",
                avatar: "photo",
                lang: "preferredLanguage",
                timezone: "timezone"
            }
        }
    }
});
Ext.define("SYNO.SDS.Profile.FormPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(b) {
        b = b || {};
        b.fieldNames = b.fieldNames || {};
        Ext.applyIf(b.fieldNames, SYNO.SDS.Profile.Defaults.getFieldNames());
        Ext.applyIf(b, {
            isMultiEmail: false
        });
        var a = b.userInfo;
        var c = {
            padding: 0,
            defaults: {
                anchor: "100%"
            },
            trackResetOnLoad: true,
            labelAlign: "top",
            items: [{
                xtype: "syno_displayfield",
                cls: "profile-panel-user",
                hideLabel: true,
                name: b.fieldNames.username,
                value: (a) ? a[b.fieldNames.username] : ""
            }, {
                xtype: "syno_textfield",
                cls: "profile-panel-nickname",
                fieldLabel: _TT("SYNO.Application.Service.Instance", "common", "nickname"),
                maxLength: 32,
                regex: /^[^~!@{}<>`\|?#$%^&*\(\)\+\\\[\]'":;,\/=]+$/,
                name: b.fieldNames.nickname,
                value: (a) ? a[b.fieldNames.nickname] : "",
                invalidText: _TT("SYNO.Application.Service.Instance", "error", "invalid_nickname")
            }, {
                xtype: "syno_textarea",
                cls: "profile-panel-desc",
                fieldLabel: _TT("SYNO.Application.Service.Instance", "common", "description"),
                name: b.fieldNames.desc,
                maxLength: 256,
                value: (a) ? a[b.fieldNames.desc] : ""
            }, this.emailField = this.createEmailField(b), {
                xtype: "syno_combobox",
                cls: "profile-panel-language",
                fieldLabel: _TT("SYNO.Application.Service.Instance", "common", "language"),
                displayField: "display",
                valueField: "value",
                name: b.fieldNames.lang,
                store: this.getLangStore(),
                value: (a) ? a[b.fieldNames.lang] || "def" : "def"
            }, {
                xtype: "syno_combobox",
                cls: "profile-panel-timezone",
                fieldLabel: _TT("SYNO.Application.Service.Instance", "common", "timezone"),
                displayField: "display",
                valueField: "value",
                hidden: b.tzHidden,
                name: b.fieldNames.timezone,
                store: this.getTZoneStore(),
                value: (a) ? a[b.fieldNames.timezone] || "def" : "def"
            }].concat(b.additionalFields || [])
        };
        this.callParent([Ext.apply(c, b)]);
        this.mon(this, "afterlayout", this.onFirstLayout, this, {
            single: true
        });
        if (b.isMultiEmail) {
            this.mon(this.emailField, "newitem", this.onEmailNewItem, this)
        }
    },
    onFirstLayout: function() {
        if (this.descHeight) {
            this.form.findField(this.fieldNames.desc).setHeight(this.descHeight)
        }
    },
    createEmailField: function(a) {
        if (!a.isMultiEmail) {
            return new SYNO.ux.TextField({
                cls: "profile-panel-email",
                fieldLabel: _TT("SYNO.Application.Service.Instance", "common", "email"),
                maxLength: 128,
                vtype: "email",
                name: a.fieldNames.email,
                value: (a.userInfo) ? a.userInfo[a.fieldNames.email] : ""
            })
        }
        return new SYNO.ux.SuperBoxSelect({
            cls: "profile-panel-email",
            fieldLabel: _TT("SYNO.Application.Service.Instance", "common", "email"),
            displayField: "display",
            valueField: "value",
            name: a.fieldNames.emails,
            store: this.getEmailStore(),
            mode: "local",
            maxLength: 128,
            hideTrigger: true,
            typeAhead: false,
            vtype: "email",
            allowAddNewData: true,
            addNewDataOnBlur: true,
            value: (a.userInfo) ? a.userInfo[a.fieldNames.emails] : "",
            initValue: function() {
                this.originalValue = this.getValue();
                if (this.mode === "remote") {
                    this.setOriginal = true
                }
            }
        })
    },
    onEmailNewItem: function(b, a) {
        if ("" === a) {
            return
        }
        b.addNewItem({
            value: a,
            display: a
        }, true)
    },
    getEmailStore: function() {
        if (!this.emailStore) {
            this.emailStore = new Ext.data.SimpleStore({
                fields: ["value", "display"],
                data: [],
                sortInfo: {
                    field: "display",
                    direction: "ASC"
                }
            })
        }
        return this.emailStore
    },
    getLangStore: function() {
        var b = SYNO.SDS.Utils.getSupportedLanguage(),
            a;
        b.unshift(["def", _TT("SYNO.Application.Service.Instance", "common", "def_lang")]);
        a = new Ext.data.SimpleStore({
            fields: ["value", "display"],
            data: b
        });
        return a
    },
    getTZoneStore: function() {
        if (Ext.isDefined(this.tZoneStore)) {
            return this.tZoneStore
        }
        if (Ext.isDefined(SYNO.SDS.Utils.getTimeZoneData)) {
            var b = SYNO.SDS.Utils.getTimeZoneData();
            var a = [];
            a.push(["def", _TT("SYNO.Application.Service.Instance", "common", "def_lang")]);
            Ext.each(b, function(c) {
                a.push([c.value, c.display])
            });
            this.tZoneStore = new Ext.data.SimpleStore({
                fields: ["value", "display"],
                data: a
            })
        } else {
            this.tZoneStore = new SYNO.API.JsonStore({
                appWindow: {
                    findAppWindow: Ext.emptyFn
                },
                autoDestroy: true,
                autoLoad: false,
                api: "SYNO.Core.Region.NTP",
                method: "listzone",
                root: "zonedata",
                version: 1,
                idProperty: "value",
                fields: ["value", "display"],
                sortData: Ext.emptyFn,
                listeners: {
                    load: function(c) {
                        c.insert(0, [new Ext.data.Record({
                            value: "def",
                            display: _TT("SYNO.Application.Service.Instance", "common", "def_lang")
                        })])
                    }
                }
            });
            this.tZoneStore.load()
        }
        return this.tZoneStore
    },
    getFieldNames: function() {
        return this.fieldNames
    },
    loadProfile: function(a) {
        this.profileRec = new Ext.data.Record(a);
        this.getForm().loadRecord(this.profileRec)
    },
    getLangField: function() {
        return this.getForm().findField(this.fieldNames.lang)
    },
    getApplyWebAPI: function() {
        var a = this.getForm(),
            b = a.getValues();
        if (!a.isDirty()) {
            return null
        }
        if (b.emails && "string" === typeof b.emails) {
            b.emails = [b.emails]
        }
        return {
            api: "SYNO.Personal.Profile",
            method: "set",
            version: 1,
            params: b
        }
    }
});
Ext.define("SYNO.SDS.Avatar.CancelMask", {
    extend: "Ext.BoxComponent",
    constructor: function(a) {
        Ext.apply(this, a);
        var b = {
            hidden: true,
            cls: "cancel-mask"
        };
        this.callParent([Ext.apply(b, a)]);
        if (this.avatar) {
            this.mon(this.avatar, "showfake", this.hide, this);
            this.mon(this.avatar, "showreal", this.show, this)
        }
    },
    findWindow: function() {
        var a = this.callParent();
        if (false === Ext.isDefined(a)) {
            if (_S("standalone")) {
                a = SYNO.SDS.AppMgr.getByAppName(_S("standaloneAppName"))[0].window
            } else {
                a = SYNO.SDS.Desktop
            }
        }
        return a
    },
    deletePhoto: function() {
        var b = this,
            a = this.findWindow();
        a.getMsgBox().confirm("", _TT("SYNO.Application.Service.Instance", "common", "avatar_confirm_delete"), function(c) {
            if (c === "yes") {
                b.sendWebAPI({
                    api: "SYNO.Personal.Profile.Photo",
                    method: "delete",
                    version: 1,
                    callback: function(d, e) {
                        if (d) {
                            this.owner.fireEvent("deletesucceed", this.owner, e);
                            if (this.avatar) {
                                this.avatar.removeAvatar()
                            }
                        }
                    },
                    scope: b
                })
            }
        }, b)
    }
});
Ext.define("SYNO.SDS.Profile.Panel", {
    extend: "SYNO.ux.Panel",
    loadFromWebAPI: true,
    useDefaultBtn: true,
    constructor: function(a) {
        Ext.apply(this, a);
        var b = {
            width: 700,
            height: 400,
            title: _TT("SYNO.Application.Service.Instance", "common", "title_profile"),
            layout: "border",
            cls: "profile-panel",
            disableMask: false,
            items: [this.createAvatarCt(a), this.createProfileForm(a)],
            buttons: (this.useDefaultBtn) ? SYNO.SDS.Avatar.Utils.reorderFooterButtons({
                xtype: "syno_button",
                text: _T("common", "save"),
                btnStyle: "blue",
                handler: this.onSave,
                scope: this
            }, {
                xtype: "syno_button",
                text: _T("common", "cancel"),
                handler: this.onCancel,
                scope: this
            }) : null
        };
        this.addEvents({
            avatarreaderror: true,
            profileloaderror: true,
            applysucceed: true,
            applyfailed: true,
            deletesucceed: true,
            beforereadavatarimage: true,
            avatarreadsuccess: true,
            avatardialogopen: true,
            beforeapply: true
        });
        this.callParent([Ext.apply(b, a)])
    },
    createAvatarCt: function(a) {
        this.avatarCt = new Ext.Container(Ext.apply({
            region: "west",
            width: 184,
            cls: "avatar-ct",
            items: [this.avatar = new SYNO.SDS.Avatar.Container(Ext.apply({
                avatarSize: "M",
                useEmptyImg: true,
                size: 160
            }, (a && a.avatarCfg) ? a.avatarCfg : {})), this.uploadMask = new Ext.BoxComponent(Ext.apply({
                cls: "upload-mask",
                html: _TT("SYNO.Application.Service.Instance", "common", "profile_upload_photo"),
                width: 160
            }, (a && a.maskCfg) ? a.maskCfg : {})), this.cancelMask = new SYNO.SDS.Avatar.CancelMask(Ext.apply({
                cls: "cancel-mask",
                owner: this,
                avatar: this.avatar
            }, (a && a.cancelMaskCfg) ? a.cancelMaskCfg : {})), this.fileInput = new Ext.BoxComponent({
                autoEl: {
                    tag: "input",
                    type: "file",
                    accept: "image/jpeg, image/gif, image/png"
                },
                style: {
                    position: "absolute",
                    top: "-100000px",
                    left: "-10000px"
                }
            })],
            listeners: {
                scope: this,
                afterrender: function() {
                    this.avatarCt.el.on("click", function(b) {
                        if (b.getTarget(".avatar") || b.getTarget(".upload-mask")) {
                            this.fileInput.el.dom.click()
                        }
                        if (b.getTarget(".cancel-mask")) {
                            this.cancelMask.deletePhoto()
                        }
                    }, this);
                    this.fileInput.el.on("change", this.onSelectAvatar, this)
                }
            }
        }, a.avatarCtCfg || {}));
        return this.avatarCt
    },
    createProfileForm: function(a) {
        var b = (a && a.profileCfg) ? a.profileCfg : {};
        b.fieldNames = b.fieldNames || {};
        Ext.applyIf(b.fieldNames, SYNO.SDS.Profile.Defaults.getFieldNames());
        Ext.apply(this, {
            fieldNames: b.fieldNames,
            isMultiEmail: b.isMultiEmail
        });
        this.profileForm = new SYNO.SDS.Profile.FormPanel(Ext.apply({
            region: "center"
        }, b));
        return this.profileForm
    },
    onSelectAvatar: function(b, d) {
        if (d.files.length < 1) {
            return
        }
        var c = d.files[0];
        if (!c.type.match(/^image\/(jpeg|gif|png)$/m)) {
            this.getMsgBox().alert("", _TT("SYNO.Application.Service.Instance", "common", "profile_avatar_type_err"));
            return
        }
        this.fireEvent("beforereadavatarimage", this);
        if (!this.disableMask) {
            this.el.mask()
        }
        var a = new FileReader();
        a.onload = this.onAvatarReadSuccess.bind(this);
        a.onerror = this.onAvatarReadError.bind(this);
        a.readAsDataURL(c);
        d.value = ""
    },
    onAvatarReadSuccess: function(a) {
        this.fireEvent("avatarreadsuccess", this, a);
        if (!this.disableMask) {
            this.el.unmask()
        }
        var b = new SYNO.SDS.Avatar.Dialog(Ext.apply({
            owner: this.findWindow(),
            dataURL: a.target.result
        }, this.avatarDlgCfg));
        this.mon(b, "avatarchanged", this.onAvatarChanged, this);
        b.open();
        this.fireEvent("avatardialogopen", b)
    },
    onAvatarReadError: function(a) {
        if (!this.disableMask) {
            this.el.unmask()
        }
        this.fireEvent("avatarreaderror", this, a)
    },
    afterRender: function() {
        this.callParent(arguments);
        if (this.loadFromWebAPI) {
            this.getProfileInfo().then(this.onProfileGetSuccess.bind(this))["catch"](this.onProfileGetFailed.bind(this))
        }
    },
    getProfileInfo: function() {
        var a = this;
        return new Promise(function(c, b) {
            a.sendWebAPIs.call(a, c, b, a.getGetWebAPIs())
        })
    },
    processProfileGetSuccess: Ext.emptyFn,
    onProfileGetSuccess: function(c) {
        var b = SYNO.API.Util.GetValByAPI(c, "SYNO.Personal.Profile", "get");
        if (b) {
            var a = Ext.urlAppend(b[this.fieldNames.avatar]);
            if (a && a.length > 0) {
                this.avatar.updateAvatar(a)
            }
            if (this.profileForm.isMultiEmail) {
                var d = b[this.fieldNames.emails];
                if (Ext.isArray(d)) {
                    Ext.each(d, function(e) {
                        if (e !== "") {
                            this.profileForm.emailField.addNewItem({
                                value: e,
                                display: e
                            }, true)
                        }
                    }, this)
                }
            }
            this.profileForm.loadProfile(b)
        }
        this.processProfileGetSuccess(c)
    },
    processProfileGetFailed: Ext.emptyFn,
    onProfileGetFailed: function(a) {
        this.fireEvent("profileloaderror", this, a);
        this.processProfileGetFailed(a)
    },
    processGetWebAPIs: function(a) {
        return a
    },
    getGetWebAPIs: function() {
        var a = [{
            api: "SYNO.Personal.Profile",
            method: "get",
            version: 2
        }];
        return this.processGetWebAPIs(a)
    },
    getValues: function() {
        var a = this.profileForm.getForm().getValues();
        if (this.avatar.avatarChanged) {
            a[this.fieldNames.avatar] = this.prepareAvatar()
        }
        return a
    },
    isValid: function() {
        return this.profileForm.getForm().isValid()
    },
    isDirty: function() {
        return this.profileForm.getForm().isDirty() || this.avatar.avatarChanged
    },
    processApplyWebAPIs: function(a) {
        return a
    },
    getApplyWebAPIs: function() {
        var b = this.profileForm.getApplyWebAPI(),
            a = (b) ? [b] : [];
        return this.processApplyWebAPIs(a)
    },
    onApplySuccess: function(a) {
        this.avatar.avatarChanged = false;
        Ext.each(this.profileForm.getForm().items.items, function(b) {
            if (b.initValue) {
                b.initValue()
            }
        });
        if (!this.disableMask) {
            this.el.unmask()
        }
        this.fireEvent("applysucceed", this, a)
    },
    onApplyFail: function(a) {
        if (!this.disableMask) {
            this.el.unmask()
        }
        this.fireEvent("applyfailed", this, a)
    },
    sendAvatarAPI: function() {
        var a = this,
            b;
        return new Promise(function(d, c) {
            if (!a.avatar.avatarChanged) {
                d();
                return
            }
            b = new FormData();
            b.append(a.fieldNames.avatar, a.prepareAvatar());
            a.sendWebAPI({
                api: "SYNO.Personal.Profile.Photo",
                method: "upload",
                version: 1,
                html5upload: true,
                uploadData: b,
                callback: function(e, f) {
                    if (e) {
                        d(f)
                    } else {
                        c(f)
                    }
                },
                scope: a
            })
        })
    },
    sendWebAPIs: function(e, d, a) {
        var c = this,
            b = function(f, g) {
                if (f) {
                    e(g)
                } else {
                    d(g)
                }
            };
        if (a.length === 0) {
            e()
        } else {
            c.sendWebAPI({
                compound: {
                    params: a
                },
                scope: c,
                callback: b
            })
        }
    },
    sendProfileAPI: function() {
        var a = this;
        return new Promise(function(c, b) {
            a.sendWebAPIs.call(a, c, b, a.getApplyWebAPIs())
        })
    },
    alertReload: function(d) {
        SYNO.SDS.UserSettings.setProperty("Personal", "lang", d);
        SYNO.SDS.UserSettings.save();
        var c = String.format("{0}<ul><br><li>{1}</li>", _T("personal_settings", "refresh_confirm"), _T("personal_settings", "lang_changed")),
            b = this.findAppWindow(),
            a = b || (_S("standalone")) ? SYNO.SDS.AppMgr.getByAppName(_S("standaloneAppName"))[0].window : SYNO.SDS.Desktop;
        setTimeout(function() {
            a.getMsgBox().confirm("", c, function(e) {
                if (e === "yes") {
                    window.onbeforeunload = null;
                    window.onbeforeunload = SYNO.SDS.onBeforeUnloadForApplication;
                    location.reload(true)
                }
            })
        }, 500)
    },
    savePreferredLanguage: function() {
        var a = this.profileForm.getLangField();
        if (a && a.isDirty()) {
            this.alertReload(a.getValue())
        }
    },
    bindReloadHandler: function() {
        var c = this.profileForm.getLangField(),
            d = c.getValue();
        if (c && c.isDirty()) {
            var b = this.findAppWindow(),
                a = b || (_S("standalone")) ? SYNO.SDS.AppMgr.getByAppName(_S("standaloneAppName"))[0].window : SYNO.SDS.Desktop;
            a.mon(this, "applysucceed", function() {
                this.alertReload(d)
            }, this)
        }
    },
    onSave: function() {
        if (!this.isValid()) {
            return false
        }
        if (this.isDirty()) {
            if (this.fireEvent("beforeapply", this) === false) {
                return
            }
            if (!this.disableMask) {
                this.el.mask()
            }
            this.bindReloadHandler();
            this.sendAvatarAPI().then(this.sendProfileAPI.bind(this)).then(this.onApplySuccess.bind(this))["catch"](this.onApplyFail.bind(this));
            return
        }
        this.fireEvent("applysucceed", this, {})
    },
    onCancel: function() {
        if (this.owner) {
            this.owner.close()
        }
    },
    onAvatarChanged: function(a) {
        this.avatar.updateAvatar(a);
        this.avatar.avatarChanged = true
    },
    prepareAvatar: function() {
        if (!this.avatar.avatarChanged) {
            return
        }
        var e = this.avatar.getAvatarURI();
        var c = atob(e.split(",")[1]);
        var b = c.length;
        var a = new Uint8Array(b);
        for (var d = 0; d < b; ++d) {
            a[d] = c.charCodeAt(d)
        }
        return new Blob([a], {
            type: "image/png"
        })
    }
});
Ext.ns("SYNO.SAS");
SYNO.SAS.DateTimeUtils = SYNO.SDS.DateTimeUtils || ((function() {
    var a = ["Y-m-d", "Y/m/d", "Y.m.d", "d-m-Y", "d/m/Y", "d.m.Y", "m-d-Y", "m/d/Y", "m.d.Y"],
        h = ["YYYY-MM-dd", "YYYY/MM/dd", "YYYY.MM.dd", "dd-MM-YYYY", "dd/MM/YYYY", "dd.MM.YYYY", "MM-dd-YYYY", "MM/dd/YYYY", "MM.dd.YYYY"],
        c = ["h:i", "H:i"],
        f = [_TT("SYNO.Application.Service.Instance", "common", "pref_time_format_12"), _TT("SYNO.Application.Service.Instance", "common", "pref_time_format_24")],
        g = [" a", ""],
        d = [0, 1].map(function(j) {
            return c[j] + g[j]
        }),
        b = a[0],
        e = d[1],
        i = {
            chs: a[0],
            cht: a[0],
            csy: a[4],
            dan: a[4],
            enu: a[7],
            fre: a[4],
            ger: a[5],
            hun: a[0],
            ita: a[4],
            jpn: a[0],
            krn: a[0],
            nld: a[3],
            nor: a[5],
            plk: a[5],
            ptb: a[4],
            ptg: a[4],
            rus: a[5],
            spn: a[4],
            sve: a[0],
            tha: a[4],
            trk: a[5]
        };
    return {
        SupportedDateFormats: a,
        SupportedTimeFormats: d,
        GetDateFormatByLang: function(j) {
            return i[j] || b
        },
        GetTimeFormatByLang: function(j) {
            return e
        },
        GetSystemDateFormat: function() {
            return _S("date_format") || b
        },
        GetSystemTimeFormat: function() {
            return _S("time_format") || e
        },
        CreateDateFormatArray: function(l) {
            var k = SYNO.SAS.DateTimeUtils.SupportedDateFormats,
                m = k.map(function(n, o) {
                    return [n, h[o]]
                }),
                j = SYNO.SAS.DateTimeUtils.GetSystemDateFormat();
            if (l) {
                Ext.each(m, function(n) {
                    if (n[0] === j) {
                        n[1] = n[1] + " (" + _TT("SYNO.Application.Service.Instance", "common", "sys_default_setting") + ")"
                    }
                })
            }
            return m
        },
        CreateDateFormatJsonOptions: function(j) {
            var k = SYNO.SAS.DateTimeUtils.CreateDateFormatArray(j);
            return k.map(function(l) {
                return {
                    value: l[0],
                    display: l[1]
                }
            })
        },
        CreateDateFormatStore: function(j) {
            var k = SYNO.SAS.DateTimeUtils.CreateDateFormatArray(j);
            return new Ext.data.ArrayStore({
                fields: ["value", "display"],
                autoDestroy: true,
                data: k
            })
        },
        CreateTimeFormatArray: function(k) {
            var j = SYNO.SAS.DateTimeUtils.SupportedTimeFormats,
                l = j.map(function(n, o) {
                    return [n, f[o]]
                }),
                m = SYNO.SAS.DateTimeUtils.GetSystemTimeFormat();
            if (k) {
                Ext.each(l, function(n) {
                    if (n[0] === m) {
                        n[1] = n[1] + " (" + _TT("SYNO.Application.Service.Instance", "common", "sys_default_setting") + ")"
                    }
                })
            }
            return l
        },
        CreateTimeFormatJsonOptions: function(j) {
            var k = SYNO.SAS.DateTimeUtils.CreateTimeFormatArray(j);
            return k.map(function(l) {
                return {
                    value: l[0],
                    display: l[1]
                }
            })
        },
        CreateTimeFormatStore: function(j) {
            var k = SYNO.SAS.DateTimeUtils.CreateTimeFormatArray(j);
            return new Ext.data.ArrayStore({
                fields: ["value", "display"],
                autoDestroy: true,
                data: k
            })
        },
        SetUserFormat: function(j, k) {
            if (typeof k !== "string") {
                return
            }
            if (j === "date") {
                SYNO.SDS.UserSettings.setProperty("Personal", "dateFormat", k)
            } else {
                if (j === "time") {
                    SYNO.SDS.UserSettings.setProperty("Personal", "timeFormat", k)
                }
            }
        },
        RemoveUserFormat: function(j) {
            if (j === "date") {
                SYNO.SDS.UserSettings.removeProperty("Personal", "dateFormat")
            } else {
                if (j === "time") {
                    SYNO.SDS.UserSettings.removeProperty("Personal", "timeFormat")
                }
            }
        },
        GetYearMonthFormat: function() {
            var j = SYNO.SAS.DateTimeUtils.GetDateFormat();
            j = j.replace("d/", "").replace("-d", "").replace("d.", "").replace("d-", "");
            return j
        },
        GetMonthDateFormat: function() {
            var j = SYNO.SAS.DateTimeUtils.GetDateFormat();
            j = j.replace("/Y", "").replace("Y-", "").replace(".Y", "").replace("-Y", "");
            return j
        },
        GetDateRawFormat: function() {
            return SYNO.SDS.UserSettings.getProperty("Personal", "dateFormat") || "system"
        },
        GetTimeRawFormat: function() {
            return SYNO.SDS.UserSettings.getProperty("Personal", "timeFormat") || "system"
        },
        GetDateFormat: function() {
            var j = SYNO.SDS.UserSettings.getProperty("Personal", "dateFormat");
            j = (j === "system") ? SYNO.SAS.DateTimeUtils.GetSystemDateFormat() : j || SYNO.SAS.DateTimeUtils.GetSystemDateFormat();
            return j
        },
        GetTimeFormat: function() {
            var j = SYNO.SDS.UserSettings.getProperty("Personal", "timeFormat");
            j = (j === "system") ? SYNO.SAS.DateTimeUtils.GetSystemTimeFormat() : j || SYNO.SAS.DateTimeUtils.GetSystemTimeFormat();
            return j
        },
        GetTimePrefix: function() {
            var j = SYNO.SAS.DateTimeUtils.GetTimeFormat();
            if (j.indexOf(c[1]) > -1) {
                return c[1]
            }
            return c[0]
        },
        GetTimePostfix: function() {
            var j = SYNO.SAS.DateTimeUtils.GetTimeFormat();
            if (j.indexOf(c[1]) > -1) {
                return g[1]
            }
            return g[0]
        },
        GetDateTimeFormat: function() {
            return SYNO.SAS.DateTimeUtils.GetDateFormat() + " " + SYNO.SAS.DateTimeUtils.GetTimeFormat()
        },
        GetDateTimeSecFormat: function() {
            var k = SYNO.SAS.DateTimeUtils;
            var j = k.GetDateFormat();
            var m = k.GetTimePrefix();
            var l = k.GetTimePostfix();
            return j + " " + m + ":s" + l
        },
        GetTimeSecFormat: function() {
            var j = SYNO.SAS.DateTimeUtils;
            var l = j.GetTimePrefix();
            var k = j.GetTimePostfix();
            return l + ":s" + k
        },
        GetDateTimeSecMsFormat: function() {
            var k = SYNO.SAS.DateTimeUtils;
            var m = k.GetTimePrefix();
            var l = k.GetTimePostfix();
            var j = k.GetDateFormat();
            return j + " " + m + ":s.u" + l
        },
        GetTimeSecMsFormat: function() {
            var j = SYNO.SAS.DateTimeUtils;
            var l = j.GetTimePrefix();
            var k = j.GetTimePostfix();
            return l + ":s.u" + k
        }
    }
})());
SYNO.SAS.DateTimeFormatter = SYNO.SDS.DateTimeFormatter || function(d, b) {
    if (!d || Object.prototype.toString.call(d) !== "[object Date]") {
        return ""
    }
    var c = b && b.type,
        a = SYNO.SAS.DateTimeUtils,
        e;
    if (c === "date") {
        e = a.GetDateFormat()
    } else {
        if (c === "yearmonth") {
            e = a.GetYearMonthFormat()
        } else {
            if (c === "monthdate") {
                e = a.GetMonthDateFormat()
            } else {
                if (c === "time") {
                    e = a.GetTimeFormat()
                } else {
                    if (c === "timesec") {
                        e = a.GetTimeSecFormat()
                    } else {
                        if (c === "datetimesec") {
                            e = a.GetDateTimeSecFormat()
                        } else {
                            if (c === "datetimesecms") {
                                e = a.GetDateTimeSecMsFormat()
                            } else {
                                e = a.GetDateTimeFormat()
                            }
                        }
                    }
                }
            }
        }
    }
    return d.format(e)
};
Ext.define("SYNO.SDS.Avatar.Utils", {
    singleton: true,
    reorderFooterButtons: function(b, a) {
        return _S("majorversion") === "6" ? [b, a] : [a, b]
    }
});
