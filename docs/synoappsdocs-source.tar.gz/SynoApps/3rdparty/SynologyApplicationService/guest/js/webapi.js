/******/
(function(modules) { // webpackBootstrap
    /******/ // The module cache
    /******/
    var installedModules = {};

    /******/ // The require function
    /******/
    function __webpack_require__(moduleId) {

        /******/ // Check if module is in cache
        /******/
        if (installedModules[moduleId])
            /******/
            return installedModules[moduleId].exports;

        /******/ // Create a new module (and put it into the cache)
        /******/
        var module = installedModules[moduleId] = {
            /******/
            exports: {},
            /******/
            id: moduleId,
            /******/
            loaded: false
            /******/
        };

        /******/ // Execute the module function
        /******/
        modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

        /******/ // Flag the module as loaded
        /******/
        module.loaded = true;

        /******/ // Return the exports of the module
        /******/
        return module.exports;
        /******/
    }


    /******/ // expose the modules object (__webpack_modules__)
    /******/
    __webpack_require__.m = modules;

    /******/ // expose the module cache
    /******/
    __webpack_require__.c = installedModules;

    /******/ // __webpack_public_path__
    /******/
    __webpack_require__.p = "";

    /******/ // Load entry module and return exports
    /******/
    return __webpack_require__(0);
    /******/
})
/************************************************************************/
/******/
([
    /* 0 */
    /***/
    (function(module, exports) {

        "use strict";

        (function(root) {
            var SYNO = function SYNO() {};
            var STRINGS = {};

            SYNO.GuestPageLocation = "/webman/3rdparty/SynologyApplicationService/guest/index.html";
            SYNO.Request = function(method, url, data) {
                return new Promise(function(resolve, reject) {
                    var xhr = new XMLHttpRequest();
                    xhr.open(method, url);
                    xhr.onload = function() {
                        if (this.status >= 200 && this.status < 300) {
                            resolve(xhr.response);
                        } else {
                            reject({
                                status: this.status,
                                statusText: xhr.statusText
                            });
                        }
                    };
                    xhr.onerror = function() {
                        reject({
                            status: this.status,
                            statusText: xhr.statusText
                        });
                    };

                    if (data && data !== "") {
                        xhr.send(data);
                    } else {
                        xhr.send();
                    }
                });
            };

            SYNO.APIRequest = function(api, method, version, params, http_method, path) {
                var cgi_path = path ? path : "/webapi/entry.cgi";
                var pathname = window.location.pathname.replace(SYNO.GuestPageLocation, cgi_path);
                var url = window.location.origin + pathname;
                url = url + "?api=" + api + "&method=" + method + "&version=" + version;
                var httpMethod = "GET" == http_method ? "GET" : "POST";
                var data = "";
                if (params) {
                    for (var key in params) {
                        data = data + (data === "" ? "" : "&");
                        data = data + encodeURIComponent(key) + "=" + encodeURIComponent(params[key]);
                    }
                    if ("GET" == httpMethod) {
                        url += "&" + data;
                        data = "";
                    }
                }

                return new Promise(function(resolve, reject) {
                    SYNO.Request(httpMethod, url, data).then(function(response) {
                        try {
                            var res = JSON.parse(response);
                            resolve(res);
                        } catch (e) {
                            reject({
                                'success': false,
                                'error': 'network'
                            });
                        }
                    })['catch'](function(error) {
                        reject({
                            'success': false,
                            'error': 'network'
                        });
                    });
                });
            };

            SYNO.GetStrings = function(lang) {
                return SYNO.Request("GET", "../texts/" + lang + "/strings").then(function(response) {
                    var lines = response.match(/[^\r\n]+/g);
                    var curSection;

                    lines.forEach(function(line) {
                        if (line[0] == '#') {
                            return;
                        }

                        // find [SECTION]
                        var section = line.match(/\[(.*?)\]/);
                        if (section !== null && section.length == 2) {
                            curSection = section[1];
                            STRINGS[curSection] = {};
                            return;
                        }

                        // find KEY = "VALUE"
                        var pair = line.match(/\s*(.*?)\s*=\s*"(.*)"\s*/);
                        if (pair !== null && pair.length == 3) {
                            STRINGS[curSection][pair[1]] = pair[2];
                        }
                    });
                });
            };

            SYNO.StatGuestRequest = function(jwt) {
                return SYNO.APIRequest("SYNO.SAS.Guest", "stat", "1", {
                    "jwt": jwt
                });
            };

            SYNO.GetGuestRequest = function(jwt, account) {
                return SYNO.APIRequest("SYNO.SAS.Guest", "get", "1", {
                    "jwt": jwt,
                    "account": JSON.stringify(account)
                });
            };

            SYNO.SetGuestRequest = function(jwt, account, passwd) {
                return SYNO.APIRequest("SYNO.SAS.Guest", "set", "1", {
                    "jwt": jwt,
                    "account": JSON.stringify(account),
                    "passwd": JSON.stringify(passwd)
                });
            };

            SYNO.IsChineseArea = function() {
                return navigator.language.toUpperCase() == "zh-CN".toUpperCase();
            };

            root.SYNO = SYNO;
            root.STRINGS = STRINGS;
        })(window);

        /***/
    })
    /******/
]);