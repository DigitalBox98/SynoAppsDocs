(function(root) {
    SYNO = root.SYNO || {};
    STRINGS = {};

    SYNO.Request = function(method, url, data) {
        return new Promise(function(resolve, reject) {
            var xhr = new XMLHttpRequest();
            xhr.open(method, url);
            xhr.onload = function() {
                if (this.status >= 200 && this.status < 300) {
                    resolve(xhr.response);
                } else {
                    reject({
                        status: this.status,
                        statusText: xhr.statusText
                    });
                }
            };
            xhr.onerror = function() {
                reject({
                    status: this.status,
                    statusText: xhr.statusText
                });
            };

            if (data && data !== "") {
                xhr.send(data);
            } else {
                xhr.send();
            }
        });
    };

    SYNO.EscapeKeys = ["ds_id", "auth", "p256dh", "public_key", "browser_key"];

    SYNO.UrlEncode = function(params, is_escaped) {
        var data = "";
        var escaped = (typeof is_escaped !== "boolean") ? true : is_escaped;
        if (params) {
            for (key in params) {
                data = data + ((data === "") ? "" : "&");
                if ((typeof params[key] === "string") && escaped && (SYNO.EscapeKeys.indexOf(key) >= 0)) {
                    data = data + encodeURIComponent(key) + "=\"" + encodeURIComponent(params[key]) + "\"";
                } else {
                    data = data + encodeURIComponent(key) + "=" + encodeURIComponent(params[key]);
                }
            }
        }

        return data;
    };

    SYNO.APIRequest = function(api, method, version, params, is_escaped) {
        var escaped = (typeof is_escaped !== "boolean") ? true : is_escaped;
        var pathname = window.location.pathname.replace("/webman/3rdparty/SynologyApplicationService/browser_pair/pair.html", "/webapi/entry.cgi");
        var url = window.location.origin + pathname;
        var urlParams = Object.assign(params, {
            "api": api,
            "method": method,
            "version": version
        });

        return new Promise(function(resolve, reject) {
            SYNO.Request("POST", url, SYNO.UrlEncode(urlParams, escaped))
                .then(function(response) {
                    try {
                        var res = JSON.parse(response);
                        resolve(res);
                    } catch (e) {
                        reject({
                            'success': false,
                            'error': 'network'
                        });
                    }
                })['catch'](function(error) {
                    reject({
                        'success': false,
                        'error': 'network'
                    });
                });
        });
    };

    SYNO.GetStrings = function(lang) {
        return SYNO.Request("GET", "../texts/" + lang + "/strings")
            .then(function(response) {
                var lines = response.match(/[^\r\n]+/g);
                var curSection;

                lines.forEach(function(line) {
                    if (line[0] == '#') {
                        return;
                    }

                    // find [SECTION]
                    var section = line.match(/\[(.*?)\]/);
                    if (section !== null && section.length == 2) {
                        curSection = section[1];
                        STRINGS[curSection] = {};
                        return;
                    }

                    // find KEY = "VALUE"
                    var pair = line.match(/\s*(.*?)\s*=\s*"(.*)"\s*/);
                    if (pair !== null && pair.length == 3) {
                        STRINGS[curSection][pair[1]] = pair[2];
                    }
                });
            });
    };

    SYNO.GetDSIDRequest = function(params) {
        return SYNO.APIRequest("SYNO.Personal.Notification.Identifier", "get", "1", params);
    };

    SYNO.GetTokenRequest = function(params) {
        return SYNO.APIRequest("SYNO.Personal.Notification.Token", "get", "1", params);
    };

    SYNO.SendPairRequest = function(params) {
        return SYNO.APIRequest("SYNO.Personal.Notification.Mobile", "pair", "1", params);
    };

    SYNO.GetVapidPKeyRequest = function(params) {
        return SYNO.APIRequest("SYNO.Personal.Notification.VapidPublicKey", "get", "1", params);
    };

    SYNO.SendEncryptStatusRequest = function(params) {
        return SYNO.APIRequest("SYNO.SAS.Encryption", "status", "1", params);
    };

    SYNO.SendEncryptExchangeRequest = function(params) {
        return SYNO.APIRequest("SYNO.SAS.Encryption", "exchange", "1", params);
    };

    SYNO.GetGDPRSettingRequest = function(params) {
        return SYNO.APIRequest("SYNO.Personal.Notification.GDPR", "get", "1", params);
    };

    SYNO.SetGDPRSettingRequest = function(params) {
        return SYNO.APIRequest("SYNO.Personal.Notification.GDPR", "set", "1", params);
    };

    if (typeof module !== 'undefined' && module.exports) {
        module.exports = SYNO;
    } else if (!root.SYNO) {
        root.SYNO = SYNO;
    }
})(this);