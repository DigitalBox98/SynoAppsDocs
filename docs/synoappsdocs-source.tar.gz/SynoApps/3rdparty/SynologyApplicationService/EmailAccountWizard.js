/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.namespace("SYNO.Personal.Mail");
/**
 * @class SYNO.Personal.Mail.EmailAccountWizard
 * @extends SYNO.SDS.Wizard.ModalWindow
 * ApplicationService email account wizard
 *
 */
SYNO.Personal.Mail.EmailAccountWizard = Ext.extend(SYNO.SDS.Wizard.ModalWindow, {
    next_step: null,
    WIZRAD_HEIGHT: 490,
    constructor: function(b) {
        this.saveData = {};
        var a = [];
        this.welcomeStep = new SYNO.Personal.Mail.EmailAccountWizard.WelcomeStep({
            itemId: "welcome",
            nextId: "normal_email_setting"
        });
        a.push(this.welcomeStep);
        this.normalEmailSettingStep = new SYNO.Personal.Mail.EmailAccountWizard.NormalEmailSettingStep({
            itemId: "normal_email_setting",
            nextId: "sync_contact"
        });
        a.push(this.normalEmailSettingStep);
        this.normalEmailWithoutSyncSettingStep = new SYNO.Personal.Mail.EmailAccountWizard.NormalEmailWithoutSyncSettingStep({
            itemId: "normal_email_withoutsync_setting",
            nextId: null
        });
        a.push(this.normalEmailWithoutSyncSettingStep);
        this.customEmailSettingStep = new SYNO.Personal.Mail.EmailAccountWizard.CustomEmailSettingStep({
            itemId: "custom_email_setting",
            nextId: null
        });
        a.push(this.customEmailSettingStep);
        if (SYNO.Personal.Mail.EmailAccountWizard.Utils.isSynoMailClientEnable()) {
            this.synomailSettingStep = new SYNO.Personal.Mail.EmailAccountWizard.SynoMailSettingStep({
                itemId: "synomail_setting",
                nextId: null
            });
            a.push(this.synomailSettingStep)
        }
        this.syncContactStep = new SYNO.Personal.Mail.EmailAccountWizard.SyncContactStep({
            itemId: "sync_contact",
            nextId: null
        });
        a.push(this.syncContactStep);
        SYNO.Personal.Mail.EmailAccountWizard.superclass.constructor.call(this, Ext.apply({
            title: _T("mail", "email_wizard_title"),
            showHelp: false,
            width: 600,
            height: this.WIZRAD_HEIGHT,
            steps: a,
            listeners: {
                beforeclose: this.onBeforeClose,
                scope: this
            }
        }, b));
        SYNO.SDS.Utils.AddTip(this.normalEmailSettingStep.getComponent("sender_name").getEl(), String.format(_T("mail", "sender_name_hint"), _T("notification", "alert_smtp_user")));
        SYNO.SDS.Utils.AddTip(this.normalEmailWithoutSyncSettingStep.getComponent("sender_name").getEl(), String.format(_T("mail", "sender_name_hint"), _T("notification", "alert_smtp_user")));
        SYNO.SDS.Utils.AddTip(this.customEmailSettingStep.getComponent("sender_name").getEl(), String.format(_T("mail", "sender_name_hint"), _T("notification", "label_smtp_sender_mail")))
    },
    onOpen: function() {
        this.setActiveStep("welcome");
        SYNO.Personal.Mail.EmailAccountWizard.superclass.onOpen.apply(this, arguments)
    },
    onBeforeClose: function() {
        this.syncContactStep.doClosePopup()
    },
    displayError: function(a) {
        var b;
        if (8006 === a) {
            b = _T("mail", "account_already_saved")
        } else {
            if (8011 === a) {
                b = _T("mail", "mail_setting_error")
            } else {
                if (8014 === a) {
                    b = _TT("SYNO.Application.Service.Instance", "error", "mail_contact_error")
                } else {
                    b = _T("error", "error_error_system")
                }
            }
        }
        this.getMsgBox().alert(this.title, b)
    },
    setNextStep: function(a, b) {
        if (0 > this.stepStack.indexOf(a)) {
            this.stepStack.push(a)
        }
        if (Ext.isString(b)) {
            this.stepStack.push(b)
        }
    },
    onClose: function() {}
});
Ext.ns("SYNO.Personal.Mail.EmailAccountWizard");
SYNO.Personal.Mail.EmailAccountWizard.Utils = {};
Ext.apply(SYNO.Personal.Mail.EmailAccountWizard.Utils, {
    emailConfig: {
        gmail: {
            desc: _T("mail", "mail_gmail_desc"),
            btn_text: _T("mail", "mail_authentication"),
            unsync_text: _T("mail", "mail_reauth"),
            sync_success: _T("mail", "mail_authentication_success"),
            sync_failed: _T("mail", "sync_fail"),
            cancel: true
        },
        other: {
            desc: _T("mail", "mail_syncpage_desc"),
            btn_text: _T("mail", "sync_contact"),
            unsync_text: _T("mail", "unsync_contact"),
            sync_success: _T("mail", "sync_success"),
            sync_failed: _T("mail", "sync_fail"),
            cancel: false
        }
    },
    getSynoMailConfig: function(c) {
        var b = new Ext.data.Store({
            autoLoad: true,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.MailClient.Setting.SMTP",
                method: "list",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "smtp"
            }, [{
                name: "mail"
            }]),
            listeners: {
                load: function(e, d) {
                    if (0 < d.length && !Ext.isEmpty(c)) {
                        c.getComponent("account").setValue(d[0].get("mail"))
                    }
                }
            }
        });
        var a = {
            items: [{
                xtype: "syno_displayfield",
                itemId: "desc",
                name: "desc",
                value: _T("mail", "synomail_desc")
            }, {
                xtype: "syno_combobox",
                itemId: "account",
                name: "account",
                allowBlank: false,
                width: 250,
                boxLabel: _T("notification", "alert_smtp_user"),
                fieldLabel: _T("notification", "alert_smtp_user"),
                valueField: "mail",
                displayField: "mail",
                store: b
            }]
        };
        return a
    },
    getNormalProviderConfig: function(b) {
        if (!Ext.isDefined(b)) {
            b = true
        }
        var a = {
            items: [{
                xtype: "syno_textfield",
                itemId: "account",
                name: "account",
                width: 250,
                allowBlank: false,
                vtype: "email",
                disabled: !b,
                fieldLabel: _T("mail", "application_title")
            }, {
                xtype: "syno_textfield",
                itemId: "passwd",
                name: "passwd",
                width: 250,
                allowBlank: false,
                inputType: "password",
                hidden: !b,
                disabled: !b,
                fieldLabel: _T("notification", "alert_smtp_pass")
            }, {
                xtype: "syno_textfield",
                itemId: "sender_name",
                name: "sender_name",
                width: 250,
                fieldLabel: _T("notification", "label_smtp_sender_name")
            }]
        };
        return a
    },
    getCustomProviderConfig: function() {
        var a = {
            items: [{
                xtype: "syno_textfield",
                itemId: "host",
                name: "host",
                width: 250,
                allowBlank: false,
                fieldLabel: _T("notification", "alert_smtp")
            }, {
                xtype: "syno_textfield",
                itemId: "port",
                name: "port",
                width: 250,
                allowBlank: false,
                fieldLabel: _T("notification", "alert_port"),
                vtype: "port"
            }, {
                xtype: "syno_checkbox",
                itemId: "enable_auth_checkbox",
                name: "auth",
                boxLabel: _T("notification", "alert_smtp_need_auth")
            }, {
                xtype: "syno_textfield",
                itemId: "account",
                name: "account",
                width: 250,
                allowBlank: false,
                indent: 1,
                fieldLabel: _T("notification", "alert_smtp_user")
            }, {
                xtype: "syno_textfield",
                itemId: "passwd",
                name: "passwd",
                width: 250,
                allowBlank: false,
                inputType: "password",
                indent: 1,
                fieldLabel: _T("notification", "alert_smtp_pass")
            }, {
                xtype: "syno_checkbox",
                itemId: "tls",
                name: "tls",
                width: 300,
                boxLabel: _T("notification", "alert_use_ssl")
            }, {
                xtype: "syno_textfield",
                itemId: "sender_account",
                name: "sender_account",
                width: 250,
                allowBlank: false,
                vtype: "email",
                fieldLabel: _T("notification", "label_smtp_sender_mail")
            }, {
                xtype: "syno_textfield",
                itemId: "sender_name",
                name: "sender_name",
                width: 250,
                fieldLabel: _T("notification", "label_smtp_sender_name")
            }]
        };
        return a
    },
    isNeedAlert: function(c, b) {
        var a = function(e, d) {
            return e.indexOf(d) > -1
        };
        if ("hotmail" === b && !a(c, "@hotmail.com") && !a(c, "@outlook.com")) {
            return true
        } else {
            if ("yahoomail" === b && !a(c, "@yahoo.com")) {
                return true
            } else {
                if ("aolmail" === b && !a(c, "@aol.com")) {
                    return true
                } else {
                    return false
                }
            }
        }
    },
    getEmailProviderName: function(a) {
        if ("gmail" === a) {
            return "Gmail"
        } else {
            if ("hotmail" === a) {
                return "Outlook"
            } else {
                if ("yahoomail" === a) {
                    return "Yahoo!"
                } else {
                    if ("aolmail" === a) {
                        return "AOL"
                    } else {
                        return "Custom"
                    }
                }
            }
        }
    },
    getEmailConfig: function(b) {
        var a = SYNO.Personal.Mail.EmailAccountWizard.Utils.emailConfig;
        if (a.hasOwnProperty(b)) {
            return a[b]
        } else {
            return a.other
        }
    },
    isSynoMailClientEnable: function() {
        return SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.MailClient.Application")
    },
    reorderFooterButtons: function(b, a) {
        return _S("majorversion") === "6" ? [b, a] : [a, b]
    }
});
SYNO.Personal.Mail.EmailAccountWizard.NormalEmailSettingStep = Ext.extend(SYNO.ux.FormPanel, {
    constructor: function(c) {
        var d = (!SYNO.SDS.UIFeatures.test("isRetina")) ? "./webman/3rdparty/SynologyApplicationService/images/1x/icon_success.png" : "./webman/3rdparty/SynologyApplicationService/images/2x/icon_success.png";
        var a = SYNO.Personal.Mail.EmailAccountWizard.Utils.getNormalProviderConfig().items;
        a.push({
            xtype: "syno_checkbox",
            itemId: "default_use_checkbox",
            name: "default_use",
            boxLabel: _T("mail", "default_use_checkbox")
        });
        this.testConnectBtn = new SYNO.ux.Button({
            btnStyle: SYNO.Personal.Mail.Config.btnStyle,
            text: _T("mail", "mail_test_connection"),
            handler: this.onTestConnect,
            scope: this
        });
        this.statusIcon = new Ext.BoxComponent({
            autoEl: {
                tag: "img",
                src: d,
                height: 24,
                width: 24
            }
        });
        this.statusField = new SYNO.ux.DisplayField({
            cls: "email-status-error"
        });
        a.push({
            xtype: "compositefield",
            itemId: "test_connection_item",
            hideLabel: true,
            items: [this.testConnectBtn, this.statusIcon, this.statusField]
        });
        var b = Ext.apply({
            headline: _T("mail", "email_settings_title"),
            items: a
        }, c);
        this.isNeedAlert = SYNO.Personal.Mail.EmailAccountWizard.Utils.isNeedAlert;
        SYNO.Personal.Mail.EmailAccountWizard.NormalEmailSettingStep.superclass.constructor.call(this, b)
    },
    load: function() {
        var b = this.getComponent("account");
        var a = this.getComponent("test_connection_item");
        b.emptyText = this.owner.emptyText;
        b.applyEmptyText();
        if (this.owner.blFirstCreate) {
            this.getComponent("default_use_checkbox").setValue(true);
            this.getComponent("default_use_checkbox").setDisabled(true)
        }
        if ("gmail" === this.owner.saveData.email_type) {
            b.setDisabled(true);
            b.hide();
            this.getComponent("passwd").setDisabled(true);
            this.getComponent("passwd").hide();
            a.setDisabled(true);
            a.hide()
        } else {
            b.setDisabled(false);
            b.show();
            this.getComponent("passwd").setDisabled(false);
            this.getComponent("passwd").show();
            a.setDisabled(false);
            a.show();
            this.statusIcon.hide()
        }
    },
    getNext: function() {
        if (!this.form.isValid()) {
            this.owner.getMsgBox().alert("", _T("common", "forminvalid"));
            return false
        }
        var b = this.owner.normalEmailSettingStep.getComponent("account").getValue();
        var a = SYNO.Personal.Mail.EmailAccountWizard.Utils.getEmailProviderName(this.owner.saveData.email_type);
        var c = String.format(_T("mail", "email_setting_alert"), b, a);
        this.owner.saveData.is_default = this.form.findField("default_use_checkbox").getValue();
        if (this.isNeedAlert(b, this.owner.saveData.email_type)) {
            this.owner.getMsgBox().confirm("", c, function(d) {
                if ("yes" === d) {
                    this.testConnect(this.getNextCallback)
                }
            }, this);
            return false
        } else {
            this.testConnect(this.getNextCallback);
            return false
        }
    },
    getNextCallback: function(c, b, a) {
        this.owner.clearStatusBusy();
        if (c) {
            this.owner.goNext(this.nextId);
            this.disableApplyBtn()
        } else {
            this.owner.displayError(b.code)
        }
    },
    disableApplyBtn: function() {
        if ("gmail" === this.owner.saveData.email_type) {
            this.owner.getButton("next").disable();
            this.owner.setHeadline(_T("mail", "mail_gmail_title"))
        }
    },
    onTestConnect: function() {
        this.statusIcon.hide();
        this.statusField.setValue("");
        if (!this.form.isValid()) {
            this.owner.getMsgBox().alert("", _T("common", "forminvalid"));
            return false
        }
        this.testConnect(this.setConnectionStatus)
    },
    testConnect: function(d) {
        if ("gmail" === this.owner.saveData.email_type) {
            this.owner.goNext(this.nextId);
            this.disableApplyBtn();
            return
        }
        var b = this.getComponent("account").getValue();
        var a = this.getComponent("passwd").getValue();
        var c = {
            email_type: this.owner.saveData.email_type,
            auth: "true",
            tls: "true",
            account: b,
            passwd: a
        };
        this.owner.setStatusBusy();
        this.owner.sendWebAPI({
            api: "SYNO.Personal.MailAccount",
            method: "test",
            version: 1,
            params: c,
            encryption: ["passwd"],
            callback: d,
            scope: this
        })
    },
    setConnectionStatus: function(d, c, b) {
        this.owner.clearStatusBusy();
        if (d) {
            var a = this.statusIcon.getPosition();
            if (!Ext.isEmpty(a) && 0 === a[0]) {
                a[0] += this.testConnectBtn.getWidth() + 4;
                this.statusIcon.setPosition(a)
            }
            this.statusIcon.show();
            this.statusField.setValue("")
        } else {
            this.statusIcon.hide();
            this.statusField.setValue(_T("mail", "mail_setting_error"))
        }
    }
});
SYNO.Personal.Mail.EmailAccountWizard.NormalEmailWithoutSyncSettingStep = Ext.extend(SYNO.Personal.Mail.EmailAccountWizard.NormalEmailSettingStep, {
    getNext: function() {
        if (!this.form.isValid()) {
            this.owner.getMsgBox().alert("", _T("common", "forminvalid"));
            return false
        }
        var b = this.owner.normalEmailWithoutSyncSettingStep.getComponent("account").getValue();
        var a = SYNO.Personal.Mail.EmailAccountWizard.Utils.getEmailProviderName(this.owner.saveData.email_type);
        var c = String.format(_T("mail", "email_setting_alert"), b, a);
        if (this.isNeedAlert(b, this.owner.saveData.email_type)) {
            this.owner.getMsgBox().confirm("", c, function(d) {
                if ("yes" === d) {
                    this.testConnect(this.getNextCallback)
                }
            }, this);
            return false
        }
        this.testConnect(this.getNextCallback);
        return false
    },
    getNextCallback: function(c, b, a) {
        this.owner.clearStatusBusy();
        if (c) {
            this.onApply()
        } else {
            this.owner.displayError(b.code)
        }
    },
    onApply: function() {
        var a = this.owner.normalEmailWithoutSyncSettingStep.getForm().getValues();
        Ext.apply(this.owner.saveData, a);
        this.owner.saveData.alias = this.owner.saveData.account || this.owner.saveData.sender_account;
        this.owner.saveData.is_default = this.form.findField("default_use_checkbox").getValue();
        this.owner.saveData.sender_name = this.owner.saveData.sender_name || this.owner.saveData.account;
        this.owner.setStatusBusy();
        this.owner.sendWebAPI({
            api: "SYNO.Personal.MailAccount",
            method: "set",
            version: 1,
            params: this.owner.saveData,
            encryption: ["passwd"],
            callback: function(d, c, b) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.owner.displayError(c.code);
                    return false
                }
                if (this.owner.saveData.is_default) {
                    SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_type", this.owner.saveData.email_type);
                    SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_alias", this.owner.saveData.alias)
                }
                this.owner.close()
            },
            scope: this
        })
    }
});
SYNO.Personal.Mail.EmailAccountWizard.CustomEmailSettingStep = Ext.extend(SYNO.ux.FormPanel, {
    constructor: function(c) {
        var d = (!SYNO.SDS.UIFeatures.test("isRetina")) ? "./webman/3rdparty/SynologyApplicationService/images/1x/icon_success.png" : "./webman/3rdparty/SynologyApplicationService/images/2x/icon_success.png";
        var a = SYNO.Personal.Mail.EmailAccountWizard.Utils.getCustomProviderConfig().items;
        a.push({
            xtype: "syno_checkbox",
            itemId: "default_use_checkbox",
            name: "default_use",
            boxLabel: _T("mail", "default_use_checkbox")
        });
        this.testConnectBtn = new SYNO.ux.Button({
            btnStyle: SYNO.Personal.Mail.Config.btnStyle,
            text: _T("mail", "mail_test_connection"),
            handler: this.onTestConnect,
            scope: this
        });
        this.statusIcon = new Ext.BoxComponent({
            hidden: true,
            autoEl: {
                tag: "img",
                src: d,
                height: 24,
                width: 24
            }
        });
        this.statusField = new SYNO.ux.DisplayField({
            cls: "email-status-error"
        });
        a.push({
            xtype: "compositefield",
            hideLabel: true,
            items: [this.testConnectBtn, this.statusIcon, this.statusField]
        });
        var b = Ext.apply({
            headline: _T("mail", "email_settings_title"),
            items: a
        }, c);
        SYNO.Personal.Mail.EmailAccountWizard.CustomEmailSettingStep.superclass.constructor.call(this, b);
        this.mon(this, "afterrender", this.onBindCheckbox, this, {
            single: true
        })
    },
    load: function() {
        var a = this.getComponent("sender_account");
        a.emptyText = this.owner.emptyText;
        a.applyEmptyText();
        if (this.owner.blFirstCreate) {
            this.getComponent("default_use_checkbox").setValue(true);
            this.getComponent("default_use_checkbox").setDisabled(true)
        }
        this.statusIcon.hide();
        this.statusField.setValue("")
    },
    getNext: function() {
        if (!this.form.isValid()) {
            this.owner.getMsgBox().alert("", _T("common", "forminvalid"));
            return false
        }
        var a = this.owner.customEmailSettingStep.getForm().getValues();
        Ext.apply(this.owner.saveData, a);
        this.owner.saveData.alias = this.owner.saveData.host + "_" + (this.owner.saveData.account || this.owner.saveData.sender_account);
        this.owner.saveData.is_default = this.form.findField("default_use_checkbox").getValue();
        this.owner.saveData.sender_name = this.owner.saveData.sender_name || this.owner.saveData.sender_account;
        this.testConnect(this.getNextCallback);
        return false
    },
    getNextCallback: function(c, b, a) {
        this.owner.clearStatusBusy();
        if (c) {
            this.onApply()
        } else {
            if (b.code) {
                this.owner.displayError(b.code)
            } else {
                this.owner.getMsgBox().alert("", _T("mail", "mail_setting_error"))
            }
        }
    },
    onApply: function() {
        this.owner.setStatusBusy();
        this.owner.sendWebAPI({
            api: "SYNO.Personal.MailAccount",
            method: "set",
            version: 1,
            params: this.owner.saveData,
            encryption: ["passwd"],
            callback: function(c, b, a) {
                this.owner.clearStatusBusy();
                if (!c) {
                    this.owner.displayError(b.code);
                    return false
                }
                if (this.owner.saveData.is_default) {
                    SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_type", this.owner.saveData.email_type);
                    SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_alias", this.owner.saveData.alias)
                }
                this.owner.close()
            },
            scope: this
        });
        return false
    },
    onBindCheckbox: function() {
        var a;
        a = new SYNO.ux.Utils.EnableCheckGroup(this.form, "auth", ["account", "passwd"])
    },
    onTestConnect: function() {
        this.statusIcon.hide();
        this.statusField.setValue("");
        if (!this.form.isValid()) {
            this.owner.getMsgBox().alert("", _T("common", "forminvalid"));
            return false
        }
        this.testConnect(this.setConnectionStatus)
    },
    testConnect: function(h) {
        var e = this.getComponent("account").getValue();
        var b = this.getComponent("passwd").getValue();
        var d = this.getComponent("host").getValue();
        var a = this.getComponent("port").getValue();
        var c = this.getComponent("enable_auth_checkbox").getValue();
        var g = this.getComponent("tls").getValue();
        var f = {
            email_type: this.owner.saveData.email_type,
            account: e,
            passwd: b,
            host: d,
            port: a,
            auth: c,
            tls: g
        };
        this.owner.setStatusBusy();
        this.owner.sendWebAPI({
            api: "SYNO.Personal.MailAccount",
            method: "test",
            version: 1,
            params: f,
            encryption: ["passwd"],
            callback: h,
            scope: this
        })
    },
    setConnectionStatus: function(d, c, b) {
        this.owner.clearStatusBusy();
        if (d) {
            var a = this.statusIcon.getPosition();
            if (!Ext.isEmpty(a) && 0 === a[0]) {
                a[0] += this.testConnectBtn.getWidth() + 4;
                this.statusIcon.setPosition(a)
            }
            this.statusIcon.show();
            this.statusField.setValue("")
        } else {
            this.statusIcon.hide();
            this.statusField.setValue(_T("mail", "mail_setting_error"))
        }
    }
});
SYNO.Personal.Mail.EmailAccountWizard.SynoMailSettingStep = Ext.extend(SYNO.ux.FormPanel, {
    constructor: function(c) {
        var a = SYNO.Personal.Mail.EmailAccountWizard.Utils.getSynoMailConfig(this).items;
        a.push({
            xtype: "syno_checkbox",
            itemId: "default_use_checkbox",
            name: "default_use",
            boxLabel: _T("mail", "default_use_checkbox")
        });
        var b = Ext.apply({
            headline: _T("mail", "email_settings_title"),
            items: a
        }, c);
        SYNO.Personal.Mail.EmailAccountWizard.SynoMailSettingStep.superclass.constructor.call(this, b)
    },
    load: function() {
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.MailClient.Info",
            method: "getinfo",
            version: 1,
            scope: this,
            callback: function(a, b) {
                this.owner.clearStatusBusy();
                if (false === a) {
                    this.owner.getMsgBox().alert("", _T("error", "error_no_share_to_write"), function() {
                        this.owner.goBack()
                    }, this)
                } else {
                    if (this.owner.blFirstCreate) {
                        this.getComponent("default_use_checkbox").setValue(true);
                        this.getComponent("default_use_checkbox").setDisabled(true)
                    }
                }
            }
        })
    },
    getNext: function() {
        if (!this.form.isValid()) {
            this.owner.getMsgBox().alert("", _T("common", "forminvalid"));
            return false
        }
        var a = this.owner.synomailSettingStep.getForm().getValues();
        Ext.apply(this.owner.saveData, a);
        this.owner.saveData.alias = this.owner.saveData.account;
        this.owner.saveData.is_default = this.form.findField("default_use_checkbox").getValue();
        this.onApply();
        return false
    },
    onApply: function() {
        this.owner.setStatusBusy();
        this.owner.sendWebAPI({
            api: "SYNO.Personal.MailAccount",
            method: "set",
            version: 1,
            params: this.owner.saveData,
            encryption: ["passwd"],
            callback: function(c, b, a) {
                this.owner.clearStatusBusy();
                if (!c) {
                    this.owner.displayError(b.code);
                    return false
                }
                if (this.owner.saveData.is_default) {
                    SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_type", this.owner.saveData.email_type);
                    SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_alias", this.owner.saveData.alias)
                }
                this.owner.close()
            },
            scope: this
        });
        return false
    }
});
SYNO.Personal.Mail.EmailAccountWizard.SyncContactStep = Ext.extend(SYNO.ux.FormPanel, {
    constructor: function(b) {
        this.syncBtn = new SYNO.ux.Button({
            btnStyle: SYNO.Personal.Mail.Config.btnStyle,
            itemId: "sync_contact",
            text: _T("mail", "sync_contact"),
            handler: this.onSyncClick,
            scope: this
        });
        this.msgField = new SYNO.ux.DisplayField({
            itemId: "msg_field",
            htmlEncode: false
        });
        var a = Ext.apply({
            headline: _T("mail", "sync_contact"),
            items: [{
                xtype: "syno_displayfield",
                itemId: "sync_displayfield",
                value: _T("mail", "mail_syncpage_desc")
            }, {
                xtype: "syno_displayfield",
                itemId: "sync_note",
                value: _T("mail", "mail_syncpage_note")
            }, {
                xtype: "compositefield",
                itemId: "sync_composite",
                hideLabel: true,
                items: [this.syncBtn, this.msgField]
            }],
            listeners: {
                activate: function() {
                    var d = this.getComponent("sync_displayfield");
                    var c = this.getEmailConfig(this.owner.saveData.email_type);
                    d.setValue(c.desc);
                    this.syncBtn.setText(c.btn_text);
                    this.msgField.setValue("");
                    if (this.owner.saveData.email_type === "gmail") {
                        this.getComponent("sync_note").hide()
                    } else {
                        this.getComponent("sync_note").show()
                    }
                },
                scope: this
            }
        }, b);
        this.getEmailConfig = SYNO.Personal.Mail.EmailAccountWizard.Utils.getEmailConfig;
        SYNO.Personal.Mail.EmailAccountWizard.SyncContactStep.superclass.constructor.call(this, a)
    },
    load: function() {},
    getNext: function() {
        var a = this.owner.normalEmailSettingStep.getForm().getValues();
        Ext.apply(this.owner.saveData, a);
        this.owner.saveData.alias = this.owner.saveData.account || this.owner.saveData.sender_account || "";
        this.owner.saveData.sender_name = this.owner.saveData.sender_name || this.owner.saveData.account;
        this.owner.setStatusBusy();
        this.owner.sendWebAPI({
            api: "SYNO.Personal.MailAccount",
            method: "set",
            version: 1,
            params: this.owner.saveData,
            encryption: ["passwd", "access_token", "refresh_token"],
            callback: function(e, c, b) {
                this.owner.clearStatusBusy();
                if (!e) {
                    this.owner.displayError(c.code);
                    return false
                }
                var d = c.account.alias;
                if (this.owner.saveData.is_default) {
                    SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_type", this.owner.saveData.email_type);
                    SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_alias", d)
                }
                this.owner.close()
            },
            scope: this
        });
        return false
    },
    onSyncClick: function(b) {
        var a = this.getEmailConfig(this.owner.saveData.email_type);
        if (a.btn_text === b.getText()) {
            this.onSyncContacts(this.owner.saveData.email_type)
        } else {
            this.onCancelSyncContacts()
        }
    },
    onCancelSyncContacts: function() {
        var a = this.getEmailConfig(this.owner.saveData.email_type);
        this.owner.saveData.access_token = "";
        this.owner.saveData.refresh_token = "";
        this.owner.saveData.expires_in = "";
        this.syncBtn.setText(a.btn_text);
        this.msgField.setValue("");
        this.owner.getButton("next").setDisabled(a.cancel)
    },
    getIndexDSUrl: function() {
        var a = window.location.protocol + "//" + window.location.hostname;
        if (window.location.port !== "") {
            a = a + ":" + window.location.port
        }
        if (window.location.pathname !== "" && window.location.pathname.indexOf("webman") < 0) {
            a = a + window.location.pathname.replace(/[^\/]*$/g, "")
        }
        return a + "/webman/3rdparty/SynologyApplicationService/index_ds.html"
    },
    onSyncContacts: function(a) {
        var c = "_syncContactOAuthCallback";
        this.register(this.onSyncCallback.createDelegate(this), c);
        var b = "http://synooauth.synology.com/email/login.php?version=2&callback=" + c + "&host=" + this.getIndexDSUrl() + "&type=" + a;
        this.popup = window.open(b, "mywindow", "menubar=1,resizable=0,width=600,height=520, top=100, left=300");
        this.addPopupTimer(this)
    },
    onSyncCallback: function(d) {
        var b = this.getEmailConfig(this.owner.saveData.email_type);
        if (Ext.isEmpty(d.token)) {
            this.showSyncMessage(false);
            return
        }
        this.owner.saveData.access_token = d.token;
        if (!Ext.isEmpty(d.refresh_token)) {
            this.owner.saveData.refresh_token = d.refresh_token
        }
        if (!Ext.isEmpty(d.expires_in) && Ext.isNumber(parseInt(d.expires_in, 10))) {
            var c = new Date();
            var a = parseInt(c.getTime() / 1000, 10) + parseInt(d.expires_in, 10) - 100;
            this.owner.saveData.expires_in = a.toString()
        }
        this.syncBtn.setText(b.unsync_text);
        this.showSyncMessage(true);
        this.owner.getButton("next").enable()
    },
    register: function(c, b) {
        if (Ext.isIE || Ext.isIE11) {
            window[b] = c
        } else {
            var a = this;
            this.receiveMessage = function(f) {
                var d = f.browserEvent;
                if (d.origin !== window.location.origin || /setImmediate/.test(d.data)) {
                    return
                }
                var g = JSON.parse(d.data);
                if (g.callback !== b) {
                    return
                }
                c.call(a, g)
            };
            Ext.EventManager.addListener(window, "message", this.receiveMessage)
        }
    },
    unregister: function() {
        if (Ext.isIE || Ext.isIE11) {
            return
        }
        Ext.EventManager.removeListener(window, "message", this.receiveMessage)
    },
    addPopupTimer: function(b) {
        if (b.popup && !b.popup.closed) {
            var a = 1000;
            var c = window.setInterval(function() {
                if (b.popup.closed) {
                    b.unregister();
                    window.clearInterval(c);
                    c = null
                }
            }, a)
        }
    },
    doClosePopup: function() {
        if (this.popup && !this.popup.closed) {
            this.popup.close()
        }
    },
    showSyncMessage: function(d) {
        var c = "";
        var b = this.getEmailConfig(this.owner.saveData.email_type);
        var a = '<span {0} aria-lable="{1}">{1}</span>';
        if (d) {
            c = String.format(a, 'class="syno-ux-note"', b.sync_success)
        } else {
            c = String.format(a, 'style="color:red;"', b.sync_failed)
        }
        this.msgField.setValue(c);
        this.doLayout()
    }
});
SYNO.Personal.Mail.EmailAccountWizard.WelcomeStep = Ext.extend(SYNO.ux.FormPanel, {
    constructor: function(b) {
        var a = Ext.apply({
            cls: "email-account-wizard-welcome-step",
            headline: _T("mail", "add_email_title"),
            padding: "0",
            items: [{
                xtype: "syno_displayfield",
                value: _T("mail", "add_email_desc"),
                style: SYNO.Personal.Mail.Config.emailWizardStyle
            }, this.createDataView()]
        }, b);
        SYNO.Personal.Mail.EmailAccountWizard.WelcomeStep.superclass.constructor.call(this, a)
    },
    createStore: function() {
        var a = new Ext.data.ArrayStore({
            fields: ["name", "type", "img", "text"],
            data: [
                ["MailPlus", "synomail", this.getIconSrc("synomail"), "user@domain.com"],
                ["Gmail", "gmail", this.getIconSrc("gmail"), "user@gmail.com"],
                ["Outlook", "hotmail", this.getIconSrc("outlook"), "user@hotmail.com"],
                ["Customize", "custom", "", "user@domain.com"]
            ]
        });
        if (!SYNO.Personal.Mail.EmailAccountWizard.Utils.isSynoMailClientEnable()) {
            a.removeAt(0)
        }
        return a
    },
    createDataView: function() {
        var a = new Ext.XTemplate('<tpl for=".">', '<div class="email-provider-template" role="option" id={[Ext.id()]} aria-label={name}>', "<tpl if=\"type !== 'custom'\">", '<div class="email-provider-image">', '<img width="200" height="60" src="{img}" draggable="false"/>', "</div>", "</tpl>", "<tpl if=\"type === 'custom'\">", '<div class="email-provider-custom">{name}</div>', "</tpl>", "</div>", "</tpl>");
        var b = new SYNO.ux.FleXcroll.DataView({
            autoFlexcroll: true,
            useARIA: true,
            store: this.createStore(),
            tpl: a,
            singleSelect: true,
            itemSelector: "div.email-provider-template",
            overClass: "email-provider-over",
            listeners: {
                selectionchange: {
                    fn: this.onSelectDone,
                    scope: this
                },
                dblclick: {
                    fn: this.onDblclickDone,
                    scope: this
                }
            },
            onKeyEnter: this.onEnter.createDelegate(this),
            onKeySpace: this.onEnter.createDelegate(this)
        });
        this.dataView = b;
        return b
    },
    onEnter: function() {
        this.onDblclickDone(this.dataView)
    },
    getNext: function() {
        var a = false;
        if (!this.owner.saveData.email_type) {
            this.owner.getMsgBox().alert("", _T("mail", "add_email_desc").slice(0, -1));
            return a
        }
        if ("custom" === this.owner.saveData.email_type) {
            this.owner.customEmailSettingStep.load();
            a = "custom_email_setting"
        } else {
            if ("aolmail" === this.owner.saveData.email_type) {
                this.owner.normalEmailWithoutSyncSettingStep.load();
                a = "normal_email_withoutsync_setting"
            } else {
                if ("synomail" === this.owner.saveData.email_type) {
                    this.owner.synomailSettingStep.load();
                    a = "synomail_setting"
                } else {
                    this.owner.normalEmailSettingStep.load();
                    a = "normal_email_setting"
                }
            }
        }
        return a
    },
    onSelectDone: function(d, c, a) {
        if (0 !== d.getSelectionCount()) {
            var b = d.getSelectedRecords();
            this.owner.saveData.email_type = b[0].data.type;
            this.owner.emptyText = b[0].data.text
        }
    },
    onDblclickDone: function(d, a, c, b) {
        this.onSelectDone(d);
        this.owner.goNext(this.getNext())
    },
    getIconSrc: function(b) {
        var c = "./webman/3rdparty/SynologyApplicationService/images/";
        var a = "";
        if (SYNO.SDS.UIFeatures.test("isRetina")) {
            a += "2x/"
        } else {
            a += "1x/"
        }
        a += "mail_" + b + ".png";
        return c + a
    }
});
