/* Copyright (c) 2020 Synology Inc. All rights reserved. */
/**
 * @class SYNO.Personal.Mail.MailForm
 * @extends SYNO.ux.GridPanel
 * ApplicationService personal mail form
 *
 */
Ext.define("SYNO.Personal.Mail.MailForm", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(a) {
        var b = this.fillConfig(a);
        this.callParent([b]);
        this.mon(this, "afterlayout", this.onLoadAccountData, this, {
            single: true
        })
    },
    fillConfig: function(a) {
        Ext.apply(this, a || {});
        this.pageSize = 50;
        var b = {
            title: _T("mail", "mail_account"),
            cls: "sas-mail-form",
            itemId: "emailAccountForm",
            store: this.createStore(),
            cm: this.initColumnMode(),
            tbar: this.initToolBar(),
            bbar: this.initBottomToolBar(),
            pageSize: this.pageSize,
            loadMask: true,
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: true,
                listeners: {
                    selectionchange: function(g) {
                        var d = true,
                            c = true,
                            e = true;
                        if (0 < g.selections.length) {
                            var f = g.selections.items[0];
                            d = !this.isAccountCanEdit(f);
                            c = false;
                            e = d || f.get("is_default")
                        }
                        this.setToolBarDisable([d, c, e])
                    },
                    scope: this
                }
            }),
            listeners: {
                dblclick: {
                    fn: this.onEditAccount,
                    scope: this
                },
                rowcontextmenu: {
                    fn: function(g, d, f) {
                        if (!this.contextMenu) {
                            this.createContextMenu()
                        }
                        if (0 < this.selModel.selections.length) {
                            var e = this.selModel.selections.items[0];
                            var c = !this.isAccountCanEdit(e);
                            this.contextMenu.getComponent("edit").setDisabled(c);
                            this.contextMenu.getComponent("set_default").setDisabled(c)
                        }
                        this.getSelectionModel().selectRow(d);
                        this.contextMenu.showAt(f.xy)
                    },
                    scope: this
                },
                sortchange: {
                    fn: function() {
                        this.swapDefaultAccountToTop()
                    },
                    scope: this
                }
            }
        };
        return b
    },
    initToolBar: function() {
        this.newBtn = new SYNO.ux.Button({
            btnStyle: SYNO.Personal.Mail.Config.btnStyle,
            itemId: "new_btn",
            text: _T("common", "add"),
            handler: this.onNewAccount,
            disabled: _S("demo_mode"),
            scope: this
        });
        this.editBtn = new SYNO.ux.Button({
            btnStyle: SYNO.Personal.Mail.Config.btnStyle,
            itemId: "edit_btn",
            text: _T("common", "alt_edit"),
            handler: this.onEditAccount,
            scope: this,
            disabled: true
        });
        this.deleteBtn = new SYNO.ux.Button({
            btnStyle: SYNO.Personal.Mail.Config.btnStyle,
            itemId: "delete_btn",
            text: _T("common", "delete"),
            handler: this.onDeleteAccount,
            scope: this,
            disabled: true
        });
        this.setBtn = new SYNO.ux.Button({
            btnStyle: SYNO.Personal.Mail.Config.btnStyle,
            itemId: "set_default_btn",
            text: _T("mail", "set_default"),
            handler: this.onSetDefaultAccount,
            scope: this,
            disabled: true
        });
        var a = new Ext.Toolbar({
            border: false,
            items: [this.newBtn, this.editBtn, this.deleteBtn, this.setBtn]
        });
        return a
    },
    initBottomToolBar: function() {
        var a = new SYNO.ux.PagingToolbar({
            pageSize: this.pageSize,
            store: this.store,
            loadMask: true,
            displayInfo: true,
            showRefreshBtn: true
        });
        this.bbar = a;
        return a
    },
    initColumnMode: function() {
        var a = new Ext.grid.ColumnModel([{
            header: _T("notification", "label_smtp_provider"),
            dataIndex: "email_type",
            width: 120,
            sortable: true,
            renderer: function(h, e, b, d, f, c) {
                var g;
                if ("gmail" === h) {
                    g = "Gmail"
                } else {
                    if ("hotmail" === h) {
                        g = "Outlook"
                    } else {
                        if ("yahoomail" === h) {
                            g = "Yahoo!"
                        } else {
                            if ("aolmail" === h) {
                                g = "AOL"
                            } else {
                                if ("synomail" == h) {
                                    g = "MailPlus"
                                } else {
                                    g = "Customize"
                                }
                            }
                        }
                    }
                }
                return g
            }
        }, {
            header: _T("mail", "application_title"),
            dataIndex: "account",
            sortable: true,
            width: 250,
            renderer: function(g, e, b, d, f, c) {
                if (b.data.auth && "custom" != b.data.email_type) {
                    return g
                } else {
                    return b.data.sender_account
                }
            }
        }, {
            header: _T("common", "status"),
            dataIndex: "state",
            sortable: false,
            width: 120,
            renderer: function(h, e, b, d, f, c) {
                switch (h) {
                    case 1:
                        return ("gmail" !== b.data.email_type) ? _T("mail", "contact_synced") : _T("mail", "mail_gmail_status");
                    case 0:
                        var g = "-";
                        if ("synomail" === b.data.email_type && !this.isSynoMailClientEnable()) {
                            g = _T("common", "disabled")
                        }
                        return g;
                    case -1:
                        return _T("error", "error_auth");
                    case -2:
                        return _T("mail", "mail_smtp_failed");
                    default:
                        return _T("download", "download_status_unknown")
                }
            },
            scope: this
        }, {
            header: _T("mail", "default_use"),
            dataIndex: "is_default",
            sortable: false,
            width: 120,
            renderer: function(g, e, b, d, f, c) {
                if (g) {
                    e.css += "syno-mail-default-use ";
                    e.attr += String.format('aria-label="{0}"', _T("mail", "default_account"))
                }
                return ""
            }
        }]);
        return a
    },
    createStore: function() {
        var a = new Ext.data.Store({
            autoDestroy: true,
            autoLoad: false,
            proxy: new SYNO.API.Proxy({
                api: "SYNO.Personal.MailAccount",
                method: "get",
                version: 1
            }),
            reader: new Ext.data.JsonReader({
                root: "data"
            }, [{
                name: "alias"
            }, {
                name: "email_type"
            }, {
                name: "account"
            }, {
                name: "passwd"
            }, {
                name: "sender_name"
            }, {
                name: "sender_account"
            }, {
                name: "host"
            }, {
                name: "port"
            }, {
                name: "auth"
            }, {
                name: "tls"
            }, {
                name: "state"
            }, {
                name: "is_default"
            }]),
            paramNames: {
                start: "offset",
                limit: "limit"
            },
            listeners: {
                load: {
                    fn: function() {
                        if (0 === this.store.getTotalCount()) {
                            this.maskPanel(true);
                            return
                        }
                        this.swapDefaultAccountToTop()
                    },
                    scope: this
                },
                exception: {
                    fn: function() {
                        var b;
                        if (_S("demo_mode")) {
                            b = _JSLIBSTR("uicommon", "error_demo")
                        } else {
                            b = _T("error", "error_error_system")
                        }
                        this.ownerCt.ownerCt.getMsgBox().alert("", b)
                    },
                    scope: this
                }
            }
        });
        this.store = a;
        return a
    },
    createContextMenu: function() {
        var a = new SYNO.ux.Menu({
            items: [{
                itemId: "edit",
                text: _T("common", "alt_edit")
            }, {
                itemId: "delete",
                text: _T("common", "delete")
            }, {
                itemId: "set_default",
                text: _T("mail", "set_default") || "Set default"
            }],
            listeners: {
                itemclick: function(b) {
                    switch (b.itemId) {
                        case "edit":
                            this.onEditAccount();
                            break;
                        case "delete":
                            this.onDeleteAccount();
                            break;
                        case "set_default":
                            this.onSetDefaultAccount();
                            break;
                        default:
                            break
                    }
                },
                scope: this
            }
        });
        this.contextMenu = a
    },
    maskPanel: function(a) {
        if (a) {
            this.bbar.mask();
            this.getView().el.mask(_T("mail", "no_account_alert") || "Please click Add button to add email account")
        } else {
            this.bbar.unmask();
            this.getView().el.unmask()
        }
    },
    onLoadAccountData: function() {
        var a = this.store.getSortState();
        this.maskPanel(false);
        this.store.load({
            params: {
                offset: 0,
                limit: this.pageSize,
                sort_by: a ? a.field : "",
                sort_direction: a ? a.direction : ""
            }
        })
    },
    onNewAccount: function() {
        var a = {
            owner: this.module,
            module: this,
            appInstance: this.module.appInstance,
            cls: "sas-email-account-wizard",
            blFirstCreate: (0 === this.store.data.items.length)
        };
        var b = new SYNO.Personal.Mail.EmailAccountWizard(a);
        this.mon(b, "beforeclose", this.onLoadAccountData, this);
        b.onOpen()
    },
    swapDefaultAccountToTop: function() {
        var a = this.getDefaultUseRecord();
        if (a) {
            this.store.remove(a, true);
            this.store.insert(0, a)
        }
    },
    getDefaultUseRecord: function() {
        var a = 0;
        var b = this.store.data.items;
        for (a = 0; a < b.length; a++) {
            if (b[a].data.is_default) {
                return b[a]
            }
        }
        return null
    },
    onEditAccount: function() {
        var b = this.getSelectionModel().getSelections();
        if (!b || 0 === b.length) {
            return
        }
        if (!this.isAccountCanEdit(b[0])) {
            return
        }
        var a = new SYNO.Personal.Mail.MailEditDialog({
            owner: this.ownerCt.ownerCt,
            formData: b[0].data,
            buttonCfg: this.dialogButtonCfg
        });
        this.mon(a, "beforeclose", this.onLoadAccountData, this);
        a.show()
    },
    onDeleteAccount: function() {
        var a = this.getSelectionModel().getSelections();
        if (!a || 0 === a.length || !a[0].data) {
            return
        }
        if (a[0].data.is_default && 1 != this.store.data.items.length) {
            this.ownerCt.ownerCt.getMsgBox().alert("", _T("mail", "delete_default_alert"));
            return
        }
        this.ownerCt.ownerCt.getMsgBox().confirm(_T("tree", "leaf_notification"), String.format(_TT("SYNO.Application.Service.Instance", "mail", "confirm_delete_account"), a[0].data.account), function(b) {
            if ("yes" === b) {
                this.ownerCt.ownerCt.setStatusBusy();
                this.sendWebAPI({
                    api: "SYNO.Personal.MailAccount",
                    method: "delete",
                    version: 1,
                    params: {
                        email_type: a[0].data.email_type,
                        alias: a[0].data.alias
                    },
                    callback: function(e, c, d) {
                        this.ownerCt.ownerCt.clearStatusBusy();
                        if (!e) {
                            this.ownerCt.ownerCt.getMsgBox().alert("", _T("error", "error_error_system"))
                        } else {
                            if (a[0].data.is_default) {
                                SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_type", "");
                                SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_alias", "");
                                SYNO.SDS.UserSettings.syncSave()
                            }
                            this.onLoadAccountData()
                        }
                    },
                    scope: this
                })
            }
        }, this)
    },
    onSetDefaultAccount: function() {
        var a = this.getSelectionModel().getSelections();
        if (!Ext.isDefined(a)) {
            return
        }
        this.ownerCt.ownerCt.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Personal.MailAccount",
            method: "update",
            version: 1,
            params: {
                email_type: a[0].data.email_type,
                alias: a[0].data.alias,
                is_default: true
            },
            callback: function(d, b, c) {
                this.ownerCt.ownerCt.clearStatusBusy();
                if (!d) {
                    this.ownerCt.ownerCt.getMsgBox().alert("", _T("error", "error_error_system"))
                } else {
                    SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_type", a[0].data.email_type);
                    SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_alias", a[0].data.alias);
                    SYNO.SDS.UserSettings.syncSave();
                    this.onLoadAccountData()
                }
            },
            scope: this
        })
    },
    setToolBarDisable: function(a) {
        this.editBtn.setDisabled(a[0]);
        this.deleteBtn.setDisabled(a[1]);
        this.setBtn.setDisabled(a[2])
    },
    applyForm: function() {
        return true
    },
    isAccountCanEdit: function(a) {
        if (a.get("email_type") === "yahoomail" || a.get("email_type") === "aolmail") {
            return false
        }
        if (a.get("email_type") === "synomail" && !this.isSynoMailClientEnable()) {
            return false
        }
        return true
    },
    isSynoMailClientEnable: function() {
        return SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.MailClient.Application")
    }
});
Ext.define("SYNO.Personal.Mail.MailEditDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.saveData = {};
        var b = this.fillConfig(a);
        this.callParent([b]);
        this.mon(this, "afterlayout", this.setDataValues, this, {
            single: this
        })
    },
    fillConfig: function(a) {
        Ext.apply(this, a || {});
        this.emailConfig = SYNO.Personal.Mail.EmailAccountWizard.Utils.getEmailConfig(this.formData.email_type);
        var b = {
            owner: this.owner,
            width: 520,
            minWidth: 450,
            autoHeight: true,
            collapsible: false,
            autoScroll: false,
            constrainHeader: true,
            title: _T("common", "alt_edit"),
            items: this.initPanel(),
            buttons: SYNO.Personal.Mail.EmailAccountWizard.Utils.reorderFooterButtons(Ext.apply({
                text: _T("common", "commit"),
                id: "commit_btn",
                btnStyle: "blue",
                scope: this,
                handler: this.onBeforeApply
            }, (a.buttonCfg || {}).confirm), Ext.apply({
                text: _T("common", "close"),
                scope: this,
                handler: this.close
            }, (a.buttonCfg || {}).cancel)),
            listeners: {
                beforeclose: this.onBeforeClose,
                scope: this
            }
        };
        return b
    },
    initPanel: function() {
        var a;
        var c = ("gmail" !== this.formData.email_type);
        var b = ("custom" !== this.formData.email_type && "aolmail" !== this.formData.email_type && "synomail" !== this.formData.email_type);
        if ("custom" === this.formData.email_type) {
            a = SYNO.Personal.Mail.EmailAccountWizard.Utils.getCustomProviderConfig()
        } else {
            if ("synomail" === this.formData.email_type) {
                a = SYNO.Personal.Mail.EmailAccountWizard.Utils.getSynoMailConfig()
            } else {
                a = SYNO.Personal.Mail.EmailAccountWizard.Utils.getNormalProviderConfig(c)
            }
        }
        a.autoFlexcroll = false;
        a.useGradient = false;
        this.syncBtn = new SYNO.ux.Button({
            btnStyle: SYNO.Personal.Mail.Config.btnStyle,
            itemId: "sync_contact",
            text: this.emailConfig.btn_text,
            handler: this.onSyncClick,
            scope: this
        });
        this.msgField = new SYNO.ux.DisplayField({
            itemId: "msg_field",
            htmlEncode: false
        });
        a.trackResetOnLoad = true;
        a.items.push({
            xtype: "compositefield",
            itemId: "sync_composite",
            hideLabel: true,
            hidden: !b,
            disabled: !b,
            items: [this.syncBtn, this.msgField]
        });
        this.panel = new SYNO.ux.FormPanel(a);
        return this.panel
    },
    setDataValues: function() {
        var c = this.panel.getComponent("sender_name");
        var a;
        if ("custom" === this.formData.email_type) {
            var b;
            b = new SYNO.ux.Utils.EnableCheckGroup(this.panel.form, "auth", ["account", "passwd"]);
            if (this.formData.auth) {
                this.formData.passwd = "00000000"
            } else {
                this.formData.account = "";
                this.formData.passwd = ""
            }
            a = _T("notification", "label_smtp_sender_mail");
            SYNO.SDS.Utils.AddTip(c.getEl(), String.format(_T("mail", "sender_name_hint"), a))
        } else {
            if ("synomail" !== this.formData.email_type) {
                this.formData.passwd = "00000000";
                if (this.formData.state === 1) {
                    this.syncBtn.setText(this.emailConfig.unsync_text)
                }
                a = _T("notification", "alert_smtp_user");
                SYNO.SDS.Utils.AddTip(c.getEl(), String.format(_T("mail", "sender_name_hint"), a))
            }
        }
        this.panel.form.setValues(this.formData)
    },
    isNeedTestConnect: function(a) {
        return ("gmail" !== a && "synomail" !== a)
    },
    onBeforeApply: function() {
        var b = this.panel.form.getValues();
        Ext.apply(this.saveData, b);
        this.saveData.email_type = this.formData.email_type;
        this.saveData.alias = this.formData.alias;
        this.saveData.auth = this.saveData.auth || "true";
        this.saveData.tls = this.saveData.tls || "true";
        this.saveData.test_connect = this.isNeedTestConnect(this.saveData.email_type);
        if (!this.panel.form.isDirty() && !Ext.isDefined(this.saveData.access_token)) {
            this.close();
            return
        }
        if (!this.panel.form.isValid()) {
            this.getMsgBox().alert("", _T("common", "forminvalid"));
            return
        }
        var d = this.panel.getComponent("passwd");
        if (d && d.isDirty()) {
            this.saveData.passwd = this.panel.getComponent("passwd").getValue()
        } else {
            delete this.saveData.passwd
        }
        this.saveData.new_alias = this.panel.getComponent("account").getValue() || this.panel.getComponent("sender_account").getValue();
        if ("custom" === this.saveData.email_type) {
            this.saveData.new_alias = this.panel.getComponent("host").getValue() + "_" + this.saveData.new_alias
        }
        this.saveData.sender_name = this.saveData.sender_name || this.saveData.sender_account || this.saveData.account;
        var a = SYNO.Personal.Mail.EmailAccountWizard.Utils.getEmailProviderName(this.saveData.email_type);
        var c = String.format(_T("mail", "email_setting_alert"), this.saveData.account, a);
        if (SYNO.Personal.Mail.EmailAccountWizard.Utils.isNeedAlert(this.saveData.account, this.saveData.email_type)) {
            this.getMsgBox().confirm("", c, function(e) {
                if ("yes" === e) {
                    this.onApply()
                }
            }, this);
            return
        }
        this.onApply()
    },
    onApply: function() {
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Personal.MailAccount",
            method: "update",
            version: 1,
            params: this.saveData,
            encryption: ["passwd"],
            callback: function(c, b, a) {
                this.clearStatusBusy();
                if (!c) {
                    this.getMsgBox().alert("", this.getAPIError(b.code));
                    return
                }
                if (this.saveData.alias === SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_alias")) {
                    SYNO.SDS.UserSettings.setProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_alias", this.saveData.new_alias);
                    SYNO.SDS.UserSettings.syncSave()
                }
                this.close()
            },
            scope: this
        })
    },
    onBeforeClose: function() {
        this.doClosePopup()
    },
    onSyncClick: function(a) {
        if (this.emailConfig.btn_text === a.getText() || this.formData.email_type === "gmail") {
            this.onSyncContacts(this.formData.email_type)
        } else {
            this.onCancelSyncContacts()
        }
    },
    getIndexDSUrl: function() {
        var a = window.location.protocol + "//" + window.location.hostname;
        if (window.location.port !== "") {
            a = a + ":" + window.location.port
        }
        if (window.location.pathname !== "" && window.location.pathname.indexOf("webman") < 0) {
            a = a + window.location.pathname
        }
        return a + "/webman/3rdparty/SynologyApplicationService/index_ds.html"
    },
    onSyncContacts: function(a) {
        var c = "_mailFormOAuthCallback";
        this.register(this.onSyncCallback.createDelegate(this), c);
        var b = "https://synooauth.synology.com/email/login.php?version=2&callback=" + c + "&host=" + this.getIndexDSUrl() + "&type=" + a;
        this.popup = window.open(b, "mywindow", "menubar=1,resizable=0,width=600,height=520, top=100, left=300");
        this.addPopupTimer(this)
    },
    onSyncCallback: function(c) {
        var b = new Date();
        var a = parseInt(b.getTime() / 1000, 10) + parseInt(c.expires_in, 10) - 100;
        this.saveData.access_token = c.token;
        this.saveData.refresh_token = c.refresh_token;
        this.saveData.expires_in = a.toString();
        this.syncBtn.setText(this.emailConfig.unsync_text);
        this.showSyncMessage();
        this.onBeforeApply()
    },
    onCancelSyncContacts: function() {
        this.saveData.access_token = "";
        this.saveData.refresh_token = "";
        this.saveData.expires_in = "";
        this.syncBtn.setText(this.emailConfig.btn_text);
        if (!Ext.isDefined(this.commitBtn)) {
            this.commitBtn = Ext.getCmp("commit_btn")
        }
        this.commitBtn.setDisabled(this.emailConfig.cancel)
    },
    showSyncMessage: function() {
        var b = '<span class="syno-ux-note">' + _T("mail", "sync_success") + "</span>";
        this.msgField.setValue(b);
        this.doLayout();
        var a = new Ext.util.DelayedTask(function() {
            if (Ext.isDefined(this.msgField.el.dom)) {
                this.msgField.setValue("")
            }
        }, this);
        a.delay(3000)
    },
    getAPIError: function(a) {
        switch (a) {
            case 116:
                return _JSLIBSTR("common", "error_demo");
            case 8007:
                return _T("mail", "account_already_saved");
            case 8011:
                return _T("mail", "mail_setting_error");
            default:
                return _T("error", "error_error_system")
        }
    },
    register: function(c, b) {
        if (Ext.isIE || Ext.isIE11) {
            window[b] = c
        } else {
            var a = this;
            this.receiveMessage = function(f) {
                var d = f.browserEvent;
                if (d.origin !== window.location.origin || /setImmediate/.test(d.data)) {
                    return
                }
                var g = JSON.parse(d.data);
                if (g.callback !== b) {
                    return
                }
                c.call(a, g)
            };
            Ext.EventManager.addListener(window, "message", this.receiveMessage)
        }
    },
    unregister: function() {
        if (Ext.isIE || Ext.isIE11) {
            return
        }
        Ext.EventManager.removeListener(window, "message", this.receiveMessage)
    },
    addPopupTimer: function(b) {
        if (b.popup && !b.popup.closed) {
            var a = 1000;
            var c = window.setInterval(function() {
                if (b.popup.closed) {
                    b.unregister();
                    window.clearInterval(c);
                    c = null
                }
            }, a)
        }
    },
    doClosePopup: function() {
        if (this.popup && !this.popup.closed) {
            this.popup.close()
        }
    }
});
Ext.define("SYNO.Personal.Mail.MailDialog.Application", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.Personal.Mail.MailDialog.MainWindow",
    constructor: function() {
        this.callParent(arguments)
    }
});
Ext.define("SYNO.Personal.Mail.MailDialog.MainWindow", {
    extend: "SYNO.SDS.AppWindow",
    constructor: function() {
        this.isSetAttach = false;
        this.contactCacheData = {};
        this.email_type = SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_type");
        this.alias = SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_alias");
        var a = this.fillConfig();
        this.callParent([a]);
        this.mon(this, "afterlayout", this.onLoadData, this, {
            single: true
        })
    },
    fillConfig: function() {
        Ext.apply(this);
        var a = {
            owner: this.owner,
            width: 700,
            autoHeight: true,
            collapsible: false,
            resizable: false,
            showHelp: true,
            maximizable: false,
            title: _T("mail", "application_title"),
            cls: "sas-mail-dialog",
            buttons: [{
                btnStyle: "blue",
                itemId: "submit_button",
                text: _T("common", "send"),
                handler: this.onBeforeConfirm,
                disabled: _S("demo_mode"),
                scope: this
            }, {
                text: _T("common", "cancel"),
                handler: this.onClose,
                scope: this
            }],
            items: this.initPanel()
        };
        return a
    },
    initPanel: function() {
        var e = this;
        e.store = new Ext.data.JsonStore({
            fields: ["name", "address"],
            data: [],
            sortInfo: {
                field: "address",
                direction: "ASC"
            }
        });
        e.attachmentStore = new Ext.data.JsonStore({
            fields: ["filename", "path", "filesize", "formatsize", "deleted"],
            data: []
        });
        e.comboStore = new Ext.data.ArrayStore({
            fields: ["alias", "value", "account"],
            data: []
        });
        var c = new Ext.XTemplate('<tpl for="."><div class="x-combo-list-item" style="height: 53px"><div style="margin-left:10px"><tpl if="name!=address;"><div style="height:20px;margin-top:4px;font-weight:bold;">{name:htmlEncode}</div></tpl><div class="syno-mail-contactaccount">{address:htmlEncode}</div></div></div></tpl>');
        var f = new Ext.XTemplate('<tpl for="."><div class="x-combo-list-item" style="width:375px;border-color:transparent;"><div style="max-width:250px;overflow:hidden;float:left;text-overflow:ellipsis; white-space:nowrap;">{filename}</div> <div style="margin-left:5px;float:left;">({formatsize})</div></div></tpl>');
        var h = new Ext.XTemplate('<tpl if"name!=null && name!=&quot;&quot;";>{name:htmlEncode}</tpl><tpl if="name==null || name==&quot;&quot;">{address:htmlEncode}</tpl>');
        var g = function(j) {
            var i = new RegExp("^" + j.query + "|\\s+" + j.query, "gi");
            this.store.filterBy(function(k) {
                if (k.data.name && null !== k.data.name.match(i)) {
                    return true
                }
                if (k.data.address && null !== k.data.address.match(i)) {
                    return true
                }
                return false
            });
            j.combo.onLoad();
            return false
        };
        var d = function(j, i) {
            if ("" === i) {
                return
            }
            j.addNewItem({
                name: i,
                address: i
            }, true)
        };
        var b = {
            autoFlexcroll: true,
            autoHeight: true,
            cls: "mail-dialog-superboxselect",
            useGradient: false,
            items: [{
                xtype: "syno_superboxselect",
                fieldLabel: _T("mail", "mail_to_desc"),
                expandBtnCls: "mail-dialog-superboxselect-expand",
                itemId: "mail_to_field",
                width: 465,
                hideTrigger: true,
                typeAhead: false,
                allowBlank: false,
                displayField: "name",
                displayFieldTpl: h,
                valueField: "address",
                allowAddNewData: true,
                addNewDataOnBlur: true,
                mode: "local",
                tpl: c,
                listeners: {
                    newitem: d,
                    beforequery: g,
                    scope: this
                },
                store: e.store
            }, {
                xtype: "syno_superboxselect",
                fieldLabel: _T("mail", "mail_cc_desc"),
                itemId: "mail_cc_field",
                expandBtnCls: "mail-dialog-superboxselect-expand",
                width: 465,
                hideTrigger: true,
                typeAhead: true,
                displayField: "name",
                displayFieldTpl: h,
                valueField: "address",
                allowAddNewData: true,
                addNewDataOnBlur: true,
                mode: "local",
                tpl: c,
                listeners: {
                    newitem: d,
                    beforequery: g,
                    scope: this
                },
                store: e.store
            }, {
                xtype: "syno_combobox",
                fieldLabel: _T("mail", "mail_from_desc"),
                itemId: "mail_from",
                value: "",
                displayField: "account",
                width: 465,
                store: e.comboStore,
                listeners: {
                    select: function(j, k, i) {
                        this.email_type = k.data.value;
                        this.alias = k.data.alias;
                        this.loadContactData(this.email_type, this.alias)
                    },
                    scope: this
                }
            }, {
                xtype: "syno_textfield",
                fieldLabel: _T("mail", "mail_subject"),
                itemId: "mail_subject",
                width: 465
            }, {
                xtype: "syno_displayfield"
            }, {
                xtype: "syno_tinymce",
                itemId: "htmleditor",
                owner: this,
                height: 200,
                width: 650,
                mceConfig: {
                    plugins: ["textcolor", "filestation_attachment", "syno_fontselect", "syno_fontsizeselect"],
                    toolbar: "syno_fontselect syno_fontsizeselect | forecolor backcolor | bold italic underline | alignleft aligncenter alignright | numlist bullist removeformat | filestation_attachment",
                    statusbar: false,
                    forced_root_block: "div",
                    extended_valid_elements: "img[class|src|border=0|alt|title|hspace|vspace|width|height|align|name|ref|adjust|content_id]",
                    menubar: false
                },
                listeners: {
                    beforeAddAttach: this.checkAttach,
                    initialize: this.initAttachment,
                    scope: this
                }
            }, {
                xtype: "syno_displayfield"
            }, {
                xtype: "syno_superboxselect",
                cls: "mail-ie8-superboxselect",
                fieldLabel: _T("mail", "mail_attachment"),
                itemId: "mail_attachment",
                expandBtnCls: "mail-dialog-superboxselect-expand",
                width: 465,
                hideTrigger: true,
                typeAhead: false,
                editable: false,
                displayField: "filename",
                valueField: "path",
                allowAddNewData: true,
                addNewDataOnBlur: true,
                mode: "local",
                displayFieldTpl: f,
                hidden: !Ext.isIE8,
                disabled: !Ext.isIE8,
                store: e.attachmentStore
            }]
        };
        var a = new SYNO.ux.FormPanel(b);
        this.panel = a;
        return a
    },
    onOpen: function(d) {
        this.appTitle = (Ext.isEmpty(d.appTitle)) ? "tree:leaf_filebrowser" : d.appTitle;
        this.appName = (Ext.isEmpty(d.appName)) ? "dsm" : d.appName;
        this.email_type = (Ext.isString(d.email_type)) ? d.email_type : this.email_type;
        this.alias = (Ext.isString(d.alias)) ? d.alias : this.alias;
        this.taskid = (Ext.isString(d.taskid)) ? d.taskid : "";
        this.mailContent = (Ext.isString(d.content)) ? d.content : "";
        this.attachmentList = (Ext.isArray(d.data)) ? d.data : this.parseObjectAttachment(d.data);
        this.inlineAttachment = (Ext.isObject(d.content_attachment)) ? this.parseObjectAttachment(d.content_attachment) : [];
        var b = 0,
            c = this.panel.getComponent("htmleditor").getEditor();
        if (c && !this.isSetAttach) {
            if (Ext.isIE8) {
                this.addAttachRecord(this.attachmentList)
            } else {
                for (b = 0; b < this.attachmentList.length; b++) {
                    var a = this.attachmentList[b];
                    c.plugins.filestation_attachment.addAttachRecord(a)
                }
            }
        }
        this.callParent(arguments)
    },
    initAttachment: function(d, c) {
        var b = 0;
        c.plugins.filestation_attachment.initMode(c);
        if (!this.isSetAttach && this.attachmentList) {
            this.isSetAttach = true;
            if (Ext.isIE8) {
                this.addAttachRecord(this.attachmentList)
            } else {
                for (b = 0; b < this.attachmentList.length; b++) {
                    var a = this.attachmentList[b];
                    c.plugins.filestation_attachment.addAttachRecord(a)
                }
            }
        }
    },
    onBeforeConfirm: function() {
        if ("" === this.panel.getComponent("mail_to_field").getValue()) {
            this.getMsgBox().alert("Title", _T("mail", "mailto_alert"));
            return
        }
        if ("" === this.panel.getComponent("mail_subject").getValue()) {
            this.getMsgBox().confirm("Title", _T("mail", "mail_subject_alert"), function(a) {
                if ("yes" === a) {
                    this.onConfirm()
                }
            }, this);
            return
        }
        this.onConfirm()
    },
    onConfirm: function() {
        var g = this;
        var j = this.panel.getComponent("mail_to_field").getValue().split(",");
        var a = this.panel.getComponent("mail_cc_field").getValue();
        var h = this.panel.getComponent("mail_subject").getValue();
        var e = this.BodyValueGet();
        var c = 0,
            d = [],
            f;
        var k = this.getAttachArray();
        for (c = 0; c < k.length; c++) {
            f = k[c];
            d.push({
                path: f.path,
                filesize: f.filesize,
                symlink: (Ext.isEmpty(f.symlink)) ? "" : f.symlink,
                app_name: (Ext.isEmpty(f.app_name)) ? "dsm" : f.app_name,
                deleted: (Ext.isEmpty(f.deleted)) ? false : f.deleted
            })
        }
        var b = {
            app_name: this.appName,
            app_title: this.appTitle,
            email_type: this.email_type,
            alias: this.alias,
            to: Ext.encode(j),
            subject: h,
            body: e,
            attachment: Ext.encode(d),
            inline_attachment: Ext.encode(this.inlineAttachment)
        };
        if (!Ext.isEmpty(a)) {
            b.cc = Ext.encode(a.split(","))
        }
        if (this.taskid && "" !== this.taskid) {
            b.taskid = this.taskid
        }
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Personal.MailAccount.Mail",
            method: "send",
            version: 1,
            params: b,
            callback: function(n, i, l) {
                if (n) {
                    g.onAddBkgTask(i.taskid);
                    this.doClose()
                } else {
                    var m = SYNO.Personal.Mail.MailDialog.Utils.APIErrorGet(i.code);
                    g.getMsgBox().alert("Title", m)
                }
                this.clearStatusBusy()
            },
            scope: this
        })
    },
    onAddBkgTask: function(a) {
        var d = this.panel.getComponent("mail_from").getValue();
        var c = this.panel.getComponent("mail_to_field").getValue().split(",");
        var b = this.panel.getComponent("mail_subject").getValue();
        b = Ext.util.Format.htmlEncode(b);
        SYNO.SDS.MailTaskMgr.addWebAPITask({
            id: a,
            title: b || d,
            sender: d,
            reciever: c,
            subject: b,
            query: {
                api: "SYNO.Personal.MailAccount.Mail",
                method: "status",
                version: 1,
                params: {
                    taskid: a
                }
            },
            cancel: {
                api: "SYNO.Personal.MailAccount.Mail",
                method: "stop",
                version: 1,
                params: {
                    taskid: a
                }
            }
        })
    },
    setFormData: function(g) {
        var c = 0,
            e = this,
            b = [];
        var f = g.to.concat(g.cc);
        var a = null;
        for (c = 0; c < f.length; c++) {
            a = f[c];
            b.push({
                name: a,
                address: a
            })
        }
        this.store.loadData(b, true);
        this.panel.getComponent("mail_to_field").setValue(g.to.toString());
        this.panel.getComponent("mail_cc_field").setValue(g.cc.toString());
        this.panel.getComponent("mail_subject").setValue(g.subject);
        this.BodyValueSet(g.body);
        if (Ext.isIE8) {
            this.addAttachRecord(g.attachment)
        } else {
            var d = e.panel.getComponent("htmleditor").getEditor();
            for (c = 0; c < g.attachment.length; c++) {
                a = g.attachment[c];
                d.plugins.filestation_attachment.addAttachRecord({
                    path: a.path,
                    filesize: a.filesize
                })
            }
        }
        if (!Ext.isEmpty(g.inline_attachment)) {
            this.inlineAttachment = g.inline_attachment
        }
    },
    onLoadData: function() {
        var a = [];
        a.push({
            api: "SYNO.Personal.MailAccount",
            method: "get",
            version: 1
        });
        a.push({
            api: "SYNO.Personal.MailAccount.Contacts",
            method: "list",
            version: 1,
            params: {
                email_type: this.email_type,
                alias: this.alias
            }
        });
        if (this.taskid) {
            a.push({
                api: "SYNO.Personal.MailAccount.Mail",
                method: "status",
                version: 1,
                params: {
                    taskid: this.taskid
                }
            })
        }
        this.setStatusBusy();
        this.sendWebAPI({
            params: {},
            compound: {
                params: a
            },
            scope: this,
            callback: function(f, b, e, c) {
                if (f) {
                    this.setAccountData(b.result);
                    if (this.taskid) {
                        if (b.result[2].error) {
                            var d = SYNO.Personal.Mail.MailDialog.Utils.APIErrorGet(b.result[2].error.code);
                            this.getMsgBox().alert("Title", d)
                        } else {
                            this.setFormData(b.result[2].data)
                        }
                    }
                } else {
                    this.getMsgBox().alert("Title", _T("error", "error_error_system"))
                }
                this.clearStatusBusy()
            }
        })
    },
    setAccountData: function(e) {
        var f = 0,
            b, k = false;
        var a, c, l = {},
            g = "confirm";
        this.BodyValueSet(this.mailContent);
        if (e[0].error) {
            b = SYNO.Personal.Mail.MailDialog.Utils.APIErrorGet(e[0].error.code);
            this.getMsgBox().alert("Title", b, function() {
                this.doClose()
            }, this);
            return
        }
        a = e[0].data.data;
        for (f = 0; f < a.length; f++) {
            var d = a[f];
            var h, j;
            if (d.is_default) {
                l.account = d.sender_account || d.account;
                j = SYNO.Personal.Mail.MailDialog.Utils.getEmailProviderName(d.email_type);
                l.account = l.account + " (" + j + ")";
                l.alias = d.alias;
                l.email_type = d.email_type
            }
            if (d.email_type === "synomail" && !this.isSynoMailClientEnable()) {
                continue
            }
            h = d.sender_account || d.account;
            j = SYNO.Personal.Mail.MailDialog.Utils.getEmailProviderName(d.email_type);
            h = h + " (" + j + ")";
            this.comboStore.loadData([
                [d.alias, d.email_type, h]
            ], true)
        }
        if (0 === a.length) {
            if (true === _S("standalone")) {
                b = _T("mail", "mail_setup_in_dsm");
                g = "alert"
            } else {
                b = _T("mail", "mail_setup_hint")
            }
            k = true
        }
        if (l.email_type === "synomail" && !this.isSynoMailClientEnable()) {
            b = _T("mail", "default_alert");
            k = true
        }
        if (k) {
            this.getMsgBox()[g]("Title", b, function(i) {
                if ("yes" === i) {}
                this.doClose()
            }, this);
            return
        }
        this.panel.getComponent("mail_from").setValue(l.account);
        if (e[1].error) {
            b = SYNO.Personal.Mail.MailDialog.Utils.APIErrorGet(e[1].error.code);
            b = String.format(b, this.email_type);
            this.setStatusError({
                text: b,
                clear: true
            });
            return
        }
        c = e[1].data.result;
        this.contactCacheData[this.alias] = c;
        this.store.loadData(c, true)
    },
    checkAttach: function(d, k, m, n) {
        var e, c, a, l = 0,
            g = 0;
        var h = m.records;
        var f = this.getAttachArray();
        var b = SYNO.Personal.Mail.MailDialog.Utils.getAttachLimitByType(this.email_type);
        if (Ext.isEmpty(this.email_type)) {
            return true
        }
        for (e = 0; e < f.length; e++) {
            g++;
            l += f[e].filesize;
            for (c = 0; c < h.length; c++) {
                if (h[c].data.path === f[e].path) {
                    g--;
                    l -= f[e].filesize;
                    break
                }
            }
        }
        if (10 < g + h.length) {
            a = String.format(_T("mail", "filenum_limit_alert"), 10);
            this.getMsgBox().alert("Title", a);
            return false
        }
        for (e = 0; e < h.length; e++) {
            if (h[e].data.isdir) {
                a = _T("mail", "filedir_limit_alert");
                this.getMsgBox().alert("Title", a);
                return false
            }
            l += h[e].data.filesize
        }
        if (b * 1024 * 1024 < l) {
            a = String.format(_T("mail", "filesize_limit_alert"), b);
            this.getMsgBox().alert("Title", a);
            return false
        }
        if (Ext.isIE8) {
            this.addAttachRecord(m.records, k);
            return false
        }
        return true
    },
    addAttachRecord: function(a, b) {
        var c = this.panel.getComponent("mail_attachment");
        a.each(function(d) {
            var e = {};
            if (Ext.isDefined(d.path)) {
                e.path = d.path;
                e.filename = e.path.substring(e.path.lastIndexOf("/") + 1);
                e.filesize = d.filesize;
                e.formatsize = Ext.util.Format.fileSize(d.filesize);
                e.deleted = (Ext.isEmpty(d.deleted)) ? false : d.deleted
            } else {
                e.path = d.get("path");
                e.filename = e.path.substring(e.path.lastIndexOf("/") + 1);
                e.filesize = d.get("filesize");
                e.formatsize = Ext.util.Format.fileSize(d.get("filesize"))
            }
            c.addNewItem(e)
        });
        if (Ext.isDefined(b)) {
            b.close()
        }
    },
    getAttachArray: function() {
        var a = [];
        if (Ext.isIE8) {
            var c = this.panel.getComponent("mail_attachment");
            var b = c.getSelectedRecords();
            b.each(function(d) {
                a.push(d.data)
            })
        } else {
            a = this.panel.getComponent("htmleditor").getEditor().plugins.filestation_attachment.getAttachArray()
        }
        return a
    },
    BodyValueGet: function() {
        var b = this.panel.getComponent("htmleditor").getDoc();
        Ext.iterate(b.querySelectorAll("img,input[content_id]"), function(d, c) {
            var e = d.getAttribute("content_id");
            if (e) {
                e = "cid:" + e;
                d.setAttribute("src", e)
            }
        });
        var a = b.body.innerHTML;
        return a
    },
    BodyValueSet: function(a) {
        var b = this.panel.getComponent("htmleditor").getDoc();
        b.body.innerHTML = a
    },
    parseObjectAttachment: function(c) {
        var a = [],
            b = this.appName;
        if (!Ext.isObject(c)) {
            return a
        }
        Ext.iterate(c, function(d, e) {
            a.push({
                app_name: b,
                path: e.name,
                symlink: e.symlink,
                filesize: e.size,
                cid: d,
                deleted: e.remove
            })
        });
        return a
    },
    loadContactData: function(b, a) {
        if (this.contactCacheData[a]) {
            this.store.loadData(this.contactCacheData[a]);
            return
        }
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Personal.MailAccount.Contacts",
            method: "list",
            version: 1,
            params: {
                email_type: b,
                alias: a
            },
            callback: function(f, c, d) {
                if (f) {
                    this.contactCacheData[a] = c.result;
                    this.store.loadData(c.result)
                } else {
                    var e = SYNO.Personal.Mail.MailDialog.Utils.APIErrorGet(c.code);
                    e = String.format(e, this.email_type);
                    this.setStatusError({
                        text: e,
                        clear: true
                    })
                }
                this.clearStatusBusy()
            },
            scope: this
        })
    },
    onClose: function() {
        this.getMsgBox().confirm("Title", _T("mail", "mail_leave_desc"), function(a) {
            if ("yes" === a) {
                this.onBeforeClose()
            }
        }, this);
        return false
    },
    onBeforeClose: function() {
        var c = 0,
            e = [],
            b;
        var a = this.getAttachArray();
        if ("dsm" === this.appName) {
            this.doClose();
            return
        }
        for (c = 0; c < a.length; c++) {
            b = a[c];
            e.push({
                path: b.path,
                filesize: b.filesize,
                symlink: (Ext.isEmpty(b.symlink)) ? "" : b.symlink,
                app_name: (Ext.isEmpty(b.app_name)) ? "dsm" : b.app_name,
                deleted: (Ext.isEmpty(b.deleted)) ? false : b.deleted
            })
        }
        var d = {
            attachment: Ext.encode(e),
            inline_attachment: Ext.encode(this.inlineAttachment)
        };
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Personal.MailAccount.Mail",
            method: "clean",
            version: 1,
            params: d,
            callback: function(h, f, g) {
                this.clearStatusBusy();
                this.doClose()
            },
            scope: this
        })
    },
    onClickHelp: function() {
        var a = "SYNO.SDS.App.FileStation3.Instance:FileBrowser/emailaccount.html";
        SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
            topic: a
        }, false)
    },
    isSynoMailClientEnable: function() {
        return SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.MailClient.Application")
    }
});
Ext.namespace("SYNO.Personal.Mail.MailDialog.Utils");
Ext.apply(SYNO.Personal.Mail.MailDialog.Utils, {
    className: "SYNO.Personal.Mail.MailDialog.Application",
    launchFn: function(d) {
        var e = 0,
            c = 0,
            f = [],
            g;
        var a = SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "email_type");
        var b = SYNO.Personal.Mail.MailDialog.Utils.getAttachLimitByType(a);
        if (10 < d.length) {
            g = String.format(_T("mail", "filenum_limit_alert"), 10);
            this.ownerCt.getMsgBox().alert("Title", g);
            return
        }
        for (e = 0; e < d.length; e++) {
            if (d[e].data.isdir) {
                g = _T("mail", "filedir_limit_alert");
                this.ownerCt.getMsgBox().alert("Title", g);
                return
            }
            c += d[e].data.filesize
        }
        if (!Ext.isEmpty(a) && b * 1024 * 1024 < c) {
            g = String.format(_T("mail", "filesize_limit_alert"), b);
            this.ownerCt.getMsgBox().alert("Title", g);
            return
        }
        for (e = 0; e < d.length; e++) {
            f.push(d[e].data)
        }
        SYNO.SDS.AppLaunch("SYNO.Personal.Mail.MailDialog.Application", {
            data: f
        })
    },
    launchMailFn: function(a) {
        SYNO.SDS.AppLaunch("SYNO.Personal.Mail.MailDialog.Application", a)
    },
    checkFn: function(b, a) {
        if (1 === a.length && a[0].data.isdir) {
            return false
        }
        return true
    },
    getAttachLimitByType: function(a) {
        if ("gmail" === a) {
            return 25
        } else {
            if ("hotmail" === a) {
                return 25
            } else {
                if ("yahoomail" === a) {
                    return 25
                } else {
                    if ("aolmail" === a) {
                        return 25
                    } else {
                        return 15
                    }
                }
            }
        }
    },
    APIErrorGet: function(a) {
        switch (a) {
            case 116:
                return _JSLIBSTR("uicommon", "error_demo");
            case 8001:
            case 8002:
            case 8003:
            case 8004:
                return _T("error", "error_error_system");
            case 8005:
                return _T("error", "error_privilege_not_enough");
            case 8006:
            case 8007:
            case 8008:
            case 8009:
            case 8010:
            case 8011:
                return _T("error", "error_error_system");
            case 8012:
                return _T("mail", "sync_expire");
            case 8013:
                return _T("error", "error_error_system");
            default:
                return _T("error", "error_error_system")
        }
    },
    getEmailProviderName: function(a) {
        if ("gmail" === a) {
            return "Gmail"
        } else {
            if ("hotmail" === a) {
                return "Outlook"
            } else {
                if ("yahoomail" === a) {
                    return "Yahoo!"
                } else {
                    if ("aolmail" === a) {
                        return "AOL"
                    } else {
                        if ("synomail" === a) {
                            return "MailPlus"
                        } else {
                            return "Custom"
                        }
                    }
                }
            }
        }
    }
});
