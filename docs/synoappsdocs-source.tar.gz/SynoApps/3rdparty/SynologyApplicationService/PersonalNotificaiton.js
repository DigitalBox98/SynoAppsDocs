/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.Personal.Notification");
/**
 * @class SYNO.Personal.Notification.WebPush
 * ApplicationService personal notification push
 *
 */
Ext.define("SYNO.Personal.Notification.WebPush", {
    statics: {
        SERVICE_WORKER_URL: "./webman/3rdparty/SynologyApplicationService/browser_pair/service-worker.js",
        arrayToBase64Url: function(e) {
            var c = new Uint8Array(e);
            var d = 0;
            var b = c.byteLength;
            var a = window.btoa(String.fromCharCode.apply(null, c.subarray(d, b)));
            return a.replace(/\=/g, "").replace(/\+/g, "-").replace(/\//g, "_")
        },
        toUrlBase64: function(a) {
            return btoa(a).replace(/\+/g, "-").replace(/\//g, "_").replace(/=/g, "")
        },
        fromUrlBase64: function(a) {
            return atob((a + "====".substr(a.length % 4)).replace(/\-/g, "+").replace(/\_/g, "/"))
        },
        strToArray: function(d) {
            var b = d.split("");
            var c = new Uint8Array(b.length);
            var a;
            for (a = 0; a < b.length; a++) {
                if (b[a]) {
                    c[a] = b[a].charCodeAt(0)
                }
            }
            return c
        },
        isSupportWebPushAPI: function(c, b, a) {
            if (location.protocol == "http:") {
                return false
            }
            if ((c != "Chrome") && (c != "Firefox")) {
                return false
            }
            if (!("serviceWorker" in navigator) || !("PushManager" in window)) {
                return false
            }
            if ((c == "Chrome") && (b < 52)) {
                return false
            }
            if (a.indexOf("6281") != -1 || a.indexOf("qoriq") != -1) {
                return false
            }
            return true
        },
        getVapidPublicKey: function() {
            return new Promise(function(b, a) {
                SYNO.API.Request({
                    api: "SYNO.Personal.Notification.VapidPublicKey",
                    method: "get",
                    version: 1,
                    params: {},
                    scope: null,
                    callback: function(e, d, c) {
                        if (!e) {
                            a(d);
                            return
                        }
                        b(d)
                    }
                })
            })
        },
        registerServiceWorker: function() {
            return new Promise(function(b, a) {
                if (("serviceWorker" in navigator) && ("PushManager" in window)) {
                    navigator.serviceWorker.register(SYNO.Personal.Notification.WebPush.SERVICE_WORKER_URL, {
                        scope: "/"
                    }).then(function(c) {
                        if (c.update) {
                            c.update().then(function() {
                                b(c)
                            })
                        } else {
                            b(c)
                        }
                    })["catch"](function(c) {
                        a(c)
                    })
                } else {
                    a()
                }
            })
        },
        getSWRegistration: function() {
            if (navigator.serviceWorker) {
                return navigator.serviceWorker.getRegistration(SYNO.Personal.Notification.WebPush.SERVICE_WORKER_URL)
            } else {
                return Promise.reject()
            }
        },
        getEndpoint: function() {
            return SYNO.Personal.Notification.WebPush.getSWRegistration().then(function(a) {
                if (!a) {
                    return Promise.reject()
                }
                return a.pushManager.getSubscription()
            }).then(function(a) {
                if (!a || !a.endpoint) {
                    return Promise.reject()
                }
                return Promise.resolve(a.endpoint)
            })
        },
        subscribeNotification: function(a, b) {
            return new Promise(function(d, c) {
                return a.pushManager.subscribe({
                    userVisibleOnly: true,
                    applicationServerKey: SYNO.Personal.Notification.WebPush.strToArray(SYNO.Personal.Notification.WebPush.fromUrlBase64(b))
                }).then(function(f) {
                    var g = {};
                    if (!f.endpoint) {
                        c();
                        return
                    }
                    if (!f.getKey) {
                        c();
                        return
                    }
                    g.endpoint = f.endpoint;
                    g.p256dh = SYNO.Personal.Notification.WebPush.arrayToBase64Url(f.getKey("p256dh"));
                    try {
                        g.auth = SYNO.Personal.Notification.WebPush.arrayToBase64Url(f.getKey("auth"))
                    } catch (h) {}
                    d(g)
                })["catch"](function(e) {
                    SYNO.Personal.Notification.WebPush.unsubscribeNotification(a, b).then(function() {
                        c(e)
                    })["catch"](function() {
                        c(e)
                    })
                })
            })
        },
        unsubscribeNotification: function(a, b) {
            return new Promise(function(d, c) {
                return a.pushManager.getSubscription().then(function(e) {
                    if (!e) {
                        d()
                    }
                    return e.unsubscribe()
                }).then(function(e) {
                    d()
                })["catch"](function(e) {
                    c(e)
                })
            })
        },
        receiveSWMessage: function(a) {
            var b = a.data;
            if (b && b.method === "check") {
                b.isPkgClient = (b.event_category === _S("standaloneAppName"));
                a.ports[0].postMessage(b)
            }
        }
    }
});
Ext.ns("SYNO.Personal.Notification");
Ext.define("SYNO.Personal.Notification.Utils", {
    statics: {
        PAIR_BASE_URL: "/webman/3rdparty/SynologyApplicationService/browser_pair/pair.html",
        isPaired: null,
        sendAPIRequest: function(b, d, a, c) {
            return new Promise(function(f, e) {
                SYNO.API.Request({
                    api: b,
                    method: d,
                    version: a,
                    params: c,
                    scope: null,
                    callback: function(i, h, g) {
                        if (!i) {
                            e(h);
                            return
                        }
                        f(h)
                    }
                })
            })
        },
        getIdentifier: function() {
            return new Promise(function(b, a) {
                SYNO.API.Request({
                    api: "SYNO.Personal.Notification.Identifier",
                    method: "get",
                    version: 1,
                    params: {},
                    scope: null,
                    callback: function(e, d, c) {
                        if (!e) {
                            a(d);
                            return
                        }
                        b(d)
                    }
                })
            })
        },
        getUrl: function() {
            var a = window.location.origin;
            if (!!_S("rewrite_mode") && !_S("rewrite_host")) {
                a += window.location.pathname.replace(/[^\/]*$/g, "")
            }
            return a
        },
        enableBrowserPush: function(a, c) {
            var b = {
                "package": a,
                name: SYNO.Personal.Notification.Utils.getBrowserName(),
                os_version: SYNO.Personal.Notification.Utils.getBrowserVersion(),
                allow_multiuser: false,
                launch_url: c,
                platform: _D("unique"),
                version: SYNO.SDS.Config.FnMap["SYNO.Personal.Notification.Utils"].config.version
            };
            if (!!_S("SynoToken")) {
                Ext.apply(b, {
                    SynoToken: _S("SynoToken")
                })
            }
            window.open(String.format("{0}{1}?{2}", SYNO.Personal.Notification.Utils.getUrl(), SYNO.Personal.Notification.Utils.PAIR_BASE_URL, Ext.urlEncode(b)));
            SYNO.Personal.Notification.Utils.isPaired = null;
            return Promise.resolve()
        },
        unpairBrowserPush: function(a, b) {
            return SYNO.Personal.Notification.Utils.sendAPIRequest("SYNO.Personal.Notification.Device", "unpair", 1, {
                list: b
            }).then(function() {
                SYNO.Personal.Notification.Utils.isPaired = false;
                return true
            })["catch"](function() {
                SYNO.Personal.Notification.Utils.isPaired = null;
                return false
            })
        },
        setupBrowserPush: function(a, c, b) {
            var d = {
                "package": a
            };
            if ("serviceWorker" in navigator) {
                navigator.serviceWorker.addEventListener("message", SYNO.Personal.Notification.WebPush.receiveSWMessage, false)
            }
            if (Ext.isString(c)) {
                d.launch_url = c
            }
            if (Ext.isBoolean(b)) {
                d.active = b
            }
            return Promise.all([SYNO.Personal.Notification.Utils.isWebPushSupported().then(function(e) {
                if (!e) {
                    return Promise.reject()
                }
                return SYNO.Personal.Notification.WebPush.getEndpoint(a)
            }).then(function(e) {
                return SYNO.Personal.Notification.Utils.sendAPIRequest("SYNO.Personal.Notification.Settings", "setup", 1, Ext.apply({
                    endpoint: e
                }, d))
            }).then(function() {
                return true
            })["catch"](function() {
                return false
            }), SYNO.Personal.Notification.Utils.getBrowserTargetId(a).then(function(e) {
                return SYNO.Personal.Notification.Utils.sendAPIRequest("SYNO.Personal.Notification.Settings", "setup", 1, Ext.apply({
                    target_id: e
                }, d))
            }).then(function() {
                return true
            })["catch"](function() {
                return false
            })]).then(function(e) {
                return e[0] || e[1]
            })
        },
        startBrowserPush: function(a) {
            return SYNO.Personal.Notification.Utils.setupBrowserPush(a, null, true)
        },
        stopBrowserPush: function(a) {
            return SYNO.Personal.Notification.Utils.setupBrowserPush(a, null, false)
        },
        getBrowserTargetId: function(a) {
            return SYNO.Personal.Notification.Utils.getIdentifier().then(function(b) {
                return new Promise(function(g, f) {
                    var c;
                    var d;
                    var h = function(k) {
                        if (k.origin === "https://notification.synology.com") {
                            var j = JSON.parse(k.data);
                            if (j.success === true) {
                                if (j.method == "loaded") {
                                    clearTimeout(d);
                                    c.contentWindow.postMessage(JSON.stringify({
                                        method: "testcookie"
                                    }), "*")
                                } else {
                                    if (j.method == "testcookie") {
                                        var i = b.id + "-" + a;
                                        c.contentWindow.postMessage(JSON.stringify({
                                            key: i,
                                            method: "get"
                                        }), "*")
                                    } else {
                                        if (j.method == "get") {
                                            window.removeEventListener("message", h);
                                            document.body.removeChild(c);
                                            g(parseInt(j.data, 10))
                                        }
                                    }
                                }
                            } else {
                                if (j.success === false) {
                                    window.removeEventListener("message", h);
                                    document.body.removeChild(c);
                                    f(j)
                                }
                            }
                        }
                    };
                    if (window.addEventListener) {
                        window.addEventListener("message", h, false)
                    } else {
                        window.attachEvent("onmessage", h)
                    }
                    c = document.createElement("iframe");
                    c.src = "https://notification.synology.com/web/iframe/iframe.html";
                    c.style.display = "none";
                    var e = function() {
                        d = setTimeout(function() {
                            f({
                                success: false
                            })
                        }, 5000)
                    };
                    if (c.addEventListener) {
                        c.addEventListener("load", e)
                    } else {
                        c.onreadystatechange = function() {
                            if ("complete" == this.readyState) {
                                e()
                            }
                        }
                    }
                    document.body.appendChild(c)
                })
            })
        },
        isWebPushSupported: function() {
            return new Promise(function(b, a) {
                if (!SYNO.Personal.Notification.WebPush.isSupportWebPushAPI(SYNO.Personal.Notification.Utils.getBrowserName(), SYNO.Personal.Notification.Utils.getBrowserVersion(), _D("unique"))) {
                    return b(false)
                }
                return b(true)
            })
        },
        isWebPushPaired: function(a) {
            return SYNO.Personal.Notification.Utils.isWebPushSupported().then(function(b) {
                if (!b) {
                    return Promise.reject()
                }
                return SYNO.Personal.Notification.WebPush.getSWRegistration()
            }).then(function(b) {
                if (!b) {
                    return Promise.reject()
                }
                return b.pushManager.getSubscription()
            }).then(function(b) {
                if (!b || !b.endpoint) {
                    return Promise.reject()
                }
                return SYNO.Personal.Notification.Utils.sendAPIRequest("SYNO.Personal.Notification.Mobile", "stat", 1, {
                    "package": a,
                    endpoint: b.endpoint
                })
            }).then(function(b) {
                if (!b) {
                    return Promise.reject()
                }
                return b.is_paired
            })["catch"](function() {
                return false
            })
        },
        isBrowserPaired: function(a) {
            if (SYNO.Personal.Notification.Utils.isPaired !== null) {
                return Promise.resolve(SYNO.Personal.Notification.Utils.isPaired)
            }
            return SYNO.Personal.Notification.Utils.isWebPushPaired(a).then(function(c) {
                if (c) {
                    return true
                }
                var b = (document.getElementById("syno-notification-is-installed") !== null);
                if (Ext.isChrome && !b) {
                    return false
                }
                return SYNO.Personal.Notification.Utils.getBrowserTargetId(a).then(function(d) {
                    return SYNO.Personal.Notification.Utils.sendAPIRequest("SYNO.Personal.Notification.Mobile", "stat", 1, {
                        "package": a,
                        target_id: d
                    })
                }).then(function(d) {
                    if (!d) {
                        return false
                    }
                    return d.is_paired
                })
            }).then(function(b) {
                SYNO.Personal.Notification.Utils.isPaired = b;
                return b
            })
        },
        isCurrentBrowser: function(b, a) {
            var c = JSON.parse(b);
            if (c.hasOwnProperty("endpoint")) {
                return SYNO.Personal.Notification.WebPush.getEndpoint().then(function(d) {
                    return (c.endpoint == d)
                })["catch"](function(d) {
                    return false
                })
            } else {
                if (c.hasOwnProperty("target_id")) {
                    return SYNO.Personal.Notification.Utils.getBrowserTargetId(a).then(function(d) {
                        return (c.target_id == d)
                    })["catch"](function(d) {
                        return false
                    })
                }
            }
            return new Promise(function(e, d) {
                return false
            })
        },
        getBrowserName: function() {
            var a = "unknown";
            if (Ext.isChrome) {
                a = "Chrome"
            } else {
                if (Ext.isSafari) {
                    a = "Safari"
                } else {
                    if (navigator.userAgent.toLowerCase().indexOf("firefox") > -1) {
                        a = "Firefox"
                    }
                }
            }
            return a
        },
        getBrowserVersion: function() {
            var a = "unknown";
            var b;
            if (Ext.isChrome) {
                b = navigator.userAgent.match(/(chrome)\/([\d.]*)/i);
                if (b) {
                    a = b[2]
                }
            } else {
                if (Ext.isSafari) {
                    b = navigator.userAgent.match(/(safari)\/([\d.]*)/i);
                    if (b) {
                        a = b[2]
                    }
                } else {
                    if (SYNO.Personal.Notification.Utils.getBrowserName() == "Firefox") {
                        b = navigator.userAgent.match(/(Firefox)\/([\d.]*)/i);
                        if (b) {
                            a = b[2]
                        }
                    }
                }
            }
            return a
        }
    }
});
Ext.ns("SYNO.Personal.Notification");
Ext.define("SYNO.Personal.Notification.SettingFormPanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(b) {
        var c, a;
        if (!b || !b.pkgName) {
            SYNO.Debug("Error: no config.pkgName.");
            return
        }
        Ext.apply(this, b);
        c = {
            get: {},
            set: {}
        };
        c.set["package"] = c.get["package"] = this.pkgName;
        a = {
            itemId: "SettingFormPanel",
            title: _TT("SYNO.Application.Service.Instance", "notification", "title_notification"),
            trackResetOnLoad: true,
            webapi: {
                api: "SYNO.Personal.Notification.Settings",
                methods: {
                    get: "get",
                    set: "set"
                },
                version: 1,
                params: c
            },
            items: [{
                xtype: "syno_checkbox",
                name: "desktop_enable",
                hidden: b.desktopHidden,
                boxLabel: _TT("SYNO.Application.Service.Instance", "notification", "desktop_notification")
            }, {
                xtype: "syno_checkbox",
                name: "email_enable",
                hidden: b.emailHidden,
                boxLabel: _TT("SYNO.Application.Service.Instance", "notification", "mail_notification_enable")
            }, {
                xtype: "syno_checkbox",
                name: "mobile_enable",
                hidden: b.mobileHidden,
                boxLabel: _TT("SYNO.Application.Service.Instance", "notification", "pushservice_mobile_enable")
            }, {
                xtype: "syno_button",
                text: _TT("SYNO.Application.Service.Instance", "notification", "enable_browser_push"),
                hidden: b.browserHidden,
                id: this.browserPairBtnId = Ext.id(),
                scope: this,
                handler: this.onClickBrowserPairBtn
            }, {
                xtype: "syno_displayfield",
                value: ""
            }, {
                xtype: "syno_button",
                text: _TT("SYNO.Application.Service.Instance", "notification", "send_test_notification"),
                id: this.testBtnId = Ext.id(),
                scope: this,
                handler: this.onClickTestNotificationBtn
            }]
        };
        this.callParent([Ext.apply(a, b)]);
        this.mon(this, "afterlayout", this.onAfterLayout, this, {
            single: true
        })
    },
    findAppWindow: function() {
        var a = this.callParent();
        if (false === Ext.isDefined(a)) {
            if (_S("standalone")) {
                a = SYNO.SDS.AppMgr.getByAppName(_S("standaloneAppName"))[0].window
            } else {
                a = SYNO.SDS.Desktop
            }
        }
        return a
    },
    save: function(b, a) {
        var c;
        if (this.isDirty() && this.isValid()) {
            var d = new Promise(this.applyForm.bind(this));
            d.then(function() {
                c = b && b()
            })["catch"](function(e) {
                console.log(e);
                c = a && a()
            })
        } else {
            c = b && b()
        }
    },
    cancel: function() {
        this.cancelForm()
    },
    load: function() {
        this.loadForm()
    },
    isValid: function() {
        return this.getForm().isValid()
    },
    isDirty: function() {
        var a = false;
        this.getForm().items.each(function(b) {
            if (b.isDirty()) {
                a = true;
                return false
            }
        });
        return a
    },
    onAfterLayout: function() {
        this.loadForm()
    },
    loadForm: function() {
        var a = SYNO.ux.Utils.getApiArray(this, "get", 0, 3)[0];
        Ext.apply(a, {
            scope: this,
            callback: function(c, b) {
                if (c) {
                    if (b.mobile_enable && this.mobileDisable) {
                        b.mobile_enable = false
                    }
                    this.form.setValues(b)
                }
            }
        });
        this.sendWebAPI(a)
    },
    applyForm: function(d, c) {
        var e, b = this.form.getFieldValues();
        var a = SYNO.ux.Utils.getApiArray(this, "set", 0, 3)[0];
        Ext.apply(a.params, b);
        Ext.apply(a, {
            scope: this,
            callback: function(g, f) {
                if (g) {
                    this.form.setValues(b);
                    e = d && d();
                    return
                }
                e = c && c()
            }
        });
        this.sendWebAPI(a)
    },
    cancelForm: function() {
        this.getForm().reset()
    },
    getNativeNotifyURL: function() {
        var b = Ext.urlDecode(window.location.search.substr(1));
        delete b.SynoToken;
        b = Ext.urlEncode(b);
        var a = window.location.origin + window.location.pathname;
        if (b.length !== 0) {
            a += "?" + b
        }
        return a
    },
    onClickBrowserPairBtn: function() {
        SYNO.Personal.Notification.Utils.enableBrowserPush(this.pkgName, this.getNativeNotifyURL()).then(function() {
            console.log("success (enable browser notification)")
        })["catch"](function(a) {
            console.log("failed: " + a)
        })
    },
    onClickTestNotificationBtn: function() {
        var b = this.browserPairedCallback.bind(this);
        var a = this.fatalError.bind(this);
        SYNO.Personal.Notification.Utils.isBrowserPaired(this.pkgName).then(b)["catch"](a)
    },
    fatalError: function() {
        this.findAppWindow().getMsgBox().alert("", _TT("SYNO.Application.Service.Instance", "common", "unknown_error"))
    },
    browserPairedCallback: function(a) {
        if (this.browserHidden || a) {
            this.sendTestNotification();
            return
        }
        this.findAppWindow().getMsgBox().alert("", _TT("SYNO.Application.Service.Instance", "notification", "browser_upair_alert"), function() {
            this.sendTestNotification()
        }, this)
    },
    sendTestNotification: function() {
        var a = {
            user: this._S("user")
        };
        a["package"] = this.pkgName;
        if (this.test_mail_tag) {
            a.tag = this.test_mail_tag
        }
        this.sendWebAPI({
            api: "SYNO.Personal.Notification.Event",
            method: "send",
            version: 1,
            params: a,
            scope: this,
            callback: function(c, b) {
                this.findAppWindow().getMsgBox().alert("", _TT("SYNO.Application.Service.Instance", "notification", "test_notification_sent"))
            }
        })
    }
});
Ext.ns("SYNO.Personal.Notification");
Ext.define("SYNO.Personal.Notification.FilterGridPanel", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(a) {
        if (!a || !a.pkgName) {
            SYNO.Debug("Error: no config.pkgName.");
            return
        }
        Ext.apply(this, a);
        Ext.apply(this, {
            filterSettingData: null,
            defaultFilterValue: "All",
            targets: ["mail", "mobile", "desktop", "browser"]
        });
        this.callParent([this.fillConfig(a)])
    },
    findAppWindow: function() {
        var a = this.callParent();
        if (false === Ext.isDefined(a)) {
            if (_S("standalone")) {
                a = SYNO.SDS.AppMgr.getByAppName(_S("standaloneAppName"))[0].window
            } else {
                a = SYNO.SDS.Desktop
            }
        }
        return a
    },
    save: function(b, a) {
        var c;
        if (this.isDirty() && this.isValid()) {
            var d = new Promise(this.onClickSaveSetting.bind(this));
            d.then(function(e) {
                c = b && b()
            })["catch"](function(e) {
                console.log(e);
                console.log("aaaaa");
                c = a && a()
            })
        } else {
            c = b && b()
        }
    },
    cancel: function() {
        this.reset()
    },
    load: function() {
        this.onCategoryChange()
    },
    isValid: function() {
        return true
    },
    isDirty: function() {
        var a = this.getStore().getModifiedRecords();
        return (0 < a.length)
    },
    fillConfig: function(e) {
        var f = new SYNO.ux.EnableColumn({
            id: "desktop",
            header: _TT("SYNO.Application.Service.Instance", "notification", "title_desktop"),
            hidden: e.desktopHidden,
            width: 100,
            sortable: false,
            dataIndex: "desktop",
            align: "center",
            enableFastSelectAll: true
        });
        var c = new SYNO.ux.EnableColumn({
            id: "mail",
            header: _TT("SYNO.Application.Service.Instance", "notification", "title_email"),
            hidden: e.emailHidden,
            width: 100,
            sortable: false,
            dataIndex: "mail",
            align: "center",
            enableFastSelectAll: true
        });
        var b = new SYNO.ux.EnableColumn({
            id: "mobile",
            hidden: e.mobileHidden,
            header: _TT("SYNO.Application.Service.Instance", "notification", "title_mobile"),
            width: 100,
            sortable: false,
            dataIndex: "mobile",
            align: "center",
            enableFastSelectAll: true
        });
        var g = new SYNO.ux.EnableColumn({
            id: "browser",
            header: _TT("SYNO.Application.Service.Instance", "notification", "title_browser"),
            hidden: e.browserHidden,
            width: 100,
            sortable: false,
            dataIndex: "browser",
            align: "center",
            enableFastSelectAll: true
        });
        var a = new Ext.grid.ColumnModel({
            columns: [{
                header: _TT("SYNO.Application.Service.Instance", "notification", "title_notification_event"),
                width: 200,
                sortable: true,
                parentid: this.id,
                dataIndex: "title",
                id: "title",
                renderer: function(j, h, i) {
                    if (0 > i.data.warnPercent) {
                        return String.format('<div ext:qtip="{0}">{0}</div>', j)
                    }
                    return String.format('<div ext:qtip="{0}">{0}<a href = javascript:void(0) tabindex="-1"><{1}%></a></div>', j, i.data.warnPercent)
                }
            }, c, b, f, g, {
                header: "Group",
                sortable: false,
                dataIndex: "group",
                hidden: true
            }]
        });
        this.filterSettingStore = new Ext.data.Store({
            reader: new Ext.data.JsonReader({
                idProperty: "name",
                fields: [{
                    name: "name"
                }, {
                    name: "title"
                }, {
                    name: "mail"
                }, {
                    name: "desktop"
                }, {
                    name: "browser"
                }, {
                    name: "mobile"
                }, {
                    name: "group"
                }, {
                    name: "warnPercent"
                }, {
                    name: "pkg_name"
                }]
            }),
            data: [],
            groupField: "group",
            autoDestroy: true
        });
        var d = {
            itemId: "filterTab",
            cls: "paired-info",
            title: _TT("SYNO.Application.Service.Instance", "notification", "title_notification_event"),
            listeners: {
                afterrender: this.onCategoryChange,
                scope: this
            },
            store: this.filterSettingStore,
            colModel: a,
            plugins: [c, b, f, g],
            enableColLock: false,
            enableHdMenu: false,
            enableColumnMove: false,
            colMail: c,
            colMobile: b,
            colDesktop: f,
            colBrowser: g,
            clicksToEdit: 1,
            sm: new Ext.grid.RowSelectionModel({
                singleSelect: true
            }),
            stripeRows: true
        };
        return Ext.apply(d, e)
    },
    reset: function() {
        this.notificationFilter.setValue(this.defaultFilterValue);
        this.filterSettingData = null
    },
    onCategoryChange: function() {
        if (null === this.filterSettingData) {
            this.loadFilterSetting("All")
        }
        this.colMail.checkSelectAll(this.getStore());
        this.colMobile.checkSelectAll(this.getStore());
        this.colDesktop.checkSelectAll(this.getStore());
        this.colBrowser.checkSelectAll(this.getStore())
    },
    loadFilterSetting: function(a) {
        this.sendWebAPI({
            api: "SYNO.Personal.Notification.Filter",
            method: "list",
            version: 1,
            params: {
                packages: this.pkgName
            },
            scope: this,
            callback: function(c, b) {
                if (c) {
                    this.filterSettingStore.loadData(b.All);
                    this.filterSettingData = b
                } else {
                    this.findAppWindow().getMsgBox().alert(_T("tree", "leaf_notification"), _T("common", "error_system"))
                }
            }
        })
    },
    onClickSaveSetting: function(h, g) {
        var a = this.getStore().getModifiedRecords();
        var d, c;
        var e = [];
        for (d = 0; d < a.length; d++) {
            var b = [];
            for (c = 0; c < this.targets.length; c++) {
                if (a[d].get(this.targets[c])) {
                    b.push(this.targets[c])
                }
            }
            var f = {
                name: a[d].get("name"),
                conf: b
            };
            f["package"] = a[d].get("pkg_name");
            e.push(f)
        }
        this.findAppWindow().setStatusBusy({
            text: _T("common", "saving")
        });
        this.sendWebAPI({
            compound: {
                stopwhenerror: true,
                params: [{
                    api: "SYNO.Personal.Notification.Filter",
                    method: "set",
                    version: 1,
                    params: {
                        settings: e
                    }
                }, {
                    api: "SYNO.Personal.Notification.Filter",
                    method: "list",
                    version: 1,
                    params: {
                        packages: this.pkgName
                    }
                }]
            },
            scope: this,
            callback: function(l, j, i) {
                var k;
                this.findAppWindow().clearStatusBusy();
                if (!l || j.has_fail || !j.result[0].success) {
                    k = g && g(_T("common", "error_system"));
                    return
                }
                this.findAppWindow().setStatusOK();
                if (j.result[1].success) {
                    this.filterSettingData = j.result[1].data;
                    if (this.getStore()) {
                        this.getStore().commitChanges()
                    }
                }
                k = h && h()
            }
        })
    }
});
Ext.ns("SYNO.Personal.Notification");
Ext.define("SYNO.Personal.Notification.LogGridPanel", {
    extend: "SYNO.ux.GridPanel",
    pageSize: 3,
    constructor: function(a) {
        if (!a || !a.pkgName) {
            SYNO.Debug("Error: no config.pkgName.");
            return
        }
        this.pkgName = a.pkgName;
        this.callParent([this.fillConfig(a)])
    },
    fillConfig: function(c) {
        var a = new Ext.grid.ColumnModel({
            columns: [{
                header: "id",
                dataIndex: "id",
                width: 20
            }, {
                header: "message",
                dataIndex: "message"
            }, {
                header: "sent_time",
                dataIndex: "sent_time",
                width: 80,
                renderer: function(f, d, e) {
                    return (new Date(f * 1000)).format("Y-m-d H:i:s")
                }
            }, {
                header: "extra_data",
                dataIndex: "additional",
                renderer: function(f, d, e) {
                    return Ext.encode(f.extra_data)
                }
            }, {
                header: "status",
                dataIndex: "additional",
                renderer: function(f, d, e) {
                    return (1 === f.status) ? "success" : f.status
                }
            }]
        });
        var b = {
            itemId: "logTab",
            title: "LOG",
            listeners: {
                activate: this.onActivate,
                scope: this
            },
            store: this.getStore(),
            colModel: a,
            sm: new Ext.grid.RowSelectionModel({
                singleSelect: true
            }),
            stripeRows: true,
            bbar: new SYNO.ux.PagingToolbar({
                store: this.getStore(),
                pageSize: this.pageSize,
                displayInfo: true
            })
        };
        return Ext.apply(b, c)
    },
    findWindow: function() {
        var a = this.callParent();
        if (false === Ext.isDefined(a)) {
            if (_S("standalone")) {
                a = SYNO.SDS.AppMgr.getByAppName(_S("standaloneAppName"))[0].window
            } else {
                a = SYNO.SDS.Desktop
            }
        }
        return a
    },
    onActivate: function() {
        this.getStore().load({
            params: {
                start: 0,
                limit: this.pageSize
            }
        })
    },
    getStore: function() {
        if (!this.store) {
            this.store = new SYNO.API.JsonStore({
                api: "SYNO.Personal.Notification.Event",
                method: "list",
                version: "1",
                baseParams: {
                    "package": this.pkgName,
                    additional: ["status", "extra_data"]
                },
                paramNames: {
                    start: "start"
                },
                appWindow: this,
                root: "data",
                idProperty: "id",
                fields: ["id", "message", "sent_time", "additional"],
                autoDestroy: true
            })
        }
        return this.store
    }
});
Ext.ns("SYNO.Personal.Notification");
Ext.define("SYNO.Personal.Notification.PairedInfo", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(c) {
        if (!c || !c.pkgName) {
            SYNO.Debug("Error: no config.pkgName.");
            return
        }
        Ext.apply(this, c);
        var a, d = {};
        if (this.pkgName !== "SynoSweet") {
            d["package"] = this.pkgName
        }
        var b = {
            layout: "fit",
            title: _TT("SYNO.Application.Service.Instance", "notification", "paired"),
            cls: "paired-info",
            store: a = new Ext.data.JsonStore({
                fields: ["device_name", "firmware_version", "app_version", "package", "identity", "id"]
            }),
            colModel: new Ext.grid.ColumnModel({
                defaults: {
                    width: 120,
                    sortable: true
                },
                columns: [{
                    id: "name",
                    header: _T("common", "name"),
                    dataIndex: "device_name",
                    width: 215
                }, {
                    header: _TT("SYNO.Application.Service.Instance", "notification", "mobile_version"),
                    dataIndex: "firmware_version",
                    width: 315,
                    renderer: function(e, f) {
                        f.css = "firmware-cell";
                        return String.format('<div class="firmware">{0}</div><div class="unpair"></div>', Ext.util.Format.htmlEncode(e))
                    }
                }]
            }),
            stripeRows: true,
            sm: new Ext.grid.RowSelectionModel({
                singleSelect: false
            })
        };
        this.callParent([Ext.apply(b, c)]);
        this.mon(this, "show", this.loadData, this, {
            single: true
        });
        this.mon(this, "rowcontextmenu", this.onRowContextMenu, this);
        this.mon(this, "containercontextmenu", this.onContainerContextMenu, this);
        this.mon(this, "cellclick", this.onCellClick, this)
    },
    findAppWindow: function() {
        var a = this.callParent();
        if (false === Ext.isDefined(a)) {
            if (_S("standalone")) {
                a = SYNO.SDS.AppMgr.getByAppName(_S("standaloneAppName"))[0].window
            } else {
                a = SYNO.SDS.Desktop
            }
        }
        return a
    },
    save: function() {},
    cancel: function() {},
    load: function() {
        this.loaddata()
    },
    isValid: function() {
        return true
    },
    isDirty: function() {
        return false
    },
    onCellClick: function(b, d, a, c) {
        if (c.target.classList.contains("unpair")) {
            this.unpair()
        }
    },
    loadData: function() {
        var b = {};
        var a = this;
        if (this.pkgName !== "SynoSweet") {
            b["package"] = this.pkgName
        }
        SYNO.Personal.Notification.Utils.sendAPIRequest("SYNO.Personal.Notification.Device", "list", 1, b).then(function(c) {
            var d = [];
            c.list.forEach(function(e) {
                d.push(SYNO.Personal.Notification.Utils.isCurrentBrowser(e.identity, a.pkgName).then(function(f) {
                    if (f) {
                        e.device_name = e.device_name + " (current)"
                    }
                    return e
                }))
            });
            return Promise.all(d)
        }).then(function(c) {
            a.getStore().loadData(c)
        })["catch"](function(c) {
            a.owner.getMsgBox().alert("", _TT("SYNO.Application.Service.Instance", "notification", "error_server_connet"))
        })
    },
    unpair: function() {
        var b = this.getSelectionModel().getSelected();
        var a = this.findAppWindow();
        if (null === b) {
            return
        }
        a.getMsgBox().confirm("", _T("common", "ask_cont"), function(c) {
            if ("yes" === c) {
                this.doUnpair()
            }
        }, this)
    },
    doUnpair: function() {
        var a = this.getSelectionModel().getSelections();
        var c = [];
        var b = 0;
        for (b = 0; b < a.length; b++) {
            c.push({
                identity: a[b].get("identity"),
                "package": a[b].get("package")
            })
        }
        this.sendWebAPI({
            api: "SYNO.Personal.Notification.Device",
            method: "unpair",
            version: 1,
            params: {
                list: c
            },
            scope: this,
            callback: function(f, e, d) {
                if (f) {
                    this.loadData()
                } else {
                    this.getMsgBox().alert("", _T("common", "error_system"))
                }
            }
        })
    },
    onContainerContextMenu: function(c, b) {
        var e = c.getSelectionModel();
        var a = e.getSelected();
        var d = c.store.indexOf(a);
        this.onRowContextMenu(c, d, b)
    },
    onRowContextMenu: function(b, e, a) {
        var d = this.getSelectionModel();
        d.suspendEvents(false);
        d.selectRow(e, d.isSelected(e));
        d.resumeEvents();
        var c = new SYNO.ux.Menu({
            autoDestroy: true,
            items: [{
                text: _TT("SYNO.Application.Service.Instance", "notification", "pushservice_unpair_device"),
                itemId: "unpair",
                scope: this,
                handler: this.unpair
            }]
        });
        c.showAt(a.getXY());
        a.preventDefault()
    }
});
