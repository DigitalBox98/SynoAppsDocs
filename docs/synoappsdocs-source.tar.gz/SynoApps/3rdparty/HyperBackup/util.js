/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.Backup");
SYNO.SDS.Backup.String = function(b, a) {
    return _TT("SYNO.SDS.Backup.Application", b, a) || _TT("SYNO.SDS.Backup.ScheduleBackupWidget", b, a) || _TT("SYNO.SDS.Backup.Client.Explore.AppInstance", b, a) || _TT("SYNO.SDS.Backup.Client.JobTray.AppInstance", b, a) || _TT("SYNO.SDS.Backup.Client.Fuse.Utils.bundleLaunchFn", b, a)
};
SYNO.SDS.Backup.NoteStyleString = function(b, a) {
    return SYNO.SDS.Backup.StringToNoteStyle(_TT("SYNO.SDS.Backup.Application", b, a))
};
SYNO.SDS.Backup.StringToNoteStyle = function(a) {
    return '<span class="syno-ux-note">' + _T("common", "note") + ": </span>" + a
};
SYNO.SDS.Backup.getAppIconPath = function(b, a) {
    return SYNO.API.GetBaseURL({
        api: "SYNO.Backup.App",
        method: "get_icon",
        version: 1,
        params: {
            app_name: b,
            app_version: a
        }
    })
};
SYNO.SDS.Backup.createTimeItemStore = function(e) {
    var a = [];
    var c = {
        hour: 24,
        min: 60,
        sec: 60
    };
    if (e in c) {
        for (var d = 0; d < c[e]; d++) {
            a.push([d, String.leftPad(String(d), 2, "0")])
        }
        var b = new Ext.data.SimpleStore({
            id: 0,
            fields: ["value", "display"],
            data: a
        });
        return b
    }
    return null
};
SYNO.SDS.Backup.convertAppError = function(b, a) {
    if (-1 === b) {
        return a
    }
    switch (b) {
        case 7:
            return _T("backup", "app_err_install");
        case 8:
            return SYNO.SDS.Backup.String("app", "broken_app");
        case 9:
            return _T("pkgmgr", "pkgmgr_pkg_stop_failed");
        case 10:
            return _T("pkgmgr", "pkgmgr_pkg_start_failed");
        case 12:
            return _T("backup", "err_connect");
        case 13:
            return SYNO.SDS.Backup.String("error", "app_network_disconnected");
        case 15:
            return _T("backup", "err_server_name");
        case 16:
            return _T("backup", "imgbkp_account_pass_fail");
        case 17:
            return _T("netbackup", "err_share_perm_denied");
        case 18:
            return _TT("SYNO.SDS.Backup.Application", "error", "err_ip_denied");
        case 19:
            return _T("backup", "err_serivce_disable");
        case 20:
            return SYNO.SDS.Backup.String("error", "client_no_space");
        case 21:
            return _T("backup", "app_err_no_volume");
        case 23:
            return SYNO.SDS.Backup.String("app", "app_version_old");
        case 25:
            return SYNO.SDS.Backup.String("error", "app_err_no_version_found");
        case 26:
            return _T("usbbackup", "usbbkp_cancel");
        case 27:
            return _T("pkgmgr", "broken_desc");
        case 31:
            return SYNO.SDS.Backup.String("app", "restore_version_old");
        case 32:
            return SYNO.SDS.Backup.String("app", "dependent_app_is_not_available");
        case 33:
            return SYNO.SDS.Backup.String("app", "not_support_new_framework");
        case 34:
            return SYNO.SDS.Backup.String("app", "dependent_app_is_not_available");
        case 41:
            return SYNO.SDS.Backup.String("app", "app_install_conflict");
        default:
            return _T("backup", "restore_fail")
    }
};
SYNO.SDS.Backup.convertDisabledShareType = function(e, d) {
    var c = SYNO.SDS.Backup.Util.htmlEncodeTip;
    var h = SYNO.SDS.Backup.String;
    var g = String.format;
    var b = "<div ext:qtip=";
    var f = ' class="x-combo-list-item syno-backup-enabled-list-item"';
    var a = 'class="x-combo-list-item syno-backup-disabled-list-item"';
    switch (e) {
        case 0:
            return b + '"' + c(d) + '"' + f;
        case 1:
            return b + '"' + c(_T("backup", "repo_already_exist")) + '"' + a;
        case 2:
            return b + '"' + c(g(h("app", "disabled_share_unsupported_fs"), d)) + '"' + a;
        case 3:
            return b + '"' + c(g(h("app", "disabled_share_default"), d)) + '"' + a;
        case 4:
            return b + '"' + c(g(h("app", "disabled_share_unmounted_enc"), d)) + '"' + a;
        case 5:
            return b + '"' + c(g(h("app", "disabled_share_NA"), d)) + '"' + a;
        case 6:
            return b + '"' + c(g(h("app", "disabled_share_ro"), d)) + '"' + a;
        case 7:
            return b + '"' + c(g(h("app", "disabled_share_vol_ro"), d)) + '"' + a;
        default:
            return b + '"' + c(g(h("app", "disabled_share_unknown"), d)) + '"' + a
    }
};
SYNO.SDS.Backup.getShareListTpl = function(a) {
    return '<tpl for=".">{[SYNO.SDS.Backup.convertDisabledShareType(values.status, values.share)]}>{' + a + ":htmlEncode}</div></tpl>"
};
SYNO.SDS.Backup.ConvertConflictIdToUniqueId = function(b) {
    var a = b.split("/");
    if (2 <= a.length) {
        a[1] += "%!enc!%"
    }
    return a.join("/")
};
SYNO.SDS.Backup.ConvertUniqueIdToConflictId = function(b) {
    var a = b.split("/");
    if (2 <= a.length) {
        a[1] = a[1].replace(/\%\!enc\!\%$/, "")
    }
    return a.join("/")
};
SYNO.SDS.Backup.getTreeNodeByCaseId = function(b, g) {
    var c = g.toUpperCase();
    var d = SYNO.SDS.Backup.ConvertConflictIdToUniqueId(g).toUpperCase();
    var a = "",
        f = "";
    for (var e in b.nodeHash) {
        if (e.toUpperCase() === c) {
            a = e
        } else {
            if (e.toUpperCase() === d) {
                f = e
            }
        }
    }
    if (!Ext.isEmpty(a) && !Ext.isEmpty(f)) {
        if (b.nodeHash[f].getUI().getCheckValue()) {
            return b.nodeHash[f]
        }
        if (b.nodeHash[a].getUI().getCheckValue()) {
            return b.nodeHash[a]
        }
        return b.nodeHash[f]
    } else {
        if (!Ext.isEmpty(a)) {
            return b.nodeHash[a]
        } else {
            if (!Ext.isEmpty(f)) {
                return b.nodeHash[f]
            }
        }
    }
};
SYNO.SDS.Backup.getDepentApps = function(a, d) {
    var b = [];
    var c = a.getById(d);
    if (!c || !c.get("depend") || !c.get("depend").app_bkp_list) {
        return []
    }
    Ext.each(c.get("depend").app_bkp_list, function(f) {
        if (0 < b.indexOf(f)) {
            return
        }
        b.push(f);
        var e = SYNO.SDS.Backup.getDepentApps(a, f);
        b.push.apply(b, e)
    });
    return SYNO.ux.Utils.uniqueApiArray(b).sort()
};
SYNO.SDS.Backup.getAppsDependOnThis = function(a, c) {
    var b = [];
    Ext.each(a.data.items, function(d) {
        if (!d || !d.get("depend") || !d.get("depend").app_bkp_list) {
            return []
        }
        Ext.each(d.get("depend").app_bkp_list, function(f) {
            if (f !== c || 0 < b.indexOf(f)) {
                return
            }
            var g = d.get("id");
            b.push(g);
            var e = SYNO.SDS.Backup.getAppsDependOnThis(a, g);
            b.push.apply(b, e)
        })
    });
    return SYNO.ux.Utils.uniqueApiArray(b).sort()
};
SYNO.SDS.Backup.getSharesDependOn = function(a, d) {
    var b = SYNO.SDS.Backup.getDepentApps(a, d);
    b.push(d);
    var c = [];
    Ext.each(b, function(f) {
        var e = a.getById(f);
        if (!e || !e.get("depend").folder_list) {
            return
        }
        Ext.each(e.get("depend").folder_list, function(g) {
            c.push(SYNO.SDS.Backup.getShareName(g.folder))
        })
    });
    return SYNO.ux.Utils.uniqueApiArray(c).sort()
};
SYNO.SDS.Backup.getAppDisplayName = function(a, c) {
    var b = [];
    Ext.each(c, function(e) {
        var d = a.getById(e);
        if (d) {
            b.push(d.get("name"))
        } else {
            b.push(e)
        }
    }, this);
    return b
};
SYNO.SDS.Backup.setAppGridDependency = function(c, d, a, b) {
    c.isBackup = a;
    Ext.each(c.getStore().data.items, function(i) {
        if (a) {
            i.set("disabled", false)
        }
        if (i.get("app_custom_err_msg") || (i.get("error_session") && i.get("error_key"))) {
            i.set("disabled", true);
            if (!b || "not_support_new_framework" !== i.get("error_key")) {
                i.set("checked", false)
            }
        }
        if (!i.get("depend") || !i.get("depend").folder_list) {
            return
        }
        var g = false;
        var e = [];
        var f = null;
        var h = SYNO.SDS.Backup.getSharesDependOn(c.getStore(), i.get("id"));
        Ext.each(h, function(k) {
            var j = SYNO.SDS.Backup.getTreeNodeByCaseId(d, "/" + k);
            if (!j || !(j.attributes) || (j.attributes.disabled)) {
                if (Ext.isDefined(j) && Ext.isDefined(j.attributes) && Ext.isDefined(j.attributes.read_only_owner)) {
                    f = j.attributes.read_only_owner
                }
                g = true;
                e.push(k);
                return true
            }
            if (undefined === j.dependAppRows) {
                j.dependAppRows = []
            }
            j.isBackup = a;
            j.dependGrid = c;
            j.dependAppRows.push(i)
        });
        if (g) {
            if (f) {
                i.set("read_only_owner", f)
            }
            if (0 !== e.length) {
                i.get("depend").invalid_shares = e
            }
            i.set("disabled", true);
            i.set("checked", false)
        }
    });
    c.getStore().sort([{
        field: "disabled",
        direction: "ASC"
    }, {
        field: "name",
        direction: "ASC"
    }])
};
SYNO.SDS.Backup.setAppDependency = function(c) {
    var d = function(f, e) {
        if (!e) {
            Ext.each(f.attributes.appNodes, function(g) {
                g.getUI().setCheckValue(false)
            });
            if (true === f.attributes.is_app) {
                Ext.each(f.attributes.dataNodes, function(g) {
                    if (g.getUI().isDisabled()) {
                        g.disabled = false;
                        g.getUI().setCheckValue(false);
                        g.disabled = true;
                        g.getUI().syncCheckCssClass()
                    }
                })
            }
        } else {
            if (true === f.attributes.is_app) {
                Ext.each(f.attributes.dataNodes, function(g) {
                    if (g.getUI().isDisabled()) {
                        g.disabled = false;
                        g.getUI().setCheckValue(true);
                        g.disabled = true;
                        g.getUI().syncCheckCssClass()
                    } else {
                        g.getUI().setCheckValue(true)
                    }
                })
            }
        }
        if (true === f.attributes.is_app) {
            f.expand(true)
        }
    };
    var a = function(e, g, i, f) {
        var h = g.getUI() || {};
        if (!Ext.isFunction(h.getCheckValue) || !(h.checkbox) || undefined === i.attributes.checked) {
            return
        }
        if (true === g.attributes.is_app) {
            if (true === g.disabled) {
                i.disable()
            }
            if (false === h.getCheckValue() && undefined !== i.attributes.checked) {
                i.attributes.checked = false
            }
            SYNO.SDS.Backup.setAppDependency.call(this, i)
        } else {
            i.attributes.appNodes = g.attributes.appNodes
        }
        i.attributes.dataNodes = g.attributes.dataNodes;
        i.on("checkchange", d);
        i.on("append", a)
    };
    if (c.attributes.depend) {
        var b = [];
        Ext.each(c.attributes.depend.shares, function(e) {
            b.push("/" + e)
        });
        Ext.each(c.attributes.depend.nodes, function(e) {
            b.push(e)
        });
        Ext.each(b, function(e) {
            var f = this.getNodeById(e);
            if (undefined === f) {
                return true
            }
            if (undefined === f.attributes.appNodes) {
                f.attributes.appNodes = []
            }
            f.attributes.appNodes.push(c);
            f.on("checkchange", d, this);
            f.on("append", a, this);
            if (undefined === c.attributes.dataNodes) {
                c.attributes.dataNodes = []
            }
            c.attributes.dataNodes.push(f)
        }, this);
        c.on("checkChange", d, this);
        c.on("append", a, this)
    }
};
SYNO.SDS.Backup.getReadOnlyOwnerString = function(a) {
    switch (a) {
        case "ddsm":
            return _TT("SYNO.SDS.Docker.Application", "ddsm", "docker_dsm");
        case "surveillance":
            return _T("backup", "surveillance_station");
        default:
            return a
    }
    return ""
};
SYNO.SDS.Backup.ConverSize = function(d, c) {
    d = d ? d : 0;
    c = c ? c : 0;
    var f = 1024;
    var a = f * 1024;
    var e = a * 1024;
    var g = e * 1024;
    var b = parseFloat(d);
    if (isNaN(b)) {
        return d
    }
    d = b;
    if ((d >= 0) && (d < f)) {
        return d.toFixed(c) + " B"
    } else {
        if ((d >= f) && (d < a)) {
            return (d / f).toFixed(c) + " KB"
        } else {
            if ((d >= a) && (d < e)) {
                return (d / a).toFixed(c) + " MB"
            } else {
                if ((d >= e) && (d < g)) {
                    return (d / e).toFixed(c) + " GB"
                } else {
                    return (d / g).toFixed(c) + " TB"
                }
            }
        }
    }
};
/**
 * @class SYNO.SDS.Backup.HostCombobox
 * @extends SYNO.ux.ComboBox
 * HyperBackup host combobox class
 *
 */  
Ext.define("SYNO.SDS.Backup.HostCombobox", {
    extend: "SYNO.ux.ComboBox",
    constructor: function(a) {
        Ext.copyTo(this, a, "appWindow,owner");
        if (!this.appWindow && this.owner) {
            this.appWindow = this.owner.findAppWindow()
        }
        this.callParent([Ext.apply({
            allowBlank: false,
            fieldLabel: _T("netbackup", "netbkp_set_ip"),
            emptyText: _T("netbackup", "netbkp_input_addr"),
            editable: true,
            store: new SYNO.API.Store({
                api: "SYNO.Core.Findhost",
                version: 1,
                method: "list",
                appWindow: this.appWindow || false,
                autoLoad: false,
                autoDestroy: true,
                reader: new Ext.data.JsonReader({
                    idProperty: "ip",
                    fields: ["hostname", "ip"]
                }),
                sortInfo: {
                    field: "hostname",
                    direction: "ASC"
                },
                listeners: {
                    beforeload: this.onStoreBeforeLoad,
                    load: this.onStoreLoad,
                    exception: this.onStoreLoadException,
                    clear: this.onStoreClear,
                    scope: this
                }
            }),
            validator: function(b) {
                return SYNO.SDS.Backup.Util.isHostnameValid(b, true)
            },
            valueField: "ip",
            displayField: "hostname",
            triggerAction: "all",
            mode: "local",
            tpl: '<tpl for="."><div ext:qtip="{hostname:htmlEncode}({ip})" class="x-combo-list-item">{hostname:htmlEncode}({ip})</div></tpl>'
        }, a)]);
        this.requestSelfNetInfo()
    },
    onTriggerClick: function() {
        if (this.readOnly || this.disabled) {
            return
        }
        if (this.isStoreLoaded !== true) {
            this.getStore().load()
        }
        this.callParent(arguments)
    },
    onStoreBeforeLoad: function() {
        if (this.owner) {
            this.owner.setStatusBusy()
        }
    },
    onStoreLoad: function() {
        if (this.owner) {
            this.owner.clearStatusBusy()
        }
        this.isStoreLoaded = true
    },
    onStoreLoadException: function(c, d, e, a, f, b) {
        if (this.owner) {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(f.code), function() {
                this.owner.close()
            }, this)
        } else {
            alert(SYNO.SDS.Backup.GetErrorString(f.code))
        }
        delete this.isStoreLoaded
    },
    onStoreClear: function(b, a) {
        delete this.isStoreLoaded
    },
    getHostAddress: function() {
        var a = this.getRawValue().trim();
        return SYNO.SDS.Backup.Util.getHostAddress(a, true)
    },
    requestSelfNetInfo: function() {
        this.owner.sendWebAPI({
            api: "SYNO.Core.System",
            method: "info",
            version: 1,
            params: {
                type: "network"
            },
            callback: this.onQueryHostnameDone,
            scope: this
        })
    },
    onQueryHostnameDone: function(d, c, b) {
        var a = [];
        if (!d || c === undefined || !Ext.isArray(c.nif)) {
            return
        }
        this.selfHostName = c.hostname.toLowerCase();
        Ext.each(c.nif, function(e) {
            a.push(e.addr);
            if (Ext.isArray(e.ipv6)) {
                Ext.each(e.ipv6, function(f) {
                    a.push(f.addr)
                })
            }
        });
        this.selfIPs = a
    }
});
SYNO.SDS.Backup.converLanString = (function() {
    var a = /^[.a-zA-Z0-9_-]+(:[a-zA-Z0-9_-]+){1,2}$/;
    return function(c) {
        var b;
        if (a.test(c)) {
            b = c.split(":");
            if (b.length === 2) {
                return _T(b[0], b[1])
            } else {
                return _TT(b[0], b[1], b[2])
            }
        } else {
            return ""
        }
    }
})();
Ext.namespace("SYNO.SDS.Backup.Util");
SYNO.SDS.Backup.Util.isValidIPAddr = function(a) {
    var b = /^(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.(25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$/;
    if (Ext.isString(a) && a.match(b)) {
        return true
    } else {
        return false
    }
};
SYNO.SDS.Backup.Util.isHostnameValid = function(c, e) {
    var b = c.toLowerCase();
    var d = /^(localhost|127\.0\.0\.1|0\.0\.0\.0|::1|0:0:0:0:0:0:0:1)$/;
    var a = this.selfIPs;
    if (b.match(d) || (b === this.selfHostName) || (a && -1 !== a.indexOf(b))) {
        return SYNO.SDS.Backup.String("app", "connect_self_ip")
    }
    if (Ext.form.VTypes.url(c)) {
        return SYNO.SDS.Backup.String("validator", "host_no_url")
    }
    if (Ext.isEmpty(SYNO.SDS.Backup.Util.getHostAddress(c, e))) {
        return _T("netbackup", "netbkp_err_host_str")
    }
    return true
};
SYNO.SDS.Backup.Util.getHostAddress = function(c, e) {
    var a = c.indexOf("(");
    var f = c.indexOf(")");
    if (e && 0 < a && a < f && f === (c.length - 1)) {
        var b = c.substring(0, a);
        var d = c.substring(a + 1, f);
        if (Ext.form.VTypes.ip(d)) {
            return d
        }
        if (Ext.form.VTypes.netbiosName(b) || (Ext.form.VTypes.hostname(b) && !Ext.form.VTypes.ip(b))) {
            return b
        }
        return ""
    }
    if (Ext.form.VTypes.netbiosName(c) || Ext.form.VTypes.hostname(c) || Ext.form.VTypes.ip(c)) {
        return c
    }
    return ""
};
SYNO.SDS.Backup.Util.htmlEncodeTip = function(a) {
    var c = Ext.util.Format.htmlEncode(a);
    var b = Ext.util.Format.htmlEncode(c);
    return b
};
SYNO.SDS.Backup.Util.lengthEllipsis = function(b, a, c) {
    return '<span ext:qtip="' + SYNO.SDS.Backup.Util.htmlEncodeTip(b) + '">' + Ext.util.Format.ellipsis(Ext.util.Format.htmlEncode(b), a, c) + "</span>"
};
SYNO.SDS.Backup.Util.widthEllipsis = function(b, a) {
    return '<span ext:qtip="' + SYNO.SDS.Backup.Util.htmlEncodeTip(b) + '" style="overflow: hidden; text-overflow: ellipsis; display: inline-block; white-space: nowrap; width: ' + a + 'px">' + Ext.util.Format.htmlEncode(b) + "</span>"
};
SYNO.SDS.Backup.Util.isRecycleBinFolder = function(a) {
    if (!a) {
        return false
    }
    var b = a.split("/", 7);
    return (b.length === 3 && b[2] === "#recycle") || (b.length === 4 && b[1] === "homes" && b[3] === "#recycle") || (b.length === 6 && b[1] === "homes" && b[5] === "#recycle")
};
SYNO.SDS.Backup.Util.comboboxLoadData = function(e, c, a, d) {
    var b = [];
    Ext.each(c, function(f) {
        if (Ext.isDefined(a) && Ext.isDefined(d)) {
            b.push([f[a], f[d]])
        } else {
            if (Ext.isDefined(a)) {
                b.push([f[a]])
            } else {
                b.push([f])
            }
        }
    });
    e.getStore().loadData(b, false);
    if (b.length > 0) {
        e.setValue(b[0][0]);
        return true
    } else {
        e.setValue("");
        return false
    }
};
SYNO.SDS.Backup.Util.getEncryption = function(a, b) {
    if (!Ext.isArray(a)) {
        return []
    }
    return a.filter(function(c) {
        return b.hasOwnProperty(c)
    })
};
SYNO.SDS.Backup.getStatusIcon = function(d, a, c, e, b) {
    if ("exportable" === d) {
        if ("backup" === a || "waiting" === a) {
            return "exporting"
        }
        if ("suspending" === a) {
            return "suspending"
        }
        if ("discarding" === a) {
            return "discarding"
        }
        if ("discard_failed" === a || "cancel" === c || "canceling" === a || "failed" === c) {
            return "failed"
        }
        if ("suspend" === c) {
            return "suspend"
        }
        return "canexport"
    } else {
        if ("importable" === d) {
            if ("none" === a) {
                return "canrelink"
            } else {
                if ("canceling" === a) {
                    return "relinkfailed"
                } else {
                    return "relinking"
                }
            }
        } else {
            if ("relinkable" === d) {
                if ("relink" === a || "relink_waiting" === a) {
                    return "relinking"
                } else {
                    if ("backup" === a) {
                        return "backingup"
                    } else {
                        if ("waiting" === a) {
                            return "waiting"
                        } else {
                            return "relinkfailed"
                        }
                    }
                }
            } else {
                if ("backupable" === d) {
                    if ("backup" === a) {
                        if ("backingup" === b) {
                            return "backingup"
                        } else {
                            if ("resuming" === b) {
                                return "resuming"
                            } else {
                                if ("waiting-server" === b) {
                                    return "waiting-server"
                                } else {
                                    return "backingup"
                                }
                            }
                        }
                    }
                    if ("waiting" === a) {
                        return "waiting"
                    }
                    if ("suspending" === a) {
                        return "suspending"
                    }
                    if ("discarding" === a) {
                        return "discarding"
                    }
                    if ("wait_discard" === a || "wait_version_delete" === a) {
                        return "check"
                    }
                    if ("version_deleting" === a) {
                        return "version-deleting"
                    }
                    if ("preparing_version_delete" === a) {
                        return "waiting"
                    }
                    if ("discard_failed" === a || "cancel" === c || "canceling" === a || "failed" === c) {
                        return "failed"
                    }
                    if ("suspend" === c) {
                        return "suspend"
                    }
                    if ("partial" === c) {
                        if (true === e) {
                            return "none"
                        }
                        return "partial"
                    }
                    if ("success" === c || "done" === c) {
                        if (true === e) {
                            return "none"
                        }
                        return "successful"
                    }
                    if ("failed_checking" === c || "backingup" === c || "resuming" === c) {
                        return "check"
                    }
                    if ("version_delete_failed" === c) {
                        return "version-delete-failed"
                    }
                    if ("none" === c) {
                        return "none"
                    }
                } else {
                    if ("unauth" === d) {
                        return "authfailed"
                    } else {
                        if ("error_detect" === d) {
                            return "errordetect"
                        } else {
                            if ("broken" === d) {
                                if ("deleting" === a) {
                                    return "deleting"
                                } else {
                                    return "failed"
                                }
                            } else {
                                if ("restore_only" === d) {
                                    return "restoreonly"
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return "failed"
};
SYNO.SDS.Backup.getStatusText = function(d, a, c, e, b) {
    if ("exportable" === d) {
        if ("backup" === a || "waiting" === a) {
            return SYNO.SDS.Backup.String("app", "do_export")
        } else {
            if ("suspending" === a) {
                return SYNO.SDS.Backup.String("app", "task_status_suspending")
            } else {
                if ("discarding" === a) {
                    return SYNO.SDS.Backup.String("app", "task_status_discarding")
                } else {
                    if ("discard_failed" === a) {
                        return SYNO.SDS.Backup.String("app", "task_status_discard")
                    } else {
                        if ("canceling" === a) {
                            return _T("backup", "backup_do_cancel")
                        } else {
                            if ("none" === c || true === e) {
                                return SYNO.SDS.Backup.String("app", "exportable")
                            } else {
                                return SYNO.SDS.Backup.GetBkpResultStr(c)
                            }
                        }
                    }
                }
            }
        }
    } else {
        if ("importable" === d) {
            if ("none" === a) {
                return SYNO.SDS.Backup.String("app", "relinkable")
            } else {
                if ("canceling" === a) {
                    return SYNO.SDS.Backup.String("app", "relink_do_cancel")
                } else {
                    return SYNO.SDS.Backup.String("app", "do_relink")
                }
            }
        } else {
            if ("relinkable" === d) {
                if ("none" === a) {
                    return SYNO.SDS.Backup.String("app", "relinkable")
                } else {
                    if ("canceling" === a) {
                        return SYNO.SDS.Backup.String("app", "relink_do_cancel")
                    } else {
                        if ("backup" === a) {
                            return _T("netbackup", "netbkp_backuping")
                        } else {
                            if ("waiting" === a || "relink_waiting" === a) {
                                return SYNO.SDS.Backup.String("app", "waiting")
                            } else {
                                return SYNO.SDS.Backup.String("app", "do_relink")
                            }
                        }
                    }
                }
            } else {
                if ("backupable" === d) {
                    if ("backup" === a) {
                        if ("backingup" === b) {
                            return _T("netbackup", "netbkp_backuping")
                        } else {
                            if ("resuming" === b) {
                                return SYNO.SDS.Backup.String("app", "task_status_resuming")
                            } else {
                                if ("waiting-server" === b) {
                                    return SYNO.SDS.Backup.String("app", "waiting")
                                } else {
                                    return _T("netbackup", "netbkp_backuping")
                                }
                            }
                        }
                    } else {
                        if ("waiting" === a) {
                            return SYNO.SDS.Backup.String("app", "waiting")
                        } else {
                            if ("suspending" === a) {
                                return SYNO.SDS.Backup.String("app", "task_status_suspending")
                            } else {
                                if ("discarding" === a) {
                                    return SYNO.SDS.Backup.String("app", "task_status_discarding")
                                } else {
                                    if ("discard_failed" === a) {
                                        return SYNO.SDS.Backup.String("app", "task_status_discard")
                                    } else {
                                        if ("wait_discard" === a) {
                                            return SYNO.SDS.Backup.String("app", "task_status_check")
                                        } else {
                                            if ("version_deleting" === a) {
                                                return SYNO.SDS.Backup.String("app", "task_status_version_deleting")
                                            } else {
                                                if ("preparing_version_delete" === a) {
                                                    return SYNO.SDS.Backup.String("app", "waiting")
                                                } else {
                                                    if ("wait_version_delete" === a) {
                                                        return SYNO.SDS.Backup.String("app", "task_status_check")
                                                    } else {
                                                        if ("canceling" === a) {
                                                            return _T("backup", "backup_do_cancel")
                                                        } else {
                                                            return SYNO.SDS.Backup.GetBkpResultStr(c, e)
                                                        }
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    if ("unauth" === d) {
                        return SYNO.SDS.Backup.String("app", "auth_failed")
                    } else {
                        if ("error_detect" === d) {
                            return SYNO.SDS.Backup.String("app", "task_status_detecting")
                        } else {
                            if ("broken" === d) {
                                if ("deleting" === a) {
                                    return SYNO.SDS.Backup.String("app", "deleting") + " ..."
                                } else {
                                    return SYNO.SDS.Backup.String("app", "crashed")
                                }
                            } else {
                                if ("restore_only" === d) {
                                    return SYNO.SDS.Backup.String("app", "restore_only")
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    return _T("usbbackup", "usbbkp_error")
};
SYNO.SDS.Backup.getStatusSubText = function(e, a, b, d, c, f) {
    if ("exportable" === e || "backupable" === e || "importable" === e) {
        if ("discard_failed" === a || ("none" === a || "restore" === a) && ("failed" === b || ("partial" === b && true !== f) || "suspend" === b)) {
            if ("" !== c) {
                return SYNO.SDS.Backup.converLanString(c)
            } else {
                if (undefined !== d && SYNO.SDS.Backup.ERR_INTERNAL_ERROR !== d) {
                    return SYNO.SDS.Backup.GetErrorString(d)
                }
            }
        }
    } else {
        if ("relinkable" === e) {
            if ("canceling" === a || "none" === a) {
                if ("" !== c) {
                    return SYNO.SDS.Backup.converLanString(c)
                }
            }
        } else {
            if ("broken" === e) {
                if ("deleting" !== a) {
                    if ("" !== c) {
                        return SYNO.SDS.Backup.converLanString(c)
                    }
                }
            } else {
                if ("restore_only" === e) {
                    if ("" !== c) {
                        return SYNO.SDS.Backup.converLanString(c)
                    } else {
                        if (undefined !== d && SYNO.SDS.Backup.ERR_INTERNAL_ERROR !== d) {
                            return SYNO.SDS.Backup.GetErrorString(d)
                        }
                    }
                }
            }
        }
    }
    return "none"
};
SYNO.SDS.Backup.GetBkpResultStr = function(b, c, a) {
    if ("cancel" === b) {
        return SYNO.SDS.Backup.String("app", "task_status_cancel")
    }
    if ("suspend" === b) {
        return SYNO.SDS.Backup.String("app", "task_status_suspend")
    }
    if ("partial" === b) {
        if (true === c) {
            return SYNO.SDS.Backup.String("app", "localbkp_not_bkp")
        }
        if (a) {
            return SYNO.SDS.Backup.String("app", "partial_success") + '&nbsp(<a class="help_link" href="#" task-id="' + Ext.util.Format.htmlEncode(a) + '">' + SYNO.SDS.Backup.String("app", "version_detail") + "</a>)"
        } else {
            return SYNO.SDS.Backup.String("app", "partial_success")
        }
    }
    if ("success" === b || "done" === b) {
        if (true === c) {
            return SYNO.SDS.Backup.String("app", "localbkp_not_bkp")
        }
        return SYNO.SDS.Backup.String("app", "task_status_succeed")
    }
    if ("failed_checking" === b || "backingup" === b || "resuming" === b) {
        return SYNO.SDS.Backup.String("app", "task_status_check")
    }
    if ("discard" === b) {
        return SYNO.SDS.Backup.String("app", "task_status_discard")
    }
    if ("none" === b) {
        return SYNO.SDS.Backup.String("app", "localbkp_not_bkp")
    }
    if ("version_delete_failed" === b) {
        return SYNO.SDS.Backup.String("app", "task_status_version_delete_failed")
    }
    return SYNO.SDS.Backup.String("app", "task_status_error")
};
SYNO.SDS.Backup.getShareName = function(b) {
    if (!b) {
        return ""
    }
    var a = -1;
    if (-1 === (a = b.indexOf("/"))) {
        return b
    } else {
        return b.substr(0, a)
    }
};
SYNO.SDS.Backup.parseAppDependFolderInfo = function(d) {
    var b = {
        outline: [],
        detail: []
    };
    if (!d || !d.folder_list) {
        return b
    }
    var a = [];
    var e = [];
    var c = function(f) {
        return {
            path: f.folder,
            whitelist: SYNO.Backup.Util.deepCopyObject(f.whitelist)
        }
    };
    Ext.each(d.folder_list, function(f) {
        e.push(c(f));
        a.push(SYNO.SDS.Backup.getShareName(f.folder))
    }, this);
    a = SYNO.ux.Utils.uniqueApiArray(a);
    b.outline = a;
    b.detail = e;
    return b
};
Ext.ns("SYNO.Backup.Util");
SYNO.Backup.Util.HBKDisplayComboboxLoadData = function(a, b, e) {
    var d = function(f) {
        if (".hbk" === f.slice(-4, f.length)) {
            return f.slice(0, f.lastIndexOf(".hbk"))
        } else {
            return f
        }
    };
    var c = [];
    Ext.each(b, function(g) {
        if (Ext.isDefined(e)) {
            var f = g[e];
            c.push([d(f), f])
        } else {
            c.push([d(g), g])
        }
    });
    a.getStore().loadData(c, false);
    if (c.length > 0) {
        a.setValue(c[0][1]);
        return true
    } else {
        a.emptyText = SYNO.SDS.Backup.String("app", "no_target_available");
        a.setValue("");
        return false
    }
};
SYNO.Backup.Util.AddTip = function(a, b, e) {
    var d = SYNO.ux.AddTip(a, b);
    d.firstChild.classList.remove("ext:qtip");
    var c = new Ext.ToolTip(Ext.apply({
        target: d.firstChild.id,
        html: b,
        dismissDelay: 5000,
        floating: {
            shadow: false,
            shim: true,
            useDisplay: true,
            constrain: false
        }
    }, e));
    return c
};
SYNO.Backup.Util.getPkgVersion = function() {
    return SYNO.SDS.Config.FnMap["SYNO.SDS.Backup.Application"].config.version
};
SYNO.Backup.Util.IsImage = function(a) {
    if (!a) {
        return false
    }
    return ("image" === a || "cloud_image" === a)
};
SYNO.Backup.Util.ExtractPattern = function(a, c) {
    if (!c) {
        return a
    }
    var b = [];
    Ext.each(a, function(d) {
        if (("dir" === c && d.endsWith("/")) || ("file" === c && !d.endsWith("/"))) {
            b.push(d)
        }
    });
    return b
};
SYNO.Backup.Util.IsSubClass = function(b, a) {
    if (!b || !a) {
        return false
    }
    var d = Ext.getClassByName(String(b));
    var c = Ext.getClassByName(String(a));
    if (!d || !c) {
        return false
    }
    return d.prototype instanceof c || d === c
};
SYNO.Backup.Util.deepCopyObject = function(a) {
    if (!a) {
        return
    }
    return JSON.parse(JSON.stringify(a))
};
SYNO.Backup.Util.updateAppShareTip = function(b, c, a) {
    if (!b || !b.getRootNode()) {
        return
    }
    var e = [];
    Ext.each(c.get("depend").folder_list, function(g) {
        e.push(SYNO.SDS.Backup.getShareName(g.folder))
    });
    e = SYNO.ux.Utils.uniqueApiArray(e);
    var d = function(g, h) {
        var j = [];
        Ext.iterate(h, function(k, l) {
            j.push(l)
        });
        var i = "<b>" + j.join(", ") + "</b>";
        return String.format(a, g, i)
    };
    var f = function(g) {
        for (var h in g) {
            if (g.hasOwnProperty(h)) {
                return true
            }
        }
        return false
    };
    Ext.each(e, function(g) {
        var i = SYNO.SDS.Backup.getTreeNodeByCaseId(b, "/" + g);
        if (!i) {
            return true
        }
        if (!i.dependApps) {
            i.dependApps = {}
        }
        i.getUI().getEl().classList.remove("syno-backup-show-app-share");
        if (false === i.dependApps.hasOwnProperty(c.id) && c.get("checked")) {
            i.dependApps[c.id] = (c.get("name")) ? c.get("name") : c.id
        } else {
            if (true === i.dependApps.hasOwnProperty(c.id) && !c.get("checked")) {
                delete i.dependApps[c.id]
            }
        }
        if (f(i.dependApps)) {
            i.getUI().getEl().classList.add("syno-backup-show-app-share");
            var h = i.getUI().getEl().getElementsByClassName("syno-backup-tree-node-app-share");
            h[0].setAttribute("ext:wtip", d(SYNO.SDS.Backup.ConvertUniqueIdToConflictId(i.id).substr(1), i.dependApps))
        }
    })
};
SYNO.Backup.Util.parseVolName = function(a, d) {
    if ("petaspace" === a) {
        return _T("share", "peta_share_control_panel_vol_desc")
    }
    var c = a.replace("/volume", "");
    var b = "";
    if (!isNaN(c)) {
        b = parseInt(c, 10)
    } else {
        b = c
    }
    return String.format("{0} {1} {2}", _T("volume", "volume"), b, d ? "(" + Ext.util.Format.htmlEncode(d) + ")" : "")
};
SYNO.Backup.Util.getSharePath = function(a) {
    if (!a || !Ext.isString(a)) {
        return ""
    }
    if (0 !== a.indexOf("/")) {
        return ""
    }
    if (a.indexOf("/") === a.lastIndexOf("/")) {
        return a
    }
    var b = a.indexOf("/", 1);
    return a.substr(0, b)
};
SYNO.Backup.Util.domAddTip = function(e, k) {
    var j = document.createElement("a");
    var g = document.createElement("img");
    var a = "vertical-align:bottom; position: relative;";
    var h = Ext.getCmp(e.id);
    var b = Ext.id();
    var c = SYNO.SDS.UIFeatures.test("isRetina") ? "2x" : "1x";
    g.setAttribute("src", "webman/3rdparty/HyperBackup/images/" + c + "/bt_information_mini.png");
    g.setAttribute("width", "24px");
    g.setAttribute("height", "24px");
    g.setAttribute("draggable", "false");
    if (h && h.defaultTriggerWidth) {
        a += " left:" + h.defaultTriggerWidth + "px;"
    }
    g.setAttribute("style", a);
    g.setAttribute("ext:wtip", k);
    g.setAttribute("id", b);
    j.appendChild(g);
    if (h instanceof SYNO.ux.DisplayField) {
        e.appendChild(j)
    } else {
        if (h instanceof SYNO.ux.Button && Ext.getDom(e).nextSibling) {
            var i = e.dom.getAttribute("style") + " margin-right:0px !important;";
            var f = "margin-right:6px !important;";
            var d = Ext.getDom(e);
            d.setAttribute("style", i);
            j.setAttribute("style", f);
            d.parentNode.insertBefore(j, d.nextSibling)
        } else {
            if (h instanceof SYNO.ux.TextArea) {
                Ext.getDom(e).parentNode.parentNode.appendChild(j)
            } else {
                Ext.getDom(e).parentNode.appendChild(j)
            }
        }
    }
    if (h && h.el) {
        h.el.set({
            "aria-describedby": h.el.dom.getAttribute("aria-describedby") + " " + b
        })
    }
    return j
};
SYNO.Backup.Util.getCertErrReason = function(a, b) {
    switch (SYNO.SDS.Backup.GetErrorKey(a)) {
        case "ERR_SSL_VERIFY_FAIL_UNKNOWN_SIGNATURE":
        case "ERR_SSL_VERIFY_FAIL_NEW_UNKNOWN_SIGNATURE":
            return String.format(SYNO.SDS.Backup.GetErrorString(a), b.issuer);
        case "ERR_SSL_VERIFY_FAIL_NEW_HOSTNAME_NOT_MATCH":
        case "ERR_SSL_VERIFY_FAIL_HOSTNAME_NOT_MATCH":
            return String.format(SYNO.SDS.Backup.GetErrorString(a), b.req_host, b.cert_hosts);
        case "ERR_SSL_VERIFY_FAIL_NEW_EXPIRED":
        case "ERR_SSL_VERIFY_FAIL_EXPIRED":
            return String.format(SYNO.SDS.Backup.GetErrorString(a), b.valid_date);
        default:
            return ""
    }
    return ""
};
SYNO.Backup.Util.DisplayAccount = function(c, b, a) {
    c.setValue(Ext.util.Format.ellipsis(b, a));
    c.getEl().dom.setAttribute("ext:qtip", b)
};
Ext.namespace("SYNO.SDS.Backup");
(function(c) {
    var b = {
        ERR_DISALLOW_DEMOSITE: [116, _T("common", "error_demo")],
        ERR_PARAM: [4400, _T("error", "error_error_system")],
        ERR_INTERNAL_ERROR: [4401, _T("error", "error_error_system")],
        ERR_CLIENT_NO_SPACE: [4402, SYNO.SDS.Backup.String("error", "client_no_space")],
        ERR_SERVER_NO_SPACE: [4403, SYNO.SDS.Backup.String("error", "repo_no_space")],
        ERR_CLIENT_NO_QUOTA: [4404, SYNO.SDS.Backup.String("error", "client_no_quota")],
        ERR_SERVER_NO_QUOTA: [4405, SYNO.SDS.Backup.String("error", "server_no_quota")],
        ERR_NOT_OWNER: [4406, SYNO.SDS.Backup.String("error", "backup_not_owner")],
        ERR_SNAPSHOT_RESTORING: [4407, SYNO.SDS.Backup.String("error", "snapshot_restoring")],
        ERR_RESTORING: [4408, SYNO.SDS.Backup.String("error", "is_restoring")],
        ERR_BACKING_UP_RESTORING: [4409, SYNO.SDS.Backup.String("error", "is_backing_up_restoring")],
        ERR_CLIENT_PERM_DENIED: [4410, SYNO.SDS.Backup.String("error", "client_perm_denied")],
        ERR_SERVER_PERM_DENIED: [4411, SYNO.SDS.Backup.String("error", "server_deny")],
        ERR_PORT_NOT_VALID: [4412, SYNO.SDS.Backup.String("error", "port_conflict")],
        ERR_NAME_NOT_VALID: [4413, SYNO.SDS.Backup.String("error", "s3_bucket_name_invalid")],
        ERR_TARGET_VERSION_TOO_OLD: [4414, SYNO.SDS.Backup.String("error", "target_version_too_old")],
        ERR_SERVER_UNDER_MAINTENANCE: [4415, SYNO.SDS.Backup.String("error", "server_maintenance")],
        ERR_CONFIG_OPERATE_ADMIN: [4416, SYNO.SDS.Backup.String("error", "confbkp_operating_user")],
        ERR_SHARE_READ_ONLY: [4417, SYNO.SDS.Backup.String("app", "share_used_by_running_application")],
        ERR_SERVICE_NO_VOLUME: [4418, SYNO.SDS.Backup.String("error", "volume_not_found")],
        ERR_SERVICE_NO_SHARE: [4419, SYNO.SDS.Backup.String("error", "create_service_share")],
        ERR_VOLUME_NOT_EXIST: [4420, SYNO.SDS.Backup.String("error", "volume_not_found")],
        ERR_VOLUME_FS_NOT_SUPPORT: [4422, String.format(SYNO.SDS.Backup.String("error", "volume_fs_not_support"), "EXT3/EXT4")],
        ERR_SHARE_NOT_EXIST: [4423, SYNO.SDS.Backup.String("error", "share_not_exist")],
        ERR_SHARE_ENCRYPTION: [4425, SYNO.SDS.Backup.String("error", "not_support_restore_to_encrypted_share")],
        ERR_CONFIG_VERSION_WRONG: [4428, SYNO.SDS.Backup.String("error", "confbkp_failed_get_conf_file")],
        ERR_CONFIG_VERSION_FUTURE: [4429, SYNO.SDS.Backup.String("error", "confbkp_error_version")],
        ERR_OFFLINE: [4430, SYNO.SDS.Backup.String("error", "general_backup_destination_disconnect")],
        ERR_RESTORE_VOLUME_BUILDING: [4431, SYNO.SDS.Backup.String("error", "is_creating_volume")],
        ERR_PROTOCOL_VERSION_CLIENT_TOO_OLD: [4432, SYNO.SDS.Backup.String("error", "client_version_old")],
        ERR_PROTOCOL_VERSION_SERVER_TOO_OLD: [4433, SYNO.SDS.Backup.String("error", "server_version_old")],
        ERR_BAD_ADDRESS: [4434, SYNO.SDS.Backup.String("error", "dns_look_up_error")],
        ERR_CONFIG_RESTORING: [4435, SYNO.SDS.Backup.String("error", "is_processing_conf")],
        ERR_CONFIG_NO_SPACE: [4436, SYNO.SDS.Backup.String("error", "conf_no_space")],
        ERR_CONFIG_WRONG_FORMAT: [4437, SYNO.SDS.Backup.String("error", "conf_format_error")],
        ERR_CONFIG_PORT_CONFLICT: [4438, SYNO.SDS.Backup.String("error", "conf_port_conflict")],
        ERR_CONFIG_SERVICE_FAIL: [4439, SYNO.SDS.Backup.String("error", "restore_import_fail")],
        ERR_NO_RESPONSE: [4440, SYNO.SDS.Backup.String("error", "general_backup_destination_no_response_v1")],
        ERR_CONNECTION_BLOCKED: [4441, SYNO.SDS.Backup.String("error", "err_ip_denied")],
        ERR_SERVICE_DISABLE: [4442, SYNO.SDS.Backup.String("error", "service_disable")],
        ERR_SSH_FAIL: [4443, SYNO.SDS.Backup.String("error", "ssh_disconnected")],
        ERR_AUTH_FAIL: [4444, SYNO.SDS.Backup.String("error", "auth_fail")],
        ERR_AUTH_DENIED: [4445, SYNO.SDS.Backup.String("error", "no_app_privilege")],
        ERR_UNSTABLE_NETWORK: [4446, SYNO.SDS.Backup.String("error", "network_unstable")],
        ERR_SSL_NOT_SUPPORT: [4447, SYNO.SDS.Backup.String("error", "ssl_not_support")],
        ERR_SSL_VERIFY_FAIL: [4448, SYNO.SDS.Backup.String("error", "ssl_verify_fail")],
        ERR_TIME_SKEWED: [4449, SYNO.SDS.Backup.String("error", "time_skewed")],
        ERR_REQUESTS_TOO_MANY: [4450, SYNO.SDS.Backup.String("error", "requests_too_many")],
        ERR_STAGE_REJECT_OPERATION: [4451, SYNO.SDS.Backup.String("error", "stage_reject_operation")],
        ERR_JOB_NOT_RUNNING: [4452, SYNO.SDS.Backup.String("error", "job_not_running")],
        ERR_DEST_FILE_NOT_EXIST: [4453, SYNO.SDS.Backup.String("error", "dest_file_not_exist")],
        ERR_DATA_SESSION_EXPIRED: [4454, SYNO.SDS.Backup.String("error", "data_session_expired")],
        ERR_REPOSITORY_NOT_EXIST: [4455, SYNO.SDS.Backup.String("error", "repo_not_exist")],
        ERR_REPOSITORY_EXIST: [4456, SYNO.SDS.Backup.String("error", "repo_already_exist")],
        ERR_REPOSITORY_BUSY: [4457, SYNO.SDS.Backup.String("error", "repository_busy")],
        ERR_REPOSITORY_PERM_DENIED: [4459, SYNO.SDS.Backup.String("error", "no_repo_permission_action")],
        ERR_TARGET_NOT_EXIST: [4460, SYNO.SDS.Backup.String("error", "target_not_exist")],
        ERR_TARGET_EXIST: [4461, SYNO.SDS.Backup.String("error", "target_already_exist")],
        ERR_TARGET_BUSY: [4462, SYNO.SDS.Backup.String("error", "target_busy")],
        ERR_TARGET_BUSY_ROLLBACK: [4463, SYNO.SDS.Backup.String("error", "target_busy_rollback")],
        ERR_TARGET_BUSY_BACKUP: [4464, SYNO.SDS.Backup.String("error", "target_busy_backup")],
        ERR_TARGET_BUSY_RESTORE: [4465, SYNO.SDS.Backup.String("error", "target_busy_restore")],
        ERR_TARGET_BUSY_CHECKING: [4466, SYNO.SDS.Backup.String("error", "target_busy_checking")],
        ERR_TARGET_BROKEN: [4467, SYNO.SDS.Backup.String("error", "target_broken")],
        ERR_TARGET_NEED_ROLLBACK: [4468, SYNO.SDS.Backup.String("error", "target_busy_protect_rollback")],
        ERR_CLOUD_CACHE_INVALID: [4469, SYNO.SDS.Backup.String("error", "status_cloud_index_broken")],
        ERR_TARGET_LINKKEY_MISMATCH: [4470, SYNO.SDS.Backup.String("error", "status_target_key_mismatch")],
        ERR_TARGET_PERM_DENIED: [4471, SYNO.SDS.Backup.String("error", "no_target_permission_action")],
        ERR_VERSION_NOT_EXIST: [4472, SYNO.SDS.Backup.String("error", "version_not_exist")],
        ERR_VERSION_LOCKED: [4475, SYNO.SDS.Backup.String("error", "version_lock_delete_fail")],
        ERR_NO_AVAILABLE_VERSION: [4476, SYNO.SDS.Backup.String("error", "no_available_restore_version")],
        ERR_MP_NOT_EMPTY: [4477, SYNO.SDS.Backup.String("error", "mp_not_empty")],
        ERR_USER_EXCEED_MAX: [4478, SYNO.SDS.Backup.String("error", "user_exceed_max")],
        ERR_GROUP_EXCEED_MAX: [4479, SYNO.SDS.Backup.String("error", "group_exceed_max")],
        ERR_APP_VERSION_INVALID: [4480, SYNO.SDS.Backup.String("error", "app_version_invalid")],
        ERR_UMOUNT_FAIL: [4481, SYNO.SDS.Backup.String("error", "umount_fail")],
        ERR_APP_MYSQL_PWD_WRONG: [4482, SYNO.SDS.Backup.String("error", "maria_db_auth_fail")],
        ERR_APP_SURVEILLANCE_ENABLE: [4483, SYNO.SDS.Backup.String("error", "stop_surveillance_first")],
        ERR_APP_MYSQL_ENABLE: [4484, SYNO.SDS.Backup.String("error", "maria_db_no_enable")],
        ERR_APP_MYSQL_VOLUME_CRASH: [4485, SYNO.SDS.Backup.String("error", "maria_db_volume_crash")],
        ERR_APP_VOLUME: [4486, SYNO.SDS.Backup.String("error", "app_no_avail_volume")],
        ERR_APP_OCCUPIED: [4487, SYNO.SDS.Backup.String("error", "app_occupied")],
        ERR_APP_NO_SPACE: [4488, SYNO.SDS.Backup.String("error", "client_no_space")],
        ERR_APP_NETWORK: [4489, SYNO.SDS.Backup.String("error", "app_network_disconnected")],
        CUSTOMIZED_WEBAPI_ERROR_CODE: [4490, _T("error", "error_error_system")],
        CUSTOMIZED_WEBAPI_ERROR_CODE_CONTAINER_INVALID_NAME: [4491, SYNO.SDS.Backup.String("error", "s3_bucket_name_invalid")],
        CUSTOMIZED_WEBAPI_ERROR_CODE_CONTAINER_EXIST: [4492, SYNO.SDS.Backup.String("error", "s3_bucket_existed")],
        CUSTOMIZED_WEBAPI_ERROR_CODE_CONTAINER_TOO_MANY: [4493, SYNO.SDS.Backup.String("error", "s3_bucket_number_limit")],
        ERR_BACKUP_CONF_FAIL: [4494, SYNO.SDS.Backup.String("error", "status_backup_conf_fail")],
        ERR_BACKUP_APP_FAIL: [4495, SYNO.SDS.Backup.String("error", "status_backup_app_fail")],
        ERR_ENCRYPT_VERIFY_FAIL: [4496, SYNO.SDS.Backup.String("error", "task_password_invalid")],
        ERR_SHARE_ENCRYPTED: [4497, SYNO.SDS.Backup.String("error", "restore_share_encrypted")],
        ERR_SESSION_EXPIRED: [4498, SYNO.SDS.Backup.String("error", "task_session_expired")],
        ERR_SERVER_NOT_READY: [4499, SYNO.SDS.Backup.String("error", "image_backup_scan_not_ready")],
        ERR_CANCEL_JOB_NOT_EXIST: [4500, SYNO.SDS.Backup.String("error", "cancel_job_not_exist")],
        ERR_TARGET_UNIKEY_MISMATCH: [4501, SYNO.SDS.Backup.String("error", "status_task_target_mismatch")],
        ERR_SERVICE_DISABLE_V2: [4502, SYNO.SDS.Backup.String("error", "service_disable_v2")],
        ERR_NO_ACTIVE_SUBSCRIPTION: [4503, SYNO.SDS.Backup.String("error", "no_active_subscription")],
        ERR_UNENCRYPTED_TRANSMISSION_NOT_SUPPORT: [4504, SYNO.SDS.Backup.String("error", "unencrypted_transmission_not_support")],
        ERR_TARGET_SHARE_ENCRYPTED: [4505, SYNO.SDS.Backup.String("error", "encryption_shared_unmount")],
        ERR_MOUNT_FIREBALL_FAIL: [4506, SYNO.SDS.Backup.String("error", "mount_fireball_fail")],
        ERR_SSL_VERIFY_FAIL_HOSTNAME_NOT_MATCH: [4507, SYNO.SDS.Backup.String("error", "subject_name_not_match")],
        ERR_SSL_VERIFY_FAIL_EXPIRED: [4508, SYNO.SDS.Backup.String("error", "cert_expired_ex")],
        ERR_SSL_VERIFY_FAIL_UNKNOWN_SIGNATURE: [4509, SYNO.SDS.Backup.String("error", "unknown_cert_issuer_ex")],
        ERR_SSL_VERIFY_FAIL_NEW_UNKNOWN_SIGNATURE: [4510, SYNO.SDS.Backup.String("error", "new_cert_unknown_cert_issuer_ex")],
        ERR_SSL_VERIFY_FAIL_NEW_HOSTNAME_NOT_MATCH: [4511, SYNO.SDS.Backup.String("error", "new_cert_subject_name_not_match")],
        ERR_SSL_VERIFY_FAIL_NEW_EXPIRED: [4512, SYNO.SDS.Backup.String("error", "new_cert_cert_expired_ex")],
        ERR_OBJECT_IN_GLACIER: [4513, SYNO.SDS.Backup.String("aws_s3", "object_in_glacier")],
        ERR_CONNECT_QUICKCONNECT: [4514, SYNO.SDS.Backup.String("error", "not_allow_connect_to_quickconnect")],
        ERR_UNEXPECTED_TERMINATION: [4515, SYNO.SDS.Backup.String("error", "unexpected_termination")],
        ERR_ROOT_PARTITION_NO_ENOUGH_SPACE: [4516, SYNO.SDS.Backup.String("error", "root_partition_no_enough_space")],
        ERR_TARGET_NO_BACKUP_DATA: [4517, SYNO.SDS.Backup.String("error", "target_no_backup_data")],
        ERR_SYNOBACKUPD_STOP: [4518, SYNO.SDS.Backup.String("error", "synobackupd_stop")],
        ERR_SERVER_NOT_DOWNLOADABLE: [4519, SYNO.SDS.Backup.String("error", "can_not_download_cloud_file")],
        ERR_NEED_INTEGRITY_CHECK: [4520, SYNO.SDS.Backup.String("error", "need_integrity_check")],
        ERR_SERVER_INTERNAL_ERROR: [4521, SYNO.SDS.Backup.String("error", "server_internal_error")],
        WEBAPI_RESTORE_ERR_RESTORE_ABB_CONFLICT: [4522, SYNO.SDS.Backup.String("error", "restore_abb_data_conflict")],
        ERR_CLOUD_NOT_SUPPORT_ACD: [4523, SYNO.SDS.Backup.String("error", "cloud_not_support_acd")]
    };
    Ext.iterate(b, function(e, f) {
        c[e] = f[0]
    });

    function d(e) {
        var f = null;
        if (Ext.isObject(e) && e.code) {
            return d(e.code)
        }
        Ext.iterate(b, function(g, h) {
            if (e === h[0]) {
                f = h[1];
                if (Ext.isObject(f)) {
                    if (!f.text && f.text_param) {
                        f.text = f.text_param
                    }
                    if (!f.text) {
                        f.text = _T("error", "error_error_system")
                    }
                }
                return false
            }
        });
        return f
    }

    function a(f, h) {
        var i = [];
        var g = false;
        var e = f.text_param || f.text;
        if (!h) {
            return f.text
        }
        if (Ext.isArray(h) && h.length > 0) {
            return String.format.apply(String, [e].concat(h))
        } else {
            if (Ext.isObject(h)) {
                g = true;
                Ext.each(f.replace_keys, function(j) {
                    if (!h.hasOwnProperty(j)) {
                        g = false;
                        return false
                    }
                    i.push(h[j])
                });
                if (g) {
                    return String.format.apply(String, [e].concat(i))
                }
            }
        }
        return f.text
    }
    c.GetErrorKey = function(e) {
        var f = "";
        Ext.iterate(b, function(g, h) {
            if (e === h[0]) {
                f = g;
                return false
            }
        });
        return f
    };
    c.GetErrorString = function(e, g) {
        if (Ext.isObject(e) && e.code) {
            return c.GetErrorString(e.code, e.errors)
        }
        var f = d(e);
        if (!f) {
            if (SYNO.SDS.ConfigBackup.isConfigError(e)) {
                return SYNO.SDS.ConfigBackup.getErrorString(e, g)
            }
            return _T("error", "error_error_system")
        }
        if (Ext.isString(f)) {
            return f
        } else {
            return a(f, g)
        }
    };
    c.GetErrorStringArg = function(e, g) {
        var f = c.GetErrorString(e);
        if (!Ext.isString(f)) {
            return _T("error", "error_error_system")
        }
        if (!Ext.isArray(g)) {
            g = new Array(g)
        }
        var h = g.slice();
        h.unshift(f);
        return String.format.apply(this, h)
    };
    c.GetErrorStringEx = function(e) {
        if (Ext.isEmpty(e) || Ext.isEmpty(e.code)) {
            return _T("error", "error_error_system")
        }
        switch (e.code) {
            case c.ERR_SERVER_NOT_DOWNLOADABLE:
            case c.WEBAPI_RESTORE_ERR_RESTORE_ABB_CONFLICT:
                if (!Ext.isEmpty(e.errors) && !Ext.isEmpty(e.errors.error_msg)) {
                    return c.GetErrorStringArg(e.code, e.errors.error_msg)
                }
        }
        return c.GetErrorString(e.code)
    }
})(SYNO.SDS.Backup);
try {
    Ext.form.VTypes.backup_destinationText = _T("vtype", "bad_backup_destination");
    Ext.form.VTypes.backup_destinationMask = /[^\\\{\}\|\^\[\]\?\=\:\+\/\*\(\)\$\!"#%&',;<>@`~]/;
    Ext.form.VTypes.backup_destinationNotValid = /[\\\{\}\|\^\[\]\?\=\:\+\/\*\(\)\$\!"#%&',;<>@`~]/;
    Ext.form.VTypes.backup_destinationVal = /^[^\-\s\.]/;
    Ext.form.VTypes.backup_destinationEnd = /\S$/;
    Ext.form.VTypes.backup_destination = function(a) {
        return (a.search(Ext.form.VTypes.backup_destinationNotValid) == -1) && Ext.form.VTypes.backup_destinationVal.test(a) && Ext.form.VTypes.backup_destinationEnd.test(a)
    };
    Ext.form.VTypes.backup_targetText = _T("vtype", "bad_backup_target");
    Ext.form.VTypes.backup_targetMask = /[^\\\{\}\|\^\[\]\?\=\:\+\/\*\(\)\$\!"#%&',;<>@`~]/;
    Ext.form.VTypes.backup_targetNotValid = /[\\\{\}\|\^\[\]\?\=\:\+\/\*\(\)\$\!"#%&',;<>@`~]/;
    Ext.form.VTypes.backup_targetVal = /^[^\-\s\.]/;
    Ext.form.VTypes.backup_targetEnd = /\S$/;
    Ext.form.VTypes.backup_target = function(a) {
        return (a.search(Ext.form.VTypes.backup_targetNotValid) == -1) && Ext.form.VTypes.backup_targetVal.test(a) && Ext.form.VTypes.backup_targetEnd.test(a)
    }
} catch (error) {};
