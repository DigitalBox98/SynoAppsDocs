/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.Backup.Client.Explore.Utils");
Ext.apply(SYNO.SDS.Backup.Client.Explore.Utils, {
    isTarget: function(a, c) {
        var b = a.split(".");
        if (1 === b.length) {
            return false
        }
        var d = b[b.length - 1].toLowerCase();
        if (c) {
            if ("hbk" !== d) {
                return false
            }
        } else {
            if ("bkpi" !== d) {
                return false
            }
        }
        return true
    },
    isThisPkgNewer: function() {
        if (!SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.Backup.Application")) {
            return false
        }
        if (!SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.BackupService.Instance")) {
            return true
        }
        var b = 0;
        var a = SYNO.SDS.Backup.Client.Explore.AppInstance.prototype.version;
        if (SYNO.SDS.Backup.Server && SYNO.SDS.Backup.Server.Explore) {
            b = SYNO.SDS.Backup.Server.Explore.AppInstance.prototype.version
        }
        if (a <= b) {
            return false
        }
        return true
    },
    checkFn_v1: function(a, b) {
        if ("6" !== _S("majorversion") || "0" !== _S("minorversion")) {
            return false
        }
        if (!SYNO.SDS.Backup.Client.Explore.Utils.checkFn(a, b)) {
            return false
        }
        return true
    },
    checkFn: function(a, b) {
        if (!_S("is_admin")) {
            return false
        }
        if (!SYNO.SDS.Backup.Client.Explore.Utils.isThisPkgNewer()) {
            return false
        }
        if (!SYNO.SDS.Backup.Client.Explore.Utils.isTarget(b[0].get("filename"), b[0].get("isdir"))) {
            return false
        }
        return true
    },
    launchFn: function(a) {
        SYNO.SDS.AppLaunch("SYNO.SDS.Backup.Client.Explore.AppInstance", {
            fb_recs: a,
            launcher: "FileStation",
            backend: "HyperBackup-backend"
        })
    },
    getIconFn: function(b, c, a) {
        if (!SYNO.SDS.Backup.Client.Explore.Utils.isThisPkgNewer()) {
            return false
        }
        if (!SYNO.SDS.Backup.Client.Explore.Utils.isTarget(c.get("filename"), c.get("isdir"))) {
            return false
        }
        if (SYNO.SDS.UIFeatures.test("isRetina")) {
            if (c.get("isdir")) {
                return "webman/3rdparty/HyperBackup/images/2x/target_icon.png"
            } else {
                return "webman/3rdparty/HyperBackup/images/files_ext/bkpi_32.png"
            }
        } else {
            if (c.get("isdir")) {
                return "webman/3rdparty/HyperBackup/images/1x/target_icon.png"
            } else {
                return "webman/3rdparty/HyperBackup/images/files_ext/bkpi_16.png"
            }
        }
    },
    checkThumbnailFn: function(a) {
        if (!SYNO.SDS.Backup.Client.Explore.Utils.isThisPkgNewer()) {
            return false
        }
        if (!SYNO.SDS.Backup.Client.Explore.Utils.isTarget(a.filename, a.isdir)) {
            return false
        }
        return true
    },
    getThumbnailFn: function(c) {
        var b = Ext.decode(c.path).split(".");
        var d = b[b.length - 1].toLowerCase();
        var a = false;
        if ("bkpi" === d) {
            a = true
        }
        if (SYNO.SDS.UIFeatures.test("isRetina")) {
            if (a) {
                return "webman/3rdparty/HyperBackup/images/files_ext/bkpi_512.png"
            } else {
                return "webman/3rdparty/HyperBackup/images/2x/target_thumb.png"
            }
        } else {
            if (a) {
                return "webman/3rdparty/HyperBackup/images/files_ext/bkpi_256.png"
            } else {
                return "webman/3rdparty/HyperBackup/images/1x/target_thumb.png"
            }
        }
    },
    GetErrorString: function(a, b) {
        if (SYNO.SDS.Backup.GetErrorString) {
            return SYNO.SDS.Backup.GetErrorString(a, b)
        } else {
            return ""
        }
    },
    GetErrorStringEx: function(a) {
        if (SYNO.SDS.Backup.GetErrorStringEx) {
            return SYNO.SDS.Backup.GetErrorStringEx(a)
        } else {
            return ""
        }
    },
    GetString: function(b, a) {
        if (SYNO.SDS.Backup.String) {
            return SYNO.SDS.Backup.String(b, a)
        } else {
            return ""
        }
    },
    GetJobTrayCls: function() {
        return "syno-sds-backup-client-jobtray"
    }
});
Ext.ns("SYNO.SDS.Backup.Explore");
SYNO.SDS.Backup.Explore.ConverSize = function(d, c) {
    d = d ? d : 0;
    c = c ? c : 0;
    var f = 1024;
    var a = f * 1024;
    var e = a * 1024;
    var g = e * 1024;
    var b = parseFloat(d);
    if (isNaN(b)) {
        return d
    }
    d = b;
    if ((d >= 0) && (d < f)) {
        return d.toFixed(c) + " B"
    } else {
        if ((d >= f) && (d < a)) {
            return (d / f).toFixed(c) + " KB"
        } else {
            if ((d >= a) && (d < e)) {
                return (d / a).toFixed(c) + " MB"
            } else {
                if ((d >= e) && (d < g)) {
                    return (d / e).toFixed(c) + " GB"
                } else {
                    return (d / g).toFixed(c) + " TB"
                }
            }
        }
    }
};
SYNO.SDS.Backup.Explore.htmlEncodeTip = function(a) {
    var c = Ext.util.Format.htmlEncode(a);
    var b = Ext.util.Format.htmlEncode(c);
    return b
};
SYNO.SDS.Backup.Explore.lengthEllipsis = function(b, a, c) {
    return '<span ext:qtip="' + SYNO.SDS.Backup.Explore.htmlEncodeTip(b) + '">' + Ext.util.Format.ellipsis(Ext.util.Format.htmlEncode(b), a, c) + "</span>"
};
SYNO.SDS.Backup.Explore.widthEllipsis = function(b, a) {
    return '<span ext:qtip="' + SYNO.SDS.Backup.Explore.htmlEncodeTip(b) + '" style="overflow: hidden; text-overflow: ellipsis; display: block; white-space: nowrap; width: ' + a + 'px">' + Ext.util.Format.htmlEncode(b) + "</span>"
};
SYNO.SDS.Backup.Explore.DateTimeFormatter = SYNO.SDS.DateTimeFormatter || function(a, c) {
    if (!a || Object.prototype.toString.call(a) !== "[object Date]") {
        return ""
    }
    var b = c && c.type;
    var d;
    if (b === "date") {
        d = "Y-m-d"
    } else {
        if (b === "time") {
            d = "H:i"
        } else {
            if (b === "datetimesec") {
                d = "Y-m-d H:i:s"
            } else {
                if (b === "datetimesecms") {
                    d = "Y-m-d H:i:s.u"
                } else {
                    if (b === "timesec") {
                        d = "H:i:s"
                    } else {
                        if (b === "timesecms") {
                            d = "H:i:s.u"
                        } else {
                            d = "Y-m-d H:i"
                        }
                    }
                }
            }
        }
    }
    return a.format(d)
};
(function() {
    var a = SYNO.SDS.Backup.Client.Explore.Utils.GetString;
    var c = SYNO.SDS.Backup.Client.Explore.Utils.GetErrorString;
    var b = SYNO.SDS.Backup.Client.Explore.Utils.GetErrorStringEx;
    Ext.define("SYNO.SDS.Backup.Client.Explore.AppInstance", {
        extend: "SYNO.SDS.AppInstance",
        version: 2,
        appWindowName: "SYNO.SDS.Backup.Client.Explore.AppWindow"
    });
    Ext.define("SYNO.SDS.Backup.Client.Explore.AppWindow", {
        extend: "SYNO.SDS.AppWindow",
        minHeight: 580,
        minWidth: 800,
        layout: "fit",
        isDownloading: false,
        support_filter: false,
        support_restore: false,
        data_enc: false,
        sess_id: null,
        sess_key: null,
        warnedNodes: [],
        hostname: a("explorer", "unknown_host"),
        folderDisplayLimit: 10000,
        constructor: function(d) {
            var e = {
                height: 580,
                width: 800,
                cls: "syno-backup-client-explore ",
                showHelp: false
            };
            Ext.apply(e, d);
            this.callParent([e])
        },
        open: function() {
            this.pathBar.path = "";
            this.opened = true;
            this.sess_id = null;
            this.sess_key = null;
            this.taskId = null;
            this.accountMeta = null;
            this.warnedNodes = [];
            return this.onOpen.apply(this, arguments)
        },
        loadConfig: function(e) {
            Ext.apply(this, e);
            if ("BackupServer" === e.launcher && e.repoPath) {
                this.transferType = "browse_local";
                this.targetType = "image"
            }
            if ("FileStation" === e.launcher && e.fb_recs) {
                var f = e.fb_recs[0].data.real_path;
                var d = f.split("/");
                if (e.fb_recs[0].data.isdir) {
                    this.repoPath = d.slice(0, -1).join("/");
                    this.targetId = d[d.length - 1]
                } else {
                    this.repoPath = d.slice(0, -2).join("/");
                    this.targetId = d[d.length - 2]
                }
                this.transferType = "browse_local";
                this.targetType = "image"
            }
            if (_S("is_admin") && "BackupAndRestore" === e.launcher) {
                this.support_restore = true
            }
        },
        onOpen: function(d) {
            this.loadConfig(d);
            this.setStatusBusy();
            this.sendWebAPI({
                api: "SYNO.SDS.Backup.Client.Explore.Target",
                version: 1,
                method: "get",
                scope: this,
                params: Ext.apply(this.getBaseParams(), {
                    additional: ["support_filter", "account_meta", "from_cache"]
                }),
                callback: function(g, e, f) {
                    if (!g) {
                        this.clearStatusBusy();
                        this.getMsgBox().alert(a("app", "backup_explorer"), c(e.code), this.close, this);
                        return
                    }
                    this.data_enc = e.data_enc;
                    this.hostname = e.host_name;
                    this.uni_key = e.uni_key;
                    this.support_filter = e.support_filter;
                    this.accountMeta = SYNO.SDS.Backup.Client.Common.Utils.createAccountMeta();
                    if (!Ext.isEmpty(e.account_meta)) {
                        this.accountMeta.setData(e.account_meta)
                    }
                    this.clearStatusBusy();
                    if (this.data_enc && !this.sess_id) {
                        this.launchPasswordWindow(this.updateView, this.setSession, Ext.apply(f, this.getBaseParams()))
                    } else {
                        this.updateView()
                    }
                }
            });
            this.callParent(arguments)
        },
        launchPasswordWindow: function(g, f, e) {
            var d = new SYNO.SDS.Backup.Client.Common.Password.Window({
                owner: this,
                verify_params: e,
                setter: Ext.createDelegate(f, this),
                callback: Ext.createDelegate(g, this)
            });
            d.open()
        },
        setSession: function(d) {
            this.sess_id = d.sess_id;
            this.sess_key = d.sess_key
        },
        updateView: function() {
            if (this.support_restore) {
                this.gridMenu.get(1).show();
                this.menuToolbar.get(1).show()
            } else {
                this.gridMenu.get(1).hide();
                this.menuToolbar.get(1).hide()
            }
            if (this.hostname) {
                this.treePanel.getRootNode().setText(this.hostname)
            }
            if (this.support_filter) {
                this.pathBarMargin = 295;
                this.pathBar.setWidth(this.width - this.pathBarMargin);
                this.searchField.show()
            } else {
                this.searchField.hide();
                this.pathBarMargin = 101;
                this.pathBar.setWidth(this.width - this.pathBarMargin)
            }
            this.timeline.setAccountMeta(this.accountMeta);
            this.timeline.load(this.defaultVersion)
        },
        getTip: function(f) {
            var d = document.createElement("unused_A");
            var g = document.createElement("unused_B");
            d.appendChild(g);
            var e = SYNO.ux.AddTip(g, f);
            e.setAttribute("style", "position: absolute; margin-top:0px");
            return e.outerHTML
        },
        initComponent: function() {
            this.pathBarMargin = 101;
            this.pathBar = new SYNO.SDS.Backup.Client.Explore.PathBar({
                width: this.width - this.pathBarMargin
            });
            var d = [{
                xtype: "syno_button",
                iconCls: "syno-sds-backup-filebrowser-tbar-back",
                disabled: true,
                listeners: {
                    click: {
                        fn: function() {
                            this.pathBar.moveToPrevPath()
                        },
                        scope: this
                    }
                }
            }, {
                xtype: "syno_button",
                iconCls: "syno-sds-backup-filebrowser-tbar-next",
                disabled: true,
                listeners: {
                    click: {
                        fn: function() {
                            this.pathBar.moveToNextPath()
                        },
                        scope: this
                    }
                }
            }, this.pathBar];
            this.filterPanel = new SYNO.SDS.Backup.Client.Explore.Filter.FormPanel({
                cls: "syno-backup-client-common-adv-search-panel",
                renderTo: Ext.getBody(),
                shadow: false,
                hidden: true,
                owner: this
            });
            d.push("->");
            this.searchField = new SYNO.SDS.Backup.Client.Explore.AdvancedSearchField({
                owner: this,
                width: 188,
                searchPanel: this.filterPanel,
                hidden: true
            });
            d.push(this.searchField);
            this.pathToolbar = new SYNO.ux.Toolbar({
                cls: "syno-sds-backup-filebrowser-tbar",
                items: d
            });
            this.menuToolbar = new SYNO.ux.Toolbar({
                items: [{
                    xtype: "syno_button",
                    itemId: "btn_copy",
                    text: a("explorer", "copy_to") + " ...",
                    disabled: true,
                    listeners: {
                        scope: this,
                        click: this.launchPathSelector
                    }
                }, {
                    xtype: "syno_button",
                    itemId: "btn_restore",
                    text: a("explorer", "restore"),
                    disabled: true,
                    hidden: true,
                    listeners: {
                        scope: this,
                        click: this.onRestoreApply
                    }
                }, {
                    xtype: "syno_button",
                    itemId: "btn_download",
                    text: a("explorer", "download"),
                    disabled: true,
                    listeners: {
                        scope: this,
                        click: this.onDownloadApply
                    }
                }]
            });
            this.tbar = new Ext.Container({
                layout: {
                    type: "vbox",
                    pack: "start",
                    align: "stretch"
                },
                height: 36 * 2,
                defaults: {
                    flex: 1
                },
                items: [this.pathToolbar, this.menuToolbar]
            });
            this.callParent(arguments);
            if (!this.treeloader) {
                this.treeloader = new SYNO.SDS.Backup.Client.Explore.TreeLoader({
                    sendWebAPI: this.sendWebAPI.createDelegate(this),
                    parseWebApiResponse: (function(f, e) {
                        if ((f && !f.isRoot) && e.length > this.treePanel.folderDisplayLimit) {
                            this.fireEvent("treediscarddata", f);
                            return e.slice(0, this.treePanel.folderDisplayLimit)
                        }
                        return e
                    }).createDelegate(this),
                    webapi: {
                        api: "SYNO.SDS.Backup.Client.Explore.Folder",
                        method: "list",
                        version: 1
                    },
                    baseParams: Ext.apply(this.getBaseParams(), {
                        limit: this.folderDisplayLimit + 1
                    }),
                    createNodeFn: function(e) {
                        e.text = e.name;
                        e.id = e.path
                    },
                    createNodeScope: this,
                    owner: this,
                    listeners: {
                        scope: this,
                        beforeload: function(e, f) {
                            if (this.badShares && f.id in this.badShares) {
                                return false
                            }
                            if (SYNO.SDS.Backup.Client.Common.Utils.isABBDataFolder("/" + f.id)) {
                                return false
                            }
                        },
                        loadexception: function(f, g, e) {
                            this.getMsgBox().alert(a("app", "backup_explorer"), c(e.code), function() {
                                if (SYNO.SDS.Backup.Explore.ERR_SESSION_EXPIRED === e.code) {
                                    this.doSessionExpired()
                                }
                                if (SYNO.SDS.Backup.Explore.ERR_PROTOCOL_VERSION_CLIENT_TOO_OLD === e.code || SYNO.SDS.Backup.Explore.ERR_PROTOCOL_VERSION_SERVER_TOO_OLD === e.code) {
                                    this.close()
                                }
                            }, this)
                        }
                    }
                })
            }
            this.treePanel = new SYNO.SDS.Backup.Client.Explore.BasicTreePanel({
                loader: this.treeloader,
                root: new Ext.tree.AsyncTreeNode({
                    name: "@pathRoot",
                    id: "@pathRoot",
                    path: "@pathRoot",
                    text: this.hostname,
                    cls: "root_node",
                    expanded: true,
                    disabled: true,
                    loaded: true
                }),
                autoFlexcroll: true,
                region: "west",
                cls: "syno-sds-backup-filebrowser-treepanel",
                split: true,
                width: 200,
                minWidth: 150,
                maxWidth: 500,
                folderDisplayLimit: this.folderDisplayLimit
            });
            if (!this.gridStore) {
                this.gridStore = new Ext.data.JsonStore({
                    proxy: new SYNO.API.Proxy({
                        api: "SYNO.SDS.Backup.Client.Explore.File",
                        method: "list",
                        version: 1
                    }),
                    totalProperty: "total",
                    root: "files",
                    fields: ["name", "path", "size", "mtime", "type", "is_bad"],
                    baseParams: this.getBaseParams(),
                    hasMultiSort: true,
                    multiSortInfo: {
                        sorters: [{
                            field: "type",
                            direction: "DESC"
                        }, {
                            field: "name",
                            direction: "ASC"
                        }],
                        direction: "ASC"
                    },
                    listeners: {
                        scope: this,
                        beforeload: function(e, f) {
                            var g = this.getShareNode();
                            if (g && g.attributes.is_bad) {
                                this.gridPanel.getStore().removeAll();
                                this.gridPanel.bwrap.mask(a("app", "broken_share"), "syno-ux-mask-info");
                                this.searchField.disable();
                                return false
                            }
                            if (SYNO.SDS.Backup.Client.Common.Utils.isABBDataFolder("/" + f.params.node)) {
                                this.gridPanel.getStore().removeAll();
                                this.gridPanel.bwrap.mask(a("app", "ABB_no_restore_part_data"), "syno-ux-mask-info");
                                this.searchField.disable();
                                return false
                            }
                            this.searchField.enable();
                            Ext.apply(f.params, this.getBaseParams());
                            return f
                        },
                        load: function(f, e) {
                            if (0 === e.length && this.isFilterCondSet()) {
                                this.gridPanel.bwrap.mask(_T("search", "no_search_result"));
                                this.gridPanel.getBottomToolbar().updateInfo();
                                return false
                            }
                            if (true === this.data_enc) {
                                this.gridPanelPagingBar.displayItem.getEl().setWidth("auto");
                                var g = 100000;
                                if (this.gridStore.getTotalCount() >= g) {
                                    this.gridPanelPagingBar.displayMsg = this.displayMsgWithTip;
                                    this.gridPanelPagingBar.updateInfo();
                                    this.gridPanelPagingBar.displayItem.getEl().setWidth(this.gridPanelPagingBar.displayItem.getWidth() + 28)
                                } else {
                                    this.gridPanelPagingBar.displayMsg = this.displayMsg;
                                    this.gridPanelPagingBar.updateInfo()
                                }
                            }
                        },
                        exception: function(h, i, j, g, f, e) {
                            if (SYNO.SDS.Backup.Explore.ERR_SHARE_NOT_EXIST === f.code) {
                                this.gridPanel.getStore().removeAll();
                                this.gridPanel.bwrap.mask(a("explorer", "no_folder"), "syno-ux-mask-info");
                                this.searchField.disable();
                                return false
                            }
                            this.getMsgBox().alert(a("app", "backup_explorer"), c(f.code), function() {
                                if (SYNO.SDS.Backup.Explore.ERR_SESSION_EXPIRED === f.code) {
                                    this.doSessionExpired()
                                }
                                if (SYNO.SDS.Backup.Explore.ERR_PROTOCOL_VERSION_CLIENT_TOO_OLD === f.code || SYNO.SDS.Backup.Explore.ERR_PROTOCOL_VERSION_SERVER_TOO_OLD === f.code) {
                                    this.close()
                                }
                            }, this)
                        }
                    }
                })
            }
            this.gridMenu = new SYNO.ux.Menu({
                cls: "syno-backup-client-explore syno-sds-backup-filebrowser-menu",
                items: [{
                    text: a("explorer", "copy_to") + " ...",
                    iconCls: "syno-sds-backup-filebrowser-copy-icon",
                    itemId: "menu_copy",
                    disabled: true,
                    listeners: {
                        scope: this,
                        click: this.launchPathSelector
                    }
                }, {
                    text: a("explorer", "restore"),
                    iconCls: "syno-sds-backup-filebrowser-restore-icon",
                    itemId: "menu_restore",
                    disabled: true,
                    hidden: true,
                    listeners: {
                        scope: this,
                        click: this.onRestoreApply
                    }
                }, {
                    text: a("explorer", "download"),
                    iconCls: "syno-sds-backup-filebrowser-download-icon",
                    itemId: "menu_download",
                    disabled: true,
                    listeners: {
                        scope: this,
                        click: this.onDownloadApply
                    }
                }]
            });
            this.gridPanelPagingBar = null;
            this.gridPanelPagingBar = new SYNO.ux.PagingToolbar({
                store: this.gridStore,
                pageSize: 1000,
                displayInfo: true,
                showRefreshBtn: false
            });
            this.displayMsg = this.gridPanelPagingBar.displayMsg;
            this.displayMsgWithTip = this.gridPanelPagingBar.displayMsg + this.getTip(a("explorer", "unsort_hint"));
            this.gridPanel = new SYNO.ux.GridPanel({
                colModel: new Ext.grid.ColumnModel({
                    columns: [{
                        header: _T("common", "name"),
                        dataIndex: "name",
                        width: 4,
                        renderer: function(i, f, e, l, h, g) {
                            var k = SYNO.SDS.Backup.Explore.htmlEncodeTip(i);
                            if ("Folder" === e.data.type) {
                                var j = "syno-sds-backup-filebrowser-folder-icon";
                                if (e.get("is_bad")) {
                                    k = "(" + a("explorer", "broken_folder") + ")" + k;
                                    j = "syno-sds-backup-filebrowser-broken-folder-icon"
                                }
                                return '<div class="' + j + '" ext:qtip="' + k + '">&nbsp;' + Ext.util.Format.htmlEncode(i) + "</div>"
                            } else {
                                if (e.get("is_bad")) {
                                    k = "(" + a("explorer", "broken_file") + ")" + k
                                }
                                return '<div class="syno-sds-backup-filebrowser-file-icon" ext:qtip="' + k + '">&nbsp;' + Ext.util.Format.htmlEncode(i) + "</div>"
                            }
                        }
                    }, {
                        header: _T("common", "size"),
                        dataIndex: "size",
                        width: 1,
                        renderer: function(i, f, e, j, h, g) {
                            return SYNO.SDS.Backup.Explore.ConverSize(i, 2)
                        }
                    }, {
                        header: a("explorer", "file_type"),
                        width: 1,
                        dataIndex: "type"
                    }, {
                        header: a("explorer", "modified_date"),
                        dataIndex: "mtime",
                        width: 2,
                        renderer: function(i, f, e, k, h, g) {
                            var j = new Date(i * 1000);
                            return SYNO.SDS.Backup.Explore.DateTimeFormatter(j, {
                                type: "datetimesec"
                            })
                        }
                    }]
                }),
                viewConfig: {
                    hideSortIcons: true,
                    getRowClass: function(e, h, g, f) {
                        if (e.get("is_bad") && "Folder" !== e.get("type")) {
                            return "disabled-file"
                        } else {
                            return ""
                        }
                    }
                },
                store: this.gridStore,
                sm: new Ext.grid.RowSelectionModel({
                    singleSelect: false,
                    listeners: {
                        beforerowselect: {
                            fn: function(f, h, g, e) {
                                if (e.get("is_bad") && "Folder" !== e.get("type")) {
                                    return false
                                }
                                return true
                            }
                        }
                    }
                }),
                keys: [{
                    key: 65,
                    ctrl: true,
                    scope: this,
                    handler: function() {
                        this.gridPanel.getSelectionModel().selectAll()
                    }
                }],
                loadMask: true,
                cls: "syno-sds-backup-filebrowser-gridpanel",
                collapsible: false,
                region: "center",
                bbar: this.gridPanelPagingBar,
                margins: "5 0 0 0",
                listeners: {
                    rowcontextmenu: {
                        fn: function(f, i, g) {
                            var e = f.getStore().getAt(i);
                            if (!e.get("is_bad") || "Folder" === e.get("type")) {
                                this.gridMenu.showAt(g.getXY())
                            }
                            var h = f.getSelectionModel();
                            if (!h.isSelected(i)) {
                                h.selectRow(i)
                            }
                        },
                        scope: this
                    }
                }
            });
            this.timeline = new SYNO.SDS.Backup.Client.Explore.TimeLine({
                owner: this,
                getBaseParams: Ext.createDelegate(this.getBaseParams, this),
                split: false,
                region: "south",
                height: 112
            });
            this.add(new SYNO.ux.Panel({
                layout: "border",
                border: false,
                cls: "syno-sds-backup-filebrowser-mainpanel",
                viewConfig: {
                    forceFit: true
                },
                defaults: {
                    fit: true
                },
                items: [this.treePanel, this.gridPanel, this.timeline]
            }))
        },
        initEvents: function() {
            this.callParent(arguments);
            this.mon(SYNO.SDS.StatusNotifier, "thirdpartychanged", this.onHyperBackupUpgrade, this);
            this.mon(this, "resize", function(f, e, d) {
                this.pathBar.setWidth(e - this.pathBarMargin)
            }, this);
            this.mon(this, "afterrender", function() {
                if (this.isDownloading) {
                    this.launchProgressPanel()
                }
            }, this);
            this.mon(this.treePanel.getSelectionModel(), "selectionchange", function(e, d) {
                if (d) {
                    this.pathBar.setPath(d.attributes.path, false, false);
                    this.updateGridPanel()
                }
            }, this);
            this.mon(this.gridPanel, "rowdblclick", function(f, e, g) {
                var d = f.getStore().getAt(e);
                if ("Folder" === d.get("type")) {
                    this.pathBar.setPath(d.get("path"), false, true)
                } else {
                    if ("File" === d.get("type")) {
                        if (!d.get("is_bad")) {
                            this.onDownloadApply()
                        }
                    }
                }
            }, this);
            this.mon(this.gridPanel.getSelectionModel(), "selectionchange", function(i) {
                var d = i.getSelections();
                if (d.length === 0) {
                    this.menuToolbar.getComponent("btn_copy").disable();
                    this.menuToolbar.getComponent("btn_restore").disable();
                    this.menuToolbar.getComponent("btn_download").disable();
                    this.gridMenu.getComponent("menu_copy").disable();
                    this.gridMenu.getComponent("menu_restore").disable();
                    this.gridMenu.getComponent("menu_download").disable();
                    return
                }
                var h = true;
                var g = true;
                var e = (d.length > 1) ? false : true;
                var f = {
                    checkTypeFile: true,
                    checkIsBadAndType: true
                };
                Ext.each(d, function(j) {
                    if (j.get("type") !== "File") {
                        e = false;
                        this.checkTypeFile = false
                    }
                    if (j.get("is_bad") && "Folder" !== j.get("type")) {
                        h = false;
                        g = false;
                        e = false;
                        this.checkTypeFile = false
                    }
                    if (this.checkTypeFile === false && this.checkIsBadAndType === false) {
                        return false
                    }
                }, f);
                if (h) {
                    this.menuToolbar.getComponent("btn_copy").enable();
                    this.menuToolbar.getComponent("btn_restore").enable()
                }
                if (g) {
                    this.gridMenu.getComponent("menu_copy").enable();
                    this.gridMenu.getComponent("menu_restore").enable()
                }
                if (e) {
                    this.menuToolbar.getComponent("btn_download").enable();
                    this.gridMenu.getComponent("menu_download").enable()
                } else {
                    this.menuToolbar.getComponent("btn_download").disable();
                    this.gridMenu.getComponent("menu_download").disable()
                }
            }, this);
            this.mon(this.pathBar, "updatepath", this.onPathBarUpdate, this);
            this.mon(this.timeline, "select", this.onTimelineSelect, this);
            this.mon(this.treePanel.getLoader(), "load", this.onTreeLoad, this);
            this.mon(this, "treediscarddata", this.onTreeDiscardData, this);
            if (this.filterPanel) {
                this.mon(this.filterPanel, "filter", this.updateGridPanel, this)
            }
        },
        onTreeDiscardData: function(e) {
            if (-1 !== this.warnedNodes.indexOf(e.attributes.id)) {
                return
            }
            this.warnedNodes.push(e.attributes.id);
            var d = String.format(a("app", "subfolder_exceed_limit"), e.attributes.path, this.treePanel.folderDisplayLimit);
            this.getMsgBox().alert(a("app", "backup_explorer"), d)
        },
        isFilterCondSet: function() {
            return (this.filterPanel && this.filterPanel.isCondSet())
        },
        getBaseParams: function() {
            var d = {};
            if (this.taskId) {
                Ext.apply(d, {
                    task_id: this.taskId
                })
            } else {
                if (this.repoId) {
                    Ext.apply(d, {
                        repo_id: this.repoId,
                        target_id: this.targetId
                    })
                } else {
                    Ext.apply(d, {
                        target_type: this.targetType,
                        transfer_type: this.transferType,
                        abs_path: this.repoPath,
                        target_id: this.targetId
                    })
                }
            }
            if (this.versionId) {
                Ext.apply(d, {
                    version_id: this.versionId
                })
            }
            if (this.pathBar && this.pathBar.getRelatedPath()) {
                Ext.apply(d, {
                    node: this.pathBar.getRelatedPath()
                })
            }
            if (this.filterPanel && this.filterPanel.getParams()) {
                Ext.apply(d, this.filterPanel.getParams())
            }
            if (this.data_enc) {
                Ext.apply(d, {
                    sess_id: this.sess_id,
                    sess_key: this.sess_key
                });
                if (!this.taskId) {
                    Ext.apply(d, {
                        data_enc: this.data_enc,
                        uni_key: this.uni_key
                    })
                }
            }
            if (this.backend) {
                Ext.apply(d, {
                    backend: this.backend
                })
            }
            return d
        },
        onHyperBackupUpgrade: function(d, e) {
            if ("HyperBackup" === d && ("upgrade" === e || "install" === e)) {
                this.close()
            }
        },
        onTimelineSelect: function() {
            this.versionId = this.timeline.getVersionId();
            this.updateTreePanel()
        },
        onPathBarUpdate: function(e, d) {
            if (!this.pathBar.getPrevPath()) {
                this.pathToolbar.items.items[0].disable()
            } else {
                this.pathToolbar.items.items[0].enable()
            }
            if (!this.pathBar.getNextPath()) {
                this.pathToolbar.items.items[1].disable()
            } else {
                this.pathToolbar.items.items[1].enable()
            }
            this.treePanel.selectPath(this.pathBar.getPath(), "name", Ext.createDelegate(this.onTreeSelect, this, [d], true))
        },
        onTreeLoad: function(d, h, e, f) {
            var j = this.pathBar.getPath();
            if ((!j || "/@pathRoot" === j) && 0 < e.length) {
                j = this.treePanel.getNodeById(e[0].id).getPath();
                this.pathBar.setPath(j, false, f)
            }
            if (h.isRoot) {
                this.badShares = {};
                for (var g = 0; g < e.length; g++) {
                    if (e[g].is_bad) {
                        this.badShares[e[g].name] = true
                    }
                }
                this.treePanel.selectPath(j, "name", Ext.createDelegate(this.onTreeSelect, this, [f], true))
            }
        },
        onTreeSelect: function(e, h, f) {
            if (!e) {
                var g = this.treePanel.getSelectionModel().getSelectedNode();
                if (g && this.badShares && g.id.split("/")[0] in this.badShares) {
                    this.gridPanel.getStore().removeAll();
                    this.gridPanel.bwrap.mask(a("app", "broken_share"), "syno-ux-mask-info");
                    this.searchField.disable();
                    return
                }
                var d = function(i) {
                    return i && -1 !== i.indexOf("/")
                };
                if (true === f && d(this.pathBar.getRelatedPath())) {
                    this.treePanel.getSelectionModel().clearSelections();
                    this.updateGridPanel();
                    return
                }
                this.gridPanel.getStore().removeAll();
                this.gridPanel.bwrap.mask(a("explorer", "no_folder"), "syno-ux-mask-info");
                this.searchField.disable()
            } else {
                this.searchField.enable()
            }
        },
        onPathSelectorApply: function(e, h) {
            var i = this.gridPanel.getSelectionModel();
            var g = i.getSelections();
            var d = [];
            g.forEach(function(j) {
                d.push(j.data.path)
            });
            var f = {
                action: "copy",
                source_path: d
            };
            Ext.apply(f, this.getBaseParams());
            Ext.apply(f, h);
            this.setStatusBusy();
            this.sendWebAPI({
                api: "SYNO.SDS.Backup.Client.Explore.File",
                version: 1,
                method: "copy",
                params: f,
                scope: this,
                callback: function(l, j, k) {
                    this.clearStatusBusy();
                    if (!l) {
                        this.getMsgBox().alert(a("app", "backup_explorer"), b(j), function() {
                            if (SYNO.SDS.Backup.Explore.ERR_SESSION_EXPIRED === j.code) {
                                this.doSessionExpired()
                            }
                            if (SYNO.SDS.Backup.Explore.ERR_PROTOCOL_VERSION_CLIENT_TOO_OLD === j.code || SYNO.SDS.Backup.Explore.ERR_PROTOCOL_VERSION_SERVER_TOO_OLD === j.code) {
                                this.close()
                            }
                        }, this);
                        return
                    }
                    this.launchProgressPanel()
                }
            })
        },
        onDownloadApply: function() {
            var g = this.gridPanel.getSelectionModel();
            if (!g.getSelected()) {
                return
            }
            if (this.isPreparingDownload()) {
                this.getMsgBox().alert(a("app", "backup_explorer"), a("app", "wait_another_file_downloaded"));
                return
            }
            var e = g.getSelected().data.path;
            var d = new Date().getTime() + Math.random().toString(36);
            var f = Ext.apply({
                source_path: e,
                support_utf8_name: Ext.isChrome || Ext.isGecko || Ext.isSafari,
                download_id: d
            }, this.getBaseParams());
            this.findAppWindow().downloadWebAPI({
                filename: e.replace(/^.*\//, ""),
                webapi: {
                    api: "SYNO.SDS.Backup.Client.Explore.File",
                    version: 1,
                    method: "download",
                    params: f
                },
                timeout: 3600000,
                scope: this,
                callback: function(j, i, k, h) {
                    if (!k && h) {
                        this.getMsgBox().alert(a("app", "backup_explorer"), c(h.code), function() {
                            if (SYNO.SDS.Backup.Explore.ERR_SESSION_EXPIRED === h.code) {
                                this.doSessionExpired()
                            }
                            if (SYNO.SDS.Backup.Explore.ERR_PROTOCOL_VERSION_CLIENT_TOO_OLD === h.code || SYNO.SDS.Backup.Explore.ERR_PROTOCOL_VERSION_SERVER_TOO_OLD === h.code) {
                                this.close()
                            }
                        }, this)
                    }
                }
            });
            setTimeout((function() {
                this.launchProgressPanel(d)
            }).createDelegate(this), 1000)
        },
        getShareNode: function() {
            var e = this.pathBar.getRelatedPath();
            var d = -1;
            if (-1 === (d = e.indexOf("/"))) {
                return this.treePanel.getNodeById(e)
            }
            return this.treePanel.getNodeById(e.substr(0, d))
        },
        onRestoreApply: function() {
            var e = a("explorer", "restore_overwrite_hint");
            var d = this.getShareNode();
            if (d && d.attributes.restore_unsafe_warn) {
                e = a("error", "restore_file_not_safe") + "<br/>" + e
            }
            this.getMsgBox().confirm(a("app", "backup_explorer"), e, function(g) {
                if ("yes" === g) {
                    var j = this.gridPanel.getSelectionModel();
                    var i = j.getSelections();
                    var f = [];
                    i.forEach(function(k) {
                        f.push(k.data.path)
                    });
                    var h = {
                        action: "restore",
                        overwrite: true,
                        source_path: f,
                        dest_path: j.getSelected().data.path
                    };
                    Ext.apply(h, this.getBaseParams());
                    this.setStatusBusy();
                    this.sendWebAPI({
                        api: "SYNO.SDS.Backup.Client.Explore.File",
                        version: 1,
                        method: "restore",
                        params: h,
                        scope: this,
                        callback: function(n, k, l) {
                            this.clearStatusBusy();
                            if (!n) {
                                var m = b(k);
                                if (k.code == SYNO.SDS.Backup.Explore.ERR_SHARE_READ_ONLY) {
                                    m = String.format(m, SYNO.SDS.Backup.getReadOnlyOwnerString(k.errors.read_only_owner))
                                }
                                this.getMsgBox().alert(a("app", "backup_explorer"), m, function() {
                                    if (SYNO.SDS.Backup.Explore.ERR_SESSION_EXPIRED === k.code) {
                                        this.doSessionExpired()
                                    }
                                    if (SYNO.SDS.Backup.Explore.ERR_PROTOCOL_VERSION_CLIENT_TOO_OLD === k.code || SYNO.SDS.Backup.Explore.ERR_PROTOCOL_VERSION_SERVER_TOO_OLD === k.code) {
                                        this.close()
                                    }
                                }, this);
                                return
                            }
                            this.launchProgressPanel()
                        }
                    })
                }
            }, this)
        },
        mask: function(d, f, e) {
            if (!f) {
                f = _T("common", "loading")
            }
            if (!e) {
                e = "x-mask-loading"
            }
            this.callParent([d, f, e])
        },
        launchPathSelector: function() {
            var d = new SYNO.SDS.Backup.Client.Explore.PathSelector.Window({
                title: a("explorer", "copy_to") + " ... - " + a("explorer", "select_path"),
                bodyStyle: "padding-right: 20px; padding-left: 20px;",
                width: 480,
                height: 500,
                layout: "fit",
                minWidth: 480,
                minHeight: 500,
                cls: "syno-backup-client-explore",
                owner: this
            });
            d.open();
            this.mon(d, "apply", this.onPathSelectorApply, this, {
                single: true
            })
        },
        launchProgressPanel: function(d) {
            SYNO.SDS.AppLaunch("SYNO.SDS.Backup.Client.JobTray.AppInstance", {}, false, function() {
                var e = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.Backup.Client.JobTray.AppInstance")[0];
                if (d) {
                    e.addDownloadId(d)
                }
                e.start({
                    launcher: this.launcher,
                    backend: this.backend
                })
            }, this)
        },
        isPreparingDownload: function() {
            var d = SYNO.SDS.AppMgr.getByAppName("SYNO.SDS.Backup.Client.JobTray.AppInstance")[0];
            if (!d) {
                return false
            }
            return d.isPreparingDownload()
        },
        updateTreePanel: function() {
            var e = this.treePanel.getRootNode();
            var d = this.treePanel.getLoader();
            this.treePanel.getEl().mask();
            d.baseParams = Ext.apply(this.getBaseParams(), {
                limit: this.treePanel.folderDisplayLimit + 1
            });
            var f = Ext.apply({}, {
                params: Ext.apply({
                    preload: this.pathBar.getPath().replace(/^\/@pathRoot\//, "")
                }, d.getParams(e)),
                argument: {
                    callback: undefined,
                    node: e,
                    scope: undefined
                },
                callback: function(l, g, k, i) {
                    var h = i.argument,
                        j = h.node;
                    this.treePanel.getEl().unmask();
                    while (j.firstChild) {
                        j.removeChild(j.firstChild)
                    }
                    d.handleNodeData(j, g)
                },
                scope: this
            }, d.webapi);
            this.sendWebAPI(f)
        },
        updateGridPanel: function() {
            var d = this.gridPanel.getStore();
            var e = this.getBaseParams();
            if (this.support_filter) {
                this.searchField.setValue(e.filter_keyword);
                this.searchField.fireEvent("keyup", this.searchField)
            }
            d.load({
                params: e
            })
        },
        doSessionExpired: function() {
            if (!this.launchInstance) {
                return
            }
            if (this.launchInstance.clearCurTaskSession) {
                this.launchInstance.clearCurTaskSession()
            } else {
                if (this.launchInstance.owner && this.launchInstance.owner.clearCurTaskSession) {
                    this.launchInstance.owner.clearCurTaskSession();
                    this.launchInstance.close()
                }
            }
            this.close()
        }
    })
})();
Ext.namespace("SYNO.SDS.Backup.Explore");
(function(b) {
    var a = {
        ERR_DISALLOW_DEMOSITE: [116],
        ERR_PARAM: [4400],
        ERR_INTERNAL_ERROR: [4401],
        ERR_CLIENT_NO_SPACE: [4402],
        ERR_SERVER_NO_SPACE: [4403],
        ERR_CLIENT_NO_QUOTA: [4404],
        ERR_SERVER_NO_QUOTA: [4405],
        ERR_NOT_OWNER: [4406],
        ERR_SNAPSHOT_RESTORING: [4407],
        ERR_RESTORING: [4408],
        ERR_BACKING_UP_RESTORING: [4409],
        ERR_CLIENT_PERM_DENIED: [4410],
        ERR_SERVER_PERM_DENIED: [4411],
        ERR_PORT_NOT_VALID: [4412],
        ERR_NAME_NOT_VALID: [4413],
        ERR_CONFIG_OPERATE_ADMIN: [4416],
        ERR_SHARE_READ_ONLY: [4417],
        ERR_SERVICE_NO_VOLUME: [4418],
        ERR_SERVICE_NO_SHARE: [4419],
        ERR_VOLUME_NOT_EXIST: [4420],
        ERR_VOLUME_FS_NOT_SUPPORT: [4422],
        ERR_SHARE_NOT_EXIST: [4423],
        ERR_SHARE_ENCRYPTION: [4425],
        ERR_CONFIG_VERSION_WRONG: [4428],
        ERR_CONFIG_VERSION_FUTURE: [4429],
        ERR_OFFLINE: [4430],
        ERR_RESTORE_VOLUME_BUILDING: [4431],
        ERR_PROTOCOL_VERSION_CLIENT_TOO_OLD: [4432],
        ERR_PROTOCOL_VERSION_SERVER_TOO_OLD: [4433],
        ERR_BAD_ADDRESS: [4434],
        ERR_CONFIG_RESTORING: [4435],
        ERR_CONFIG_NO_SPACE: [4436],
        ERR_CONFIG_WRONG_FORMAT: [4437],
        ERR_CONFIG_PORT_CONFLICT: [4438],
        ERR_CONFIG_SERVICE_FAIL: [4439],
        ERR_NO_RESPONSE: [4440],
        ERR_CONNECTION_BLOCKED: [4441],
        ERR_SERVICE_DISABLE: [4442],
        ERR_SSH_FAIL: [4443],
        ERR_AUTH_FAIL: [4444],
        ERR_AUTH_DENIED: [4445],
        ERR_UNSTABLE_NETWORK: [4446],
        ERR_SSL_NOT_SUPPORT: [4447],
        ERR_SSL_VERIFY_FAIL: [4448],
        ERR_TIME_SKEWED: [4449],
        ERR_REPOSITORY_NOT_EXIST: [4455],
        ERR_REPOSITORY_EXIST: [4456],
        ERR_REPOSITORY_BUSY: [4457],
        ERR_REPOSITORY_PERM_DENIED: [4459],
        ERR_TARGET_NOT_EXIST: [4460],
        ERR_TARGET_EXIST: [4461],
        ERR_TARGET_BUSY: [4462],
        ERR_TARGET_BUSY_ROLLBACK: [4463],
        ERR_TARGET_BUSY_BACKUP: [4464],
        ERR_TARGET_BUSY_RESTORE: [4465],
        ERR_TARGET_BUSY_CHECKING: [4466],
        ERR_TARGET_BROKEN: [4467],
        ERR_TARGET_NEED_ROLLBACK: [4468],
        ERR_TARGET_PERM_DENIED: [4471],
        ERR_VERSION_NOT_EXIST: [4472],
        ERR_VERSION_LOCKED: [4475],
        ERR_NO_AVAILABLE_VERSION: [4476],
        ERR_USER_EXCEED_MAX: [4478],
        ERR_GROUP_EXCEED_MAX: [4479],
        ERR_APP_VERSION_INVALID: [4480],
        ERR_APP_MYSQL_PWD_WRONG: [4482],
        ERR_APP_SURVEILLANCE_ENABLE: [4483],
        ERR_APP_MYSQL_ENABLE: [4484],
        ERR_APP_MYSQL_VOLUME_CRASH: [4485],
        ERR_APP_VOLUME: [4486],
        ERR_APP_OCCUPIED: [4487],
        ERR_APP_NO_SPACE: [4488],
        ERR_APP_NETWORK: [4489],
        CUSTOMIZED_WEBAPI_ERROR_CODE: [4490],
        CUSTOMIZED_WEBAPI_ERROR_CODE_CONTAINER_INVALID_NAME: [4491],
        CUSTOMIZED_WEBAPI_ERROR_CODE_CONTAINER_EXIST: [4492],
        CUSTOMIZED_WEBAPI_ERROR_CODE_CONTAINER_TOO_MANY: [4493],
        ERR_BACKUP_CONF_FAIL: [4494],
        ERR_BACKUP_APP_FAIL: [4495],
        ERR_ENCRYPT_VERIFY_FAIL: [4496],
        ERR_SHARE_ENCRYPTED: [4497],
        ERR_SESSION_EXPIRED: [4498],
        ERR_SERVER_NOT_READY: [4499],
        ERR_CANCEL_JOB_NOT_EXIST: [4500],
        ERR_OBJECT_IN_GLACIER: [4513]
    };
    Ext.iterate(a, function(c, d) {
        b[c] = d[0]
    })
})(SYNO.SDS.Backup.Explore);
(function() {
    var a = SYNO.SDS.Backup.Client.Explore.Utils.GetString;
    Ext.define("SYNO.SDS.Backup.Client.Explore.Filter.FormPanel", {
        extend: "SYNO.ux.FormPanel",
        constructor: function(b) {
            this.dateType = {
                custom: 1,
                today: 2,
                yesterday: 4,
                lastweek: 8,
                lastmonth: 16
            };
            this.dataRange = [
                [this.dateType.custom, a("app", "log_date_custom")],
                [this.dateType.today, a("app", "log_date_today")],
                [this.dateType.yesterday, a("app", "log_date_yesterday")],
                [this.dateType.lastweek, a("app", "log_date_lastweek")],
                [this.dateType.lastmonth, a("app", "log_date_lastmonth")]
            ];
            this.defaultAnimation = ["#000", 1, {
                duration: 0.35
            }];
            Ext.apply(this, b || {});
            var c = this.fillConfig(b);
            this.callParent([c]);
            this.defineBehaviors()
        },
        initComponent: function() {
            this.callParent(arguments);
            this.addEvents("filter")
        },
        fillConfig: function(d) {
            var b, f, c, h, i;
            var e = [];
            b = this.createKeyword();
            f = this.createFileType();
            c = this.createFileSize();
            h = this.createFriendlyDate();
            i = this.createCustDate();
            e.push(b);
            e.push(f);
            e.push(c);
            e.push(h);
            e.push(i);
            e.push({
                xtype: "toolbar",
                border: false,
                itemId: "btns",
                toolbarCls: "search-panel-fbar-btnPanel",
                items: [{
                    xtype: "tbfill"
                }, {
                    xtype: "syno_button",
                    minWidth: 80,
                    text: _T("common", "reset"),
                    handler: this.onReset,
                    scope: this
                }, {
                    xtype: "syno_button",
                    btnStyle: "blue",
                    style: "margin-right: 10px",
                    text: a("app", "log_search"),
                    itemId: "btn_search",
                    handler: this.onSearch,
                    scope: this
                }]
            });
            var g = {
                width: 368,
                heigh: 480,
                floating: true,
                labelAlign: "left",
                trackResetOnLoad: true,
                waitMsgTarget: true,
                border: true,
                bodyStyle: "padding: 20px; padding-top: 0px; font-size: 24px;",
                autoFlexcroll: false,
                defaults: {
                    hideLabel: true,
                    anchor: "100%"
                },
                items: e,
                listeners: {
                    actionfailed: {
                        fn: function() {
                            this.form.reset()
                        },
                        scope: this
                    },
                    beforeshow: {
                        fn: function() {
                            this.doLayout()
                        },
                        single: true
                    },
                    show: {
                        fn: this.doLayout,
                        single: true
                    }
                },
                keys: [{
                    key: [10, 13],
                    fn: function() {
                        if (!this.isVisible()) {
                            return
                        }
                        if (!this.btnSearch.hidden && !this.btnSearch.disabled) {
                            this.onSearch()
                        }
                    },
                    scope: this
                }]
            };
            return g
        },
        createTpl: function() {
            return new Ext.XTemplate('<tpl for=".">', '<div class="x-combo-list-item" ext:qtip="{displayText:htmlEncode}">', "{displayText:htmlEncode}", "</div>", "</tpl>")
        },
        createKeyword: function() {
            return [{
                xtype: "syno_displayfield",
                value: a("app", "log_keyword") + _T("common", "colon"),
                flex: 1
            }, {
                xtype: "syno_textfield",
                msgTarget: "qtip",
                validateOnBlur: true,
                validationEvent: "blur",
                name: "keyword",
                flex: 2,
                vaule: ""
            }]
        },
        createFileType: function() {
            this.FileTypeComboBox = new SYNO.ux.ComboBox({
                mode: "local",
                editable: false,
                name: "fileType",
                tpl: this.createTpl(),
                resizable: true,
                store: this.getFileTypeStore(),
                displayField: "displayText",
                valueField: "value",
                triggerAction: "all",
                lazyRender: true,
                flex: 6,
                value: "any"
            });
            return [{
                xtype: "syno_displayfield",
                value: a("explorer", "file_type") + _T("common", "colon"),
                flex: 1
            }, this.FileTypeComboBox]
        },
        getFileTypeStore: function() {
            return new Ext.data.SimpleStore({
                autoDestroy: true,
                fields: ["value", "displayText"],
                data: [
                    ["any", a("explorer", "any")],
                    ["folder", a("explorer", "any_folder")],
                    ["file", a("explorer", "any_file")]
                ]
            })
        },
        createFileSize: function() {
            this.FileSizeField = new SYNO.ux.CompositeField({
                hideLabel: true,
                defaults: {
                    flex: 1
                },
                defaultMargins: "0 8 0 0",
                items: [{
                    xtype: "syno_combobox",
                    mode: "local",
                    editable: false,
                    name: "fileSizeOption",
                    tpl: this.createTpl(),
                    resizable: true,
                    store: this.getFileSizeStore(),
                    displayField: "displayText",
                    valueField: "value",
                    triggerAction: "all",
                    lazyRender: true,
                    value: "any",
                    listeners: {
                        select: {
                            fn: function(d, c, b) {
                                this.enableDisableItem(c.get("value"), this.form.findField("fileSize"))
                            },
                            scope: this
                        }
                    }
                }, {
                    xtype: "syno_numberfield",
                    name: "fileSize",
                    minValue: 0,
                    maxValue: 4294967296,
                    disabled: true
                }]
            });
            return [{
                xtype: "syno_displayfield",
                value: _T("common", "size") + " (" + _T("common", "size_kb") + ")" + _T("common", "colon"),
                flex: 1
            }, this.FileSizeField]
        },
        getFileSizeStore: function() {
            return new Ext.data.SimpleStore({
                autoDestroy: true,
                fields: ["value", "displayText"],
                data: [
                    ["any", a("explorer", "search_any")],
                    ["equal", a("explorer", "size_equal")],
                    ["greater", a("explorer", "size_greater")],
                    ["less", a("explorer", "size_less")]
                ]
            })
        },
        setDate: function(d, c, b) {
            if (b === true) {
                this.frameAnimation(this.form.findField("searchdatefrom").el, this.defaultAnimation);
                this.frameAnimation(this.form.findField("searchdateto").el, this.defaultAnimation)
            }
            this.form.findField("searchdatefrom").setMaxValue(c);
            this.form.findField("searchdateto").setMinValue(d);
            this.form.findField("searchdatefrom").setValue(d);
            this.form.findField("searchdateto").setValue(c)
        },
        getFromToDate: function(d) {
            var f, e, c = new Date();
            if (d === this.dateType.today) {
                f = c;
                e = c
            } else {
                if (d === this.dateType.yesterday) {
                    f = c.add(Date.DAY, -1);
                    e = f
                } else {
                    if (d === this.dateType.lastweek) {
                        var b = c.getDay();
                        f = c.add(Date.DAY, -7 - b);
                        e = f.add(Date.DAY, 6)
                    } else {
                        if (d === this.dateType.lastmonth) {
                            c = c.add(Date.MONTH, -1);
                            f = c.getFirstDateOfMonth();
                            e = c.getLastDateOfMonth()
                        }
                    }
                }
            }
            return {
                from: f,
                to: e
            }
        },
        friendlyDateSelect: function(d, f, b) {
            var c = f.get("id"),
                e = this.getFromToDate(c);
            this.setDate(e.from, e.to, true)
        },
        getFriendlyDateStore: function() {
            var b = this.dataRange;
            return new Ext.data.ArrayStore({
                autoDestroy: true,
                fields: ["id", "displayText"],
                data: b
            })
        },
        createFriendlyDate: function() {
            this.FriendlyDate = new SYNO.ux.ComboBox({
                mode: "local",
                editable: false,
                name: "dateRange",
                tpl: this.createTpl(),
                resizable: true,
                store: this.getFriendlyDateStore(),
                displayField: "displayText",
                valueField: "id",
                triggerAction: "all",
                lazyRender: true,
                flex: 6,
                value: this.dateType.custom,
                listeners: {
                    scope: this,
                    beforequery: function(b) {
                        delete b.combo.lastQuery
                    },
                    beforeselect: this.friendlyDateSelect
                }
            });
            return [{
                xtype: "syno_displayfield",
                value: a("explorer", "modified_date") + _T("common", "colon"),
                flex: 1
            }, this.FriendlyDate]
        },
        createCustDate: function() {
            var b = {
                name: "searchdatefrom",
                editable: false,
                emptyText: a("app", "log_date_from"),
                value: "",
                listeners: {
                    scope: this,
                    select: function(e, d) {
                        this.form.findField("searchdateto").setMinValue(d)
                    }
                }
            };
            var c = {
                name: "searchdateto",
                editable: false,
                emptyText: a("app", "log_date_to"),
                value: "",
                listeners: {
                    scope: this,
                    select: function(e, d) {
                        this.form.findField("searchdatefrom").setMaxValue(d)
                    }
                }
            };
            if (!SYNO.SDS.DateTimeUtils) {
                b.format = "m/d/Y";
                c.format = "m/d/Y"
            }
            this.DateFrom = new SYNO.ux.DateTimeField(b);
            this.DateTo = new SYNO.ux.DateTimeField(c);
            return [{
                xtype: "syno_compositefield",
                hideLabel: true,
                defaults: {
                    flex: 1
                },
                defaultMargins: "0 8 0 0",
                items: [this.DateFrom, this.DateTo]
            }]
        },
        frameAnimation: function(b, c) {
            if (b && b.isVisible()) {
                Ext.Element.prototype.frame.apply(b, c)
            }
        },
        defineBehaviors: function() {
            var b = this.get("btns");
            this.btnSearch = b.get("btn_search");
            this.btnStop = b.get("btn_stop")
        },
        setKeyWord: function(b) {
            var c = this.form.findField("keyword");
            if (c && Ext.isString(b)) {
                c.setValue(b)
            }
            c.focus("", 1)
        },
        enableDisableItem: function(c, b) {
            if (c !== "any") {
                this.frameAnimation(b.el, this.defaultAnimation);
                b.enable();
                return 1
            } else {
                b.reset();
                b.disable();
                return 0
            }
        },
        onSearch: function(b, c) {
            if (!this.getForm().isValid()) {
                return
            }
            this.fireEvent("filter", this)
        },
        onReset: function() {
            this.form.items.each(function(b) {
                if (b.isDirty()) {
                    this.frameAnimation(b.el, this.defaultAnimation)
                }
            }, this);
            this.form.reset();
            this.form.findField("fileSize").disable();
            this.form.findField("searchdatefrom").setMaxValue(null);
            this.form.findField("searchdateto").setMinValue(null)
        },
        isCondSet: function() {
            var e, d, c, b, g, f;
            e = this.getForm();
            b = e.findField("keyword").getValue();
            d = e.findField("fileType").getValue();
            c = e.findField("fileSizeOption").getValue();
            g = e.findField("searchdatefrom").getRawValue();
            f = e.findField("searchdateto").getRawValue();
            return (!Ext.isEmpty(b) || "any" !== d || "any" !== c || !Ext.isEmpty(g) || !Ext.isEmpty(f))
        },
        getParams: function() {
            var f, e, c, d, b, i, h;
            var g;
            f = this.getForm();
            b = f.findField("keyword").getValue();
            e = f.findField("fileType").getValue();
            c = f.findField("fileSizeOption").getValue();
            d = f.findField("fileSize").getValue();
            i = f.findField("searchdatefrom").getRawValue();
            h = f.findField("searchdateto").getRawValue();
            g = {
                filter_keyword: b,
                filter_type: e,
                filter_size_option: c,
                filter_size: d * 1024,
                filter_date_from: i ? new Date(i + " 00:00:00").getTime() / 1000 : 0,
                filter_date_to: h ? new Date(h + " 23:59:59").getTime() / 1000 : 0
            };
            return g
        }
    })
})();
Ext.define("SYNO.SDS.Backup.Client.Explore.AdvancedSearchField", {
    extend: "SYNO.ux.SearchField",
    initEvents: function() {
        this.callParent(arguments);
        this.mon(Ext.getDoc(), "mousedown", this.onMouseDown, this);
        this.mon(this, "keypress", function(b, a) {
            if (a.getKey() === Ext.EventObject.ENTER) {
                this.searchPanel.setKeyWord(this.getValue());
                this.searchPanel.onSearch()
            }
        }, this)
    },
    isInnerComponent: function(c, b) {
        var a = false;
        b.items.each(function(d) {
            if (d instanceof Ext.form.ComboBox) {
                if (d.view && c.within(d.view.getEl())) {
                    a = true;
                    return false
                }
            } else {
                if (d instanceof Ext.form.DateField) {
                    if (d.menu && c.within(d.menu.getEl())) {
                        a = true;
                        return false
                    }
                } else {
                    if (d instanceof Ext.form.CompositeField) {
                        if (this.isInnerComponent(c, d)) {
                            a = true;
                            return false
                        }
                    }
                }
            }
        }, this);
        return a
    },
    onMouseDown: function(b) {
        var a = this.searchPanel;
        if (a && a.isVisible() && !a.isDestroyed && !a.inEl && !b.within(a.getEl()) && !b.within(this.searchtrigger) && !this.isInnerComponent(b, this.searchPanel.getForm())) {
            a.hide()
        }
    },
    onSearchTriggerClick: function() {
        if (this.disabled) {
            return
        }
        if (this.searchPanel.isVisible()) {
            this.searchPanel.hide();
            return
        }
        this.searchPanel.getEl().alignTo(this.wrap, "tr-br?", [6, 0]);
        this.searchPanel.show();
        this.searchPanel.setKeyWord(this.getValue())
    },
    onTriggerClick: function() {
        if (this.disabled) {
            return
        }
        this.callParent();
        this.searchPanel.onReset();
        this.searchPanel.onSearch()
    }
});
Ext.define("SYNO.SDS.Backup.Client.Explore.PathBar", {
    extend: "Ext.Container",
    cls: "syno-sds-backup-pathbar syno-ux-textfield x-form-text x-form-field",
    path: "",
    historyManager: null,
    initComponent: function() {
        this.callParent(arguments);
        if (!this.historyManager) {
            this.historyManager = new SYNO.SDS.Backup.Client.Explore.HistoryManager()
        }
        if (!Ext.isEmpty(this.defaultPath)) {
            this.setPath(this.defaultPath)
        }
        this.addEvents("updatepath")
    },
    setPath: function(d, c, a) {
        if (d == this.path) {
            return false
        }
        var e = d.split("/").filter(function(f) {
            return !Ext.isEmpty(f)
        });
        this.removeAll();
        if ("@pathRoot" !== e[0]) {
            e.unshift("@pathRoot")
        }
        var b = "";
        Ext.each(e, function(h, f, g) {
            if (Ext.isEmpty(h)) {
                return true
            }
            b += ("/" + h);
            var i = "syno-sds-backup-pathbutton";
            if (0 === f && "@pathRoot" == h) {
                return true
            } else {
                if (1 === f) {
                    i = "syno-sds-backup-pathbutton-first"
                }
            }
            this.add(new SYNO.SDS.Backup.Client.Explore.PathButton({
                path: b,
                cls: i,
                owner: this,
                listeners: {
                    click: {
                        fn: function() {
                            this.owner.setPath(this.path, false, true)
                        }
                    }
                }
            }))
        }, this);
        this.path = b;
        this.doLayout();
        c = typeof c !== "undefined" ? c : false;
        if (this.historyManager && !c) {
            this.historyManager.addEvent(this.path)
        }
        this.fireEvent("updatepath", this, a)
    },
    getPath: function() {
        return this.path
    },
    getRelatedPath: function() {
        return this.path.substr("/@pathRoot".length + 1)
    },
    moveToPrevPath: function() {
        var a = null;
        if (this.historyManager) {
            a = this.historyManager.moveToPrevEvent();
            if (a) {
                this.setPath(a, true, true)
            }
        }
        return a
    },
    moveToNextPath: function() {
        var a = null;
        if (this.historyManager) {
            a = this.historyManager.moveToNextEvent();
            if (a) {
                this.setPath(a, true, true)
            }
        }
        return a
    },
    getPrevPath: function() {
        var a = null;
        if (this.historyManager) {
            a = this.historyManager.getPrevEvent()
        }
        return a
    },
    getNextPath: function() {
        var a = null;
        if (this.historyManager) {
            a = this.historyManager.getNextEvent()
        }
        return a
    }
});
Ext.define("SYNO.SDS.Backup.Client.Explore.PathButton", {
    extend: "SYNO.ux.Button",
    cls: "syno-sds-backup-pathbutton",
    iconCls: "syno-sds-backup-pathbutton-text",
    path: "",
    initComponent: function() {
        this.setPath(this.path);
        this.callParent(arguments)
    },
    setPath: function(a) {
        if (!Ext.isEmpty(this.path)) {
            this.path = a;
            this.text = this.path.split("/").pop();
            this.tooltip = Ext.util.Format.htmlEncode(this.text)
        }
    },
    getPath: function() {
        return this.path
    }
});
Ext.define("SYNO.SDS.Backup.Client.Explore.HistoryManager", {
    history: [],
    historyPoint: -1,
    historyMaxLength: 30,
    addEvent: function(a) {
        if (this.history[this.historyPoint] === a) {
            return
        }
        this.history.splice(this.historyPoint + 1, this.history.length - (this.historyPoint + 1), a);
        if (this.history.length > this.historyMaxLength) {
            this.history.shift()
        }
        this.historyPoint = this.history.length - 1
    },
    moveToPrevEvent: function() {
        var a = null;
        if (0 < this.historyPoint) {
            this.historyPoint--;
            a = this.history[this.historyPoint]
        }
        return a
    },
    moveToNextEvent: function() {
        var a = null;
        if ((this.historyPoint + 1) < this.history.length) {
            this.historyPoint++;
            a = this.history[this.historyPoint]
        }
        return a
    },
    getPrevEvent: function() {
        var a = null;
        if (0 < this.historyPoint) {
            a = this.history[this.historyPoint - 1]
        }
        return a
    },
    getNextEvent: function() {
        var a = null;
        if ((this.historyPoint + 1) < this.history.length) {
            a = this.history[this.historyPoint + 1]
        }
        return a
    }
});
(function() {
    var g = SYNO.SDS.Backup.Client.Explore.Utils.GetString;
    var e = SYNO.SDS.Backup.Client.Explore.Utils.GetErrorString;
    var d = function(s) {
            var t = s.clone();
            t.setHours(0);
            t.setMinutes(0);
            t.setSeconds(0);
            t.setMilliseconds(0);
            return t
        },
        k = function(s) {
            var t = s.clone();
            t.setHours(0);
            t.setMinutes(0);
            t.setSeconds(0);
            t.setMilliseconds(0);
            t.setDate(1);
            return t
        },
        i = function(w, u, s) {
            var t = new Ext.Template(u, {
                    compiled: true,
                    disableFormats: true
                }),
                v = t.append(w, s || {}, true);
            return v
        },
        q = function(w, u, s) {
            var t = new Ext.Template(u, {
                    compiled: true,
                    disableFormats: true
                }),
                v = t.overwrite(w, s || {}, true);
            return v
        },
        c = function(t, s) {
            return t.format("Y-m-d") === s.format("Y-m-d")
        },
        f = function(t, s) {
            if (!Ext.isDefined(t) && !Ext.isDefined(s)) {
                return true
            } else {
                if (!Ext.isDefined(t) || !Ext.isDefined(s)) {
                    return false
                }
            }
            return t.version_id === s.version_id
        },
        m = function(t) {
            var s = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
            return s[t.getMonth()]
        },
        l = "syno-backup-timeline-wrapper",
        n = "syno-backup-timeline-scroller",
        o = "syno-backup-timeline-pin-bg",
        h = "syno-backup-timeline-calendar x-btn syno-ux-button syno-ux-button-default x-btn-icon",
        b = "Y-m-d",
        a = "Y-m",
        p = 1000 * 60 * 60 * 24,
        j = 30,
        r = 10980;
    Ext.define("SYNO.SDS.Backup.Client.Explore.VersionMenu", {
        extend: "Ext.menu.Menu",
        cls: "syno-backup-client-timeline-version-menu",
        initComponent: function() {
            var s;
            Ext.apply(this, {
                plain: true,
                showSeparator: false
            });
            s = this.callParent(arguments);
            this.addEvents("select")
        },
        renderVersinfo: function() {
            if (!this.rendered) {
                this.mon(this, "afterrender", this.renderVersinfo, this);
                return
            }
            var w = ['<div class="syno-backup-timeline-version-ct">', '<div class="version-menu-header">', "<b>{vers_count}</b> {vers_desc} {vers_date}", "</div>", "</div>"],
                v, y, t = [],
                u = this.getVersinfo(),
                s, x = this.owner.selectedVersion;
            t.push("<table>");
            for (v = 0; v < u.length; v += 2) {
                s = f(u[v], x);
                t.push('<tr><td data-index="' + v + '" ' + (s ? 'class="version-selected"' : "") + " >" + SYNO.SDS.Backup.Explore.DateTimeFormatter(u[v].date, {
                    type: "timesec"
                }) + "</td>");
                if (v + 1 < u.length) {
                    s = f(u[v + 1], x);
                    t.push('<td data-index="' + (v + 1) + '" ' + (s ? 'class="version-selected"' : "") + " >" + SYNO.SDS.Backup.Explore.DateTimeFormatter(u[v + 1].date, {
                        type: "timesec"
                    }) + "</td>")
                }
                t.push("</tr>")
            }
            t.push("</table>");
            y = q(this.getEl(), w.join(""), {
                vers_desc: g("explorer", "timeline_versions"),
                vers_count: u.length,
                vers_date: SYNO.SDS.Backup.Explore.DateTimeFormatter(u[0].date, {
                    type: "date"
                })
            });
            this._box = new Ext.BoxComponent({
                renderTo: y,
                cls: "version-menu-ct",
                html: t
            });
            if (u.length > 6) {
                this._box.setHeight(105 - 25);
                this._box.updateScroller(0)
            }
            y.on("click", this.onClickVersion, this);
            return y
        },
        setVersinfo: function(s) {
            this.versinfo = s;
            this.changed = false;
            return this.renderVersinfo(s)
        },
        getVersinfo: function() {
            return this.versinfo
        },
        onClickVersion: function(u, v, t) {
            if (v.tagName === "TD") {
                var s = v.getAttribute("data-index");
                this.changed = true;
                this.selectedVersion = this.getVersinfo()[s];
                this.fireEvent("select", this.selectedVersion);
                this.hide(true)
            }
        }
    });
    Ext.define("SYNO.SDS.Backup.Client.Explore.TimeLine", {
        extend: "Ext.Panel",
        calendar: null,
        minDate: null,
        maxDate: null,
        selectedDate: null,
        versionMenu: null,
        versionList: null,
        _elMonth: null,
        _elTimeline: null,
        defaultVersion: null,
        panelWidth: 0,
        statusBusy: false,
        constructor: function(s) {
            var t = new Date(),
                u = Ext.apply({
                    owner: s.owner,
                    border: false,
                    frame: false,
                    minDate: t.add(Date.YEAR, -1),
                    maxDate: t
                }, s);
            u.minDate = d(u.minDate);
            u.maxDate = d(u.maxDate);
            this._elMonth = {};
            this.versionList = {};
            this.apiClass = "SYNO.SDS.Backup.Client.Explore.Version";
            this.methodVersionMap = {
                summary: 1,
                list: 1
            };
            return this.callParent([u])
        },
        initComponent: function() {
            this.callParent(arguments);
            this.addEvents("select");
            this.mon(this, "afterrender", this.onAfterRender, this)
        },
        onAfterRender: function() {
            this.renderTimeLine();
            if (this.loadAfterRender) {
                this.loadVersionSummary()
            }
        },
        setAccountMeta: function(s) {
            this.accountMeta = s
        },
        load: function(s) {
            this.defaultVersion = null;
            this.selectedVersion = null;
            if (s) {
                this.defaultVersion = s
            }
            Ext.iterate(this._elMonth, function(t, u) {
                u.remove()
            });
            this._elMonth = {};
            this.versionList = {};
            this.preLoadAll = false;
            if (!Ext.isEmpty(this.accountMeta) && SYNO.SDS.Backup.Client.Common.Utils.AccountMeta.ROTATION_BASIC === this.accountMeta.versionRotation) {
                this.preLoadAll = true
            }
            this.loadVersionSummary()
        },
        getPanelWidth: function() {
            return this._elTimeline.getWidth()
        },
        getScrollerWidth: function() {
            return this._elTimeline.child(".syno-backup-timeline-scroller").getWidth()
        },
        getDateByOffsetX: function(t) {
            if (t === undefined) {
                t = -this.scroll.x
            }
            var s = -Math.ceil((this.getScrollerWidth() - (this.getPanelWidth() / 2 + 15) - t) / j);
            return this.maxDate.add(Date.DAY, s)
        },
        getOffsetXByDate: function(s) {
            var t = d(s);
            return this.getScrollerWidth() - (this.getPanelWidth() / 2 + 15) - ((this.maxDate - t) / p) * j
        },
        getOffsetXByMonthDate: function(s) {
            return this.getOffsetXByDate(s.getFirstDateOfMonth())
        },
        getMonthEl: function(s) {
            var t = s.getFirstDateOfMonth();
            return this._elMonth[t.format(b)]
        },
        setMonthEl: function(s, t) {
            var u = s.getFirstDateOfMonth();
            this._elMonth[u.format(b)] = t
        },
        getVersionDomByVersionInfo: function(t) {
            var s = t[0].date,
                u = this.getMonthEl(s);
            return u.dom.childNodes[s.getDate()]
        },
        getVersionId: function() {
            if (this.selectedVersion) {
                return this.selectedVersion.version_id
            } else {
                return undefined
            }
        },
        getVersionDate: function() {
            if (this.selectedVersion) {
                return this.selectedVersion.name
            } else {
                return undefined
            }
        },
        renderTimeLine: function() {
            var t = this,
                s = i(t.getEl(), ['<div class="{wrapper_cls}">', '<div class="{scroller_cls}"></div>', '<div class="{calendar_cls}"></div>', '<div class="{pin_bg_cls}"></div>', "</div>"], {
                    wrapper_cls: l,
                    scroller_cls: n,
                    calendar_cls: h,
                    pin_bg_cls: o
                });
            t.scroll = new SYNO.SDS.Utils.IScroll(s.dom, {
                scrollX: true,
                scrollY: false,
                mouseWheel: true,
                deceleration: 0.01,
                startX: s.getWidth() * 1.2 - r,
                tap: Ext.isIE8 ? false : true
            });
            s.on(Ext.isIE8 ? "click" : "tap", function(w, v, u) {
                var x = null;
                if (v.classList.contains("syno-backup-timeline-calendar")) {
                    t.onCalendarClick(v)
                } else {
                    if (v.classList.contains("version-prev")) {
                        t.onClickPrevVersion()
                    } else {
                        if (v.classList.contains("version-next")) {
                            t.onClickNextVersion()
                        } else {
                            if (v.classList.contains("version-time") || v.classList.contains("version-count")) {
                                x = v.parentNode.parentNode;
                                t.onDateClick(x)
                            } else {
                                if (v.classList.contains("syno-backup-timeline-version-tag") || v.classList.contains("clickable")) {
                                    x = v.parentNode;
                                    if (x !== t._lastClickDom) {
                                        t.onDateClick(x)
                                    } else {
                                        x = null
                                    }
                                } else {
                                    if (v.tagName === "TD") {
                                        x = v.parentNode.parentNode.parentNode.parentNode;
                                        t.onDateClick(x)
                                    } else {
                                        if (t.versionMenu && t.versionMenu.isVisible()) {
                                            t.versionMenu.hide()
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                t._lastClickDom = x
            });
            t.scroll.on("beforeScrollStart", function() {
                if (t.versionMenu && t.versionMenu.isVisible()) {
                    t.versionMenu.hide()
                }
            });
            t.scroll.on("scrollEnd", function() {
                t.updateCurrentView()
            });
            t._elTimeline = s;
            this.panelWidth = t._elTimeline.getWidth();
            return s
        },
        renderMonth: function(t) {
            if (this.getMonthEl(t)) {
                return this.getMonthEl(t)
            }
            var x = this,
                v, w, s = t.getDaysInMonth(),
                u = ['<ul class="timeline-month" style="left:{offsetX}px; width:{width}px">', '<div class="month-label">{month}</div>'];
            for (v = 1; v <= s; v += 1) {
                if (v % 2 === 0) {
                    u.push('<li data-day="' + v + '"><div class="day-grid-line"></div><div class="day-mark"></div><a>' + v + "</a></li>")
                } else {
                    u.push('<li data-day="' + v + '"><div class="day-grid-line"></div><div class="day-mark"></div></li>')
                }
            }
            u.push("</ul>");
            w = i(x._elTimeline.child("." + n), u, {
                offsetX: x.getOffsetXByMonthDate(t),
                month: m(t),
                width: s * j
            });
            w.date = t.getFirstDateOfMonth();
            x.setMonthEl(t, w);
            if (this.versionList[t.format(a)] && 0 < this.versionList[t.format(a)].length) {
                this.renderVersions(this.versionList[t.format(a)])
            }
            return w
        },
        setVersionInfo: function(t) {
            var s = t[0].date,
                w, v = s.getDate() - s.getFirstDateOfMonth().getDate() + 1,
                u = this.renderMonth(s);
            w = u.dom.childNodes[v];
            if (!u.versions) {
                u.versions = []
            }
            u.versions[v] = t;
            this.renderVersionTag(u, v)
        },
        renderVersions: function(s) {
            var t = {};
            Ext.each(s, function(u) {
                var v = Date.parseDate(u.timestamp, "U");
                var w = v.format(b);
                u.date = v;
                if (t[w]) {
                    t[w].push(u)
                } else {
                    t[w] = [u]
                }
            }, this);
            Ext.iterate(t, function(u, v) {
                this.setVersionInfo(v)
            }, this)
        },
        scrollToDate: function(s, t) {
            this.scroll.scrollTo(-this.getOffsetXByDate(s) + this.getPanelWidth() - (this.getPanelWidth() / 2 + 15), 0, t)
        },
        updateMonthOffset: function() {
            for (var s in this._elMonth) {
                if (this._elMonth[s]) {
                    this._elMonth[s].setLeft(this.getOffsetXByDate(this._elMonth[s].date))
                }
            }
        },
        resizeScroller: function(t) {
            var s = t - this.getScrollerWidth();
            this._elTimeline.child(".syno-backup-timeline-scroller").setWidth(t);
            this.updateMonthOffset();
            this.scroll.refresh();
            this.scroll.scrollTo(this.scroll.x - s, 0, 0)
        },
        onResize: function(w, t, s, v) {
            this.callParent(arguments);
            var u = w - this.panelWidth;
            this.panelWidth = w;
            if (this.selectedVersion) {
                this.resizeScroller(this.getScrollerWidth() + u);
                this.scrollToDate(this.selectedVersion.date, 0)
            }
        },
        renderVersionTagByDate: function(s, t) {
            return this.renderVersionTag(this.getMonthEl(s), s.getDate(), t)
        },
        renderVersionTag: function(w, v, u) {
            var y = w.dom.childNodes[v],
                t = w.versions[v],
                s = "";
            y.classList.remove("version-exists");
            y.classList.remove("version-select");
            y.classList.remove("version-show");
            if (v % 2 === 0 && v !== w.date.getDaysInMonth()) {
                s = "<a>" + v + "</a>"
            }
            if (!Ext.isDefined(t)) {
                y.innerHTML = s;
                return y
            }
            if (!Ext.isDefined(u) || u === false) {
                y.classList.add("version-exists");
                y.innerHTML = '<div class="day-grid-line"></div><div class="day-mark"></div><div class="syno-backup-timeline-version-tag clickable"><div class="syno-backup-timeline-version-tag-bubble"><span>' + t.length + '</span></div><div class="syno-backup-timeline-version-tag-triangle "></div><div class="syno-backup-timeline-version-tag-circle unselect"></div></div>' + s;
                return y
            }
            if (u === true) {
                y.classList.add("version-show");
                y.innerHTML = '<div class="day-grid-line"></div><div class="day-mark"></div><div class="syno-backup-timeline-version-tag"><div class="syno-backup-timeline-version-tag-pin"></div><div class="syno-backup-timeline-version-tag-box-triangle"></div><div class="syno-backup-timeline-version-tag-circle show"></div></div>' + s;
                var x = this.createVersionMenu(t);
                x.show(y.childNodes[2], "b-t?")
            } else {
                y.classList.add("version-select");
                y.innerHTML = '<div class="day-grid-line"></div><div class="day-mark"></div><div class="version-box"><div class="version-count">' + t.length + '</div><div class="version-prev">&nbsp;</div><div class="version-time">' + SYNO.SDS.Backup.Explore.DateTimeFormatter(u.date) + '</div><div class="version-next">&nbsp;</div></div><div class="syno-backup-timeline-version-tag"><div class="syno-backup-timeline-version-tag-pin"></div><div class="syno-backup-timeline-version-tag-box-triangle"></div><div class="syno-backup-timeline-version-tag-circle select"></div></div>' + s
            }
            return y
        },
        createVersionMenu: function(s) {
            var t = this;
            if (!t.versionMenu) {
                t.versionMenu = new SYNO.SDS.Backup.Client.Explore.VersionMenu({
                    width: 172,
                    owner: t,
                    enableScrolling: false,
                    defaultOffsets: [0, -1],
                    listeners: {
                        hide: t.onVersionMenuHide,
                        scope: t
                    }
                })
            }
            t.versionMenu.setVersinfo(s);
            return t.versionMenu
        },
        updateCurrentView: function() {
            var t = this.getDateByOffsetX(-this.scroll.x);
            var s = this.getPreloadWindow(t, 5);
            if (s) {
                this.loadVersionList(s.minDate, s.maxDate)
            }
        },
        checkVersionLoaded: function(s) {
            return this.versionList[s.format(a)]
        },
        onCalendarClick: function(s) {
            if (null === this.calendar) {
                this.calendar = new SYNO.ux.DateTimeMenu({
                    hideOnClick: true,
                    focusOnSelect: false,
                    pickerCfg: {
                        isAllDay: true,
                        minDate: this.minDate,
                        maxDate: this.maxDate,
                        onClearClick: this.switchToDefaultVersion.bind(this)
                    }
                });
                this.mon(this.calendar, "select", function(u, t) {
                    this.scrollToDate(t, 700)
                }, this);
                this.mon(this.calendar, "updateDirtyValue", function(t) {
                    this.scrollToDate(t, 700)
                }, this)
            }
            this.calendar.show(s, "bl-tl?")
        },
        switchToDefaultVersion: function() {
            var s = (this.defaultVersion) ? Date.parseDate(this.defaultVersion + 3, "U") : this.maxDate;
            if (!s) {
                return
            }
            this.loadNextVersionInfo(s, -1, false);
            this.scrollToDate(this.selectedVersion.date, 700)
        },
        selectNextVersionForPreloadAll: function(w) {
            var v = this.selectedVersion.date;
            var t = this.versionList[v.format(a)];
            var u;
            var s = null;
            if (0 >= w) {
                for (u = t.length - 1; u >= 0; u--) {
                    if (t[u].timestamp < this.selectedVersion.timestamp) {
                        s = t[u];
                        break
                    }
                }
                while (!s) {
                    v = v.add(Date.MONTH, -1);
                    t = this.versionList[v.format(a)];
                    if (t) {
                        if (t.length > 0) {
                            s = t[t.length - 1];
                            break
                        }
                    } else {
                        break
                    }
                }
            } else {
                for (u = 0; u < t.length; u++) {
                    if (t[u].timestamp > this.selectedVersion.timestamp) {
                        s = t[u];
                        break
                    }
                }
                while (!s) {
                    v = v.add(Date.MONTH, 1);
                    t = this.versionList[v.format(a)];
                    if (t) {
                        if (t.length > 0) {
                            s = t[0];
                            break
                        }
                    } else {
                        break
                    }
                }
            }
            if (!s) {
                s = this.selectedVersion
            }
            this.selectVersion(s)
        },
        selectVersion: function(t) {
            if (!t) {
                return
            }
            if (this.selectedVersion && t.date.toString() === this.selectedVersion.date.toString()) {
                return
            }
            var s = this.selectedVersion;
            this.selectedVersion = t;
            if (s) {
                this.renderVersionTagByDate(s.date, false)
            }
            this.renderVersionTagByDate(t.date, t);
            this.scrollToDate(this.selectedVersion.date, 700);
            this.fireEvent("select", this.selectedVersion)
        },
        onDateClick: function(u) {
            var t = Ext.get(u.parentNode),
                s = t.versions[u.getAttribute("data-day")];
            if (!s || s.length <= 0) {
                SYNO.Debug("renderVersions: failed?");
                return
            }
            if (s.length === 1) {
                this.selectVersion(s[0])
            } else {
                this.renderVersionTagByDate(s[0].date, true)
            }
        },
        onVersionMenuHide: function(s) {
            if (s.changed) {
                if (this.selectedVersion) {
                    if (f(this.selectedVersion, s.selectedVersion)) {
                        this.renderVersionTagByDate(this.selectedVersion.date, this.selectedVersion);
                        return
                    }
                    this.renderVersionTagByDate(this.selectedVersion.date, false)
                }
                this.selectVersion(s.selectedVersion)
            } else {
                if (!this.selectedVersion) {
                    this.renderVersionTagByDate(s.getVersinfo()[0].date, false);
                    return
                }
                if (!c(this.selectedVersion.date, s.getVersinfo()[0].date)) {
                    this.renderVersionTagByDate(s.getVersinfo()[0].date, false);
                    return
                }
                this.renderVersionTagByDate(this.selectedVersion.date, this.selectedVersion)
            }
        },
        setDateInterval: function(s, t) {
            this.minDate = d(s);
            this.maxDate = d(t);
            if (this.calendar) {
                this.calendar.picker.setMinDate(this.minDate);
                this.calendar.picker.setMaxDate(this.maxDate)
            }
            this.resizeScroller(((this.maxDate.getTime() - this.minDate.getTime()) / 86400000 * j) + this.getPanelWidth());
            return this
        },
        loadVersionList: function(t, v, s) {
            if (!this.statusBusy) {
                this.owner.setStatusBusy();
                this.statusBusy = true
            }
            var u = Ext.apply(this.getBaseParams(), {
                time_from: k(t).getTime() / 1000,
                time_to: k(v).add(Date.MONTH, 1).getTime() / 1000,
                filter_name: "success",
                account_meta: this.accountMeta,
                additional: ["skip_check_key"]
            });
            this.sendWebAPI({
                api: this.apiClass,
                version: this.methodVersionMap.list,
                method: "list",
                params: u,
                encryption: ["pwd", "secret", "remote_refresh_token", "remote_access_token"],
                scope: this,
                callback: function(y, w, x) {
                    this.owner.clearStatusBusy();
                    this.statusBusy = false;
                    if (!y) {
                        this.owner.getMsgBox().alert(g("app", "backup_explorer"), e(w.code), function() {
                            this.owner.close()
                        }, this);
                        return
                    }
                    this.updateVersionList(t, v, w.version_info_list);
                    this.renderVersionList(t, v, s)
                }
            })
        },
        updateVersionList: function(t, u, s) {
            while (t <= u) {
                if (!this.versionList[t.format(a)]) {
                    this.versionList[t.format(a)] = []
                }
                t = t.add(Date.MONTH, 1)
            }
            Ext.each(s, function(y, w, x) {
                if ("success" !== y.status && "partial" !== y.status) {
                    return
                }
                var v = Date.parseDate(y.timestamp, "U");
                if (!this.versionList[v.format(a)]) {
                    this.versionList[v.format(a)] = []
                }
                this.versionList[v.format(a)].unshift(y)
            }, this)
        },
        renderVersionList: function(t, u, s) {
            while (u >= t) {
                this.renderMonth(u);
                u = u.add(Date.MONTH, -1)
            }
            if (s) {
                this.selectVersion(s)
            }
        },
        getPreloadWindow: function(u, t) {
            var s = {},
                v = k(u),
                w = true;
            if (this.checkVersionLoaded(v)) {
                if (!this.checkVersionLoaded(v.add(Date.MONTH, -1))) {
                    v = v.add(Date.MONTH, -1)
                } else {
                    if (!this.checkVersionLoaded(v.add(Date.MONTH, 1))) {
                        v = v.add(Date.MONTH, 1)
                    } else {
                        return undefined
                    }
                }
            }
            s.maxDate = v;
            s.minDate = v;
            while (true === w) {
                w = false;
                if (!this.checkVersionLoaded(s.minDate.add(Date.MONTH, -1)) && 0 < t) {
                    s.minDate = s.minDate.add(Date.MONTH, -1);
                    --t;
                    w = true
                }
                if (!this.checkVersionLoaded(s.maxDate.add(Date.MONTH, 1)) && 0 < t) {
                    s.maxDate = s.maxDate.add(Date.MONTH, 1);
                    --t;
                    w = true
                }
            }
            return s
        },
        loadNextVersionInfo: function(t, v, s) {
            if (this.preLoadAll && this.selectedVersion) {
                this.selectNextVersionForPreloadAll(v);
                return
            }
            if (!this.statusBusy) {
                this.owner.setStatusBusy();
                this.statusBusy = true
            }
            var u = Ext.apply(this.getBaseParams(), {
                offset: 0,
                limit: this.preLoadAll ? 999 : 1,
                filter_name: "success",
                account_meta: this.accountMeta,
                additional: ["skip_check_key"]
            });
            if (0 >= v) {
                u.sort_direction = "desc";
                u.time_from = 1;
                u.time_to = Math.floor(t.getTime() / 1000) - 1
            } else {
                u.sort_direction = "asc";
                u.time_from = Math.floor(t.getTime() / 1000) + 1;
                u.time_to = -1
            }
            this.sendWebAPI({
                api: this.apiClass,
                version: this.methodVersionMap.list,
                method: "list",
                params: u,
                encryption: ["pwd", "secret", "remote_refresh_token", "remote_access_token"],
                scope: this,
                callback: function(D, y, A) {
                    if (!D) {
                        this.owner.clearStatusBusy();
                        this.statusBusy = false;
                        this.owner.getMsgBox().alert(g("app", "backup_explorer"), e(y.code), function() {
                            this.owner.close()
                        }, this);
                        return
                    }
                    if (y.version_info_list.length < 1) {
                        this.owner.clearStatusBusy();
                        this.statusBusy = false;
                        if (s) {
                            this.owner.getMsgBox().alert(g("app", "backup_explorer"), g("error", "no_available_restore_version"), function() {
                                this.owner.close()
                            }, this)
                        }
                        return
                    }
                    var w = y.version_info_list[0];
                    w.date = Date.parseDate(w.timestamp, "U");
                    if (this.preLoadAll) {
                        this.owner.clearStatusBusy();
                        this.statusBusy = false;
                        var z = y.version_info_list[y.version_info_list.length - 1];
                        var B = Date.parseDate(z.timestamp, "U");
                        var C = w.date;
                        B = k(B).add(Date.MONTH, -2);
                        C = k(C).add(Date.MONTH, 2);
                        this.updateVersionList(B, C, y.version_info_list);
                        this.renderVersionList(B, C, w)
                    } else {
                        var x = this.getPreloadWindow(w.date, 5);
                        if (x) {
                            this.loadVersionList(x.minDate, x.maxDate, w)
                        } else {
                            this.owner.clearStatusBusy();
                            this.statusBusy = false;
                            this.selectVersion(w)
                        }
                    }
                }
            })
        },
        loadVersionSummary: function() {
            if (!this.statusBusy) {
                this.owner.setStatusBusy();
                this.statusBusy = true
            }
            var s = this.getBaseParams();
            this.sendWebAPI({
                api: this.apiClass,
                version: this.methodVersionMap.summary,
                method: "summary",
                params: s,
                encryption: ["pwd", "secret", "remote_refresh_token", "remote_access_token"],
                scope: this,
                callback: function(x, t, u) {
                    if (!x) {
                        this.loadVersionSummaryCompatible();
                        return
                    }
                    if (t.version_count < 1) {
                        this.owner.clearStatusBusy();
                        this.statusBusy = false;
                        this.owner.getMsgBox().alert(g("app", "backup_explorer"), g("error", "no_available_restore_version"), function() {
                            this.owner.close()
                        }, this);
                        return
                    }
                    var v = Date.parseDate(t.start_time, "U");
                    var w = Date.parseDate(t.end_time, "U").add(Date.SECOND, 1);
                    if (0 >= w) {
                        w = new Date()
                    }
                    this.setDateInterval(v, this.maxDate);
                    if (this.defaultVersion) {
                        this.loadNextVersionInfo(Date.parseDate(this.defaultVersion + 3, "U"), -1, true)
                    } else {
                        this.loadNextVersionInfo(w, -1, true)
                    }
                }
            })
        },
        loadVersionSummaryCompatible: function() {
            if (!this.statusBusy) {
                this.owner.setStatusBusy();
                this.statusBusy = true
            }
            var s = Ext.apply(this.getBaseParams(), {
                offset: 0,
                limit: 1,
                sort_direction: "asc",
                filter_name: "success",
                account_meta: this.accountMeta,
                additional: ["skip_check_key"]
            });
            this.sendWebAPI({
                api: this.apiClass,
                version: this.methodVersionMap.list,
                method: "list",
                params: s,
                scope: this,
                callback: function(x, t, v) {
                    if (!x || t.version_info_list.length < 1) {
                        this.owner.clearStatusBusy();
                        this.statusBusy = false;
                        this.owner.getMsgBox().alert(g("app", "backup_explorer"), e(t.code), function() {
                            this.owner.close()
                        }, this);
                        return
                    }
                    var u = new Date();
                    var w = Date.parseDate(t.version_info_list[0].timestamp, "U");
                    this.setDateInterval(w, this.maxDate);
                    this.loadNextVersionInfo(u, -1, true)
                }
            })
        },
        onClickPrevVersion: function() {
            if (this.selectedVersion) {
                this.loadNextVersionInfo(this.selectedVersion.date, -1, false)
            }
        },
        onClickNextVersion: function() {
            if (this.selectedVersion) {
                this.loadNextVersionInfo(this.selectedVersion.date, 1, false)
            }
        }
    })
})();
Ext.define("SYNO.SDS.Backup.Client.Explore.TreeLoader", {
    extend: "Ext.tree.TreeLoader",
    sendWebAPI: undefined,
    webapi: undefined,
    numPerLevel: undefined,
    constructor: function() {
        var a = arguments[0];
        if (a && a.webapi) {
            this.dataUrl = "dummy"
        }
        return this.callParent(arguments)
    },
    requestData: function(c, e, b) {
        if (this.fireEvent("beforeload", this, c, e) !== false) {
            if (this.directFn) {
                var a = this.getParams(c);
                a.push(this.processDirectResponse.createDelegate(this, [{
                    callback: e,
                    node: c,
                    scope: b
                }], true));
                this.directFn.apply(window, a)
            } else {
                if (this.nodeData && -1 !== this.owner.fm_root_nodes.indexOf(c.id)) {
                    this.handleNodeData(c, this.nodeData, e, b)
                } else {
                    if (Ext.isFunction(this.sendWebAPI)) {
                        var d = Ext.apply({}, {
                            params: this.getParams(c),
                            argument: {
                                callback: e,
                                node: c,
                                scope: b
                            },
                            callback: this.handleWebAPIResponse,
                            scope: this
                        }, this.webapi);
                        this.transId = this.sendWebAPI(d)
                    } else {
                        this.transId = Ext.Ajax.request({
                            method: this.requestMethod,
                            url: this.dataUrl || this.url,
                            success: this.handleResponse,
                            failure: this.handleFailure,
                            scope: this,
                            argument: {
                                callback: e,
                                node: c,
                                scope: b
                            },
                            params: this.getParams(c)
                        })
                    }
                }
            }
        } else {
            this.runCallback(e, b || c, [])
        }
    },
    handleNodeData: function(f, c, h, e) {
        if (Ext.isFunction(this.parseWebApiResponse)) {
            c = this.parseWebApiResponse.call(this, f, c)
        }
        f.beginUpdate();
        for (var d = 0, b = c.length; d < b; d++) {
            var g = this.createNode(c[d]);
            if (g) {
                f.appendChild(g)
            }
        }
        f.endUpdate();
        var a = f.getOwnerTree();
        if (a) {
            a.doLayout()
        }
        this.runCallback(h, e || f, [f]);
        this.fireEvent("load", this, f, c, true)
    },
    handleWebAPIResponse: function(l, b, f, m) {
        var k = m.argument,
            d = k.node;
        this.transId = false;
        if (l) {
            try {
                if (Ext.isFunction(this.parseWebApiResponse)) {
                    b = this.parseWebApiResponse.call(this, d, b)
                }
                d.beginUpdate();
                for (var g = 0, h = b.length; g < h; g++) {
                    if (b[g].recycle) {
                        continue
                    }
                    var c = this.createNode(b[g]);
                    if (c) {
                        d.appendChild(c)
                    }
                }
                d.endUpdate();
                this.runCallback(k.callback, k.scope || d, [d])
            } catch (j) {
                SYNO.Debug("tree loadexception");
                this.fireEvent("loadexception", this, d, b);
                this.runCallback(k.callback, k.scope || d, [d]);
                return
            }
            this.fireEvent("load", this, d, b, false)
        } else {
            this.fireEvent("loadexception", this, d, b);
            this.runCallback(k.callback, k.scope || d, [d])
        }
    },
    createNode: function(a) {
        var b;
        a.uiProvider = "SYNO.SDS.Backup.Client.Explore.TriTreeNodeUI";
        a.draggable = false;
        if (Ext.isFunction(this.createNodeFn)) {
            b = this.createNodeFn.call(this.createNodeScope || this, a);
            if (b === false) {
                return
            }
        }
        var c = this.callParent(arguments);
        return c
    }
});
Ext.define("SYNO.SDS.Backup.Client.Explore.BasicTreePanel", {
    extend: "SYNO.ux.TreePanel",
    constructor: function(a) {
        var b = Ext.apply({
            useArrows: true,
            autoScroll: true,
            containerScroll: true,
            bodyStyle: "overflow-x: hidden;overflow-y:auto; padding-right: 12px;",
            enableDD: false
        }, a);
        return this.callParent([b])
    },
    initEvents: function() {
        var a = this.callParent(arguments);
        this.mon(this, "checkchange", this.onCheckChange, this);
        this.mon(this, "expandnode", this.onExpandNode, this);
        return a
    },
    getCheckedSubTreeRoot: function(b) {
        var a = [];
        var c = function(d) {
            d.eachChild(function(f) {
                var e = f.getUI() || {};
                if (!Ext.isFunction(e.getCheckValue)) {
                    return
                }
                if (true === e.getCheckValue()) {
                    a.push(f)
                } else {
                    if ("gray" === e.getCheckValue()) {
                        c(f)
                    }
                }
            })
        };
        c(b || this.root);
        return a
    },
    onCheckChange: function(a, e) {
        var d, c, g, f = function(k) {
                var j = 0,
                    i = 0,
                    h = 0;
                k.eachChild(function(m) {
                    var l = m.getUI() || {};
                    if (l.checkbox && Ext.isFunction(l.getCheckValue) && (!Ext.isFunction(l.isDisabled) || !l.isDisabled())) {
                        if (true === l.getCheckValue()) {
                            i += 1
                        } else {
                            if (false === l.getCheckValue()) {
                                h += 1
                            }
                        }
                        j += 1
                    }
                });
                if (0 === j) {
                    return k.getUI().getCheckValue()
                } else {
                    if (i === j) {
                        return true
                    } else {
                        if (h === j) {
                            return false
                        } else {
                            return "gray"
                        }
                    }
                }
            },
            b = function(h) {
                var i = Ext.apply({}, h.attributes.depend);
                return Ext.applyIf(i, {
                    parent: false,
                    children: true
                })
            };
        g = b(a);
        if (true === g.children) {
            if (true === e) {
                a.eachChild(function(i) {
                    var h = i.getUI();
                    if (h && Ext.isFunction(h.setCheckValue) && (!Ext.isFunction(h.isDisabled) || !h.isDisabled())) {
                        h.setCheckValue(true)
                    }
                }, this)
            } else {
                if (false === e) {
                    a.eachChild(function(i) {
                        var h = i.getUI();
                        if (h && Ext.isFunction(h.setCheckValue) && (!Ext.isFunction(h.isDisabled) || !h.isDisabled())) {
                            h.setCheckValue(false)
                        }
                    }, this)
                }
            }
        }
        d = a.parentNode;
        while (d) {
            c = d.getUI();
            if (!c || !Ext.isFunction(c.getCheckValue)) {
                g = b(d);
                d = d.parentNode;
                continue
            }
            if (true === g.parent) {
                d.attributes.checked = f(d)
            } else {
                if (true === e && false === d.attributes.checked) {
                    d.attributes.checked = "gray"
                } else {
                    if (false === e) {
                        d.attributes.checked = f(d)
                    }
                }
            }
            c.syncCheckCssClass();
            g = b(d);
            d = d.parentNode
        }
    },
    onExpandNode: function(a) {
        var b = a.getUI(),
            c = Ext.apply({}, a.attributes.depend);
        Ext.applyIf(c, {
            parent: false,
            children: true
        });
        if (!b || !Ext.isFunction(b.getCheckValue)) {
            return
        }
        if (true === c.children && true === b.getCheckValue()) {
            a.eachChild(function(d) {
                b = d.getUI();
                if (b && Ext.isFunction(b.isDisabled) && !b.isDisabled() && Ext.isFunction(b.setCheckValue)) {
                    b.setCheckValue(true)
                }
            }, this)
        }
    }
});
(function() {
    var a = SYNO.SDS.Backup.Client.Explore.Utils.GetString;
    Ext.define("SYNO.SDS.Backup.Client.Explore.TriTreeNodeUI", {
        extend: "Ext.tree.TreeNodeUI",
        renderElements: function(f, l, k, m) {
            this.indentMarkup = f.parentNode ? f.parentNode.ui.getChildIndent() : "";
            var h = Ext.isBoolean(l.checked) || l.checked === "gray",
                g = Ext.util.Format.htmlEncode,
                e = l.input,
                c, b = this.getHref(l.href),
                d = ['<li class="x-tree-node syno-backup-tri-tree-node"><div ext:tree-node-id="', g(f.id), '" class="x-tree-node-el x-tree-node-leaf x-unselectable ', l.cls, '" unselectable="on">', '<span class="x-tree-node-indent">', this.indentMarkup, "</span>", '<img alt="" src="', this.emptyIcon, '" class="x-tree-ec-icon x-tree-elbow" />', h ? ('<img alt="" src="' + this.emptyIcon + '" class="syno-backup-tri-tree-node-cb syno-ux-checkbox-icon" />') : "", '<img alt="" src="', l.icon || this.emptyIcon, '" class="x-tree-node-icon', (l.icon ? " x-tree-node-inline-icon" : ""), (l.iconCls ? " " + l.iconCls : ""), '" unselectable="on" ', ((l.icon || l.iconCls) ? "" : 'style="display: none;"') + "/>", '<a hidefocus="on" class="x-tree-node-anchor" href="', b, '" tabIndex="1" ', l.hrefTarget ? ' target="' + l.hrefTarget + '"' : "", '><span unselectable="on" ext:qtip="', SYNO.SDS.Backup.Explore.htmlEncodeTip(f.text), '">', g(f.text), "</span></a>", "</div>", '<ul class="x-tree-node-ct" style="display:none;"></ul>', "</li>"].join("");
            if (m !== true && f.nextSibling && (c = f.nextSibling.ui.getEl())) {
                this.wrap = Ext.DomHelper.insertHtml("beforeBegin", c, d)
            } else {
                this.wrap = Ext.DomHelper.insertHtml("beforeEnd", k, d)
            }
            this.elNode = this.wrap.childNodes[0];
            this.ctNode = this.wrap.childNodes[1];
            var j = this.elNode.childNodes;
            var i = 0;
            this.indentNode = j[i++];
            this.ecNode = j[i++];
            if (h) {
                this.checkbox = j[i++]
            }
            this.iconNode = j[i++];
            this.anchor = j[i++];
            this.textNode = this.anchor.firstChild;
            if ("rename" === l.shareConflict) {
                this.renameNode = j[i++]
            }
            if ("overwrite" === l.shareConflict) {
                this.overwriteNode = j[i++]
            }
            this.volumeWarnNode = j[i++];
            if (e) {
                this.createInputField(e, l, this.elNode);
                i++
            }
            if (h) {
                this.syncCheckCssClass()
            }
            f.on("disabledchange", this.onDisabled, this)
        },
        onIdChange: function(c) {
            var b = Ext.util.Format.htmlEncode;
            if (this.rendered) {
                this.elNode.setAttribute("ext:tree-node-id", b(c))
            }
        },
        createInputField: function(c, b, d) {
            var e = c;
            if (Ext.isObject(c)) {
                this.inputConfig = Ext.apply({}, c);
                e = c.xtype || "textfield";
                delete c.xtype
            } else {
                this.inputConfig = {}
            }
            if (Ext.isDefined(b.value)) {
                this.inputConfig.value = b.value
            }
            this.inputConfig.renderTo = d;
            switch (e) {
                case "textfield":
                    this.input = new SYNO.ux.TextField(this.inputConfig);
                    break;
                case "numberfield":
                    this.input = new SYNO.ux.NumberField(this.inputConfig);
                    break
            }
        },
        initEvent: function() {
            var b = this.callParent(arguments);
            if (this.checkbox) {
                this.initCheckEvent()
            }
            return b
        },
        isChecked: function() {
            return this.getCheckValue()
        },
        isDisabled: function() {
            var b = this.node;
            return (true === b.disabled)
        },
        toggleCheck: function() {
            var b = this.checkbox;
            if (true === this.node.disabled) {
                return
            }
            if (b) {
                this.setCheckValue(!this.getCheckValue())
            }
        },
        onClick: function(b) {
            if (b.getTarget(".x-form-field")) {
                return
            }
            if (b.getTarget(".syno-backup-tri-tree-node-cb")) {
                this.toggleCheck()
            }
            return this.callParent(arguments)
        },
        onDblClick: function(b) {
            b.preventDefault();
            if (this.disabled) {
                return
            }
            if (this.fireEvent("beforedblclick", this.node, b) !== false) {
                if (!this.animating && this.node.isExpandable()) {
                    this.node.toggle()
                }
                this.fireEvent("dblclick", this.node, b)
            }
        },
        onDisabled: function(c, b) {
            if (this.input) {
                if (b) {
                    this.input.disable()
                } else {
                    this.input.enable()
                }
            }
            if (this.checkbox) {
                if (b) {
                    this.checkbox.classList.add("syno-ux-cb-disabled")
                } else {
                    this.checkbox.classList.remove("syno-ux-cb-disabled")
                }
            }
        },
        onCheckChange: function() {
            this.syncCheckCssClass();
            this.fireEvent("checkchange", this.node, this.getCheckValue())
        },
        isValid: function() {
            if (this.node.disabled) {
                return true
            }
            if (this.input && !this.input.isValid()) {
                return false
            }
            return true
        },
        getInputValue: function() {
            if (!this.input || this.disabled) {
                return undefined
            }
            return this.input.getValue()
        },
        setInputValue: function(b) {
            if (!this.input) {
                return
            }
            this.input.setValue(b)
        },
        getCheckValue: function() {
            return this.node.attributes.checked
        },
        setCheckValue: function(b) {
            if (this.node.disabled) {
                return
            }
            if (b === this.getCheckValue()) {
                return
            }
            if (b === "false" || b === "off" || b === "0") {
                b = false
            } else {
                if (b === "gray") {
                    b = "gray"
                } else {
                    b = (b ? true : false)
                }
            }
            this.node.attributes.checked = b;
            this.onCheckChange()
        },
        syncCheckCssClass: function() {
            var c = this.getCheckValue();
            var b = this.checkbox;
            if (!b) {
                return
            }
            Ext.each(["checked", "grayed", "disabled"], function(d) {
                this.checkbox.classList.remove("syno-ux-cb-" + d)
            }, this);
            if (this.volumeWarnNode) {
                this.volumeWarnNode.classList.remove("syno-ux-cb-selected")
            }
            if (c === true) {
                this.checkbox.classList.add("syno-ux-cb-checked");
                if (this.volumeWarnNode) {
                    this.volumeWarnNode.classList.add("syno-ux-cb-selected")
                }
            } else {
                if (c === "gray") {
                    this.checkbox.classList.add("syno-ux-cb-grayed");
                    if (this.volumeWarnNode) {
                        this.volumeWarnNode.classList.add("syno-ux-cb-selected")
                    }
                }
            }
            if (this.node.disabled) {
                this.checkbox.classList.add("syno-ux-cb-disabled")
            }
        },
        initCheckEvent: function() {
            this.checkbox.addListener("mouseover", this.onCheckMouseover, this);
            this.checkbox.addListener("mouseout", this.onCheckMouseout, this);
            this.checkbox.addListener("focus", this.onCheckIconfocus, this);
            this.checkbox.addListener("blur", this.onCheckIconblur, this)
        },
        onCheckMouseover: function() {
            this.checkbox.classList.add("syno-ux-cb-hover")
        },
        onCheckMouseout: function() {
            this.checkbox.classList.remove("syno-ux-cb-hover")
        },
        onCheckIconfocus: function() {
            this.checkbox.classList.add("syno-ux-cb-focus")
        },
        onCheckIconblur: function() {
            this.checkbox.classList.remove("syno-ux-cb-focus")
        }
    });
    Ext.define("SYNO.SDS.Backup.Client.Explore.TriTreeDisableCheckNodeUI", {
        extend: "SYNO.SDS.Backup.Client.Explore.TriTreeNodeUI",
        checkShareNode: function(c, d, b) {
            if (!c.dependAppRows || 0 === c.dependAppRows.length) {
                return
            }
            Ext.each(c.dependAppRows, function(e) {
                if (e.get("checked")) {
                    if (-1 === d.indexOf(c.id.substr(1))) {
                        d.push(c.id.substr(1))
                    }
                    if (-1 === b.indexOf(e.get("name"))) {
                        b.push(e.get("name"));
                        this.node.appRowsToBeUnselected.push(e)
                    }
                    this.node.appGrid = c.dependGrid
                }
            }, this)
        },
        setCheckValue: function(f) {
            if (true !== f && !this.node.clickConfirmed) {
                this.node.appRowsToBeUnselected = [];
                var e = [];
                var b = [];
                var g;
                if ("fm_root" === this.node.id) {
                    Ext.each(this.node.childNodes, function(h) {
                        this.checkShareNode(h, e, b)
                    }, this)
                } else {
                    var d = this.node.id.substr(1).split("/", 1)[0];
                    var c = this.node.getOwnerTree().getNodeById("/" + d);
                    this.checkShareNode(c, e, b)
                }
                if (0 < b.length && 0 < e.length) {
                    if (e[0].isBackup) {
                        g = a("explorer", "unselect_share_alert_bkp")
                    } else {
                        g = a("explorer", "unselect_share_alert_restore")
                    }
                    g = String.format(g, e.join(", "), b.join(", "));
                    this.node.getOwnerTree().owner.getMsgBox().confirm("", g, function(h) {
                        if ("yes" === h) {
                            this.node.clickConfirmed = true;
                            this.setCheckValue(false)
                        }
                    }, this);
                    return false
                }
            }
            this.node.clickConfirmed = false;
            Ext.each(this.node.appRowsToBeUnselected, function(h) {
                h.set("checked", false)
            });
            this.node.appRowsToBeUnselected = [];
            if (this.node.appGrid) {
                this.node.appGrid.syncCheckedStatus();
                delete this.node.appGrid
            }
            if (!f && this.node.disabled) {
                this.node.disabled = false;
                this.callParent(arguments);
                this.node.disabled = true;
                this.syncCheckCssClass()
            } else {
                this.callParent(arguments)
            }
        }
    })
})();
(function() {
    var a = SYNO.SDS.Backup.Client.Explore.Utils.GetString;
    Ext.define("SYNO.SDS.Backup.Client.Explore.PathSelector.Window", {
        extend: "SYNO.SDS.ModalWindow",
        selectedPath: null,
        constructor: function(b) {
            var c = Ext.apply({
                buttons: [{
                    text: _T("common", "cancel"),
                    handler: function() {
                        this.close()
                    },
                    scope: this
                }, {
                    itemId: "btn_apply",
                    text: _T("common", "apply"),
                    btnStyle: "blue",
                    handler: function() {
                        this.fireEvent("apply", this, this.getParams());
                        this.close()
                    },
                    scope: this
                }]
            }, b);
            return this.callParent([c])
        },
        initEvents: function() {
            this.callParent(arguments);
            this.addEvents("apply");
            this.mon(this.treePanel.getSelectionModel(), "selectionchange", function(c, b) {
                if (b) {
                    this.selectedPath = b.attributes.abspath
                }
            }, this);
            this.mon(this.treePanel.getLoader(), "load", this.onTreeLoad, this)
        },
        initComponent: function() {
            this.callParent(arguments);
            this.treeLoader = new SYNO.SDS.Backup.Client.Explore.TreeLoader({
                nodeParameter: "folder_path",
                sendWebAPI: this.sendWebAPI.createDelegate(this),
                webapi: {
                    api: "SYNO.Core.File",
                    method: "list",
                    version: 1
                },
                createNodeScope: this,
                createNodeFn: function(b) {
                    b.checked = null;
                    if (b.spath) {
                        b.id = b.spath;
                        b.abspath = b.path;
                        b.path = b.spath;
                        if ("" !== b.mountType) {
                            b.hidden = true
                        }
                    } else {
                        if (b.path) {
                            b.id = b.path;
                            b.abspath = b.additional.real_path;
                            b.text = b.name;
                            if ("" !== b.additional.mount_point_type) {
                                b.hidden = true
                            }
                        }
                    }
                },
                parseWebApiResponse: (function(d, b) {
                    var c = [];
                    if (b.files) {
                        c = b.files.filter(function(e) {
                            return !SYNO.SDS.Backup.Util.isRecycleBinFolder(e.path)
                        })
                    } else {
                        c = b.filter(function(e) {
                            return "RW" === e.right
                        })
                    }
                    if ((d && !d.isRoot) && c.length > this.treePanel.folderDisplayLimit) {
                        d.attributes.expandable = true;
                        d.attributes.exceedLimit = true;
                        return []
                    }
                    return c
                }).createDelegate(this),
                baseParams: {
                    superuser: false,
                    status_filter: "valid",
                    filetype: "dir",
                    additional: ["real_path", "mount_point_type"],
                    support_enum_cold_storage: true
                },
                owner: this
            });
            this.treePanel = new SYNO.SDS.Backup.Client.Explore.PathSelector.TreePanel({
                loader: this.treeLoader,
                border: false,
                folderDisplayLimit: 10000,
                root: new Ext.tree.AsyncTreeNode({
                    name: "fm_root",
                    id: "/",
                    path: "/",
                    text: _S("hostname"),
                    cls: "root_node",
                    expanded: true,
                    disabled: true
                }),
                autoFlexcroll: true,
                cls: "syno-sds-backup-filebrowser-treepanel",
                owner: this
            });
            this.add(this.treePanel)
        },
        getParams: function() {
            var b = {
                dest_path: this.selectedPath,
                overwrite: this.treePanel.getBottomToolbar().getComponent("overwrite").checked
            };
            return b
        },
        onTreeLoad: function(b, d, c) {
            if (!this.selectedPath && 0 < c.length) {
                this.treePanel.getSelectionModel().select(this.treePanel.getNodeById(c[0].id))
            }
        }
    });
/**
 * @class SYNO.SDS.Backup.Client.Explore.PathSelector.TreePanel
 * @extends SYNO.SDS.Backup.Client.Explore.BasicTreePanel
 * HyperBackup client explore path selector tree panel class
 *
 */
    Ext.define("SYNO.SDS.Backup.Client.Explore.PathSelector.TreePanel", {
        extend: "SYNO.SDS.Backup.Client.Explore.BasicTreePanel",
        initComponent: function() {
            this.bbar = [new Ext.form.Label({
                height: 32,
                text: a("explorer", "same_file_description") + ":"
            }), new SYNO.ux.DisplayField({
                style: "width: 13px",
                fieldLabel: "",
                value: "&nbsp;",
                htmlEncode: false
            }), new SYNO.ux.Radio({
                itemId: "skip",
                boxLabel: a("explorer", "skip"),
                name: "writestrategy",
                inputValue: "skip",
                checked: true
            }), new SYNO.ux.DisplayField({
                style: "width: 13px",
                fieldLabel: "",
                value: "&nbsp;",
                htmlEncode: false
            }), new SYNO.ux.Radio({
                itemId: "overwrite",
                boxLabel: a("explorer", "overwrite"),
                name: "writestrategy",
                inputValue: "overwrite"
            })];
            this.callParent(arguments)
        },
        initEvents: function() {
            this.callParent(arguments);
            this.mon(this, "beforeexpandnode", this.onBeforeExpandNode, this)
        },
        onBeforeExpandNode: function(b) {
            if (b.attributes.exceedLimit) {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), String.format(SYNO.SDS.Backup.String("app", "node_exceed_display_limit"), b.text, this.folderDisplayLimit));
                return false
            }
        }
    })
})();
