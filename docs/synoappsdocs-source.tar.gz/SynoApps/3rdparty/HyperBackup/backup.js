/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.Backup.Task.SubPanel
 * @extends Ext.Panel
 * HyperBackup task sub panel
 *
 */
Ext.define("SYNO.SDS.Backup.Task.SubPanel", {
    extend: "Ext.Panel",
    constructor: function(a) {
        a = this.fillConfig(a);
        this.callParent(arguments)
    },
    fillConfig: function(a) {
        return Ext.apply({
            cls: "syno-backup-task-subpanel",
            buttonAlign: "left"
        }, a)
    },
    setHeaderStatus: function(f, a, e) {
        var d = this.header;
        var c = d.child("span.dest-status-text");
        if (c) {
            Ext.fly(c).setStyle("color", a);
            Ext.fly(c).update(f);
            if (!Ext.isEmpty(e)) {
                c.dom.setAttribute("ext:qtip", e)
            } else {
                c.dom.removeAttribute("ext:qtip")
            }
        } else {
            var b = d.child("span." + this.headerTextCls);
            if (b) {
                var g = Ext.DomHelper.insertAfter(b.dom, {
                    tag: "span",
                    cls: "dest-status-text",
                    style: "color:" + a,
                    html: f
                });
                if (!Ext.isEmpty(e)) {
                    g.setAttribute("ext:qtip", e)
                }
            }
        }
    },
    setHeaderLock: function(d) {
        var c = this.header;
        var b = "data-enc-lock";
        var a = c.child("span." + b);
        if (!a) {
            Ext.DomHelper.append(c.dom, {
                tag: "span",
                cls: b,
                "ext:qtip": d ? SYNO.SDS.Backup.String("app", "enc_lock_close") : SYNO.SDS.Backup.String("app", "enc_lock_open")
            });
            if (d) {
                c.child("span." + b).addClass("has-data-enc")
            }
        }
    }
});
Ext.define("SYNO.SDS.Backup.Task.MainPage", {
    extend: "SYNO.ux.Panel",
    border: false,
    constructor: function(a) {
        this.isOnline = undefined;
        this.taskState = a.taskState;
        this.taskStatus = a.taskStatus;
        this.taskLastResult = a.taskLastResult;
        this.statusPanel = null;
        this.cancelBtn = null;
        this.backupBtn = null;
        this.browseBtn = null;
        this.actionBtn = null;
        this.suspendedMenu = null;
        this.backingupMenu = null;
        this.statisticBtn = null;
        this.isSupportStatistics = true;
        this.suspendedMenuBtn = null;
        this.backingupMenuBtn = null;
        this.canCancel = true;
        this.destPanel = null;
        this.settingPanel = null;
        this.displayStatus = this.checkDisplayStatus();
        this.isDemoMode = _S("demo_mode");
        this.taskIcon = a.taskIcon;
        a = this.fillConfig(a);
        this.callParent(arguments)
    },
    getStatusPanel: function() {
        if (this.statusPanel) {
            return this.statusPanel
        }
        var a = ("suspended" === this.displayStatus) ? "suspended" : "idle";
        this.statusPanel = new Ext.Panel({
            cls: "syno-backup-task-status-panel",
            buttonAlign: "left",
            height: 208,
            bwrapStyle: "height: 178px",
            items: [{
                itemId: "statusText",
                data: {
                    status: this.taskIcon,
                    text: _T("common", "loading")
                },
                tpl: '<div class="task-status-text task-status-text-{status}">{text}</div>'
            }, {
                xtype: "container",
                itemId: "statusCard",
                layout: "card",
                activeItem: a,
                items: [{
                    itemId: "idle",
                    cls: "syno-backup-task-status-idle-panel",
                    xtype: "container",
                    items: [{
                        itemId: "errorText",
                        data: {
                            errorText: _T("common", "loading"),
                            isShowError: false
                        },
                        tpl: '<div class="tip-text {cls}" <tpl if="!isShowError">style="display:none"</tpl> >{errorText}</div>'
                    }, {
                        itemId: "timeText",
                        data: {
                            lastBkpTime: _T("common", "loading"),
                            nextBkpTime: _T("common", "loading")
                        },
                        tpl: '<div class="bkp-time-text">' + _T("usbbackup", "usbbkp_lasttime") + ': {lastBkpTime}</div><div class="bkp-time-text">' + _T("backup", "next_bkp_time") + ": {nextBkpTime}</div>"
                    }]
                }, {
                    itemId: "active",
                    cls: "syno-backup-task-status-active-panel",
                    xtype: "container",
                    items: [{
                        itemId: "progress",
                        data: {
                            isShowPercentage: false,
                            description: "",
                            speed: "",
                            percentage: 0,
                            bottom_description: "",
                            scan_file: ""
                        },
                        tpl: new Ext.XTemplate('<div class="progress-upper-row">{[this.upperText(values.description, values.speed)]}<span class="syno-backup-progress-percentage-text" <tpl if="!isShowPercentage">style="visibility:hidden"</tpl>>{percentage}%</span></div><div class="syno-backup-percentage-bar-bg" <tpl if="!isShowPercentage">style="visibility:hidden"</tpl>><div class="syno-backup-percentage-bar" style="width:{percentage* 4.2}px"></div></div><div class="progress-bottom-row"><span <tpl if="!isShowPercentage">style="visibility:hidden"</tpl> ext:qtip="{[this.bottomText(values.bottom_description, values.scan_file)]}">{[this.bottomText(values.bottom_description, values.scan_file)]}</tpl>{scan_file}</span></div>', {
                            upperText: function(d, c) {
                                var b = d ? d : "";
                                if (c) {
                                    b += "<br>";
                                    b += SYNO.SDS.Backup.String("app", "speed") + _T("common", "colon") + c
                                }
                                return String.format('<span class="upper-row-desc-text" ext:qtip="{0}">{1}</span>', b, d)
                            },
                            bottomText: function(b, c) {
                                b = b ? b : "";
                                c = c ? c : "";
                                if (b && c) {
                                    return b + ",&nbsp" + c
                                }
                                return b + c
                            }
                        })
                    }]
                }, {
                    itemId: "suspended",
                    cls: "syno-backup-task-status-suspend-panel",
                    xtype: "container",
                    items: [{
                        itemId: "errorText",
                        data: {
                            errorText: _T("common", "loading"),
                            isShowError: false
                        },
                        tpl: '<div class="tip-text task-status-text-failed" <tpl if="!isShowError">style="display:none"</tpl> >{errorText}</div>'
                    }, {
                        itemId: "progress",
                        data: {
                            isShowPercentage: true,
                            percentage: 0
                        },
                        tpl: '<div class="progress-upper-row"><span class="syno-backup-progress-percentage-text" <tpl if="!isShowPercentage">style="visibility:hidden"</tpl>>{percentage}%</span></div><div class="syno-backup-percentage-bar-bg" <tpl if="!isShowPercentage">style="visibility:hidden"</tpl>><div class="syno-backup-percentage-bar" style="width:{percentage* 4.2}px"></div></div>'
                    }, {
                        itemId: "timeText",
                        data: {
                            nextBkpTime: _T("common", "loading")
                        },
                        tpl: "<div>" + _T("backup", "next_bkp_time") + ": {nextBkpTime}</div>"
                    }]
                }]
            }],
            buttons: [this.suspendedMenuBtn = new Ext.Container({
                hidden: ("suspended" === a && "backupable" === this.taskState) ? false : true,
                cls: "syno-backup-container-menu",
                items: [this.suspendedMenu = new SYNO.ux.Button({
                    text: SYNO.SDS.Backup.String("app", "backingup_action_menu"),
                    disabled: true,
                    cls: "syno-backup-button-menu",
                    menu: {
                        xtype: "syno_menu",
                        items: [{
                            itemId: "btn_resume",
                            text: SYNO.SDS.Backup.String("app", "resume_button_title"),
                            scope: this,
                            disabled: true,
                            handler: this.onResumeNow
                        }, {
                            itemId: "btn_discard",
                            text: SYNO.SDS.Backup.String("app", "discard_button_title"),
                            scope: this,
                            disabled: true,
                            handler: this.onDiscard
                        }]
                    }
                }), {
                    xtype: "box",
                    height: 28,
                    width: 1,
                    cls: "syno-backup-box"
                }]
            }), this.backingupMenuBtn = new Ext.Container({
                hidden: true,
                cls: "syno-backup-container-menu",
                items: [this.backingupMenu = new SYNO.ux.Button({
                    text: SYNO.SDS.Backup.String("app", "backingup_action_menu"),
                    disabled: true,
                    cls: "syno-backup-button-menu",
                    menu: {
                        xtype: "syno_menu",
                        items: [{
                            itemId: "btn_suspend",
                            text: SYNO.SDS.Backup.String("app", "suspend_button_title"),
                            scope: this,
                            disabled: true,
                            handler: this.onSuspendBackup
                        }, {
                            itemId: "btn_cancel",
                            text: _T("common", "cancel"),
                            scope: this,
                            disabled: true,
                            handler: this.onCancelBackup
                        }, {
                            itemId: "btn_cancel_discard",
                            text: SYNO.SDS.Backup.String("app", "discard_button_title"),
                            scope: this,
                            disabled: false,
                            handler: this.onCancelAndDiscard
                        }]
                    }
                }), {
                    xtype: "box",
                    height: 28,
                    width: 1,
                    cls: "syno-backup-box"
                }]
            }), this.backupBtn = new SYNO.ux.Button({
                btnStyle: "blue",
                text: SYNO.SDS.Backup.String("app", "backup_button_title"),
                hidden: ("idle" === a && "backupable" === this.taskState) ? false : true,
                scope: this,
                handler: this.onBackupNow
            }), this.cancelBtn = new SYNO.ux.Button({
                text: _T("common", "cancel"),
                hidden: true,
                scope: this,
                handler: this.onCancelBackup
            }), this.importBtn = new SYNO.ux.Button({
                btnStyle: "blue",
                text: SYNO.SDS.Backup.String("app", "relink_button_title"),
                scope: this,
                hidden: ("importable" === this.taskStatus) ? false : true,
                handler: this.onImportNow
            }), this.relinkBtn = new SYNO.ux.Button({
                btnStyle: "blue",
                text: SYNO.SDS.Backup.String("app", "relink_button_title"),
                scope: this,
                hidden: ("relinkable" === this.taskStatus) ? false : true,
                handler: this.onRelinkNow
            }), this.exportBtn = new SYNO.ux.Button({
                btnStyle: "blue",
                text: SYNO.SDS.Backup.String("app", "export_button_title"),
                scope: this,
                handler: this.onBackupNow,
                hidden: ("exportable" === this.taskStatus) ? false : true
            }), this.reauthBtn = new SYNO.ux.Button({
                btnStyle: "blue",
                text: SYNO.SDS.Backup.String("app", "reauth_button_title"),
                scope: this,
                handler: this.onReauthNow,
                hidden: ("unauth" === this.taskStatus) ? false : true
            }), this.browseBtn = new SYNO.ux.Button({
                iconCls: "syno-backup-button-icon syno-backup-browse-icon",
                tooltip: SYNO.SDS.Backup.String("app", "backup_explorer"),
                hidden: !this.isImage,
                width: 30,
                scope: this,
                handler: this.onVersionBrowse
            }), this.statisticBtn = new SYNO.ux.Button({
                iconCls: "syno-backup-button-icon syno-backup-statistics-icon",
                tooltip: SYNO.SDS.Backup.String("statistics", "storage_statistics_title"),
                hidden: !this.isImage,
                width: 30,
                scope: this,
                handler: this.onStatisticBrowse
            }), this.actionBtn = new SYNO.ux.SplitButton({
                iconCls: "syno-backup-button-icon syno-backup-action-icon",
                handler: function() {
                    this.showMenu()
                },
                menu: {
                    xtype: "syno_menu",
                    items: [{
                        itemId: "btn_edit",
                        text: _T("common", "alt_edit"),
                        disabled: true,
                        scope: this,
                        handler: this.onEditBackupTask
                    }, {
                        itemId: "btn_delete",
                        tooltip: this.isDemoMode ? _JSLIBSTR("uicommon", "error_demo") : "",
                        text: _T("common", "delete"),
                        scope: this,
                        handler: this.onDeleteBackupTask
                    }, {
                        itemId: "btn_check",
                        text: SYNO.SDS.Backup.String("app", "detect_button"),
                        disabled: true,
                        scope: this,
                        handler: this.onDetectTarget
                    }]
                }
            })]
        });
        return this.statusPanel
    },
    getDestPanel: function() {
        if (this.destPanel) {
            return this.destPanel
        }
        this.destPanel = new SYNO.SDS.Backup.Task.SubPanel({
            flex: 296,
            margins: "0 17 4 0",
            title: _T("netbackup", "netbkp_target"),
            items: this.destView = new Ext.DataView({
                store: this.destStore = new Ext.data.JsonStore({
                    autoDestroy: true,
                    fields: ["key", "text", "tip"],
                    data: this.getDestData(),
                    listeners: {
                        load: this.destEllipsisSetOnLoad,
                        scope: this
                    }
                }),
                itemSelector: "table",
                tpl: new Ext.XTemplate('<tpl for=".">', '<table style="width:100%;border-spacing: 0px;table-layout:fixed;">', '<tr class="detail-row">', '<td style="width:46%" valign="top"><div class="detail-key">{key}:</div></td>', '<td style="width:8%"></td>', '<td style="width:46%" valign="top"><div class="detail-value" ext:qtip="{tip:htmlEncode}">{text}</div></td>', "</tr>", "</table>", "</tpl>")
            }),
            listeners: {
                resize: this.destEllipsisSetOnResize,
                scope: this
            },
            buttons: [{
                xtype: "syno_button",
                text: SYNO.SDS.Backup.String("app", "version_list"),
                hidden: !this.isImage,
                scope: this,
                handler: this.onVersionList
            }]
        });
        return this.destPanel
    },
    getSettingPanel: function() {
        if (this.settingPanel) {
            return this.settingPanel
        }
        this.settingPanel = new SYNO.SDS.Backup.Task.SubPanel({
            flex: 330,
            margins: "0 0 4 0",
            title: _T("schedule", "task_settings"),
            items: this.settingView = new Ext.DataView({
                store: this.settingStore = new Ext.data.JsonStore({
                    autoDestroy: true,
                    fields: ["key", "text", "link_text", "handle_fn"],
                    data: this.getSettingData(),
                    listeners: {
                        load: this.settingEllipsisSetOnLoad,
                        scope: this
                    }
                }),
                itemSelector: "table",
                tpl: new Ext.XTemplate('<tpl for=".">', '<table style="width:100%;border-spacing: 0px;table-layout:fixed;">', '<tr class="detail-row">', '<td style="width:42%" valign="top"><div class="detail-key">{key}:</div></td>', '<td style="width:7%"></td>', '<td style="width:51%" valign="top"><div class="detail-value" ext:qtip="{text:htmlEncode}">{text}&nbsp;<span class="detail-value-link {handle_fn}">{link_text}</span></div></td>', "</tr>", "</table>", "</tpl>")
            }),
            listeners: {
                resize: this.settingEllipsisSetOnResize,
                scope: this
            },
            buttons: [{
                xtype: "syno_button",
                text: _T("schedule", "task_settings"),
                disabled: true,
                scope: this,
                handler: this.onEditBackupTask
            }]
        });
        return this.settingPanel
    },
    settingEllipsisSetOnResize: function() {
        this.viewComponentEllipsisSet(this.settingView, 3, false)
    },
    settingEllipsisSetOnLoad: function() {
        this.settingClickHandler(this.settingView);
        this.viewComponentEllipsisSet(this.settingView, 3, true)
    },
    destEllipsisSetOnResize: function() {
        this.viewComponentEllipsisSet(this.destView, 2, false)
    },
    destEllipsisSetOnLoad: function() {
        this.viewComponentEllipsisSet(this.destView, 2, true)
    },
    viewComponentEllipsisSet: function(b, e, f) {
        if (!b) {
            return
        }
        var d = b.getTemplateTarget();
        var c = d.parent("div");
        var a = 207;
        e += Math.floor((c.getHeight() - a) / 18);
        Ext.each(Ext.query("div.detail-key", d.dom), function(g) {
            if (f) {
                g.originInnerHTML = g.innerHTML
            }
            this.textEllipseSet(g, 18, e)
        }, this)
    },
    textEllipseSet: function(e, k, h) {
        if (Ext.isDefined(e.originInnerHTML)) {
            e.innerHTML = e.originInnerHTML
        }
        if (e.offsetHeight <= k * h) {
            return
        }
        var a = 0;
        var c = "";
        var b = "";
        var g = [],
            m = [];
        var l = e.innerHTML.match(/(^<[^>]*>)([^<]*)(<\/[^>]*>$)/);
        if (null !== l) {
            m.push(l[1]);
            g = l[2].split(" ");
            m.push(l[3])
        } else {
            g = e.innerHTML.split(" ")
        }
        e.innerHTML = "";
        Ext.each(g, function(j, i) {
            a = i;
            e.innerHTML += (j + " ");
            if (e.offsetHeight > k * (h - 1)) {
                return false
            }
        });
        for (var f = 0; f < a; f++) {
            c += (g[f] + " ")
        }
        for (var d = a; d < g.length; d++) {
            b += (g[d] + " ")
        }
        e.innerHTML = c + '<div style="white-space: nowrap; text-overflow: ellipsis; overflow:hidden;">' + b + "</div>";
        if (2 === m.length) {
            e.innerHTML = m[0] + e.innerHTML + m[1]
        }
    },
    fillConfig: function(a) {
        return Ext.apply({
            cls: "syno-backup-task-main-page",
            layout: "border",
            border: false,
            items: [{
                region: "north",
                height: 208,
                xtype: "container",
                cls: "syno-backup-task-status-wrapper",
                layout: "hbox",
                items: [{
                    xtype: "container",
                    width: 92,
                    items: [this.statusIcon = new Ext.Component({
                        data: {
                            status: this.taskIcon
                        },
                        tpl: '<div class= "task-status-icon task-status-icon-{status}"/>'
                    })]
                }, {
                    border: false,
                    xtype: "container",
                    layout: "fit",
                    flex: 1,
                    items: [this.getStatusPanel()]
                }]
            }, {
                region: "center",
                xtype: "container",
                margins: "16 0 13 0",
                layout: {
                    type: "hbox",
                    align: "stretch"
                },
                items: [this.getDestPanel(), this.getSettingPanel()]
            }]
        }, a)
    },
    setTaskStatus: function(a, i, n, h, c, e, f, k) {
        this.taskStatus = i;
        this.taskState = a;
        this.taskLastResult = h;
        this.displayStatus = this.checkDisplayStatus();
        this.setDetailLinkVisibility();
        this.setBtnStatus();
        var j = SYNO.SDS.Backup.getStatusIcon(a, i, h, f, k);
        var m = SYNO.SDS.Backup.getStatusText(a, i, h, f, k);
        var b = SYNO.SDS.Backup.getStatusSubText(a, i, h, c, e, f);
        var g = false;
        this.statusIcon.update({
            status: j
        });
        this.owner.setTaskStatusIcon(j);
        this.getStatusPanel().getComponent("statusText").update({
            status: j,
            text: m
        });
        if ("suspended" === this.displayStatus) {
            this.getStatusPanel().getComponent("statusCard").layout.setActiveItem("suspended");
            g = (b === "none") ? false : true;
            if (g) {
                b += ' <a class="syno-backup-log-detail-link">(' + SYNO.SDS.Backup.String("app", "status_detailed_log") + ")</a>";
                this.setErrDetailedLogLink("suspended")
            }
            this.getStatusPanel().getComponent("statusCard").getComponent("suspended").getComponent("errorText").update({
                errorText: b,
                isShowError: g
            })
        } else {
            if ("idle" === this.displayStatus) {
                this.getStatusPanel().getComponent("statusCard").layout.setActiveItem("idle");
                if ("partial" === h && this.isImage && true !== f) {
                    b = (b === "none") ? SYNO.SDS.Backup.String("app", "partial_success") : b;
                    b += " <a class='syno-backup-version-detail-link'>(" + SYNO.SDS.Backup.String("app", "version_detail") + ")</a>"
                }
                if (this.getStatusPanel().getComponent("statusCard").getComponent("idle").getComponent("errorText").body) {
                    var d = "task-status-text-failed";
                    if (this.taskState === "restore_only") {
                        d = "task-status-text-restoreonly";
                        b = (b === "none") ? SYNO.SDS.Backup.String("error", "status_target_broken") : b;
                        b += " <a class='syno-backup-version-detail-link'>(" + SYNO.SDS.Backup.String("app", "download_damage_report") + ")</a>"
                    } else {
                        if (h === "partial") {
                            d = "task-status-text-partial"
                        }
                    }
                    g = (b === "none") ? false : true;
                    if (("backupable" === this.taskState || "exportable" === this.taskState) && ("suspend" === this.taskLastResult || "failed" === this.taskLastResult) && g) {
                        b += ' <a class="syno-backup-log-detail-link">(' + SYNO.SDS.Backup.String("app", "status_detailed_log") + ")</a>";
                        this.setErrDetailedLogLink("idle")
                    }
                    this.getStatusPanel().getComponent("statusCard").getComponent("idle").getComponent("errorText").update({
                        errorText: b,
                        isShowError: g,
                        cls: d
                    });
                    if (this.isImage) {
                        var l = this.getStatusPanel().getComponent("statusCard").getComponent("idle").getComponent("errorText").getEl();
                        if (this.taskState === "restore_only") {
                            this.registerErrorText(l, "download_report")
                        } else {
                            if ("partial" === h) {
                                this.registerErrorText(l, "partial_detail")
                            }
                        }
                    }
                }
            } else {
                if ("active" === this.displayStatus) {
                    this.getStatusPanel().getComponent("statusCard").layout.setActiveItem("active")
                }
            }
        }
    },
    registerErrorText: function(c, b) {
        if (!c) {
            return
        }
        var a = {
            download_report: this.downloadDamageReport,
            partial_detail: this.checkDetailLink,
            error_log: this.openErrFilteredLogWindow
        };
        Ext.iterate(a, function(e, d) {
            c.un("click", d, this);
            if (e === b) {
                c.on("click", d, this)
            }
        }, this)
    },
    setProgress: function(a) {
        this.getStatusPanel().getComponent("statusCard").getComponent("active").getComponent("progress").update(a)
    },
    setSuspendedProgress: function(a) {
        this.getStatusPanel().getComponent("statusCard").getComponent("suspended").getComponent("progress").update(a)
    },
    setIsOnline: function(b, a) {
        this.isOnline = b;
        if (b) {
            this.getDestPanel().setHeaderStatus(" - " + _T("usbbackup", "usbbkp_online"), "#1CA600", a)
        } else {
            this.getDestPanel().setHeaderStatus(" - " + _T("usbbackup", "usbbkp_offline"), "#D94141", a)
        }
    },
    setErrDetailedLogLink: function(a) {
        var b = this.getStatusPanel().getComponent("statusCard").getComponent(a).getComponent("errorText").getEl();
        this.registerErrorText(b, "error_log")
    },
    getIsOnline: function() {
        return this.isOnline
    },
    setIsSupportStatistics: function(a) {
        this.isSupportStatistics = a;
        if (a) {
            this.statisticBtn.setTooltip(SYNO.SDS.Backup.String("statistics", "storage_statistics_title"))
        } else {
            this.statisticBtn.setTooltip(SYNO.SDS.Backup.String("error", "status_server_version_old"))
        }
    },
    isTaskNotRunning: function() {
        if (!this.taskStatus || !this.taskState) {
            return false
        }
        return ("none" === this.taskStatus || "discard_failed" === this.taskStatus || "wait_discard" === this.taskStatus)
    },
    inVersionDeleteSession: function() {
        return "preparing_version_delete" === this.taskStatus || "version_deleting" === this.taskStatus
    },
    isEnableBrowse: function() {
        return ((this.isTaskNotRunning() || "error_detect" === this.taskState || this.inVersionDeleteSession()) && !this.owner.isRestore() && this.getIsOnline() !== false && ("backupable" === this.taskState || "restore_only" === this.taskState || "error_detect" === this.taskState))
    },
    isEnableEdit: function() {
        if (!this.taskStatus || !this.taskState) {
            return false
        }
        var b = this.isTaskNotRunning();
        var a = ((b || this.inVersionDeleteSession()) && "backupable" === this.taskState) || "restore_only" === this.taskState || "unauth" === this.taskState || "error_detect" == this.taskState;
        return a
    },
    getIsSupportStatistics: function() {
        return this.isSupportStatistics
    },
    loadDestData: function(a) {
        this.destStore.loadData(this.getDestData(a))
    },
    loadSettingData: function(a) {
        this.settingStore.loadData(this.getSettingData(a));
        if (this.isImage) {
            this.getSettingPanel().setHeaderLock(a.data_enc)
        }
    },
    getScheduleStr: function(a) {
        return SYNO.SDS.Backup.Client.Common.Utils.getScheduleStr(a)
    },
    getLastBkpTextCls: function(a) {
        return ""
    },
    getDisplayTimeText: function(a) {
        var b = SYNO.SDS.Backup.Client.Common.Utils.getDSMStyleDateTimeString(a);
        return b ? b : a
    },
    setBkpTime: function(c, b, d) {
        var a = this.getStatusPanel().getComponent("statusCard").layout.activeItem.itemId;
        if ("idle" === a) {
            this.getStatusPanel().getComponent("statusCard").getComponent("idle").getComponent("timeText").update({
                lastBkpTime: c ? '<span class="' + this.getLastBkpTextCls(d) + '">' + this.getDisplayTimeText(c) + "</span>" : SYNO.SDS.Backup.String("app", "localbkp_not_bkp"),
                nextBkpTime: b ? this.getDisplayTimeText(b) : _T("common", "none")
            })
        } else {
            if ("suspended" === a) {
                this.getStatusPanel().getComponent("statusCard").getComponent("suspended").getComponent("timeText").update({
                    nextBkpTime: b ? this.getDisplayTimeText(b) : _T("common", "none")
                })
            }
        }
    },
    setBtnStatus: function() {
        if (!this.taskStatus || !this.taskState) {
            return
        }
        var g = this.owner.isRestore();
        var d = this.owner.isSnapShotRestore();
        this.enableBackup("backupable" === this.taskState && "none" === this.taskStatus && !g && this.getIsOnline() !== false && "backingup" !== this.taskLastResult && "resuming" !== this.taskLastResult, d);
        this.enableRelink("relinkable" === this.taskState && "none" === this.taskStatus && !g);
        this.enableImport("importable" === this.taskState && "none" === this.taskStatus && !g);
        this.enableExport("exportable" === this.taskState && "none" === this.taskStatus && !g && this.getIsOnline() !== false);
        this.enableReauth("none" === this.taskStatus && !g);
        this.enableCancel((("waiting" === this.taskStatus) || ("relink_waiting" === this.taskStatus) || ("syncing" === this.taskStatus) || ("backup" === this.taskStatus && "backupable" === this.taskState && (!this.isImage || this.canCancel)) || ("relink" === this.taskStatus && "relinkable" === this.taskState) || ("backup" === this.taskStatus && "exportable" === this.taskState) || ("detect" === this.taskStatus && "error_detect" === this.taskState)) && "resuming" !== this.taskLastResult);
        var e = this.isTaskNotRunning();
        var b = this.isEnableEdit();
        this.enableEdit(b);
        var a = ((e || "error_detect" === this.taskState) && !g && !this.isDemoMode);
        this.enableDelete(a);
        var f = ("none" === this.taskStatus && "backupable" === this.taskState && this.isImage && this.getIsOnline() !== false);
        this.enableCheck(f);
        this.actionBtn.setDisabled(!b && !a && !f);
        var c = ("discard" === this.taskLastResult || "discard_failed" === this.taskStatus);
        if ("importable" === this.taskState) {
            this.displayRunningOrIdle(this.importBtn);
            this.suspendedMenuBtn.hide();
            this.backupBtn.hide();
            this.relinkBtn.hide();
            this.exportBtn.hide();
            this.reauthBtn.hide()
        } else {
            if ("relinkable" === this.taskState) {
                this.displayRunningOrIdle(this.relinkBtn);
                this.suspendedMenuBtn.hide();
                this.backupBtn.hide();
                this.importBtn.hide();
                this.exportBtn.hide();
                this.reauthBtn.hide()
            } else {
                if ("exportable" === this.taskState) {
                    this.backupBtn.hide();
                    this.importBtn.hide();
                    this.relinkBtn.hide();
                    this.reauthBtn.hide();
                    if ("suspend" === this.taskLastResult) {
                        this.exportBtn.hide();
                        this.displayRunningOrIdle(this.suspendedMenuBtn)
                    } else {
                        if (c) {
                            this.exportBtn.hide();
                            this.suspendedMenuBtn.show();
                            this.backingupMenuBtn.hide();
                            this.cancelBtn.hide()
                        } else {
                            this.suspendedMenuBtn.hide();
                            this.displayRunningOrIdle(this.exportBtn)
                        }
                    }
                } else {
                    if ("broken" === this.taskState) {
                        this.displayRunningOrIdle(null);
                        this.suspendedMenuBtn.hide();
                        this.backupBtn.hide();
                        this.importBtn.hide();
                        this.relinkBtn.hide();
                        this.exportBtn.hide();
                        this.reauthBtn.hide()
                    } else {
                        if ("unauth" === this.taskState) {
                            this.displayRunningOrIdle(this.reauthBtn);
                            this.suspendedMenuBtn.hide();
                            this.backupBtn.hide();
                            this.importBtn.hide();
                            this.relinkBtn.hide();
                            this.exportBtn.hide()
                        } else {
                            if ("backupable" === this.taskState) {
                                this.importBtn.hide();
                                this.relinkBtn.hide();
                                this.exportBtn.hide();
                                this.reauthBtn.hide();
                                if ("suspend" === this.taskLastResult) {
                                    this.backupBtn.hide();
                                    this.displayRunningOrIdle(this.suspendedMenuBtn)
                                } else {
                                    if (c) {
                                        this.backupBtn.hide();
                                        this.suspendedMenuBtn.show();
                                        this.backingupMenuBtn.hide();
                                        this.cancelBtn.hide()
                                    } else {
                                        this.suspendedMenuBtn.hide();
                                        this.displayRunningOrIdle(this.backupBtn)
                                    }
                                }
                            } else {
                                if ("error_detect" === this.taskState) {
                                    this.suspendedMenuBtn.hide();
                                    this.backingupMenuBtn.hide();
                                    this.backupBtn.hide();
                                    this.cancelBtn.show();
                                    this.importBtn.hide();
                                    this.relinkBtn.hide();
                                    this.exportBtn.hide();
                                    this.reauthBtn.hide()
                                } else {
                                    if ("restore_only" === this.taskState) {
                                        this.suspendedMenuBtn.hide();
                                        this.backingupMenuBtn.hide();
                                        this.backupBtn.hide();
                                        this.cancelBtn.hide();
                                        this.importBtn.hide();
                                        this.relinkBtn.hide();
                                        this.exportBtn.hide();
                                        this.reauthBtn.hide()
                                    } else {
                                        this.suspendedMenuBtn.hide();
                                        this.backingupMenuBtn.hide();
                                        this.backupBtn.show();
                                        this.cancelBtn.hide();
                                        this.importBtn.hide();
                                        this.relinkBtn.hide();
                                        this.exportBtn.hide();
                                        this.reauthBtn.hide()
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    },
    checkDetailLink: function(c, a, d) {
        var b = Ext.fly(c.target);
        if (b.hasClass("syno-backup-version-detail-link")) {
            this.launchDetailWindow()
        }
    },
    downloadDamageReport: function(c, a, f) {
        var b = Ext.fly(c.target);
        if (!b.hasClass("syno-backup-version-detail-link")) {
            return false
        }
        var d = {
            support_utf8_name: Ext.isChrome || Ext.isGecko || Ext.isSafari,
            task_id: this.taskId
        };
        this.findAppWindow().downloadWebAPI({
            filename: "error_report.txt",
            webapi: {
                api: "SYNO.Backup.Target",
                version: 1,
                method: "damage_report_download",
                params: d
            },
            scope: this,
            callback: function(h, g, i, e) {
                if (!i && e) {
                    this.appWin.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(e.code), function() {}, this);
                    return
                }
            }
        })
    },
    checkDisplayStatus: function() {
        if ("backupable" === this.taskState && "none" === this.taskStatus && "suspend" === this.taskLastResult) {
            return "suspended"
        } else {
            if (("none" === this.taskStatus && "error_detect" !== this.taskState) || "restore" === this.taskStatus || "discard_failed" === this.taskStatus || "wait_discard" === this.taskStatus || "version_delete_fail" === this.taskStatus || "wait_version_delete" === this.taskStatus) {
                return "idle"
            } else {
                return "active"
            }
        }
    },
    launchDetailWindow: function() {
        var a = new SYNO.SDS.Backup.Client.Common.ErrorReportWindow({
            task_id: this.taskId,
            owner: this.owner
        });
        a.open()
    },
    enableEdit: function(a) {
        this.getSettingPanel().buttons[0].setDisabled(!a);
        this.actionBtn.menu.getComponent("btn_edit").setDisabled(!a)
    },
    enableDelete: function(a) {
        this.actionBtn.menu.getComponent("btn_delete").setDisabled(!a)
    },
    enableCheck: function(a) {
        this.actionBtn.menu.getComponent("btn_check").setDisabled(!a)
    },
    enableBackup: function(a, b) {
        this.backupBtn.setDisabled(!a);
        if (b) {
            this.backupBtn.setTooltip(SYNO.SDS.Backup.String("app", "bkp_disabled_by_restore_snapshot"))
        } else {
            this.backupBtn.setTooltip("")
        }
    },
    enableRelink: function(a) {
        this.relinkBtn.setDisabled(!a)
    },
    enableImport: function(a) {
        this.importBtn.setDisabled(!a)
    },
    enableExport: function(a) {
        this.exportBtn.setDisabled(!a)
    },
    enableReauth: function(a) {
        this.reauthBtn.setDisabled(!a)
    },
    enableCancel: function(a) {
        this.cancelBtn.setDisabled(!a);
        this.backingupMenu.menu.getComponent("btn_cancel").setDisabled(!a)
    },
    openWindow: function(a) {
        this.appWin.openWindow(a)
    },
    openErrFilteredLogWindow: function(f, c, g) {
        var d = Ext.fly(f.target);
        if (!d.hasClass("syno-backup-log-detail-link")) {
            return
        }
        var a = this.owner.getCurrentTask();
        var b = new SYNO.SDS.Backup.Client.Common.Log.LogsWindow({
            appWin: this.owner,
            jsConfig: this.owner.jsConfig,
            owner: this.owner,
            filterParams: {
                filter_keyword: a.name,
                filter_level: "3"
            }
        });
        this.openWindow(b)
    },
    onPageActivate: function() {
        this.setBtnStatus();
        this.updatePageData()
    },
    onPageDeactivate: function() {
        this.stopUpdatePageData()
    },
    updatePageData: function() {
        this.loadStaticData();
        this.onStartPolling()
    },
    stopUpdatePageData: function() {
        this.onStopPolling()
    },
    onCancelBackup: function() {
        this.appWin.getMsgBox().confirm(_T("tree", "leaf_backup"), SYNO.SDS.Backup.String("app", "backup_confirm_cancel_task"), function(a) {
            if (a !== "yes") {
                return
            }
            if ("none" === this.taskStatus) {
                return
            }
            if ("error_detect" === this.taskState) {
                this.doCancelErrorDetect()
            } else {
                this.doCancelBackup()
            }
        }, this)
    },
    onSuspendBackup: function() {
        this.appWin.getMsgBox().confirm(_T("tree", "leaf_backup"), SYNO.SDS.Backup.String("app", "backup_confirm_suspend_task"), function(a) {
            if (a !== "yes") {
                return
            }
            if ("none" === this.taskStatus) {
                return
            }
            this.doSuspendBackup()
        }, this)
    },
    onCancelAndDiscard: function() {
        this.appWin.getMsgBox().confirm(_T("tree", "leaf_backup"), SYNO.SDS.Backup.String("app", "backup_confirm_discard"), function(a) {
            if (a !== "yes") {
                return
            }
            if ("backingup" === this.taskStatus) {
                return
            }
            this.doCancelAndDiscard()
        }, this)
    },
    onDiscard: function() {
        this.appWin.getMsgBox().confirm(_T("tree", "leaf_backup"), SYNO.SDS.Backup.String("app", "backup_confirm_discard"), function(a) {
            if (a !== "yes") {
                return
            }
            if ("none" !== this.taskStatus && "discard_failed" !== this.taskStatus) {
                return
            }
            this.doDiscard()
        }, this)
    },
    displayRunningOrIdle: function(a) {
        if ("idle" === this.displayStatus || "suspended" === this.displayStatus) {
            if (a) {
                a.show()
            }
            this.cancelBtn.hide();
            this.backingupMenuBtn.hide()
        } else {
            if (a) {
                a.hide()
            }
            if (this.isImage && ("backupable" === this.taskState || "exportable" === this.taskState)) {
                this.cancelBtn.hide();
                this.backingupMenuBtn.show()
            } else {
                this.cancelBtn.show();
                this.backingupMenuBtn.hide()
            }
        }
    },
    getDestData: function() {
        return []
    },
    getSettingData: function() {
        return []
    },
    setDetailLinkVisibility: function() {},
    settingClickHandler: function(a) {},
    loadStaticData: function() {},
    onStartPolling: function() {},
    onStopPolling: function() {},
    onEditBackupTask: function() {},
    onDeleteBackupTask: function() {},
    onDetectTarget: function() {},
    doCancelBackup: function() {},
    doCancelAndDiscard: function() {},
    doCancelErrorDetect: function() {},
    doBackupSuspend: function() {},
    doDiscard: function() {},
    onBackupNow: function() {},
    onResumeNow: function() {},
    onImportNow: function() {},
    onRelinkNow: function() {},
    onReauthNow: function() {},
    onStatisticBrowse: function() {},
    onVersionBrowse: function() {},
    onVersionList: function() {}
});
Ext.define("SYNO.SDS.Backup.EditSchedulePanel", {
    extend: "SYNO.SDS.TaskScheduler2.EditSchedulePanel",
    constructor: function(a) {
        this.blSupportErrorDetect = true;
        var b = Ext.apply({
            labelWidth: 250
        }, a);
        if (!b.isImage) {
            b.cls = "syno-backup-edit-schedule-panel-single";
            b.bwrapStyle = "padding: 0px 8px"
        }
        this.callParent([b])
    },
    initComponent: function() {
        this.items[0].title = "";
        this.items[1].title = "";
        this.items[0].items.unshift({
            xtype: "syno_radio",
            id: this.disable_id = Ext.id(),
            boxLabel: _T("backup", "schedule_disabled"),
            name: "date",
            inputValue: -1
        });
        if (this.isImage) {
            this.items[0].title = SYNO.SDS.Backup.String("app", "backup_schedule_title");
            this.items.push({
                xtype: "syno_fieldset",
                title: SYNO.SDS.Backup.String("app", "detect_schedule_title"),
                cls: "syno-backup-edit-field-set",
                collapsible: false,
                itemId: "incheck-panel",
                items: [this.incheckSchedule = new SYNO.SDS.Backup.IntegrityCheckSchedulePanel({
                    owner: this,
                    targetType: this.targetType,
                    containerLabelWidth: this.labelWidth
                })]
            })
        }
        this.callParent(arguments)
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(Ext.getCmp(this.disable_id), "check", this.onDisableChecked, this);
        delete Ext.getCmp(this.per_week_id).handler;
        this.mon(Ext.getCmp(this.per_week_id), "check", this.onWeekChecked, this);
        this.mon(Ext.getCmp(this.by_date_id), "check", this.onDateChecked, this);
        this.mon(this, "activate", this.addTips, this, {
            single: true
        })
    },
    addTips: function() {
        var a = this.getForm().findField("incheck_schedule_enable");
        if (a && a.getEl()) {
            SYNO.SDS.Utils.AddTip(a.getEl(), SYNO.SDS.Backup.String("app", "incheck_schedule_tip"))
        }
    },
    setData: function(a) {
        this.callParent([a.backup]);
        if (a.backup.schedule_enable) {
            if (0 === a.backup.date_type) {
                Ext.getCmp(this.disable_id).setValue(false)
            } else {
                Ext.getCmp(this.disable_id).setValue(false)
            }
        } else {
            Ext.getCmp(this.disable_id).setValue(true);
            Ext.getCmp(this.by_date_id).setValue(false);
            Ext.getCmp(this.per_week_id).setValue(false);
            Ext.getCmp(this.week_name_id).setDisabled(true);
            Ext.getCmp(this.date_id).setDisabled(true);
            Ext.getCmp(this.repeat_id).setDisabled(true);
            Ext.getCmp(this.hour_id).setDisabled(true);
            Ext.getCmp(this.min_id).setDisabled(true);
            Ext.getCmp(this.repeat_hour_id).setDisabled(true);
            Ext.getCmp(this.last_work_hour_id).setDisabled(true)
        }
        if (this.isImage && this.blSupportErrorDetect) {
            this.incheckSchedule.setData(a.incheck, a.support_detect_time_limit)
        }
    },
    getData: function() {
        var a = {
            backup: this.callParent()
        };
        if (this.isImage && this.blSupportErrorDetect) {
            a.incheck = this.incheckSchedule.getData()
        }
        a.backup.schedule_enable = (false === Ext.getCmp(this.disable_id).getValue());
        return a
    },
    onDisableChecked: function(b, a) {
        if (a) {
            Ext.getCmp(this.week_name_id).setDisabled(true);
            Ext.getCmp(this.date_id).setDisabled(true);
            Ext.getCmp(this.repeat_id).setDisabled(true);
            Ext.getCmp(this.hour_id).setDisabled(true);
            Ext.getCmp(this.min_id).setDisabled(true);
            Ext.getCmp(this.repeat_hour_id).setDisabled(true);
            Ext.getCmp(this.last_work_hour_id).setDisabled(true)
        }
    },
    onWeekChecked: function(b, a) {
        if (a) {
            Ext.getCmp(this.week_name_id).setDisabled(false);
            Ext.getCmp(this.date_id).setDisabled(true);
            Ext.getCmp(this.repeat_id).setDisabled(true);
            Ext.getCmp(this.hour_id).setDisabled(false);
            Ext.getCmp(this.min_id).setDisabled(false);
            Ext.getCmp(this.repeat_hour_id).setDisabled(false);
            Ext.getCmp(this.last_work_hour_id).setDisabled(false)
        }
    },
    onDateChecked: function(b, a) {
        if (a) {
            Ext.getCmp(this.week_name_id).setDisabled(true);
            Ext.getCmp(this.date_id).setDisabled(false);
            Ext.getCmp(this.repeat_id).setDisabled(false);
            Ext.getCmp(this.hour_id).setDisabled(false);
            Ext.getCmp(this.min_id).setDisabled(false);
            Ext.getCmp(this.repeat_hour_id).setDisabled(false);
            Ext.getCmp(this.last_work_hour_id).setDisabled(false)
        }
    },
    setSupportErrorDetect: function(a) {
        this.blSupportErrorDetect = a;
        if (a) {
            this.items.get(2).show()
        } else {
            this.items.get(2).hide();
            this.remove("incheck-panel")
        }
    }
});
Ext.define("SYNO.SDS.Backup.C2CloudEditSchedulePanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(a) {
        this.blSupportErrorDetect = true;
        this.simpleSchedule = new SYNO.SDS.Backup.SimpleScheduleComponent({
            canUnckeckSchedule: true,
            owner: this
        });
        var b = [];
        b.push({
            xtype: "syno_fieldset",
            title: SYNO.SDS.Backup.String("app", "backup_schedule_title"),
            collapsible: false,
            cls: "syno-backup-edit-field-set",
            items: [this.simpleSchedule]
        });
        b.push({
            xtype: "syno_fieldset",
            title: SYNO.SDS.Backup.String("app", "detect_schedule_title"),
            cls: "syno-backup-edit-field-set",
            collapsible: false,
            itemId: "incheck-panel",
            items: [this.incheckSchedule = new SYNO.SDS.Backup.IntegrityCheckSchedulePanel({
                owner: this,
                targetType: a.targetType
            })]
        });
        var c = Ext.apply({
            bwrapStyle: "padding: 8px 8px 0 8px;",
            labelWidth: 250,
            items: b
        }, a);
        this.callParent([c])
    },
    setData: function(a) {
        this.bkpSchedule = Ext.apply({}, a.backup);
        this.simpleSchedule.setData(this.bkpSchedule);
        if (this.blSupportErrorDetect) {
            this.incheckSchedule.setData(a.incheck, a.support_detect_time_limit)
        }
    },
    getData: function() {
        var c = this.simpleSchedule.getData();
        var b = {
            schedule_enable: c.schedule_enable,
            hour: c.hour,
            minute: c.min,
            last_work_hour: c.last_work_hour,
            week_day: c.week_name
        };
        b = Ext.apply(this.bkpSchedule, b);
        var a = {
            backup: b
        };
        if (this.blSupportErrorDetect) {
            a.incheck = this.incheckSchedule.getData()
        }
        return a
    },
    setSupportErrorDetect: function(a) {
        this.blSupportErrorDetect = a;
        if (a) {
            this.getComponent("incheck-panel").show()
        } else {
            this.remove("incheck-panel")
        }
    }
});
Ext.define("SYNO.SDS.Backup.RepoTypePanel", {
    extend: "SYNO.SDS.Backup.FormPanel",
    constructor: function(a) {
        var b = Ext.apply({
            tbar: this.initToolbar(),
            autoFlexcroll: false,
            height: 377,
            bodyStyle: "max-height: 377px; min-height: 377px; padding-top: 0px;",
            items: [{
                xtype: "container",
                collapsible: false,
                cls: "syno-backup-destination-button-ct",
                itemId: "repo_button_ct",
                items: this.getRepoButtonConfig()
            }]
        }, a);
        this.addonInfo = null;
        this.callParent([b]);
        this.initEvents()
    },
    initEvents: function() {
        this.mon(this.textFilter, "keyup", function(a, b) {
            var c = this.textFilter.getValue();
            this.getFilterRepoButton(c)
        }, this)
    },
    initToolbar: function() {
        this.textFilter = new SYNO.ux.TextFilter({
            width: 230,
            iconStyle: "filter",
            owner: this,
            onTriggerClick: function(b) {
                this.owner.getFilterRepoButton("");
                this.setValue("")
            }
        });
        var a = new SYNO.ux.Toolbar({
            textFilter: this.textFilter,
            style: {
                borderBottom: "0px",
                paddingTop: "12px"
            }
        });
        a.add("->");
        a.add(this.textFilter);
        return a
    },
    getFilterRepoButton: function(c) {
        this.unSelectAll();
        var a = (!c || c.length === 0) ? true : false;
        var b = this.getComponent("repo_button_ct");
        Ext.each(b.items.items, function(e, d) {
            e.removeAll();
            e.setHeight(0);
            e.hide()
        });
        b.setHeight(397);
        this.doLayout();
        b.setHeight("auto");
        Ext.each(b.items.items, function(e, d) {
            e.setHeight("auto")
        }, this);
        Ext.each(b.items.items, function(f, d) {
            var e = 0;
            var g = new Ext.Container();
            Ext.each(this.repoTypeButtons[f.category], function(j, h, i) {
                if (a || j.addonInfo.displayName.toUpperCase().includes(c.toUpperCase())) {
                    e += 1;
                    g.add(new SYNO.SDS.Backup.RepoTypeButton({
                        addonInfo: j.addonInfo,
                        title: j.addonInfo.displayName,
                        iconCls: j.addonInfo.destIconCls,
                        clickHandler: j.clickHandler,
                        hidden: j.hidden,
                        options: j.options
                    }))
                }
            }, this);
            if (e > 0) {
                f.add(g);
                f.show()
            } else {
                if (e === 0) {
                    f.hide()
                }
            }
        }, this);
        this.doLayout()
    },
    getRepoButtonConfig: function() {
        var b = {};
        Ext.each(SYNO.Backup.Addon.Config.addon_list, function(e, d) {
            if (this.isRepoDisplay(e)) {
                var c = new SYNO.SDS.Backup.RepoTypeButton({
                    addonInfo: e,
                    title: e.displayName,
                    iconCls: e.destIconCls,
                    clickHandler: Ext.createDelegate(this.selectDest, this),
                    options: e.options
                });
                if (!b[e.category]) {
                    b[e.category] = []
                }
                b[e.category].push(c)
            }
        }, this);
        if (!Ext.isEmpty(b.cloud)) {
            b.cloud.sort(function(e, c) {
                var d = /^[A-Za-z0-9]+/;
                var g = d.test(e.addonInfo.displayName);
                var f = d.test(c.addonInfo.displayName);
                if (g && f || !g && !f) {
                    if (e.addonInfo.displayName < c.addonInfo.displayName) {
                        return -1
                    } else {
                        if (e.addonInfo.displayName > c.addonInfo.displayName) {
                            return 1
                        } else {
                            return 0
                        }
                    }
                } else {
                    if (g && !f) {
                        return 1
                    } else {
                        return -1
                    }
                }
            })
        }
        var a = [];
        Ext.iterate(b, function(d, e) {
            var c = {
                xtype: "syno_fieldset",
                title: SYNO.SDS.Backup.String("app", "repo_field_" + d),
                category: d,
                cls: "syno-backup-destination-field",
                bodyStyle: this.getFieldHeightStyle(e.length),
                items: [{
                    xtype: "container",
                    items: []
                }]
            };
            Ext.each(e, function(g, f) {
                c.items[0].items.push(g)
            }, this);
            a.push(c)
        }, this);
        this.repoTypeButtons = b;
        return a
    },
    isRepoDisplay: function(a) {
        return !a.hidden
    },
    getFieldHeightStyle: function(a) {
        return "height:" + (41 * Math.ceil(a / 2)) + "px;"
    },
    selectDest: function(d, c) {
        var a = Ext.getCmp(c.id);
        var b = null;
        if (!a && c) {
            a = Ext.getCmp(c.parentNode.id)
        }
        Ext.each(this.getComponent("repo_button_ct").items.items, function(f, e) {
            if (f.get(0)) {
                Ext.each(f.get(0).items.items, function(g) {
                    g.removeClass("selected")
                }, this)
            }
        }, this);
        if (c.classList.contains("syno-backup-destination-button")) {
            b = a
        } else {
            if (a && a.ownerCt) {
                b = a.ownerCt
            } else {
                return
            }
        }
        b.addClass("selected");
        this.addonInfo = b.addonInfo
    },
    unSelectAll: function() {
        this.addonInfo = null
    },
    launchOAuthWindow: function(b) {
        var a = SYNO.Backup.Addon.Util.getOathWindowParams(b);
        if (!Ext.isObject(a)) {
            return false
        }
        if (!this.winAuth) {
            if (Ext.isIE || Ext.isIE11 || Ext.isIE10) {
                window.cbDSCS = this.authCB.createDelegate(this)
            } else {
                this.cbDSCS = this.receiveMessage.createDelegate(this);
                window.addEventListener("message", this.cbDSCS)
            }
        }
        this.winAuth = (window.open(encodeURI(a.url), "", a.specs));
        return true
    },
    authCB: function(a) {
        this.winAuth = null;
        if (!Ext.isEmpty(a.error)) {
            return
        }
        var b = this.getRepoType();
        this.owner.getStep(this.nextId[b.id]).setOauthResponse(a);
        this.owner.goNext(this.nextId[b.id])
    },
    receiveMessage: function(a) {
        if ("hyperbackup_oauth" !== a.data.source) {
            return
        }
        window.removeEventListener("message", this.cbDSCS);
        this.authCB(a.data)
    },
    getRepoType: function() {
        return this.addonInfo
    },
    getNext: function() {
        var a = this.getRepoType();
        if (!Ext.isObject(a)) {
            return false
        }
        if (this.launchOAuthWindow(a)) {
            return false
        }
        return this.nextId[a.id]
    },
    getParams: function() {
        var b = {};
        var a = this.getRepoType();
        if (Ext.isObject(a)) {
            b.target_type = a.target_type
        }
        return b
    },
    isValid: function() {
        if (null === this.getRepoType()) {
            return false
        } else {
            return true
        }
    }
});
Ext.define("SYNO.SDS.Backup.BaseTaskSourceSelector", {
    extend: "SYNO.SDS.Backup.BasicTreePanel",
    preloaded: false,
    preload_blocked: false,
    dest: undefined,
    folderLoadCount: 0,
    _mysql_pwd: undefined,
    pre_load_folder_done: false,
    folderDisplayLimit: 10000,
    constructor: function(a) {
        this.fm_root_nodes = [];
        this._folder_list = [];
        this._volList = [];
        this._excludeFolderList = [];
        this.pre_load_folder_done = a.pre_load_folder_done;
        var b = Ext.apply({
            bwrapStyle: "padding-top: 0px",
            bodyStyle: "padding: 8px 8px 0px 8px",
            rootVisible: false,
            loader: new SYNO.SDS.Backup.TreeLoader(),
            root: (new Ext.tree.AsyncTreeNode({
                draggable: false,
                id: "root",
                title: _T("backup", "select_share_app_title")
            }))
        }, a);
        return this.callParent([b])
    },
    activate: function() {
        if (!this.preloaded) {
            this.owner.setStatusBusy();
            this.preload_blocked = true
        }
    },
    initEvents: function() {
        var a = this.callParent(arguments);
        this.sendWebAPI({
            api: "SYNO.Backup.Source.Folder",
            version: 1,
            method: "list",
            params: {
                node: "fm_root"
            },
            callback: function(d, b, c) {
                if (this.preload_blocked) {
                    this.owner.clearStatusBusy()
                }
                if (!d) {
                    this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(b.code));
                    return
                }
                this.allFolders = b.folder;
                this.allVolumes = b.volume;
                if (this.pre_load_folder_done) {
                    this.createVolumeNodes()
                } else {
                    this.pre_load_folder_done = true
                }
                this.preloaded = true;
                if (Ext.isEmpty(this.allFolders)) {
                    new Ext.LoadMask(this.pageContainer.getEl(), {
                        msgCls: "syno-ux-mask-info",
                        msg: SYNO.SDS.Backup.String("app", "no_shared_folder_available")
                    }).show()
                }
            },
            scope: this
        });
        this.mon(this, "beforeexpandnode", this.onBeforeExpandNode);
        return a
    },
    onBeforeExpandNode: function(a) {
        if (a.attributes.exceedLimit) {
            this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), String.format(SYNO.SDS.Backup.String("app", "node_exceed_display_limit"), a.text, this.folderDisplayLimit));
            return false
        }
    },
    getUiProvider: function() {},
    getInitialVolumeCheckStatus: function() {},
    setNodeCheckAttr: function() {},
    getPathProcessParams: function() {},
    disableNode: function(a) {},
    enableNode: function(b, a) {},
    dealEmptyVolumeNode: function(a) {},
    createVolumeNodes: function() {
        var c = {};
        this.fm_root_map = {};
        this.petaVolId = "";
        Ext.each(this.allFolders, function(f) {
            var e = "";
            if (f.isClusterShare) {
                e = "petaspace"
            } else {
                e = f.volume
            }
            if (!c[e]) {
                c[e] = []
            }
            c[e].push(f)
        }, this);
        this.dealEmptyVolumeNode(c);
        var d = function(g, f, e) {
            if (-1 !== this.fm_root_nodes.indexOf(f.id)) {
                this.folderLoadCount++;
                if (this.folderLoadCount === this.volumeCount) {
                    this.owner.doIfAppShareReady("folder_loaded")
                }
            }
        };
        var b;
        if (this._folder_list) {
            b = this._folder_list.slice(0)
        } else {
            b = []
        }
        var a = Object.keys(c);
        a.sort();
        this.volumeCount = a.length;
        if (0 >= this.volumeCount) {
            this.owner.doIfAppShareReady("folder_loaded");
            this.owner.doIfAppShareReady("folder_initialed");
            new Ext.LoadMask(this.pageContainer.getEl(), {
                msgCls: "syno-ux-mask-info",
                msg: SYNO.SDS.Backup.String("app", "no_shared_folder_available")
            }).show()
        }
        Ext.each(a, function(f) {
            if (c.hasOwnProperty(f)) {
                var e = this.createTreeLoader("SYNO.Backup.Source.Folder", this.onCreateFolderNode, c[f]);
                e.on("load", d, this);
                var g = "fm_root" + this.fm_root_nodes.length;
                if ("petaspace" === f) {
                    this.petaVolId = g
                }
                this.fm_root_nodes.push(g);
                this.fm_root_map[g] = f;
                if (this.root) {
                    this.root.appendChild({
                        id: g,
                        expanded: true,
                        leaf: false,
                        text: this.getVolName(f, c),
                        loader: e,
                        uiProvider: this.getUiProvider(),
                        checked: this.getInitialVolumeCheckStatus(f),
                        volume: f
                    })
                }
            }
        }, this);
        this.checkMissingVolume(a, this._volList);
        this.setVolumeCheckState(b, this._volList, this._excludeFolderList);
        this.setConflictVolume()
    },
    checkMissingVolume: function(a, b) {},
    setVolumeCheckState: function(a, b, c) {},
    setConflictVolume: function() {
        var a = null;
        if (Ext.isFunction(this.owner.getLocalRepoVolume)) {
            a = this.owner.getLocalRepoVolume()
        }
        Ext.each(this.fm_root_nodes, function(c) {
            var b = this.getNodeById(c);
            if (!b) {
                return true
            }
            if ("petaspace" === b.attributes.volume) {
                return true
            } else {
                if (a && b.attributes.volume === a) {
                    b.getUI().getEl().classList.add("syno-backup-tri-conflict-volume")
                } else {
                    b.getUI().getEl().classList.remove("syno-backup-tri-conflict-volume")
                }
            }
        }, this)
    },
    getVolName: function(a, b) {
        if (-1 !== a.indexOf("usb")) {
            return b[a][0].display_vol_name
        }
        var c = this.getVolDesc(a, this.allVolumes);
        return SYNO.Backup.Util.parseVolName(a, c)
    },
    getVolDesc: function(b, a) {
        var c = "";
        if ("petaspace" === b) {
            return c
        }
        Ext.each(a, function(d) {
            if (b === d.volume) {
                c = d.description;
                return false
            }
        });
        return c
    },
    createTreeLoader: function(g, f, d, c, b, h, a) {
        var e = new SYNO.SDS.Backup.TreeLoader({
            sendWebAPI: this.sendWebAPI.createDelegate(this),
            webapi: {
                api: g,
                method: h || "list",
                version: a || 1
            },
            createNodeFn: f,
            createNodeScope: this,
            owner: this,
            nodeData: d,
            baseParams: {
                folder_limit: this.folderDisplayLimit + 1
            },
            nodeUI: this.getUiProvider().displayName,
            parseWebApiResponse: (function(j, i) {
                if (Ext.isArray(i)) {
                    return i
                }
                if (this.folderDisplayLimit >= i.folder.length) {
                    return i.folder
                }
                j.attributes.expandable = true;
                j.attributes.exceedLimit = true;
                return []
            }).createDelegate(this)
        });
        return e
    },
    convertLanguage: function(a, b) {
        var c = SYNO.SDS.Backup.converLanString(a[b]);
        if (c) {
            if ((b + "_param") in a) {
                c = String.format(c, a[b + "_param"])
            }
            a[b] = c
        }
    },
    onCreateFolderNode: function(a) {
        a.uiProvider = this.getUiProvider().displayName;
        this.convertLanguage(a, "text");
        this.convertLanguage(a, "qtip");
        if ("remote" == a.fileSystemType) {
            a.disabled = true;
            a.qtip = _T("backup", "source_not_remote_folder");
            a.disable_reason = _T("backup", "source_not_remote_folder")
        } else {
            if ("image" == a.fileSystemType) {
                a.disabled = true;
                a.qtip = _T("backup", "source_not_virtual_drive");
                a.disable_reason = _T("backup", "source_not_virtual_drive")
            }
        }
        if (true === a.encryptedShare) {
            if (true === a.dataEncrypted) {
                a.leaf = true
            }
        } else {
            if (true === a.isC2Share) {
                if (!this.isImage) {
                    a.disabled = true;
                    a.qtip = SYNO.SDS.Backup.String("app", "source_not_c2share");
                    a.disable_reason = SYNO.SDS.Backup.String("app", "source_not_c2share")
                }
            }
        }
        if (true === a.disabled) {
            a.leaf = true
        }
        if (SYNO.SDS.Backup.Client.Common.Utils.isABBDataFolder(a.folderPath)) {
            a.leaf = true
        } else {
            if (a.disabled && SYNO.SDS.Backup.Client.Common.Utils.isABBFuseFolder(a.folderPath)) {
                a.qtip = SYNO.SDS.Backup.String("app_backup", "ABB_no_backup_fuse");
                a.disable_reason = SYNO.SDS.Backup.String("app_backup", "ABB_no_backup_fuse")
            }
        }
        this.setNodeCheckAttr(a);
        if (a.checked === false && a.recycle === true) {
            a.hidden = true;
            a.disabled = true
        }
    },
    setVolumeList: function(a) {
        this._volList = a
    },
    setExcludeFolderList: function(a) {
        this._excludeFolderList = a
    },
    setFolderList: function(c) {
        this._folder_list = [];
        var b = [];
        var h = [];
        var g = [];
        var e = [];
        var d = [];
        var a = false;
        var f = "";
        Ext.each(c, function(j) {
            if (j.isValidSource) {
                this._folder_list.push(j.folderPath)
            } else {
                var i = SYNO.SDS.Backup.Util.lengthEllipsis(j.folderPath.substring(1), 20);
                if ("remote" === j.fileSystemType) {
                    b.push(i)
                } else {
                    if ("image" === j.fileSystemType) {
                        h.push(i)
                    } else {
                        if (j.missing) {
                            d.push(i)
                        } else {
                            if (SYNO.SDS.Backup.Client.Common.Utils.isABBFuseFolder(j.folderPath)) {
                                e.push(i)
                            } else {
                                g.push(i)
                            }
                        }
                    }
                }
            }
        }, this);
        if (0 < b.length) {
            f += (_T("backup", "remote_folder") + ": " + b.join(", ") + "<br/>");
            a = true
        }
        if (0 < h.length) {
            f += (_T("backup", "virtual_drive") + ": " + h.join(", ") + "<br/>");
            a = true
        }
        if (0 < d.length) {
            f += (_T("backup", "missing_folder") + ": " + d.join(", ") + "<br/>");
            a = true
        }
        if (0 < e.length) {
            f += (SYNO.SDS.Backup.String("app_backup", "ABB_no_backup_fuse") + ": " + e.join(", ") + "<br/>");
            a = true
        }
        if (0 < g.length) {
            f += (_T("backup", "not_support_filesystem") + ": " + g.join(", ") + "<br/>");
            a = true
        }
        if (a) {
            this.owner.invalidList += f
        }
        if (this.pre_load_folder_done) {
            this.createVolumeNodes();
            this.checkAllAzureDotEnd(this.owner.transferType)
        } else {
            this.pre_load_folder_done = true
        }
    },
    getSelectedEncList: function(b) {
        var a = [];
        Ext.each(this.fm_root_nodes, function(g) {
            var c;
            var e = this.getNodeById(g);
            var f = e.childNodes.length;
            for (c = 0; c < f; c++) {
                var d = e.childNodes[c];
                if (true === d.attributes.encryptedShare && (b === undefined || b === d.attributes.dataEncrypted) && false !== d.getUI().getCheckValue()) {
                    a.push(d.text)
                }
            }
        }, this);
        return a
    },
    updateAllEncShare: function(b, a) {
        var c = false;
        Ext.each(this.fm_root_nodes, function(d) {
            var e = this.getNodeById(d);
            e.eachChild(function(f) {
                if (this.updateEncShare(b, a, f)) {
                    c = true
                }
            }, this)
        }, this);
        return c
    },
    updateEncShare: function(c, a, b) {
        var d = false;
        if (true !== b.attributes.encryptedShare) {
            return false
        }
        if ("cloud" === c && "hicloud_s3" === a) {
            if (false !== b.getUI().getCheckValue()) {
                d = true
            }
            this.disableNode(b);
            b.setTooltip(_T("backup", "multi_version_not_support_encrypted_share"))
        } else {
            this.enableNode(b, !b.attributes.dataEncrypted);
            b.setTooltip(b.text)
        }
        return d
    },
    checkAllAzureDotEnd: function(a) {
        var b = [];
        Ext.each(this.fm_root_nodes, function(c) {
            var d = this.getNodeById(c);
            d.eachChild(function(e) {
                if (this.checkAzureDotEnd(a, e)) {
                    b.push(e.text)
                }
            }, this)
        }, this);
        if (0 < b.length) {
            this.owner.invalidList += (SYNO.SDS.Backup.String("app", "azure_share_end_with_dot_msg") + ": " + b.join(", ") + "<br/>")
        }
    },
    checkAzureDotEnd: function(a, b) {
        if (!b.text.endsWith(".")) {
            return false
        }
        if ("azure_blob" === a || "azure_cn_blob" === a) {
            this.disableNode(b);
            b.setTooltip(SYNO.SDS.Backup.String("error", "azure_share_end_with_dot"));
            return true
        } else {
            this.enableNode(b, true);
            b.setTooltip(b.text);
            return false
        }
    },
    hasCheckedNode: function(b) {
        if (b.getUI().isChecked()) {
            return true
        }
        var c = b.childNodes.length;
        var a;
        for (a = 0; a < c; a++) {
            if (true === this.hasCheckedNode(b.childNodes[a])) {
                return true
            }
        }
        return false
    },
    setExpandable: function(a, b) {
        a.collapse(false, false);
        a.leaf = !b;
        a.getUI().updateExpandIcon()
    },
    setDestination: function(a) {
        var b = this.getNodeById(a);
        if (undefined !== this.dest) {
            this.clearDestination()
        }
        if (b !== undefined) {
            this.disableNode(b);
            b.attributes.disabled = true;
            b.attributes.disable_reason = _T("backup", "source_share_conflict_destination");
            b.setTooltip(_T("backup", "source_share_conflict_destination"));
            if (b.getUI().getEl()) {
                b.getUI().getEl().classList.add("syno-backup-show-disable-folder");
                var c = b.getUI().getEl().getElementsByClassName("syno-backup-tree-node-disable-folder");
                c[0].setAttribute("ext:qtip", _T("backup", "source_share_conflict_destination"))
            }
            this.dest = a
        }
    },
    getDestination: function() {
        return this.dest
    },
    clearDestination: function() {
        var a = this.getNodeById(this.dest);
        if (a) {
            this.enableNode(a, true);
            a.setTooltip(a.text);
            a.attributes.disabled = false;
            a.attributes.disable_reason = "";
            if (a.getUI().getEl()) {
                a.getUI().getEl().classList.remove("syno-backup-show-disable-folder")
            }
            this.dest = undefined
        }
    },
    onBeforeLoad: function(c, a, b) {
        if (true === a.disabled) {
            return false
        }
    },
    getNext: function() {
        this.callParent(arguments)
    }
});
Ext.define("SYNO.SDS.Backup.TaskSourceTriSelector", {
    extend: "SYNO.SDS.Backup.BaseTaskSourceSelector",
    constructor: function(a) {
        this.callParent([a])
    },
    getUiProvider: function() {
        return SYNO.SDS.Backup.TriTreeNodeUI
    },
    getInitialVolumeCheckStatus: function() {
        return "none"
    },
    setVolumeCheckState: function(a) {
        Ext.each(this.fm_root_nodes, function(c) {
            var b = this.getNodeById(c);
            if (b) {
                b.attributes.checked = this.getCheckState(c, a);
                b.getUI().syncCheckCssClass()
            }
        }, this)
    },
    setNodeCheckAttr: function(a) {
        if (Ext.isBoolean(a.checked) || a.checked === "gray") {
            a.checked = this.getCheckState(a.id, this._folder_list)
        }
    },
    getPathProcessParams: function() {
        var a = [];
        Ext.each(this.fm_root_nodes, function(b) {
            Ext.each(this.getCheckedSubTreeRoot(this.getNodeById(b)), function(c) {
                a.push(c.id)
            })
        }, this);
        Ext.each(this._folder_list, function(b) {
            a.push(b)
        });
        return {
            folder_list: a
        }
    },
    disableNode: function(a) {
        a.getUI().setCheckValue(false);
        this.setExpandable(a, false);
        a.disable()
    },
    enableNode: function(b, a) {
        b.enable();
        this.setExpandable(b, a)
    },
    onCheckChange: function(d, e) {
        var b = this.callParent(arguments);
        var f = d.attributes.id;
        var a, c;
        if (!f) {
            return b
        }
        if (this._folder_list) {
            a = [];
            Ext.each(this._folder_list, function(h, g) {
                if (h === f) {
                    a.push(g);
                    return false
                } else {
                    if (h.indexOf(f + "/") === 0) {
                        a.push(g)
                    }
                }
            }, this);
            for (c = a.length - 1; c >= 0; c--) {
                this._folder_list.splice(a[c], 1)
            }
        }
        d.bubble(function(g) {
            if (0 === g.id.indexOf("fm_root")) {
                this.updateVolumeConflictTip(g);
                return false
            }
        }, this);
        return b
    },
    updateVolumeConflictTip: function(a) {
        a.getUI().getEl().classList.remove("syno-volume-show-conflict");
        a.eachChild(function(b) {
            if (true === b.disabled || false === b.attributes.checked) {
                return true
            }
            a.getUI().getEl().classList.add("syno-volume-show-conflict");
            return false
        })
    },
    getCheckState: function(c, b) {
        var a = false;
        if (!b) {
            return false
        }
        if (-1 !== this.fm_root_nodes.indexOf(c)) {
            Ext.each(b, function(f) {
                var d = f.indexOf("/", 1);
                if (-1 !== d) {
                    f = f.substring(0, d)
                }
                var e = this.getNodeById(f);
                if (null !== e && e.parentNode.id === c) {
                    a = "gray";
                    return false
                }
            }, this);
            this.getNodeById(c).eachChild(function(d) {
                Ext.each(this._folder_list, function(e) {
                    if (d.id === e || 0 === e.indexOf(d.id + "/")) {
                        this.getNodeById(c).getUI().getEl().classList.add("syno-volume-show-conflict");
                        return false
                    }
                }, this)
            }, this);
            return a
        } else {
            Ext.each(b, function(e, d) {
                if (c === e) {
                    b.splice(d, 1);
                    a = true;
                    return false
                } else {
                    if (e.indexOf(c + "/") === 0) {
                        a = "gray";
                        return false
                    }
                }
            });
            return a
        }
    }
});
Ext.define("SYNO.SDS.Backup.TaskSourceQuadSelector", {
    extend: "SYNO.SDS.Backup.BaseTaskSourceSelector",
    constructor: function(a) {
        this.callParent([a])
    },
    getUiProvider: function() {
        return SYNO.SDS.Backup.QuadTreeNodeUI
    },
    getInitialVolumeCheckStatus: function(a) {
        if (-1 !== this._volList.indexOf(a)) {
            return true
        }
        return "gray"
    },
    checkMissingVolume: function(a, c) {
        var b = [];
        Ext.each(c, function(d) {
            if (-1 === a.indexOf(d)) {
                b.push(SYNO.Backup.Util.parseVolName(d, ""))
            }
        });
        if (0 < b.length) {
            this.owner.invalidList += SYNO.SDS.Backup.String("app", "missing_volume") + ": " + b.join(", ") + "<br/>"
        }
    },
    setVolumeCheckState: function(a, b, c) {
        Ext.each(this.fm_root_nodes, function(e) {
            var d = this.getNodeById(e);
            if (d) {
                d.attributes.checked = this.getCheckState(d.attributes, a, b, c);
                if (true === d.attributes.checked) {
                    d.state = new SYNO.SDS.Backup.QuadTreeNodeFullState({
                        node: d
                    })
                } else {
                    if ("gray" === d.attributes.checked) {
                        d.state = new SYNO.SDS.Backup.QuadTreeNodePartialState({
                            node: d
                        })
                    } else {
                        if (false === d.attributes.checked) {
                            d.state = new SYNO.SDS.Backup.QuadTreeNodeEmptyState({
                                node: d
                            })
                        }
                    }
                }
                d.getUI().syncCheckCssClass()
            }
        }, this)
    },
    setNodeCheckAttr: function(a) {
        if (Ext.isBoolean(a.checked) || a.checked === "gray") {
            a.checked = this.getCheckState(a, this._folder_list, this._volList, this._excludeFolderList);
            if (true === a.checked) {
                a.state = "SYNO.SDS.Backup.QuadTreeNodeFullState"
            } else {
                if ("gray" === a.checked) {
                    a.state = "SYNO.SDS.Backup.QuadTreeNodePartialState"
                } else {
                    if (false === a.checked) {
                        a.state = "SYNO.SDS.Backup.QuadTreeNodeEmptyState"
                    }
                }
            }
        }
    },
    dealEmptyVolumeNode: function(a) {
        Ext.each(this.allVolumes, function(b) {
            if (!a.hasOwnProperty(b.volume)) {
                a[b.volume] = []
            }
        }, this)
    },
    onExpandNode: function(a) {
        return
    },
    getPathProcessParams: function() {
        var c = this.root;
        var b = [];
        var d = [];
        var e = [];
        var a = function(f) {
            if ("root" === f.id) {
                return
            }
            var g = f.getUI();
            if (!Ext.isFunction(g.getCheckValue)) {
                return
            }
            if (0 === f.id.indexOf("fm_root")) {
                if (true === g.getCheckValue()) {
                    b.push(f.attributes.volume)
                }
            } else {
                if (true === g.getCheckValue()) {
                    if (true === f.parentNode.getUI().getCheckValue()) {
                        return
                    }
                    d.push(f.id)
                } else {
                    if (true === f.parentNode.getUI().getCheckValue()) {
                        e.push(f.id + "/")
                    }
                }
            }
        };
        c.cascade(a, this);
        return {
            backup_volumes: b,
            folder_list: SYNO.ux.Utils.uniqueApiArray(d.concat(this._folder_list)),
            folder_exclude_list: SYNO.ux.Utils.uniqueApiArray(e.concat(this._excludeFolderList))
        }
    },
    checkFolderUnderVolume: function(d, b) {
        var c = "/" + b.split("/")[1];
        var a = false;
        Ext.each(d.childNodes, function(e) {
            if (e.id === c) {
                a = true;
                return false
            }
        });
        return a
    },
    disableNode: function(a) {
        if (!a.state) {
            this.preInitNodeStateFromAttr(a)
        }
        a.state.setDisable();
        this.setExpandable(a, false)
    },
    enableNode: function(b, a) {
        if (!b.state) {
            this.preInitNodeStateFromAttr(b)
        }
        b.state.setEnable();
        this.setExpandable(b, a)
    },
    preInitNodeStateFromAttr: function(b) {
        if (b.attributes && b.attributes.state) {
            var a = Ext.getClassByName(b.attributes.state);
            b.state = new a({
                node: b
            })
        }
    },
    getParentNodeFromId: function(c) {
        if (true === c.isClusterShare) {
            return this.getNodeById(this.petaVolId)
        } else {
            if (-1 === c.id.indexOf("/", 1)) {
                var b;
                Ext.each(this.fm_root_nodes, function(d) {
                    if (this.fm_root_map[d] === c.volume) {
                        b = this.getNodeById(d);
                        return false
                    }
                }, this);
                return b
            } else {
                var a = c.id.lastIndexOf("/");
                return this.getNodeById(c.id.substring(0, a))
            }
        }
    },
    getCheckState: function(a, d, f, g) {
        var c = false;
        var e = false;
        if ("remote" == a.fileSystemType || "image" == a.fileSystemType) {
            c = false
        } else {
            if (a.disabled && SYNO.SDS.Backup.Client.Common.Utils.isABBFuseFolder(a.folderPath)) {
                c = false
            } else {
                if (-1 !== this.fm_root_nodes.indexOf(a.id)) {
                    var b = this.getNodeById(a.id);
                    if (-1 !== f.indexOf(b.attributes.volume)) {
                        c = true
                    } else {
                        Ext.each(d, function(h) {
                            if (this.checkFolderUnderVolume(b, h)) {
                                c = "gray";
                                return false
                            }
                        }, this)
                    }
                } else {
                    if (true === this.getParentNodeFromId(a).dirty) {
                        c = this.getParentNodeFromId(a).getUI().getCheckValue()
                    } else {
                        if (-1 !== g.indexOf(String(a.id + "/"))) {
                            Ext.each(d, function(h) {
                                if (0 === h.indexOf(a.id + "/")) {
                                    c = "gray";
                                    e = true;
                                    return false
                                }
                            });
                            if (!e) {
                                c = false
                            }
                        } else {
                            if (true === this.getParentNodeFromId(a).getUI().getCheckValue()) {
                                c = true
                            } else {
                                if (false === this.getParentNodeFromId(a).getUI().getCheckValue()) {
                                    c = false
                                } else {
                                    Ext.each(d, function(h) {
                                        if (a.id === h) {
                                            c = true;
                                            e = true;
                                            return false
                                        }
                                    });
                                    if (!e) {
                                        Ext.each(d, function(h) {
                                            if (0 === h.indexOf(a.id + "/")) {
                                                c = "gray";
                                                e = true;
                                                return false
                                            }
                                        })
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return c
    }
});
Ext.define("SYNO.SDS.Backup.TaskSourceContainerWrapper", {
    extend: "SYNO.ux.Panel",
    constructor: function(a) {
        var b = {
            layout: "fit",
            height: 425,
            items: [new SYNO.SDS.Backup.TaskSourceContainer({
                owner: a.owner,
                appWin: a.appWin,
                itemId: "source_container_wrapper",
                isImage: a.isImage,
                pre_load_folder_done: a.pre_load_folder_done,
                bodyStyle: "padding-right: 0px;"
            })]
        };
        Ext.apply(b, a);
        this.callParent([b])
    },
    initComponent: function() {
        this.callParent(arguments);
        var a = this.appWin.appInstance.getUserSettings("show_parent_file_only_tip");
        if (this.isImage && (undefined === a || a)) {
            this.add(new SYNO.SDS.Backup.NewFeaturePanel({
                appInstance: this.appWin.appInstance,
                subTopic: "data_backup_source.html"
            }))
        }
    },
    getParams: function() {
        return this.getComponent("source_container_wrapper").getParams()
    },
    getNext: function() {
        var a = this.getComponent("source_container_wrapper").getWarnEncList();
        this.owner.setStatusBusy();
        if (0 === a.length) {
            this.goToNextStep()
        } else {
            this.owner.getMsgBox().alert(_T("leaf", "backup"), String.format(SYNO.SDS.Backup.String("error", "keep_enc_mounted_when_backup"), "<b>" + a.join(", ") + "</b>"), this.goToNextStep, this)
        }
        return false
    },
    goToNextStep: function() {
        if (this.owner.getStep("app").isLoaded()) {
            this.owner.clearStatusBusy();
            if (this.owner.getStep("app").needHide()) {
                this.owner.goNext(this.owner.getStep("app").getNext())
            } else {
                this.owner.goNext(this.nextId)
            }
        } else {
            setTimeout((function() {
                this.goToNextStep()
            }).createDelegate(this), 100)
        }
    },
    saveFilterParams: function(a) {
        this.getComponent("source_container_wrapper").saveFilterParams(a)
    },
    getSourceSelector: function() {
        return this.getComponent("source_container_wrapper").getSourceSelector()
    },
    activate: function() {
        this.getComponent("source_container_wrapper").activate()
    },
    getWarnEncList: function() {
        return this.getComponent("source_container_wrapper").getWarnEncList()
    }
});
Ext.define("SYNO.SDS.Backup.TaskSourceContainer", {
    extend: "SYNO.SDS.Backup.FormPanel",
    constructor: function(a) {
        var c = Ext.apply({
            cls: "syno-backup-source-container syno-backup-source-wrapper",
            autoFlexcroll: false,
            items: [this.createSourceSelector(a.owner, a.pre_load_folder_done, a.isImage)],
            bbar: (a.isImage) ? this.createBbar() : undefined
        }, a);
        var b = this.callParent([c]);
        return b
    },
    createSourceSelector: function(a, d, c) {
        var b = {
            itemId: "source",
            owner: a,
            pageContainer: this,
            isImage: c,
            firstLevelExpanded: true,
            pre_load_folder_done: d
        };
        if (c) {
            b.height = 367;
            return new SYNO.SDS.Backup.TaskSourceQuadSelector(b)
        } else {
            b.height = 396;
            return new SYNO.SDS.Backup.TaskSourceTriSelector(b)
        }
    },
    createBbar: function() {
        var a = new SYNO.ux.Toolbar();
        a.add(new Ext.ux.StatusBar({
            html: '<span class="syno-backup-open-filter-text">' + SYNO.SDS.Backup.String("app", "create_file_filter") + "</span>",
            hideBorders: true,
            listeners: {
                scope: this,
                afterrender: function(b) {
                    b.getEl().on("click", function() {
                        var c = new SYNO.SDS.Backup.Client.Common.FilterSettingWindow({
                            owner: this.owner,
                            backupFilter: this.backupFilter
                        });
                        c.on("savefilterparams", this.saveFilterParams, this);
                        c.open()
                    }, this)
                }
            }
        }));
        return a
    },
    saveFilterParams: function(a) {
        var b = {};
        Ext.copyTo(b, a, "whitelist");
        b.exclude_list = SYNO.Backup.Util.ExtractPattern(a.exclude_list, "file");
        this.backupFilter = b
    },
    activate: function() {
        var e = this.owner.getParams();
        var d = this.getSourceSelector();
        var c, b, a;
        if (d.updateAllEncShare(e.target_type, e.transfer_type)) {
            this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), String.format(_T("backup", "multi_version_not_support_encrypted_share") + "&nbsp;" + _T("backup", "deselect_all_encrypted_share")))
        }
        d.checkAllAzureDotEnd(e.transfer_type);
        d.clearDestination();
        if (("share" === e.target_type && "local" === e.transfer_type) || ("image" === e.target_type && "image_local" === e.transfer_type) || ("export" === e.action)) {
            c = e.share;
            b = d.getNodeById("/" + c);
            if (b) {
                a = d.hasCheckedNode(b);
                d.setDestination("/" + c);
                if (true === a) {
                    this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), String.format(_T("localbkp", "localbkp_dest_conflict_bkpshare") + "&nbsp;" + _T("localbkp", "deselect_conflict_source_share") + "&nbsp;[" + c + "]"))
                }
            }
        }
        d.setConflictVolume();
        this.owner.doIfAppShareReady("folder_initialed");
        this.getSourceSelector().activate()
    },
    getSourceSelector: function() {
        return this.getComponent("source")
    },
    getSourceSelectorName: function() {
        return this.getSourceSelector().self.displayName
    },
    getWarnEncList: function() {
        var a = this.owner.getParams();
        if (a.target_type === "image" || a.target_type === "cloud_image") {
            return this.getSourceSelector().getSelectedEncList()
        }
        return []
    },
    getParams: function() {
        var b = {};
        var a = {};
        a = this.getSourceSelector().getPathProcessParams();
        b.file_list = a.folder_list;
        if (true === this.isImage) {
            b.backup_volumes = a.backup_volumes;
            b.backup_filter = SYNO.Backup.Util.deepCopyObject(this.backupFilter) || {
                whitelist: [],
                exclude_list: []
            };
            b.backup_filter.exclude_list = b.backup_filter.exclude_list.concat(a.folder_exclude_list)
        }
        return b
    }
});
Ext.define("SYNO.SDS.Backup.AppGridPanel", {
    extend: "SYNO.ux.GridPanel",
    isAddAppDepTip: {},
    createColumnSelect: function() {
        this.enableColumn = new SYNO.SDS.Backup.EnableColumn({
            sortable: false,
            resizable: false,
            dataIndex: "checked",
            width: 40,
            align: "center",
            afterCheck: {
                handler: function(a) {
                    this.clickAppNode(a)
                },
                scope: this
            }
        });
        return this.enableColumn
    },
    createColumnAppInfo: function() {
        return new Ext.grid.Column({
            header: _T("backup", "application"),
            width: 200,
            dataIndex: "name",
            scope: this,
            renderer: function(f, b, a, g, e, c) {
                var d = new Ext.XTemplate('<table><tbody><tr><td class="syno-backup-cell-app-td"><div class="syno-backup-cell-app-icon" ext:qtip="{app_err_msg}"> <img class="syno-backup-cell-app-icon-img" url="{[this.getIconUrl(values.id, values.version)]}" src="{[this.getIconUrl(values.id, values.version)]}" ext:qtip="{app_err_msg}"><tpl if="app_err_msg.length &gt; 0"><div class="syno-backup-cell-app-warning"ext:qtip="{app_err_msg}"></div></tpl></div><tpl if="is_beta"><div class="syno-backup-cell-app-beta-label" ext:qtip="{app_err_msg}"></div></tpl></td><td class="syno-backup-cell-app-title"><span class="syno-backup-cell-app-name" ext:qtip="{app_err_msg}">{name:htmlEncode}</span><tpl if="online_backup == false"><span class="syno-backup-cell-app_disable"ext:qtip="{disable_tip:htmlEncode}"></span></tpl><div class="normal-font" ext:qtip="{app_err_msg}">{version:htmlEncode}</div></div></tr></tbody></table>');
                d.getIconUrl = SYNO.SDS.Backup.getAppIconPath;
                d.compile();
                return d.apply({
                    name: a.get("name"),
                    id: a.get("id"),
                    version: a.get("version"),
                    is_beta: a.get("is_beta"),
                    online_backup: a.get("online_backup"),
                    disable_tip: _T("backup", "disable_in_backup_qtip"),
                    app_err_msg: this.getErrorMsg(a)
                })
            }
        })
    },
    createColumnAppDependency: function() {
        return new Ext.grid.Column({
            header: '<span class="app-share-depend-header">' + _T("backup", "share_depend") + '</span><div class="app-share-depend-header-tip" ext:wtip="' + this.getAppDepShareTipFormat() + '"></div>',
            headerHtmlEncode: false,
            dataIndex: "depend",
            width: 130,
            renderer: function(h, a, c, g, j, i) {
                var b = [];
                if (true === c.get("disabled")) {
                    if (!h) {
                        return "--"
                    }
                    if (Ext.isDefined(h.invalid_shares) && 0 !== h.invalid_shares.length) {
                        b.push('<span class="red-status">' + h.invalid_shares.join(", ") + "</span>")
                    }
                    var k = h.folder_list.map(function(l) {
                        return SYNO.SDS.Backup.getShareName(l.folder)
                    });
                    k = SYNO.ux.Utils.uniqueApiArray(k);
                    Ext.each(k, function(l) {
                        if (Ext.isDefined(h.invalid_shares) && 0 <= h.invalid_shares.indexOf(l)) {
                            return true
                        }
                        b.push(l)
                    });
                    return b.join(", ")
                } else {
                    if (0 === h.folder_list.length) {
                        return "--"
                    }
                    var e = SYNO.SDS.Backup.parseAppDependFolderInfo(h);
                    var d = [];
                    Ext.each(e.detail, function(l) {
                        if (-1 !== l.whitelist.indexOf("*")) {
                            d.push(l.path);
                            return true
                        }
                        d.push(l.path + "(" + l.whitelist.join(", ") + ")")
                    });
                    var f = new Ext.XTemplate('<div class="syno-backup-cell-folder-detail"><span ext:qtip="{folder_detail:htmlEncode}">{folder_outline:htmlEncode}</span></div>');
                    f.compile();
                    return f.apply({
                        folder_outline: e.outline.sort().join(", "),
                        folder_detail: d.sort().join("<br>")
                    })
                }
            }
        })
    },
    createColumnAppSummary: function() {
        var a = this;
        return new Ext.grid.Column({
            header: SYNO.SDS.Backup.String("app", "summary"),
            headerHtmlEncode: false,
            dataIndex: "summary",
            width: 220,
            renderer: function(i, b, d, h, k, j) {
                var g = a.getAppInfoTip(j, d);
                var c = d.get("summary_disp_tip");
                var f = c;
                if (!Ext.isEmpty(g)) {
                    f = g + "<br>" + f
                }
                if (Ext.isEmpty(f)) {
                    f = "--"
                }
                var e = new Ext.XTemplate('<span class="syno-backup-cell-app-summary"ext:qtip="{finalDisp}">{finalDisp}</span>');
                e.compile();
                return e.apply({
                    finalDisp: f
                })
            }
        })
    },
    syncSourceTip: function(a) {},
    syncCheckedStatus: function() {
        this.enableColumn.checkSelectAll(this.getStore())
    },
    clickAppNode: function(b) {
        var c = b.get("id");
        var f = b.get("checked");
        var d = [];
        if (f) {
            d = SYNO.SDS.Backup.getDepentApps(this.getStore(), c);
            Ext.each(d, function(h) {
                this.getStore().getById(h).set("checked", true);
                this.syncSourceTip(this.getStore().getById(h))
            }, this)
        } else {
            d = SYNO.SDS.Backup.getAppsDependOnThis(this.getStore(), c);
            var e = [];
            var a = [];
            Ext.each(d, function(i) {
                var h = this.getStore().getById(i);
                if (!h.get("checked")) {
                    return
                }
                e.push(h);
                a.push(h.get("name"))
            }, this);
            if (0 < e.length && 0 < a.length) {
                var g;
                if (true === this.isBackup) {
                    g = SYNO.SDS.Backup.String("app", "unselect_app_alert_bkp")
                } else {
                    g = SYNO.SDS.Backup.String("app", "unselect_app_alert_restore")
                }
                g = String.format(g, b.get("name"), a.join(", "));
                this.owner.getMsgBox().confirm("", g, function(h) {
                    if ("yes" === h) {
                        Ext.each(e, function(i) {
                            i.set("checked", false);
                            this.syncSourceTip(i)
                        }, this)
                    } else {
                        b.set("checked", true)
                    }
                    this.syncCheckedStatus()
                }, this)
            }
        }
        this.syncSourceTip(b)
    },
    getAppList: function() {
        var a = [];
        Ext.each(this.getStore().data.items, function(b) {
            if (true === b.get("checked")) {
                a.push(b.get("id"))
            }
        });
        return a
    },
    getAppFolder: function(b) {
        var a = this.getStore().getById(b);
        return a.get("depend").folder_list
    },
    getAppWhitelist: function(b) {
        var a = this.getStore().getById(b);
        return a.get("depend").whitelist
    },
    checkIsSubFolder: function(b, a) {
        if (b === a) {
            return true
        }
        if (b.length < a.length) {
            return false
        }
        if (a === b.substring(0, a.length)) {
            if ("/" === b.charAt(a.length)) {
                return true
            }
        }
        return false
    },
    getDealedAppWhitelist: function(c, b) {
        var a = [];
        Ext.each(b, function(d) {
            a.push(c + "/" + d);
            a.push(c + "/**/" + d)
        });
        return a
    },
    getSelectedAppFolderWhitelist: function() {
        var b = this.owner.getStep("share").getFolderList(true);
        var c = [];
        var a = [];
        this.getStore().each(function(e) {
            if (true !== e.get("checked")) {
                return true
            }
            var f = e.get("depend").folder_list;
            if (!f || 0 === f.length) {
                return true
            }
            var d = function(g) {
                Ext.each(g, function(h) {
                    var j = false;
                    var i = "/" + h.folder;
                    Ext.each(b, function(l) {
                        if (this.checkIsSubFolder(i, l.path)) {
                            j = l.is_enc;
                            return false
                        }
                    }, this);
                    var k = {
                        path: i,
                        is_enc: j
                    };
                    c.push(k);
                    a = a.concat(this.getDealedAppWhitelist(i, h.whitelist))
                }, this)
            };
            d.call(this, f, false)
        }, this);
        return {
            app_folder: c,
            app_whitelist: a
        }
    },
    getSelectedAppShare: function() {
        var a = [];
        this.getStore().each(function(b) {
            if (true !== b.get("checked")) {
                return true
            }
            var c = b.get("depend").folder_list;
            if (!c || 0 === c.length) {
                return true
            }
            var d = function(e) {
                return e.folder
            };
            a = a.concat(c.map(d))
        });
        return SYNO.ux.Utils.uniqueApiArray(a)
    },
    getAppDepTip: function(b, f, c) {
        var e = "";
        var d = SYNO.SDS.Backup.getDepentApps(b, f);
        if (0 < d.length) {
            var a = SYNO.SDS.Backup.getAppDisplayName(b, d);
            e = String.format(this.getAppDepTipFormat(), c, a.join(", "))
        }
        return e
    },
    getSource: function() {}
});
Ext.define("SYNO.SDS.Backup.Restore.AppStep", {
    extend: "SYNO.SDS.Backup.AppGridPanel",
    AppSummary: {},
    constructor: function(b) {
        Ext.copyTo(this, b, "owner");
        var f = this.createColumnSelect();
        var a = this.createColumnAppInfo();
        var c = this.createColumnAppDependency();
        var e = this.createColumnAppSummary();
        var d = Ext.apply({
            cls: "syno-backup-app-grid-panel",
            store: this.createStore(),
            enableHdMenu: false,
            bbar: [new Ext.ux.StatusBar({
                id: "selectStatus",
                cls: "normal-font"
            })],
            colModel: new Ext.grid.ColumnModel({
                columns: [f, a, c, e]
            }),
            viewConfig: {
                getRowClass: function(g, j, h, i) {
                    if (g.get("disabled")) {
                        return "syno-backup-app-grid-disabled-row"
                    }
                }
            },
            listeners: {
                rowmousedown: function(h, j, i) {
                    var g = h.getStore().getAt(j);
                    if (g.get("disabled")) {
                        return false
                    }
                }
            },
            plugins: [f]
        }, b);
        this.callParent([d])
    },
    createStore: function() {
        return new Ext.data.JsonStore({
            proxy: new SYNO.API.Proxy({
                api: "SYNO.Backup.App2.Restore",
                method: "list",
                timeout: 300000,
                version: 2,
                listeners: {
                    load: {
                        scope: this,
                        fn: this.onProxyLoad
                    }
                }
            }),
            listeners: {
                exception: {
                    scope: this,
                    fn: this.onStoreException
                },
                beforeload: {
                    scope: this,
                    fn: this.onBeforeLoad
                },
                load: {
                    scope: this,
                    fn: this.onLoad
                }
            },
            root: "app_list",
            idProperty: "id",
            sortInfo: {
                field: "name",
                direction: "ASC"
            },
            fields: ["id", "name", "version", "depend", "disabled", "behavior", "error_code", "is_beta", "summary_disp", "summary_disp_tip"]
        })
    },
    onProxyLoad: function(a, b) {
        if (Ext.isEmpty(b.version_id) || Ext.isEmpty(b.dss_id)) {
            return
        }
        this.owner.dssCache[b.version_id] = b.dss_id
    },
    isMaskError: function(a) {
        return SYNO.SDS.Backup.ERR_APP_VOLUME === a || SYNO.SDS.Backup.ERR_APP_NO_SPACE === a
    },
    onStoreException: function(d, e, f, c, b, a) {
        this.owner.clearStatusBusy();
        if (this.isMaskError(b.code)) {
            this.loadErrorCode = b.code;
            return
        }
        this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), SYNO.SDS.Backup.GetErrorString(b.code), function(g) {
            if (SYNO.SDS.Backup.ERR_SESSION_EXPIRED === b.code) {
                this.owner.clearSession()
            }
            this.owner.close()
        }, this)
    },
    onBeforeLoad: function(a, b) {
        delete this.loadErrorCode;
        this.owner.setStatusBusy()
    },
    onLoad: function(b, a, c) {
        SYNO.SDS.Backup.setAppGridDependency(this, this.getFileTree(), false, false);
        this.owner.clearStatusBusy()
    },
    getFileTree: function() {
        return this.owner.getStep("share").getFileSourcePanel()
    },
    getVersionAppParams: function() {
        var a = this.owner.getBaseParams("share");
        Ext.apply(a, this.owner.getEncParams());
        a.dss_id = this.owner.dssCache[a.version_id];
        return a
    },
    isReloadNeeded: function() {
        var a = this.getVersionAppParams();
        delete a.dss_id;
        var b = Ext.encode(a);
        if (this.lastQuery === b) {
            return false
        }
        this.lastQuery = b;
        return true
    },
    activate: function() {
        if (this.isMaskError(this.loadErrorCode)) {
            this.body.mask(SYNO.SDS.Backup.GetErrorString(this.loadErrorCode), "syno-ux-mask-info")
        } else {
            this.body.unmask()
        }
        if (!this.isReloadNeeded()) {
            return
        }
        this.getStore().load({
            params: this.getVersionAppParams()
        })
    },
    summary: function(b) {
        var d = [];
        var c = {
            install: {
                title: _T("backup", "app_install_list"),
                list: []
            },
            reinstall: {
                title: _T("backup", "app_reinstall_list"),
                list: []
            },
            upgrade: {
                title: _T("backup", "app_upgrade_list"),
                list: []
            },
            replace: {
                title: SYNO.SDS.Backup.String("app", "app_replace_list"),
                list: []
            },
            to_break: {
                title: SYNO.SDS.Backup.String("app", "app_break_list"),
                list: []
            }
        };
        Ext.iterate(this.AppSummary, function(e, f) {
            if (!f.isDepended) {
                d.push(f.name)
            }
            if (f.behavior === "install" || f.behavior === "upgrade") {
                c[f.behavior].list.push(f.name + " (" + f.version + ")")
            } else {
                if (f.behavior === "reinstall" || f.behavior === "replace") {
                    c[f.behavior].list.push(f.name)
                } else {
                    if (f.behavior === "break") {
                        c.to_break.list.push(f.name)
                    }
                }
            }
        });
        if (0 === d.length) {
            b.append(SYNO.SDS.Backup.String("app", "app_restore_list"), _T("system", "none_opt"))
        } else {
            b.append(SYNO.SDS.Backup.String("app", "app_restore_list"), d.join(", "))
        }
        for (var a in c) {
            if (0 < c[a].list.length) {
                b.append(c[a].title, c[a].list.join(", "))
            }
        }
    },
    updateAppSummaryAndGoNext: function() {
        this.AppSummary = {};
        if (0 < this.getAppList().length) {
            this.owner.getMsgBox().confirm("", _T("backup", "restore_stop_app_alert"), function(a) {
                if ("yes" !== a) {
                    return
                }
                this.owner.setStatusBusy();
                var b = this.owner.getBaseParams();
                Ext.apply(b, this.owner.getEncParams());
                b.dss_id = this.owner.dssCache[b.version_id];
                b.app_list = this.getAppList();
                this.sendWebAPI({
                    api: "SYNO.Backup.App2.Restore",
                    version: 1,
                    method: "list_install",
                    timeout: 300000,
                    params: b,
                    encryption: SYNO.SDS.Backup.Util.getEncryption(["pwd", "secret", "remote_refresh_token", "remote_access_token"], b),
                    scope: this,
                    callback: function(e, c, d) {
                        this.owner.clearStatusBusy();
                        if (!e) {
                            this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(c.code), function() {
                                if (SYNO.SDS.Backup.ERR_SESSION_EXPIRED === c.code) {
                                    this.owner.clearSession();
                                    this.owner.close()
                                }
                            }, this);
                            return
                        }
                        Ext.each(c.app_list, function(i, g, h) {
                            var f = (-1 === b.app_list.indexOf(i.id));
                            if (f && i.behavior === "skip") {
                                return true
                            }
                            this.AppSummary[i.id] = [];
                            this.AppSummary[i.id].name = i.name;
                            this.AppSummary[i.id].behavior = i.behavior;
                            this.AppSummary[i.id].version = i.version;
                            this.AppSummary[i.id].isDepended = f
                        }, this);
                        this.owner.goNext(this.nextId)
                    }
                })
            }, this);
            return false
        }
        this.owner.goNext(this.nextId)
    },
    getNext: function() {
        var a = this.owner.getStep("share");
        if (0 === a.getFolderList().length && 0 === this.getAppList().length && !this.owner.getStep("config").isRestoreConfig()) {
            this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("backup", "backup_data_empty"));
            return false
        }
        var b = a.getFileSourcePanel().getWarning(this.getSelectedAppShare());
        if (b) {
            this.owner.getMsgBox().confirm(_T("netbackup", "netbkp_recovery"), b, function(c) {
                if ("yes" === c) {
                    this.updateAppSummaryAndGoNext()
                }
            }, this)
        } else {
            this.updateAppSummaryAndGoNext()
        }
        return false
    },
    getParams: function() {
        var b = this.getAppList();
        b = b.map(function(e) {
            var c = this.getStore().getById(e).get("version");
            var d = this.getStore().getById(e).get("name");
            return {
                id: e,
                version: c,
                display_name: d
            }
        }, this);
        var a = {
            app_list: b
        };
        Ext.apply(a, this.getSelectedAppFolderWhitelist());
        return a
    },
    getAppDepTipFormat: function() {
        return SYNO.SDS.Backup.String("app", "app_depend_app_restore_qtip")
    },
    getAppDepShareTipFormat: function() {
        return SYNO.SDS.Backup.String("app", "restore_share_depend_qtip")
    },
    getErrorMsg: function(a) {
        var b = "";
        if (a.get("error_code")) {
            b = SYNO.SDS.Backup.convertAppError(a.get("error_code"))
        }
        return b
    },
    getAppInfoTip: function(b, a) {
        var d = [];
        var f = this.getAppDepTip(b, a.get("id"), a.get("name"));
        if (!Ext.isEmpty(f)) {
            d.push(f)
        }
        var c = function(h, g) {
            return String.format(SYNO.SDS.Backup.String("app", "app_restore_action_also_" + h), g)
        };
        if ("skip" !== a.get("behavior")) {
            d.push(c(a.get("behavior"), a.get("name")))
        }
        var e = a.get("depend");
        if (e) {
            Ext.each(e.app_install_list, function(h) {
                var g = c(h.behavior, h.name);
                if ("skip" !== h.behavior && 0 > d.indexOf(g)) {
                    d.push(g)
                }
            })
        }
        return d.join("<br/>")
    },
    getSource: function() {
        return this.owner.getStep("share").getFileSourcePanel()
    },
    syncSourceTip: function(a) {
        var b = this.getSource();
        SYNO.Backup.Util.updateAppShareTip(b, a, SYNO.SDS.Backup.String("app", "tip_share_restore_by_app"))
    }
});
Ext.define("SYNO.SDS.Backup.AppParamsPanel", {
    extend: "SYNO.SDS.Backup.AppGridPanel",
    isStoreLoaded: false,
    checkedList: [],
    configList: [],
    AppAvailableTipId: undefined,
    AppEditId: "",
    AppEditColumnIdx: 4,
    constructor: function(b) {
        Ext.copyTo(this, b, "owner");
        var g = this.createColumnSelect();
        var e = this.createColumnAppInfo();
        var c = this.createColumnAppDependency();
        var f = this.createColumnAppSummary();
        var a = this.createColumnAppEdit();
        var h = "0px";
        if (b.owner.configWizard) {
            h = "12px"
        }
        var d = Ext.apply({
            layout: "fit",
            cls: "syno-backup-app-grid-panel",
            store: this.createStore(),
            enableHdMenu: false,
            bwrapStyle: {
                paddingTop: "0px",
                paddingBottom: "0px"
            },
            bbar: [new SYNO.ux.DisplayField({
                html: '<span class="syno-ux-note">' + _T("common", "note") + _T("common", "colon") + "&nbsp</span><span>" + SYNO.SDS.Backup.String("app", "source_pkg_wizard_title_tip") + "</span>"
            })],
            colModel: new Ext.grid.ColumnModel({
                columns: [g, e, c, f, a]
            }),
            viewConfig: {
                getRowClass: function(i, l, j, k) {
                    if (i.get("disabled")) {
                        return "syno-backup-app-grid-disabled-row"
                    }
                }
            },
            listeners: {
                rowmousedown: function(j, l, k) {
                    var i = j.getStore().getAt(l);
                    if (i.get("disabled")) {
                        return false
                    }
                }
            },
            plugins: [g]
        }, b);
        this.callParent([d])
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this, "rowclick", this.onRowClick, this)
    },
    createColumnAppEdit: function() {
        return new Ext.grid.Column({
            header: _T("common", "alt_edit"),
            width: 60,
            resizable: false,
            dataIndex: "edit",
            menuDisabled: true,
            renderer: function(g, b, a, h, e, c) {
                if (!this.isEnableAppEdit(a)) {
                    return
                }
                var f = "app-summary-button-hidden";
                if (a.get("checked") || true === a.get("disabled")) {
                    f = "app-summary-button-visible"
                }
                var d = new Ext.XTemplate('<div class="x-btn syno-ux-button syno-ux-button-default x-btn-icon syno-backup-cell-app-edit-button app-summary-button-tag {visibility_value}"><div class="syno-backup-cell-app-edit-button-icon app-summary-button-tag {visibility_value}"></div></div>');
                d.compile();
                return d.apply({
                    visibility_value: f
                })
            }.createDelegate(this)
        })
    },
    isEnableAppEdit: function(a) {
        var b = a.get("summary_edit_window");
        if (Ext.isEmpty(b) || !Ext.isString(b) || !a.get("is_running")) {
            return false
        }
        var c = Ext.isDefined(a.get("depend").invalid_shares) && 0 < a.get("depend").invalid_shares.length;
        if (true === a.get("disabled") && !c) {
            return false
        }
        return true
    },
    createStore: function() {
        return new Ext.data.JsonStore({
            id: "id",
            fields: ["id", "name", "version", "checked", "depend", "online_backup", "is_beta", "disabled", "app_custom_err_msg", "error_session", "error_key", "summary_disp", "summary_disp_tip", "summary_edit_window", "config", "is_running"],
            listeners: {
                scope: this,
                load: function(c, b) {
                    var a = true;
                    Ext.each(b, function(d) {
                        if (this.isEnableAppEdit(d)) {
                            a = false;
                            return false
                        }
                    }, this);
                    if (a) {
                        this.getColumnModel().setHidden(this.AppEditColumnIdx, true)
                    } else {
                        this.getColumnModel().setHidden(this.AppEditColumnIdx, false)
                    }
                    this.doLayout()
                }
            }
        })
    },
    getFileTree: function() {
        return this.owner.getSourceSelector()
    },
    syncSourceTip: function(a) {
        var b = this.getSource();
        SYNO.Backup.Util.updateAppShareTip(b, a, SYNO.SDS.Backup.String("app", "tip_share_backup_by_app"))
    },
    loadStore: function(a, b) {
        this.isStoreLoaded = false;
        this.sendWebAPI({
            api: "SYNO.Backup.App2.Backup",
            method: "list",
            version: 2,
            params: {
                app_config: this.configList,
                support_app_share: a
            },
            scope: this,
            callback: function(e, c, d) {
                if (!e) {
                    if (SYNO.SDS.Backup.ERR_APP_VOLUME === c.code) {
                        this.loadErrorCode = c.code
                    } else {
                        this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(c.code), function(f) {
                            this.owner.close()
                        }, this)
                    }
                }
                Ext.each(c, function(f) {
                    if (-1 < this.checkedList.indexOf(f.id)) {
                        f.checked = true
                    } else {
                        f.checked = false
                    }
                    Ext.each(this.configList, function(g) {
                        if (f.id === g.app) {
                            f.config = g.config
                        }
                    }, this)
                }, this);
                if (this.getStore()) {
                    this.getStore().loadData(c);
                    this.owner.doIfAppShareReady("app_loaded");
                    this.isStoreLoaded = true;
                    this.getStore().each(function(f) {
                        this.syncSourceTip(f)
                    }, this);
                    this.getStore().sort([{
                        field: "disabled",
                        direction: "ASC"
                    }, {
                        field: "name",
                        direction: "ASC"
                    }])
                }
                if (Ext.isFunction(b)) {
                    b()
                }
            }
        })
    },
    isLoaded: function() {
        return this.isStoreLoaded
    },
    needHide: function() {
        if (this.loadErrorCode) {
            return false
        }
        return (0 === this.getStore().data.items.length)
    },
    activate: function() {
        if (this.loadErrorCode) {
            this.bwrap.mask(SYNO.SDS.Backup.GetErrorString(this.loadErrorCode), "syno-ux-mask-info")
        }
    },
    onRowClick: function(b, f, d) {
        var c = Ext.fly(d.target);
        if (!c) {
            return
        }
        var a = this.store.getAt(f);
        if (c.hasClass("app-summary-button-tag")) {
            this.onAppSummaryEdit(a)
        }
    },
    onAppSummaryEdit: function(a) {
        var c = a.get("summary_edit_window");
        if (Ext.isEmpty(c) || !Ext.isString(c) || !a.get("is_running")) {
            return
        }
        var b = function() {
            var e = Ext.getClassByName(c);
            if (!(e.prototype instanceof SYNO.SDS.ModalWindow)) {
                SYNO.Debug.error(c + " is not extends from SYNO.SDS.ModalWindow.");
                return
            }
            var d = new e({
                owner: this.owner,
                config: a.get("config"),
                submitFn: Ext.createDelegate(this.onAppSummaryEditDone, this)
            });
            this.AppEditId = a.get("id");
            this.mon(d, "close", function() {
                this.AppEditId = ""
            });
            d.open()
        };
        SYNO.SDS.JSLoad(c, b, this)
    },
    onAppSummaryEditDone: function(b) {
        var a = this.getStore().getById(this.AppEditId);
        if (!a) {
            return
        }
        a.set("config", b);
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.App2.Backup",
            method: "get",
            version: 1,
            params: {
                app_name: this.AppEditId,
                app_config: b,
                support_app_share: this.owner.support_app_share
            },
            scope: this,
            callback: function(f, d, e) {
                this.owner.clearStatusBusy();
                if (!f) {
                    this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(d.code), function(g) {
                        this.owner.close()
                    }, this)
                }
                var c = this.getStore().getById(e.app_name);
                c.set("summary_disp", d.summary_disp);
                c.set("summary_disp_tip", d.summary_disp_tip);
                c.set("depend", d.depend);
                c.set("online_backup", d.online_backup);
                SYNO.SDS.Backup.setAppGridDependency(this, this.getFileTree(), true, false)
            }
        })
    },
    afterRender: function() {
        this.callParent(arguments);
        this.getView().refresh();
        if (this.owner.app_loaded) {
            if (this.loadErrorCode) {
                this.bwrap.mask(SYNO.SDS.Backup.GetErrorString(this.loadErrorCode), "syno-ux-mask-info")
            } else {
                if (Ext.isEmpty(this.getStore().data.items)) {
                    this.bwrap.mask(_T("backup", "no_application"), "syno-ux-mask-info")
                }
            }
        }
    },
    setAppCheckList: function(a) {
        this.checkedList = a
    },
    setAppNameList: function(a) {
        this.nameList = a
    },
    setAppLastConfig: function(a) {
        this.configList = a
    },
    getAppConfig: function() {
        var a = [];
        Ext.each(this.getStore().data.items, function(b) {
            if (b.get("checked") && !Ext.isEmpty(b.get("config"))) {
                a.push({
                    app: b.get("id"),
                    config: b.get("config")
                })
            }
        });
        return a
    },
    getParams: function() {
        return {
            app_list: this.getAppList(),
            app_config: this.getAppConfig()
        }
    },
    getNext: function() {
        var g = this.owner.getParams();
        var e = this.owner.getSourceSelector();
        var d = g.target_type + ":" + g.transfer_type;
        var c;
        var b;
        if ("share" === g.target_type && "local" === g.transfer_type) {
            c = g.share;
            b = e.getNodeById("/" + c);
            if (b && false !== b.getUI().getCheckValue()) {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("localbkp", "localbkp_dest_conflict_bkpshare"));
                return false
            }
        }
        var a = this.owner.getStep(this.nextId[d]).getForm();
        if (a && a.findField("dest_auto_unmount")) {
            a.findField("dest_auto_unmount").hide();
            a.findField("dest_auto_unmount").disable();
            if (!_D("usbstation") && this.owner.is_usb_share) {
                if (g.transfer_type === "local" || g.transfer_type === "image_local" || g.action === "export") {
                    a.findField("dest_auto_unmount").show();
                    a.findField("dest_auto_unmount").enable()
                }
            }
        }
        var f = g.target_type;
        if ("share" === f || "cloud" === f) {
            this.owner.setStatusBusy();
            this.sendWebAPI({
                api: "SYNO.Backup.Target",
                method: "get_candidate_dir",
                params: g,
                version: 1,
                encryption: SYNO.SDS.Backup.Util.getEncryption(["pwd", "secret", "remote_refresh_token", "remote_access_token"], g),
                timeout: 240000,
                scope: this,
                callback: function(k, h, i) {
                    this.owner.clearStatusBusy();
                    var j = null;
                    if (!k) {
                        this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(h.code));
                        return
                    }
                    j = h.candidate_dir;
                    this.owner.goNext(this.nextId[d]);
                    if (j) {
                        this.owner.setDestFolderName(j, g.target_type, g.transfer_type)
                    }
                }
            });
            return false
        } else {
            return this.nextId[d]
        }
    },
    getAppDepTipFormat: function() {
        return SYNO.SDS.Backup.String("app", "app_depend_app_backup")
    },
    getAppDepShareTipFormat: function() {
        return _T("backup", "share_depend_qtip")
    },
    getErrorMsg: function(a) {
        var d = "";
        if (!a.get("app_custom_err_msg") && !a.get("depend").invalid_shares && (!a.get("error_session") || !a.get("error_key"))) {
            return ""
        }
        d = SYNO.SDS.Backup.Util.htmlEncodeTip(SYNO.SDS.Backup.String("app", "cannot_backup_reason_prefix"));
        d += "<br/>";
        var c = a.get("depend").invalid_shares;
        if (Ext.isDefined(c) && 0 !== c.length) {
            d += "<br/>";
            d += SYNO.SDS.Backup.Util.htmlEncodeTip(SYNO.SDS.Backup.String("app", "err_mapped_shared_folder_restore"));
            var b = this.getSource().getDestination();
            if (!Ext.isEmpty(b) && -1 < c.indexOf(b.substr(1))) {
                d += "<br/>";
                d += String.format(SYNO.SDS.Backup.String("error", "localbkp_dest_conflict_bkpshare"), b.substr(1))
            }
        }
        if (a.get("error_session") && a.get("error_key")) {
            d += "<br/>";
            if ("not_support_new_framework" === a.get("error_key")) {
                if ("share" === this.owner.getParams().target_type || "cloud" === this.owner.getParams().target_type) {
                    d += SYNO.SDS.Backup.String("error", "not_support_new_framework_legacy_task")
                } else {
                    if ("image_remote" === this.owner.getParams().transfer_type && false === this.owner.isOnline) {
                        d += d = SYNO.SDS.Backup.String("error", "general_backup_destination_disconnect")
                    } else {
                        if ("image_remote" === this.owner.getParams().transfer_type) {
                            d += SYNO.SDS.Backup.String("error", "not_support_new_framework_vault")
                        } else {
                            d += SYNO.SDS.Backup.String("app", "restore_version_old")
                        }
                    }
                }
            } else {
                d += SYNO.SDS.Backup.Util.htmlEncodeTip(SYNO.SDS.Backup.String(a.get("error_session"), a.get("error_key")))
            }
        }
        if (a.get("app_custom_err_msg")) {
            d += "<br/>";
            d += SYNO.SDS.Backup.Util.htmlEncodeTip(a.get("app_custom_err_msg"))
        }
        return d
    },
    getAppInfoTip: function(b, a) {
        return this.getAppDepTip(b, a.get("id"), a.get("name"))
    },
    getSource: function() {
        return this.owner.getSourceSelector()
    }
});
Ext.define("SYNO.SDS.Backup.RotationParamsPanel", {
    extend: "SYNO.SDS.Backup.FormPanel",
    rotate_customize_retention: [],
    rotation_action: [],
    smart_rotation_setting: [
        [24 * 60 * 60, 60 * 60, 1],
        [28 * 24 * 60 * 60, 24 * 60 * 60, 1],
        [0, 7 * 24 * 60 * 60, 1]
    ],
    constructor: function(a) {
        var b = [{
            xtype: "syno_fieldset",
            itemId: "rotation_fieldset",
            cls: "syno-sds-backup-rotationParam-fieldset",
            labelWidth: 300,
            collapsible: false,
            items: this.configRotationFields(a)
        }];
        if (!Ext.isIE8) {
            this.previewer = new SYNO.SDS.Backup.Rotation.Previewer({
                cls: "syno-sds-backup-rotationPreviewer"
            });
            b.push(this.previewer)
        }
        var c = Ext.apply({
            height: 410,
            cls: "syno-sds-backup-rotationParamPanel",
            items: [b]
        }, a);
        this.rotate_customize_retention = this.rotate_customize_retention.concat(this.smart_rotation_setting);
        this.activated = false;
        this.lastTypeValue = false;
        return this.callParent([c])
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this, "activate", this.activate, this)
    },
    activate: function() {
        if (!this.activated) {
            var b = this.getForm().findField("backup_rotation");
            var a = this.getForm().items.filter("name", "backup_rotation_action").get(1);
            var c = this.getForm().findField("backup_rotation_condition_max_version");
            if (b && b.getEl()) {
                SYNO.ux.AddTip(b.getEl(), _T("backup", "rotate_enable_hint"))
            }
            if (a && a.getEl()) {
                var d = _T("backup", "rotate_action_smart_recycle_description") + "<br/><br/><b>" + _T("backup", "rotate_action_smart_recycle_hourly") + "</b><br/>" + _T("backup", "rotate_action_smart_recycle_hourly_hint") + "<br/><br/><b>" + _T("backup", "rotate_action_smart_recycle_daily") + "</b><br/>" + _T("backup", "rotate_action_smart_recycle_daily_hint") + "<br/><br/><b>" + _T("backup", "rotate_action_smart_recycle_weekly") + "</b><br/>" + _T("backup", "rotate_action_smart_recycle_weekly_hint") + "<br/>";
                SYNO.ux.AddTip(a, d)
            }
            if (c && c.getEl()) {
                var e = SYNO.SDS.Backup.String("app", "rotate_condition_desc");
                SYNO.ux.AddTip(c, e)
            }
            this.activated = true
        }
        this.doLayout();
        if (this.previewer) {
            this.updatePreviewer()
        }
        this.changeSynoCloudRotateView()
    },
    isSynoCloudType: function() {
        return (SYNO.SDS.Backup.Client.Common.Utils.AccountMeta.ROTATION_BASIC === this.owner.accountMeta.versionRotation)
    },
    changeSynoCloudRotateView: function() {
        var c = (function(d) {
            return this.getComponent("rotation_fieldset").getComponent(d)
        }).createDelegate(this);
        var a = (function(d) {
            return this.getForm().findField(d)
        }).createDelegate(this);
        var b = this.isSynoCloudType();
        if (this.lastTypeValue === b) {
            return
        }
        this.lastTypeValue = b;
        this.rotate_customize_retention = b ? [
            [2419200, 604800, 1],
            [604800, 86400, 1]
        ] : [
            [86400, 3600, 1],
            [2419200, 86400, 1],
            [0, 604800, 1]
        ];
        a("backup_rotation").setValue(b);
        a("backup_rotation").setDisabled(b);
        a("rotate_condition_desc").setVisible(!b);
        a("rotate_action_desc").setVisible(!b);
        a("backup_rotation_condition_max_version").setValue(b ? 10 : 256);
        a("backup_rotation_condition_max_version").setVisible(!b);
        a("synocloud_rotation_desc").setVisible(b);
        c("rotate_earliest").setValue(!b);
        c("rotate_earliest").setVisible(!b);
        c("rotate_smart_recycle").setVisible(!b);
        c("rotate_customize_retention").setValue(b);
        c("rotate_customize_retention").setVisible(!b);
        c("rotate_customize_retention_setting").setVisible(!b);
        this.updatePreviewer()
    },
    configRotationFields: function(a) {
        this.customize_button_id = Ext.id();
        var b = [{
            xtype: "syno_checkbox",
            name: "backup_rotation",
            groupFields: {
                enable: ["backup_rotation_action", "backup_rotation_condition_max_version"]
            },
            boxLabel: _T("backup", "enable_backup_rotation"),
            listeners: {
                check: function() {
                    this.updatePreviewer()
                },
                scope: this
            }
        }, {
            xtype: "syno_displayfield",
            name: "rotate_action_desc",
            indent: 1,
            value: SYNO.SDS.Backup.String("app", "rotate_action_description")
        }, {
            xtype: "syno_radio",
            indent: 1,
            name: "backup_rotation_action",
            itemId: "rotate_earliest",
            inputValue: "rotate_earliest",
            checked: true,
            boxLabel: _T("backup", "rotate_action_earliest"),
            listeners: {
                check: function(d, c) {
                    if (c) {
                        this.updatePreviewer("rotate_earliest")
                    }
                },
                scope: this
            }
        }, {
            xtype: "syno_radio",
            indent: 1,
            name: "backup_rotation_action",
            itemId: "rotate_smart_recycle",
            inputValue: "rotate_smart_recycle",
            boxLabel: _T("backup", "rotate_action_smart_recycle"),
            listeners: {
                check: function(d, c) {
                    if (c) {
                        this.updatePreviewer("rotate_smart_recycle")
                    }
                },
                scope: this
            }
        }, {
            xtype: "syno_radio",
            indent: 1,
            name: "backup_rotation_action",
            itemId: "rotate_customize_retention",
            inputValue: "rotate_customize_retention",
            groupFields: [this.customize_button_id],
            boxLabel: SYNO.SDS.Backup.String("app", "customized_retention"),
            listeners: {
                check: function(d, c) {
                    if (c) {
                        this.updatePreviewer("rotate_customize_retention")
                    }
                },
                scope: this
            }
        }, {
            xtype: "syno_button",
            id: this.customize_button_id,
            indent: 2,
            itemId: "rotate_customize_retention_setting",
            text: _T("common", "common_settings"),
            handler: this.openCustomizedRetentionWindow,
            scope: this
        }, {
            xtype: "syno_displayfield",
            name: "synocloud_rotation_desc",
            cls: "syno-sds-backup-synocloud-rotation-desc",
            indent: 1,
            value: SYNO.SDS.Backup.String("synocloud", "rotation_description"),
            hidden: true,
            htmlEncode: false
        }, {
            xtype: "container",
            layout: {
                type: "hbox"
            },
            items: [{
                xtype: "syno_displayfield",
                cls: "syno-sds-backup-rotation-maximumVer-text",
                name: "backup_rotation_condition_max_label",
                value: SYNO.SDS.Backup.String("app", "rotate_maximum_versions") + ":"
            }, {
                xtype: "syno_numberfield",
                cls: "syno-sds-backup-rotation-maximumVer-num-field",
                allowBlank: false,
                name: "backup_rotation_condition_max_version",
                width: 60,
                value: 256,
                minValue: 1,
                indent: 1,
                maxValue: 65535,
                enableKeyEvents: true,
                listeners: {
                    keyup: function() {
                        this.updatePreviewer()
                    },
                    scope: this
                }
            }]
        }, {
            xtype: "syno_displayfield",
            cls: "syno-sds-backup-rotationPreviewer-title",
            value: SYNO.SDS.Backup.String("app", "rotate_retention_description")
        }];
        return b
    },
    loadData: function(b) {
        var a = this.getForm().findField("backup_rotation");
        if (Ext.isBoolean(b.enable_rotate)) {
            a.setValue(b.enable_rotate)
        }
        if (!Ext.isEmpty(b.rotate_option)) {
            this.setRotationOptionValue(b.rotate_option)
        } else {
            if (Ext.isArray(b.rotate_action)) {
                if (0 < b.rotate_action.length) {
                    this.setRotationOptionValue("rotate_smart_recycle")
                } else {
                    this.setRotationOptionValue("rotate_earliest")
                }
            }
        }
        if (Ext.isArray(b.rotate_action)) {
            this.rotation_action = b.rotate_action
        }
        if (Ext.isArray(b.rotate_customized_rules)) {
            this.rotate_customize_retention = b.rotate_customized_rules
        }
        var c = this.getForm().findField("backup_rotation_condition_max_version");
        if (c) {
            if (Ext.isArray(b.rotate_condition)) {
                c.setValue(b.rotate_condition[1])
            } else {
                c.setValue(256)
            }
        }
    },
    getRotationParams: function(d) {
        var a = this.getForm().findField("backup_rotation");
        var b = this.getForm().findField("backup_rotation_condition_max_version");
        var c = {};
        c.rotate_params = {};
        c.rotate_params.enable_rotate = a.getValue();
        d = Ext.isDefined(d) ? d : this.getRotationOptionValue();
        if ("rotate_earliest" === d) {
            c.rotate_params.rotate_option = "rotate_earliest";
            c.rotate_params.rotate_action = []
        } else {
            if ("rotate_smart_recycle" === d) {
                c.rotate_params.rotate_option = "rotate_smart_recycle";
                c.rotate_params.rotate_action = this.smart_rotation_setting
            } else {
                if ("rotate_customize_retention" === d) {
                    c.rotate_params.rotate_option = "rotate_customize_retention";
                    c.rotate_params.rotate_action = this.rotate_customize_retention
                }
            }
        }
        c.rotate_params.rotate_condition = [1, b.getValue()];
        c.rotate_params.rotate_customized_rules = this.rotate_customize_retention;
        return c
    },
    getParams: function(a) {
        var b = this.getRotationParams();
        if (!b.rotate_params.enable_rotate) {
            delete b.rotate_params.rotate_action;
            delete b.rotate_params.rotate_condition
        }
        return b
    },
    updatePreviewer: function(c) {
        if (this.activated && this.previewer) {
            var a = this.owner.getParams().schedule;
            var b = this.getRotationParams(c).rotate_params;
            b.isSynoCloudType = this.isSynoCloudType();
            this.previewer.updatePreviewer(a, b)
        }
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        return this.nextId
    },
    openCustomizedRetentionWindow: function() {
        var b = [];
        b = b.concat(this.rotate_customize_retention);
        var a = new SYNO.SDS.Backup.Client.Common.RetentionSetting.CustomizedWindow({
            title: SYNO.SDS.Backup.String("app", "customized_retention_title"),
            owner: this.owner,
            appWin: this.appWin,
            retention_rules: b
        });
        this.mon(a, "setCustomizedRetention", this.onSetCustomizedRetention, this);
        a.open()
    },
    onSetCustomizedRetention: function(a) {
        this.rotate_customize_retention = a.rotate_customize_retention;
        this.updatePreviewer()
    },
    getRotationOptionList: function() {
        return this.getForm().items.items.filter(function(a) {
            if (a.name === "backup_rotation_action") {
                return true
            }
        })
    },
    setRotationOptionValue: function(a) {
        var b = this.getRotationOptionList();
        Ext.each(b, function(c) {
            if (a === c.itemId) {
                c.setValue(true)
            } else {
                c.setValue(false)
            }
        })
    },
    getRotationOptionValue: function() {
        var b = this.getRotationOptionList();
        var a = "";
        Ext.each(b, function(c) {
            if (c.getValue()) {
                a = c.itemId;
                return false
            }
        });
        return a
    }
});
Ext.define("SYNO.SDS.Backup.TaskCreateWizard", {
    extend: "SYNO.SDS.Backup.Wizard",
    wizardAnchor: "",
    support_app_share: false,
    support_detect_time_limit: false,
    accountMeta: SYNO.SDS.Backup.Client.Common.Utils.createAccountMeta(),
    constructor: function(b) {
        var e = SYNO.Backup.Addon.Config.addon_list;
        var f = function() {
            var g = {};
            Ext.each(e, function(i, h, j) {
                g[i.id] = i.id + "::dest_setting"
            });
            return g
        };
        var a = function() {
            var g = {};
            Ext.each(e, function(i, h, k) {
                var j = i.target_type + ":" + i.transfer_type;
                g[j] = i.id + ":" + i.target_type + ":task_setting"
            });
            return g
        };
        var c = [new SYNO.SDS.Backup.RepoTypePanel({
            owner: this,
            itemId: "repo_type",
            nextId: f(),
            headline: SYNO.SDS.Backup.String("app", "select_dest_title")
        }), new SYNO.SDS.Backup.Repository.NetworkCreateStep({
            owner: this,
            itemId: "legacy_rsync::dest_folder_setting",
            nextId: "source_repo_legacy",
            headline: SYNO.SDS.Backup.String("app", "repo_info_wizard_title")
        }), new SYNO.SDS.Backup.TaskSourceContainerWrapper({
            owner: this,
            appWin: b.appWin,
            itemId: "source_repo_legacy",
            isImage: false,
            pre_load_folder_done: true,
            nextId: "app",
            headline: SYNO.SDS.Backup.String("app", "source_share_wizard_title")
        }), new SYNO.SDS.Backup.TaskSourceContainerWrapper({
            owner: this,
            appWin: b.appWin,
            itemId: "source_repo_image",
            isImage: true,
            pre_load_folder_done: true,
            nextId: "app",
            headline: SYNO.SDS.Backup.String("app", "source_share_wizard_title")
        }), new SYNO.SDS.Backup.AppParamsPanel({
            owner: this,
            appWin: b.appWin,
            itemId: "app",
            headline: SYNO.SDS.Backup.String("app", "source_pkg_wizard_title"),
            bodyStyle: "max-height: 373px; min-height: 373px",
            nextId: a()
        }), new SYNO.SDS.Backup.RotationParamsPanel({
            owner: this,
            appWin: b.appWin,
            itemId: "rotate",
            headline: _T("backup", "backup_rotation_settings"),
            nextId: null
        })];
        var d = Ext.apply({
            title: _T("bkpwizard", "wizard_title"),
            cls: "syno-backup-create-wizard",
            banner: true,
            width: 680,
            height: 580,
            steps: c
        }, b);
        this.callParent([d])
    },
    createStep: function(h) {
        var c = h.split(":")[0];
        var a = h.split(":")[2];
        var e = null;
        var g = SYNO.Backup.Addon.Util.getInfo(c);
        if ("dest_setting" === a) {
            var f = SYNO.Backup.Addon.Util.getClass(c, "Destination.SettingPanel");
            if (f) {
                var d = SYNO.Backup.Util.IsImage(g.target_type) ? "source_repo_image" : "source_repo_legacy";
                e = new f({
                    appWin: this.appWin,
                    owner: this,
                    cls: "syno-backup-base-destination-setting",
                    itemId: h,
                    target_type: g.target_type,
                    transfer_type: g.transfer_type,
                    nextId: g.options.dest_setting_nextId ? g.options.dest_setting_nextId : d,
                    headline: SYNO.SDS.Backup.String("app", "repo_info_wizard_title"),
                    description: SYNO.SDS.Backup.String("app", "repo_info_wizard_desc")
                })
            }
        } else {
            if ("task_setting" === a) {
                var b = SYNO.Backup.Addon.Util.getClass(c, "Task.SettingPanel");
                if (b) {
                    e = new b({
                        appWin: this.appWin,
                        owner: this,
                        itemId: h,
                        target_type: g.target_type,
                        transfer_type: g.transfer_type,
                        nextId: "rotate",
                        headline: _T("backup", "backup_settings")
                    })
                }
            }
        }
        return e
    },
    initializeTask: function() {
        var a = this.getActiveStep();
        if (!a || (Ext.isFunction(a.isValid) && !a.isValid())) {
            return false
        }
        var b = this.getParams();
        this.setStatusBusy();
        if (!b.repo_id) {
            if ("image_remote" === b.transfer_type) {
                delete b.enc_port
            }
            if ("export" === b.action) {
                if ("image_remote" === b.transfer_type) {
                    b.transfer_type = "image_local"
                } else {
                    b.transfer_type = "local"
                }
                b.account = _S("user")
            }
            b.name = b.repo_name;
            delete b.backup_params.encrypt_password;
            delete b.backup_params.encrypt_password_confirm;
            delete b.clientEncrypt;
            this.sendWebAPI({
                api: "SYNO.Backup.Repository",
                version: 1,
                method: "create",
                encryption: SYNO.SDS.Backup.Util.getEncryption(["pwd", "secret"], b),
                params: b,
                callback: this.onCreateRepoDone,
                scope: this
            })
        } else {
            this.createTask(b)
        }
    },
    onCreateRepoDone: function(d, a, b) {
        if (!d || a.has_fail) {
            this.reportError(a);
            this.clearStatusBusy();
            return
        }
        var c = this.getParams();
        Ext.apply(c, {
            repo_id: a.repo_id
        });
        if ("export" === c.action) {
            c.transfer_type = "local"
        }
        this.createTask(c, c.action)
    },
    getRepoInfo: function() {
        return this.getParams()
    },
    getSourceSelector: function() {
        var a = SYNO.Backup.Util.IsImage(this.getParams().target_type) ? "source_repo_image" : "source_repo_legacy";
        return this.getStep(a).getSourceSelector()
    },
    getAppPanel: function() {
        return this.getStep("app")
    },
    loadAppParams: function() {
        this.getAppPanel().setAppCheckList(this.getAppPanel().getAppList());
        this.getAppPanel().setAppLastConfig(this.getAppPanel().getAppConfig());
        this.getAppPanel().loadStore(this.support_app_share)
    },
    doIfAppShareReady: function(a) {
        this[a] = true;
        if (this.app_loaded && this.folder_loaded && this.folder_initialed) {
            SYNO.SDS.Backup.setAppGridDependency(this.getAppPanel(), this.getSourceSelector(), true, false)
        }
    },
    createTask: function(b) {
        var a = {
            app_list: Ext.isEmpty(b.app_list) ? [] : b.app_list,
            file_list: Ext.isEmpty(b.file_list) ? [] : b.file_list,
            app_config: Ext.isEmpty(b.app_config) ? [] : b.app_config
        };
        if (SYNO.Backup.Util.IsImage(b.target_type)) {
            a.backup_filter = b.backup_filter;
            a.backup_volumes = Ext.isEmpty(b.backup_volumes) ? [] : b.backup_volumes
        }
        var c = Ext.apply({
            name: b.name,
            source: a
        }, b);
        delete c.app_list;
        delete c.file_list;
        delete c.app_config;
        delete c.backup_filter;
        delete c.backup_volumes;
        delete c.clientEncrypt;
        if (this.data_enc) {
            c.backup_params.enable_data_encrypt = true
        }
        if (this.data_comp) {
            c.backup_params.enable_data_compress = true
        }
        if ("relink" === c.action && !Ext.isEmpty(this.sess_id)) {
            Ext.apply(c, {
                sess_id: this.sess_id
            })
        }
        if (!Ext.isEmpty(c.backup_params.encrypt_password)) {
            c.encrypt_password = c.backup_params.encrypt_password
        }
        delete c.backup_params.encrypt_password;
        delete c.backup_params.encrypt_password_confirm;
        this.sendWebAPI({
            api: "SYNO.Backup.Task",
            version: 1,
            method: "create",
            encryption: SYNO.SDS.Backup.Util.getEncryption(["pwd", "secret", "encrypt_password"], c),
            params: c,
            timeout: 240000,
            callback: this.onCreateTaskDone,
            scope: this
        })
    },
    onCreateTaskDone: function(d, a, b) {
        if (!d) {
            this.clearStatusBusy();
            this.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(a.code), function() {
                if (SYNO.SDS.Backup.ERR_SESSION_EXPIRED === a.code) {
                    this.close()
                }
            }, this);
            return
        }
        var c = this.getParams();
        if (this.callbacks && this.callbacks.apply) {
            this.callbacks.apply.call(this.callbacks.scope || window, a, b)
        }
        if (!Ext.isEmpty(c.backup_params.encrypt_password)) {
            this.findAppWindow().downloadWebAPI({
                webapi: {
                    api: "SYNO.Backup.Target",
                    version: 1,
                    method: "private_key_download_by_password",
                    params: {
                        task_id: a.task_id,
                        password: c.backup_params.encrypt_password,
                        file_name: b.name,
                        support_utf8_name: Ext.isChrome || Ext.isGecko || Ext.isSafari
                    },
                    encryption: ["password"]
                }
            })
        }
        this.owner.onTaskCreated(a.task_id, function() {
            if ("create" === c.action || "export" === c.action) {
                var e = "";
                if ("create" === c.action) {
                    e = SYNO.SDS.Backup.String("app", "backup_now_confirm")
                } else {
                    if ("export" === c.action) {
                        e = SYNO.SDS.Backup.String("app", "export_now_confirm_dont_change_target_name")
                    }
                }
                this.getMsgBox().confirm(_T("tree", "leaf_backup"), e, function(f) {
                    if ("yes" === f) {
                        this.appWin.getActivePage().onBackupNow()
                    }
                    this.clearStatusBusy();
                    this.close()
                }, this)
            } else {
                this.clearStatusBusy();
                this.close()
            }
        }, this)
    },
    createTaskDefaultName: function(b) {
        var a = 1;
        while (true) {
            if (this.isTaskNameValid(b + " " + a)) {
                break
            }
            a++
        }
        return b + " " + a
    },
    isTaskNameValid: function(a) {
        return -1 === this.owner.getTaskNameList().indexOf(a)
    },
    setDestFolderName: function(b, e, a) {
        var d;
        if (a === "local") {
            d = this.getStep("legacy_local:share:task_setting").getForm()
        } else {
            if (a === "rsync") {
                d = this.getStep("legacy_rsync:share:task_setting").getForm()
            } else {
                if (a === "rsync_ds") {
                    d = this.getStep("legacy_rsync_ds:share:task_setting").getForm()
                } else {
                    if (a === "aws_s3") {
                        d = this.getStep("legacy_aws_s3:cloud:task_setting").getForm()
                    } else {
                        if (a === "azure_blob") {
                            d = this.getStep("legacy_azure_blob:cloud:task_setting").getForm()
                        } else {
                            if (a === "sfr_s3") {
                                d = this.getStep("legacy_sfr_s3:cloud:task_setting").getForm()
                            } else {
                                if (a === "hicloud_s3") {
                                    d = this.getStep("legacy_hicloud_s3:cloud:task_setting").getForm()
                                } else {
                                    return
                                }
                            }
                        }
                    }
                }
            }
        }
        var c = e + ":" + a;
        if (d.getValues().task_dir && this.choosedType === c) {
            return
        }
        this.choosedType = c;
        d.findField("task_dir").setValue(b);
        return
    },
    getLocalRepoVolume: function() {
        var a;
        if (this.lastStepId) {
            a = this.stepStack.concat([this.lastStepId])
        } else {
            a = this.stepStack
        }
        var b = null;
        Ext.each(a, function(d) {
            var c = this.getStep(d);
            if (Ext.isFunction(c.getLocalRepoVolume)) {
                b = this.getStep(d).getLocalRepoVolume();
                if (b) {
                    return false
                }
            }
        }, this);
        return b
    },
    reportError: function(a, b) {
        b = b || {};
        if (!this.reporter) {
            this.reporter = new SYNO.SDS.Backup.ApiHelper({
                owner: this
            })
        }
        this.reporter.alert(a, b.callback, b.scope)
    }
});
Ext.define("SYNO.SDS.Backup.Restore.RestoreListView", {
    extend: "SYNO.ux.ExpandableListView",
    constructor: function(a) {
        this.callParent(arguments);
        this.addClass("syno-backup-restore-progress-listview")
    },
    createTpl: function() {
        var a = new Ext.XTemplate('<tpl for="."><div class="item-wrap"><div class="item-summary"><div class="item-icon {icon_cls} icon-task" style="{style}"></div><div><span class="item-title">{display_name:htmlEncode}</span><tpl if="version != null && version != \'\'"><span class="version-text"> ({version:htmlEncode}) </span></tpl><div class="status-wrapper ' + this.getStatusStyle() + '">{status_str}</div></div></div></div></tpl><div class="x-clear"></div>');
        return a
    },
    checkShowFn: function(a) {
        return (0 < this.getStore().getCount())
    },
    mapDisplayName: function(b) {
        var a = {
            system_config: _T("confbackup", "config"),
            shared_folder: _T("backup", "data"),
            app: SYNO.SDS.Backup.String("app", "application_install_update")
        };
        if ("app" === b.stage && "app_install_update" !== b.id) {
            b.display_name = b.display_name
        } else {
            if (b.stage in a) {
                b.display_name = a[b.stage]
            } else {
                b.display_name = b.stage
            }
        }
    },
    mapStatusStr: function(a) {
        if ("done" === a.status) {
            a.status_str = _T("backup", "restore_success");
            a.status_class = "green-status"
        } else {
            if ("waiting" === a.status) {
                a.status_str = _T("netbackup", "netbkp_wait_sync");
                a.status_class = "disable-font"
            } else {
                if ("failed" === a.status) {
                    a.status_str = _T("backup", "restore_fail");
                    a.status_class = "red-status"
                } else {
                    if ("cancel" === a.status) {
                        a.status_str = _T("usbbackup", "usbbkp_cancel");
                        a.status_class = "red-status"
                    } else {
                        if ("partial" === a.status) {
                            a.status_str = _T("backup", "status_partial");
                            a.status_class = "orange-status"
                        } else {
                            if ("canceling" === a.status) {
                                a.status_str = _T("backup", "restore_do_cancel");
                                a.status_class = "red-status"
                            }
                        }
                    }
                }
            }
        }
    },
    getStatusStyle: function() {},
    prepareData: function(c, b, a) {}
});
Ext.define("SYNO.SDS.Backup.Restore.ProgressView", {
    extend: "SYNO.SDS.Backup.Restore.RestoreListView",
    WINDOW_SIZE: 5,
    constructor: function(a) {
        this.transSizeBuf = [];
        this.callParent(arguments)
    },
    createTpl: function() {
        var d = '<span class="item-title">{display_name:htmlEncode}</span><tpl if="version != null && version != \'\'"><span class="version-text"> ({version:htmlEncode}) </span></tpl>';
        var b = '<div class="status-wrapper {status_class}">{status_str}</div>';
        var a = '<div class="syno-backup-usage" ext:qtip="{tran_speed}"><div class="syno-backup-percentage-bar-bg"><div class="syno-backup-percentage-bar" style="width:{percentage * 1.87}px"></div></div><span class="blue-status percentage-text" ext:qtip="{tran_speed}">{progress_left}</span><span class="percentage-text percentage-denominator">{progress_right}</span></div>';
        var c = new Ext.XTemplate('<tpl for=".">', '<div class="item-wrap">', '<div class="item-summary">', '<div class="item-icon {icon_cls} icon-task" style="{style}"></div>', '<div class="item-wrapper">', d, b, "</div>", '<tpl if="has_progress">', a, "</tpl>", "</div>", "</div>", "</tpl>", '<div class="x-clear"></div>');
        return c
    },
    calTranSpeed: function(b) {
        var d = this.transSizeBuf;
        var c = parseInt(b.get("processed_size"), 10);
        if (d.length > 0 && d[0].tran_size > c) {
            d.length = 0
        }
        d.unshift({
            tran_size: c,
            tran_time: new Date().getTime()
        });
        if (d.length > this.WINDOW_SIZE) {
            d.pop()
        }
        if (d.length > 1) {
            var a = (d[0].tran_size - d[d.length - 1].tran_size) * 1000;
            if (a >= 0) {
                var e = a / (d[0].tran_time - d[d.length - 1].tran_time);
                b.data.tran_speed = SYNO.SDS.Backup.ConverSize(e, 2) + "/s"
            } else {
                b.data.tran_speed = ""
            }
        } else {
            b.data.tran_speed = ""
        }
    },
    appStatusStringGet: function(a, c) {
        var b;
        if ("install" === c) {
            b = "installing_something"
        } else {
            if ("reinstall" === c) {
                b = "reinstalling_something"
            } else {
                if ("upgrade" === c) {
                    b = "upgrading_something"
                } else {
                    b = "restoring_something"
                }
            }
        }
        return String.format(_T("backup", b), a)
    },
    prepareData: function(d, c, a) {
        d.icon_cls = "";
        d.style = "";
        d.status_str = "";
        this.mapStatusStr(d);
        if ("" === d.status_str) {
            if ("app" === d.stage) {
                if ("app_install_update" === d.id) {
                    d.status_str = this.appStatusStringGet(d.current_object_name, d.current_object_status)
                } else {
                    if (d.hasOwnProperty("percentage")) {
                        d.app_stage = (d.app_stage) ? d.app_stage : "";
                        d.progress_left = SYNO.SDS.Backup.ConverSize(d.processed_size, 2);
                        if (0 < d.percentage) {
                            d.progress_right = "&nbsp;(" + d.percentage + "%)"
                        } else {
                            d.progress_right = ""
                        }
                        if (Ext.isEmpty(d.app_stage)) {
                            d.status_str = _T("backup", "restoring")
                        } else {
                            d.status_str = String.format(SYNO.SDS.Backup.String("app", "restoring_app_something"), d.app_stage)
                        }
                    } else {
                        d.status_str = _T("backup", "restoring")
                    }
                }
            } else {
                if ("shared_folder" === d.stage) {
                    if ("0" !== d.total_size) {
                        this.calTranSpeed(a);
                        d.progress_left = SYNO.SDS.Backup.ConverSize(d.processed_size, 2);
                        d.progress_right = "&nbsp;/&nbsp;" + SYNO.SDS.Backup.ConverSize(d.total_size, 2);
                        if (d.current_object_name) {
                            d.status_str = String.format(_T("backup", "restoring_something"), d.current_object_name)
                        } else {
                            d.status_str = _T("backup", "restoring")
                        }
                    } else {
                        d.status_str = _T("backup", "restoring")
                    }
                } else {
                    if ("system_config" === d.stage) {
                        d.progress_left = d.percentage + "%";
                        if ("initializing" === d.current_object_id) {
                            d.status_str = _T("confbackup", "confbkp_st_init")
                        } else {
                            if ("stopping_system_service" === d.current_object_id) {
                                d.status_str = _T("confbackup", "confbkp_st_service_stop")
                            } else {
                                if ("starting_system_service" === d.current_object_id) {
                                    d.status_str = _T("confbackup", "confbkp_st_service_start")
                                } else {
                                    if (d.current_object_name) {
                                        d.status_str = String.format(_T("backup", "restoring_something"), SYNO.SDS.Backup.converLanString(d.current_object_name))
                                    } else {
                                        d.status_str = _T("backup", "restoring")
                                    }
                                }
                            }
                        }
                    }
                }
            }
            d.status_class = "blue-status"
        }
        d.has_progress = (d.progress_left) ? true : false;
        this.mapDisplayName(d);
        if ("app" !== d.stage || d.id === "app_install_update") {
            d.icon_cls = "syno-backup-restore-progress-" + d.stage
        } else {
            var b = SYNO.SDS.Backup.getAppIconPath(d.id, d.version);
            d.style = "background-size: cover; background-image:url(" + b + ")"
        }
        return d
    }
});
Ext.define("SYNO.SDS.Backup.Restore.SuccessStageView", {
    extend: "SYNO.SDS.Backup.Restore.RestoreListView",
    getStatusStyle: function() {
        return "green-status"
    },
    prepareData: function(d, c, a) {
        d.icon_cls = "";
        d.style = "";
        if (!d.version) {
            d.version = null
        }
        d.status_str = _T("backup", "restore_success");
        this.mapDisplayName(d);
        if ("app" !== d.stage || d.id === "app_install_update") {
            d.icon_cls = "syno-backup-restore-progress-" + d.stage
        } else {
            var b = SYNO.SDS.Backup.getAppIconPath(d.id, d.version);
            d.style = "background-size: cover; background-image:url(" + b + ")"
        }
        return d
    }
});
Ext.define("SYNO.SDS.Backup.Restore.IssueStageView", {
    extend: "SYNO.SDS.Backup.Restore.RestoreListView",
    getStatusStyle: function() {
        return "red-status"
    },
    prepareData: function(d, c, a) {
        d.icon_cls = "";
        d.style = "";
        if (!d.version) {
            d.version = null
        }
        if (d.error_code || d.error_string) {
            d.status_str = SYNO.SDS.Backup.convertAppError(d.error_code, d.error_string)
        } else {
            this.mapStatusStr(d)
        }
        this.mapDisplayName(d);
        if ("app" !== d.stage || d.id === "app_install_update") {
            d.icon_cls = "syno-backup-restore-progress-" + d.stage
        } else {
            var b = SYNO.SDS.Backup.getAppIconPath(d.id, d.version);
            d.style = "background-size: cover; background-image:url(" + b + ")"
        }
        return d
    }
});
Ext.define("SYNO.SDS.Backup.Restore.ProgressPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(a) {
        a = this.fillConfig(a);
        this.callParent([a])
    },
    initEvents: function() {
        this.on("afterrender", this.startPolling, this);
        this.on("beforeclose", this.stopPolling, this)
    },
    fillConfig: function(a) {
        return Ext.apply({
            items: [this.processingFieldSet = new SYNO.ux.FieldSet({
                title: _T("backup", "restore_progress"),
                items: [this.getProcessingView()]
            }), this.issueFieldSet = new SYNO.ux.FieldSet({
                title: SYNO.SDS.Backup.String("app", "restoration_issue_title"),
                items: [this.getIssueView()],
                hidden: true
            }), this.successFieldSet = new SYNO.ux.FieldSet({
                title: SYNO.SDS.Backup.String("app", "success_restoration"),
                items: [this.getSuccessView()],
                hidden: true
            })]
        }, a)
    },
    startPolling: function() {
        this.pollingID = this.pollReg({
            webapi: {
                api: "SYNO.Backup.Restore",
                version: 1,
                method: "status",
                params: {
                    restore_id: this.owner.restore_id
                }
            },
            interval: 2,
            immediate: true,
            scope: this,
            status_callback: this.onPollingDone
        })
    },
    stopPolling: function() {
        this.pollUnreg(this.pollingID)
    },
    setCancelStatus: function(b) {
        this.isCanceling = true;
        var a = [];
        Ext.each(this.getProcessingStore().data.items, function(c) {
            var d = {};
            d.stage = c.data.stage;
            if (d.stage === b && (!c.data.status || "waiting" === c.data.status || "restoring" === c.data.status)) {
                d.status = "canceling"
            }
            Ext.applyIf(d, c.data);
            a.push(d)
        });
        this.loadDataAndDecideShow(this.processingFieldSet, a)
    },
    onPollingDone: function(e, b, d, c) {
        if (!e) {
            return
        }
        if (-1 === this.owner.restore_id) {
            this.owner.restore_id = b.restore_id;
            this.stopPolling();
            this.startPolling()
        }
        if ("init" === b.current_stage || "system_config" === b.current_stage || "none" === b.current_stage || this.isCanceling) {
            this.owner.getButton("cancel").disable()
        } else {
            if (true === _S("is_admin")) {
                this.owner.getButton("cancel").enable()
            }
        }
        if (!(b.processing_stage)) {
            if (0 === this.owner.maskCnt) {
                this.owner.setStatusBusy()
            }
            return
        }
        if (b.finish) {
            this.owner.getButton("ok").enable();
            this.owner.getButton("cancel").disable();
            this.loadDataAndDecideShow(this.issueFieldSet, b.issue_stage);
            var a = function(f) {
                return "app" === f.stage
            };
            if (b.success_stage && b.success_stage.some(a)) {
                SYNO.SDS.StatusNotifier.fireEvent("thirdpartychanged")
            }
            this.stopPolling();
            if (Ext.isDefined(b.init_error_code)) {
                this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(b.init_error_code), function() {
                    this.owner.close()
                }, this)
            }
        } else {
            if (this.isCanceling) {
                return
            }
        }
        if (!b.finish && "success" === b.current_stage) {
            if (0 === this.owner.maskCnt) {
                this.owner.setStatusBusy()
            }
        } else {
            this.owner.clearStatusBusy()
        }
        this.view.setHeight(10 + b.processing_stage.length * 50);
        this.processingFieldSet.setVisible(true);
        this.loadDataAndDecideShow(this.processingFieldSet, b.processing_stage);
        this.loadDataAndDecideShow(this.issueFieldSet, b.issue_stage);
        this.loadDataAndDecideShow(this.successFieldSet, b.success_stage)
    },
    loadDataAndDecideShow: function(d, c) {
        var b = 59;
        var e = 36;
        if (!d || !c) {
            return
        }
        var a = d.getComponent("viewWrapper");
        if (!a.getStore()) {
            return
        }
        a.getStore().loadData(c);
        if (!a.checkShowFn()) {
            d.hide()
        } else {
            d.show();
            d.setHeight(e + b * c.length)
        }
        this.owner.doLayout()
    },
    getProcessingStore: function() {
        if (!this.store) {
            this.store = new Ext.data.JsonStore({
                id: "id",
                fields: ["id", "stage", "status", "percentage", "total_size", "processed_size", "current_object_id", "current_object_name", "current_object_status", "version", "display_name", "app_stage"]
            })
        }
        return this.store
    },
    getSuccessStore: function() {
        if (!this.successStore) {
            this.successStore = new Ext.data.JsonStore({
                id: "id",
                fields: ["id", "status", "display_name", "version", "stage"]
            })
        }
        return this.successStore
    },
    getIssueStore: function() {
        if (!this.issueStore) {
            this.issueStore = new Ext.data.JsonStore({
                id: "id",
                fields: ["id", "version", "err", "display_name", "error_code", "error_string", "stage", "status"]
            })
        }
        return this.issueStore
    },
    getProcessingView: function(b) {
        if (!this.view) {
            var a = {
                itemId: "viewWrapper",
                store: this.getProcessingStore(),
                owner: this,
                autoFlexcroll: false,
                appRestoreList: b
            };
            this.view = new SYNO.SDS.Backup.Restore.ProgressView(a)
        }
        return this.view
    },
    getSuccessView: function() {
        if (!this.successView) {
            var a = {
                itemId: "viewWrapper",
                store: this.getSuccessStore(),
                owner: this,
                autoFlexcroll: false
            };
            this.successView = new SYNO.SDS.Backup.Restore.SuccessStageView(a)
        }
        return this.successView
    },
    getIssueView: function() {
        if (!this.issueView) {
            var a = {
                itemId: "viewWrapper",
                store: this.getIssueStore(),
                owner: this,
                autoFlexcroll: false
            };
            this.issueView = new SYNO.SDS.Backup.Restore.IssueStageView(a)
        }
        return this.issueView
    }
});
Ext.define("SYNO.SDS.Backup.Restore.ProgressWindow", {
    extend: "SYNO.SDS.ModalWindow",
    dsmStyle: "v5",
    constructor: function(a) {
        Ext.copyTo(this, a, "owner");
        var b = Ext.apply({
            resizable: false,
            banner: false,
            layout: "fit",
            width: 680,
            height: 580,
            cls: "syno-backup-restore-progress-window",
            title: SYNO.SDS.Backup.String("app", "restore"),
            items: [this.wrapPanel = new SYNO.ux.Panel({
                autoFlexcroll: true,
                items: [this.progressPanel = new SYNO.SDS.Backup.Restore.ProgressPanel({
                    owner: this
                })]
            })],
            buttons: [{
                xtype: "syno_button",
                itemId: "cancel",
                disabled: true,
                text: _T("common", "cancel"),
                scope: this,
                handler: function() {
                    this.getMsgBox().confirm(_T("tree", "leaf_backup"), _T("backup", "restore_cancel_confirm"), function(c) {
                        if (c === "yes") {
                            this.onRestoreCancel()
                        }
                    }, this)
                }
            }, {
                xtype: "syno_button",
                itemId: "ok",
                btnStyle: "blue",
                disabled: true,
                text: _T("common", "ok"),
                btnStle: "blue",
                scope: this,
                handler: this.close
            }]
        }, a);
        this.callParent([b])
    },
    getButton: function(a) {
        return this.getFooterToolbar().getComponent(a)
    },
    onRestoreCancel: function() {
        this.getButton("cancel").disable();
        this.setStatusBusy();
        this.progressPanel.stopPolling();
        this.sendWebAPI({
            api: "SYNO.Backup.Restore",
            version: 1,
            method: "cancel",
            scope: this,
            callback: function(c, a, b) {
                this.clearStatusBusy();
                if (!c) {
                    this.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(a.code));
                    return
                }
                this.progressPanel.setCancelStatus(a.current_stage);
                this.progressPanel.startPolling()
            }
        })
    }
});
Ext.define("SYNO.SDS.Backup.Restore.BasicRestoreWizard", {
    extend: "SYNO.SDS.Backup.Wizard",
    deepApply: function(c, a) {
        for (var b in a) {
            if ("object" === typeof a[b] && a[b].constructor === Object && "object" === typeof c[b] && c[b].constructor === Object && c[b]) {
                Ext.apply(c[b], a[b])
            } else {
                c[b] = a[b]
            }
        }
    },
    getParams: function() {
        var a = {
            task_id: this.taskId
        };
        Ext.each(this.stepStack, function(c) {
            var b = this.getStep(c);
            if (Ext.isFunction(b.getParams)) {
                this.deepApply(a, b.getParams())
            }
        }, this);
        if (0 > this.taskId && !Ext.isEmpty(this.cache_sess_id)) {
            Ext.apply(a, {
                cache_sess_id: this.cache_sess_id
            })
        }
        return a
    },
    getBaseParams: function(b) {
        var c = {
            task_id: this.taskId
        };
        var a = this.stepStack.slice(0);
        if (b && -1 === a.indexOf(b)) {
            a.push(b)
        }
        Ext.each(a, function(e) {
            var d = this.getStep(e);
            if (Ext.isFunction(d.getBaseParams)) {
                this.deepApply(c, d.getBaseParams())
            } else {
                if (Ext.isFunction(d.getParams)) {
                    this.deepApply(c, d.getParams())
                }
            }
        }, this);
        if (0 > this.taskId && !Ext.isEmpty(this.cache_sess_id)) {
            Ext.apply(c, {
                cache_sess_id: this.cache_sess_id
            })
        }
        return c
    },
    getEncParams: function() {
        if (this.data_enc) {
            return {
                data_enc: this.data_enc,
                sess_id: this.sess_id,
                sess_key: this.sess_key,
                uni_key: this.uni_key
            }
        }
        return {
            data_enc: false
        }
    },
    onRestore: function() {
        var a = this.getParams();
        Ext.apply(a, this.getEncParams());
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Restore",
            method: "restore",
            version: 2,
            params: a,
            encryption: SYNO.SDS.Backup.Util.getEncryption(["pwd", "secret", "remote_refresh_token", "remote_access_token"], a),
            scope: this,
            callback: function(d, b, c) {
                this.clearStatusBusy();
                if (!d) {
                    this.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), SYNO.SDS.Backup.GetErrorStringEx(b), function() {
                        if (SYNO.SDS.Backup.ERR_SESSION_EXPIRED === b.code || SYNO.SDS.Backup.ERR_DATA_SESSION_EXPIRED === b.code) {
                            this.clearSession();
                            this.close()
                        }
                    }, this);
                    return
                }
                this.appWin.isRestoreWinShow = true;
                var e = new SYNO.SDS.Backup.Restore.ProgressWindow({
                    restore_id: b.restore_id,
                    owner: this.owner
                });
                e.on("close", function() {
                    this.appWin.isRestoreWinShow = false
                }, this);
                this.close();
                e.open()
            }
        })
    },
    clearSession: function() {
        delete this.sess_id;
        delete this.sess_key;
        if (this.taskId && 0 < this.taskId) {
            var a = this.owner;
            var b = a.getTaskById(this.taskId);
            delete b.sess_id;
            delete b.sess_key
        }
    }
});
Ext.define("SYNO.SDS.Backup.Restore.MainBranch", {
    extend: "SYNO.ux.Panel",
    constructor: function(b) {
        Ext.copyTo(this, b, "owner");
        var a = Ext.apply({
            autoFlexcroll: false,
            cls: "syno-backup-task-grid",
            bodyStyle: "padding-top: 0px",
            items: this.configFields(),
            bbar: [{
                xtype: "component",
                cls: "syno-backup-restore-from-other-link-wrapper",
                autoEl: {
                    html: '<a class="link-font syno-backup-restore-from-other-link">' + _TT("SYNO.SDS.Backup.Application", "app", "restore_from_link") + "</a>"
                },
                listeners: {
                    scope: this,
                    render: function(c) {
                        c.getEl().on("click", function() {
                            this.owner.taskId = -1;
                            this.owner.goNext(this.nextId.restore_from_other)
                        }, this)
                    }
                }
            }]
        }, b);
        return this.callParent([a])
    },
    activate: function() {
        var a = this.getGridStore();
        var b = this.owner.owner.getTaskList().filter(function(c) {
            return "data" === c.data_type
        });
        if (Ext.isArray(b) && 0 < b.length) {
            a.loadData(b)
        } else {
            this.getComponent("task_list").bwrap.mask(SYNO.SDS.Backup.String("error", "no_available_restore_task"), "syno-ux-mask-info")
        }
    },
    configFields: function() {
        var a = [];
        a = [{
            xtype: "syno_gridpanel",
            itemId: "task_list",
            height: 367,
            autoFlexcroll: true,
            layout: "fit",
            viewConfig: {
                hideSortIcons: true
            },
            bodyStyle: "padding: 0px",
            bwrapStyle: "padding: 0px",
            store: this.getGridStore(),
            colModel: this.getColumnModel(),
            listeners: {
                viewready: function(e) {
                    var c = this.owner.appWin.getCurrentTask();
                    var f = e.getSelectionModel();
                    var b = e.getStore();
                    if (Ext.isEmpty(c) || Ext.isEmpty(c.id)) {
                        return
                    }
                    var d = b.indexOfId(c.id);
                    if (0 <= d) {
                        f.selectRow(d)
                    } else {
                        if (0 < b.getCount()) {
                            f.selectFirstRow()
                        }
                    }
                },
                scope: this
            }
        }];
        return a
    },
    getGridStore: function() {
        if (!this.gridStore) {
            this.gridStore = new Ext.data.JsonStore({
                fields: [{
                    name: "data_type",
                    mapping: "data_type"
                }, {
                    name: "last_bkp_end_time",
                    mapping: "last_bkp_end_time"
                }, {
                    name: "last_bkp_result",
                    mapping: "last_bkp_result"
                }, {
                    name: "last_bkp_time",
                    mapping: "last_bkp_time"
                }, {
                    name: "name",
                    mapping: "name"
                }, {
                    name: "repo_id",
                    mapping: "repo_id"
                }, {
                    name: "status",
                    mapping: "status"
                }, {
                    name: "target_id",
                    mapping: "target_id"
                }, {
                    name: "target_type",
                    mapping: "target_type"
                }, {
                    name: "task_id",
                    mapping: "task_id"
                }, {
                    name: "transfer_type",
                    mapping: "transfer_type"
                }, {
                    name: "type",
                    mapping: "type"
                }]
            })
        }
        return this.gridStore
    },
    getColumnModel: function() {
        return new Ext.grid.ColumnModel([{
            header: _TT("SYNO.SDS.Backup.Application", "app", "restore_column_task_name"),
            dataIndex: "name"
        }, {
            header: _TT("SYNO.SDS.Backup.Application", "app", "last_backup_time"),
            dataIndex: "last_bkp_time",
            renderer: function(e, b, a, f, d, c) {
                return SYNO.SDS.Backup.Client.Common.Utils.getDSMStyleDateTimeString(e)
            }
        }])
    },
    getNext: function() {
        var d = this.getComponent("task_list").getSelectionModel();
        if (!d || !d.hasSelection()) {
            return false
        }
        var b = d.getSelected().data;
        this.owner.taskRecord = b;
        this.owner.targetType = b.target_type;
        this.owner.transferType = b.transfer_type;
        this.owner.repoId = b.repo_id;
        this.owner.targetId = b.target_id;
        this.owner.taskId = b.task_id;
        this.owner.blChangeRcvrSrc = true;
        this.owner.setSingle(("share" === this.owner.targetType || "cloud" === this.owner.targetType));
        var a = this.owner.owner;
        var c = a.getTaskById(this.owner.taskId);
        this.owner.data_enc = c.data_enc;
        this.owner.sess_id = null;
        this.owner.sess_key = null;
        if (this.isTaskVerified(c)) {
            this.owner.sess_id = c.sess_id;
            this.owner.sess_key = c.sess_key;
            this.owner.goNext(this.nextId.restore_from_task)
        } else {
            this.launchPasswordWindow(c, function() {
                this.owner.goNext(this.nextId.restore_from_task)
            })
        }
        return false
    },
    isTaskVerified: function(a) {
        return (!a.data_enc || !Ext.isEmpty(a.sess_id))
    },
    launchPasswordWindow: function(b, a) {
        var d = {
            task_id: b.task_id,
            repo_id: b.repo_id,
            target_id: b.target_id
        };
        var c = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.owner,
            verify_params: d,
            setter: Ext.createDelegate(this.setSession, this),
            callback: Ext.createDelegate(a, this)
        });
        c.open()
    },
    setSession: function(c) {
        var a = this.owner.owner;
        var b = a.getTaskById(this.owner.taskId);
        b.sess_id = c.sess_id;
        b.sess_key = c.sess_key;
        this.owner.sess_id = c.sess_id;
        this.owner.sess_key = c.sess_key
    }
});
Ext.define("SYNO.SDS.Backup.Restore.ConfigStep", {
    extend: "SYNO.SDS.Backup.FormPanel",
    constructor: function(a) {
        Ext.copyTo(this, a, "owner");
        this.configTreeHeight = 299;
        this.singleConfigTreeHeight = 265;
        this.configTree = new SYNO.SDS.ConfigBackup.Restore.ConfigTreePanel({
            height: this.singleConfigTreeHeight,
            loader: new SYNO.SDS.Backup.TreeLoader(),
            disabled: true,
            rootVisible: true,
            autoWidth: true,
            style: "padding-left: 30px"
        });
        var c = new Ext.tree.AsyncTreeNode({
            expanded: false,
            id: "config_root",
            allowDrop: false,
            leaf: false,
            checked: false,
            loader: this.createTreeLoader(),
            uiProvider: SYNO.SDS.ConfigBackup.TriTreeNodeUI
        });
        this.configTree.setRootNode(c);
        var d = new SYNO.ux.FieldSet({
            cls: "syno-backup-syscfg-field",
            items: [{
                xtype: "syno_radio",
                boxLabel: _T("backup", "restore_config_no"),
                name: "config_selected",
                itemId: "config_selected_no",
                groupFields: [],
                inputValue: "no",
                indent: 0,
                hideLabel: true,
                scope: this,
                checked: true
            }, {
                xtype: "syno_radio",
                boxLabel: _T("backup", "restore_config_yes") + ":",
                name: "config_selected",
                itemId: "config_selected_yes",
                groupFields: ["version_selector"],
                inputValue: "yes",
                indent: 0,
                hideLabel: true,
                scope: this,
                listeners: {
                    scope: this,
                    check: this.onConfigYesChecked
                },
                checked: false
            }, {
                width: 240,
                xtype: "syno_combobox",
                hideLabel: true,
                itemId: "version_selector",
                name: "version_selector",
                forceSelection: true,
                allowBlank: false,
                autoSelect: true,
                displayField: "text",
                valueField: "version_id",
                indent: 1,
                store: new Ext.data.SimpleStore({
                    id: "version_id",
                    fields: ["version_id", "text"]
                }),
                listeners: {
                    scope: this,
                    select: function(f, g, e) {
                        this.reloadTree(g.get("version_id"))
                    }
                }
            }, {
                xtype: "syno_checkbox",
                indent: 1,
                boxLabel: _T("confbackup", "bkp_overwrite"),
                disabled: true,
                hiddenName: "overwrite",
                name: "overwrite"
            }, this.configTree]
        });
        var b = {
            items: d,
            cls: "syno-backup-config-step-panel"
        };
        Ext.apply(b, a);
        this.callParent([b])
    },
    onConfigYesChecked: function(a, b) {
        if ((b && !this.isConfigInvalid) || !b && this.newestDssId) {
            this.owner.getButton("next").enable()
        } else {
            this.owner.getButton("next").disable()
        }
        if (this.isConfigInvalid) {
            return
        }
        this.configTree.setDisabled(!b);
        this.configTree.getRootNode().getUI().setCheckValue(b);
        this.getForm().findField("overwrite").setValue(b);
        this.getForm().findField("overwrite").setDisabled(!b)
    },
    setConfigInvalid: function(b, a) {
        this.isConfigInvalid = b;
        if (!b && (this.getForm().findField("config_selected_no").getValue())) {
            this.owner.getButton("next").setDisabled(b);
            return
        }
        if (b) {
            this.configTree.getEl().mask(a)
        } else {
            this.configTree.getEl().unmask()
        }
        this.configTree.getRootNode().getUI().setCheckValue(!b);
        this.getForm().findField("overwrite").setDisabled(b);
        this.getForm().findField("overwrite").setValue(!b);
        this.owner.getButton("next").setDisabled(b)
    },
    createTreeLoader: function() {
        var a = new SYNO.SDS.Backup.TreeLoader({
            sendWebAPI: this.configTree.sendWebAPI.createDelegate(this.configTree),
            webapi: {
                api: "SYNO.Backup.Target.Config",
                method: "list",
                version: 1,
                encryption: ["pwd", "secret"],
                timeout: 360000
            },
            baseParams: {
                is_show_shared_folder: false
            },
            parseWebApiResponse: this.parseWebApiResponse.createDelegate(this),
            createNodeFn: function(b) {
                this.configTree.createConfigNodeFn(b);
                if (!this.owner.isSingle) {
                    delete b.checked
                }
            },
            createNodeScope: this
        });
        a.on("beforeload", function(e, c, b) {
            var d;
            if (!this.owner.el.isMasked()) {
                this.owner.setStatusBusy()
            }
            this.owner.getButton("next").disable();
            d = this.getLoadVersionListParams();
            d.version_id = this.configTree.version_id;
            if (this.owner.data_enc) {
                d.sess_id = this.owner.sess_id;
                d.sess_key = this.owner.sess_key;
                d.data_enc = this.owner.data_enc;
                d.uni_key = this.owner.uni_key
            }
            d.dss_id = this.owner.dssCache[d.version_id];
            d.is_show_shared_folder = false;
            e.baseParams = d
        }, this);
        a.on("loadexception", function(e, c, b) {
            var d = SYNO.SDS.Backup.GetErrorString(b);
            if (b.code == SYNO.SDS.ConfigBackup.ERR_CONFIG_VERSION_WRONG || b.code == SYNO.SDS.ConfigBackup.ERR_CONFIG_VERSION_OTHER_OS || b.code == SYNO.SDS.ConfigBackup.ERR_CONFIG_VERSION_FUTURE) {
                this.setConfigInvalid(true, d)
            } else {
                this.setConfigInvalid(true);
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), d, function() {
                    if (SYNO.SDS.Backup.ERR_SESSION_EXPIRED === b.code) {
                        this.owner.clearSession()
                    }
                    this.owner.close()
                }, this)
            }
            this.owner.clearStatusBusy()
        }, this);
        a.on("load", function(d, c, b) {
            this.setConfigInvalid(false);
            this.owner.clearStatusBusy()
        }, this);
        return a
    },
    parseWebApiResponse: function(b, a) {
        if (!this.newestDssId) {
            this.newestDssId = a.dss_id
        }
        this.owner.dssCache[this.configTree.version_id] = a.dss_id;
        this.configTree.dss_id = a.dss_id;
        return a.config_info_list
    },
    getLoadVersionListParams: function() {
        return Ext.apply({
            offset: 0,
            limit: -1
        }, this.owner.getBaseParams())
    },
    checkState: function() {
        SYNO.SDS.Wizard.Step.prototype.checkState.apply(this, arguments);
        if (this.isConfigInvalid) {
            this.owner.getButton("next").disable()
        }
    },
    activate: function() {
        var a = this.owner.getBaseParams();
        if (0 < a.task_id || "cloud_image" !== a.target_type) {
            this.loadVersion();
            return
        }
        if (this.lastQueryCloudCache !== Ext.encode(a)) {
            this.owner.setStatusBusy({
                text: _T("backup", "search_restore_config")
            });
            this.sendWebAPI({
                api: "SYNO.Backup.Target",
                version: 1,
                method: "create_cache",
                params: a,
                encryption: SYNO.SDS.Backup.Util.getEncryption(["pwd", "secret", "remote_refresh_token", "remote_access_token"], a),
                scope: this,
                callback: function(d, b, c) {
                    if (!d) {
                        this.owner.clearStatusBusy();
                        this.reportFatalError(SYNO.SDS.Backup.GetErrorString(b.code));
                        return
                    }
                    this.owner.cache_sess_id = b.cache_sess_id;
                    this.lastQueryCloudCache = Ext.encode(this.owner.getBaseParams());
                    this.loadVersion()
                }
            })
        }
    },
    loadVersion: function() {
        var e = this.getLoadVersionListParams();
        var b;
        var a;
        var d;
        if (this.lastQueryVersionList !== Ext.encode(e)) {
            this.owner.dssCache = {};
            this.newestDssId = "";
            this.getForm().findField("config_selected_no").setValue(true);
            a = this.getForm().findField("version_selector");
            a.getStore().loadData([], false);
            a.clearValue();
            b = this.configTree.getRootNode();
            if (!this.owner.el.isMasked()) {
                this.owner.setStatusBusy({
                    text: _T("backup", "search_restore_config")
                })
            }
            if (!this.owner.isSingle) {
                d = _T("confbackup", "confbkp_all") + ' <element class="red-status">(' + _T("confbackup", "bkp_overwrite") + ")</element>";
                var c = _T("confbackup", "confbkp_all") + " (" + _T("confbackup", "bkp_overwrite") + ")";
                b.setText(d);
                b.setTooltip(c);
                this.getForm().findField("overwrite").setVisible(false);
                this.configTree.setHeight(this.configTreeHeight)
            } else {
                d = _T("confbackup", "confbkp_all");
                b.setText(d);
                b.setTooltip(d);
                this.getForm().findField("overwrite").setVisible(true);
                this.configTree.setHeight(this.singleConfigTreeHeight)
            }
            e.sort_direction = "desc";
            e.filter_name = "success";
            this.sendWebAPI({
                api: "SYNO.Backup.Version",
                version: 2,
                method: "list",
                params: e,
                encryption: SYNO.SDS.Backup.Util.getEncryption(["pwd", "secret", "remote_refresh_token", "remote_access_token"], e),
                scope: this,
                callback: this.loadVersionDone,
                timeout: 240000
            })
        }
    },
    loadVersionDone: function(e, b, c) {
        if (!e) {
            this.owner.clearStatusBusy();
            this.reportFatalError(SYNO.SDS.Backup.GetErrorString(b.code));
            return
        }
        var a = this.getForm().findField("version_selector");
        var d = [];
        if (!b || !(b.version_info_list) || 0 === b.version_info_list.length) {
            this.setConfigInvalid(true);
            this.owner.clearStatusBusy();
            if (!this.owner.isSingle) {
                this.reportFatalError(SYNO.SDS.Backup.String("error", "no_available_restore_version"))
            } else {
                this.reportFatalError(_T("confbackup", "confbkp_file_not_found"))
            }
            return
        }
        Ext.each(b.version_info_list, function(f) {
            var g;
            if (0 === f.timestamp) {
                d.push([f.version_id, _T("confbackup", "confbkp_old_config_format")])
            } else {
                g = new Date(f.timestamp * 1000);
                d.push([f.version_id, SYNO.SDS.Backup.Client.Common.Utils.DateTimeFormatter(g, {
                    type: "datetimesec"
                })])
            }
        }, this);
        this.newestVersionId = d[0][0];
        a.getStore().loadData(d, false);
        a.setValue(d[0][0]);
        a.setRawValue(d[0][1]);
        this.lastQueryVersionList = Ext.encode(this.getLoadVersionListParams());
        this.reloadTree(d[0][0])
    },
    reportFatalError: function(a) {
        this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), a || SYNO.SDS.Backup.String("error", "app_network_disconnected"), function(b) {
            this.owner.close()
        }, this)
    },
    getNext: function() {
        var a = this.nextId;
        var b = this.isOverwrite();
        if (this.isRestoreConfig()) {
            this.configTree.checkUGConflict(b, function() {
                this.goNext(a)
            }, this.owner)
        } else {
            return a
        }
        return false
    },
    summary: function(a) {
        var b;
        if (this.isRestoreConfig()) {
            a.append(SYNO.SDS.Backup.String("app", "select_version"), this.getForm().findField("version_selector").getRawValue());
            b = _T("common", "yes") + ", ";
            b += _T("netbackup", "netbkp_restore_enhance")
        } else {
            b = _T("common", "no")
        }
        a.append(SYNO.SDS.Backup.String("app", "bkp_import"), b)
    },
    reloadTree: function(b) {
        var a;
        this.configTree.dss_id = "";
        this.configTree.version_id = b;
        a = this.configTree.getRootNode();
        a.reload();
        a.expand()
    },
    getVersionId: function() {
        if (this.isRestoreConfig()) {
            return this.getForm().findField("version_selector").getValue()
        } else {
            if (this.owner.isSingle) {
                return this.newestVersionId
            } else {
                return -1
            }
        }
    },
    isOverwrite: function() {
        if (!this.owner.isSingle) {
            return this.configTree.isRestoreConfig()
        }
        return this.getForm().findField("overwrite").getValue()
    },
    isRestoreConfig: function() {
        return this.getForm().findField("config_selected_yes").getValue() && this.configTree.isRestoreConfig()
    },
    getBaseParams: function() {
        var a = this.getVersionId();
        if (-1 === a) {
            return {}
        }
        return {
            dss_id: this.owner.dssCache[a],
            version_id: a
        }
    },
    getParams: function() {
        var a = this.getBaseParams();
        if (!this.isRestoreConfig()) {
            return a
        }
        return Ext.apply(a, {
            config_list: this.configTree.getRestoreServiceList(),
            option: {
                overwrite: this.isOverwrite()
            }
        })
    }
});
Ext.define("SYNO.SDS.Backup.VersionFileTree", {
    extend: "SYNO.SDS.Backup.BasicTreePanel",
    shareWarnStatus: {},
    folderDisplayLimit: 10000,
    constructor: function(a) {
        this.dss_id = null;
        Ext.copyTo(this, a, "owner");
        var b = Ext.apply({
            border: false,
            loader: this.createTreeLoader(),
            root: this.createTreeRoot(),
            bodyStyle: "padding: 0px"
        }, a);
        return this.callParent([b])
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this, "beforeexpandnode", this.onBeforeExpandNode)
    },
    createTreeRoot: function() {
        var a = new Ext.tree.AsyncTreeNode({
            draggable: false,
            expanded: false,
            id: "fm_root",
            allowDrop: false,
            text: _T("tree", "leaf_sharefolder"),
            checked: false,
            uiProvider: SYNO.SDS.Backup.TriTreeNodeUI
        });
        return a
    },
    createTreeLoader: function() {
        return new SYNO.SDS.Backup.TreeLoader({
            sendWebAPI: this.sendWebAPI.createDelegate(this),
            scope: this,
            webapi: {},
            baseParams: {
                offset: 0,
                limit: -1
            },
            listeners: {
                beforeload: this.onBeforeLoad,
                load: this.onLoad,
                loadexception: this.onLoadException,
                scope: this
            },
            createNodeFn: this.createNodeFn,
            createNodeScope: this,
            parseWebApiResponse: this.parseWebApiResponse.createDelegate(this)
        })
    },
    onBeforeLoad: function(d, a, c) {
        d.baseParams = {
            offset: 0,
            limit: -1
        };
        this.owner.setStatusBusy();
        var b = this.getBaseParams();
        Ext.apply(b, this.owner.getEncParams());
        if (a.id === "fm_root") {
            d.webapi.api = "SYNO.Backup.Share.Restore";
            d.webapi.method = "list";
            d.webapi.version = 1;
            d.webapi.encryption = ["pwd", "secret"]
        } else {
            b.path = SYNO.SDS.Backup.ConvertUniqueIdToConflictId(a.id);
            d.webapi.api = "SYNO.Backup.Version";
            d.webapi.method = "list_folder";
            d.webapi.version = 1;
            d.webapi.encryption = ["pwd", "secret"];
            d.baseParams.limit = this.folderDisplayLimit;
            d.baseParams.type = "dir"
        }
        Ext.apply(d.baseParams, b)
    },
    onLoad: function(d, c, b) {
        var a = 0;
        if ("fm_root" === c.id) {
            c.eachChild(function(e) {
                if (!(e.disabled)) {
                    a++
                }
            });
            if (0 === c.childNodes.length) {
                c.disable();
                c.appendChild(new Ext.tree.AsyncTreeNode({
                    checked: false,
                    leaf: true,
                    uiProvider: SYNO.SDS.Backup.TriTreeNodeUI,
                    text: '<element class="red-status">' + _T("download", "download_task_dest_not_exist") + "</element>",
                    disabled: true
                }))
            } else {
                if (0 === a) {
                    c.disable()
                } else {
                    c.enable()
                }
            }
        }
        this.owner.clearStatusBusy()
    },
    onLoadException: function(c, b, a) {
        this.owner.clearStatusBusy();
        this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), SYNO.SDS.Backup.GetErrorString(a.code), function() {
            if (SYNO.SDS.Backup.ERR_SESSION_EXPIRED === a.code) {
                this.owner.clearSession()
            }
            this.owner.close()
        }, this);
        return
    },
    onBeforeExpandNode: function(a) {
        if (a.attributes.exceedLimit) {
            this.owner.getMsgBox().alert(_T("netbackup", '"netbkp_recovery"'), String.format(SYNO.SDS.Backup.String("app", "node_exceed_display_limit"), a.text, this.folderDisplayLimit));
            return false
        }
    },
    createNodeFn: function(a) {
        a.uiProvider = "SYNO.SDS.Backup.TriTreeNodeUI";
        a.checked = false;
        a.text = a.qtip = a.name;
        a.htmlEncode = false;
        a.is_user_modify = false;
        a.is_restore = true;
        if (a.file_path) {
            a.id = a.file_path
        } else {
            a.id = "/" + a.text;
            if (a.is_bad) {
                a.disabled = true;
                a.qtip = SYNO.SDS.Backup.String("app", "broken_share")
            } else {
                if (a.conflict) {
                    if (!a.is_valid) {
                        a.disabled = true;
                        a.qtip = SYNO.SDS.ConfigBackup.getShareErrorString(a.conflict, a.name);
                        if ("err_share_not_writable" === a.conflict && undefined !== a.read_only_owner) {
                            a.qtip += " ";
                            a.qtip += String.format(SYNO.SDS.Backup.String("app", "share_used_by_running_application"), SYNO.SDS.Backup.getReadOnlyOwnerString(a.read_only_owner))
                        }
                    } else {
                        a.shareConflict = a.conflict
                    }
                    delete a.conflict
                }
            }
        }
        if (a.is_enc) {
            a.id = SYNO.SDS.Backup.ConvertConflictIdToUniqueId(a.id)
        }
        delete a.name;
        a.leaf = SYNO.SDS.Backup.Client.Common.Utils.isABBDataFolder(a.file_path) || !this.isShareExpandable || a.disabled
    },
    parseWebApiResponse: function(b, a) {
        var c = [];
        if (b.id === "fm_root") {
            if (undefined !== a.dss_id) {
                this.owner.dssCache[b.getLoader().baseParams.version_id] = a.dss_id
            }
            this.dss_id = a.dss_id;
            return a.share_info_list
        } else {
            if (this.folderDisplayLimit < a.total) {
                b.attributes.expandable = true;
                b.attributes.exceedLimit = true;
                return c
            }
            Ext.each(a.file_list, function(d) {
                if (d.is_dir === false) {
                    return
                }
                d.is_enc = b.attributes.is_enc;
                d.warning = b.attributes.warning;
                c.push(d)
            });
            return c
        }
    },
    getVersionPanel: function() {
        return this.versionPanel
    },
    checkShare: function() {
        var e = "";
        if (this.isSingle) {
            this.owner.setStatusBusy();
            var c = false;
            var d = false;
            var a = this.getFolderList();
            var b = {};
            Ext.each(a, function(h) {
                var f = h.path;
                var i = h.is_enc;
                var g = false;
                f = f.substr(1);
                f = f.toLowerCase();
                if (b[f]) {
                    g = (b[f] === "enc_share");
                    if (g === i) {
                        c = true
                    } else {
                        d = true
                    }
                    return false
                } else {
                    b[f] = i ? "enc_share" : "share"
                }
            });
            this.owner.clearStatusBusy();
            if (c) {
                e = _T("netbackup", "netbkp_restore_conflict_share")
            } else {
                if (d) {
                    e = _T("backup", "restore_the_same_share_err")
                }
            }
        }
        return e
    },
    getWarning: function(b) {
        var a = [];
        if (b && Ext.isArray(b)) {
            a = this.getRootNode().childNodes.filter(function(d) {
                return b.some(function(e) {
                    return !this.shareWarnStatus[e] && e === SYNO.SDS.Backup.ConvertUniqueIdToConflictId(d.id).substr(1)
                }, this)
            }, this)
        } else {
            this.shareWarnStatus = {};
            a = this.getCheckedSubTreeRoot(this.getRootNode())
        }
        var c = {};
        Ext.each(a, function(e) {
            if (Ext.isEmpty(e.attributes.warning)) {
                return true
            }
            var d = SYNO.SDS.Backup.ConvertUniqueIdToConflictId(e.id).split("/")[1];
            if (!b) {
                this.shareWarnStatus[d] = true
            }
            Ext.each(e.attributes.warning.split(","), function(f) {
                if (undefined === c[f]) {
                    c[f] = []
                }
                if (-1 === c[f].indexOf(d)) {
                    c[f].push(d)
                }
            })
        }, this);
        return SYNO.SDS.ConfigBackup.getShareWarningString(c)
    },
    getFolderList: function(c) {
        var b = [];
        var a = [];
        if (!c) {
            a = this.getCheckedSubTreeRoot(this.getRootNode())
        } else {
            this.getRootNode().eachChild(function(d) {
                a.push(d)
            })
        }
        Ext.each(a, function(f) {
            var e = f.id;
            var d = f.attributes.is_enc;
            if (d) {
                e = SYNO.SDS.Backup.ConvertUniqueIdToConflictId(e)
            }
            b.push({
                path: e,
                is_enc: d
            })
        });
        return b
    }
});
Ext.define("SYNO.SDS.Backup.VersionSelector", {
    extend: "SYNO.SDS.Backup.FormPanel",
    constructor: function(a) {
        Ext.copyTo(this, a, "owner");
        var b = Ext.apply({
            style: "border-top: 1px solid #D7E1EB; padding: 12px 20px 0px 20px;",
            items: [{
                labelWidth: 260,
                width: 240,
                fieldLabel: _T("backup", "select_version"),
                xtype: "syno_combobox",
                itemId: "version_selector",
                name: "version_selector",
                forceSelection: true,
                allowBlank: false,
                autoSelect: true,
                displayField: "name",
                valueField: "version_id",
                store: this.createStore(a),
                listeners: {
                    scope: this,
                    select: function(d, e, c) {
                        this.getVersionPanel().reloadTree(e.get("version_id"))
                    }
                }
            }]
        }, a);
        return this.callParent([b])
    },
    createStore: function(a) {
        return new SYNO.API.Store({
            api: "SYNO.Backup.Version",
            version: 2,
            method: "list",
            baseParams: Ext.apply({}, this.params),
            encryption: SYNO.SDS.Backup.Util.getEncryption(["pwd", "secret", "remote_refresh_token", "remote_access_token"], this.params),
            appWindow: this.owner.findAppWindow(),
            reader: new Ext.data.JsonReader({
                idProperty: "version_id",
                root: "version_info_list",
                totalProperty: "total",
                fields: [{
                    name: "version_id",
                    mapping: "version_id"
                }, {
                    name: "name",
                    mapping: "name"
                }, {
                    name: "modify",
                    mapping: "modify"
                }, {
                    name: "status",
                    mapping: "status"
                }, {
                    name: "timestamp",
                    mapping: "timestamp"
                }]
            })
        })
    },
    getVersionId: function() {
        return this.getComponent("version_selector").getValue()
    },
    getVersionDate: function() {
        var a = this.getVersionId();
        return this.getComponent("version_selector").getStore().getById(a).get("name")
    },
    getVersionPanel: function() {
        return this.versionPanel
    }
});
Ext.define("SYNO.SDS.Backup.Restore.ShareStep", {
    extend: "SYNO.ux.Panel",
    loaded: false,
    version_selector: (Ext.isIE6 || Ext.isIE7) ? "combobox" : "timeline",
    constructor: function(a) {
        Ext.copyTo(this, a, "owner,repoId,targetId,taskId");
        this.timelineHeight = 112;
        this.wizardStepHeight = 425;
        this.versionFileTreeHeight = this.wizardStepHeight - this.timelineHeight - 6 - 24;
        this.versionFileTree = new SYNO.SDS.Backup.VersionFileTree({
            itemId: "version_file_tree",
            owner: this.owner,
            versionPanel: this,
            getBaseParams: function() {
                var c = this.owner.getBaseParams();
                if (this.getVersionSelectPanel() && this.getVersionSelectPanel().isVisible()) {
                    c.version_id = this.getVersionSelectPanel().getVersionId();
                    c.dss_id = this.owner.dssCache[c.version_id]
                }
                return c
            }.createDelegate(this),
            height: this.versionFileTreeHeight,
            bwrapStyle: "padding-top: 0px",
            bodyStyle: "padding: 8px 8px 0px 8px"
        });
        var b = Ext.apply({
            itemId: "version_panel",
            layout: "vbox",
            layoutConfig: {
                align: "stretch",
                pack: "start"
            },
            items: [new SYNO.ux.FieldSet({
                itemId: "tree_field",
                layout: "fit",
                cls: "syno-backup-sharestep-treefield",
                items: [this.versionFileTree]
            }), {
                xtype: "spacer",
                flex: 1
            }]
        }, a);
        return this.callParent([b])
    },
    getFileSourcePanel: function() {
        return this.versionFileTree
    },
    getVersionSelectPanel: function() {
        return this.versionSelector
    },
    showVersionSelector: function(a) {
        if (this.versionSelector) {
            this.versionSelector.setVisible(a)
        } else {
            if (a) {
                if (this.version_selector === "timeline") {
                    this.versionSelector = new SYNO.SDS.Backup.Client.Explore.TimeLine({
                        loadAfterRender: true,
                        cls: "syno-backup-client-explore",
                        owner: this.owner,
                        getBaseParams: this.getLoadVersionListParams.createDelegate(this),
                        height: this.timelineHeight,
                        apiClass: "SYNO.Backup.Version",
                        methodVersionMap: {
                            list: 2,
                            summary: 1
                        },
                        listeners: {
                            select: this.reloadTree,
                            scope: this
                        }
                    })
                } else {
                    this.versionSelector = new SYNO.SDS.Backup.VersionSelector({
                        owner: this.owner,
                        height: 60,
                        versionPanel: this
                    })
                }
                this.add(this.versionSelector)
            }
        }
        if (a && this.version_selector === "timeline") {
            this.owner.getFooterToolbar().getEl().addClass("syno-backup-timeline-fbar")
        } else {
            this.owner.getFooterToolbar().getEl().removeClass("syno-backup-timeline-fbar")
        }
    },
    isReloadNeeded: function() {
        var a = this.getLoadVersionListParams();
        a = Ext.encode(a);
        if (this.lastQuery === a) {
            return false
        }
        this.lastQuery = a;
        return true
    },
    isShareExpandable: function() {
        if (this.owner.isSingle) {
            return false
        }
        var a = this.owner.getBaseParams();
        if (-1 === a.task_id && "cloud_image" === a.target_type) {
            return false
        }
        return true
    },
    activate: function() {
        if (this.owner.isSingle !== this.getFileSourcePanel().isSingle) {
            this.getFileSourcePanel().isSingle = this.owner.isSingle;
            this.getFileSourcePanel().loader = this.getFileSourcePanel().createTreeLoader()
        }
        this.getFileSourcePanel().isShareExpandable = this.isShareExpandable();
        if (-1 !== this.owner.getStep("config").getVersionId()) {
            this.showVersionSelector(false);
            if (this.isReloadNeeded()) {
                this.reloadTree()
            }
            this.getComponent("tree_field").setHeight(this.wizardStepHeight - 24);
            this.doLayout()
        } else {
            this.showVersionSelector(true);
            if (this.isReloadNeeded()) {
                this.reloadVersionList()
            }
            this.getComponent("tree_field").setHeight(this.versionFileTreeHeight);
            this.setHeight(this.wizardStepHeight);
            this.doLayout()
        }
    },
    getNext: function() {
        var b = this.getFileSourcePanel().checkShare();
        if ("" !== b) {
            this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), b);
            return false
        }
        var a = this.getFileSourcePanel().getWarning();
        if ("" !== a) {
            this.owner.getMsgBox().confirm(_T("netbackup", "netbkp_recovery"), a, function(c) {
                if ("yes" === c) {
                    this.loadNextStep()
                }
            }, this)
        } else {
            this.loadNextStep()
        }
        return false
    },
    loadNextStep: function() {
        this.owner.getFooterToolbar().getEl().removeClass("syno-backup-timeline-fbar");
        if (this.owner.getStep("app").isReloadNeeded()) {
            this.isAppSkip = false;
            this.owner.setStatusBusy();
            var a = this.owner.getStep("app").getStore();
            var b = this.owner.getStep("app").getVersionAppParams();
            a.proxy.encryption = SYNO.SDS.Backup.Util.getEncryption(["pwd", "secret", "remote_refresh_token", "remote_access_token"], b);
            this.owner.getStep("app").getStore().load({
                params: b,
                scope: this,
                callback: function(c, d, e) {
                    this.owner.clearStatusBusy();
                    if (e && 0 === c.length) {
                        this.isAppSkip = true;
                        this.owner.goNext(this.owner.getStep("app").getNext())
                    } else {
                        this.owner.goNext(this.nextId)
                    }
                }
            })
        } else {
            if (this.isAppSkip) {
                this.owner.goNext(this.owner.getStep("app").getNext())
            } else {
                this.owner.goNext(this.nextId)
            }
        }
        return false
    },
    getBack: function() {
        this.owner.getFooterToolbar().getEl().removeClass("syno-backup-timeline-fbar")
    },
    summary: function(d) {
        var c = [];
        var b = [];
        var e = [];
        var a = [];
        Ext.each(this.getFileSourcePanel().getFolderList(), function(h) {
            c.push({
                path: h.path.substring(1),
                whitelist: ["*"]
            })
        });
        b = b.concat(c);
        this.owner.getStep("app").getStore().each(function(h) {
            if (true !== h.get("checked")) {
                return true
            }
            var i = SYNO.SDS.Backup.parseAppDependFolderInfo(h.get("depend"));
            e = e.concat(i.detail)
        });
        Ext.each(e, function(h) {
            if (-1 !== h.whitelist.indexOf("*")) {
                b.push(h)
            }
        });
        b.sort(function(h, i) {
            if (h.path < i.path) {
                return -1
            } else {
                if (h.path === i.path) {
                    return 0
                } else {
                    return 1
                }
            }
        });
        var g = 0;
        b = b.filter(function(i, h, j) {
            if (0 === h) {
                return true
            }
            if (i.path === j[g].path) {
                return false
            }
            if (0 === i.path.indexOf(j[g].path + "/")) {
                return false
            }
            g = h;
            return true
        });
        a = SYNO.Backup.Util.deepCopyObject(b);
        var f = function(h) {
            Ext.each(h, function(j) {
                var i = b.some(function(k) {
                    return (j.path === k.path || 0 === j.path.indexOf(k.path + "/"))
                });
                if (!i) {
                    a.push(j)
                }
            })
        };
        f(c);
        f(e);
        a = a.map(function(h) {
            if (-1 !== h.whitelist.indexOf("*")) {
                return h.path
            }
            return h.path + "(" + h.whitelist.join(", ") + ")"
        });
        if (this.getVersionSelectPanel() && this.getVersionSelectPanel().isVisible()) {
            d.append(SYNO.SDS.Backup.String("app", "select_version"), SYNO.SDS.Backup.Client.Common.Utils.getDSMStyleDateTimeString(this.getVersionSelectPanel().getVersionDate(), {
                type: "datetimesec"
            }))
        }
        if (0 === a.length) {
            d.append(SYNO.SDS.Backup.String("app", "restore_share"), _T("system", "none_opt"))
        } else {
            d.append(SYNO.SDS.Backup.String("app", "restore_share"), a.sort().join(", "))
        }
    },
    getLoadVersionListParams: function() {
        return Ext.apply({
            offset: 0,
            limit: -1
        }, this.owner.getBaseParams())
    },
    reloadVersionList: function() {
        if (this.version_selector === "combobox") {
            var a = this.getLoadVersionListParams();
            this.owner.setStatusBusy();
            this.sendWebAPI({
                api: "SYNO.Backup.Version",
                version: 2,
                method: "list",
                encryption: SYNO.SDS.Backup.Util.getEncryption(["pwd", "secret", "remote_refresh_token", "remote_access_token"], a),
                params: a,
                scope: this,
                callback: function(f, c, d) {
                    this.owner.clearStatusBusy();
                    if (!f) {
                        this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), SYNO.SDS.Backup.GetErrorString(c.code), function() {
                            this.owner.close()
                        }, this);
                        return
                    }
                    var b = this.getVersionSelectPanel();
                    var e = [];
                    Ext.each(c.version_info_list, function(i, g, h) {
                        if ("success" !== i.status && "partial" !== i.status) {
                            return
                        }
                        e.push(i)
                    }, this);
                    if (0 === e.length) {
                        this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), SYNO.SDS.Backup.String("error", "no_available_restore_version"), function() {
                            this.owner.close()
                        }, this);
                        return
                    }
                    b = b.getComponent("version_selector");
                    b.getStore().loadData({
                        version_info_list: e
                    });
                    b.setValue(e[0].version_id);
                    b.setRawValue(e[0].name);
                    if (this.lastQueryVersionList) {
                        this.getFileSourcePanel().getRootNode().reload()
                    }
                    this.getFileSourcePanel().getRootNode().expand()
                }
            })
        } else {
            if (this.version_selector === "timeline") {
                this.remove(this.versionSelector);
                this.versionSelector = null;
                this.showVersionSelector(true);
                this.doLayout()
            }
        }
    },
    reloadTree: function() {
        this.getFileSourcePanel().getRootNode().removeAll();
        this.getFileSourcePanel().getRootNode().getUI().setCheckValue(false);
        this.getFileSourcePanel().getRootNode().reload()
    },
    getFolderList: function(a) {
        return this.getFileSourcePanel().getFolderList(a)
    },
    getBaseParams: function() {
        var a = {};
        if (this.getVersionSelectPanel() && this.getVersionSelectPanel().isVisible()) {
            a.version_id = this.getVersionSelectPanel().getVersionId()
        }
        return a
    },
    getParams: function() {
        var a = this.getBaseParams();
        if (null !== this.getFileSourcePanel().dss_id) {
            a.dss_id = this.getFileSourcePanel().dss_id
        }
        return Ext.apply(a, {
            share_list: this.getFolderList(),
            option: {
                conflict: "overwrite"
            }
        })
    }
});
Ext.define("SYNO.SDS.Backup.Restore.RestoreWizard", {
    extend: "SYNO.SDS.Backup.Restore.BasicRestoreWizard",
    constructor: function(c) {
        this.dssCache = {};
        Ext.copyTo(this, c, "owner");
        this.api = new SYNO.SDS.Backup.ApiHelper({
            owner: this
        });
        this.taskId = -1;
        var d = SYNO.Backup.Addon.Config.addon_list;
        var b = function() {
            var e = {};
            Ext.each(d, function(g, f, h) {
                e[g.id] = g.id + "::restore_setting"
            });
            return e
        };
        var a = [new SYNO.SDS.Backup.Restore.MainBranch({
            owner: this,
            headline: SYNO.SDS.Backup.String("app", "task_restore_wizard_title"),
            bodyStyle: "max-height: 367px; min-height: 367px",
            itemId: "main_branch",
            nextId: {
                restore_from_task: "config",
                restore_from_other: "dest_type"
            }
        }), new SYNO.SDS.Backup.Restore.RepoTypePanel({
            owner: this,
            headline: SYNO.SDS.Backup.String("app", "repo_type_restore_wizard_title"),
            itemId: "dest_type",
            nextId: b()
        }), new SYNO.SDS.Backup.Restore.ConfigStep({
            headline: SYNO.SDS.Backup.String("app", "source_config_restore_wizard_title"),
            itemId: "config",
            nextId: "share",
            owner: this
        }), new SYNO.SDS.Backup.Restore.ShareStep({
            headline: SYNO.SDS.Backup.String("app", "source_share_restore_wizard_title"),
            itemId: "share",
            nextId: "app",
            owner: this
        }), new SYNO.SDS.Backup.Restore.AppStep({
            headline: SYNO.SDS.Backup.String("app", "source_pkg_restore_wizard_title"),
            itemId: "app",
            nextId: "summary",
            bodyStyle: "max-height: 380px; min-height: 380px",
            owner: this
        }), new SYNO.SDS.Backup.SummaryStep({
            headline: SYNO.SDS.Backup.String("app", "restore_summary"),
            itemId: "summary",
            nextId: null,
            getNext: function() {
                this.owner.onRestore();
                return false
            },
            owner: this,
            columns: [{
                width: 200,
                header: _T("status", "header_item"),
                dataIndex: "key",
                renderer: this.fieldRenderer
            }, {
                id: "value",
                autoExpand: true,
                header: _T("status", "header_value"),
                dataIndex: "value",
                renderer: this.descRenderer,
                scope: this
            }]
        })];
        return this.callParent([Ext.apply({
            title: SYNO.SDS.Backup.String("app", "main_branch_restore_wizard_title"),
            cls: "syno-backup-restore-wizard",
            width: 680,
            height: 580,
            banner: true,
            steps: a
        }, c)])
    },
    setSingle: function(a) {
        this.isSingle = a
    },
    targetGetErrorHandle: function(a) {
        if (SYNO.SDS.Backup.ERR_TARGET_BROKEN === a.code) {
            this.getMsgBox().alert(_T("tree", "leaf_backup"), SYNO.SDS.Backup.String("error", "target_not_support"))
        } else {
            if (SYNO.SDS.Backup.ERR_SERVER_NOT_DOWNLOADABLE === a.code) {
                this.getMsgBox().alert(_T("tree", "leaf_backup"), SYNO.SDS.Backup.GetErrorStringArg(a.code, a.errors.error_msg))
            } else {
                this.api.alert(a)
            }
        }
    },
    createStep: function(f) {
        var c = f.split(":")[0];
        var b = f.split(":")[2];
        var d = null;
        var e = SYNO.Backup.Addon.Util.getInfo(c);
        if ("restore_setting" === b) {
            var a = SYNO.Backup.Addon.Util.getClass(c, "Restore.DestStep");
            if (a) {
                d = new a({
                    owner: this,
                    itemId: f,
                    target_type: e.target_type,
                    transfer_type: e.transfer_type,
                    nextId: "config",
                    headline: SYNO.SDS.Backup.String("app", "dest_info_restore_wizard_title"),
                    description: SYNO.SDS.Backup.String("app", "dest_info_restore_wizard_desc")
                })
            }
        }
        return d
    },
    getDestType: function() {
        return this.getStep("dest_type").getOption()
    },
    reportError: function(a, b) {
        b = b || {};
        if (!this.reporter) {
            this.reporter = new SYNO.SDS.Backup.ApiHelper({
                owner: this
            })
        }
        this.reporter.alert(a, b.callback, b.scope)
    }
});
Ext.define("SYNO.SDS.Backup.Restore.RepoTypePanel", {
    extend: "SYNO.SDS.Backup.RepoTypePanel",
    constructor: function(a) {
        Ext.copyTo(this, a, "owner");
        this.callParent([a])
    },
    isRepoDisplay: function(a) {
        if (false !== a.options.supportRestore) {
            return !a.hidden
        } else {
            return false
        }
    },
    loadLocalDestData: function() {
        var a = [{
            api: "SYNO.Backup.Repository",
            method: "find",
            params: {
                connect_list: [{
                    target_type: "share",
                    transfer_type: "local"
                }]
            },
            version: 1
        }];
        this.owner.setStatusBusy({
            text: _T("backup", "search_restore_folder")
        });
        this.owner.api.send(a, function(f, e, d) {
            var b = this.nextId[this.getRepoType().id];
            var c = this.owner.getStep(b);
            this.owner.clearStatusBusy();
            if (!f) {
                this.owner.api.alert(e);
                return
            }
            if (c.loadData(e)) {
                this.owner.goNext(b);
                this.loaded = true
            } else {
                this.owner.api.alert(_T("backup", "restore_no_dest"), function() {
                    this.getComponent(0).getComponent("local").disable();
                    this.getForm().setValues({
                        bkptype: "synology"
                    })
                }, this)
            }
        }, this)
    },
    getNext: function() {
        var a = this.getRepoType();
        if (!Ext.isObject(a)) {
            return false
        }
        if (a.id === "local" && !this.loaded) {
            this.loadLocalDestData();
            return false
        }
        if (this.launchOAuthWindow(a)) {
            return false
        }
        return this.nextId[a.id]
    },
    getParams: function() {
        var a = this.getRepoType();
        if (!Ext.isObject(a)) {
            return {}
        }
        return {
            bkptype: a.target_type
        }
    }
});
Ext.namespace("SYNO.SDS.LunBackup");
SYNO.SDS.LunBackup.LUNBKP_SYNO_SERVER = "lunbkp_synology";
SYNO.SDS.LunBackup.BKPSET_MAX_LEN = 32;
SYNO.SDS.LunBackup.BKP_DEST_CONTD_WIDTH = 250;
SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH = 230;
SYNO.SDS.LunBackup.BKP_DEST_TYPE_LOCLUN = "locallun";
SYNO.SDS.LunBackup.BKP_DEST_TYPE_NETLUN = "netlun";
SYNO.SDS.LunBackup.BKPTASK_LOCLUN = "loclunbkp";
SYNO.SDS.LunBackup.BKPTASK_NETLUN = "netlunbkp";
SYNO.SDS.LunBackup.getFakePass = function() {
    var a;
    var b = "";
    for (a = 0; a < 8; a++) {
        b += String.fromCharCode(65283)
    }
    return b
};
SYNO.SDS.LunBackup.GetServerName = function(c) {
    var b = c;
    var a = c.indexOf("(");
    if (a > 0) {
        b = c.substring(0, a)
    }
    if (Ext.form.VTypes.netbiosName(b) || (Ext.form.VTypes.hostname(b) && !Ext.form.VTypes.looseip(b))) {
        return b
    }
    return ""
};
SYNO.SDS.LunBackup.GetServerIP = function(b) {
    var c = b;
    var a = b.indexOf("(");
    var d = b.indexOf(")");
    if (a > 0 && a < d && d === (b.length - 1)) {
        c = b.substring(a + 1, d)
    }
    if (Ext.form.VTypes.looseip(c)) {
        return c
    }
    return ""
};
SYNO.SDS.LunBackup.onLoadSynologyServer = function(c, a, b) {
    b.setStatusBusy({
        text: _T("netbackup", "netbkp_wait_server")
    });
    b.sendWebAPI({
        api: "SYNO.Backup.Lunbackup",
        version: 1,
        method: "net_bkp_host",
        scope: this,
        callback: function(f, d) {
            b.clearStatusBusy();
            if (f) {
                for (var e = 0; e < d.total; e++) {
                    a.push([d.items[e].ip, d.items[e].host])
                }
                if (!c.isExpanded()) {
                    c.el.focus()
                }
                c.getStore().loadData(a, false)
            }
        }
    })
};
SYNO.SDS.LunBackup.onTestSvrConnection = function(c, d, b, a) {
    b.owner.setStatusBusy({
        text: _T("netbackup", "netbkp_connection_testing")
    });
    b.owner.sendWebAPI({
        api: "SYNO.Backup.Lunbackup",
        version: 1,
        method: c,
        params: d,
        scope: b,
        callback: function(g, f) {
            var e = d.title ? d.title : _T("tree", "leaf_backup");
            if (a) {
                a.call(b, g, f)
            } else {
                b.owner.clearStatusBusy();
                if (g) {
                    b.owner.getMsgBox().alert(e, _T("netbackup", "netbkp_connection_testing_success"))
                } else {
                    if (f && f.errors && f.errors.sec && f.errors.key && "" !== f.errors.sec && "" !== f.errors.key) {
                        b.owner.getMsgBox().alert(e, _T(f.errors.sec, f.errors.key))
                    } else {
                        b.owner.getMsgBox().alert(e, _T("netbackup", "netbkp_connection_testing_fail"))
                    }
                }
            }
        }
    })
};
SYNO.SDS.LunBackup.getLocalIPs = function(b, a) {
    b.sendWebAPI({
        api: "SYNO.Backup.Lunbackup",
        method: "get_self_host",
        version: 1,
        scope: b,
        callback: function(d, c) {
            if (a) {
                a.call(b, d, c)
            }
        }
    })
};
SYNO.SDS.LunBackup.netbkpValidator = function(f, a, c) {
    var d = a.split(",");
    var e = new RegExp(c, "gi");
    if (f === a || f === "127.0.0.1" || (f.match(e) && f.length === c.length)) {
        return SYNO.SDS.Backup.String("app", "connect_self_ip")
    }
    for (var b = 0; b < d.length; b++) {
        if (f === d[b]) {
            return SYNO.SDS.Backup.String("app", "connect_self_ip")
        }
    }
    return true
};
Ext.define("SYNO.SDS.Backup.LUNResTypePanel", {
    extend: "SYNO.ux.FormPanel",
    isActivatedBefore: false,
    taskStore: null,
    constructor: function(b) {
        this.bkptaskList = [];
        var d = b.grid;
        var e = true;
        var c;
        for (c = 0; c < d.getCount(); c++) {
            var f = d.getAt(c);
            if (("success" === f.data.status) && ((SYNO.SDS.LunBackup.BKPTASK_LOCLUN === f.data.type) || (SYNO.SDS.LunBackup.BKPTASK_NETLUN === f.data.type))) {
                this.bkptaskList.push([f.data.name, f.data.type, f.data.bkp_dest_type]);
                e = false
            }
        }
        this.taskStore = new Ext.data.SimpleStore({
            id: "bkptaskstore",
            fields: ["bkpset", "bkptype", "bkp_dest_type"],
            data: this.bkptaskList
        });
        this.taskStore.loadData(this.bkptaskList, false);
        var a = {
            items: [{
                xtype: "syno_displayfield",
                value: _T("backup", "restore_current_task")
            }, {
                xtype: "syno_radio",
                boxLabel: _T("backup", "select_task"),
                name: "bkptype",
                inputValue: SYNO.SDS.Backup.BKPTASK_EXISTED,
                checked: true,
                disabled: e,
                indent: 1
            }, {
                xtype: "syno_combobox",
                name: "select_current_task",
                hiddenName: "select_current_task",
                width: 200,
                listWidth: 200,
                store: this.taskStore,
                valueField: "bkpset",
                displayField: "bkpset",
                editable: false,
                forceSelection: true,
                triggerAction: "all",
                selectOnFocus: true,
                scope: this,
                indent: 2,
                hideLabel: true
            }, {
                xtype: "syno_displayfield",
                value: String.format(_T("backup", "restore_new_task"), _D("company_title"))
            }, {
                xtype: "syno_radio",
                boxLabel: _T("lunbkp", "local_lun_restore"),
                name: "bkptype",
                inputValue: SYNO.SDS.LunBackup.BKPTASK_LOCLUN,
                checked: e ? true : false,
                indent: 1
            }, {
                xtype: "syno_displayfield",
                value: _T("lunbkp", "local_lun_restore_desc"),
                indent: 2
            }, {
                xtype: "syno_radio",
                boxLabel: _T("lunbkp", "network_lun_restore") + " (" + String.format(_T("netbackup", "synology_server"), _D("company_title")) + ")",
                name: "bkptype",
                inputValue: SYNO.SDS.LunBackup.BKPTASK_NETLUN,
                indent: 1
            }, {
                xtype: "syno_displayfield",
                value: String.format(_T("lunbkp", "network_lun_restore_desc"), _D("company_title")),
                indent: 2
            }]
        };
        Ext.apply(a, b);
        this.callParent([a])
    },
    registerEvent: function() {
        if (0 < this.bkptaskList.length) {
            this.getForm().findField("select_current_task").setValue(this.bkptaskList[0][0])
        } else {
            this.getForm().findField("select_current_task").setDisabled(true)
        }
    },
    activate: function() {
        if (!this.isActivatedBefore) {
            this.isActivatedBefore = true;
            this.registerEvent()
        }
    },
    saveSettings: function() {
        var e = this.getForm();
        var c = e.findField("select_current_task").getValue();
        var a = e.findField("bkptype").getGroupValue();
        var d;
        this.owner.taskname = c;
        this.owner.bkptype = a;
        this.owner.desttype = a;
        if (SYNO.SDS.Backup.BKPTASK_EXISTED === this.owner.bkptype) {
            this.owner.blExistedTask = true;
            var b = e.findField("select_current_task").getValue();
            for (d = 0; d < this.taskStore.getTotalCount(); d++) {
                if (b === this.taskStore.getAt(d).data.bkpset) {
                    this.owner.bkptype = this.taskStore.getAt(d).data.bkptype;
                    this.owner.desttype = this.taskStore.getAt(d).data.bkp_dest_type;
                    break
                }
            }
        } else {
            this.owner.blExistedTask = false
        }
    },
    getNext: function() {
        this.saveSettings();
        if (this.owner.blExistedTask) {
            return this.nextId[0]
        } else {
            if (SYNO.SDS.LunBackup.BKPTASK_LOCLUN === this.owner.bkptype) {
                return this.nextId[2]
            } else {
                if (SYNO.SDS.LunBackup.BKPTASK_NETLUN === this.owner.bkptype) {
                    return this.nextId[3]
                } else {
                    return false
                }
            }
        }
    },
    summary: function(a) {}
});
Ext.define("SYNO.SDS.Backup.LUNResSynoSerPanel", {
    extend: "SYNO.ux.FormPanel",
    isActivatedBefore: false,
    ServerStore: null,
    constructor: function(b) {
        this.ServerList = [];
        this.ServerStore = new Ext.data.SimpleStore({
            fields: ["value", "display"],
            data: this.ServerList
        });
        var a = {
            items: [{
                xtype: "syno_combobox",
                fieldLabel: _T("netbackup", "netbkp_set_ip"),
                hiddenName: "server",
                name: "server",
                forceSelection: false,
                allowBlank: false,
                emptyText: _T("netbackup", "netbkp_input_addr"),
                editable: true,
                store: this.ServerStore,
                displayField: "display",
                valueField: "value",
                triggerAction: "all",
                lazyRender: true,
                queryDelay: 1800000,
                width: 200,
                validateOnBlur: true,
                validationEvent: "blur",
                validator: function(c) {
                    return SYNO.SDS.LunBackup.netbkpValidator(c, b.owner.selfIPs, b.owner.selfHostName)
                },
                onTriggerClick: function() {
                    if (0 !== this.getStore().getCount()) {
                        if (this.isExpanded()) {
                            this.collapse();
                            this.el.focus()
                        } else {
                            this.onFocus({});
                            this.expand();
                            this.el.focus()
                        }
                    } else {
                        this.scope.serverListLoaded = true;
                        this.el.focus();
                        SYNO.SDS.LunBackup.onLoadSynologyServer(this, this.scope.ServerList, this.scope.owner)
                    }
                },
                scope: this
            }, {
                xtype: "syno_textfield",
                fieldLabel: _T("netbackup", "netbkp_account"),
                hiddenName: "account",
                name: "account",
                allowBlank: false,
                width: 200,
                vtype: "username_ext"
            }, {
                xtype: "syno_textfield",
                fieldLabel: _T("common", "password"),
                name: "password",
                inputType: "password",
                width: 200
            }, {
                xtype: "syno_button",
                id: this.btnTestId = Ext.id(),
                labelSeparator: "",
                name: "testconbtn",
                hiddenName: "testconbtn",
                text: _T("netbackup", "netbkp_test_connection"),
                handler: this.onTestConnectionButton,
                scope: this
            }]
        };
        Ext.apply(a, b);
        this.callParent([a])
    },
    activate: function() {},
    saveSettings: function() {
        this.owner.netRcvrParams = {};
        this.owner.netRcvrParams.account = this.getForm().findField("account").getValue();
        this.owner.netRcvrParams.password = this.getForm().findField("password").getValue();
        var a = this.getForm().findField("server").getRawValue();
        this.owner.netRcvrParams.server = SYNO.SDS.LunBackup.GetServerName(a);
        this.owner.netRcvrParams.ip = SYNO.SDS.LunBackup.GetServerIP(a)
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        this.saveSettings();
        this.onTestConnectionButton("next");
        return false
    },
    summary: function(a) {},
    TestServerVersionDone: function(b, a) {
        this.owner.clearStatusBusy();
        if (b) {
            this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("netbackup", "netbkp_connection_testing_success"))
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), SYNO.SDS.Backup.String(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("netbackup", "netbkp_connection_testing_fail"))
            }
        }
    },
    TestConnectionDone: function(c, a) {
        if (c) {
            var b = {};
            b.servertype = "synology";
            b.share = "share";
            b = this.getParamsVal(b);
            b.ip = a.ip;
            this.sendWebAPI({
                api: "SYNO.Backup.Lunbackup",
                version: 1,
                method: "remote_version_check",
                params: b,
                scope: this,
                callback: this.TestServerVersionDone
            })
        } else {
            this.owner.clearStatusBusy();
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("netbackup", "netbkp_connection_testing_fail"))
            }
        }
    },
    TestServerVersionWhenGoNext: function(b, a) {
        this.owner.clearStatusBusy();
        if (b) {
            this.owner.goNext(this.nextId)
        } else {
            if (a && a.errors && a.errors.key) {
                if ("netbkp_e_unknown" !== a.errors.key) {
                    this.owner.goNext(this.nextId)
                } else {
                    this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("lunbkp", "server_version_error"))
                }
            } else {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("netbackup", "netbkp_connection_testing_fail"))
            }
        }
    },
    TestConnectionWhenGoNext: function(c, a) {
        if (c) {
            var b = {};
            b.servertype = "synology";
            b.share = "share";
            b = this.getParamsVal(b);
            b.ip = a.ip;
            this.sendWebAPI({
                api: "SYNO.Backup.Lunbackup",
                version: 1,
                method: "remote_version_check",
                params: b,
                scope: this,
                callback: this.TestServerVersionWhenGoNext
            })
        } else {
            this.owner.clearStatusBusy();
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("netbackup", "netbkp_connection_testing_fail"))
            }
        }
    },
    onTestConnectionButton: function(b) {
        var a = {};
        a.servertype = SYNO.SDS.LunBackup.LUNBKP_SYNO_SERVER;
        a = this.getParamsVal(a);
        if (a) {
            var c = b === "next" ? this.TestConnectionWhenGoNext : this.TestConnectionDone;
            SYNO.SDS.LunBackup.onTestSvrConnection("test_connections", a, this, c)
        } else {
            this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("netbackup", "netbkp_err_host_str"))
        }
    },
    getParamsVal: function(e) {
        var d = this.getForm();
        var b = d.findField("server").getRawValue();
        var a = SYNO.SDS.LunBackup.GetServerName(b);
        var c = SYNO.SDS.LunBackup.GetServerIP(b);
        if (a === "" && c === "") {
            this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("netbackup", "netbkp_err_host_str"));
            return false
        }
        e.server = a;
        e.ip = c;
        e.account = d.findField("account").getValue();
        e.password = d.findField("password").getValue();
        e.module = "";
        e.incrbkp_enable = false;
        e.ssh_enable = false;
        e.compression_enable = false;
        e.blockbkp_enable = false;
        return e
    }
});
Ext.define("SYNO.SDS.Backup.LUNResNetShare", {
    extend: "SYNO.ux.FormPanel",
    initialized: false,
    RemoteStore: null,
    constructor: function(b) {
        this.RemoteList = [];
        this.RemoteStore = new Ext.data.SimpleStore({
            id: "dsRemoteShare",
            fields: ["value", "display"],
            data: this.RemoteList
        });
        var a = {
            items: [{
                xtype: "syno_combobox",
                fieldLabel: _T("netbackup", "restore_share_folder"),
                name: "remoteShare",
                store: this.RemoteStore,
                allowBlank: false,
                displayField: "display",
                valueField: "value",
                width: 250
            }]
        };
        Ext.apply(a, b);
        this.callParent([a])
    },
    activate: function() {
        if (!this.initialized) {
            this.remoteShareEnum()
        }
    },
    saveSettings: function() {
        this.owner.netRcvrParams.module = this.getForm().findField("remoteShare").getValue()
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        this.saveSettings();
        return this.nextId
    },
    summary: function(a) {},
    remoteShareEnumDone: function(c, a) {
        this.owner.clearStatusBusy();
        if (c) {
            for (var b = 0; b < a.items.length; b++) {
                this.RemoteList.push([a.items[b].share, a.items[b].share])
            }
            this.RemoteStore.loadData(this.RemoteList, false);
            if (0 < this.RemoteList.length) {
                this.getForm().findField("remoteShare").setValue(this.RemoteList[0][0]);
                this.owner.netRcvrParams.ip = a.server_ip;
                this.owner.getButton("next").enable()
            } else {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("ftp", "ftp_no_share"));
                this.owner.getButton("next").disable()
            }
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("common", "error_system"));
                this.owner.getButton("next").disable()
            }
        }
    },
    remoteShareEnum: function() {
        var b;
        var a = this.owner.PanelSynoServer.getForm().findField("server").getRawValue();
        this.RemoteStore.removeAll();
        this.RemoteList.length = 0;
        b = {};
        b.user = this.owner.PanelSynoServer.getForm().findField("account").getRawValue();
        b.password = this.owner.PanelSynoServer.getForm().findField("password").getRawValue();
        b.server = SYNO.SDS.LunBackup.GetServerName(a);
        b.ip = SYNO.SDS.LunBackup.GetServerIP(a);
        b.type = "lunrtor";
        this.owner.setStatusBusy({
            text: _T("netbackup", "netbkp_search_folder")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "enum_remote_share",
            params: b,
            scope: this,
            callback: this.remoteShareEnumDone
        })
    }
});
Ext.define("SYNO.SDS.Backup.LUNResLocSrc", {
    extend: "SYNO.ux.FormPanel",
    isActivatedBefore: false,
    constructor: function(c) {
        var a = new Ext.data.SimpleStore({
            id: "value",
            fields: ["value", "display"],
            data: c.owner.localRcvrSrcList
        });
        c.owner.localRcvrSrcStore = a;
        var d = new SYNO.ux.ComboBox({
            fieldLabel: _T("backup", "local_restore_rcvr_folder"),
            hiddenName: "localrcvrsrc",
            name: "localrcvrsrc",
            forceSelection: true,
            editable: false,
            store: c.owner.localRcvrSrcStore,
            displayField: "display",
            valueField: "value",
            typeAhead: true,
            triggerAction: "all",
            lazyRender: true,
            width: 200,
            value: "",
            mode: "local"
        });
        var b = {
            items: [d]
        };
        Ext.apply(b, c);
        this.callParent([b])
    },
    activate: function() {
        if (!this.isActivatedBefore) {
            this.isActivatedBefore = true;
            this.localRcvrSrcRequest()
        }
    },
    saveSettings: function() {
        this.owner.localRcvrSrc = this.getForm().findField("localrcvrsrc").getValue()
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        this.saveSettings();
        return this.nextId
    },
    summary: function(a) {},
    localRcvrSrcDone: function(c, a) {
        this.owner.clearStatusBusy();
        if (c) {
            for (var b = 0; b < a.total; b++) {
                this.owner.localRcvrSrcList.push([a.items[b], a.items[b]])
            }
            this.owner.localRcvrSrcStore.loadData(this.owner.localRcvrSrcList, false);
            if (0 < this.owner.localRcvrSrcList.length) {
                this.getForm().findField("localrcvrsrc").setValue(this.owner.localRcvrSrcList[0][0]);
                this.owner.getButton("next").enable()
            } else {
                this.owner.getButton("next").disable()
            }
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("common", "error_system"));
                this.owner.getButton("next").disable()
            }
        }
    },
    localRcvrSrcRequest: function() {
        this.owner.localRcvrSrcList.length = 0;
        this.owner.setStatusBusy({
            text: _T("backup", "search_restore_folder")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "enum_local_share",
            scope: this,
            callback: this.localRcvrSrcDone
        })
    }
});
Ext.define("SYNO.SDS.Backup.ResLocSrcCID", {
    extend: "SYNO.ux.FormPanel",
    isActivatedBefore: false,
    constructor: function(c) {
        var b = new Ext.data.SimpleStore({
            id: "value",
            fields: ["value", "display"],
            data: c.owner.localSrcCIDList
        });
        c.owner.localSrcCIDStore = b;
        var d = new SYNO.ux.ComboBox({
            fieldLabel: _T("backup", "backup_dest_directory"),
            hiddenName: "localsrccid",
            name: "localsrccid",
            forceSelection: true,
            editable: false,
            store: c.owner.localSrcCIDStore,
            displayField: "display",
            valueField: "value",
            typeAhead: true,
            triggerAction: "all",
            lazyRender: true,
            width: 200,
            value: "",
            mode: "local"
        });
        var a = {
            items: [d]
        };
        Ext.apply(a, c);
        this.callParent([a]);
        d.on("select", function() {
            this.owner.blChangeRcvrSrc = true
        }, this)
    },
    activate: function() {
        this.localSrcCIDRequest()
    },
    saveSettings: function() {
        this.owner.localSrcCID = this.getForm().findField("localsrccid").getValue()
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        this.saveSettings();
        return this.nextId
    },
    summary: function(a) {},
    localSrcCIDDone: function(c, a) {
        this.owner.clearStatusBusy();
        if (c) {
            for (var b = 0; b < a.total; b++) {
                this.owner.localSrcCIDList.push([a.items[b], a.items[b]])
            }
            this.owner.localSrcCIDStore.loadData(this.owner.localSrcCIDList, false);
            if (0 < this.owner.localSrcCIDList.length) {
                this.getForm().findField("localsrccid").setValue(this.owner.localSrcCIDList[0][0]);
                this.owner.getButton("next").enable()
            } else {
                this.getForm().findField("localsrccid").setValue("");
                this.owner.getButton("next").disable()
            }
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("common", "error_system"));
                this.owner.getButton("next").disable()
            }
        }
    },
    localSrcCIDRequest: function() {
        var a = {};
        this.owner.localSrcCIDList.length = 0;
        a.share = this.owner.localRcvrSrc;
        this.owner.setStatusBusy({
            text: _T("lunbkp", "search_client_folder")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "enum_local_lun_dir",
            params: a,
            scope: this,
            callback: this.localSrcCIDDone
        })
    }
});
Ext.define("SYNO.SDS.Backup.ResDestVol", {
    extend: "SYNO.ux.FormPanel",
    isActivatedBefore: false,
    lunName: null,
    constructor: function(c) {
        var a = new Ext.data.SimpleStore({
            id: "value",
            fields: ["value", "display"],
            data: c.owner.destVolumeList
        });
        c.owner.destVolumeStore = a;
        var d = new SYNO.ux.ComboBox({
            fieldLabel: _T("localbkp", "localbkp_dest"),
            hiddenName: "destvolume",
            name: "destvolume",
            forceSelection: true,
            editable: false,
            store: c.owner.destVolumeStore,
            displayField: "display",
            valueField: "value",
            typeAhead: true,
            triggerAction: "all",
            lazyRender: true,
            width: 200,
            value: "",
            mode: "local"
        });
        var b = {
            items: [d]
        };
        Ext.apply(b, c);
        SYNO.SDS.Backup.ResDestVol.superclass.constructor.call(this, b);
        d.on("select", function(g, f, e) {
            this.getForm().findField("destvolume").el.dom.qtip = this.owner.destVolumeList[e][1]
        }, this)
    },
    activate: function() {
        if (!this.isActivatedBefore) {
            this.isActivatedBefore = true;
            this.destVolumeRequest()
        }
        if (this.owner.blExistedTask) {
            this.loadLUNBkpConf(this.owner.taskname)
        } else {
            if (SYNO.SDS.LunBackup.BKPTASK_LOCLUN === this.owner.bkptype) {
                this.enumLocLUNName()
            } else {
                if (SYNO.SDS.LunBackup.BKPTASK_NETLUN === this.owner.bkptype) {
                    this.enumNetLUNName()
                }
            }
        }
    },
    saveSettings: function() {
        this.owner.destVolume = this.getForm().findField("destvolume").getValue()
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        this.saveSettings();
        return this.nextId
    },
    enumLocLUNNameDone: function(b, a) {
        this.owner.clearStatusBusy();
        if (b) {
            this.owner.lunName = a.items[0].lunname_org;
            this.owner.lunSize = a.items[0].lunsize;
            this.owner.renamedLun = a.items[0].lunname_new;
            this.owner.blocksize = a.items[0].blocksize;
            this.owner.lun_type = a.items[0].lun_type;
            this.owner.dev_attribs = a.items[0].dev_attribs;
            this.owner.directIOPattern = a.items[0].directIOPattern;
            this.owner.advLun = a.items[0].advLun
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("common", "error_system"))
            }
        }
    },
    enumLocLUNName: function() {
        var a = {};
        a.share = this.owner.localRcvrSrc;
        a.dir = this.owner.localSrcCID;
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "enum_local_restore_lun_name",
            params: a,
            scope: this,
            callback: this.enumLocLUNNameDone
        })
    },
    enumNetLUNNameDone: function(b, a) {
        this.owner.clearStatusBusy();
        if (b) {
            this.owner.lunName = a.items[0].lunname_org;
            this.owner.renamedLun = a.items[0].lunname_new;
            this.owner.lunSize = a.items[0].lunsize;
            this.owner.blocksize = a.items[0].blocksize;
            this.owner.lun_type = a.items[0].lun_type;
            this.owner.dev_attribs = a.items[0].dev_attribs;
            this.owner.directIOPattern = a.items[0].directIOPattern;
            this.owner.advLun = a.items[0].advLun
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("common", "error_system"))
            }
        }
    },
    enumNetLUNName: function() {
        var a = {};
        a.share = this.owner.netRcvrParams.module;
        a.dir = this.owner.netSrcCID;
        this.owner.PanelSynoServer.getParamsVal(a);
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "enum_net_restore_lun_name",
            params: a,
            scope: this,
            callback: this.enumNetLUNNameDone
        })
    },
    loadLUNBkpConfDone: function(b, a) {
        this.owner.clearStatusBusy();
        if (b) {
            this.owner.serverIP = a.items[0].ip;
            this.owner.account = a.items[0].user;
            this.owner.sourcePath = a.items[0].dest;
            this.owner.lunName = a.items[0].lunname_org;
            this.owner.renamedLun = a.items[0].lunname_new;
            this.owner.blocksize = a.items[0].blocksize;
            this.owner.lun_type = a.items[0].lun_type
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("common", "error_system"))
            }
        }
    },
    loadLUNBkpConf: function(a) {
        var b = {};
        b.taskname = a;
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "load_lun_bkp_conf",
            params: b,
            scope: this,
            callback: this.loadLUNBkpConfDone
        })
    },
    summary: function(a) {
        if (this.owner.blExistedTask) {
            if (SYNO.SDS.LunBackup.BKPTASK_LOCLUN === this.owner.bkptype) {
                a.append(_T("backup", "restore_type"), _T("lunbkp", "local_lun_restore"))
            } else {
                a.append(_T("backup", "restore_type"), _T("lunbkp", "network_lun_restore"));
                a.append(_T("netbackup", "netbkp_slct_server"), String.format(_T("netbackup", "synology_server"), _D("company_title")));
                a.append(_T("netbackup", "restore_server"), this.owner.serverIP);
                a.append(_T("netbackup", "netbkp_auth_user"), this.owner.account)
            }
            a.append(_T("netbackup", "netbkp_restore_folder"), this.owner.sourcePath)
        } else {
            if (SYNO.SDS.LunBackup.BKPTASK_LOCLUN === this.owner.bkptype) {
                a.append(_T("backup", "restore_type"), _T("lunbkp", "local_lun_restore"));
                a.append(_T("netbackup", "netbkp_restore_folder"), this.owner.localRcvrSrc + "/" + this.owner.localSrcCID + "/")
            } else {
                a.append(_T("backup", "restore_type"), _T("lunbkp", "network_lun_restore"));
                a.append(_T("netbackup", "netbkp_slct_server"), String.format(_T("netbackup", "synology_server"), _D("company_title")));
                var b = (this.owner.netRcvrParams.server.length > 0) ? this.owner.netRcvrParams.server : this.owner.netRcvrParams.ip;
                a.append(_T("netbackup", "restore_server"), b);
                a.append(_T("netbackup", "netbkp_auth_user"), this.owner.netRcvrParams.account);
                a.append(_T("netbackup", "netbkp_restore_folder"), this.owner.netRcvrParams.module + "/" + this.owner.netSrcCID + "/")
            }
        }
        this.owner.dest = this.owner.destVolume + "/" + this.owner.renamedLun;
        a.append(_T("lunbkp", "restore_lun"), this.owner.lunName);
        a.append(_T("lunbkp", "name_after_restored"), this.owner.dest)
    },
    destVolumeDone: function(c, a) {
        this.owner.clearStatusBusy();
        if (c) {
            this.owner.blChangeRcvrSrc = true;
            for (var b = 0; b < a.volume_list.length; b++) {
                this.owner.destVolumeList.push([a.volume_list[b].mount_point.substring(1, a.volume_list[b].mount_point.length), a.volume_list[b].display])
            }
            this.owner.destVolumeStore.loadData(this.owner.destVolumeList, false);
            if (0 < this.owner.destVolumeList.length) {
                this.getForm().findField("destvolume").setValue(this.owner.destVolumeList[0][0]);
                this.getForm().findField("destvolume").el.dom.qtip = this.owner.destVolumeList[0][1];
                this.owner.getButton("next").enable()
            } else {
                this.owner.getButton("next").disable()
            }
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("common", "error_system"));
                this.owner.getButton("next").disable()
            }
        }
    },
    destVolumeRequest: function() {
        this.owner.destVolumeList.length = 0;
        this.owner.setStatusBusy({
            text: _T("lunbkp", "search_dest_volume")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "enum_volume",
            scope: this,
            callback: this.destVolumeDone
        })
    }
});
Ext.define("SYNO.SDS.Backup.ResNetSrcCID", {
    extend: "SYNO.ux.FormPanel",
    loadFinished: false,
    enableNext: false,
    isActivatedBefore: false,
    taskPolling: null,
    constructor: function(c) {
        var a = new Ext.data.SimpleStore({
            id: "value",
            fields: ["value", "display"],
            data: c.owner.netSrcCIDList
        });
        c.owner.netSrcCIDStore = a;
        var d = new SYNO.ux.ComboBox({
            fieldLabel: _T("backup", "backup_dest_directory"),
            hiddenName: "netSrcCID",
            name: "netSrcCID",
            forceSelection: true,
            editable: false,
            store: c.owner.netSrcCIDStore,
            displayField: "display",
            valueField: "value",
            typeAhead: true,
            triggerAction: "all",
            lazyRender: true,
            width: 200,
            value: "",
            mode: "local"
        });
        var b = {
            items: [d]
        };
        Ext.apply(b, c);
        d.on("select", function() {
            this.owner.blChangeRcvrSrc = true
        }, this);
        this.callParent([b])
    },
    load: function() {
        this.owner.netSrcCIDList.length = 0;
        this.netSrcCIDRequest()
    },
    activate: function() {
        this.enableNext = false;
        this.loadFinished = false;
        this.owner.netSrcCIDStore.loadData([], false);
        this.getForm().findField("netSrcCID").clearValue();
        if (!this.isActivatedBefore) {
            this.load()
        }
    },
    checkState: function() {
        SYNO.SDS.Wizard.Step.prototype.checkState.apply(this, arguments);
        if (this.loadFinished) {
            if (this.enableNext) {
                this.owner.getButton("next").enable()
            } else {
                this.owner.getButton("next").disable()
            }
        } else {
            this.owner.getButton("next").disable()
        }
    },
    saveSettings: function() {
        this.owner.netSrcCID = this.getForm().findField("netSrcCID").getValue()
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        this.saveSettings();
        return this.nextId
    },
    summary: function(a) {},
    netSrcCIDDone: function(c, a) {
        this.owner.clearStatusBusy();
        if (c) {
            this.enableNext = true;
            this.loadFinished = true;
            this.checkState();
            for (var b = 0; b < a.total; b++) {
                this.owner.netSrcCIDList.push([a.items[b], a.items[b]])
            }
            if (this.owner.netSrcCIDStore !== null) {
                this.owner.netSrcCIDStore.loadData(this.owner.netSrcCIDList, false)
            }
            if (a.params) {
                this.owner.netRcvrParams = a.params
            }
            if (0 < this.owner.netSrcCIDList.length) {
                this.getForm().findField("netSrcCID").setValue(this.owner.netSrcCIDList[0][0]);
                this.owner.getButton("next").enable()
            } else {
                this.getForm().findField("netSrcCID").setValue("");
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("netbackup", "bkp_host_no_dir"));
                this.owner.getButton("next").disable()
            }
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("common", "error_system"))
            }
        }
    },
    netSrcCIDRequest: function() {
        var a = {};
        a.servertype = "synology";
        a.share = this.owner.netRcvrParams.module;
        this.GetParams(a);
        this.SearchRequest(a, _T("backup", "search_restore_folder"), this.netSrcCIDDone)
    },
    GetParams: function(a) {
        a.account = this.owner.netRcvrParams.account;
        a.ip = this.owner.netRcvrParams.ip;
        a.server = this.owner.netRcvrParams.server;
        a.module = this.owner.netRcvrParams.module;
        a.password = this.owner.netRcvrParams.password
    },
    SearchRequest: function(c, b, a) {
        this.owner.setStatusBusy(_T("lunbkp", "search_directory"));
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "enum_net_lun_dir",
            params: c,
            scope: this,
            callback: a
        })
    }
});
Ext.define("SYNO.SDS.Backup.Restore.LunProgressView", {
    extend: "SYNO.ux.ExpandableListView",
    constructor: function(a) {
        this.callParent(arguments);
        this.addClass("syno-backup-restore-progress-listview")
    },
    createTpl: function() {
        var d = '<span class="item-title" style="padding-top: 8px">{name:htmlEncode}</span>';
        var b = '<div class="item-status" style="margin-top: 2px; color: unset; padding-bottom:8px"><div class="{status_class}">{status_str}</div></div>';
        var a = '<div class="syno-restore-usage-lun"><div class="item-title syno-backup-percentage-bar-bg"><div class="syno-backup-percentage-bar" style="height: inherit; width:{progress * 2}px"></div></div><div class="item-status" style="color: unset; padding-bottom:8px; padding-top:3px"><span class="blue-status">{processed_size}</span>&nbsp;/&nbsp;{total_size}</div></div>';
        var c = new Ext.XTemplate('<tpl for=".">', '<div class="item-wrap" style="margin-top:16px; margin-left:20px; margin-right:20px">', '<div class="item-summary">', '<div class="item-icon {icon_cls} icon-task"></div>', "<div>", d, b, "</div>", '<tpl if="has_progress">', a, "</tpl>", "</div>", "</div>", "</tpl>", '<div class="x-clear"></div>');
        return c
    },
    prepareData: function(c, b, a) {
        c.name = _T("lunbkp", "lun_restore");
        c.status_str = _T("backup", "restore_lun_executing");
        c.status_class = "blue-status";
        c.has_progress = c.total_size !== "";
        c.processed_size = SYNO.SDS.Backup.ConverSize(c.processed_size, 2);
        c.total_size = SYNO.SDS.Backup.ConverSize(c.total_size, 2);
        c.icon_cls = "syno-backup-restore-progress-lun";
        return c
    }
});
Ext.define("SYNO.SDS.Backup.Restore.LunProgressPanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(a) {
        a = this.fillConfig(a);
        this.callParent([a])
    },
    initEvents: function() {
        this.on("afterrender", this.startPolling, this);
        this.on("beforeclose", this.stopPolling, this)
    },
    fillConfig: function(a) {
        return Ext.apply({
            items: [this.getView()]
        }, a)
    },
    startPolling: function() {
        if (this.pollingTask) {
            this.pollingTask.restart()
        } else {
            this.pollingTask = this.addWebAPITask({
                api: "SYNO.Backup.Lunbackup",
                version: 1,
                method: "load_restore_progress",
                interval: 2000,
                scope: this,
                callback: this.onPollingDone
            }).start(true)
        }
    },
    stopPolling: function() {
        if (this.pollingTask) {
            this.pollingTask.stop()
        }
    },
    onPollingDone: function(b, a) {
        if (b) {
            if (a.finish) {
                this.stopPolling();
                this.owner.close();
                return
            }
            a.progress.id = "lun";
            if (a.progress.progress >= 0) {
                this.owner.getButton("cancel").enable()
            }
            this.getStore().loadData([a.progress])
        }
    },
    getStore: function() {
        if (!this.store) {
            this.store = new Ext.data.JsonStore({
                fields: ["progress", "processed_size", "total_size"]
            })
        }
        return this.store
    },
    getView: function() {
        if (!this.view) {
            var a = {
                store: this.getStore(),
                owner: this,
                height: 60,
                autoFlexcroll: false
            };
            this.view = new SYNO.SDS.Backup.Restore.LunProgressView(a)
        }
        return this.view
    }
});
Ext.define("SYNO.SDS.Backup.Restore.LunProgressWindow", {
    extend: "SYNO.SDS.ModalWindow",
    dsmStyle: "v5",
    constructor: function(a) {
        Ext.copyTo(this, a, "owner");
        var b = Ext.apply({
            resizable: false,
            banner: false,
            layout: "fit",
            width: 580,
            height: 250,
            bodyCssClass: "sds-wizard-step",
            title: _T("backup", "restore_progress"),
            items: [this.wrapPanel = new SYNO.ux.Panel({
                autoFlexcroll: true,
                bwrapCfg: {
                    cls: "x-panel-bwrap sds-wizard-step-bwrap"
                },
                items: [this.progressPanel = new SYNO.SDS.Backup.Restore.LunProgressPanel({
                    owner: this
                })]
            })],
            buttons: [{
                xtype: "syno_button",
                itemId: "cancel",
                disabled: true,
                text: _T("common", "cancel"),
                scope: this,
                handler: function() {
                    this.getMsgBox().confirm(_T("tree", "leaf_backup"), _T("backup", "restore_cancel_confirm"), function(c) {
                        if (c === "yes") {
                            this.onRestoreCancel()
                        }
                    }, this)
                }
            }]
        }, a);
        this.callParent([b])
    },
    getButton: function(a) {
        return this.getFooterToolbar().getComponent(a)
    },
    onRestoreCancel: function() {
        this.getButton("cancel").disable();
        this.setStatusBusy();
        this.progressPanel.stopPolling();
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "restore_cancel",
            scope: this,
            callback: function(b, a) {
                this.clearStatusBusy();
                if (!b) {
                    if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                        this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T(a.errors.sec, a.errors.key))
                    } else {
                        this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("common", "error_system"))
                    }
                }
                this.close()
            }
        })
    }
});
Ext.define("SYNO.SDS.Backup.LUNRestoreWizard", {
    extend: "SYNO.SDS.Wizard.ModalWindow",
    selfIPs: null,
    selfHostName: null,
    PanelWelcome: null,
    PanelType: null,
    PanelSummary: null,
    PanelSynoServer: null,
    PanelLocSrc: null,
    PanelLocSrcCID: null,
    PanelDest: null,
    PanelNetSrcCID: null,
    PanelNetShare: null,
    taskname: null,
    bkptype: null,
    desttype: null,
    blExistedTask: false,
    blChangeRcvrSrc: true,
    localRcvrSrcStore: null,
    localRcvrSrc: null,
    localSrcCIDStore: null,
    localSrcCID: null,
    netSrcShareStore: null,
    netSrcShare: null,
    netSrcCIDStore: null,
    netSrcCID: null,
    destVolumeStore: null,
    destVolume: null,
    serverIP: null,
    account: null,
    sourcePath: null,
    lunName: null,
    renamedLun: null,
    lunSize: null,
    advLun: null,
    blocksize: null,
    selectedShareCount: 0,
    shareStore: null,
    dest: null,
    restoreConflict: 0,
    excuteConfirm: 0,
    constructor: function(b) {
        var c = SYNO.SDS.Backup;
        this.localRcvrSrcList = [];
        this.localSrcCIDList = [];
        this.netSrcShareList = [];
        this.netSrcCIDList = [];
        this.destVolumeList = [];
        this.shareList = [];
        this.netRcvrParams = {};
        this.PanelWelcome = new SYNO.SDS.Wizard.WelcomeStep({
            headline: _T("lunbkp", "lun_restore_welcome_title"),
            description: _T("lunbkp", "lun_restore_welcome_desc").replaceAll("<li>", '<li class="syno-lun-bkp-welcome"><span>').replaceAll("</li>", "</span></li>").replaceAll("<ul>", '<ul class="syno-lun-bkp-welcome">'),
            itemId: "welcome",
            nextId: "type"
        });
        this.PanelType = new c.LUNResTypePanel({
            headline: _T("backup", "restore_wizard_desttype_title"),
            description: _T("backup", "reswizard_type_title"),
            itemId: "type",
            nextId: ["dest-volume", "net-srccid", "loc-src", "syno-server"],
            grid: b.grid,
            owner: this
        });
        this.PanelSynoServer = new c.LUNResSynoSerPanel({
            headline: _T("netbackup", "recover_serverset_title"),
            description: _T("netbackup", "netbkp_serverset3_desc"),
            itemId: "syno-server",
            nextId: "net-share",
            owner: this
        });
        this.PanelNetShare = new c.LUNResNetShare({
            headline: _T("lunbkp", "source_folder_title"),
            description: _T("lunbkp", "source_folder_desc"),
            itemId: "net-share",
            nextId: "net-srccid",
            owner: this
        });
        this.PanelLocSrc = new c.LUNResLocSrc({
            headline: _T("lunbkp", "source_folder_title"),
            description: _T("lunbkp", "source_folder_desc"),
            itemId: "loc-src",
            nextId: "loc-srccid",
            owner: this
        });
        this.PanelLocSrcCID = new c.ResLocSrcCID({
            headline: _T("lunbkp", "directory_title"),
            description: _T("lunbkp", "directory_desc"),
            itemId: "loc-srccid",
            nextId: "dest-volume",
            owner: this
        });
        this.PanelDest = new c.ResDestVol({
            headline: _T("lunbkp", "dest_vol_select"),
            description: _T("lunbkp", "dest_vol_select_desc"),
            itemId: "dest-volume",
            nextId: "summary",
            owner: this
        });
        this.PanelNetSrcCID = new c.ResNetSrcCID({
            headline: _T("lunbkp", "directory_title"),
            description: _T("lunbkp", "directory_desc"),
            itemId: "net-srccid",
            nextId: "dest-volume",
            owner: this
        });
        this.PanelSummary = new SYNO.SDS.Wizard.SummaryStep({
            headline: _T("localbkpwizard", "summary_title"),
            description: _T("wizcommon", "summary_descr"),
            itemId: "summary",
            nextId: null,
            getNext: function() {
                this.owner.applySetting();
                return false
            },
            owner: this
        });
        var a = [this.PanelWelcome, this.PanelType, this.PanelSynoServer, this.PanelNetShare, this.PanelLocSrc, this.PanelLocSrcCID, this.PanelDest, this.PanelNetSrcCID, this.PanelSummary];
        b = Ext.apply({
            title: _T("lunbkp", "restwizard_title"),
            width: 600,
            height: 520,
            steps: a
        }, b);
        this.callParent([b]);
        this.setActiveStep("welcome")
    },
    genApplyParams: function() {
        var b = {};
        var a = this.bkptype;
        b.rcvrtype = a;
        if (this.blExistedTask) {
            b.bytask = true;
            b.taskname = this.taskname;
            b.destvolume = this.destVolume;
            b.lunname = this.lunName;
            b.advLun = this.advLun
        } else {
            if (SYNO.SDS.LunBackup.BKPTASK_LOCLUN === a) {
                b.dest = this.destVolume;
                b.share = this.localRcvrSrc;
                b.dir = this.localSrcCID;
                b.lunname = this.lunName;
                b.lunsize = this.lunSize;
                b.advLun = this.advLun;
                b.blocksize = this.blocksize;
                b.dev_attribs = this.dev_attribs;
                b.directIOPattern = this.directIOPattern
            } else {
                b.dest = this.destVolume;
                b.share = this.netRcvrParams.module;
                b.dir = this.netSrcCID;
                b.lunname = this.lunName;
                b.lunsize = this.lunSize;
                b.advLun = this.advLun;
                b.blocksize = this.blocksize;
                b.account = this.netRcvrParams.account;
                b.ip = this.netRcvrParams.ip;
                b.server = this.netRcvrParams.server;
                b.password = this.netRcvrParams.password;
                b.dev_attribs = this.dev_attribs;
                b.directIOPattern = this.directIOPattern
            }
        }
        return b
    },
    applyDone: function(b, a) {
        this.clearStatusBusy();
        if (b) {
            this.appWin.isRestoreWinShow = true;
            var c = new SYNO.SDS.Backup.Restore.LunProgressWindow({
                owner: this.owner
            });
            c.on("close", function() {
                this.appWin.isRestoreWinShow = false
            }, this);
            this.close();
            c.open()
        } else {
            if (a && a.errors && "" !== a.errors.sec && "" !== a.errors.key) {
                this.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T(a.errors.sec, a.errors.key))
            } else {
                this.getMsgBox().alert(_T("netbackup", "netbkp_recovery"), _T("common", "commfail"))
            }
        }
    },
    applySetting: function() {
        this.WebapiRequest(this.genApplyParams(), _T("common", "saving"), this.applyDone)
    },
    Show: function() {
        SYNO.SDS.LunBackup.getLocalIPs(this, function(b, a) {
            if (b) {
                this.selfIPs = a.selfIPs;
                this.selfHostName = a.selfHostName
            }
        });
        this.open()
    },
    WebapiRequest: function(c, b, a) {
        this.setStatusBusy({
            text: b
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "restore_lun",
            params: c,
            scope: this,
            callback: a
        })
    }
});
Ext.define("SYNO.SDS.Backup.TaskNamePanel", {
    extend: "SYNO.ux.FormPanel",
    oriTaskName: "",
    constructor: function(b) {
        var a = {
            title: _T("localbkp", "localbkp_dest"),
            padding: "24px 0 0 0",
            items: [{
                xtype: "syno_textfield",
                fieldLabel: _T("localbkp", "localbkp_bkpset_name"),
                name: "bkpset",
                maxlength: SYNO.SDS.LunBackup.BKPSET_MAX_LEN,
                vtype: "taskname",
                width: SYNO.SDS.LunBackup.BKP_DEST_CONTD_WIDTH,
                allowBlank: false
            }]
        };
        Ext.apply(a, b);
        this.callParent([a])
    },
    getDefaultName: function() {
        var b = "My LUN Backup Set";
        var a = 1;
        while (true) {
            if (-1 === this.owner.owner.getTaskNameList().indexOf(b + " " + a)) {
                break
            }
            a++
        }
        return b + " " + a
    },
    activate: function() {
        var a = this.getForm().findField("bkpset");
        if ("" === a.getValue()) {
            a.setValue(this.getDefaultName())
        }
        this.getForm().findField("bkpset").focus(true)
    },
    bkpsetConflictDone: function(c, b) {
        this.owner.clearStatusBusy();
        if (c) {
            if (b.conflict) {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("localbkp", "localbkp_bkpset_exist"), function() {
                    this.getForm().findField("bkpset").focus(true)
                }, this)
            } else {
                var a = this.getForm().findField("bkpset").getValue();
                this.oriTaskName = a;
                this.owner.taskName = a;
                this.owner.goNext(this.nextId)
            }
        }
    },
    getNext: function() {
        var b = this.getForm().findField("bkpset");
        var a;
        if (!this.getForm().isValid()) {
            this.owner.setStatusError({
                text: _T("common", "forminvalid"),
                clear: true
            });
            return false
        }
        a = Ext.util.Format.trim(b.getValue());
        b.setValue(a);
        if (this.oriTaskName !== a) {
            this.owner.setStatusBusy({
                text: _T("common", "loading")
            });
            var c = {};
            c.bkpset = a;
            this.sendWebAPI({
                api: "SYNO.Backup.Lunbackup",
                version: 1,
                method: "is_bkp_set_conflict",
                params: c,
                scope: this,
                callback: this.bkpsetConflictDone
            });
            return false
        } else {
            return this.nextId
        }
    },
    summary: function(a) {
        a.append(_T("localbkp", "localbkp_bkpset_name"), this.getForm().findField("bkpset").getValue());
        return
    },
    getBkpSet: function() {
        return this.getForm().findField("bkpset").getValue()
    }
});
Ext.define("SYNO.SDS.Backup.LUNSourcePanel", {
    extend: "SYNO.ux.FormPanel",
    isActivatedBefore: false,
    constructor: function(b) {
        var c = new Ext.data.SimpleStore({
            id: "value",
            sortInfo: {
                field: "display",
                direction: "ASC"
            },
            fields: ["value", {
                name: "display",
                sortType: "asNaturalUCString"
            }],
            data: b.owner.lunSourceList
        });
        b.owner.lunSourceStore = c;
        var a = {
            title: Ext.util.Format.ellipsis(_T("lunbkp", "lun_source"), 15),
            padding: "24px 0 0 0",
            items: [{
                tpl: '<tpl for="."><div ext:qtip="{display}" class="x-combo-list-item">{display}</div></tpl>',
                xtype: "syno_combobox",
                fieldLabel: _T("lunbkp", "lun_source"),
                hiddenName: "lunsource",
                name: "lunsource",
                forceSelection: true,
                allowBlank: false,
                editable: false,
                store: c,
                displayField: "display",
                valueField: "value",
                triggerAction: "all",
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH,
                width: SYNO.SDS.LunBackup.BKP_DEST_CONTD_WIDTH,
                mode: "local",
                scope: this
            }]
        };
        Ext.apply(a, b);
        this.callParent([a]);
        this.registerEvent()
    },
    registerEvent: function() {
        this.getForm().findField("lunsource").on("select", function(c, b, a) {
            this.getForm().findField("lunsource").el.dom.qtip = this.owner.lunSourceList[a][1];
            this.owner.blBkpLUNChanged = true
        }, this)
    },
    activate: function() {
        if (!this.isActivatedBefore) {
            this.isActivatedBefore = true;
            this.lunSourceRequest()
        }
    },
    saveSettings: function() {
        this.owner.lunSource = this.getForm().findField("lunsource").getValue().name;
        this.owner.lunSourceSize = this.getForm().findField("lunsource").getValue().size;
        this.owner.lunSourceType = this.getForm().findField("lunsource").getValue().type
    },
    checkLUNDone: function(b, a) {
        this.owner.clearStatusBusy();
        if (b) {
            if (("passed" === a.name_check) && ("passed" === a.space_check)) {
                this.owner.goNext(this.nextId)
            }
        } else {
            if (null !== a) {
                if ("failed" === a.errors.name_check) {
                    this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("smsnotify", "provider_name_repetition"))
                } else {
                    if ("failed" === a.errors.space_check) {
                        this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("share", "share_space_not_enough"))
                    } else {
                        this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("common", "error_system"))
                    }
                }
            } else {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("common", "error_system"))
            }
            this.owner.getButton("next").disable()
        }
    },
    checkLUN: function() {
        var a = {};
        a.tasktype = this.owner.taskType;
        a.lunname = this.owner.lunSource;
        a.lunsize = this.owner.lunSourceSize;
        if (SYNO.SDS.LunBackup.BKPTASK_LOCLUN === this.owner.taskType) {
            a.share = this.owner.PanelDestLocal.getForm().findField("localDest").getValue()
        } else {
            if (SYNO.SDS.LunBackup.BKPTASK_NETLUN === this.owner.taskType) {
                a.servertype = "synology";
                a.share = this.owner.PanelDestShare.getForm().findField("remoteShare").getValue();
                a = this.owner.PanelDestNet.getParamsVal(a)
            }
        }
        this.owner.setStatusBusy({
            text: _T("bkpwizard", "msg_waiting")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "check_lun",
            params: a,
            scope: this,
            callback: this.checkLUNDone
        })
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        this.saveSettings();
        if ("block" !== this.owner.lunSourceType) {
            this.checkLUN()
        } else {
            this.owner.getMsgBox().confirm(_T("tree", "leaf_backup"), _T("lunbkp", "lun_is_vaai_or_block"), function(a) {
                if ("yes" === a) {
                    this.checkLUN()
                }
            }, this)
        }
        return false
    },
    summary: function(a) {
        a.append(_T("lunbkp", "lun_source"), this.owner.lunSource);
        return
    },
    lunSourceDone: function(c, a) {
        var b = 0;
        this.owner.clearStatusBusy();
        if (c) {
            for (b = 0; b < a.total; b++) {
                this.owner.lunSourceList.push([{
                    name: a.items[b].name,
                    size: a.items[b].size,
                    type: a.items[b].type
                }, a.items[b].name])
            }
            this.owner.lunSourceStore.loadData(this.owner.lunSourceList, false);
            if ("edit" !== this.mode) {
                if (0 < this.owner.lunSourceList.length) {
                    var d = this.owner.lunSourceStore.getAt(0);
                    this.owner.blBkpLUNChanged = true;
                    this.getForm().findField("lunsource").setValue(d.get("value"));
                    this.getForm().findField("lunsource").el.dom.qtip = d.get("display");
                    this.owner.getButton("next").enable()
                } else {
                    this.owner.getButton("next").disable();
                    this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("lunbkp", "err_no_available_lun"))
                }
            } else {
                if (0 < this.owner.lunSourceList.length) {
                    for (b = 0; b < this.owner.lunSourceList.length; b++) {
                        if (this.owner.lunSource === this.owner.lunSourceList[b][0].name) {
                            this.getForm().findField("lunsource").setValue(this.owner.lunSourceList[b][0]);
                            this.owner.lunSourceSize = this.owner.lunSourceList[b][0].size
                        }
                    }
                }
            }
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("common", "error_system"))
            }
            this.owner.getButton("next").disable()
        }
    },
    lunSourceRequest: function() {
        var a = {};
        this.owner.lunSourceList.length = 0;
        a.mode = this.mode;
        if ("edit" === this.mode) {
            a.lunname = this.owner.lunSource
        } else {
            a.lunname = ""
        }
        this.owner.setStatusBusy({
            text: _T("lunbkp", "search_lun_source")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "enum_lun",
            params: a,
            scope: this,
            callback: this.lunSourceDone
        })
    }
});
Ext.define("SYNO.SDS.Backup.LUNDestTypePanel", {
    extend: "SYNO.ux.FormPanel",
    constructor: function(b) {
        if (!b.nextId || 2 !== b.nextId.length) {
            throw "invalid config"
        }
        var a = {
            padding: "24px 0 0 0",
            items: [{
                xtype: "radiogroup",
                columns: 1,
                hideLabel: true,
                itemId: "option",
                items: [{
                    xtype: "syno_radio",
                    boxLabel: _T("lunbkp", "local_lunbkp"),
                    name: "mode",
                    inputValue: 0,
                    checked: true
                }, {
                    xtype: "syno_displayfield",
                    indent: 1,
                    value: _T("lunbkp", "local_lunbkp_desc")
                }, {
                    xtype: "syno_radio",
                    boxLabel: _T("lunbkp", "net_lunbkp") + " (" + String.format(_T("netbackup", "synology_server"), _D("company_title")) + ")",
                    name: "mode",
                    inputValue: 1
                }, {
                    xtype: "syno_displayfield",
                    indent: 1,
                    value: String.format(_T("lunbkp", "net_lunbkp_desc"), _D("company_title"))
                }]
            }]
        };
        Ext.apply(a, b);
        this.callParent([a])
    },
    activate: function() {},
    SaveSettings: function() {
        this.owner.taskType = this.getBkpType()
    },
    getNext: function() {
        this.SaveSettings();
        var a = this.getForm().getValues().mode;
        return this.nextId[a]
    },
    summary: function(a) {
        return
    },
    getBkpType: function() {
        var a = this.getForm().getValues().mode;
        var b = "";
        switch (a) {
            case "0":
                b = SYNO.SDS.LunBackup.BKPTASK_LOCLUN;
                break;
            case "1":
                b = SYNO.SDS.LunBackup.BKPTASK_NETLUN;
                break;
            default:
                break
        }
        return b
    }
});
Ext.define("SYNO.SDS.Backup.LUNDestLocalPanel", {
    extend: "SYNO.ux.FormPanel",
    blLoaded: false,
    userInputDirectoryFlag: false,
    destStore: null,
    destList: [],
    constructor: function(c) {
        var a = new Ext.data.ArrayStore({
            id: "value",
            fields: ["value", "display"],
            data: this.destList
        });
        this.destStore = a;
        var b = {
            padding: "24px 0 0 0",
            items: [{
                xtype: "syno_combobox",
                fieldLabel: _T("localbkp", "localbkp_dest"),
                name: "localDest",
                store: a,
                allowBlank: false,
                displayField: "display",
                valueField: "value",
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH,
                width: SYNO.SDS.LunBackup.BKP_DEST_CONTD_WIDTH,
                listeners: {
                    scope: this,
                    select: this.defaultDirectoryUpdate
                }
            }, {
                xtype: "syno_textfield",
                fieldLabel: _T("backup", "backup_dest_directory"),
                itemId: "destDirectory",
                allowBlank: false,
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH,
                width: SYNO.SDS.LunBackup.BKP_DEST_CONTD_WIDTH,
                vtype: "sharename",
                maxlength: 32,
                listeners: {
                    scope: this,
                    change: this.userInputDirectory
                }
            }]
        };
        Ext.apply(b, c);
        this.callParent([b])
    },
    localbkpDestDone: function(d, a) {
        this.owner.clearStatusBusy();
        if (d) {
            this.allDest = a.items;
            this.destList = [];
            for (var b = 0; b < a.total; b++) {
                this.destList.push([this.allDest[b].destValue, this.allDest[b].dest])
            }
            if (null === this) {
                return
            }
            var c = this.getForm().findField("localDest");
            c.store.loadData(this.destList, false);
            if (0 < this.destList.length) {
                c.setValue(this.destList[0][0]);
                this.defaultDirectoryUpdate();
                this.owner.getButton("next").enable()
            } else {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("share", "error_noneshare"));
                this.owner.getButton("next").disable()
            }
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("common", "error_system"))
            }
            this.owner.getButton("next").disable()
        }
    },
    load: function() {
        this.destList.length = 0;
        this.owner.setStatusBusy({
            text: _T("localbkp", "localbkp_wait_dest")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "enum_local_bkp_dest",
            scope: this,
            callback: this.localbkpDestDone
        })
    },
    registerEvent: function() {
        this.getForm().findField("localDest").on("select", function(c, b, a) {
            this.owner.blDestChanged = true
        }, this)
    },
    activate: function() {
        if (!this.blLoaded) {
            this.registerEvent();
            this.load();
            this.blLoaded = true
        }
    },
    checkDirDone: function(b, a) {
        this.owner.clearStatusBusy();
        if (b) {
            this.owner.goNext(this.nextId)
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("common", "error_system"))
            }
        }
    },
    checkDir: function() {
        var a = {};
        a.bkptype = SYNO.SDS.LunBackup.BKPTASK_LOCLUN;
        a.bkpset = this.owner.taskName;
        a.share = this.getForm().findField("localDest").getValue();
        a.directory = this.getForm().findField("destDirectory").getValue();
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "check_dir",
            params: a,
            scope: this,
            callback: this.checkDirDone
        })
    },
    getNext: function() {
        if (this.owner.taskDest !== this.getForm().findField("localDest").getValue()) {
            this.owner.blDestChanged = true
        }
        if (!this.getForm().isValid()) {
            return false
        }
        this.owner.taskDest = this.getForm().findField("localDest").getValue() + "/" + this.getForm().findField("destDirectory").getValue();
        this.checkDir();
        return false
    },
    summary: function(a) {
        a.append(_T("backup", "backup_type"), _T("lunbkp", "local_lunbkp"));
        a.append(_T("localbkp", "localbkp_dest"), this.owner.taskDest);
        return
    },
    userInputDirectory: function() {
        this.userInputDirectoryFlag = true
    },
    defaultDirectoryUpdate: function() {
        if (this.userInputDirectoryFlag) {
            return
        }
        var b = this.getForm().findField("destDirectory");
        var a = this.owner;
        var c = {};
        c.bkpShare = this.getForm().findField("localDest").getValue();
        this.owner.setStatusBusy({
            text: _T("localbkp", "localbkp_wait_dest")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "get_local_dest_dir",
            params: c,
            scope: this,
            callback: function(e, d) {
                a.clearStatusBusy();
                if (e) {
                    b.setValue(d.defaultDirectory)
                } else {
                    a.getMsgBox().alert(_T("tree", "leaf_backup"), _T("common", "error_system"))
                }
            }
        })
    },
    getBkpDest: function() {
        return this.getForm().findField("localDest").getValue()
    }
});
Ext.define("SYNO.SDS.Backup.LUNDestNetPanel", {
    extend: "SYNO.ux.FormPanel",
    blSynoServerLoad: false,
    ServerStore: null,
    constructor: function(b) {
        this.ServerList = [];
        this.ServerStore = new Ext.data.SimpleStore({
            fields: ["value", "display"],
            data: this.ServerList
        });
        var a = {
            padding: "24px 0 0 0",
            items: [{
                xtype: "syno_combobox",
                fieldLabel: _T("netbackup", "netbkp_set_ip"),
                name: "server",
                allowBlank: false,
                emptyText: _T("netbackup", "netbkp_input_addr"),
                editable: true,
                store: this.ServerStore,
                displayField: "display",
                valueField: "value",
                triggerAction: "all",
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH,
                width: SYNO.SDS.LunBackup.BKP_DEST_CONTD_WIDTH,
                mode: "local",
                validator: function(c) {
                    return SYNO.SDS.LunBackup.netbkpValidator(c, b.owner.selfIPs, b.owner.selfHostName)
                },
                onTriggerClick: function() {
                    if (0 !== this.getStore().getCount()) {
                        if (this.isExpanded()) {
                            this.collapse();
                            this.el.focus()
                        } else {
                            this.onFocus({});
                            this.expand();
                            this.el.focus()
                        }
                    } else {
                        this.owner.serverListLoaded = true;
                        this.el.focus();
                        SYNO.SDS.LunBackup.onLoadSynologyServer(this, this.owner.ServerList, this.owner.owner)
                    }
                },
                owner: this
            }, {
                xtype: "syno_textfield",
                fieldLabel: _T("netbackup", "netbkp_account"),
                name: "account",
                allowBlank: false,
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH,
                width: SYNO.SDS.LunBackup.BKP_DEST_CONTD_WIDTH,
                vtype: "username_ext"
            }, {
                xtype: "syno_textfield",
                fieldLabel: _T("common", "password"),
                name: "password",
                inputType: "password",
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH,
                width: SYNO.SDS.LunBackup.BKP_DEST_CONTD_WIDTH
            }]
        };
        Ext.apply(a, b);
        this.callParent([a]);
        this.mon(this, "afterlayout", function(c, d) {
            this.getForm().findField("account").setValue("admin")
        }, this, {
            single: true
        })
    },
    activate: function() {
        this.serverListLoaded = false
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        this.onTestConnectionButton("next");
        return false
    },
    summary: function(e) {
        var d = this.getForm();
        e.append(_T("backup", "backup_type"), _T("lunbkp", "net_lunbkp"));
        e.append(_T("netbackup", "netbkp_slct_server"), String.format(_T("netbackup", "synology_server"), _D("company_title")));
        var b = d.findField("server").getRawValue();
        var a = SYNO.SDS.LunBackup.GetServerName(b);
        var c = SYNO.SDS.LunBackup.GetServerIP(b);
        var f;
        if (a !== "") {
            f = a;
            if (c !== "") {
                f += "(" + c + ")"
            }
        } else {
            f = c
        }
        e.append(_T("netbackup", "netbkp_server"), f);
        e.append(_T("netbackup", "netbkp_auth_user"), d.findField("account").getValue())
    },
    TestServerVersionDone: function(b, a) {
        this.owner.clearStatusBusy();
        if (b) {
            this.owner.goNext(this.nextId)
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), SYNO.SDS.Backup.String(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("netbackup", "netbkp_connection_testing_fail"))
            }
        }
    },
    TestConnectionWhenGoNext: function(c, a) {
        if (c) {
            var b = {};
            b.servertype = "synology";
            b.share = "share";
            b = this.getParamsVal(b);
            this.sendWebAPI({
                api: "SYNO.Backup.Lunbackup",
                version: 1,
                method: "remote_version_check",
                params: b,
                scope: this,
                callback: this.TestServerVersionDone
            })
        } else {
            this.owner.clearStatusBusy();
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("netbackup", "netbkp_connection_testing_fail"))
            }
        }
    },
    onTestConnectionButton: function(b) {
        var a = {};
        a.servertype = SYNO.SDS.LunBackup.LUNBKP_SYNO_SERVER;
        a = this.getParamsVal(a);
        if (a) {
            var c = b === "next" ? this.TestConnectionWhenGoNext : null;
            SYNO.SDS.LunBackup.onTestSvrConnection("test_connections", a, this, c)
        } else {
            this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("netbackup", "netbkp_err_host_str"))
        }
    },
    getParamsVal: function(g) {
        var e = this.getForm();
        var b = SYNO.SDS.LunBackup.GetServerName(e.findField("server").getRawValue());
        var c = SYNO.SDS.LunBackup.GetServerIP(e.findField("server").getRawValue());
        var f = e.findField("account").getValue();
        var d = e.findField("password").getValue();
        if (b === "" && c === "") {
            this.owner.getMsgBox().alert(_T("tree", "node_backup"), _T("netbackup", "netbkp_err_host_str"));
            return false
        }
        g.server = b;
        g.ip = c;
        g.account = f;
        g.password = d;
        var a = e.findField("module");
        if (a) {
            g.module = a.getRawValue()
        } else {
            g.module = ""
        }
        return g
    }
});
Ext.define("SYNO.SDS.Backup.LUNDestSharePanel", {
    extend: "SYNO.ux.FormPanel",
    initialized: false,
    owner: null,
    userInputDirectoryFlag: false,
    constructor: function(d) {
        var c;
        var b;
        var a = new Ext.data.SimpleStore({
            id: "dsRemoteShare",
            fields: ["value", "display"],
            data: d.owner.remoteShareList
        });
        d.owner.remoteShareStore = a;
        b = _T("lunbkp", "dest_shared_folder");
        c = {
            padding: "24px 0 0 0",
            items: [{
                xtype: "syno_displayfield",
                itemId: "serverInfo",
                fieldLabel: _T("netbackup", "netbkp_server"),
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH,
                width: 300
            }, {
                xtype: "syno_combobox",
                fieldLabel: b,
                name: "remoteShare",
                store: d.owner.remoteShareStore,
                allowBlank: false,
                displayField: "display",
                valueField: "value",
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH,
                width: SYNO.SDS.LunBackup.BKP_DEST_CONTD_WIDTH,
                listeners: {
                    scope: this,
                    select: this.defaultDirectoryUpdate
                }
            }, {
                xtype: "syno_textfield",
                fieldLabel: _T("backup", "backup_dest_directory"),
                itemId: "destDirectory",
                allowBlank: false,
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH,
                width: SYNO.SDS.LunBackup.BKP_DEST_CONTD_WIDTH,
                vtype: "sharename",
                maxlength: 32,
                listeners: {
                    scope: this,
                    change: this.userInputDirectory
                }
            }]
        };
        Ext.apply(c, d);
        this.callParent([c])
    },
    activate: function() {
        if (!this.initialized) {
            this.remoteShareEnum();
            this.serverNameSet()
        }
    },
    checkDirDone: function(b, a) {
        this.owner.clearStatusBusy();
        if (b) {
            this.owner.goNext(this.nextId)
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("common", "error_system"))
            }
        }
    },
    checkDir: function() {
        var b = {};
        var a = this.owner.PanelDestNet.getForm().findField("server").getRawValue();
        b.bkptype = SYNO.SDS.LunBackup.BKPTASK_NETLUN;
        b.bkpset = this.owner.taskName;
        b.share = this.getForm().findField("remoteShare").getValue();
        b.directory = this.getForm().findField("destDirectory").getValue();
        b.user = this.owner.PanelDestNet.getForm().findField("account").getRawValue();
        b.password = this.owner.PanelDestNet.getForm().findField("password").getRawValue();
        b.server = SYNO.SDS.LunBackup.GetServerName(a);
        b.ip = SYNO.SDS.LunBackup.GetServerIP(a);
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "check_dir",
            params: b,
            scope: this,
            callback: this.checkDirDone
        })
    },
    saveSetting: function() {
        this.owner.directory = this.getForm().findField("destDirectory").getValue()
    },
    getNext: function() {
        if (!this.getForm().isValid()) {
            return false
        }
        this.checkDir();
        this.saveSetting();
        return false
    },
    summary: function(a) {
        a.append(_T("lunbkp", "dest_shared_folder"), this.getForm().findField("remoteShare").getValue() + "/" + this.owner.directory)
    },
    remoteShareEnumDone: function(c, a) {
        this.owner.clearStatusBusy();
        if (c) {
            for (var b = 0; b < a.items.length; b++) {
                this.owner.remoteShareList.push([a.items[b].share, a.items[b].share])
            }
            this.owner.remoteShareStore.loadData(this.owner.remoteShareList, false);
            if (0 < this.owner.remoteShareList.length) {
                this.getForm().findField("remoteShare").setValue(this.owner.remoteShareList[0][0]);
                this.defaultDirectoryUpdate();
                this.owner.getButton("next").enable()
            } else {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("ftp", "ftp_no_share"));
                this.owner.getButton("next").disable()
            }
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("common", "error_system"))
            }
            this.owner.getButton("next").disable()
        }
    },
    remoteShareEnum: function() {
        var b;
        this.owner.remoteShareList.length = 0;
        var a = this.owner.PanelDestNet.getForm().findField("server").getRawValue();
        b = {};
        b.user = this.owner.PanelDestNet.getForm().findField("account").getRawValue();
        b.password = this.owner.PanelDestNet.getForm().findField("password").getRawValue();
        b.server = SYNO.SDS.LunBackup.GetServerName(a);
        b.ip = SYNO.SDS.LunBackup.GetServerIP(a);
        b.type = "lunbkp";
        this.owner.setStatusBusy({
            text: _T("netbackup", "netbkp_search_folder")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "enum_remote_share",
            params: b,
            scope: this,
            callback: this.remoteShareEnumDone
        })
    },
    serverNameSet: function() {
        var b = this.owner.PanelDestNet.getForm().findField("server").getRawValue();
        var c = SYNO.SDS.LunBackup.GetServerName(b);
        var a = SYNO.SDS.LunBackup.GetServerIP(b);
        var d = "";
        if (c.length) {
            d = c
        } else {
            if (a.length) {
                d = a
            }
        }
        this.getForm().findField("serverInfo").setValue(d)
    },
    userInputDirectory: function() {
        this.userInputDirectoryFlag = true
    },
    defaultDirectoryUpdate: function() {
        var d;
        var c;
        var a = this.owner.PanelDestNet.getForm().findField("server").getRawValue();
        if (this.userInputDirectoryFlag) {
            return
        }
        d = {};
        d.user = this.owner.PanelDestNet.getForm().findField("account").getRawValue();
        d.password = this.owner.PanelDestNet.getForm().findField("password").getRawValue();
        d.ssh_enable = "0";
        d.servertype = "synology";
        d.server = SYNO.SDS.LunBackup.GetServerName(a);
        d.ip = SYNO.SDS.LunBackup.GetServerIP(a);
        d.share = this.getForm().findField("remoteShare").getRawValue();
        c = this.getForm().findField("destDirectory");
        var b = this.owner;
        b.setStatusBusy({
            text: _T("netbackup", "netbkp_wait_server")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "get_remote_dest_dir",
            params: d,
            scope: this,
            callback: function(f, e) {
                b.clearStatusBusy();
                if (f) {
                    c.setValue(e.defaultDirectory)
                } else {
                    b.getMsgBox().alert(_T("tree", "leaf_backup"), _T("common", "error_system"))
                }
            }
        })
    }
});
Ext.define("SYNO.SDS.Backup.SchedulePanel", {
    extend: "SYNO.ux.FormPanel",
    isLoaded: false,
    advanceScheduleDialog: null,
    weekArray: null,
    oldAdvanceSchedule: null,
    constructor: function(b) {
        var e = false;
        var d = Ext.getCmp("btnTaskRestore");
        if ("edit" === b.mode || (d && d.disabled)) {
            e = true
        }
        this.weekArray = SYNO.SDS.Backup.Client.Common.Utils.WeekArray;
        var c = new Ext.data.SimpleStore({
            fields: ["value", "display"],
            data: this.weekArray
        });
        var a = {
            title: Ext.util.Format.ellipsis(_T("common", "schedule"), 15),
            tabTip: _T("common", "schedule"),
            padding: b.padding,
            items: [{
                xtype: "syno_checkbox",
                boxLabel: _T("netbackup", "netbkp_set_schedule"),
                name: "schedule_enable"
            }, {
                xtype: "syno_radio",
                name: "schedule_type",
                inputValue: "basic",
                boxLabel: _T("schedule", "schedule_basic"),
                checked: true,
                indent: 1
            }, {
                xtype: "syno_compositefield",
                hideLabel: true,
                fieldLabel: "composite field",
                name: "basic_time",
                indent: 2,
                items: [{
                    xtype: "syno_displayfield",
                    value: _T("time", "time_day")
                }, {
                    xtype: "syno_combobox",
                    name: "basic_weekday",
                    store: c,
                    displayField: "display",
                    valueField: "value",
                    width: 90
                }, {
                    border: false,
                    width: 50
                }, {
                    xtype: "syno_displayfield",
                    value: _T("time", "time_hour")
                }, {
                    xtype: "syno_combobox",
                    name: "hour",
                    displayField: "display",
                    valueField: "value",
                    store: SYNO.SDS.Backup.createTimeItemStore("hour"),
                    width: 70
                }, {
                    border: false,
                    width: 10
                }, {
                    xtype: "syno_displayfield",
                    value: _T("time", "time_minute")
                }, {
                    xtype: "syno_combobox",
                    name: "minute",
                    displayField: "display",
                    valueField: "value",
                    store: SYNO.SDS.Backup.createTimeItemStore("min"),
                    width: 70
                }]
            }, {
                xtype: "syno_radio",
                name: "schedule_type",
                inputValue: "advance",
                boxLabel: _T("schedule", "schedule_advance"),
                checked: false,
                indent: 1
            }, {
                xtype: "syno_button",
                id: "btn_schedule",
                name: "btn_schedule",
                text: _T("schedule", "schedule_title"),
                handler: this.launchScheduleDialog,
                scope: this,
                indent: 2
            }, {
                xtype: "syno_displayfield",
                name: "txtadvscheduletime",
                labelSeparator: "",
                value: "",
                height: "12px",
                style: "margin-left: 80px"
            }, {
                xtype: "syno_displayfield",
                name: "txtadvscheduleday",
                labelSeparator: "",
                value: "",
                height: "12px",
                style: "margin-left: 80px"
            }, {
                xtype: "syno_checkbox",
                name: "bkpnow",
                hidden: e,
                boxLabel: _T("localbkpwizard", "wizard_start_backup")
            }]
        };
        Ext.apply(a, b);
        this.callParent([a]);
        this.mon(this, "afterlayout", function(f, g) {
            var h;
            h = new SYNO.ux.Utils.EnableCheckGroup(f.getForm(), "schedule_enable", ["schedule_type", "basic_weekday", "hour", "minute", "btn_schedule"]);
            h = new SYNO.ux.Utils.EnableRadioGroup(f.getForm(), "schedule_type", {
                basic: ["basic_weekday", "hour", "minute"],
                advance: ["btn_schedule"]
            });
            this.getForm().findField("schedule_type").on("check", function(i, j) {
                if ("basic" === i.getGroupValue()) {
                    this.getForm().findField("txtadvscheduletime").setValue("");
                    this.getForm().findField("txtadvscheduleday").setValue("")
                } else {
                    delete this.owner.schedule
                }
            }, this)
        }, this, {
            single: true
        })
    },
    advSchedulePrint: function(b) {
        var a = this.getForm().findField("txtadvscheduletime");
        var c = this.getForm().findField("txtadvscheduleday");
        a.setValue(this.timeScheduleToString(b));
        c.setValue(this.dateScheduleToString(b))
    },
    setOldAdvanceSchedule: function(a) {
        this.oldAdvanceSchedule = a
    },
    afterScheduleDialog: function() {
        if (this.owner.schedule) {
            this.owner.schedule = this.deConstructJson(this.owner.schedule);
            this.oldAdvanceSchedule = this.owner.schedule;
            this.advSchedulePrint(this.owner.schedule)
        }
    },
    launchScheduleDialogDone: function(b, a) {
        this.advanceScheduleDialog = new SYNO.SDS.TaskScheduler2.ScheduleDialog({
            title: _T("schedule", "schedule_advance"),
            height: 472,
            owner: this.owner
        });
        this.advanceScheduleDialog.mon(this.advanceScheduleDialog, "hide", this.afterScheduleDialog, this);
        this.owner.clearStatusBusy();
        if (b) {
            this.advanceScheduleDialog.onOpen(this.reConstructJson(a.task.schedule))
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("common", "error_system"))
            }
        }
    },
    launchScheduleDialog: function() {
        var a;
        if (this.oldAdvanceSchedule) {
            a = new SYNO.SDS.TaskScheduler2.ScheduleDialog({
                title: _T("schedule", "schedule_advance"),
                height: 472,
                owner: this.owner
            });
            a.mon(a, "hide", this.afterScheduleDialog, this);
            a.open(this.reConstructJson(this.oldAdvanceSchedule))
        } else {
            this.owner.setStatusBusy();
            this.sendWebAPI({
                api: "SYNO.Backup.Lunbackup",
                version: 1,
                method: "load_default_adv_schedule",
                scope: this,
                callback: this.launchScheduleDialogDone
            })
        }
    },
    loadForm: function(b) {
        if (b) {
            this.getForm().loadRecord(b);
            if (false === b.data.schedule_enable) {
                var a = Ext.getCmp("btn_schedule");
                a.disable();
                this.getForm().findField("basic_weekday").disable();
                this.getForm().findField("hour").disable();
                this.getForm().findField("minute").disable()
            } else {
                if ("advance" === b.data.schedule_type && this.oldAdvanceSchedule) {
                    this.advSchedulePrint(this.oldAdvanceSchedule)
                }
            }
        }
    },
    activate: function() {
        if (false === this.isLoaded) {
            var a = {};
            var b = {};
            a.schedule_enable = false;
            a.schedule_type = "basic";
            a.basic_weekday = "1";
            a.hour = 0;
            a.minute = 0;
            b.data = a;
            this.loadForm(b);
            this.getForm().findField("basic_weekday").disable();
            this.getForm().findField("hour").disable();
            this.getForm().findField("minute").disable();
            this.isLoaded = true
        }
    },
    getNext: function() {
        var b;
        var a;
        a = this.getForm().findField("schedule_type").getGroupValue() === "basic" ? true : false;
        if (a) {
            b = this.getScheduleData();
            this.owner.schedule = b.schedule;
            this.owner.enableschedule = b.enableschedule
        } else {
            this.owner.enableschedule = this.getForm().findField("schedule_enable").getValue();
            if (this.owner.enableschedule && !this.owner.schedule) {
                this.owner.getMsgBox().alert(_T("netbackup", "netbkp_no_schedule"), _T("netbackup", "netbkp_no_schedule"));
                return false
            }
        }
        return this.nextId
    },
    summary: function(a) {
        var b;
        var c = this.owner.schedule;
        if (!this.getForm().findField("schedule_enable").getValue()) {
            a.append(_T("netbackup", "netbkp_schedule"), _T("netbackup", "netbkp_no_schedule"))
        } else {
            b = this.timeScheduleToString(c) + " " + this.dateScheduleToString(c);
            a.append(_T("netbackup", "netbkp_schedule"), b)
        }
    },
    getScheduleData: function() {
        var f = [];
        var d;
        var e = this.getForm();
        var c;
        f.enableschedule = e.findField("schedule_enable").getValue();
        c = e.findField("schedule_type").getGroupValue() === "basic" ? true : false;
        if (c) {
            var b = e.findField("basic_weekday").getValue();
            var a = e.findField("hour").getValue();
            var g = e.findField("minute").getValue();
            d = {};
            d.date_type = 0;
            d.repeat = 0;
            d.hour = a;
            d.min = g;
            d.repeat_hour = 0;
            d.last_work_hour = a;
            d.week_name = String(b)
        } else {
            if (this.oldAdvanceSchedule) {
                d = this.deConstructJson(this.oldAdvanceSchedule)
            } else {
                d = {};
                d.date_type = 0;
                d.repeat = 0;
                d.hour = 0;
                d.min = 0;
                d.repeat_hour = 0;
                d.last_work_hour = 0;
                d.week_name = "0,1,2,3,4,5,6"
            }
        }
        f.schedule = d;
        return f
    },
    reConstructJson: function(b) {
        var a = b;
        if (a.minute === undefined) {
            a.minute = a.min
        }
        if (a.week_day === undefined) {
            a.week_day = a.week_name
        }
        if (a.repeat_date === undefined) {
            a.repeat_date = a.repeat
        }
        return a
    },
    deConstructJson: function(b) {
        var a = b;
        if (a.min === undefined) {
            a.min = a.minute
        }
        if (a.week_name === undefined) {
            a.week_name = a.week_day
        }
        if (a.repeat === undefined) {
            a.repeat = a.repeat_date
        }
        return a
    },
    dateScheduleToString: function(a) {
        return SYNO.SDS.Backup.Client.Common.Utils.DateScheduleToString(a)
    },
    timeScheduleToString: function(a) {
        return SYNO.SDS.Backup.Client.Common.Utils.TimeScheduleToString(a)
    }
});
Ext.define("SYNO.SDS.Backup.LUNBackupWizard", {
    extend: "SYNO.SDS.Wizard.ModalWindow",
    rcvr_step: null,
    selfIPs: null,
    selfHostName: null,
    PanelWelcome: null,
    PanelTaskName: null,
    PanelDestType: null,
    PanelDestLocal: null,
    PanelDestNet: null,
    PanelDestShare: null,
    PanelLUNSource: null,
    PanelSchedule: null,
    PanelSummary: null,
    taskName: null,
    taskType: null,
    taskDest: null,
    schedule: null,
    bkpNow: false,
    remoteShareStore: null,
    remoteShare: null,
    lunSourceStore: null,
    lunSource: null,
    lunSourceSize: null,
    bkpDir: null,
    blDestChanged: true,
    blBkpLUNChanged: false,
    excuteConfirm: 1,
    constructor: function(b) {
        var c = SYNO.SDS.Backup;
        this.remoteShareList = [];
        this.lunSourceList = [];
        this.PanelWelcome = new SYNO.SDS.Wizard.WelcomeStep({
            headline: _T("lunbkp", "backup_welcome_title"),
            description: _T("backup", "welcome").replaceAll("<li>", '<li class="syno-lun-bkp-welcome"><span>').replaceAll("</li>", "</span></li>").replaceAll("<ul>", '<ul class="syno-lun-bkp-welcome">'),
            itemId: "welcome",
            nextId: "taskname",
            owner: this
        });
        this.PanelTaskName = new c.TaskNamePanel({
            headline: _T("localbkpwizard", "backup_set_title"),
            description: _T("localbkpwizard", "backup_set_desc"),
            itemId: "taskname",
            nextId: "desttype",
            header: false,
            owner: this
        });
        this.PanelDestType = new c.LUNDestTypePanel({
            headline: _T("backup", "wizard_desttype_title"),
            description: _T("backup", "bkpwizard_type_title"),
            itemId: "desttype",
            nextId: ["destlocal", "destnet"],
            header: false,
            mode: "wizard",
            owner: this
        });
        this.PanelDestLocal = new c.LUNDestLocalPanel({
            headline: _T("localbkpwizard", "select_dest_title"),
            description: _T("localbkpwizard", "select_dest_desc"),
            itemId: "destlocal",
            nextId: "lunsource",
            header: false,
            mode: "wizard",
            owner: this
        });
        this.PanelDestNet = new c.LUNDestNetPanel({
            headline: _T("netbackup", "netbkp_serverset_title"),
            description: _T("netbackup", "netbkp_serverset1_desc"),
            itemId: "destnet",
            nextId: "destshare",
            header: false,
            mode: "wizard",
            owner: this
        });
        this.PanelDestShare = new c.LUNDestSharePanel({
            headline: _T("netbackup", "dest_share_title"),
            description: _T("netbackup", "dest_share_desc"),
            itemId: "destshare",
            nextId: "lunsource",
            header: false,
            mode: "wizard",
            owner: this
        });
        this.PanelLUNSource = new c.LUNSourcePanel({
            headline: _T("lunbkp", "select_lun_title"),
            description: _T("lunbkp", "select_lun_desc"),
            itemId: "lunsource",
            nextId: "schedule",
            header: false,
            owner: this,
            mode: "wizard"
        });
        this.PanelSchedule = new c.SchedulePanel({
            headline: _T("usbbackup", "usbbkp_schedule_desc1"),
            description: _T("backup", "bkpwizard_sche_title"),
            itemId: "schedule",
            nextId: "summary",
            padding: "24px 0 0 0",
            header: false,
            mode: "wizard",
            owner: this
        });
        this.PanelSummary = new SYNO.SDS.Wizard.SummaryStep({
            autoScroll: true,
            headline: _T("localbkpwizard", "summary_title"),
            description: _T("wizcommon", "summary_descr"),
            itemId: "summary",
            nextId: null,
            getNext: function() {
                this.owner.applySetting();
                return false
            },
            owner: this
        });
        var a = [this.PanelWelcome, this.PanelTaskName, this.PanelDestType, this.PanelDestLocal, this.PanelDestNet, this.PanelDestShare, this.PanelLUNSource, this.PanelSchedule, this.PanelSummary];
        b = Ext.apply({
            title: _T("lunbkp", "bkpwizard_title"),
            width: 600,
            height: 490,
            steps: a
        }, b);
        this.callParent([b]);
        this.setActiveStep("welcome");
        SYNO.SDS.LunBackup.getLocalIPs(this, function(e, d) {
            if (e) {
                this.selfIPs = d.selfIPs;
                this.selfHostName = d.selfHostName
            }
        })
    },
    genApplyParams: function() {
        var a = {};
        a.mode = "create";
        a.oldbkpset = "";
        a.newbkpset = this.taskName;
        a.bkptype = this.taskType;
        a.lunsource = this.lunSource;
        a.lunsize = this.lunSourceSize;
        a.scheduleEnable = this.enableschedule;
        a.schedule = this.schedule;
        a.bkpnow = this.PanelSchedule.getForm().findField("bkpnow").getValue();
        if (SYNO.SDS.LunBackup.BKPTASK_LOCLUN === this.taskType) {
            a.dest = this.taskDest;
            a.desttype = SYNO.SDS.LunBackup.BKP_DEST_TYPE_LOCLUN
        } else {
            a.servertype = SYNO.SDS.Backup.BKP_DEST_TYPE_SYNO;
            a = this.PanelDestNet.getParamsVal(a, "create");
            a.dest = this.PanelDestShare.getForm().findField("remoteShare").getValue() + "/" + this.directory;
            this.PanelDestNet.getParamsVal(a)
        }
        return a
    },
    sendRequest: function() {
        var a = this.genApplyParams();
        this.setStatusBusy({
            text: _T("common", "saving")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            method: "apply_lun",
            version: 1,
            params: a,
            scope: this,
            callback: function(c, b) {
                this.clearStatusBusy();
                if (c) {
                    this.owner.onLunTaskCreated(this.taskName, function() {
                        this.close()
                    }, this)
                } else {
                    if (null !== b && null !== b.err_type && "dir_in_used" === b.err_type) {
                        this.getMsgBox().alert(_T("tree", "leaf_backup"), _T("backup", "backup_dest_directory_not_available"))
                    } else {
                        if (b && b.errors && b.errors.sec && b.errors.key && "" !== b.errors.sec && "" !== b.errors.key) {
                            this.getMsgBox().alert(_T("tree", "leaf_backup"), _T(b.errors.sec, b.errors.key))
                        } else {
                            this.getMsgBox().alert(_T("tree", "leaf_backup"), _T("common", "commfail"))
                        }
                    }
                }
            }
        })
    },
    applySetting: function() {
        this.sendRequest()
    }
});
Ext.define("SYNO.SDS.Backup.LUNDestEditPanel", {
    extend: "SYNO.ux.FormPanel",
    destStore: null,
    selfIPs: null,
    selfHostName: null,
    btnTestId: null,
    ServerStore: null,
    RemoteStore: null,
    RsyncModuleStore: null,
    RegionStore: null,
    BucketStore: null,
    BucketKeyed: false,
    constructor: function(b) {
        this.ServerList = [];
        this.destList = [];
        this.RegionList = [];
        this.BucketList = [];
        SYNO.SDS.LunBackup.getLocalIPs(this, function(d, c) {
            if (d) {
                this.selfIPs = c.selfIPs;
                this.selfHostName = c.selfHostName
            }
        });
        var a = this.initLayout(b);
        Ext.apply(a, b);
        this.callParent([a])
    },
    initLayout: function(b) {
        var a;
        if (SYNO.SDS.LunBackup.BKPTASK_LOCLUN === b.type) {
            a = this.initDestLocal()
        } else {
            if (SYNO.SDS.LunBackup.BKPTASK_NETLUN === b.type) {
                a = this.initDestNet(b)
            } else {
                SYNO.Debug("Invalid type")
            }
        }
        return a
    },
    onLoadLocalDest: function() {
        this.destList.length = 0;
        this.owner.setStatusBusy({
            text: _T("localbkp", "localbkp_wait_dest")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "enum_local_bkp_dest",
            scope: this,
            callback: function(c, a) {
                this.owner.clearStatusBusy();
                if (c) {
                    for (var b = 0; b < a.total; b++) {
                        this.destList.push([a.items[b].destValue, a.items[b].dest])
                    }
                    this.destStore.loadData(this.destList, false)
                }
            }
        })
    },
    TestServerVersionDone: function(b, a) {
        this.owner.clearStatusBusy();
        if (b) {
            this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("netbackup", "netbkp_connection_testing_success"))
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), SYNO.SDS.Backup.String(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("netbackup", "netbkp_connection_testing_fail"))
            }
        }
    },
    TestServerVersion: function(c, a) {
        if (c) {
            var b = {};
            b.servertype = "synology";
            b.share = "share";
            b.mode = "edit";
            b = this.getTestconParams(b, true);
            b.ip = a.ip;
            this.sendWebAPI({
                api: "SYNO.Backup.Lunbackup",
                version: 1,
                method: "remote_version_check",
                params: b,
                scope: this,
                callback: this.TestServerVersionDone
            })
        } else {
            this.owner.clearStatusBusy();
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("netbackup", "netbkp_connection_testing_fail"))
            }
        }
    },
    onTestConnectionButton: function() {
        var a = {};
        a = this.getTestconParams(a, true);
        if (a) {
            SYNO.SDS.LunBackup.onTestSvrConnection("test_connections", a, this, this.TestServerVersion)
        } else {
            this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("netbackup", "netbkp_err_host_str"))
        }
    },
    getTestconParams: function(d, a) {
        var b = this.getForm();
        var c;
        var e;
        if (!b.findField("comboServer").isValid()) {
            return
        } else {
            e = b.findField("comboServer");
            c = e.getRawValue();
            d.account = b.findField("textAccount").getValue();
            if (a) {
                d.module = b.findField("remoteShare").getValue()
            } else {
                d.module = ""
            }
        }
        d.servertype = SYNO.SDS.LunBackup.LUNBKP_SYNO_SERVER;
        d.server = SYNO.SDS.LunBackup.GetServerName(e.getRawValue());
        d.ip = SYNO.SDS.LunBackup.GetServerIP(e.getRawValue());
        if (d.server === "" && d.ip === "") {
            this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("netbackup", "netbkp_err_host_str"));
            return
        }
        d.password = b.findField("password").getValue();
        d.ssh_enable = false;
        d.bkpset = this.owner.taskNameOrig;
        return d
    },
    remoteShareEnumDone: function(c, a) {
        this.owner.clearStatusBusy();
        if (c) {
            for (var b = 0; b < a.items.length; b++) {
                this.RemoteList.push([a.items[b].share, a.items[b].share])
            }
            this.RemoteStore.loadData(this.RemoteList, false);
            if ((0 < this.RemoteList.length)) {
                if ("" === this.getForm().findField("remoteShare").getValue()) {
                    this.getForm().findField("remoteShare").setValue(this.RemoteList[0][0])
                }
            } else {
                this.owner.getMsgBox().alert(_T("share", "share_remote_volume"), _T("common", "error_system"))
            }
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("share", "share_remote_volume"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("share", "share_remote_volume"), _T("common", "error_system"))
            }
        }
    },
    remoteShareEnum: function(a, b) {
        this.RemoteList.length = 0;
        this.owner.setStatusBusy({
            text: _T("netbackup", "netbkp_search_folder")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: a,
            params: b,
            scope: this,
            callback: this.remoteShareEnumDone
        })
    },
    initDestLocal: function() {
        var b;
        var a;
        a = new Ext.data.ArrayStore({
            id: "value",
            fields: ["value", "display"],
            data: this.destList
        });
        this.destStore = a;
        b = {
            title: Ext.util.Format.ellipsis(_T("localbkp", "localbkp_detail_info"), 15),
            tabTip: _T("localbkp", "localbkp_detail_info"),
            items: [{
                xtype: "syno_textfield",
                fieldLabel: _T("localbkp", "localbkp_bkpset_name"),
                name: "bkpset",
                maxlength: SYNO.SDS.LunBackup.BKPSET_MAX_LEN,
                vtype: "taskname",
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH,
                width: SYNO.SDS.LunBackup.BKP_DEST_CONTD_WIDTH,
                allowBlank: false
            }, {
                xtype: "syno_displayfield",
                hideLabel: false,
                fieldLabel: _T("backup", "backup_type"),
                hiddenName: "bkptype_localbkp",
                name: "bkptype_localbkp",
                value: _T("lunbkp", "local_lunbkp"),
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH
            }, {
                xtype: "syno_displayfield",
                hideLabel: false,
                fieldLabel: _T("backup", "backup_restore_source"),
                name: "lunSource",
                value: "",
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH
            }, {
                xtype: "syno_combobox",
                fieldLabel: _T("localbkp", "localbkp_dest"),
                hiddenName: "localDest",
                name: "localDest",
                editable: false,
                store: a,
                forceSelection: true,
                allowBlank: false,
                displayField: "display",
                valueField: "value",
                typeAhead: true,
                triggerAction: "all",
                lazyRender: true,
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH,
                width: SYNO.SDS.LunBackup.BKP_DEST_CONTD_WIDTH
            }, {
                xtype: "syno_textfield",
                fieldLabel: _T("backup", "backup_dest_directory"),
                name: "destDirectory",
                maxlength: 32,
                allowBlank: false,
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH,
                width: SYNO.SDS.LunBackup.BKP_DEST_CONTD_WIDTH,
                vtype: "sharename"
            }]
        };
        return b
    },
    initDestNet: function(b) {
        var a;
        this.ServerStore = new Ext.data.SimpleStore({
            fields: ["value", "display"],
            data: this.ServerList
        });
        this.RemoteList = [];
        this.RemoteStore = new Ext.data.SimpleStore({
            id: "dsRemoteShare",
            fields: ["value", "display"],
            data: this.RemoteList
        });
        this.RsyncModuleStore = new Ext.data.SimpleStore({
            fields: ["module"],
            data: []
        });
        a = {
            title: Ext.util.Format.ellipsis(_T("localbkp", "localbkp_detail_info"), 15),
            tabTip: _T("localbkp", "localbkp_detail_info"),
            items: [{
                xtype: "syno_textfield",
                fieldLabel: _T("localbkp", "localbkp_bkpset_name"),
                name: "bkpset",
                maxlength: SYNO.SDS.LunBackup.BKPSET_MAX_LEN,
                vtype: "taskname",
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH,
                width: SYNO.SDS.LunBackup.BKP_DEST_CONTD_WIDTH,
                allowBlank: false
            }, {
                xtype: "syno_displayfield",
                hideLabel: false,
                fieldLabel: _T("backup", "backup_type"),
                hiddenName: "bkptype_localbkp",
                name: "bkptype_localbkp",
                value: _T("lunbkp", "net_lunbkp"),
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH
            }, {
                xtype: "syno_combobox",
                fieldLabel: _T("netbackup", "netbkp_set_ip"),
                hiddenName: "comboServer",
                name: "comboServer",
                forceSelection: false,
                allowBlank: false,
                emptyText: _T("netbackup", "netbkp_input_addr"),
                editable: true,
                store: this.ServerStore,
                displayField: "display",
                valueField: "value",
                triggerAction: "all",
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH,
                width: SYNO.SDS.LunBackup.BKP_DEST_CONTD_WIDTH,
                validateOnBlur: true,
                validationEvent: "blur",
                mode: "local",
                validator: function(c) {
                    return SYNO.SDS.LunBackup.netbkpValidator(c, this.ownerCt.selfIPs, this.ownerCt.selfHostName)
                },
                onTriggerClick: function() {
                    if (0 !== this.getStore().getCount()) {
                        if (this.isExpanded()) {
                            this.collapse();
                            this.el.focus()
                        } else {
                            this.onFocus({});
                            this.expand();
                            this.el.focus()
                        }
                    } else {
                        this.scope.serverListLoaded = true;
                        this.el.focus();
                        SYNO.SDS.LunBackup.onLoadSynologyServer(this, this.scope.ServerList, this.scope.owner)
                    }
                },
                listeners: {
                    change: function() {
                        this.scope.getForm().findField("remoteShare").setValue("")
                    }
                },
                scope: this
            }, {
                xtype: "syno_textfield",
                fieldLabel: _T("netbackup", "netbkp_account"),
                name: "textAccount",
                emptyText: _T("netbackup", "netbkp_input"),
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH,
                width: SYNO.SDS.LunBackup.BKP_DEST_CONTD_WIDTH,
                validateOnBlur: true,
                validationEvent: "blur",
                allowBlank: false,
                vtype: "username_ext",
                scope: this,
                listeners: {
                    change: function() {
                        this.scope.owner.blUserChanged = true
                    }
                }
            }, {
                xtype: "syno_textfield",
                fieldLabel: _T("common", "password"),
                name: "password",
                inputType: "password",
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH,
                width: SYNO.SDS.LunBackup.BKP_DEST_CONTD_WIDTH,
                scope: this,
                listeners: {
                    change: function() {
                        this.scope.owner.blUserChanged = true
                    }
                }
            }, {
                xtype: "syno_displayfield",
                hideLabel: false,
                fieldLabel: _T("backup", "backup_restore_source"),
                name: "lunSource",
                value: "",
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH
            }, {
                xtype: "syno_combobox",
                fieldLabel: _T("netbackup", "dest_share_folder"),
                name: "remoteShare",
                store: this.RemoteStore,
                allowBlank: false,
                displayField: "display",
                valueField: "value",
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH,
                width: SYNO.SDS.LunBackup.BKP_DEST_CONTD_WIDTH,
                triggerAction: "all",
                onTriggerClick: function() {
                    var c = function(i, f) {
                        this.owner.clearStatusBusy();
                        if (i) {
                            var h = {};
                            var e = this.getForm().findField("comboServer").getValue();
                            h.task = this.owner.taskNameOrig;
                            h.user = this.getForm().findField("textAccount").getValue();
                            h.password = this.getForm().findField("password").getValue();
                            h.server = SYNO.SDS.LunBackup.GetServerName(e);
                            h.ip = SYNO.SDS.LunBackup.GetServerIP(e);
                            h.type = "lunbkp";
                            var g = this.getForm().findField("remoteShare");
                            if (g.isExpanded()) {
                                g.collapse();
                                g.el.focus()
                            } else {
                                g.onFocus({});
                                g.expand();
                                g.el.focus()
                            }
                            this.remoteShareEnum("enum_remote_share", h)
                        } else {
                            if (f && f.errors && f.errors.sec && f.errors.key && "" !== f.errors.sec && "" !== f.errors.key) {
                                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T(f.errors.sec, f.errors.key))
                            } else {
                                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("netbackup", "netbkp_connection_testing_fail"))
                            }
                        }
                    };
                    var d = {};
                    d = this.scope.getTestconParams(d, false);
                    if (d) {
                        SYNO.SDS.LunBackup.onTestSvrConnection("test_connections", d, this.scope, c)
                    } else {
                        this.scope.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("netbackup", "netbkp_err_host_str"))
                    }
                },
                scope: this
            }, {
                xtype: "syno_textfield",
                fieldLabel: _T("backup", "backup_dest_directory"),
                itemId: "destDirectory",
                maxlength: 32,
                allowBlank: false,
                labelWidth: SYNO.SDS.LunBackup.BKP_DEST_LABEL_WIDTH,
                width: SYNO.SDS.LunBackup.BKP_DEST_CONTD_WIDTH,
                vtype: "sharename"
            }, {
                xtype: "syno_button",
                id: this.btnTestId = Ext.id(),
                labelSeparator: "",
                name: "testconbtn",
                hiddenName: "testconbtn",
                text: _T("netbackup", "netbkp_test_connection"),
                handler: this.onTestConnectionButton,
                scope: this
            }]
        };
        return a
    },
    switchNetLayout: function(a) {
        var b = this.getForm();
        SYNO.SDS.Utils.DisplayField(b, "comboServer", true);
        SYNO.SDS.Utils.DisplayField(b, "remoteShare", true)
    }
});
Ext.define("SYNO.SDS.Backup.LUNEditDialog", {
    extend: "SYNO.SDS.ModalWindow",
    dsShare: null,
    blSrcChanged: false,
    blDestChanged: false,
    blTaskChanged: false,
    blUserChanged: false,
    taskNameOrig: null,
    serverOrg: null,
    IPOrg: null,
    taskDestOrg: null,
    destDirectoryOrg: null,
    taskName: null,
    taskType: null,
    taskDest: null,
    taskDestType: null,
    taskShareStr: null,
    destDirectory: null,
    lunSource: null,
    blScheduleLoad: false,
    blBkpLUNChanged: false,
    PanelDest: null,
    PanelSchedule: null,
    schedule: null,
    oldSchedule: null,
    oldScheduleType: null,
    oldScheduleEnable: null,
    constructor: function(c) {
        var d = SYNO.SDS.Backup;
        this.shareList = [];
        this.PanelDest = new d.LUNDestEditPanel({
            owner: this,
            mode: "edit",
            type: c.type
        });
        this.PanelSchedule = new d.SchedulePanel({
            owner: this,
            padding: "8px 8px 0 8px",
            mode: "edit"
        });
        var b = new SYNO.ux.TabPanel({
            activeTab: 0,
            plain: true,
            items: [this.PanelDest, this.PanelSchedule]
        });
        var a = {
            width: 600,
            height: 480,
            minWidth: 300,
            minHeight: 250,
            layout: "fit",
            closable: true,
            items: [b],
            buttons: [{
                text: _T("common", "cancel"),
                itemId: "cancel",
                handler: this.onCancel,
                scope: this
            }, {
                text: _T("common", "apply"),
                btnStyle: "blue",
                itemId: "apply",
                handler: this.onOk,
                scope: this
            }]
        };
        Ext.apply(a, c);
        this.callParent([a]);
        this.PanelSchedule.on("activate", function() {
            this.activateSchedulePanel()
        }, this)
    },
    activateSchedulePanel: function() {
        var a = {};
        var b = {};
        this.blScheduleLoad = true;
        if ("basic" === this.oldScheduleType) {
            a.basic_weekday = this.oldSchedule.week_name;
            a.hour = this.oldSchedule.hour;
            a.minute = this.oldSchedule.min
        } else {
            if ("advance" === this.oldScheduleType) {
                this.PanelSchedule.setOldAdvanceSchedule(this.oldSchedule);
                a.basic_weekday = "1";
                a.hour = 0;
                a.minute = 0
            } else {
                a.basic_weekday = "1";
                a.hour = 0;
                a.minute = 0
            }
        }
        a.schedule_enable = this.oldScheduleEnable;
        a.schedule_type = this.oldScheduleType;
        b.data = a;
        this.PanelSchedule.loadForm(b)
    },
    initDestPanel: function() {
        if (SYNO.SDS.LunBackup.BKPTASK_LOCLUN === this.taskType) {
            var b = this.PanelDest.getForm();
            this.taskDestOrg = this.taskDest;
            this.destDirectoryOrg = this.destDirectory;
            var a = {};
            a = {
                bkpset: this.taskName,
                localDest: this.taskDest,
                destDirectory: this.destDirectory,
                lunSource: this.lunSource
            };
            b.setValues(a);
            this.taskDestOrg = this.taskDest;
            this.destDirectoryOrg = this.destDirectory;
            this.PanelDest.onLoadLocalDest()
        } else {
            if (SYNO.SDS.LunBackup.BKPTASK_NETLUN === this.type) {
                this.PanelDest.switchNetLayout(this.type);
                var c = {};
                c.taskname = this.taskName;
                this.setStatusBusy();
                this.sendWebAPI({
                    api: "SYNO.Backup.Lunbackup",
                    version: 1,
                    method: "load_lun_bkp_conf",
                    params: c,
                    scope: this,
                    callback: function(h, e) {
                        this.clearStatusBusy();
                        if (h) {
                            this.selfIPs = e.selfIPs;
                            this.selfHostName = e.selfHostName;
                            var g = {};
                            var f = [];
                            var d = "";
                            d = e.items[0].dest;
                            f = d.split("/");
                            g = {
                                bkpset: this.taskName,
                                comboServer: e.items[0].ip,
                                textAccount: e.items[0].user,
                                remoteShare: f[0],
                                password: SYNO.SDS.LunBackup.getFakePass(),
                                destDirectory: f[1],
                                lunSource: this.lunSource
                            };
                            this.PanelDest.getForm().setValues(g);
                            this.serverOrg = SYNO.SDS.LunBackup.GetServerName(e.items[0].ip);
                            this.IPOrg = SYNO.SDS.LunBackup.GetServerIP(e.items[0].ip);
                            this.taskDestOrg = f[0];
                            this.destDirectoryOrg = f[1]
                        }
                    }
                })
            } else {
                return false
            }
        }
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "load_schedule",
            params: {
                bkpset: this.taskName,
                bkptype: this.taskType
            },
            scope: this,
            callback: function(e, d) {
                this.clearStatusBusy();
                if (e) {
                    this.oldScheduleEnable = d.schedule_enable;
                    this.oldScheduleType = d.schedule_type;
                    if ("basic" === d.schedule_type || "advance" === d.schedule_type) {
                        this.oldSchedule = d.task.schedule;
                        if (1 === this.oldSchedule.date_type) {
                            this.oldSchedule.date = this.oldSchedule.date
                        }
                    } else {
                        return
                    }
                } else {
                    this.getMsgBox().alert(_T("tree", "leaf_backup"), _T("common", "error_system"))
                }
            }
        })
    },
    load: function(a) {
        this.taskNameOrig = a.name;
        this.taskName = a.name;
        this.taskType = a.type;
        this.lunSource = a.bkpdata;
        if (SYNO.SDS.LunBackup.BKPTASK_LOCLUN === this.taskType) {
            this.taskDest = a.dest;
            this.destDirectory = a.destDirectory
        }
        this.setTitle(this.taskName);
        this.initDestPanel()
    },
    RequestDone: function(b, a) {
        this.clearStatusBusy();
        if (b) {
            if (a && a.newbkpset !== a.oldbkpset) {
                this.owner.onLunTaskRenamed(a.newbkpset, function() {
                    this.close()
                }, this)
            } else {
                this.close()
            }
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.getMsgBox().alert(_T("tree", "leaf_backup"), _T(a.errors.sec, a.errors.key))
            } else {
                this.getMsgBox().alert(_T("tree", "leaf_backup"), _T("common", "commfail"))
            }
        }
    },
    SendRequest: function(a, b) {
        this.setStatusBusy(_T("common", "saving"));
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: a,
            params: b,
            scope: this,
            callback: this.RequestDone
        })
    },
    CheckSetting: function() {
        var b = this.PanelDest.getForm();
        var a = this.PanelSchedule.getForm();
        if (!b.isValid()) {
            return
        }
        if (a.findField("schedule_enable").getValue()) {
            if (a.findField("schedule_type").getGroupValue() === "basic" && ("" === a.findField("basic_weekday").getValue() || "" === a.findField("hour").getValue() || "" === a.findField("minute").getValue())) {
                this.getMsgBox().alert(_T("tree", "leaf_backup"), _T("schedule", "schedule_warn_nodaysel"));
                return false
            } else {
                if (a.findField("schedule_type").getGroupValue() === "advance") {
                    if (!this.schedule) {
                        this.getMsgBox().alert(_T("netbackup", "netbkp_no_schedule"), _T("netbackup", "netbkp_no_schedule"));
                        return false
                    }
                }
            }
        }
        if (this.blDestChanged) {
            if (SYNO.SDS.LunBackup.BKPTASK_LOCLUN == this.taskType) {
                this.checkDirLocal()
            } else {
                this.checkDirNet()
            }
        } else {
            this.ApplySetting()
        }
    },
    CheckChanges: function() {
        var b = this.PanelDest.getForm();
        if (SYNO.SDS.LunBackup.BKPTASK_LOCLUN === this.taskType) {
            this.taskDest = b.findField("localDest").getValue();
            this.destDirectory = b.findField("destDirectory").getValue();
            if (this.taskDest !== this.taskDestOrg || this.destDirectory !== this.destDirectoryOrg) {
                this.blDestChanged = true
            } else {
                this.blDestChanged = false
            }
        } else {
            this.taskDest = b.findField("remoteShare").getValue();
            this.destDirectory = b.findField("destDirectory").getValue();
            var d = b.findField("comboServer");
            var a = SYNO.SDS.LunBackup.GetServerName(d.getRawValue());
            var c = SYNO.SDS.LunBackup.GetServerIP(d.getRawValue());
            if (this.taskDest !== this.taskDestOrg || this.destDirectory !== this.destDirectoryOrg || (c !== this.IPOrg && "" === this.serverOrg) || ((a !== this.serverOrg) && "" !== this.serverOrg)) {
                this.blDestChanged = true
            } else {
                this.blDestChanged = false
            }
        }
    },
    ApplySetting: function() {
        var e = {};
        e.mode = "edit";
        e.oldbkpset = this.taskNameOrig;
        e.newbkpset = this.PanelDest.getForm().findField("bkpset").getValue();
        e.srcchanged = this.blSrcChanged;
        e.destchanged = this.blDestChanged;
        e.bkptype = this.taskType;
        e.lunsource = this.lunSource;
        if (this.blScheduleLoad) {
            if (this.schedule) {
                e.schedule = this.schedule;
                e.scheduleEnable = this.PanelSchedule.getForm().findField("schedule_enable").getValue()
            } else {
                var d = this.PanelSchedule.getScheduleData();
                e.schedule = d.schedule;
                e.scheduleEnable = d.enableschedule
            }
        } else {
            e.schedule = this.oldSchedule;
            e.scheduleEnable = this.oldScheduleEnable
        }
        e.bkpnow = this.PanelSchedule.getForm().findField("bkpnow").getValue();
        var b = this.PanelDest.getForm();
        if (SYNO.SDS.LunBackup.BKPTASK_LOCLUN === this.taskType) {
            var c = b.findField("localDest");
            var a = c.getValue();
            e.dest = a + "/" + b.findField("destDirectory").getValue()
        } else {
            var f;
            e.servertype = this.taskType;
            e.dest = b.findField("remoteShare").getValue() + "/" + b.findField("destDirectory").getValue() + "/";
            f = b.findField("comboServer");
            e.server = SYNO.SDS.LunBackup.GetServerName(f.getRawValue());
            e.ip = SYNO.SDS.LunBackup.GetServerIP(f.getRawValue());
            e.account = b.findField("textAccount").getValue();
            e.password = b.findField("password").getValue();
            e.module = b.findField("remoteShare").getValue()
        }
        this.SendRequest("apply_lun", e)
    },
    TestServerVersionDone: function(b, a) {
        this.owner.clearStatusBusy();
        if (b) {
            this.owner.CheckSetting()
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), SYNO.SDS.Backup.String(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("netbackup", "netbkp_connection_testing_fail"))
            }
        }
    },
    onTestConnectionDone: function(c, a) {
        if (c) {
            var b = {};
            b.servertype = "synology";
            b.share = "share";
            b.mode = "edit";
            b = this.owner.PanelDest.getTestconParams(b, false);
            this.sendWebAPI({
                api: "SYNO.Backup.Lunbackup",
                version: 1,
                method: "remote_version_check",
                params: b,
                scope: this,
                callback: this.owner.TestServerVersionDone
            })
        } else {
            this.owner.clearStatusBusy();
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("netbackup", "netbkp_connection_testing_fail"))
            }
        }
    },
    onTestConnection: function() {
        var a = {};
        a = this.PanelDest.getTestconParams(a, false);
        if (a) {
            SYNO.SDS.LunBackup.onTestSvrConnection("test_connections", a, this.PanelDest, this.onTestConnectionDone)
        } else {
            this.scope.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("netbackup", "netbkp_err_host_str"))
        }
    },
    checkDirDone: function(b, a) {
        this.clearStatusBusy();
        if (b) {
            this.ApplySetting()
        } else {
            if (a && a.errors && a.errors.sec && a.errors.key && "" !== a.errors.sec && "" !== a.errors.key) {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T(a.errors.sec, a.errors.key))
            } else {
                this.owner.getMsgBox().alert(_T("tree", "leaf_backup"), _T("common", "error_system"))
            }
        }
    },
    checkDirNet: function() {
        var b = this.PanelDest.getForm();
        var a = b.findField("comboServer").getRawValue();
        this.setStatusBusy({
            text: _T("netbackup", "netbkp_wait_server")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "check_dir",
            params: {
                bkptype: SYNO.SDS.LunBackup.BKPTASK_NETLUN,
                bkpset: this.taskName,
                share: this.taskDest,
                directory: this.destDirectory,
                user: b.findField("textAccount").getValue(),
                password: b.findField("password").getValue(),
                server: SYNO.SDS.LunBackup.GetServerName(a),
                ip: SYNO.SDS.LunBackup.GetServerIP(a)
            },
            scope: this,
            callback: this.checkDirDone
        })
    },
    checkDirLocal: function() {
        this.setStatusBusy({
            text: _T("localbkp", "localbkp_wait_dest")
        });
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: "check_dir",
            params: {
                bkptype: SYNO.SDS.LunBackup.BKPTASK_LOCLUN,
                bkpset: this.taskName,
                share: this.taskDest,
                directory: this.destDirectory
            },
            scope: this,
            callback: this.checkDirDone
        })
    },
    onOk: function() {
        this.CheckChanges();
        if ("" === this.taskDest || "" === this.destDirectory) {
            return
        }
        if (SYNO.SDS.LunBackup.BKPTASK_NETLUN === this.taskType && (true === this.blDestChanged || true === this.blSrcChanged || true === this.blUserChanged)) {
            this.onTestConnection()
        } else {
            this.CheckSetting()
        }
    },
    onCancel: function() {
        this.close()
    }
});
Ext.define("SYNO.SDS.Backup.Task.LunMainPage", {
    extend: "SYNO.SDS.Backup.Task.MainPage",
    constructor: function(a) {
        this.taskData = {};
        this.pollingTask = null;
        this.pollingDest = null;
        this.taskType = a.taskType;
        this.taskLoaded = false;
        this.callParent(arguments)
    },
    onStartPolling: function() {
        if (this.pollingTask) {
            this.pollingTask.restart()
        } else {
            this.pollingTask = this.addWebAPITask({
                api: "SYNO.Backup.Lunbackup",
                version: 1,
                method: "load_task",
                params: {
                    taskName: this.taskName
                },
                interval: 3000,
                scope: this,
                callback: this.loadTask
            }).start(true)
        }
        if (this.pollingDest) {
            this.pollingDest.restart(true)
        } else {
            this.pollingDest = this.addWebAPITask({
                api: "SYNO.Backup.Lunbackup",
                version: 1,
                method: "load_dest_status",
                params: {
                    taskName: this.taskName
                },
                interval: 30000,
                scope: this,
                callback: this.loadDest
            }).start(true)
        }
    },
    onStopPolling: function() {
        if (this.pollingTask) {
            this.pollingTask.stop()
        }
        if (this.pollingDest) {
            this.pollingDest.stop()
        }
    },
    setBtnStatus: function() {
        this.callParent(arguments);
        if (!this.taskStatus || !this.taskState) {
            return
        }
        var c = this.owner.isRestore();
        var b = ("none" === this.taskStatus && "backupable" === this.taskState && this.taskLoaded);
        this.enableEdit(b);
        var a = ("none" === this.taskStatus && !c && !this.isDemoMode && "backupable" === this.taskState);
        this.enableDelete(a);
        this.actionBtn.setDisabled(!b && !a);
        if (_S("systemdr_running")) {
            this.enableBackup(false)
        }
    },
    setTaskDetailStatus: function(a) {
        this.setTaskStatus("backupable", a.status, a.last_bkp_time, a.last_bkp_result);
        if (a.status === "waiting") {
            this.setProgress({
                isShowPercentage: false,
                description: "",
                scan_file: "",
                bottom_description: ""
            })
        } else {
            if (a.status === "backup") {
                if ("syncing" === a.progress.step) {
                    this.setProgress({
                        isShowPercentage: true,
                        description: _T("backup", "transmitted_size"),
                        scan_file: "",
                        bottom_description: "",
                        speed: "",
                        percentage: a.progress ? a.progress.progress : 0
                    })
                } else {
                    if ("prebackup" === a.progress.step) {
                        this.setProgress({
                            isShowPercentage: false,
                            description: _T("usbbackup", "usbbkp_init"),
                            scan_file: "",
                            bottom_description: ""
                        })
                    }
                }
            }
        }
    },
    loadTask: function(b, a) {
        if (this.isDestroyed) {
            return
        }
        if (b) {
            this.taskLoaded = true;
            this.taskData.name = a.taskName;
            this.taskData.type = a.type;
            this.taskData.bkpdata = a.bkpdata;
            this.taskData.dest = a.dest_share;
            this.taskData.destDirectory = a.dest_dir;
            this.setTaskDetailStatus(a);
            this.setBkpTime(a.last_bkp_time, a.next_bkp_time);
            this.loadDestData(a);
            this.loadSettingData({
                bkpdata: a.bkpdata,
                schedule: this.getScheduleStr(a.schedule)
            })
        }
    },
    getDestData: function(b) {
        var a = [];
        if (SYNO.SDS.LunBackup.BKPTASK_NETLUN === this.taskType) {
            a = [{
                key: _T("common", "ip_addr"),
                text: b ? Ext.util.Format.htmlEncode(b.ip) : _T("common", "loading"),
                tip: b ? Ext.util.Format.htmlEncode(b.ip) : _T("common", "loading")
            }, {
                key: _T("netbackup", "netbkp_account"),
                text: b ? Ext.util.Format.htmlEncode(b.user) : _T("common", "loading"),
                tip: b ? Ext.util.Format.htmlEncode(b.user) : _T("common", "loading")
            }]
        }
        return a.concat([{
            key: _T("tree", "leaf_sharefolder"),
            text: b ? Ext.util.Format.htmlEncode(b.dest_share) : _T("common", "loading"),
            tip: b ? Ext.util.Format.htmlEncode(b.dest_share) : _T("common", "loading")
        }, {
            key: _T("backup", "backup_dest_directory"),
            text: b ? Ext.util.Format.htmlEncode(b.dest_dir) : _T("common", "loading"),
            tip: b ? Ext.util.Format.htmlEncode(b.dest_dir) : _T("common", "loading")
        }])
    },
    getSettingData: function(a) {
        return [{
            key: _T("lunbkp", "lun_source"),
            text: a ? Ext.util.Format.htmlEncode(a.bkpdata) : _T("common", "loading")
        }, {
            key: _T("common", "schedule"),
            text: a ? Ext.util.Format.htmlEncode(a.schedule) : _T("common", "loading")
        }]
    },
    loadDest: function(c, b) {
        if (this.isDestroyed) {
            return
        }
        if (c) {
            var a = b.deststatus;
            var d = ("connected" === a || "int_ok" === a || "normal" === a);
            this.setIsOnline(d);
            if (this.pollingDest) {
                if (!d) {
                    this.pollingDest.interval = 120000
                } else {
                    this.pollingDest.interval = 30000
                }
            }
        }
    },
    onEditBackupTask: function() {
        var a = new SYNO.SDS.Backup.LUNEditDialog({
            owner: this.appWin,
            type: this.taskData.type
        });
        this.mon(a, "close", this.loadStaticData, this);
        a.load({
            name: this.taskData.name,
            type: this.taskData.type,
            bkpdata: this.taskData.bkpdata,
            dest: this.taskData.dest,
            destDirectory: this.taskData.destDirectory
        });
        this.openWindow(a)
    },
    onDeleteBackupTask: function() {
        this.appWin.getMsgBox().confirmDelete(_T("tree", "leaf_backup"), _T("backup", "backup_confirm_delete_task"), function(a) {
            if (a !== "yes") {
                return
            }
            this.doDeleteBackupTask()
        }, this)
    },
    doDeleteBackupTask: function() {
        this.sendWebAPIRequest("delete", {
            before: function() {
                this.onStopPolling()
            },
            success: function() {
                this.appWin.deleteCurrentTask()
            },
            fail: function() {
                this.onStartPolling()
            }
        })
    },
    doCancelBackup: function() {
        this.sendWebAPIRequest("cancel", {
            before: function() {
                this.onStopPolling()
            },
            success: function() {
                this.onStartPolling()
            },
            fail: function() {
                this.onStartPolling()
            }
        })
    },
    onBackupNow: function() {
        this.sendWebAPIRequest("bkpnow", {
            before: function() {
                this.onStopPolling()
            },
            success: function() {
                this.setTaskDetailStatus({
                    status: "waiting"
                });
                this.onStartPolling()
            },
            fail: function() {
                this.onStartPolling()
            }
        })
    },
    sendWebAPIRequest: function(b, a) {
        this.appWin.setStatusBusy();
        if (a.before) {
            a.before.call(this)
        }
        var c = (function(g) {
            var f = [];
            var e = [];
            var d = [];
            var h = [];
            if (SYNO.SDS.LunBackup.BKPTASK_LOCLUN === g.type) {
                f.push(g.name);
                e.push(g.bkpdata)
            } else {
                if (SYNO.SDS.LunBackup.BKPTASK_NETLUN === g.type) {
                    d.push(g.name);
                    h.push(g.bkpdata)
                }
            }
            return ({
                action: b,
                locluntasks: f.join(","),
                loclunnames: e.join(","),
                netluntasks: d.join(","),
                netlunnames: h.join(",")
            })
        })(this.taskData);
        this.sendWebAPI({
            api: "SYNO.Backup.Lunbackup",
            version: 1,
            method: b,
            params: c,
            scope: this,
            callback: function(e, d) {
                if (e) {
                    if (a.success) {
                        a.success.call(this)
                    }
                    this.appWin.clearStatusBusy()
                } else {
                    if (a.fail) {
                        a.fail.call(this)
                    }
                    this.appWin.clearStatusBusy();
                    if (d && d.errors && d.errors.sec && d.errors.key && "" !== d.errors.sec && "" !== d.errors.key) {
                        this.appWin.getMsgBox().alert(_T("tree", "leaf_backup"), _T(d.errors.sec, d.errors.key))
                    } else {
                        this.appWin.getMsgBox().alert(_T("tree", "leaf_backup"), _T("common", "error_system"))
                    }
                }
            }
        })
    }
});
Ext.define("SYNO.SDS.Backup.EditSourcePanelWrapper", {
    extend: "SYNO.ux.Panel",
    constructor: function(a) {
        var b = {
            layout: "fit",
            items: [new SYNO.SDS.Backup.EditSourcePanel({
                itemId: "source_selector_panel",
                owner: a.owner,
                isImage: a.isImage,
                height: a.height,
                disable_modified_source: a.disable_modified_source
            })]
        };
        Ext.apply(b, a);
        this.callParent([b])
    },
    initComponent: function() {
        this.callParent(arguments);
        var a = this.appInstance.getUserSettings("show_parent_file_only_tip");
        if (this.isImage && (undefined === a || a)) {
            this.add(new SYNO.SDS.Backup.NewFeaturePanel({
                appInstance: this.appInstance,
                subTopic: "data_backup_source.html"
            }))
        }
    }
});
Ext.define("SYNO.SDS.Backup.EditSourcePanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(a) {
        var b = {
            bbar: (a.isImage) ? this.createBbar() : undefined,
            cls: "syno-backup-source-wrapper",
            height: a.height,
            layout: "fit",
            items: [this.createSourceSelector(a.owner, a.disable_modified_source, a.isImage)]
        };
        b = Ext.apply(a, b);
        this.callParent([b])
    },
    createSourceSelector: function(a, b, d) {
        var c = {
            itemId: "source_selector",
            owner: a,
            pageContainer: this,
            isImage: d,
            pre_load_folder_done: false,
            disabled: b
        };
        if (d) {
            return new SYNO.SDS.Backup.TaskSourceQuadSelector(c)
        } else {
            return new SYNO.SDS.Backup.TaskSourceTriSelector(c)
        }
    },
    openFilterSettingWindow: function() {
        var a = new SYNO.SDS.Backup.Client.Common.FilterSettingWindow({
            owner: this.owner,
            backupFilter: this.backupFilter,
            disable_modified_source: this.disable_modified_source
        });
        a.on("savefilterparams", this.saveFilterParams, this);
        a.open()
    },
    createBbar: function() {
        var a = new SYNO.ux.Toolbar();
        a.add(new Ext.ux.StatusBar({
            html: '<span class="syno-backup-open-filter-text">' + SYNO.SDS.Backup.String("app", "create_file_filter") + "</span>",
            hideBorders: true,
            listeners: {
                scope: this,
                afterrender: function(b) {
                    b.getEl().on("click", function() {
                        this.openFilterSettingWindow()
                    }, this)
                }
            }
        }));
        return a
    },
    getSource: function() {
        return this.getComponent("source_selector")
    },
    saveFilterParams: function(a) {
        var b = {};
        Ext.copyTo(b, a, "whitelist");
        b.exclude_list = SYNO.Backup.Util.ExtractPattern(a.exclude_list, "file");
        this.backupFilter = b
    },
    getParams: function() {
        return this.backupFilter || {}
    }
});
Ext.define("SYNO.SDS.Backup.TaskEditDialog", {
    extend: "SYNO.SDS.ModalWindow",
    dsmStyle: "v5",
    invalidList: "",
    support_app_share: false,
    constructor: function(c) {
        this.repoEdit = false;
        this.invalidAlerted = false;
        this.expandedRoot = 0;
        this.isImage = SYNO.Backup.Util.IsImage(c.targetType);
        this.hasRotationPanel = this.isImage;
        this.accountMeta = c.accountMeta;
        var h = 680,
            a = 580;
        var d = (true === c.isOnline && true === c.isSuspended) || c.taskState === "restore_only";
        this.disable_rotate = (SYNO.SDS.Backup.Client.Common.Utils.AccountMeta.ROTATION_CUSTOM !== c.accountMeta.versionRotation || true === c.isDiscard || "error_detect" === c.taskState);
        var g = [new SYNO.SDS.Backup.EditSourcePanelWrapper({
            title: _T("backup", "folder_title"),
            itemId: "source_selector_panel_wrapper",
            cls: "syno-backup-edit-source-panel",
            owner: this,
            isImage: this.isImage,
            height: a - 143,
            disable_modified_source: d,
            appInstance: c.appInstance
        }), new SYNO.SDS.Backup.AppParamsPanel({
            title: _T("backup", "application"),
            itemId: "app_panel",
            disabled: d,
            height: a - 143,
            owner: this
        }), this.createParamsPanelByType(c.transferType, c.targetType, {
            title: _T("common", "common_settings"),
            itemId: "task_setting_panel",
            owner: this,
            height: a - 143,
            accountMeta: c.accountMeta,
            isSuspended: c.isSuspended
        })];
        if (SYNO.SDS.Backup.Client.Common.Utils.AccountMeta.SCHEDULE_UNLIMITED === c.accountMeta.scheduleRule) {
            g.push(new SYNO.SDS.Backup.EditSchedulePanel({
                title: _T("common", "schedule"),
                itemId: "sched_panel",
                owner: this,
                isImage: c.isImage,
                height: a - 143,
                targetType: c.targetType
            }))
        } else {
            if (SYNO.SDS.Backup.Client.Common.Utils.AccountMeta.SCHEDULE_ONCE_A_DAY === c.accountMeta.scheduleRule) {
                g.push(new SYNO.SDS.Backup.C2CloudEditSchedulePanel({
                    title: _T("common", "schedule"),
                    itemId: "sched_panel",
                    owner: this,
                    height: a - 143,
                    targetType: c.targetType
                }))
            }
        }
        if (this.hasRotationPanel) {
            g.push(new SYNO.SDS.Backup.RotationParamsPanel({
                title: SYNO.SDS.Backup.String("app", "rotation"),
                tabTip: SYNO.SDS.Backup.Client.Common.Utils.AccountMeta.ROTATION_BASIC === c.accountMeta.versionRotation ? SYNO.SDS.Backup.String("error", "plan_not_support") : null,
                itemId: "rotate_panel",
                disabled: d || this.disable_rotate,
                owner: this,
                appWin: c.appWin,
                height: a - 130
            }))
        }
        var f = SYNO.Backup.Addon.Util.getID(c.targetType, c.transferType);
        var b = SYNO.Backup.Addon.Util.getClass(f, "Destination.EditPanel");
        if (Ext.isFunction(b)) {
            g.push(new b({
                title: _T("netbackup", "netbkp_target"),
                itemId: "repo_panel",
                taskId: c.taskId,
                repoId: c.repoId,
                targetType: c.targetType,
                transferType: c.transferType,
                owner: this
            }))
        }
        var e = Ext.apply({
            width: h,
            height: a,
            resizable: false,
            cls: "syno-backup-edit-window",
            title: _T("schedule", "task_settings"),
            items: [{
                xtype: "syno_tabpanel",
                itemId: "edit_tab_panel",
                activeTab: (d ? "task_setting_panel" : "source_selector_panel_wrapper"),
                items: g
            }],
            buttons: [{
                text: _T("common", "cancel"),
                scope: this,
                handler: function() {
                    this.close()
                }
            }, {
                text: _T("common", "apply"),
                btnStyle: "blue",
                scope: this,
                handler: this.onApplyClick
            }]
        }, c);
        this.callParent([e])
    },
    initEvents: function() {
        this.callParent(arguments);
        var a = this.getSourceSelector();
        this.mon(a, "beforeexpandnode", this.onExpandFmRoot, this)
    },
    createParamsPanelByType: function(a, f, b) {
        var e = b;
        e.target_type = f;
        e.transfer_type = a;
        e.enableRotate = (SYNO.SDS.Backup.Client.Common.Utils.AccountMeta.ROTATION_CUSTOM === b.accountMeta.versionRotation) && ("image" === f || "cloud_image" === f);
        e.hideDataEnc = true;
        e.disableDataComp = true;
        e.hideDataComp = false;
        e.bwrapStyle = "padding: 0px 8px";
        var d = SYNO.Backup.Addon.Util.getID(f, a);
        var c = SYNO.Backup.Addon.Util.getClass(d, "Task.SettingPanel");
        if (Ext.isFunction(c)) {
            return new c(e)
        }
        return null
    },
    disableNode: function(a) {
        a.getUI().setCheckValue(false);
        a.leaf = true;
        a.expandable = false;
        a.disable()
    },
    disableEncShare: function(a) {
        a.eachChild(function(c) {
            if (c.attributes.encryptedShare) {
                if (this.isImage && !this.support_enc_share) {
                    c.disable();
                    var b = ("offline" === this.destStatus) ? SYNO.SDS.Backup.String("app", "offline_disable_enc_share") : _T("backup", "multi_version_not_support_encrypted_share");
                    c.setTooltip(b)
                } else {
                    this.getSourceSelector().updateEncShare(this.targetType, this.transferType, c)
                }
            }
        }, this)
    },
    destShareCheck: function(a) {
        if (this.destShare) {
            var b = this.getSourceSelector();
            b.setDestination("/" + this.destShare)
        }
    },
    onExpandFmRoot: function(a) {
        if (-1 !== this.getSourceSelector().fm_root_nodes.indexOf(a.id)) {
            this.disableEncShare(a);
            this.destShareCheck(a);
            this.expandedRoot += 1;
            if (this.getSourceSelector().volumeCount === this.expandedRoot) {
                this.doIfAppShareReady("folder_initialed")
            }
        }
        return true
    },
    doIfAppShareReady: function(b) {
        this[b] = true;
        if (this.app_loaded && this.folder_loaded && this.folder_initialed) {
            var a = "image_remote" === this.transferType && !this.isOnline;
            SYNO.SDS.Backup.setAppGridDependency(this.getAppPanel(), this.getSourceSelector(), true, a);
            this.alertInvalidList()
        }
    },
    onOpen: function() {
        this.setStatusBusy();
        var b = ["is_usb_share", "local_volume", "support_ssl", "support_rotate", "support_enc_share", "support_compression", "support_app_share", "support_error_detect", "support_detect_time_limit", "support_version_file_log", "skip_repo_status", "is_share_enc"];
        var a = ["backup_params", "rotate_params", "schedule", "incheck_schedule", "backup_volumes", "backup_filter"];
        if (!this.disable_rotate) {
            a.push("version_count")
        }
        this.sendWebAPI({
            compound: {
                stopwhenerror: false,
                mode: "parallel",
                params: [{
                    api: "SYNO.Backup.Task",
                    version: 1,
                    method: "get",
                    scope: this,
                    params: {
                        task_id: this.taskId,
                        additional: a,
                        account_meta: this.accountMeta
                    }
                }, {
                    api: "SYNO.Backup.Repository",
                    version: 1,
                    method: "get",
                    params: {
                        task_id: this.taskId,
                        additional: b
                    }
                }]
            },
            timeout: 180000,
            scope: this,
            callback: this.onOpenDone
        });
        return this.callParent(arguments)
    },
    onOpenDone: function(h, b, f) {
        if (!h) {
            this.clearStatusBusy();
            this.getMsgBox().alert(_T("leaf", "backup"), _T("error", "error_error_system"), function() {
                this.close()
            }, this);
            return
        }
        if (!b.result[1].success) {
            this.clearStatusBusy();
            this.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(b.result[1].error.code), function() {
                this.close()
            }, this);
            return
        }
        var a = b.result[1].data;
        this.repoVolume = a.local_volume;
        if ("image_remote" === a.transfer_type && b.result[0].success && Ext.isDefined(b.result[0].data.backup_params.trans_encrypt)) {
            var c = Ext.apply({
                sslcheck: b.result[0].data.backup_params.trans_encrypt
            }, a);
            this.loadRepoParams(c)
        } else {
            this.loadRepoParams(a)
        }
        if (!b.result[0].success) {
            var g = this.getComponent("edit_tab_panel");
            this.clearStatusBusy();
            if (this.getRepoPanel()) {
                g.setActiveTab("repo_panel");
                g.items.get(0).setDisabled(true);
                g.items.get(1).setDisabled(true);
                g.items.get(2).setDisabled(true);
                g.items.get(3).setDisabled(true);
                if (this.hasRotationPanel) {
                    g.items.get(4).setDisabled(true)
                }
                this.repoEdit = true
            } else {
                this.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(b.result[0].error.code), function() {
                    this.close()
                }, this)
            }
            return
        }
        var d = b.result[0].data;
        if ("local" === a.transfer_type || "image_local" === a.transfer_type) {
            this.destShare = a.share
        }
        this.support_ssl = a.support_ssl;
        this.support_rotate = a.support_rotate;
        this.support_enc_share = a.support_enc_share;
        this.support_data_comp = a.support_compression;
        this.support_app_share = a.support_app_share;
        this.support_error_detect = a.support_error_detect;
        this.support_detect_time_limit = a.support_detect_time_limit;
        this.support_version_file_log = a.support_version_file_log;
        this.destStatus = a.deststatus;
        this.destEnc = a.is_share_enc;
        this.version_count = d.version_count;
        this.loadBackupSource(d, a);
        this.loadTaskSettingParams(d, a);
        this.loadScheduleParams(d);
        if (this.hasRotationPanel) {
            if (this.support_rotate) {
                this.loadRotationParams(d)
            } else {
                this.getComponent("edit_tab_panel").items.get(4).setDisabled(true);
                if ("offline" === a.deststatus) {
                    this.getComponent("edit_tab_panel").getTabEl("rotate_panel").setAttribute("ext:qtip", SYNO.SDS.Backup.String("app", "offline_disable_rotation"))
                }
            }
        }
        var e = (function() {
            this.clearStatusBusy();
            if (this.isSuspended) {
                if (true === this.isOnline) {
                    this.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("app", "suspend_modified_warning"))
                } else {
                    this.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.String("app", "offline_modified_warning"))
                }
            }
            if (true === this.openFilterPage) {
                this.getSourceSelectorPanel().openFilterSettingWindow()
            }
        }).createDelegate(this);
        this.loadAppParams(d, e)
    },
    alertInvalidList: function() {
        this.invalidAlerted = true;
        var b = this.getAppPanel().getAppList().slice(0);
        var a = this.getAppPanel().checkedList.slice(0);
        var f = this.getAppPanel().nameList.slice(0);
        var d = [];
        Ext.each(a, function(i, h) {
            if (0 > b.indexOf(i)) {
                d.push(f[h])
            }
        });
        var c = "";
        if ("image" === this.targetType || "cloud_image" === this.targetType) {
            var g = this.getSourceSelector().getSelectedEncList(true);
            if (0 < g.length) {
                c += SYNO.SDS.Backup.String("error", "mount_enc_before_backup") + ":<br/>" + g.join(", ") + "<br/>"
            }
        }
        var e = "";
        if (0 < this.invalidList.length) {
            e += this.invalidList
        }
        if (0 < d.length) {
            e += _T("backup", "application") + ": " + d.join(", ")
        }
        if (0 < e.length) {
            e = _T("backup", "unselect_invalid_source") + "<br/>" + e
        }
        c += e;
        if (0 < c.length) {
            c = '<div style="width:420px; max-height:460px; overflow:auto;">' + c + "</div>";
            this.getMsgBox().alert(_T("leaf", "backup"), c, this.clearStatusBusy, this)
        }
    },
    getLocalRepoVolume: function() {
        return this.repoVolume
    },
    loadAppParams: function(a, b) {
        this.getAppPanel().setAppCheckList(a.source.app_list);
        this.getAppPanel().setAppNameList(a.source.app_name_list);
        this.getAppPanel().setAppLastConfig(a.source.app_config);
        this.getAppPanel().loadStore(this.support_app_share, b)
    },
    loadBackupSource: function(b, c) {
        var a = this.getSourceSelector();
        if (!b || !b.source) {
            return
        }
        if (this.isImage) {
            a.setVolumeList(b.source.backup_volumes);
            a.setExcludeFolderList(SYNO.Backup.Util.ExtractPattern(b.source.backup_filter.exclude_list, "dir"));
            this.getSourceSelectorPanel().saveFilterParams(b.source.backup_filter || {})
        }
        a.setFolderList(b.source.file_list)
    },
    loadBackupVolumeAndExcludeFolder: function(b) {
        if (!this.isImage || !b) {
            return
        }
        var a = this.getSourceSelector();
        if (b.backup_volumes) {
            a.setVolumeList(b.backup_volumes)
        }
        if (b.backup_filter) {
            a.setExcludeFolderList(SYNO.Backup.Util.ExtractPattern(b.backup_filter.exclude_list, "dir"))
        }
    },
    loadScheduleParams: function(a) {
        var b = {
            week_name: "1",
            hour: 0,
            min: 0,
            date: new Date().format("Y/m/d"),
            date_type: 0,
            repeat: 0,
            repeat_hour: 0,
            last_work_hour: 0,
            schedule_enable: false
        };
        if (a.schedule) {
            b = a.schedule.schedule;
            b.schedule_enable = a.schedule.schedule_enable
        }
        b.repeat_date = b.repeat;
        b.minute = b.min;
        b.week_day = b.week_name;
        delete b.repeat;
        delete b.min;
        delete b.week_name;
        if (this.isImage && !this.support_error_detect) {
            this.getSchedPanel().setSupportErrorDetect(false)
        }
        this.getSchedPanel().setData({
            backup: b,
            incheck: a.incheck_schedule,
            support_detect_time_limit: this.support_detect_time_limit
        })
    },
    loadFilterParams: function(a) {
        this.getSourceSelectorPanel().saveFilterParams(a.backup_filter || {})
    },
    loadTaskSettingParams: function(a, c) {
        if ("synocloud_swift" === c.transfer_type) {
            if (a.backup_params.bw_limit && a.backup_params.bw_limit > 0) {
                a.backup_params.bw_limit = a.backup_params.bw_limit / 1024;
                a.backup_params.bw_limit_unit = "KB";
                if (a.backup_params.bw_limit >= 1024 && 0 === a.backup_params.bw_limit % 1024) {
                    a.backup_params.bw_limit = a.backup_params.bw_limit / 1024;
                    a.backup_params.bw_limit_unit = "MB"
                }
            }
        }
        this.getTaskSettingPanel().getForm().setValues(Ext.apply({
            task_name: a.name,
            task_dir: a.target_id,
            incrbkp_enable: !a.backup_params.delete_on_target,
            bandwidthcheck: (a.backup_params.bw_limit && a.backup_params.bw_limit > 0)
        }, a.backup_params));
        this.orgName = a.name;
        if ("cloud_image" === c.target_type && ("rsync" === c.transfer_type || "rsync_ds" === c.transfer_type || "hidrive" === c.transfer_type)) {
            if (Ext.isDefined(a.backup_params.trans_compress)) {
                this.getTaskSettingPanel().getForm().findField("trans_compress").setVisible(true);
                this.getTaskSettingPanel().getForm().findField("trans_compress").setDisabled(false)
            } else {
                this.getTaskSettingPanel().getForm().findField("trans_compress").setVisible(false);
                this.getTaskSettingPanel().getForm().findField("trans_compress").setDisabled(true)
            }
        }
        if ("cloud_image" === c.target_type && "aws_s3" === c.transfer_type) {
            if (Ext.isDefined(a.backup_params.storage_class)) {
                this.getTaskSettingPanel().getFieldset().getComponent("storage_class").setValue(a.backup_params.storage_class);
                this.getTaskSettingPanel().getFieldset().getComponent("storage_class").transToText()
            } else {
                this.getTaskSettingPanel().getFieldset().getComponent("storage_class").setVisibleAndEnable(false)
            }
        }
        if (this.getTaskSettingPanel().getForm().findField("dest_auto_unmount")) {
            this.getTaskSettingPanel().getForm().findField("dest_auto_unmount").hide();
            this.getTaskSettingPanel().getForm().findField("dest_auto_unmount").disable();
            if (!_D("usbstation") && c.is_usb_share) {
                if ("local" === c.transfer_type || "image_local" === c.transfer_type) {
                    this.getTaskSettingPanel().getForm().findField("dest_auto_unmount").show();
                    this.getTaskSettingPanel().getForm().findField("dest_auto_unmount").enable()
                }
            }
        }
        if (!this.support_data_comp) {
            var b = this.getTaskSettingPanel().getForm().findField("enable_data_compress");
            if (!Ext.isEmpty(b)) {
                b.hide();
                b.disable()
            }
        }
        var d = this.getTaskSettingPanel().getForm().findField("enable_version_file_log");
        if (!Ext.isEmpty(d)) {
            if (this.isSuspended) {
                d.disable()
            } else {
                if (!this.support_version_file_log) {
                    d.setValue(false);
                    d.disable()
                }
            }
        }
    },
    loadRotationParams: function(a) {
        this.getRotationPanel().loadData(a.rotate_params)
    },
    loadRepoParams: function(b) {
        if (!this.getRepoPanel()) {
            return
        }
        var a = {};
        a.accountMeta = this.accountMeta;
        this.getRepoPanel().loadData(b, a)
    },
    getSourceSelectorPanel: function() {
        return this.getComponent("edit_tab_panel").getComponent("source_selector_panel_wrapper").getComponent("source_selector_panel")
    },
    getSourceSelector: function() {
        return this.getSourceSelectorPanel().getSource()
    },
    getAppPanel: function() {
        return this.getComponent("edit_tab_panel").getComponent("app_panel")
    },
    getTaskSettingPanel: function() {
        return this.getComponent("edit_tab_panel").getComponent("task_setting_panel")
    },
    getSchedPanel: function() {
        return this.getComponent("edit_tab_panel").getComponent("sched_panel")
    },
    getRotationPanel: function() {
        return this.getComponent("edit_tab_panel").getComponent("rotate_panel")
    },
    getRepoPanel: function() {
        return this.getComponent("edit_tab_panel").getComponent("repo_panel")
    },
    onApplyClick: function() {
        if (this.repoEdit) {
            this.onRepoEditApply()
        } else {
            this.onFullEditApply()
        }
    },
    onFullEditApply: function() {
        if (!this.getTaskSettingPanel().getForm().isValid()) {
            this.getComponent("edit_tab_panel").setActiveTab("task_setting_panel");
            this.setStatusError({
                text: _T("common", "forminvalid"),
                clear: true
            });
            return false
        }
        if (this.getRepoPanel() && !this.getRepoPanel().getForm().isValid()) {
            this.getComponent("edit_tab_panel").setActiveTab("repo_panel");
            this.setStatusError({
                text: _T("common", "forminvalid"),
                clear: true
            });
            return false
        }
        if (!this.getSchedPanel().getForm().isValid()) {
            this.getComponent("edit_tab_panel").setActiveTab("sched_panel");
            this.setStatusError({
                text: _T("common", "forminvalid"),
                clear: true
            });
            return false
        }
        var c, d, a, e;
        if (this.hasRotationPanel && this.support_rotate) {
            c = this.getRotationPanel().getForm();
            d = c.findField("backup_rotation");
            a = c.findField("backup_rotation_action");
            e = c.findField("backup_rotation_condition_max_version");
            if (!c.isValid()) {
                this.getComponent("edit_tab_panel").setActiveTab("rotate_panel");
                this.setStatusError({
                    text: _T("common", "forminvalid"),
                    clear: true
                });
                return false
            }
        }
        if (d && d.getValue() && ((d && d.isDirty()) || (a && a.isDirty()) || (e && e.isDirty()))) {
            var b;
            if (e && this.version_count && ((e.getValue() + 1) < this.version_count)) {
                this.getComponent("edit_tab_panel").setActiveTab("rotate_panel");
                b = String.format(SYNO.SDS.Backup.String("app", "rotate_delete_hint"), this.version_count, e.getValue()) + "<br/><br/>" + SYNO.SDS.Backup.String("app", "rotate_delete_note");
                b += "<br/><br/>" + SYNO.SDS.Backup.String("app", "rotate_delete_confirm");
                this.getMsgBox().confirmDelete("", b, function(f) {
                    if ("yes" === f) {
                        this.checkEncShare()
                    } else {
                        return false
                    }
                }, this, {
                    yes: {
                        text: _T("backup", "rotate"),
                        btnStyle: "red"
                    },
                    no: {
                        text: Ext.MessageBox.buttonText.no
                    }
                })
            } else {
                this.getComponent("edit_tab_panel").setActiveTab("rotate_panel");
                b = String.format(SYNO.SDS.Backup.String("app", "rotate_delete_hint_under"), this.version_count, e.getValue());
                b += "<br/><br/>" + SYNO.SDS.Backup.String("app", "rotate_delete_confirm");
                this.getMsgBox().confirm("", b, function(f) {
                    if ("yes" === f) {
                        this.checkEncShare()
                    } else {
                        return false
                    }
                }, this)
            }
        } else {
            this.checkEncShare()
        }
    },
    checkEncShare: function() {
        if ("image" === this.targetType || "cloud_image" === this.targetType) {
            var b = this.getSourceSelector().getSelectedEncList();
            if (0 < b.length) {
                var a = this.getTaskSettingPanel().getForm().findField("enable_data_encrypt");
                if (false === this.destEnc && a && false === a.getValue()) {
                    this.getComponent("edit_tab_panel").setActiveTab("source_selector");
                    this.getMsgBox().confirm(_T("leaf", "backup"), String.format(SYNO.SDS.Backup.String("error", "backup_enc_to_not_enc_dest"), "<b>" + b.join(", ") + "</b>"), function(c) {
                        if ("yes" === c) {
                            this.checkNeedVerify()
                        }
                    }, this);
                    return
                }
            }
        }
        this.checkNeedVerify()
    },
    checkNeedVerify: function() {
        var a = this.owner.getCurrentTask();
        if (a.data_enc) {
            var c, d, b, e;
            if (this.hasRotationPanel && this.support_rotate) {
                c = this.getRotationPanel().getForm();
                d = c.findField("backup_rotation");
                b = c.findField("backup_rotation_action");
                e = c.findField("backup_rotation_condition_max_version")
            }
            if (d && d.getValue() && ((d && d.isDirty()) || (b && b.isDirty()) || (e && e.isDirty()))) {
                if (Ext.isEmpty(a.sess_id)) {
                    this.launchPasswordWindow(function() {
                        this.applyEdit(true)
                    }, SYNO.SDS.Backup.String("app", "edit_version_rotate_verify"));
                    return
                }
                this.applyEdit(true);
                return
            }
        }
        this.applyEdit(false)
    },
    launchPasswordWindow: function(a, e) {
        var b = this.owner.getCurrentTask();
        var d = {
            task_id: b.task_id,
            repo_id: b.repo_id,
            target_id: b.target_id
        };
        var c = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.owner,
            verify_params: d,
            verify_hint: e,
            setter: Ext.createDelegate(this.owner.setCurTaskSession, this.owner),
            callback: Ext.createDelegate(a, this)
        });
        c.open()
    },
    onRepoEditApply: function() {
        if (!this.getRepoPanel() || !this.getRepoPanel().getForm().isDirty()) {
            this.close();
            return
        }
        this.setStatusBusy();
        this.sendWebAPI(Ext.apply(this.getRepoPanel().getApplyApi(), {
            scope: this,
            callback: function(c, a, b) {
                if (!c) {
                    this.clearStatusBusy();
                    this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(a.code));
                    return
                }
                this.clearStatusBusy();
                this.close()
            }
        }));
        return false
    },
    applyEdit: function(e) {
        var d = [];
        var g = {};
        var f = this.getParams();
        if (this.getRepoPanel()) {
            var a = this.getRepoPanel().getForm().findField("sslcheck");
            if (a) {
                if (a.getValue()) {
                    f.backup_params.trans_encrypt = true
                } else {
                    f.backup_params.trans_encrypt = false
                }
            }
        }
        if (!this.isNameValid(f.name)) {
            this.getComponent("edit_tab_panel").setActiveTab("task_setting_panel");
            this.getMsgBox().alert(_T("tree", "leaf_backup"), _T("localbkp", "localbkp_bkpset_exist"));
            return false
        }
        if (e) {
            Ext.apply(f, {
                need_sess: true,
                sess_id: this.owner.getCurrentTask().sess_id
            })
        }
        g.api = "SYNO.Backup.Task";
        g.version = 1;
        g.method = "set";
        g.params = f;
        d.push(g);
        var b = [];
        if (this.getRepoPanel() && this.getRepoPanel().getForm().isDirty()) {
            var c = this.getRepoPanel().getApplyApi();
            b = SYNO.SDS.Backup.Util.getEncryption(["pwd", "secret", "remote_refresh_token", "remote_access_token"], c.params);
            d.unshift(c)
        }
        this.setStatusBusy();
        this.sendWebAPI({
            compound: {
                stopwhenerror: true,
                params: d
            },
            encryption: b,
            scope: this,
            callback: function(k, h, i) {
                var j = true;
                if (!k) {
                    this.clearStatusBusy();
                    this.owner.getMsgBox().alert(_T("leaf", "backup"), _T("error", "error_error_system"));
                    return
                }
                Ext.each(h.result, function(l) {
                    if (!l.success) {
                        this.clearStatusBusy();
                        j = false;
                        var m;
                        if (SYNO.SDS.Backup.ERR_OFFLINE === l.error.code && Ext.isDefined(l.error.errors) && Ext.isDefined(l.error.errors.errorlist)) {
                            m = "<li>" + _T("backup", "network_backup") + "<BR>" + SYNO.SDS.Backup.GetErrorString(l.error.errors.errorlist.rsync) + "</li>";
                            m += "<li>" + _T("backup", "encrypt_backup") + "<BR>" + SYNO.SDS.Backup.GetErrorString(l.error.errors.errorlist.ssh) + "</li>";
                            this.getMsgBox().alert(_T("leaf", "backup"), m)
                        } else {
                            if (SYNO.SDS.Backup.ERR_SESSION_EXPIRED === l.error.code) {
                                this.owner.clearCurTaskSession();
                                this.launchPasswordWindow(function() {
                                    this.applyEdit(true)
                                }, SYNO.SDS.Backup.String("app", "edit_version_rotate_verify"))
                            } else {
                                if (l.error.errors && l.error.errors.verify_req_host && l.error.errors.verify_cert_hosts) {
                                    this.owner.getMsgBox().alert(_T("leaf", "backup"), String.format(SYNO.SDS.Backup.GetErrorString(l.error.code), l.error.errors.verify_req_host, l.error.errors.verify_cert_hosts))
                                } else {
                                    this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(l.error.code))
                                }
                            }
                        }
                        return false
                    }
                }, this);
                if (j) {
                    if (h.result[0].data.is_upload_success) {
                        this.triggerVersionRotation(f)
                    }
                    if (this.getTaskSettingPanel().getForm().findField("task_name").isDirty()) {
                        this.owner.onDataTaskRenamed(this.taskId, function() {
                            this.clearStatusBusy();
                            this.close()
                        }, this)
                    } else {
                        this.clearStatusBusy();
                        this.close()
                    }
                }
            }
        });
        return false
    },
    triggerVersionRotation: function(e) {
        if (this.hasRotationPanel && this.support_rotate) {
            var b = this.getRotationPanel().getForm();
            var c = b.findField("backup_rotation");
            var a = b.findField("backup_rotation_action");
            var d = b.findField("backup_rotation_condition_max_version");
            if (c && c.getValue() && ((c && c.isDirty()) || (a && a.isDirty()) || (d && d.isDirty()))) {
                this.sendWebAPI({
                    api: "SYNO.Backup.Version",
                    version: 1,
                    method: "rotate",
                    params: e,
                    callback: function(i, f, g) {
                        if (!i) {
                            var h;
                            if (SYNO.SDS.Backup.ERR_OFFLINE === f.code && Ext.isDefined(f.errors) && Ext.isDefined(f.errors.errorlist)) {
                                h = "<li>" + _T("backup", "network_backup") + "<BR>" + SYNO.SDS.Backup.GetErrorString(f.errors.errorlist.rsync) + "</li>";
                                h += "<li>" + _T("backup", "encrypt_backup") + "<BR>" + SYNO.SDS.Backup.GetErrorString(f.errors.errorlist.ssh) + "</li>";
                                this.getMsgBox().alert(_T("leaf", "backup"), h)
                            } else {
                                if (SYNO.SDS.Backup.ERR_SESSION_EXPIRED === f.code) {
                                    this.owner.clearCurTaskSession();
                                    this.launchPasswordWindow(function() {
                                        this.applyEdit(true)
                                    }, SYNO.SDS.Backup.String("app", "edit_version_rotate_verify"))
                                } else {
                                    this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(f.code))
                                }
                            }
                        }
                    },
                    scope: this
                })
            }
        }
    },
    isNameValid: function(a) {
        return this.orgName === a || -1 === this.owner.getTaskNameList().indexOf(a)
    },
    getParams: function() {
        var d = this.getSchedule();
        var a = this.getSourceSelector().getPathProcessParams();
        var b = {
            file_list: a.folder_list,
            app_list: this.getAppPanel().getAppList(),
            app_config: this.getAppPanel().getAppConfig()
        };
        if (this.isImage) {
            b.backup_volumes = a.backup_volumes;
            b.backup_filter = SYNO.Backup.Util.deepCopyObject(this.getSourceSelectorPanel().getParams());
            b.backup_filter.exclude_list = b.backup_filter.exclude_list.concat(a.folder_exclude_list)
        }
        var c = {
            task_id: this.taskId,
            repo_id: this.repoId,
            source: b,
            schedule: d.backup,
            target_type: this.targetType,
            transfer_type: this.transferType,
            incheck_schedule: d.incheck
        };
        Ext.apply(c, this.getTaskSettingPanel().getParams());
        if (this.hasRotationPanel && this.support_rotate) {
            Ext.apply(c, this.getRotationPanel().getParams())
        }
        return c
    },
    getSchedule: function() {
        var a = {};
        Ext.apply(a, this.getSchedPanel().getData());
        a.backup.repeat = a.backup.repeat_date;
        a.backup.min = a.backup.minute;
        a.backup.week_name = a.backup.week_day;
        delete a.backup.repeat_date;
        delete a.backup.minute;
        delete a.backup.week_day;
        return a
    }
});
Ext.define("SYNO.SDS.Backup.TaskImportWizard", {
    extend: "SYNO.SDS.Backup.Wizard",
    wizardAnchor: "",
    support_app_share: false,
    support_detect_time_limit: false,
    accountMeta: SYNO.SDS.Backup.Client.Common.Utils.createAccountMeta(),
    constructor: function(a) {
        this.lastStepId = null;
        var h = SYNO.Backup.Addon.Config.addon_list;
        var f = SYNO.Backup.Addon.Util.getID(a.targetType, a.transferType);
        var e = {};
        Ext.each(h, function(i) {
            e[a.targetType + ":" + i.transfer_type] = "params"
        });
        var g = SYNO.Backup.Addon.Util.getClass(f, "Destination.SettingPanel");
        var c = SYNO.Backup.Addon.Util.getClass(f, "Task.SettingPanel");
        this.source_selector_id = (SYNO.Backup.Util.IsImage(a.targetType)) ? "source_repo_image" : "source_repo_legacy";
        var b = [new g({
            owner: this,
            appWin: a.appWin,
            itemId: "auth_repo",
            target_type: a.targetType,
            transfer_type: a.transferType,
            action: "import",
            supportCreate: false,
            supportExport: false,
            headline: SYNO.SDS.Backup.String("app", "repo_info_wizard_title"),
            nextId: this.source_selector_id
        }), new SYNO.SDS.Backup.TaskSourceContainerWrapper({
            owner: this,
            appWin: a.appWin,
            itemId: this.source_selector_id,
            isImage: SYNO.Backup.Util.IsImage(a.targetType),
            pre_load_folder_done: false,
            headline: SYNO.SDS.Backup.String("app", "source_share_wizard_title"),
            nextId: "app"
        }), new SYNO.SDS.Backup.AppParamsPanel({
            owner: this,
            appWin: a.appWin,
            itemId: "app",
            headline: SYNO.SDS.Backup.String("app", "source_pkg_wizard_title"),
            bodyStyle: "max-height: 373px; min-height: 373px",
            nextId: e
        }), new c({
            owner: this,
            appWin: a.appWin,
            itemId: "params",
            target_type: a.targetType,
            transfer_type: a.transferType,
            action: "import",
            headline: _T("backup", "backup_settings"),
            nextId: "rotate"
        }), new SYNO.SDS.Backup.RotationParamsPanel({
            owner: this,
            appWin: a.appWin,
            itemId: "rotate",
            headline: _T("backup", "backup_rotation_settings"),
            nextId: null
        })];
        var d = Ext.apply({
            title: SYNO.SDS.Backup.String("app", "wizard_relink"),
            cls: "syno-backup-import-wizard",
            banner: true,
            width: 680,
            height: 580,
            steps: b
        }, a);
        this.callParent([d])
    },
    onOpen: function() {
        var a = this.getAuthPanel();
        if (Ext.isFunction(a.setOauthResponse)) {
            a.setOauthResponse(this.auth_response)
        }
        this.getDefaultParams();
        return this.callParent(arguments)
    },
    getDefaultParams: function() {
        this.setStatusBusy();
        this.sendWebAPI({
            compound: {
                stopwhenerror: true,
                params: [{
                    api: "SYNO.Backup.Task",
                    version: 1,
                    method: "get",
                    scope: this,
                    params: {
                        task_id: this.taskId,
                        additional: ["backup_params", "rotate_params", "schedule", "backup_filter", "backup_volumes"]
                    }
                }, {
                    api: "SYNO.Backup.Repository",
                    version: 1,
                    method: "get",
                    params: {
                        repo_id: this.repoId,
                        additional: ["support_auto_unmount", "local_volume", "support_ssl", "support_rotate", "support_app_share", "support_detect_time_limit", "support_version_file_log"]
                    }
                }]
            },
            scope: this,
            callback: this.getDefaultParamsDone
        })
    },
    getDefaultParamsDone: function(d, a, c) {
        this.clearStatusBusy();
        if (!d) {
            this.getMsgBox().alert(_T("leaf", "backup"), _T("error", "error_error_system"), function() {
                this.close()
            }, this);
            return
        }
        if (!a.result[0].success) {
            this.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(a.result[0].error.code), function() {
                this.close()
            }, this);
            return
        }
        if (!a.result[1].success) {
            this.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(a.result[1].error.code), function() {
                this.close()
            }, this);
            return
        }
        var b = a.result[0].data;
        var e = a.result[1].data;
        this.taskName = b.name;
        this.repoName = e.name;
        this.loadRepoAuth(e, b);
        this.loadBackupSource(b);
        this.loadBackupParams(b);
        this.setAppCheckList(b);
        this.setAppLastConfig(b)
    },
    loadRepoAuth: function(b, a) {
        this.getAuthPanel().getForm().setValues({
            name: b.name
        });
        SYNO.Backup.Util.HBKDisplayComboboxLoadData(this.getAuthPanel().relink_target_id, [a.target_id])
    },
    loadBackupSource: function(b) {
        var a = this.getSourceSelector();
        if (!b || !b.source) {
            return
        }
        if (SYNO.Backup.Util.IsImage(this.targetType)) {
            a.setVolumeList(b.source.backup_volumes);
            a.setExcludeFolderList(SYNO.Backup.Util.ExtractPattern(b.source.backup_filter.exclude_list, "dir"));
            this.getSourceSelectorPanel().saveFilterParams(b.source.backup_filter || {})
        }
        a.setFolderList(b.source.file_list)
    },
    setAppCheckList: function(a) {
        this.getAppPanel().setAppCheckList(a.source.app_list)
    },
    setAppLastConfig: function(a) {
        this.getAppPanel().setAppLastConfig(a.source.app_config)
    },
    loadAppParams: function() {
        if (this.getAppPanel().isLoaded()) {
            this.getAppPanel().setAppCheckList(this.getAppPanel().getAppList())
        }
        this.getAppPanel().loadStore(this.support_app_share)
    },
    loadBackupParams: function(a) {
        this.getParamsPanel().getForm().setValues(Ext.apply({
            task_name: a.name
        }, a.backup_params))
    },
    loadFilterParams: function(a) {
        this.getSourceSelectorPanel().saveFilterParams(a.backup_filter || {})
    },
    loadBackupVolumeAndExcludeFolder: function(b) {
        if (this.isImage || !b) {
            return
        }
        var a = this.getSourceSelector();
        if (b.backup_volumes) {
            a.setVolumeList(b.backup_volumes)
        }
        if (b.backup_filter) {
            a.setExcludeFolderList(SYNO.Backup.Util.ExtractPattern(b.backup_filter.exclude_list, "dir"))
        }
    },
    initializeTask: function() {
        this.setStatusBusy();
        var a = this.getSourceSelector().getPathProcessParams();
        var b = {
            file_list: a.folder_list,
            app_list: this.getAppPanel().getAppList(),
            app_config: this.getAppPanel().getAppConfig()
        };
        if (SYNO.Backup.Util.IsImage(this.targetType)) {
            b.backup_volumes = a.backup_volumes;
            b.backup_filter = SYNO.Backup.Util.deepCopyObject(this.getParams().backup_filter)
        }
        var c = Ext.apply(this.getParams(), {
            task_id: this.taskId,
            sess_id: this.sess_id,
            source: b
        });
        delete c.backup_filter;
        delete c.backup_volumes;
        this.sendWebAPI({
            api: "SYNO.Backup.Task",
            version: 1,
            method: "import",
            params: c,
            callback: this.onRelinkTaskDone,
            scope: this
        })
    },
    onRelinkTaskDone: function(c, a, b) {
        if (!c) {
            this.clearStatusBusy();
            this.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(a.code), function() {
                if (SYNO.SDS.Backup.ERR_SESSION_EXPIRED === a.code) {
                    this.close()
                }
            }, this);
            return
        }
        if (this.getParamsPanel().getForm().findField("task_name").isDirty()) {
            this.owner.onDataTaskRenamed(this.taskId, function() {
                this.clearStatusBusy();
                this.close()
            }, this)
        } else {
            this.clearStatusBusy();
            this.close()
        }
        this.fireEvent("wizardResult", true)
    },
    getParams: function() {
        var a = this.callParent();
        if (this.taskId) {
            a.ori_task_id = this.taskId
        }
        return a
    },
    createTaskDefaultName: function(a) {
        return this.taskName
    },
    getSourceSelectorPanel: function() {
        return this.getStep(this.source_selector_id)
    },
    getSourceSelector: function() {
        return this.getSourceSelectorPanel().getSourceSelector()
    },
    getAppPanel: function() {
        return this.getStep("app")
    },
    getParamsPanel: function() {
        return this.getStep("params")
    },
    getAuthPanel: function() {
        return this.getStep("auth_repo")
    },
    doIfAppShareReady: function(a) {
        this[a] = true;
        if (this.app_loaded && this.folder_loaded && this.folder_initialed) {
            SYNO.SDS.Backup.setAppGridDependency(this.getAppPanel(), this.getSourceSelector(), true, false)
        }
    },
    isTaskNameValid: function(a) {
        return this.taskName === a || -1 === this.owner.getTaskNameList().indexOf(a)
    },
    getRepoInfo: function() {
        return this.getParams()
    },
    reportError: function(a, b) {
        b = b || {};
        if (!this.reporter) {
            this.reporter = new SYNO.SDS.Backup.ApiHelper({
                owner: this
            })
        }
        this.reporter.alert(a, b.callback, b.scope)
    }
});
Ext.define("SYNO.SDS.Backup.Task.DataMainPage", {
    extend: "SYNO.SDS.Backup.Task.MainPage",
    WINDOW_SIZE: 5,
    constructor: function(b) {
        this.pollingTaskID = null;
        this.pollingTargetID = {};
        this.transSizeBuf = [];
        this.isCalculatingSpace = false;
        this.destStatusLoaded = false;
        this.skipNextWebAPI = false;
        this.skipCheckLastResult = false;
        this.canResume = false;
        this.canDiscard = false;
        this.canSuspend = false;
        this.isImage = ("image" === b.targetType || "cloud_image" === b.targetType) ? true : false;
        this.isCloudImage = ("cloud_image" === b.targetType) ? true : false;
        this.targetType = b.targetType;
        this.transferType = b.transferType;
        var c = SYNO.Backup.Addon.Util.getID(this.targetType, this.transferType);
        this.addonInfo = SYNO.Backup.Addon.Util.getInfo(c);
        this.isReAuth = false;
        this.sourceSize = 0;
        this.usedSize = 0;
        this.usedSizeCache = 0;
        this.transSize = 0;
        this.repo = {};
        this.reconnectTimes = 0;
        this.callParent(arguments);
        var a = '<div class="bkp-time-text">' + SYNO.SDS.Backup.String("app", "last_bkp_success_time") + ': {lastBkpTime}</div><div class="bkp-time-text">' + _T("backup", "next_bkp_time") + ": {nextBkpTime}</div>";
        this.getStatusPanel().getComponent("statusCard").getComponent("idle").getComponent("timeText").tpl = a
    },
    initEvents: function() {
        this.callParent(arguments);
        this.mon(this, "activate", function() {
            this.getDestPanel().setHeaderStatus(SYNO.SDS.Backup.String("app", "status_connecting"), "#0086E5")
        }, this, {
            single: true
        })
    },
    loadStaticData: function() {
        var a = this.appWin.getTaskById(this.taskId);
        if (!a.accountMeta) {
            a.accountMeta = SYNO.SDS.Backup.Client.Common.Utils.createAccountMeta();
            if ("synocloud_swift" === this.transferType) {
                a.accountMeta.setSynoCloudDefault()
            }
        }
        if ("synocloud_swift" === this.transferType) {
            this.sendWebAPI({
                compound: {
                    mode: "parallel",
                    stopwhenerror: false,
                    params: [{
                        api: "SYNO.Backup.Task",
                        version: 1,
                        method: "get",
                        params: {
                            task_id: this.taskId,
                            additional: ["repository", "schedule"]
                        }
                    }, {
                        api: "SYNO.Backup.Target",
                        version: 1,
                        method: "get",
                        params: {
                            task_id: this.taskId,
                            additional: ["account_meta"]
                        }
                    }]
                },
                callback: this.loadTaskStaticWithAccountMeta,
                scope: this
            })
        } else {
            this.sendWebAPI({
                api: "SYNO.Backup.Task",
                version: 1,
                method: "get",
                params: {
                    task_id: this.taskId,
                    additional: ["repository", "schedule"]
                },
                callback: this.loadTaskStatic,
                scope: this
            })
        }
    },
    onStartPolling: function() {
        if (!this.pollingTaskID) {
            var a;
            if (this.isImage) {
                a = ["last_bkp_time", "next_bkp_time", "last_bkp_result", "is_modified", "last_bkp_progress", "last_bkp_success_version"]
            } else {
                a = ["last_bkp_time", "next_bkp_time", "last_bkp_result", "is_modified"]
            }
            this.pollingTaskID = this.pollReg({
                webapi: {
                    api: "SYNO.Backup.Task",
                    version: 1,
                    method: "status",
                    params: {
                        task_id: this.taskId,
                        blOnline: true === this.getIsOnline(),
                        additional: a
                    }
                },
                interval: 3,
                immediate: true,
                scope: this,
                status_callback: this.loadTaskDynamic
            })
        }
        this.refreshTargetPolling()
    },
    refreshTaskInfo: function() {
        this.appWin.setStatusBusy();
        var a;
        if (this.isImage) {
            a = ["last_bkp_time", "next_bkp_time", "last_bkp_result", "is_modified", "last_bkp_progress"]
        } else {
            a = ["last_bkp_time", "next_bkp_time", "last_bkp_result", "is_modified"]
        }
        this.sendWebAPI({
            compound: {
                mode: "parallel",
                stopwhenerror: false,
                params: [{
                    api: "SYNO.Backup.Task",
                    version: 1,
                    method: "status",
                    params: {
                        task_id: this.taskId,
                        blOnline: true === this.getIsOnline(),
                        additional: a
                    }
                }, {
                    api: "SYNO.Backup.Task",
                    version: 1,
                    method: "get",
                    params: {
                        task_id: this.taskId,
                        additional: ["repository", "schedule"]
                    }
                }]
            },
            callback: this.loadTask,
            scope: this
        })
    },
    loadTask: function(b, a) {
        if (!b) {
            this.appWin.clearStatusBusy();
            return
        }
        this.loadTaskDynamic(a.result[0].success, a.result[0].data);
        this.loadTaskStatic(a.result[1].success, a.result[1].data)
    },
    refreshTargetPolling: function() {
        if (("broken" === this.taskState && false === this.getIsOnline()) || ("unauth" === this.taskState && false === this.getIsOnline())) {
            this.stopTargetPolling();
            return
        }
        var b = {};
        if (false === this.getIsOnline()) {
            b = {
                additional: ["is_online"],
                interval: 120
            }
        } else {
            if ("canceling" === this.taskStatus || "relink" === this.taskStatus || "delete" === this.taskStatus || "broken" === this.taskState || !this.isImage) {
                b = {
                    additional: ["is_online"],
                    interval: 30
                }
            } else {
                if ("backup" === this.taskStatus || "importable" === this.taskState) {
                    b = {
                        additional: ["is_online", "used_size"],
                        interval: 30
                    }
                } else {
                    if ("relinkable" === this.taskState) {
                        b = {
                            additional: ["is_online", "used_size", "check_auth"],
                            interval: 30
                        }
                    } else {
                        if (this.isCalculatingSpace) {
                            b = {
                                additional: ["is_online", "used_size", "check_auth"],
                                interval: 3
                            }
                        } else {
                            if ("suspend" === this.taskLastResult || "discard_failed" === this.taskStatus) {
                                b = {
                                    additional: ["is_online", "used_size", "check_task_key", "check_auth", "suspend_runtime_button"],
                                    interval: 30
                                }
                            } else {
                                b = {
                                    additional: ["is_online", "used_size", "check_task_key", "check_auth", "account_meta"],
                                    interval: 30
                                };
                                if (this.destStatusLoaded) {
                                    b.additional.push("update_account_meta")
                                }
                            }
                        }
                    }
                }
            }
        }
        if (this.spaceUndetermined()) {
            b.additional.remove("used_size")
        }
        var c = JSON.stringify(b);
        if (!Ext.isEmpty(this.pollingTargetID[c])) {
            return
        }
        for (var a in this.pollingTargetID) {
            if (this.pollingTargetID.hasOwnProperty(a) && a !== c) {
                this.stopTargetPollingID(a)
            }
        }
        this.pollingTargetID[c] = this.pollReg({
            webapi: {
                api: "SYNO.Backup.Target",
                version: 1,
                method: "get",
                params: {
                    task_id: this.taskId,
                    additional: b.additional
                }
            },
            interval: b.interval,
            immediate: true,
            scope: this,
            status_callback: this.loadTarget
        })
    },
    settingClickHandler: function(a) {
        if (!a) {
            return
        }
        var b = a.getTemplateTarget();
        Ext.each(Ext.query("div.detail-value .detail-value-link", b.dom), function(e) {
            var d = Ext.fly(e);
            var c = e.className.split(" ");
            Ext.each(c, function(f) {
                if ("open_filter" === f) {
                    d.on("click", function() {
                        this.openEditWindow({
                            openFilterPage: true
                        })
                    }, this);
                    return false
                }
            }, this)
        }, this)
    },
    openEditWindow: function(c) {
        var b = this.appWin.getTaskById(this.taskId);
        var d = {
            targetType: this.targetType,
            transferType: this.transferType,
            isImage: this.isImage,
            isSuspended: ("suspend" === this.taskLastResult),
            isDiscard: ("discard" === this.taskLastResult),
            isOnline: this.getIsOnline(),
            taskState: this.taskState,
            owner: this.appWin,
            appWin: this.appWin,
            taskId: this.taskId,
            repoId: this.repoId,
            accountMeta: b.accountMeta,
            appInstance: this.findAppWindow().appInstance
        };
        Ext.apply(d, c);
        var a = new SYNO.SDS.Backup.TaskEditDialog(d);
        this.mon(a, "close", this.loadStaticData, this);
        this.openWindow(a);
        return a
    },
    stopTargetPollingID: function(a) {
        if (!Ext.isEmpty(this.pollingTargetID[a])) {
            this.pollUnreg(this.pollingTargetID[a]);
            delete this.pollingTargetID[a]
        }
    },
    stopTargetPolling: function() {
        for (var a in this.pollingTargetID) {
            if (this.pollingTargetID.hasOwnProperty(a)) {
                this.stopTargetPollingID(a)
            }
        }
    },
    onStopPolling: function() {
        if (this.pollingTaskID) {
            this.pollUnreg(this.pollingTaskID);
            this.pollingTaskID = null
        }
        this.stopTargetPolling()
    },
    loadTaskStatic: function(j, d, a) {
        if (!j) {
            this.appWin.clearStatusBusy();
            return
        }
        var e = d.target_id;
        if (".hbk" === d.target_id.slice(-4, d.target_id.length)) {
            e = e.slice(0, e.lastIndexOf(".hbk"))
        }
        this.loadDestData({
            repository: d.repository,
            targetId: e
        });
        this.repo = d.repository;
        var i = {};
        Ext.each(d.source.folder_list, function(o, l, n) {
            var m, p = 0;
            var q = o.folderPath.split("/");
            if (!this.isImage && o.dataEncryped && (2 < q.length)) {
                m = q[1];
                p = 1
            } else {
                m = SYNO.Backup.Util.getSharePath(o.folderPath)
            }
            if (m in i) {
                i[m] += p
            } else {
                i[m] = p
            }
        }, this);
        var h = [];
        Ext.iterate(i, function(l, m) {
            if (m > 0) {
                h.push(l + "/" + m + " " + _T("backup", "folders"))
            } else {
                h.push(l.substr(1))
            }
        }, this);
        h.sort();
        var c = {
            folder: 0 !== h.length ? h.join(", ") : _T("common", "none"),
            app: 0 !== d.source.app_name_list.length ? d.source.app_name_list.join(", ") : _T("common", "none"),
            schedule: this.getScheduleStr(d.schedule),
            data_enc: d.data_enc
        };
        if (SYNO.Backup.Util.IsImage(d.target_type)) {
            var b = [];
            var g = [];
            b = b.concat(d.source.backup_filter.whitelist);
            g = g.concat(SYNO.Backup.Util.ExtractPattern(d.source.backup_filter.exclude_list, "file"));
            var f = "";
            if (0 < d.source.backup_volumes.length) {
                var k = [];
                Ext.each(d.source.backup_volumes, function(l) {
                    k.push(SYNO.Backup.Util.parseVolName(l))
                });
                f = k.join(", ")
            } else {
                f = _T("common", "none")
            }
            Ext.apply(c, {
                volume: f,
                filter: (0 < b.length || 0 < g.length) ? SYNO.SDS.Backup.String("app", "on") : SYNO.SDS.Backup.String("app", "off"),
                filterLinkText: (0 < b.length || 0 < g.length) ? SYNO.SDS.Backup.String("app", "version_detail") : "",
                filterHandleFn: "open_filter"
            })
        }
        this.loadSettingData(c);
        this.appWin.clearStatusBusy()
    },
    loadTaskStaticWithAccountMeta: function(c, b) {
        if (!c) {
            this.appWin.clearStatusBusy();
            return
        }
        this.loadTaskStatic(b.result[0].success, b.result[0].data);
        if (b.result[1].success && !Ext.isEmpty(b.result[1].data.account_meta)) {
            var a = this.appWin.getTaskById(this.taskId);
            a.accountMeta.setData(b.result[1].data.account_meta)
        }
    },
    lastResultHasVersion: function(a) {
        return undefined !== a && 0 < Number(a)
    },
    getLastBkpTextCls: function(a) {
        if (!this.isEnableBrowse() || !this.lastResultHasVersion(a)) {
            return ""
        }
        return "last-bkp-version-link"
    },
    setBkpTime: function(d, b, f) {
        this.callParent(arguments);
        var e = this.getStatusPanel().getComponent("statusCard").getComponent("idle");
        if (!e || !e.isVisible()) {
            return
        }
        var a;
        try {
            a = e.getComponent("timeText").getEl().select("." + this.getLastBkpTextCls(f))
        } catch (c) {
            return
        }
        if (!a) {
            return
        }
        a.on("click", function() {
            if (this.isTaskVerified(this.appWin.getTaskById(this.taskId))) {
                this.launchVersionList(f)
            } else {
                this.launchPasswordWindow(function() {
                    this.launchVersionList(f)
                })
            }
        }, this)
    },
    getDestData: function(a) {
        var c = [];
        var b = SYNO.Backup.Addon.Util.getFunc(this.addonInfo.id, "Destination.getInfo");
        if (!Ext.isDefined(a)) {
            a = {
                repository: {},
                targetId: undefined
            }
        }
        a.isImage = this.isImage;
        a.taskState = this.taskState;
        a.stringSection = this.addonInfo.stringSection;
        a.regionWebLink = this.addonInfo.options.regionWebLink;
        a.popupIcon = this.addonInfo.options.popupIcon;
        a.targetType = this.targetType;
        a.transferType = this.transferType;
        if (!Ext.isEmpty(this.destStore)) {
            if (!Ext.isEmpty(this.destStore.getById("space"))) {
                a.spaceUsage = this.destStore.getById("space").get("text")
            }
            if (!Ext.isEmpty(this.destStore.getById("last_detect_time"))) {
                a.lastDetectTime = this.destStore.getById("last_detect_time").get("text")
            }
            if (!Ext.isEmpty(this.destStore.getById("owner_name"))) {
                a.ownerName = this.destStore.getById("owner_name").get("text")
            }
        }
        if (Ext.isFunction(b)) {
            c = b(a)
        }
        Ext.each(c, function(f) {
            f.text = Ext.util.Format.htmlEncode(f.text);
            f.tip = f.text;
            if (Ext.isDefined(f.regionWebLink)) {
                var e = "";
                var d = "";
                if (Ext.isDefined(a.repository.region)) {
                    e = String.format(f.regionWebLink, a.repository.region)
                } else {
                    e = f.regionWebLink
                }
                if (a.popupIcon) {
                    d = '<span class="popup-icon"></span>'
                }
                f.text = String.format('<b><a href="{0}" target="_blank">{1} {2}</a></b>', e, f.text, d)
            }
        });
        return c
    },
    getSettingData: function(b) {
        var a = [{
            key: _T("tree", "leaf_sharefolder"),
            text: b ? Ext.util.Format.htmlEncode(b.folder) : _T("common", "loading")
        }, {
            key: _TT("SYNO.SDS.Backup.Application", "app", "application"),
            text: b ? Ext.util.Format.htmlEncode(b.app) : _T("common", "loading")
        }, {
            key: SYNO.SDS.Backup.String("app", "backup_schedule_title"),
            text: b ? Ext.util.Format.htmlEncode(b.schedule) : _T("common", "loading")
        }];
        if (this.isImage) {
            a.splice(2, 0, {
                key: SYNO.SDS.Backup.String("app", "file_filter_title"),
                text: b ? Ext.util.Format.htmlEncode(b.filter) : _T("common", "loading"),
                link_text: b ? b.filterLinkText : "",
                handle_fn: b ? b.filterHandleFn : ""
            })
        }
        return a
    },
    getScanFileCountStr: function(a) {
        if (a > 0) {
            return SYNO.SDS.Backup.String("app", "scan_file_count") + a
        } else {
            return ""
        }
    },
    getTransFileSizeStr: function(a) {
        var b = function(d, c) {
            if ("local" === c || "image_local" === c) {
                return _T("backup", "written_size") + ": "
            } else {
                if ("rsync_ds" === c || "rsync" === c || "image_remote" === c || "cloud" === d || "cloud_image" === d) {
                    return _T("backup", "transmitted_size") + ": "
                }
            }
            SYNO.Debug("Error: unknown targetType: [" + d + "], transferType: [" + c + "]");
            return ""
        };
        return b(this.targetType, this.transferType) + SYNO.SDS.Backup.ConverSize(a, 2)
    },
    getProgressData: function(f, c, a, b, e) {
        var d = function(k, j, i) {
            var h = parseInt(i, 10);
            if (k.length > 0 && k[0].tran_size > h) {
                k.length = 0
            }
            k.unshift({
                tran_size: h,
                tran_time: new Date().getTime()
            });
            if (k.length > j) {
                k.pop()
            }
            if (k.length > 1) {
                var g = (k[0].tran_size - k[k.length - 1].tran_size) * 1000;
                if (g >= 0) {
                    var l = g / (k[0].tran_time - k[k.length - 1].tran_time);
                    return SYNO.SDS.Backup.ConverSize(l, 2) + "/s"
                } else {
                    return ""
                }
            } else {
                return ""
            }
        };
        return {
            isShowPercentage: true,
            description: f + SYNO.SDS.Backup.String("app", "shared_folder_data"),
            speed: d(this.transSizeBuf, this.WINDOW_SIZE, b),
            percentage: a,
            bottom_description: this.getTransFileSizeStr(b),
            scan_file: this.getScanFileCountStr(e)
        }
    },
    setDetailLinkVisibility: function() {
        if (!this.settingView) {
            return
        }
        var b = this.isEnableEdit();
        var a = this.settingView.getTemplateTarget();
        if (true === b) {
            a.removeClass("hidelink")
        } else {
            if (false === b) {
                a.addClass("hidelink")
            }
        }
    },
    setBtnStatus: function() {
        this.callParent(arguments);
        if (!this.taskStatus || !this.taskState || !this.isImage) {
            return
        }
        var g = this.isEnableBrowse();
        this.browseBtn.disable().setDisabled(!g);
        var b = g;
        this.getDestPanel().buttons[0].setDisabled(!b);
        var f = g && this.getIsSupportStatistics();
        this.statisticBtn.disable().setDisabled(!f);
        var e = (("backup" === this.taskStatus || "waiting" === this.taskStatus) && ("backupable" === this.taskState || "exportable" === this.taskState));
        this.backingupMenu.setDisabled(!e);
        this.backingupMenu.menu.getComponent("btn_suspend").setDisabled(!(e && this.canSuspend));
        var d = ("backupable" === this.taskState || "exportable" === this.taskState) && "resuming" === this.taskLastResult;
        if (d) {
            this.backingupMenu.menu.getComponent("btn_cancel").hide();
            this.backingupMenu.menu.getComponent("btn_cancel_discard").show();
            this.backingupMenu.menu.getComponent("btn_cancel_discard").setDisabled(!(e && this.canCancel))
        } else {
            this.backingupMenu.menu.getComponent("btn_cancel").show();
            this.backingupMenu.menu.getComponent("btn_cancel_discard").hide();
            this.backingupMenu.menu.getComponent("btn_cancel_discard").setDisabled(true)
        }
        var a = (("backupable" === this.taskState || "exportable" === this.taskState) && (("none" === this.taskStatus && "suspend" === this.taskLastResult) || "discard_failed" === this.taskStatus));
        var c = "discard_failed" === this.taskStatus;
        this.suspendedMenu.setDisabled(!a);
        this.suspendedMenu.menu.getComponent("btn_resume").setDisabled(!(true === this.getIsOnline() && a && this.canResume && !c));
        this.suspendedMenu.menu.getComponent("btn_discard").setDisabled(!(true === this.getIsOnline() && a && this.canDiscard))
    },
    getBackupStepStr: function(a, c, b) {
        switch (a) {
            case "data_backup":
                return _T("netbackup", "netbkp_backuping");
            case "prebackup":
                return _T("usbbackup", "usbbkp_init");
            case "backup_prepare":
                return SYNO.SDS.Backup.String("app", "backup_preparing");
            case "config_backup":
                return _T("backup", "bkpstatus_sys");
            case "app_backup":
                if (Ext.isEmpty(b)) {
                    return _T("backup", "bkpstatus_app")
                }
                return c + b;
            case "total_size_count":
                return _T("localbkp", "localbkp_check_dest_size");
            case "backup_complete":
                return SYNO.SDS.Backup.String("app", "backup_completing");
            case "postbackup":
                return _T("backup", "backup_finishing");
            case "canceling":
                return _T("backup", "backup_do_cancel");
            case "rebuild_client_cache":
            case "rebuild_tag":
                return SYNO.SDS.Backup.String("app", "resume_preparing");
            case "upload_queue":
                return _T("common", "none");
            case "wait_server":
                return SYNO.SDS.Backup.String("app", "backup_wait_process")
        }
        return _T("common", "none")
    },
    getRelinkStepStr: function(a) {
        switch (a) {
            case "prerelink":
                return _T("usbbackup", "usbbkp_init");
            case "total_size_count":
                return _T("localbkp", "localbkp_check_dest_size");
            case "download":
                return _T("dashboard_version", "downloading");
            case "rebuild_index":
                return _T("backup", "transmitted_size");
            case "postrelink":
                return _T("backup", "backup_finishing");
            case "canceling":
                return _T("backup", "backup_do_cancel")
        }
        return _T("common", "none")
    },
    getAppStageStr: function(a) {
        if (Ext.isEmpty(a)) {
            return ""
        }
        return String.format(SYNO.SDS.Backup.String("app", "backing_up_app_something"), a)
    },
    spaceUndetermined: function() {
        if (("backupable" === this.taskState && "backup" === this.taskStatus && "backup_prepare" === this.backup_step) || ("backupable" === this.taskState && "suspending" === this.taskStatus)) {
            return true
        } else {
            return false
        }
    },
    setTaskDetailStatus: function(s) {
        var g = (this.taskStatus !== null && this.taskStatus !== s.status);
        var n = (this.taskLastResult !== s.last_bkp_result && "suspend" === s.last_bkp_result);
        if (g || n) {
            var c = [];
            if (!g && n || "discard_failed" === s.status) {
                c = ["is_online", "suspend_runtime_button"]
            } else {
                if ("none" === s.status && "suspend" === s.last_bkp_result) {
                    c = ["is_online", "check_task_key", "check_auth", "suspend_runtime_button"]
                } else {
                    c = ["is_online", "check_task_key", "check_auth"]
                }
            }
            this.sendWebAPI({
                api: "SYNO.Backup.Target",
                version: 1,
                method: "get",
                params: {
                    task_id: this.taskId,
                    additional: c
                },
                scope: this,
                callback: this.loadTarget
            })
        }
        if (g && "discarding" === this.taskStatus) {
            this.usedSize = -1;
            this.usedSizeCache = -1;
            this.updateSpace(this.sourceSize, this.usedSize, this.usedSizeCache)
        }
        var e = Ext.isEmpty(s.progress) ? "" : s.progress.title_type;
        this.canSuspend = Ext.isEmpty(s.progress) ? false : (true === s.progress.can_suspend);
        if (this.isImage) {
            this.canCancel = !Ext.isEmpty(s.progress) && (true === s.progress.can_cancel)
        }
        this.setTaskStatus(s.state, s.status, s.last_bkp_time, s.last_bkp_result, s.last_bkp_error_code, s.last_bkp_error, s.is_modified, e);
        this.transSize = 0;
        if (s.status === "canceling" || s.status === "waiting" || s.status === "preparing_version_delete" || s.status === "relink_waiting" || s.status === "deleting" || s.status === "suspending") {
            this.setProgress({
                isShowPercentage: false,
                description: "",
                bottom_description: "",
                scan_file: ""
            })
        } else {
            if (s.status === "backup") {
                this.backup_step = s.progress ? s.progress.step : "none";
                var o = s.progress ? s.progress.current_app : "";
                var p = s.progress ? s.progress.current_app_stage : "";
                var i = s.progress ? s.progress.app_list : [];
                var a = s.progress ? s.progress.app_done_list : [];
                var l = "(" + (a.length + 1).toString() + "/" + (i.length + 1).toString() + "): ";
                var f = this.getBackupStepStr(this.backup_step, l, o);
                var k = s.progress ? s.progress.progress : 0;
                var d = s.progress ? s.progress.current_app_percent : 0;
                var r = s.progress ? s.progress.scan_file_count : 0;
                var m = s.progress ? s.progress.transmitted_size : 0;
                if (this.backup_step === "data_backup" || this.backup_step === "upload_queue") {
                    this.setProgress(this.getProgressData(l, this.backup_step, k, m, r));
                    this.transSize = m / 1024;
                    if (0 < this.usedSize) {
                        this.updateSpace(this.sourceSize, this.usedSize + this.transSize, this.usedSizeCache)
                    }
                } else {
                    if (this.backup_step == "app_backup") {
                        this.setProgress({
                            isShowPercentage: true,
                            description: f,
                            scan_file: "",
                            bottom_description: this.getAppStageStr(p),
                            percentage: d
                        })
                    } else {
                        if (this.backup_step === "backup_prepare") {
                            this.setProgress({
                                isShowPercentage: false,
                                description: f,
                                bottom_description: "",
                                scan_file: ""
                            })
                        } else {
                            if (this.backup_step === "postbackup") {
                                this.setProgress({
                                    isShowPercentage: true,
                                    description: f,
                                    speed: "",
                                    percentage: k,
                                    bottom_description: this.getTransFileSizeStr(m),
                                    scan_file: this.getScanFileCountStr(r)
                                })
                            } else {
                                this.setProgress({
                                    isShowPercentage: false,
                                    description: f,
                                    bottom_description: "",
                                    scan_file: ""
                                })
                            }
                        }
                    }
                }
            } else {
                if (s.status === "relink") {
                    var j = s.progress ? s.progress.step : "none";
                    var h = this.getRelinkStepStr(j);
                    if (j === "download" || j === "rebuild_index") {
                        this.setProgress({
                            isShowPercentage: true,
                            description: h,
                            speed: "",
                            percentage: s.progress ? s.progress.progress : 0,
                            bottom_description: "",
                            scan_file: ""
                        })
                    } else {
                        this.setProgress({
                            isShowPercentage: false,
                            description: h,
                            bottom_description: "",
                            scan_file: ""
                        })
                    }
                } else {
                    if ("detect" === s.status) {
                        var b = s.progress ? s.progress.stage : "none";
                        if ("detect_index" === b) {
                            this.setProgress({
                                isShowPercentage: true,
                                description: SYNO.SDS.Backup.String("app", "detect_index_progress"),
                                percentage: s.progress ? s.progress.progress : 0,
                                bottom_description: "",
                                scan_file: ""
                            })
                        } else {
                            if ("detect_data" === b) {
                                this.setProgress({
                                    isShowPercentage: true,
                                    description: SYNO.SDS.Backup.String("app", "detect_data_progress"),
                                    percentage: s.progress ? s.progress.progress : 0,
                                    bottom_description: "",
                                    scan_file: ""
                                })
                            } else {
                                if ("detect_cloud_data" === b) {
                                    this.setProgress({
                                        isShowPercentage: true,
                                        description: SYNO.SDS.Backup.String("app", "detect_cloud_progress"),
                                        percentage: s.progress ? s.progress.progress : 0,
                                        bottom_description: "",
                                        scan_file: ""
                                    })
                                } else {
                                    this.setProgress({
                                        isShowPercentage: false,
                                        description: SYNO.SDS.Backup.String("app", "backup_preparing"),
                                        bottom_description: "",
                                        scan_file: ""
                                    })
                                }
                            }
                        }
                    } else {
                        if ("detect_waiting" === s.status) {
                            this.setProgress({
                                isShowPercentage: false,
                                description: SYNO.SDS.Backup.String("app", "task_status_check"),
                                bottom_description: "",
                                scan_file: ""
                            })
                        } else {
                            if ("discarding" === s.status) {
                                this.setProgress({
                                    isShowPercentage: true,
                                    speed: "",
                                    percentage: s.progress ? s.progress.progress : 0,
                                    description: "",
                                    bottom_description: "",
                                    scan_file: ""
                                })
                            } else {
                                if ("backupable" === s.state && "version_deleting" === s.status) {
                                    var q = function(t) {
                                        if (!t) {
                                            return ""
                                        }
                                        if ("unlink_version" === t.stage) {
                                            return String.format(SYNO.SDS.Backup.String("app", "deleting_version_desc"), SYNO.SDS.Backup.Client.Common.Utils.getDSMStyleDateTimeString(t.version_create_time * 1000, {
                                                type: "datetimesec"
                                            }))
                                        }
                                        if ("compact" === t.stage) {
                                            return SYNO.SDS.Backup.String("app", "deleting_version_compact")
                                        }
                                    };
                                    this.setProgress({
                                        isShowPercentage: s.progress ? true : false,
                                        speed: "",
                                        percentage: s.progress ? s.progress.progress : 0,
                                        description: q(s.progress),
                                        bottom_description: "",
                                        scan_file: ""
                                    })
                                } else {
                                    if ("backupable" === s.state && "none" === s.status && "suspend" === s.last_bkp_result) {
                                        this.setSuspendedProgress({
                                            isShowPercentage: s.last_bkp_progress ? true : false,
                                            percentage: s.last_bkp_progress ? s.last_bkp_progress : 0,
                                            bottom_description: "",
                                            scan_file: ""
                                        })
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        if (this.spaceUndetermined()) {
            this.usedSize = -1;
            this.usedSizeCache = -1;
            this.updateSpace(this.sourceSize, this.usedSize, this.usedSizeCache)
        }
        if (true === this.getIsOnline() && true === this.isImage && false === this.skipCheckLastResult && "backupable" === s.state && "none" === s.status && ("failed_checking" === s.last_bkp_result || "backingup" === s.last_bkp_result || "resuming" === s.last_bkp_result)) {
            this.updateLastResult()
        }
    },
    loadTaskDynamic: function(c, a, b) {
        if (this.isDestroyed) {
            return
        }
        if (this.skipNextWebAPI) {
            this.skipNextWebAPI = false;
            return
        }
        if (!c) {
            if (SYNO.SDS.Backup.ERR_INTERNAL_ERROR === a.code && a.errors && "task_not_exist" === a.errors.description) {
                this.appWin.deleteCurrentTask()
            }
            return
        }
        this.setTaskDetailStatus(a);
        this.setBkpTime(a.last_bkp_success_time, a.next_bkp_time, a.last_bkp_success_version);
        this.refreshTargetPolling()
    },
    loadDestStatus: function(d, a, b) {
        var e;
        var c;
        if (!d) {
            e = a.errors ? a.errors.is_online : false;
            if ((4442 === a.code) && ("rsync_ds" === this.transferType || "rsync" === this.transferType)) {
                c = SYNO.SDS.Backup.String("error", "rsync_service_disable")
            } else {
                if ((4442 === a.code) && ("image_remote" === this.transferType)) {
                    c = SYNO.SDS.Backup.String("error", "remote_service_disable")
                } else {
                    c = SYNO.SDS.Backup.GetErrorStringEx(a)
                }
            }
            if (c === _T("error", "error_error_system")) {
                c = SYNO.SDS.Backup.String("error", "general_backup_destination_disconnect")
            }
        } else {
            e = a.is_online
        }
        e = e ? true : false;
        if (false === e && "exportable" === this.taskState && "synocloud_swift" === this.transferType) {
            if (!Ext.isEmpty(this.repo) && this.repo.share === "/mnt/synology_cloud_export_share" && 1 > this.reconnectTimes) {
                this.reconnectTimes++;
                this.remountFireball()
            }
        }
        this.setIsOnline(e, c);
        if (!this.destStatusLoaded) {
            this.destStatusLoaded = true
        }
    },
    loadTarget: function(g, c, b, e) {
        if (this.isDestroyed) {
            return
        }
        if (!g && "broken" === this.taskState) {
            this.stopTargetPolling()
        }
        if (!Ext.isEmpty(c.can_resume)) {
            this.canResume = c.can_resume
        }
        if (!Ext.isEmpty(c.can_discard)) {
            this.canDiscard = c.can_discard
        }
        this.isCalculatingSpace = false;
        this.loadDestStatus(g, c, b);
        this.setBtnStatus();
        if (Ext.isObject(c.capability)) {
            this.setIsSupportStatistics(c.capability.support_statistics)
        }
        if (!Ext.isEmpty(c.account_meta)) {
            var a = this.appWin.getTaskById(this.taskId);
            a.accountMeta.setData(c.account_meta)
        }
        if (0 <= b.additional.indexOf("used_size")) {
            this.sourceSize = c.source_size;
            this.usedSize = c.used_size;
            this.usedSizeCache = c.used_size_cache;
            this.updateSpace(c.source_size, this.usedSize + this.transSize, c.used_size_cache)
        }
        var d = this.destStore.getById("owner_name");
        if (d) {
            if (!Ext.isEmpty(c.owner_name)) {
                d.set("text", c.owner_name)
            } else {
                d.set("text", SYNO.SDS.Backup.String("app", "not_available"))
            }
        }
        var f = this.destStore.getById("last_detect_time");
        if (f) {
            if ("error_detect" === this.taskState) {
                f.set("text", SYNO.SDS.Backup.String("app", "detect_result_doing"));
                f.set("tip", SYNO.SDS.Backup.String("app", "detect_result_doing"))
            } else {
                if (!Ext.isEmpty(c.last_detect_time)) {
                    f.set("text", SYNO.SDS.Backup.Client.Common.Utils.getDSMStyleDateTimeString(c.last_detect_time));
                    f.set("tip", SYNO.SDS.Backup.Client.Common.Utils.getDSMStyleDateTimeString(c.last_detect_time))
                } else {
                    f.set("text", SYNO.SDS.Backup.String("app", "detect_result_none"));
                    f.set("tip", SYNO.SDS.Backup.String("app", "detect_result_none"))
                }
            }
        }
        this.refreshTargetPolling()
    },
    updateSpace: function(d, g, c) {
        var f = this.destStore.getById("space");
        if (f) {
            var a = "";
            if (this.isCloudImage) {
                var b = this.appWin.getTaskById(this.taskId);
                var e = g;
                if (SYNO.SDS.Backup.Client.Common.Utils.AccountMeta.SPACE_SOURCE === b.accountMeta.spaceUsage && Ext.isDefined(d)) {
                    e = d
                }
                f.set("text", this.getSpaceStr(this.getIsOnline(), e));
                f.set("tip", this.getCloudSpaceTip(this.getIsOnline(), e, c))
            } else {
                a = this.getSpaceStr(this.getIsOnline(), g);
                f.set("text", a);
                f.set("tip", a)
            }
        }
    },
    getSpaceStr: function(c, b) {
        var a = "";
        if (!c) {
            a = SYNO.SDS.Backup.String("app", "not_available")
        } else {
            if (undefined === b) {
                a = _T("error", "error_error")
            } else {
                if (-1 === b) {
                    this.isCalculatingSpace = true;
                    a = _T("backup", "calculating")
                } else {
                    a = SYNO.SDS.Backup.ConverSize(b * 1024, 2)
                }
            }
        }
        return a
    },
    getCloudSpaceTip: function(e, d, a) {
        if (!e) {
            return SYNO.SDS.Backup.String("app", "not_available")
        } else {
            var c = _T("backup", "bkp_storage") + ": " + this.getSpaceStr(e, d);
            var b = SYNO.SDS.Backup.String("app", "index_size") + ": " + this.getSpaceStr(e, a);
            return String.format("{0}<br/>{1}", c, b)
        }
    },
    onDetectTarget: function() {
        if (this.isTaskVerified(this.appWin.getTaskById(this.taskId))) {
            this.prepareDetectTarget()
        } else {
            this.launchPasswordWindow(this.prepareDetectTarget)
        }
    },
    prepareDetectTarget: function() {
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            version: 1,
            method: "status",
            params: {
                task_id: this.taskId,
                required_idx_major: 0,
                required_idx_minor: 3,
                required_idx_sub_minor: 3,
                additional: ["version_cmp"]
            },
            scope: this,
            callback: function(c, a, b) {
                this.owner.clearStatusBusy();
                if (!c) {
                    this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(a.code));
                    return
                }
                this.alertDetectTarget(a.status, false)
            }
        })
    },
    alertDetectTarget: function(b, a) {
        var c = new SYNO.SDS.Backup.AlertWindow({
            appWin: this.appWin,
            owner: this.appWin,
            yesBtnText: _T("common", "ok"),
            noBtnText: _T("common", "cancel"),
            width: 486,
            height: (1 === b || 6 === b) && !a ? 285 : 335,
            title: SYNO.SDS.Backup.String("app", "detect_title"),
            formItems: [{
                xtype: "syno_displayfield",
                value: SYNO.SDS.Backup.String("app", "detect_after_import"),
                hidden: !a
            }, {
                xtype: "syno_displayfield",
                value: "1. " + SYNO.SDS.Backup.String("error", "target_busy_protect_rollback"),
                hidden: 1 === b || 6 === b || a
            }, {
                xtype: "syno_displayfield",
                value: ((1 === b || 6 === b) ? "" : "2. ") + SYNO.SDS.Backup.String("app", this.isCloudImage ? "incheck_cloud_desc" : "incheck_desc"),
                hidden: a
            }, {
                xtype: "syno_checkbox",
                name: "detect_data",
                checked: a || this.isCloudImage,
                disabled: a,
                hidden: this.isCloudImage,
                boxLabel: SYNO.SDS.Backup.String("app", "detect_data")
            }, {
                xtype: "syno_displayfield",
                value: SYNO.SDS.Backup.String("app", "detect_data_warning")
            }],
            callback: Ext.createDelegate(function(f, e) {
                if ("yes" === f) {
                    var d = this.appWin.getTaskById(this.taskId);
                    this.appWin.setStatusBusy();
                    this.sendWebAPI({
                        api: "SYNO.Backup.Target",
                        version: 1,
                        method: "error_detect",
                        params: {
                            task_id: this.taskId,
                            detect_data: "true" === e.detect_data,
                            sessId: d.sess_id,
                            sessKey: d.sess_key
                        },
                        scope: this,
                        callback: function(i, g, h) {
                            if (!i) {
                                this.owner.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(g.code), function() {
                                    if (SYNO.SDS.Backup.ERR_SESSION_EXPIRED === g.code) {
                                        this.owner.clearCurTaskSession()
                                    }
                                }, this)
                            } else {
                                this.setTaskDetailStatus({
                                    state: "error_detect",
                                    status: "detect"
                                })
                            }
                            this.appWin.clearStatusBusy()
                        }
                    });
                    this.skipNextWebAPI = true
                }
            }, this)
        });
        this.openWindow(c)
    },
    onEditBackupTask: function(a) {
        var b = this.openEditWindow();
        if (Ext.isString(a)) {
            b.getComponent("edit_tab_panel").setActiveTab(a)
        }
    },
    onDeleteBackupTask: function() {
        var b = this.taskId;
        var a = function(c) {
            if ("yes" !== c) {
                return
            }
            this.findAppWindow().setStatusBusy();
            this.sendWebAPI({
                api: "SYNO.Backup.Task",
                version: 1,
                method: "delete",
                params: {
                    task_id_list: [b],
                    is_remove_data: false
                },
                callback: function(f, d, e) {
                    this.findAppWindow().clearStatusBusy();
                    if (!f) {
                        this.findAppWindow().getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(d.code));
                        return
                    }
                    this.setTaskDetailStatus({
                        state: "broken",
                        status: "deleting"
                    })
                },
                scope: this
            })
        };
        this.findAppWindow().getMsgBox().confirmDelete("", _T("backup", "backup_confirm_delete_task"), a, this)
    },
    launchPasswordWindow: function(a) {
        var b = this.appWin.getTaskById(this.taskId);
        var d = {
            task_id: b.task_id,
            repo_id: b.repo_id,
            target_id: b.target_id
        };
        var c = new SYNO.SDS.Backup.Client.Common.Password.Window({
            owner: this.appWin,
            verify_params: d,
            setter: Ext.createDelegate(this.appWin.setCurTaskSession, this.appWin),
            callback: Ext.createDelegate(a, this, [])
        });
        this.openWindow(c)
    },
    doCancelBackup: function() {
        this.appWin.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Task",
            version: 1,
            method: "cancel",
            params: {
                task_id: this.taskId,
                task_state: this.taskState
            },
            scope: this,
            callback: function(c, a, b) {
                if (!c) {
                    this.appWin.clearStatusBusy();
                    this.appWin.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(a.code));
                    return
                }
                this.setTaskDetailStatus({
                    state: this.taskState,
                    status: "canceling"
                });
                this.appWin.clearStatusBusy()
            }
        })
    },
    doCancelAndDiscard: function() {
        this.appWin.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Task",
            version: 1,
            method: "cancel_and_discard",
            params: {
                task_id: this.taskId
            },
            scope: this,
            callback: function(c, a, b) {
                if (!c) {
                    this.appWin.clearStatusBusy();
                    this.appWin.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(a.code));
                    return
                }
                this.setTaskDetailStatus({
                    state: this.taskState,
                    status: "canceling"
                });
                this.appWin.clearStatusBusy()
            }
        })
    },
    doCancelErrorDetect: function() {
        this.appWin.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            version: 1,
            method: "error_detect_cancel",
            params: {
                task_id: this.taskId
            },
            scope: this,
            callback: function(c, a, b) {
                if (!c) {
                    this.appWin.clearStatusBusy();
                    this.appWin.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(a.code));
                    return
                }
                this.setTaskDetailStatus({
                    state: this.taskState,
                    status: "canceling"
                });
                this.appWin.clearStatusBusy()
            }
        })
    },
    doSuspendBackup: function() {
        this.appWin.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Task",
            version: 1,
            method: "suspend",
            params: {
                task_id: this.taskId,
                task_state: this.taskState
            },
            scope: this,
            callback: function(c, a, b) {
                if (!c) {
                    this.appWin.clearStatusBusy();
                    this.appWin.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(a.code));
                    return
                }
                this.setTaskDetailStatus({
                    state: this.taskState,
                    status: "suspending"
                });
                this.appWin.clearStatusBusy()
            }
        })
    },
    doDiscard: function() {
        this.appWin.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Task",
            version: 1,
            method: "discard",
            params: {
                task_id: this.taskId
            },
            scope: this,
            callback: function(c, a, b) {
                if (!c) {
                    this.appWin.clearStatusBusy();
                    this.appWin.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorStringEx(a));
                    return
                }
                this.setTaskDetailStatus({
                    state: this.taskState,
                    status: "discarding",
                    progress: {
                        progress: 0
                    }
                });
                this.appWin.clearStatusBusy()
            }
        })
    },
    onBackupNow: function() {
        this.appWin.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Task",
            version: 1,
            method: "backup",
            params: {
                task_id: this.taskId
            },
            scope: this,
            callback: this.onBackupDone
        })
    },
    onImportNow: function() {
        this.isReAuth = false;
        if (this.addonInfo && Ext.isObject(this.addonInfo.oauth)) {
            this.launchOAuthWindow(this.addonInfo)
        } else {
            this.launchImportWizard()
        }
    },
    onRelinkNow: function() {
        this.appWin.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Task",
            version: 1,
            method: "relink",
            timeout: 240000,
            params: {
                task_id: this.taskId
            },
            scope: this,
            callback: this.onRelinkDone
        })
    },
    onReauthNow: function() {
        this.isReAuth = true;
        if (this.addonInfo && Ext.isObject(this.addonInfo.oauth)) {
            this.launchOAuthWindow(this.addonInfo)
        } else {
            this.onEditBackupTask("repo_panel")
        }
    },
    onResumeNow: function() {
        this.appWin.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Task",
            version: 1,
            method: "resume",
            params: {
                task_id: this.taskId
            },
            scope: this,
            callback: this.onResumeDone
        })
    },
    onBackupDone: function(c, a, b) {
        if (!c) {
            this.appWin.clearStatusBusy();
            this.appWin.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorStringEx(a));
            return
        }
        this.setTaskDetailStatus({
            state: this.taskState,
            status: "waiting"
        });
        this.appWin.clearStatusBusy()
    },
    onRelinkDone: function(c, a, b) {
        if (!c) {
            this.appWin.clearStatusBusy();
            this.appWin.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(a.code));
            return
        }
        this.setTaskDetailStatus({
            state: this.taskState,
            status: "relink_waiting"
        });
        this.appWin.clearStatusBusy()
    },
    onReauthDone: function(c, a, b) {
        if (!c) {
            this.appWin.clearStatusBusy();
            this.appWin.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorString(a.code));
            return
        }
        this.setIsOnline(true, "");
        this.setTaskDetailStatus({
            state: "backupable",
            status: "none"
        });
        this.appWin.clearStatusBusy()
    },
    onResumeDone: function(c, a, b) {
        if (!c) {
            this.appWin.clearStatusBusy();
            this.appWin.getMsgBox().alert(_T("leaf", "backup"), SYNO.SDS.Backup.GetErrorStringEx(a));
            return
        }
        this.setTaskDetailStatus({
            state: this.taskState,
            status: "waiting"
        });
        this.appWin.clearStatusBusy()
    },
    onVersionList: function() {
        if (this.isTaskVerified(this.appWin.getTaskById(this.taskId))) {
            this.launchVersionList()
        } else {
            this.launchPasswordWindow(this.launchVersionList)
        }
    },
    launchVersionList: function(c) {
        var b = this.appWin.getTaskById(this.taskId);
        var a = new SYNO.SDS.Backup.Client.Common.Version.MainWindow({
            taskId: this.taskId,
            repoId: this.repoId,
            targetId: this.targetId,
            targetType: this.targetType,
            transferType: this.transferType,
            isDiscard: ("discard" === this.taskLastResult),
            sessId: b.sess_id,
            sessKey: b.sess_key,
            taskState: this.taskState,
            appWin: this.appWin,
            owner: this.appWin,
            hideVersionDelete: (SYNO.SDS.Backup.Client.Common.Utils.AccountMeta.ABILITY_DISABLE === b.accountMeta.versionDelete || ("discard" === this.taskLastResult)),
            hideVersionLock: (SYNO.SDS.Backup.Client.Common.Utils.AccountMeta.ABILITY_DISABLE === b.accountMeta.versionLock),
            accountMeta: b.accountMeta,
            openVersion: c
        });
        this.openWindow(a)
    },
    onStatisticBrowse: function() {
        var a = this.appWin.getTaskById(this.taskId);
        var c = (SYNO.SDS.Backup.Client.Common.Utils.AccountMeta.STATISTICS_SOURCE !== a.accountMeta.statisticsDisplay);
        var b = new SYNO.SDS.Backup.Client.Common.Statistic.MainWindow({
            title: SYNO.SDS.Backup.String("statistics", "storage_statistics_title"),
            taskId: this.taskId,
            appWin: this.appWin,
            owner: this.appWin,
            supportTargetStatistic: c
        });
        this.openWindow(b)
    },
    onVersionBrowse: function() {
        if (this.isTaskVerified(this.appWin.getTaskById(this.taskId))) {
            this.launchVersionBrowse()
        } else {
            this.launchPasswordWindow(this.launchVersionBrowse)
        }
    },
    isTaskVerified: function(a) {
        return (!a.data_enc || !Ext.isEmpty(a.sess_id))
    },
    launchVersionBrowse: function() {
        var a = this.appWin.getTaskById(this.taskId);
        SYNO.SDS.AppLaunch("SYNO.SDS.Backup.Client.Explore.AppInstance", {
            launchInstance: this.owner,
            taskId: this.taskId,
            sess_id: a.sess_id,
            sess_key: a.sess_key,
            launcher: "BackupAndRestore",
            backend: "HyperBackup-backend"
        })
    },
    launchOAuthWindow: function(b) {
        var a = SYNO.Backup.Addon.Util.getOathWindowParams(b);
        if (!Ext.isObject(a)) {
            return false
        }
        if (!this.winAuth) {
            if (Ext.isIE || Ext.isIE11 || Ext.isIE10) {
                window.cbDSCS = this.authCB.createDelegate(this)
            } else {
                this.cbDSCS = this.receiveMessage.createDelegate(this);
                window.addEventListener("message", this.cbDSCS)
            }
        }
        this.winAuth = (window.open(encodeURI(a.url), "", a.specs));
        return true
    },
    authCB: function(a) {
        this.winAuth = null;
        if (!Ext.isEmpty(a.error)) {
            return
        }
        if (this.isReAuth) {
            this.reauthTask(a.access_token, a.refresh_token, a.openstack_token)
        } else {
            this.launchImportWizard(a)
        }
    },
    receiveMessage: function(a) {
        if ("hyperbackup_oauth" !== a.data.source) {
            return
        }
        window.removeEventListener("message", this.cbDSCS);
        this.authCB(a.data)
    },
    launchImportWizard: function(a) {
        var c = {};
        if (!Ext.isEmpty(a)) {
            c.auth_response = a
        } else {
            c.auth_response = {}
        }
        var b = new SYNO.SDS.Backup.TaskImportWizard(Ext.apply(c, {
            taskId: this.taskId,
            repoId: this.repoId,
            appWin: this.appWin,
            targetType: this.targetType,
            transferType: this.transferType,
            owner: this.appWin
        }));
        this.mon(b, "close", this.refreshTaskInfo, this);
        this.mon(b, "wizardResult", this.ImportWizardCB, this);
        this.openWindow(b)
    },
    ImportWizardCB: function(a) {
        if (a) {
            setTimeout(Ext.createDelegate(function() {
                this.alertDetectTarget(1, true)
            }, this), 1000)
        }
    },
    reauthTask: function(d, b, a) {
        var c = {};
        if ("synocloud_swift" === this.transferType) {
            if (!Ext.isEmpty(d)) {
                c.key = d
            }
            if (!Ext.isEmpty(b)) {
                c.secret = b
            }
            if (!Ext.isEmpty(a)) {
                c.tenant_id = a
            }
        } else {
            if (!Ext.isEmpty(d)) {
                c.remote_access_token = d
            }
            if (!Ext.isEmpty(b)) {
                c.remote_refresh_token = b
            }
        }
        this.appWin.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Task",
            version: 1,
            method: "reauth",
            params: Ext.apply(c, {
                task_id: this.taskId
            }),
            callback: this.onReauthDone,
            scope: this
        })
    },
    updateLastResult: function() {
        this.skipCheckLastResult = true;
        this.sendWebAPI({
            api: "SYNO.Backup.Target",
            version: 1,
            method: "status",
            params: {
                task_id: this.taskId,
                update_last_result: true
            },
            scope: this,
            callback: function(c, a, b) {
                this.skipCheckLastResult = false
            }
        })
    },
    remountFireball: function() {
        var a = {};
        a.fireball_url = this.repo.dest;
        a.fireball_mount_source = ":/volume1/synology_cloud_export_share";
        a.fireball_mount_target = "/mnt/synology_cloud_export_share";
        this.sendWebAPI({
            api: "SYNO.Backup.Repository",
            version: 1,
            method: "mount_fireball",
            params: a,
            scope: this,
            callback: function(d, b, c) {
                if (!d) {
                    return
                }
                this.onStopPolling();
                this.onStartPolling()
            }
        })
    }
});
Ext.define("SYNO.SDS.Backup.Application", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.Backup.MainWindow"
});
Ext.define("SYNO.SDS.Backup.EmptyPage", {
    extend: "SYNO.ux.Panel",
    initComponent: function() {
        this.callParent(arguments);
        this.addClass("syno-backup-empty-page");
        this.emptyMessage = new Ext.Container({
            width: 330,
            cls: "syno-backup-empty-page-container",
            items: [{
                xtype: "container",
                height: 120,
                width: 120,
                cls: "syno-backup-empty-page-icon"
            }, {
                xtype: "container",
                html: SYNO.SDS.Backup.String("error", "empty_page_message_btn_top"),
                cls: "syno-backup-empty-page-text"
            }]
        });
        this.add(this.emptyMessage)
    },
    onStartPolling: function() {},
    onStopPolling: function() {}
});
Ext.define("SYNO.SDS.Backup.MainWindow", {
    extend: "SYNO.SDS.Backup.PageListAppWindow",
    emptyPageId: "syno_backup_empty_page",
    emptyPageFn: "SYNO.SDS.Backup.EmptyPage",
    constructor: function(a) {
        this.pollingID = null;
        this.listPanel = null;
        this.isRestoreWinShow = false;
        this.loadFirstDone = false;
        var f = {
            xtype: "syno_button",
            btnStyle: "blue",
            tooltip: _T("common", "create"),
            iconCls: "syno-sds-backup-create-icon",
            margins: "0 6px 0 0",
            cls: "syno-sds-backup-btn"
        };
        if (this._D("support_iscsi_lunbkp", "no") === "yes" && !_S("systemdr_running")) {
            var e = [{
                text: _T("lunbkp", "data_bkp_task"),
                useBuffer: true,
                listeners: {
                    click: this.openCreateWizard,
                    scope: this
                }
            }, {
                text: _T("lunbkp", "lun_bkp_task"),
                useBuffer: true,
                disabled: !_S("is_admin"),
                listeners: {
                    click: this.onCreateLUNBackup,
                    afterrender: function(g) {
                        if (!_S("is_admin")) {
                            g.getEl().select("span").elements[0].setAttribute("ext:qtip", SYNO.SDS.Backup.String("app", "only_admin_able_lun"))
                        }
                    },
                    scope: this
                }
            }];
            Ext.apply(f, {
                menu: {
                    xtype: "syno_menu",
                    items: e,
                    cls: "syno-sds-backup-mainwindow-menu"
                }
            })
        } else {
            Ext.apply(f, {
                handler: this.openCreateWizard,
                scope: this
            })
        }
        var d = {
            xtype: "syno_button",
            tooltip: _S("is_admin") ? _T("netbackup", "netbkp_recovery") : SYNO.SDS.Backup.String("app", "only_admin_able_restore"),
            iconCls: "syno-sds-backup-restore-icon",
            disabled: !_S("is_admin"),
            margins: "0 6px 0 0",
            cls: "syno-sds-backup-btn"
        };
        if (this._D("support_iscsi_lunbkp", "no") === "yes" && !_S("systemdr_running")) {
            var c = [{
                text: _T("lunbkp", "data_restore"),
                useBuffer: true,
                listeners: {
                    click: this.onDataRestore,
                    scope: this
                }
            }, {
                text: _T("lunbkp", "lun_restore"),
                useBuffer: true,
                listeners: {
                    click: this.onLUNRestore,
                    scope: this
                }
            }];
            Ext.apply(d, {
                menu: {
                    xtype: "syno_menu",
                    items: c,
                    cls: "syno-sds-backup-mainwindow-menu"
                }
            })
        } else {
            Ext.apply(d, {
                handler: this.onDataRestore,
                scope: this
            })
        }
        var b = this.callParent([Ext.apply({
            cls: "syno-app-backup",
            width: 990,
            height: 580,
            minWidth: 900,
            minHeight: 580,
            listPanel: this.getListPanel(),
            buttonItems: [f, d, {
                xtype: "syno_button",
                tooltip: _T("tree", "leaf_log"),
                iconCls: "syno-sds-backup-log-icon",
                cls: "syno-sds-backup-btn",
                handler: this.openLogWindow,
                scope: this
            }]
        }, a)]);
        return b
    },
    getListPanel: function() {
        if (this.listPanel) {
            return this.listPanel
        }
        var a = {
            isRestore: false,
            taskNameList: [],
            sendWebAPI: this.sendWebAPI.createDelegate(this),
            webapi: {
                api: "SYNO.Backup.Task",
                version: 1,
                method: "list"
            },
            baseParams: {
                sort_by: "name",
                additional: ["last_bkp_time", "last_bkp_result", "get_source", "is_modified", "progress_title_type"]
            },
            parseWebApiResponse: function(c, b) {
                this.taskList = b.task_list;
                this.isRestore = b.is_restoring || b.is_snapshot_restoring;
                this.isSnapshotRestore = b.is_snapshot_restoring;
                c.ownerTree.owner.popUpWindowIfNeeded(b.is_data_restoring, b.is_lun_restoring);
                this.taskNameList = [];
                Ext.each(this.taskList, function(d) {
                    this.taskNameList.push(d.name)
                }, this);
                return this.taskList
            },
            getRepoIcon: function(b) {
                var d = {
                    loclunbkp: "syno-backup-task-lun",
                    netlunbkp: "syno-backup-task-lun"
                };
                var c = SYNO.Backup.Addon.Config.addon_list;
                Ext.each(c, function(f) {
                    var e = f.target_type + ":" + f.transfer_type;
                    d[e] = f.taskIconCls
                });
                if (b in d) {
                    return d[b]
                }
                return "syno-backup-task-local"
            },
            createNodeFn: function(b) {
                if ("data" !== b.data_type) {
                    b.state = "backupable"
                }
                b.uiProvider = "SYNO.SDS.Backup.TaskTreeNodeUI";
                b.leaf = true;
                b.text = b.name;
                b.statusIcon = SYNO.SDS.Backup.getStatusIcon(b.state, b.status, b.last_bkp_result, b.is_modified, b.progress_title_type);
                b.iconCls = this.getRepoIcon(b.type);
                if ("data" === b.data_type) {
                    b.id = "" + b.task_id;
                    b.fn = "SYNO.SDS.Backup.Task.DataMainPage";
                    b.pageConfig = {
                        taskState: b.state,
                        taskStatus: b.status,
                        taskLastResult: b.last_bkp_result,
                        taskIcon: b.statusIcon,
                        taskId: b.task_id,
                        repoId: b.repo_id,
                        targetId: b.target_id,
                        targetType: b.target_type,
                        transferType: b.transfer_type
                    }
                } else {
                    b.id = "Lun_" + b.task_id;
                    b.fn = "SYNO.SDS.Backup.Task.LunMainPage";
                    b.pageConfig = {
                        taskState: b.state,
                        taskStatus: b.status,
                        taskIcon: b.statusIcon,
                        taskName: b.name,
                        taskType: b.type
                    }
                }
            }
        };
        this.listPanel = new SYNO.SDS.Backup.ModuleList({
            layout: "fit",
            align: "stretch",
            border: false,
            padding: "4px 16px 0 12px",
            flex: 1,
            owner: this,
            loaderCfg: a
        });
        return this.listPanel
    },
    initEvents: function() {
        this.callParent(arguments);
        this.on("show", function() {
            if (Ext.isEmpty(this.modalWin)) {
                this.onStartPolling()
            }
        });
        this.on("hide", this.onStopPolling);
        this.mon(this.listPanel.loader, "load", this.onLoadFirst, this, {
            single: true
        });
        this.mon(this.listPanel.loader, "loadexception", this.clearStatusBusy, this, {
            single: true
        })
    },
    onLoadFirst: function() {
        SYNO.Backup.Addon.Config.updateAllowList(false, []);
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Backup.Task",
            version: 1,
            method: "get_support_cloud",
            scope: this,
            callback: function(e, c, d) {
                this.clearStatusBusy();
                if (e) {
                    SYNO.Backup.Addon.Config.updateAllowList(c.allow_all, c.allow_list)
                }
                this.loadFirstDone = true;
                var b = this.listPanel.getRootNode();
                var a = this.getTaskList();
                if (b.childNodes.length > 0) {
                    this.selectPage(b.childNodes[0].id)
                } else {
                    this.launchEmptyPage();
                    if (!this.isRestoreWinShow) {
                        this.openCreateWizard()
                    }
                }
                this.clearStatusBusy();
                if (!Ext.isEmpty(a)) {
                    this.alertMarkTask(a)
                }
                if (Ext.isEmpty(this.modalWin)) {
                    this.onStartPolling()
                }
            }
        })
    },
    onOpen: function() {
        this.setStatusBusy();
        this.callParent(arguments)
    },
    openWindow: function(a) {
        this.onStopPolling();
        a.on("close", this.onStartPolling, this);
        a.open()
    },
    popUpWindowIfNeeded: function(b, a) {
        if (this.isRestoreWinShow) {
            return
        }
        if (b || a) {
            this.isRestoreWinShow = true;
            var c;
            if (b) {
                c = new SYNO.SDS.Backup.Restore.ProgressWindow({
                    restore_id: -1,
                    owner: this
                })
            } else {
                c = new SYNO.SDS.Backup.Restore.LunProgressWindow({
                    owner: this
                })
            }
            c.on("close", function() {
                this.isRestoreWinShow = false
            }, this);
            this.openWindow(c)
        }
    },
    isRestore: function() {
        return this.listPanel.loader.isRestore
    },
    isSnapShotRestore: function() {
        return this.listPanel.loader.isSnapshotRestore
    },
    getCurrentTask: function() {
        var a = this.listPanel.getSelectionModel().getSelectedNode();
        if (!Ext.isEmpty(a)) {
            return a.attributes
        }
        return null
    },
    setCurTaskSession: function(b) {
        var a = this.getCurrentTask();
        a.sess_id = b.sess_id;
        a.sess_key = b.sess_key
    },
    clearCurTaskSession: function() {
        var a = this.getCurrentTask();
        delete a.sess_id;
        delete a.sess_key
    },
    getTaskById: function(a) {
        return this.listPanel.getNodeById(a).attributes
    },
    getTaskList: function() {
        return this.listPanel.loader.taskList
    },
    getTaskNameList: function() {
        return this.listPanel.loader.taskNameList
    },
    getLunTaskId: function(a) {
        return "Lun_" + a
    },
    onLunTaskRenamed: function(b, c, a) {
        this.refreshAndSelectTask(this.getLunTaskId(b), c, a)
    },
    onDataTaskRenamed: function(a, c, b) {
        this.refreshAndSelectTask(a, c, b, true)
    },
    onLunTaskCreated: function(a, c, b) {
        this.refreshAndSelectTask(this.getLunTaskId(a), c, b)
    },
    onTaskCreated: function(a, c, b) {
        this.refreshAndSelectTask(a, c, b)
    },
    refreshAndSelectTask: function(a, e, c, d) {
        var b = this.getListWebApi();
        b.scope = this;
        b.callback = function(j, f, i, h) {
            if (!j) {}
            var g = this.updateList(f);
            this.selectPage(a);
            if (d) {
                this.rearrangeNode(this.listPanel.getNodeById(a), this.listPanel.getRootNode(), g)
            }
            if (e) {
                e.call(c)
            }
        };
        this.sendWebAPI(b)
    },
    selectPageByIndex: function(b) {
        var a = this.listPanel.getRootNode();
        if (a.childNodes.length > b && b > -1) {
            this.selectPage(a.childNodes[b].id)
        } else {
            if (a.childNodes.length > 0) {
                this.selectPage(a.childNodes[a.childNodes.length - 1].id)
            } else {
                this.launchEmptyPage()
            }
        }
    },
    deleteCurrentTask: function() {
        var b = this.listPanel;
        var d = b.getSelectionModel().getSelectedNode();
        var a = b.getRootNode();
        var c = a.childNodes.indexOf(d);
        b.loader.taskList = b.loader.taskList.filter(function(e) {
            return e.id !== d.id
        });
        b.loader.taskNameList = b.loader.taskNameList.filter(function(e) {
            return e != d.attributes.name
        });
        a.removeChild(d);
        this.selectPageByIndex(c);
        this.pageContainer.remove(d.id);
        b.updateScroller()
    },
    openCreateWizard: function() {
        var a = new SYNO.SDS.Backup.TaskCreateWizard({
            appWin: this,
            owner: this
        });
        this.openWindow(a)
    },
    onCreateLUNBackup: function() {
        var a = new SYNO.SDS.Backup.LUNBackupWizard({
            owner: this
        });
        this.openWindow(a)
    },
    onDataRestore: function() {
        var a = new SYNO.SDS.Backup.Restore.RestoreWizard({
            restoreTaskPage: this,
            appWin: this,
            owner: this
        });
        this.openWindow(a)
    },
    onLUNRestore: function() {
        this.onStopPolling();
        var a = new Ext.data.Store({
            reader: new Ext.data.JsonReader({
                idProperty: "name",
                root: "lun_task_list",
                totalProperty: "total",
                fields: [{
                    name: "name",
                    mapping: "name"
                }, {
                    name: "type",
                    mapping: "type"
                }, {
                    name: "bkp_dest_type",
                    mapping: "bkp_dest_type"
                }, {
                    name: "status",
                    mapping: "last_bkp_result"
                }]
            })
        });
        a.loadData({
            lun_task_list: this.getTaskList().filter(function(c) {
                return "lun" === c.data_type
            })
        });
        var b = new SYNO.SDS.Backup.LUNRestoreWizard({
            appWin: this,
            owner: this,
            grid: a
        });
        b.on("close", this.onStartPolling, this);
        b.Show()
    },
    openLogWindow: function() {
        var a = new SYNO.SDS.Backup.Client.Common.Log.LogsWindow({
            appWin: this,
            jsConfig: this.jsConfig,
            owner: this
        });
        this.openWindow(a)
    },
    getListWebApi: function() {
        return {
            api: "SYNO.Backup.Task",
            version: 1,
            method: "list",
            params: {
                sort_by: "name",
                additional: ["last_bkp_time", "last_bkp_result", "is_modified", "progress_title_type"]
            }
        }
    },
    onStartPolling: function() {
        if (this.pollingID || !this.loadFirstDone) {
            return
        }
        this.pollingID = this.pollReg({
            webapi: this.getListWebApi(),
            interval: 3,
            immediate: false,
            scope: this,
            status_callback: this.onPollingDone
        });
        var a = this.getActivePage();
        if (a) {
            a.onStartPolling()
        }
    },
    onStopPolling: function() {
        if (!this.pollingID) {
            return
        }
        this.pollUnreg(this.pollingID);
        this.pollingID = null;
        var a = this.getActivePage();
        if (a) {
            a.onStopPolling()
        }
    },
    insertNode: function(b, d, c) {
        var a;
        if (d.length > (c + 1)) {
            a = this.listPanel.getNodeById(d[c + 1].id)
        }
        if (a) {
            b.insertBefore(d[c], a)
        } else {
            b.appendChild(d[c])
        }
    },
    rearrangeNode: function(d, a, b) {
        var e = d.id;
        var c;
        Ext.each(b, function(g, f) {
            if (g.id === e) {
                c = f;
                return false
            }
        });
        if (a.childNodes[c].id !== e) {
            a.removeChild(d);
            this.insertNode(a, b, c);
            this.selectPage(e)
        }
    },
    setTaskStatusIcon: function(a, b) {
        if (undefined === b) {
            b = this.listPanel.getSelectionModel().getSelectedNode()
        }
        var c = this.pageContainer.getComponent(b.id);
        if ("check" === a) {
            if (Ext.isEmpty(c)) {
                a = "failed"
            } else {
                if (b.id !== this.listPanel.getSelectionModel().getSelectedNode().id && false === c.skipCheckLastResult) {
                    a = "failed"
                }
            }
        }
        Ext.fly(b.ui.statusIcon).replaceClass("task-status-icon-" + b.attributes.statusIcon, "task-status-icon-" + a);
        b.attributes.statusIcon = a
    },
    updateList: function(d) {
        var b = this.listPanel;
        var a = b.getRootNode();
        var f = a.childNodes.length;
        var c = [];
        var e = b.getLoader().parseWebApiResponse(a, d);
        Ext.each(e, b.getLoader().createNodeFn, b.getLoader());
        Ext.each(a.childNodes, function(h, g) {
            c.push(h.id)
        }, this);
        Ext.each(e, function(g, h) {
            var i = b.getNodeById(g.id);
            if (i) {
                c.remove(g.id);
                i.setText(g.text);
                this.setTaskStatusIcon(g.statusIcon, i)
            } else {
                this.insertNode(a, e, h)
            }
        }, this);
        Ext.each(c, function(i) {
            var g = b.getNodeById(i);
            var h = this.pageContainer.getComponent(i);
            a.removeChild(g);
            if (h) {
                h.onStopPolling()
            }
            this.pageContainer.remove(i)
        }, this);
        if (f != a.childNodes.length) {
            b.updateScroller()
        }
        return e
    },
    onPollingDone: function(f, a, e, c) {
        if (!f) {
            return
        }
        var d = this.listPanel.getSelectionModel().getSelectedNode();
        var b = this.listPanel.getRootNode().childNodes.indexOf(d);
        this.updateList(a);
        if (null === this.listPanel.getSelectionModel().getSelectedNode()) {
            this.selectPageByIndex(b)
        }
    },
    alertMarkTask: function(e) {
        var b = [];
        var c = [];
        Ext.each(e, function(g, h, f) {
            if (Ext.isArray(g.ext3ShareList) && 0 < g.ext3ShareList.length) {
                b.push(g.name);
                Ext.each(g.ext3ShareList, function(k, j, i) {
                    if (0 > c.indexOf(k)) {
                        c.push(k)
                    }
                }, this)
            }
        }, this);
        if (0 < b.length) {
            var d = SYNO.SDS.Backup.String("app", "ext3issue_fullbackup_hint") + "<br />" + _T("backup", "task_name") + ": " + b.join(", ");
            var a = new SYNO.SDS.Backup.AlertWindow({
                appWin: this,
                owner: this,
                title: SYNO.SDS.Backup.String("app", "ext3issue_fullbackup_title"),
                formItems: [{
                    xtype: "syno_displayfield",
                    htmlEncode: false,
                    value: d
                }, {
                    name: "notremind",
                    xtype: "syno_checkbox",
                    boxLabel: SYNO.SDS.Backup.String("app", "remind_confirm")
                }],
                callback: Ext.createDelegate(function(g, f) {
                    if ("yes" === g || "true" === f.notremind) {
                        this.setStatusBusy();
                        this.sendWebAPI({
                            api: "SYNO.Backup.Task",
                            version: 1,
                            method: "mark",
                            params: {
                                markedShareList: c,
                                fixTasks: "yes" === g,
                                notRemind: f.notremind
                            },
                            scope: this,
                            callback: function(j, h, i) {
                                this.clearStatusBusy()
                            }
                        })
                    }
                }, this)
            });
            a.open()
        }
    }
});
Ext.define("SYNO.SDS.Backup.TaskTreeNodeUI", {
    extend: "Ext.tree.TreeNodeUI",
    renderElements: function(e, j, i, k) {
        this.indentMarkup = e.parentNode ? e.parentNode.ui.getChildIndent() : "";
        var f = Ext.isBoolean(j.checked),
            b, c = this.getHref(j.href),
            d = ['<li class="x-tree-node"><div ext:tree-node-id="', e.id, '" class="x-tree-node-el x-tree-node-leaf x-unselectable ', j.cls, '" unselectable="on">', '<span class="x-tree-node-indent">', this.indentMarkup, "</span>", '<img alt="" src="', this.emptyIcon, '" class="x-tree-ec-icon x-tree-elbow" />', '<img alt="" src="', j.icon || this.emptyIcon, '" class="x-tree-node-icon', (j.icon ? " x-tree-node-inline-icon" : ""), (j.iconCls ? " " + j.iconCls : ""), '" unselectable="on" />', f ? ('<input class="x-tree-node-cb" type="checkbox" ' + (j.checked ? 'checked="checked" />' : "/>")) : "", '<a hidefocus="on" class="x-tree-node-anchor" href="', c, '" tabIndex="1" ', j.hrefTarget ? ' target="' + j.hrefTarget + '"' : "", '><span ext:qtip="', e.text, '" unselectable="on">', e.text, "</span></a>", '<img alt="" src="', this.emptyIcon, '" class="task-status-icon task-status-icon-', j.statusIcon, '" />', "</div>", '<ul class="x-tree-node-ct" style="display:none;"></ul>', "</li>"].join("");
        if (k !== true && e.nextSibling && (b = e.nextSibling.ui.getEl())) {
            this.wrap = Ext.DomHelper.insertHtml("beforeBegin", b, d)
        } else {
            this.wrap = Ext.DomHelper.insertHtml("beforeEnd", i, d)
        }
        this.elNode = this.wrap.childNodes[0];
        this.ctNode = this.wrap.childNodes[1];
        var h = this.elNode.childNodes;
        this.indentNode = h[0];
        this.ecNode = h[1];
        this.iconNode = h[2];
        var g = 3;
        if (f) {
            this.checkbox = h[3];
            this.checkbox.defaultChecked = this.checkbox.checked;
            g++
        }
        this.anchor = h[g];
        this.textNode = h[g].firstChild;
        this.statusIcon = h[g + 1]
    },
    onTextChange: function(b, c, a) {
        if (this.rendered) {
            this.textNode.innerHTML = c;
            this.textNode.setAttribute("ext:qtip", c)
        }
    }
});
Ext.define("SYNO.SDS.Backup.Restore.AppUtil", {
    treePanel: null,
    constructor: function(a) {
        Ext.apply(this, a)
    },
    convertLanguage: function(a, b) {
        var c = SYNO.SDS.Backup.converLanString(a[b]);
        if (c) {
            if ((b + "_param") in a) {
                c = String.format(c, a[b + "_param"])
            }
            a[b] = c
        }
    },
    onCreateAppNode: function(a) {
        this.convertLanguage(a, "text");
        this.convertLanguage(a, "qtip");
        if ("warn" === a.type) {
            a.text = '<element class="red-status">' + a.text + "</element>";
            a.qtip = '<element class="red-status">' + a.qtip + "</element>"
        }
    },
    getAppCheckedSubTreeRoot: function(b) {
        var a = [];
        var c = function(d) {
            d.eachChild(function(f) {
                var e = f.getUI() || {};
                if (!Ext.isFunction(e.getCheckValue) || !(e.checkbox)) {
                    return
                }
                if (true === e.getCheckValue() || "gray" === e.getCheckValue()) {
                    a.push(f);
                    c(f)
                }
            })
        };
        c(b);
        return a
    },
    getAppList: function(b) {
        var a = [];
        Ext.each(this.getAppCheckedSubTreeRoot(this.treePanel.getNodeById("app_root")), function(c) {
            a.push(c.id)
        });
        return a
    },
    getCheckAppApi: function() {
        var a = [];
        Ext.each(this.getAppList(), function(d) {
            var c = {};
            var b;
            if ("mysql" === d) {
                var e = this.treePanel.getNodeById("mysql_pwd");
                if (e) {
                    b = e.getUI().getInputValue()
                } else {
                    b = ""
                }
                c.api = "SYNO.Backup.App.Restore";
                c.version = 1;
                c.method = "mysql_check";
                c.params = {};
                c.params.mysql_pwd = b;
                a.push(c)
            } else {
                if ("surveillance" === d) {
                    c.api = "SYNO.Backup.App.Restore";
                    c.version = 1;
                    c.method = "surveillance_check";
                    a.push(c)
                }
            }
        }, this);
        return a
    }
});
