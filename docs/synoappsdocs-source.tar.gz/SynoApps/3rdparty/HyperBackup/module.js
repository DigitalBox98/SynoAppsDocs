/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.Backup.PrivateKeyDownloadWindow
 * @extends SYNO.SDS.ModalWindow
 * HyperBackup private key download window
 *
 */  
Ext.define("SYNO.SDS.Backup.PrivateKeyDownloadWindow", {
    extend: "SYNO.SDS.ModalWindow",
    task_id: undefined,
    file_name: undefined,
    constructor: function(a) {
        this.formPanel = new SYNO.ux.FormPanel({
            fieldWidth: 160,
            labelWidth: 150,
            items: [{
                xtype: "syno_displayfield",
                value: SYNO.SDS.Backup.String("app", "download_encryption_key_verify_hint")
            }, {
                xtype: "syno_textfield",
                fieldLabel: SYNO.SDS.Backup.String("app", "task_password_input"),
                textType: "password",
                name: "password",
                minLength: 8,
                maxLength: 64,
                allowBlank: false
            }]
        });
        var b = Ext.apply({
            width: 500,
            height: 180,
            resizable: false,
            title: SYNO.SDS.Backup.String("app", "download_encryption_key_verify"),
            layout: "fit",
            items: [this.formPanel],
            keys: [{
                key: Ext.EventObject.ENTER,
                handler: this.onSubmit,
                stopEvent: true,
                scope: this
            }],
            buttons: [{
                itemId: "cancel",
                text: _T("common", "cancel"),
                handler: this.close,
                scope: this
            }, {
                itemId: "apply",
                btnStyle: "blue",
                text: _T("common", "ok"),
                handler: this.onSubmit,
                scope: this
            }]
        }, a);
        this.callParent([b])
    },
    onOpen: function() {
        this.callParent(arguments);
        this.formPanel.getForm().findField("password").focus(false, 100)
    },
    onSubmit: function() {
        if (!this.formPanel.getForm().isValid()) {
            return
        }
        var a = this.getParams();
        this.findAppWindow().downloadWebAPI({
            webapi: {
                api: "SYNO.Backup.Target",
                version: 1,
                method: "private_key_download_by_password",
                params: a,
                encryption: ["password"]
            },
            callback: function(b, d, e, c) {
                if (!e) {
                    this.appWin.getMsgBox().alert(this.title, SYNO.SDS.Backup.GetErrorString(c.code))
                }
            },
            scope: this
        });
        this.close()
    },
    getParams: function() {
        var a = Ext.apply({
            task_id: this.task_id,
            file_name: this.file_name,
            support_utf8_name: Ext.isChrome || Ext.isGecko || Ext.isSafari
        }, this.formPanel.getForm().getValues());
        return a
    }
});
(function() {
    var c = function(l, n) {
        var o = {
            enableSchedule: l.schedule_enable,
            isWeeklyRepeat: (undefined !== l.week_name),
            isNotRepeat: (0 === l.repeat),
            isMonthlyRepeat: (1 === l.repeat),
            isYearlyRepeat: (2 === l.repeat),
            isHalfYearlyRepeat: (3 === l.repeat),
            isQuarterYearlyRepeat: (5 === l.repeat),
            backupDays: l.week_name,
            enableRotate: n.enable_rotate,
            rotateRuleList: n.rotate_action,
            rotateMaxVersion: n.rotate_condition[1],
            rotateMode: n.rotate_option,
            isSynoCloudType: n.isSynoCloudType
        };
        o.backupTimeStampPerDay = [];
        o.backupPerDay = 0;
        var m = l.hour;
        do {
            o.backupTimeStampPerDay.push(m);
            o.backupPerDay++;
            m += l.repeat_hour
        } while (m <= l.last_work_hour && 0 !== l.repeat_hour);
        if (o.isSynoCloudType) {
            if (Ext.isDefined(o.backupDays)) {
                o.rotateMaxVersion = 3 + o.backupDays.split(",").length
            } else {
                if (o.isMonthlyRepeat || o.isYearlyRepeat || o.isHalfYearlyRepeat || o.isQuarterYearlyRepeat) {
                    o.rotateMaxVersion = 1
                }
            }
        }
        return o
    };
    var j = function(l, m) {
        var o, n;
        if (m === "month_view") {
            if (0 === l % 14) {
                o = l / 7;
                n = "";
                if (0 < o) {
                    n = String.format('<div class="text">' + _T("backup", "time_before") + "</div>", o, _T("common", "time_weeks"))
                }
                return new Ext.Container({
                    cls: "weekline",
                    html: n
                })
            }
        } else {
            if (0 === l % 12) {
                o = l;
                n = "";
                if (0 < o && o < 52) {
                    n = String.format('<div class="text">' + _T("backup", "time_before") + "</div>", o, _T("common", "time_weeks"))
                }
                return new Ext.Container({
                    cls: "weekline",
                    html: n
                })
            }
        }
        return new Ext.Container({
            cls: "block"
        })
    };
    var h = function(n) {
        var m = null;
        if (n.isFirstNode) {
            m = new Ext.Container({
                cls: "block pin"
            })
        } else {
            if (-1 === n.versionNumber) {
                m = new Ext.Container({
                    cls: "block pass"
                })
            } else {
                m = new Ext.Container({
                    cls: "block"
                })
            }
        }
        if (0 < n.versionNumber) {
            var l = String.format("{0} {1}", n.versionNumber, _T("backup", "version_nums"));
            var p = "",
                o = "";
            if (0 === n.index) {
                p = _T("backup", "nearest_backup")
            } else {
                if (n.isFirstNode) {
                    p = n.firstNodeText
                } else {
                    if (n.viewMode === "month_view") {
                        p = String.format(_T("backup", "time_before"), n.index, _T("common", "time_days"))
                    } else {
                        p = String.format(_T("backup", "time_before"), n.index, _T("common", "time_weeks"))
                    }
                }
            }
            if (n.isFirstNode && n.firstNodeExceedTenYear) {
                o = p
            } else {
                o = l + ", " + p
            }
            m.add(new Ext.BoxComponent({
                cls: "cycle",
                autoEl: {
                    "ext:qtip": o
                }
            }))
        }
        return m
    };
    var e = function(n, l) {
        var m;
        if (l <= 0) {
            return
        } else {
            if (l >= n.length) {
                for (m = 0; m < n.length; ++m) {
                    n[m] = 0
                }
                return n
            }
        }
        for (m = n.length - 1; m >= l; --m) {
            n[m] = n[m - l]
        }
        for (m = l - 1; m >= 0; --m) {
            n[m] = 0
        }
    };
    var a = function(o, m) {
        var n, l = o.length - m;
        if (m <= 0) {
            return
        } else {
            if (m >= o.length) {
                for (n = 0; n < o.length; ++n) {
                    o[n] = 0
                }
                return o
            }
        }
        for (n = 0; n < l; ++n) {
            o[n] = o[n + m]
        }
        for (n = l; n < o.length; ++n) {
            o[n] = 0
        }
    };
    var i = function(l) {
        var m = Array.apply(null, new Array(24)).map(Number.prototype.valueOf, 0);
        Ext.each(l, function(n) {
            m[n] = 1
        });
        while (m[23] !== 1) {
            e(m, 1)
        }
        return m
    };
    var k = function(l) {
        var m, n = Array.apply(null, new Array(24)).map(Number.prototype.valueOf, 0);
        if (l >= 24) {
            n[23] = 1;
            return n
        }
        for (m = 0; m < 24; ++m) {
            if (0 === (m % l)) {
                n[23 - m] = 1
            }
        }
        return n
    };
    var d = function(n) {
        var l = n.slice();
        var m = [];
        if (l.length === 0) {
            l.push([0, 3600, 1])
        }
        Ext.each(l, function(q) {
            var p = {},
                o = q[1] / 3600;
            p.range = Math.ceil(q[0] / 86400);
            p.bitwise = k(o);
            if (0 === (o % 24)) {
                p.type = "date";
                p.interval = o / 24
            } else {
                p.type = "hour";
                p.interval = o
            }
            m.push(p)
        });
        m.sort(function(p, o) {
            if (0 === p.range || 0 === o.range) {
                return o.range - p.range
            }
            return p.range - o.range
        });
        return m
    };
    var b = function(m, n) {
        var o, l = 0;
        while (l !== -1) {
            l = -1;
            for (o = 0; o < m.length; ++o) {
                if (m[o].range !== 0 && m[o].range < (n + 1)) {
                    l = o;
                    break
                }
            }
            if (l !== -1) {
                m.splice(l, 1)
            }
        }
    };
    var g = function(m, n) {
        var l = [];
        Ext.each(m, function(p) {
            var o, q;
            if (p.type === "hour") {
                o = ((n % p.interval) * 24) % p.interval;
                q = p.bitwise.slice();
                if (o !== 0) {
                    o = p.interval - o;
                    q = a(q, o)
                }
                l.push(q)
            } else {
                if (p.type === "date" && (n % p.interval) === 0) {
                    l.push(p.bitwise.slice())
                }
            }
        });
        return l
    };
    var f = function(B) {
        if (!B.enableSchedule) {
            return [0, []]
        }
        var y = 3650;
        var x = B.rotateMaxVersion;
        var v = Array.apply(null, new Array(y)).map(Number.prototype.valueOf, 0);
        var w = i(B.backupTimeStampPerDay);
        var l = d(B.rotateRuleList);
        var z = null,
            A, p, m;
        if (B.isWeeklyRepeat) {
            m = B.backupDays.split(",").map(function(C) {
                return 6 - parseInt(C, 10)
            }).sort();
            p = m[0];
            m = m.map(function(C) {
                return C - p
            });
            z = function(C) {
                return (0 <= m.indexOf(C % 7))
            }
        } else {
            if (B.isMonthlyRepeat) {
                A = 28
            } else {
                if (B.isQuarterYearlyRepeat) {
                    A = 84
                } else {
                    if (B.isHalfYearlyRepeat) {
                        A = 182
                    } else {
                        if (B.isYearlyRepeat) {
                            A = 365
                        }
                    }
                }
            }
            z = function(C) {
                return (0 === (C % A))
            }
        }
        var s, r, u = 0,
            t = -1,
            o, q;
        for (o = 0; o < y && u < x; ++o) {
            if (z(o) || t !== -1) {
                b(l, o);
                if (l.length === 0) {
                    break
                }
            }
            if (z(o)) {
                q = g(l, o);
                for (s = w.length - 1; s >= 0 && u < x; --s) {
                    if (w[s] === 1) {
                        t = o
                    }
                    if (t !== -1) {
                        for (r = 0; r < q.length; ++r) {
                            if (q[r][s] === 1) {
                                v[t] += 1;
                                u++;
                                t = -1;
                                break
                            }
                        }
                    }
                }
            } else {
                if (t !== -1) {
                    q = g(l, o);
                    for (r = 0; r < q.length && u < x; ++r) {
                        for (s = q[r].length - 1; s >= 0; --s) {
                            if (1 === q[r][s]) {
                                v[t] += 1;
                                u++;
                                t = -1;
                                break
                            }
                        }
                    }
                }
            }
        }
        x -= u;
        var n;
        if (x > 0 && l.length === 0) {
            for (o = 0; o < y && 0 < x; ++o) {
                if (z(o) && B.backupPerDay > v[o]) {
                    n = Ext.min([B.backupPerDay - v[o], x]);
                    v[o] += n;
                    x -= n
                }
            }
        }
        return [x, v]
    };
    Ext.define("SYNO.SDS.Backup.Rotation.Previewer", {
        extend: "SYNO.ux.Panel",
        lastRotationParams: null,
        rotationParams: null,
        lastViewArray: null,
        viewMode: "month_view",
        isUserSelectedViewMode: false,
        initEvents: function() {
            this.mon(this, "afterlayout", function(l, m) {
                if (l.items.length !== 1) {
                    this.mon(this.changeViewBtn.el, "click", function() {
                        if (this.viewMode === "month_view") {
                            this.viewMode = "year_view"
                        } else {
                            this.viewMode = "month_view"
                        }
                        this.isUserSelectedViewMode = true;
                        this.updateView()
                    }, this)
                }
            }, this)
        },
        initComponent: function() {
            this.callParent(arguments);
            this.add(this.getChangeViewBtn());
            this.doLayout()
        },
        getChangeViewBtn: function() {
            if (this.viewMode === "month_view") {
                this.changeViewBtn = new Ext.Container({
                    cls: "change-view-btn month-view"
                })
            } else {
                this.changeViewBtn = new Ext.Container({
                    cls: "change-view-btn year-view"
                })
            }
            return this.changeViewBtn
        },
        updatePreviewer: function(l, m) {
            this.rotationParams = c(l, m);
            this.updateView()
        },
        updateView: function() {
            this.removeAll();
            this.unmask();
            var r, o = this.getWidth();
            if (!this.rotationParams.enableSchedule || (this.rotationParams.isNotRepeat && !this.rotationParams.isWeeklyRepeat) || 1 > this.rotationParams.rotateMaxVersion) {
                var t = new Ext.Container({
                    cls: "timeline-background",
                    width: 640
                });
                for (r = 0; r < 62; ++r) {
                    t.add(new Ext.Container({
                        cls: "block"
                    }))
                }
                this.add(t);
                this.doLayout();
                if (1 > this.rotationParams.rotateMaxVersion) {
                    this.mask(_T("backup", "not_available"))
                } else {
                    if (!this.rotationParams.enableSchedule || (this.rotationParams.isNotRepeat && !this.rotationParams.isWeeklyRepeat)) {
                        this.mask(_T("backup", "rotate_retention_no_schedule"))
                    } else {
                        this.mask(_T("error", "error_error_system"))
                    }
                }
                return false
            }
            var u = Ext.encode(this.rotationParams);
            if (u !== this.lastRotationParams) {
                this.lastRotationParams = u;
                this.lastViewArray = f(this.rotationParams)
            }
            var A = this.lastViewArray;
            var z;
            if (!this.isUserSelectedViewMode) {
                this.viewMode = this.getAutoViewMode(A)
            }
            if (this.viewMode === "month_view") {
                z = this.getMonthViewArray(A, this.rotationParams)
            } else {
                z = this.getYearViewArray(A, this.rotationParams)
            }
            var s = z[0];
            var w = z[1];
            var v = 0;
            var q = -1;
            for (r = 0; r < 62; ++r) {
                if (0 < w[r]) {
                    q = r
                }
            }
            v = q + 1;
            var y = (o - 2 * 15) / (v + 2 - 3);
            if (1 === v) {
                y = 2 * o
            }
            var p = y * (v + 2);
            var n = new Ext.Container({
                cls: "timeline-background",
                width: p,
                x: (-1.5) * y + 15
            });
            var m = new Ext.Container({
                cls: "timeline-wrapper",
                width: p,
                x: (-1.5) * y + 15
            });
            var l = new Ext.Container({
                cls: "timeline-weekline",
                width: p,
                x: (-1.5) * y + 15
            });
            var B = "";
            if (0 === s) {
                B = _T("backup", "nearest_backup")
            } else {
                if (28 >= s) {
                    B = String.format(_T("backup", "time_before"), s, _T("common", "time_days"))
                } else {
                    if (6 * 28 >= s) {
                        B = String.format(_T("backup", "time_before"), Math.floor(s / 7), _T("common", "time_weeks"))
                    } else {
                        if (365 >= s) {
                            B = String.format(_T("backup", "time_before"), Math.floor(s / 28), _T("common", "time_months"))
                        } else {
                            if (3650 > s) {
                                B = String.format(_T("backup", "time_before"), Math.floor(s / 365), _T("common", "time_years"))
                            } else {
                                B = SYNO.SDS.Backup.String("app", "time_exceed_ten_year")
                            }
                        }
                    }
                }
            }
            n.add(new Ext.Container({
                cls: "block"
            }));
            m.add(new Ext.Container({
                cls: "block"
            }));
            l.add(new Ext.Container({
                cls: "block"
            }));
            for (r = 0; r <= q; ++r) {
                n.add(new Ext.Container({
                    cls: "block"
                }));
                l.add(j(q - r, this.viewMode));
                m.add(h({
                    index: q - r,
                    isFirstNode: (0 === r),
                    firstNodeText: B,
                    firstNodeExceedTenYear: (s >= 3650),
                    versionNumber: w[q - r],
                    viewMode: this.viewMode
                }))
            }
            n.add(new Ext.Container({
                cls: "block"
            }));
            m.add(new Ext.Container({
                cls: "block"
            }));
            l.add(new Ext.Container({
                cls: "block"
            }));
            this.add(l);
            this.add(n);
            this.add(m);
            this.add(new Ext.Container({
                html: B,
                cls: "oldest"
            }));
            this.add(this.getChangeViewBtn());
            this.doLayout();
            if (!this.rotationParams.enableRotate) {
                this.mask()
            }
        },
        getYearViewArray: function(s, t) {
            var n, p, l, o = -1;
            var r = s[0];
            var m = s[1];
            var q = Array.apply(null, new Array(62)).map(Number.prototype.valueOf, 0);
            p = 0;
            l = 0;
            for (n = 0; n < 434; ++n) {
                l += m[n];
                p += m[n];
                if (6 === (n % 7)) {
                    q[Math.floor(n / 7)] = l;
                    l = 0
                }
            }
            if (0 < r) {
                o = 3650
            } else {
                for (n = 3649; n >= 0; --n) {
                    if (m[n] > 0) {
                        o = n;
                        break
                    }
                }
            }
            if (0 < (t.rotateMaxVersion - p)) {
                q[59] = -1;
                q[60] = 0;
                q[61] = 1
            }
            return [o, q]
        },
        getMonthViewArray: function(s, l) {
            var p, q, o = -1;
            var m = s[0];
            var n = s[1];
            var r = Array.apply(null, new Array(62)).map(Number.prototype.valueOf, 0);
            q = 0;
            for (p = 0; p < 62; ++p) {
                r[p] = n[p];
                q += n[p]
            }
            if (0 < m) {
                o = 3650
            } else {
                for (p = 3649; p >= 0; --p) {
                    if (n[p] > 0) {
                        o = p;
                        break
                    }
                }
            }
            if (0 < (l.rotateMaxVersion - q)) {
                r[59] = -1;
                r[60] = 0;
                r[61] = 1
            }
            return [o, r]
        },
        getAutoViewMode: function(o) {
            var l = o[1];
            var m, n = "year_view";
            for (m = 1; m < 62; ++m) {
                if (0 !== l[m]) {
                    n = "month_view";
                    break
                }
            }
            return n
        },
        mask: function(l) {
            this.el.mask(l, "syno-ux-grid-mask-info")
        },
        unmask: function() {
            this.el.unmask()
        }
    })
})();
Ext.define("SYNO.SDS.Backup.AlertWindow", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        var b = Ext.apply({
            width: 600,
            height: 220,
            cls: "syno-backup-alert-window",
            bodyStyle: "padding-top: 8px;",
            resizable: false,
            layout: "fit",
            buttons: [{
                text: a.noBtnText ? a.noBtnText : _T("common", "no"),
                handler: function() {
                    var c = this.items.get(0).getForm().getValues();
                    if (Ext.isFunction(this.callback)) {
                        this.callback("no", c)
                    }
                    this.close()
                },
                scope: this
            }, {
                text: a.yesBtnText ? a.yesBtnText : _T("common", "yes"),
                btnStyle: "blue",
                handler: function() {
                    var c = this.items.get(0).getForm().getValues();
                    if (Ext.isFunction(this.callback)) {
                        this.callback("yes", c)
                    }
                    this.close()
                },
                scope: this
            }],
            items: [{
                xtype: "syno_formpanel",
                items: a.formItems
            }]
        }, a);
        return this.callParent([b])
    }
});
Ext.define("SYNO.SDS.Backup.Wizard", {
    extend: "SYNO.SDS.Wizard.ModalWindow",
    wizardAnchor: "",
    lastStepId: null,
    getStep: function(b) {
        var a = this.getAllSteps().filter(function(c) {
            return b === c.itemId
        })[0];
        if (!a) {
            if (Ext.isFunction(this.createStep)) {
                a = this.createStep(b);
                if (!Ext.isDefined(a.itemId) || !Ext.isDefined(a.nextId)) {
                    throw Error("missing step itemId: " + b)
                }
                if (a) {
                    if (!a.checkState) {
                        a.checkState = SYNO.SDS.Wizard.Step.prototype.checkState
                    }
                    this.appendSteps(a)
                }
            }
        }
        return a
    },
    goNext: function(b, c) {
        this.lastStepId = this.getActiveStep().getItemId();
        var a = this.getActiveStep().isAnchor;
        if (null === b) {
            this.initializeTask();
            return
        }
        this.callParent(arguments);
        this.lastStepId = null;
        if (a) {
            this.setWizardAnchor()
        }
    },
    getParams: function() {
        var b = {};
        var a;
        if (this.lastStepId) {
            a = this.stepStack.concat([this.lastStepId])
        } else {
            a = this.stepStack
        }
        Ext.each(a, function(d) {
            var c = this.getStep(d);
            if (Ext.isFunction(c.getParams)) {
                Ext.apply(b, this.getStep(d).getParams())
            }
        }, this);
        return b
    },
    setWizardAnchor: function() {
        this.wizardAnchor = Ext.encode(this.getParams())
    },
    getWizardAnchor: function() {
        return this.wizardAnchor
    },
    setHeadline: function(a) {},
    setDescription: function(a) {}
});
Ext.define("SYNO.SDS.Backup.SummaryStep", {
    extend: "SYNO.SDS.Wizard.SummaryStep",
    cls: "syno-backup-summary",
    fieldRenderer: function(a) {
        return '<b ext:qtip="' + a + '">' + a + "</b>"
    }
});
