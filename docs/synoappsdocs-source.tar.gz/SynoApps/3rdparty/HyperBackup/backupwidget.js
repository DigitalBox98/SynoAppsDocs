/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.Backup.ScheduleBackupWidget
 * @extends SYNO.SDS._Widget.GridPanel
 * HyperBackup schedule backup widget
 *
 */
Ext.define("SYNO.SDS.Backup.ScheduleBackupWidget", {
    extend: "SYNO.SDS._Widget.GridPanel",
    constructor: function(a) {
        this.NUM_REC_PER_PAGE = 2;
        var b = {
            cls: "sds-widget-gridpanel syno-sds-backupapp-widget-panel"
        };
        Ext.apply(b, a);
        this.callParent([b])
    },
    onActivateScheduleDone: function(d, b, c, a) {
        if (d) {
            this.ProcessBackupStatus(b.task_list)
        }
    },
    onStartPolling: function() {
        this.pollingID = this.pollReg({
            webapi: {
                api: "SYNO.Backup.Task",
                version: 1,
                method: "list",
                params: {
                    additional: ["schedule", "next_bkp_time", "last_bkp_time", "last_bkp_result:Backupable", "is_modified"]
                }
            },
            interval: 10,
            immediate: true,
            scope: this,
            status_callback: this.onActivateScheduleDone
        })
    },
    onStopPolling: function() {
        if (!Ext.isEmpty(this.pollingID)) {
            this.pollUnreg(this.pollingID);
            delete this.pollingID
        }
    },
    onGridCellClick: function() {},
    onClick: function(d, c, b) {
        this.callParent(arguments);
        var a = Ext.fly(c);
        if (a && (a.hasClass("help_link"))) {
            SYNO.SDS.AppLaunch("SYNO.SDS.Backup.Application", {
                id: a.getAttribute("task-id")
            })
        }
    },
    getColumnModel: function() {
        if (this.cmSystemLog) {
            return this.cmSystemLog
        }
        var a = new Ext.grid.ColumnModel({
            columns: [{
                id: "bkpstatus",
                width: 290,
                renderer: this.backupTaskRenderer.createDelegate(this)
            }]
        });
        this.cmSystemLog = a;
        return a
    },
    getStore: function() {
        if (this.dsSystemLog) {
            return this.dsSystemLog
        }
        var a = new Ext.data.Store({
            reader: new Ext.data.ArrayReader({}, [{
                name: "type"
            }, {
                name: "task"
            }, {
                name: "tasks"
            }, {
                name: "status"
            }, {
                name: "total"
            }, {
                name: "time"
            }])
        });
        this.dsSystemLog = a;
        this.addManagedComponent(a);
        return a
    },
    getTime: function(b) {
        var a = parseInt(b, 10);
        return String.format("{0}:{1}", String.leftPad(Math.floor(a / 60), 2, "0"), String.leftPad(a % 60, 2, "0"))
    },
    moreContentRender: function(c, a) {
        var b = String.format(SYNO.SDS.Backup.String("app", c), a.length);
        if (1 < a.length) {
            b += String.format(" [{0}]", a.map(function(d) {
                return d.name
            }).join(","))
        }
        return this.contentRender(b, "")
    },
    contentRender: function(b, a, d) {
        var c = String.format('<div class = "syno-sds-backupapp-scedule-task" ext:qtip="{1}">{0}: {2}</div>', _T("localbkp", "localbkp_bkpset_name"), SYNO.SDS.Backup.Util.htmlEncodeTip(b), Ext.util.Format.htmlEncode(b));
        if (!Ext.isEmpty(a)) {
            if (Ext.isEmpty(d)) {
                d = a
            }
            c += String.format('<div ext:qtip="{2}">{0}: {1}</div>', _T("widget", "backup_status"), a, Ext.util.Format.htmlEncode(d))
        }
        return c
    },
    backupTaskRenderer: function(c, a, b) {
        return new SYNO.SDS.Backup.BackupTaskView(b.json).getDecorator()
    },
    getLastBkp: function(e) {
        var j = {};
        var d = [];
        var g = [];
        var h = [];
        var f = [];
        var c = [];
        var k = [];
        var a = [];
        Ext.each(e, function(m) {
            if (("success" === m.last_bkp_result || "done" === m.last_bkp_result) && true !== m.is_modified) {
                d.push(m)
            } else {
                if ("discard_failed" === m.status || ("none" === m.status && ("backingup" === m.last_bkp_result || "resuming" === m.last_bkp_result || "failed" === m.last_bkp_result || "failed_checking" === m.last_bkp_result))) {
                    g.push(m)
                } else {
                    if ("partial" === m.last_bkp_result && true !== m.is_modified) {
                        f.push(m)
                    } else {
                        if ("cancel" === m.last_bkp_result) {
                            c.push(m)
                        } else {
                            if ("suspend" === m.last_bkp_result) {
                                k.push(m)
                            } else {
                                if ("version_delete_failed" === m.last_bkp_result) {
                                    a.push(m)
                                } else {
                                    h.push(m)
                                }
                            }
                        }
                    }
                }
            }
        }, this);
        var i = function(n, m) {
            return new Date(m.last_bkp_time).getTime() - new Date(n.last_bkp_time).getTime()
        };
        d.sort(i);
        g.sort(i);
        f.sort(i);
        c.sort(i);
        k.sort(i);
        a.sort(i);
        j.title = SYNO.SDS.Backup.String("app", "widget_backup_title");
        j.cls = "syno-sds-backupapp-scedule-enable";
        var b = function(m) {
            return SYNO.SDS.Backup.GetBkpResultStr(m.last_bkp_result, m.is_modified, m.task_id)
        };
        if (g.length === 1) {
            j.time = g[0].last_bkp_time;
            j.iconCls = "syno-sds-backupapp-scedule-icon failed";
            j.content = this.contentRender(g[0].name, b(g[0]))
        } else {
            if (g.length > 1) {
                j.time = "";
                j.iconCls = "syno-sds-backupapp-scedule-icon failed";
                j.content = this.moreContentRender("more_failed", g)
            } else {
                if (a.length === 1) {
                    j.time = a[0].last_bkp_time;
                    j.iconCls = "syno-sds-backupapp-scedule-icon version-delete-failed";
                    j.content = this.contentRender(a[0].name, b(a[0]))
                } else {
                    if (a.length > 1) {
                        j.time = "";
                        j.iconCls = "syno-sds-backupapp-scedule-icon version-delete-failed";
                        j.content = this.moreContentRender("more_version_delete_failed", a)
                    } else {
                        if (c.length === 1) {
                            j.time = c[0].last_bkp_time;
                            j.iconCls = "syno-sds-backupapp-scedule-icon cancel";
                            j.content = this.contentRender(c[0].name, b(c[0]))
                        } else {
                            if (c.length > 1) {
                                j.time = "";
                                j.iconCls = "syno-sds-backupapp-scedule-icon cancel";
                                j.content = this.moreContentRender("more_cancel", c)
                            } else {
                                if (k.length === 1) {
                                    j.time = k[0].last_bkp_time;
                                    j.iconCls = "syno-sds-backupapp-scedule-icon suspend";
                                    j.content = this.contentRender(k[0].name, b(k[0]))
                                } else {
                                    if (k.length > 1) {
                                        j.time = "";
                                        j.iconCls = "syno-sds-backupapp-scedule-icon suspend";
                                        j.content = this.moreContentRender("more_suspend", k)
                                    } else {
                                        if (f.length === 1) {
                                            j.time = f[0].last_bkp_time;
                                            j.iconCls = "syno-sds-backupapp-scedule-icon partial";
                                            var l = SYNO.SDS.Backup.GetBkpResultStr(f[0].last_bkp_result, f[0].is_modified);
                                            j.content = this.contentRender(f[0].name, b(f[0]), l)
                                        } else {
                                            if (f.length > 1) {
                                                j.time = "";
                                                j.iconCls = "syno-sds-backupapp-scedule-icon partial";
                                                j.content = this.moreContentRender("more_partial", f)
                                            } else {
                                                if (d.length === 1) {
                                                    j.time = d[0].last_bkp_time;
                                                    j.iconCls = "syno-sds-backupapp-scedule-icon success";
                                                    j.content = this.contentRender(d[0].name, b(d[0]))
                                                } else {
                                                    if (d.length > 1) {
                                                        j.time = "";
                                                        j.iconCls = "syno-sds-backupapp-scedule-icon success";
                                                        j.content = this.moreContentRender("more_success", d)
                                                    } else {
                                                        j.time = String.format("--{0}--{0}--", _T("common", "colon"));
                                                        j.iconCls = "syno-sds-backupapp-scedule-icon no-result";
                                                        j.content = this.contentRender(SYNO.SDS.Backup.String("app", "no_backup"), "")
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        return j
    },
    getNextBkp: function(d) {
        var c = [],
            a = {};
        Ext.each(d, function(e) {
            e.next_bkp_epoch_time = Date.parseDate(e.next_bkp_time, "Y/m/d H:i");
            if (undefined !== e.next_bkp_epoch_time) {
                c.push(e)
            }
        }, this);
        var b = function(f, e) {
            return f.next_bkp_epoch_time - e.next_bkp_epoch_time
        };
        c.sort(b);
        a.title = SYNO.SDS.Backup.String("app", "backup_schedule_title");
        a.cls = "syno-sds-backupapp-scedule-enable";
        if (0 !== c.length) {
            a.iconCls = "syno-sds-backupapp-scedule-icon schedule-active";
            a.time = c[0].next_bkp_time;
            a.content = this.contentRender(c[0].name, "")
        } else {
            a.iconCls = "syno-sds-backupapp-scedule-icon schedule-inactive";
            a.time = String.format("--{0}--{0}--", _T("common", "colon"));
            a.content = this.contentRender(SYNO.SDS.Backup.String("app", "no_backup_schedule"), "")
        }
        return a
    },
    ProcessBackupStatus: function(b) {
        var a = [];
        a.push(this.getLastBkp(b));
        a.push(this.getNextBkp(b));
        this.getStore().loadData(a, false);
        this.doLayout()
    },
    onActivate: function() {
        this.onStartPolling()
    },
    onDeactivate: function() {
        this.onStopPolling()
    }
});
SYNO.SDS.Backup.BackupTaskView = function(a) {
    this.cfg = a;
    this.getDecorator = function() {
        return String.format('<div class = "{0}">{1}</div>', this.cfg.cls, this.getContent(this.cfg))
    };
    this.getContent = function(b) {
        var c = String.format('<div class = "{0}"></div>', b.iconCls);
        var e = String.format('<div class = "syno-sds-backupapp-scedule-title-bar"><div class = "syno-sds-backupapp-scedule-title" ext:qtip="{0}">{0}</div><div class = "syno-sds-backupapp-scedule-time" ext:qtip="{1}">{1}</div></div>', b.title, b.time);
        var d = String.format('<div class = "{0}">{1}</div>', b.contentCls || "", b.content);
        return c + '<div class = "syno-sds-backupapp-scedule-content">' + e + d + "</div>"
    }
};
