/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.define("SYNO.SDS.Backup.ApiHelper", {
    extend: "Object",
    owner: null,
    title: "",
    defaultErrorSec: "common",
    defaultErrorKey: "error_system",
    getDefaultErrorMsg: function() {
        return _T(this.defaultErrorSec, this.defaultErrorKey)
    },
    constructor: function(a) {
        Ext.apply(this, a);
        if (this.owner && !this.title) {
            this.title = this.owner.title
        }
    },
    send: function(b, c, a) {
        if (typeof b !== "object") {
            return false
        }
        if (b instanceof Array) {
            this.sendCompound(b, c, a)
        } else {
            this.sendSingle(b, c, a)
        }
    },
    sendCompound: function(e, g, c) {
        var d = this;
        if (!Ext.isFunction(g)) {
            g = Ext.emptyFn
        }
        var a = {
            count: 0,
            callback: g,
            scope: c,
            api: []
        };

        function f(h) {
            if (h.api) {
                return "_" + h.api + Ext.encode(h.params)
            } else {
                if (h.compound) {
                    return "_compound" + Ext.encode(h.compound)
                } else {
                    if (h.url) {
                        return "_" + h.url + Ext.encode(h.params)
                    }
                }
            }
        }

        function b(i, k, h) {
            var j = f(i);
            a[j] = {};
            if (i.callback) {
                a[j].callback = i.callback.createDelegate(i.scope || window)
            }
            if (i.api || i.compound) {
                i.callback = function(l, n, m) {
                    a[j].success = l;
                    a[j].response = n;
                    a[j].options = m;
                    a[j].request.callback = null;
                    a.count -= 1;
                    k.call(h, a)
                };
                delete i.scope
            } else {
                if (i.url) {
                    if (!Ext.isDefined(i.method)) {
                        i.method = "POST"
                    }
                    i.callback = function(m, l, o) {
                        var n = d.parseAjaxResponse(m, l, o);
                        a[j].success = !!(l && n.success);
                        a[j].response = n;
                        a[j].options = m;
                        a[j].request.callback = null;
                        a.count -= 1;
                        k.call(h, a)
                    };
                    delete i.scope
                } else {
                    return false
                }
            }
            a[j].request = i;
            a.api.push(j);
            return j
        }
        Ext.each(e, function(h) {
            var i = Ext.apply({}, h);
            var j;
            j = b(i, d.sendCompoundHandler, d);
            if (!j) {
                return true
            }
            if (i.api || i.compound) {
                if (!d.owner.sendWebAPI(i)) {
                    a[j].success = false;
                    a[j].response = {
                        success: false,
                        error: {
                            code: 102
                        }
                    };
                    return true
                }
            } else {
                if (i.url) {
                    Ext.Ajax.request(i)
                }
            }
            a.count += 1
        })
    },
    sendCompoundHandler: function(a) {
        var c = 0;
        var b = {
            result: []
        };
        if (a.count !== 0) {
            return
        }
        Ext.each(a.api, function(f) {
            var e = a[f];
            var d = e.response;
            if (e.callback) {
                e.callback(e.success, d, e.options)
            }
            if (!e.success) {
                c += 1
            }
            if (e.request.api) {
                Ext.copyTo(d, e.request, "api,method,version")
            } else {
                Ext.copyTo(d, e.request, "url,params")
            }
            b.result.push(d)
        });
        b.has_fail = (c > 0);
        if (a.callback) {
            a.callback.call(a.scope || window, c !== a.api.length, b)
        }
    },
    sendSingle: function(c, e, a) {
        var b = this;
        var d = Ext.emptyFn;
        if (c.callback) {
            d = c.callback.createDelegate(c.scope || window)
        }
        if (!Ext.isFunction(e)) {
            e = Ext.emptyFn
        }
        if (c.api || c.compound) {
            c.callback = function(h, f, g) {
                d(h, f, g);
                e.call(a, h, f, g)
            };
            this.owner.sendWebAPI(c)
        } else {
            if (!Ext.isDefined(c.method)) {
                c.method = "POST"
            }
            c.callback = function(h, f, g) {
                var i = b.parseAjaxResponse(h, f, g);
                var j = (f && i.success);
                d(j, i, h);
                e.call(a, j, i, h)
            };
            delete c.scope;
            Ext.Ajax.request(c)
        }
    },
    alert: function(a, e, b) {
        var d = this.title,
            c = this.getDefaultErrorMsg();
        if (!a) {} else {
            if (typeof a === "string") {
                c = a
            } else {
                if (typeof a === "number") {
                    c = SYNO.SDS.Backup.GetErrorString(a)
                } else {
                    if (a instanceof Array) {
                        Ext.each(a, function(f) {
                            if (!f.success) {
                                c = SYNO.SDS.Backup.GetErrorString(f.error.code);
                                return false
                            }
                        })
                    } else {
                        if (typeof a === "object") {
                            c = this.getResponseErrorMsg(a)
                        }
                    }
                }
            }
        }
        this.owner.getMsgBox().alert(d, c, e, b)
    },
    getResponseErrorMsg: function(a) {
        var c = this.getDefaultErrorMsg();
        if (Ext.isDefined(a.code)) {
            c = SYNO.SDS.Backup.GetErrorString(a.code)
        } else {
            if (Ext.isDefined(a.result) && Ext.isDefined(a.has_fail)) {
                Ext.each(a.result, function(d) {
                    if (!d.success) {
                        if (Ext.isDefined(d.code)) {
                            c = SYNO.SDS.Backup.GetErrorString(d.error.code)
                        } else {
                            if (Ext.isDefined(d.errinfo)) {
                                try {
                                    c = _T(d.errinfo.sec, d.errinfo.key)
                                } catch (f) {}
                            } else {
                                if (Ext.isDefined(d.errno)) {
                                    try {
                                        c = _T(d.errno.sec, d.errno.key)
                                    } catch (f) {}
                                }
                            }
                        }
                        return false
                    }
                })
            } else {
                if (Ext.isDefined(a.errors)) {
                    try {
                        c = _T(a.errors.sec, a.errors.key)
                    } catch (b) {}
                } else {
                    if (Ext.isDefined(a.errno)) {
                        try {
                            c = _T(a.errno.sec, a.errno.key)
                        } catch (b) {}
                    }
                }
            }
        }
        return c
    },
    parseAjaxResponse: function(b, f, a) {
        var c = {
            success: false,
            errinfo: {
                sec: this.defaultErrorSec,
                key: this.defaultErrorKey
            }
        };
        try {
            c = Ext.util.JSON.decode(a.responseText)
        } catch (d) {}
        return c
    }
});
/**
 * @class SYNO.SDS.Backup.ExpandableListView
 * @extends SYNO.ux.ExpandableListView
 * HyperBackup expandable list view class
 *
 */
Ext.define("SYNO.SDS.Backup.ExpandableListView", {
    extend: "SYNO.ux.ExpandableListView",
    trackResetOnLoad: false,
    constructor: function(a) {
        a.innerTpl = a.innerTpl || new Ext.XTemplate("{detail_html}");
        this.callParent(arguments)
    },
    initComponent: function() {
        this.callParent(arguments);
        this.addEvents("beforetoggle", "toggle")
    },
    needToggleEvent: true,
    toggleDetail: function(a, b) {
        if (!this.innerTpl || !a) {
            return
        }
        if (this.needToggleEvent && this.fireEvent("beforetoggle", this, a) === false) {
            return
        }
        this.callParent(arguments);
        if (this.needToggleEvent) {
            this.fireEvent("toggle", this, a)
        }
    },
    restoreUIState: function() {
        this.needToggleEvent = false;
        this.callParent(arguments);
        this.needToggleEvent = true
    },
    selectAndExpandById: function(a) {
        var d = this.store.getById(a),
            c, b;
        if (!d) {
            return
        }
        this.select(d);
        c = this.getNode(d);
        b = Ext.get(c);
        this.fleXcrollTo(b);
        if (!b.child(".item-toggle-expanded")) {
            this.toggleDetail(b, true)
        }
    },
    collapseAll: function() {
        var a = this.getToggledItemIds();
        Ext.each(a, function(g, c, b) {
            var e, d;
            var f = this.getStore().getById(g);
            if (f) {
                e = this.getNode(f);
                d = Ext.fly(e);
                if (d && d.child(".item-toggle-expanded")) {
                    this.toggleDetail(d, false)
                }
            }
        }, this)
    }
});
Ext.define("SYNO.SDS.Backup.TriTreeNodeUI", {
    extend: "Ext.tree.TreeNodeUI",
    renderElements: function(l, u, d, r) {
        this.indentMarkup = l.parentNode ? l.parentNode.ui.getChildIndent() : "";
        var q = '<img alt="" src="' + this.emptyIcon + '" class="syno-backup-tree-node-share-overwrite" ext:qtip="' + _T("confbackup", "confbkp_share_overwrite") + '"/>';
        var h = '<img alt="" src="' + this.emptyIcon + '" class="syno-backup-tree-node-share-rename" ext:qtip="' + _T("confbackup", "confbkp_share_rename") + '"/>';
        var f = '<img alt="" src="' + this.emptyIcon + '" class="syno-backup-tree-node-same-volume" ext:qtip="' + _T("backup", "warn_backup_same_volume") + '"/>';
        var c = '<img alt="" src="' + this.emptyIcon + '" class="syno-backup-tree-node-c2-share" "/>';
        var b = '<img alt="" src="' + this.emptyIcon + '" class="syno-backup-tree-node-enc-mount-share" "/>';
        var i = '<img alt="" src="' + this.emptyIcon + '" class="syno-backup-tree-node-enc-umount-share" "/>';
        var m = '<img alt="" src="' + this.emptyIcon + '" class="syno-backup-tree-node-app-share" ext:qtip=""/>';
        var t = '<img alt="" src="' + this.emptyIcon + '" class="syno-backup-tree-node-abb-folder" ext:qtip="' + (true === u.is_restore ? SYNO.SDS.Backup.String("app", "ABB_must_restore_entire_data") : SYNO.SDS.Backup.String("app_backup", "ABB_must_backup_data")) + '"/>';
        var w = '<img alt="" src="' + this.emptyIcon + '" class="syno-backup-tree-node-disable-folder ' + (true === u.disabled ? "syno-backup-show-disable-folder" : "") + '" ext:wtip="' + (u.disable_reason ? u.disable_reason : "") + '"/>';
        var j = Ext.isBoolean(u.checked) || u.checked === "gray",
            o = Ext.util.Format.htmlEncode,
            k = u.input,
            v, p = this.getHref(u.href),
            s = ['<li class="x-tree-node syno-backup-tri-tree-node"><div ext:tree-node-id="', o(l.id), '" class="x-tree-node-el x-tree-node-leaf x-unselectable ', u.cls, '" unselectable="on">', '<span class="x-tree-node-indent">', this.indentMarkup, "</span>", '<img alt="" src="', this.emptyIcon, '" class="x-tree-ec-icon x-tree-elbow" />', j ? ('<img alt="" src="' + this.emptyIcon + '" class="syno-backup-tri-tree-node-cb syno-ux-checkbox-icon" />') : "", '<img alt="" src="', u.icon || this.emptyIcon, '" class="x-tree-node-icon', (u.icon ? " x-tree-node-inline-icon" : ""), (u.iconCls ? " " + u.iconCls : ""), '" unselectable="on" ', ((u.icon || u.iconCls) ? "" : 'style="display: none;"') + "/>", '<a hidefocus="on" class="x-tree-node-anchor" href="', p, '" tabIndex="1" ', u.hrefTarget ? ' target="' + u.hrefTarget + '"' : "", '><span unselectable="on">', l.text, "</span></a>", true === u.isC2Share || u.is_c2 ? c : "", (true === u.encryptedShare && u.dataEncrypted) || u.is_enc ? i : "", (true === u.encryptedShare && !u.dataEncrypted) ? b : "", "rename" === u.shareConflict ? h : "", "overwrite" === u.shareConflict ? q : "", 0 === l.id.indexOf("fm_root") ? f : "", 0 === l.id.indexOf("/") && 0 === l.id.lastIndexOf("/") ? m : "", SYNO.SDS.Backup.Client.Common.Utils.isABBDataFolder(l.id) ? t : "", 0 === l.id.indexOf("/") ? w : "", "</div>", '<ul class="x-tree-node-ct" style="display:none;"></ul>', "</li>"].join("");
        if (r !== true && l.nextSibling && (v = l.nextSibling.ui.getEl())) {
            this.wrap = Ext.DomHelper.insertHtml("beforeBegin", v, s)
        } else {
            this.wrap = Ext.DomHelper.insertHtml("beforeEnd", d, s)
        }
        this.elNode = this.wrap.childNodes[0];
        this.ctNode = this.wrap.childNodes[1];
        var e = this.elNode.childNodes;
        var g = 0;
        this.indentNode = e[g++];
        this.ecNode = e[g++];
        if (j) {
            this.checkbox = e[g++]
        }
        this.iconNode = e[g++];
        this.anchor = e[g++];
        this.textNode = this.anchor.firstChild;
        if ("rename" === u.shareConflict) {
            this.renameNode = e[g++]
        }
        if ("overwrite" === u.shareConflict) {
            this.overwriteNode = e[g++]
        }
        this.volumeWarnNode = e[g++];
        if (k) {
            this.createInputField(k, u, this.elNode);
            g++
        }
        if (j) {
            this.syncCheckCssClass()
        }
        l.on("disabledchange", this.onDisabled, this)
    },
    onIdChange: function(b) {
        var a = Ext.util.Format.htmlEncode;
        if (this.rendered) {
            this.elNode.setAttribute("ext:tree-node-id", a(b))
        }
    },
    createInputField: function(b, a, c) {
        var d = b;
        if (Ext.isObject(b)) {
            this.inputConfig = Ext.apply({}, b);
            d = b.xtype || "textfield";
            delete b.xtype
        } else {
            this.inputConfig = {}
        }
        if (Ext.isDefined(a.value)) {
            this.inputConfig.value = a.value
        }
        this.inputConfig.renderTo = c;
        switch (d) {
            case "textfield":
                this.input = new SYNO.ux.TextField(this.inputConfig);
                break;
            case "numberfield":
                this.input = new SYNO.ux.NumberField(this.inputConfig);
                break
        }
    },
    initEvent: function() {
        var a = this.callParent(arguments);
        if (this.checkbox) {
            this.initCheckEvent()
        }
        return a
    },
    isChecked: function() {
        return this.getCheckValue()
    },
    isDisabled: function() {
        var a = this.node;
        return (true === a.disabled)
    },
    toggleCheck: function() {
        var a = this.checkbox;
        var b = true;
        if (true === this.node.disabled) {
            return
        }
        if (a) {
            this.setCheckValue(!this.getCheckValue(), b)
        }
    },
    onClick: function(a) {
        if (a.getTarget(".x-form-field")) {
            return
        }
        if (a.getTarget(".syno-backup-tri-tree-node-cb")) {
            this.toggleCheck()
        }
        return this.callParent(arguments)
    },
    onDblClick: function(a) {
        a.preventDefault();
        if (this.disabled) {
            return
        }
        if (this.fireEvent("beforedblclick", this.node, a) !== false) {
            if (!this.animating && this.node.isExpandable()) {
                this.node.toggle()
            }
            this.fireEvent("dblclick", this.node, a)
        }
    },
    onDisabled: function(b, a) {
        if (this.input) {
            if (a) {
                this.input.disable()
            } else {
                this.input.enable()
            }
        }
        if (this.checkbox) {
            if (a) {
                this.checkbox.classList.add("syno-ux-cb-disabled")
            } else {
                this.checkbox.classList.remove("syno-ux-cb-disabled")
            }
        }
    },
    onCheckChange: function(a) {
        this.syncCheckCssClass();
        this.fireEvent("checkchange", this.node, this.getCheckValue(), a)
    },
    isValid: function() {
        if (this.node.disabled) {
            return true
        }
        if (this.input && !this.input.isValid()) {
            return false
        }
        return true
    },
    getInputValue: function() {
        if (!this.input || this.disabled) {
            return undefined
        }
        return this.input.getValue()
    },
    setInputValue: function(a) {
        if (!this.input) {
            return
        }
        this.input.setValue(a)
    },
    getCheckValue: function() {
        return this.node.attributes.checked
    },
    setCheckValue: function(a, b) {
        if (this.node.disabled) {
            return
        }
        if (a === this.getCheckValue()) {
            return
        }
        if (a === "false" || a === "off" || a === "0") {
            a = false
        } else {
            if (a === "gray") {
                a = "gray"
            } else {
                a = (a ? true : false)
            }
        }
        if (false === b && true === this.node.attributes.is_user_modify && true === this.node.attributes.checked && false === a) {} else {
            this.node.attributes.checked = a;
            this.node.attributes.is_user_modify = a && b
        }
        this.onCheckChange(b)
    },
    syncCheckCssClass: function() {
        var b = this.getCheckValue();
        var a = this.checkbox;
        if (!a) {
            return
        }
        Ext.each(["checked", "grayed", "disabled"], function(c) {
            this.checkbox.classList.remove("syno-ux-cb-" + c)
        }, this);
        if (this.volumeWarnNode) {
            this.volumeWarnNode.classList.remove("syno-ux-cb-selected")
        }
        if (b === true) {
            this.checkbox.classList.add("syno-ux-cb-checked");
            if (this.volumeWarnNode) {
                this.volumeWarnNode.classList.add("syno-ux-cb-selected")
            }
        } else {
            if (b === "gray") {
                this.checkbox.classList.add("syno-ux-cb-grayed");
                if (this.volumeWarnNode) {
                    this.volumeWarnNode.classList.add("syno-ux-cb-selected")
                }
            }
        }
        if (this.node.disabled) {
            this.checkbox.classList.add("syno-ux-cb-disabled")
        }
    },
    initCheckEvent: function() {
        this.checkbox.addListener("mouseover", this.onCheckMouseover, this);
        this.checkbox.addListener("mouseout", this.onCheckMouseout, this);
        this.checkbox.addListener("focus", this.onCheckIconfocus, this);
        this.checkbox.addListener("blur", this.onCheckIconblur, this)
    },
    onCheckMouseover: function() {
        this.checkbox.classList.add("syno-ux-cb-hover")
    },
    onCheckMouseout: function() {
        this.checkbox.classList.remove("syno-ux-cb-hover")
    },
    onCheckIconfocus: function() {
        this.checkbox.classList.add("syno-ux-cb-focus")
    },
    onCheckIconblur: function() {
        this.checkbox.classList.remove("syno-ux-cb-focus")
    }
});
Ext.define("SYNO.SDS.Backup.TriTreeDisableCheckNodeUI", {
    extend: "SYNO.SDS.Backup.TriTreeNodeUI",
    checkShareNode: function(b, c, a) {
        if (!b.dependAppRows || 0 === b.dependAppRows.length) {
            return
        }
        Ext.each(b.dependAppRows, function(d) {
            if (d.get("checked")) {
                if (-1 === c.indexOf(b.text)) {
                    c.push(b.text)
                }
                if (-1 === a.indexOf(d.get("name"))) {
                    a.push(d.get("name"));
                    this.node.appRowsToBeUnselected.push(d)
                }
                this.node.appGrid = b.dependGrid
            }
        }, this)
    },
    setCheckValue: function(f, g) {
        if (true !== f && !this.node.clickConfirmed) {
            this.node.appRowsToBeUnselected = [];
            var e = [];
            var b = [];
            var h;
            var a = false;
            if ("fm_root" === this.node.id) {
                Ext.each(this.node.childNodes, function(i) {
                    this.checkShareNode(i, e, b);
                    if (true === i.isBackup) {
                        a = true
                    }
                }, this)
            } else {
                var d = this.node.id.substr(1).split("/", 1)[0];
                var c = this.node.getOwnerTree().getNodeById("/" + d);
                this.checkShareNode(c, e, b);
                a = c.isBackup
            }
            if (0 < b.length && 0 < e.length) {
                if (true !== g) {
                    return false
                }
                if (true === a) {
                    h = _T("backup", "unselect_share_alert_bkp")
                } else {
                    h = _T("backup", "unselect_share_alert_restore")
                }
                b.sort();
                h = String.format(h, e.join(", "), b.join(", "));
                this.node.getOwnerTree().owner.getMsgBox().confirm("", h, function(i) {
                    if ("yes" === i) {
                        this.node.clickConfirmed = true;
                        Ext.each(this.node.appRowsToBeUnselected, function(j) {
                            j.set("checked", false)
                        });
                        this.node.appRowsToBeUnselected = [];
                        if (this.node.appGrid) {
                            this.node.appGrid.syncCheckedStatus();
                            delete this.node.appGrid
                        }
                        this.setCheckValue(false, g)
                    }
                }, this);
                return false
            }
        }
        this.node.clickConfirmed = false;
        if (!f && this.node.disabled) {
            this.node.disabled = false;
            this.callParent(arguments);
            this.node.disabled = true;
            this.syncCheckCssClass()
        } else {
            this.callParent(arguments)
        }
    }
});
Ext.define("SYNO.SDS.Backup.TreeLoader", {
    extend: "Ext.tree.TreeLoader",
    sendWebAPI: undefined,
    webapi: undefined,
    nodeUI: undefined,
    constructor: function() {
        var a = arguments[0];
        if (a && a.webapi) {
            this.dataUrl = "dummy"
        }
        return this.callParent(arguments)
    },
    checkEncryption: function(d) {
        if (Ext.isArray(d.encryption) && !Ext.isEmpty(d.params)) {
            var b = d.encryption;
            for (var c = 0, a = b.length; c < a; c++) {
                if (b[c] in d.params) {
                    return
                }
            }
        }
        delete d.encryption
    },
    requestData: function(c, e, b) {
        if (this.fireEvent("beforeload", this, c, e) !== false) {
            if (this.directFn) {
                var a = this.getParams(c);
                a.push(this.processDirectResponse.createDelegate(this, [{
                    callback: e,
                    node: c,
                    scope: b
                }], true));
                this.directFn.apply(window, a)
            } else {
                if (this.nodeData && -1 !== this.owner.fm_root_nodes.indexOf(c.id)) {
                    this.handleNodeData(c, this.nodeData, e, b)
                } else {
                    if (Ext.isFunction(this.sendWebAPI)) {
                        var d = Ext.apply({}, {
                            params: this.getParams(c),
                            argument: {
                                callback: e,
                                node: c,
                                scope: b
                            },
                            callback: this.handleWebAPIResponse,
                            scope: this
                        }, this.webapi);
                        this.checkEncryption(d);
                        this.transId = this.sendWebAPI(d)
                    } else {
                        this.transId = Ext.Ajax.request({
                            method: this.requestMethod,
                            url: this.dataUrl || this.url,
                            success: this.handleResponse,
                            failure: this.handleFailure,
                            scope: this,
                            argument: {
                                callback: e,
                                node: c,
                                scope: b
                            },
                            params: this.getParams(c)
                        })
                    }
                }
            }
        } else {
            this.runCallback(e, b || c, [])
        }
    },
    handleNodeData: function(e, b, g, d) {
        if (Ext.isFunction(this.parseWebApiResponse)) {
            b = this.parseWebApiResponse.call(this, e, b)
        }
        e.beginUpdate();
        for (var c = 0, a = b.length; c < a; c++) {
            var f = this.createNode(b[c]);
            if (f) {
                e.appendChild(f)
            }
        }
        e.endUpdate();
        this.runCallback(g, d || e, [e]);
        this.fireEvent("load", this, e, b)
    },
    handleWebAPIResponse: function(l, b, f, m) {
        var k = m.argument,
            d = k.node;
        this.transId = false;
        if (l) {
            try {
                if (Ext.isFunction(this.parseWebApiResponse)) {
                    b = this.parseWebApiResponse.call(this, d, b)
                }
                d.beginUpdate();
                for (var g = 0, h = b.length; g < h; g++) {
                    if (b[g].recycle) {
                        continue
                    }
                    var c = this.createNode(b[g]);
                    if (c) {
                        d.appendChild(c)
                    }
                }
                d.endUpdate();
                this.runCallback(k.callback, k.scope || d, [d])
            } catch (j) {
                SYNO.Debug("tree loadexception");
                this.fireEvent("loadexception", this, d, b);
                this.runCallback(k.callback, k.scope || d, [d]);
                return
            }
            this.fireEvent("load", this, d, b)
        } else {
            this.fireEvent("loadexception", this, d, b);
            this.runCallback(k.callback, k.scope || d, [d])
        }
    },
    createNode: function(a) {
        var b;
        if (!a.uiProvider) {
            a.uiProvider = this.nodeUI ? this.nodeUI : "SYNO.SDS.Backup.TriTreeNodeUI"
        }
        a.draggable = false;
        if (Ext.isFunction(this.createNodeFn)) {
            b = this.createNodeFn.call(this.createNodeScope || this, a);
            if (b === false) {
                return
            }
        }
        var c = this.callParent(arguments);
        return c
    }
});
Ext.define("SYNO.SDS.Backup.BasicTreePanel", {
    extend: "SYNO.ux.TreePanel",
    constructor: function(a) {
        var b = Ext.apply({
            useArrows: true,
            autoScroll: true,
            containerScroll: true,
            bodyStyle: "overflow-x: hidden;overflow-y:auto; padding-right: 12px;",
            cls: "syno-backup-basic-tree-panel",
            enableDD: false,
            useGradient: false
        }, a);
        return this.callParent([b])
    },
    initEvents: function() {
        var a = this.callParent(arguments);
        this.mon(this, "checkchange", this.onCheckChange, this);
        this.mon(this, "expandnode", this.onExpandNode, this);
        return a
    },
    getCheckedSubTreeRoot: function(b) {
        var a = [];
        var c = function(d) {
            d.eachChild(function(f) {
                var e = f.getUI() || {};
                if (!Ext.isFunction(e.getCheckValue)) {
                    return
                }
                if (true === e.getCheckValue()) {
                    a.push(f)
                } else {
                    if ("gray" === e.getCheckValue()) {
                        c(f)
                    }
                }
            })
        };
        c(b || this.root);
        return a
    },
    onCheckChange: function(a, e, h) {
        var d, c, g, f = function(l) {
                var k = 0,
                    j = 0,
                    i = 0;
                l.eachChild(function(n) {
                    var m = n.getUI() || {};
                    if (m.checkbox && Ext.isFunction(m.getCheckValue) && (!Ext.isFunction(m.isDisabled) || !m.isDisabled())) {
                        if (true === m.getCheckValue()) {
                            j += 1
                        } else {
                            if (false === m.getCheckValue()) {
                                i += 1
                            }
                        }
                        k += 1
                    }
                });
                if (0 === k) {
                    return l.getUI().getCheckValue()
                } else {
                    if (j === k) {
                        return true
                    } else {
                        if (i === k) {
                            return false
                        } else {
                            return "gray"
                        }
                    }
                }
            },
            b = function(i) {
                var j = Ext.apply({}, i.attributes.depend);
                return Ext.applyIf(j, {
                    parent: false,
                    children: true
                })
            };
        g = b(a);
        if (true === g.children) {
            if (true === e) {
                a.eachChild(function(j) {
                    var i = j.getUI();
                    if (i && Ext.isFunction(i.setCheckValue) && (!Ext.isFunction(i.isDisabled) || !i.isDisabled())) {
                        i.setCheckValue(true, h)
                    }
                }, this)
            } else {
                if (false === e) {
                    a.eachChild(function(j) {
                        var i = j.getUI();
                        if (i && Ext.isFunction(i.setCheckValue) && (!Ext.isFunction(i.isDisabled) || !i.isDisabled())) {
                            i.setCheckValue(false, h)
                        }
                    }, this)
                }
            }
        }
        d = a.parentNode;
        while (d) {
            c = d.getUI();
            if (!c || !Ext.isFunction(c.getCheckValue)) {
                g = b(d);
                d = d.parentNode;
                continue
            }
            if (true === g.parent) {
                d.attributes.checked = f(d)
            } else {
                if (true === e && false === d.attributes.checked) {
                    d.attributes.checked = "gray"
                } else {
                    if (false === e) {
                        d.attributes.checked = f(d)
                    }
                }
            }
            c.syncCheckCssClass();
            g = b(d);
            d = d.parentNode
        }
    },
    onExpandNode: function(a) {
        var d = false;
        var b = a.getUI(),
            c = Ext.apply({}, a.attributes.depend);
        Ext.applyIf(c, {
            parent: false,
            children: true
        });
        if (!b || !Ext.isFunction(b.getCheckValue)) {
            return
        }
        if (true === c.children && true === b.getCheckValue()) {
            a.eachChild(function(e) {
                b = e.getUI();
                if (b && Ext.isFunction(b.isDisabled) && !b.isDisabled() && Ext.isFunction(b.setCheckValue)) {
                    b.setCheckValue(true, d)
                }
            }, this)
        }
    }
});
Ext.define("SYNO.SDS.Backup.QuadTreeNodeUI", {
    extend: "SYNO.SDS.Backup.TriTreeNodeUI",
    renderElements: function(f, c, e, b) {
        this.callParent(arguments);
        if (!f.state && c.state) {
            var d = Ext.getClassByName(c.state);
            f.state = new d({
                node: f
            })
        }
    },
    normalizeValue: function(a) {
        if (a === "false" || a === "off" || a === "0") {
            return false
        } else {
            if (a === "gray") {
                return "gray"
            }
        }
        return a ? true : false
    },
    toggleCheck: function() {
        var a = this.checkbox;
        if (true === this.node.disabled) {
            return
        }
        if (a) {
            this.node.dirty = true;
            this.node.state.toggleCheck()
        }
    },
    setCheckValue: function(a, b) {
        if (this.node.disabled) {
            return
        }
        if (a === this.getCheckValue()) {
            return
        }
        a = this.normalizeValue(a);
        if (false === b && true === this.node.attributes.is_user_modify && true === this.node.attributes.checked && false === a) {} else {
            this.node.attributes.checked = a;
            this.node.attributes.is_user_modify = a && b
        }
        this.syncCheckCssClass()
    }
});
Ext.define("SYNO.SDS.Backup.QuadTreeNodeState", {
    stateName: "unknown",
    isUserModify: true,
    constructor: function(a) {
        if (a && a.node) {
            this.setNode(a.node)
        }
    },
    setNode: function(a) {
        this.node = a
    },
    getNode: function() {
        return this.node
    },
    changeNodeState: function(a) {
        if (!this.getNode()) {
            return
        }
        this.getNode().changeState(a)
    },
    toggleCheck: function() {
        if (!this.getNode()) {
            return
        }
        this.setChildStatus();
        this.setSelfStatus();
        this.setParentStatus()
    },
    setDisable: function() {
        if (!this.getNode()) {
            return
        }
        this.getNode().state = new SYNO.SDS.Backup.QuadTreeNodePartialState({
            node: this.getNode()
        });
        this.getNode().state.toggleCheck();
        this.getNode().disable()
    },
    setEnable: function() {
        if (!this.getNode()) {
            return
        }
        this.getNode().enable()
    },
    setChildStatus: function() {},
    setSelfStatus: function() {},
    setParentStatus: function() {},
    cleanSubFolderPattern: function() {
        if (!this.getNode()) {
            return
        }
        var c = this.getNode().ownerTree;
        var a = c._folder_list;
        var b = c._excludeFolderList;
        var d = function(e) {
            var f = a.slice(0);
            var g = b.slice(0);
            Ext.each(f, function(h) {
                if (e === h || 0 === h.indexOf(String(e + "/"))) {
                    a.splice(a.indexOf(h), 1)
                }
            }, this);
            Ext.each(g, function(h) {
                if (String(e + "/") === h || 0 === h.indexOf(String(e + "/"))) {
                    b.splice(b.indexOf(h), 1)
                }
            }, this)
        };
        if (0 === this.getNode().attributes.id.indexOf("fm_root")) {
            this.getNode().eachChild(function(e) {
                d(e.attributes.id)
            })
        } else {
            d(this.getNode().attributes.id)
        }
    },
    setAllChildrenEmptyState: function() {
        var a = function(b) {
            if (this.getNode().attributes.id === b.attributes.id) {
                return true
            }
            if (!this.isUIAbleToSetValue(b)) {
                return false
            }
            b.getUI().setCheckValue(false, this.isUserModify);
            b.state = new SYNO.SDS.Backup.QuadTreeNodeEmptyState({
                node: b
            })
        };
        this.getNode().cascade(a, this);
        this.cleanSubFolderPattern()
    },
    setAllChildrenFullState: function() {
        var a = function(b) {
            if (this.getNode().attributes.id === b.attributes.id) {
                return true
            }
            if (!this.isUIAbleToSetValue(b)) {
                return false
            }
            b.getUI().setCheckValue(true, this.isUserModify);
            b.state = new SYNO.SDS.Backup.QuadTreeNodeFullState({
                node: b
            })
        };
        this.getNode().cascade(a, this);
        this.cleanSubFolderPattern()
    },
    checkAndSetParentEmptyState: function() {
        var a = function(b) {
            if (this.getNode().attributes.id === b.attributes.id) {
                return true
            }
            if (!this.isUIAbleToSetValue(b)) {
                return false
            }
            if (this.isAllChildrenInEmptyStatus(b) && "partial" === b.state.getStateName()) {
                b.ui.setCheckValue(false, this.isUserModify);
                b.state = new SYNO.SDS.Backup.QuadTreeNodeEmptyState({
                    node: b
                })
            }
        };
        this.getNode().bubble(a, this)
    },
    checkAndSetParentPartialState: function() {
        var a = function(b) {
            if (this.getNode().attributes.id === b.attributes.id) {
                return true
            }
            if (!this.isUIAbleToSetValue(b)) {
                return false
            } else {
                if ("empty" === b.state.getStateName()) {
                    b.getUI().setCheckValue("gray", this.isUserModify);
                    b.state = new SYNO.SDS.Backup.QuadTreeNodePartialState({
                        node: b
                    })
                }
            }
        };
        this.getNode().bubble(a, this)
    },
    updateSelfAndNextLevelChildrenConfig: function() {
        if (!this.getNode()) {
            return true
        }
        var d = this.getNode().id;
        var c = this.getNode().ownerTree;
        var b = -1;
        if (-1 !== c.fm_root_nodes.indexOf(d)) {
            this.getNode().eachChild(function(e) {
                if (-1 !== (b = c._excludeFolderList.indexOf(e.id + "/"))) {
                    c._excludeFolderList.splice(b, 1)
                }
            });
            return
        }
        if (-1 !== (b = c._folder_list.indexOf(d))) {
            c._folder_list.splice(b, 1)
        }
        var a = function(f, e) {
            return 0 === e.indexOf(f + "/") && f.length === e.lastIndexOf("/")
        };
        c._excludeFolderList = c._excludeFolderList.filter(function(e) {
            return !a(d, e.substr(0, e.length - 1))
        })
    },
    isAllChildrenInEmptyStatus: function(b) {
        if (!b) {
            return true
        }
        var a = true;
        b.eachChild(function(c) {
            if (true === c.getUI().getCheckValue() || "gray" === c.getUI().getCheckValue()) {
                a = false;
                return false
            }
        });
        return a
    },
    isUIAbleToSetValue: function(a) {
        if (!a) {
            return false
        }
        var b = a.getUI();
        if (b && Ext.isFunction(b.setCheckValue) && (!Ext.isFunction(b.isDisabled) || !b.isDisabled()) && a.state) {
            return true
        }
        return false
    },
    getStateName: function() {
        return this.stateName
    }
});
Ext.define("SYNO.SDS.Backup.QuadTreeNodeFullState", {
    extend: "SYNO.SDS.Backup.QuadTreeNodeState",
    stateName: "full",
    setChildStatus: function() {
        var a = this.getNode();
        if (!a.isExpanded()) {
            this.setAllChildrenEmptyState()
        }
        return
    },
    setSelfStatus: function() {
        var a = this.getNode();
        var b = a.getUI();
        if (!this.isUIAbleToSetValue(a)) {
            return
        }
        if (!a.isExpanded()) {
            b.setCheckValue(false, this.isUserModify);
            a.state = new SYNO.SDS.Backup.QuadTreeNodeEmptyState({
                node: this.getNode()
            })
        } else {
            if (this.isAllChildrenInEmptyStatus(a)) {
                b.setCheckValue(false, this.isUserModify);
                a.state = new SYNO.SDS.Backup.QuadTreeNodeEmptyState({
                    node: this.getNode()
                })
            } else {
                b.setCheckValue("gray", this.isUserModify);
                a.state = new SYNO.SDS.Backup.QuadTreeNodePartialState({
                    node: this.getNode()
                });
                this.updateSelfAndNextLevelChildrenConfig()
            }
        }
    },
    setParentStatus: function() {
        this.checkAndSetParentEmptyState()
    }
});
Ext.define("SYNO.SDS.Backup.QuadTreeNodePartialState", {
    extend: "SYNO.SDS.Backup.QuadTreeNodeState",
    stateName: "partial",
    setChildStatus: function() {
        this.setAllChildrenEmptyState()
    },
    setSelfStatus: function() {
        var a = this.getNode();
        a.getUI().setCheckValue(false, this.isUserModify);
        a.state = new SYNO.SDS.Backup.QuadTreeNodeEmptyState({
            node: a
        })
    },
    setParentStatus: function() {
        this.checkAndSetParentEmptyState()
    }
});
Ext.define("SYNO.SDS.Backup.QuadTreeNodeEmptyState", {
    extend: "SYNO.SDS.Backup.QuadTreeNodeState",
    stateName: "empty",
    setChildStatus: function() {
        this.setAllChildrenFullState()
    },
    setSelfStatus: function() {
        var a = this.getNode();
        a.getUI().setCheckValue(true, this.isUserModify);
        a.state = new SYNO.SDS.Backup.QuadTreeNodeFullState({
            node: a
        })
    },
    setParentStatus: function() {
        this.checkAndSetParentPartialState()
    }
});
Ext.define("SYNO.SDS.Backup.FormPanel", {
    extend: "SYNO.ux.FormPanel",
    initEvents: function() {
        this.callParent(arguments);
        this.initFieldGroup()
    },
    initFieldGroup: function() {
        var a = {},
            b = {};
        this.getForm().items.each(function(c) {
            if (c instanceof SYNO.ux.Radio && Ext.isArray(c.groupFields)) {
                a[c.name] = a[c.name] || {};
                a[c.name][c.inputValue] = c.groupFields
            }
            if (c instanceof SYNO.ux.Checkbox && Ext.isObject(c.groupFields)) {
                b[c.name] = [];
                b[c.name][0] = c.groupFields.enable;
                b[c.name][1] = c.groupFields.disable
            }
        });
        this.mon(this, "afterlayout", function() {
            var c;
            Ext.iterate(a, function(e, d) {
                c = new SYNO.ux.Utils.EnableRadioGroup(this.getForm(), e, d)
            }, this);
            Ext.iterate(b, function(d, e) {
                c = new SYNO.ux.Utils.EnableCheckGroup(this.getForm(), d, e[0], e[1])
            }, this)
        }, this, {
            single: true
        })
    }
});
Ext.define("SYNO.SDS.Backup.ComboBox", {
    extend: "SYNO.ux.ComboBox",
    owner: null,
    initComponent: function() {
        this.callParent(arguments);
        if (Ext.isObject(this.getParams) && Ext.isFunction(this.getParams.handler)) {
            this.getParams.scope = this.getParams.scope || this;
            this.getParams = Ext.createDelegate(this.getParams.handler, this.getParams.scope)
        }
    },
    initList: function() {
        if (!this.tpl) {
            this.tpl = '<tpl for="."><tpl if="values.qtip"><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.qtip)]}" class="x-combo-list-item {cls:htmlEncode}"></tpl><tpl if="!values.qtip"><div class="x-combo-list-item {cls:htmlEncode}"></tpl>{' + Ext.util.Format.htmlEncode(this.displayField) + ":htmlEncode}</div></tpl>"
        }
        this.callParent(arguments);
        if (Ext.isFunction(this.prepareData)) {
            this.view.prepareData = this.prepareData
        }
        if (this.store && this.owner) {
            this.mon(this.store, "beforeload", function() {
                if (this.busyText) {
                    this.owner.setStatusBusy({
                        text: this.busyText
                    })
                } else {
                    this.owner.setStatusBusy()
                }
            }, this);
            this.mon(this.store, "load", function(b, a, c) {
                this.owner.clearStatusBusy();
                this.cacheAPIParam = this.getParamCache(c.params || c.add)
            }, this);
            this.mon(this.store, "exception", function(c, d, e, b, a) {
                this.owner.clearStatusBusy();
                this.owner.reportError(a)
            }, this)
        }
        this.mon(this, "beforeselect", this.onBeforeSelect, this)
    },
    getParams: function() {
        return {}
    },
    onTriggerClick: function() {
        if (this.readOnly || this.disabled) {
            return
        }
        var a = this.getParams();
        if (Ext.isFunction(this.clickValidator) && !this.clickValidator(this, a)) {
            return
        }
        if (this.isExpanded()) {
            this.collapse()
        } else {
            this.onFocus({});
            if (this.cacheAPIParam === this.getParamCache(a)) {
                SYNO.ux.ComboBox.prototype.onTriggerClick.call(this, arguments)
            } else {
                this.checkEncryption(a);
                this.store.load({
                    params: a
                })
            }
        }
        this.el.focus()
    },
    onBeforeLoad: function() {
        if (!this.hasFocus) {
            return
        }
        this.selectedIndex = -1
    },
    onBeforeSelect: function(c, a, b) {
        return !a.get("disable")
    },
    checkEncryption: function(d) {
        if (Ext.isArray(this.store.proxy.encryption)) {
            var b = this.store.proxy.encryption;
            for (var c = 0, a = b.length; c < a; c++) {
                if (b[c] in d) {
                    return
                }
            }
        }
        delete this.store.proxy.encryption
    },
    getParamCache: function(b) {
        var a = Ext.apply({}, b);
        delete a[this.name];
        return Ext.encode(a)
    }
});
Ext.define("SYNO.SDS.Backup.ComboBoxAndDisplayField", {
    extend: "Ext.Container",
    _transToCombo: true,
    _displayField: "",
    _valueField: "",
    constructor: function(b) {
        var c = "comboBoxAndDisplayField",
            a = false;
        this._displayField = b.displayField;
        this._valueField = b.valueField;
        delete b.name;
        if (b.itemId) {
            c = b.itemId;
            delete b.itemId
        }
        if (b.hidden) {
            a = b.hidden;
            delete b.hidden
        }
        if (!Ext.isDefined(b.tpl)) {
            b.tpl = ['<tpl for="."><div ext:qtip="{[SYNO.SDS.Backup.Util.htmlEncodeTip(values.', this._displayField, ')]}" class="x-combo-list-item">{', this._displayField, ":htmlEncode}</div></tpl>"].join("")
        }
        var d = {
            layout: "form",
            itemId: c,
            hidden: a,
            items: [this._comboBox = new SYNO.ux.ComboBox(b), this._displayText = new SYNO.ux.DisplayField({
                fieldLabel: b.fieldLabel,
                value: "",
                hidden: true,
                listeners: {
                    render: function(e) {
                        if (!Ext.isEmpty(e.value)) {
                            this._textTip = new Ext.ToolTip({
                                target: e.getEl(),
                                html: e.value
                            })
                        }
                    },
                    scope: this
                }
            })]
        };
        this._comboBox.on("afterrender", function(e) {
            if (!this._comboTip) {
                this._comboTip = new Ext.ToolTip({
                    target: e.getEl(),
                    html: e.lastSelectionText
                })
            }
        }, this);
        this._comboBox.on("select", function(f, e) {
            this.getDisplayField().setValue(e.data[this._displayField]);
            if (!this._comboTip) {
                this._comboTip = new Ext.ToolTip({
                    target: f.getEl(),
                    html: e.data[this._displayField]
                })
            } else {
                this._comboTip.update(e.data[this._displayField])
            }
        }, this);
        this.callParent([d])
    },
    getComboBox: function() {
        return this._comboBox
    },
    getDisplayField: function() {
        return this._displayText
    },
    getValue: function() {
        if (!this.disabled && !this.getComboBox().disabled) {
            return this.getComboBox().getValue()
        } else {
            if (!this.disabled && !this.getDisplayField().disabled) {
                var a;
                Ext.each(this.getComboBox().store.getRange(), (function(b) {
                    if (b.data[this._displayField] === this.getDisplayField().getValue()) {
                        a = b.data[this._valueField];
                        return
                    }
                }).createDelegate(this));
                return a
            }
        }
    },
    setVisibleAndEnable: function(a) {
        if (a) {
            if (this._transToCombo) {
                this.transToComboBox()
            } else {
                this.transToText()
            }
        } else {
            this.hide();
            this.getComboBox().disable();
            this.getComboBox().hide();
            this.getDisplayField().disable();
            this.getDisplayField().hide()
        }
    },
    setValue: function(a) {
        this.getComboBox().setValue(a);
        Ext.each(this.getComboBox().store.getRange(), (function(b) {
            if (b.data[this._valueField] === a) {
                this.getDisplayField().setValue(b.data[this._displayField]);
                if (!this._textTip) {
                    this._textTip = new Ext.ToolTip({
                        target: this.getDisplayField().getEl(),
                        html: this.getDisplayField().getValue()
                    })
                } else {
                    if (this._textTip.getContentTarget()) {
                        this._textTip.update(this.getDisplayField().getValue())
                    }
                }
                return false
            }
        }).createDelegate(this))
    },
    transToText: function() {
        this._transToCombo = false;
        this.show();
        this.getComboBox().disable();
        this.getComboBox().hide();
        this.getDisplayField().enable();
        this.getDisplayField().show()
    },
    transToComboBox: function() {
        this._transToCombo = true;
        this.show();
        this.getComboBox().enable();
        this.getComboBox().show();
        this.getDisplayField().disable();
        this.getDisplayField().hide()
    }
});
Ext.define("SYNO.SDS.Backup.EnableColumn", {
    extend: "SYNO.ux.EnableColumn",
    constructor: function(a) {
        this.callParent(arguments);
        if (Ext.isObject(this.afterCheck) && Ext.isFunction(this.afterCheck.handler)) {
            this.afterCheck.scope = this.afterCheck.scope || this;
            this.afterCheck = Ext.createDelegate(this.afterCheck.handler, this.afterCheck.scope)
        }
    },
    isIgnore: function(b, a) {
        if (a.get("disabled")) {
            return true
        }
        return false
    },
    toggleRec: function(a) {
        this.callParent(arguments);
        if (Ext.isFunction(this.afterCheck)) {
            this.afterCheck(a)
        }
    },
    renderer: function(e, d, b) {
        var c = b.get("disabled") ? "disabled-" : "";
        var a = "gray" === e ? "grayed" : e ? "checked" : "unchecked";
        return String.format('<div class="syno-ux-grid-enable-column-{0}{1}">&nbsp;</div>', c, a)
    }
});
Ext.define("SYNO.SDS.Backup.PathBar", {
    extend: "Ext.Container",
    cls: "syno-sds-backup-pathbar",
    path: "",
    historyManager: null,
    initComponent: function() {
        this.callParent(arguments);
        if (!this.historyManager) {
            this.historyManager = new SYNO.SDS.Backup.HistoryManager()
        }
        if (!Ext.isEmpty(this.defaultPath)) {
            this.setPath(this.defaultPath)
        }
        this.addEvents("updatepath")
    },
    setPath: function(c, b) {
        if (c == this.path) {
            return false
        }
        var d = c.trim().split("/").filter(function(e) {
            return !Ext.isEmpty(e)
        });
        this.removeAll();
        if ("@pathRoot" !== d[0]) {
            d.unshift("@pathRoot")
        }
        var a = "";
        Ext.each(d, function(g, e, f) {
            if (Ext.isEmpty(g)) {
                return true
            }
            a += ("/" + g);
            var h = "syno-sds-backup-pathbutton";
            if (0 === e && "@pathRoot" == g) {
                return true
            } else {
                if (1 === e) {
                    h = "syno-sds-backup-pathbutton-first"
                }
            }
            this.add(new SYNO.SDS.Backup.PathButton({
                path: a,
                cls: h,
                owner: this,
                listeners: {
                    click: {
                        fn: function() {
                            this.owner.setPath(this.path)
                        }
                    }
                }
            }))
        }, this);
        this.path = a;
        this.doLayout();
        b = typeof b !== "undefined" ? b : false;
        if (this.historyManager && !b) {
            this.historyManager.addEvent(this.path)
        }
        this.fireEvent("updatepath", this)
    },
    getPath: function() {
        return this.path
    },
    getRelatedPath: function() {
        return this.path.substr("/@pathRoot".length + 1)
    },
    moveToPrevPath: function() {
        var a = null;
        if (this.historyManager) {
            a = this.historyManager.moveToPrevEvent();
            if (a) {
                this.setPath(a, true)
            }
        }
        return a
    },
    moveToNextPath: function() {
        var a = null;
        if (this.historyManager) {
            a = this.historyManager.moveToNextEvent();
            if (a) {
                this.setPath(a, true)
            }
        }
        return a
    },
    getPrevPath: function() {
        var a = null;
        if (this.historyManager) {
            a = this.historyManager.getPrevEvent()
        }
        return a
    },
    getNextPath: function() {
        var a = null;
        if (this.historyManager) {
            a = this.historyManager.getNextEvent()
        }
        return a
    }
});
Ext.define("SYNO.SDS.Backup.PathButton", {
    extend: "SYNO.ux.Button",
    cls: "syno-sds-backup-pathbutton",
    iconCls: "syno-sds-backup-pathbutton-text",
    path: "",
    initComponent: function() {
        this.setPath(this.path);
        this.callParent(arguments)
    },
    setPath: function(a) {
        if (!Ext.isEmpty(this.path)) {
            this.path = a;
            this.text = this.path.split("/").pop();
            this.tooltip = this.text
        }
    },
    getPath: function() {
        return this.path
    }
});
Ext.define("SYNO.SDS.Backup.HistoryManager", {
    history: [],
    historyPoint: -1,
    historyMaxLength: 30,
    addEvent: function(a) {
        if (this.history[this.historyPoint] === a) {
            return
        }
        this.history.splice(this.historyPoint + 1, this.history.length - (this.historyPoint + 1), a);
        if (this.history.length > this.historyMaxLength) {
            this.history.shift()
        }
        this.historyPoint = this.history.length - 1
    },
    moveToPrevEvent: function() {
        var a = null;
        if (0 < this.historyPoint) {
            this.historyPoint--;
            a = this.history[this.historyPoint]
        }
        return a
    },
    moveToNextEvent: function() {
        var a = null;
        if ((this.historyPoint + 1) < this.history.length) {
            this.historyPoint++;
            a = this.history[this.historyPoint]
        }
        return a
    },
    getPrevEvent: function() {
        var a = null;
        if (0 < this.historyPoint) {
            a = this.history[this.historyPoint - 1]
        }
        return a
    },
    getNextEvent: function() {
        var a = null;
        if ((this.historyPoint + 1) < this.history.length) {
            a = this.history[this.historyPoint + 1]
        }
        return a
    }
});
Ext.define("SYNO.SDS.Backup.ModuleList", {
    extend: "SYNO.ux.ModuleList",
    createLoader: function(a) {
        return new SYNO.SDS.Backup.TreeLoader(a.loaderCfg)
    }
});
Ext.define("SYNO.SDS.Backup.PageListAppWindow", {
    extend: "SYNO.SDS.AppWindow",
    layout: "border",
    border: false,
    plain: true,
    help: undefined,
    activePage: null,
    pageList: null,
    buttonList: null,
    listContainer: null,
    pageContainer: null,
    initComponent: function() {
        this.callParent(arguments);
        if (!this.listContainer) {
            this.listContainer = new Ext.Container({
                region: "west",
                width: 240,
                margins: "0 0 0 0",
                layout: {
                    type: "vbox",
                    align: "stretch"
                }
            })
        }
        if (this.buttonPanel) {
            this.listContainer.add(this.buttonPanel)
        } else {
            if (this.buttonItems) {
                this.buttonPanel = new SYNO.ux.Panel({
                    cls: "syno-sds-backup-button-panel",
                    layout: "hbox",
                    align: "stretch",
                    border: false,
                    items: this.buttonItems
                });
                this.listContainer.add(this.buttonPanel)
            }
        }
        if (!this.listPanel) {
            this.listPanel = new SYNO.ux.ModuleList({
                layout: "fit",
                align: "stretch",
                border: false,
                padding: "4px 16px 0 12px",
                flex: 1,
                listItems: this.listItems
            })
        }
        this.listContainer.add(this.listPanel);
        if (!this.pageContainer) {
            this.pageContainer = new Ext.Container({
                layout: "card",
                cls: "syno-backup-card-page-container",
                border: false,
                frame: false,
                hideMode: "offsets",
                region: "center"
            })
        }
        this.add(this.listContainer);
        this.add(this.pageContainer)
    },
    initEvents: function() {
        this.callParent(arguments);
        if (this.listPanel) {
            var a = this.listPanel.getSelectionModel();
            this.mon(a, "beforeselect", this.onBeforeSelect, this);
            this.mon(a, "selectionchange", this.onSelectionChange, this);
            this.mon(this.listPanel.getLoader(), "load", this.onListPanelLoad, this, {
                single: true
            })
        }
    },
    onListPanelLoad: function() {
        this.fireEvent("moduleready", this)
    },
    selectPage: function(b) {
        var a;
        if (!b || !this.listPanel) {
            return
        }
        a = this.listPanel.getNodeById(b);
        if (a && this.listPanel.getSelectionModel().isSelected(a)) {
            this.handleOpenParams()
        } else {
            this.listPanel.selectModule(b)
        }
    },
    getActivePage: function() {
        return this.pageContainer.layout.activeItem
    },
    getHelpParam: function() {
        var a, b;
        a = this.getActivePage();
        if (!a) {
            return this.help
        }
        if (Ext.isFunction(a.getHelpParam)) {
            return a.getHelpParam()
        }
        if (!this.listPanel) {
            return this.help
        }
        b = this.listPanel.getNodeById(a.itemId);
        if (!b) {
            return this.help
        }
        if (b.attributes && Ext.isString(b.attributes.help)) {
            return b.attributes.help
        }
        return this.help
    },
    onBeforeSelect: function(b, c, e) {
        var a, d = true;
        if (this.isSkipDeactivateCheck()) {
            this.clearSkipDeactivateCheck();
            return true
        }
        if (!c.leaf) {
            return true
        }
        if (!c.attributes.fn) {
            SYNO.Debug.error("Error: not implemented yet!!");
            return false
        }
        if (e && e.leaf) {
            a = this.pageContainer.getComponent(e.attributes.id);
            if (a && Ext.isFunction(a.onPageDeactivate)) {
                d = a.onPageDeactivate()
            }
        }
        if (false === d) {
            this.confirmLostChange(function(f) {
                if (a && Ext.isFunction(a.onPageConfirm)) {
                    a.onPageConfirm(f)
                }
                if (f === "yes") {
                    this.setSkipDeactivateCheck();
                    this.selectPage(c.attributes.fn)
                }
            }, this)
        }
        return d
    },
    onSelectionChange: function(a, c) {
        var e, b, d;
        if (!c || !c.leaf) {
            return
        }
        e = c.attributes.id;
        b = c.attributes.fn;
        d = c.attributes.pageConfig;
        if (e && b) {
            this.launchPage(e, b, d)
        }
    },
    onClose: function() {
        var a = this.getActivePage(),
            b = this.callParent(arguments);
        if (this.isSkipDeactivateCheck()) {
            this.clearSkipDeactivateCheck();
            return true
        }
        if (false === b) {
            return false
        }
        if (a && Ext.isFunction(a.onPageDeactivate)) {
            if (false === a.onPageDeactivate()) {
                this.confirmLostChange(function(c) {
                    if (a && Ext.isFunction(a.onPageConfirm)) {
                        a.onPageConfirm(c)
                    }
                    if (c === "yes") {
                        this.setSkipDeactivateCheck();
                        this.close()
                    }
                }, this);
                return false
            }
        }
        return b
    },
    launchEmptyPage: function(a) {
        if (this.emptyPageId && this.emptyPageFn) {
            if (this.launchPage(this.emptyPageId, this.emptyPageFn, a)) {
                return true
            }
        }
        return false
    },
    launchPage: function(e, c, d) {
        var b = this.pageContainer,
            a = b.getComponent(e);
        if (!a) {
            a = this.createPage(e, c, d);
            b.add(a)
        }
        if (!a) {
            return false
        }
        b.layout.setActiveItem(e);
        this.activePage = a;
        this.selectTab(0);
        if (a.onPageActivate) {
            a.onPageActivate(this.openParams)
        }
        return true
    },
    handleOpenParams: function() {
        if (Ext.isFunction(this.activePage.onPageFocus)) {
            this.activePage.onPageFocus(this.openParams)
        }
        if (this.openParams && this.openParams.tab) {
            this.selectTab(this.openParams.tab)
        }
    },
    selectTab: function(b) {
        var a = this.getActivePage();
        if (!a || !(a instanceof Ext.TabPanel)) {
            return
        }
        if (Ext.isFunction(a.setActiveTab)) {
            a.setActiveTab(b)
        }
    },
    createPage: function(g, d, f) {
        var e, b, c = this.appWin || this,
            a = c.jsConfig;
        e = Ext.getClassByName(d);
        b = new e(Ext.apply({
            appWin: c,
            jsConfig: a,
            owner: this
        }, f));
        b.itemId = g;
        return b
    },
    confirmLostChange: function(b, a) {
        this.getMsgBox().confirm("", _T("common", "confirm_lostchange"), b, a)
    },
    isSkipDeactivateCheck: function() {
        return !!this.skipDeactivateCheckFlag
    },
    setSkipDeactivateCheck: function() {
        this.skipDeactivateCheckFlag = true
    },
    clearSkipDeactivateCheck: function() {
        this.skipDeactivateCheckFlag = false
    },
    onOpen: function(a) {
        this.callParent(arguments);
        this.onLaunchPage(a)
    },
    onRequest: function(a) {
        this.callParent(arguments);
        this.onLaunchPage(a)
    },
    onLaunchPage: function(b) {
        if (!this.listPanel) {
            return
        }
        var a = this.listPanel.getRootNode();
        if (a && a.childrenRendered && a.childNodes.length > 0) {
            this.launchPageOnOpen(b)
        } else {
            this.mon(this, "moduleready", function() {
                this.launchPageOnOpen(b)
            }, this, {
                single: true
            })
        }
    },
    launchPageOnOpen: function(a) {
        var b;
        if (this.checkModalOrMask()) {
            return
        }
        if (a && a.id) {
            b = a.id
        } else {
            b = this.activePage
        }
        this.openParams = a;
        this.selectPage(b);
        this.openParams = null
    }
});
Ext.define("SYNO.SDS.Backup.RepoTypeButton", {
    extend: "Ext.Container",
    cls: "syno-backup-destination-button",
    initComponent: function() {
        this.callParent(arguments);
        if (this.selected) {
            this.addClass("selected")
        }
        this.repoIcon = new Ext.Container({
            height: 24,
            width: 24,
            cls: "syno-backup-destination-icon"
        });
        if (this.iconCls) {
            this.repoIcon.addClass(this.iconCls);
            delete this.iconCls
        }
        this.add(this.repoIcon);
        if (this.title) {
            var d = "&nbsp;" + SYNO.SDS.Backup.String("app", "beta");
            var a = '<span style="color:#0086E5">' + d + "</span>";
            var b = (!this.options.beta) ? this.title : (this.title + d);
            var c = (!this.options.beta) ? this.title : (this.title + a);
            this.repoText = new Ext.Container({
                html: '<div class="syno-backup-destination-innertext" ext:qtip="' + b + '" >' + c + "</div>",
                cls: "syno-backup-destination-text"
            });
            delete this.title;
            if (this.textCls) {
                this.repoText.addClass(this.textCls);
                delete this.textCls
            }
            this.add(this.repoText)
        }
    },
    afterRender: function() {
        if (Ext.isFunction(this.clickHandler)) {
            this.mon(this.el, "click", this.clickHandler)
        }
        this.callParent(arguments)
    }
});
Ext.define("SYNO.SDS.Backup.SimpleScheduleComponent", {
    extend: "SYNO.ux.FieldSet",
    canUnckeckSchedule: true,
    owner: undefined,
    constructor: function(b) {
        var a;
        if (b.canUnckeckSchedule) {
            a = {
                xtype: "syno_checkbox",
                name: "schedule_enable",
                id: this.schedule_enable_id = Ext.id(),
                boxLabel: _T("netbackup", "netbkp_set_schedule"),
                checked: true
            }
        } else {
            a = {
                xtype: "syno_displayfield",
                name: "schedule_enable",
                id: this.schedule_enable_id = Ext.id(),
                value: SYNO.SDS.Backup.String("app", "backup_schedule_title") + _T("common", "colon")
            }
        }
        this.owner = b.owner;
        var c = Ext.apply({
            name: "schedule_fieldset",
            cls: "syno-backup-simple-schedule-component",
            collapsible: false,
            bwrapStyle: {
                padding: 0
            },
            items: [a, {
                xtype: "container",
                layout: "hbox",
                cls: "simple-schedule-runtime-field",
                items: [{
                    xtype: "spacer",
                    width: 28
                }, {
                    xtype: "container",
                    width: 210,
                    html: SYNO.SDS.Backup.String("app", "detect_schedule_run_time") + ":"
                }, {
                    xtype: "spacer",
                    width: 8
                }, {
                    xtype: "syno_schedulefield",
                    name: "basic_weekday",
                    id: this.basic_weekday_id = Ext.id(),
                    allowBlank: false,
                    editable: false,
                    width: 115
                }, {
                    xtype: "spacer",
                    width: 6
                }, {
                    xtype: "syno_combobox",
                    store: SYNO.SDS.Backup.createTimeItemStore("hour"),
                    displayField: "display",
                    name: "hour",
                    id: this.hour_id = Ext.id(),
                    valueField: "value",
                    triggerAction: "all",
                    mode: "local",
                    width: 70,
                    editable: false
                }, {
                    xtype: "spacer",
                    html: ":",
                    width: 14,
                    cls: "simple-schedule-spacer"
                }, {
                    xtype: "syno_combobox",
                    store: SYNO.SDS.Backup.createTimeItemStore("min"),
                    displayField: "display",
                    name: "minute",
                    id: this.minute_id = Ext.id(),
                    valueField: "value",
                    triggerAction: "all",
                    width: 70,
                    mode: "local",
                    editable: false
                }]
            }]
        }, b);
        this.callParent([c])
    },
    initEvents: function() {
        if (this.owner) {
            var a;
            a = new SYNO.ux.Utils.EnableCheckGroup(this.owner.getForm(), "schedule_enable", ["basic_weekday", "hour", "minute"], [])
        }
    },
    setCheckBoxVisible: function(b) {
        var a = function(e, c) {
            var d = c * 30;
            Ext.getCmp(e).getEl().up("div.x-form-item").down("label").setStyle("margin-left", d + "px")
        };
        if (true === b) {
            Ext.getCmp(this.schedule_enable_id).show();
            a(this.basic_weekday_id, 1);
            a(this.hour_id, 1)
        } else {
            Ext.getCmp(this.schedule_enable_id).hide();
            a(this.basic_weekday_id, 0);
            a(this.hour_id, 0)
        }
    },
    setData: function(a) {
        Ext.getCmp(this.schedule_enable_id).setValue(a.schedule_enable);
        Ext.getCmp(this.hour_id).setValue(a.hour);
        Ext.getCmp(this.minute_id).setValue(a.minute);
        Ext.getCmp(this.basic_weekday_id).setValue(a.week_day)
    },
    getData: function() {
        var b = Ext.getCmp(this.schedule_enable_id).getValue();
        var a = Ext.getCmp(this.basic_weekday_id).getValue();
        var c = Ext.getCmp(this.hour_id).getValue();
        var d = Ext.getCmp(this.minute_id).getValue();
        if (!this.canUnckeckSchedule) {
            b = true
        }
        return {
            schedule_enable: b,
            hour: c,
            min: d,
            date_type: 0,
            repeat: 0,
            repeat_hour: 0,
            last_work_hour: c,
            week_name: String(a)
        }
    }
});
Ext.define("SYNO.SDS.Backup.IntegrityCheckSchedulePanel", {
    extend: "SYNO.ux.Panel",
    targetType: undefined,
    containerLabelWidth: undefined,
    constructor: function(b) {
        this.FREQUENCY_ID_WEEKLY = 1024;
        this.blSupportTimeLimit = true;
        var d = new Ext.data.ArrayStore({
            fields: ["display", "value"],
            data: [
                [_T("schedule", "no_repeat"), 0],
                [SYNO.SDS.Backup.String("app", "detect_schedule_weekly"), this.FREQUENCY_ID_WEEKLY],
                [_T("schedule", "repeat_monthly"), 1],
                [_T("schedule", "repeat_yearly"), 2],
                [_T("schedule", "repeat_half_year"), 3]
            ]
        });
        var a = {
            xtype: "syno_datetimefield",
            name: "incheck_date",
            width: 140,
            allowBlank: false,
            editable: false,
            value: new Date(),
            maxValue: "2037/12/31",
            minValue: "2005/1/1"
        };
        if (!SYNO.SDS.DateTimeUtils) {
            a.format = "Y/n/j"
        }
        var c = Ext.apply({
            name: "incheck_schedule_fieldset",
            cls: "syno-integrity-check-schedule-component",
            layout: "form",
            items: [{
                xtype: "syno_checkbox",
                name: "incheck_schedule_enable",
                boxLabel: SYNO.SDS.Backup.String("app", "detect_schedule_enable"),
                checked: true
            }, {
                xtype: "syno_compositefield",
                fieldLabel: SYNO.SDS.Backup.String("app", "detect_schedule_run_time"),
                itemId: "date_composite",
                indent: 1,
                items: [a, {
                    xtype: "syno_combobox",
                    store: SYNO.SDS.Backup.createTimeItemStore("hour"),
                    name: "incheck_hour",
                    displayField: "display",
                    valueField: "value",
                    triggerAction: "all",
                    mode: "local",
                    width: 70,
                    allowBlank: false,
                    editable: false,
                    value: 5
                }, {
                    xtype: "syno_displayfield",
                    value: ":",
                    width: 2
                }, {
                    xtype: "syno_combobox",
                    store: SYNO.SDS.Backup.createTimeItemStore("min"),
                    name: "incheck_min",
                    displayField: "display",
                    valueField: "value",
                    triggerAction: "all",
                    width: 70,
                    mode: "local",
                    allowBlank: false,
                    editable: false,
                    value: 0
                }]
            }, {
                xtype: "syno_combobox",
                indent: 1,
                name: "incheck_frequency",
                store: d,
                fieldLabel: SYNO.SDS.Backup.String("app", "detect_schedule_frequency"),
                displayField: "display",
                valueField: "value",
                value: this.FREQUENCY_ID_WEEKLY,
                allowBlank: false,
                editable: false,
                width: 220
            }, {
                xtype: "syno_checkbox",
                indent: 1,
                name: "incheck_data_enable",
                boxLabel: SYNO.SDS.Backup.String("app", "detect_schedule_data"),
                checked: true,
                hidden: b.targetType === "cloud_image"
            }, {
                xtype: "syno_compositefield",
                indent: 2,
                itemId: "time_limit_composite",
                hidden: b.targetType === "cloud_image",
                hideLabel: true,
                items: [{
                    xtype: "syno_checkbox",
                    name: "incheck_time_limit_enable",
                    boxLabel: SYNO.SDS.Backup.String("app", "detect_schedule_limit"),
                    checked: true,
                    width: b.containerLabelWidth - 60
                }, {
                    xtype: "syno_numberfield",
                    name: "incheck_time_limit",
                    width: 70,
                    value: 30,
                    allowBlank: true,
                    maxValue: 10080,
                    minValue: 1
                }, {
                    xtype: "syno_displayfield",
                    value: _T("common", "time_minutes"),
                    width: 70
                }]
            }]
        }, b);
        this.callParent([c])
    },
    initEvents: function() {
        this.callParent(arguments);
        var a;
        a = new SYNO.ux.Utils.EnableCheckGroup(this.owner.getForm(), "incheck_time_limit_enable", ["incheck_time_limit"], []);
        a = new SYNO.ux.Utils.EnableCheckGroup(this.owner.getForm(), "incheck_data_enable", ["incheck_time_limit_enable"], []);
        a = new SYNO.ux.Utils.EnableCheckGroup(this.owner.getForm(), "incheck_schedule_enable", ["incheck_date", "incheck_hour", "incheck_min", "incheck_frequency", "incheck_data_enable"], [])
    },
    setData: function(e, a) {
        var b = this.owner.getForm();
        if (Ext.isEmpty(e)) {
            b.findField("incheck_schedule_enable").setValue(false);
            b.findField("incheck_date").setValue(new Date());
            b.findField("incheck_hour").setValue(5);
            b.findField("incheck_min").setValue(0);
            b.findField("incheck_frequency").setValue(this.FREQUENCY_ID_WEEKLY);
            b.findField("incheck_data_enable").setValue(true);
            b.findField("incheck_time_limit_enable").setValue(true);
            b.findField("incheck_time_limit").setValue(30);
            this.setSupportTimeLimit(a);
            return
        }
        var d = e.schedule;
        if (d) {
            b.findField("incheck_hour").setValue(d.hour);
            b.findField("incheck_min").setValue(d.min);
            b.findField("incheck_frequency").setValue(d.date_type == 1 ? d.repeat : this.FREQUENCY_ID_WEEKLY)
        }
        var c = e.info;
        if (c) {
            b.findField("incheck_date").setValue(Date.parseDate(c.date, "Y/n/j"));
            b.findField("incheck_data_enable").setValue(c.data_enable);
            if (0 === c.time_limit) {
                b.findField("incheck_time_limit_enable").setValue(false);
                b.findField("incheck_time_limit").setValue(30)
            } else {
                b.findField("incheck_time_limit_enable").setValue(true);
                b.findField("incheck_time_limit").setValue(c.time_limit)
            }
        }
        b.findField("incheck_schedule_enable").setValue(e.schedule_enable);
        this.setSupportTimeLimit(a)
    },
    getData: function() {
        var b = this.owner.getForm();
        var c = b.findField("incheck_date").getValue();
        if (Ext.isEmpty(c)) {
            c = new Date()
        }
        var h = c.format("Y/n/j");
        var d = b.findField("incheck_hour").getValue();
        var a = b.findField("incheck_frequency").getValue() == this.FREQUENCY_ID_WEEKLY ? 0 : 1;
        var i = "";
        if (0 === a) {
            i = String(c.getDay())
        }
        var e = b.findField("incheck_data_enable").getValue();
        var j = b.findField("incheck_time_limit_enable").getValue();
        var g = b.findField("incheck_time_limit").getValue();
        if (this.targetType === "cloud_image") {
            e = true;
            g = 0
        } else {
            if (false === j || !this.blSupportTimeLimit) {
                g = 0
            }
        }
        var f = {
            schedule_enable: b.findField("incheck_schedule_enable").getValue(),
            date_type: a,
            date: h,
            hour: d,
            min: b.findField("incheck_min").getValue(),
            repeat: a == 1 ? b.findField("incheck_frequency").getValue() : 0,
            repeat_hour: 0,
            last_work_hour: d,
            week_name: i,
            info: {
                data_enable: e,
                time_limit: g,
                date: h
            }
        };
        return f
    },
    setSupportTimeLimit: function(a) {
        this.blSupportTimeLimit = a;
        if (this.targetType !== "cloud_image") {
            this.getComponent("time_limit_composite").setVisible(a)
        }
    },
    onShow: function() {
        this.callParent(arguments);
        this.getComponent("date_composite").setVisible(true);
        this.getComponent("time_limit_composite").setVisible(this.targetType !== "cloud_image")
    }
});
Ext.define("SYNO.SDS.Backup.SimpleIntegrityCheckPanel", {
    extend: "SYNO.ux.Panel",
    targetType: undefined,
    containerLabelWidth: undefined,
    constructor: function(a) {
        this.blSupportTimeLimit = true;
        var b = Ext.apply({
            name: "incheck_schedule_fieldset",
            cls: "syno-integrity-check-schedule-component",
            layout: "form",
            bodyStyle: "padding-right: 0px;",
            items: [{
                xtype: "syno_checkbox",
                name: "incheck_schedule_enable",
                boxLabel: SYNO.SDS.Backup.String("app", "detect_schedule_enable"),
                checked: true
            }, {
                xtype: "container",
                layout: "hbox",
                cls: "integrity-check-runtime-field",
                name: "incheck_date_composite",
                itemId: "date_composite",
                items: [{
                    xtype: "spacer",
                    width: 28
                }, {
                    xtype: "container",
                    hideLabel: true,
                    width: 210,
                    html: SYNO.SDS.Backup.String("app", "detect_schedule_run_time") + ":"
                }, {
                    xtype: "spacer",
                    width: 8
                }, {
                    xtype: "syno_combobox",
                    store: this.getWeekdayStore(),
                    displayField: "display",
                    valueField: "value",
                    triggerAction: "all",
                    mode: "local",
                    name: "incheck_basic_weekday",
                    width: 115,
                    allowBlank: false,
                    value: "0",
                    editable: false
                }, {
                    xtype: "spacer",
                    width: 6
                }, {
                    xtype: "syno_combobox",
                    store: SYNO.SDS.Backup.createTimeItemStore("hour"),
                    name: "incheck_weekday_hour",
                    displayField: "display",
                    valueField: "value",
                    triggerAction: "all",
                    mode: "local",
                    width: 70,
                    allowBlank: false,
                    editable: false,
                    value: 5
                }, {
                    xtype: "spacer",
                    width: 14,
                    value: ":",
                    cls: "integrity-check-spacer"
                }, {
                    xtype: "syno_combobox",
                    store: SYNO.SDS.Backup.createTimeItemStore("min"),
                    name: "incheck_weekday_min",
                    displayField: "display",
                    valueField: "value",
                    triggerAction: "all",
                    width: 70,
                    mode: "local",
                    allowBlank: false,
                    editable: false,
                    value: 0
                }]
            }, {
                xtype: "container",
                layout: "hbox",
                cls: "integrity-check-data-field",
                hidden: a.targetType === "cloud_image",
                hideLabel: true,
                items: [{
                    xtype: "spacer",
                    width: 28
                }, {
                    xtype: "syno_checkbox",
                    width: 210,
                    name: "incheck_data_enable",
                    checked: true,
                    boxLabel: SYNO.SDS.Backup.String("app", "detect_schedule_data")
                }, {
                    xtype: "spacer",
                    width: 8
                }, {
                    xtype: "syno_combobox",
                    name: "incheck_time_policy",
                    width: 208,
                    store: this.getTimePolicyStore([10, 30, 60], true),
                    displayField: "display",
                    value: 30,
                    valueField: "value"
                }]
            }]
        }, a);
        this.callParent([b])
    },
    initEvents: function() {
        this.callParent(arguments);
        var a;
        a = new SYNO.ux.Utils.EnableCheckGroup(this.owner.getForm(), "incheck_data_enable", ["incheck_time_policy"], []);
        a = new SYNO.ux.Utils.EnableCheckGroup(this.owner.getForm(), "incheck_schedule_enable", ["incheck_weekday_hour", "incheck_weekday_min", "incheck_data_enable", "incheck_basic_weekday"], [])
    },
    setData: function(e, a) {
        var b = this.owner.getForm();
        if (Ext.isEmpty(e)) {
            b.findField("incheck_schedule_enable").setValue(true);
            b.findField("incheck_basic_weekday").setValue("0");
            b.findField("incheck_data_enable").setValue(true);
            b.findField("incheck_time_policy").setValue(30);
            b.findField("incheck_weekday_hour").setValue(0);
            b.findField("incheck_weekday_min").setValue(0);
            return
        }
        var d = e.schedule;
        if (d) {
            b.findField("incheck_weekday_hour").setValue(d.hour);
            b.findField("incheck_weekday_min").setValue(d.min)
        }
        var c = e.info;
        if (c) {
            if (c.week_name) {
                b.findField("incheck_basic_weekday").setValue(c.week_name)
            } else {
                b.findField("incheck_basic_weekday").setValue("0")
            }
            b.findField("incheck_data_enable").setValue(c.data_enable);
            b.findField("incheck_time_policy").setValue(c.time_limit)
        } else {
            b.findField("incheck_basic_weekday").setValue("0");
            b.findField("incheck_data_enable").setValue(true);
            b.findField("incheck_time_policy").setValue(30)
        }
        b.findField("incheck_schedule_enable").setValue(e.schedule_enable);
        this.setSupportTimeLimit(a)
    },
    getData: function() {
        var a = this.owner.getForm();
        var j = 24 * 60 * 60 * 1000;
        var c;
        var b = new Date();
        var k = a.findField("incheck_basic_weekday").getValue();
        var d = a.findField("incheck_weekday_hour").getValue();
        var e = a.findField("incheck_weekday_min").getValue();
        if (k - b.getDay() === 0) {
            if (b.getHours() === d) {
                if (b.getMinutes() < e) {
                    c = b
                } else {
                    c = new Date((b.getTime() + 7 * j))
                }
            } else {
                if (b.getHours() < d) {
                    c = b
                } else {
                    c = new Date((b.getTime() + 7 * j))
                }
            }
        } else {
            c = new Date(b.getTime() + (((k - b.getDay()) % 7) + 7) % 7 * j)
        }
        var i = c.format("Y/n/j");
        var f = a.findField("incheck_data_enable").getValue();
        var h = a.findField("incheck_time_policy").getValue();
        if (this.targetType === "cloud_image") {
            f = true;
            h = 0
        } else {
            if (!this.blSupportTimeLimit) {
                h = 0
            }
        }
        var g = {
            schedule_enable: a.findField("incheck_schedule_enable").getValue(),
            date_type: 0,
            date: i,
            hour: d,
            min: e,
            repeat: 0,
            repeat_hour: 0,
            last_work_hour: d,
            week_name: String(k),
            info: {
                data_enable: f,
                time_limit: h,
                date: i
            }
        };
        return g
    },
    getWeekdayStore: function() {
        return new Ext.data.ArrayStore({
            fields: ["display", "value"],
            data: [
                [SYNO.SDS.Backup.String("app", "schedule_sun"), 0],
                [SYNO.SDS.Backup.String("app", "schedule_mon"), 1],
                [SYNO.SDS.Backup.String("app", "schedule_tue"), 2],
                [SYNO.SDS.Backup.String("app", "schedule_wed"), 3],
                [SYNO.SDS.Backup.String("app", "schedule_thu"), 4],
                [SYNO.SDS.Backup.String("app", "schedule_fri"), 5],
                [SYNO.SDS.Backup.String("app", "schedule_sat"), 6]
            ]
        })
    },
    getTimePolicyStore: function(b, c) {
        if (!b || b.length === 0) {
            return null
        }
        var a = [];
        if (c === true) {
            a.push([SYNO.SDS.Backup.String("app", "no_time_limit"), 0])
        }
        Ext.each(b, function(e, d) {
            a.push([String.format(SYNO.SDS.Backup.String("app", "less_than_minutes"), e), e])
        }, this);
        return new Ext.data.ArrayStore({
            fields: ["display", "value"],
            data: a
        })
    },
    setSupportTimeLimit: function(a) {
        this.blSupportTimeLimit = a;
        if (this.targetType !== "cloud_image") {
            this.owner.getForm().findField("incheck_time_policy").setVisible(a)
        }
    },
    onShow: function() {
        this.callParent(arguments);
        this.getComponent("date_composite").setVisible(true);
        this.owner.getForm().findField("incheck_time_policy").setVisible(this.targetType !== "cloud_image")
    }
});
Ext.define("SYNO.SDS.Backup.NewFeaturePanel", {
    extend: "SYNO.ux.Panel",
    constructor: function(a) {
        var b = this;
        var c = {
            cls: "syno-backup-new-feature-panel",
            items: [{
                xtype: "container",
                cls: "syno-backup-new-feature-panel-close-btn",
                listeners: {
                    afterrender: function(d) {
                        d.getEl().on("click", function() {
                            b.destroy()
                        })
                    }
                }
            }, {
                xtype: "syno_displayfield",
                cls: "syno-backup-new-feature-panel-title",
                value: SYNO.SDS.Backup.String("app", "new_feature")
            }, {
                xtype: "syno_displayfield",
                cls: "syno-backup-new-feature-panel-desc",
                html: SYNO.SDS.Backup.String("app", "file_only_backup_tip") + '&nbsp;<span class="syno-backup-learn-more-text">' + SYNO.SDS.Backup.String("app", "learn_more") + "</span>",
                listeners: {
                    afterrender: function(d) {
                        d.getEl().child(".syno-backup-learn-more-text").on("click", b.openHelpCenter.bind(b))
                    }
                }
            }, {
                xtype: "container",
                cls: "syno-backup-new-feature-panel-checkbox-container",
                itemId: "promptContainer",
                items: [{
                    xtype: "syno_checkbox",
                    itemId: "prompt",
                    boxLabel: SYNO.SDS.Backup.String("app", "do_not_show_again"),
                    listeners: {
                        check: function(e, d) {
                            b.updateUserPrompt(d)
                        }
                    }
                }, {
                    xtype: "container"
                }]
            }]
        };
        Ext.apply(c, a);
        this.callParent([c])
    },
    updateUserPrompt: function(a) {
        this.appInstance.setUserSettings("show_parent_file_only_tip", !a)
    },
    openHelpCenter: function() {
        if (!this.appInstance || !this.appInstance.jsConfig) {
            return
        }
        var a = this.subTopic ? this.appInstance.jsConfig.jsID + ":" + this.subTopic : this.appInstance.jsConfig.jsID;
        SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
            topic: a
        }, false)
    }
});
