/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.GIT");
/**
 * @class SYNO.SDS.GIT.Instance
 * @extends SYNO.SDS.AppInstance
 * Git application instance class
 *
 */
Ext.define("SYNO.SDS.GIT.Instance", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.GIT.MainWindow",
    constructor: function() {
        this.callParent(arguments)
    }
});
/**
 * @class SYNO.SDS.GIT.MainWindow
 * @extends SYNO.SDS.AppWindow
 * Git main window class
 *
 */
Ext.define("SYNO.SDS.GIT.MainWindow", {
    extend: "SYNO.SDS.AppWindow",
    grid: null,
    pageSize: 50,
    constructor: function(a) {
        var b = this;
        var c = new SYNO.API.JsonStore({
            appWindow: b,
            api: "SYNO.Git.lib",
            method: "enum_user",
            version: 1,
            fields: ["name", "enable_git", "editable"],
            root: "data",
            remoteSort: false,
            pruneModifiedRecords: true
        });
        this.grid = this.createGridPanel(c);
        a = Ext.apply({
            resizable: false,
            maximizable: false,
            minimizable: true,
            width: 600,
            height: 350,
            layout: "fit",
            items: [this.grid],
            buttons: [{
                xtype: "syno_button",
                text: _T("common", "cancel"),
                ctCls: "git-btn",
                scope: this,
                handler: function() {
                    b.close()
                }
            }, {
                xtype: "syno_button",
                text: _T("common", "commit"),
                scope: this,
                ctCls: "git-btn",
                btnStyle: "blue",
                handler: function() {
                    b.doApply()
                }
            }]
        }, a);
        this.callParent([a])
    },
    doApply: function() {
        var b = this.grid.getStore().getModifiedRecords();
        var a = [];
        if (b.length === 0) {
            return
        }
        for (var c = 0; c < b.length; c++) {
            a.push(b[c].data)
        }
        this.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.Git.lib",
            method: "apply",
            version: 1,
            scope: this,
            params: {
                data: Ext.util.JSON.encode(a)
            },
            callback: function(g, f, e, d) {
                if (!g) {
                    this.getMsgBox().alert("title", _T("error", "error_unknown"))
                }
                this.clearStatusBusy();
                this.refresh()
            }
        })
    },
    createGridPanel: function(c) {
        var b = new SYNO.ux.EnableColumn({
            align: "center",
            id: "enable_git",
            header: _TT("SYNO.SDS.GIT.Instance", "ui", "can_use_git"),
            dataIndex: "enable_git",
            isIgnore: function(f, e) {
                return !e.get("editable")
            },
            renderer: function(g, f, e) {
                if (e.get("editable")) {
                    return SYNO.ux.EnableColumn.prototype.renderer.call(this, g, f, e)
                } else {
                    return SYNO.ux.EnableColumn.prototype.disableRenderer.call(this, e.get("enable_git"), f, e)
                }
            },
            enableFastSelectAll: false
        });
        var d = new SYNO.ux.TextFilter({
            itemId: "search",
            emptyText: _T("user", "search_user"),
            store: c,
            pageSize: this.pageSize
        });
        var a = {
            itemId: "grid",
            border: false,
            store: c,
            loadMask: true,
            enableHdMenu: false,
            plugins: [b],
            columns: [{
                header: _T("user", "user_account"),
                dataIndex: "name",
                width: 300
            }, b],
            autoExpandColumn: "enable_git",
            viewConfig: {
                emptyText: _TT("SYNO.SDS.GIT.Instance", "ui", "grid_emptyText")
            },
            tbar: {
                items: ["->", d]
            },
            bbar: new SYNO.ux.PagingToolbar({
                store: c,
                displayInfo: true,
                pageSize: this.pageSize
            })
        };
        return new SYNO.ux.GridPanel(a)
    },
    initEvents: function() {
        SYNO.SDS.GIT.MainWindow.superclass.initEvents.apply(this, arguments);
        this.grid.getStore().load({
            params: {
                offset: 0,
                limit: this.pageSize
            }
        });
        this.refresh()
    },
    refresh: function() {
        this.grid.getStore().reload();
        this.grid.getView().refresh()
    }
});
