/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.OAuthService.Instance
 * @extends SYNO.SDS.AppInstance
 * OAuthService application instance class
 *
 */  
Ext.define("SYNO.SDS.OAuthService.Instance", {
    extend: "SYNO.SDS.AppInstance",
    appWindowName: "SYNO.SDS.OAuthService.MainWindow"
});
Ext.define("SYNO.SDS.OAuthService.MainWindow", {
    extend: "SYNO.SDS.PageListAppWindow",
    width: 990,
    height: 560,
    activePage: "SYNO.SDS.OAuthService.SettingPanel",
    constructor: function(a) {
        var b = [{
            iconCls: "icon-application-list",
            text: SYNO.SDS.OAuthService._V("app", "application"),
            fn: "SYNO.SDS.OAuthService.SettingPanel"
        }, {
            iconCls: "icon-client-list",
            text: SYNO.SDS.OAuthService._V("app", "authorization_list"),
            fn: "SYNO.SDS.OAuthService.AuthorizationPanel"
        }, {
            iconCls: "icon-log",
            text: SYNO.SDS.OAuthService._V("app", "log"),
            fn: "SYNO.SDS.OAuthService.LogPanel"
        }];
        var c = {
            cls: "syno-app-oauthservice",
            width: 990,
            height: 560,
            minWidth: 990,
            minHeight: 560,
            listItems: b
        };
        Ext.apply(c, a);
        this.callParent([c])
    }
});
Ext.define("SYNO.SDS.OAuthService.SettingPanel", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(b) {
        this.owner = b.appWin;
        this.createStore();
        this.createActions();
        this.pageSize = 20;
        this.actionEditMenu = new SYNO.ux.Menu({
            items: [this.actions.clientEnable, this.actions.clientDisable]
        });
        this.actionEdit = new Ext.Action({
            text: SYNO.SDS.OAuthService._V("action", "edit"),
            scope: this,
            menu: this.actionEditMenu
        });
        var a = Ext.apply({
            enableColumnMove: false,
            store: this.store,
            colModel: this.createColumnModel(),
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: false
            }),
            listeners: {
                rowcontextmenu: this.onRowContextMenu,
                rowclick: this.checkSelect
            },
            tbar: [new SYNO.ux.Button(this.actionEdit), "->", new SYNO.ux.Button(this.actions.commonSetting)],
            bbar: new SYNO.ux.PagingToolbar({
                store: this.store,
                pageSize: this.pageSize,
                displayInfo: true
            })
        }, b);
        this.callParent([a])
    },
    onRowContextMenu: function(b, f, c) {
        var a = this.getSelectionModel();
        var d = new SYNO.ux.Menu({
            autoDestroy: true,
            items: [this.actions.clientEnable, this.actions.clientDisable]
        });
        a.suspendEvents(false);
        a.selectRow(f, a.isSelected(f));
        this.checkSelect(b, f, c);
        d.showAt(c.getXY());
        c.preventDefault()
    },
    checkSelect: function(a, f, d) {
        var b = this.getSelectionModel().getCount();
        if (b > 1) {
            this.enableAction("clientEnable", true);
            this.enableAction("clientDisable", true)
        } else {
            if (b === 1) {
                var c = a.getStore().getAt(f).data.enable;
                this.enableAction("clientEnable", !c);
                this.enableAction("clientDisable", c)
            } else {
                this.enableAction("clientEnable", false);
                this.enableAction("clientDisable", false)
            }
        }
    },
    enableAction: function(a, b) {
        var c = this.actions[a];
        if (c) {
            if (b) {
                c.enable()
            } else {
                c.disable()
            }
        }
    },
    onException: function(b, a, c) {
        console.log("Load exception");
        this.owner.clearStatusBusy()
    },
    onBeforeLoad: function(a, b) {
        a.removeAll();
        this.owner.setStatusBusy()
    },
    onLoad: function(b, a, c) {
        this.owner.clearStatusBusy();
        this.checkSelect()
    },
    onPageActivate: function() {
        this.store.load()
    },
    createStore: function() {
        this.store = new SYNO.API.JsonStore({
            api: "SYNO.OAUTH.Client",
            method: "list",
            version: 1,
            appWindow: this.owner,
            listeners: {
                exception: {
                    scope: this,
                    fn: this.onException
                },
                beforeload: {
                    scope: this,
                    fn: this.onBeforeLoad
                },
                load: {
                    scope: this,
                    fn: this.onLoad
                }
            },
            baseParams: {
                offset: 0,
                limit: 20
            },
            root: "client",
            totalProperty: "total",
            fields: ["display_name", "redirect_uri", "scope", "enable", "id"],
            scope: this
        });
        return this.store
    },
    createActions: function() {
        var a = function(e, d, c, b) {
            return new Ext.Action(Ext.apply({
                text: e,
                handler: d,
                scope: c
            }, b))
        };
        this.actions = {
            clientEnable: a(SYNO.SDS.OAuthService._V("action", "enable"), this.onClientEnable, this),
            clientDisable: a(SYNO.SDS.OAuthService._V("action", "disable"), this.onClientDisable, this),
            commonSetting: a(SYNO.SDS.OAuthService._V("action", "common_setting"), this.onCommonSetting, this)
        };
        return this.actions
    },
    createColumnModel: function() {
        return new Ext.grid.ColumnModel([{
            header: SYNO.SDS.OAuthService._V("field", "application_name"),
            dataIndex: "display_name",
            width: 130
        }, {
            header: SYNO.SDS.OAuthService._V("field", "redirect_uri"),
            dataIndex: "redirect_uri",
            width: 130
        }, {
            header: SYNO.SDS.OAuthService._V("field", "authorization"),
            dataIndex: "scope",
            width: 200
        }, {
            header: SYNO.SDS.OAuthService._V("field", "status"),
            dataIndex: "enable",
            width: 100,
            renderer: function(a) {
                if (a === true) {
                    return SYNO.SDS.OAuthService._V("common", "enabled")
                } else {
                    return SYNO.SDS.OAuthService._V("common", "disabled")
                }
            }
        }])
    },
    onCommonSetting: function() {
        var a = new SYNO.SDS.OAuthService.CommonSettingDialog({
            owner: this.owner
        });
        a.open()
    },
    getSelectionIDs: function() {
        var c = this.getSelectionModel().getSelections();
        var b = [];
        for (var a = 0; a < c.length; a++) {
            b.push(c[a].data.id)
        }
        return b
    },
    onClientEnable: function() {
        var a = this.getSelectionIDs();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.OAUTH.Client",
            method: "enable",
            version: 1,
            scope: this,
            params: {
                id: a
            },
            callback: function(d, c, b) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.owner.getMsgBox().alert("", _T("error", "error_unknown"))
                } else {
                    this.store.load()
                }
            }
        })
    },
    onClientDisable: function() {
        var a = this.getSelectionIDs();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.OAUTH.Client",
            method: "disable",
            version: 1,
            scope: this,
            params: {
                id: a
            },
            callback: function(d, c, b) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.owner.getMsgBox().alert("", _T("error", "error_unknown"))
                } else {
                    this.store.load()
                }
            }
        })
    }
});
Ext.define("SYNO.SDS.OAuthService.CommonSettingDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(b) {
        this.formPanel = this.createFormPanel();
        this.form = this.formPanel.getForm();
        var a = Ext.apply({
            title: SYNO.SDS.OAuthService._V("action", "common_setting"),
            width: 500,
            height: 160,
            resizable: false,
            items: [this.formPanel],
            buttons: [{
                xtype: "syno_button",
                text: SYNO.SDS.OAuthService._V("common", "cancel"),
                handler: this.onCancel,
                scope: this
            }, {
                xtype: "syno_button",
                btnStyle: "blue",
                text: SYNO.SDS.OAuthService._V("common", "apply"),
                handler: this.onApply,
                scope: this
            }]
        }, b);
        this.callParent([a])
    },
    onCancel: function() {
        this.close()
    },
    onApply: function() {
        if (!this.form.isValid()) {
            this.setStatusError({
                text: SYNO.SDS.OAuthService._V("common", "forminvalid"),
                clear: true
            });
            return
        }
        if (this.form.isDirty()) {
            this.applySetting()
        } else {
            this.close()
        }
    },
    applySetting: function() {
        this.owner.setStatusBusy();
        var a = {
            token_expired: this.form.findField("token_expired").getValue()
        };
        this.sendWebAPI({
            api: "SYNO.OAUTH.Common",
            version: 1,
            method: "set",
            params: a,
            scope: this,
            callback: function(c, b) {
                this.owner.clearStatusBusy();
                if (!c) {
                    this.owner.getMsgBox().alert("", SYNO.SDS.OAuthService._V("error", "error_unknown"));
                    return
                }
                this.close()
            }
        })
    },
    onOpen: function() {
        this.callParent(arguments);
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.OAUTH.Common",
            version: 1,
            method: "get",
            scope: this,
            callback: function(b, a) {
                this.owner.clearStatusBusy();
                if (!b) {
                    this.owner.getMsgBox().alert("", SYNO.SDS.OAuthService._V("error", "error_unknown"));
                    return
                }
                this.form.setValues(a)
            }
        })
    },
    createFormPanel: function() {
        var a = {
            trackResetOnLoad: true,
            layout: "form",
            labelWidth: 300,
            items: [{
                xtype: "syno_numberfield",
                fieldLabel: SYNO.SDS.OAuthService._V("field", "token_expired_after") + "(" + SYNO.SDS.OAuthService._V("common", "time_seconds") + ")",
                name: "token_expired",
                allowBlank: false,
                allowDecimals: false,
                maxValue: 604800,
                minValue: 1,
                width: 130
            }]
        };
        return new SYNO.ux.FormPanel(a)
    }
});
Ext.define("SYNO.SDS.OAuthService.AuthorizationPanel", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(b) {
        this.owner = b.appWin;
        this.createStore();
        this.createActions();
        this.pageSize = 20;
        var a = Ext.apply({
            enableColumnMove: false,
            store: this.store,
            colModel: this.createColumnModel(),
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: false
            }),
            listeners: {
                rowcontextmenu: this.onRowContextMenu,
                rowclick: this.checkSelect
            },
            tbar: [new SYNO.ux.Button(this.actions.revoke)],
            bbar: new SYNO.ux.PagingToolbar({
                store: this.store,
                pageSize: this.pageSize,
                displayInfo: true
            })
        }, b);
        this.callParent([a])
    },
    onRowContextMenu: function(b, f, c) {
        var a = this.getSelectionModel();
        var d = new SYNO.ux.Menu({
            autoDestroy: true,
            items: [this.actions.revoke]
        });
        a.suspendEvents(false);
        a.selectRow(f, a.isSelected(f));
        this.checkSelect();
        d.showAt(c.getXY());
        c.preventDefault()
    },
    checkSelect: function() {
        var a = this.getSelectionModel().getCount();
        this.enableAction("revoke", (a !== 0))
    },
    enableAction: function(a, c) {
        var b = this.actions[a];
        if (b) {
            if (c) {
                b.enable()
            } else {
                b.disable()
            }
        }
    },
    onException: function(b, a, c) {
        console.log("Load exception");
        this.owner.clearStatusBusy()
    },
    onBeforeLoad: function(a, b) {
        a.removeAll();
        this.owner.setStatusBusy()
    },
    onLoad: function(b, a, c) {
        this.owner.clearStatusBusy();
        this.checkSelect()
    },
    onPageActivate: function() {
        this.store.load()
    },
    createStore: function() {
        this.store = new SYNO.API.JsonStore({
            api: "SYNO.OAUTH.Token",
            method: "list",
            version: 1,
            appWindow: this.owner,
            listeners: {
                exception: {
                    scope: this,
                    fn: this.onException
                },
                beforeload: {
                    scope: this,
                    fn: this.onBeforeLoad
                },
                load: {
                    scope: this,
                    fn: this.onLoad
                }
            },
            baseParams: {
                offset: 0,
                limit: 20
            },
            root: "token",
            totalProperty: "total",
            fields: ["username", "display_name", "scope", "ip", "expired_time", "id"],
            scope: this
        });
        return this.store
    },
    createActions: function() {
        var a = function(e, d, c, b) {
            return new Ext.Action(Ext.apply({
                text: e,
                handler: d,
                scope: c
            }, b))
        };
        this.actions = {
            revoke: a(SYNO.SDS.OAuthService._V("action", "revoke"), this.onRevoke, this)
        };
        return this.actions
    },
    createColumnModel: function() {
        return new Ext.grid.ColumnModel([{
            header: SYNO.SDS.OAuthService._V("field", "username"),
            dataIndex: "username",
            width: 130
        }, {
            header: SYNO.SDS.OAuthService._V("field", "application_name"),
            dataIndex: "display_name",
            width: 130
        }, {
            header: SYNO.SDS.OAuthService._V("field", "authorization"),
            dataIndex: "scope",
            width: 200
        }, {
            header: SYNO.SDS.OAuthService._V("field", "ip"),
            dataIndex: "ip",
            width: 100
        }, {
            header: SYNO.SDS.OAuthService._V("field", "expired_time"),
            dataIndex: "expired_time",
            renderer: SYNO.SDS.OAuthService.timeRenderer,
            width: 275
        }])
    },
    getSelectionIDs: function() {
        var c = this.getSelectionModel().getSelections();
        var b = [];
        for (var a = 0; a < c.length; a++) {
            b.push(c[a].data.id)
        }
        return b
    },
    onRevoke: function() {
        var a = this.getSelectionIDs();
        this.owner.setStatusBusy();
        this.sendWebAPI({
            api: "SYNO.OAUTH.Token",
            method: "revoke",
            version: 1,
            scope: this,
            params: {
                id: a
            },
            callback: function(d, c, b) {
                this.owner.clearStatusBusy();
                if (!d) {
                    this.owner.getMsgBox().alert("", _T("error", "error_unknown"))
                } else {
                    this.store.load()
                }
            }
        })
    }
});
Ext.define("SYNO.SDS.OAuthService.LogPanel", {
    extend: "SYNO.ux.GridPanel",
    constructor: function(b) {
        this.owner = b.appWin;
        this.createStore();
        this.createActions();
        this.pageSize = 20;
        this.findField = new SYNO.ux.TextFilter({
            iconStyle: "search",
            itemId: "search",
            queryAction: "list",
            enumAction: "list",
            queryParam: "substr",
            store: this.store,
            pageSize: this.pageSize
        });
        var a = Ext.apply({
            enableColumnMove: false,
            store: this.store,
            colModel: this.createColumnModel(),
            selModel: new Ext.grid.RowSelectionModel({
                singleSelect: false
            }),
            listeners: {
                rowcontextmenu: this.onRowContextMenu
            },
            tbar: [new SYNO.ux.Button(this.actions.clearLog), new SYNO.ux.Button(this.actions.exportLog), "->", this.findField],
            bbar: new SYNO.ux.PagingToolbar({
                store: this.store,
                pageSize: this.pageSize,
                displayInfo: true
            })
        }, b);
        this.callParent([a])
    },
    onRowContextMenu: function(b, f, c) {
        var a = this.getSelectionModel();
        var d = new SYNO.ux.Menu({
            autoDestroy: true,
            items: [this.actions.clearLog, this.actions.exportLog]
        });
        a.suspendEvents(false);
        a.selectRow(f);
        d.showAt(c.getXY());
        c.preventDefault()
    },
    enableAction: function(a, b) {
        var c = this.actions[a];
        if (c) {
            if (b) {
                c.enable()
            } else {
                c.disable()
            }
        }
    },
    onException: function(b, a, c) {
        console.log("Load exception");
        this.owner.clearStatusBusy()
    },
    onBeforeLoad: function(a, b) {
        a.removeAll();
        this.owner.setStatusBusy()
    },
    onLoad: function(b, a, c) {
        this.owner.clearStatusBusy();
        if (a.length > 0) {
            this.enableAction("clearLog", true);
            this.enableAction("exportLog", true)
        } else {
            this.enableAction("clearLog", false);
            this.enableAction("exportLog", false)
        }
    },
    onPageActivate: function() {
        this.store.load()
    },
    createStore: function() {
        this.store = new SYNO.API.JsonStore({
            api: "SYNO.OAUTH.Log",
            method: "list",
            version: 1,
            appWindow: this.owner,
            listeners: {
                exception: {
                    scope: this,
                    fn: this.onException
                },
                beforeload: {
                    scope: this,
                    fn: this.onBeforeLoad
                },
                load: {
                    scope: this,
                    fn: this.onLoad
                }
            },
            baseParams: {
                offset: 0,
                limit: 20
            },
            root: "log",
            totalProperty: "total",
            fields: ["timestamp", "msg"],
            scope: this
        });
        return this.store
    },
    createActions: function() {
        var a = function(e, d, c, b) {
            return new Ext.Action(Ext.apply({
                text: e,
                handler: d,
                scope: c
            }, b))
        };
        this.actions = {
            clearLog: a(SYNO.SDS.OAuthService._V("action", "clear"), this.onClearLog, this),
            exportLog: a(SYNO.SDS.OAuthService._V("action", "export"), this.onExportLog, this)
        };
        return this.actions
    },
    createColumnModel: function() {
        return new Ext.grid.ColumnModel([{
            header: SYNO.SDS.OAuthService._V("field", "datetime"),
            dataIndex: "timestamp",
            renderer: SYNO.SDS.OAuthService.timeRenderer,
            width: 60
        }, {
            header: SYNO.SDS.OAuthService._V("field", "msg"),
            dataIndex: "msg",
            width: 200
        }])
    },
    onClearLog: function() {
        this.owner.getMsgBox().confirmDelete(this.owner.title, SYNO.SDS.OAuthService._V("log", "log_cfrm_clear"), function(a) {
            if ("yes" === a) {
                this.owner.setStatusBusy();
                this.sendWebAPI({
                    api: "SYNO.OAUTH.Log",
                    version: 1,
                    method: "del",
                    scope: this,
                    callback: function(c, b) {
                        this.owner.clearStatusBusy();
                        if (!c) {
                            this.owner.getMsgBox().alert("", SYNO.SDS.OAuthService._V("error", "error_unknown"));
                            return
                        }
                        this.store.load()
                    }
                })
            }
        }, this)
    },
    onExportLog: function() {
        this.downloadWebAPI({
            webapi: {
                api: "SYNO.OAUTH.Log",
                method: "export",
                version: 1
            }
        })
    }
});
Ext.ns("SYNO.SDS.OAuthService");
SYNO.SDS.OAuthService._V = function(b, a) {
    if (("app" === b) || ("action" === b) || ("field" === b)) {
        return _TT("SYNO.SDS.OAuthService.Instance", b, a)
    } else {
        return _T(b, a)
    }
};
SYNO.SDS.OAuthService.DateTimeFormatter = SYNO.SDS.DateTimeFormatter || function(b, a) {
    if (!b || Object.prototype.toString.call(b) !== "[object Date]") {
        return ""
    }
    return b.format("Y/m/d H:i:s")
};
SYNO.SDS.OAuthService.timeRenderer = function(a) {
    return SYNO.SDS.OAuthService.DateTimeFormatter(Date.parseDate(a, "Y-n-j g:i:s"), {
        type: "datetimesec"
    })
};
