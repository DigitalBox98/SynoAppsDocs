/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS.C2FS"), 
/**
 * @class SYNO.SDS.C2FS.Helper
 * C2FS helper
 *
 */
SYNO.SDS.C2FS.Helper = {
    MAX_C2_SHARE_NUM: 1,
    PKG_ID: "HybridShare",
    T: function(e, t) {
        return _TT("SYNO.SDS.C2FS.Application", e, t) || _T(e, t) || String.format("{0}", t)
    },
    pkgVersion: function() {
        return SYNO.SDS.Config.FnMap["SYNO.SDS.C2FS.Application"].hasOwnProperty("config") && SYNO.SDS.Config.FnMap["SYNO.SDS.C2FS.Application"].config.hasOwnProperty("version") ? SYNO.SDS.Config.FnMap["SYNO.SDS.C2FS.Application"].config.version : ""
    },
    mask: function(e, t) {
        void 0 !== t ? e.getEl().mask(t) : e.getEl().mask()
    },
    maskinfo: function(e, t) {
        void 0 !== t && e.getEl().mask(t, "syno-ux-mask-info")
    },
    maskSaving: function(e) {
        e.getEl().mask(_T("common", "saving"), "x-mask-loading")
    },
    maskWaiting: function(e) {
        e.getEl().mask(_T("common", "msg_waiting"), "x-mask-loading")
    },
    maskLoading: function(e) {
        e.getEl().mask(_T("common", "loading"), "x-mask-loading")
    },
    maskLoadingOnce: function(e, t) {
        void 0 === t.maskLoaded && (this.maskLoading(e), t.maskLoaded = !0)
    },
    unmask: function(e) {
        e.getEl().unmask()
    },
    toolTipRenderer: function(e, t, i) {
        if (!e || "-" === e) return "-";
        var s = Ext.util.Format.htmlEncode(e),
            r = Ext.util.Format.htmlEncode(s);
        return String.format('<span ext:qtip="{0}">{1}</span>', r, s)
    },
    getSelectedObjectFromCombobox: function(e) {
        return e && e.hasOwnProperty("selectedIndex") && e.hasOwnProperty("store") ? e.getStore().getAt(e.selectedIndex) || e.getStore().getById(e.getValue()) : null
    },
    popupErrorMessage: function(e, t, i) {
        var s = SYNO.SDS.C2FS.Helper.ErrorMap.T(t) || SYNO.SDS.C2FS.Helper.T("common", "error_system");
        if (!e || !e.getMsgBox) return !1;
        e.getMsgBox().alert(e.title, s, i || Ext.emptyFn)
    },
    popupFeasibilityCheckMsg: function(e, t, i) {
        var s = SYNO.SDS.C2FS.Helper.T("common", "error_system");
        return t && t.hard ? (s = SYNO.SDS.C2FS.Helper.T("share", "edit_hard_check_fail"), s += "<br><b>" + SYNO.SDS.Utils.GetFeasibilityCheckMsgJoin(t.hard) + "</b>", void e.getMsgBox().alert("warning_msg", s)) : t && t.soft ? (s = SYNO.SDS.C2FS.Helper.T("share", "edit_soft_check_fail"), s += "<br><b>" + SYNO.SDS.Utils.GetFeasibilityCheckMsgJoin(t.soft) + "</b>", void e.getMsgBox().confirm("warning_msg", s, function(e) {
            "yes" === e && i()
        }, e)) : void e.getMsgBox().alert("warning_msg", s)
    },
    timeRender: function(e, t, i) {
        var s = {
            s: 1,
            m: 2,
            h: 3,
            d: 4
        };
        (i = s[i] ? s[i] : s.d) < (t = s[t] ? s[t] : s.s) && (i = [t, t = i][0]);
        var r = [],
            n = 0,
            a = 0,
            o = 0;
        return i > s.s && (n = e / 60, e %= 60), i > s.m && (a = n / 60, n %= 60), i > s.h && (o = a / 24, a %= 24), e = Math.floor(e), n = Math.floor(n), a = Math.floor(a), o = Math.floor(o), t <= s.d && 0 !== o && r.push(String.format("{0} {1}", o, 1 === o ? SYNO.SDS.C2FS.Helper.T("common", "time_day") : SYNO.SDS.C2FS.Helper.T("common", "time_days"))), t <= s.h && 0 !== a && r.push(String.format("{0} {1}", a, 1 === a ? SYNO.SDS.C2FS.Helper.T("common", "time_hour") : SYNO.SDS.C2FS.Helper.T("common", "time_hours"))), t <= s.m && 0 !== n && r.push(String.format("{0} {1}", n, 1 === n ? SYNO.SDS.C2FS.Helper.T("common", "time_minute") : SYNO.SDS.C2FS.Helper.T("common", "time_minutes"))), t <= s.s && 0 !== e && r.push(String.format("{0} {1}", e, 1 === e ? SYNO.SDS.C2FS.Helper.T("common", "time_second") : SYNO.SDS.C2FS.Helper.T("common", "time_seconds"))), 0 === r.length && (t === s.d && r.push(String.format("{0} {1}", o, SYNO.SDS.C2FS.Helper.T("common", "time_day"))), t === s.h && r.push(String.format("{0} {1}", a, SYNO.SDS.C2FS.Helper.T("common", "time_hour"))), t === s.m && r.push(String.format("{0} {1}", n, SYNO.SDS.C2FS.Helper.T("common", "time_minute"))), t === s.s && r.push(String.format("{0} {1}", e, SYNO.SDS.C2FS.Helper.T("common", "time_second")))), r.join(" ")
    },
    approximateTime: function(e, t) {
        return e ? (t || (t = 4), [86400, 3600, 60, 1].reduce(function(i, s) {
            return t ? (i += e - e % s, e %= s, i > 0 && t--, i) : i
        }, 0)) : 0
    },
    percentRender: function(e, t, i) {
        return parseFloat((100 * e / t).toFixed(i || 2)) + "%"
    },
    capacityRender: function(e, t) {
        var i = SYNO.SDS.C2FS.Helper.T("common", "size_kb"),
            s = e;
        return s < 0 && (s = 0), s >= 1024 && (s /= 1024, i = SYNO.SDS.C2FS.Helper.T("common", "size_mb")), s >= 1024 && (s /= 1024, i = SYNO.SDS.C2FS.Helper.T("common", "size_gb")), s >= 1024 && (s /= 1024, i = SYNO.SDS.C2FS.Helper.T("common", "size_tb")), s.toFixed(Number.isInteger(t) && t >= 0 ? t : 2) + " " + i
    },
    addAlignedBullet: function(e) {
        return String.format('<div style="display:inline-flex; line-height:20px; margin-top:8px;"><div>&#8226;</div><div style="padding-left:8px;">{0}</div></div>', e)
    }
}, SYNO.SDS.C2FS.Helper.ErrorMap = {
    ERR_NO_SUCH_API: 102,
    ERR_NO_SUCH_METHODS: 103,
    ERR_BAD_PARAMETER: 401,
    ERR_OPERATION: 402,
    ERR_BACKUP: 403,
    ERR_RESTORE: 404,
    ERR_OPEN_FILE: 405,
    ERR_READ_FILE: 406,
    ERR_NO_FILE: 407,
    ERR_NOT_JSON: 408,
    ERR_NOT_SUBVOLUME: 409,
    ERR_NOT_FEASIBLE: 410,
    ERR_INVALID_SHARENAME: 500,
    ERR_NO_SUCH_SHARE: 501,
    ERR_NOT_C2SHARE: 502,
    ERR_VOLUME_IS_NOT_BTRFS: 503,
    ERR_VOLUME_IS_READ_ONLY: 504,
    ERR_TARGET_SHARE_NAME_EXISTED: 505,
    ERR_TARGET_VOLUME_IS_NOT_BTRFS: 506,
    ERR_TARGET_VOLUME_IS_READ_ONLY: 507,
    ERR_TARGET_SHARE_PATH_EXISTS: 508,
    ERR_MULTI_MOUNT: 509,
    ERR_UPDATE_ATTRIBUTE: 510,
    ERR_LOCAL_CACHE_MAX_EXCEED: 510,
    ERR_BAD_CONF: 512,
    ERR_CACHE_SIZE_TOO_LOW: 513,
    ERR_DESCRIPTION_TOO_LONG: 514,
    ERR_UNSYNC_EXCEED_CACHE_SIZE: 515,
    ERR_EXCEED_C2_SHARE_NUM: 518,
    ERR_SHARE_NAME_RESERVED: 519,
    ERR_BUCKET_CONNECT: 600,
    ERR_BUCKET_INFO: 601,
    ERR_BUCKET_NOT_FOUND: 602,
    ERR_BUCKET_INVALID_SCOPED_TOKEN: 603,
    ERR_BUCKET_NOT_SUITABLE_PASSWORD: 604,
    ERR_BUCKET_ENCRYPT_FAILED: 605,
    ERR_BUCKET_IS_ALREADY_MOUNT: 606,
    ERR_BUCKET_ALREADY_ENCRYPT: 607,
    ERR_BUCKET_WRONG_PASSWORD: 608,
    ERR_BUCKET_BAD_PASSWORD_KEY: 609,
    ERR_C2FS_CLIENT_VERSION_INCOMPATIBLE: 700,
    T: function(e) {
        switch (e) {
            case this.ERR_NO_SUCH_API:
            case this.ERR_NO_SUCH_METHODS:
                return SYNO.SDS.C2FS.Helper.T("share", "c2_need_package");
            case this.ERR_BAD_PARAMETER:
            case this.ERR_OPERATION:
            case this.ERR_BACKUP:
            case this.ERR_RESTORE:
            case this.ERR_OPEN_FILE:
            case this.ERR_READ_FILE:
            case this.ERR_NO_FILE:
            case this.ERR_NOT_JSON:
            case this.ERR_NOT_SUBVOLUME:
            case this.ERR_NOT_FEASIBLE:
                return "";
            case this.ERR_INVALID_SHARENAME:
                return SYNO.SDS.C2FS.Helper.T("share", "error_badname");
            case this.ERR_NO_SUCH_SHARE:
                return SYNO.SDS.C2FS.Helper.T("share", "no_such_share");
            case this.ERR_NOT_C2SHARE:
                return SYNO.SDS.C2FS.Helper.T("error", "not_c2share");
            case this.ERR_VOLUME_IS_NOT_BTRFS:
                return "";
            case this.ERR_VOLUME_IS_READ_ONLY:
                return SYNO.SDS.C2FS.Helper.T("share", "error_volume_read_only");
            case this.ERR_TARGET_SHARE_NAME_EXISTED:
                return SYNO.SDS.C2FS.Helper.T("share", "share_already_exist");
            case this.ERR_TARGET_VOLUME_IS_NOT_BTRFS:
                return SYNO.SDS.C2FS.Helper.T("error", "target_volume_is_not_btrfs");
            case this.ERR_TARGET_VOLUME_IS_READ_ONLY:
                return SYNO.SDS.C2FS.Helper.T("error", "target_volume_is_read_only");
            case this.ERR_TARGET_SHARE_PATH_EXISTS:
                return SYNO.SDS.C2FS.Helper.T("error", "target_share_path_exists");
            case this.ERR_MULTI_MOUNT:
                return SYNO.SDS.C2FS.Helper.T("error", "multi_mount");
            case this.ERR_UPDATE_ATTRIBUTE:
                return SYNO.SDS.C2FS.Helper.T("error", "update_attribute");
            case this.ERR_LOCAL_CACHE_MAX_EXCEED:
                return SYNO.SDS.C2FS.Helper.T("error", "local_cache_max_exceed");
            case this.ERR_BAD_CONF:
                return SYNO.SDS.C2FS.Helper.T("error", "broken_share");
            case this.ERR_CACHE_SIZE_TOO_LOW:
                return SYNO.SDS.C2FS.Helper.T("error", "local_cache_min_exceed_strong");
            case this.ERR_DESCRIPTION_TOO_LONG:
                return "";
            case this.ERR_UNSYNC_EXCEED_CACHE_SIZE:
                return SYNO.SDS.C2FS.Helper.T("error", "local_cache_min_exceed_soft");
            case this.ERR_EXCEED_C2_SHARE_NUM:
                return SYNO.SDS.C2FS.Helper.T("warn", "one_hybrid_share_only");
            case this.ERR_SHARE_NAME_RESERVED:
                return SYNO.SDS.C2FS.Helper.T("share", "error_nameused");
            case this.ERR_BUCKET_CONNECT:
                return SYNO.SDS.C2FS.Helper.T("error", "bucket_connect_failed");
            case this.ERR_BUCKET_INFO:
                return "";
            case this.ERR_BUCKET_NOT_FOUND:
                return SYNO.SDS.C2FS.Helper.T("error", "bucket_not_found");
            case this.ERR_BUCKET_INVALID_SCOPED_TOKEN:
                return SYNO.SDS.C2FS.Helper.T("error", "bucket_invalid_scoped_token");
            case this.ERR_BUCKET_NOT_SUITABLE_PASSWORD:
                return SYNO.SDS.C2FS.Helper.T("error", "bucket_bad_password");
            case this.ERR_BUCKET_ENCRYPT_FAILED:
                return SYNO.SDS.C2FS.Helper.T("error", "bucket_encrypt_failed");
            case this.ERR_BUCKET_IS_ALREADY_MOUNT:
                return SYNO.SDS.C2FS.Helper.T("error", "bucket_is_already_mount");
            case this.ERR_BUCKET_ALREADY_ENCRYPT:
                return SYNO.SDS.C2FS.Helper.T("error", "bucket_has_been_encrypt");
            case this.ERR_BUCKET_WRONG_PASSWORD:
                return SYNO.SDS.C2FS.Helper.T("error", "bucket_wrong_password");
            case this.ERR_BUCKET_BAD_PASSWORD_KEY:
                return SYNO.SDS.C2FS.Helper.T("share", "error_key_file");
            case this.ERR_C2FS_CLIENT_VERSION_INCOMPATIBLE:
                return SYNO.SDS.C2FS.Helper.T("error", "client_version_incompatible");
            default:
                return ""
        }
    }
}, Ext.define("SYNO.SDS.C2FS.WelcomeStep", {
    extend: "SYNO.SDS.Wizard.WelcomeStep",
    helper: SYNO.SDS.C2FS.Helper,
    constructor: function(e) {
        this.callParent([this.fillConfig(e)]), this.shareStore = e.module.panel.store, this.checkCanCreateShare()
    },
    fillConfig: function(e) {
        this.panel = this.createPanel();
        var t = {
            headline: this.helper.T("common", "hybrid_share"),
            items: [this.panel],
            listeners: {
                destroy: this.unregister
            }
        };
        return Ext.apply(t, e), t
    },
    createPanel: function() {
        return this.newShareDescriptionLearnMoreId = Ext.id(), new SYNO.ux.Panel({
            cls: "c2fs-panel-no-padding",
            layout: "vbox",
            listeners: {
                afterrender: function() {
                    this.appWin.setStatusBusy({
                        text: this.helper.T("common", "msg_waiting")
                    })
                }.bind(this)
            },
            items: [{
                xtype: "label",
                name: "create_wizard_image",
                width: 740,
                height: 240,
                cls: "c2-create-wizard-img"
            }, {
                xtype: "syno_displayfield",
                cls: "c2-create-wizard-welcome-txt",
                htmlEncode: !1,
                value: String.format(this.helper.T("common", "new_share_detail_description"), '<a href="https://c2.synology.com/" class="c2-link-no-bold" target="_blank">', "</a>", '<a id="' + this.newShareDescriptionLearnMoreId + '" class="link-font c2-link-no-bold" tabindex="0" role="link">', "</a>"),
                listeners: {
                    afterrender: function() {
                        Ext.get(this.newShareDescriptionLearnMoreId).on("click", function() {
                            SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                                topic: "SYNO.SDS.C2FS.Application"
                            }, !1)
                        }, this)
                    },
                    scope: this
                }
            }, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                value: '<span class="syno-ux-note">' + this.helper.T("common", "note") + this.helper.T("common", "colon") + "</span>" + String.format(this.helper.T("common", "create_wizard_welcome_note"), '<a href="https://sy.to/HybridShareBeta" class="c2-link-no-bold" target="_blank">', "</a>")
            }]
        })
    },
    hasExistedHybridShare: function() {
        return new Promise(function(e, t) {
            this.shareStore.getRange().filter(function(e) {
                return !0 === e.get("is_c2_share")
            }).length >= this.helper.MAX_C2_SHARE_NUM ? e() : t()
        }.bind(this))
    },
    checkCanCreateShare: function() {
        this.hasExistedHybridShare().then(function() {
            this.appWin.getMsgBox().alert(this.appWin.title, this.helper.T("warn", "one_hybrid_share_only"), function() {
                this.appWin.close()
            }.bind(this))
        }.bind(this), function() {
            this.checkVolumeExist()
        }.bind(this))
    },
    checkVolumeExist: function() {
        return this.checkHasBtrfs().then(this.checkPoolExist.bind(this))
    },
    checkHasBtrfs: function() {
        return this.sendWebAPIPromise({
            api: "SYNO.Core.Storage.Volume",
            method: "list",
            version: 1,
            params: {
                limit: -1,
                offset: 0,
                location: "internal"
            },
            scope: this
        }).then(function(e) {
            var t = !1;
            if (!Ext.isArray(e.volumes) || 0 === e.total) return t;
            if (t = !0, e.volumes.some(function(e) {
                    return "btrfs" === e.fs_type && SYNO.SDS.C2FS.Share.Utils.idealLocalCacheGB({
                        free_mb: e.size_free_byte / 1024 / 1024,
                        total_mb: e.size_total_byte / 1024 / 1024
                    })
                })) return t;
            var i = String.format(this.helper.T("error", "no_available_volume"), SYNO.SDS.Utils.CapacityRender(1024 * SYNO.SDS.C2FS.Share.Utils.basicVolumeSizeGB())) + ' <a class="link-font c2-link-no-bold" tabindex="0" role="link">' + this.helper.T("common", "learn_more") + "</a>",
                s = this.appWin.getMsgBox();
            return s.alert(this.appWin.title, i, function() {
                this.appWin.close()
            }.bind(this)), s.getDialog().el.child(".link-font").on("click", function() {
                SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                    topic: "SYNO.SDS.C2FS.Application:getting_started.html"
                }, !1)
            }), t
        }.bind(this), this.sendDsmWebApiFailure.bind(this))
    },
    checkPoolExist: function(e) {
        if (!0 !== e) return this.sendWebAPIPromise({
            api: "SYNO.Core.Storage.Pool",
            method: "list",
            version: 1,
            params: {
                limit: -1,
                offset: 0
            },
            scope: this
        }).then(function(e) {
            var t, i = {};
            return e.pools.length > 0 ? (t = this.helper.T("warn", "go_create_volume_wizard"), i = {
                fn: "SYNO.SDS.StorageManager.Pool.Main",
                vueWizard: "CreateWizard",
                modalParam: {
                    width: 820,
                    height: 560,
                    title: this.helper.T("volume", "volume_raid_creation_title"),
                    mode: "volume"
                }
            }) : t = this.helper.T("warn", "go_storage_first_time_wizard"), this.alertGoStorageManager(t, i), !1
        }.bind(this), this.sendDsmWebApiFailure.bind(this));
        this.appWin.clearStatusBusy()
    },
    alertGoStorageManager: function(e, t) {
        var i = this.appWin;
        i.getMsgBox().show({
            title: i.title,
            msg: e,
            buttons: {
                ok: this.helper.T("warn", "go_storage_manager")
            },
            fn: function() {
                "SYNO.SDS.CMS.Application" !== this.findAppWindow().getOpenConfig("className") && SYNO.SDS.AppLaunch("SYNO.SDS.StorageManager.Instance", t), i.close()
            }.bind(this),
            scope: i,
            minWidth: i.minWidth
        }, i)
    },
    sendDsmWebApiFailure: function(e) {
        SYNO.Debug("err: ", e);
        var t = this.helper.ErrorMap.T(e.error.code) || this.helper.T("common", "error_system"),
            i = this.findWindow();
        return i.getMsgBox().alert(this.title, t, function() {
            i.close()
        }), !1
    },
    goDecryptStep: function() {
        this.appWin.reloadData(!0), this.appWin.goNext(this.decryptId)
    },
    goEncryptStep: function() {
        this.appWin.reloadData(!0), this.appWin.goNext(this.encryptId)
    },
    getNext: function() {
        return _S("is_admin") ? this.adminUserCheckNtpSetting() : this.delegatedUserCheckNtpSetting(), !1
    },
    delegatedUserCheckNtpSetting: function() {
        this.sendWebAPIPromise({
            api: "SYNO.C2FS.Utils",
            version: 1,
            method: "check_ntp_enable",
            scope: this
        }).then(function(e) {
            e.is_ntp_enable ? this.popC2LoginWeb() : this.appWin.getMsgBox().alert(this.title, this.helper.T("warn", "inform_admin_of_enabling_ntp"))
        }.bind(this), this.sendDsmWebApiFailure.bind(this))
    },
    adminUserCheckNtpSetting: function() {
        var e = this;
        this.sendWebAPIPromise({
            api: "SYNO.Core.Region.NTP",
            version: 2,
            method: "get",
            scope: this
        }).then(function(t) {
            if ("ntp" !== t.enable_ntp) {
                var i = String.format(e.helper.T("warn", "need_enable_ntp_sync_setting"), '<a class="link-font c2-link-no-bold" tabindex="0" role="link">', "</a>"),
                    s = e.appWin.getMsgBox();
                return s.confirm(e.appWin.title, i, function(i) {
                    return "yes" === i ? function(t) {
                        return t.timeZone || (t.timeZone = "Dublin"), t.server || (t.server = "time.google.com"), e.sendWebAPIPromise({
                            api: "SYNO.Core.Region.NTP",
                            version: 1,
                            method: "set",
                            params: {
                                timezone: t.timeZone,
                                enable_ntp: "ntp",
                                server: t.server
                            }
                        })
                    }(t).then(function(t) {
                        var i = e._D("product"),
                            s = SYNO.SDS.AdminCenter.Region.Utils.ntpUpdateFailedMsg(i, t.server),
                            r = SYNO.SDS.AdminCenter.Region.Utils.ntpUpdateProgressMsg(i, t.server);
                        e.appWin.setStatusBusy({
                            text: r
                        }, .1, 100), SYNO.SDS.AdminCenter.Region.Utils.trySendSyncAPI(t.server, function(t, i) {
                            e.appWin.clearStatusBusy(), t ? e.popC2LoginWeb() : e.appWin.getMsgBox().alert(e.title, s, function() {
                                e.popC2LoginWeb()
                            })
                        }, e.appWin)
                    }(t), e.sendDsmWebApiFailure.bind(e)) : (e.appWin.close(), !1)
                }, e.appWin, {
                    yes: {
                        text: e.helper.T("common", "ok")
                    },
                    no: {
                        text: e.helper.T("common", "cancel")
                    }
                }), s.getDialog().el.child(".link-font").on("click", function() {
                    SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                        topic: "SYNO.SDS.C2FS.Application:create_hybrid_share.html"
                    }, !1)
                }), !1
            }
            return e.popC2LoginWeb(), !1
        }, e.sendDsmWebApiFailure.bind(e))
    },
    popC2LoginWeb: function() {
        this.unregister();
        this.register(this.c2PostMessageManager.createDelegate(this), "C2Share");
        var e = Ext.urlDecode(window.location.href.split("?")[1]),
            t = encodeURIComponent(String.format("{0}//{1}", window.location.protocol, window.location.host)),
            i = "test" == e.everest ? "https://account.c2test.synology.com/c2share/" : "https://account.c2.synology.com/c2share/";
        i += String.format("?origin={0}&version={1}", t, this.helper.pkgVersion()), this.popup = window.open(i, "mywindow", "menubar=1, resizable=0, width=1080, height=800, top=100, left=300"), this.popup || this.appWin.getMsgBox().alert(this.appWin.title, this.helper.T("warn", "popup_c2_web_failed"), Ext.emptyFn)
    },
    processC2LoginResponse: function(e) {
        !1 !== e.authorize && (this.isLogined = !0)
    },
    c2PostMessageManager: function(e) {
        switch (e.data.cmd) {
            case "check_mount":
                this.checkAccountMount(e);
                break;
            case "authorize":
                var t = e.data.share,
                    i = e.data;
                if (t && t.shares && t.shares[0]) {
                    var s = i.catalog.find(function(e) {
                        return "api" === e.name
                    }).endpoints[0].url;
                    "http" !== s.substring(0, 4) && (s = "https://" + s), this.owner.fireEvent("setServerInfo", {
                        metadata: t.shares[0].metadata ? t.shares[0].metadata : "",
                        c2share_api_url: s + "/c2share/v1",
                        project_id: i.project_id,
                        share_id: t.shares[0].share_id,
                        scoped_token: i.scoped_token,
                        synology_account: i.account,
                        bucket_name: t.shares[0].share_name,
                        bucket_used_mb: t.shares[0].bytes_used ? t.shares[0].bytes_used / 1024 / 1024 : 0,
                        bucket_total_mb: t.total_quota / 1024 / 1024
                    }), t.shares[0].share_key && SYNO.SDS.Utils.IsJson(t.shares[0].share_key) ? this.goDecryptStep() : (this.owner.fireEvent("setBucketEncryptStatus", !1), this.goEncryptStep())
                }
        }
    },
    checkAccountMount: function(e) {
        return !!e.data.account && (this.sendWebAPIPromise({
            api: "SYNO.C2FS.Bucket",
            method: "get_account_mount",
            version: 1,
            params: {
                synology_account: e.data.account
            },
            scope: this
        }).then(function(t) {
            this.popup.postMessage({
                shares: t
            }, e.origin)
        }.bind(this), function(e) {
            var t = this.findWindow();
            return this.helper.popupErrorMessage(t, e.code, function() {
                t.close()
            }), !1
        }.bind(this)), !0)
    },
    register: function(e, t) {
        var i = this;
        this.receiveMessage = function(s) {
            /setImmediate/.test(s.browserEvent.data) || s.browserEvent.data.pkg_name === t && e.call(i, s.browserEvent)
        }, Ext.EventManager.addListener(window, "message", this.receiveMessage)
    },
    unregister: function() {
        Ext.EventManager.removeListener(window, "message", this.receiveMessage)
    }
}), Ext.ns("SYNO.SDS.C2FS.Share.Utils"), SYNO.SDS.C2FS.Share.Utils = {
    VOLUME_USAGE_MAX_RATIO: .9,
    LOCAL_CACHE: {
        MIN_SIZE_GB: 300,
        DEFAULT_SIZE_GB: 500
    },
    MIN_RATIO_OF_BUCKET: .05,
    isNormalStatus: function(e) {
        return "uploading" === e || "updating" === e || "building" === e || "full_resync" === e || "transform_check" === e || "transform_upload" === e || "confirming_connection" === e || "in_write_throttle" === e
    },
    isWarningStatus: function(e) {
        return "slow_uploading" === e || "in_throttle" === e || "insufficient_volume_free_space" === e
    },
    isErrorStatus: function(e) {
        return "disconnected" === e || "incompatible" === e || "no_config" === e || "space_full" === e || "disable" == e || "unauth" === e || "c2_space_full" === e
    },
    idealLocalCacheGB: function(e, t, i) {
        if (!e.free_mb || !e.total_mb) return SYNO.Debug("Invalid volumeInfo: ", e), NaN;
        var s = e.free_mb + (t && t.used_mb ? t.used_mb : 0);
        return s = Math.min(s, t && t.total_mb ? t.total_mb : 1 / 0, e.total_mb * this.VOLUME_USAGE_MAX_RATIO), (s = Math.floor(s / 1024)) < this.minLocalCacheGB(i) ? NaN : s
    },
    minLocalCacheGB: function(e) {
        return Math.ceil(Math.max(this.LOCAL_CACHE.MIN_SIZE_GB, (e && e.total_mb ? e.total_mb / 1024 : 1024) * this.MIN_RATIO_OF_BUCKET))
    },
    basicVolumeSizeGB: function(e) {
        return Math.ceil(this.minLocalCacheGB(e) / this.VOLUME_USAGE_MAX_RATIO)
    },
    isNoSupportShareName: function(e) {
        return ["ActiveBackupforBusiness", "MailPlus", "chat", "docker", "Surveillance", "music", "video", "photo", "web", "web_packages", "homes"].includes(e)
    }
}, Ext.define("SYNO.SDS.C2FS.Share.GeneralForm", {
    extend: "SYNO.SDS.Utils.FormPanel",
    helper: SYNO.SDS.C2FS.Helper,
    constructor: function(e) {
        this.callParent([this.fillConfig(e)]), this.isShareRecycleCleaning = !1
    },
    fillConfig: function(e) {
        e && e.highlightBox || (e.highlightBox = {}), (!e.highlightBox.hasOwnProperty("marginRight") || !Number.isInteger(e.highlightBox.marginRight) || e.highlightBox.marginRight < 0) && (e.highlightBox.marginRight = 0);
        var t = {
            title: this.helper.T("share", "share_subject"),
            border: !1,
            frame: !1,
            header: !1,
            labelWidth: 300,
            trackResetOnLoad: !0,
            items: [{
                xtype: "syno_textfield",
                name: "name",
                ref: "shareName",
                maxlength: 32,
                fieldLabel: this.helper.T("share", "share_name"),
                allowBlank: !1,
                blankText: this.helper.T("share", "error_noname"),
                width: 300,
                vtype: "sharename"
            }, {
                xtype: "syno_textfield",
                name: "description",
                ref: "description",
                maxlength: 64,
                width: 300,
                fieldLabel: this.helper.T("share", "share_comment")
            }, {
                xtype: "syno_share_combobox",
                name: "volume_path",
                ref: "volumePath",
                fieldLabel: this.helper.T("volume", "volume_share_position"),
                store: new Ext.data.JsonStore({
                    idProperty: "volume_path",
                    fields: ["volume_path", "for_display", "size_total_mb", "volume_name", "description", "tooltip", "size_free_mb"]
                }),
                displayField: "for_display",
                descriptionField: "description",
                tooltip: "tooltip",
                valueField: "volume_path",
                allowBlank: !1,
                width: 300
            }, {
                xtype: "syno_compositefield",
                fieldLabel: this.helper.T("attribute", "local_cache"),
                name: "local_cache",
                ref: "localCache",
                items: [{
                    xtype: "syno_numberfield",
                    name: "local_cache_max_gb",
                    ref: "maxGb",
                    minValue: 0,
                    width: 204,
                    allowBlank: !1
                }, {
                    xtype: "syno_displayfield",
                    width: 20,
                    name: "unit",
                    value: "GB"
                }]
            }, {
                xtype: "syno_displayfield",
                cls: "c2fs-hightlight-box",
                hideLabel: !1,
                htmlEncode: !1,
                style: "padding:10px 20px; margin:0px " + e.highlightBox.marginRight + "px  6px 0;",
                value: this.helper.T("common", "local_cache_usage")
            }, {
                xtype: "syno_checkbox",
                name: "disableBrowsable",
                ref: "disableBrowsable",
                boxLabel: this.helper.T("share", "share_hide")
            }, {
                xtype: "syno_checkbox",
                name: "hide_unreadable",
                ref: "hideUnreadable",
                boxLabel: this.helper.T("share", "share_hide_unreadable"),
                hideLabel: !0
            }, {
                xtype: "syno_checkbox",
                name: "enable_recycle_bin",
                ref: "enableRecyleBin",
                boxLabel: this.helper.T("share", "share_enable_recycle_bin"),
                hideLabel: !0,
                hidden: !_S("is_admin"),
                listeners: {
                    scope: this,
                    check: function(e, t) {
                        t ? this.recyleBinAdminOnly.enable() : this.recyleBinAdminOnly.disable()
                    }
                }
            }, {
                xtype: "syno_checkbox",
                name: "recycle_bin_admin_only",
                ref: "recyleBinAdminOnly",
                boxLabel: this.helper.T("network", "cifs_safe_recycle_bin"),
                width: 500,
                indent: 1,
                hidden: !_S("is_admin")
            }, {
                xtype: "syno_button",
                ref: "cleanRecyleBin",
                indent: 1,
                width: "auto",
                text: this.helper.T("share", "share_clean_recycle_bin"),
                hidden: !0,
                scope: this,
                handler: this.onCleanBinBtnClick
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                tabIndex: -1,
                htmlEncode: !1,
                hidden: !_S("is_admin"),
                value: '<span class="syno-ux-note">' + this.helper.T("common", "note") + this.helper.T("common", "colon") + '</span><a id="' + Ext.id() + '" class="link-font" tabindex="0" role="link" style="cursor:pointer">' + this.helper.T("network", "cifs_recycle_bin_help_link") + "</a>",
                listeners: {
                    afterrender: SYNO.SDS.AdminCenter.Share.Utils.ShowHelpCallback(SYNO.SDS.AdminCenter.TaskScheduler.Main.prototype.getHelpParam()),
                    scope: this
                }
            }]
        };
        return Ext.apply(t, e), t
    },
    setRecycleStatus: function(e) {
        !0 === e ? (this.isShareRecycleCleaning = !0, this.cleanRecyleBin.setText(this.helper.T("share", "share_clean_recycle_bin_abort"))) : (this.isShareRecycleCleaning = !1, this.cleanRecyleBin.setText(this.helper.T("share", "share_clean_recycle_bin")))
    },
    onCleanBinBtnClick: function(e, t) {
        var i, s;
        !0 === this.isShareRecycleCleaning ? (i = "stop", s = this.helper.T("share", "share_recycle_bin_clean_abort_warn")) : (i = "start", s = this.helper.T("share", "share_recycle_bin_clean_warn"));
        var r = {
            yes: {
                text: Ext.MessageBox.buttonText.yes,
                btnStyle: "red"
            },
            no: {
                text: Ext.MessageBox.buttonText.no
            }
        };
        this.findWindow().getMsgBox().confirmDelete(this.helper.T("share", "share_clean_recycle_bin"), s, function(e) {
            "yes" === e && (this.cleanRecyleBin.disable(), this.sendWebAPI({
                api: "SYNO.Core.RecycleBin",
                method: i,
                version: 1,
                params: {
                    id: this.shareName.originalValue
                },
                scope: this,
                callback: function(e, t, i) {
                    e ? (t.is_cleaning ? (this.isShareRecycleCleaning = !0, this.cleanRecyleBin.setText(this.helper.T("share", "share_clean_recycle_bin_abort")), this.startPollRecycleStatus()) : (this.isShareRecycleCleaning = !1, this.cleanRecyleBin.setText(this.helper.T("share", "share_clean_recycle_bin")), this.stopPollRecycleStatus()), this.cleanRecyleBin.enable()) : this.startPollRecycleStatus()
                }
            }))
        }, this, r)
    },
    startPollRecycleStatus: function() {
        this.PollTaskRecycleBinId || (this.PollTaskRecycleBinId = this.pollReg({
            interval: 5,
            immediate: !0,
            webapi: {
                api: "SYNO.Core.RecycleBin",
                method: "get",
                version: 1,
                params: {
                    id: this.shareName.originalValue
                }
            },
            scope: this,
            status_callback: function(e, t, i) {
                if (!e) return !1;
                t.is_cleaning ? (this.isShareRecycleCleaning = !0, this.cleanRecyleBin.setText(this.helper.T("share", "share_clean_recycle_bin_abort")), this.cleanRecyleBin.enable()) : (this.isShareRecycleCleaning = !1, this.cleanRecyleBin.setText(this.helper.T("share", "share_clean_recycle_bin")), this.cleanRecyleBin.enable(), this.stopPollRecycleStatus())
            }
        }))
    },
    stopPollRecycleStatus: function() {
        this.PollTaskRecycleBinId && (this.pollUnreg(this.PollTaskRecycleBinId), this.PollTaskRecycleBinId = null)
    }
}), Ext.define("SYNO.SDS.C2FS.FillBasicInfoStep", {
    extend: "SYNO.SDS.Wizard.Step",
    helper: SYNO.SDS.C2FS.Helper,
    constructor: function(e) {
        var t = this;
        this.callParent([this.fillConfig(e)]), this.mon(this.generalForm.volumePath, "afterrender", function() {
            SYNO.ux.AddWhiteTipWithMsg(t.generalForm.volumePath, t.helper.T("common", "btrfs_volume_only"))
        })
    },
    fillConfig: function(e) {
        var t = this;
        this.generalform = new SYNO.SDS.C2FS.Share.GeneralForm({
            module: e.module,
            cls: "c2fs-panel-no-padding",
            ref: "generalForm",
            owner: this,
            itemId: "generalForm",
            autoHeight: !0
        });
        var i = {
            shareStore: e.module.panel.store,
            headline: this.helper.T("share", "create_wizard_basic_info"),
            layout: "fit",
            items: [this.generalform],
            listeners: {
                afterrender: function() {
                    t.generalform.recyleBinAdminOnly.setValue(!0), t.generalform.enableRecyleBin.setValue(!0), t.generalForm.shareName.validator = function(e) {
                        if (!t.shareStore) return !0;
                        var i = !1;
                        return t.shareStore.each(function(t) {
                            if (t.get("name").toLowerCase() === e.toLowerCase()) return i = !0, !1
                        }), !i || t.helper.T("share", "share_already_exist")
                    }
                },
                scope: this
            }
        };
        return Ext.apply(i, e), i
    },
    validate: function() {
        return this.generalform.getForm().isValid()
    },
    activate: function() {
        var e = this,
            t = this.owner.getServerInfo().bucket_total_mb,
            i = SYNO.SDS.C2FS.Share.Utils.minLocalCacheGB({
                total_mb: t
            });
        this.generalForm.localCache.maxGb.validator = function(s) {
            var r = e.generalForm.volumePath.store.getById(e.generalForm.volumePath.getValue());
            if (s > t / 1024) return String.format(e.helper.T("warn", "local_cache_size_exceed_bucket"), SYNO.SDS.Utils.CapacityRender(t, 1));
            var n = SYNO.SDS.C2FS.Share.Utils.idealLocalCacheGB({
                free_mb: r.get("size_free_mb"),
                total_mb: r.get("size_total_mb")
            }, {}, {
                total_mb: t
            });
            return s > n ? String.format(e.helper.T("warn", "set_local_cache_exceed_volume"), r.get("for_display"), n.toFixed(2)) : !(s < i) || String.format(e.helper.T("warn", "set_local_cache_too_low"), i.toFixed(2))
        }, this.findWindow().setStatusBusy(), this.sendWebAPIPromise({
            api: "SYNO.Core.Storage.Volume",
            method: "list",
            params: {
                limit: -1,
                offset: 0,
                location: "internal"
            },
            version: 1
        }).then(function(s) {
            e.findWindow().clearStatusBusy();
            var r = s.volumes;
            if (!Ext.isArray(r) || 0 === r.length) return e.findWindow().getMsgBox().alert(e.title, String.format(e.helper.T("error", "no_available_volume"), SYNO.SDS.Utils.CapacityRender(1024 * i))), !1;
            var n = r.filter(function(e, t) {
                return !e.readonly && "btrfs" === e.fs_type && SYNO.SDS.C2FS.Share.Utils.idealLocalCacheGB({
                    free_mb: e.size_free_byte / 1024 / 1024,
                    total_mb: e.size_total_byte / 1024 / 1024
                })
            }).map(function(t, i) {
                return {
                    volume_path: t.volume_path,
                    for_display: String.format("{0} ({1}){2}", SYNO.SDS.Utils.StorageUtils.VolumeNameRenderer(t), t.fs_type, "" === t.description ? "" : " - " + t.description),
                    size_total_mb: t.size_total_byte / 1024 / 1024,
                    size_free_mb: t.size_free_byte / 1024 / 1024,
                    volume_name: t.display_name,
                    description: String.format("{0}{1}{2}", e.helper.T("volume", "volume_freesize"), e.helper.T("common", "colon"), SYNO.SDS.Utils.StorageUtils.UiRenderHelper.SizeRender(t.size_free_byte)),
                    tooltip: t.description ? t.description : ""
                }
            });
            if (0 === n.length) return e.findWindow().getMsgBox().alert(e.title, String.format(e.helper.T("error", "no_proper_volume_for_this_bucket"), SYNO.SDS.Utils.CapacityRender(1024 * SYNO.SDS.C2FS.Share.Utils.basicVolumeSizeGB()))), !1;
            if (e.generalForm.volumePath.store.loadData(n), e.generalForm.volumePath.getValue() || e.generalForm.volumePath.setValue(n[0].volume_path), !e.generalForm.localCache.maxGb.getValue()) {
                var a = SYNO.SDS.C2FS.Share.Utils.idealLocalCacheGB({
                        free_mb: n[0].size_free_mb,
                        total_mb: n[0].size_total_mb
                    }, {}, {
                        total_mb: t
                    }),
                    o = SYNO.SDS.C2FS.Share.Utils.LOCAL_CACHE.DEFAULT_SIZE_GB;
                e.generalForm.localCache.maxGb.setValue(a > o ? o : a)
            }
        }).catch(function(t) {
            SYNO.Debug("error: ", t), e.helper.popupErrorMessage(e.findWindow(), t.code), e.findWindow().clearStatusBusy()
        })
    },
    getValues: function() {
        return Ext.apply(this.generalform.getForm().getValues(), {
            volume_desc: this.generalform.volumePath.rawValue
        })
    },
    getNext: function() {
        return !!this.validate() && (this.appWin.reloadData(!0), this.nextId)
    }
}), Ext.define("SYNO.SDS.C2FS.DecryptBucketStep", {
    extend: "SYNO.SDS.Wizard.Step",
    helper: SYNO.SDS.C2FS.Helper,
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        this.formPanel = this.createFormPanel(e);
        var t = {
            headline: this.helper.T("common", "decryption_title"),
            layout: "fit",
            items: [this.formPanel],
            listeners: {
                scope: this
            }
        };
        return Ext.apply(t, e), t
    },
    createFormPanel: function(e) {
        var t = {
            cls: "c2fs-panel-no-padding",
            itemId: "decryptBucketForm",
            ref: "decryptBucketForm",
            height: 350,
            items: [{
                xtype: "syno_displayfield",
                style: "margin-bottom: 6px;",
                hideLabel: !0,
                htmlEncode: !1,
                value: String.format(this.helper.T("common", "decryption_desc"), '<a id="' + Ext.id() + '" class="c2-link-no-bold" tabindex="0" role="link">', "</a>"),
                listeners: {
                    afterrender: function(e) {
                        var t = e.el.query("a");
                        t[0] ? Ext.get(t[0].id).on("click", function() {
                            SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                                topic: "SYNO.SDS.C2FS.Application:create_hybrid_share.html"
                            }, !1)
                        }, this) : SYNO.Debug("Failed to find link element: ", t)
                    },
                    scope: this
                }
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                items: [{
                    xtype: "syno_radio",
                    name: "decrypt_method",
                    width: 260,
                    inputValue: "manual",
                    boxLabel: this.helper.T("share", "share_encryption_keyinput") + this.helper.T("common", "colon"),
                    checked: !0
                }, {
                    xtype: "syno_textfield",
                    textType: "password",
                    name: "password",
                    allowBlank: !1,
                    width: 220,
                    validator: function(e) {
                        return -1 === e.indexOf("=") && -1 === e.indexOf(",") && -1 === e.indexOf(":") || this.helper.T("share", "encryption_password_invalid")
                    }.bind(this)
                }]
            }, {
                xtype: "syno_compositefield",
                hideLabel: !0,
                items: [{
                    xtype: "syno_radio",
                    name: "decrypt_method",
                    width: 260,
                    inputValue: "keyfile",
                    boxLabel: this.helper.T("share", "share_encryption_importfrom")
                }, {
                    xtype: "syno_filebutton",
                    ref: "../keyFileButton",
                    allowBlank: !1,
                    name: "key_file",
                    textConfig: {
                        width: 204
                    }
                }],
                listeners: {
                    afterrender: function() {
                        var e = this.formPanel.getForm();
                        new SYNO.ux.Utils.EnableRadioGroup(e, "decrypt_method", {
                            manual: ["password"],
                            keyfile: ["key_file"]
                        })
                    }.bind(this)
                }
            }]
        };
        return Ext.apply(t, e), new SYNO.SDS.Utils.FormPanel(t)
    },
    isValid: function() {
        return this.formPanel.getForm().isValid()
    },
    getValues: function() {
        return null
    },
    sendDecryptWebApi: function(e) {
        var t = {
            api: "SYNO.C2FS.Bucket",
            version: 1,
            method: "decrypt",
            encryption: ["server_info"],
            params: {
                server_info: this.owner.getServerInfo()
            }
        };
        e ? (t.params.decrypt_key_in_base64 = e, t.encryption.push("decrypt_key_in_base64")) : (t.params.decrypt_password = this.formPanel.getForm().findField("password").getValue(), t.encryption.push("decrypt_password")), this.sendWebAPIPromise(t).then(function() {
            this.appWin.clearStatusBusy(), this.appWin.reloadData(!0), this.appWin.goNext(this.nextId)
        }.bind(this), function(e) {
            return this.appWin.clearStatusBusy(), this.helper.popupErrorMessage(this.findWindow(), e.code), !1
        }.bind(this))
    },
    getNext: function() {
        if (!this.isValid()) return !1;
        if (this.appWin.setStatusBusy({
                text: this.helper.T("common", "msg_waiting")
            }), "keyfile" === this.formPanel.getForm().findField("decrypt_method").getGroupValue()) {
            var e = this.formPanel.keyFileButton.el.dom.files[0];
            if (32 !== e.size) return this.helper.popupErrorMessage(this.findWindow(), this.helper.ErrorMap.ERR_BUCKET_BAD_PASSWORD_KEY, function() {
                this.appWin.clearStatusBusy()
            }.bind(this)), !1;
            var t = new FileReader;
            t.onload = function() {
                for (var e = "", i = new Uint8Array(t.result), s = 0; s < i.byteLength; s++) e += String.fromCharCode(i[s]);
                this.sendDecryptWebApi(btoa(e))
            }.bind(this), t.readAsArrayBuffer(e)
        } else this.sendDecryptWebApi();
        return !1
    }
}), Ext.define("SYNO.SDS.C2FS.EncryptBucketStep", {
    extend: "SYNO.SDS.Wizard.Step",
    helper: SYNO.SDS.C2FS.Helper,
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        this.formPanel = this.createFormPanel(e);
        var t = {
            headline: this.helper.T("common", "encryption_title"),
            layout: "vbox",
            items: [this.formPanel, {
                xtype: "spacer",
                flex: 1
            }, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                value: '<span class="syno-ux-note">' + this.helper.T("common", "note") + this.helper.T("common", "colon") + " </span>" + this.helper.T("common", "create_wizard_encrypt_reminder")
            }],
            listeners: {
                scope: this
            }
        };
        return Ext.apply(t, e), t
    },
    createFormPanel: function(e) {
        var t = {
            cls: "c2fs-panel-no-padding",
            itemId: "encryptBucketForm",
            autoFlexcroll: !1,
            labelWidth: 265,
            items: [{
                xtype: "syno_displayfield",
                style: "margin-bottom: 6px;",
                hideLabel: !0,
                htmlEncode: !1,
                value: String.format(this.helper.T("common", "encryption_desc"), '<a id="' + Ext.id() + '" class="c2-link-no-bold" tabindex="0" role="link">', "</a>"),
                listeners: {
                    afterrender: function(e) {
                        var t = e.el.query("a");
                        t[0] ? Ext.get(t[0].id).on("click", function() {
                            SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                                topic: "SYNO.SDS.C2FS.Application:create_hybrid_share.html"
                            }, !1)
                        }, this) : SYNO.Debug("Failed to find link element: ", t)
                    },
                    scope: this
                }
            }, {
                xtype: "syno_textfield",
                textType: "password",
                name: "enc_passwd",
                minLength: 8,
                maxLength: 64,
                width: 220,
                allowBlank: !1,
                fieldLabel: this.helper.T("share", "share_encryption_key"),
                validator: function(e) {
                    return -1 === e.indexOf("=") && -1 === e.indexOf(",") && -1 === e.indexOf(":") || this.helper.T("share", "encryption_password_invalid")
                }.bind(this)
            }, {
                xtype: "syno_textfield",
                textType: "password_confirm",
                name: "enc_passwd_confirm",
                confirmFor: "enc_passwd",
                confirmFailedText: this.helper.T("share", "share_encryption_key_confirm_mismatch"),
                maxlength: 64,
                width: 220,
                allowBlank: !1,
                fieldLabel: this.helper.T("share", "share_encryption_key_confirm")
            }]
        };
        return Ext.apply(t, e), new SYNO.SDS.Utils.FormPanel(t)
    },
    isValid: function() {
        return this.formPanel.getForm().isValid()
    },
    getValues: function() {
        return null
    },
    getNext: function() {
        if (this.isValid()) {
            var e = '<div class="c2-create-wizard"><p class="c2-warning-msg-content">' + this.helper.T("warn", "encrypt_note") + '</p><p class="c2-warning-msg-content c2-warning-red">' + this.helper.T("warn", "encrypt_key_cant_modified") + '</p><p class="c2-warning-msg-content c2-warning-red">' + this.helper.T("warn", "encrypt_key_no_save_on_server") + "</p></div>";
            this.appWin.getMsgBox().confirm(this.helper.T("warn", "encrypting_comfirm_title"), e, function(e) {
                "yes" === e && (this.appWin.setStatusBusy({
                    text: this.helper.T("common", "msg_waiting")
                }), this.sendWebAPIPromise({
                    api: "SYNO.C2FS.Bucket",
                    method: "encrypt",
                    version: 1,
                    encryption: ["encrypt_password", "server_info"],
                    params: {
                        encrypt_password: this.formPanel.getForm().getValues().enc_passwd,
                        server_info: this.owner.getServerInfo()
                    },
                    scope: this
                }).then(function() {
                    return this.appWin.clearStatusBusy(), this.downloadKey(), this.appWin.reloadData(!0), this.appWin.goNext(this.nextId), !1
                }.bind(this), function(e) {
                    return this.appWin.clearStatusBusy(), this.helper.popupErrorMessage(this.findWindow(), e.code), !1
                }.bind(this)))
            }, this, {
                yes: !0,
                no: !0
            }, {
                useMessageTitle: !0,
                hideBrElement: !0
            })
        }
        return !1
    },
    downloadKey: function() {
        var e = this.owner.getServerInfo();
        this.findAppWindow().downloadWebAPI({
            webapi: {
                api: "SYNO.C2FS.Bucket",
                method: "password_key_export",
                version: 1,
                params: {
                    share_id: e.share_id,
                    bucket_name: e.bucket_name
                }
            },
            scope: this,
            callback: function(e, t, i, s) {
                "timeout" !== e && !1 === i && this.findWindow().getMsgBox().alert(this.title, this.helper.T("status", "status_err_load"))
            }.bind(this)
        })
    }
}), Ext.define("SYNO.SDS.C2FS.SummaryStep", {
    extend: "SYNO.SDS.Wizard.SummaryStep",
    helper: SYNO.SDS.C2FS.Helper,
    constructor: function(e) {
        this.callParent([e])
    },
    activate: function() {
        var e = this.owner.getValues().fillBasicInfo,
            t = [];
        e.disableBrowsable && t.push(this.helper.T("share", "share_hide_in_windows")), e.hide_unreadable && t.push(this.helper.T("share", "share_hide_without_perm")), this.getStore().removeAll(!0), this.getStore().append(this.helper.T("share", "share_name"), e.name), this.getStore().append(this.helper.T("share", "share_comment"), e.description), this.getStore().append(this.helper.T("volume", "volume_share_position"), e.volume_desc), this.getStore().append(this.helper.T("attribute", "local_cache"), e.local_cache_max_gb + " GB"), this.getStore().append(this.helper.T("share", "share_visibility"), t.join("; ")), this.getStore().append(this.helper.T("share", "recycle_bin"), e.enable_recycle_bin ? this.helper.T("share", e.recycle_bin_admin_only ? "recycle_bin_enabled_admin_only" : "create_wizard_enabled") : ""), this.getView().syncFocusEl(0), this.getView().refresh()
    },
    checkState: function() {
        this.callParent(), !1 === this.needGoToNextStep() && this.owner.fireEvent("setNextButtonText", this.helper.T("common", "done"))
    },
    needGoToNextStep: function() {
        return !1 === this.owner.getBucketEncryptStatus().is_encrypt
    },
    getNext: function() {
        this.helper.maskLoading(this.owner);
        var e = this.owner.getValues().fillBasicInfo,
            t = this.owner.getServerInfo();
        return this.sendWebAPIPromise({
            api: "SYNO.C2FS.Share",
            method: "create",
            version: 1,
            scope: this,
            encryption: ["volume_path", "local_cache_max_mb", "server_info", "share_attribute"],
            params: {
                name: e.name,
                volume_path: e.volume_path,
                local_cache_max_mb: 1024 * e.local_cache_max_gb,
                server_info: t,
                is_enable_immediately: !1,
                share_attribute: {
                    is_recycle_bin_admin_only: e.recycle_bin_admin_only,
                    is_enable_recycle_bin: e.enable_recycle_bin,
                    is_hide_unreadable: e.hide_unreadable,
                    is_browsable: !e.disableBrowsable,
                    description: e.description
                }
            }
        }).then(function(i) {
            this.owner.isNeedCloseWarnMsg = !1, this.helper.unmask(this.owner), SYNO.SDS.C2FS.UtilForDSM.updateOldInfoOfShare(e.name, {
                bucket_total_mb: t.bucket_total_mb,
                bucket_used_mb: t.bucket_used_mb,
                local_cache_max_mb: 1024 * e.local_cache_max_gb,
                status: ["building"],
                cache_used_mb: 0,
                sync_speed_mb_s: 0,
                unsync_data_mb: 0,
                synology_account: t.synology_account
            }), this.module.panel.store.load(), this.module.panel.fireEvent("sharefolderchanged", e.name), SYNO.SDS.StatusNotifier.fireEvent("sharefolderchanged", "permission"), this.appWin.reloadData(!0), this.appWin.goNext(this.needGoToNextStep() ? this.nextId : null)
        }.bind(this), function(e) {
            if (e.code != this.helper.ErrorMap.ERR_NOT_FEASIBLE) return this.helper.popupErrorMessage(this.owner, e.code, function() {
                this.helper.unmask(this.owner)
            }.bind(this)), !1;
            this.helper.popupFeasibilityCheckMsg(this.owner, e.errors.feasibility_check)
        }.bind(this)), !1
    }
}), Ext.define("SYNO.SDS.C2FS.Share.PermissionGrid", {
    extend: "SYNO.SDS.Share.ShareGrid",
    helper: SYNO.SDS.C2FS.Helper,
    constructor: function(e) {
        var t = e.hideCustomColumn;
        "SYNO.SDS.CMS.Application" === e.module.appWin.getOpenConfig("className") && (t = t || e.module.appWin._S("version") < 4475), this.colCu = new SYNO.SDS.Share.CustomColumn({
            module: e.module,
            owner: e.owner,
            ownerGrid: this,
            dataIndex: "is_custom",
            id: "is_custom",
            hidden: t,
            applyCallback: function() {
                this.store.load()
            },
            applyTarget: this
        }), e.colCu = this.colCu, e.cls = "without-dirty-red-grid syno-position-disable-position-absolute", e.isShowPreview = !0, this.callParent([e])
    },
    loadFormData: function(e) {
        var t = [{
            api: "SYNO.Core.Directory.LDAP",
            method: "get",
            version: 1
        }, {
            api: "SYNO.Core.Storage.Volume",
            method: "get",
            version: 1,
            params: {
                volume_path: e.get("vol_path")
            }
        }];
        return this.getKnownAPI("SYNO.Core.Directory.Domain") && (t.push({
            api: "SYNO.Core.Directory.Domain",
            method: "get",
            version: 1
        }), t.push({
            api: "SYNO.Core.Directory.Domain",
            method: "test_dc",
            version: 1
        }), "yes" === this._D("supportdomain") && t.push({
            api: "SYNO.Core.Directory.Domain",
            method: "get_domain_list",
            version: 2
        })), this.sendWebAPIPromise({
            compound: {
                stopwhenerror: !1,
                params: t
            },
            params: {},
            scope: this
        }).then(function(t) {
            if (t.has_fail) return this.showAlertMsg(t), Promise.reject(t);
            if (this.getKnownAPI("SYNO.Core.Directory.Domain")) {
                var i = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.Directory.Domain", "get", "enable_domain"),
                    s = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.Directory.Domain", "test_dc", "test_join_success");
                i && !s && this.findWindow().getMsgBox().alert("warning_msg", _T("share", "warning_directory_service_offline"))
            }
            var r = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.Storage.Volume", "get").volume;
            e.set("share_path", String.format("{0}/{1}", r.volume_path, e.get("name"))), e.set("readonly", r.readonly), this.loadPermissions(e, t)
        }.bind(this), function(e) {
            return this.showAlertMsg(e), Promise.reject(e)
        }.bind(this))
    },
    showAlertMsg: function(e) {
        var t = SYNO.API.Response.GetFirstError(e),
            i = SYNO.API.Errors.core[t.code] || this.helper.T("common", "commfail");
        this.findWindow().getMsgBox().alert(this.title, i, function() {
            this.findWindow().close()
        }, this)
    }
}), Ext.define("SYNO.SDS.C2FS.Share.DefaultPermissionGrid", {
    extend: "SYNO.SDS.C2FS.Share.PermissionGrid",
    helper: SYNO.SDS.C2FS.Helper,
    constructor: function(e) {
        this.callParent([e])
    },
    createStore: function(e) {
        return new SYNO.API.JsonStore({
            autoDestroy: !0,
            remoteSort: !0,
            appWindow: e.owner,
            api: "SYNO.Core.Share.Permission",
            method: "list",
            version: 1,
            baseParams: {
                offset: 0,
                limit: this.pageSize,
                is_unite_permission: e.isAdvancedMode || !1,
                with_inherit: e.isShowPreview || !1
            },
            listeners: {
                exception: {
                    scope: this,
                    fn: this.onStoreException
                },
                beforeload: {
                    scope: this,
                    fn: this.onBeforeLoad
                },
                load: {
                    scope: this,
                    fn: function(e, t) {
                        t.forEach(function(e) {
                            e.data.inherit = !0 === e.get("is_admin") ? "rw" : "-", e.data.is_custom = !1, e.data.name === this._S("user") && !1 === this._S("is_admin") && (e.data.is_writable = !0)
                        }), this.onLoad()
                    }
                }
            },
            root: "items",
            idProperty: "name",
            totalProperty: "total",
            fields: ["name", "is_writable", "is_readonly", "is_deny", "is_custom", "is_admin", "inherit", {
                name: "preview",
                persist: !1
            }]
        })
    },
    sendApplyRequest: function() {
        var e = this.getWebAPI()[0];
        Object.assign(e, {
            api: "SYNO.C2FS.Share",
            method: "set_permission",
            version: 1
        }), this.sendWebAPIPromise(e).then(function() {
            return !1
        }, function(e) {
            return SYNO.Debug("err", e), !1
        })
    }
}), Ext.define("SYNO.SDS.C2FS.PermissionStep", {
    extend: "SYNO.SDS.Wizard.Step",
    helper: SYNO.SDS.C2FS.Helper,
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        this.gridPanel = new SYNO.SDS.C2FS.Share.DefaultPermissionGrid({
            module: e.module,
            owner: e.owner,
            itemId: "permissionGrid",
            ref: "permissionGrid"
        });
        var t = {
            headline: this.helper.T("share", "create_wizard_perm_setting"),
            layout: "fit",
            items: new SYNO.ux.Panel({
                ref: "wrapPanel",
                cls: "c2fs-panel-no-padding",
                items: this.gridPanel
            })
        };
        return Ext.apply(t, e), t
    },
    activate: function() {
        this.gridPanel.setHeight(this.wrapPanel.getHeight()), this.gridPanel.nameFilter.updateElSize();
        var e = this.owner.getValues().fillBasicInfo,
            t = new Ext.data.Record({
                name: e.name,
                vol_path: e.volume_path,
                is_aclmode: !0
            });
        this.findWindow().setStatusBusy({
            text: this.helper.T("common", "msg_waiting")
        }), this.gridPanel.loadFormData(t).then(function() {
            this.findWindow().clearStatusBusy()
        }.bind(this), function(e) {
            SYNO.Debug("Promise reject:", e), this.findWindow().clearStatusBusy()
        }.bind(this))
    },
    getNext: function() {
        return this.gridPanel.isChanged() ? (this.gridPanel.sendApplyRequest(), this.nextId) : this.nextId
    }
}), Ext.define("SYNO.SDS.C2FS.Wizard", {
    extend: "SYNO.SDS.Wizard.ModalWindow",
    helper: SYNO.SDS.C2FS.Helper,
    constructor: function(e) {
        this.callParent([this.fillConfig(e)]), this.setAllStepSize(), this.bucketEncryptStatus = !0
    },
    fillConfig: function(e) {
        var t = [new SYNO.SDS.C2FS.WelcomeStep({
                appWin: this,
                owner: this,
                module: e.module,
                itemId: "welcome",
                nextId: "fillBasicInfo",
                encryptId: "encryptBucketStep",
                decryptId: "decryptBucketStep"
            }), new SYNO.SDS.C2FS.EncryptBucketStep({
                appWin: this,
                owner: this,
                module: e.module,
                itemId: "encryptBucketStep",
                nextId: "fillBasicInfo"
            }), new SYNO.SDS.C2FS.DecryptBucketStep({
                appWin: this,
                owner: this,
                module: e.module,
                itemId: "decryptBucketStep",
                nextId: "fillBasicInfo"
            }), new SYNO.SDS.C2FS.FillBasicInfoStep({
                appWin: this,
                owner: this,
                module: e.module,
                itemId: "fillBasicInfo",
                nextId: "summary"
            }), new SYNO.SDS.C2FS.SummaryStep({
                appWin: this,
                owner: this,
                module: e.module,
                itemId: "summary",
                nextId: "permissionStep"
            }), new SYNO.SDS.C2FS.PermissionStep({
                appWin: this,
                owner: this,
                module: e.module,
                itemId: "permissionStep",
                nextId: null
            })],
            i = {
                title: this.helper.T("action", "create_wizard"),
                steps: t,
                cls: "c2-create-wizard",
                listeners: {
                    beforeclose: this.onBeforeClose,
                    setServerInfo: this.setServerInfo,
                    setBucketEncryptStatus: this.setBucketEncryptStatus,
                    setNextButtonText: this.setNextButtonText,
                    scope: this
                },
                isNeedCloseWarnMsg: !0
            };
        return Ext.apply(i, e), i
    },
    setNextButtonText: function(e) {
        this.getButton("next").setText(e)
    },
    setServerInfo: function(e) {
        this.serverInfo = e
    },
    getServerInfo: function() {
        return Object.assign({}, this.serverInfo)
    },
    setBucketEncryptStatus: function(e) {
        this.bucketEncryptStatus = e
    },
    getBucketEncryptStatus: function() {
        return {
            is_encrypt: this.bucketEncryptStatus
        }
    },
    reloadData: function(e) {
        this.getAllSteps().forEach(function(t) {
            void 0 !== t.reloadStore && (t.reloadStore = e)
        })
    },
    setAllStepSize: function() {
        this.getAllSteps().forEach(function(e) {
            e.setHeight(Math.max(this.height - 162, 162)), e.setWidth(Math.max(this.width - 80, 80))
        }, this)
    },
    getValues: function() {
        return this.getAllSteps().reduce(function(e, t) {
            return Ext.isFunction(t.getValues) && (e[t.itemId] = t.getValues()), e
        }, {})
    },
    onBeforeClose: function() {
        if (!this.isNeedCloseWarnMsg || !this.stepStack.includes("encryptBucketStep") && !this.stepStack.includes("decryptBucketStep")) return !0;
        var e = this.findWindow(),
            t = '<div class="c2-create-wizard"><p class="c2-warning-msg-content c2-warning-red">' + this.helper.T("warn", "create_leave_content") + "</p></div>";
        return e.getMsgBox().confirm(this.helper.T("warn", "create_leave_title"), t, function(e) {
            "yes" === e && (this.isNeedCloseWarnMsg = !1, this.close())
        }, this, {
            yes: !0,
            no: !0
        }, {
            useMessageTitle: !0,
            hideBrElement: !0
        }), !1
    },
    hasHistory: function() {
        return this.stepStack.includes("summary") ? 0 : this.stepStack.filter(function(e) {
            return "welcome" !== e && "encryptBucketStep" !== e && "decryptBucketStep" !== e
        }).length
    }
}), Ext.define("SYNO.SDS.C2FS.Share.AdvancedPermissionForm", {
    extend: "SYNO.SDS.Share.AdvanceForm",
    helper: SYNO.SDS.C2FS.Helper,
    constructor: function(e) {
        this.callParent([e])
    },
    loadPermissions: function(e, t) {
        return new Promise(function(i, s) {
            SYNO.SDS.ControlPanel.Share.isHomes(e.get("name")) && Ext.getCmp(this.advSettingsSet).hide(), this.shareRecord = e, this.getForm().setValues(t), e.get("readonly") && this.getForm().findField("disable_modify").disable(), e.get("is_aclmode") || this.getComponent("advFieldSet").hide(), i()
        }.bind(this))
    }
}), Ext.define("SYNO.SDS.C2FS.Share.EditDialog", {
    extend: "SYNO.SDS.ModalWindow",
    helper: SYNO.SDS.C2FS.Helper,
    moveShareMsg: _T("share", "init_status"),
    constructor: function(e) {
        this.module = e.module, this.owner = e.owner, this.share = e.share, this.mode = e.mode, this.callParent([this.fillConfig(e)]), this.loadEachFormData(), this.mon(this, "deactivate", function() {
            return this.tabPanel.generalForm.stopPollRecycleStatus(), !0
        }, this)
    },
    fillConfig: function(e) {
        var t = {
            title: String.format(this.helper.T("action", "edit_title"), this.share.get("name")),
            width: 860,
            height: 570,
            layout: "fit",
            buttons: [{
                xtype: "syno_button",
                text: this.helper.T("common", "alt_cancel"),
                scope: this,
                handler: function() {
                    this.isAnyFormDirty() ? this.getMsgBox().confirm(this.title, _T("common", "confirm_lostchange"), function(e) {
                        "yes" === e && this.close()
                    }, this) : this.close()
                }
            }, {
                xtype: "syno_button",
                text: this.helper.T("common", "save"),
                btnStyle: "blue",
                scope: this,
                handler: function() {
                    if (this.isAnyFormDirty()) {
                        if (!this.tabPanel.generalForm.getForm().isValid()) return this.tabPanel.setActiveTab("generalForm"), void this.setStatusError({
                            text: this.helper.T("error", "error_bad_field"),
                            clear: !0
                        });
                        if (!0 !== this.share.get("is_aclmode") || "surveillance" !== this.tabPanel.generalForm.shareName.getValue().toLowerCase()) {
                            var e = this.getWebApiParamFromEachForm(),
                                t = [{
                                    api: "SYNO.C2FS.Share",
                                    method: "set",
                                    params: e,
                                    encryption: ["shareinfo"],
                                    version: 1
                                }];
                            t = t.concat(this.tabPanel.permissionGrid.disabled ? [] : this.tabPanel.permissionGrid.getWebAPI()), "yes" === this._D("supportNFS", "no") && _S("is_admin") && (t = t.concat(this.tabPanel.nfsGrid.disabled ? [] : this.tabPanel.nfsGrid.getWebAPI())), this.shareSetCheck(e).then(this.tempDisableWarn.bind(this)).then(this.unitPermissionWarn.bind(this)).then(this.shareSet.bind(this)).then(this.sendApplyRequest.bind(this, t))
                        } else this.getMsgBox().alert(this.title, this.helper.T("share", "share_acl_share_not_support"))
                    } else this.close()
                }
            }],
            items: this.createTabPanel(e)
        };
        return Ext.apply(t, e), t
    },
    createTabPanel: function(e) {
        var t = [new SYNO.SDS.C2FS.Share.GeneralForm({
            module: this.module,
            ref: "generalForm",
            owner: this,
            shareStore: this.module.panel.store,
            highlightBox: {
                marginRight: 12
            },
            itemId: "generalForm"
        }), new SYNO.SDS.C2FS.Share.PermissionGrid({
            module: this.module,
            owner: this,
            itemId: "permissionGrid",
            ref: "permissionGrid",
            disabled: !1 === this.share.get("is_aclmode"),
            hidden: !1 === this.share.get("is_aclmode"),
            hideCustomColumn: !SYNO.SDS.ControlPanel.Share.isCustomizable(this.share.data)
        }), new SYNO.SDS.C2FS.Share.AdvancedPermissionForm({
            module: this.module,
            owner: this,
            disabled: this.share.get("is_aclmode") && "homes" === this.share.get("name").toLowerCase(),
            ref: "advancedPermissionForm",
            itemId: "advancedPermissionForm"
        })];
        "yes" === this._D("supportNFS", "no") && _S("is_admin") && t.push(new SYNO.SDS.AdminCenter.Share.NFSGridPanel({
            module: this.module,
            owner: this,
            itemId: "nfsgrid",
            ref: "nfsGrid",
            blNfsEnabled: e.blNfsEnabled,
            blKerberosSupport: e.blKerberosSupport,
            blKerberosEnabled: e.blKerberosEnabled
        }));
        var i = {
            itemId: "tab",
            ref: "tabPanel",
            activeTab: 0,
            deferredRender: !1,
            useDefaultBtn: !1,
            items: t
        };
        return Ext.apply(i, e), new SYNO.SDS.Utils.TabPanel(i)
    },
    waitShareConfig: function(e, t, i) {
        var s = this;
        return new Promise(function(r, n) {
            return e().then(r, function(a) {
                0 !== t ? setTimeout(function() {
                    s.waitShareConfig(e, t - 1, i).then(r, n)
                }, i) : n(a)
            })
        })
    },
    loadEachFormData: function() {
        var e = this;
        this.setStatusBusy({
            text: this.helper.T("common", "msg_waiting")
        }), this.tabPanel.generalForm.shareName.resetValue(this.share.get("name")), this.tabPanel.generalForm.description.resetValue(this.share.get("desc")), this.tabPanel.generalForm.volumePath.disable(), this.tabPanel.generalForm.localCache.maxGb.resetValue(this.share.get("local_cache_max_gb")), SYNO.ux.AddWhiteTipWithMsg(this.tabPanel.generalForm.volumePath, this.helper.T("common", "share_transfer_volume_not_support")), _S("is_admin") && this.tabPanel.generalForm.cleanRecyleBin.show(), this.tabPanel.generalForm.shareName.validator = function(t) {
            if (e.tabPanel.generalForm.shareName.originalValue.toLowerCase() === t.toLowerCase()) return !0;
            var i = !1;
            return e.module.panel.store.each(function(e) {
                if (e.get("name").toLowerCase() === t.toLowerCase()) return i = !0, !1
            }), !i || e.helper.T("share", "share_already_exist")
        };
        this.waitShareConfig(function(e) {
            return new Promise(function(t, i) {
                e.local_cache_max_gb ? t() : i(e)
            })
        }.bind(this, this.share.data), 100, 100).then(function() {
            this.processLoadEachForm()
        }.bind(this), function(e) {
            SYNO.Debug("Share Config:", e), this.findWindow().getMsgBox().alert(this.title, this.helper.T("share", "c2_need_package"), function() {
                this.findWindow().close()
            }, this)
        }.bind(this))
    },
    processLoadEachForm: function() {
        var e = this,
            t = [{
                api: "SYNO.Core.Storage.Volume",
                method: "list",
                params: {
                    limit: -1,
                    offset: 0,
                    location: "internal"
                },
                version: 1
            }, {
                api: "SYNO.Core.Share",
                method: "get",
                version: 1,
                params: {
                    name: this.share.get("name"),
                    additional: ["recyclebin", "disable_list", "disable_modify", "disable_download", "unite_permission", "is_aclmode", "hidden", "advance_setting"]
                }
            }];
        _S("is_admin") && t.push({
            api: "SYNO.Core.RecycleBin",
            method: "get",
            version: 1,
            params: {
                id: this.share.get("name")
            }
        }), this.sendWebAPIPromise({
            params: {},
            compound: {
                stopwhenerror: !1,
                params: t
            },
            scope: this
        }).then(function(t) {
            var i = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.Share", "get"),
                s = Object.assign({}, e.share.data, i);
            e.tabPanel.generalForm.enableRecyleBin.resetValue(i.enable_recycle_bin), i.enable_recycle_bin ? (e.tabPanel.generalForm.recyleBinAdminOnly.resetValue(i.recycle_bin_admin_only), e.tabPanel.generalForm.cleanRecyleBin.enable()) : (e.tabPanel.generalForm.recyleBinAdminOnly.disable(), e.tabPanel.generalForm.cleanRecyleBin.disable()), e.tabPanel.generalForm.disableBrowsable.resetValue(i.hidden), e.tabPanel.generalForm.hideUnreadable.resetValue(i.hide_unreadable);
            var r = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.Storage.Volume", "list").volumes.find(function(t) {
                return t.volume_path === e.share.get("vol_path")
            });
            if (e.tabPanel.generalForm.volumePath.resetValue(String.format("{0} ({1}){2}", SYNO.SDS.Utils.StorageUtils.VolumeNameRenderer(r), r.fs_type, "" === r.description ? "" : " - " + r.description)), e.tabPanel.generalForm.localCache.maxGb.validator = function(t) {
                    if (t > e.share.get("bucket_size_gb")) return String.format(e.helper.T("warn", "local_cache_size_exceed_bucket"), SYNO.SDS.Utils.CapacityRender(1024 * e.share.get("bucket_size_gb"), 1));
                    var i = SYNO.SDS.C2FS.Share.Utils.idealLocalCacheGB({
                        free_mb: r.size_free_byte / 1024 / 1024,
                        total_mb: r.size_total_byte / 1024 / 1024
                    }, {
                        used_mb: 1024 * e.share.get("local_cache_used_gb")
                    });
                    if (t > i) return String.format(e.helper.T("warn", "set_local_cache_exceed_volume"), r.display_name, i.toFixed(2));
                    var s = SYNO.SDS.C2FS.Share.Utils.minLocalCacheGB({
                        total_mb: 1024 * e.share.get("bucket_size_gb")
                    });
                    return !(t < s) || String.format(e.helper.T("warn", "set_local_cache_too_low"), s.toFixed(2))
                }, _S("is_admin")) {
                var n = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.RecycleBin", "get");
                e.tabPanel.generalForm.setRecycleStatus(n.is_cleaning)
            }
            return Promise.all([e.tabPanel.permissionGrid.loadFormData(e.share), e.tabPanel.advancedPermissionForm.loadPermissions(e.share, s)])
        }).catch(function(t) {
            SYNO.Debug("webapi error:", t);
            var i = SYNO.API.getErrorString(SYNO.API.Response.GetFirstError(t)) || e.helper.T("common", "proc_conflict");
            e.getMsgBox().alert(e.title, i, function() {
                e.close()
            }, e)
        }).then(function(t) {
            e.tabPanel.nfsGrid && e.tabPanel.nfsGrid.getStore() && e.tabPanel.nfsGrid.getStore().load(), e.clearStatusBusy()
        }).catch(function(t) {
            SYNO.Debug("Promise reject:", t), e.clearStatusBusy()
        })
    },
    getWebApiParamFromEachForm: function() {
        var e = this.tabPanel.generalForm,
            t = this.tabPanel.advancedPermissionForm.getForm(),
            i = e.getForm().getValues(),
            s = {
                original_name: e.shareName.originalValue,
                new_share_attribute: {
                    description: e.description.isDirty() ? i.description : null,
                    is_browsable: e.disableBrowsable.isDirty() ? !i.disableBrowsable : null,
                    is_enable_recycle_bin: e.enableRecyleBin.isDirty() ? i.enable_recycle_bin : null,
                    is_recycle_bin_admin_only: e.recyleBinAdminOnly.isDirty() ? i.recycle_bin_admin_only : null,
                    is_hide_unreadable: e.hideUnreadable.isDirty() ? i.hide_unreadable : null
                },
                new_share_basic_info: {
                    local_cache_max_mb: 1024 * i.local_cache_max_gb,
                    name: i.name,
                    volume_path: e.volumePath.getValue()
                }
            };
        return t.isDirty() && Object.assign(s.new_share_attribute, {
            is_disable_list: t.findField("disable_list").getValue(),
            is_disable_modify: t.findField("disable_modify").getValue(),
            is_disable_download: t.findField("disable_download").getValue(),
            is_unite_permission: t.findField("unite_permission").getValue()
        }), Object.keys(s.new_share_attribute).forEach(function(e) {
            null !== s.new_share_attribute[e] && void 0 !== s.new_share_attribute[e] || delete s.new_share_attribute[e]
        }), s
    },
    shareSetCheck: function(e) {
        return this.setStatusBusy({
            text: this.helper.T("common", "msg_waiting")
        }), new Promise(function(t) {
            this.sendWebAPI({
                api: "SYNO.C2FS.Share",
                method: "validate_set",
                params: e,
                encryption: ["shareinfo"],
                version: 1,
                scope: this,
                callback: function(e, i, s) {
                    this.clearStatusBusy(), e ? t() : i.code != this.helper.ErrorMap.ERR_NOT_FEASIBLE ? this.helper.popupErrorMessage(this, i.code) : this.helper.popupFeasibilityCheckMsg(this, i.errors.feasibility_check, t)
                }
            })
        }.bind(this))
    },
    tempDisableWarn: function() {
        return new Promise(function(e) {
            var t = [],
                i = this.tabPanel.generalForm;
            i.shareName.isDirty() && t.push(String.format(this.helper.T("warn", "set_temp_disable_by_rename"), i.shareName.getValue()));
            var s = 0 !== t.length,
                r = i.localCache.maxGb.getValue();
            if (i.localCache.isDirty() && r < this.share.get("local_cache_used_gb") + 2 && t.push(String.format(this.helper.T("warn", "set_temp_disable_by_local_cache_change"), r)), 0 !== t.length) {
                var n = "",
                    a = "<br><br>" + t.join("<br>") + "<br><br>" + this.helper.T("common", "ask_cont");
                n = s ? this.helper.T("warn", "set_temp_unaccessible") : this.helper.T("warn", "set_local_cache_smaller_affect"), this.getMsgBox().confirm(this.title, n + a, function(t) {
                    "yes" === t && e()
                }, this)
            } else e()
        }.bind(this))
    },
    unitPermissionWarn: function() {
        return new Promise(function(e) {
            var t = this.tabPanel.advancedPermissionForm.getForm().findField("unite_permission");
            t.isDirty() && !0 === t.getValue() ? this.getMsgBox().alert(this.title, this.helper.T("share", "warn_enable_advanced_permission"), function() {
                e()
            }, this) : e()
        }.bind(this))
    },
    shareSet: function() {
        var e = {
            name: this.share.get("name"),
            is_sync_share: this.share.get("is_sync_share"),
            permissions: this.tabPanel.permissionGrid.getModifiedPermissions(),
            no_check_permission: this.tabPanel.advancedPermissionForm.isAdvPermissionDisabled()
        };
        return new Promise(function(t) {
            SYNO.SDS.Utils.S2S.confirmIfSyncShareAffected(!1, e, {
                dialogTitle: this.title,
                dialogMsg: this.helper.T("s2s", "s2s_warn_share_change_priv"),
                dialogOwner: this,
                continueHandler: t,
                abortHandler: this.clearStatusBusy(),
                scope: this
            })
        }.bind(this))
    },
    sendApplyRequest: function(e) {
        this.setStatusBusy({
            text: this.helper.T("common", "msg_waiting")
        }), this.sendWebAPI({
            params: {},
            compound: {
                stopwhenerror: !0,
                params: e
            },
            encryption: ["shareinfo"],
            scope: this,
            callback: function(e, t, i) {
                this.clearStatusBusy();
                var s = SYNO.API.Response.GetValByAPI(t, "SYNO.Core.Share.Permission", "set"),
                    r = SYNO.API.Response.GetValByAPI(t, "SYNO.C2FS.Share", "set");
                if (!e || t.has_fail) {
                    var n = "";
                    if (r && r.code) switch (r.code) {
                        case this.helper.ErrorMap.ERR_CACHE_SIZE_TOO_LOW:
                            n = String.format(this.helper.ErrorMap[r.code], Math.ceil(r.errors.local_cache_lower_limit_mb / 1024));
                            break;
                        case this.helper.ErrorMap.ERR_UNSYNC_EXCEED_CACHE_SIZE:
                            n = String.format(this.helper.ErrorMap.T(r.code), Math.ceil(r.errors.local_cache_lower_limit_mb / 1024));
                            break;
                        default:
                            n = this.helper.ErrorMap.T(r.code)
                    }
                    return s && s.code && (n = n || SYNO.API.Errors.core[s.code]), void this.getMsgBox().alert(this.title, n || this.helper.T("common", "error_system"))
                }
                r && r.name ? (this.module.getPanel().fireEvent("sharefolderchanged", r.name), SYNO.SDS.StatusNotifier.fireEvent("sharefolderchanged", "permission"), s && s.is_ftp_anonymous_chroot_conflict ? this.tabPanel.permissionGrid.confirmToShowFTPAdvancedSetting({
                    closeDialog: !0
                }) : this.close()) : this.close()
            }
        })
    },
    isAnyFormDirty: function() {
        return this.tabPanel.generalForm.isFormDirty() || this.tabPanel.permissionGrid.isChanged() || this.tabPanel.advancedPermissionForm.getForm().isDirty() || this.tabPanel.nfsGrid && 0 !== this.tabPanel.nfsGrid.dataModified
    }
}), Ext.ns("SYNO.SDS.C2FS"), SYNO.SDS.C2FS.UtilForDSM = {
    helper: SYNO.SDS.C2FS.Helper,
    object: new Ext.Component,
    listWebapiTask: null,
    askAccountWebapiTask: null,
    shareStore: null,
    getAndCheckNotSupportReason: function() {
        return "no" === _D("support_c2fs", "no") || "chs" === _S("lang") ? _T("share", "c2_not_support") : !0 === _S("is_hybrid_ha") ? this.helper.T("error", "hybrid_ha_is_running") : ""
    },
    exclusiveDeleteErrorMsg: function(e) {
        if (!e) return [];
        var t = [];
        return t.push(this.helper.ErrorMap.T(e.code) || this.helper.T("common", "error_system")), t
    },
    exclusiveValidateDeleteWarnMsg: function(e) {
        if (!e) return [];
        var t = [];
        return t.push(this.helper.ErrorMap.T(e.code) || this.helper.T("common", "error_system")), t
    },
    c2ShareTpl: function() {
        return (new Ext.XTemplate).html
    },
    c2ShareInnerTpl: function() {
        var e = '<dt class="share-info share-info-title">{0}</dt>',
            t = '<dt class="share-info share-info-value {1}">{0}</dt>';
        return new Ext.XTemplate("<dl>", String.format(e, this.helper.T("bucket", "c2_storage_size") + this.helper.T("common", "colon")), String.format(t, "{bucketStorageSize}"), "</dl>", "<dl>", String.format(e, this.helper.T("bucket", "c2_storage_usage") + this.helper.T("common", "colon")), String.format(t, "{bucketStorageUsage}"), "</dl>", "<dl>", String.format(e, this.helper.T("status", "cache_size") + this.helper.T("common", "colon")), String.format(t, '{localCacheSize}<div ext:wtip="{localCacheTip}" style="height:20px; bottom:2px" class="syno-ux-whitetip-icon"></div>'), "</dl>", "<dl>", String.format(e, this.helper.T("status", "cache_usage") + this.helper.T("common", "colon")), String.format(t, "{localCacheUsage}"), "</dl>", "<dl>", String.format(e, this.helper.T("status", "upload_queue") + this.helper.T("common", "colon")), String.format(t, '{uploadQueue}<div ext:wtip="{uploadQueueTip}" style="height:20px; bottom:2px" class="syno-ux-whitetip-icon"></div>'), "</dl>", "<dl>", String.format(e, this.helper.T("status", "upload_status") + this.helper.T("common", "colon")), String.format(t, "{uploadStatus}"), "</dl>", '<div class="x-clear"></div>').html
    },
    setC2ShareRecordDisable: function(e) {
        e.set("condition", this.helper.T("common", "disabled")), e.set("conditionCls", "red-status"), e.set("localCacheSize", this.helper.T("common", "disabled")), e.set("localCacheTip", this.helper.T("common", "local_cache_size_description")), e.set("localCacheUsage", this.helper.T("common", "disabled")), e.set("bucketStorageSize", this.helper.T("common", "disabled")), e.set("bucketStorageUsage", this.helper.T("common", "disabled")), e.set("uploadQueue", this.helper.T("common", "disabled")), e.set("uploadQueueTip", this.helper.T("common", "upload_queue_desc")), e.set("uploadStatus", this.helper.T("common", "disabled"))
    },
    setC2ShareRecordUpdating: function(e) {
        e.set("condition", this.helper.T("common", "loading")), e.set("conditionCls", "blue-status"), e.set("localCacheSize", "-"), e.set("localCacheTip", this.helper.T("common", "local_cache_size_description")), e.set("localCacheUsage", "-"), e.set("bucketStorageSize", "-"), e.set("bucketStorageUsage", "-"), e.set("uploadQueue", SYNO.SDS.Utils.CapacityRender(0)), e.set("uploadQueueTip", this.helper.T("common", "upload_queue_desc")), e.set("uploadStatus", SYNO.SDS.C2FS.Helper.capacityRender(0) + "/s")
    },
    recordConditionSet: function(e, t) {
        var i = function(t) {
                for (var i = arguments.length, s = new Array(i > 1 ? i - 1 : 0), r = 1; r < i; r++) s[r - 1] = arguments[r];
                return String.format.apply(this, [t, '<a id="' + this.shareStatusLink[e.get("name")] + '" class="link-font" style="cursor:pointer;">', "</a>"].concat(s))
            }.bind(this),
            s = t.status.filter(function(e) {
                return SYNO.SDS.C2FS.Share.Utils.isNormalStatus(e)
            }),
            r = t.status.filter(function(e) {
                return SYNO.SDS.C2FS.Share.Utils.isWarningStatus(e)
            }),
            n = t.status.filter(function(e) {
                return SYNO.SDS.C2FS.Share.Utils.isErrorStatus(e)
            });
        if (n.length > 1) return e.set("condition", i(this.helper.T("status", "multi_abnormal_status"), n.length)), e.set("conditionCls", "red-status"), void e.set("statusIconCls", "c2-share-offline-icon");
        switch (e.set("statusIconCls", "syno-admincenter-c2share-icon"), n[0]) {
            case void 0:
                break;
            case "disconnected":
                return e.set("condition", i(this.helper.T("status", "disconnected"))), e.set("conditionCls", "red-status"), void e.set("statusIconCls", "c2-share-offline-icon");
            case "incompatible":
                return e.set("condition", i(this.helper.T("status", "version_incompatible"))), e.set("conditionCls", "red-status"), void e.set("statusIconCls", "c2-share-offline-icon");
            case "unauth":
                return e.set("condition", i(this.helper.T("status", "unauth"))), e.set("conditionCls", "red-status"), void e.set("statusIconCls", "c2-share-offline-icon");
            case "no_config":
                return this.setC2ShareRecordDisable(e), e.set("condition", i(this.helper.T("status", "no_config"))), e.set("conditionCls", "red-status"), void e.set("statusIconCls", "c2-share-offline-icon");
            case "space_full":
                return e.set("condition", i(this.helper.T("status", "space_full"))), void e.set("conditionCls", "red-status");
            case "c2_space_full":
                return e.set("condition", i(this.helper.T("status", "c2_space_full"))), void e.set("conditionCls", "red-status");
            default:
                return void this.setC2ShareRecordDisable(e)
        }
        if (r.length > 1) return e.set("condition", i(this.helper.T("status", "multi_abnormal_status"), r.length)), void e.set("conditionCls", "orange-status");
        switch (r[0]) {
            case void 0:
                break;
            case "in_throttle":
                return e.set("condition", i(this.helper.T("status", "in_throttle"))), void e.set("conditionCls", "orange-status");
            case "insufficient_volume_free_space":
                return e.set("condition", i(this.helper.T("status", "insufficient_volume_free_space"))), void e.set("conditionCls", "orange-status");
            case "slow_uploading":
                return e.set("condition", i(this.helper.T("status", "slow_uploading"), SYNO.SDS.Utils.CapacityRender(t.unsync_data_mb))), void e.set("conditionCls", "orange-status")
        }
        switch (s[0]) {
            case void 0:
            case "nothing_need_upload":
            case "uploading":
                return e.set("condition", this.helper.T("status", "connected")), void e.set("conditionCls", "green-status");
            case "full_resync":
                return e.set("condition", String.format(this.helper.T("status", "full_resync"), t.full_resync_progress.progress.toFixed(2))), void e.set("conditionCls", "blue-status");
            case "transform_check":
                e.set("condition", String.format(this.helper.T("status", s[0]), t.transform_check_progress.dir_count, t.transform_check_progress.file_count)), e.set("conditionCls", "blue-status");
                break;
            case "transform_upload":
                return e.set("condition", String.format(this.helper.T("status", s[0]), t.transform_to_c2_progress.progress.toFixed(2))), void e.set("conditionCls", "blue-status");
            case "confirming_connection":
                return e.set("condition", this.helper.T("status", "confirming_connection")), void e.set("conditionCls", "blue-status");
            case "in_write_throttle":
                return e.set("condition", i(this.helper.T("status", "in_write_throttle"))), void e.set("conditionCls", "blue-status");
            case "building":
                return e.set("condition", this.helper.T("status", "building")), void e.set("conditionCls", "blue-status");
            default:
                return SYNO.Debug("Unknown hybrid share status ", s[0]), e.set("condition", this.helper.T("common", "disabled")), void e.set("conditionCls", "red-status")
        }
    },
    updateC2ShareRecord: function(e, t) {
        if (this.recordConditionSet(e, t), t.hasOwnProperty("bucket_total_mb") && t.hasOwnProperty("bucket_used_mb") && t.hasOwnProperty("cache_used_mb") && t.hasOwnProperty("local_cache_max_mb") && t.hasOwnProperty("unsync_data_mb") && t.hasOwnProperty("sync_speed_mb_s")) {
            this.shareOldData[e.get("name")] = t, e.set("localCacheSize", SYNO.SDS.Utils.CapacityRender(t.local_cache_max_mb)), e.set("localCacheTip", this.helper.T("common", "local_cache_size_description")), e.set("localCacheUsage", SYNO.SDS.Utils.CapacityRender(t.cache_used_mb) + " (" + this.helper.percentRender(t.cache_used_mb, t.local_cache_max_mb) + ")");
            var i = t.hasOwnProperty("synology_account") ? t.synology_account : this.helper.T("common", "disabled");
            e.set("bucketStorageSize", SYNO.SDS.Utils.CapacityRender(t.bucket_total_mb) + " (" + i + ")"), e.set("bucketStorageUsage", SYNO.SDS.Utils.CapacityRender(t.bucket_used_mb) + " (" + this.helper.percentRender(t.bucket_used_mb, t.bucket_total_mb) + ")"), e.set("uploadQueue", SYNO.SDS.Utils.CapacityRender(t.unsync_data_mb)), e.set("uploadQueueTip", this.helper.T("common", "upload_queue_desc"));
            var s = SYNO.SDS.C2FS.Helper.capacityRender(1024 * t.sync_speed_mb_s, 2) + "/s";
            if (t.status.includes("uploading"))
                if (t.unsync_data_mb < .01 || 0 === t.sync_speed_mb_s) s = this.helper.T("status", "syncing_file");
                else if (0 !== t.sync_speed_mb_s) {
                var r = t.unsync_data_mb / t.sync_speed_mb_s;
                s += ", " + String.format(this.helper.T("status", "remain"), this.helper.timeRender(r, "s"))
            }
            e.set("uploadStatus", s), e.set("local_cache_max_gb", t.local_cache_max_mb / 1024), e.set("bucket_size_gb", t.bucket_total_mb / 1024), e.set("local_cache_used_gb", t.cache_used_mb / 1024)
        }
    },
    onPackageStatusChange: function(e) {
        "start" !== e && (this.listWebapiTask && this.listWebapiTask.stop(), this.askAccountWebapiTask && this.askAccountWebapiTask.stop(), this.shareStore.each(function(e) {
            !1 !== e.get("is_c2_share") && (e.beginEdit(), this.setC2ShareRecordDisable(e), e.set("condition", this.helper.T("share", "c2_no_package_status")), e.endEdit())
        }.bind(this)))
    },
    initEvents: function(e) {
        "yes" === _D("support_c2fs_transform", "no") && (SYNO.SDS.C2FS.UtilForDSM.initTransformC2ShareWizard = function(e) {
            return new SYNO.SDS.C2FS.Share.Transform.Wizard(e)
        }, SYNO.SDS.C2FS.UtilForDSM.canTransformToC2Share = function(e) {
            return !1 === e.get("is_c2_share")
        });
        var t = function() {
            this.listWebapiTask && this.listWebapiTask.stop(), this.askAccountWebapiTask && this.askAccountWebapiTask.stop(), SYNO.SDS.Packages.unregisterPackageStatusChange(this.onPackageStatusChange, this)
        }.bind(this);
        t(), this.object.clearMons(), this.object.mon(e, "beforedestroy", t, this, {
            single: !0
        }), this.object.mon(e, "deactivate", t, this, {
            single: !0
        }), SYNO.SDS.Packages.registerPackageStatusChange(this.onPackageStatusChange, this, this.helper.PKG_ID)
    },
    updateOldInfoOfShare: function(e, t) {
        this.shareOldData || (this.shareOldData = {}), t && t.hasOwnProperty("bucket_total_mb") && t.hasOwnProperty("bucket_used_mb") && t.hasOwnProperty("local_cache_max_mb") && t.hasOwnProperty("cache_used_mb") && t.hasOwnProperty("sync_speed_mb_s") && t.hasOwnProperty("unsync_data_mb") && t.hasOwnProperty("synology_account") && Array.isArray(t.status) || SYNO.Debug("Bad info: ", t), this.shareOldData[e] = t
    },
    fetchInfoOfC2Share: function(e) {
        var t = this;
        if (e && e.suspendEvents && e.each)
            if (this.shareStore = e, this.initEvents(e.appWindow.activePage), SYNO.SDS.StatusNotifier.isAppEnabled("SYNO.SDS.C2FS.Application")) {
                if (-1 !== e.find("is_c2_share", !0)) {
                    this.shareStatusLink = {}, this.shareOldData ? this.shareListPollingCallback(!0, this.shareOldData) : (e.each(function(e) {
                        !1 !== e.get("is_c2_share") && t.setC2ShareRecordUpdating(e)
                    }), this.shareOldData = {});
                    var i = function() {
                        this.listWebapiTask = this.object.addWebAPITask({
                            interval: 5e3,
                            api: "SYNO.C2FS.Share",
                            method: "list",
                            version: 1,
                            scope: this,
                            callback: this.shareListPollingCallback
                        }).start()
                    }.bind(this);
                    SYNO.API.currentManager.queryAPI("SYNO.C2FS.Share", i, this);
                    var s = function() {
                        this.askAccountWebapiTask = this.object.addWebAPITask({
                            interval: 108e5,
                            api: "SYNO.C2FS.Bucket",
                            method: "ask_account",
                            version: 1,
                            scope: this,
                            callback: function(e, t) {
                                e || SYNO.Debug(t)
                            }
                        }).start()
                    }.bind(this);
                    SYNO.API.currentManager.queryAPI("SYNO.C2FS.Bucket", s, this)
                }
            } else e.each(function(e) {
                !1 !== e.get("is_c2_share") && (e.beginEdit(), this.setC2ShareRecordDisable(e), e.set("condition", this.helper.T("share", "c2_no_package_status")), e.endEdit())
            }.bind(this))
    },
    shareListPollingCallback: function(e, t) {
        return this.shareStore.suspendEvents(!1), this.shareStore.each(function(i) {
            if (!1 !== i.get("is_c2_share")) {
                if (!1 === e || !t) return SYNO.Debug("Failed to list hybrid share, err:", t), this.setC2ShareRecordDisable(i), void(t && t.error && (t.error.code == this.helper.ErrorMap.ERR_NO_SUCH_API || t.error.code == this.helper.ErrorMap.ERR_NO_SUCH_METHODS) && (i.set("condition", this.helper.T("share", "c2_no_package_status")), i.set("conditionCls", "red-status")));
                this.shareStatusLink.hasOwnProperty(i.get("name")) || (this.shareStatusLink[i.get("name")] = Ext.id());
                var s = t[i.get("name")];
                s ? this.updateC2ShareRecord(i, s) : this.setC2ShareRecordDisable(i)
            }
        }.bind(this)), this.shareStore.resumeEvents(), this.shareStore.fireEvent("datachanged", this.shareStore), Object.keys(this.shareStatusLink).forEach(function(e) {
            var i = this.shareStatusLink[e];
            if (!Ext.get(i)) return !1;
            Ext.get(i).on({
                scope: this,
                click: function() {
                    new SYNO.SDS.C2FS.Share.Issue({
                        owner: this.shareStore.appWindow,
                        shareName: e,
                        updateData: t[e],
                        share: this.shareStore.getById(e)
                    }).onOpen()
                }
            }, this)
        }.bind(this)), !1
    },
    initCreateC2ShareWizard: function(e) {
        return new SYNO.SDS.C2FS.Wizard(e)
    },
    initEditC2ShareWizard: function(e) {
        return new SYNO.SDS.C2FS.Share.EditDialog(e)
    }
}, Ext.define("SYNO.SDS.C2FS.Share.Transform.WelcomeStep", {
    extend: "SYNO.SDS.Wizard.WelcomeStep",
    helper: SYNO.SDS.C2FS.Helper,
    constructor: function(e) {
        this.shareStore = e.module.panel.store, this.targetShare = e.share, this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = {
            headline: this.helper.T("common", "hybrid_share"),
            items: [this.createPanel()],
            listeners: {
                destroy: this.unregister
            }
        };
        return Ext.apply(t, e), t
    },
    createPanel: function() {
        var e = this;
        return this.newShareDescriptionLearnMoreId = Ext.id(), new SYNO.ux.Panel({
            cls: "c2fs-panel-no-padding",
            layout: "vbox",
            listeners: {
                afterrender: function() {
                    e.appWin.setStatusBusy({
                        text: e.helper.T("common", "msg_waiting")
                    }), e.checkCanTransformShare()
                }
            },
            items: [{
                xtype: "label",
                name: "create_wizard_image",
                width: 740,
                height: 240,
                cls: "c2-create-wizard-img"
            }, {
                xtype: "syno_displayfield",
                cls: "c2-create-wizard-welcome-txt",
                htmlEncode: !1,
                value: String.format(this.helper.T("common", "new_share_detail_description"), '<a href="https://c2.synology.com/" class="c2-link-no-bold" target="_blank">', "</a>", '<a id="' + this.newShareDescriptionLearnMoreId + '" class="link-font c2-link-no-bold" tabindex="0" role="link">', "</a>"),
                listeners: {
                    afterrender: function() {
                        Ext.get(e.newShareDescriptionLearnMoreId).on("click", function() {
                            SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                                topic: "SYNO.SDS.C2FS.Application"
                            }, !1)
                        }, e)
                    },
                    scope: this
                }
            }, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                value: '<span class="syno-ux-note">' + this.helper.T("common", "note") + this.helper.T("common", "colon") + "</span>" + String.format(this.helper.T("common", "create_wizard_welcome_note"), '<a href="https://sy.to/HybridShareBeta" class="c2-link-no-bold" target="_blank">', "</a>")
            }]
        })
    },
    hasExistedHybridShare: function() {
        return this.shareStore.getRange().filter(function(e) {
            return !0 === e.get("is_c2_share")
        }).length >= this.helper.MAX_C2_SHARE_NUM
    },
    checkCanTransformShare: function() {
        var e = this;
        !0 === this.hasExistedHybridShare() && this.appWin.getMsgBox().alert(this.appWin.title, this.helper.T("warn", "one_hybrid_share_only"), function() {
            e.appWin.close()
        }), 0 === this.targetShare.get("encryption") ? !0 !== this.targetShare.get("is_cold_storage_share") ? !0 !== this.targetShare.get("is_cluster_share") ? !1 !== this.targetShare.get("is_btrfs_share") ? SYNO.SDS.C2FS.Share.Utils.isNoSupportShareName(this.targetShare.get("name")) ? this.appWin.getMsgBox().alert(this.appWin.title, this.helper.T("warn", "transform_reserved_share_no_way"), function() {
            e.appWin.close()
        }) : this.appWin.clearStatusBusy() : this.appWin.getMsgBox().alert(this.appWin.title, this.helper.T("warn", "transform_not_btrfs_share_no_way"), function() {
            e.appWin.close()
        }) : this.appWin.getMsgBox().alert(this.appWin.title, this.helper.T("warn", "transform_cluster_share_no_way"), function() {
            e.appWin.close()
        }) : this.appWin.getMsgBox().alert(this.appWin.title, this.helper.T("warn", "transform_cold_storage_share_no_way"), function() {
            e.appWin.close()
        }) : this.appWin.getMsgBox().alert(this.appWin.title, this.helper.T("warn", "transform_encryption_share_no_way"), function() {
            e.appWin.close()
        })
    },
    sendDsmWebApiFailure: function(e) {
        var t = this;
        SYNO.Debug("api err: ", e);
        var i = SYNO.API.Errors.core[e.error.code] || this.helper.T("common", "error_system");
        return this.appWin.getMsgBox().alert(this.title, i, function() {
            t.appWin.close()
        }), !1
    },
    getNext: function() {
        return _S("is_admin") ? this.adminUserCheckNtpSetting() : this.delegatedUserCheckNtpSetting(), !1
    },
    delegatedUserCheckNtpSetting: function() {
        var e = this;
        this.sendWebAPIPromise({
            api: "SYNO.C2FS.Utils",
            version: 1,
            method: "check_ntp_enable",
            scope: this
        }).then(function(t) {
            t.is_ntp_enable ? e.popC2LoginWeb() : e.appWin.getMsgBox().alert(e.title, e.helper.T("warn", "inform_admin_of_enabling_ntp"))
        }).catch(this.sendDsmWebApiFailure)
    },
    adminUserCheckNtpSetting: function() {
        var e = this;
        this.sendWebAPIPromise({
            api: "SYNO.Core.Region.NTP",
            method: "get",
            version: 2,
            scope: this
        }).then(function(t) {
            if ("ntp" !== t.enable_ntp) {
                var i = e.appWin.getMsgBox();
                i.confirm(e.appWin.title, String.format(e.helper.T("warn", "need_enable_ntp_sync_setting"), '<a class="link-font c2-link-no-bold" tabindex="0" role="link">', "</a>"), function(i) {
                    "yes" === i ? function(t) {
                        var i = e._D("product");
                        e.appWin.setStatusBusy({
                            text: SYNO.SDS.AdminCenter.Region.Utils.ntpUpdateProgressMsg(i, t.server)
                        }), e.sendWebAPIPromise({
                            api: "SYNO.Core.Region.NTP",
                            method: "ensure_ntp_sync_and_enable",
                            version: 1,
                            params: {
                                enable_ntp: "ntp",
                                timezone: t.timeZone ? t.timeZone : "Dublin",
                                server: t.server ? t.server : "time.google.com"
                            }
                        }).then(function() {
                            e.appWin.clearStatusBusy(), e.popC2LoginWeb()
                        }).catch(function(s) {
                            SYNO.Debug("Sync ntp, err: ", s), e.appWin.clearStatusBusy(), e.appWin.getMsgBox().alert(e.title, SYNO.SDS.AdminCenter.Region.Utils.ntpUpdateFailedMsg(i, t.server), Ext.emptyFn)
                        })
                    }(t) : e.appWin.close()
                }, e.appWin, {
                    yes: {
                        text: e.helper.T("common", "ok")
                    },
                    no: {
                        text: e.helper.T("common", "cancel")
                    }
                }), i.getDialog().el.child(".link-font").on("click", function() {
                    SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                        topic: "SYNO.SDS.C2FS.Application:create_hybrid_share.html"
                    }, !1)
                })
            } else e.popC2LoginWeb()
        }).catch(this.sendDsmWebApiFailure.bind(this))
    },
    popC2LoginWeb: function() {
        this.unregister();
        this.register(this.c2PostMessageManager, "C2Share");
        var e = Ext.urlDecode(window.location.href.split("?")[1]),
            t = encodeURIComponent(String.format("{0}//{1}", window.location.protocol, window.location.host)),
            i = "test" == e.everest ? "https://account.c2test.synology.com/c2share/" : "https://account.c2.synology.com/c2share/";
        i += String.format("?origin={0}&version={1}", t, this.helper.pkgVersion()), this.popup = window.open(i, "c2_web", "menubar=1, resizable=0, width=1080, height=800, top=100, left=300"), this.popup || this.appWin.getMsgBox().alert(this.appWin.title, this.helper.T("warn", "popup_c2_web_failed"), Ext.emptyFn)
    },
    c2PostMessageManager: function(e) {
        var t = this;
        switch (e.data.cmd) {
            case "check_mount":
                this.checkAccountMount(e);
                break;
            case "authorize":
                var i = e.data.share,
                    s = e.data;
                if (i && i.shares && i.shares[0]) {
                    var r = s.catalog.find(function(e) {
                        return "api" === e.name
                    }).endpoints[0].url;
                    if ("http" !== r.substring(0, 4) && (r = "https://" + r), i.shares[0].share_key && SYNO.SDS.Utils.IsJson(i.shares[0].share_key)) return this.appWin.getMsgBox().alert(this.appWin.title, "This bucket cannot be migrated target init, because it is inited"), !1;
                    this.appWin.setStatusBusy(), this.owner.fireEvent("setServerInfo", {
                        metadata: i.shares[0].metadata ? i.shares[0].metadata : "",
                        c2share_api_url: r + "/c2share/v1",
                        project_id: s.project_id,
                        share_id: i.shares[0].share_id,
                        scoped_token: s.scoped_token,
                        synology_account: s.account,
                        bucket_name: i.shares[0].share_name,
                        bucket_used_mb: i.shares[0].bytes_used / 1024 / 1024,
                        bucket_total_mb: i.total_quota / 1024 / 1024
                    }), this.sendWebAPIPromise({
                        api: "SYNO.C2FS.Transform",
                        method: "validate_for_service",
                        version: 1,
                        params: {
                            share_name: this.targetShare.get("name")
                        },
                        scope: this
                    }).then(function() {
                        return t.appWin.clearStatusBusy(), t.appWin.goNext(t.nextId), !1
                    }).catch(function(e) {
                        return t.appWin.clearStatusBusy(), e.code !== t.helper.ErrorMap.ERR_NOT_FEASIBLE ? (SYNO.Debug("err", e), t.helper.popupErrorMessage(t.appWin, e.code), !1) : (t.owner.fireEvent("recordFeasibilityCheck", e.errors), t.appWin.goNext(t.validateId), !1)
                    })
                }
        }
    },
    checkAccountMount: function(e) {
        var t = this;
        return !!e.data.account && (this.sendWebAPIPromise({
            api: "SYNO.C2FS.Bucket",
            method: "get_account_mount",
            version: 1,
            params: {
                synology_account: e.data.account
            },
            scope: this
        }).then(function(i) {
            t.popup.postMessage({
                shares: i
            }, e.origin)
        }).catch(function(e) {
            return t.helper.popupErrorMessage(t.appWin, e.code, function() {
                t.appWin.close()
            }), !1
        }), !0)
    },
    register: function(e, t) {
        var i = this;
        this.receiveMessage = function(s) {
            /setImmediate/.test(s.browserEvent.data) || s.browserEvent.data.pkg_name === t && e.call(i, s.browserEvent)
        }, Ext.EventManager.addListener(window, "message", this.receiveMessage)
    },
    unregister: function() {
        Ext.EventManager.removeListener(window, "message", this.receiveMessage)
    }
}), Ext.define("SYNO.SDS.C2FS.Share.Transform.ValidateStep", {
    extend: "SYNO.SDS.Wizard.Step",
    helper: SYNO.SDS.C2FS.Helper,
    constructor: function(e) {
        this.targetShare = e.share, this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        this.store = new Ext.data.JsonStore({
            autoDestroy: !0,
            fields: ["issue"]
        });
        var t = {
            headline: this.helper.T("transform", "invalid_check_title"),
            layout: "vbox",
            items: [new SYNO.SDS.Utils.FormPanel({
                title: this.helper.T("share", "share_subject"),
                border: !1,
                frame: !1,
                autoScroll: !0,
                header: !1,
                autoHeight: !0,
                width: "100%",
                ref: "form",
                itemId: "form",
                cls: "c2fs-panel-no-padding",
                items: [{
                    xtype: "syno_displayfield",
                    fieldLabel: this.helper.T("share", "share_name"),
                    value: this.targetShare.get("name")
                }, {
                    xtype: "syno_displayfield",
                    ref: "description",
                    name: "description",
                    value: this.helper.T("transform", "invalid_check_description")
                }]
            }), new SYNO.ux.SplitButton({
                text: this.helper.T("delegation", "export"),
                autoWidth: !0,
                scope: this,
                handler: this.exportHTML,
                menu: new SYNO.ux.Menu({
                    items: [{
                        text: this.helper.T("log", "html_type"),
                        scope: this,
                        handler: this.exportHTML
                    }, {
                        text: this.helper.T("log", "csv_type"),
                        scope: this,
                        handler: this.exportCSV
                    }]
                })
            }), new SYNO.ux.GridPanel({
                store: this.store,
                flex: 1,
                width: "100%",
                autoExpandColumn: "value",
                autoExpand: !0,
                colModel: new Ext.grid.ColumnModel({
                    columns: [{
                        header: this.helper.T("common", "issue_suggest"),
                        dataIndex: "issue",
                        renderer: function(e, t, i) {
                            return '<span style="white-space: normal; overflow-wrap: break-word;">' + String.format('<span ext:qtip="{0}">{0}</span>', e) + "</span>"
                        }
                    }]
                })
            })]
        };
        return Ext.apply(t, e), t
    },
    getValues: function() {
        return null
    },
    getNext: function() {
        return this.checkResult && this.checkResult.hard ? null : this.nextId
    },
    checkState: function() {
        this.callParent(), this.checkResult && this.checkResult.hard && this.owner.getButton("next").setText(this.helper.T("common", "done"))
    },
    activate: function() {
        if (this.checkResult = this.owner.getFeasibilityCheck(), this.checkResult.hard) {
            var e = this.checkResult.hard.map(function(e) {
                return {
                    issue: SYNO.SDS.Utils.GetFeasibilityCheckMsg(e)
                }
            });
            this.store.loadData(e)
        } else {
            if (this.checkResult.soft) {
                var t = this.checkResult.soft.map(function(e) {
                    return {
                        issue: SYNO.SDS.Utils.GetFeasibilityCheckMsg(e)
                    }
                });
                return this.setHeader(this.helper.T("transform", "warning_check_title")), this.form.description.setValue(this.helper.T("transform", "warning_check_description")), void this.store.loadData(t)
            }
            this.appWin.goNext()
        }
    },
    exportFile: function(e, t, i) {
        var s = new Blob([i], {
                type: e
            }),
            r = URL.createObjectURL(s),
            n = document.createElement("a");
        document.body.appendChild(n), n.href = r, n.download = t, n.click()
    },
    exportHTML: function() {
        var e = this.targetShare.get("name") + "_feasibility_check.html",
            t = '<html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8;"></head>';
        t += "<body>", t += '<table border=1 style="width: 95%; margin-left: auto; margin-right: auto;">', t += "<th>", t += Ext.util.Format.htmlEncode(this.helper.T("common", "issue_suggest")), t += "</th>", (this.checkResult.hard || this.checkResult.soft).forEach(function(e) {
            t += "<tr><td>", t += Ext.util.Format.htmlEncode(SYNO.SDS.Utils.GetFeasibilityCheckMsg(e)), t += "</td></tr>"
        }), t += "</table></body></html>", this.exportFile("text/html", e, t)
    },
    exportCSV: function() {
        var e = this.targetShare.get("name") + "_feasibility_check.csv",
            t = this.helper.T("common", "issue_suggest");
        (this.checkResult.hard || this.checkResult.soft).forEach(function(e) {
            t += "\n", t += SYNO.SDS.Utils.GetFeasibilityCheckMsg(e)
        }), this.exportFile("text/csv", e, t)
    }
}), Ext.define("SYNO.SDS.C2FS.Share.Transform.EncryptBucketStep", {
    extend: "SYNO.SDS.Wizard.Step",
    helper: SYNO.SDS.C2FS.Helper,
    constructor: function(e) {
        this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        this.formPanel = this.createFormPanel(e);
        var t = {
            headline: this.helper.T("common", "encryption_title"),
            layout: "vbox",
            items: [this.formPanel, {
                xtype: "spacer",
                flex: 1
            }, {
                xtype: "syno_displayfield",
                htmlEncode: !1,
                value: '<span class="syno-ux-note">' + this.helper.T("common", "note") + this.helper.T("common", "colon") + " </span>" + this.helper.T("common", "create_wizard_encrypt_reminder")
            }],
            listeners: {
                scope: this
            }
        };
        return Ext.apply(t, e), t
    },
    createFormPanel: function(e) {
        var t = this,
            i = {
                cls: "c2fs-panel-no-padding",
                itemId: "encryptBucketForm",
                autoFlexcroll: !1,
                labelWidth: 265,
                items: [{
                    xtype: "syno_displayfield",
                    style: "margin-bottom: 6px;",
                    hideLabel: !0,
                    htmlEncode: !1,
                    value: String.format(this.helper.T("common", "encryption_desc"), '<a id="' + Ext.id() + '" class="c2-link-no-bold" tabindex="0" role="link">', "</a>"),
                    listeners: {
                        afterrender: function(e) {
                            var i = e.el.query("a");
                            i[0] ? Ext.get(i[0].id).on("click", function() {
                                SYNO.SDS.AppLaunch("SYNO.SDS.HelpBrowser.Application", {
                                    topic: "SYNO.SDS.C2FS.Application:create_hybrid_share.html"
                                }, !1)
                            }, t) : SYNO.Debug("Failed to find link element: ", i)
                        },
                        scope: this
                    }
                }, {
                    xtype: "syno_textfield",
                    textType: "password",
                    width: 220,
                    minLength: 8,
                    maxLength: 64,
                    name: "enc_passwd",
                    allowBlank: !1,
                    fieldLabel: this.helper.T("share", "share_encryption_key"),
                    validator: function(e) {
                        return -1 === e.indexOf("=") && -1 === e.indexOf(",") && -1 === e.indexOf(":") || t.helper.T("share", "encryption_password_invalid")
                    }
                }, {
                    xtype: "syno_textfield",
                    textType: "password_confirm",
                    name: "enc_passwd_confirm",
                    confirmFor: "enc_passwd",
                    confirmFailedText: this.helper.T("share", "share_encryption_key_confirm_mismatch"),
                    maxlength: 64,
                    width: 220,
                    allowBlank: !1,
                    fieldLabel: this.helper.T("share", "share_encryption_key_confirm")
                }]
            };
        return Ext.apply(i, e), new SYNO.SDS.Utils.FormPanel(i)
    },
    isValid: function() {
        return this.formPanel.getForm().isValid()
    },
    getValues: function() {
        return null
    },
    getNext: function() {
        var e = this;
        if (this.isValid()) {
            var t = '<div class="c2-create-wizard"><p class="c2-warning-msg-content">' + this.helper.T("warn", "encrypt_note") + '</p><p class="c2-warning-msg-content c2-warning-red">' + this.helper.T("warn", "encrypt_key_cant_modified") + '</p><p class="c2-warning-msg-content c2-warning-red">' + this.helper.T("warn", "encrypt_key_no_save_on_server") + "</p></div>";
            this.appWin.getMsgBox().confirm(this.helper.T("warn", "encrypting_comfirm_title"), t, function(t) {
                "yes" === t && (e.appWin.setStatusBusy({
                    text: e.helper.T("common", "msg_waiting")
                }), e.sendWebAPIPromise({
                    api: "SYNO.C2FS.Bucket",
                    method: "encrypt",
                    version: 1,
                    encryption: ["encrypt_password", "server_info"],
                    params: {
                        encrypt_password: e.formPanel.getForm().getValues().enc_passwd,
                        server_info: e.owner.getServerInfo()
                    },
                    scope: e
                }).then(function() {
                    return e.appWin.clearStatusBusy(), e.downloadKey(), e.appWin.goNext(e.nextId), !1
                }).catch(function(t) {
                    return e.appWin.clearStatusBusy(), e.helper.popupErrorMessage(e.findWindow(), t.code), !1
                }))
            }, this, {
                yes: !0,
                no: !0
            }, {
                useMessageTitle: !0,
                hideBrElement: !0
            })
        }
        return !1
    },
    downloadKey: function() {
        var e = this.owner.getServerInfo();
        this.findAppWindow().downloadWebAPI({
            webapi: {
                api: "SYNO.C2FS.Bucket",
                method: "password_key_export",
                version: 1,
                params: {
                    share_id: e.share_id,
                    bucket_name: e.bucket_name
                }
            },
            scope: this,
            callback: function(e, t, i, s) {
                "timeout" !== e && !1 === i && this.findWindow().getMsgBox().alert(this.title, this.helper.T("status", "status_err_load"))
            }.bind(this)
        })
    }
}), Ext.define("SYNO.SDS.C2FS.Share.Transform.FillBasicInfoStep", {
    extend: "SYNO.SDS.Wizard.Step",
    helper: SYNO.SDS.C2FS.Helper,
    constructor: function(e) {
        this.targetShare = e.share, this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = this,
            i = {
                headline: this.helper.T("transform", "fill_basic_info_title"),
                layout: "fit",
                items: [new SYNO.SDS.Utils.FormPanel(Ext.apply({
                    title: this.helper.T("share", "share_subject"),
                    border: !1,
                    frame: !1,
                    header: !1,
                    height: 350,
                    labelWidth: 300,
                    ref: "form",
                    itemId: "form",
                    cls: "c2fs-panel-no-padding",
                    items: [{
                        xtype: "syno_displayfield",
                        style: "margin-bottom: 6px;",
                        htmlEncode: !1,
                        value: this.helper.T("common", "local_cache_size_description")
                    }, {
                        xtype: "syno_displayfield",
                        ref: "shareName",
                        name: "name",
                        fieldLabel: this.helper.T("share", "share_name"),
                        value: this.targetShare.get("name")
                    }, {
                        xtype: "syno_displayfield",
                        ref: "volumePath",
                        name: "volume_path",
                        fieldLabel: this.helper.T("volume", "volume_share_position"),
                        value: this.targetShare.get("status")
                    }, {
                        xtype: "syno_compositefield",
                        fieldLabel: this.helper.T("attribute", "local_cache"),
                        ref: "localCache",
                        name: "local_cache",
                        items: [{
                            xtype: "syno_numberfield",
                            ref: "sizeGb",
                            name: "local_cache_size_gb",
                            minValue: 0,
                            width: 204,
                            allowBlank: !1,
                            validator: function(e) {
                                var i = SYNO.SDS.C2FS.Share.Utils.LOCAL_CACHE.MIN_SIZE_GB;
                                if (e < i) return String.format(t.helper.T("warn", "set_local_cache_too_low"), i.toFixed(2));
                                if (!t.volume) return !0;
                                var s = t.volume.size_total_byte / 1024 / 1024 / 1024;
                                return !(e > s) || String.format(t.helper.T("warn", "set_local_cache_exceed_volume"), t.volume.display_name, s.toFixed(2))
                            }
                        }, {
                            xtype: "syno_displayfield",
                            width: 20,
                            name: "unit",
                            value: "GB"
                        }]
                    }]
                }, e))],
                listeners: {
                    scope: this
                }
            };
        return Ext.apply(i, e), i
    },
    activate: function() {
        var e = this;
        this.appWin.setStatusBusy(), this.sendWebAPIPromise({
            api: "SYNO.Core.Storage.Volume",
            method: "get",
            version: 1,
            scope: this,
            params: {
                volume_path: this.targetShare.get("vol_path")
            }
        }).then(function(t) {
            e.appWin.clearStatusBusy(), e.volume = t.volume, e.form.localCache.sizeGb.setValue(200), e.form.volumePath.setValue(String.format("{0} ({1})", SYNO.SDS.Utils.StorageUtils.VolumeNameRenderer(e.volume), e.volume.fs_type))
        }).catch(function(t) {
            e.appWin.clearStatusBusy(), SYNO.Debug(t)
        })
    },
    validate: function() {
        return this.form.getForm().isValid()
    },
    getValues: function() {
        return this.form.getForm().getValues()
    },
    getNext: function() {
        return !!this.validate() && this.nextId
    }
}), Ext.define("SYNO.SDS.C2FS.Share.Transform.SummaryStep", {
    extend: "SYNO.SDS.Wizard.Step",
    helper: SYNO.SDS.C2FS.Helper,
    constructor: function(e) {
        this.targetShare = e.share, this.ASSUMED_UPLOAD_SPEED = 2.5, this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        var t = {
            layout: "fit",
            headline: this.helper.T("transform", "summary_title"),
            items: [new SYNO.SDS.Utils.FormPanel(Ext.apply({
                header: !1,
                ref: "form",
                cls: "c2fs-panel-no-padding",
                items: [{
                    xtype: "syno_displayfield",
                    value: this.helper.T("transform", "summary_description")
                }, {
                    xtype: "syno_displayfield",
                    ref: "account",
                    fieldLabel: this.helper.T("common", "synology_account"),
                    value: "-"
                }, {
                    xtype: "syno_displayfield",
                    ref: "estimatedTime",
                    fieldLabel: this.helper.T("transform", "estimated_time"),
                    value: "-"
                }, {
                    xtype: "syno_panel",
                    cls: "c2-transform-summary c2fs-panel-no-padding",
                    ref: "diagram",
                    items: [{
                        style: "text-align: center",
                        xtype: "syno_displayfield",
                        ref: "title",
                        htmlEncode: !1,
                        value: "-"
                    }, {
                        xtype: "box",
                        cls: "img"
                    }, {
                        xtype: "syno_displayfield",
                        htmlEncode: !1,
                        ref: "detail",
                        data: {
                            share_size: "-",
                            local_cache_size: "-",
                            c2_size: "-"
                        },
                        tpl: '<div><span style = "text-align: center; width: 321px; display: inline-block; padding: 0px 0px 0px 20px;">' + this.helper.T("share", "share_size") + this.helper.T("common", "colon") + '<span class = "bold">{share_size}</span></span><span style = "text-align: center; width: 321px; display: inline-block; padding: 0px 0px 0px 18px;">' + this.helper.T("attribute", "local_cache") + this.helper.T("common", "colon") + '<span class = "hightlight bold">{local_cache_size}</span></span></div><div><span style = "text-align: center; width: 321px; display: inline-block; padding: 6px 0px 0px 359px;">' + this.helper.T("bucket", "c2_storage_size") + this.helper.T("common", "colon") + '<span class = "hightlight bold">{c2_size}</span></span></div>'
                    }]
                }]
            }))]
        };
        return Ext.apply(t, e), t
    },
    activate: function() {
        var e = this.targetShare.json.share_quota_used;
        this.form.estimatedTime.setValue(String.format(this.helper.T("transform", "display_about_time"), this.helper.timeRender(this.helper.approximateTime(e / this.ASSUMED_UPLOAD_SPEED, 2))));
        var t = this.owner.getServerInfo(),
            i = 1048576 * this.owner.getValues().fillBasicInfo.local_cache_size_gb;
        this.form.diagram.title.setValue(String.format(this.helper.T("transform", "summary_diagram_title"), '<span class = "bold">', this.targetShare.get("name") + "(" + this.targetShare.get("status") + ")", "</span>", '<span class = "hightlight bold">', "</span>")), SYNO.ux.AddWhiteTipWithMsg(this.form.diagram.title, String.format(this.helper.T("transform", "summary_diagram_white_tip"), this.helper.capacityRender(i, 0), this.helper.capacityRender(1024 * e, 0))), SYNO.ux.AddWhiteTipWithMsg(this.form.estimatedTime, String.format(this.helper.T("transform", "summary_estimate_time_white_tip"), 8 * this.ASSUMED_UPLOAD_SPEED)), this.form.diagram.detail.update({
            share_size: this.helper.capacityRender(1024 * e, 0),
            local_cache_size: this.helper.capacityRender(i, 0),
            c2_size: this.helper.capacityRender(1024 * t.bucket_total_mb, 0)
        }), this.form.account.setValue(t.synology_account)
    },
    getNext: function() {
        var e = this;
        return this.appWin.getMsgBox().confirm(this.appWin.title, String.format(this.helper.T("transform", "confirm_dialog_content"), "<b>" + this.targetShare.get("name") + "</b>") + this.helper.addAlignedBullet("<b>" + String.format(this.helper.T("transform", "confirm_dialog_time_estimated"), this.helper.timeRender(this.helper.approximateTime(this.targetShare.json.share_quota_used / this.ASSUMED_UPLOAD_SPEED, 2))) + "</b>") + this.helper.addAlignedBullet("<b>" + this.helper.T("transform", "confirm_dialog_service_temporarily_unavailable") + "</b>"), function(t) {
            if ("cancel" !== t) return e.appWin.setStatusBusy(), e.sendWebAPIPromise({
                api: "SYNO.C2FS.Transform",
                method: "transform_to_c2share",
                version: 1,
                scope: e,
                params: {
                    share_name: e.targetShare.get("name"),
                    local_cache_size_gb: e.owner.getValues().fillBasicInfo.local_cache_size_gb,
                    server_info: e.owner.getServerInfo()
                }
            }).then(function(t) {
                e.owner.isNeedCloseWarnMsg = !1, e.appWin.clearStatusBusy(), e.showTransformPolling(t.task_id), e.createBackgroundTask(t.task_id), SYNO.SDS.StatusNotifier.fireEvent("sharefolderchanged", e.targetShare.get("name"))
            }).catch(function(t) {
                return SYNO.Debug(t), e.appWin.clearStatusBusy(), e.helper.popupErrorMessage(e.appWin, t.code), !1
            }), !1
        }, this, {
            ok: !0,
            cancel: !0
        }), !1
    },
    createBackgroundTask: function(e) {
        SYNO.SDS.BackgroundTaskMgr.addWebAPITask({
            title: [this.helper.T("common", "transform_background_title") + ": " + this.targetShare.get("name")],
            query: {
                api: "SYNO.C2FS.Transform",
                method: "get_progress",
                version: 1,
                params: {
                    task_id: e,
                    for_background_task: !0
                }
            },
            cancel: {
                api: "SYNO.C2FS.Transform",
                method: "cancel",
                version: 1,
                params: {
                    share_name: this.targetShare.get("name")
                }
            }
        })
    },
    showTransformPolling: function(e) {
        var t = this,
            i = this.appWin.getMsgBox();
        i.show({
            progress: !0,
            closable: !1,
            buttons: {
                ok: this.helper.T("common", "hide"),
                cancel: this.helper.T("common", "cancel")
            },
            fn: function(e) {
                "ok" === e ? (t.module.panel.store.load(), t.appWin.goNext(t.nextId)) : "cancel" === e && (t.appWin.setStatusBusy({
                    text: "cancel migrate"
                }), t.sendWebAPIPromise({
                    api: "SYNO.C2FS.Transform",
                    method: "cancel",
                    version: 1,
                    params: {
                        share_name: t.targetShare.get("name")
                    }
                }).then(function() {
                    t.appWin.clearStatusBusy(), t.module.panel.store.load(), t.appWin.goNext(t.nextId)
                }).catch(function(e) {
                    SYNO.Debug(e), t.appWin.clearStatusBusy(), t.module.panel.store.load(), t.helper.popupErrorMessage(t.appWin, e.code)
                }))
            },
            msg: this.helper.T("common", "transform_check"),
            scope: this
        });
        var s = this.pollReg({
            webapi: {
                api: "SYNO.C2FS.Transform",
                method: "get_progress",
                version: 1,
                params: {
                    task_id: e
                }
            },
            interval: 5,
            immediate: !0,
            scope: this,
            status_callback: function(e, r, n, a) {
                return e ? r ? void("transform_check" === r.status ? i.updateProgress(0, t.helper.T("common", "transform_check"), String.format(t.helper.T("status", "transform_check_file"), 100)) : 1 == r.status.includes("transform") && i.updateProgress(r.progress.progress / 100, r.progress.progress.toFixed(2) + " %", t.helper.T("common", "transform"))) : (t.pollUnreg(s), i.hide(), t.module.panel.store.load(), void t.appWin.goNext(t.nextId)) : (SYNO.Debug("Get progress err ", r), t.pollUnreg(s), i.hide(), t.module.panel.store.load(), void t.appWin.goNext(t.nextId))
            }
        })
    }
}), Ext.define("SYNO.SDS.C2FS.Share.Transform.Wizard", {
    extend: "SYNO.SDS.Wizard.ModalWindow",
    helper: SYNO.SDS.C2FS.Helper,
    constructor: function(e) {
        this.isNeedCloseWarnMsg = !0, this.callParent([this.fillConfig(e)]), this.setAllStepSize()
    },
    fillConfig: function(e) {
        var t = [new SYNO.SDS.C2FS.Share.Transform.WelcomeStep({
                appWin: this,
                owner: this,
                module: e.module,
                itemId: "welcome",
                nextId: "encryptBucket",
                validateId: "validate",
                share: e.share
            }), new SYNO.SDS.C2FS.Share.Transform.ValidateStep({
                appWin: this,
                owner: this,
                module: e.module,
                itemId: "validate",
                nextId: "encryptBucket",
                share: e.share
            }), new SYNO.SDS.C2FS.Share.Transform.EncryptBucketStep({
                appWin: this,
                owner: this,
                module: e.module,
                itemId: "encryptBucket",
                nextId: "fillBasicInfo",
                share: e.share
            }), new SYNO.SDS.C2FS.Share.Transform.FillBasicInfoStep({
                appWin: this,
                owner: this,
                module: e.module,
                itemId: "fillBasicInfo",
                nextId: "summary",
                share: e.share
            }), new SYNO.SDS.C2FS.Share.Transform.SummaryStep({
                appWin: this,
                owner: this,
                module: e.module,
                itemId: "summary",
                nextId: null,
                share: e.share
            })],
            i = {
                title: this.helper.T("action", "transform_wizard"),
                steps: t,
                width: 820,
                height: 560,
                cls: "c2-create-wizard",
                listeners: {
                    beforeclose: this.onBeforeClose,
                    setServerInfo: this.setServerInfo,
                    recordFeasibilityCheck: this.recordFeasibilityCheck,
                    scope: this
                }
            };
        return Ext.apply(i, e), i
    },
    setAllStepSize: function() {
        this.getAllSteps().forEach(function(e) {
            e.setHeight(Math.max(this.height - 162, 162)), e.setWidth(Math.max(this.width - 80, 80))
        }, this)
    },
    setServerInfo: function(e) {
        this.serverInfo = e
    },
    getServerInfo: function() {
        return Object.assign({}, this.serverInfo)
    },
    recordFeasibilityCheck: function(e) {
        e && (e.soft || e.hard) || SYNO.Debug("Bad feasibility check: ", e), this.feasibilityCheck = e
    },
    getFeasibilityCheck: function() {
        return this.feasibilityCheck ? Object.assign({}, this.feasibilityCheck) : {}
    },
    getValues: function() {
        return this.getAllSteps().reduce(function(e, t) {
            return Ext.isFunction(t.getValues) && (e[t.itemId] = t.getValues()), e
        }, {})
    },
    onBeforeClose: function() {
        var e = this;
        return !this.stepStack.includes("encryptBucket") || !this.isNeedCloseWarnMsg || (this.findWindow().getMsgBox().confirm(this.helper.T("warn", "create_leave_title"), '<div class="c2-create-wizard"><p class="c2-warning-msg-content c2-warning-red">' + this.helper.T("warn", "create_leave_content") + "</p></div>", function(t) {
            "yes" === t && (e.isNeedCloseWarnMsg = !1, e.close())
        }, this, {
            yes: !0,
            no: !0
        }, {
            useMessageTitle: !0,
            hideBrElement: !0
        }), !1)
    },
    hasHistory: function() {
        return this.stepStack.includes("summary") ? 0 : this.stepStack.filter(function(e) {
            return "welcome" !== e && "encryptBucket" !== e
        }).length
    }
}), Ext.define("SYNO.SDS.C2FS.Application", {
    extend: "SYNO.SDS.AppInstance",
    onOpen: function(e) {
        this.sendWebAPIPromise({
            params: {},
            compound: {
                stopwhenerror: !1,
                params: [{
                    api: "SYNO.Core.Storage.Volume",
                    version: 1,
                    method: "list",
                    params: {
                        limit: -1,
                        offset: 0,
                        location: "" === _D("usbstation") ? "internal" : "external",
                        option: "include_cold_storage"
                    }
                }, {
                    api: "SYNO.C2FS.Share",
                    method: "list",
                    version: 1
                }]
            },
            scope: this
        }).then(function(e) {
            SYNO.Debug(e);
            var t = SYNO.API.Response.GetValByAPI(e, "SYNO.C2FS.Share", "list"),
                i = SYNO.API.Response.GetValByAPI(e, "SYNO.Core.Storage.Volume", "list");
            0 === Object.keys(t).length && 0 !== i.volumes.length ? SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                fn: "SYNO.SDS.AdminCenter.Share.Main",
                dlg: "create",
                type: "c2_share"
            }) : SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                fn: "SYNO.SDS.AdminCenter.Share.Main",
                c2share_name: Object.keys(e)[0]
            })
        }).catch(function(e) {
            SYNO.Debug(e), SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                fn: "SYNO.SDS.AdminCenter.Share.Main"
            })
        }), this.destroy()
    }
}), Ext.define("SYNO.SDS.C2FS.App.LaunchForDSMNotification", {
    extend: "SYNO.SDS.AppInstance",
    onOpen: function(e) {
        this.sendWebAPIPromise({
            api: "SYNO.C2FS.Share",
            method: "list",
            version: 1,
            scope: this
        }).then(function(e) {
            SYNO.SDS.AppLaunch("SYNO.SDS.AdminCenter.Application", {
                fn: "SYNO.SDS.AdminCenter.Share.Main",
                c2share_name: Object.keys(e)[0]
            })
        }), this.destroy()
    }
}), Ext.define("SYNO.SDS.C2FS.App.DownloadForDSMNotification", {
    extend: "SYNO.SDS.AppInstance",
    statics: {
        downloadTransformInfo: function(e) {
            "key" in e && "type" in e && "share_name" in e ? SYNO.SDS.Utils.IFrame.requestWebAPI({
                webapi: {
                    api: "SYNO.C2FS.Transform",
                    method: "export_invalid_files",
                    version: 1,
                    params: e
                },
                appWindow: !1
            }) : SYNO.Debug("Invalid parameter, param: ", e)
        }
    }
}), Ext.define("SYNO.SDS.C2FS.Share.Issue", {
    extend: "SYNO.SDS.ModalWindow",
    helper: SYNO.SDS.C2FS.Helper,
    constructor: function(e) {
        this.shareName = e.shareName, this.updateData = e.updateData, this.share = e.share, this.callParent([this.fillConfig(e)])
    },
    fillConfig: function(e) {
        this.store = this.createStore(), this.gridPanel = this.createGridPanel();
        var t = {
            title: String.format(this.helper.T("common", "share_issue"), this.shareName),
            layout: "fit",
            width: 820,
            height: 560,
            items: [this.gridPanel],
            listeners: {
                scope: this,
                afterrender: function() {
                    this.setStatusBusy({
                        text: this.helper.T("common", "msg_waiting")
                    }), this.filterStatus().then(this.loadNeedInfo.bind(this)).then(this.generateIssues.bind(this)).then(function(e) {
                        this.store.loadData(e), this.clearStatusBusy()
                    }.bind(this), function(e) {
                        this.clearStatusBusy(), SYNO.Debug("error: ", e)
                    }.bind(this))
                }
            },
            buttons: [{
                xtype: "syno_button",
                text: this.helper.T("common", "alt_close"),
                scope: this,
                handler: function() {
                    this.close()
                }
            }]
        };
        return Ext.apply(t, e), t
    },
    createStore: function() {
        return new Ext.data.JsonStore({
            autoDestroy: !0,
            fields: ["level", "levelClass", "event", "summary", "suggest", "suggestExtIdLink", "suggestPartNeedLink"]
        })
    },
    processExtIdClick: function() {
        var e = function(e) {
            Ext.get(e).on({
                scope: this,
                click: function() {
                    new SYNO.SDS.C2FS.Share.EditDialog({
                        owner: this,
                        module: this.owner.activePage.module,
                        shareName: this.shareName,
                        share: this.share
                    }).onOpen()
                }.bind(this)
            }, this)
        }.bind(this);
        this.extIdOfInThrottle && e(this.extIdOfInThrottle), this.extIdOfSpaceFull && e(this.extIdOfSpaceFull)
    },
    createGridPanel: function() {
        return new SYNO.ux.GridPanel({
            store: this.store,
            border: !1,
            enableHdMenu: !1,
            autoExpandColumn: !0,
            listeners: {
                scope: this,
                viewready: this.processExtIdClick
            },
            view: new SYNO.ux.FleXcroll.grid.GridView({
                listeners: {
                    scope: this,
                    refresh: this.processExtIdClick
                }
            }),
            colModel: new Ext.grid.ColumnModel({
                columns: [{
                    width: 30,
                    dataIndex: "level",
                    header: this.helper.T("common", "issue_level"),
                    renderer: function(e, t, i) {
                        return String.format('<span class="{0}">', i.get("levelClass")) + this.helper.toolTipRenderer(e, t, i) + "</span>"
                    }.bind(this)
                }, {
                    width: 75,
                    header: this.helper.T("common", "issue_event"),
                    dataIndex: "event",
                    renderer: function(e, t, i) {
                        return '<span style="white-space: normal; overflow-wrap: break-word;">' + this.helper.toolTipRenderer(e) + "</span>"
                    }.bind(this)
                }, {
                    header: this.helper.T("common", "issue_summary"),
                    dataIndex: "summary",
                    renderer: function(e, t, i) {
                        return '<span style="white-space: normal; overflow-wrap: break-word;">' + this.helper.toolTipRenderer(e) + "</span>"
                    }.bind(this)
                }, {
                    header: this.helper.T("common", "issue_suggest"),
                    dataIndex: "suggest",
                    renderer: function(e, t, i) {
                        var s = this.helper.toolTipRenderer(e);
                        if (i.get("suggestExtIdLink") && (s = '<a id="' + i.get("suggestExtIdLink") + '" class="link-font" style="cursor:pointer;">' + s + "</a>"), i.get("suggestPartNeedLink")) {
                            if (!e || "-" === e) return "-";
                            var r = e.replace(/{.}/g, ""),
                                n = Ext.util.Format.htmlEncode(r),
                                a = Ext.util.Format.htmlEncode(n);
                            s = String.format('<span ext:qtip="{0}">{1}</span>', a, String.format(e, '<a href="' + i.get("suggestPartNeedLink") + '" target="_blank">', "</a>"))
                        }
                        return s = '<span style="white-space: normal; overflow-wrap: break-word;">' + s + "</span>"
                    }.bind(this)
                }]
            })
        })
    },
    filterStatus: function() {
        var e = this;
        return new Promise(function(t) {
            var i = e.updateData.status.filter(function(e) {
                    return "in_write_throttle" === e
                }),
                s = e.updateData.status.filter(function(e) {
                    return SYNO.SDS.C2FS.Share.Utils.isWarningStatus(e)
                }),
                r = e.updateData.status.filter(function(e) {
                    return SYNO.SDS.C2FS.Share.Utils.isErrorStatus(e)
                }),
                n = e.updateData.status.filter(function(e) {
                    return SYNO.SDS.C2FS.Share.Utils.isNormalStatus(e)
                });
            r.length > 0 ? t(Array.from(new Set(r.concat(i)))) : s.length > 0 ? t(Array.from(new Set(s.concat(i)))) : n.length > 0 ? t(Array.from(new Set(n.concat(i)))) : t(i)
        })
    },
    loadNeedInfo: function(e) {
        return e.includes("insufficient_volume_free_space") ? new Promise(function(t) {
            return this.sendWebAPIPromise({
                api: "SYNO.Core.Storage.Volume",
                method: "list",
                params: {
                    limit: -1,
                    offset: 0,
                    location: "internal"
                },
                version: 1,
                scope: this
            }).then(function(i) {
                var s = i.volumes.find(function(e) {
                        return e.volume_path == this.share.get("vol_path")
                    }.bind(this)),
                    r = SYNO.SDS.C2FS.Share.Utils.idealLocalCacheGB({
                        free_mb: s.size_free_byte / 1024 / 1024,
                        total_mb: s.size_total_byte / 1024 / 1024
                    }, {
                        used_mb: this.updateData.cache_used_mb,
                        total_mb: this.updateData.local_cache_max_mb
                    });
                t([e, {
                    insufficient_volume_free_space: {
                        suggest_local_cache: r
                    }
                }])
            }.bind(this), function(i) {
                SYNO.Debug("error", i), t([e])
            })
        }.bind(this)) : new Promise(function(t) {
            t([e])
        })
    },
    generateIssues: function(e) {
        var t = e[0],
            i = [];
        return t.forEach(function(t) {
            switch (t) {
                case "no_config":
                    i.push({
                        level: this.helper.T("error", "error_error"),
                        levelClass: "red-status",
                        event: this.helper.T("issue", "event_no_config"),
                        summary: this.helper.T("issue", "summary_no_config"),
                        suggest: this.helper.T("issue", "suggest_no_config")
                    });
                    break;
                case "insufficient_volume_free_space":
                    if (!e[1].insufficient_volume_free_space) break;
                    i.push({
                        level: this.helper.T("error", "error_system_abnormal_warning"),
                        levelClass: "orange-status",
                        event: this.helper.T("issue", "event_insufficient_volume_free_space"),
                        summary: this.helper.T("issue", "summary_insufficient_volume_free_space"),
                        suggest: e[1].insufficient_volume_free_space.suggest_local_cache ? String.format(this.helper.T("issue", "suggest_insufficient_volume_free_space"), e[1].insufficient_volume_free_space.suggest_local_cache) : this.helper.T("issue", "suggest_insufficient_volume_free_space_without_local_cache")
                    });
                    break;
                case "in_throttle":
                    this.extIdOfInThrottle || (this.extIdOfInThrottle = Ext.id()), i.push({
                        level: this.helper.T("error", "error_system_abnormal_warning"),
                        levelClass: "orange-status",
                        event: this.helper.T("issue", "event_in_throttle"),
                        summary: this.helper.T("issue", "summary_in_throttle"),
                        suggest: String.format(this.helper.T("issue", "suggest_in_throttle"), SYNO.SDS.Utils.CapacityRender(2 * this.updateData.local_cache_max_mb)),
                        suggestExtIdLink: this.extIdOfInThrottle
                    });
                    break;
                case "slow_uploading":
                    var s = this.updateData.unsync_data_mb / this.updateData.sync_speed_mb_s;
                    i.push({
                        level: this.helper.T("error", "error_system_abnormal_warning"),
                        levelClass: "orange-status",
                        event: this.helper.T("issue", "event_slow_uploading"),
                        summary: String.format(this.helper.T("issue", "summary_slow_uploading"), this.helper.timeRender(s, "m")),
                        suggest: this.helper.T("issue", "suggest_slow_uploading"),
                        suggestPartNeedLink: "https://www.synology.com/company/contact_us"
                    });
                    break;
                case "space_full":
                    this.extIdOfSpaceFull || (this.extIdOfSpaceFull = Ext.id()), i.push({
                        level: this.helper.T("error", "error_error"),
                        levelClass: "red-status",
                        event: this.helper.T("issue", "event_space_full"),
                        summary: this.helper.T("issue", "summary_space_full"),
                        suggest: String.format(this.helper.T("issue", "suggest_space_full"), SYNO.SDS.Utils.CapacityRender(2 * this.updateData.local_cache_max_mb)),
                        suggestExtIdLink: this.extIdOfSpaceFull
                    });
                    break;
                case "disconnected":
                    i.push({
                        level: this.helper.T("error", "error_error"),
                        levelClass: "red-status",
                        event: this.helper.T("issue", "event_disconnected"),
                        summary: this.helper.T("issue", "summary_disconnected"),
                        suggest: this.helper.T("issue", "suggest_disconnected"),
                        suggestPartNeedLink: "https://www.synology.com/company/contact_us"
                    });
                    break;
                case "incompatible":
                    i.push({
                        level: this.helper.T("error", "error_error"),
                        levelClass: "red-status",
                        event: this.helper.T("issue", "event_version_incompatible"),
                        summary: this.helper.T("issue", "summary_version_incompatible"),
                        suggest: this.helper.T("issue", "suggest_version_incompatible")
                    });
                    break;
                case "unauth":
                    i.push({
                        level: this.helper.T("error", "error_error"),
                        levelClass: "red-status",
                        event: this.helper.T("issue", "event_unauth"),
                        summary: this.helper.T("issue", "summary_unauth"),
                        suggest: this.helper.T("issue", "suggest_unauth")
                    });
                    break;
                case "in_write_throttle":
                    i.push({
                        level: this.helper.T("common", "info"),
                        levelClass: "blue-status",
                        event: this.helper.T("issue", "event_in_write_throttle"),
                        summary: this.helper.T("issue", "summary_in_write_throttle"),
                        suggest: this.helper.T("issue", "suggest_in_write_throttle")
                    });
                    break;
                case "c2_space_full":
                    i.push({
                        level: this.helper.T("error", "error_error"),
                        levelClass: "red-status",
                        event: this.helper.T("issue", "event_c2_space_full"),
                        summary: this.helper.T("issue", "summary_c2_space_full"),
                        suggest: this.helper.T("issue", "suggest_c2_space_full")
                    })
            }
        }.bind(this)), i
    }
});
