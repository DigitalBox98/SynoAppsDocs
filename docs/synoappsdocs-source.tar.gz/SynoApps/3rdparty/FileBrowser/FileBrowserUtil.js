/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.webfm.utils");

function _WFT(c, a) {
    try {
        if (window.SYNO_FileStation_Strings) {
            return window.SYNO_FileStation_Strings[c][a]
        } else {
            return _TT("SYNO.SDS.App.FileStation3.Instance", c, a) || _T(c, a)
        }
    } catch (b) {
        SYNO.Debug.error(b);
        return ""
    }
}
SYNO.webfm.Cfg = {};
Ext.apply(SYNO.webfm.Cfg, {
    timeout: 600000
});
Ext.apply(SYNO.webfm.utils, {
    ThumbSize: {
        SMALL: "S",
        MEDIUM: "M",
        LARGE: "L"
    }
});
SYNO.webfm.VFS = {};
Ext.apply(SYNO.webfm.VFS, {
    SupportChmodList: ["ftp", "sftp", "ftps"],
    isVFSPath: function(a) {
        if (!a) {
            return false
        }
        if ("/" !== a.charAt(0) && -1 != a.indexOf("://")) {
            return true
        }
        return false
    },
    isGDrivePath: function(a) {
        if (!this.isVFSPath(a)) {
            return false
        }
        if (0 !== a.indexOf("google://")) {
            return false
        }
        return true
    },
    isGDriveRootPath: function(a) {
        if (!this.isGDrivePath(a)) {
            return false
        }
        return -1 === a.indexOf("/", String("google://").length)
    },
    isGDriveDefaultFolder: function(c) {
        if (!this.isGDrivePath(c)) {
            return false
        }
        var b = c.substring(String("google://").length);
        var a = b.split("/", 3);
        return 2 === a.length
    },
    isGDriveStarsPath: function(c) {
        if (!this.isGDrivePath(c)) {
            return false
        }
        var b = c.substring(String("google://").length);
        var a = b.split("/", 3);
        return 2 === a.length && "Starred" === a[1]
    },
    isGDriveStarsFirstLevelPath: function(c) {
        if (!this.isGDrivePath(c)) {
            return false
        }
        var b = c.substring(String("google://").length);
        var a = b.split("/", 4);
        return 3 === a.length && "Starred" === a[1]
    },
    isOneDrivePath: function(a) {
        if (!this.isVFSPath(a)) {
            return false
        }
        if (0 !== a.indexOf("onedrive://")) {
            return false
        }
        return true
    },
    isSharingPath: function(a) {
        if (!this.isVFSPath(a)) {
            return false
        }
        if (0 !== a.indexOf("sharing://")) {
            return false
        }
        return true
    },
    getBaseURI: function(c) {
        if (!SYNO.webfm.VFS.isVFSPath(c)) {
            return ""
        }
        var a = c.indexOf("://");
        if (-1 === a) {
            return ""
        }
        var b = c.indexOf("/", a + 3);
        if (-1 === b) {
            return c
        }
        return c.substr(0, b)
    },
    isRootFolder: function(b) {
        if (!SYNO.webfm.VFS.isVFSPath(b)) {
            return false
        }
        var a = b.indexOf("://");
        if (-1 === a) {
            return false
        }
        a = b.indexOf("/", a + 3);
        if (-1 === a) {
            return true
        }
        return false
    },
    getSchemaFromPath: function(b) {
        if (!SYNO.webfm.VFS.isVFSPath(b)) {
            return ""
        }
        var a = b.indexOf("://");
        if (-1 === a) {
            return ""
        }
        return b.substr(0, a)
    }
});
SYNO.webfm.SmartDDMVCPMgr = {};
Ext.apply(SYNO.webfm.SmartDDMVCPMgr, {
    filename: "",
    blCtrl: false,
    blShift: false,
    blDisableUpate: false,
    blHotkey: false,
    blSrcReadOnly: false,
    operation: "mvcp",
    action: "move",
    defaultAction: "move",
    ghost: null,
    proxy: null,
    sourceType: null,
    onAction: function(i, c, a) {
        var f = SYNO.webfm.SmartDDMVCPMgr;
        var d = a.getXY();
        var g = (SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "isfirstdd") === false) ? false : true;
        var b = SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enablesmartmvcp");
        var h = Ext.isEmpty(b);
        if (h || g) {
            var e = new SYNO.FileStation.DragDropHintDialog({
                owner: c.owner
            });
            e.on("onAskDone", function(j) {
                f.doAction(i, c, d, j)
            });
            e.show().center()
        } else {
            f.doAction(i, c, d, f.isEnable())
        }
    },
    doAction: function(e, b, a, d) {
        var c = SYNO.webfm.SmartDDMVCPMgr;
        if (d) {
            b.FileAction.onBeforeSmartDDMVCP(b.ddParams.src, e.action, b.ddParams.target, b.ddParams);
            c.updateHotkeyAction("keyup")
        } else {
            if (!b.onCheckVFSAction("copy", b.ddParams.src, b.ddParams.target)) {
                e.getComponent("copy_skip").disable();
                e.getComponent("copy_overwrite").disable()
            }
            if (!b.onCheckVFSAction("move", b.ddParams.src, b.ddParams.target)) {
                e.getComponent("move_skip").disable();
                e.getComponent("move_overwrite").disable()
            }
            e.showAt(a)
        }
    },
    initDragData: function(a, c) {
        var b = SYNO.webfm.SmartDDMVCPMgr;
        b.blSrcReadOnly = false;
        if (!b.isEnable() || !Ext.isDefined(c) || 0 === c.length) {
            return
        }
        if (!a.onCheckPrivilege("move", c, false, false)) {
            b.blSrcReadOnly = true
        }
        b.sourceType = b.getSourceTypeByPath(a, c[0].get("path"))
    },
    setDragDropData: function(b, a, c, e) {
        var d = SYNO.webfm.SmartDDMVCPMgr;
        d.filename = b;
        d.operation = a;
        d.proxy = c;
        d.ghost = c.getGhost()
    },
    bindHotKey: function(b) {
        var a = SYNO.webfm.SmartDDMVCPMgr;
        b.mon(b.getEl(), "keydown", a.updateHotkey, a);
        b.mon(b.getEl(), "keyup", a.updateHotkey, a)
    },
    focus: function(a, b) {
        if (b.grid) {
            a.enableHotKeyByFocusGrid(b.grid)
        } else {
            if (b.from) {
                a.enableHotKeyByFocusDataView(b.from)
            } else {
                a.getEl().focus()
            }
        }
    },
    disableUpateDDText: function(a) {
        var b = SYNO.webfm.SmartDDMVCPMgr;
        b.blDisableUpadte = a
    },
    isEnable: function() {
        var a = SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "enablesmartmvcp");
        return a
    },
    onDragOver: function(c) {
        var d = c.browserEvent.ctrlKey;
        var a = c.browserEvent.shiftKey;
        var b = SYNO.webfm.SmartDDMVCPMgr;
        if (!d && !a) {
            b.action = b.defaultAction;
            b.blHotkey = false
        }
        if (d && b.action == "move") {
            b.blHotkey = true;
            b.action = "copy"
        }
        if (a && b.action == "copy") {
            b.blHotkey = true;
            b.action = "move"
        }
        b.updateDDText()
    },
    updateHotkey: function(b) {
        var a = SYNO.webfm.SmartDDMVCPMgr;
        if (!a.isEnable() || !b || ("keydown" === b.type && !b.ctrlKey && !b.shiftKey) || ("keyup" === b.type && (b.ctrlKey || b.shiftKey))) {
            return
        }
        a.blCtrl = b.ctrlKey;
        a.blShift = b.shiftKey;
        a.updateHotkeyAction(b.type);
        a.updateDDText()
    },
    updateDefaultAction: function(b, a, e) {
        var d = SYNO.webfm.SmartDDMVCPMgr;
        var c = (d.blSrcReadOnly) ? "copy" : "move";
        if (a || e || (b && (d.sourceType !== b))) {
            c = "copy"
        }
        d.defaultAction = c
    },
    updateHotkeyAction: function(b) {
        var a = SYNO.webfm.SmartDDMVCPMgr;
        if (!a.blHotkey) {
            a.action = a.defaultAction
        }
        if ("copy" === a.action && "keydown" === b && a.blShift) {
            a.blHotkey = true;
            a.action = "move"
        } else {
            if ("move" === a.action && "keydown" === b && a.blCtrl) {
                a.blHotkey = true;
                a.action = "copy"
            } else {
                if ("keyup" === b) {
                    a.blHotkey = false;
                    a.action = a.defaultAction
                }
            }
        }
    },
    updateDDText: function() {
        var a = SYNO.webfm.SmartDDMVCPMgr;
        if (!a.blDisableUpadte && a.ghost && a.proxy && a.proxy.dropNotAllowed !== a.proxy.dropStatus) {
            a.ghost.update(String.format(a.getDDText(), Ext.util.Format.htmlEncode(a.filename)))
        }
    },
    getAction: function() {
        var a = SYNO.webfm.SmartDDMVCPMgr;
        var b = (a.blHotkey) ? a.action : a.defaultAction;
        return ("upload" === a.operation) ? "copy" : b
    },
    getDDText: function(c) {
        var a = SYNO.webfm.SmartDDMVCPMgr;
        var b = (a.blHotkey) ? a.action : a.defaultAction;
        var d = "";
        if (c) {
            d = _WFT("filetable", "filetable_copy_to") + " {0}";
            return d
        }
        if ("upload" === a.operation) {
            d = _WFT("filetable", "upload_ddtext")
        } else {
            if ("copy" === b) {
                if ("download" === a.operation) {
                    d = _WFT("filetable", "filetable_download") + " " + _WFT("filetable", "filetable_copy_to") + " {0}"
                } else {
                    d = _WFT("filetable", "filetable_copy_to") + " {0}"
                }
            } else {
                if ("move" === b) {
                    if ("download" === a.operation) {
                        d = _WFT("filetable", "filetable_download") + " " + _WFT("filetable", "filetable_move_to") + " {0}"
                    } else {
                        d = _WFT("filetable", "filetable_move_to") + " {0}"
                    }
                }
            }
        }
        return d
    },
    getSourceTypeByPath: function(b, f, h) {
        var a = 1,
            e;
        var g = (f || b.getCurrentDir()) + "/";
        var d = h || b.getCurrentSource();
        var c;
        if (SYNO.webfm.utils.isLocalSource(d)) {
            return d
        }
        if (SYNO.webfm.VFS.isVFSPath(g)) {
            return SYNO.webfm.utils.source.remotevfs
        }
        while (-1 !== (a = g.indexOf("/", a))) {
            e = g.substr(0, a);
            c = b.dirTree.getNodeById(d + e);
            if (c && c.attributes && ((c.attributes.type === SYNO.webfm.utils.source.remotev) || (c.attributes.mountType === "iso"))) {
                return SYNO.webfm.utils.source.remotev
            } else {
                if (c && c.attributes && ((c.attributes.type === SYNO.webfm.utils.source.remoter) || (c.attributes.mountType == "remote"))) {
                    return SYNO.webfm.utils.source.remoter
                }
            }
            a++
        }
        return d
    }
});
Ext.apply(SYNO.webfm.utils, {
    hotKey: "hotKey",
    source: {
        local: "local",
        localh: "localh",
        remote: "remote",
        remotes: "remotes",
        remotev: "remotev",
        remoter: "remoter",
        remotefav: "remotefav",
        remotevfs: "remotevfs"
    },
    snapshotTimeRenderer: function(i) {
        var h = /GMT\-(\d+)\.(\d+)\.(\d+)\-(\d+)\.(\d+)\.(\d+)/,
            a = /GMT(\+|\-)(\d+)\-(\d+)\.(\d+)\.(\d+)\-(\d+)\.(\d+)\.(\d+)/,
            b = new Date(),
            g, c, d, e, f;
        f = h.exec(i) || a.exec(i);
        if (!f || f.length < 7) {
            return i
        }
        g = (f.length === 7) ? 1 : 3;
        b.setUTCFullYear(f[g++]);
        b.setUTCMonth(parseInt(f[g++], 10) - 1);
        b.setUTCDate(f[g++]);
        b.setUTCHours(f[g++]);
        b.setUTCMinutes(f[g++]);
        b.setUTCSeconds(f[g++]);
        if (f.length > 7) {
            c = f[1] === "+" ? -1 : 1;
            d = parseInt(f[2].substr(0, 2), 10);
            e = f[2].length > 2 ? parseInt(f[2].substr(2), 10) : 0;
            b = b.add(Date.HOUR, c * d);
            b = b.add(Date.MINUTE, c * e)
        }
        return SYNO.webfm.utils.DateTimeFormatter(b, {
            type: "datetimesec"
        })
    },
    isRemoteSource: function(a) {
        var b = SYNO.webfm.utils.source;
        return (a && a.substr(0, 6) === b.remote && a !== b.remotes)
    },
    isLocalSource: function(a) {
        var b = SYNO.webfm.utils.source;
        return (a && a.substr(0, 5) === b.local)
    },
    isFavSource: function(a) {
        var b = SYNO.webfm.utils.source;
        return (a.substr(0, 9) === b.remotefav)
    },
    isSharingUpload: function() {
        return !Ext.isEmpty(_S("sharing_id"))
    },
    isSupportFileSystem: function() {
        if (window.requestFileSysteme || window.webkitRequestFileSystem || window.mozRequestFileSystem) {
            return true
        }
        return false
    },
    isSupportMultiDownload: function() {
        if (SYNO.webfm.utils.isSupportFileSystem() && 0 === AppletProgram.blJavaPermission && !_S("standalone") && !Ext.isMac) {
            return true
        }
        return false
    },
    getWebAPIErrStr: function(a, c, b) {
        if (!c) {
            return _WFT("error", "error_error_system")
        }
        switch (c.code) {
            case 400:
                return _WFT("error", "error_error_system");
            case 401:
                return _WFT("error", "error_error_system");
            case 402:
                return _WFT("error", "error_system_busy");
            case 403:
                return _WFT("error", "error_invalid_user_group");
            case 404:
                return _WFT("error", "error_invalid_user_group");
            case 405:
                return _WFT("error", "error_invalid_user_group");
            case 406:
                return _WFT("error", "error_testjoin");
            case 407:
                return _WFT("error", "error_privilege_not_enough");
            case 408:
                return _WFT("error", "error_no_path");
            case 409:
                return _WFT("error", "error_privilege_not_enough");
            case 410:
                return _WFT("error", "conn_rv_fail");
            case 411:
                return _WFT("error", "error_fs_ro");
            case 412:
                return _WFT("error", "error_long_path");
            case 413:
                return _WFT("error", "error_encryption_long_path");
            case 414:
                return _WFT("error", "error_file_exist");
            case 415:
                return _WFT("error", "error_quota_not_enough");
            case 416:
                return _WFT("error", "error_space_not_enough");
            case 417:
                return _WFT("error", "error_io");
            case 418:
                return _WFT("error", "error_reserved_name");
            case 419:
                return _WFT("error", "error_fat_reserved_name");
            case 420:
                return _WFT("error", "error_error_system");
            case 421:
                return _WFT("error", "error_folder_busy");
            case 422:
                return _WFT("error", "not_support");
            case 423:
                return _WFT("error", "volume_no_volumes");
            case 424:
                return _WFT("error", "umount_fail");
            case 425:
                return _WFT("error", "disconnect_fail");
            case 426:
                return _WFT("error", "mount_iso_fail");
            case 427:
                return _WFT("property", "error_save_property");
            case 428:
                return _WFT("error", "error_mp_external");
            case 429:
                return _WFT("error", "error_mp_encshare");
            case 430:
                return _WFT("error", "error_mp_mp");
            case 431:
                return _WFT("error", "mount_fail_reach_limit");
            case 432:
                return _WFT("mount", "err_user_home");
            case 433:
                return _WFT("mount", "err_cloud_station");
            case 434:
                return _WFT("error", "error_mp_share");
            case 435:
                return _WFT("mount", "invalid_local_host");
            case 436:
                return _WFT("mount", "bad_remote_folder");
            case 437:
                return _WFT("error", "error_mp_nfs");
            case 438:
                return _WFT("mount", "err_permission_denied");
            case 439:
                return _WFT("error", "mount_remote_fail_reach_limit");
            case 440:
                return _WFT("mount", "err_no_such_device");
            case 441:
                return _WFT("error", "mount_point_not_empty");
            case 442:
                return _WFT("error", "error_dest_no_path");
            case 443:
                return _WFT("error", "error_acl_volume_not_support");
            case 444:
                return _WFT("error", "error_fat_privilege");
            case 445:
                return _WFT("error", "error_remote_privilege");
            case 446:
                return _WFT("error", "error_no_shared_folder");
            case 447:
                return String.format(_WFT("acl_editor", "error_privilage_mode"), c.errno.arg);
            case 448:
                return _WFT("property", "error_invalid_domain_user");
            case 449:
                return _WFT("property", "error_invalid_domain_group");
            case 450:
                return _WFT("mount", "config_remote_warning");
            case 451:
                return _WFT("error", "nfs_conn_rv_fail");
            case 452:
                return _WFT("error", "error_share_quota_not_enough");
            case 453:
                return _WFT("error", "error_cifs_smb1_disabled");
            case 454:
                return _WFT("error", "error_c2share_quota_not_enough");
            case 599:
                return "";
            case 600:
                return _WFT("search", "no_search_cache");
            case 800:
                return String.format(_WFT("favorite", "same_favorite_path"), Ext.util.Format.htmlEncode(c.errors[0].path), Ext.util.Format.htmlEncode(c.errors[0].name));
            case 801:
                return String.format(_WFT("favorite", "same_favorite_name"), Ext.util.Format.htmlEncode(c.errors[0].name));
            case 802:
                return _WFT("favorite", "over_limit");
            case 900:
                return _WFT("error", "delete_error_rmdir");
            case 1004:
                return _WFT("error", "error_overwrite_fail");
            case 1005:
                return _WFT("error", "error_select_conflict");
            case 1006:
                return _WFT("error", "mvcp_filename_illegal");
            case 1007:
                return _WFT("error", "mvcp_file_too_big");
            case 1100:
                return _WFT("error", "error_error_system");
            case 1101:
                return _WFT("error", "error_too_many_folder");
            case 1102:
                return SYNO.webfm.utils.getExceedMaxFolderMsg();
            case 1200:
                return _WFT("error", "error_error_system");
            case 1300:
                return _WFT("error", "error_error_system");
            case 1301:
                return _WFT("compress", "compress_error_long_name");
            case 1400:
                return _WFT("error", "error_error_system");
            case 1401:
                return _WFT("error", "error_invalid_archive");
            case 1402:
                return _WFT("error", "error_invalid_archive_data");
            case 1403:
                return _WFT("error", "extract_passwd_missing");
            case 1404:
                return _WFT("error", "error_error_system");
            case 1405:
                return _WFT("error", "error_error_system");
            case 1800:
                return _WFT("upload", "upload_error_data");
            case 1801:
                return _WFT("upload", "upload_error_timeout");
            case 1802:
                return _WFT("upload", "upload_nofile");
            case 1803:
                return _WFT("connections", "kick_connection");
            case 1804:
                return _WFT("error", "mvcp_file_too_big");
            case 1805:
                return _WFT("error", "error_select_conflict");
            case 1806:
                return _WFT("error", "upload_add_vfs_queue");
            case 1807:
                return _WFT("error", "error_io");
            case 1808:
                return _WFT("error", "upload_zero_size_file_error");
            case 1809:
                return _WFT("error", "error_file_exist");
            case 1810:
                return _WFT("upload", "upload_nofile");
            case 1811:
                return _WFT("error", "error_no_path");
            case 1812:
                return _WFT("upload", "upload_exceed_maximum_filesize");
            case 1813:
                return _WFT("extract", "extract_file_exist");
            case 1900:
                return _WFT("error", "download_add_vfs_queue");
            case 2001:
                return _WFT("error", "over_account_limit");
            case 2002:
                return _WFT("error", "unknown_db_error");
            case 2100:
                return _WFT("error", "vfs_no_such_server");
            case 2101:
                return _WFT("error", "vfs_duplicated_connection");
            case 2102:
                return _WFT("error", "vfs_authentication_failed");
            case 2103:
                return _WFT("error", "vfs_host_unreachable");
            case 2104:
                return _WFT("error", "vfs_connection_refused");
            case 2105:
                return _WFT("error", "vfs_read_config_failed");
            case 2106:
                return _WFT("error", "vfs_write_config_failed");
            case 2107:
                return _WFT("error", "vfs_wrong_fingerprint");
            case 2108:
                return _WFT("error", "vfs_identity_wrong");
            case 2109:
                return _WFT("error", "vfs_conn_rv_fail");
            case 2110:
                return _WFT("error", "vfs_reach_max_server_per_protocol");
            case 2111:
                return _WFT("error", "vfs_proxy_authentication_failed");
            case 2112:
                return _WFT("error", "vfs_err_ca_wrong");
            case 2113:
                return _WFT("error", "vfs_duplicated_profile");
            case 2114:
                return _WFT("error", "vfs_root_ioerror");
            case 2115:
                return _WFT("error", "vfs_token_expired");
            case 2116:
                return _WFT("error", "vfs_filesize_too_large");
            case 2117:
                return _T("ddsm", "unsupport_on_non_privileged_mode");
            case 2118:
                return _T("login", "error_maxtried");
            case 2119:
                return _WFT("error", "mvcp_filename_illegal");
            default:
                return _WFT("error", "error_error_system")
        }
    },
    getWebAPIErr: function(h, d, b) {
        var j, f, a, e, g, c, k;
        if (!h) {
            if (!d) {
                return _WFT("error", "error_error_system")
            } else {
                if (d && d.code < 400) {
                    return SYNO.API.CheckResponse(h, d, b)
                } else {
                    j = d.errors;
                    if (d.code !== 800 && d.code !== 801 && j && Ext.isArray(j) && j && 0 < j.length) {
                        c = (j.length > 15) ? 15 : j.length;
                        g = _WFT("error", "error_files");
                        for (f = 0; f < c; f++) {
                            e = j[f];
                            if (!e.path) {
                                continue
                            }
                            k = e.path;
                            if (k.length > 52) {
                                k = '<span ext:qtip="' + Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(e.path)) + '">' + Ext.util.Format.htmlEncode(k.substr(0, 25) + " ... " + k.substr(k.length - 25)) + "</span>"
                            } else {
                                k = Ext.util.Format.htmlEncode(k)
                            }
                            g += "<br>" + k;
                            a = SYNO.webfm.utils.getWebAPIErr(h, e, b);
                            if (a) {
                                g += "&nbsp;(" + a + ")"
                            }
                        }
                        if (c < j.length) {
                            g += "<br>..."
                        }
                    }
                    if (!g) {
                        g = SYNO.webfm.utils.getWebAPIErrStr(h, d, b)
                    }
                    return g
                }
            }
        }
    },
    getExceedMaxFolderMsg: function() {
        var a = [_WFT("error", "error_exceed_folder_limit")];
        if (_S("is_admin")) {
            a.push('<a class="pathlink" tabIndex="0"> ');
            a.push(_WFT("common", "goto_setting"));
            a.push("</a>")
        }
        return a.join("")
    },
    isCompressFile: function(a, d) {
        d = d.toLowerCase();
        if (-1 !== SYNO.webfm.utils.archive_type.indexOf(d)) {
            return true
        }
        var b = a.split("."),
            c;
        if (2 < b.length) {
            c = b[b.length - 2].toLowerCase();
            if (-1 !== SYNO.webfm.utils.archive_type.indexOf(c) && (d === "001" || d === "000")) {
                return true
            }
        }
        return false
    },
    getPathSeparator: function(b) {
        var a = b ? SYNO.webfm.utils.isLocalSource(b) : false;
        return (a && Ext.isWindows) ? "\\" : "/"
    },
    checkFileLen: function(b, c) {
        var a = window.unescape(encodeURIComponent(b)).length;
        if (c) {
            a += c
        }
        return (a <= 255)
    },
    getLangText: function(a) {
        return _WFT(a.section, a.key)
    },
    isNameReserved: function(b) {
        var a = b.toLowerCase();
        return ("@eaDir" == a)
    },
    isNameCharIllegal: function(a) {
        if (-1 != a.indexOf("/")) {
            return true
        } else {
            return false
        }
    },
    ParseArrToFileName: function(d, c, e) {
        var a = e ? e : "/";
        var g = [],
            f, b;
        for (b = 0; b < d.length; b++) {
            g.push(SYNO.webfm.utils.parseFullPathToFileName(d[b], a))
        }
        f = g.join(", ");
        return f
    },
    ParseArr: function(c, b) {
        var d = [],
            a;
        for (a = 0; a < c.length; a++) {
            d.push(c[a].get(b))
        }
        return d
    },
    ParsePairArr: function(d, c, b) {
        var e = [],
            a;
        for (a = 0; a < d.length; a++) {
            e.push({
                file: d[a].get(c),
                path: b[a]
            })
        }
        return e
    },
    ParseArrToJSON: function(c, b) {
        var d = [],
            a;
        for (a = 0; a < c.length; a++) {
            d.push(c[a].get(b))
        }
        return Ext.util.JSON.encode(d)
    },
    isConflictTargetPath: function(e, b, d) {
        var a = d ? d : "/";
        var c = "";
        var g = "";
        if (b.length < e.length) {
            var f = e.lastIndexOf(a);
            if (d === "\\" && e[f - 1] === ":") {
                f++
            }
            g = e.substring(f);
            return (b + g == e)
        } else {
            if (b.length == e.length) {
                return (b == e)
            } else {
                c = b.substring(0, e.length);
                g = b.substring(e.length);
                return ((c == e) && (a == g.charAt(0)))
            }
        }
    },
    isSubNotEqualPath: function(e, b, d) {
        var a = d ? d : "/";
        var c = "";
        var f = "";
        if (b.length <= e.length) {
            return false
        } else {
            c = b.substring(0, e.length);
            f = b.substring(e.length);
            return ((c == e) && (a == f.charAt(0)))
        }
    },
    getParentDirArr: function(g, e) {
        var b = e ? e : "/";
        var a = [];
        var h = -1;
        var f = "";
        if (!(g instanceof Array)) {
            h = g.lastIndexOf(b);
            f = g.substring(0, h);
            if ("\\" === b && -1 === f.indexOf(b)) {
                f += "\\"
            }
            a.push(f);
            return a
        }
        var d = g[0].data || g[0];
        a = this.getParentDirArr(d.file_id, b);
        for (var c = 0; c < g.length; c++) {
            d = g[c].data || g[c];
            if (!(d.isdir)) {
                continue
            }
            f = d.file_id;
            h = f.lastIndexOf(b);
            f = f.substring(0, h);
            if ("\\" === b && -1 === f.indexOf(b)) {
                f += "\\"
            }
            if (!this.strElementInArray(f, a)) {
                a.push(f)
            }
        }
        return a
    },
    strElementInArray: function(c, a) {
        for (var b = 0; b < a.length; b++) {
            if (c == a[b]) {
                return true
            }
        }
        return false
    },
    replaceDLNameSpecChars: function(a) {
        var b = Ext.isWindows ? /[\/\\\:\?\>\<\*\"\|]/g : /[\/\\\:]/g;
        return a.replace(b, "-")
    },
    checkIfNeedRedirect: function(c, a, b) {
        if ((b && "login" == c) || ("error" == c && "error_testjoin" == a)) {
            if ("true" == _S("customized")) {
                window.location = "webUI/logout.cgi"
            } else {
                window.location = "/index.cgi"
            }
            alert(_WFT(c, a));
            return true
        }
        return false
    },
    parseFullPathToFileName: function(d, c) {
        var b = c ? c : "/";
        var a = "";
        var e = d.lastIndexOf(b);
        if (-1 == e) {
            e = d.lastIndexOf(b === "\\" ? "/" : "\\")
        }
        a = d.substring(e + 1);
        return a
    },
    isParentDir: function(d, c) {
        if (!d || !c) {
            return false
        }
        var b = d.lastIndexOf("/");
        if (-1 === b || 0 === b) {
            return false
        }
        var a = d.substring(0, b);
        return (a == c)
    },
    isWinParentDir: function(d, c) {
        if (!d || !c) {
            return false
        }
        var b = d.lastIndexOf("\\");
        if (b < 2) {
            return false
        }
        var a;
        if (d.length != 3) {
            a = d.substring(0, b + 1)
        } else {
            a = d
        }
        return (a == c)
    },
    utfencode: function(b) {
        b = b.replace(/\r\n/g, "\n");
        var a = "";
        for (var e = 0; e < b.length; e++) {
            var d = b.charCodeAt(e);
            if (d < 128) {
                a += String.fromCharCode(d)
            } else {
                if ((d > 127) && (d < 2048)) {
                    a += String.fromCharCode((d >> 6) | 192);
                    a += String.fromCharCode((d & 63) | 128)
                } else {
                    a += String.fromCharCode((d >> 12) | 224);
                    a += String.fromCharCode(((d >> 6) & 63) | 128);
                    a += String.fromCharCode((d & 63) | 128)
                }
            }
        }
        return a
    },
    bin2hex: function(d) {
        d = SYNO.webfm.utils.utfencode(d);
        var c, e = 0,
            b = [];
        d += "";
        e = d.length;
        for (c = 0; c < e; c++) {
            b[c] = d.charCodeAt(c).toString(16).replace(/^([\da-f])$/, "0$1")
        }
        return b.join("")
    },
    checkPointInBox: function(c, b, a) {
        if (b < c.x || a < c.y) {
            return false
        }
        return ((c.right > b) && (c.bottom > a))
    },
    getBaseName: function(e, d) {
        var c = d ? d : "/";
        if (!Ext.isDefined(e)) {
            return ""
        }
        var b = "";
        var a = e.lastIndexOf(c);
        if (a != -1) {
            b = e.substr(a + 1)
        }
        return b
    },
    getExt: function(b) {
        var c = SYNO.webfm.utils.getBaseName(b);
        b = !c ? b : c;
        var a = b.lastIndexOf(".");
        if (-1 === a) {
            return ""
        }
        return b.substr(a + 1).toLowerCase()
    },
    getFullSize: function(a) {
        var b = 0;
        b = parseFloat(a);
        if (!Ext.isString(a)) {
            return b
        }
        if (a.indexOf("KB") > 0) {
            b *= 1024
        } else {
            if (a.indexOf("MB") > 0) {
                b *= 1048576
            } else {
                if (a.indexOf("GB") > 0) {
                    b *= 1073741824
                }
            }
        }
        return b
    },
    doesIncludeMountPoint: function(a) {
        if (a) {
            Ext.each(a, function(b) {
                if (b.data && "" !== b.data.mountType) {
                    return true
                }
            })
        }
        return false
    },
    getSupportedLanguage: function() {
        var a = SYNO.SDS.Utils.getSupportedLanguageCodepage();
        a.push(["utf8", _WFT("codepage", "unicode")]);
        return a
    },
    transNodeToRecs: function(b) {
        var k = b.attributes.path || "";
        var g = b.attributes.real_path;
        var a = b.attributes.name;
        var f = b.attributes.uid;
        var e = b.attributes.gid;
        var i = b.attributes.right;
        var j = b.attributes.ftpright;
        var c = b.attributes.isMountPoint;
        var d = b.attributes.mountType;
        var h = [];
        h[0] = new Ext.data.Record({
            uid: f,
            gid: e,
            isdir: true,
            ftpright: j,
            fileprivilege: i,
            file_id: k,
            real_path: g,
            isMountPoint: c,
            mountType: d,
            filename: a,
            size: 0,
            type: ""
        });
        return h
    },
    isShareByPath: function(a) {
        if (-1 === (a.indexOf("/", 1))) {
            return true
        }
        return false
    },
    getRemoteTreeParams: function(c, b, a) {
        delete c.baseParams.folder_path;
        delete c.baseParams.type;
        if (a) {
            c.api = "SYNO.FileStation.VirtualFolder";
            c.method = "list";
            c.version = 2;
            c.dataroot = ["data", "folders"];
            c.baseParams.type = a
        } else {
            if (b.id === "fm_fav_root") {
                c.api = "SYNO.FileStation.Favorite";
                c.method = "list";
                c.version = 2;
                c.dataroot = ["data", "favorites"];
                c.baseParams.enum_cluster = true
            } else {
                if (b.id === "fm_root") {
                    c.api = "SYNO.FileStation.List";
                    c.method = "list_share";
                    c.version = 2;
                    c.dataroot = ["data", "shares"]
                } else {
                    if (b.id === "fm_rf_root") {
                        c.api = "SYNO.FileStation.VirtualFolder";
                        c.method = "list";
                        c.version = 2;
                        c.dataroot = ["data", "folders"];
                        c.baseParams.type = ["cifs", "nfs"]
                    } else {
                        if (b.id === "fm_vd_root") {
                            c.api = "SYNO.FileStation.VirtualFolder";
                            c.method = "list";
                            c.version = 2;
                            c.dataroot = ["data", "folders"];
                            c.baseParams.type = "iso"
                        } else {
                            c.api = "SYNO.FileStation.List";
                            c.method = "list";
                            c.version = 2;
                            c.dataroot = ["data", "files"];
                            c.baseParams.folder_path = b.attributes.path
                        }
                    }
                }
            }
        }
    },
    parseRemoteTreeNode: function(b, f) {
        if (!f) {
            return
        }
        var a = b.additional;
        b.leaf = false;
        if (f.id === "fm_root") {
            b.draggable = false
        } else {
            b.draggable = true
        }
        var e = "";
        if (f.attributes.type) {
            e = f.attributes.type
        }
        switch (f.id) {
            case "fm_fav_root":
                e = SYNO.webfm.utils.source.remotefav + b.name;
                break;
            case "fm_vd_root":
                e = SYNO.webfm.utils.source.remotev;
                break;
            case "fm_rf_root":
                e = SYNO.webfm.utils.source.remoter;
                b.draggable = false;
                break;
            default:
                if (f.parentNode.id === "fm_top_root") {
                    e = SYNO.webfm.utils.source.remote
                }
                break
        }
        b.id = e + b.path;
        b.type = e;
        b.text = b.name;
        b.qtip = b.text;
        if (b.children && b.children.files) {
            b.children = b.children.files
        }
        if (!a) {
            return b
        }
        if (a.volume) {
            b.qtip = String.format("{0} @{1}", b.qtip, a.volume)
        }
        if (a.volume_status) {
            var d = a.volume_status;
            if (0 <= d.totalspace && 0 <= d.freespace) {
                b.qtip = String.format("{0}, {1}", b.qtip, String.format(_T("filetable", "space_size"), Ext.util.Format.fileSize(d.freespace), Ext.util.Format.fileSize(d.totalspace)))
            }
        }
        b.real_path = a.real_path;
        b.isMountPoint = !Ext.isEmpty(a.mount_point_type);
        b.mountType = a.mount_point_type;
        if (a.time) {
            b.mt = a.time.mtime;
            b.at = a.time.atime;
            b.ct = a.time.crtime
        }
        if (a.perm) {
            if (a.perm.posix) {
                b.privilege = a.perm.posix
            }
            if (a.perm.acl) {
                var c = a.perm.acl,
                    g;
                if (c.append) {
                    g |= SYNO.webfm.utils.Mode_Append
                }
                if (c.del) {
                    g |= SYNO.webfm.utils.Mode_Del
                }
                if (c.exec) {
                    g |= SYNO.webfm.utils.Mode_Exec
                }
                if (c.read) {
                    g |= SYNO.webfm.utils.Mode_Read
                }
                if (c.write) {
                    g |= SYNO.webfm.utils.Mode_Write
                }
                b.right = g
            }
            if (a.perm.share_right) {
                b.right = a.perm.share_right
            }
            if (Ext.isBoolean(a.perm.acl_enable)) {
                b.isACLPrivilege = a.perm.acl_enable
            }
            b.ftpright = 0;
            if (a.perm && a.perm.adv_right) {
                if (Ext.isBoolean(a.perm.adv_right.disable_download)) {
                    if (a.perm.adv_right.disable_download) {
                        b.ftpright |= SYNO.webfm.utils.FTP_PRIV_DISABLE_DOWNLOAD
                    }
                    b.is_disable_download = a.perm.adv_right.disable_download
                }
                if (Ext.isBoolean(a.perm.adv_right.disable_modify)) {
                    if (a.perm.adv_right.disable_modify) {
                        b.ftpright |= SYNO.webfm.utils.FTP_PRIV_DISABLE_MODIFY
                    }
                    b.is_disable_modify = a.perm.adv_right.disable_modify
                }
                if (Ext.isBoolean(a.perm.adv_right.disable_list)) {
                    if (a.perm.adv_right.disable_list) {
                        b.ftpright |= SYNO.webfm.utils.FTP_PRIV_DISABLE_LIST
                    }
                    b.bldisablesearch = true;
                    b.is_disable_list = a.perm.adv_right.disable_list
                }
            }
        }
        if (a.owner) {
            b.owner = a.owner.user;
            b.group = a.owner.group;
            b.uid = a.owner.uid;
            b.gid = a.owner.gid
        }
        if (Ext.isBoolean(a.sync_share)) {
            b.is_sync_share = a.sync_share
        }
        b.bldisablesearch = false;
        if (SYNO.webfm.utils.isRecycleBinFolder(b.path)) {
            b.bldisablesearch = true
        }
        if (b.isMountPoint && b.mountType) {
            if ("iso" == b.mountType) {
                b.cls = "isomountpoint_node"
            } else {
                if ("remote" == b.mountType) {
                    b.cls = "remotemountpoint_node"
                } else {
                    if ("remotefail" == b.mountType) {
                        b.cls = "remotefailmountpoint_node"
                    }
                }
            }
        }
        if (f.attributes.isMountPoint) {
            SYNO.webfm.utils.updateRemoteMountIconByNode(f)
        }
        if (b.status === "broken") {
            b.cls = "tree-node-broken-folder"
        }
        SYNO.webfm.utils.IndexFolderMap[b.path] = a.indexed || false;
        return b
    },
    isRecycleBinFolder: function(b) {
        if (!b) {
            return false
        }
        var a = b.split("/", 7);
        return (a.length === 3 && a[2] === "#recycle") || (a.length === 4 && a[1] === "homes" && a[3] === "#recycle") || (a.length === 6 && a[1] === "homes" && a[5] === "#recycle")
    },
    isInRecycleBinFolder: function(b) {
        if (!b) {
            return false
        }
        var a = b.split("/");
        return (a.length >= 3 && a[2] === "#recycle") || (a.length >= 4 && a[1] === "homes" && a[3] === "#recycle") || (a.length >= 6 && a[1] === "homes" && a[5] === "#recycle")
    },
    isSnapshotFolder: function(a, c, b) {
        return this.isSnapshotShareFolder(a, c, b) || this.isSnapshotTopFolder(a, c)
    },
    isInHybridShareFolder: function(c, a) {
        if (!c) {
            return false
        }
        var b = c.split("/");
        return a.hasOwnProperty(b[1])
    },
    isSnapshotShareFolder: function(b, d, c) {
        if (!b || !d || !c) {
            return false
        }
        var a = b.split("/", 7);
        return (a.length === 4 && a[2] === "#snapshot")
    },
    isSnapshotTopFolder: function(b, c) {
        if (!b || !c) {
            return false
        }
        var a = b.split("/", 7);
        return (a.length === 3 && a[2] === "#snapshot")
    },
    isWebFolder: function(a) {
        if (!a) {
            return false
        }
        if ("/" !== a[a.length - 1]) {
            a += "/"
        }
        if (0 === a.indexOf("/web/") || 0 === a.indexOf("/home/www/")) {
            return true
        }
        if (0 === a.indexOf("/homes/") && -1 !== a.indexOf("/www/")) {
            return true
        }
        return false
    },
    createCAErrorMsg: function(c) {
        var a = new Date(),
            b = function(f) {
                var e = new Date(f || 0);
                return SYNO.webfm.utils.DateTimeFormatter(e, {
                    type: "date"
                })
            },
            d = [_WFT("error", "vfs_ca_unknown"), _T("certificate", "server_crt") + ":", String.format(_WFT("vfs", "vfs_ca_subject"), c.subject), String.format(_WFT("vfs", "vfs_ca_issuer"), c.issuer)];
        if (c.availDate > a.getTime() / 1000 || c.expDate < a.getTime() / 1000) {
            d.push(String.format(_WFT("vfs", "vfs_ca_availdate"), b(c.availDate * 1000)), String.format(_WFT("vfs", "vfs_ca_expdate"), b(c.expDate * 1000)))
        }
        return d.join("<br>")
    },
    getThumbName: function(d) {
        var b = "misc.png";
        if (d.isdir) {
            var c = d.mountType;
            if (!Ext.isEmpty(c)) {
                switch (c) {
                    case "remote":
                        return "remotemountpoint.png";
                    case "remotefail":
                        return "remotefailmountpoint.png";
                    case "iso":
                        return "isomountpoint.png"
                }
            }
            if (SYNO.webfm.utils.isRecycleBinFolder(d.path)) {
                return "recycle_bin.png"
            }
            if (SYNO.webfm.utils.isSnapshotFolder(d.path, d.is_snapshot, d.is_btrfs_subvol)) {
                return "snapshot.png"
            }
            return "folder.png"
        }
        var a = d.type;
        if (!a) {
            return b
        }
        a = a.toLowerCase();
        if (-1 !== SYNO.webfm.utils.icon_type.indexOf(a)) {
            return a + ".png"
        }
        return b
    },
    onMailTo: function(c) {
        var b = "My DS Shared File Links";
        var d = c;
        var a = "mailto:?subject=" + b + "&body=" + d;
        window.open(a, "_blank")
    },
    handleRemoteConnectionException: function(f, c, h, i, j, k, d) {
        var e = SYNO.API.Util.GetFirstError(f);
        var g = function(l) {
            if ("yes" !== l) {
                j.call(this);
                return
            }
            if (!d) {
                h.sendWebAPI({
                    timeout: 3600000,
                    api: "SYNO.FileStation.VFS.Connection",
                    method: "create",
                    version: 1,
                    params: {
                        profile_id: c.id,
                        force: true
                    },
                    encryption: ["password", "access_token", "refresh_token"],
                    scope: k,
                    callback: function(p, m, o, n) {
                        i.call(this)
                    }
                })
            } else {
                i.call(this)
            }
        };
        var a = function(m) {
            if ("yes" !== m) {
                j.call(this);
                return
            }
            var n = c.id;
            var o = SYNO.webfm.VFS.getSchemaFromPath(c.id);
            var l = function(p) {
                p.id = n;
                var q = [{
                    timeout: 3600000,
                    api: "SYNO.FileStation.VFS.Connection",
                    method: "set",
                    version: 1,
                    params: p
                }, {
                    api: "SYNO.FileStation.VFS.Profile",
                    method: "set",
                    version: 1,
                    params: p
                }];
                h.sendWebAPI({
                    params: {},
                    compound: {
                        stopwhenerror: true,
                        params: q
                    },
                    encryption: ["password", "access_token", "refresh_token"],
                    scope: k,
                    callback: function(u, r, t, s) {
                        if (h.isDestroyed) {
                            return
                        }
                        i.call(k)
                    }
                })
            };
            SYNO.webfm.utils.startOAuth(o, l, k)
        };
        var b = function(m) {
            if ("yes" !== m) {
                j.call(this);
                return
            }
            var l = new SYNO.FileStation.RemoteConnection.EditDialog({
                owner: h,
                title: _WFT("vfs", "edit_profile")
            });
            this.mon(l, "editcomplete", i.createDelegate(k));
            l.load(c.id)
        };
        switch (e.code) {
            case 2102:
                h.getMsgBox().confirm("", _WFT("error", "vfs_confirm_edit_profile"), b, k);
                break;
            case 2107:
                h.getMsgBox().confirm("", String.format(_WFT("error", "vfs_identity_unknown"), e.errors[0].fingerprint), g, k);
                break;
            case 2112:
                h.getMsgBox().confirm("", SYNO.webfm.utils.createCAErrorMsg(e.errors[0]), g, k);
                break;
            case 2115:
                h.getMsgBox({
                    preventDelay: true
                }).confirm("", _WFT("error", "vfs_confirm_refresh_oauth"), a, k);
                break;
            default:
                break
        }
    },
    startOAuth: function(h, g, c) {
        var a = window.location.href.indexOf("/", window.location.protocol.length + 2);
        var d = window.location.href.slice(0, a);
        var e = "_webfmOAuthCallback";
        if (_S("rewrite_mode")) {
            var f = window.location.href.indexOf("/", a + 1);
            if (-1 !== f) {
                var b = window.location.href.slice(a, f);
                d += b
            }
        }
        this.register(h, g, c, e);
        this.popup = window.open("https://synooauth.synology.com/FileStation/Cloud/login.php?" + Ext.urlEncode({
            major: _S("majorversion"),
            minor: _S("minorversion"),
            version: _S("version"),
            fullversion: _S("fullversion"),
            unique: _D("unique"),
            timezone: _D("timezone"),
            callback: e,
            host: d,
            type: h
        }), "mywindow", "menubar=1,resizable=0,width=600,height=520, top=100, left=300");
        this.addPopupTimer(this)
    },
    updateRemoteMountIconByNode: function(a) {
        if (a && a.ui && a.ui.elNode && "remotefail" === a.attributes.mountType) {
            if (Ext.fly(a.ui.elNode).hasClass("remotefailmountpoint_node")) {
                Ext.fly(a.ui.elNode).replaceClass("remotefailmountpoint_node", "remotemountpoint_node");
                a.attributes.mountType = "remote"
            }
        }
    },
    register: function(d, c, a, b) {
        if (Ext.isIE || Ext.isIE11) {
            window[b] = function(e) {
                e.protocol = d;
                c.call(a, e)
            }
        } else {
            this.receiveMessage = function(g) {
                var f = g.browserEvent;
                if (f.origin !== window.location.origin || /setImmediate/.test(f.data)) {
                    return
                }
                var h = JSON.parse(f.data);
                if (h.callback !== b) {
                    return
                }
                h.protocol = d;
                c.call(a, h)
            };
            Ext.EventManager.addListener(window, "message", this.receiveMessage)
        }
    },
    unregister: function() {
        if (Ext.isIE || Ext.isIE11) {
            return
        }
        Ext.EventManager.removeListener(window, "message", this.receiveMessage)
    },
    addPopupTimer: function(b) {
        if (b.popup && !b.popup.closed) {
            var a = 1000;
            var c = window.setInterval(function() {
                if (b.popup.closed) {
                    b.unregister();
                    window.clearInterval(c);
                    c = null
                }
            }, a)
        }
    },
    doClosePopup: function() {
        if (this.popup && !this.popup.closed) {
            this.popup.close()
        }
    },
    isRootNode: function(a) {
        return a.id === "fm_root" || a.id === "fm_local_root" || a.id === "fm_vd_root" || a.id === "fm_rf_root" || a.id === "fm_fav_root" || a.id === "fm_top_root" || (a.parentNode && a.parentNode.id === "fm_top_root") || a.hidden === true
    }
});
SYNO.webfm.Plugin = {};
Ext.apply(SYNO.webfm.Plugin, {
    checkFileType: function(b, d, c) {
        var a = true;
        Ext.each(c, function(g) {
            var f = g.get("type") && g.get("type").toLowerCase() || g.get("filename") && SYNO.webfm.utils.getExt(g.get("filename"));
            var e = g.get("isdir") ? d.dir : d.file;
            if (false === d.support_mnt_point && "remotev" === SYNO.webfm.SmartDDMVCPMgr.getSourceTypeByPath(b, g.get("path"))) {
                a = false;
                return a
            }
            if (false === e || (Ext.isArray(e) && 0 > e.indexOf(f))) {
                a = false;
                return a
            }
        }, this);
        return a
    },
    checkActionByPlugin: function(g, i, j, k, b) {
        var f, c;
        if (b) {
            f = b.arg1;
            c = b.warning_fn
        }
        var h = true,
            d = [],
            l = k[0].get("path"),
            a = false;
        if (l && SYNO.webfm.VFS.isVFSPath(l)) {
            a = true
        }
        Ext.each(g.actionPlugins[j], function(m) {
            if (!m.checkFn) {
                return
            }
            var p = m.plugin.data;
            if (1 < k.length && true !== p.multiple) {
                return
            }
            if (a && !p.vfs) {
                return
            }
            if (!SYNO.webfm.Plugin.checkFileType(g.webfm, p, k)) {
                return
            }
            try {
                var n = m.checkFn.call(g.webfm, j, k, f);
                if (false === n) {
                    h = "error"
                } else {
                    if (Ext.isString(n)) {
                        h = "error";
                        d.push(n)
                    } else {
                        if (Ext.isObject(n)) {
                            h = ("error" !== h && "warning" === n.type) ? n.type : "error";
                            if (n.msg) {
                                d.push(n.msg)
                            }
                        }
                    }
                }
            } catch (o) {
                SYNO.Debug(o);
                return
            }
        }, this);
        if (true !== h) {
            var e = Ext.isEmpty(d) ? _WFT("error", "action") : d.join("<br>");
            if ("error" === h) {
                i.getMsgBox().alert("", e);
                return false
            }
            if (c) {
                c.call(b ? b.scope : null, d)
            } else {
                if (b) {
                    i.getMsgBox().confirm("", e, function(m) {
                        if ("yes" == m && b.fn) {
                            b.fn.call(b.scope)
                        }
                    })
                }
            }
        } else {
            if (b && b.fn) {
                b.fn.call(b.scope)
            }
        }
        return h
    }
});
SYNO.webfm.utils.FTP_PRIV_DISABLE_LIST = 1;
SYNO.webfm.utils.FTP_PRIV_DISABLE_MODIFY = 2;
SYNO.webfm.utils.FTP_PRIV_DISABLE_DOWNLOAD = 4;
SYNO.webfm.utils.NA = 1;
SYNO.webfm.utils.RW = 2;
SYNO.webfm.utils.RO = 4;
SYNO.webfm.utils.Mode_Exec = 1;
SYNO.webfm.utils.Mode_Write = 2;
SYNO.webfm.utils.Mode_Read = 4;
SYNO.webfm.utils.Mode_Append = 8;
SYNO.webfm.utils.Mode_Del = 512;
SYNO.webfm.utils.Mode_All = 8191;
SYNO.webfm.utils.ReqPrivilege = {};
SYNO.webfm.utils.ReqPrivilege.SrcFolder = {};
SYNO.webfm.utils.ReqPrivilege.DestFolder = {};
SYNO.webfm.utils.ReqPrivilege.SrcFile = {};
SYNO.webfm.utils.ReqPrivilege.DestFolder.Create = SYNO.webfm.utils.Mode_Exec | SYNO.webfm.utils.Mode_Append;
SYNO.webfm.utils.ReqPrivilege.SrcFile.Copy = SYNO.webfm.utils.Mode_Read;
SYNO.webfm.utils.ReqPrivilege.DestFolder.Copy = SYNO.webfm.utils.Mode_Write | SYNO.webfm.utils.Mode_Exec;
SYNO.webfm.utils.ReqPrivilege.DestFolder.CopyDir = SYNO.webfm.utils.Mode_Read | SYNO.webfm.utils.Mode_Exec;
SYNO.webfm.utils.ReqPrivilege.SrcFile.Move = SYNO.webfm.utils.Mode_Del;
SYNO.webfm.utils.ReqPrivilege.DestFolder.Move = SYNO.webfm.utils.Mode_Write | SYNO.webfm.utils.Mode_Exec;
SYNO.webfm.utils.ReqPrivilege.DestFolder.MoveDir = SYNO.webfm.utils.Mode_Read | SYNO.webfm.utils.Mode_Exec;
SYNO.webfm.utils.ReqPrivilege.SrcFile.Delete = SYNO.webfm.utils.Mode_Del;
SYNO.webfm.utils.ReqPrivilege.DestFolder.Upload = SYNO.webfm.utils.Mode_Write | SYNO.webfm.utils.Mode_Exec;
SYNO.webfm.utils.ReqPrivilege.DestFolder.UploadDir = SYNO.webfm.utils.Mode_Exec | SYNO.webfm.utils.Mode_Append;
SYNO.webfm.utils.ReqPrivilege.SrcFile.Download = SYNO.webfm.utils.Mode_Read;
SYNO.webfm.utils.ReqPrivilege.SrcFolder.Download = SYNO.webfm.utils.Mode_Read | SYNO.webfm.utils.Mode_Exec;
SYNO.webfm.utils.ReqPrivilege.DestFolder.Navigate = SYNO.webfm.utils.Mode_Exec;
SYNO.webfm.utils.ReqPrivilege.SrcFile.Extract = SYNO.webfm.utils.Mode_Read;
SYNO.webfm.utils.ReqPrivilege.DestFolder.Extract = SYNO.webfm.utils.Mode_Read | SYNO.webfm.utils.Mode_Write | SYNO.webfm.utils.Mode_Exec;
SYNO.webfm.utils.ReqPrivilege.DestFolder.ExtractDir = SYNO.webfm.utils.Mode_Read | SYNO.webfm.utils.Mode_Write | SYNO.webfm.utils.Mode_Exec;
SYNO.webfm.utils.ReqPrivilege.SrcFile.Compress = SYNO.webfm.utils.Mode_Read;
SYNO.webfm.utils.ReqPrivilege.SrcFolder.Compress = SYNO.webfm.utils.Mode_Read | SYNO.webfm.utils.Mode_Exec;
SYNO.webfm.utils.ReqPrivilege.DestFolder.Compress = SYNO.webfm.utils.Mode_Read | SYNO.webfm.utils.Mode_Write | SYNO.webfm.utils.Mode_Exec;
SYNO.webfm.utils.ReqPrivilege.SrcFile.ISO = SYNO.webfm.utils.Mode_Read;
SYNO.webfm.utils.ReqPrivilege.DestFolder.Mount = SYNO.webfm.utils.Mode_Read | SYNO.webfm.utils.Mode_Write | SYNO.webfm.utils.Mode_Exec;
SYNO.webfm.utils.IndexFolderMap = {};
SYNO.webfm.utils.tids = {};
SYNO.webfm.utils.checkShareRight = function(a, b) {
    var c;
    if (a == "NA") {
        c = SYNO.webfm.utils.NA
    } else {
        if (a == "RW") {
            c = SYNO.webfm.utils.RW
        } else {
            if (a == "RO") {
                c = SYNO.webfm.utils.RO
            }
        }
    }
    if (b & c) {
        return true
    }
    return false
};
SYNO.webfm.utils.checkFileRight = function(b) {
    if (_S("is_admin") === true || _S("domainUser") == "true") {
        return true
    }
    var c = b.right;
    var a = c & ~(SYNO.webfm.utils.Mode_All & ~b.needRight);
    if (a == b.needRight) {
        return true
    }
    return false
};
SYNO.webfm.utils.parseMode = function(c) {
    var e = 0;
    var b = 0,
        d = 0,
        a = 0;
    e = parseInt(c, 10);
    if (e >= 100) {
        b = Math.floor(e / 100);
        e -= b * 100
    }
    if (e >= 10) {
        d = Math.floor(e / 10);
        e -= d * 10
    }
    a = e;
    return {
        owner: b,
        group: d,
        others: a
    }
};
SYNO.webfm.utils.getShareRight = function(b, d) {
    if (d.parentNode.id === "fm_root") {
        return d.attributes.right
    }
    var e = d.attributes.path,
        f, a;
    if ((a = e.indexOf("/", 1)) != -1) {
        var c = e.substring(0, a);
        f = b.getNodeById(SYNO.webfm.utils.source.remote + c)
    } else {
        f = b.getNodeById(SYNO.webfm.utils.source.remote + e)
    }
    if (f) {
        return f.attributes.right
    }
    return null
};
SYNO.webfm.utils.IsFolderIndexed = function(a) {
    if (Ext.isEmpty(a)) {
        return false
    }
    return SYNO.webfm.utils.IndexFolderMap[a]
};
SYNO.webfm.utils.IsShareForceRO = function(b, d) {
    var a = d.indexOf("/", 1);
    if (a === -1) {
        return false
    }
    var c = b.getNodeById(SYNO.webfm.utils.source.remote + d.substring(0, a));
    if (c) {
        return c.attributes.additional.perm.is_share_readonly
    }
    return false
};
SYNO.webfm.utils.getShareRightBySPath = function(b, d) {
    var e, a;
    if ((a = d.indexOf("/", 1)) != -1) {
        var c = d.substring(0, a);
        e = b.getNodeById(SYNO.webfm.utils.source.remote + c)
    } else {
        e = b.getNodeById(SYNO.webfm.utils.source.remote + d)
    }
    if (e) {
        return e.attributes.right
    }
    return null
};
SYNO.webfm.utils.getShareFtpRight = function(a, b) {
    var c = b.attributes.path;
    return SYNO.webfm.utils.getShareFtpRightByPath(a, c)
};
SYNO.webfm.utils.getShareFtpRightByPath = function(b, d) {
    var e, a;
    if ((a = d.indexOf("/", 1)) != -1) {
        var c = d.substring(0, a);
        e = b.getNodeById(SYNO.webfm.utils.source.remote + c)
    } else {
        e = b.getNodeById(SYNO.webfm.utils.source.remote + d)
    }
    if (e) {
        return e.attributes.ftpright
    }
    return null
};
SYNO.webfm.utils.getZipName = function(b) {
    var a = b.lastIndexOf(".");
    b = b.substr(0, a);
    a = b.lastIndexOf(".");
    if (b.substr(a + 1).toLowerCase() == "tar") {
        b = b.substr(0, a)
    }
    return b
};
SYNO.webfm.utils.getImageName = function(b) {
    var a = b.lastIndexOf(".");
    if (-1 === a) {
        return ""
    }
    b = b.substr(0, a);
    return b
};
SYNO.webfm.utils.GridDropTarget = function(c, b, a) {
    this.webfm = a;
    SYNO.webfm.utils.GridDropTarget.superclass.constructor.call(this, c, b)
};
Ext.extend(SYNO.webfm.utils.GridDropTarget, Ext.dd.DropTarget, {
    notifyOverAndDrop: function(p, m, h, j, l, g) {
        var q = p.getProxy().getGhost();
        if (j.activeDS === j.remoteSearchDS && (l !== true)) {
            return this.dropNotAllowed
        }
        if (p.tree) {
            if (p.tree === j.dirTree || p.tree === j.dirLocalTree) {
                return this.dropNotAllowed
            }
            var i = h.node.parentNode;
            if (i && i.id === "fm_fav_root") {
                q.update(_WFT("favorite", "insert_invalid_favorite"));
                return this.dropNotAllowed
            }
        }
        var b = h.node,
            a = h.from || p.grid,
            o, f, d = b ? b.attributes.type : (a ? a.getStore().storetype : null),
            c = SYNO.webfm.utils.isLocalSource(j.activeDS.storetype),
            n = SYNO.webfm.utils.isLocalSource(d);
        if (g) {
            f = (g.blTgtTreeType) ? g.target.attributes.path : g.target.get("path")
        }
        if (a) {
            o = a.getSelectionModel().getSelections()
        }
        if (!c && n) {
            if (!this.webfm.onCheckVFSAction("upload", f)) {
                return this.dropNotAllowed
            }
        } else {
            if (c && !n) {
                if (!this.webfm.onCheckVFSAction("download", b || o)) {
                    return this.dropNotAllowed
                }
                var k = true;
                if (a) {
                    Ext.each(o, function(e) {
                        k = !this.webfm.checkFTPDownloadRightByPath(e.get("file_id"));
                        return k
                    }, this)
                } else {
                    if (b) {
                        if (this.webfm.checkFTPDownloadRight(b)) {
                            k = false
                        }
                    }
                }
                if (!k) {
                    q.update(_WFT("error", "error_privilege_not_enough"));
                    return this.dropNotAllowed
                }
            } else {
                if ((!SYNO.webfm.SmartDDMVCPMgr.isEnable() && !j.onCheckVFSAction("copy", b || o, f) && !j.onCheckVFSAction("move", b || o, f)) || (SYNO.webfm.SmartDDMVCPMgr.isEnable() && !j.onCheckVFSAction(SYNO.webfm.SmartDDMVCPMgr.getAction(), b || o, f))) {
                    return this.dropNotAllowed
                }
            }
        }
        return this.dropAllowed
    },
    updateDefalutDDText: function(a, f, c) {
        SYNO.webfm.SmartDDMVCPMgr.disableUpateDDText(true);
        var d = a.getProxy().getGhost();
        if (a.tree) {
            d.update("");
            c.node.ui.appendDDGhost(d.dom)
        } else {
            if (a.grid) {
                var b = a.grid.getDragDropText();
                d.update(b)
            } else {
                if (a.dataview) {
                    d.update(a.dataview.getDragDropText())
                }
            }
        }
    },
    notifyOut: function(a, c, b) {
        this.updateDefalutDDText(a, c, b)
    },
    notifyOver: function(w, u, z) {
        var g = this.webfm;
        var k, v, p;
        var j = false,
            x = true;
        var t = u.getTarget(),
            y;
        if (SYNO.webfm.SmartDDMVCPMgr.isEnable()) {
            SYNO.webfm.SmartDDMVCPMgr.focus(g, z);
            SYNO.webfm.SmartDDMVCPMgr.onDragOver(u)
        }
        if (t && (Ext.fly(t).findParentNode("div.syno-sds-fs-tree", Number.MAX_VALUE))) {
            return this.dropAllowed
        }
        if ((k = this.getTarget(w, u, z)) === false) {
            this.updateDefalutDDText(w, u, z)
        } else {
            if ((p = this.getSource(w, u, z)) === false) {
                this.updateDefalutDDText(w, u, z)
            } else {
                if (!w.tree && !w.grid && !w.dataview) {
                    return this.dropNotAllowed
                }
                v = k.blTgtTreeType;
                y = k.target;
                var d = w.getProxy().getGhost();
                var q;
                if (v) {
                    q = y.attributes.text
                } else {
                    q = y.get("filename");
                    j = y.get("isdir")
                }
                q = Ext.util.Format.htmlEncode(q);
                q = Ext.util.Format.ellipsis(q, 36);
                var f = z.node;
                var n = z.from || w.grid;
                var c = f ? f.attributes.type : (n ? n.getStore().storetype : null);
                var l = SYNO.webfm.utils.isLocalSource(g.activeDS.storetype);
                var o = SYNO.webfm.utils.isLocalSource(c),
                    m, i;
                if (!l && o) {
                    m = String.format(_WFT("filetable", "upload_ddtext"), q);
                    i = "upload"
                } else {
                    if (l && !o) {
                        m = String.format(_WFT("download", "download_to"), q);
                        i = "download"
                    } else {
                        m = String.format(_WFT("filetable", "mvcp_ddtext"), q);
                        i = "mvcp"
                    }
                }
                var s = (SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "isfirstdd") === false) ? false : true;
                var b = false;
                if (SYNO.webfm.SmartDDMVCPMgr.isEnable() || s) {
                    var a, r = false,
                        h = false;
                    if (0 < p.length) {
                        r = SYNO.webfm.VFS.isVFSPath(p[0].get("path"));
                        b = SYNO.webfm.VFS.isSharingPath(p[0].get("path")) || SYNO.webfm.VFS.isGDriveStarsFirstLevelPath(p[0].get("path"))
                    }
                    if (!v && "remote" === y.get("mountType")) {
                        a = SYNO.webfm.utils.source.remoter
                    } else {
                        if (!v && "iso" === y.get("mountType")) {
                            a = SYNO.webfm.utils.source.remotev
                        } else {
                            if (!v) {
                                h = SYNO.webfm.VFS.isVFSPath(y.get("path"));
                                a = SYNO.webfm.SmartDDMVCPMgr.getSourceTypeByPath(this.webfm, y.get("path"))
                            } else {
                                h = SYNO.webfm.VFS.isVFSPath(y.attributes.path);
                                a = SYNO.webfm.SmartDDMVCPMgr.getSourceTypeByPath(this.webfm, y.attributes.path)
                            }
                        }
                    }
                    SYNO.webfm.SmartDDMVCPMgr.disableUpateDDText(b);
                    SYNO.webfm.SmartDDMVCPMgr.setDragDropData(q, i, w.getProxy());
                    SYNO.webfm.SmartDDMVCPMgr.updateDefaultAction(a, r, h);
                    if (!s) {
                        m = String.format(SYNO.webfm.SmartDDMVCPMgr.getDDText(b), q)
                    }
                }
                d.update(m)
            }
        }
        if (!x) {
            return this.dropNotAllowed
        }
        return this.notifyOverAndDrop(w, u, z, g, j, k)
    },
    getTarget: function(a, h, f) {
        var d = this.webfm;
        var g;
        var b = Ext.lib.Event.getTarget(h);
        var c = d.grid.getView().findRowIndex(b);
        var i = true;
        if (c !== false && !Ext.isDefined(g = d.activeDS.getAt(c))) {
            return false
        } else {
            if (c === false || !g.get("isdir")) {
                if (a.grid && a.grid === d.grid) {
                    return false
                }
                g = d.dirTree.getSelectionModel().getSelectedNode()
            } else {
                i = false
            }
        }
        return {
            target: g,
            blTgtTreeType: i
        }
    },
    getSource: function(a, d, c) {
        var b;
        if (a.tree) {
            b = c.node
        } else {
            if (a.grid || a.dataview) {
                b = c.selections
            } else {
                return false
            }
        }
        return b
    },
    notifyDrop: function(w, s, y) {
        var c = this.webfm;
        var r = s.getTarget();
        if (r && (r = (Ext.fly(r).findParentNode("div.syno-sds-fs-win")))) {
            if (r !== this.webfm.owner.el.dom) {
                return false
            }
        }
        if (!w.grid && !w.tree && !w.dataview) {
            return false
        }
        var m, x;
        var g, u;
        if ((g = this.getTarget(w, s, y)) === false) {
            return false
        }
        u = g.blTgtTreeType;
        x = g.target;
        var f = u ? false : x.get("isdir");
        if (this.notifyOverAndDrop(w, s, y, c, f, g) === this.dropNotAllowed) {
            return false
        }
        if ((m = this.getSource(w, s, y)) === false) {
            return false
        }
        var j = w.grid || w.dataview;
        var a = (u) ? x.attributes.real_path : x.get("real_path");
        var z = _T("tree", "leaf_filebrowser");
        var h = SYNO.webfm.utils.isLocalSource(c.activeDS.storetype);
        var l = w.tree ? SYNO.webfm.utils.isLocalSource(m.attributes.type) : SYNO.webfm.utils.isLocalSource(j.getStore().storetype);
        if (h === l) {
            var k = h && Ext.isWindows ? "\\" : "/";
            if (w.tree) {
                if (SYNO.webfm.utils.isConflictTargetPath(m.attributes.real_path, a, k)) {
                    c.owner.getMsgBox().alert(z, _WFT("error", "error_select_conflict"));
                    return false
                }
            } else {
                if (w.grid || w.dataview) {
                    for (var q = 0; q < m.length; q++) {
                        var b = m[q].get("real_path");
                        if (SYNO.webfm.utils.isConflictTargetPath(b, a, k)) {
                            c.owner.getMsgBox().alert(z, _WFT("error", "error_select_conflict"));
                            return false
                        }
                    }
                }
            }
        }
        c.ddParams = {
            src: (w.tree) ? m.attributes.path : m,
            target: (u) ? x.attributes.path : x.get("file_id"),
            srcsource: (w.tree) ? m.attributes.type : j.getStore().storetype,
            srcnode: (w.tree) ? w.dragData.node : undefined
        };
        if (j && j.getStore().storetype === SYNO.webfm.utils.source.remotes) {
            Ext.apply(c.ddParams, {
                search_taskid: j.getStore().search_taskid,
                blsame: (!u) && (w.grid === c.grid)
            })
        }
        var p = (u) ? x.attributes.text : x.get("filename");
        p = "<b>[" + Ext.util.Format.ellipsis(Ext.util.Format.htmlEncode(p), 36) + "]</b>";
        var t = c.copymoveCtxMenu;
        var v = t.items;
        v.each(function(e) {
            e.enable();
            e.show()
        });
        var n = c.dirTree.getSelectionModel().getSelectedNode();
        var o, d;
        if (!h && l) {
            if (_S("demo_mode") === true) {
                c.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _JSLIBSTR("uicommon", "error_demo"));
                return false
            }
            if (!c.checkUploadRight(n)) {
                c.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "error_privilege_not_enough"));
                return false
            }
            d = c.checkFtpModifyRight(n);
            if (d) {
                v.get("copy_overwrite").disable()
            }
            v.get("move_skip").hide();
            v.get("move_overwrite").hide();
            v.get("text").setText(String.format("<b>" + _WFT("filetable", "upload_ddtext") + "&nbsp</b>", Ext.util.Format.htmlEncode(p)));
            o = "upload"
        } else {
            if (h && !l) {
                if (c.checkFTPDownloadRight(n)) {
                    c.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), _WFT("error", "error_privilege_not_enough"));
                    return
                }
                d = c.checkFtpModifyRight(n);
                if (d || (this.isSrcReadOnly(w, m))) {
                    v.get("move_overwrite").disable();
                    v.get("move_skip").disable()
                }
                v.get("text").setText(String.format("<b>" + _WFT("download", "download_to") + "&nbsp</b>", p));
                o = "download"
            } else {
                if (this.isSrcReadOnly(w, m)) {
                    v.get("move_overwrite").disable();
                    v.get("move_skip").disable()
                }
                v.get("text").setText(p);
                o = "copymove"
            }
        }
        t.action = o;
        SYNO.webfm.SmartDDMVCPMgr.onAction(t, c, s);
        return true
    },
    isSrcReadOnly: function(a, b) {
        return ((a.tree && b.attributes && ((b.attributes.is_snapshot) || (b.attributes.type === SYNO.webfm.utils.source.remotev || b.attributes.isMountPoint))) || (a.grid && SYNO.webfm.utils.doesIncludeMountPoint(a.grid.getSelectionModel().getSelections())) || (a.grid && a.grid.owner && SYNO.webfm.utils.source.remotev === a.grid.owner.getCurrentSource()) || (a.dataview && SYNO.webfm.utils.doesIncludeMountPoint(a.dataview.getSelectionModel().getSelections())) || (a.dataview && a.dataview.owner && SYNO.webfm.utils.source.remotev === a.dataview.owner.getCurrentSource()))
    }
});
SYNO.webfm.utils.DataViewDragZone = function(a, b) {
    SYNO.webfm.utils.DataViewDragZone.superclass.constructor.call(this, a.getEl(), b);
    this.dataview = a;
    this.scroll = false;
    this.ddel = document.createElement("div");
    this.ddel.className = "x-grid-dd-wrap";
    this.preventDefault = true
};
Ext.extend(SYNO.webfm.utils.DataViewDragZone, Ext.dd.DragZone, {
    proxy: new Ext.dd.StatusProxy({
        animRepair: false
    }),
    onGetShortCutRecs: function(a) {},
    getDragData: function(f) {
        var a = this.dataview,
            b = f.getTarget(a.itemSelector, 10);
        if (b) {
            var i = a.getSelectionModel(),
                c, g = b.cloneNode(true),
                h = a.indexOf(b);
            g.id = Ext.id();
            if (h !== -1 && !a.isSelected(h) && !f.hasModifier()) {
                a.select(h, false)
            }
            if (h === -1 || !a.isSelected(h) || f.hasModifier()) {
                return
            }
            c = i.getSelections();
            return {
                from: a,
                ddel: this.ddel,
                index: h,
                selections: c,
                SDSShortCut: this.onGetShortCutRecs(c),
                _fromFile: true,
                ddText: _T("desktop", "add_shortcut")
            }
        }
        return false
    },
    validateTarget: function(f, d, i) {
        var a = f.getEl();
        if (Ext.fly(a).findParentNode("div.syno-sds-aceeditor-main-panel") || Ext.fly(a).findParentNode("div.sds-audioplayer-mini-player-window") || Ext.fly(a).findParentNode("div.syno-sds-filestation-available-drop-target")) {
            return true
        }
        var h = d.getTarget("li.launch-icon");
        if (SYNO.SDS.Desktop.getEl().id === d.getTarget().id || (h && Ext.fly(h).findParentNode(".sds-desktop-shortcut"))) {
            var b = this.dragData;
            if (b && b.from && SYNO.webfm.utils.isLocalSource(b.from.getStore().storetype)) {
                return false
            }
            return true
        }
        h = d.getTarget();
        var c, g;
        if ((h && (Ext.fly(h).is("div.syno-sds-fs-grid-scroller") || Ext.fly(h).is("div.syno-sds-fs-thumbnailsView") || Ext.fly(h).is("div.syno-sds-fs-columnView") || (g = Ext.fly(h).findParentNode("div.syno-sds-fs-grid-scroller")) || (g = Ext.fly(h).findParentNode("div.syno-sds-fs-thumbnailsView")) || (g = Ext.fly(h).findParentNode("div.syno-sds-fs-columnView")) || (g = Ext.fly(h).findParentNode("div.syno-sds-fs-tree", Number.MAX_VALUE))))) {
            g = g || h;
            g = (Ext.fly(g).findParentNode("div.syno-sds-fs-win", Number.MAX_VALUE));
            c = SYNO.SDS.WindowMgr.get(g.id);
            if (c) {
                c.toFront()
            }
            return true
        }
        g = g || h;
        if (g && (g = (Ext.fly(g).findParentNode("div.syno-sds-fs-win", Number.MAX_VALUE)))) {
            c = SYNO.SDS.WindowMgr.get(g.id);
            if (c) {
                c.toFront()
            }
        }
        return false
    }
});
SYNO.webfm.utils.DataViewDropTarget = function(a, c, b) {
    this.webfm = b;
    this.dataview = a;
    SYNO.webfm.utils.DataViewDropTarget.superclass.constructor.call(this, a.getEl(), c)
};
Ext.extend(SYNO.webfm.utils.DataViewDropTarget, Ext.dd.DropTarget, {
    notifyOverAndDrop: function(p, m, h, j, l, g) {
        var q = p.getProxy().getGhost();
        if (j.activeDS === j.remoteSearchDS && (l !== true)) {
            return this.dropNotAllowed
        }
        if (p.tree) {
            if (p.tree === j.dirTree || p.tree === j.dirLocalTree) {
                return this.dropNotAllowed
            }
            var i = h.node.parentNode;
            if (i && i.id === "fm_fav_root") {
                q.update(_WFT("favorite", "insert_invalid_favorite"));
                return this.dropNotAllowed
            }
        }
        var b = h.node;
        var a = h.from || p.grid,
            o, f;
        var d = b ? b.attributes.type : (a ? a.getStore().storetype : null);
        var c = SYNO.webfm.utils.isLocalSource(j.activeDS.storetype);
        var n = SYNO.webfm.utils.isLocalSource(d);
        if (g) {
            f = (g.blTgtTreeType) ? g.target.attributes.path : g.target.get("path")
        }
        if (a) {
            o = a.getSelectionModel().getSelections()
        }
        if (!c && n) {
            if (!j.onCheckVFSAction("upload", f)) {
                return this.dropNotAllowed
            }
        } else {
            if (c && !n) {
                if (!j.onCheckVFSAction("download", b || o)) {
                    return this.dropNotAllowed
                }
                var k = true;
                if (a) {
                    Ext.each(o, function(e) {
                        k = !this.webfm.checkFTPDownloadRightByPath(e.get("file_id"));
                        return k
                    }, this)
                } else {
                    if (b) {
                        if (this.webfm.checkFTPDownloadRight(b)) {
                            k = false
                        }
                    }
                }
                if (!k) {
                    q.update(_WFT("error", "error_privilege_not_enough"));
                    return this.dropNotAllowed
                }
            } else {
                if ((!SYNO.webfm.SmartDDMVCPMgr.isEnable() && !j.onCheckVFSAction("copy", b || o, f) && !j.onCheckVFSAction("move", b || o, f)) || (SYNO.webfm.SmartDDMVCPMgr.isEnable() && !j.onCheckVFSAction(SYNO.webfm.SmartDDMVCPMgr.getAction(), b || o, f))) {
                    return this.dropNotAllowed
                }
            }
        }
        return this.dropAllowed
    },
    updateDefalutDDText: function(a, f, c) {
        SYNO.webfm.SmartDDMVCPMgr.disableUpateDDText(true);
        var d = a.getProxy().getGhost();
        if (a.tree) {
            d.update("");
            c.node.ui.appendDDGhost(d.dom)
        } else {
            if (a.grid) {
                var b = a.grid.getDragDropText();
                d.update(b)
            } else {
                if (a.dataview) {
                    d.update(a.dataview.getDragDropText())
                }
            }
        }
    },
    notifyOut: function(a, c, b) {
        this.updateDefalutDDText(a, c, b)
    },
    notifyOver: function(w, u, z) {
        var g = this.webfm;
        var k, v, p, x;
        var j = false,
            y = true;
        var t = u.getTarget();
        if (SYNO.webfm.SmartDDMVCPMgr.isEnable()) {
            SYNO.webfm.SmartDDMVCPMgr.focus(g, z);
            SYNO.webfm.SmartDDMVCPMgr.onDragOver(u)
        }
        if (t && (Ext.fly(t).findParentNode("div.syno-sds-fs-tree", Number.MAX_VALUE))) {
            return this.dropAllowed
        }
        if ((k = this.getTarget(w, u, z)) === false) {
            this.updateDefalutDDText(w, u, z)
        } else {
            if ((p = this.getSource(w, u, z)) === false) {
                this.updateDefalutDDText(w, u, z)
            } else {
                if (!w.tree && !w.grid && !w.dataview) {
                    return this.dropNotAllowed
                }
                v = k.blTgtTreeType;
                x = k.target;
                var d = w.getProxy().getGhost();
                var q;
                if (v) {
                    q = x.attributes.text
                } else {
                    q = x.get("filename");
                    j = x.get("isdir")
                }
                q = Ext.util.Format.htmlEncode(q);
                q = Ext.util.Format.ellipsis(q, 36);
                var f = z.node;
                var n = z.from;
                var c = f ? f.attributes.type : (n ? n.getStore().storetype : null);
                var l = SYNO.webfm.utils.isLocalSource(g.activeDS.storetype);
                var o = SYNO.webfm.utils.isLocalSource(c),
                    m, i;
                if (!l && o) {
                    m = String.format(_WFT("filetable", "upload_ddtext"), q);
                    i = "upload"
                } else {
                    if (l && !o) {
                        m = String.format(_WFT("download", "download_to"), q);
                        i = "download"
                    } else {
                        m = String.format(_WFT("filetable", "mvcp_ddtext"), q);
                        i = "mvcp"
                    }
                }
                var s = (SYNO.SDS.UserSettings.getProperty("SYNO.SDS.App.PersonalSettings.Instance", "isfirstdd") === false) ? false : true;
                var b = false;
                if (SYNO.webfm.SmartDDMVCPMgr.isEnable() || s) {
                    var a, r = false,
                        h = false;
                    if (0 < p.length) {
                        r = SYNO.webfm.VFS.isVFSPath(p[0].get("path"));
                        b = SYNO.webfm.VFS.isSharingPath(p[0].get("path")) || SYNO.webfm.VFS.isGDriveStarsFirstLevelPath(p[0].get("path"))
                    }
                    if (!v && "remote" === x.get("mountType")) {
                        a = SYNO.webfm.utils.source.remoter
                    } else {
                        if (!v && "iso" === x.get("mountType")) {
                            a = SYNO.webfm.utils.source.remotev
                        } else {
                            if (!v) {
                                h = SYNO.webfm.VFS.isVFSPath(x.get("path"));
                                a = SYNO.webfm.SmartDDMVCPMgr.getSourceTypeByPath(this.webfm, x.get("path"))
                            } else {
                                h = SYNO.webfm.VFS.isVFSPath(x.attributes.path);
                                a = SYNO.webfm.SmartDDMVCPMgr.getSourceTypeByPath(this.webfm, x.attributes.path)
                            }
                        }
                    }
                    SYNO.webfm.SmartDDMVCPMgr.disableUpateDDText(b);
                    SYNO.webfm.SmartDDMVCPMgr.setDragDropData(q, i, w.getProxy());
                    SYNO.webfm.SmartDDMVCPMgr.updateDefaultAction(a, r, h);
                    if (!s) {
                        m = String.format(SYNO.webfm.SmartDDMVCPMgr.getDDText(b), q)
                    }
                }
                d.update(m)
            }
        }
        if (!y) {
            return this.dropNotAllowed
        }
        return this.notifyOverAndDrop(w, u, z, g, j, k)
    },
    getTarget: function(a, h, f) {
        var d = this.webfm,
            b = h.getTarget(this.dataview.itemSelector, 10),
            c = b ? this.dataview.indexOf(b) : -1,
            i = true,
            g;
        if (c !== -1 && !Ext.isDefined(g = d.activeDS.getAt(c))) {
            return false
        } else {
            if (c === -1 || !g.get("isdir")) {
                if (a.dataview && a.dataview === d.thumbnailView) {
                    return false
                }
                g = d.dirTree.getSelectionModel().getSelectedNode()
            } else {
                i = false
            }
        }
        return {
            target: g,
            blTgtTreeType: i
        }
    },
    getSource: function(a, d, c) {
        var b;
        if (a.tree) {
            b = c.node
        } else {
            if (a.dataview || a.grid) {
                b = c.selections
            } else {
                return false
            }
        }
        return b
    },
    notifyDrop: function(w, s, y) {
        var c = this.webfm;
        var r = s.getTarget();
        if (r && (r = (Ext.fly(r).findParentNode("div.syno-sds-fs-win")))) {
            if (r !== this.webfm.owner.el.dom) {
                return false
            }
        }
        if (!w.dataview && !w.grid && !w.tree) {
            return false
        }
        var m, x;
        var g, u;
        if ((g = this.getTarget(w, s, y)) === false) {
            return false
        }
        u = g.blTgtTreeType;
        x = g.target;
        var f = u ? false : x.get("isdir");
        if (this.notifyOverAndDrop(w, s, y, c, f, g) === this.dropNotAllowed) {
            return false
        }
        if ((m = this.getSource(w, s, y)) === false) {
            return false
        }
        var a = (u) ? x.attributes.real_path : x.get("real_path");
        var z = _T("tree", "leaf_filebrowser");
        var h = SYNO.webfm.utils.isLocalSource(c.activeDS.storetype);
        var b = w.grid || w.dataview;
        var l = w.tree ? SYNO.webfm.utils.isLocalSource(m.attributes.type) : SYNO.webfm.utils.isLocalSource(b.getStore().storetype);
        if (h === l) {
            var k = h && Ext.isWindows ? "\\" : "/";
            if (w.tree) {
                if (SYNO.webfm.utils.isConflictTargetPath(m.attributes.real_path, a, k)) {
                    c.owner.getMsgBox().alert(z, _WFT("error", "error_select_conflict"));
                    return false
                }
            } else {
                if (w.grid || w.dataview) {
                    for (var q = 0; q < m.length; q++) {
                        var j = m[q].get("real_path");
                        if (SYNO.webfm.utils.isConflictTargetPath(j, a, k)) {
                            c.owner.getMsgBox().alert(z, _WFT("error", "error_select_conflict"));
                            return false
                        }
                    }
                }
            }
        }
        c.ddParams = {
            src: (w.tree) ? m.attributes.path : m,
            target: (u) ? x.attributes.path : x.get("file_id"),
            srcsource: (w.tree) ? m.attributes.type : b.getStore().storetype,
            srcnode: (w.tree) ? w.dragData.node : undefined
        };
        if ((b && b.getStore().storetype === SYNO.webfm.utils.source.remotes)) {
            Ext.apply(c.ddParams, {
                search_taskid: b.getStore().search_taskid,
                blsame: (!u) && (b === c.dataview)
            })
        }
        var p = (u) ? x.attributes.text : x.get("filename");
        p = "<b>[" + Ext.util.Format.ellipsis(Ext.util.Format.htmlEncode(p), 36) + "]</b>";
        var t = c.copymoveCtxMenu;
        var v = t.items;
        v.each(function(e) {
            e.enable();
            e.show()
        });
        var n = c.dirTree.getSelectionModel().getSelectedNode();
        var o, d;
        if (!h && l) {
            if (_S("demo_mode") === true) {
                c.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _JSLIBSTR("uicommon", "error_demo"));
                return false
            }
            if (!c.checkUploadRight(n)) {
                c.owner.getMsgBox().alert(_WFT("filetable", "filetable_upload"), _WFT("error", "error_privilege_not_enough"));
                return false
            }
            d = c.checkFtpModifyRight(n);
            if (d) {
                v.get("copy_overwrite").disable()
            }
            v.get("move_skip").hide();
            v.get("move_overwrite").hide();
            v.get("text").setText(String.format("<b>" + _WFT("filetable", "upload_ddtext") + "&nbsp</b>", Ext.util.Format.htmlEncode(p)));
            o = "upload"
        } else {
            if (h && !l) {
                if (c.checkFTPDownloadRight(n)) {
                    c.owner.getMsgBox().alert(_WFT("filetable", "filetable_download"), _WFT("error", "error_privilege_not_enough"));
                    return
                }
                d = c.checkFtpModifyRight(n);
                if (d || (this.isSrcReadOnly(w, m))) {
                    v.get("move_overwrite").disable();
                    v.get("move_skip").disable()
                }
                v.get("text").setText(String.format("<b>" + _WFT("download", "download_to") + "&nbsp</b>", p));
                o = "download"
            } else {
                if (this.isSrcReadOnly(w, m)) {
                    v.get("move_overwrite").disable();
                    v.get("move_skip").disable()
                }
                v.get("text").setText(p);
                o = "copymove"
            }
        }
        t.action = o;
        SYNO.webfm.SmartDDMVCPMgr.onAction(t, c, s);
        return true
    },
    isSrcReadOnly: function(a, b) {
        return ((a.tree && b.attributes && (b.attributes.type === SYNO.webfm.utils.source.remotev || b.attributes.isMountPoint)) || (a.grid && SYNO.webfm.utils.doesIncludeMountPoint(a.grid.getSelectionModel().getSelections())) || (a.grid && a.grid.owner && SYNO.webfm.utils.source.remotev === a.grid.owner.getCurrentSource()) || (a.dataview && SYNO.webfm.utils.doesIncludeMountPoint(a.dataview.getSelectionModel().getSelections())) || (a.dataview && a.dataview.owner && SYNO.webfm.utils.source.remotev === a.dataview.owner.getCurrentSource()))
    }
});
SYNO.webfm.utils.TreeDropZone = Ext.extend(Ext.tree.TreeDropZone, {
    onResetDragText: function(a, f, c) {
        var d = a.getProxy().getGhost();
        if (a.tree) {
            d.update("");
            c.node.ui.appendDDGhost(d.dom)
        } else {
            if (a.grid) {
                var b = a.grid.getDragDropText();
                d.update(b)
            } else {
                if (a.dataview) {
                    d.update(a.dataview.getDragDropText())
                }
            }
        }
    },
    onContainerOver: function(a, c, b) {
        if (this.allowContainerDrop && this.isValidDropPoint({
                ddel: this.tree.getRootNode().ui.elNode,
                node: this.tree.getRootNode()
            }, "append", a, c, b)) {
            return this.dropAllowed
        }
        this.onResetDragText(a, c, b);
        return this.dropNotAllowed
    },
    onNodeOut: function(d, a, c, b) {
        this.onResetDragText(a, c, b);
        this.cancelExpand();
        this.removeDropIndicators(d)
    },
    getDropPoint: function(c, d, b) {
        var a = SYNO.webfm.utils.TreeDropZone.superclass.getDropPoint.apply(this, arguments);
        if (d && d.node && d.node.parentNode && d.node.parentNode.id === "fm_fav_root") {
            return a
        }
        if (a === "above" || a === "below") {
            return "append"
        }
        return a
    }
});
SYNO.webfm.utils.parseDuration = function(b) {
    var a = {},
        e = SYNO.webfm.utils.durations;
    var d;
    for (var c in e) {
        if (e.hasOwnProperty(c)) {
            d = Math.floor(b / e[c]);
            if (d) {
                a[c] = (Ext.isNumber(d) && d < Number.MAX_VALUE) ? d : Number.MAX_VALUE;
                if (0 >= (b -= d * e[c])) {
                    break
                }
            }
        }
    }
    return a
};
SYNO.webfm.utils.fancyDuration = function(c) {
    var b = [],
        a = SYNO.webfm.utils.parseDuration(c);
    for (var d in a) {
        if (a.hasOwnProperty(d)) {
            var e = (a[d] > 9999) ? 9999 : a[d];
            b.push(e + " " + SYNO.webfm.utils.durationsAbbr[d])
        }
    }
    return b.join(", ")
};
SYNO.webfm.utils.durations = {
    days: 86400,
    hours: 3600,
    minutes: 60,
    seconds: 1
};
SYNO.webfm.utils.durationsAbbr = {
    days: _WFT("upload", "upload_time_day"),
    hours: _WFT("upload", "upload_time_hour"),
    minutes: _WFT("upload", "upload_time_min"),
    seconds: _WFT("upload", "upload_time_sec")
};
SYNO.webfm.utils.FieldFind = function(b, a) {
    var c = b.findField(a);
    if (!c) {
        c = Ext.getCmp(a)
    }
    return c
};
SYNO.webfm.utils.getRadioGroup = function(c, b) {
    var e = [];
    var d = c.el.query("input[name=" + b + "]");
    for (var a = 0; a < d.length; a++) {
        e.push(Ext.getCmp(d[a].id))
    }
    return e
};
SYNO.webfm.utils.EnableCheckGroup = Ext.extend(Object, {
    constructor: function(b, a, e, d) {
        var c = SYNO.webfm.utils.FieldFind(b, a);
        d = typeof(d) != "undefined" ? d : [];
        this.enable_fields = e;
        this.disable_fields = d;
        this.form = b;
        c.mon(c, "check", this.checkHandler, this);
        c.mon(c, "enable", this.enableHandler, this, {
            delay: 50
        });
        c.mon(c, "disable", this.enableHandler, this, {
            delay: 50
        });
        this.checkHandler(c, c.getValue())
    },
    setFieldStatus: function(d, g, c, a) {
        if (g.inputType == "radio") {
            var f = SYNO.webfm.utils.getRadioGroup(d, g.getName()),
                h;
            for (var b = 0; b < f.length; b++) {
                if (a) {
                    h = c ? f[b].disable() : f[b].enable()
                } else {
                    h = c ? f[b].enable() : f[b].disable()
                }
            }
        } else {
            var e;
            if (a) {
                e = c ? g.disable() : g.enable()
            } else {
                e = c ? g.enable() : g.disable()
            }
        }
    },
    checkHandler: function(c, b) {
        var a, d;
        for (a = 0; a < this.enable_fields.length; a++) {
            d = SYNO.webfm.utils.FieldFind(this.form, this.enable_fields[a]);
            this.setFieldStatus(this.form, d, b, false)
        }
        for (a = 0; a < this.disable_fields.length; a++) {
            d = SYNO.webfm.utils.FieldFind(this.form, this.disable_fields[a]);
            this.setFieldStatus(this.form, d, b, true)
        }
    },
    enableHandler: function(c) {
        var b, d;
        var a = (c.disabled === false && c.getValue() === true);
        for (b = 0; b < this.enable_fields.length; b++) {
            d = SYNO.webfm.utils.FieldFind(this.form, this.enable_fields[b]);
            this.setFieldStatus(this.form, d, a, false)
        }
        for (b = 0; b < this.disable_fields.length; b++) {
            d = SYNO.webfm.utils.FieldFind(this.form, this.disable_fields[b]);
            this.setFieldStatus(this.form, d, a, true)
        }
    }
});
SYNO.webfm.utils.getCmdCode = function() {
    var a = 224;
    if (Ext.isWebKit) {
        a = [91, 93]
    } else {
        if (Ext.isOpera) {
            a = 17
        }
    }
    return a
};
SYNO.webfm.utils.setSpaceTooltip = function(a) {
    if (!a || !a.additional) {
        return
    }
    var b = a.additional.volume_status;
    if (b && b.totalSpace && b.freeSpace) {
        a.qtip = String.format("{0}<br>{1}", a.qtip, String.format(_T("filetable", "space_size"), Ext.util.Format.fileSize(b.freeSpace), Ext.util.Format.fileSize(b.totalSpace)))
    }
};
SYNO.webfm.utils.NodeActionEnable = function() {
    var a = function(e) {
            return !(e.id == "fm_root" || e.id == "fm_local_root" || e.id === "fm_vd_root" || e.id === "fm_rf_root" || !e.parentNode || e.parentNode.id == "fm_root" || e.parentNode.id == "fm_local_root" || e.id === "fm_fav_root" || ((e.parentNode && e.parentNode.id === "fm_fav_root") && e.attributes.status === "broken"))
        },
        c = function(g) {
            if (!a(g)) {
                return false
            }
            var f = SYNO.webfm.utils.isLocalSource(g.attributes.type);
            var e = g.attributes.type === SYNO.webfm.utils.source.remotev || g.attributes.mountType === "iso" || g.attributes.is_snapshot;
            var i = e || (g.parentNode && g.parentNode.id === "fm_rf_root");
            var h = !f && g.parentNode && g.parentNode.id == "fm_fav_root";
            return !h && !i
        },
        d = function(f) {
            if (!a(f)) {
                return false
            }
            var e = f.attributes.type === SYNO.webfm.utils.source.remotev || f.attributes.mountType === "iso";
            var g = e || (f.parentNode && f.parentNode.id === "fm_rf_root");
            return !SYNO.FileStation.Clipboard.isEmpty() && !g
        },
        b = function(f) {
            if (!a(f)) {
                return false
            }
            var e = SYNO.webfm.utils.isLocalSource(f.attributes.type);
            var g = !e && f.parentNode && f.parentNode.id == "fm_fav_root";
            return !g
        };
    return {
        isEnableCut: c,
        isEnableDelete: c,
        isEnableRename: c,
        isEnableCopy: b,
        isEnablePaste: d
    }
}();
SYNO.webfm.utils.ShowHideMenu = function(b) {
    var c = false,
        e = null,
        d, a;
    b.each(function(g) {
        if (g instanceof Ext.menu.Separator) {
            g.show()
        }
    });
    for (d = 0, a = b.length; d >= 0 && d < a; d++) {
        var f = b.get(d);
        if (f instanceof Ext.menu.Separator && !f.hidden) {
            if (c || d === 0) {
                f.hide()
            } else {
                e = f
            }
            c = true
        } else {
            if (!f.hidden) {
                c = false;
                e = null
            }
        }
    }
    if (e) {
        e.hide()
    }
};
SYNO.webfm.utils.GetIconvCodepageList = function() {
    var a = [
        ["BIG5", _WFT("codepage", "chinese_traditional") + " (BIG5)"],
        ["BIG5-HKSCS", _WFT("codepage", "chinese_traditional") + " (BIG5-HKSCS)"],
        ["GBK", _WFT("codepage", "chinese_simplified") + " (GBK)"],
        ["GB18030", _WFT("codepage", "chinese_simplified") + " (GB18030)"],
        ["EUC-JP", _WFT("codepage", "japanese") + " (EUC-JP)"],
        ["SHIFT_JIS", _WFT("codepage", "japanese") + " (SHIFT_JIS)"],
        ["ISO-2022-JP", _WFT("codepage", "japanese") + " (ISO-2022-JP)"],
        ["EUC-KR", _WFT("codepage", "korean") + " (EUC-KR)"],
        ["CP949", _WFT("codepage", "korean") + " (CP949)"],
        ["CP1258", _WFT("codepage", "vietnamese") + " (CP1258)"],
        ["VISCII", _WFT("codepage", "vietnamese") + " (VISCII)"],
        ["TIS-620", _WFT("codepage", "thai") + " (TIS-620)"],
        ["ISO-8859-11", _WFT("codepage", "thai") + " (ISO-8859-11)"],
        ["ISO-8859-2", _WFT("codepage", "central_european") + " (ISO-8859-2)"],
        ["CP1250", _WFT("codepage", "central_european") + " (CP1250)"],
        ["ISO-8859-10", _WFT("codepage", "nordic") + " (ISO-8859-10)"],
        ["ISO-8859-1", _WFT("codepage", "western") + " (ISO-8859-1)"],
        ["ISO-8859-15", _WFT("codepage", "western") + " (ISO-8859-15)"],
        ["CP1252", _WFT("codepage", "western") + " (CP1252)"],
        ["Macintosh", _WFT("codepage", "western") + " (Macintosh)"],
        ["CP1254", _WFT("codepage", "turkish") + " (CP1254)"],
        ["CP1255", _WFT("codepage", "hebrew") + " (CP1255)"],
        ["ISO-8859-8", _WFT("codepage", "hebrew") + " (ISO-8859-8)"],
        ["ISO-8859-7", _WFT("codepage", "greek") + " (ISO-8859-7)"],
        ["CP1253", _WFT("codepage", "greek") + " (CP1253)"],
        ["CP1256", _WFT("codepage", "arabic") + " (CP1256)"],
        ["ISO-8859-6", _WFT("codepage", "arabic") + " (ISO-8859-6)"],
        ["ISO-8859-4", _WFT("codepage", "baltic") + " (ISO-8859-4)"],
        ["ISO-8859-13", _WFT("codepage", "baltic") + " (ISO-8859-13)"],
        ["CP1257", _WFT("codepage", "baltic") + " (CP1257)"],
        ["ISO-8859-3", _WFT("codepage", "south_european") + " (ISO-8859-3)"],
        ["ISO-8859-5", _WFT("codepage", "cyrillic") + " (ISO-8859-5)"],
        ["CP1251", _WFT("codepage", "cyrillic") + " (CP1251)"],
        ["KOI8-R", _WFT("codepage", "cyrillic") + " (KOI8-R)"],
        ["KOI8-U", _WFT("codepage", "cyrillic") + " (KOI8-U)"],
        ["ISO-8859-14", _WFT("codepage", "celtic") + " (ISO-8859-14)"],
        ["ISO-8859-16", _WFT("codepage", "romanian") + " (ISO-8859-16)"],
        ["ARMSCII-8", _WFT("codepage", "armenian") + " (ARMSCII-8)"],
        ["Georgian-Academy", _WFT("codepage", "georgian") + " (Georgian-Academy)"],
        ["KOI8-T", _WFT("codepage", "tajik") + " (KOI8-T)"],
        ["CP1133", _WFT("codepage", "laotian") + " (CP1133)"],
        ["PT154", _WFT("codepage", "kazakh") + " (PT154)"]
    ];
    a.sort(function(d, c) {
        return d[1].localeCompare(c[1])
    });
    a.unshift(["UTF-16", _WFT("codepage", "unicode") + " (UTF-16)"]);
    a.unshift(["UTF-8", _WFT("codepage", "unicode") + " (UTF-8)"]);
    return a
};
SYNO.webfm.utils.getLastModifiedTime = function(a) {
    return (a.lastModifiedDate) ? a.lastModifiedDate.getTime() : a.lastModified
};
Ext.apply(SYNO.webfm.utils, {
    icon_type: ["acc", "ai", "avi", "bmp", "doc", "exe", "fla", "folder", "gif", "htm", "indd", "iso", "jpg", "js", "misc", "mp3", "pdf", "png", "ppt", "psd", "rar", "swf", "tar", "ttf", "txt", "wma", "xls", "ico", "tif", "tiff", "ufo", "raw", "arw", "srf", "sr2", "dcr", "k25", "kdc", "cr2", "crw", "nef", "mrw", "ptx", "pef", "raf", "3fr", "erf", "mef", "mos", "orf", "rw2", "dng", "x3f", "jpe", "jpeg", "html", "3gp", "3g2", "asf", "dat", "divx", "dvr-ms", "m2t", "m2ts", "m4v", "mkv", "mp4", "mts", "mov", "qt", "tp", "trp", "ts", "vob", "wmv", "xvid", "ac3", "amr", "rm", "rmvb", "ifo", "mpeg", "mpg", "mpe", "m1v", "m2v", "mpeg1", "mpeg2", "mpeg4", "ogv", "webm", "m3u", "aiff", "wpl", "aac", "flac", "m4a", "m4b", "aif", "ogg", "pcm", "wav", "cda", "mid", "mp2", "mka", "mpc", "ape", "ra", "ac3", "dts", "bin", "img", "mds", "nrg", "daa", "docx", "wri", "rtf", "xla", "xlb", "xlc", "xld", "xlk", "xll", "xlm", "xlt", "xlv", "xlw", "xlsx", "xlsm", "xlsb", "xltm", "xlam", "pptx", "pps", "ppsx", "ade", "adp", "adn", "accdr", "accdb", "accdt", "mdb", "mda", "mdn", "mdt", "mdw", "mdf", "mde", "accde", "mam", "maq", "mar", "mat", "maf", "flv", "f4v", "7z", "bz2", "gz", "zip", "tgz", "tbz", "ttc", "otf", "css", "actproj", "ad", "akp", "applescript", "as", "asax", "asc", "ascx", "asm", "asmx", "asp", "aspx", "asr", "bkpi", "c", "cc", "php", "jsx", "xml", "xhtml", "mhtml", "cpp", "cs", "cxx", "odoc", "osheet", "oslides"],
    archive_type: ["zip", "gz", "tar", "tgz", "tbz", "bz2", "rar", "7z", "iso"],
    image_type: ["iso"],
    DocumentFileTypes: "docx,wri,rtf,xla,xlb,xlc,xld,xlk,xll,xlm,xlt,xlv,xlw,xlsx,xlsm,xlsb,xltm,xlam,pptx,pps,ppsx,pdf,txt,doc,xls,ppt,odt,ods,odp,odg,odc,odf,odb,odi,odm,ott,ots,otp,otg,otc,otf,oti,oth,potx,pptm,ppsm,potm,dotx,dot,pot,ppa,xltx,docm,dotm,eml,msgc,c,cc,cpp,cs,cxx,ada,coffee,cs,css,js,json,lisp,markdown,ocaml,pl,py,rb,sass,scala,r,tex,conf,csv,sub,srt,md,log",
    ImageFileTypes: "ico,tif,tiff,ufo,raw,arw,srf,sr2,dcr,k25,kdc,cr2,crw,nef,mrw,ptx,pef,raf,3fr,erf,mef,mos,orf,rw2,dng,x3f,jpg,jpg,jpeg,png,gif,bmp,psd",
    VideoFileTypes: "3gp,3g2,asf,dat,divx,dvr-ms,m2t,m2ts,m4v,mkv,mp4,mts,mov,qt,tp,trp,ts,vob,wmv,xvid,ac3,amr,rm,rmvb,ifo,mpeg,mpg,mpe,m1v,m2v,mpeg1,mpeg2,mpeg4,ogv,webm,flv,avi,swf,f4v",
    AudioFileTypes: "aac,flac,m4a,m4b,aif,ogg,pcm,wav,cda,mid,mp2,mka,mpc,ape,ra,ac3,dts,wma,mp3,mp1,mp2,mpa,ram,m4p,aiff,dsf,dff,m3u,wpl,aiff",
    WebPageFileTypes: "html,htm,css,actproj,ad,akp,applescript,as,asax,asc,ascx,asm,asmx,asp,aspx,asr,jsx,xml,xhtml,mhtml,cs,js",
    DiscFileTypes: "bin,img,mds,nrg,daa,iso",
    ZippedFileTypes: "7z,bz2,gz,zip,tgz,tbz,rar,tar"
});
SYNO.webfm.utils.DateTimeFormatter = function(c, a) {
    if (SYNO.SDS.DateTimeFormatter) {
        return SYNO.SDS.DateTimeFormatter(c, a)
    }
    if (!c || Object.prototype.toString.call(c) !== "[object Date]") {
        return ""
    }
    var b = a && a.type,
        d;
    if (b === "date") {
        d = "Y-m-d"
    } else {
        if (b === "time") {
            d = "H:i"
        } else {
            if (b === "timesec") {
                d = "H:i:s"
            } else {
                if (b === "datetimesec") {
                    d = "Y-m-d H:i:s"
                } else {
                    if (b === "datetimesecms") {
                        d = "Y-m-d H:i:s.u"
                    } else {
                        d = "Y-m-d H:i"
                    }
                }
            }
        }
    }
    return c.format(d)
};
SYNO.webfm.utils.GetDateFormat = function() {
    if (SYNO.SDS.DateTimeUtils && SYNO.SDS.DateTimeUtils.GetDateFormat) {
        return SYNO.SDS.DateTimeUtils.GetDateFormat()
    }
    return "Y-m-d"
};
SYNO.webfm.utils.showMessage = function(a, b) {
    a.toastBox = new SYNO.SDS.ToastBox({
        text: b,
        owner: a,
        delay: 2500
    });
    a.toastBox.show()
};
SYNO.webfm.utils.buildSharingQRCodeMail = function(c, a) {
    var b = "",
        d = function(e, g) {
            var f = g ? '<img src="' + g + '"></img>' : "";
            return f + "<div>" + Ext.util.Format.htmlEncode(e) + "</div>"
        };
    if (Ext.isArray(c)) {
        Ext.iterate(c, function(f, e) {
            b += d(f, a[e])
        }, this)
    } else {
        b = d(c, a)
    }
    SYNO.SDS.AppLaunch("SYNO.SDS.App.MailDialog.Application", {
        content: b
    })
};
SYNO.webfm.utils.getTicketID = function(c) {
    var b = c.api,
        a = c.methods;
    if (SYNO.webfm.utils.tids[b]) {
        return SYNO.webfm.utils.tids[b]
    }
    if (!Ext.isArray(a) || a.length === 0) {
        return null
    }
    SYNO.API.Request({
        api: "SYNO.API.Auth.Key",
        version: 7,
        method: "grant",
        async: false,
        timeout: 10,
        params: {
            allow_api: b,
            allow_methods: a
        },
        callback: function(e, d) {
            if (e) {
                SYNO.webfm.utils.tids[b] = d.tid
            }
        }
    });
    return SYNO.webfm.utils.tids[b]
};