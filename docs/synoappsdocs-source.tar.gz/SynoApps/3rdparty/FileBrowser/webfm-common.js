/* Copyright (c) 2020 Synology Inc. All rights reserved. */

Ext.ns("SYNO.SDS");
Ext.data.Connection.prototype.timeout = 120000;
Ext.form.BasicForm.prototype.timeout = 120;