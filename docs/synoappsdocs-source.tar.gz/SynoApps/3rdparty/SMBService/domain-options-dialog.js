/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.SMBService.Domain.OptionsDialog
 * @extends SYNO.SDS.ModalWindow
 * SMBService options dialog class
 *
 */
Ext.define("SYNO.SDS.SMBService.Domain.OptionsDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.module = a.module;
        this.form = new SYNO.SDS.SMBService.Domain.OptionsForm({
            owner: this,
            itemId: "formpanel",
            domainEnable: a.domainEnable,
            is_dc: a.is_dc,
            module: a.module
        });
        this.data = {};
        var b = Ext.apply({
            title: _T("network", "domain_options"),
            autoDestroy: true,
            width: 630,
            autoHeight: true,
            layout: "fit",
            border: false,
            items: [this.form],
            buttons: [{
                btnStyle: "blue",
                text: _T("common", "commit"),
                disabled: this._S("demo_mode"),
                tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                scope: this,
                handler: this.apply
            }, {
                btnStyle: "grey",
                text: _T("common", "cancel"),
                scope: this,
                handler: this.close
            }]
        }, a);
        this.callParent([b])
    },
    onOpen: function(a) {
        this.callParent(arguments);
        this.load()
    },
    load: function() {
        this.form.load()
    },
    apply: function() {
        this.form.apply()
    }
});
Ext.define("SYNO.SDS.SMBService.Domain.OptionsForm", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(a) {
        this.module = a.module;
        this.domainEnable = a.domainEnable;
        this.is_dc = a.is_dc;
        var b = Ext.apply({
            border: false,
            trackResetOnLoad: true,
            labelWidth: 340,
            height: 235,
            width: 200,
            items: [{
                xtype: "syno_checkbox",
                name: "enable_sync_time",
                itemId: "enable_sync_time",
                boxLabel: _T("domain", "domain_options_sync_time"),
                value: false,
                disabled: this.is_dc
            }, {
                xtype: "syno_checkbox",
                name: "enable_rpc_enum_usergroup",
                itemId: "enable_rpc_enum_usergroup",
                boxLabel: _T("domain", "enable_rpc_enum_usergroup"),
                disabled: this.is_dc
            }, {
                xtype: "syno_checkbox",
                name: "direct_connect_trust",
                boxLabel: _T("domain", "direct_connect_trust"),
                disabled: this.is_dc
            }, {
                xtype: "syno_combobox",
                name: "encrypt_ad_ldap",
                fieldLabel: _T("domain", "encrypt_ad_ldap"),
                forceSelection: true,
                store: new Ext.data.JsonStore({
                    fields: ["display", "value"],
                    data: [{
                        display: _T("ldap", "with_sasl"),
                        value: "sasl"
                    }, {
                        display: _T("ldap", "with_ssl"),
                        value: "ssl"
                    }]
                }),
                value: "sasl",
                editable: false,
                displayField: "display",
                disabled: this.is_dc,
                valueField: "value"
            }, {
                xtype: "syno_numberfield",
                name: "domain_nested_group",
                fieldLabel: _T("domain", "domain_nested_group"),
                maxlength: 2,
                minValue: 1,
                width: 80,
                allowBlank: false,
                disabled: this.is_dc
            }, {
                xtype: "syno_button",
                itemId: "domain_admin_list",
                btnStyle: "default",
                text: _T("network", "domain_set_admin"),
                handler: this.openAdminList,
                disabled: !this.domainEnable,
                scope: this
            }]
        }, a);
        SYNO.LayoutConfig.fill(b);
        this.callParent([b])
    },
    confirmSyncTime: function(a, b) {
        if (!b) {
            return
        }
        this.ownerCt.ownerCt.getMsgBox().confirm(_T("controlpanel", "directory_service_title"), _T("domain", "domain_options_sync_time_enable_warn"), function(c) {
            if ("cancel" === c) {
                this.getComponent("enable_sync_time").setValue(false)
            }
        }, this, Ext.MessageBox.OKCANCEL)
    },
    confirmRpcEnum: function(a, b) {
        if (!b) {
            return
        }
        this.ownerCt.ownerCt.getMsgBox().confirm(_T("controlpanel", "directory_service_title"), _T("domain", "enable_rpc_enum_usergroup_warn"), function(c) {
            if ("cancel" === c) {
                this.getComponent("enable_rpc_enum_usergroup").setValue(false)
            }
        }, this, Ext.MessageBox.OKCANCEL)
    },
    load: function() {
        this.setStatusBusy();
        this.sendWebAPI({
            params: {},
            compound: {
                stopwhenerror: false,
                params: [{
                    api: "SYNO.Core.Directory.Domain.Conf",
                    method: "get",
                    version: 2
                }]
            },
            callback: this.loadDataCB,
            scope: this
        })
    },
    openAdminList: function() {
        var a = new SYNO.SDS.SMBService.Domain.DirectoryAdminDialog({
            owner: this.owner,
            module: this,
            authType: "domain"
        });
        a.load()
    },
    errorHandling: function(c) {
        var b = SYNO.API.Response.GetFirstError(c);
        var a = _T("common", "commfail");
        if (SYNO.API.Erros.core[b.code]) {
            a = SYNO.API.Erros.core[b.code]
        }
        this.getMsgBox().alert(_T("network", "wnds_domain"), a)
    },
    loadDataCB: function(a, c, b) {
        this.clearStatusBusy();
        if (true === c.isTimeout) {
            this.getMsgBox().alert(_T("network", "wnds_domain"), _T("network", "domain_join_err"));
            return
        } else {
            if (true === c.has_fail) {
                this.errorHandling(c);
                return
            }
        }
        if (c.result[0].data.encrypt_ad_ldap && "off" === c.result[0].data.encrypt_ad_ldap) {
            c.result[0].data.encrypt_ad_ldap = _T("ldap", "no_ssl")
        }
        this.getForm().setValues(c.result[0].data);
        this.mon(this.getComponent("enable_sync_time"), "check", this.confirmSyncTime, this);
        this.mon(this.getComponent("enable_rpc_enum_usergroup"), "check", this.confirmRpcEnum, this)
    },
    applyDataCB: function(c, b, a) {
        this.clearStatusBusy();
        if (true === b.isTimeout) {
            this.getMsgBox().alert(_T("network", "wnds_domain"), _T("network", "domain_join_err"));
            return
        } else {
            if (true === b.has_fail) {
                this.errorHandling(b);
                return
            } else {
                this.owner.close()
            }
        }
    },
    apply: function() {
        var b = this.getForm();
        if (!b.isDirty()) {
            this.owner.close();
            return
        }
        if (!b.isValid()) {
            this.setStatusError({
                text: _T("common", "forminvalid"),
                clear: true
            });
            return false
        }
        var a = b.getValues();
        if (a.encrypt_ad_ldap === _T("ldap", "no_ssl")) {
            a.encrypt_ad_ldap = "off"
        }
        this.setStatusBusy();
        this.sendWebAPI({
            params: {},
            compound: {
                stopwhenerror: false,
                params: [{
                    api: "SYNO.Core.Directory.Domain.Conf",
                    method: "set",
                    version: 2,
                    params: a
                }]
            },
            callback: this.applyDataCB,
            scope: this
        })
    }
});
