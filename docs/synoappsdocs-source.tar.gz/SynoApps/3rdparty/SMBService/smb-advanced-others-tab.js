/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.SMBService.SMB.OthersTab
 * @extends SYNO.SDS.Utils.FormPanel
 * SMBService others tab class
 *
 */
Ext.define("SYNO.SDS.SMBService.SMB.OthersTab", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(a) {
        this.module = a.module;
        var b = Ext.apply(this.fillConfig(), a);
        this.callParent([b]);
        this.on("afterlayout", function() {
            this.enableVetoFileGroupDummy = new SYNO.ux.Utils.EnableCheckGroup(this.getForm(), "enable_vetofile", ["vetofile", "enable_delete_vetofiles"]);
            this.enableSymLinkGroupDummy = new SYNO.ux.Utils.EnableCheckGroup(this.getForm(), "enable_symlink", ["enable_widelink"])
        }, this, {
            single: true
        })
    },
    loadConfirmHook: function(a) {
        this.mon(this.getComponent("enable_vetofile"), "check", this.confirmVetofile, this);
        this.mon(this.getComponent("enable_symlink"), "check", this.confirmSymLink, this);
        this.mon(this.getComponent("enable_widelink"), "check", this.confirmWideLink, this);
        this.mon(this.getComponent("enable_local_master_browser"), "check", this.confirmLocalMasterBrowser, this)
    },
    fillConfig: function() {
        var a = {
            autoscroll: true,
            title: _T("network", "smb_others"),
            border: false,
            itemId: "others_tab",
            trackResetOnLoad: true,
            height: 430,
            width: 250,
            padding: 8,
            labelWidth: 250,
            items: [{
                xtype: "syno_checkbox",
                name: "enable_local_master_browser",
                itemId: "enable_local_master_browser",
                boxLabel: _T("network", "network_lmb_enable")
            }, {
                xtype: "syno_checkbox",
                name: "enable_dirsort",
                boxLabel: _T("network", "smb_enable_dirsort")
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                value: _T("network", "smb_enable_dirsort_desc")
            }, {
                xtype: "syno_checkbox",
                name: "enable_vetofile",
                itemId: "enable_vetofile",
                boxLabel: _T("network", "smb_enable_vetofile")
            }, {
                xtype: "syno_textfield",
                name: "vetofile",
                itemId: "vetofile",
                regex: /^(\/[^\/]+)+\/$/,
                indent: 1,
                width: 200,
                fieldLabel: _T("network", "smb_vetofile_list"),
                emptyText: "/*.txt/README/",
                allowBlank: false
            }, {
                xtype: "syno_checkbox",
                name: "enable_delete_vetofiles",
                itemId: "enable_delete_vetofiles",
                indent: 1,
                boxLabel: _T("network", "smb_delete_vetofiles")
            }, {
                xtype: "syno_checkbox",
                name: "enable_symlink",
                itemId: "enable_symlink",
                boxLabel: _T("network", "smb_enable_symlink")
            }, {
                xtype: "syno_checkbox",
                name: "enable_widelink",
                itemId: "enable_widelink",
                indent: 1,
                boxLabel: _T("network", "smb_enable_widelink")
            }, {
                xtype: "syno_checkbox",
                name: "enable_msdfs",
                boxLabel: _T("network", "smb_enable_msdfs")
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                value: _T("network", "smb_enable_msdfs_desc")
            }, {
                xtype: "syno_checkbox",
                name: "enable_reset_on_zero_vc",
                itemId: "enable_reset_on_zero_vc",
                boxLabel: _T("network", "smb_reset_on_zero_vc")
            }, {
                xtype: "syno_checkbox",
                name: "enable_enhance_log",
                boxLabel: _T("network", "smb_enhance_log")
            }, {
                xtype: "syno_checkbox",
                name: "enable_mask",
                boxLabel: _T("common", "apply_default_umask")
            }, {
                xtype: "syno_checkbox",
                name: "disable_strict_allocate",
                itemId: "disable_strict_allocate",
                boxLabel: _T("network", "smb_disable_strict_allocate")
            }, {
                xtype: "syno_checkbox",
                name: "syno_wildcard_search",
                itemId: "syno_wildcard_search",
                boxLabel: _T("network", "syno_wildcard_search")
            }]
        };
        return a
    },
    confirmVetofile: function(a, b) {
        if (!b) {
            this.getComponent("enable_delete_vetofiles").setValue(false)
        }
    },
    confirmSymLink: function(b, c) {
        if (c) {
            return
        }
        if (true === this.ownerCt.macTab.getComponent("enable_syno_catia").getValue()) {
            var a = _T("network", "cifs_disable_symlink_warn") + "<p />" + _T("network", "cifs_disable_catia_warn");
            a = a + "<p />" + _T("common", "cfrm_continue");
            this.ownerCt.ownerCt.getMsgBox().confirm(_T("tree", "leaf_winmacnfs"), a, function(d) {
                if ("no" == d) {
                    this.getComponent("enable_symlink").setValue(true)
                } else {
                    var e = this.ownerCt.macTab.getComponent("enable_syno_catia");
                    e.suspendEvents(false);
                    e.setValue(false);
                    e.resumeEvents();
                    this.getComponent("enable_widelink").setValue(false)
                }
            }, this)
        } else {
            this.getComponent("enable_widelink").setValue(false)
        }
    },
    confirmWideLink: function(a, b) {
        if (!b || !this.getForm().isDirty()) {
            return
        }
        this.ownerCt.ownerCt.getMsgBox().confirm(_T("tree", "leaf_winmacnfs"), _T("common", "warning_option_affects_security"), function(c) {
            if ("no" == c) {
                this.getComponent("enable_widelink").setValue(false)
            }
        }, this)
    },
    confirmLocalMasterBrowser: function(a, b) {
        if (b === true) {
            this.ownerCt.ownerCt.getMsgBox().alert(_T("tree", "leaf_winmacnfs"), _T("network", "cifs_lmb_enable_warm"))
        }
    }
});
