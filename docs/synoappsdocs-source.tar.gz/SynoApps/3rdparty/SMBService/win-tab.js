/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.SMBService.SMB.WinTab
 * @extends SYNO.SDS.Utils.FormPanel
 * SMBService win tab class
 *
 */
Ext.define("SYNO.SDS.SMBService.SMB.WinTab", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(a) {
        this.module = a.module;
        var b = this.fillConfig(a);
        this.domainEnabled = false;
        this.smbTMEnable = false;
        this.callParent([b]);
        this.winHelpBox = Ext.getCmp(this.winHelpBox);
        this.on("afterlayout", this.onPanelAfterLayout, this, {
            single: true
        })
    },
    onPanelAfterLayout: function(a, b) {
        var c = this.getSMBAPIInfo();
        if (1 === c.maxVersion) {
            this.checkEnableSamba = new SYNO.ux.Utils.EnableCheckGroup(a.getForm(), "enable_samba", ["smb_transfer_log_enable", "disable_shadow_copy"])
        } else {
            if (2 === c.maxVersion) {
                this.checkEnableSamba = new SYNO.ux.Utils.EnableCheckGroup(a.getForm(), "enable_samba", ["enable_smb2", "smb_transfer_log_enable", "disable_shadow_copy"])
            } else {
                this.checkEnableSamba = new SYNO.ux.Utils.EnableCheckGroup(a.getForm(), "enable_samba", ["smb_transfer_log_enable", "disable_shadow_copy", "enable_access_based_share_enum"]);
                this.checkEnableXferlog = new SYNO.ux.Utils.EnableCheckGroup(a.getForm(), "smb_transfer_log_enable", [this.smbLogSettingsBtnId])
            }
        }
        a.mon(a.getForm().findField("enable_samba"), "check", function(d, f) {
            if (2 === c.maxVersion) {
                var e = this.getForm().findField("enable_smb2").getValue();
                this.getForm().findField("enable_large_mtu").setDisabled(!(!!f && !!e))
            }
            this.getComponent("winFieldset").getComponent("advanceBtnId").setDisabled(!f);
            this.setWinHelpBoxVisible(!!f)
        }, this);
        if (this._D("support_share_snapshot", "no") === "no" || this._D("support_btrfs", "no") === "no") {
            a.getForm().findField("disable_shadow_copy").hide()
        }
    },
    setWinHelpBoxVisible: function(a) {
        this.winHelpBox.setVisible(a);
        this.doLayout()
    },
    fillConfig: function(a) {
        var b = {
            title: _T("network", "wnds_file_service"),
            autoScroll: true,
            items: [this.createWinTabObj(a), this.createWSTransferTabObj(a)]
        };
        Ext.apply(b, a);
        return b
    },
    createWinTabObj: function(a) {
        var c = {
            xtype: "syno_fieldset",
            stateId: "SYNO.SDS.SMBService.SMB.WinTab::smb::smb",
            title: _T("network", "wnds_file_service"),
            webapi: {
                api: "SYNO.Core.FileServ.SMB",
                methods: {
                    get: "get",
                    set: "set"
                },
                version: 1
            },
            itemId: "winFieldset",
            collapsible: true,
            items: [{
                xtype: "syno_checkbox",
                name: "enable_samba",
                itemId: "enable_samba",
                boxLabel: _T("network", "samba_enable"),
                listeners: {
                    check: {
                        scope: this,
                        fn: this.onSambaCheckHandler
                    }
                }
            }, {
                xtype: "syno_textfield",
                indent: 1,
                style: "text-transform: uppercase;",
                itemId: "workgroup",
                name: "workgroup",
                fieldLabel: _T("network", "wnds_group"),
                vtype: "workgroup",
                maxlength: 15,
                allowBlank: false,
                validator: this.workgroupValidator
            }, {
                xtype: "syno_displayfield",
                itemId: "workgroup_in_domain",
                fieldLabel: "Note",
                hideLabel: true,
                hidden: true,
                indent: 1,
                name: "workgroup_in_domain",
                htmlEncode: false,
                value: '<span class="syno-ux-note">' + _T("common", "note") + _T("common", "colon") + " </span>" + _T("network", "workgroup_in_domain")
            }, {
                xtype: "syno_checkbox",
                indent: 1,
                name: "enable_smb2_and_large_mtu",
                boxLabel: _T("network", "cifs_smb2_large_mtu_enable")
            }, {
                xtype: "syno_checkbox",
                indent: 1,
                name: "disable_shadow_copy",
                boxLabel: _T("network", "smb_disable_shadow_copy")
            }, {
                xtype: "syno_checkbox",
                indent: 1,
                name: "enable_access_based_share_enum",
                boxLabel: _T("network", "smb_access_based_share_enum")
            }, {
                xtype: "syno_checkbox",
                indent: 1,
                itemId: "smb_transfer_log_enable",
                name: "smb_transfer_log_enable",
                boxLabel: _T("service", "service_smb_transfer_log"),
                listeners: {
                    enable: {
                        scope: this,
                        fn: function(e) {
                            var h = this.getSMBAPIInfo();
                            if (3 <= h.maxVersion) {
                                var g = this.getComponent("winFieldset");
                                var f = g.getComponent("enable_samba");
                                if (true === f.originalValue && true === e.originalValue) {
                                    Ext.getCmp(this.smbLogBtnId).setDisabled(false)
                                }
                            }
                        }
                    },
                    disable: {
                        scope: this,
                        fn: function() {
                            var e = this.getSMBAPIInfo();
                            if (3 <= e.maxVersion) {
                                Ext.getCmp(this.smbLogBtnId).setDisabled(true)
                            }
                        }
                    },
                    check: {
                        scope: this,
                        fn: function(e) {
                            if (3 <= d.maxVersion) {
                                var g = this.getComponent("winFieldset");
                                var f = g.getComponent("enable_samba");
                                if (true === f.checked && false === e.originalValue && true === e.checked) {
                                    this.onSmbLogSettingBtnClick()
                                }
                            }
                        }
                    }
                }
            }, {
                xtype: "syno_compositefield",
                hideLabel: true,
                indent: 2,
                items: [{
                    xtype: "syno_button",
                    btnStyle: "default",
                    itemId: "smbCmdBtn",
                    name: "smbCmdBtn",
                    id: this.smbLogSettingsBtnId = Ext.id(),
                    text: _T("service", "transfer_log_settings"),
                    autoWidth: true,
                    scope: this,
                    handler: this.onSmbLogSettingBtnClick
                }, {
                    xtype: "syno_button",
                    btnStyle: "default",
                    itemId: "smbLogBtn",
                    name: "smbLogBtn",
                    id: this.smbLogBtnId = Ext.id(),
                    text: _T("log", "log_subtitle"),
                    autoWidth: true,
                    handler: function() {
                        SYNO.SDS.AppLaunch("SYNO.SDS.LogCenter.BuiltIn", {
                            logType: "fileTransfer",
                            protocol: "smbxfer"
                        })
                    }
                }]
            }, {
                xtype: "spacer",
                height: 18
            }, {
                xtype: "syno_button",
                btnStyle: "default",
                name: "advanceBtnId",
                itemId: "advanceBtnId",
                text: _T("common", "adv_setting"),
                autoWidth: true,
                indent: 1,
                style: {
                    marginBottom: "0px"
                },
                scope: this,
                handler: this.onSmbAdvSettingBtnClick
            }, {
                xtype: "spacer",
                height: 18
            }, {
                xtype: "syno_displayfield",
                itemId: "sambaNoteId",
                fieldLabel: "Note",
                hideLabel: true,
                indent: 1,
                htmlEncode: false,
                value: '<span class="syno-ux-note">' + _T("common", "note") + _T("common", "colon") + ' </span><br><ul style="list-style-type: disc; list-style-position: outside; margin-left: 16px;"><li>' + String.format(_T("share", "share_recycle_bin_win_desc"), '<a id="' + Ext.id() + '" class="link-font" href="">' + _T("helptoc", "share") + "</a>") + "</li><li>" + String.format(_T("fileindex", "fileindex_spotlight_win_desc"), '<a id="' + Ext.id() + '" class="link-font" href="">' + _T("fileindex", "indexed_folder_list") + "</a>") + "</li></ul>",
                listeners: {
                    render: function(e) {
                        var g = e.el.select("a");
                        var h = g.item(0);
                        if (h) {
                            this.mon(h, "click", function(i) {
                                i.preventDefault();
                                SYNO.SDS.SMBService.SMB.WinTab.Utils.onClickShareUrl(this.module.appWin)
                            }, this)
                        }
                        var f = g.item(1);
                        if (f) {
                            this.mon(f, "click", function(i) {
                                i.preventDefault();
                                SYNO.SDS.SMBService.SMB.WinTab.Utils.onClickFileIndexUrl(this.module.appWin)
                            }, this)
                        }
                    },
                    scope: this,
                    single: true,
                    buffer: 80
                }
            }, {
                xtype: "box",
                hidden: "true",
                id: this.winHelpBox = Ext.id(),
                htmlEncode: false,
                tpl: new Ext.XTemplate('<div class="syno_fileservice_container"><div><div class="description normal-font" tabIndex="0" aria-labelledby="{this.promptId}"><span id="{this.promptId}">' + _T("network", "share_access_prompt") + '</span></div><div class="content" tabIndex="0" aria-labelledby="{this.promptPcId} {this.promptPcHostnameId}"><span id="{this.promptPcId}" class="title normal-font">' + _T("network", "share_access_prompt_pc") + " (" + _T("network", "windows_explorer") + ")" + _T("common", "colon") + '</span><span id="{this.promptPcHostnameId}" class="info allowDefCtxMenu link-font" style="text-decoration: none">&#92;&#92;{hostname}</span></div><div class="content" tabIndex="0" aria-labelledby="{this.promptMacId} {this.promptMacHostnameId}"><span id="{this.promptMacId}" class="title normal-font">' + _T("network", "share_access_prompt_mac") + " (" + _T("network", "mac_finder") + ")" + _T("common", "colon") + '</span><span id="{this.promptMacHostnameId}" class="info allowDefCtxMenu link-font" style="text-decoration: none">smb://{hostname}</span></div></div></div>', {
                    promptId: Ext.id(),
                    promptPcId: Ext.id(),
                    promptPcHostnameId: Ext.id(),
                    promptMacId: Ext.id(),
                    promptMacHostnameId: Ext.id()
                })
            }]
        };
        var d = this.getSMBAPIInfo();
        if (2 === d.maxVersion) {
            var b = [{
                xtype: "syno_checkbox",
                indent: 1,
                name: "enable_smb2",
                boxLabel: _T("network", "cifs_smb2_enable"),
                listeners: {
                    scope: this,
                    check: function(h, g) {
                        var e = this.getForm().findField("enable_samba").getValue();
                        var f = this.getForm().findField("enable_large_mtu");
                        f.setDisabled(!(g && e))
                    }
                }
            }, {
                xtype: "syno_checkbox",
                indent: 2,
                name: "enable_large_mtu",
                boxLabel: _T("network", "cifs_large_mtu_enable")
            }];
            Array.prototype.splice.apply(c.items, [3, 1].concat(b));
            c.webapi = {
                api: "SYNO.Core.FileServ.SMB",
                methods: {
                    get: "get",
                    set: "set"
                },
                version: 2
            }
        } else {
            if (3 === d.maxVersion) {
                Array.prototype.splice.apply(c.items, [3, 1].concat());
                c.webapi = {
                    api: "SYNO.Core.FileServ.SMB",
                    methods: {
                        get: "get",
                        set: "set"
                    },
                    version: 3
                }
            }
        }
        return c
    },
    createWSTransferTabObj: function(a) {
        var b = {
            xtype: "syno_fieldset",
            stateId: "SYNO.SDS.SMBService.SMB.WinTab::smb::wsdiscovery",
            collapsible: true,
            itemId: "wstransfer_fieldset",
            title: _T("service", "wstransfer_title"),
            items: [{
                xtype: "syno_displayfield",
                value: _T("service", "enable_wstransfer_desc")
            }, {
                xtype: "syno_checkbox",
                boxLabel: _T("service", "enable_wstransfer"),
                itemId: "enable_wstransfer",
                name: "enable_wstransfer"
            }]
        };
        return b
    },
    workgroupValidator: function(a) {
        if (!/^[\x00-\x7F]{0,15}$/.test(a)) {
            return _JSLIBSTR("vtype", "bad_networkgroupname")
        }
        return true
    },
    selectHelpText: function(d, c) {
        var a = c.ownerDocument.createRange();
        a.selectNode(c.firstChild);
        var b = window.getSelection();
        b.removeAllRanges();
        b.addRange(a)
    },
    onSmbLogSettingBtnClick: function() {
        var a = new SYNO.SDS.SMBService.SMB.SmbLogSettingDialog({
            module: this.module,
            owner: this.module.appWin
        });
        a.open()
    },
    onSmbAdvSettingBtnClick: function() {
        var b = this.getSMBAPIInfo().maxVersion;
        var a = new SYNO.SDS.SMBService.SMB.AdvancedSettingsDialog({
            module: this.module,
            owner: this.module.appWin,
            smbApiMaxVersion: b
        });
        a.open()
    },
    onBeforeRequest: function(a) {
        return true
    },
    processParams: function(f, e) {
        var d = {};
        if ("set" == f) {
            d = this.getForm().getValues();
            if (this.getForm().findField("smb_transfer_log_enable").isDirty()) {
                e = e.concat({
                    api: "SYNO.Core.SyslogClient.FileTransfer",
                    method: "set",
                    version: 1,
                    params: {
                        cifs: d.smb_transfer_log_enable
                    }
                })
            }
            this.smbChange = this.getForm().findField("enable_samba").isDirty();
            var a = this.getForm().findField("enable_samba").checked;
            if (this.smbChange) {
                this.smbTMEnable = a ? this.smbTMEnable : false;
                e = e.concat({
                    api: "SYNO.Core.FileServ.ServiceDiscovery",
                    method: "set",
                    version: 1,
                    params: {
                        enable_smb_time_machine: this.smbTMEnable
                    }
                })
            }
            var b = this.getComponent("wstransfer_fieldset");
            var c = b.getComponent("enable_wstransfer");
            if (c.isDirty()) {
                e = e.concat({
                    api: "SYNO.Core.FileServ.ServiceDiscovery.WSTransfer",
                    method: "set",
                    version: 1,
                    params: {
                        enable_wstransfer: c.checked
                    }
                })
            }
        }
        e = e.concat({
            api: "SYNO.Core.Directory.Domain",
            method: "get",
            version: 1
        });
        e = e.concat({
            api: "SYNO.Core.FileServ.ServiceDiscovery",
            method: "get",
            version: 1
        });
        e = e.concat({
            api: "SYNO.Core.SyslogClient.FileTransfer",
            method: "get",
            version: 1
        });
        e = e.concat({
            api: "SYNO.Core.Network",
            method: "get",
            version: 1
        });
        e = e.concat({
            api: "SYNO.Core.FileServ.ServiceDiscovery.WSTransfer",
            method: "get",
            version: 1
        });
        e = e.filter(function(g) {
            if (!this.getKnownAPI(g.api)) {
                return false
            }
            return true
        }, this);
        return e
    },
    processReturnData: function(a, k, h) {
        var m = false;
        var g = false;
        var b = {
            api: "SYNO.Core.SyslogClient.FileTransfer",
            method: "get",
            version: 1
        };
        var e = {
            api: "SYNO.Core.Directory.Domain",
            method: "get",
            version: 1
        };
        var f = {
            api: "SYNO.Core.Network",
            method: "get",
            version: 1
        };
        var c = {
            api: "SYNO.Core.FileServ.ServiceDiscovery",
            method: "get",
            version: 1
        };
        var d = {
            api: "SYNO.Core.FileServ.ServiceDiscovery.WSTransfer",
            method: "get",
            version: 1
        };
        for (var j = 0; j < k.result.length; j++) {
            if (true === SYNO.ux.Utils.checkApiConsistency(b, k.result[j])) {
                m = k.result[j].data.cifs
            } else {
                if (true === SYNO.ux.Utils.checkApiConsistency(e, k.result[j])) {
                    this.domainEnabled = k.result[j].data.enable_domain
                } else {
                    if (true === SYNO.ux.Utils.checkApiConsistency(f, k.result[j])) {
                        var n = Ext.util.Format.htmlEncode(k.result[j].data.server_name);
                        this.winHelpBox.update({
                            hostname: n
                        });
                        this.winHelpBox.getEl().on("click", this.selectHelpText, null, {
                            delegate: "span.link-font"
                        })
                    } else {
                        if (true === SYNO.ux.Utils.checkApiConsistency(c, k.result[j])) {
                            this.smbTMEnable = k.result[j].data.enable_smb_time_machine
                        } else {
                            if (true === SYNO.ux.Utils.checkApiConsistency(d, k.result[j])) {
                                g = k.result[j].data.enable_wstransfer
                            }
                        }
                    }
                }
            }
        }
        this.getForm().setValues({
            smb_transfer_log_enable: m,
            enable_wstransfer: g
        });
        this.getForm().loadRecords(k.result, h.compound);
        this.afterLoad();
        for (j = 0; j < k.result.length; j++) {
            if ("SYNO.Core.FileServ.SMB" === k.result[j].api && "get" === k.result[j].method) {
                var l = k.result[j].data && k.result[j].data.enable_adserver;
                this.getComponent("winFieldset").getComponent("enable_samba").setReadOnly(l);
                this.addADServerTip(l)
            }
        }
    },
    addADServerTip: function(a) {
        var b = this.getForm().findField("enable_samba");
        if (a) {
            b.wrap.dom.setAttribute("ext:qtip", _T("domain", "warr_cant_disable_due_to_service"))
        } else {
            b.wrap.dom.removeAttribute("ext:qtip")
        }
    },
    afterLoad: function() {
        var c = this.getComponent("winFieldset");
        var b = c.getComponent("enable_samba").getValue();
        var a = this.getForm().findField("smb_transfer_log_enable").getValue();
        var h = (b && a);
        var f = c.getComponent("enable_samba");
        var g = this.findAppWindow().getOpenConfig("className") === "SYNO.SDS.CMS.Application";
        var e = this.getSMBAPIInfo();
        this.onSambaCheckHandler(null, null);
        this.setWinHelpBoxVisible(b);
        if (2 === e.maxVersion) {
            var d = this.getForm().findField("enable_smb2").getValue();
            this.getForm().findField("enable_large_mtu").setDisabled(!(!!b && !!d))
        }
        c.getComponent("advanceBtnId").setDisabled(!b);
        if (g) {
            Ext.getCmp(this.smbLogBtnId).disable();
            Ext.getCmp(this.smbLogSettingsBtnId).disable()
        } else {
            Ext.getCmp(this.smbLogBtnId).setDisabled(!h);
            Ext.getCmp(this.smbLogSettingsBtnId).setDisabled(!h)
        }
        if (!this.domainEnabled) {
            if (b) {
                c.getComponent("workgroup").enable()
            } else {
                c.getComponent("workgroup").disable()
            }
            c.getComponent("workgroup_in_domain").hide();
            f.mon(f, "check", this.workgroupHandler, this)
        } else {
            c.getComponent("workgroup").disable();
            c.getComponent("workgroup_in_domain").show();
            f.mun(f, "check", this.workgroupHandler, this)
        }
        this.sendServiceEvent()
    },
    sendServiceEvent: function() {
        var a = this.getForm();
        if (this.smbChange) {
            SYNO.SDS.StatusNotifier.setServiceDisabled("SYNO.SDS.AdminCenter.WinMacNfs.SAMBA", !a.findField("enable_samba").getValue())
        }
    },
    workgroupHandler: function(b, a) {
        var c = this.getComponent("winFieldset").getComponent("workgroup");
        if (a) {
            c.enable()
        } else {
            c.disable()
        }
    },
    onSambaCheckHandler: function(c, a) {
        var b = this.getComponent("winFieldset").getComponent("enable_samba").getValue();
        var d = this.getComponent("winFieldset").getComponent("sambaNoteId");
        d.el.set({
            tabIndex: (b ? 0 : -1)
        });
        d.originalValue = d.getValue()
    },
    getSMBAPIInfo: function() {
        var a = this.getKnownAPI("SYNO.Core.FileServ.SMB");
        if (!a) {
            a = {
                maxVersion: -1,
                minVersion: -1
            }
        }
        return a
    }
});
Ext.define("SYNO.SDS.SMBService.SMB.WinTab.Utils", {
    statics: {
        onClickShareUrl: function(a) {
            a.findAppWindow().startModule("SYNO.SDS.AdminCenter.Share.Main")
        },
        onClickFileIndexUrl: function(a) {
            SYNO.SDS.AppLaunch("SYNO.Finder.Application", {
                fn: "preference"
            })
        }
    }
});
