/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.SMBService.Domain.Filter
 * @extends SYNO.ux.ComboBox
 * SMBService filter class
 *
 */
Ext.define("SYNO.SDS.SMBService.Domain.Filter", {
    extend: "SYNO.ux.ComboBox",
    constructor: function(b) {
        var a = Ext.apply({
            width: 100,
            hideLabel: false,
            valueField: "value",
            displayField: "domain",
            store: {
                xtype: "arraystore",
                autoDestroy: true,
                fields: ["domain", "value", "comment"]
            },
            resizable: true,
            mode: "local",
            triggerAction: "all",
            editable: false,
            value: "",
            tpl: '<tpl for="."><div ext:qtip="{comment}" class="x-combo-list-item">{domain}</div></tpl>',
            forceSelection: true,
            listeners: {
                select: this.onSelect
            }
        }, b);
        this.callParent([a])
    },
    updateList: function(a) {
        var d = [];
        var b = true;
        var c = function(e) {
            return [Ext.util.Format.htmlEncode(e[0]), e[1], Ext.util.Format.htmlEncode(Ext.util.Format.htmlEncode(e[2]))]
        };
        Ext.each(a, function(e) {
            var f = c(e);
            if (typeof f === "object") {
                d.push(f);
                if (f[1] && f[1] === this.getValue()) {
                    b = false
                }
            } else {
                d.push([f, f, f]);
                if (f === this.getValue()) {
                    b = false
                }
            }
        }, this);
        this.getStore().loadData(d);
        if (b && 0 !== d.length) {
            this.setValue(d[0][1] || "");
            this.module.currDomain = d[0][1] || ""
        }
    },
    onSelect: function(a, c) {
        var d = "";
        var b = this.grid.getStore();
        if (this.grid && a.data && a.data.value) {
            d = a.data.value
        }
        this.module.currDomain = d;
        b.baseParams.domain_name = this.module.currDomain;
        b.load({
            params: {
                offset: 0
            }
        });
        this.collapse()
    }
});
