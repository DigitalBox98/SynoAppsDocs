/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.SMBService.SMB.SmbLogSettingDialog
 * @extends SYNO.SDS.ModalWindow
 * SMBService log settings dialog class
 *
 */
Ext.define("SYNO.SDS.SMBService.SMB.SmbLogSettingDialog", {
    extend: "SYNO.SDS.ModalWindow",
    constructor: function(a) {
        this.module = a.module;
        this.panel = this.configForm();
        var b = Ext.apply({
            title: _T("service", "transfer_log_settings"),
            autoDestroy: true,
            resizable: false,
            width: 552,
            height: 240,
            autoHeight: true,
            layout: "fit",
            border: false,
            closeAction: "cancelHandler",
            items: [this.panel],
            buttons: [{
                btnStyle: "grey",
                text: _T("common", "cancel"),
                scope: this,
                handler: this.cancelHandler
            }, {
                btnStyle: "blue",
                disabled: this._S("demo_mode"),
                tooltip: this._S("demo_mode") ? _JSLIBSTR("uicommon", "error_demo") : "",
                text: _T("common", "save"),
                scope: this,
                handler: this.applyHandler
            }]
        }, a);
        this.callParent([b]);
        this.mon(this, "show", this.load, this)
    },
    configForm: function() {
        var a = {
            border: false,
            height: 187,
            padding: 0,
            items: [{
                xtype: "syno_displayfield",
                value: _T("service", "transfer_log_settings_desc")
            }, {
                xtype: "syno_compositefield",
                hideLabel: true,
                items: [{
                    xtype: "syno_checkbox",
                    name: "create",
                    width: "160",
                    hight: "28",
                    boxLabel: _T("service", "transfer_log_create")
                }, {
                    xtype: "syno_checkbox",
                    name: "write",
                    width: "160",
                    hight: "28",
                    boxLabel: _T("service", "transfer_log_write")
                }, {
                    xtype: "syno_checkbox",
                    name: "move",
                    width: "160",
                    hight: "28",
                    boxLabel: _T("service", "transfer_log_move")
                }]
            }, {
                xtype: "syno_compositefield",
                hideLabel: true,
                items: [{
                    xtype: "syno_checkbox",
                    name: "delete",
                    width: "160",
                    hight: "28",
                    boxLabel: _T("service", "transfer_log_delete")
                }, {
                    xtype: "syno_checkbox",
                    name: "read",
                    width: "160",
                    hight: "28",
                    boxLabel: _T("service", "transfer_log_read")
                }, {
                    xtype: "syno_checkbox",
                    name: "rename",
                    width: "160",
                    hight: "28",
                    boxLabel: _T("service", "transfer_log_rename")
                }]
            }, {
                xtype: "syno_compositefield",
                hideLabel: true,
                items: [{
                    xtype: "syno_checkbox",
                    name: "permission change",
                    width: "160",
                    hight: "28",
                    boxLabel: _T("service", "transfer_log_permission_change")
                }]
            }]
        };
        return new SYNO.SDS.Utils.FormPanel(a)
    },
    applyHandler: function() {
        var a = this.panel.getForm();
        if (!a.isDirty()) {
            this.close();
            return false
        }
        this.getMsgBox().confirm(_T("tree", "leaf_winmacnfs"), _T("network", "service_restart_warning") + " " + _T("common", "ask_cont"), function(d, c, b) {
            if ("yes" == d) {
                this.submit(a)
            }
        }, this)
    },
    submit: function(b) {
        var a = {};
        var c = ["create", "write", "move", "delete", "read", "rename", "permission change"];
        c.forEach(function(d) {
            if (b.findField(d).getValue()) {
                a[d] = "1"
            } else {
                a[d] = "0"
            }
        });
        this.setStatusBusy({
            text: _T("common", "loading")
        });
        this.sendWebAPI({
            scope: this,
            api: "SYNO.Core.SyslogClient.FileTransfer",
            method: "set_level",
            version: 1,
            params: {
                protocol: "cifs",
                loglevel: a
            },
            callback: function(f, e, d) {
                this.clearStatusBusy();
                if (f) {
                    this.close();
                    return true
                } else {
                    this.setStatusError()
                }
            }
        })
    },
    cancelHandler: function() {
        var a = {
            dontSave: function() {
                this.close()
            },
            cancel: Ext.emptyFn,
            save: function() {
                this.applyHandler()
            }
        };
        if (this.panel.getForm().isDirty()) {
            this.confirmLostChangePromise(a, this)
        } else {
            this.close()
        }
    },
    load: function() {
        this.setStatusBusy({
            text: _T("common", "loading")
        });
        this.sendWebAPI({
            scope: this,
            api: "SYNO.Core.SyslogClient.FileTransfer",
            method: "get_level",
            version: 1,
            params: {
                protocol: "cifs"
            },
            callback: function(c, b, a) {
                this.clearStatusBusy();
                if (c) {
                    this.panel.getForm().setValues(b)
                }
            }
        })
    }
});
