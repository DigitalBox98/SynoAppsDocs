/* Copyright (c) 2020 Synology Inc. All rights reserved. */

/**
 * @class SYNO.SDS.SMBService.SMB.MacTab
 * @extends SYNO.SDS.Utils.FormPanel
 * SMBService mac tab class
 *
 */
Ext.define("SYNO.SDS.SMBService.SMB.MacTab", {
    extend: "SYNO.SDS.Utils.FormPanel",
    constructor: function(a) {
        this.module = a.module;
        var b = Ext.apply(this.fillConfig(), a);
        this.callParent([b])
    },
    loadConfirmHook: function(a) {
        this.mon(this.getComponent("enable_syno_catia"), "check", this.confirmCatia, this)
    },
    fillConfig: function() {
        var a = {
            autoscroll: true,
            title: _T("network", "smb_mac"),
            border: false,
            itemId: "mac_tab",
            trackResetOnLoad: true,
            height: 430,
            width: 250,
            padding: 8,
            labelWidth: 250,
            items: [{
                xtype: "syno_checkbox",
                name: "enable_syno_catia",
                itemId: "enable_syno_catia",
                boxLabel: _T("network", "smb_enable_syno_catia")
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                value: _T("network", "suggest_mac_user_to_enable_catia")
            }, {
                xtype: "spacer",
                height: 10
            }, {
                xtype: "syno_checkbox",
                name: "enable_fruit_locking",
                itemId: "enable_fruit_locking",
                boxLabel: _T("network", "smb_fruit_locking")
            }, {
                xtype: "syno_displayfield",
                indent: 1,
                value: _T("network", "smb_enable_durable_handles_warn_fruit_locking")
            }]
        };
        return a
    },
    confirmCatia: function(b, d) {
        var e = this.ownerCt.othersTab;
        var c = e.getComponent("enable_symlink").getValue();
        if (d) {
            var a = "";
            if (!c) {
                a = a + _T("network", "cifs_enable_catia_warn_symlink") + "<p />"
            }
            a = a + _T("network", "cifs_enable_catia_warn");
            a = a + "<p />" + _T("common", "cfrm_continue");
            this.ownerCt.ownerCt.getMsgBox().confirm(_T("tree", "leaf_winmacnfs"), a, function(f) {
                if ("no" == f) {
                    var g = this.getComponent("enable_syno_catia");
                    g.suspendEvents(false);
                    g.setValue(false);
                    g.resumeEvents()
                } else {
                    e.getComponent("enable_symlink").setValue(true)
                }
            }, this)
        } else {
            if (!d) {
                this.ownerCt.ownerCt.getMsgBox().confirm(_T("tree", "leaf_winmacnfs"), _T("network", "cifs_disable_catia_warn") + "<p />" + _T("common", "cfrm_continue"), function(f) {
                    if ("no" == f) {
                        var g = this.getComponent("enable_syno_catia");
                        g.suspendEvents(false);
                        g.setValue(true);
                        g.resumeEvents()
                    }
                }, this)
            }
        }
    }
});
